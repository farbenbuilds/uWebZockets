# Incomplete WebTransport child-stream checkpoint

This incremental bundle requires the prior stream-credit proposal
9f0088c58fe67cccf1871dc172c90c2ec6f97944 and retains checkpoint
a1947ce3a4ceeb98413e53014cc87f72b6d89869. Restore the prior archived proposal chain,
then run git bundle verify, fetch this bundle's HEAD and check out the fetched
commit. Verify proposal-inputs.sha256 at that checkout. The matching source
files and native Zig scaffold are included. This material is a review archive;
it is not a production overlay, published fork commit or dependency pin.

The native scaffold requires Zig 0.16.0 and its unchanged exact dependencies.
Relocate -Dlsquic-source, -Dfixture, -Dfixture-includes and -Dfixture-support
paths in the original commands. All three child fixtures use the matching
uwz_quic_fixture.h, shared uwz_webtransport_fixture.h and support C file.
Use -Dfixture-hooks=true and ulimit -c 0. run-streams.py is an external
verification driver: relocate its hard-coded paths. Its process exit status
is not a cohort result; inspect each manifest record and original native log.

checkpoint-results.json lists the fresh Debug results against this exact
checkpoint: six normal child scenarios, ten reset scenarios and 25 prefix
classification scenarios pass. The separate pending-reset case fails at the
assertion that typed notification precedes on_reset. With peer SETTINGS still
pending, reset visibility can run too early. This is an unresolved functional
failure, not a skipped smoke/security check. No assertion was weakened.

Earlier ReleaseSafe/ReleaseFast normal-child runs and four focused upstream
Debug runs are historical results against the source hashes in their
manifests. They are not full final-checkpoint validation. Earlier genuine
REDs and fixture setup failures are retained separately in original logs.
Some intermediate uncommitted source versions no longer exist; these are
listed explicitly in historical-input-map.json. Current source and fixtures
are fully retained by the bundle and source manifest. No full 83-case suite,
foreign runtime run, final cross-target gate or completed independent review
is claimed for this unfinished child-stream checkpoint.

Next work: defer reset visibility and callbacks until classification is
published; cover STOP before typed notification and preservation of an
unpacketized prefix; test pending/negative negotiation and loss/recovery;
review final ABI/lifetimes and re-run the functional gates. Then complete
external interoperability, reviewed fork publication, synchronized pins and
bounded Zig connection/session/stream integration. The existing public
App.datagram interface remains the integration target. Smoke/security runs
remain deferred to the user. WebTransport and v2.3.0 remain incomplete.

The archive excludes dependency caches, compiled binaries and generated
fixture private keys. files.sha256 covers every archive payload file except
itself. Root production sources, pins and capability bits are unchanged.
