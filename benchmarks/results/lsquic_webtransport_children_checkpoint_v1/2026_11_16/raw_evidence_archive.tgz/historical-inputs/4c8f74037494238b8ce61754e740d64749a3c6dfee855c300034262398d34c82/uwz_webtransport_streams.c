/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/queue.h>

#include <openssl/ssl.h>

#include "lsquic.h"
#include "lsxpack_header.h"
#include "uwz_quic_fixture.h"

#ifdef NDEBUG
#error "uwz_webtransport_streams requires active assertions"
#endif

enum {
    STREAMS_MAX_STEPS = 20000,
    STREAMS_MAX_STREAMS = 8,
    STREAMS_CANARY = 0xA5,
    STREAMS_MAX_HSETS = 8,
    STREAMS_MAX_HEADERS = 16,
    STREAMS_HEADER_BYTES = 1024,
};

struct streams_endpoint;
struct streams_header_pool;

struct streams_header_field {
    struct lsxpack_header shf_header;
    char shf_bytes[STREAMS_HEADER_BYTES];
};

struct streams_header_set {
    struct streams_header_pool *shs_pool;
    unsigned shs_active;
    unsigned shs_complete;
    unsigned shs_count;
    struct streams_header_field shs_fields[STREAMS_MAX_HEADERS];
};

struct streams_header_pool {
    unsigned shp_created;
    unsigned shp_discarded;
    struct streams_header_set shp_sets[STREAMS_MAX_HSETS];
};

struct streams_state {
    struct streams_endpoint *ss_endpoint;
    lsquic_stream_t *ss_stream;
    lsquic_stream_id_t ss_id;
    unsigned ss_new_context;
    unsigned ss_hsets;
    unsigned ss_notifications;
    unsigned ss_callback_before_close;
    unsigned ss_fin;
    unsigned ss_closed;
    size_t ss_received;
    int ss_new_result;
    int ss_notification_result;
    int ss_close_result;
    struct lsquic_webtransport_stream_info ss_new_info;
    struct lsquic_webtransport_stream_info ss_notification_info;
    struct lsquic_webtransport_stream_info ss_close_info;
    unsigned char ss_bytes[128];
};

struct streams_endpoint {
    lsquic_conn_t *se_conn;
    unsigned se_server;
    unsigned se_handshake_ok;
    unsigned se_settings_count;
    unsigned se_stream_count;
    unsigned se_closed;
    struct streams_state se_streams[STREAMS_MAX_STREAMS];
    struct streams_header_pool se_headers;
};

struct streams_fixture {
    struct lsquic_test_pair sf_transport;
    struct streams_endpoint sf_client;
    struct streams_endpoint sf_server;
};

struct streams_info_probe {
    unsigned char sip_before[8];
    struct lsquic_webtransport_stream_info sip_info;
    unsigned char sip_after[8];
};

static const unsigned char child_payload[] = { 0x41, 0, 0xFF, 'r', 'a', 'w' };
static const unsigned char child_reply[] = { 0x41, 0x41, 0, 0xFE, 'r', 'e', 'p', 'l', 'y' };
static const unsigned char client_capsule[] = { 0x21, 2, 'o', 'k' };
static const unsigned char server_capsule[] = { 0x21, 2, 'h', 'i' };


static void *
create_header_set (void *ctx, lsquic_stream_t *stream, int is_push)
{
    struct streams_header_pool *pool = ctx;
    struct streams_header_set *set;
    unsigned index;

    (void) stream;
    assert(pool && !is_push);
    for (index = 0; index < STREAMS_MAX_HSETS; ++index)
    {
        set = &pool->shp_sets[index];
        if (set->shs_active)
            continue;
        memset(set, 0, sizeof(*set));
        set->shs_pool = pool;
        set->shs_active = 1;
        ++pool->shp_created;
        return set;
    }
    assert(0 && "bounded decoded header-set pool exhausted");
    return NULL;
}


static struct lsxpack_header *
prepare_header (void *ctx, struct lsxpack_header *header, size_t space)
{
    struct streams_header_set *set = ctx;
    struct streams_header_field *field;

    assert(set->shs_active && !set->shs_complete);
    assert(set->shs_count < STREAMS_MAX_HEADERS && space <= STREAMS_HEADER_BYTES);
    field = &set->shs_fields[set->shs_count];
    if (!header)
        lsxpack_header_prepare_decode(&field->shf_header, field->shf_bytes,
                                     0, sizeof(field->shf_bytes));
    else
    {
        assert(header == &field->shf_header);
        assert(header->buf == field->shf_bytes && header->name_offset >= 0);
        assert((size_t) header->name_offset + space <= sizeof(field->shf_bytes));
        header->val_len = (lsxpack_strlen_t) space;
    }
    return &field->shf_header;
}


static int
process_header (void *ctx, struct lsxpack_header *header)
{
    struct streams_header_set *set = ctx;
    struct streams_header_field *field;

    assert(set->shs_active && !set->shs_complete);
    if (!header)
    {
        set->shs_complete = 1;
        return 0;
    }
    assert(set->shs_count < STREAMS_MAX_HEADERS);
    field = &set->shs_fields[set->shs_count];
    assert(header == &field->shf_header && header->buf == field->shf_bytes);
    assert(header->name_offset >= 0 && header->val_offset >= 0 && header->name_len);
    assert((size_t) header->name_offset + header->name_len <= sizeof(field->shf_bytes));
    assert((size_t) header->val_offset + header->val_len <= sizeof(field->shf_bytes));
    ++set->shs_count;
    return 0;
}


static void
discard_header_set (void *ctx)
{
    struct streams_header_set *set = ctx;

    assert(set->shs_active && set->shs_pool);
    set->shs_active = 0;
    ++set->shs_pool->shp_discarded;
}


static const struct lsquic_hset_if streams_hsi = {
    .hsi_create_header_set = create_header_set,
    .hsi_prepare_decode = prepare_header,
    .hsi_process_header = process_header,
    .hsi_discard_header_set = discard_header_set,
};


static int
query_info (const lsquic_stream_t *stream, struct lsquic_webtransport_stream_info *out)
{
    struct streams_info_probe probe;
    unsigned char before[sizeof(probe)];
    size_t index;
    int result;

    memset(&probe, STREAMS_CANARY, sizeof(probe));
    memcpy(before, &probe, sizeof(probe));
    result = lsquic_stream_get_webtransport_info(stream, &probe.sip_info);
    for (index = 0; index < sizeof(probe.sip_before); ++index)
        assert(probe.sip_before[index] == STREAMS_CANARY);
    for (index = 0; index < sizeof(probe.sip_after); ++index)
        assert(probe.sip_after[index] == STREAMS_CANARY);
    if (result == LSQUIC_WTS_OK)
        *out = probe.sip_info;
    else
        assert(0 == memcmp(before, &probe, sizeof(probe)));
    return result;
}


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct streams_endpoint *endpoint = ctx;

    assert(!endpoint->se_conn);
    endpoint->se_conn = conn;
    if (endpoint->se_server)
        endpoint->se_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct streams_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(status == LSQ_HSK_OK);
    endpoint->se_handshake_ok = 1;
}


static void
settings_received (lsquic_conn_t *conn)
{
    struct streams_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);
    struct lsquic_webtransport_peer peer;

    assert(endpoint && endpoint->se_conn == conn);
    ++endpoint->se_settings_count;
    assert(LSQUIC_WTP_OK == lsquic_conn_get_webtransport_peer(conn, &peer));
    assert(peer.flags == (endpoint->se_server ? 29U : 31U));
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct streams_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint && endpoint->se_conn == conn && !endpoint->se_closed);
    endpoint->se_closed = 1;
    endpoint->se_conn = NULL;
    lsquic_conn_set_ctx(conn, NULL);
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct streams_endpoint *endpoint = ctx;
    struct streams_state *state;

    assert(stream && endpoint->se_stream_count < STREAMS_MAX_STREAMS);
    state = &endpoint->se_streams[endpoint->se_stream_count++];
    state->ss_endpoint = endpoint;
    state->ss_stream = stream;
    state->ss_id = lsquic_stream_id(stream);
    state->ss_new_context = 1;
    state->ss_new_result = query_info(stream, &state->ss_new_info);
    return (lsquic_stream_ctx_t *) state;
}


static void
header_set_received (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct streams_state *state = (void *) ctx;

    assert(state && state->ss_stream == stream && state->ss_id == 0);
    ++state->ss_hsets;
}


static void
webtransport_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct streams_state *state = (void *) ctx;

    assert(state && state->ss_stream == stream && state->ss_new_context);
    ++state->ss_notifications;
    state->ss_callback_before_close = !state->ss_closed;
    state->ss_notification_result = query_info(stream, &state->ss_notification_info);
    assert(state->ss_id != 0);
    if (!(state->ss_notification_info.flags & LSQUIC_WTSF_UNI)
        || (state->ss_id & 1) != state->ss_endpoint->se_server)
        assert(lsquic_stream_wantread(stream, 1) >= 0);
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct streams_state *state = (void *) ctx;
    unsigned char bytes[32];
    ssize_t size;

    while (1)
    {
        size = lsquic_stream_read(stream, bytes, sizeof(bytes));
        if (size > 0)
        {
            assert((size_t) size <= sizeof(state->ss_bytes) - state->ss_received);
            memcpy(state->ss_bytes + state->ss_received, bytes, size);
            state->ss_received += size;
            continue;
        }
        if (size < 0)
        {
            assert(errno == EAGAIN || errno == EWOULDBLOCK);
            return;
        }
        assert(state->ss_id != 0 && !state->ss_fin);
        state->ss_fin = 1;
        assert(lsquic_stream_wantread(stream, 0) >= 0);
        assert(0 == lsquic_stream_shutdown(stream, 0));
        return;
    }
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) stream;
    (void) ctx;
    assert(0 && "stream fixture writes through public synchronous APIs");
}


static void
close_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct streams_state *state = (void *) ctx;

    assert(state && state->ss_stream == stream && !state->ss_closed);
    state->ss_close_result = query_info(stream, &state->ss_close_info);
    state->ss_closed = 1;
    state->ss_stream = NULL;
}


static void
stream_reset (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx, int how)
{
    struct streams_state *state = (void *) ctx;
    uint64_t error = UINT64_MAX;
    int result;

    assert(state && state->ss_stream == stream);
    result = lsquic_stream_get_reset_error(stream, how, &error);
    printf("unexpected stream reset: role=%s stream=%llu how=%d getter=%d error=%llu\n",
           state->ss_endpoint->se_server ? "server" : "client",
           (unsigned long long) state->ss_id, how, result, (unsigned long long) error);
    assert(0 && "valid CONNECT and child streams must not reset");
}


static const struct lsquic_stream_if streams_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_h3_settings = settings_received,
    .on_new_stream = new_stream,
    .on_hset_in = header_set_received,
    .on_webtransport_stream = webtransport_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_reset = stream_reset,
};


static void
pump_step (struct streams_fixture *fixture)
{
    lsquic_test_pair_process(&fixture->sf_transport, 1000);
    lsquic_test_deliver_all(&fixture->sf_transport.ltp_client);
    lsquic_test_deliver_all(&fixture->sf_transport.ltp_server);
}


static void
init_endpoint (struct streams_fixture *fixture, unsigned server)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct streams_endpoint *endpoint;
    struct lsquic_test_endpoint *transport, *peer;
    unsigned flags = LSENG_HTTP | (server ? LSENG_SERVER : 0);

    endpoint = server ? &fixture->sf_server : &fixture->sf_client;
    endpoint->se_server = server;
    transport = server ? &fixture->sf_transport.ltp_server
                       : &fixture->sf_transport.ltp_client;
    peer = server ? &fixture->sf_transport.ltp_client
                  : &fixture->sf_transport.ltp_server;
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = 8;
    settings.es_init_max_streams_bidi = 8;
    settings.es_max_streams_in = 8;
    settings.es_init_max_stream_data_bidi_local = 65536;
    settings.es_init_max_stream_data_bidi_remote = 65536;
    settings.es_init_max_stream_data_uni = 65536;
    settings.es_qpack_dec_max_size = 0;
    settings.es_qpack_dec_max_blocked = 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    settings.es_datagrams = 1;
    settings.es_reset_stream_at = 1;
    settings.es_webtransport.enabled = 1;
    settings.es_webtransport.initial_max_data = 65536;
    settings.es_webtransport.initial_max_streams_bidi = 16;
    settings.es_webtransport.initial_max_streams_uni = 16;
    assert(0 == lsquic_engine_check_settings(&settings, flags, NULL, 0));
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &streams_callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_hsi_if = &streams_hsi;
    config.ltec_hsi_ctx = &endpoint->se_headers;
    config.ltec_alpn = "h3";
    config.ltec_tls = lsquic_test_tls_context_new(server, "h3");
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(transport, peer, &config,
                                        server ? 12901 : 12902));
    SSL_CTX_free(config.ltec_tls);
}


static void
start_fixture (struct streams_fixture *fixture)
{
    unsigned step;

    memset(fixture, 0, sizeof(*fixture));
    init_endpoint(fixture, 0);
    init_endpoint(fixture, 1);
    assert(lsquic_engine_connect(fixture->sf_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture->sf_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture->sf_transport.ltp_server.lte_address,
                &fixture->sf_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        if (fixture->sf_client.se_handshake_ok && fixture->sf_server.se_handshake_ok
            && fixture->sf_client.se_settings_count && fixture->sf_server.se_settings_count)
            break;
        pump_step(fixture);
    }
    assert(step < STREAMS_MAX_STEPS);
    assert(fixture->sf_client.se_settings_count == 1 && fixture->sf_server.se_settings_count == 1);
    for (step = 0; step < 20; ++step)
        pump_step(fixture);
    assert(!fixture->sf_client.se_stream_count && !fixture->sf_server.se_stream_count);
}


static struct streams_state *
find_stream (struct streams_endpoint *endpoint, lsquic_stream_id_t id)
{
    unsigned index;

    for (index = 0; index < endpoint->se_stream_count; ++index)
        if (endpoint->se_streams[index].ss_id == id)
            return &endpoint->se_streams[index];
    return NULL;
}


static void
send_connect (lsquic_stream_t *stream)
{
    /* draft-ietf-webtrans-http3-16 Section 3.2 requires webtransport-h3. */
    static const char *const fields[] = {
        ":methodCONNECT", ":protocolwebtransport-h3", ":schemehttps",
        ":authoritylocalhost", ":path/wt", "originhttps://localhost",
    };
    static const unsigned name_sizes[] = { 7, 9, 7, 10, 5, 6 };
    struct lsxpack_header encoded[6];
    struct lsquic_http_headers headers = { 6, encoded };
    unsigned index;

    for (index = 0; index < 6; ++index)
        lsxpack_header_set_offset2(&encoded[index], fields[index], 0,
                    name_sizes[index], name_sizes[index], strlen(fields[index]) - name_sizes[index]);
    assert(0 == lsquic_stream_send_headers(stream, &headers, 0));
    assert(0 == lsquic_stream_flush(stream));
}


static void
send_success (lsquic_stream_t *stream)
{
    static const char status[] = ":status200";
    struct lsxpack_header encoded;
    struct lsquic_http_headers headers = { 1, &encoded };

    lsxpack_header_set_offset2(&encoded, status, 0, 7, 7, 3);
    assert(0 == lsquic_stream_send_headers(stream, &headers, 0));
    assert(0 == lsquic_stream_flush(stream));
}


static void
assert_header_value (const struct streams_header_set *set,
                     const char *name, const char *value)
{
    const struct lsxpack_header *header;
    size_t name_size = strlen(name), value_size = strlen(value);
    unsigned index, matches = 0;

    for (index = 0; index < set->shs_count; ++index)
    {
        header = &set->shs_fields[index].shf_header;
        if (header->name_len != name_size
            || 0 != memcmp(lsxpack_header_get_name(header), name, name_size))
            continue;
        ++matches;
        assert(header->val_len == value_size);
        assert(0 == memcmp(lsxpack_header_get_value(header), value, value_size));
    }
    assert(matches == 1);
}


static void
claim_headers (struct streams_state *state, unsigned request)
{
    struct streams_header_set *set;

    assert(state && state->ss_stream && state->ss_hsets == 1);
    set = lsquic_stream_get_hset(state->ss_stream);
    assert(set && set->shs_active && set->shs_complete);
    if (request)
    {
        assert(set->shs_count == 6);
        assert_header_value(set, ":method", "CONNECT");
        assert_header_value(set, ":protocol", "webtransport-h3");
        assert_header_value(set, ":scheme", "https");
        assert_header_value(set, ":authority", "localhost");
        assert_header_value(set, ":path", "/wt");
        assert_header_value(set, "origin", "https://localhost");
    }
    else
    {
        assert(set->shs_count == 1);
        assert_header_value(set, ":status", "200");
    }
    discard_header_set(set);
}


static void
assert_parent (struct streams_state *state, unsigned local)
{
    struct lsquic_webtransport_stream_info info;

    assert(state && state->ss_stream && !state->ss_closed && !state->ss_notifications);
    assert(LSQUIC_WTS_OK == query_info(state->ss_stream, &info));
    assert(info.session_id == 0);
    assert(info.flags == (LSQUIC_WTSF_CONNECT | (local ? LSQUIC_WTSF_LOCAL : 0)));
    assert(info.send_prefix_size == 0 && info.receive_prefix_size == 0);
}


static void
establish_parent (struct streams_fixture *fixture)
{
    struct streams_state *client, *server = NULL;
    unsigned step;

    lsquic_conn_make_stream(fixture->sf_client.se_conn);
    client = find_stream(&fixture->sf_client, 0);
    assert(client && client->ss_stream);
    send_connect(client->ss_stream);
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        server = find_stream(&fixture->sf_server, 0);
        if (server && server->ss_hsets)
            break;
        pump_step(fixture);
    }
    assert(step < STREAMS_MAX_STEPS);
    claim_headers(server, 1);
    assert(LSQUIC_MWTS_OK == lsquic_stream_accept_webtransport(server->ss_stream));
    send_success(server->ss_stream);
    for (step = 0; step < STREAMS_MAX_STEPS && !client->ss_hsets; ++step)
        pump_step(fixture);
    assert(step < STREAMS_MAX_STEPS);
    claim_headers(client, 0);
    assert(LSQUIC_MWTS_OK == lsquic_stream_accept_webtransport(client->ss_stream));
    assert_parent(client, 1);
    assert_parent(server, 0);
    assert(lsquic_stream_wantread(client->ss_stream, 1) >= 0);
    assert(lsquic_stream_wantread(server->ss_stream, 1) >= 0);
    assert(sizeof(client_capsule) == (size_t) lsquic_stream_write(client->ss_stream,
                                                        client_capsule, sizeof(client_capsule)));
    assert(0 == lsquic_stream_flush(client->ss_stream));
    assert(sizeof(server_capsule) == (size_t) lsquic_stream_write(server->ss_stream,
                                                        server_capsule, sizeof(server_capsule)));
    assert(0 == lsquic_stream_flush(server->ss_stream));
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        if (client->ss_received == sizeof(server_capsule)
            && server->ss_received == sizeof(client_capsule))
            break;
        pump_step(fixture);
    }
    assert(step < STREAMS_MAX_STEPS);
    assert(0 == memcmp(client->ss_bytes, server_capsule, sizeof(server_capsule)));
    assert(0 == memcmp(server->ss_bytes, client_capsule, sizeof(client_capsule)));
    assert(!client->ss_fin && !server->ss_fin);
}


static void
assert_child_info (const struct lsquic_webtransport_stream_info *info,
                   unsigned local, unsigned uni)
{
    assert(info->session_id == 0);
    assert(info->flags == (LSQUIC_WTSF_CHILD | (uni ? LSQUIC_WTSF_UNI : 0)
                                            | (local ? LSQUIC_WTSF_LOCAL : 0)));
    assert(info->send_prefix_size == (local ? 3U : 0U));
    assert(info->receive_prefix_size == (local ? 0U : 3U));
}


static void
test_child (unsigned server_sender, unsigned uni)
{
    struct streams_fixture fixture;
    struct streams_endpoint *sender, *receiver;
    struct streams_state *outgoing, *incoming = NULL;
    unsigned before, step;

    start_fixture(&fixture);
    establish_parent(&fixture);
    sender = server_sender ? &fixture.sf_server : &fixture.sf_client;
    receiver = server_sender ? &fixture.sf_client : &fixture.sf_server;
    before = sender->se_stream_count;
    assert(LSQUIC_MWTS_OK == lsquic_conn_make_webtransport_stream(sender->se_conn,
                                                0, uni ? LSQUIC_WTS_UNI : LSQUIC_WTS_BIDI));
    assert(sender->se_stream_count == before + 1);
    outgoing = &sender->se_streams[before];
    assert(outgoing->ss_stream && !!(outgoing->ss_id & 2) == !!uni);
    for (step = 0; step < STREAMS_MAX_STEPS && !outgoing->ss_notifications; ++step)
        pump_step(&fixture);
    assert(step < STREAMS_MAX_STEPS);
    assert(outgoing->ss_notifications == 1 && outgoing->ss_callback_before_close);
    assert(outgoing->ss_notification_result == LSQUIC_WTS_OK);
    assert_child_info(&outgoing->ss_notification_info, 1, uni);
    assert(sizeof(child_payload) == (size_t) lsquic_stream_write(outgoing->ss_stream,
                                                        child_payload, sizeof(child_payload)));
    assert(0 == lsquic_stream_shutdown(outgoing->ss_stream, 1));
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        incoming = find_stream(receiver, outgoing->ss_id);
        if (incoming && incoming->ss_fin && incoming->ss_received == sizeof(child_payload)
            && (!uni || (outgoing->ss_closed && incoming->ss_closed)))
            break;
        pump_step(&fixture);
    }
    assert(step < STREAMS_MAX_STEPS);
    assert(incoming->ss_notifications == 1 && incoming->ss_callback_before_close);
    assert(incoming->ss_notification_result == LSQUIC_WTS_OK);
    assert_child_info(&incoming->ss_notification_info, 0, uni);
    assert(incoming->ss_fin && incoming->ss_received == sizeof(child_payload));
    assert(0 == memcmp(incoming->ss_bytes, child_payload, sizeof(child_payload)));
    if (!uni)
    {
        assert(incoming->ss_new_result == LSQUIC_WTS_PENDING
            || incoming->ss_new_result == LSQUIC_WTS_OK);
        if (incoming->ss_new_result == LSQUIC_WTS_OK)
            assert_child_info(&incoming->ss_new_info, 0, 0);
        assert(incoming->ss_stream && outgoing->ss_stream);
        assert(!incoming->ss_closed && !outgoing->ss_closed);
        assert(sizeof(child_reply) == (size_t) lsquic_stream_write(incoming->ss_stream,
                                                        child_reply, sizeof(child_reply)));
        assert(0 == lsquic_stream_shutdown(incoming->ss_stream, 1));
        for (step = 0; step < STREAMS_MAX_STEPS; ++step)
        {
            if (outgoing->ss_closed && incoming->ss_closed)
                break;
            pump_step(&fixture);
        }
        assert(step < STREAMS_MAX_STEPS);
        assert(outgoing->ss_fin && outgoing->ss_received == sizeof(child_reply));
        assert(0 == memcmp(outgoing->ss_bytes, child_reply, sizeof(child_reply)));
    }
    assert(outgoing->ss_closed && incoming->ss_closed);
    assert(outgoing->ss_notifications == 1 && incoming->ss_notifications == 1);
    assert(outgoing->ss_close_result == LSQUIC_WTS_OK && incoming->ss_close_result == LSQUIC_WTS_OK);
    assert_child_info(&outgoing->ss_close_info, 1, uni);
    assert_child_info(&incoming->ss_close_info, 0, uni);
    assert_parent(find_stream(&fixture.sf_client, 0), 1);
    assert_parent(find_stream(&fixture.sf_server, 0), 0);
    assert(fixture.sf_client.se_conn && fixture.sf_server.se_conn);
    lsquic_test_endpoint_destroy(&fixture.sf_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture.sf_transport.ltp_server);
    assert(fixture.sf_client.se_headers.shp_created == fixture.sf_client.se_headers.shp_discarded);
    assert(fixture.sf_server.se_headers.shp_created == fixture.sf_server.se_headers.shp_discarded);
    printf("PASS native WebTransport %s: %s sender/real CONNECT+nonFIN2xx/HTTP-framed parent capsules/raw child payload+FIN/directional prefix3/typed context once/close info\n",
           uni ? "uni" : "bidi with raw0x41 reply", server_sender ? "server" : "client");
}


int
main (int argc, char **argv)
{
    struct lsquic_webtransport_stream_info ignored;
    unsigned uni_client, uni_server, bidi_client, bidi_server;

    assert(argc <= 2);
    assert(LSQUIC_WTS_BIDI == 0 && LSQUIC_WTS_UNI == 1);
    assert(LSQUIC_WTS_OK == 0 && LSQUIC_WTS_PENDING == 1);
    assert(LSQUIC_WTS_INVALID == -1 && LSQUIC_WTS_UNSUPPORTED == -2);
    assert(LSQUIC_WTSF_CONNECT == 1 && LSQUIC_WTSF_CHILD == 2);
    assert(LSQUIC_WTSF_LOCAL == 4 && LSQUIC_WTSF_UNI == 8);
    assert(LSQUIC_MWTS_OK == 0 && LSQUIC_MWTS_BLOCKED == 1);
    assert(LSQUIC_MWTS_UNSUPPORTED == -1 && LSQUIC_MWTS_CLOSED == -2);
    assert(LSQUIC_MWTS_NOMEM == -3 && LSQUIC_MWTS_INVALID == -4);
    assert(LSQUIC_MWTS_NO_SESSION == -5);
    assert(LSQUIC_WTS_INVALID == query_info(NULL, &ignored));
    assert(LSQUIC_WTS_INVALID == lsquic_stream_get_webtransport_info(NULL, NULL));
    uni_client = argc == 1 || 0 == strcmp(argv[1], "all") || 0 == strcmp(argv[1], "uni-client");
    uni_server = argc == 1 || 0 == strcmp(argv[1], "all") || 0 == strcmp(argv[1], "uni-server");
    bidi_client = argc == 1 || 0 == strcmp(argv[1], "all") || 0 == strcmp(argv[1], "bidi-client");
    bidi_server = argc == 1 || 0 == strcmp(argv[1], "all") || 0 == strcmp(argv[1], "bidi-server");
    assert(uni_client || uni_server || bidi_client || bidi_server);
    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    if (uni_client)
        test_child(0, 1);
    if (uni_server)
        test_child(1, 1);
    if (bidi_client)
        test_child(0, 0);
    if (bidi_server)
        test_child(1, 0);
    lsquic_global_cleanup();
    return 0;
}
