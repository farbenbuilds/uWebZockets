/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#ifndef UWZ_WEBTRANSPORT_FIXTURE_H
#define UWZ_WEBTRANSPORT_FIXTURE_H

#include <assert.h>
#include <stddef.h>
#include <string.h>

#include "lsquic.h"
#include "lsxpack_header.h"

enum {
    STREAMS_MAX_HSETS = 8,
    STREAMS_MAX_HEADERS = 16,
    STREAMS_HEADER_BYTES = 1024,
};

struct streams_header_pool;

struct streams_header_field {
    struct lsxpack_header shf_header;
    char shf_bytes[STREAMS_HEADER_BYTES];
};

struct streams_header_set {
    struct streams_header_pool *shs_pool;
    unsigned shs_active;
    unsigned shs_complete;
    unsigned shs_count;
    struct streams_header_field shs_fields[STREAMS_MAX_HEADERS];
};

struct streams_header_pool {
    unsigned shp_created;
    unsigned shp_discarded;
    struct streams_header_set shp_sets[STREAMS_MAX_HSETS];
};


static void *
create_header_set (void *ctx, lsquic_stream_t *stream, int is_push)
{
    struct streams_header_pool *pool = ctx;
    struct streams_header_set *set;
    unsigned index;

    (void) stream;
    assert(pool && !is_push);
    for (index = 0; index < STREAMS_MAX_HSETS; ++index)
    {
        set = &pool->shp_sets[index];
        if (set->shs_active)
            continue;
        memset(set, 0, sizeof(*set));
        set->shs_pool = pool;
        set->shs_active = 1;
        ++pool->shp_created;
        return set;
    }
    assert(0 && "bounded decoded header-set pool exhausted");
    return NULL;
}


static struct lsxpack_header *
prepare_header (void *ctx, struct lsxpack_header *header, size_t space)
{
    struct streams_header_set *set = ctx;
    struct streams_header_field *field;

    assert(set->shs_active && !set->shs_complete);
    assert(set->shs_count < STREAMS_MAX_HEADERS && space <= STREAMS_HEADER_BYTES);
    field = &set->shs_fields[set->shs_count];
    if (!header)
        lsxpack_header_prepare_decode(&field->shf_header, field->shf_bytes,
                                     0, sizeof(field->shf_bytes));
    else
    {
        assert(header == &field->shf_header);
        assert(header->buf == field->shf_bytes && header->name_offset >= 0);
        assert((size_t) header->name_offset + space <= sizeof(field->shf_bytes));
        header->val_len = (lsxpack_strlen_t) space;
    }
    return &field->shf_header;
}


static int
process_header (void *ctx, struct lsxpack_header *header)
{
    struct streams_header_set *set = ctx;
    struct streams_header_field *field;

    assert(set->shs_active && !set->shs_complete);
    if (!header)
    {
        set->shs_complete = 1;
        return 0;
    }
    assert(set->shs_count < STREAMS_MAX_HEADERS);
    field = &set->shs_fields[set->shs_count];
    assert(header == &field->shf_header && header->buf == field->shf_bytes);
    assert(header->name_offset >= 0 && header->val_offset >= 0 && header->name_len);
    assert((size_t) header->name_offset + header->name_len <= sizeof(field->shf_bytes));
    assert((size_t) header->val_offset + header->val_len <= sizeof(field->shf_bytes));
    ++set->shs_count;
    return 0;
}


static void
discard_header_set (void *ctx)
{
    struct streams_header_set *set = ctx;

    assert(set->shs_active && set->shs_pool);
    set->shs_active = 0;
    ++set->shs_pool->shp_discarded;
}


static const struct lsquic_hset_if streams_hsi = {
    .hsi_create_header_set = create_header_set,
    .hsi_prepare_decode = prepare_header,
    .hsi_process_header = process_header,
    .hsi_discard_header_set = discard_header_set,
};


#endif
