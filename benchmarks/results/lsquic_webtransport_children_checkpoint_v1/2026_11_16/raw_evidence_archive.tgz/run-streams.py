import argparse
import hashlib
import json
import os
import pathlib
import resource
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--fixture')
parser.add_argument('--tag', required=True)
parser.add_argument('--mode', default='Debug')
parser.add_argument('selectors', nargs='+')
args = parser.parse_args()
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
source = pathlib.Path('/tmp/uwz-lsquic-wt-streams-20261113')
harness = pathlib.Path('/tmp/uwz-lsquic-webtransport-harness')
fixture = pathlib.Path(args.fixture or pathlib.Path('/tmp/uwz-wt-streams-frozen-path').read_text().strip())
env = os.environ.copy()
env['ZIG_GLOBAL_CACHE_DIR'] = '/tmp/uwz-uni-global-cache'
results = []
for selector in args.selectors:
    log = pathlib.Path('/tmp/uwz-lsquic-wt-streams-' + args.tag + '-' + selector + '.log')
    assert not log.exists(), str(log)
    command = [
        '/tmp/zig-x86_64-linux-0.16.0/zig', 'build', 'test',
        '-Dlsquic-source=' + str(source), '-Dfixture=' + str(fixture),
        '-Dfixture-includes=' + str(source / 'src/liblsquic'),
        '-Dfixture-name=uwz_webtransport_streams',
        '-Dfixture-support=' + str(source / 'tests/uwz_quic_fixture.c'),
        '-Dfixture-hooks=true', '-Doptimize=' + args.mode,
        '-j2', '--summary', 'all', '--', selector,
    ]
    with log.open('w') as output:
        result = subprocess.run(command, cwd=harness, env=env,
                                stdout=output, stderr=subprocess.STDOUT)
    log.with_suffix('.exit').write_text(str(result.returncode) + '\n')
    inputs = [fixture, fixture.parent / 'uwz_quic_fixture.h',
              source / 'tests/uwz_quic_fixture.c', source / 'include/lsquic.h',
              source / 'src/liblsquic/lsquic_stream.c',
              source / 'src/liblsquic/lsquic_full_conn_ietf.c']
    inputs += [path for path in sorted(fixture.parent.glob('*.h')) if path not in inputs]
    record = {'command': command, 'exit': result.returncode, 'log': str(log),
              'inputs': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs}}
    results.append(record)
    print(json.dumps({'selector': selector, 'mode': args.mode,
                      'exit': result.returncode, 'log': str(log)}), flush=True)
    if result.returncode:
        print(log.read_text()[:2800], flush=True)
    else:
        for line in log.read_text().splitlines():
            if line.startswith('PASS ') or line.startswith('Build Summary:'):
                print(line, flush=True)
(harness / ('evidence/streams-' + args.tag + '.json')).write_text(json.dumps(results, indent=2) + '\n')
