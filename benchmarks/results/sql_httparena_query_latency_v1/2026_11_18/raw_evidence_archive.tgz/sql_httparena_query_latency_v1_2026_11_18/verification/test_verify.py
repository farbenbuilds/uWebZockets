from collections import Counter
from pathlib import Path
import runpy
import unittest

from verify import RECORD, TRACE_COUNTS, phase, recorded_clock, require_same_clock, worker_records


WINDOWS = {"warmup": (1100, 1200), "timed": (1300, 1400)}
PROCESSES = {"warmup": (1080, 1220), "timed": (1280, 1420)}
LIFETIME = (900, 1550)
TRIPLES = (
    (1, 1100, 1101, 1102, 0, 0),
    (2, 1295, 1296, 1302, 1, 0),
    (3, 1300, 1330, 1400, 0, 0),
    (4, 1401, 1402, 1410, 1, 2),
    (5, 1423, 0, 1430, 0, 1),
)


def anchor(point):
    return {"monotonic_before_ns": point - 1, "awake_ns": point, "monotonic_after_ns": point + 1}


def metadata():
    counters = dict.fromkeys(TRACE_COUNTS, 0) | {
        "submitted": 5, "assigned": 4, "callbacks": 4, "successful_callbacks": 3,
        "failed_callbacks": 1, "immediate_failures": 1, "unassigned_completed": 1,
    }
    return {
        "schema": "uwz_sql_query_latency_v1", "version": 1, "record_size": 40,
        "byte_order": "little", "worker": 0, "capacity": 262144, "record_count": 5,
        "pending_at_dump": 0, "rendered_queries": 3, "empty_fallbacks": 0, "rejected_responses": 0,
        "start_clock": anchor(1000), "dump_clock": anchor(1500), "stop_awake_ns": 1440,
        "finalized": True, "counters": counters,
    }


def analyze(triples=TRIPLES, meta=None, extra=b""):
    if meta is None:
        meta = metadata()
    raw = b"".join(RECORD.pack(*triple) for triple in triples) + extra
    metrics = {name: [] for name in ("submit_to_assign", "assign_to_callback", "submit_to_callback")}
    outcomes = Counter()
    counts = worker_records(meta, raw, 0, WINDOWS, PROCESSES, LIFETIME, metrics, outcomes)
    return counts, metrics, outcomes


class VerifyTests(unittest.TestCase):
    def test_closed_endpoints_and_excluded_outcomes(self):
        counts, timings, outcomes = analyze()
        self.assertEqual(counts["assigned"], 4)
        self.assertEqual(timings, {"submit_to_assign": [30], "assign_to_callback": [70], "submit_to_callback": [100]})
        self.assertEqual(outcomes, {
            ("warmup", "success"): 1,
            ("crosses_timed_start", "success"): 1,
            ("timed", "success"): 1,
            ("timed_tail", "immediate_failure"): 1,
            ("after_timed_process", "callback_failure"): 1,
        })

    def test_all_crossed_boundaries_and_gap(self):
        self.assertEqual(phase(1099, 1401, WINDOWS, PROCESSES),
                         "crosses_warmup_start_and_warmup_end_and_timed_start_and_timed_end")
        self.assertEqual(phase(1201, 1210, WINDOWS, PROCESSES), "warmup_tail")
        self.assertEqual(phase(1230, 1240, WINDOWS, PROCESSES), "between_processes")
        self.assertEqual(phase(1281, 1290, WINDOWS, PROCESSES), "timed_lead")
        self.assertEqual(phase(1400, 1401, WINDOWS, PROCESSES), "crosses_timed_end")

    def test_timestamp_order(self):
        for assign in (0, 1299, 1401):
            with self.subTest(assign=assign), self.assertRaisesRegex(ValueError, "Assignment timestamp"):
                analyze(TRIPLES[:2] + ((3, 1300, assign, 1400, 0, 0),) + TRIPLES[3:])
        with self.assertRaisesRegex(ValueError, "timestamp order"):
            analyze(TRIPLES[:2] + ((3, 1300, 1300, 1301, 0, 0),) + TRIPLES[3:])

    def test_duplicate_sequence(self):
        with self.assertRaisesRegex(ValueError, "Duplicate/out-of-range"):
            analyze(TRIPLES[:2] + ((2, 1300, 1330, 1400, 0, 0),) + TRIPLES[3:])

    def test_clipping_and_counter_overflow(self):
        bad = metadata()
        bad["counters"]["clipped"] = 1
        with self.assertRaisesRegex(ValueError, "Pending, clipped"):
            analyze(meta=bad)
        bad["counters"]["clipped"] = 1 << 64
        with self.assertRaisesRegex(ValueError, "overflowing"):
            analyze(meta=bad)

    def test_file_size_and_counter_mismatch(self):
        with self.assertRaisesRegex(ValueError, "truncated"):
            analyze(TRIPLES[:-1])
        with self.assertRaisesRegex(ValueError, "truncated"):
            analyze(extra=b"value")
        bad = metadata()
        bad["counters"]["assigned"] = 5
        with self.assertRaisesRegex(ValueError, "does not match emitted counters"):
            analyze(meta=bad)

    def test_clock_anchor_mismatch(self):
        bad = metadata()
        bad["dump_clock"]["monotonic_after_ns"] = 1300
        with self.assertRaisesRegex(ValueError, "outside direct CLOCK_MONOTONIC"):
            analyze(meta=bad)

    def test_clock_namespaces_with_zero_offsets(self):
        app_runner = runpy.run_path(str(Path(__file__).resolve().parents[1] / "runner/measure.py"))
        kernel = "ab" * 32
        host = f"time:[101]\ntime:[101]\nmonotonic 0 0\nboottime 0 0\n{kernel}\n"
        app = host.replace("[101]", "[202]")
        self.assertNotEqual(recorded_clock(host)["inode"], recorded_clock(app)["inode"])
        require_same_clock(recorded_clock(host), recorded_clock(app))
        self.assertTrue(app_runner["same_clock"](app_runner["clock_namespace"](host), app_runner["clock_namespace"](app)))
        for bad in (app.replace("monotonic 0 0", "monotonic -1 999999999"), app.replace("ab", "aa"),
                    app.replace("boottime 0 0", "boottime 0 1")):
            with self.subTest(bad=bad), self.assertRaisesRegex(ValueError, "differing clock coordinates"):
                self.assertFalse(app_runner["same_clock"](app_runner["clock_namespace"](host), app_runner["clock_namespace"](bad)))
                require_same_clock(recorded_clock(host), recorded_clock(bad))

    def test_invalid_namespace_raw_identity(self):
        app_runner = runpy.run_path(str(Path(__file__).resolve().parents[1] / "runner/measure.py"))
        kernel = "ab" * 32
        raw = f"time:[101]\ntime:[101]\nmonotonic 0 0\nboottime 0 0\n{kernel}\n"
        invalid = (raw.replace("[101]", "[303]", 1), raw.replace("boottime", "monotonic"),
                   raw.replace("monotonic 0 0", "monotonic - 0"), raw.replace("boottime 0 0", "boottime 0 1000000000"))
        for candidate in invalid:
            for parse in (recorded_clock, app_runner["clock_namespace"]):
                with self.subTest(candidate=candidate, parse=parse.__name__), self.assertRaises(ValueError):
                    parse(candidate)


if __name__ == "__main__":
    unittest.main()
