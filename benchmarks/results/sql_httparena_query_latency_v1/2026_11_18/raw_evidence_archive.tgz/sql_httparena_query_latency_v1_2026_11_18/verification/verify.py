import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import statistics
import struct


RECORD = struct.Struct("<QQQQII")
SCHEMA = "uwz_sql_query_latency_v1"
WORKERS, THREADS, CONNECTIONS = 32, 8, 1024
PERCENTILES = (50, 90, 95, 99)
LIMITS = (5, 10, 20, 35, 50)
TRACE_COUNTS = (
    "submitted", "assigned", "callbacks", "successful_callbacks", "failed_callbacks",
    "immediate_failures", "unassigned_completed", "clipped", "invalid_order", "duplicate_assign",
    "duplicate_complete", "unexpected_assign",
)
VALIDITY_COUNTERS = ("clipped", "invalid_order", "duplicate_assign", "duplicate_complete", "unexpected_assign")
ROUTE_COUNTERS = ("rendered_queries", "empty_fallbacks", "rejected_responses")
PAIR_ORDER = (("control", "instrumented"), ("instrumented", "control"), ("control", "instrumented"))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def unsigned(value):
    return type(value) is int and 0 <= value <= (1 << 64) - 1


def ns(seconds):
    whole, rest = seconds.split(".")
    return int(whole + rest)


def unique_fields(entries):
    result = dict(entries)
    require(len(result) == len(entries), "Duplicate JSON field")
    return result


def recorded_clock(raw):
    inode, child_inode, monotonic, boottime, kernel = raw.splitlines()
    offsets = [line.split() for line in (monotonic, boottime)]
    require(re.fullmatch(r"time:\[\d+\]", inode) and re.fullmatch(r"[0-9a-f]{64}", kernel)
            and inode == child_inode and [row[0] for row in offsets] == ["monotonic", "boottime"], "Invalid Linux time namespace evidence")
    require(all(len(row) == 3 and 0 <= int(row[2]) < 1_000_000_000 for row in offsets), "Invalid time namespace offsets")
    return {"inode": inode, "child_inode": child_inode, "kernel_boot_sha256": kernel,
            "offsets_ns": {clock: 1_000_000_000 * int(seconds) + int(nanos) for clock, seconds, nanos in offsets}}


def require_same_clock(host, app):
    require(app["kernel_boot_sha256"] == host["kernel_boot_sha256"]
            and app["offsets_ns"] == host["offsets_ns"] == {"monotonic": 0, "boottime": 0},
            "Application and host have differing clock coordinates")


def case_path(root, mode, pair):
    return root / (f"pair_{pair:02}_{mode}" if pair else f"{mode}_fixed")


def read_window(case, label, seconds):
    command = read(case / f"{label}.command.json")
    raw = (case / f"{label}.stdout").read_text()
    summary, = re.findall(r"^UWZ_WRK (.+)$", raw, re.M)
    stats = {name: int(value) for name, value in re.findall(r"(\w+)=(\d+)", summary)}
    require(command["exit_code"] == 0 and stats["completed"] > 0 and stats["duration_us"] >= seconds * 1_000_000,
            f"Unhealthy client {case.name}/{label}")
    require(all(stats[name] == 0 for name in ("status", "connect", "read", "write", "timeout")), f"Client errors {case.name}/{label}")
    argv = command["argv"]
    expected = {"-d": f"{seconds}s", "-c": str(CONNECTIONS), "-t": str(THREADS), "--timeout": "2s"}
    require(all(argv[argv.index(key) + 1] == val for key, val in expected.items()) and argv[-2:] == ["--", str(seconds * 4000)],
            f"Unexpected client flags {case.name}/{label}")
    before = command["monotonic_before_spawn_ns"]
    after = command["monotonic_after_reap_ns"]
    done, = map(ns, re.findall(r"^UWZ_WRK_DONE_MONOTONIC (\d+\.\d{9})$", raw, re.M))
    hooks = [dict((int(thread), member) for thread, member in re.findall(
        rf"^UWZ_WRK_{kind}_HOOK (\d+) (\d+\.\d{{9}}|absent)$", raw, re.M)) for kind in ("ACTIVE", "LATE")]
    require(all(set(hook) == set(range(1, THREADS + 1)) for hook in hooks), f"Incomplete per-thread clock hooks {case.name}/{label}")
    first = {thread: ns(point) for thread, point in hooks[0].items() if point != "absent"}
    late = {thread: ns(point) for thread, point in hooks[1].items() if point != "absent"}
    generated = {int(thread): int(calls) for thread, calls in re.findall(r"^UWZ_WRK_GENERATED thread=(\d+) calls=(\d+)", raw, re.M)}
    require(set(generated) == set(first) and {thread for thread, calls in generated.items() if calls >= seconds * 4000} == set(late),
            f"Generation counts do not match clock hooks {case.name}/{label}")
    require(len(first) == THREADS and late and before < min(first.values()) <= max(first.values()) <= done <= after
            and all(first[thread] < point <= done for thread, point in late.items()), f"Invalid monotonic hooks {case.name}/{label}")
    start = max(first.values())
    end = min(max(late.values()), before + 1_000_000_000 * seconds, done)
    require(start < end, f"Empty window {case.name}/{label}")
    stats["rps"] = stats["completed"] * 1_000_000 / stats["duration_us"]
    stats["active_ns"] = end - start
    stats["process_monotonic_ns"] = (before, after)
    stats["late_marker_threads"] = sorted(late)
    return (start, end), stats


def phase(submit, complete, windows, processes):
    for name, (start, end) in windows.items():
        if start <= submit <= complete <= end:
            return name
    crossed = []
    for name, (start, end) in windows.items():
        if submit < start <= complete:
            crossed.append(f"{name}_start")
        if submit <= end < complete:
            crossed.append(f"{name}_end")
    if crossed:
        return "crosses_" + "_and_".join(crossed)
    if not processes:
        return "outside_fixed"
    warmup_start, warmup_end = processes["warmup"]
    timed_start, timed_end = processes["timed"]
    intervals = (
        ("before_warmup_process", 0, warmup_start),
        ("warmup_lead", warmup_start, windows["warmup"][0]),
        ("warmup_tail", windows["warmup"][1], warmup_end),
        ("between_processes", warmup_end, timed_start),
        ("timed_lead", timed_start, windows["timed"][0]),
        ("timed_tail", windows["timed"][1], timed_end),
        ("after_timed_process", timed_end, (1 << 64) - 1),
    )
    for name, start, end in intervals:
        if start <= submit <= complete <= end:
            return name
    return "crosses_process_boundary"


def percentiles(values):
    values.sort()
    if not values:
        return {}
    return {f"p{p}_ns": values[(p * len(values) + 99) // 100 - 1] for p in PERCENTILES}


def clock_point(anchor):
    keys = ("monotonic_before_ns", "awake_ns", "monotonic_after_ns")
    require(all(unsigned(anchor[key]) for key in keys), "Invalid anchor integer")
    before, awake, after = (anchor[key] for key in keys)
    require(0 < before <= awake <= after, "Zig awake timestamp fell outside direct CLOCK_MONOTONIC calls")
    return before, awake, after


def worker_records(meta, raw, worker, windows, processes, lifetime, metrics, phases):
    require((meta["schema"], meta["version"], meta["record_size"], meta["byte_order"], meta["worker"]) ==
            (SCHEMA, 1, RECORD.size, "little", worker) and meta["finalized"] is True, "Wrong trace metadata schema")
    fields = (*ROUTE_COUNTERS, "capacity", "record_count", "pending_at_dump", "stop_awake_ns")
    counters = meta["counters"]
    require(all(unsigned(meta[key]) for key in fields) and all(unsigned(counters[key]) for key in TRACE_COUNTS),
            "Negative, overflowing or noninteger trace counter")
    require(meta["pending_at_dump"] == 0 and all(counters[key] == 0 for key in VALIDITY_COUNTERS),
            "Pending, clipped, duplicate, unexpected, or invalid trace observations")
    count = meta["record_count"]
    require(meta["capacity"] == 262144 and count <= meta["capacity"] and len(raw) == count * RECORD.size,
            "Trace is truncated or exceeds its record capacity")
    require(counters["submitted"] == count == counters["callbacks"] + counters["immediate_failures"]
            and counters["callbacks"] == counters["successful_callbacks"] + counters["failed_callbacks"],
            "Per-worker submission/callback counts do not reconcile")
    start_before, start, start_after = clock_point(meta["start_clock"])
    dump_before, dump, dump_after = clock_point(meta["dump_clock"])
    first_window, last_window = next(iter(windows.values())), next(reversed(windows.values()))
    require(lifetime[0] <= start_before <= start <= start_after <= first_window[0]
            and last_window[1] <= meta["stop_awake_ns"] <= dump_before <= dump <= dump_after <= lifetime[1],
            "Worker anchors do not bracket the runner windows and application lifetime")
    previous_completion = start
    sequences = set()
    observed = Counter()
    for sequence, submit, assign, complete, slot, status in RECORD.iter_unpack(raw):
        require(1 <= sequence <= count and sequence not in sequences and slot < 128 and status in (0, 1, 2),
                "Duplicate/out-of-range sequence, invalid slot, or invalid record status")
        require(start <= submit <= complete <= dump and previous_completion <= complete,
                "Per-worker timestamp order or clock lifetime violation")
        require((assign == 0 or submit <= assign <= complete) and (status != 0 or assign > 0),
                "Assignment timestamp is missing or out of order")
        sequences.add(sequence)
        previous_completion = complete
        route = phase(submit, complete, windows, processes)
        observed["assigned"] += assign != 0
        observed["unassigned_completed"] += assign == 0
        observed[("successful_callbacks", "failed_callbacks", "immediate_failures")[status]] += 1
        phases[(route, ("success", "callback_failure", "immediate_failure")[status])] += 1
        if status == 0 and route == "timed":
            metrics["submit_to_assign"].append(assign - submit)
            metrics["assign_to_callback"].append(complete - assign)
            metrics["submit_to_callback"].append(complete - submit)
    require(all(observed[key] == counters[key] for key in (
        "assigned", "unassigned_completed", "successful_callbacks", "failed_callbacks", "immediate_failures")),
        "Per-worker trace data does not match emitted counters")
    require(counters["successful_callbacks"] >= meta["rendered_queries"] and meta["empty_fallbacks"] == meta["rejected_responses"] == 0,
            "Worker produced invalid render/fallback/rejection counts")
    return counters


def fixed_responses(case, rows):
    responses = read(case / "fixed_responses.json")
    shapes = Counter()
    for response in responses:
        require(response["status"] == 200 and response["version"] == 11, "Fixed response is not HTTP/1.1 200")
        headers = {key.lower(): val for key, val in response["headers"]}
        request = response["request"]
        limit = request["limit"]
        require(len(headers) == len(response["headers"]) and headers.get("content-type") == "application/json"
                and headers.get("content-length") == str(len(response["body_utf8"].encode("utf-8"))) and request["method"] == "GET"
                and request["path"] == f"/async-db?min=10&max=50&limit={limit}", "Incorrect fixed request or content type")
        payload = json.loads(response["body_utf8"], object_pairs_hook=unique_fields)
        require(set(payload) == {"items", "count"} and type(payload["count"]) is int and payload["count"] == limit
                and len(payload["items"]) == len({item["id"] for item in payload["items"]}) == limit, "Fixed payload has wrong count")
        for item in payload["items"]:
            require(10 <= item["price"] <= 50 and json.dumps(item, sort_keys=True) == json.dumps(rows[item["id"]], sort_keys=True),
                    "Fixed payload has incorrect typed fields or PostgreSQL values")
        shapes[limit] += 1
    require(shapes == {limit: 10 for limit in LIMITS}, "Fixed requests do not cover the exact five shapes")
    return len(responses)


def raw_stats(case, label):
    snapshots = [read(path) for path in sorted(case.glob(f"pg_{label}_*.stdout"))]
    require(len(snapshots) >= 2 and snapshots[-1] == snapshots[-2] and snapshots[-1]["tcp_clients"] == 0,
            f"PostgreSQL statistics did not settle {case.name}/{label}")
    return snapshots[-1]


def verify_case(case, mode, fixed, rows, metadata):
    summary = read(case / "summary.json")
    host = metadata["clock_namespace"]
    app = recorded_clock((case / "app_clock_namespace.stdout").read_text())
    host_app_ns = read(case / "app_host_clock_namespace.json")
    link_verified = host_app_ns.get("time_inode") == app["inode"]
    link_unavailable = "time_inode" not in host_app_ns and host_app_ns.get("unavailable_time_inode_errno") in (1, 13)
    require(app == summary["clock_namespace"] and (link_verified or link_unavailable)
            and host_app_ns["pid"] == int((case / "app_pid.stdout").read_text()), f"Clock namespace mismatch {case.name}")
    require_same_clock(host, app)
    require(summary["valid"] is True and summary["io_uring_fds"] == WORKERS and summary["mode"] == mode,
            f"Original runner marked invalid or unexpected configuration {case.name}")
    run_cmd, stop_cmd, remove_cmd = (read(case / f"app_{label}.command.json") for label in ("run", "stop", "remove"))
    require(run_cmd["exit_code"] == stop_cmd["exit_code"] == remove_cmd["exit_code"] == 0, f"Lifecycle command failed {case.name}")
    executable = metadata["executables"][mode]
    argv = run_cmd["argv"]
    mounts = [value for option, value in zip(argv, argv[1:]) if option == "--mount"]
    require([mount for mount in mounts if ",target=/server," in mount] ==
            [f"type=bind,source={executable['path']},target=/server,readonly"]
            and metadata["sha256"][executable["path"]] == executable["sha256"], f"Incorrect case executable {case.name}")
    require(any(mount.endswith(",target=/latency_output") for mount in mounts) == (mode == "instrumented"),
            f"Incorrect trace mount for case {case.name}")
    state = read(case / "app_final_state.stdout")
    require(state["ExitCode"] == 0 and not state["OOMKilled"], f"Application exit was unhealthy {case.name}")
    cid = (case / "app_run.stdout").read_text().strip()
    cgroups = re.findall(r"^0::(.+)$", host_app_ns["cgroup"], re.M)
    require(len(cgroups) == 1 and cgroups[0].rsplit("/", 1)[-1] in (cid, f"docker-{cid}.scope"),
            f"Host PID cgroup does not identify the immutable application container {case.name}")
    labels = read(case / "app_ownership.json")["labels"]
    claimed = read(case / "app_verify_ownership.stdout")
    require(re.fullmatch(r"[0-9a-f]{64}", cid) and stop_cmd["argv"][-1] == remove_cmd["argv"][-1] == cid
            and all(claimed[key] == value for key, value in labels.items()), f"Application ownership mismatch {case.name}")
    before, after = (raw_stats(case, label) for label in ("before", "after"))
    scans = after["seq_scan"] - before["seq_scan"]
    require(before["reset_at"] == after["reset_at"] and (before["idx_scan"] or 0) == (after["idx_scan"] or 0),
            f"Unexpected PostgreSQL index scans or reset {case.name}")
    raw_log = "\n".join((case / f"app_logs.{stream}").read_text() for stream in ("stdout", "stderr"))
    route_counts = [tuple(map(int, fields)) for fields in re.findall(
        r"benchmark database rendered_queries=(\d+) empty_fallbacks=(\d+) rejected_responses=(\d+)", raw_log)]
    require(len(route_counts) == WORKERS and all(empty == rejected == 0 for _, empty, rejected in route_counts),
            f"Application route counters are missing or nonzero {case.name}")
    rendered = sum(row[0] for row in route_counts)
    require(summary["rendered_queries"] == rendered and summary["seq_scan_delta"] == scans,
            f"Application or PostgreSQL summary differs from raw evidence {case.name}")
    if fixed:
        completed = fixed_responses(case, rows)
        require(completed == rendered == scans, f"Drained counters do not reconcile {case.name}")
        fixed_run = summary["fixed"]
        windows = {"fixed": (fixed_run["start_ns"], fixed_run["end_ns"])}
        loads = {}
    else:
        warmup, warmup_stats = read_window(case, "warmup", 5)
        timed, timed_stats = read_window(case, "timed", 10)
        require(warmup[1] < timed[0], f"HTTP load windows overlap {case.name}")
        windows, loads = {"warmup": warmup, "timed": timed}, {"warmup": warmup_stats, "timed": timed_stats}
        completed = warmup_stats["completed"] + timed_stats["completed"]
        require(completed <= rendered == scans <= completed + 2 * CONNECTIONS, f"Deadline counters do not reconcile {case.name}")
    require(summary["completed"] == completed, f"Client summary does not reconcile {case.name}")
    report = {"mode": mode, "windows": windows, "wrk": loads, "completed": completed, "rendered": rendered, "seq_scans": scans,
              "clock_binding": {"host": host, "app": app, "host_pid_time_inode_verified": link_verified,
                                "host_pid_time_inode_unavailable_errno": host_app_ns.get("unavailable_time_inode_errno")}}
    if mode == "control":
        require(not (case / "latency_output").exists(), f"Control contains instrumented output {case.name}")
        return report
    folder = case / "latency_output"
    require({file.name for file in folder.iterdir()} == {f"worker_{worker}.{suffix}" for worker in range(WORKERS)
                                                       for suffix in ("bin", "json")}, f"Unexpected trace file inventory {case.name}")
    lifetime = (run_cmd["monotonic_before_spawn_ns"], stop_cmd["monotonic_after_reap_ns"])
    processes = {phase_name: data["process_monotonic_ns"] for phase_name, data in loads.items()}
    metrics = {name: [] for name in ("submit_to_assign", "assign_to_callback", "submit_to_callback")}
    phases, totals, worker_routes = Counter(), Counter(), []
    for worker in range(WORKERS):
        meta = read(folder / f"worker_{worker}.json")
        raw = (folder / f"worker_{worker}.bin").read_bytes()
        try:
            totals.update(worker_records(meta, raw, worker, windows, processes, lifetime, metrics, phases))
        except (KeyError, ValueError) as error:
            raise ValueError(f"{case.name}/worker_{worker}: {error}") from error
        worker_routes.append(tuple(meta[key] for key in ROUTE_COUNTERS))
    require(sorted(worker_routes) == sorted(route_counts) and rendered <= totals["successful_callbacks"] <= scans <= totals["submitted"],
            f"Lifecycle observations do not match SQL scans and application logs {case.name}")
    require(not any(phases[(window, kind)] for window in windows for kind in ("callback_failure", "immediate_failure")),
            f"Database failure inside a load window {case.name}")
    if fixed:
        require(phases == {("fixed", "success"): completed}, f"Fixed trace did not contain every successful query {case.name}")
    else:
        require(phases[("timed", "success")] > 0, f"No fully contained successful timed triples {case.name}")
    report["latency"] = {"counters": dict(totals), "window_outcomes": {
        f"{route}.{status}": count for (route, status), count in sorted(phases.items())
    }, "successful_callbacks_not_rendered": totals["successful_callbacks"] - rendered,
        "excluded_successful_callbacks": totals["successful_callbacks"] - phases[("timed", "success")] if not fixed else 0,
        "pending_at_dump": 0,
        "timed_success_fraction_of_run": phases[("timed", "success")] / totals["successful_callbacks"],
        "timed_percentiles": {metric: percentiles(values) for metric, values in metrics.items()}}
    return report


def verify(root, items):
    metadata = read(root / "metadata.json")
    require(metadata["python_monotonic_clock"]["implementation"] == "clock_gettime(CLOCK_MONOTONIC)", "Wrong Python clock")
    require(recorded_clock((root / "host_clock_namespace.txt").read_text()) == metadata["clock_namespace"],
            "Host Linux time namespace differs from raw observation")
    items_rows = [json.loads(line) for line in items.read_text().splitlines() if line]
    rows = {row["id"]: row for row in items_rows}
    require(len(rows) == len(items_rows) == metadata["fixture_rows_exported"], "Incorrect item reference count")
    require((root / "app_final_inventory.stdout").read_text() == "", "Experiment left application containers")
    items_digest = hashlib.sha256(items.read_bytes()).hexdigest()
    require(any(digest == items_digest and Path(path).name == "expected_items.jsonl" for path, digest in metadata["sha256"].items()),
            "PostgreSQL comparison export does not have the measured fingerprint")
    require(metadata["executables"]["control"]["sha256"] != metadata["executables"]["instrumented"]["sha256"],
            "Control and instrumented executables have identical fingerprints")
    modes = ("control", "instrumented")
    fixed = {mode: verify_case(case_path(root, mode, 0), mode, True, rows, metadata) for mode in modes}
    prior_start = None
    pairs = []
    for num, order in enumerate(PAIR_ORDER, 1):
        pair = {}
        for mode in order:
            case = case_path(root, mode, num)
            started = read(case / "app_run.command.json")["monotonic_before_spawn_ns"]
            require(prior_start is None or prior_start < started, "Paired controls were not run in the declared order")
            prior_start = started
            pair[mode] = verify_case(case, mode, False, rows, metadata)
        control, instrumented = (pair[mode]["wrk"]["timed"]["rps"] for mode in modes)
        pair["instrumented_minus_control_percent"] = 100 * (instrumented / control - 1)
        pairs.append(pair)
    medians = {mode: {metric: statistics.median(pair[mode]["wrk"]["timed"][metric] for pair in pairs)
                      for metric in ("rps", *(f"p{p}_us" for p in PERCENTILES))} for mode in modes}
    instrumented = [pair["instrumented"]["latency"]["timed_percentiles"] for pair in pairs]
    latency_medians = {stage: {percentile: statistics.median(run[stage][percentile] for run in instrumented)
                               for percentile in instrumented[0][stage]} for stage in instrumented[0]}
    return {"valid": True, "fixed": fixed, "pairs": pairs, "http_sample_medians": medians,
            "latency_medians_of_sample_percentiles_ns": latency_medians,
            "throughput_threshold_rps": 300000, "throughput_gate_met": medians["control"]["rps"] > 300000,
            "median_pair_instrumented_minus_control_percent": statistics.median(
                pair["instrumented_minus_control_percent"] for pair in pairs)}


def main():
    parser = argparse.ArgumentParser(description="Offline verification of paired query-latency evidence")
    parser.add_argument("measurements", type=Path)
    parser.add_argument("--items", type=Path, required=True)
    args = parser.parse_args()
    result = verify(args.measurements, args.items)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
