#!/usr/bin/env python3
"""Check the extracted archive and recompute the successful measurement offline."""
import hashlib
import json
from pathlib import Path
import re
import stat
import subprocess
import sys


CONTROL = 'baseline/install/bin/sql_httparena'
INSTRUMENTED = 'install/bin/sql_httparena'
WRK = 'tooling/root/usr/bin/wrk'
DELTA = {'builds/examples.zig', 'examples/sql_httparena.zig', 'src/sql/db.zig'}
MODULE = 'instrumentation/query_timing.zig'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def mode(path):
    return stat.S_IMODE(path.stat().st_mode)


def members(root):
    found = set()
    for path in root.rglob('*'):
        require(not path.is_symlink(), f'Unexpected symlink: {path}')
        if path.is_dir():
            continue
        require(path.is_file(), f'Expected a regular file: {path}')
        found.add(path.relative_to(root).as_posix())
    return found


def manifest(root):
    entries = load(root / 'payload_manifest.json')['files']
    seen = set()
    for entry in entries:
        name = entry['path']
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts and name not in seen, f'Invalid manifest entry: {name}')
        seen.add(name)
        require(mode(root / path) == entry['mode'] and sha(root / path) == entry['sha256'], f'Payload identity differs: {name}')
    require(members(root) == seen | {'payload_manifest.json'}, 'Payload inventory differs')
    return len(seen)


def verify_source(root):
    parent = load(root / 'parent_identity.json')
    baseline = load(root / 'baseline/packaged_source_identity.json')
    changes = load(root / 'source_delta.json')
    instrumented = load(root / 'build/result.json')
    before = {entry['path']: (entry['sha256'], entry['mode']) for entry in baseline['files']}
    files = {entry['path']: (entry['sha256'], int(entry['mode'], 8)) for entry in parent['files']}
    deltas = {entry['path']: entry for entry in changes['changes']}
    require(len(files) == len(parent['files']) == 346 and DELTA == set(deltas) == members(root / 'parent_source'),
            'Unexpected source or delta inventory')
    require(files == before and members(root / 'source') == set(files), 'The baseline package source inventory differs')
    require(parent['source_commit'] == baseline['commit'] == changes['base_source_commit'], 'Baseline source commit differs')
    require(parent['parent_commit'] == load(root / 'input_identity.json')['parent_commit'], 'Parent commit differs')
    changed_hashes = {}
    for name, (expected_sha, expected_mode) in files.items():
        path = root / 'source' / name
        require(mode(path) == expected_mode, f'Unexpected source mode: {name}')
        if name not in deltas:
            require(sha(path) == expected_sha, f'Unlisted source change: {name}')
            continue
        delta = deltas[name]
        original = root / 'parent_source' / name
        changed_hash = sha(path)
        require(sha(original) == expected_sha == delta['parent_sha256'] and mode(original) == expected_mode and
                changed_hash == delta['instrumented_sha256'] != expected_sha and int(delta['mode'], 8) == expected_mode,
                f'Unexpected source delta: {name}')
        changed_hashes[f'source/{name}'] = changed_hash
    module = changes['named_instrumentation_module']
    require(module['path'] == MODULE and module['sha256'] == sha(root / MODULE), 'Instrumentation module differs')
    changed_hashes[MODULE] = module['sha256']
    require(changed_hashes == instrumented['source_sha256'], 'Build-time source hashes differ')
    require(sha(root / INSTRUMENTED) == changes['instrumented_binary']['sha256'] and
            (root / INSTRUMENTED).stat().st_size == changes['instrumented_binary']['bytes'], 'Source delta executable differs')


def prelaunch(root, name):
    observed = {}
    for line in (root / 'verification' / name).read_text().splitlines():
        digest, original = line.split()
        _, local = original.split('/async-db-query-latency-20261118/', 1)
        require(re.fullmatch(r'[a-f0-9]{64}', digest) and local not in observed, f'Bad prelaunch member {local}')
        observed[local] = digest
    return observed


def verify_file_identity(root, name, expected_sha, expected_bytes):
    path = root / name
    require(sha(path) == expected_sha and path.stat().st_size == expected_bytes, f'Executable identity differs: {name}')


def verify_inputs(root):
    baseline = load(root / 'baseline/build/result.json')
    experiment = load(root / 'build/result.json')
    tools = load(root / 'tooling/identity.json')
    inputs = load(root / 'input_identity.json')['inputs']
    require(baseline['exit_code'] == experiment['exit_code'] == 0 and baseline['zig_sha256'] == inputs[2]['sha256'],
            'Build outcome or compiler identity differs')
    verify_file_identity(root, CONTROL, baseline['binary_sha256'], baseline['binary_bytes'])
    verify_file_identity(root, INSTRUMENTED, experiment['binary']['sha256'], experiment['binary']['bytes'])
    for name, entry in zip((CONTROL, WRK), inputs[:2], strict=True):
        verify_file_identity(root, name, entry['sha256'], entry['bytes'])
        require(mode(root / name) == int(entry['mode'], 8), f'Executable mode differs: {name}')
    require(mode(root / INSTRUMENTED) == int(experiment['binary']['mode'], 8), 'Instrumented executable mode differs')
    require(sha(root / WRK) == tools['wrk_sha256'] and
            sha(root / 'tooling/wrk_4.1.0-4build3_amd64.deb') == tools['package_sha256'], 'wrk package identity differs')
    for entry in load(root / 'baseline/archived_inputs.json')['files']:
        seed = root / 'archived_fixture' / Path(entry['member']).name
        require(sha(seed) == entry['sha256'] and mode(seed) == entry['mode'], f'Archived fixture differs: {seed.name}')
    fixture = load(root / 'fixture.json')
    old_fixture = load(root / 'baseline/fixture.json')
    require(fixture['seed_sha256'] == old_fixture['seed_sha256'] == sha(root / 'archived_fixture/pgdb-seed.sql') and
            fixture['image'] == old_fixture['image'] == (root / 'archived_fixture/image.txt').read_text().strip() and
            fixture['seed_rows'] == old_fixture['seed_rows'] == 100000 and fixture['expected_rows'] == 8237,
            'Measured PostgreSQL fixture differs')
    require(sha(root / 'fixture/expected_items.jsonl') == sha(root / 'parent_fixture/expected_items.jsonl'), 'Fixture export differs')
    cleanup = load(root / 'cleanup.json')
    require(cleanup['container_removed_or_absent'] is True and cleanup['private_inputs_removed'] is True and
            cleanup['matched_database_containers'] == 1 and cleanup['label'] == fixture['label'] and
            cleanup['ownership_token_sha256'] == hashlib.sha256(fixture['owner_token'].encode()).hexdigest(),
            'Fixture cleanup proof differs')


def verify_run_identity(root, number):
    run = root / 'measurements' / f'run_{number:02}'
    raw = load(run / 'metadata.json')
    historical = number == 1
    before = prelaunch(root, 'prelaunch.sha256' if historical else 'prelaunch_run_02.sha256')
    expected_paths = {'runner/measure.py', 'runner/async_db.lua', 'verification/verify.py', 'verification/test_verify.py'}
    require(set(before) == expected_paths, 'Unexpected prelaunch script inventory')
    if not historical:
        require(all(sha(root / path) == digest for path, digest in before.items()), 'Experiments runner or verifier differs')
    for name, mode in ((CONTROL, 'control'), (INSTRUMENTED, 'instrumented')):
        record = raw['executables'][mode]
        require(sha(root / name) == record['sha256'] == raw['sha256'][record['path']], f'Measured {mode} executable differs')
    for name in (WRK, 'fixture.json', 'fixture/expected_items.jsonl', 'runner/measure.py', 'runner/async_db.lua'):
        matches = [digest for path, digest in raw['sha256'].items() if path.endswith('/' + name)]
        expected = before[name] if name in before else sha(root / name)
        require(matches == [expected], f'Measured input differs: {name}')
    if not historical:
        return
    for label, cohort in load(run / 'summary.json').items():
        fixed = cohort['fixed']
        require(label in ('control', 'instrumented') and cohort['valid'] is False and not cohort['samples'] and
                fixed['completed'] == fixed['rendered_queries'] == fixed['seq_scan_delta'] == 0 and
                fixed['app_state']['ExitCode'] == 0 and 'different Linux time namespaces' in fixed['runtime_error'],
                'Rejected preflight does not match the stated outcome')
    require((run / 'app_final_inventory.stdout').stat().st_size == 0, 'Rejected preflight left application containers')


def main():
    root = Path(__file__).resolve().parent
    files = manifest(root)
    verify_source(root)
    verify_inputs(root)
    verify_run_identity(root, 1)
    verify_run_identity(root, 2)
    run = root / 'measurements/run_02'
    result = subprocess.check_output([sys.executable, '-B', root / 'verification/verify.py', run,
                                      '--items', root / 'fixture/expected_items.jsonl'])
    measured = json.loads(result)
    require(measured == load(run / 'verified.json'), 'Derived results differ from the retained verifier output')
    control = measured['http_sample_medians']['control']['rps']
    instrumented = measured['http_sample_medians']['instrumented']['rps']
    contained = sum(pair['instrumented']['latency']['window_outcomes']['timed.success'] for pair in measured['pairs'])
    print(f'Verified {files} payload identities and eight successful cases with {contained} contained timed SDK triples.')
    print(f'HTTP medians: {control:.3f} control requests/s, {instrumented:.3f} instrumented requests/s.')
    print('300,000 requests/s gate:', 'met' if measured['throughput_gate_met'] else 'unmet')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, subprocess.CalledProcessError) as error:
        raise SystemExit(f'Verification failed: {error}') from error
