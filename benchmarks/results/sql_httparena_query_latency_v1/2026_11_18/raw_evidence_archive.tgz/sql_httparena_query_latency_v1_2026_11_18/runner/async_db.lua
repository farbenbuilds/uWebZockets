local limits = {5, 10, 20, 35, 50}
local requests = {}
local index = 0
local threads = {}
local late_hook
local ffi = require("ffi")
ffi.cdef[[
struct timespec { long tv_sec; long tv_nsec; };
int clock_gettime(int clockid, struct timespec *tp);
]]
local timepoint = ffi.new("struct timespec[1]")

local function monotonic_time()
    assert(ffi.C.clock_gettime(1, timepoint) == 0)
    return string.format("%d.%09d", tonumber(timepoint[0].tv_sec), tonumber(timepoint[0].tv_nsec))
end

generated = 0

function setup(thread)
    threads[#threads + 1] = thread
end

function init(args)
    late_hook = assert(tonumber(args[1]))
    assert(late_hook > 2)
    for i, limit in ipairs(limits) do
        requests[i] = wrk.format("GET", "/async-db?min=10&max=50&limit=" .. limit)
    end
end

local function rotate_request()
    index = index % #requests + 1
    generated = generated + 1
    return requests[index]
end

local function record_late()
    local payload = rotate_request()
    if generated == late_hook then
        active_late_hook_time = monotonic_time()
        request = rotate_request
    end
    return payload
end

function request()
    local payload = rotate_request()
    -- wrk may call the first hook while verifying the constructed request.
    if generated == 2 then
        active_hook_time = monotonic_time()
        request = record_late
    end
    return payload
end

function done(summary, latency, _)
    io.write("UWZ_WRK_DONE_MONOTONIC ", monotonic_time(), "\n")
    io.write(string.format(
        "UWZ_WRK completed=%d duration_us=%d status=%d connect=%d read=%d write=%d timeout=%d p50_us=%d p90_us=%d p95_us=%d p99_us=%d\n",
        summary.requests, summary.duration, summary.errors.status, summary.errors.connect,
        summary.errors.read, summary.errors.write, summary.errors.timeout,
        latency:percentile(50.0), latency:percentile(90.0),
        latency:percentile(95.0), latency:percentile(99.0)))
    for number, thread in ipairs(threads) do
        io.write(string.format("UWZ_WRK_ACTIVE_HOOK %d %s\n", number, thread:get("active_hook_time") or "absent"))
        io.write(string.format("UWZ_WRK_LATE_HOOK %d %s\n", number, thread:get("active_late_hook_time") or "absent"))
        local count = thread:get("generated")
        local complete_cycles = math.floor(count / #limits)
        local extra = count % #limits
        io.write(string.format("UWZ_WRK_GENERATED thread=%d calls=%d", number, count))
        for i, limit in ipairs(limits) do
            local shape_count = complete_cycles + (i <= extra and 1 or 0)
            io.write(string.format(" limit_%d=%d", limit, shape_count))
        end
        io.write("\n")
    end
end
