//! Artifact-only bounded accounting; timestamps and storage come from the caller.
const std = @import("std");

/// SQL terminal boundaries are independent of HTTP rendering and delivery.
pub const Status = enum(u32) { success = 0, failure = 1, submission_failure = 2 };

/// Forty-byte on-disk records use explicit little-endian encoding.
pub const Record = struct {
    sequence: u64,
    submitted_ns: u64,
    assigned_ns: u64,
    completed_ns: u64,
    slot: u32,
    status: Status,
};

/// One live adapter slot retains its identity until its terminal boundary.
pub const SampleState = struct {
    sequence: u64 = 0,
    submitted_ns: u64 = 0,
    assigned_ns: u64 = 0,
    active: bool = false,
};

/// Counters retain overflow and invalid observations rather than repairing them.
pub const Counters = struct {
    submitted: u64 = 0,
    assigned: u64 = 0,
    callbacks: u64 = 0,
    successful_callbacks: u64 = 0,
    failed_callbacks: u64 = 0,
    immediate_failures: u64 = 0,
    unassigned_completed: u64 = 0,
    clipped: u64 = 0,
    invalid_order: u64 = 0,
    duplicate_assign: u64 = 0,
    duplicate_complete: u64 = 0,
    unexpected_assign: u64 = 0,
};

/// Startup-owned memory and worker-confined accounting for one capture.
pub const Capture = struct {
    records: []Record,
    count: usize = 0,
    counters: Counters = .{},
};

/// Direct Linux CLOCK_MONOTONIC reads bracket the SDK's awake clock.
pub const ClockAnchor = struct {
    monotonic_before_ns: u64,
    awake_ns: u64,
    monotonic_after_ns: u64,
};

/// Written only after the complete binary record file has closed successfully.
pub const Metadata = struct {
    schema: []const u8 = "uwz_sql_query_latency_v1",
    version: u32 = 1,
    record_size: u32 = 40,
    byte_order: []const u8 = "little",
    worker: usize,
    capacity: usize,
    record_count: usize,
    pending_at_dump: u64,
    counters: Counters,
    rendered_queries: u64,
    empty_fallbacks: u64,
    rejected_responses: u64,
    start_clock: ClockAnchor,
    stop_awake_ns: u64,
    dump_clock: ClockAnchor,
    finalized: bool = true,
};

/// Starts a new worker-local sequence; callers guarantee the slot was released.
pub fn submit(capture: *Capture, submitted_ns: u64) SampleState {
    capture.counters.submitted += 1;
    return .{ .sequence = capture.counters.submitted, .submitted_ns = submitted_ns, .active = true };
}

/// Preserves the first assignment boundary even when a duplicate is observed.
pub fn assign(capture: *Capture, state: *SampleState, assigned_ns: u64) void {
    if (!state.active) {
        capture.counters.unexpected_assign += 1;
        return;
    }
    if (state.assigned_ns != 0) {
        capture.counters.duplicate_assign += 1;
        return;
    }
    capture.counters.assigned += 1;
    state.assigned_ns = assigned_ns;
}

/// Records each terminal boundary once, including failures without assignment.
pub fn complete(capture: *Capture, state: *SampleState, slot: u32, completed_ns: u64, status: Status) void {
    if (!state.active) {
        capture.counters.duplicate_complete += 1;
        return;
    }
    state.active = false;
    switch (status) {
        .success => {
            capture.counters.callbacks += 1;
            capture.counters.successful_callbacks += 1;
        },
        .failure => {
            capture.counters.callbacks += 1;
            capture.counters.failed_callbacks += 1;
        },
        .submission_failure => capture.counters.immediate_failures += 1,
    }
    if (state.assigned_ns == 0) capture.counters.unassigned_completed += 1;
    const invalid = completed_ns < state.submitted_ns or
        (state.assigned_ns != 0 and (state.assigned_ns < state.submitted_ns or state.assigned_ns > completed_ns)) or
        (status == .success and state.assigned_ns == 0);
    if (invalid) capture.counters.invalid_order += 1;
    if (capture.count == capture.records.len) {
        capture.counters.clipped += 1;
        return;
    }
    capture.records[capture.count] = .{
        .sequence = state.sequence,
        .submitted_ns = state.submitted_ns,
        .assigned_ns = state.assigned_ns,
        .completed_ns = completed_ns,
        .slot = slot,
        .status = status,
    };
    capture.count += 1;
}

/// File encoding is independent of native struct padding and target endianness.
pub fn encode_record(record: Record, output: *[40]u8) void {
    std.mem.writeInt(u64, output[0..8], record.sequence, .little);
    std.mem.writeInt(u64, output[8..16], record.submitted_ns, .little);
    std.mem.writeInt(u64, output[16..24], record.assigned_ns, .little);
    std.mem.writeInt(u64, output[24..32], record.completed_ns, .little);
    std.mem.writeInt(u32, output[32..36], record.slot, .little);
    std.mem.writeInt(u32, output[36..40], @intFromEnum(record.status), .little);
}
