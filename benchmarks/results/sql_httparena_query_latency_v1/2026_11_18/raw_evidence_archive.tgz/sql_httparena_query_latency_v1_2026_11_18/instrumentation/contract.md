# Artifact-only SQL query timing

The frozen adapter keeps its SQL, prepared name, connection counts, parsing,
response rendering and HTTP behavior. Its copied `Db.assign` observes the exact
caller-owned `Query` identity before `Connection.execute`. No production source
or public API is changed.

Each worker owns 262144 records allocated during `Context.init` and freed after
the loop drains. The reserved sample pages are first touched as records arrive;
the measured instrumentation overhead includes those page faults and writes.
No request allocates, logs or writes timing data to an external sink. Slot identity
is a worker-local sequence starting at one on every `Db.query` submission, plus
the existing slot index. The assignment callback first excludes callbacks other
than the adapter's `on_query` before interpreting query context as an adapter
slot. Owner, address and active-slot assertions document that private contract.

Three `std.Io.Clock.awake` nanosecond timestamps are captured:

- Submission immediately before `Db.query`, including observer bookkeeping in
  the subsequent admission interval.
- Assignment at `Db.assign` entry before encoding, transport submission or the
  scratch observer callback.
- Completion at `on_query` entry before token inspection and JSON rendering.
  A synchronous `Db.query` error records a separate terminal boundary at its
  catch site; it is never presented as a successful callback triple.

Submission to assignment measures admission including submission bookkeeping.
Assignment to callback measures assigned SDK service, including encoding,
transport, PostgreSQL and result reception. Submission to callback measures
total SDK query latency. These are neither HTTP latency nor PostgreSQL engine
execution alone. Raw successful callbacks can outnumber rendered HTTP responses
when clients disconnect at a load cutoff; those outcomes remain separately
observable.

## Files

An empty writable `/latency_output` mount receives `worker_N.bin` and
`worker_N.json`. Both use exclusive creation. The record file closes before the
JSON finalization metadata is written. A dump failure is logged and produces no
valid finalized pair. Every expected worker must have one complete pair.

Every binary record is 40 bytes, explicitly encoded little endian:

| Offset | Type | Meaning |
| --- | --- | --- |
| 0 | u64 | Worker-local sequence, starting at 1 |
| 8 | u64 | Submission nanoseconds |
| 16 | u64 | Assignment nanoseconds, or zero when never assigned |
| 24 | u64 | Terminal nanoseconds |
| 32 | u32 | Existing adapter slot index |
| 36 | u32 | Status: 0 success callback, 1 failure callback, 2 synchronous submission failure |

Record order is completion order; concurrent queries can complete out of
submission order. Consumers must use sequence and slot identity. Failure records
may legitimately lack assignment; synchronous execution failure may already
have an assignment. Invalid timestamps are retained and counted.

The exact JSON contract is `Metadata`, `Counters` and `ClockAnchor` in
`query_timing.zig`. Counter relations without clipping or invalid observations:

- `callbacks = successful_callbacks + failed_callbacks`
- `record_count + clipped = callbacks + immediate_failures`
- `submitted = callbacks + immediate_failures + pending_at_dump`
- `assigned` counts first observations; it may exceed assigned terminal records
  only through pending or clipped records.
- `unassigned_completed` counts terminal outcomes whose assignment timestamp is
  zero. A success without assignment also counts as invalid ordering.

Duplicate assignment preserves the first stamp. Duplicate completion is counted
without adding another terminal record. Assignment of an inactive timing state
increments `unexpected_assign`. Capacity overflow preserves terminal counters,
increments `clipped`, and makes the evidence incomplete. Acceptance requires no
clipping, invalid order, duplicates or unexpected assignments; failure/cutoff
counts are explicit rather than discarded.

`start_clock` and `dump_clock` independently bracket the SDK awake timestamp
between two raw Linux `clock_gettime(CLOCK_MONOTONIC)` reads. Startup refuses a
clock mismatch; a dump mismatch prevents finalization. `stop_awake_ns` is the
service stop boundary, before cancellation/draining, so terminal callbacks can
follow it. `dump_clock` is captured after drain and before writing files.
Consumers also verify the container time namespace and actual runner lifecycle
brackets, then classify the actual warmup/timed boundaries without merging them.

## Focused verification

`query_timing_tests.zig` covers out-of-order completion, slot reuse, clipping,
failure accounting, duplicate boundaries, invalid ordering and exact byte
encoding. The initial test command failed because the implementation module did
not yet exist; implementing it made all five tests pass. `focused_tests.json`
retains the final command and output. Runtime verification of callback identity,
real response bodies, PostgreSQL scans, clock windows and overhead belongs to
the accompanying matched HTTP benchmark, not these deterministic helper tests.
