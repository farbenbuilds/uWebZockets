const std = @import("std");
const timing = @import("query_timing.zig");

test "interleaved slots retain independent identities across reuse" {
    var records: [3]timing.Record = undefined;
    var capture: timing.Capture = .{ .records = &records };
    var first = timing.submit(&capture, 100);
    var second = timing.submit(&capture, 110);
    timing.assign(&capture, &first, 120);
    timing.assign(&capture, &second, 130);
    timing.complete(&capture, &second, 1, 150, .success);
    timing.complete(&capture, &first, 0, 160, .success);
    first = timing.submit(&capture, 170);
    timing.assign(&capture, &first, 180);
    timing.complete(&capture, &first, 0, 200, .success);
    try std.testing.expectEqual(@as(u64, 2), records[0].sequence);
    try std.testing.expectEqual(@as(u64, 1), records[1].sequence);
    try std.testing.expectEqual(@as(u64, 3), records[2].sequence);
    try std.testing.expectEqual(@as(u64, 170), records[2].submitted_ns);
    try std.testing.expectEqual(@as(u64, 3), capture.counters.submitted);
    try std.testing.expectEqual(@as(u64, 3), capture.counters.callbacks);
    try std.testing.expectEqual(@as(u64, 0), capture.counters.invalid_order);
}

test "capacity overflow keeps terminal accounting and explicit clipping" {
    var records: [1]timing.Record = undefined;
    var capture: timing.Capture = .{ .records = &records };
    var first = timing.submit(&capture, 100);
    timing.assign(&capture, &first, 110);
    timing.complete(&capture, &first, 0, 120, .success);
    var second = timing.submit(&capture, 130);
    timing.complete(&capture, &second, 0, 140, .submission_failure);
    try std.testing.expectEqual(@as(usize, 1), capture.count);
    try std.testing.expectEqual(@as(u64, 1), capture.counters.clipped);
    try std.testing.expectEqual(@as(u64, 1), capture.counters.immediate_failures);
    try std.testing.expectEqual(@as(u64, 1), capture.counters.unassigned_completed);
    try std.testing.expectEqual(@as(u64, 2), capture.counters.submitted);
}

test "duplicate assignment and completion do not overwrite first boundaries" {
    var records: [2]timing.Record = undefined;
    var capture: timing.Capture = .{ .records = &records };
    var sample = timing.submit(&capture, 100);
    timing.assign(&capture, &sample, 120);
    timing.assign(&capture, &sample, 140);
    timing.complete(&capture, &sample, 3, 160, .failure);
    timing.complete(&capture, &sample, 3, 170, .failure);
    timing.assign(&capture, &sample, 180);
    try std.testing.expectEqual(@as(usize, 1), capture.count);
    try std.testing.expectEqual(@as(u64, 120), records[0].assigned_ns);
    try std.testing.expectEqual(@as(u64, 1), capture.counters.duplicate_assign);
    try std.testing.expectEqual(@as(u64, 1), capture.counters.duplicate_complete);
    try std.testing.expectEqual(@as(u64, 1), capture.counters.unexpected_assign);
    try std.testing.expectEqual(@as(u64, 1), capture.counters.failed_callbacks);
}

test "invalid timestamp ordering remains visible in raw records" {
    var records: [2]timing.Record = undefined;
    var capture: timing.Capture = .{ .records = &records };
    var first = timing.submit(&capture, 200);
    timing.assign(&capture, &first, 190);
    timing.complete(&capture, &first, 0, 220, .success);
    var second = timing.submit(&capture, 300);
    timing.assign(&capture, &second, 330);
    timing.complete(&capture, &second, 1, 320, .success);
    try std.testing.expectEqual(@as(u64, 2), capture.counters.invalid_order);
    try std.testing.expectEqual(@as(u64, 190), records[0].assigned_ns);
    try std.testing.expectEqual(@as(u64, 320), records[1].completed_ns);
}

test "record encoding is exactly forty bytes in explicit little endian order" {
    const record: timing.Record = .{
        .sequence = 1,
        .submitted_ns = 2,
        .assigned_ns = 3,
        .completed_ns = 4,
        .slot = 5,
        .status = .submission_failure,
    };
    var bytes: [40]u8 = undefined;
    timing.encode_record(record, &bytes);
    const expected = [_]u8{
        1, 0, 0, 0, 0, 0, 0, 0,
        2, 0, 0, 0, 0, 0, 0, 0,
        3, 0, 0, 0, 0, 0, 0, 0,
        4, 0, 0, 0, 0, 0, 0, 0,
        5, 0, 0, 0, 2, 0, 0, 0,
    };
    try std.testing.expectEqualSlices(u8, &expected, &bytes);
}
