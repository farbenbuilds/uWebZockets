# Actual QUIC engine connection ownership

Base project commit: 640bb8ba7bc02bde35fc271c8bc2821a3d219ce1.
Final project files under project/ add bounded generation-checked connection
slots, immutable peer snapshots, stream leases and one context per existing
global stream slot. Native calls stay in engine callbacks. A closing slot is
retained through its final stream lease; native connctx is cleared first.
Generation exhaustion rejects new admission instead of reviving stale handles.
There is no per-connection full-capacity stream/session slab.

## Verified commands

Root Zig 0.16.0 test-unit passes 971/971 tests in 20/20 steps. The seven new
centralized cases cover distinct connections, retention and reuse, duplicate
operations, stale/foreign handles, immutable full-width peer data, linear
engine capacities, role transitions and exhausted generations. Root
ReleaseSafe test-compile and ReleaseFast lib each pass 21/21 steps. Exact
formatting, conventions and release-version checks pass; graph update ran
AST-only. Original command logs and exit files are under logs/.

The isolated harness imports actual src/test_support.zig and engine.zig with
one actual translated C module. It calls production init/start/process_datagram/
process/deinit with a real TLS context and bound loopback UDP socket. Server
packets use production send_packets/sendmsg. A native C client receives them
on another UDP socket and delivers its queued packets to server packet_in.
No native callbacks or native layouts are simulated.

Two real-engine tests pass Debug, ReleaseSafe and ReleaseFast, 16/16 steps each.
They check partial then exact completed POST payload/200/FIN, actual connctx
and streamctx addresses, active stream leases and counts, normal stream close,
connection abort with pending body, all relevant pool drainage and generation
change on slot reuse. Peer caching completes while WT settings remain off.
Input hashes validate before and after the matrix. final-runs.json retains the
actual original commands, working directory, input manifest hash and status.

## Reproduce

Verify files.sha256. Restore an isolated project checkout from the base plus
the project/ files here, or use the commit containing this evidence. Restore
native candidate 2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c using the separately
retained lsquic_webtransport_children_v1/2026_11_16 handoff and prerequisites.
Resolve the pinned packages in harness/build.zig.zon using Zig 0.16.0. The
archive excludes package caches, generated keys, binaries and core files.
From harness/, with loopback socket access:

```sh
zig build test -Doptimize=Debug -j2 --summary all \
  -Dproject-source=/absolute/isolated/project \
  -Dlsquic-source=/absolute/frozen/native-candidate
```

Repeat with ReleaseSafe and ReleaseFast. These overrides are scratch harness
options only; production build manifests and dependency pins are unchanged.
External input manifests retain the original absolute locations and hashes.
The harness README predates root execution; later final-runs.json/logs are
the authoritative run records.

## Original failures and scope

Initial root REDs fail for missing module/API; an intermediate compile also
caught a typed opaque-pointer comparison. These are retained as compile REDs,
not runtime assertion failures. Independent review found potential u64
generation wrap; the final table never wraps and has a boundary regression.

The first actual-engine run passed abort/reuse but failed complete-body
submission: the scratch helper called flush after shutdown(write). Native
flush deliberately rejects WRITE_DONE with EBADF, while shutdown already
queues buffered bytes and FIN. Only the helper changed to return the shutdown
result on FIN. Test assertions are byte-identical. Original input snapshots,
log, diff and native source rationale are retained under harness/provenance/.

The first matrix wrapper completed Debug, then terminated with disk quota
error 122 while recording ReleaseSafe status. That mode's initial log/status
were empty, so no pass is inferred. Root verified the process was terminal,
removed 8.7 GB of old generated native-harness cache only, and resumed remaining
modes on unchanged inputs. quota-event.txt records the gap; final logs prove
the retried modes. This was an environment failure, not a skipped test.

Positive engine typed-child/session integration, App authorization and route
binding, capsules, datagrams, multi-session flow control and independent
WebTransport client acceptance remain open. Native candidate WT negotiation
is also off in this engine cohort. Pure role tests and the preceding backend
TLS cohort do not substitute for live session integration. No foreign runtime,
new allocation campaign, UDP event-loop reception or direct global-reference
counter proof is claimed. Smoke/security runs remain deferred by the user;
compile-only C API smoke evidence is not an execution pass. v2.3.0 remains
incomplete.
