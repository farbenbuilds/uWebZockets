# Client FIN helper correction

The root agent's first actual-engine Debug run terminated with one of two
tests passing. The complete-body test received -1 from the scratch client
write helper after writing its final bytes and requesting FIN. The pending
body abort/reuse test passed. The original log and first frozen scratch inputs
are preserved under `first_failure_inputs/`.

The error is localized statically to the scratch helper's final call sequence:
write, write shutdown, then unconditional flush. In the frozen candidate
`src/liblsquic/lsquic_stream.c`:

- `stream_shutdown_write`, lines 2207-2256, sets `STREAM_U_WRITE_DONE` and
  packetizes pending bytes and FIN through the native shutdown path.
- `lsquic_stream_shutdown`, lines 2274-2301, dispatches that write finalization
  and makes the connection tickable.
- `lsquic_stream_flush`, lines 2883-2889, rejects `STREAM_U_WRITE_DONE` with
  `errno = EBADF` and a -1 return. The public header's flush contract at
  lines 1942-1949 also identifies flushing a closed stream as an error.

The corrected helper returns `lsquic_stream_shutdown(..., 1)` directly for
FIN writes and calls `lsquic_stream_flush` only for non-FIN writes. This
preserves native write and shutdown errors. No production source, native
candidate source, callback, expectation, or test assertion changes.

The existing complete-body test remains the regression check: it still
requires successful FIN submission, a real 200 response, exact echoed bytes,
received FIN, native stream close, lease release, and connection cleanup.
The scaffold agent did not reproduce or rerun the test; the root agent owns
the pending build and end-to-end verification. No production premature-close
claim can be drawn from the original helper return alone.

Original manifest SHA-256:
`f20443ac1b8274b5d2cad289c1e6f6211ceb1f044fa722d072a8556fb1b18b1c`.

Original failing log SHA-256:
`e7175985c5182c7871cc08e634235746add1f5f3ddbcc55c1a57e6cea2f411ec`.
