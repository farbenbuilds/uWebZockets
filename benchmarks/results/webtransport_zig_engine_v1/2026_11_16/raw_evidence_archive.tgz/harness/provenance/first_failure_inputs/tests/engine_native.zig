const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const testing = std.testing;

const Engine = support.quic_engine.quic_engine(4, 512, 0, .{
    .request_header_size = 4096,
    .request_body_size = 512,
    .response_header_size = 1024,
    .response_header_count = 16,
    .decoded_header_count = 16,
});
const request_body = "owned-request-body";
const partial_size = 6;

/// Route evidence lives beside the actual server and is borrowed by the router.
const RouteObservation = struct {
    server: *Engine,
    calls: usize = 0,
    body: [64]u8 = undefined,
    body_length: usize = 0,
    ownership_valid: bool = false,
    response_failed: bool = false,
};

fn loopback(port: u16) std.Io.net.IpAddress {
    return .{ .ip4 = .{ .bytes = .{ 127, 0, 0, 1 }, .port = port } };
}

fn connection_index(server: *Engine) !usize {
    for (server.connections.pool.storage, 0..) |_, index| {
        if (server.connections.pool.is_active(index)) return index;
    }
    return error.MissingConnection;
}

fn stream_index(server: *Engine) !usize {
    for (server.stream_pool.storage, 0..) |_, index| {
        if (server.stream_pool.is_active(index)) return index;
    }
    return error.MissingHttpStream;
}

fn ownership_valid(server: *Engine) bool {
    const conn_index = connection_index(server) catch return false;
    const http_index = stream_index(server) catch return false;
    const connection = &server.connections.pool.storage[conn_index];
    const context = &server.stream_contexts[http_index];
    const http = &server.stream_pool.storage[http_index];
    const native_connection = connection.native orelse return false;
    const native_conn_context = c.lsquic_conn_get_ctx(native_connection) orelse return false;
    const native_stream_context = c.lsquic_stream_get_ctx(http.stream) orelse return false;
    return server.active_connections == 1 and
        server.connections.pool.count_active() == 1 and
        connection.owner == @as(*anyopaque, @ptrCast(server)) and
        connection.stream_count == 1 and context.http == http and
        context.state.role == .http and context.state.lease.active and
        std.meta.eql(context.state.lease.connection, connection.handle) and
        @intFromPtr(native_conn_context) == @intFromPtr(connection) and
        @intFromPtr(native_stream_context) == @intFromPtr(context);
}

fn respond(context: *anyopaque, request: *support.Request, response: *support.public_api.Response) void {
    const observation: *RouteObservation = @ptrCast(@alignCast(context));
    observation.calls += 1;
    observation.ownership_valid = ownership_valid(observation.server);
    if (request.body.len > observation.body.len) {
        observation.response_failed = true;
        return;
    }
    @memcpy(observation.body[0..request.body.len], request.body);
    observation.body_length = request.body.len;
    response.end("200 OK", request.body) catch {
        observation.response_failed = true;
    };
}

fn client_snapshot(client: *c.struct_uwz_engine_client) !c.struct_uwz_engine_client_snapshot {
    var snapshot: c.struct_uwz_engine_client_snapshot = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_engine_client_observe(client, &snapshot));
    return snapshot;
}

fn response_snapshot(client: *c.struct_uwz_engine_client, id: u64) !c.struct_uwz_engine_response_snapshot {
    var snapshot: c.struct_uwz_engine_response_snapshot = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_engine_client_response(client, id, &snapshot));
    return snapshot;
}

fn pump(server: *Engine, client: *c.struct_uwz_engine_client) !void {
    try testing.expectEqual(@as(c_int, 0), c.uwz_engine_client_process(client));
    const peer = loopback(c.uwz_engine_client_port(client));
    var bytes: [4096]u8 = undefined;
    while (true) {
        const size = c.uwz_engine_client_take_packet(client, &bytes, bytes.len);
        try testing.expect(size >= 0);
        if (size == 0) break;
        server.process_datagram(bytes[0..@intCast(size)], peer);
    }
    server.process();
    try testing.expect(c.uwz_engine_client_receive_udp(client) >= 0);
}

fn handshake(server: *Engine, client: *c.struct_uwz_engine_client) !void {
    try testing.expectEqual(@as(c_int, 0), c.uwz_engine_client_connect(client));
    var step: usize = 0;
    while (step < c.UWZ_ENGINE_MAX_STEPS) : (step += 1) {
        try pump(server, client);
        const observed = try client_snapshot(client);
        if (observed.handshake_complete == 0 or observed.settings_callbacks == 0) continue;
        if (server.active_connections != 1) continue;
        const index = try connection_index(server);
        if (server.connections.pool.storage[index].peer == null) continue;
        try testing.expectEqual(@as(c_uint, 1), observed.settings_callbacks);
        try testing.expect(observed.received_datagrams > 0);
        try testing.expectEqual(@as(c_uint, 0), observed.typed_callbacks);
        try testing.expectEqual(@as(usize, 1), server.connections.pool.count_active());
        try testing.expectEqual(@as(usize, 0), server.connections.pool.storage[index].stream_count);
        return;
    }
    return error.ActualServerHandshakeTimeout;
}

fn open_partial_post(server: *Engine, client: *c.struct_uwz_engine_client) !u64 {
    const id = c.uwz_engine_client_open_post(client, request_body.len);
    try testing.expect(id != std.math.maxInt(u64));
    try testing.expectEqual(@as(c_int, 0), c.uwz_engine_client_write(client, id, request_body.ptr, partial_size, 0));
    var step: usize = 0;
    while (step < c.UWZ_ENGINE_MAX_STEPS) : (step += 1) {
        try pump(server, client);
        if (server.stream_pool.count_active() != 1) continue;
        const index = try stream_index(server);
        if (server.stream_pool.storage[index].body_length != partial_size) continue;
        try testing.expect(ownership_valid(server));
        try testing.expectEqual(@as(usize, 1), server.header_pool.count_active());
        return id;
    }
    return error.ActualServerPartialBodyTimeout;
}

fn abort_and_drain(server: *Engine, client: *c.struct_uwz_engine_client) !void {
    const index = try connection_index(server);
    const handle = server.connections.pool.storage[index].handle;
    const native = server.connections.pool.storage[index].native orelse return error.MissingNativeConnection;
    c.lsquic_conn_abort(native);
    var step: usize = 0;
    while (step < c.UWZ_ENGINE_MAX_STEPS) : (step += 1) {
        try pump(server, client);
        if (server.active_connections != 0 or server.stream_pool.count_active() != 0) continue;
        try testing.expectEqual(@as(usize, 0), server.connections.pool.count_active());
        try testing.expectEqual(@as(usize, 0), server.header_pool.count_active());
        try testing.expect(server.connections.find(handle) == null);
        return;
    }
    return error.ActualServerAbortTimeout;
}

test "actual engine owns native connection and stream contexts through complete HTTP body" {
    const fd = c.uwz_engine_udp_socket_new();
    try testing.expect(fd >= 0);
    defer c.uwz_engine_udp_socket_close(fd);
    const port = c.uwz_engine_udp_socket_port(fd);
    try testing.expect(port != 0);
    const tls = c.lsquic_test_tls_context_new(1, "h3") orelse return error.TlsContext;
    defer c.SSL_CTX_free(tls);
    var server = try Engine.init();
    defer server.deinit();
    var route_observation: RouteObservation = .{ .server = &server };
    var route_storage: support.radix.DefaultBundle = .{};
    var router = try support.radix.Router.init(route_storage.storage());
    try router.route_context(.post, "/owned", &route_observation, respond);
    try server.start(tls, &router, fd, loopback(port));
    const client = c.uwz_engine_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_engine_client_destroy(client);
    try handshake(&server, client);
    const id = try open_partial_post(&server, client);
    try testing.expectEqual(@as(usize, 0), route_observation.calls);
    try testing.expectEqual(@as(c_int, 0), c.uwz_engine_client_write(client, id, request_body[partial_size..].ptr, request_body.len - partial_size, 1));

    var step: usize = 0;
    while (step < c.UWZ_ENGINE_MAX_STEPS) : (step += 1) {
        try pump(&server, client);
        const response = try response_snapshot(client, id);
        if (response.fin_received == 0 or response.close_callbacks == 0) continue;
        if (server.stream_pool.count_active() != 0) continue;
        try testing.expectEqual(@as(c_uint, 1), response.header_callbacks);
        try testing.expectEqual(@as(c_uint, 1), response.status_ok);
        try testing.expectEqual(@as(c_uint, 0), response.reset_callbacks);
        try testing.expectEqual(request_body.len, response.received);
        try testing.expectEqualSlices(u8, request_body, response.bytes[0..response.received]);
        break;
    }
    try testing.expect(step < c.UWZ_ENGINE_MAX_STEPS);
    try testing.expectEqual(@as(usize, 1), route_observation.calls);
    try testing.expect(route_observation.ownership_valid);
    try testing.expect(!route_observation.response_failed);
    try testing.expectEqualSlices(u8, request_body, route_observation.body[0..route_observation.body_length]);
    const index = try connection_index(&server);
    try testing.expectEqual(@as(usize, 0), server.connections.pool.storage[index].stream_count);
    try testing.expectEqual(@as(usize, 0), server.header_pool.count_active());
    try abort_and_drain(&server, client);
}

test "actual engine abort releases pending HTTP lease and reused connection generation" {
    const fd = c.uwz_engine_udp_socket_new();
    try testing.expect(fd >= 0);
    defer c.uwz_engine_udp_socket_close(fd);
    const port = c.uwz_engine_udp_socket_port(fd);
    const tls = c.lsquic_test_tls_context_new(1, "h3") orelse return error.TlsContext;
    defer c.SSL_CTX_free(tls);
    var server = try Engine.init();
    defer server.deinit();
    var route_observation: RouteObservation = .{ .server = &server };
    var route_storage: support.radix.DefaultBundle = .{};
    var router = try support.radix.Router.init(route_storage.storage());
    try router.route_context(.post, "/owned", &route_observation, respond);
    try server.start(tls, &router, fd, loopback(port));
    const first = c.uwz_engine_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_engine_client_destroy(first);
    try handshake(&server, first);
    _ = try open_partial_post(&server, first);
    const old_index = try connection_index(&server);
    const old_handle = server.connections.pool.storage[old_index].handle;
    try testing.expectEqual(@as(usize, 0), route_observation.calls);
    try abort_and_drain(&server, first);

    const second = c.uwz_engine_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_engine_client_destroy(second);
    try handshake(&server, second);
    const new_index = try connection_index(&server);
    const new_handle = server.connections.pool.storage[new_index].handle;
    try testing.expectEqual(old_handle.index, new_handle.index);
    try testing.expect(old_handle.generation != new_handle.generation);
    try testing.expect(server.connections.find(old_handle) == null);
    _ = try open_partial_post(&server, second);
    try testing.expectEqual(@as(usize, 0), route_observation.calls);
    try abort_and_drain(&server, second);
}
