# Actual project QUIC engine ownership harness

This separate scratch scaffold imports the actual project
`src/test_support.zig`, including the production `src/quic/engine.zig`, router,
request/response, pool, lsquic support, and WebTransport ownership modules.
One translated C module includes the actual project `src/c.h` and the scratch
client bridge, so the engine and driver share the same candidate native types.
The previous `/tmp/uwz-wt-zig-runtime-harness` is untouched.

## Real transport seam

The tests call the real engine's `init`, `start`, `process_datagram`, `process`,
and `deinit`. `start` receives a real TLS server context and bound nonblocking
loopback UDP socket. The production packet callback and `quic_api.send_packets`
send every server packet through that socket. A second bound UDP socket receives
the real datagrams for the native lsquic client.

Client output uses the candidate's existing bounded packet queue. The Zig
driver forwards queued bytes to the actual server's `process_datagram` with
the client's real loopback address. The C bridge advances the native client,
receives server UDP packets, and calls native client `packet_in`. Server
callbacks are never invoked manually, replaced, or simulated.

The production server owns lsquic global initialization through its existing
reference path. The client bridge performs no global init or cleanup and is
destroyed before server `deinit`. The client selects IETF QUIC only; that
candidate's IETF global initializer ignores the role flags. The bridge's
engine allocation, TLS references, decoded header sets, and client socket
have balanced destruction. The server owns its ordinary setup-time slabs.

## Two tests

1. A real POST carries a partial body while the driver checks that native
   connctx points at the occupied connection slot, native streamctx points at
   the matching sidecar, the sidecar owns the HTTP state, its active lease
   resolves to that connection generation, and the connection stream count
   is one. Completing the body calls the actual contextual route once and
   echoes the bytes through real HTTP/3 response headers, DATA and FIN. Native
   stream close releases the lease and header set while retaining the live
   connection. Aborting that connection then releases its slot.
2. A connection abort with a partial POST drives actual native teardown and
   releases the stream, header set, lease, and connection slot. A fresh TLS
   client reuses the same server slot with a different generation; the old
   handle cannot resolve. A second partial POST and abort check the reused
   ownership path.

The driver checks completed peer SETTINGS caching and actual UDP reception.
WebTransport negotiation stays disabled by the actual server policy. These
are ordinary HTTP/3 ownership tests; no live WebTransport session, application
datagram routing, external-client interop, or global-reference-count visibility
is claimed.

## Build inputs

- Candidate source is the clean frozen tree
  `/tmp/uwz-lsquic-wt-streams-20261113`, commit
  `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c`.
- The BoringSSL, lsquic, zlib, and sanitizer helpers are copied from the frozen
  backend scaffold; the libdeflate helper is copied unchanged from the actual
  project. The lsquic source override exists only in the scratch helper.
- The scratch manifest retains the actual project's exact dependency URLs,
  revisions, and Zig hashes, including the unchanged published lsquic pin
  `85bd081c9103c077a7cc98271d09334d0f1043d4`. The native lsquic build explicitly
  selects the frozen local candidate; it never rewrites a package input.
- `zig-pkg` links to the already populated project package directory. The
  project libxev shim and pinned libxev/zslay modules use the native module
  wiring. Optional SQL and SQLite options remain disabled in this scaffold.
- The three candidate fixture files `uwz_quic_fixture.c`,
  `uwz_quic_fixture.h`, and `uwz_webtransport_fixture.h` are unchanged copies.
  The original documented singleton clock and constructor hooks remain in the
  copied support; the new client bridge adds no mutable globals.
- The actual project `src/quic/lsquic_shim.c` compiles against the same real
  candidate header and retains its native lsxpack layout assertions.

## Root-agent commands

No compilation or execution has been performed by the scaffold agent.

```sh
cd /tmp/uwz-wt-zig-engine-harness
/tmp/zig-x86_64-linux-0.16.0/zig build test-compile \
  -Doptimize=Debug \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-streams-20261113 \
  --summary all
/tmp/zig-x86_64-linux-0.16.0/zig build test \
  -Doptimize=Debug \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-streams-20261113 \
  --summary all
```

The root agent can select other optimization modes or use
`-Dproject-source=/absolute/path/to/checkout`. This builds only the actual
engine harness artifact; it does not add a production build option, pin
override, activation flag, CI change, or deferred gate.
