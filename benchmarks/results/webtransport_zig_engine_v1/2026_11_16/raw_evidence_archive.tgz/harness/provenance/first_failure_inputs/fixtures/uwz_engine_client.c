/* Copyright (c) 2026 uWebZockets contributors. See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <openssl/ssl.h>
#include "lsquic.h"
#include "lsxpack_header.h"
#include "uwz_quic_fixture.h"
#include "uwz_webtransport_fixture.h"
#include "uwz_engine_client.h"

#ifdef NDEBUG
#error "uwz_engine_client requires active assertions"
#endif

struct uwz_engine_request {
    lsquic_stream_t *native;
    struct uwz_engine_response_snapshot observation;
};

struct uwz_engine_client {
    struct lsquic_test_pair transport;
    lsquic_conn_t *native;
    int udp_fd;
    struct uwz_engine_client_snapshot observation;
    struct uwz_engine_request requests[UWZ_ENGINE_MAX_STREAMS];
    struct streams_header_pool headers;
};

int
uwz_engine_udp_socket_new(void)
{
    struct sockaddr_in address;
    int fd = socket(AF_INET, SOCK_DGRAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);

    if (fd < 0)
        return -1;
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (bind(fd, (struct sockaddr *) &address, sizeof(address)))
    {
        close(fd);
        return -1;
    }
    return fd;
}

uint16_t
uwz_engine_udp_socket_port(int fd)
{
    struct sockaddr_in address;
    socklen_t size = sizeof(address);

    if (getsockname(fd, (struct sockaddr *) &address, &size)
        || size != sizeof(address) || address.sin_family != AF_INET)
        return 0;
    return ntohs(address.sin_port);
}

void
uwz_engine_udp_socket_close(int fd)
{
    if (fd >= 0)
        assert(close(fd) == 0);
}

static struct uwz_engine_request *
find_request(struct uwz_engine_client *client, uint64_t id)
{
    unsigned index;

    for (index = 0; index < client->observation.stream_callbacks; ++index)
        if (client->requests[index].observation.stream_id == id)
            return &client->requests[index];
    return NULL;
}

static lsquic_conn_ctx_t *
new_connection(void *ctx, lsquic_conn_t *conn)
{
    struct uwz_engine_client *client = ctx;

    assert(!client->native);
    client->native = conn;
    return (lsquic_conn_ctx_t *) client;
}

static void
handshake_done(lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct uwz_engine_client *client = (void *) lsquic_conn_get_ctx(conn);

    assert(client && status == LSQ_HSK_OK);
    client->observation.handshake_complete = 1;
}

static void
settings_received(lsquic_conn_t *conn)
{
    struct uwz_engine_client *client = (void *) lsquic_conn_get_ctx(conn);

    assert(client && client->native == conn);
    ++client->observation.settings_callbacks;
}

static void
connection_closed(lsquic_conn_t *conn)
{
    struct uwz_engine_client *client = (void *) lsquic_conn_get_ctx(conn);

    assert(client && client->native == conn);
    ++client->observation.connection_closed;
    client->native = NULL;
    lsquic_conn_set_ctx(conn, NULL);
}

static lsquic_stream_ctx_t *
new_stream(void *ctx, lsquic_stream_t *stream)
{
    struct uwz_engine_client *client = ctx;
    struct uwz_engine_request *request;

    assert(stream && client->observation.stream_callbacks < UWZ_ENGINE_MAX_STREAMS);
    request = &client->requests[client->observation.stream_callbacks++];
    request->native = stream;
    request->observation.stream_id = lsquic_stream_id(stream);
    assert(lsquic_stream_wantread(stream, 1) >= 0);
    return (lsquic_stream_ctx_t *) request;
}

static void
headers_received(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct uwz_engine_request *request = (void *) ctx;
    struct streams_header_set *set;
    const struct lsxpack_header *header;
    unsigned index;

    assert(request && request->native == stream);
    ++request->observation.header_callbacks;
    set = lsquic_stream_get_hset(stream);
    assert(set && set->shs_active && set->shs_complete);
    for (index = 0; index < set->shs_count; ++index)
    {
        header = &set->shs_fields[index].shf_header;
        if (header->name_len == 7
            && !memcmp(lsxpack_header_get_name(header), ":status", 7)
            && header->val_len == 3
            && !memcmp(lsxpack_header_get_value(header), "200", 3))
            request->observation.status_ok += 1;
    }
    discard_header_set(set);
}

static void
read_stream(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct uwz_engine_request *request = (void *) ctx;
    struct uwz_engine_response_snapshot *out = &request->observation;
    ssize_t size;

    assert(request && request->native == stream);
    while (out->received < sizeof(out->bytes))
    {
        size = lsquic_stream_read(stream, out->bytes + out->received,
                                sizeof(out->bytes) - out->received);
        if (size > 0)
        {
            out->received += (size_t) size;
            continue;
        }
        if (size < 0)
        {
            assert(errno == EAGAIN || errno == EWOULDBLOCK || out->reset_callbacks);
            return;
        }
        out->fin_received = 1;
        assert(lsquic_stream_wantread(stream, 0) >= 0);
        assert(lsquic_stream_shutdown(stream, 0) == 0);
        return;
    }
    assert(0 && "bounded response body exhausted");
}

static void
write_stream(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) ctx;
    assert(lsquic_stream_wantwrite(stream, 0) >= 0);
}

static void
close_stream(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct uwz_engine_request *request = (void *) ctx;

    assert(request && request->native == stream && !request->observation.close_callbacks);
    ++request->observation.close_callbacks;
    request->native = NULL;
}

static void
reset_stream(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx, int how)
{
    struct uwz_engine_request *request = (void *) ctx;

    assert(request && request->native == stream && (how == 0 || how == 1));
    ++request->observation.reset_callbacks;
}

static void
typed_stream(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct uwz_engine_client *client = (void *) lsquic_conn_get_ctx(lsquic_stream_conn(stream));

    (void) ctx;
    ++client->observation.typed_callbacks;
}

static const struct lsquic_stream_if client_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_h3_settings = settings_received,
    .on_new_stream = new_stream,
    .on_hset_in = headers_received,
    .on_webtransport_stream = typed_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_reset = reset_stream,
};

struct uwz_engine_client *
uwz_engine_client_create(uint16_t server_port)
{
    struct uwz_engine_client *client;
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    int result;

    if (!server_port)
        return NULL;
    client = calloc(1, sizeof(*client));
    if (!client)
        return NULL;
    client->udp_fd = uwz_engine_udp_socket_new();
    if (client->udp_fd < 0)
    {
        free(client);
        return NULL;
    }
    client->transport.ltp_server.lte_address.sin_family = AF_INET;
    client->transport.ltp_server.lte_address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    client->transport.ltp_server.lte_address.sin_port = htons(server_port);
    lsquic_engine_init_settings(&settings, LSENG_HTTP);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_bidi = 8;
    settings.es_init_max_streams_uni = 8;
    settings.es_qpack_dec_max_size = 0;
    settings.es_qpack_dec_max_blocked = 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    settings.es_max_udp_payload_size_rx = 2048;
    assert(lsquic_engine_check_settings(&settings, LSENG_HTTP, NULL, 0) == 0);
    memset(&config, 0, sizeof(config));
    config.ltec_flags = LSENG_HTTP;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &client_callbacks;
    config.ltec_stream_if_ctx = client;
    config.ltec_hsi_if = &streams_hsi;
    config.ltec_hsi_ctx = &client->headers;
    config.ltec_alpn = "h3";
    config.ltec_tls = lsquic_test_tls_context_new(0, "h3");
    if (!config.ltec_tls)
    {
        uwz_engine_client_destroy(client);
        return NULL;
    }
    result = lsquic_test_endpoint_init(&client->transport.ltp_client,
        &client->transport.ltp_server, &config, uwz_engine_udp_socket_port(client->udp_fd));
    SSL_CTX_free(config.ltec_tls);
    if (result)
    {
        uwz_engine_client_destroy(client);
        return NULL;
    }
    return client;
}

void
uwz_engine_client_destroy(struct uwz_engine_client *client)
{
    if (!client)
        return;
    lsquic_test_endpoint_destroy(&client->transport.ltp_client);
    assert(client->headers.shp_created == client->headers.shp_discarded);
    uwz_engine_udp_socket_close(client->udp_fd);
    free(client);
}

int
uwz_engine_client_connect(struct uwz_engine_client *client)
{
    if (!client || client->native)
        return -1;
    return lsquic_engine_connect(client->transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &client->transport.ltp_client.lte_address,
                (struct sockaddr *) &client->transport.ltp_server.lte_address,
                &client->transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0) ? 0 : -1;
}

int
uwz_engine_client_process(struct uwz_engine_client *client)
{
    if (!client)
        return -1;
    lsquic_test_pair_process(&client->transport, 1000);
    return 0;
}

int
uwz_engine_client_take_packet(struct uwz_engine_client *client,
                              unsigned char *out, size_t capacity)
{
    struct lsquic_test_packet packet;

    if (!client || !out)
        return -1;
    if (!client->transport.ltp_server.lte_incoming.ltq_count)
        return 0;
    if (lsquic_test_packet_take(&client->transport.ltp_server, 0, &packet)
        || packet.ltp_size > capacity)
        return -1;
    memcpy(out, packet.ltp_bytes, packet.ltp_size);
    return (int) packet.ltp_size;
}

int
uwz_engine_client_receive_udp(struct uwz_engine_client *client)
{
    struct lsquic_test_packet packet;
    ssize_t size;
    unsigned count = 0;

    if (!client)
        return -1;
    while (count < LSQUIC_TEST_MAX_PACKETS)
    {
        size = recv(client->udp_fd, packet.ltp_bytes, sizeof(packet.ltp_bytes), MSG_DONTWAIT);
        if (size < 0 && (errno == EAGAIN || errno == EWOULDBLOCK))
            return (int) count;
        if (size <= 0)
            return -1;
        packet.ltp_size = (size_t) size;
        if (lsquic_test_packet_deliver(&client->transport.ltp_client, &packet) < 0)
            return -1;
        ++client->observation.received_datagrams;
        ++count;
    }
    return (int) count;
}

uint16_t
uwz_engine_client_port(const struct uwz_engine_client *client)
{
    return client ? ntohs(client->transport.ltp_client.lte_address.sin_port) : 0;
}

int
uwz_engine_client_observe(const struct uwz_engine_client *client,
                          struct uwz_engine_client_snapshot *out)
{
    if (!client || !out)
        return -1;
    *out = client->observation;
    return 0;
}

int
uwz_engine_client_response(const struct uwz_engine_client *client, uint64_t id,
                           struct uwz_engine_response_snapshot *out)
{
    unsigned index;

    if (!client || !out)
        return -1;
    for (index = 0; index < client->observation.stream_callbacks; ++index)
    {
        if (client->requests[index].observation.stream_id != id)
            continue;
        *out = client->requests[index].observation;
        return 0;
    }
    return -1;
}

uint64_t
uwz_engine_client_open_post(struct uwz_engine_client *client, size_t body_size)
{
    static const char *const fields[] = {
        ":methodPOST", ":schemehttps", ":authoritylocalhost", ":path/owned",
    };
    static const unsigned name_sizes[] = { 7, 7, 10, 5 };
    struct lsxpack_header encoded[5];
    struct lsquic_http_headers headers = { 5, encoded };
    struct uwz_engine_request *request;
    char length_field[40];
    unsigned index, before;
    int length_size;

    if (!client || !client->native || body_size > UWZ_ENGINE_MAX_BODY)
        return UINT64_MAX;
    before = client->observation.stream_callbacks;
    lsquic_conn_make_stream(client->native);
    if (client->observation.stream_callbacks != before + 1)
        return UINT64_MAX;
    request = &client->requests[before];
    for (index = 0; index < 4; ++index)
        lsxpack_header_set_offset2(&encoded[index], fields[index], 0,
                    name_sizes[index], name_sizes[index], strlen(fields[index]) - name_sizes[index]);
    length_size = snprintf(length_field, sizeof(length_field), "content-length%zu", body_size);
    if (length_size < 14 || (size_t) length_size >= sizeof(length_field))
        return UINT64_MAX;
    lsxpack_header_set_offset2(&encoded[4], length_field, 0, 14, 14, (unsigned) length_size - 14);
    if (lsquic_stream_send_headers(request->native, &headers, 0)
        || lsquic_stream_flush(request->native))
        return UINT64_MAX;
    return request->observation.stream_id;
}

int
uwz_engine_client_write(struct uwz_engine_client *client, uint64_t id,
                        const unsigned char *bytes, size_t size, int fin)
{
    struct uwz_engine_request *request;
    ssize_t written;

    if (!client || !bytes || size > UWZ_ENGINE_MAX_BODY || (fin != 0 && fin != 1))
        return -1;
    request = find_request(client, id);
    if (!request || !request->native)
        return -1;
    written = lsquic_stream_write(request->native, bytes, size);
    if (written < 0 || (size_t) written != size)
        return -1;
    if (fin && lsquic_stream_shutdown(request->native, 1))
        return -1;
    return lsquic_stream_flush(request->native);
}
