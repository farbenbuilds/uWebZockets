/* Copyright (c) 2026 uWebZockets contributors. See LICENSE. */
#ifndef UWZ_ENGINE_CLIENT_H
#define UWZ_ENGINE_CLIENT_H

#include <stddef.h>
#include <stdint.h>
#include "lsquic.h"

struct uwz_engine_client;

enum {
    UWZ_ENGINE_MAX_STEPS = 20000,
    UWZ_ENGINE_MAX_STREAMS = 8,
    UWZ_ENGINE_MAX_BODY = 512,
};

struct uwz_engine_client_snapshot {
    unsigned handshake_complete;
    unsigned settings_callbacks;
    unsigned connection_closed;
    unsigned stream_callbacks;
    unsigned typed_callbacks;
    unsigned received_datagrams;
};

struct uwz_engine_response_snapshot {
    uint64_t stream_id;
    size_t received;
    unsigned header_callbacks;
    unsigned status_ok;
    unsigned fin_received;
    unsigned close_callbacks;
    unsigned reset_callbacks;
    unsigned char bytes[UWZ_ENGINE_MAX_BODY];
};

/* No global init/cleanup: the actual project engine owns that reference. */
struct uwz_engine_client *uwz_engine_client_create(uint16_t server_port);
void uwz_engine_client_destroy(struct uwz_engine_client *);
int uwz_engine_client_connect(struct uwz_engine_client *);
int uwz_engine_client_process(struct uwz_engine_client *);
int uwz_engine_client_take_packet(struct uwz_engine_client *, unsigned char *, size_t);
int uwz_engine_client_receive_udp(struct uwz_engine_client *);
uint16_t uwz_engine_client_port(const struct uwz_engine_client *);
int uwz_engine_client_observe(const struct uwz_engine_client *, struct uwz_engine_client_snapshot *);
int uwz_engine_client_response(const struct uwz_engine_client *, uint64_t,
                               struct uwz_engine_response_snapshot *);
uint64_t uwz_engine_client_open_post(struct uwz_engine_client *, size_t body_size);
int uwz_engine_client_write(struct uwz_engine_client *, uint64_t,
                            const unsigned char *, size_t, int fin);

int uwz_engine_udp_socket_new(void);
uint16_t uwz_engine_udp_socket_port(int fd);
void uwz_engine_udp_socket_close(int fd);

#endif
