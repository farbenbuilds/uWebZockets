const std = @import("std");
const engine = @import("builds/engine.zig");

pub fn build(b: *std.Build) void {
    engine.configure(b);
}
