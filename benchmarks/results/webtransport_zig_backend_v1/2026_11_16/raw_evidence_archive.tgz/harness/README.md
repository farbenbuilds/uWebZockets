# Real native WebTransport backend harness

This isolated Zig 0.16.0 scaffold imports the repository's actual
`src/quic/webtransport/backend.zig` and gives it a translated module named
`c`, generated from the candidate's real public lsquic header and BoringSSL
headers. It compiles the candidate and dependencies using the existing native
Zig C/C++ build helpers. No production manifest, pin, source, or capability is
changed by this scaffold.

A separate test artifact roots directly at the repository's
`src/tests/webtransport_runtime_tests.zig`. Its scratch `test_support` namespace
only aliases `webtransport_backend` to the same actual backend module; the
component artifact uses the same real translated C module as the TLS driver.
`test` runs ten tests across both artifacts, `test-native` runs the four TLS
driver tests, and `test-components` runs the six centralized component tests.

## Inputs and provenance

- Frozen candidate source:
  `/tmp/uwz-lsquic-wt-streams-20261113`, clean commit
  `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c`.
- Build helpers copied from `/tmp/uwz-lsquic-webtransport-harness/builds`.
  The lsquic helper's default scratch source path is the only helper edit.
- The BoringSSL, ls-qpack, ls-hpack, and zlib URL/revision and Zig hashes in
  `build.zig.zon` are unchanged from the existing scaffold. BoringSSL is
  `d3bf4795ad5b79d646cddf2fec687da5b9b502db`, ls-qpack is
  `91567706c41c0d97ab8dc576873ecd472d7869fa`, ls-hpack is
  `fda48e02491d865cce00612be8cc10c2622b8e55`, and zlib is 1.3.2.
- `zig-pkg` links to the already populated immutable package inputs at
  `/tmp/uwz-lsquic-uni-harness/zig-pkg`.
- The repository's published lsquic pin remains
  `85bd081c9103c077a7cc98271d09334d0f1043d4`.

`fixtures/c.h` matches the repository's translation-only BoringSSL workaround:
it includes `openssl/base.h`, undefines `OPENSSL_GNUC_CLANG_PRAGMA`, and defines
that macro empty before including `openssl/ssl.h`. This suppresses the
diagnostic pragmas that ARO cannot translate in `DEFINE_STACK_OF`; the native
C/C++ vendor sources and their compilation are unchanged.

The following candidate test files were copied unchanged into `fixtures/`:

| File | SHA-256 |
| --- | --- |
| `uwz_quic_fixture.c` | `8cd2c2878be1e8beb03e02d39a2294de2954d6c022f3a2b67a9476dc0de70be5` |
| `uwz_quic_fixture.h` | `9326751e969a28ebe5426850e3c462d6879a93daac82a10a6fa364bad7b0de5f` |
| `uwz_webtransport_fixture.h` | `0099248b52dc9537adc4664ac7c9facc939565d0a62786b44076799e6ce48bdc` |

`fixtures/uwz_wt_bridge.c` owns the engine pair and two fixed eight-stream
tables in one fixture allocation. It adds no mutable global state. The copied
packet fixture retains its documented process-wide clock and one-shot native
constructor hooks. Engine destruction, TLS references, claimed header sets,
the fixture allocation, and lsquic initialization are balanced. Fixtures run
sequentially because lsquic initialization is process-wide.

## Phase API

The bridge header is `fixtures/uwz_wt_bridge.h`. Calls return native pointers
from the actual TLS engines; no lsquic symbols or layouts are simulated.

1. `uwz_wt_fixture_create` accepts a named initialization callback. The Zig
   driver invokes `backend.configure` and `backend.install_callbacks` against
   the real settings and fixture-owned callback table before each engine is
   created. Stack-owned callback context records the native zero defaults,
   both configuration calls, and preservation of every existing callback.
   The context pointer is not retained after the constructor returns. Passing
   null selects the bridge's baseline configuration.
   `uwz_wt_fixture_connect` exposes the client connection before peer SETTINGS.
   `uwz_wt_fixture_handshake` pumps until
   both actual TLS connections have received SETTINGS.
2. `uwz_wt_fixture_open_connect` sends all six extended CONNECT headers,
   including draft-16 `:protocol = webtransport-h3` and Origin.
   `uwz_wt_fixture_await_headers` validates and releases the real decoded
   header set while leaving session admission to the Zig caller.
3. The Zig driver invokes `backend.accept_connect(server)`.
   `uwz_wt_fixture_send_success` sends a real non-FIN 200 response.
   After the client header callback, the driver invokes
   `backend.accept_connect(client)`.
4. The driver invokes `backend.create_child`; bridge callbacks record the
   native creation/typed/read/close/reset counts and copied metadata.
   `uwz_wt_fixture_write` supplies bounded raw bytes and pumps only when
   requested through the separate phase API.

The tests check capability discovery, pending and invalid getter output
preservation, real peer flags 31 on the client and 29 on the server, no-session
and invalid creation without new callbacks, CONNECT marking, and raw payload
delivery with directional prefix metadata for client/server bidi/uni children.
Actual peer-decoded limits of data 4096, bidi 2, and uni 3 check all three
translated C offsets and wrapper field mappings. This is negotiation evidence;
the scaffold makes no claim that Zig session flow control is connected.
An additional fresh TLS pair advertises data `(1 << 40) + 4096`, bidi
`(1 << 35) + 2`, and uni `(1 << 34) + 3` to check positive 64-bit values
through actual SETTINGS decoding and backend snapshots on both roles.
They keep parents and children alive for direct metadata reads. Snapshot APIs
also retain native metadata observed during close for later lifecycle tests.

## Commands for the root agent

These commands have not been run by the scaffold implementation agent.

```sh
cd /tmp/uwz-wt-zig-runtime-harness
/tmp/zig-x86_64-linux-0.16.0/zig build test-compile \
  -Doptimize=Debug \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-streams-20261113 \
  --summary all
/tmp/zig-x86_64-linux-0.16.0/zig build test \
  -Doptimize=Debug \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-streams-20261113 \
  --summary all
```

For separate artifact evidence, replace `test` with `test-components` (six
repository component tests) and `test-native` (four actual TLS driver tests).

`-Dbackend-source=/absolute/path/to/backend.zig` selects another repository
checkout. Both the backend and test driver share the same translated C module,
so their pointers have the same actual candidate types. `builds/runtime.zig`
owns module construction separately from the reused vendor graph; it can be
extended with the full repository module and additional pinned dependencies
when the root agent reaches engine/runtime integration.
`-Dcomponent-tests-source=/absolute/path/to/webtransport_runtime_tests.zig`
selects the corresponding centralized test file from another checkout.

During initial setup, the root agent's first Debug compile failed in ARO on
BoringSSL diagnostic pragmas. After the workaround and native enum correction,
the root agent reported nine tests green in
`/tmp/uwz-wt-backend-candidate-enum-fixed-debug.log`. The current ten-test suite
adds the 64-bit peer case and awaits the root agent's final runs. The scaffold
implementation agent has not compiled or executed either artifact.

Current scope is the private backend leaf and actual TLS fixture phases.
This scaffold does not prove listener activation, application routing,
WebTransport interoperability with another implementation, complete lifecycle
coverage, sanitizer coverage, or any deferred gate.
