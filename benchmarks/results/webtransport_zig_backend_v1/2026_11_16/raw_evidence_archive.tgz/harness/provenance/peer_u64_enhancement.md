# Frozen peer limit enhancement

Date: 2026-11-16

The wide-limit code enhancement modifies only `tests/backend_native.zig`. It retains
the 4096/2/3 peer case and introduces a fresh engine pair configured through
stack-owned callback context with advertised WebTransport limits:

- data: `(1 << 40) + 4096`;
- bidirectional streams: `(1 << 35) + 2`;
- unidirectional streams: `(1 << 34) + 3`.

The callback compares the complete native C settings record against its
original value with only the intended negotiation fields changed. It also
checks that installing the original native callbacks preserves the complete
callback table. Both roles check the raw C and backend peer snapshots, exact
limits, flags 31/29, and role-specific prerequisites. The added case creates
no application streams and preserves the native QUIC limits and fixed tables.

The driver now contains four tests; the centralized repository artifact
contains six. The current README and build-step descriptions reflect ten
combined tests. The final documentation polish changes no types or behavior.

As historical setup evidence, the root agent reported the earlier nine-test Debug run green at
`/tmp/uwz-wt-backend-candidate-enum-fixed-debug.log`. The new wide-limit case
has not been built or executed by this agent. Its pending root verification
must report ten tests, including four TLS-driver and six centralized tests.
Formatting and source-integrity checks passed. No sanitizer, security, fuzz,
smoke, publishing, or push operation was run.

`final_inputs.sha256` freezes the scratch build graph, fixture sources,
translated-C umbrella input, test driver, support alias, manifest, and notes.
`external_inputs.sha256` records the actual root backend and central tests
plus the candidate public header. The candidate remains clean at commit
`2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c`.

This enhancement covers positive 64-bit peer limit copying after real TLS
SETTINGS delivery. It provides no evidence for high-session-ID child streams
or connected Zig session flow control.
