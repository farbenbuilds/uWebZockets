# Private WebTransport Zig backend evidence

This archive records the first private backend-contract slice, based on project
commit 5810982dae0f81c4d9ecc782293fa998b2110603. The final project files are
under project/. The actual native candidate is clean commit
2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c; its source and incremental bundle
are retained by the preceding lsquic_webtransport_children_v1/2026_11_16
archive and its prerequisite archives. No native source is duplicated here.
Published production pins and listener capability records are unchanged.

## Reproduce

Verify files.sha256 before use. Restore that exact native candidate using the
preceding archive handoff, or use the already restored clean candidate. Install
Zig 0.16.0 and resolve the pinned packages in harness/build.zig.zon. Dependency
caches and generated outputs are deliberately absent. The original commands
and absolute source paths are in harness/provenance/final-runs.json. Run from
harness/ with paths adjusted explicitly for the restored project and candidate:

```sh
zig build test -Doptimize=Debug -j2 --summary all \
  -Dbackend-source=/absolute/project/src/quic/webtransport/backend.zig \
  -Dcomponent-tests-source=/absolute/project/src/tests/webtransport_runtime_tests.zig \
  -Dlsquic-source=/absolute/native-candidate
```

Repeat with ReleaseSafe and ReleaseFast. The source overrides belong only to
this isolated verification scaffold. They are not production build options.
The archived project/ copies also allow isolated replay of the tested leaf.
Both test artifacts share the real translated candidate C module and actual
project backend. The scratch test_support only aliases that backend.

## Results and original failures

Final Debug, ReleaseSafe and ReleaseFast runs each pass ten tests in 15/15
steps: four real TLS driver cases and six actual project component cases.
They verify negotiation PENDING/output preservation, native settings and callback
installation before engine creation, three 64-bit peer limits including values
above 32 bits, admitted non-FIN CONNECT, and UNI/BIDI children in both roles.

The first candidate compile failed on BoringSSL diagnostic pragmas in ARO.
The scaffold adopted the existing root translation-only macro workaround.
The next compile found an inferred signed C enum argument; the backend now
uses the actual translated enum type and requires that declaration. The
nine-test GREEN predates the added positive 64-bit peer-limit test. Original
setup failures and intermediate GREEN logs are retained as such.

The first published-pin RED failed because backend.zig was absent. After
implementation, the six targeted component tests and all 964 centralized
published-pin tests pass via test-unit. That target includes the existing
archive symbol check. The default test target retains its existing consumers
and C API smoke dependencies; no test assertion or threshold was weakened.

## Limits

This verifies the private adapter and actual native TLS fixture phases. It
does not implement fixed connection generations, session ownership, application
routing, datagram delivery, capsule integration, or listener activation.
No independent WebTransport client acceptance, child loss campaign, foreign
runtime, new allocation proof or full release completion is claimed. Smoke
and security verification remain deferred by the user. No caches, binaries,
core files, generated keys or packet captures are included.

The scaffold README is retained byte-for-byte from the implementation agent;
its statement that the final ten-test cohort awaits root execution predates
the final-runs.json and final log records. Those later records are authoritative.
