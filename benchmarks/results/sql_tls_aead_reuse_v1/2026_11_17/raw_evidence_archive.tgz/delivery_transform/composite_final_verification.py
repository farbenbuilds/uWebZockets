#!/usr/bin/env python3
"""Verify the strip phase plus exactly two documented replay guard edits."""
import hashlib
import json
from pathlib import Path
import runpy


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def guarded_source(original):
    anchor = '    base = Path(__file__).resolve().parent\n'
    insertion = (
        '    evidence_root = base\n'
        "    if ((base.parent / 'restore_pki_tool.py').is_file() and\n"
        "            (base.parent / 'native/HANDOFF.md').is_file()):\n"
        '        evidence_root = base.parent\n'
    )
    guard = '    if output.resolve().is_relative_to(base):\n'
    if original.count(anchor) != 1 or original.count(guard) != 1:
        raise ValueError('Unexpected original guard shape')
    return original.replace(anchor, anchor + insertion, 1).replace(
        guard, '    if output.resolve().is_relative_to(evidence_root):\n', 1)


def verify_subtree(stage, base, producer, subtree, strip_record, guard_record):
    original_identity = json.loads((base / ('original_' + subtree + '_prebuilt_identity.json')).read_text())
    delivered_identity = json.loads((stage / subtree / 'prebuilt_identity.json').read_text())
    expected_identity = json.loads(json.dumps(original_identity))
    binary_rows = {row['path']: row for row in strip_record['binaries'] if row['subtree'] == subtree}
    for name, row in binary_rows.items():
        expected_identity['binaries'][name] = row['delivered_sha256']
        if 'sizes' in expected_identity:
            expected_identity['sizes'][name] = row['delivered_bytes']
    expected_identity['delivery_transform'] = '../delivery_transform/manifest.json'
    if delivered_identity != expected_identity:
        raise ValueError('Delivery identity has an unauthorized change: ' + subtree)
    wrapper_rows = {row['path']: row for row in guard_record['wrappers']}
    wrapper = subtree + '/replay_prebuilt.py'
    before_text = (producer / 'replay_prebuilt.py').read_text()
    after_text = (stage / wrapper).read_text()
    if after_text != guarded_source(before_text):
        raise ValueError('Replay wrapper has a change beyond the exact guard: ' + subtree)
    if digest(producer / 'replay_prebuilt.py') != wrapper_rows[wrapper]['before_sha256']:
        raise ValueError('Original wrapper checksum differs')
    if digest(stage / wrapper) != wrapper_rows[wrapper]['after_sha256']:
        raise ValueError('Delivered wrapper checksum differs')
    allowed = set(binary_rows) | {'prebuilt_identity.json', 'replay_prebuilt.py'}
    original_entries = 0
    untouched = 0
    for line in (base / ('original_' + subtree + '_files.sha256')).read_text().splitlines():
        checksum, name = line.split('  ', 1)
        if digest(producer / name) != checksum:
            raise ValueError('Original producer entry changed: ' + name)
        original_entries += 1
        if name in allowed:
            continue
        if digest(stage / subtree / name) != checksum:
            raise ValueError('Unauthorized staged change: ' + subtree + '/' + name)
        untouched += 1
    before_manifest = base / 'guard_step' / ('before_' + subtree + '_files.sha256')
    manifest_record = guard_record['submanifests'][subtree]
    if digest(before_manifest) != manifest_record['before_sha256']:
        raise ValueError('Pre-guard delivery manifest differs')
    if digest(stage / subtree / 'files.sha256') != manifest_record['after_sha256']:
        raise ValueError('Final delivery manifest differs')
    changed = []
    for line in before_manifest.read_text().splitlines():
        checksum, name = line.split('  ', 1)
        if digest(stage / subtree / name) != checksum:
            changed.append(name)
    if changed != ['replay_prebuilt.py']:
        raise ValueError('Second step changed more than its wrapper: ' + subtree)
    return original_entries, untouched


def main():
    base = Path(__file__).resolve().parent
    stage = base.parent
    strip_record = json.loads((base / 'manifest.json').read_text())
    guard_record = json.loads((base / 'guard_step/manifest.json').read_text())
    historical_entries = 0
    for line in (base / 'guard_step/before_delivery_transform_files.sha256').read_text().splitlines():
        checksum, name = line.split('  ', 1)
        path = base / name
        if name == 'HANDOFF.md':
            path = base / 'guard_step/original_strip_HANDOFF.md'
        if digest(path) != checksum:
            raise ValueError('Historical strip record changed: ' + name)
        historical_entries += 1
    historical = json.loads((base / 'post_transform_verification.json').read_text())
    if historical['non_delivery_staged_entries_unchanged'] != 707:
        raise ValueError('Historical strip phase scope changed')
    strip = runpy.run_path(str(base / 'strip_delivery.py'), run_name='strip_checker')
    prior = runpy.run_path(str(base / 'verify_delivery.py'), run_name='historical_checker')
    roots = {
        'helper': Path('/tmp/uwz-pg-tls-aead-verify-20261117'),
        'wire': Path('/tmp/uwz-pg-tls-aead-wire-20261117'),
    }
    original_entries = 0
    untouched = 0
    for subtree, producer in roots.items():
        counts = verify_subtree(stage, base, producer, subtree, strip_record, guard_record)
        original_entries += counts[0]
        untouched += counts[1]
        strip['verify_manifest'](stage / subtree)
    for row in strip_record['binaries']:
        original = roots[row['subtree']] / row['path']
        delivered = stage / row['subtree'] / row['path']
        if digest(original) != row['original_measured_sha256']:
            raise ValueError('Original executable changed')
        if digest(delivered) != row['delivered_sha256']:
            raise ValueError('Delivered executable changed during guard step')
        before, after = original.read_bytes(), delivered.read_bytes()
        if strip['compare_elf'](before, after) != row['elf_comparison']:
            raise ValueError('Runtime ELF proof changed')
        if not prior['has_symbol_table'](before) or not prior['has_symbol_table'](after):
            raise ValueError('Regular symbol table missing')
    if original_entries != 727 or untouched != 705:
        raise ValueError('Unexpected composite change scope')
    result = {
        'complete': True, 'delivery_steps': 2,
        'producer_manifest_entries_unchanged': original_entries,
        'other_original_staged_entries_unchanged': untouched,
        'historical_strip_manifest_entries_retained': historical_entries,
        'historical_strip_phase_unchanged_entries': 707,
        'authorized_binary_strip_copies': 18,
        'authorized_binary_delivery_identity_maps': 2,
        'authorized_combined_root_guard_wrappers': 2,
        'second_step_changed_only_two_guard_wrappers': True,
        'regular_symbol_tables_and_runtime_elf_proofs_rechecked': 18,
        'baseline_guard_gap_checks': len(guard_record['baseline_red_checks']),
        'final_early_refusal_checks': len(guard_record['final_early_checks']),
        'native_or_measurement_fixture_sources_and_raw_results_changed': False,
        'private_pki_created_in_guard_checks': False,
        'happy_path_replays': 'Root-owned and required after both delivery steps',
    }
    (base / 'composite_final_verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
