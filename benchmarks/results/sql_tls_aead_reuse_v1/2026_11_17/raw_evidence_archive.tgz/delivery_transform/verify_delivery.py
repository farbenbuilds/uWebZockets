#!/usr/bin/env python3
"""Recheck exact original and delivered identities after debug-only stripping."""
import hashlib
import json
from pathlib import Path
import runpy
import struct


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def has_symbol_table(data):
    header = struct.unpack('<16sHHIQQQIHHHHHH', data[:64])
    offset, width, count = header[6], header[11], header[12]
    for index in range(count):
        section = struct.unpack('<IIQQQQIIQQ', data[offset + index * width:offset + (index + 1) * width])
        if section[1] == 2 and section[5] > 0:
            return True
    return False


def main():
    base = Path(__file__).resolve().parent
    stage = base.parent
    transform = json.loads((base / 'manifest.json').read_text())
    checker = runpy.run_path(str(base / 'strip_delivery.py'), run_name='delivery_checker')
    producer_roots = {
        'helper': Path('/tmp/uwz-pg-tls-aead-verify-20261117'),
        'wire': Path('/tmp/uwz-pg-tls-aead-wire-20261117'),
    }
    unchanged = 0
    original_entries = 0
    for subtree, producer in producer_roots.items():
        identity = json.loads((stage / subtree / 'prebuilt_identity.json').read_text())
        changed = set(identity['binaries']) | {'prebuilt_identity.json'}
        lines = (base / ('original_' + subtree + '_files.sha256')).read_text().splitlines()
        for line in lines:
            checksum, name = line.split('  ', 1)
            if sha(producer / name) != checksum:
                raise ValueError('Original producer changed: ' + subtree + '/' + name)
            original_entries += 1
            if name not in changed:
                if sha(stage / subtree / name) != checksum:
                    raise ValueError('Non-delivery staged file changed: ' + name)
                unchanged += 1
        checker['verify_manifest'](stage / subtree)
        for name, checksum in identity['binaries'].items():
            if sha(stage / subtree / name) != checksum:
                raise ValueError('Delivered binary identity differs: ' + name)
    for row in transform['binaries']:
        original = producer_roots[row['subtree']] / row['path']
        delivered = stage / row['subtree'] / row['path']
        before, after = original.read_bytes(), delivered.read_bytes()
        if sha(original) != row['original_measured_sha256'] or sha(delivered) != row['delivered_sha256']:
            raise ValueError('Transformation mapping differs: ' + row['path'])
        if checker['compare_elf'](before, after) != row['elf_comparison']:
            raise ValueError('Recomputed ELF proof differs: ' + row['path'])
        if not has_symbol_table(before) or not has_symbol_table(after):
            raise ValueError('Regular symbol table was not retained: ' + row['path'])
    result = {
        'complete': True, 'producer_manifest_entries_unchanged': original_entries,
        'non_delivery_staged_entries_unchanged': unchanged,
        'binary_mappings_and_runtime_elf_proofs_rechecked': len(transform['binaries']),
        'regular_symbol_tables_retained': len(transform['binaries']),
        'test_sources_assertions_raw_results_or_native_inputs_changed': False,
        'functional_replay_status': 'Root-owned; still required after this static step',
    }
    (base / 'post_transform_verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
