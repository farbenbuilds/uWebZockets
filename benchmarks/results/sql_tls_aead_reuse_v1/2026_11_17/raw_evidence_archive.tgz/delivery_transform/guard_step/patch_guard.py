#!/usr/bin/env python3
"""Tighten only the delivered replay output boundary and retain its proof."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def invoke(script, helper, output, directory):
    command = [sys.executable, '-B', str(script), '--pki-tool', str(helper),
               '--output', str(output)]
    existed_before = output.exists() or output.is_symlink()
    result = subprocess.run(command, cwd=directory, capture_output=True,
                            text=True, timeout=15)
    exists_after = output.exists() or output.is_symlink()
    return {'command': command, 'exit_code': result.returncode,
            'stdout': result.stdout, 'stderr': result.stderr,
            'output_exists_after': exists_after,
            'output_existed_before': existed_before,
            'new_output_created': exists_after and not existed_before}


def require_refusal(row, expected_text, absent_output=True):
    if row['exit_code'] != 1 or expected_text not in row['stderr']:
        raise ValueError('Wrong early refusal: ' + str(row['command']))
    if absent_output and row['output_exists_after']:
        raise ValueError('Refusal created its output directory')


def main():
    stage = Path('/tmp/uwz-sql-tls-aead-evidence-20261117')
    transform = stage / 'delivery_transform'
    step = transform / 'guard_step'
    scratch = Path(__file__).resolve().parent / 'guard_checks'
    if step.exists() or scratch.exists():
        raise ValueError('Guard records and scratch must be absent')
    helper = Path('/tmp/uwz-wt-upstream-backport-client-20261117/client/wt-tools')
    expected_helper = '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9'
    if digest(helper) != expected_helper:
        raise ValueError('Use the exact valid PKI helper for guard checks')
    step.mkdir()
    scratch.mkdir()
    marked = scratch / 'baseline_marked'
    (marked / 'native').mkdir(parents=True)
    (marked / 'restore_pki_tool.py').write_text('baseline marker\n')
    (marked / 'native/HANDOFF.md').write_text('baseline marker\n')
    originals = {}
    identities = {}
    before_manifests = {}
    baseline_checks = []
    for name in ('helper', 'wire'):
        script = stage / name / 'replay_prebuilt.py'
        originals[name] = script.read_text()
        producer = Path('/tmp/uwz-pg-tls-aead-' + ('verify' if name == 'helper' else 'wire') + '-20261117')
        if script.read_bytes() != (producer / 'replay_prebuilt.py').read_bytes():
            raise ValueError('Guard input differs from original producer')
        identities[name] = digest(stage / name / 'prebuilt_identity.json')
        before_manifests[name] = (stage / name / 'files.sha256').read_text()
        (step / ('original_' + name + '_replay_prebuilt.py')).write_text(originals[name])
        (step / ('before_' + name + '_files.sha256')).write_text(before_manifests[name])
        copy = marked / name / 'replay_prebuilt.py'
        copy.parent.mkdir()
        copy.write_text(originals[name])
        output = marked / ('baseline_' + name + '_combined_child')
        row = invoke(copy, helper, output, scratch)
        row['case'] = name + '/baseline_combined_root_gap'
        require_refusal(row, 'FileNotFoundError')
        if 'prebuilt_identity.json' not in row['stderr'] or 'ValueError: Keep' in row['stderr']:
            raise ValueError('Baseline did not demonstrate the bounded guard gap')
        baseline_checks.append(row)
    insertion = (
        '    evidence_root = base\n'
        "    if ((base.parent / 'restore_pki_tool.py').is_file() and\n"
        "            (base.parent / 'native/HANDOFF.md').is_file()):\n"
        '        evidence_root = base.parent\n'
    )
    wrappers = []
    patches = []
    for name in ('helper', 'wire'):
        before = originals[name]
        anchor = '    base = Path(__file__).resolve().parent\n'
        guard = '    if output.resolve().is_relative_to(base):\n'
        if before.count(anchor) != 1 or before.count(guard) != 1:
            raise ValueError('Unexpected replay guard spelling')
        after = before.replace(anchor, anchor + insertion, 1).replace(
            guard, '    if output.resolve().is_relative_to(evidence_root):\n', 1)
        compile(after, str(stage / name / 'replay_prebuilt.py'), 'exec')
        (stage / name / 'replay_prebuilt.py').write_text(after)
        wrappers.append({
            'path': name + '/replay_prebuilt.py',
            'before_sha256': hashlib.sha256(before.encode()).hexdigest(),
            'after_sha256': hashlib.sha256(after.encode()).hexdigest(),
        })
        patches.extend(difflib.unified_diff(before.splitlines(keepends=True),
            after.splitlines(keepends=True), fromfile='a/' + name + '/replay_prebuilt.py',
            tofile='b/' + name + '/replay_prebuilt.py'))
    (step / 'guard.patch').write_text(''.join(patches))
    checks = []
    existing = scratch / 'existing_output'
    existing.mkdir()
    (existing / 'sentinel').write_text('unchanged\n')
    wrong = scratch / 'wrong_helper'
    wrong.write_text('not the PKI helper\n')
    symlink = scratch / 'existing_symlink'
    symlink.symlink_to(scratch / 'missing_target')
    for name, other in (('helper', 'wire'), ('wire', 'helper')):
        script = stage / name / 'replay_prebuilt.py'
        for label, output in (
            ('combined_child', stage / ('guard_probe_' + name + '_combined')),
            ('other_subtree_child', stage / other / ('guard_probe_' + name + '_sibling')),
            ('own_subtree_child', stage / name / ('guard_probe_' + name + '_own')),
        ):
            if output.exists() or output.is_symlink():
                raise ValueError('Guard probe output must be absent')
            row = invoke(script, helper, output, scratch)
            row['case'] = name + '/' + label
            require_refusal(row, 'ValueError: Keep')
            checks.append(row)
        row = invoke(script, helper, existing, scratch)
        row['case'] = name + '/existing_output'
        require_refusal(row, 'ValueError: Choose an absent', False)
        checks.append(row)
        row = invoke(script, helper, symlink, scratch)
        row['case'] = name + '/existing_symlink'
        require_refusal(row, 'ValueError: Choose an absent', False)
        checks.append(row)
        row = invoke(script, wrong, scratch / (name + '_wrong_helper_output'), scratch)
        row['case'] = name + '/wrong_helper'
        require_refusal(row, 'checksum differs')
        checks.append(row)
        standalone = scratch / ('standalone_' + name) / 'producer'
        standalone.mkdir(parents=True)
        standalone_script = standalone / 'replay_prebuilt.py'
        shutil.copy2(script, standalone_script)
        row = invoke(standalone_script, helper, standalone / 'guard_probe', scratch)
        row['case'] = name + '/standalone_own_tree'
        require_refusal(row, 'ValueError: Keep')
        checks.append(row)
        row = invoke(standalone_script, helper, standalone.parent / 'external_probe', scratch)
        row['case'] = name + '/standalone_external_passes_guard'
        require_refusal(row, 'FileNotFoundError')
        if 'prebuilt_identity.json' not in row['stderr'] or 'ValueError: Keep' in row['stderr']:
            raise ValueError('Standalone fallback incorrectly rejected an external path')
        checks.append(row)
    if (existing / 'sentinel').read_text() != 'unchanged\n':
        raise ValueError('Existing output contents changed')
    if list(scratch.rglob('private_pki')):
        raise ValueError('Guard checks created private PKI')
    submanifests = {}
    for name in ('helper', 'wire'):
        if digest(stage / name / 'prebuilt_identity.json') != identities[name]:
            raise ValueError('Binary delivery identities changed')
        old_lines = before_manifests[name].splitlines()
        changed_names = []
        new_lines = []
        for line in old_lines:
            old_sha, relative = line.split('  ', 1)
            new_sha = digest(stage / name / relative)
            if new_sha != old_sha:
                changed_names.append(relative)
            new_lines.append(new_sha + '  ' + relative + '\n')
        if changed_names != ['replay_prebuilt.py']:
            raise ValueError('Guard step changed an unauthorized file: ' + name)
        (stage / name / 'files.sha256').write_text(''.join(new_lines))
        submanifests[name] = {
            'before_sha256': hashlib.sha256(before_manifests[name].encode()).hexdigest(),
            'after_sha256': digest(stage / name / 'files.sha256'),
            'only_changed_entry': 'replay_prebuilt.py',
        }
    manifest = {
        'complete': True, 'delivery_step': 2,
        'scope': 'combined evidence output-boundary guard only',
        'combined_root_markers': ['restore_pki_tool.py', 'native/HANDOFF.md'],
        'standalone_fallback': 'resolved script parent',
        'wrappers': wrappers, 'submanifests': submanifests,
        'valid_pki_helper': str(helper), 'valid_pki_helper_sha256': expected_helper,
        'baseline_red_checks': baseline_checks, 'final_early_checks': checks,
        'private_pki_created': False, 'functional_matrices_executed': False,
        'native_or_measurement_fixture_sources_changed': False,
        'delivery_wrapper_sources_changed': 2,
        'measurement_results_binaries_or_delivery_identity_maps_changed': False,
        'happy_path_replays': 'Root-owned and required after this guard step',
    }
    (step / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    shutil.copy2(Path(__file__).resolve(), step / 'patch_guard.py')
    print(json.dumps({'baseline_red_checks': len(baseline_checks),
        'final_early_checks': len(checks), 'only_two_wrapper_guards_changed': True,
        'private_pki_created': False, 'functional_matrices_executed': False}, indent=2))


if __name__ == '__main__':
    main()
