# Delivery-only debug stripping

The measured programs were built in Debug with Zig 0.16.0. Their native code,
source fixtures, assertions, optimization settings, raw results and measured
binary identities remain unchanged in the producer evidence. The delivery
copies of eighteen executables have nonallocated debug sections removed to
keep the single compressed evidence archive small enough for normal Git.

`manifest.json` maps every original measured SHA-256/size to its delivered
SHA-256/size and records the exact command and ELF comparison. The original
`prebuilt_identity.json` files and original subtree checksum manifests are
retained here as `original_helper_*` and `original_wire_*`. Current
`helper/prebuilt_identity.json`, `wire/prebuilt_identity.json` and their
`files.sha256` manifests identify the actual stripped delivery copies. Other
build/provenance/result records and the producer handoffs describe the original
measured Debug artifacts; do not interpret those historical hashes as the
current delivery hashes.

The pinned Zig `objcopy --strip-debug` operation was attempted but returned
`error: unimplemented`. Its ELF-to-ELF implementation unconditionally rejects
the operation at `lib/compiler/objcopy.zig:207`. Root approved the existing
GNU objcopy 2.46 executable as a packaging-only fallback. Its path, complete
version output and executable checksum are recorded. No tool was installed.
This does not add a native compilation, linking, source-replay or project build
dependency. Prebuilt replay needs neither objcopy nor a compiler.

Each delivery copy preserves the entrypoint, ELF ABI identity and every program
header exactly. Every allocated section retains its type, flags, address, size,
alignment, linked-section meaning and payload. Every PT_LOAD byte range matches
after normalizing only the ELF header fields `e_shoff`, `e_shnum` and
`e_shstrndx`, which locate/count the changed nonallocated section table. Debug
sections are removed; the regular symbol table remains present. This is not
an identical-file-byte claim. It is not an optimization or relink.

To regenerate delivery copies from an original Debug inventory, use the exact
recorded command shape:

```sh
/usr/bin/objcopy --strip-debug ORIGINAL_DEBUG_EXECUTABLE NEW_DELIVERY_EXECUTABLE
```

Require the original input identity, preserve executable permissions and compare
the ELF properties before replacing any delivery copy. `strip_delivery.py`
records the actual one-time staging operation, including its explicit original
staging/scratch roots and refusal of existing transformation outputs. For a
new staging namespace, adapt only those explicit roots after producing fresh
original inputs; do not rerun it against the already stripped delivery tree.
Source rebuilds may have path-dependent Debug hashes; record their own measured
identities rather than requiring the old measured hash on another path.

`post_transform_verification.json` verifies that all original producer hashes
still match, all non-delivery staged files retain their original checksums,
all delivered identities/submanifests match, and all regular symbol tables
remain present. Root owns the complete helper and wire replay after this
transformation; static equivalence does not substitute for that replay.
