# Delivery-only debug stripping

The measured programs were built in Debug with Zig 0.16.0. Their native code,
source fixtures, assertions, optimization settings, raw results and measured
binary identities remain unchanged in the producer evidence. The delivery
copies of eighteen executables have nonallocated debug sections removed to
keep the single compressed evidence archive small enough for normal Git.

`manifest.json` maps every original measured SHA-256/size to its delivered
SHA-256/size and records the exact command and ELF comparison. The original
`prebuilt_identity.json` files and original subtree checksum manifests are
retained here as `original_helper_*` and `original_wire_*`. Current
`helper/prebuilt_identity.json`, `wire/prebuilt_identity.json` and their
`files.sha256` manifests identify the actual stripped delivery copies. Other
build/provenance/result records and the producer handoffs describe the original
measured Debug artifacts; do not interpret those historical hashes as the
current delivery hashes.

The pinned Zig `objcopy --strip-debug` operation was attempted but returned
`error: unimplemented`. Its ELF-to-ELF implementation unconditionally rejects
the operation at `lib/compiler/objcopy.zig:207`. Root approved the existing
GNU objcopy 2.46 executable as a packaging-only fallback. Its path, complete
version output and executable checksum are recorded. No tool was installed.
This does not add a native compilation, linking, source-replay or project build
dependency. Prebuilt replay needs neither objcopy nor a compiler.

Each delivery copy preserves the entrypoint, ELF ABI identity and every program
header exactly. Every allocated section retains its type, flags, address, size,
alignment, linked-section meaning and payload. Every PT_LOAD byte range matches
after normalizing only the ELF header fields `e_shoff`, `e_shnum` and
`e_shstrndx`, which locate/count the changed nonallocated section table. Debug
sections are removed; the regular symbol table remains present. This is not
an identical-file-byte claim. It is not an optimization or relink.

To regenerate delivery copies from an original Debug inventory, use the exact
recorded command shape:

```sh
/usr/bin/objcopy --strip-debug ORIGINAL_DEBUG_EXECUTABLE NEW_DELIVERY_EXECUTABLE
```

Require the original input identity, preserve executable permissions and compare
the ELF properties before replacing any delivery copy. `strip_delivery.py`
records the actual one-time staging operation, including its explicit original
staging/scratch roots and refusal of existing transformation outputs. For a
new staging namespace, adapt only those explicit roots after producing fresh
original inputs; do not rerun it against the already stripped delivery tree.
Source rebuilds may have path-dependent Debug hashes; record their own measured
identities rather than requiring the old measured hash on another path.

At the end of the binary-only strip phase, `post_transform_verification.json`
recorded all 727 original producer entries unchanged, 707 non-delivery staged
entries unchanged and all eighteen regular symbol tables retained. That report
and `verify_delivery.py` preserve the historical strip-only phase. They predate
the two delivery-wrapper guard changes below. Use
`composite_final_verification.py` and its result for the current delivery tree.

## Second delivery step: combined-root output guards

Independent review found that each replay wrapper originally excluded only its
own subtree, while the combined artifact contract excludes the entire extracted
evidence root. The two delivered `replay_prebuilt.py` files now detect the
canonical parent markers `restore_pki_tool.py` and `native/HANDOFF.md`; that
parent is the exclusion root. Without both markers, standalone producers retain
their own resolved script-parent exclusion. Existing output/symlink checks and
error messages remain intact. The boundary check runs before output creation,
PKI generation and binary work.

`guard_step/manifest.json` records exact original/patched wrapper hashes and
`guard_step/guard.patch` records the minimal change. The original wrappers and
pre-guard subtree manifests are preserved there. Two isolated pre-fix probes
show the missing combined-root rejection without running a native helper.
Sixteen final early checks cover combined-root, sibling-subtree, own-tree,
existing-output, symlink, wrong-helper and standalone behavior. Guard tests use
the exact valid PKI helper so argument/hash errors cannot mask exclusions;
wrong-helper checks are explicitly separate. No outputs or private PKI were
created, and no functional matrix ran during those negative checks.

The composite final proof permits precisely the eighteen stripped executables,
their two delivery identity maps and these two guard wrappers relative to the
original producer manifests. All 727 producer entries still match and the
other 705 staged entries remain byte-identical. Binary identities, native and
measurement-fixture sources, measurement assertions, raw results and build
inputs are unchanged by the guard step. Root owns both complete happy-path
replays after the final guard
change; static and refusal checks do not substitute for those replays.
