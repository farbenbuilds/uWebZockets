# Recycled client KeyUpdate contexts

Reserve one inactive AEAD context during startup for a completed idle ordinary
TLS 1.3 client. The bounded set is active RX, active TX and one spare. Capture
the supported negotiated cipher, own the spare in SSL3_STATE, and identify a
borrowed candidate explicitly. No unavailable/inconsistent-spare heap fallback.

Prepare and initialize the inactive object with unchanged HKDF/AEAD primitives.
Preserve the read excess-data guard and old-key write sealing before swapping.
Commit the corresponding traffic secret only after hook success. Recycle and
cleanse the retired active object on success; recover/cleanse the candidate on
initializer or hook failure. Preserve existing alert/flight/consumption effects,
not whole-operation rollback. Cleanup alone does not wipe inline AEAD state;
reset explicitly erases old key/IV/nonce state and every mode flag. Touched local
key, IV and derived-secret copies use the existing native cleanup primitive.

The opt-in is serialized and forbids recursive mutating SSL I/O from callbacks.
Observation callbacks may run while the candidate is borrowed. SSL_clear frees
and disables the reservation. Unsupported roles/protocols/handshake/error/
shutdown/pending states reject without activating it.

Verification uses actual public singleton TLS1.3 cipher selection for
0x1301/0x1302/0x1303. Baseline RED precedes native changes; unchanged whole-client
call accounting becomes GREEN for valid no-response updates. Direct crypto,
separate injected failures, ownership/nonce/cleansing and lifecycle proofs stay
distinct from actual encrypted protocol comparisons and public controls.

Independent review binds the six-file final delta after removing an unused
forwarding predicate. Earlier source/test versions remain explicitly preliminary.
Root owns complete source restoration, copied-layout replay, artifact integrity
and ordinary project checks. Ticket/session, response-flight and error/reconnect
storage, maintenance and production adoption remain open. No PostgreSQL
exception, production pin change or full allocation-gate closure is claimed.
