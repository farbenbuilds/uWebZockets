#!/usr/bin/env python3
"""Reconcile the three-suite KeyUpdate protocol and ownership observations."""
import argparse
import csv
import json
from pathlib import Path

SCENARIOS = ('requested_chain', 'coalesced_requests', 'excess_old_epoch', 'consecutive_limit')
SUITES = (0x1301, 0x1302, 0x1303)
FIELDS = ('malloc', 'calloc', 'realloc', 'free', 'bytes')


def verify(directory):
    rows = [json.loads(line) for line in (directory / 'summary.jsonl').read_text().splitlines()]
    operations = list(csv.DictReader((directory / 'operations.csv').open()))
    assert [(row['suite'], row['scenario']) for row in rows] == [(suite, name) for suite in SUITES for name in SCENARIOS]
    checked = 0
    for row in rows:
        suite = row['suite']
        scenario = row['scenario']
        cipher_name = 'aes_128_gcm' if suite == 0x1301 else 'aes_256_gcm' if suite == 0x1302 else 'chacha20_poly1305'
        name = cipher_name + '_' + scenario
        selected = [op for op in operations if op['scenario'] == name]
        reads = [op for op in selected if op['phase'] != 'response_write']
        writes = [op for op in selected if op['phase'] == 'response_write']
        assert row['tls13_verified'] and row['hostname_verified']
        assert row['client_negotiated_suite'] == row['server_negotiated_suite'] == suite
        for subset, prefix in [(reads, 'read'), (writes, 'write')]:
            assert len(subset) == row[prefix + '_operations']
            assert sum(int(op['result']) <= 0 for op in subset) == row[prefix + '_retries']
            assert {field: sum(int(op[field]) for op in subset) for field in FIELDS} == row['client_' + prefix]
            assert all(int(op[field]) >= 0 for op in subset for field in FIELDS)
        assert sum(max(int(op['result']), 0) for op in reads) == row['payload_bytes_each_direction']
        assert sum(max(int(op['result']), 0) for op in writes) == row['payload_bytes_each_direction']
        assert row['payloads_exact'] is True
        assert all(int(op['error']) in (0, 1, 2, 3) for op in selected)
        if scenario == 'requested_chain':
            assert row['completed_updates'] == 8
            assert row['payload_bytes_each_direction'] == 32768
            assert row['client_received_key_updates'] == row['client_sent_key_updates'] == row['server_received_key_updates'] == 8
            assert row['old_key_sealing_headers'] == 8
            assert row['terminal_error'] == row['terminal_reason'] == 0
            if row['reserved']:
                assert row['pool_trace'] == [[2, 0, 1], [1, 2, 0], [0, 1, 2], [2, 0, 1], [1, 2, 0], [0, 1, 2], [2, 0, 1], [1, 2, 0]]
        elif scenario == 'coalesced_requests':
            assert row['completed_updates'] == 2
            assert row['payload_bytes_each_direction'] == 4096
            assert row['client_received_key_updates'] == 2
            assert row['client_sent_key_updates'] == row['server_received_key_updates'] == 1
            assert row['old_key_sealing_headers'] == 1
            assert row['terminal_error'] == row['terminal_reason'] == 0
            if row['reserved']: assert row['pool_trace'] == [[1, 0, 2]]
        elif scenario == 'excess_old_epoch':
            assert row['completed_updates'] == 0 and row['payload_bytes_each_direction'] == 0
            assert row['client_received_key_updates'] == 1
            assert row['client_sent_key_updates'] == row['server_received_key_updates'] == 0
            assert row['read_hook_state_preserved'] is True
            assert row['spare_recovered_clean'] == row['reserved']
            assert row['terminal_error'] == 1 and row['terminal_reason'] != 0
        else:
            assert row['completed_updates'] == 32 and row['payload_bytes_each_direction'] == 0
            assert row['client_received_key_updates'] == 33
            assert row['client_sent_key_updates'] == row['server_received_key_updates'] == 0
            assert row['terminal_error'] == 1 and row['terminal_reason'] != 0
        assert row['borrowed_candidate_headers'] == (row['old_key_sealing_headers'] if row['reserved'] else 0)
        if not row['reserved']: assert all(ids == [-1, -1, -1] for ids in row['pool_trace'])
        checked += len(selected)
    assert checked == len(operations)
    return {'rows_verified': len(rows), 'operations_verified': checked,
        'all_three_actual_negotiated_suites': True,
        'requested_old_key_ordering_observed': True,
        'active_read_secret_preserved_on_actual_old_epoch_failure': True,
        'three_context_identity_recycling_checked_when_reserved': True,
        'client_private_observations_read_only': True,
        'fatal_protocol_rows_per_suite': 2,
        'strict_postgresql_gate_closed': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.directory), indent=2))


if __name__ == '__main__': main()
