#!/usr/bin/env python3
"""Replay exact KeyUpdate gates, protocol cases and controls without native archives."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pki-tool', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    evidence_root = base
    if ((base.parent / 'restore_pki_tool.py').is_file() and
            (base.parent / 'native/HANDOFF.md').is_file()):
        evidence_root = base.parent
    output = args.output.absolute()
    helper = args.pki_tool.resolve(strict=True)
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    if output.resolve().is_relative_to(evidence_root):
        raise ValueError('Keep output outside retained evidence')
    if digest(helper) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('The retained PKI helper checksum differs')
    expected = {'baseline/key_update_witness', 'candidate/key_update_witness',
        'candidate_unreserved/key_update_witness', 'baseline_protocol/protocol_witness',
        'candidate_protocol/protocol_witness', 'candidate_unreserved_protocol/protocol_witness',
        'baseline_controls/control_witness', 'candidate_controls/control_witness'}
    identity = json.loads((base/'prebuilt_identity.json').read_text())
    if set(identity['binaries']) != expected:
        raise ValueError('Unexpected retained binary inventory')
    for name, checksum in identity['binaries'].items():
        if digest(base/name) != checksum:
            raise ValueError('Retained executable checksum differs: '+name)
    output.mkdir(parents=True, mode=0o700)
    commands = []
    pki = output/'private_pki'
    complete = False

    def run(command, name, expected_status=0):
        with (output/(name+'.stdout')).open('wb') as out,(output/(name+'.stderr')).open('wb') as err:
            result = subprocess.run(command,cwd=output,stdout=out,stderr=err)
        commands.append({'command':command,'exit_code':result.returncode,'expected_exit_code':expected_status})
        if result.returncode != expected_status:
            raise RuntimeError('Unexpected command status: '+name)

    def compare_files(directory,names):
        for name in names:
            if (output/directory/name).read_bytes() != (base/directory/name).read_bytes():
                raise ValueError('Replay bytes differ: '+directory+'/'+name)

    try:
        run([str(helper),'pki',str(pki)],'pki_metadata')
        arguments = [str(pki/name) for name in ['server.pem','server.key','ca.pem']]
        for name in ['baseline','candidate','candidate_unreserved']:
            target=output/name
            target.mkdir()
            run([str(base/name/'key_update_witness'),*arguments,
                str(target/'observe_operations.csv'),str(target/'observe_summary.jsonl'),
                '--require-zero'],name,0 if name=='candidate' else 1)
            compare_files(name,['observe_operations.csv','observe_summary.jsonl'])
        for name in ['baseline_protocol','candidate_protocol','candidate_unreserved_protocol',
                     'baseline_controls','candidate_controls']:
            target=output/name
            target.mkdir()
            control=name.endswith('controls')
            binary='control_witness' if control else 'protocol_witness'
            run([str(base/name/binary),*arguments,str(target/'operations.csv'),
                str(target/'summary.jsonl')],name)
            verifier='verify_controls.py' if control else 'verify_protocol.py'
            command=[sys.executable,str(base/verifier),str(target)]
            if control:
                command.extend(['--operations','operations.csv','--summary','summary.jsonl'])
                if name=='candidate_controls':command.append('--key-update-reserved')
            run(command,name+'_verification')
            compare_files(name,['operations.csv','summary.jsonl'])
        run([sys.executable,str(base/'compare_results.py'),str(output)],'comparison')
        complete=True
    finally:
        if pki.exists():
            names={path.name for path in pki.iterdir()}
            if names-{'ca.pem','server.pem','server.key'}:
                raise ValueError('Unexpected PKI output; refusing broad cleanup')
            for name in names:(pki/name).unlink()
            pki.rmdir()
        (output/'results.json').write_text(json.dumps({
            'complete':complete,'commands':commands,'private_pki_removed':not pki.exists(),
            'requires_compiler_native_archives_or_source':False,
            'strict_postgresql_gate_closed':False},indent=2)+'\n')
    print('PASS: baseline RED, reserved GREEN and unreserved RED across all suites; protocol/control bytes match; private PKI removed')


if __name__=='__main__':main()
