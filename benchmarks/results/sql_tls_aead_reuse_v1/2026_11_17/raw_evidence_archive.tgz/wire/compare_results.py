#!/usr/bin/env python3
"""Check KeyUpdate allocation, protocol and control equivalence from retained rows."""
import argparse
import csv
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
from verify_protocol import verify as verify_protocol
from verify_controls import verify as verify_controls

COUNTERS = {'malloc', 'calloc', 'realloc', 'free', 'bytes'}


def load_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def operation_equality(left, right, excluded=COUNTERS):
    a = list(csv.DictReader(left.open()))
    b = list(csv.DictReader(right.open()))
    assert len(a) == len(b)
    assert [{key:value for key,value in row.items() if key not in excluded} for row in a] == [
        {key:value for key,value in row.items() if key not in excluded} for row in b]
    return len(a)


def key_comparison(root):
    baseline = load_rows(root/'baseline/observe_summary.jsonl')
    candidate = load_rows(root/'candidate/observe_summary.jsonl')
    unreserved = load_rows(root/'candidate_unreserved/observe_summary.jsonl')
    assert len(baseline) == len(candidate) == len(unreserved) == 24
    excluded = {'reserved', 'client_read', 'client_write'}
    for before, after, generic in zip(baseline, candidate, unreserved):
        assert before == generic
        assert {key:value for key,value in before.items() if key not in excluded} == {
            key:value for key,value in after.items() if key not in excluded}
        assert before['client_read'] == {'malloc':1,'calloc':0,'realloc':0,'free':1,'bytes':608}
        assert all(value == 0 for phase in ['client_read','client_write'] for value in after[phase].values())
        assert after['client_negotiated_suite'] == after['server_negotiated_suite'] == after['suite']
        assert after['payloads_exact'] and after['tls13_verified'] and after['hostname_verified']
    count = operation_equality(root/'baseline/observe_operations.csv', root/'candidate/observe_operations.csv')
    assert (root/'baseline/observe_operations.csv').read_bytes() == (root/'candidate_unreserved/observe_operations.csv').read_bytes()
    return {'rows':24,'operations_per_variant':count,'actual_suites':[0x1301,0x1302,0x1303],
        'candidate_complete_client_calls_zero':True,'baseline_strict_exit':1,'candidate_strict_exit':0,
        'unreserved_strict_exit':1,'unreserved_rows_and_operation_bytes_equal':True}


def protocol_comparison(root):
    directories = [root/name for name in ['baseline_protocol','candidate_protocol','candidate_unreserved_protocol']]
    verification = [verify_protocol(path) for path in directories]
    left, right, generic = [load_rows(path/'summary.jsonl') for path in directories]
    excluded = {'reserved','client_read','client_write','borrowed_candidate_headers','pool_trace','spare_recovered_clean'}
    for before, after, unreserved in zip(left,right,generic):
        assert before == unreserved
        assert {key:value for key,value in before.items() if key not in excluded} == {
            key:value for key,value in after.items() if key not in excluded}
    count = operation_equality(directories[0]/'operations.csv',directories[1]/'operations.csv')
    assert (directories[0]/'operations.csv').read_bytes() == (directories[2]/'operations.csv').read_bytes()
    return {'rows_per_variant':12,'operations_per_variant':count,'semantic_equality':True,
        'unreserved_rows_and_operation_bytes_equal':True,'verification':verification,
        'reserved_old_key_header_observations':sum(row['borrowed_candidate_headers'] for row in right),
        'reserved_read_hook_neutral_recovery_cases':sum(row['spare_recovered_clean'] for row in right)}


def control_comparison(root):
    left = root/'baseline_controls'; right = root/'candidate_controls'
    verify_controls(left,'operations.csv','summary.jsonl')
    verify_controls(right,'operations.csv','summary.jsonl',True)
    a = load_rows(left/'summary.jsonl'); b = load_rows(right/'summary.jsonl')
    rows = []
    excluded = {'client_read','client_response_write'}
    for before,after in zip(a,b):
        assert {key:value for key,value in before.items() if key not in excluded} == {
            key:value for key,value in after.items() if key not in excluded}
        assert before['client_response_write'] == after['client_response_write']
        rows.append({'round':before['round'],'scenario':before['scenario'],
            'before':before['client_read'],'after':after['client_read'],
            'following_write':after['client_response_write']})
    count = operation_equality(left/'operations.csv',right/'operations.csv')
    return {'rows_per_variant':12,'operations_per_variant':count,'semantic_equality':True,'counts':rows}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',nargs='?',type=Path,default=Path(__file__).resolve().parent)
    args=parser.parse_args()
    result={'key_update_gate':key_comparison(args.root),
        'protocol':protocol_comparison(args.root),'public_controls':control_comparison(args.root),
        'strict_postgresql_gate_closed':False}
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
