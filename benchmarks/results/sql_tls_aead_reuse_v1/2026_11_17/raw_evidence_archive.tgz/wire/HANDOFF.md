# KeyUpdate AEAD wire verification

This is an isolated verification experiment. The native implementation belongs
to `/tmp/uwz-pg-tls-aead-fixed-20261117`; its unchanged baseline is the complete
handshake-buffer candidate. This verifier changed no native, production,
repository or protected vendor source.

## Primary RED/GREEN assertion

`key_update_witness.cc` is frozen by `baseline_frozen.json`. Both peers configure
one actual TLS 1.3 suite with successful `SSL_CTX_set1_tls13_ciphers` calls:
`0x1301`, `0x1302` and `0x1303`, passing null flags and a singleton ID array.
The negotiated suite is checked on both completed, CA/localhost-verified peers.
A legacy cipher list is not used to infer suite selection.

Each suite receives eight peer NOT_REQUESTED KeyUpdates, with exact 4096-byte
application payloads in both directions after every update. Each run therefore
contains 24 updates and 600 complete client SSL read/write calls, including
immediate `SSL_get_error`. Peer preparation, payload checking and logging remain
outside accounting. Existing record and incoming-handshake storage are reserved
before accounting; the new optional context reservation also runs at startup.

The same assertion gives:

| Native variant | Per-update client read | Client app write | Strict exit |
| --- | --- | --- | --- |
| Prior handshake-buffer candidate | 1 malloc, 1 free, 608 bytes | zero | 1 |
| New candidate, unreserved | 1 malloc, 1 free, 608 bytes | zero | 1 |
| New candidate, reserved | zero allocator operations | zero | 0 |

All 24 successful reserved updates count zero malloc, calloc, realloc, free and
requested bytes. Observe and strict runs complete all payloads and produce
identical operation/summary bytes. The baseline was recorded before native
implementation started. The original all-C allocator interposer and its
63-byte self-test are unchanged. No allocation assertion was suppressed.

## Protocol, ownership and callback evidence

`protocol_witness.cc` has four cases for each of the three explicitly negotiated
suites, totaling twelve rows and 783 measured client calls per variant. All
protocol outcomes, payloads, update callbacks and operation result/error
sequences match baseline, new-unreserved and new-reserved variants. Unreserved
summary and operation bytes, including allocation counts, equal baseline.

- Eight requested-response cycles per suite transfer exact data both ways.
  During 27 outgoing record-header callbacks across requested/coalesced cases,
  the old active write context remains installed while the prepared candidate
  is distinct and borrowed: the spare owner is null. The observer performs no
  nested I/O or mutation. Successful peer decryption verifies the KeyUpdate
  record precedes application records under the new key.
- Relative object identities show the same three objects rotate through active
  RX, active TX and spare roles. Every idle inspection checks distinct ownership,
  an unborrowed spare and its neutral structural predicate.
- Two requested updates before the client application write coalesce to one
  NOT_REQUESTED response. Both incoming updates and the response are observed,
  and subsequent bidirectional payloads validate the resulting keys.
- A genuine encrypted old-key record contains a KeyUpdate followed by another
  handshake message. Native server `tls_seal_record` and real BIO delivery are
  used; no client parser state is staged. The incoming message callback captures
  the active RX object, full object bytes, traffic secret and read sequence
  after record decryption but before key preparation. The read-state hook rejects
  trailing old-epoch data with `EXCESS_HANDSHAKE_DATA`, preserving those captured
  values. The same borrowed spare returns byte-identical to its pre-prepare
  neutral representation. Temporary key snapshots are cleansed and never logged.
  Record consumption, alert generation and error-state side effects are allowed.
- Thirty-two consecutive peer KeyUpdates without application data succeed; the
  thirty-third receives the same fatal limit error in all variants. Callback
  visibility is not mistaken for semantic acceptance of that final update.

BIO capacity is 1024 bytes and application reads use at most 257 bytes, exercising
real short writes and retries. KeyUpdate callback validation checks the complete
five-byte message shape and mode. The only private client access is read-only
ownership/state observation; the old-epoch peer construction is explicitly
internal native test machinery rather than a public API interoperability claim.

## Existing public control witness

The previous public control source is copied with only the new startup option
added; `control_startup_delta.patch` records the actual source adjustment.
The incoming-handshake reservation is enabled in both variants. Each has twelve
rows and 255 complete client calls. Stable read counts are:

| Scenario | Prior malloc/free/bytes | New reserved malloc/free/bytes |
| --- | --- | --- |
| Ticket-free payload | 0/0/0 | 0/0/0 |
| Two initially queued tickets, caching off | 12/12/1600 | 12/12/1600 |
| Peer KeyUpdate, no response requested | 1/1/608 | 0/0/0 |
| Peer KeyUpdate, response requested | 7/5/1416 | 5/3/200 |

The following client response/application write remains zero malloc/two frees.
All calloc/realloc counts are zero. The copied control verifier retains its
legacy assertions and explicitly strengthens the reserved no-response row to
require zero allocator operations; its source delta is retained. Initially
queued tickets are not arbitrary later tickets, and these TLS/BIO call counts
are not PostgreSQL query measurements.

## Retained identity and replay

Final source/library identities are recorded in every build's provenance. The
initial native build containing an unused forwarding predicate is labeled
`preliminary_native_build/`; its duplicate binaries are omitted. The first
successful protocol proof, superseded by the additional same-spare neutral-byte
check, is labeled `preliminary_protocol_guard/`; all row/operation bytes remain
identical and duplicate binaries are omitted.

The prebuilt replay checks eight exact Linux x86-64 executable identities, then
repeats all strict gates, protocol cases and controls using a fresh owned PKI:

```sh
python3 replay_prebuilt.py --pki-tool /absolute/path/to/wt-tools --output /tmp/uwz-aead-wire-new-replay
```

The output must be absent and outside this retained evidence directory. The PKI
helper checksum is pinned to the prior retained helper. All operation/summary
bytes must equal the frozen results, including expected baseline/unreserved
strict exits 1 and candidate strict exit 0. No compiler, native archive, native
source or network is required. Owned private PKI is removed in a finally block.
`replay_validation/` records the successful full replay; three early refusal
checks are in `replay_refusals.json`.

Offline comparison:

```sh
python3 compare_results.py
```

Source runners are `run_key_updates.py NATIVE_ROOT PKI_HELPER NEW_OUTPUT`
(with `--reserved` for the new profile), and `build_run.py` with
`--fixture protocol` or `--fixture control`, plus `--reserved` as appropriate.
They use exact Zig 0.16 Debug and complete matching native libraries, record
all commands/statuses and actual archive hashes, and refuse existing outputs.
Debug archive hashes are provenance, not portable rebuild-byte requirements.
Python is external evidence tooling, not a new library build dependency.

No private keys, certificates, native archives or duplicate preliminary binaries
are in the payload. Other ticket/session, response-flight and error allocations
remain. The strict PostgreSQL request-path allocation gate and production native
integration stay open. Dedicated smoke/security/sanitizer/fuzz/scan campaigns
were not run; no FIPS validation or release completion is claimed.
