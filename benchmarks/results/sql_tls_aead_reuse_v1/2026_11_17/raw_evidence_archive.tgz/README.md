# Recycled client KeyUpdate evidence

This isolated native proposal reserves one inactive AEAD context during startup.
The bounded set is active RX, active TX and one spare; successful install swaps
and cleanses the retired object, while failed initialization/install recovers
the neutral candidate. No unavailable-spare allocation fallback exists.
Mutating SSL I/O is serialized and non-reentrant; observation callbacks remain
usable while the spare is borrowed. Production pins and the full PostgreSQL
allocation gate remain unchanged.

After fresh extraction, verify and replay from this directory:

```sh
sha256sum -c files.sha256
python3 restore_pki_tool.py /absolute/path/to/uWebZockets
python3 helper/replay_prebuilt.py --pki-tool tools/wt-tools --output /tmp/uwz-aead-helper-final-replay
python3 wire/replay_prebuilt.py --pki-tool tools/wt-tools --output /tmp/uwz-aead-wire-final-replay
```

Choose absent external replay directories. The checksum-pinned PKI executable
comes from the existing repository artifact; no network, compiler, native
archives or objcopy is needed. Replays verify current delivery identities,
require baseline/unreserved RED and reserved GREEN, compare exact outcomes and
remove owned private PKI. Root's successful copied-layout replays are retained
under root_checks/helper_delivery_replay and root_checks/wire_delivery_replay.

Measured code is Zig Debug. Eighteen delivery executable copies have debug
information removed with the recorded existing GNU objcopy 2.46, after the
pinned Zig objcopy reported unimplemented ELF output. Native compilation and
linking, native/test-fixture source, functional assertions and raw results remain unchanged. Original measured
hashes are preserved; current prebuilt maps identify delivered bytes.
delivery_transform/HANDOFF.md and manifest.json explain both identity sets,
exact commands and allocated-section/normalized-load equivalence. Both complete
replays pass after this step. The delivery wrappers additionally exclude the entire combined evidence root from output paths, retaining own-tree exclusion for standalone use. This guard step is recorded separately; original producer wrappers remain preserved. No project build dependency was added.

Primary actual peer proof: 24 no-response updates across all 3 negotiated suites,
600 client calls per variant, zero reserved allocator operations. Protocol proof:
12 rows/783 calls per variant, 27 borrowed old-key header observations and exact
read-guard recovery; public controls 12 rows/255 calls per build. Direct/failure
proofs include 24 fresh/reused epochs, 12 populated initialization failures,
48 bounded transitions and 22 lifecycle cases. All inherited record/HS/HKDF
regressions pass. Read each producer HANDOFF for precise scope and original
Debug provenance; do not substitute it for current delivery hashes.

Source restoration is documented in native/HANDOFF.md. Root verifies both the
original pinned package and explicit prior-HS input against all 8709 final
entries; root_checks/source_restore_results.json records the completed proof.
The quota-interrupted attempt and fixture-only corrections are classified
preliminary; native source and thresholds were not weakened.

Root's ordinary SQL-enabled suite passed 1158 tests with 24 existing live
PostgreSQL cases skipped without required fixture settings. Dedicated smoke,
security, sanitizer, fuzz and scan campaigns remain user-deferred. Ticket/
session, requested-response flight and error/reconnect allocations remain work;
no PostgreSQL exception or FIPS certification is claimed.
