# Bounded AEAD delivery review

Reviewed the copied delivery at `/tmp/uwz-sql-tls-aead-evidence-20261117` on 2026-11-17. Read-only review; no functional matrices or deferred campaigns were repeated.

## Actionable finding

**P2: replay output exclusion protects only one producer subtree, not the combined evidence bundle.**

Locations: `helper/replay_prebuilt.py:25` and `wire/replay_prebuilt.py:25` in the copied delivery. Both set `base` to their own script directory and test `output.resolve().is_relative_to(base)`. Consequently an absent output such as `/tmp/uwz-sql-tls-aead-evidence-20261117/new-output` passes both guards, as does a new child of the sibling producer subtree. Execution then writes logs, results and temporary private PKI inside the retained bundle. This contradicts the inner/outer README requirement that output be outside the extracted evidence and the helper result's retained-evidence-unchanged claim.

Protect the combined root when running in the packaged layout, while preserving standalone producer replay, and retain a pre-write refusal check for an absent sibling/root output. No runtime reproduction was needed: the current `Path` guard evaluates false for that contained output and true when bounded against the combined root. Existing-directory, wrong-helper and own-subtree checks do not cover it.

## Other reviewed scope

No additional actionable issue found in the final native/source/prose claims or delivery transformation. Independently checked the current native/helper/wire/transform manifests (62/484/243/9 entries), original producer hashes, all 707 unchanged non-delivery staged entries, all 18 original-to-delivery ELF maps and current executable identities. The 323,309,328 to 89,836,472-byte totals agree. Allocated sections, all program headers, entrypoint/ABI and PT_LOAD bytes normalized only for the three documented section-table fields match. Regular symbol tables remain in all 18 files; the recorded GNU objcopy checksum matches. Original measured Debug provenance and current delivery identities are clearly distinguished.

The copied-layout helper and wire replay records are complete, with all 53 and 15 child commands respectively returning their expected statuses and private PKI removed. Source restoration validates both original-package and prior-HS modes against all 8,709 expected entries before recording success; existing/wrong-mode refusals and the earlier quota interruption are separately retained. The pinned PKI bootstrap reads one validated member from the validated whole archive, uses exclusive creation and refuses conflicting destinations. Restored tools and private fixture files are absent from the reviewed stage.

README/docs/tasks correctly preserve the startup-versus-request-path distinction, tracked-allocation scope, three-suite/client eligibility, serialized mutation requirement, residual ticket/response-flight allocations and open PostgreSQL gate. Original source-build Debug archive hashes are recorded provenance, not path-independent rebuild requirements. Top-level final manifest/archive/checksum assembly remains Root-owned and was outside this pre-assembly review.
