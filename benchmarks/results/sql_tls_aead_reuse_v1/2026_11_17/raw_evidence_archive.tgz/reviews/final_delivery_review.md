# Bounded AEAD delivery review

Reviewed the copied delivery at `/tmp/uwz-sql-tls-aead-evidence-20261117` on 2026-11-17, including the final bounded guard-fix re-review. Read-only review; no functional matrices or deferred campaigns were repeated.

## Result

No unresolved actionable delivery defect remains in the reviewed stage. The initial P2 is resolved; its original report remains byte-identical at `reviews/delivery_review_before_guard_fix.md` in the delivery.

## Resolved P2 history and fix

Originally `helper/replay_prebuilt.py:25` and `wire/replay_prebuilt.py:25` excluded only their own producer subtree. A new output under the combined root or sibling subtree passed that boundary, contrary to the combined artifact contract.

The delivered wrappers now detect canonical parent markers `restore_pki_tool.py` and `native/HANDOFF.md` and use that resolved parent as `evidence_root`; standalone use retains its own resolved script-directory boundary. Both check `output.resolve().is_relative_to(evidence_root)` before output creation, PKI or executable work. Existing output/symlink refusal and pinned helper/executable checks remain intact. The exact minimal patch is retained in `delivery_transform/guard_step/guard.patch`.

Independently checked the preserved original and current wrapper hashes and exact unified diff: helper changes from `bb00dc3abefeb894513f0ab65b6035ddd2e10c991e7ff56f1dbe92abfb819859` to `e486f1ba6c67868e41ffa1a7661640a9611e043b9c4c53ab5ff47f8acbcea7ed`; wire changes from `e9135595fe197c9631f2e09d4fa3244ab4ca8f8961c8a13ff2d29b956f2e44d1` to `985b0b1a2221d1b0479ed07f26aeb4e1bd2c5538fc83d3416cabf8f40e89b4e1`. Two bounded pre-fix probes reach the later missing-inventory check instead of rejecting the combined-root path. Sixteen final early checks demonstrate combined-root, sibling, own-subtree, existing-output, symlink, wrong-helper and standalone behavior without new output or private PKI. Standalone external-path probes deliberately stop at the absent inventory after passing the boundary; they are not presented as full replay success.

## Other reviewed scope

No additional actionable issue found in the final native/source/prose claims or delivery transformation. Independently checked the final native/helper/wire/transform manifests (62/484/243/20 entries), all 727 original producer entries and all 705 other unchanged staged entries. The initial strip-phase proof of 707 unchanged staged entries remains correctly labeled historical; the two authorized guard wrappers account for the difference.

The original review recomputed all 18 original-to-delivery ELF maps; final re-review confirms all delivered binary hashes are unchanged by the guard step and match those same maps. The 323,309,328 to 89,836,472-byte totals agree. Allocated sections, all program headers, entrypoint/ABI and PT_LOAD bytes normalized only for the three documented section-table fields match. Regular symbol tables remain in all 18 files; the recorded GNU objcopy checksum matches. Original measured Debug provenance and current delivery identities are clearly distinguished. The composite checker permits precisely the 18 stripped binaries, their two identity maps and two guard wrappers relative to the original producer manifests.

The final copied-layout helper and wire replay records under `root_checks/helper_final_delivery_replay` and `root_checks/wire_final_delivery_replay` are complete after both delivery steps, with all 53 and 15 child commands respectively returning their expected statuses and private PKI removed. Source restoration validates both original-package and prior-HS modes against all 8,709 expected entries before recording success; existing/wrong-mode refusals and the earlier quota interruption are separately retained. The pinned PKI bootstrap reads one validated member from the validated whole archive, uses exclusive creation and refuses conflicting destinations. Restored tools, native archives/objects and private fixture files are absent from the reviewed stage.

README/docs/tasks correctly preserve the startup-versus-request-path distinction, tracked-allocation scope, three-suite/client eligibility, serialized mutation requirement, residual ticket/response-flight allocations and open PostgreSQL gate. Updated inner/outer wording distinguishes unchanged native/test-fixture source, functional assertions and raw results from the separately strengthened delivery wrappers. Original source-build Debug archive hashes are recorded provenance, not path-independent rebuild requirements. The retained unit log matches its recorded checksum and 1,158-pass/24-live-fixture-skip claim; formatting remains 314 unchanged inputs and the completed graph update log is retained. Top-level final manifest/archive/checksum assembly remains Root-owned and was outside this pre-assembly review.
