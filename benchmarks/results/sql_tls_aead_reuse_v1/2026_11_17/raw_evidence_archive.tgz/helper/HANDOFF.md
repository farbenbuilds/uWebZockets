# Reusable TLS KeyUpdate context verification

This payload is self-relative. Native source and the complete build are owned
by `/tmp/uwz-pg-tls-aead-fixed-20261117`; every final proof uses these archives:

- libssl.a `c1d199bc40a22a6688894cdf4d16aa8e9870e82d9732e6b28e7865397a508d12`
- libcrypto.a `8ffe1c065a69222731a44b1dbc37ef20f06f7c34d7f1aabbc7cdf1d12de0d951`

The native quality cleanup removed an unused SupportsKeyUpdate wrapper before
this final build. Its allowlist is tested through InitForKeyUpdate and
IsKeyUpdateContext. Initial build/link-driver investigations are retained under
`direct/` as preliminary source/logs; their executables and intermediate objects
are excluded from the delivery allowlist. No prior result was relabeled final.

## Direct preparation and erasure

`direct_final/` contains two distinct binaries. The normal binary uses the
byte-identical original all-C counter, with its 63-byte malloc/calloc/realloc/free
self-test intact, and has no initializer wrapper. It verifies 24 epochs across
AES-128-GCM, AES-256-GCM and ChaCha20-Poly1305, both directions, four rounds.
Every reused context produces the same ciphertext or plaintext as fresh Create
for identical inputs, with sequence numbers zero and one. Reinitializing a live
context is rejected without mutation. Five invalid key/IV/cipher inputs preserve
an empty candidate; three invalid-AAD records fail authentication. All measured
reset/init/operation intervals have zero malloc/calloc/realloc/free/bytes.

The pinned x86_64 Debug context layout is extracted from Zig/Clang record-layout
output, then compared exactly against the candidate. sizeof(SSLAEADContext)=600;
full EVP_AEAD_CTX occupies bytes8..583; all 12 fixed-nonce capacity bytes occupy
584..595; nonce length, variable length and five flag bits are checked separately.
Reset zeros all those regions and clears cipher_. Byte599 and unused flag bits
are padding, so no whole-object padding-zero claim is made. No private-to-public
macro, native test accessor or fabricated parser state is used. Direct inputs
are public deterministic test vectors, not captured session secrets.

The separate injected binary wraps EVP_AEAD_CTX_init_with_direction only for
test failure cases. It calls the real initializer first and verifies populated
inline state, then forces failure with either aead=nullptr (matching the real
failure contract, whose cleanup may return early) or the live aead pointer.
All 12 combinations of suite/direction/pointer state recover the same empty
candidate with zero heap operations. This injected result is distinct from
normal successful-call counting. The Zig C++ driver's argument parser rejects
--wrap; the runner passes its ordinary driver-produced CRT/runtime arguments
and Zig-compiled objects to the bundled `zig ld.lld --wrap=...` directly.
No external linker, altered native archive or production interposer is used.

## Ownership, failure and lifecycle

`lifecycle_final/aead_transitions` is a normal, unwrapped counter binary. Real
CA/hostname-verified TLS 1.3 pairs negotiate each selected suite through the
pinned public cipher configuration API. Forty-eight direct native RX/TX key
installation transitions preserve exactly the original three distinct object
addresses, reset sequence numbers to zero and fully cleanse the reclaimed
spare, with zero measured allocation/free operations. This is direct key-helper
scope; the peer does not process those internally rotated keys. Missing-spare,
borrowed-candidate and inconsistent-spare guard fixtures are explicitly internal
ownership tests and never claim encrypted peer-protocol acceptance.

Default reservation startup observes one C malloc /608 requested bytes, consisting
of the 600-byte object and eight-byte allocation prefix. sizeof(SSL3_STATE) is
608 at the prior HS candidate and 632 here: three pointer fields add 24 bytes.
These facts are separate from handshake, record-buffer and HS-buffer startup.

`lifecycle_final/aead_lifecycle` uses the separate fixed fault/free observer and
test-only initializer wrapper. All 22 cases pass:

- Startup allocation failure preserves mode/config/state/ownership, and retry
  on the same verified SSL succeeds. Idle repeated reservation allocates nothing.
- Real pending plaintext, incomplete ciphertext and backpressured writes reject
  reservation without mutation, then continue valid payloads and reserve.
- Queued KeyUpdate, native partially flushed flight, null/unfinished, server,
  TLS 1.2, configured-only DTLS/QUIC, close_notify and saved fatal read-error
  states reject reservation. DTLS/QUIC cases are not handshake interoperability.
- SSL_clear frees the reserved object and removes the profile, then a fresh
  verified nonresumed handshake accepts a new profile and encrypted updates in
  both directions. A shared SSL_CTX does not share the per-SSL profile.
- A populated initializer failure during RX and TX key installation preserves
  installed contexts and traffic secrets, returning the same cleansed spare.
- A real public SSL_key_update reaches a post-initialization flight-storage
  malloc failure. Installed TX context/key/secret remain intact, the candidate
  is recovered without freeing it and the borrowed marker clears. The pinned
  flush consumes pending_hs_data before the failing allocation; its empty
  pending_flight descriptor remains. Those existing outgoing effects are allowed;
  whole-operation rollback is not asserted.

Tracked raw allocations start nonzero. The observer verifies every byte zero
immediately before forwarding the actual __libc_free and observes exactly one
real free per tracked allocation, with no live records. It is not the ordinary
allocation counter and is not a whole-process leak proof. Actual session-key/
traffic-secret snapshots are captured directly into caller-owned storage and
explicitly cleansed after their last use. No key or traffic secret is logged.

The first lifecycle fixture attempted to copy TLS context bytes for configured
DTLS, whose TLS context pointers are null. `lifecycle/` retains that preliminary
failure and exact source. The final snapshot handles absent pointers. Independent
review also required the explicit snapshot cleansing and corrected the outgoing
flush ownership expectation from pinned primary source. Their assertions were
preserved; no native change was needed.

## Inherited regressions and replay

`regressions/` contains 23 byte-identical prior source/counter/script inputs,
recorded in `regression_source_preservation.json`, rebuilt against the final
complete archives. The inherited checks pass: 16 record-reservation lifecycle
cases plus buffer/pair witnesses; 64 HS fragment/coalescing loops, exact-L bounds
and 21 HS lifecycle cases; and 1440 HKDF differential cases with 700 successful
zero-allocation calls and 740 unchanged rejections. Their established scopes and
old record-reservation failure contract remain unchanged.

The safe prebuilt command, from this payload or its copied outer layout, is:

```sh
python3 replay_prebuilt.py --pki-tool /absolute/path/to/wt-tools --output /tmp/uwz-aead-new-replay
```

Output must be absent and outside this payload. The verified PKI helper checksum
and ten retained binary checksums are checked before execution. The replay needs
no compiler/native source/native archives, does not import local modules or write
bytecode into retained evidence, and removes owned private PKI in a finally block.
`replay_validation/` retains a complete successful replay; three refusal checks
are in `replay_negative_results.json`. No certificate/private key, native archive,
compiler cache, core dump or preliminary executable is in the delivery allowlist.

Exact Debug build commands, wrapper flags, source/archive identities and raw
results are retained. Actual encrypted three-suite update loops, read-hook
trailing-old-epoch rejection, observation callbacks and public control rows
belong to the separate wire verifier. This payload does not substitute direct
helper fixtures for that peer evidence. Other native post-handshake allocations
remain: the strict PostgreSQL gate, production integration/pins, fork publication
and full release completion stay open. Deferred smoke/security/sanitizer/fuzz
campaigns were not run.
