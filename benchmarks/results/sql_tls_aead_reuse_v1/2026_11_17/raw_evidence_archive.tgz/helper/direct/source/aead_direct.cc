#include "aead_checks.h"

struct Inputs {
    uint8_t key[32];
    uint8_t iv[12];
    uint8_t plaintext[47];
    uint8_t header[5];
};

struct Ciphertexts {
    uint8_t bytes[2][80];
    size_t lengths[2];
};

static Inputs inputs_for(uint16_t suite, unsigned epoch)
{
    Inputs result = {};
    for (size_t index = 0; index < sizeof(result.key); index++) result.key[index] = index * 7 + epoch * 3 + 11;
    for (size_t index = 0; index < sizeof(result.iv); index++) result.iv[index] = index * 13 + epoch + suite;
    for (size_t index = 0; index < sizeof(result.plaintext); index++) result.plaintext[index] = index * 17 + 5;
    result.plaintext[sizeof(result.plaintext) - 1] = SSL3_RT_APPLICATION_DATA;
    const uint8_t header[] = {SSL3_RT_APPLICATION_DATA, 3, 3, 0, sizeof(result.plaintext) + 16};
    memcpy(result.header, header, sizeof(header));
    return result;
}

static size_t key_length(uint16_t suite)
{
    return suite == 0x1301 ? 16 : 32;
}

static Ciphertexts fresh_ciphertexts(const SSL_CIPHER *cipher, uint16_t suite,
                                     const Inputs *inputs)
{
    auto context = bssl::SSLAEADContext::Create(evp_aead_seal, TLS1_3_VERSION, cipher,
        bssl::Span(inputs->key).first(key_length(suite)), {}, inputs->iv);
    AEAD_CHECK(context);
    Ciphertexts result = {};
    for (size_t index = 0; index < 2; index++) {
        AEAD_CHECK(context->Seal(result.bytes[index], &result.lengths[index],
            sizeof(result.bytes[index]), SSL3_RT_APPLICATION_DATA, TLS1_2_VERSION,
            index, inputs->header, inputs->plaintext, sizeof(inputs->plaintext)));
    }
    return result;
}

static void compare_seal(bssl::SSLAEADContext *reused, const Inputs *inputs,
                         const Ciphertexts *expected)
{
    for (size_t index = 0; index < 2; index++) {
        uint8_t output[80];
        size_t length = 0;
        AEAD_CHECK(reused->Seal(output, &length, sizeof(output), SSL3_RT_APPLICATION_DATA,
            TLS1_2_VERSION, index, inputs->header, inputs->plaintext, sizeof(inputs->plaintext)));
        AEAD_CHECK(length == expected->lengths[index]);
        AEAD_CHECK(memcmp(output, expected->bytes[index], length) == 0);
    }
}

static void compare_open(bssl::SSLAEADContext *context, const Inputs *inputs,
                         const Ciphertexts *expected)
{
    for (size_t index = 0; index < 2; index++) {
        uint8_t bytes[80];
        memcpy(bytes, expected->bytes[index], expected->lengths[index]);
        bssl::Span<uint8_t> plaintext;
        AEAD_CHECK(context->Open(&plaintext, SSL3_RT_APPLICATION_DATA, TLS1_2_VERSION,
            index, inputs->header, bssl::Span(bytes).first(expected->lengths[index])));
        AEAD_CHECK(plaintext.size() == sizeof(inputs->plaintext));
        AEAD_CHECK(memcmp(plaintext.data(), inputs->plaintext, plaintext.size()) == 0);
    }
}

static void live_reinitialization_rejected(bssl::SSLAEADContext *context,
    const SSL_CIPHER *cipher, uint16_t suite, const Inputs *inputs)
{
    uint8_t snapshot[sizeof(bssl::SSLAEADContext)];
    memcpy(snapshot, context, sizeof(snapshot));
    AEAD_CHECK(!bssl::SSLAEADContext::InitForKeyUpdate(context, evp_aead_open,
        cipher, bssl::Span(inputs->key).first(key_length(suite)), inputs->iv));
    AEAD_CHECK(memcmp(snapshot, context, sizeof(snapshot)) == 0);
    ERR_clear_error();
}

static void run_epoch(bssl::SSLAEADContext *context, uint16_t suite,
                      evp_aead_direction_t direction, unsigned epoch)
{
    const SSL_CIPHER *cipher = SSL_get_cipher_by_value(suite);
    AEAD_CHECK(cipher && bssl::SSLAEADContext::SupportsKeyUpdate(cipher));
    const Inputs inputs = inputs_for(suite, epoch);
    const Ciphertexts expected = fresh_ciphertexts(cipher, suite, &inputs);
    auto fresh_open = bssl::SSLAEADContext::Create(evp_aead_open, TLS1_3_VERSION, cipher,
        bssl::Span(inputs.key).first(key_length(suite)), {}, inputs.iv);
    AEAD_CHECK(fresh_open);
    compare_open(fresh_open.get(), &inputs, &expected);
    ERR_clear_error();
    uwz_alloc_begin();
    bssl::SSLAEADContext::ResetForKeyUpdate(context);
    check_empty(context);
    AEAD_CHECK(bssl::SSLAEADContext::InitForKeyUpdate(context, direction, cipher,
        bssl::Span(inputs.key).first(key_length(suite)), inputs.iv));
    AEAD_CHECK(bssl::SSLAEADContext::IsKeyUpdateContext(context, cipher));
    live_reinitialization_rejected(context, cipher, suite, &inputs);
    if (direction == evp_aead_seal) compare_seal(context, &inputs, &expected);
    else compare_open(context, &inputs, &expected);
    bssl::SSLAEADContext::ResetForKeyUpdate(context);
    check_empty(context);
    uwz_alloc_end();
    const AllocationCounts value = counts();
    check_zero(&value);
    printf("{\"suite\":%u,\"direction\":\"%s\",\"epoch\":%u,"
        "\"fresh_equivalence\":true,\"sequence_zero_and_one\":true,\"inline_reset\":true,"
        "\"malloc\":0,\"calloc\":0,\"realloc\":0,\"free\":0,\"bytes\":0}\n",
        suite, direction == evp_aead_seal ? "seal" : "open", epoch);
}

static void invalid_inputs(bssl::SSLAEADContext *context)
{
    const SSL_CIPHER *cipher = SSL_get_cipher_by_value(0x1301);
    const Inputs inputs = inputs_for(0x1301, 7);
    SSL_CIPHER invalid = *cipher;
    invalid.algorithm_enc = 0;
    const SSL_CIPHER *unsupported = SSL_get_cipher_by_value(0x002f);
    AEAD_CHECK(unsupported);
    ERR_clear_error();
    uwz_alloc_begin();
    AEAD_CHECK(!bssl::SSLAEADContext::InitForKeyUpdate(context, evp_aead_seal, cipher,
        bssl::Span(inputs.key).first(15), inputs.iv));
    check_empty(context);
    ERR_clear_error();
    AEAD_CHECK(!bssl::SSLAEADContext::InitForKeyUpdate(context, evp_aead_open, cipher,
        bssl::Span(inputs.key).first(16), bssl::Span(inputs.iv).first(11)));
    check_empty(context);
    ERR_clear_error();
    AEAD_CHECK(!bssl::SSLAEADContext::InitForKeyUpdate(context, evp_aead_seal, &invalid,
        bssl::Span(inputs.key).first(16), inputs.iv));
    check_empty(context);
    ERR_clear_error();
    AEAD_CHECK(!bssl::SSLAEADContext::InitForKeyUpdate(context, evp_aead_open, unsupported,
        bssl::Span(inputs.key).first(16), inputs.iv));
    check_empty(context);
    ERR_clear_error();
    AEAD_CHECK(!bssl::SSLAEADContext::InitForKeyUpdate(context, evp_aead_open, nullptr,
        bssl::Span(inputs.key).first(16), inputs.iv));
    check_empty(context);
    ERR_clear_error();
    uwz_alloc_end();
    const AllocationCounts value = counts();
    check_zero(&value);
    puts("{\"invalid_preparations\":5,\"remain_empty\":true,\"heap_operations\":0}");
}

static void aad_rejection(bssl::SSLAEADContext *context)
{
    const uint16_t suites[] = {0x1301, 0x1302, 0x1303};
    for (uint16_t suite : suites) {
        const SSL_CIPHER *cipher = SSL_get_cipher_by_value(suite);
        const Inputs inputs = inputs_for(suite, 9);
        const Ciphertexts expected = fresh_ciphertexts(cipher, suite, &inputs);
        uint8_t bytes[80], header[5];
        memcpy(bytes, expected.bytes[0], expected.lengths[0]);
        memcpy(header, inputs.header, sizeof(header));
        header[4] ^= 1;
        uwz_alloc_begin();
        AEAD_CHECK(bssl::SSLAEADContext::InitForKeyUpdate(context, evp_aead_open, cipher,
            bssl::Span(inputs.key).first(key_length(suite)), inputs.iv));
        bssl::Span<uint8_t> plaintext;
        AEAD_CHECK(!context->Open(&plaintext, SSL3_RT_APPLICATION_DATA, TLS1_2_VERSION,
            0, header, bssl::Span(bytes).first(expected.lengths[0])));
        bssl::SSLAEADContext::ResetForKeyUpdate(context);
        check_empty(context);
        ERR_clear_error();
        uwz_alloc_end();
        const AllocationCounts value = counts();
        check_zero(&value);
    }
    puts("{\"aad_rejections\":3,\"reset_empty\":true,\"heap_operations\":0}");
}

int main()
{
    AEAD_CHECK(uwz_alloc_self_test());
    auto context = bssl::SSLAEADContext::CreateNullCipher();
    AEAD_CHECK(context);
    bssl::SSLAEADContext::ResetForKeyUpdate(context.get());
    check_empty(context.get());
    const SSL_CIPHER *cipher = SSL_get_cipher_by_value(0x1301);
    const Inputs warm = inputs_for(0x1301, 1);
    AEAD_CHECK(!bssl::SSLAEADContext::Create(evp_aead_open, TLS1_3_VERSION, cipher,
        bssl::Span(warm.key).first(16), {}, bssl::Span(warm.iv).first(11)));
    ERR_clear_error();
    const uint16_t suites[] = {0x1301, 0x1302, 0x1303};
    for (unsigned epoch = 0; epoch < 4; epoch++) {
        for (uint16_t suite : suites) {
            run_epoch(context.get(), suite, evp_aead_seal, epoch);
            run_epoch(context.get(), suite, evp_aead_open, epoch);
        }
    }
    invalid_inputs(context.get());
    aad_rejection(context.get());
    puts("PASS: 24 fresh/reused epochs, invalid inputs, AAD rejection and complete inline-reset regions; self-test63");
}
