#!/usr/bin/env python3
"""Build normal AEAD reuse tests and separate populated-initializer-failure tests."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--zig', default='/tmp/zig-x86_64-linux-0.16.0/zig')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    native = args.native_root.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    output.mkdir()
    environment = dict(os.environ)
    environment['ZIG_GLOBAL_CACHE_DIR'] = '/tmp/uwz-zig-cache'
    commands = []

    def run(command, stem):
        with (output / (stem + '.stdout')).open('wb') as stdout, \
             (output / (stem + '.stderr')).open('wb') as stderr:
            result = subprocess.run(command, cwd=output, env=environment,
                                    stdout=stdout, stderr=stderr)
        commands.append({'command': command, 'exit_code': result.returncode, 'stem': stem})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode != 0:
            raise RuntimeError('Command failed: ' + str(output / stem))

    archives = [native / 'native_out/lib/libssl.a', native / 'native_out/lib/libcrypto.a']
    (output / 'provenance.json').write_text(json.dumps({
        'native_archives': {p.name: sha(p) for p in archives},
        'source_sha256': {name: sha(base / name) for name in
            ['layout_probe.cc', 'aead_checks.h', 'aead_direct.cc', 'aead_inject.c',
             'aead_inject.h', 'aead_init_failures.cc', 'allocation_scope.c']},
        'optimization': 'Debug (-O0 -g)',
        'private_field_access_macro_or_production_test_accessor': False,
    }, indent=2) + '\n')
    common = [args.zig, 'c++', '-std=c++17', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
        '-DBORINGSSL_IMPLEMENTATION', '-isystem', str(native / 'boringssl'),
        '-isystem', str(native / 'boringssl/include')]
    run([*common, '-Xclang', '-fdump-record-layouts', '-c', str(base / 'layout_probe.cc'),
         '-o', str(output / 'layout_probe.o')], 'candidate-layout')
    dump = (output / 'candidate-layout.stdout').read_text()
    match = re.search(r'^\s*0 \| class bssl::SSLAEADContext\n', dump, re.M)
    if not match:
        raise ValueError('Context record layout missing')
    record = dump[match.start():dump.find('\n\n', match.start())]
    baseline = (base / 'baseline_layout.stdout').read_text()
    baseline_match = re.search(r'^\s*0 \| class bssl::SSLAEADContext\n', baseline, re.M)
    if not baseline_match:
        raise ValueError('Baseline record layout missing')
    baseline_record = baseline[baseline_match.start():baseline.find('\n\n', baseline_match.start())]
    if record != baseline_record:
        raise ValueError('Context layout differs from retained fixed-region profile')
    (output / 'context_layout.txt').write_text(record + '\n')
    for stem in ['allocation_scope', 'aead_inject']:
        run([args.zig, 'cc', '-std=c11', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
             '-isystem', str(native / 'boringssl/include'), '-c', str(base / (stem + '.c')),
             '-o', str(output / (stem + '.o'))], 'build-' + stem)
    run([*common, str(base / 'aead_direct.cc'), str(output / 'allocation_scope.o'),
         *[str(p) for p in archives], '-o', str(output / 'aead_direct')], 'link-direct')
    run([*common, str(base / 'aead_init_failures.cc'), str(output / 'allocation_scope.o'),
         str(output / 'aead_inject.o'), '-Wl,--wrap=EVP_AEAD_CTX_init_with_direction',
         *[str(p) for p in archives], '-o', str(output / 'aead_init_failures')], 'link-injected')
    run([str(output / 'aead_direct')], 'direct')
    run([str(output / 'aead_init_failures')], 'init-failures')
    print('PASS: direct reuse/inline reset and separate populated-initializer failures')


if __name__ == '__main__':
    main()
