# Reserved TLS 1.3 KeyUpdate context proposal

This isolated native proposal adds SSL_reserve_key_update_context for ordinary
TLS 1.3 clients. It is not production integration, a native pin or a maintained
fork. Its baseline is exact BoringSSL revision
d3bf4795ad5b79d646cddf2fec687da5b9b502db plus the prior record-buffer, fixed-HKDF
and bounded-handshake-buffer proposals. Input package identities remain in
input_provenance.json. The preceding proposal directories are immutable.

## Ownership and behavior

Startup requires an idle, completed ordinary TLS 1.3 client, with peer CA and
hostname verification performed by its caller. Both active contexts must match
the negotiated application's supported cipher and TLS 1.3 nonce/AAD shape.
Servers, DTLS, QUIC, initialization, shutdown/error and pending plaintext,
records, messages, writes, alerts, updates or flights are rejected before
allocation. The allowed AEADs are AES-128-GCM-TLS13, AES-256-GCM-TLS13 and
ChaCha20-Poly1305. The original record and handshake reservation APIs and the
generic SSLAEADContext::Create body remain byte-identical to this baseline.

One temporary empty context is allocated and committed only after success.
Startup failure preserves the connection's ownership and state. Repeated idle
reservation allocates nothing. SSL3_STATE captures the cipher, owns one spare
and identifies a borrowed candidate by its exact pointer. A local UniquePtr and
then the install-hook parameter own that candidate while the spare slot is empty.
An unavailable or inconsistent reserved slot fails without heap fallback.

The existing lookup, HKDF and AEAD initializers prepare the inactive candidate;
the active context is never reinitialized in place. Read excess-handshake-data
checks and write old-key pending-plaintext sealing precede installation. Hook
success swaps the prepared candidate into its active slot, then cleanses and
recycles the replaced context. Initializer or hook failure cleanses and recovers
the borrowed candidate. Traffic secrets commit only after hook success. Existing
alert, flight and message-consumption effects on error remain; no whole-operation
rollback is promised.

Reset uses existing EVP cleanup followed by explicit cleansing of every byte in
the inline EVP_AEAD_CTX and all 12 fixed-nonce storage bytes. It clears the cipher,
logical nonce length, variable nonce length and every nonce/AAD flag. Real AEAD
initialization resets the AES TLS 1.3 min_next_nonce tracker. Existing bssl::Cleanup
ensures all touched local key, IV and derived-traffic-secret storage is cleansed
on every return; no new generic cleanup abstraction or cryptographic math was
introduced. SSL_clear destroys the spare/profile, and normal destruction frees
all uniquely owned contexts. Full free-zeroing evidence is scoped to the observed
default OPENSSL/glibc allocator path; custom allocator hooks were not tested.

Mutating SSL operations must be serialized and non-reentrant, including from
callbacks. Observation callbacks remain supported during borrowing. The explicit
borrowed identity permits observing old active context ownership during old-key
record sealing without recursively invoking mutating SSL I/O.

## Source and build evidence

Six files differ from the preceding handshake-buffer proposal among 8709 source
entries: ssl.h, internal.h, ssl_lib.cc, ssl_aead_ctx.cc, tls13_enc.cc and
tls_method.cc. Nine unique files differ cumulatively from the exact original
package. Both inventories, source_difference.json and provenance.json record
these identities and all nine complete candidate snapshots. The prior fixed HKDF
file retains hash
abce47c85d1ee69e68e748b5e67159dd3514899e437fe60421a15f83264236a2.

Root released source editing only after a genuine baseline allocation RED:
24 valid peer NOT_REQUESTED KeyUpdates, eight per actually negotiated TLS 1.3
suite 0x1301/0x1302/0x1303, with exact 4096-byte application payloads in both
directions after every update. Each client read allocated/freed 608 bytes once;
writes allocated nothing. Observe mode exited zero; the unchanged strict-zero
assertion exited one with identical data rows. The original 63-byte allocation
interposer self-test passed and generated private PKI was removed.

The initial implementation built successfully but independent review found an
unused SupportsKeyUpdate forwarding predicate. Root approved removing only its
declaration/definition. preliminary/ preserves the initial source snapshots,
diff, inventories, build log, archive identities and preparation evidence as
explicitly preliminary. No runtime source defect was claimed from that finding.

The final matching crypto library and all 38 SSL translation units were rebuilt
together through unchanged Zig 0.16.0 native source lists using a fresh final
local cache. The process exited zero and all six steps succeeded. The final
diff SHA-256 is c734656e6fa305c3fa4a00ae895db10868501dc33fbc3e93270b0f1d2fb1e7ad.
build_commands.json records the exact command, compiler/input hashes and terminal
status. build-native.log and native_archives.json record final build output and
actual archive identities. Debug archive hashes vary with source paths; they
are provenance rather than portable rebuild requirements.

Functional, allocation, failure-injection, callback and lifecycle proofs belong
to companion verification evidence. Its commands, outputs, hashes and terminal
results are authoritative. This implementation payload does not substitute for
those results or claim unreported tests passed. Independent review binds the
final source and evidence separately.

The independent final normal, unwrapped transition fixture measures one startup
C malloc of 608 bytes: a 600-byte context plus its 8-byte allocator prefix.
SSL3_STATE grows from the prior proposal's 608 to 632 bytes (+24 metadata),
including for connections that do not enable this profile. Forty-eight direct
rotations retain exactly three distinct context allocations with no heap calls
or frees and return an empty reclaimed spare. Its unavailable/busy/inconsistent
guards report zero allocation; 24 fresh/reused epochs and 12 populated
initializer-failure cases pass against the final archives. Companion lifecycle
and wire raw results remain separately owned.

The verification owner now reports all 22 final lifecycle/failure cases passing,
including clear/free and fresh-handshake reuse, along with inherited record,
bounded-handshake-buffer and 1440-case HKDF regressions. Its prebuilt replay and
refusal controls also pass. These reported terminal results bind the final
archives; the initial source/build evidence remains preliminary.

The wire owner reports 24 final encrypted peer updates and 600 instrumented
calls per variant. Reserved receive-update windows report zero heap calls;
baseline and final-unreserved modes each retain one 608-byte malloc/free pair
per received update. Twelve protocol rows with 783 calls per variant agree;
27 old-key header observations preserve the active write context while the
candidate is borrowed. The genuine old-epoch trailing-data guard failure
preserves old RX state and recovers the same candidate spare. Public controls
still observe five mallocs/three frees/200 requested bytes for requested
responses, zero for no-response updates, and unchanged 12 mallocs/12 frees/1600
bytes for initial tickets. These are component results, not whole-lifetime
allocation closure.

Ordinary allocation accounting uses the unchanged original all-C counter.
Populated initializer failures use separate test-only link-wrapper instrumentation
that calls the real initializer and then forces its failure return. That injected
erasure proof is distinct from normal allocation accounting; native sources have
no fault-injection branch.

## Source restoration

The payload allowlist retains six baseline snapshots, nine candidate snapshots,
the minimal current diff, full source inventories, provenance, build inputs/logs,
the restore helper and its validation logs. It excludes the full native source
copy, native archives, compilation caches, generated PKI and test secrets.

From the copied implementation payload directory, use the exact original package
and an absent destination:

    python3 restore_source.py /path/to/exact-original-package ./boringssl
    /path/to/zig build -Doptimize=Debug --cache-dir /tmp/new-aead-native-cache \
      -p native_out -j2 --summary all

The preceding handshake-buffer proposal is accepted only with explicit
--source-kind hs. Both modes verify the full expected old file set/hashes and
all nine retained snapshots before writing a new directory. Existing destinations
are refused; cached input is never modified. No patch executable is required.
Python prepares external experiment evidence and is not a library dependency.
The native fallback build compiles every SSL unit together.

restore_validation.json records successful restoration from the prior HS proposal
with exact 8709-entry final-candidate equality, rejection of an existing output
and rejection of HS input presented as the original package. The owned generated
source copy was removed. Successful original-package restoration from the final
copied delivery layout remains Root's validation responsibility.

## Remaining scope

This proposal removes one AEAD-context allocation component. Outgoing control
flights, session tickets, errors, reconnects, other lifetime paths, maintenance
policy and production integration remain separate requirements. SQL-ALLOC-002
and the strict PostgreSQL allocation gate remain open; no PostgreSQL exception,
whole-lifetime allocation guarantee or FIPS certification is claimed. Dedicated
smoke/security/sanitizer/fuzz/scan campaigns remain user-deferred.
