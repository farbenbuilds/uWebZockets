# WebTransport early receive-debt fixture

Root source: aabc85e1ff7ff0a908b8e1e0053947a2ed079c73.
Final Root inputs: project_v5 (263 source/build files). Its exact manifest is
provenance/project_v5_inputs.sha256. Earlier snapshots retain failed and baseline
inputs; none is substituted for the final source.
Native candidate d1104a9fab040af659295a95fb448c971a7bc6de requires its c8 parent.
XEV candidate 5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5 is unchanged.

Run sh replay.sh MODE debt or sh replay.sh MODE datagrams. MODE is Debug,
ReleaseSafe or ReleaseFast. The combined debt driver executes77 tests: the
retained67 stream cases, one publication guard, eight new actual TLS debt cases,
and one explicitly labeled C callback-order injection. The separate33-case
N4 datagram driver shares helpers; these are not110 disjoint cases. Two inherited
N4 reset-credit cases stage a private native receive-window increment before
real wire updates. The new eight debt scenarios do not use that mutation.
The streams selector retains the earlier standalone67 driver; it need not be
repeated after the combined driver already passed the same source/tests.

The new network cases cover late CONNECT transfer, closed-child reclamation,
a lost encrypted payload followed by hidden RESET final-size accounting,
NULL-context BIDI classification with a full Root pool, SID/terminal exhaustion,
ordinary HTTP recovery and debit asserted inside application open/data callbacks.
The ninth case injects only header-close/read callback order while Native owns
the stream. It is not an encrypted-overlap reproduction. The old source fails
its admission-latch assertion; the corrected source passes. Source review records
the narrower overlapping STREAM path that can produce this callback order.
Publication guards passed on old and new source and are not RED evidence.

Replay accepts UWZ_ZIG, UWZ_PACKAGE_DIR, UWZ_LIBXEV_SOURCE, UWZ_LSQUIC_SOURCE,
UWZ_PROJECT_SOURCE, UWZ_CACHE_DIR and ZIG_GLOBAL_CACHE_DIR. Set these to valid
local compiler/package/dependency paths after extraction. Defaults name this
machine's original paths; only the fixture/project default is script-relative.
A suitable Native source is retained in the publication snapshot checkpoint;
its incremental bundle requires c8 from the receive-observer checkpoint.
No maintained fork or production pin is changed by replay.

Positive session limits, bounded grant output integration, multiple sessions,
independent-client acceptance and fork publication remain open. Dedicated
smoke/security/sanitizer/fuzz campaigns are user-deferred.
