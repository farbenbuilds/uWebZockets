from pathlib import Path
import subprocess,shutil,hashlib,json,sys
root=Path('/home/foo/Desktop/Repos/uWebZockets')
fixture=Path('/tmp/uwz-wt-early-debt-native-20261117')
label=sys.argv[1]
target=fixture/label
assert not target.exists(), target
paths=set()
for opts in [[],['--others','--exclude-standard']]:
    output=subprocess.check_output(['git','ls-files','-z',*opts,'--','src','builds','build.zig','build.zig.zon'],cwd=root)
    paths.update(part.decode() for part in output.split(b'\0') if part)
manifest={}
for rel in sorted(paths):
    src=root/rel
    if not src.is_file(): continue
    dst=target/rel
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)
    manifest[rel]=hashlib.sha256(dst.read_bytes()).hexdigest()
provenance=fixture/'provenance'
provenance.mkdir(exist_ok=True)
manifest_path=provenance/(label+'_inputs.sha256')
manifest_path.write_text(''.join(f'{digest}  {name}\n' for name,digest in manifest.items()))
Path('/tmp/uwz-wt-early-debt-evidence-20261117/'+label+'_freeze.json').write_text(json.dumps({'source_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'input_count':len(manifest),'manifest_sha256':hashlib.sha256(manifest_path.read_bytes()).hexdigest()},indent=2)+'\n')
print('Frozen',label,':',len(manifest),'source/build inputs')
