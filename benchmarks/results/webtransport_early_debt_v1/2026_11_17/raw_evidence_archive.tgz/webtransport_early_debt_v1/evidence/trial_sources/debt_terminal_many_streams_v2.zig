const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const h = @import("app_children.zig").ChildrenSupport;
const publication = @import("app_publication.zig").PublicationSupport;
const sessions = @import("session_observer.zig");
const backend = support.webtransport_backend;
const Limits = support.webtransport_session_flow.Limits;
const testing = std.testing;
const reset_code: u64 = (@as(u64, 1) << 62) - 19;

/// Copied accounting facts never retain a borrowed native or session pointer.
const Debt = struct { used: Limits, reclaimed: Limits };

fn early(application: *h.Application, index: usize, id: u64) !Debt {
    const engine = &application.quic_transport.?.engine;
    const store = if (engine.early_debt_store) |*active| active else return error.MissingEarlyStore;
    const debt = store.find(.{ .connection = engine.connections.pool.storage[index].handle, .session_id = id }) orelse return error.MissingEarlyDebt;
    return .{ .used = debt.used, .reclaimed = debt.reclaimed };
}

fn known(application: *h.Application, index: usize, id: u64) !Debt {
    const parent = try sessions.snapshot(h.Application, application, index, id);
    const debt = application.quic_transport.?.engine.stream_contexts[parent.stream_index].session_record.?.receive_debt;
    return .{ .used = debt.used, .reclaimed = debt.reclaimed };
}

fn expect_used(actual: Debt, expected: Limits) !void {
    try testing.expectEqualDeep(expected, actual.used);
}

fn buffered(application: *h.Application, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, observed: *h.Observation, index: usize, id: u64, body: []const u8) !u64 {
    const stream_id = try h.raw_uni(client, id, body);
    try h.await_pending_native(application, clients, observed, index, stream_id, id);
    try h.await_buffered(application, clients, observed, index, stream_id, body);
    return stream_id;
}

fn open_connect(client: *c.struct_uwz_app_client, expected: u64) !void {
    var request: c.struct_uwz_app_connect_request = .{
        .origin = "https://localhost",
        .authorization = "Bearer admission-fixture",
        .duplicate_origin = 0,
    };
    try testing.expectEqual(expected, c.uwz_app_client_open_connect(client, &request));
}

fn rejected_connect(application: *h.Application, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, observed: *h.Observation, expected_id: u64, authorizations: usize) !void {
    try open_connect(client, expected_id);
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(application, clients, observed);
        const result = try h.response_snapshot(client, expected_id);
        if (result.reset_events[0] == 0) continue;
        try testing.expectEqual(@as(c_uint, 0), result.header_callbacks);
        try testing.expectEqual(authorizations, observed.authorization_calls);
        try testing.expectEqual(@as(c_int, c.LSQUIC_SERR_AVAILABLE), result.reset_error_status[0]);
        try testing.expectEqual(support.webtransport.h3_request_rejected, result.reset_error_code[0]);
        return;
    }
    return error.RetiredConnectRejectionTimeout;
}

fn raw_uni_packet(application: *h.Application, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, observed: *h.Observation, session_id: u64, finish: bool) !u64 {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        var id: u64 = std.math.maxInt(u64);
        const status = c.uwz_app_client_open_raw_uni(client, &id);
        if (status == c.LSQUIC_MUS_BLOCKED) {
            try h.pump(application, clients, observed);
            continue;
        }
        try testing.expectEqual(@as(c_int, c.LSQUIC_MUS_OK), status);
        var prefix: [16]u8 = undefined;
        const length = try support.webtransport.encode_unidirectional_header(session_id, &prefix);
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, &prefix, length, 0));
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, "X", 1, @intFromBool(finish)));
        return id;
    }
    return error.DebtUniCreditRecoveryTimeout;
}

test "early debt: retained body transfers once before late CONNECT child delivery" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application };
    const port = try publication.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    const body = "debt-before";
    const id = try buffered(&application, client, &clients, &observed, index, 0, body);
    const before = try early(&application, index, 0);
    try expect_used(before, .{ .data = body.len, .streams_uni = 1 });
    try testing.expectEqualDeep(Limits{}, before.reclaimed);
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expectEqual(@as(usize, 0), observed.authorization_calls);
    for (0..16) |_| {
        _ = try h.receive_snapshot(&application, index, id);
        try h.pump(&application, &clients, &observed);
    }
    try testing.expectEqualDeep(before, try early(&application, index, 0));
    _ = try h.accept(&application, client, &clients, &observed, 0);
    const key = try h.key_for(&application, index, 0, id);
    _ = try h.await_data(&application, &clients, &observed, key, body);
    try expect_used(try known(&application, index, 0), before.used);
    const engine = &application.quic_transport.?.engine;
    try testing.expect(engine.early_debt_store.?.find(.{ .connection = key.connection, .session_id = 0 }) == null);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, "+", 1, 1));
    try h.expect_completed(try h.await_closed(&application, &clients, &observed, key), "debt-before+");
    const final = try known(&application, index, 0);
    try expect_used(final, .{ .data = body.len + 1, .streams_uni = 1 });
    try testing.expectEqualDeep(final.used, final.reclaimed);
    try h.healthy_http(&application, client, &clients, &observed);
}

test "early debt: closed child remains charged and reclaimed before late CONNECT" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application };
    const port = try publication.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    const body = "abandoned";
    const id = try buffered(&application, client, &clients, &observed, index, 0, body);
    _ = try buffered(&application, client, &clients, &observed, index, 4, "future");
    try testing.expectEqual(backend.ResetResult.ok, backend.reset_stream(try h.native_client_stream(client, id), reset_code));
    var reclaimed = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        const debt = try early(&application, index, 0);
        if (debt.reclaimed.streams_uni == 0) continue;
        try expect_used(debt, .{ .data = body.len, .streams_uni = 1 });
        try testing.expectEqualDeep(debt.used, debt.reclaimed);
        reclaimed = true;
        break;
    }
    try testing.expect(reclaimed);
    try testing.expectEqual(@as(usize, 0), observed.count);
    _ = try h.accept(&application, client, &clients, &observed, 0);
    const imported = try known(&application, index, 0);
    try expect_used(imported, .{ .data = body.len, .streams_uni = 1 });
    try testing.expectEqualDeep(imported.used, imported.reclaimed);
    try testing.expectEqual(@as(usize, 0), observed.count);
    try expect_used(try early(&application, index, 4), .{ .data = 6, .streams_uni = 1 });
    try h.healthy_http(&application, client, &clients, &observed);
}

test "early debt: reset final gap from a lost payload packet charges once before admission" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application };
    const port = try publication.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    const id = try buffered(&application, client, &clients, &observed, index, 0, "abcd");
    try h.settle(&application, &clients, &observed, index);
    try expect_used(try early(&application, index, 0), .{ .data = 4, .streams_uni = 1 });
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, "efghijkl", 8, 0));
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_process(client));
    try testing.expect(c.uwz_app_client_drop_pending_packets(client) > 0);
    // Loss drops encrypted datagrams, without changing native offsets or credit.
    try testing.expectEqual(@as(c_int, c.LSQUIC_SRA_OK), c.lsquic_stream_reset_at(try h.native_client_stream(client, id), reset_code, 7));
    try h.deliver_client_batch(&application, client, &observed, index);
    const state = try h.receive_snapshot(&application, index, id);
    try testing.expectEqual(@as(?u64, 15), state.final_size);
    try testing.expect(!state.reset_visible);
    try expect_used(try early(&application, index, 0), .{ .data = 12, .streams_uni = 1 });
    _ = try h.accept(&application, client, &clients, &observed, 0);
    const key = try h.key_for(&application, index, 0, id);
    const record = try h.await_closed(&application, &clients, &observed, key);
    try testing.expectEqualSlices(u8, "abcd", record.bytes[0..record.received]);
    try testing.expectEqual(@as(usize, 1), record.reset_calls);
    const final = try known(&application, index, 0);
    try expect_used(final, .{ .data = 12, .streams_uni = 1 });
    try testing.expectEqualDeep(final.used, final.reclaimed);
    for (0..16) |_| try h.pump(&application, &clients, &observed);
    try testing.expectEqualDeep(final, try known(&application, index, 0));
    try h.healthy_http(&application, client, &clients, &observed);
}

test "early debt: NULL context BIDI classification charges a full pool without retiring its transport ID" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application };
    const port = try publication.listen(&application, &observed);
    const a = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(a);
    const b = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(b);
    const d = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(d);
    const clients = [_]*c.struct_uwz_app_client{ a, b, d };
    const ai = try h.handshake(&application, a, &clients, &observed);
    const bi = try h.handshake(&application, b, &clients, &observed);
    const di = try h.handshake(&application, d, &clients, &observed);
    _ = try h.accept(&application, a, &clients, &observed, 0);
    for (0..3) |_| _ = try buffered(&application, a, &clients, &observed, ai, 4, "A");
    for (0..2) |_| _ = try buffered(&application, b, &clients, &observed, bi, 0, "B");
    for (0..2) |_| _ = try buffered(&application, d, &clients, &observed, di, 0, "D");
    const engine = &application.quic_transport.?.engine;
    try testing.expectEqual(@as(usize, 8), engine.stream_pool.count_active());
    const id = try h.open_child(&application, a, 0, .bidi);
    try testing.expectEqual(@as(u64, 4), id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(a, id, "orphan-bidi", 11, 1));
    try h.peer_stop(&application, a, &clients, &observed, id, support.webtransport.wt_buffered_stream_rejected);
    var reclaimed = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        const debt = try known(&application, ai, 0);
        if (debt.reclaimed.streams_bidi == 0) continue;
        try expect_used(debt, .{ .data = 11, .streams_bidi = 1 });
        try testing.expectEqualDeep(debt.used, debt.reclaimed);
        reclaimed = true;
        break;
    }
    try testing.expect(reclaimed);
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expectEqual(@as(usize, 7), engine.pending_child_count);
    try testing.expectEqual(@as(usize, 8), engine.stream_pool.count_active());
    try expect_used(try early(&application, ai, 4), .{ .data = 3, .streams_uni = 3 });
    _ = try h.abort_connection(&application, b, &clients, &observed);
    try h.healthy_http(&application, a, &clients, &observed);
}

test "early debt: exhausted SID bucket retires that SID before CONNECT authorization" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application };
    const port = try publication.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    for (0..4) |number| _ = try buffered(&application, client, &clients, &observed, index, number * 4, "A");
    const rejected = try h.raw_uni(client, 16, "retired");
    try h.peer_stop(&application, client, &clients, &observed, rejected, support.webtransport.wt_buffered_stream_rejected);
    const engine = &application.quic_transport.?.engine;
    const key: support.webtransport_pending_datagrams.SessionKey = .{ .connection = engine.connections.pool.storage[index].handle, .session_id = 16 };
    try testing.expect(engine.pending_datagrams.?.store.is_retired(key));
    try testing.expect(engine.early_debt_store.?.find(key) == null);
    for (0..4) |_| try h.healthy_http(&application, client, &clients, &observed);
    try rejected_connect(&application, client, &clients, &observed, 16, 0);
    try testing.expectEqual(@as(usize, 0), observed.session_count);
    try h.healthy_http(&application, client, &clients, &observed);
}

test "early debt: terminal exhaustion suppresses unknown CONNECT while an established sibling survives" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application };
    const port = try publication.listen(&application, &observed);
    const a = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(a);
    const b = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(b);
    const clients = [_]*c.struct_uwz_app_client{ a, b };
    const ai = try h.handshake(&application, a, &clients, &observed);
    const bi = try h.handshake(&application, b, &clients, &observed);
    _ = try h.accept(&application, b, &clients, &observed, 0);
    const engine = &application.quic_transport.?.engine;
    const capacity = engine.pending_datagrams.?.store.storage.terminals.len;
    for (0..capacity + 5) |number| {
        const session_id = @as(u64, 4096) + number * 4;
        const id = try raw_uni_packet(&application, a, &clients, &observed, session_id, number < 4);
        if (number < 4) {
            try h.await_pending_native(&application, &clients, &observed, ai, id, session_id);
            try h.await_buffered(&application, &clients, &observed, ai, id, "X");
            continue;
        }
        try h.peer_stop(&application, a, &clients, &observed, id, support.webtransport.wt_buffered_stream_rejected);
    }
    try testing.expect(engine.connections.pool.storage[ai].unknown_receive_disabled);
    try testing.expect(!engine.connections.pool.storage[bi].unknown_receive_disabled);
    try rejected_connect(&application, a, &clients, &observed, 0, 1);
    try testing.expectEqual(@as(usize, 1), observed.session_count);
    const id = try h.open_child(&application, b, 0, .uni);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(b, id, "survives", 8, 1));
    var completed = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        const record = h.find_record(&observed, engine.connections.pool.storage[bi].handle, id) orelse continue;
        if (record.closed == null) continue;
        try h.expect_completed(record, "survives");
        completed = true;
        break;
    }
    try testing.expect(completed);
    try expect_used(try known(&application, bi, 0), .{ .data = 8, .streams_uni = 1 });
    try h.healthy_http(&application, a, &clients, &observed);
    try h.healthy_http(&application, b, &clients, &observed);
}
