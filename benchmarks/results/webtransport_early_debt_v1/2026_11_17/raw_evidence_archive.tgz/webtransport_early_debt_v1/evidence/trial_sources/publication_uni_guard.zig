const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const h = @import("app_children.zig").ChildrenSupport;
const streams = h.Streams;
const testing = std.testing;

fn opened(context: *anyopaque, info: streams.Info) bool {
    const observed: *h.Observation = @ptrCast(@alignCast(context));
    const engine = &observed.application.quic_transport.?.engine;
    if (!engine.stream_contexts[info.handle.index].transmit.published) {
        observed.failure = error.OpenBeforeTypedPublication;
        return false;
    }
    return h.Consumer.callbacks.open(context, info);
}

fn listen(application: *h.Application, observed: *h.Observation) !u16 {
    try application.enable_http3_ephemeral();
    var callbacks = h.Consumer.callbacks;
    callbacks.open = opened;
    _ = try application.webtransport_streams_context("/wt", observed, callbacks);
    _ = try application.route_context(.connect, "/wt", observed, h.authorize);
    _ = try application.route_context(.post, "/health", observed, h.health);
    try application.listen_udp("127.0.0.1", 0);
    return application.quic_transport.?.local_address.ip4.port;
}

test "early publication: typed notification precedes incoming consumer open" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    _ = try h.accept(&application, client, &clients, &observed, 0);
    const id = try h.raw_uni(client, 0, "published-body");
    try h.finish_send(client, id);
    var found = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        if (h.find_record(&observed, application.quic_transport.?.engine.connections.pool.storage[index].handle, id)) |record| {
            if (record.closed == null) continue;
            try h.expect_completed(record, "published-body");
            found = true;
            break;
        }
    }
    try testing.expect(found);
    try h.healthy_http(&application, client, &clients, &observed);
}

const module = @This();
pub const PublicationSupport = struct {
    pub const listen = module.listen;
};
