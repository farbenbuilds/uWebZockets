from pathlib import Path
import json,os,subprocess,time
proof=Path('/tmp/uwz-wt-early-debt-evidence-20261117')
fixture=Path('/tmp/uwz-wt-early-debt-native-20261117')
results=json.loads((proof/"matrix-v5.json").read_text()) if (proof/"matrix-v5.json").exists() else []
for mode in ['Debug','ReleaseSafe','ReleaseFast']:
    for suite,count in [('debt',77),('datagrams',33)]:
        name=f'v5-{suite}-{mode}.log'
        prior=next((item for item in results if item['mode']==mode and item['suite']==suite),None)
        if prior is not None:
            assert prior['exit_code']==0 and f'{count}/{count} tests passed' in prior['summary'][0]
            print(mode,suite,'retaining verified same-source success',flush=True)
            continue
        env=dict(os.environ,UWZ_PROJECT_SOURCE=str(fixture/'project_v5'))
        env.pop('UWZ_TEST_FILTER',None)
        start=time.monotonic()
        with (proof/name).open('w') as log:
            done=subprocess.run(['sh',str(fixture/'replay.sh'),mode,suite],env=env,stdout=log,stderr=subprocess.STDOUT)
        (proof/(name+'.exit')).write_text(str(done.returncode)+'\n')
        summaries=[line for line in (proof/name).read_text().splitlines() if line.startswith('Build Summary:')]
        record={'mode':mode,'suite':suite,'expected_tests':count,'log':name,'exit_code':done.returncode,'seconds':round(time.monotonic()-start,3),'summary':summaries}
        results.append(record)
        (proof/'matrix-v5.json').write_text(json.dumps(results,indent=2)+'\n')
        print(mode,suite,'exit',done.returncode,'; '.join(summaries),flush=True)
        if done.returncode!=0: raise SystemExit(done.returncode)
        assert len(summaries)==1 and f'{count}/{count} tests passed' in summaries[0],record
