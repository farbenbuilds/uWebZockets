# TX source reviews

Independent architect/reviewer and writer-lifecycle reviewer found no unresolved source findings.
Reviewed tracked reader lifetime/ownership, typed publication, STOP/RX independence, handle
identity, preflight wake ordering, one-shot interest and timer/cancel reuse.
The required errno finding was reproduced: stale AGAIN caused zero-consumption failure to
return WouldBlock. Clearing errno before writef fixes it. Actual Root reader fault tests cover
positive consumption followed by negative return or flush failure in all three modes.
These injected C-boundary cases are distinct from actual native37 and the Root wake-fault seam.
No actual native allocation/flush failure or OS submit failure is claimed.

The wake worker verified actual io_uring expiration with cancellation outstanding, all3modes,
and published-XEV epoll7pass/1platformskip. kqueue/IOCP runtime remains open; cross compile
is not runtime proof. macOS first used system ar fallback which listed BSD symbol metadata;
the intended Zig ar path and unchanged archive verifier passed. No quality gate was weakened.

Public local half-stop/reset, outgoing construction, positive/multi-session flow, independent
client acceptance, publication and all remaining v2.3.0 gates remain open. Smoke/security
campaigns stay user-deferred.
