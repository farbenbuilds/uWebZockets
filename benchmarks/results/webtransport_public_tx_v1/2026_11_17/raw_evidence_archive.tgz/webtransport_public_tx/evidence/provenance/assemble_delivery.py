import hashlib, json, shutil, subprocess, tarfile
from pathlib import Path
root=Path('/home/foo/Desktop/Repos/uWebZockets')
scratch=Path('/tmp/uwz-wt-public-tx-20261117')
evidence=Path('/tmp/uwz-wt-public-tx-evidence-20261117')
delivery=Path('/tmp/uwz-wt-public-tx-delivery-20261117')
if delivery.exists():
    raise SystemExit('Delivery exists; inspect before replacing it')
delivery.mkdir()
shutil.copytree(scratch,delivery/'fixture',ignore=shutil.ignore_patterns('.zig-cache','zig-out','zig-pkg','.git'))
shutil.copytree(evidence,delivery/'evidence')
for name, location in [('udp_wake','/tmp/uwz-udp-wake-20261117'),('tx_policy','/tmp/uwz-wt-tx-policy-20261117')]:
    shutil.copytree(location,delivery/name,ignore=shutil.ignore_patterns('.zig-cache','zig-pkg','zig-out','cache*','global-cache','.git'))
paths=['src','tests/package_consumer','README.md','CHANGELOG.md','CODEBASE.md','docs/quic.md','tasks/plan.md','tasks/todo.md']
patch=subprocess.check_output(['git','diff','--binary','b0e47ec8dc7c9ca8b9e844293f4aceb74d509893','--',*paths],cwd=root)
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z','--','src'],cwd=root)
for path in (x.decode() for x in new.split(b'\0') if x):
    result=subprocess.run(['git','diff','--no-index','--binary','/dev/null',path],cwd=root,stdout=subprocess.PIPE)
    if result.returncode!=1:raise SystemExit('Unexpected new-file diff result')
    patch+=result.stdout
(delivery/'evidence'/'provenance'/'root.patch').write_bytes(patch)
source=[]
for line in (evidence/'provenance'/'project_v2_inputs.sha256').read_text().splitlines():
    digest,path=line.split('  ',1)
    if hashlib.sha256((root/path).read_bytes()).hexdigest()!=digest:raise SystemExit('Root differs from frozen v4: '+path)
    source.append(path)
    copied=delivery/'fixture'/'project_v2'/path
    if hashlib.sha256(copied.read_bytes()).hexdigest()!=digest:raise SystemExit('Packaged Root input differs: '+path)
records=[]
for f in sorted(delivery.rglob('*')):
    if f.is_file():records.append(f'{hashlib.sha256(f.read_bytes()).hexdigest()}  {f.relative_to(delivery)}\n')
(delivery/'files.sha256').write_text(''.join(records))
archive=delivery.with_suffix('.tgz')
with tarfile.open(archive,'w:gz') as tar:
    tar.add(delivery,arcname='webtransport_public_tx')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'payload_files':len(records),'final_root_inputs':len(source)},indent=2))
