# Public peer-BIDI TX handoff

READY: every build is terminal. Copy
`/tmp/uwz-wt-public-tx-20261117` as `fixture/` and this directory as `evidence/`.
No Root or native source was edited by this worker. The old RX fixture is
immutable; all 26 copied RX test sources remain unchanged.

The final actual-engine cohort is 37 functional cases, no anchors: RX26 plus
TX11. Debug63704, ReleaseSafe69358 and ReleaseFast30477 each exit0 with37/37
tests and16/16 steps. `results.json` and `commands.txt` retain exact commands,
sessions and raw log hashes. All final inputs verify unchanged after every
mode and after documentation edits.

| Inventory | Inputs | SHA256 |
| --- | --- | --- |
| `fixture/provenance/tx37_run_inputs.sha256` |33|`cc8bf3c71cb87e329892a7a1ea417027cab990b768e197b3f030c4136b1f7def`|
| `fixture/provenance/project_v2_inputs.sha256` |257|`810931c3eb4975bf19e729acc705e2d9c568176bccc96f7118ecfc498343c915`|
| `fixture/provenance/tx37_delivery_inputs.sha256` |36|`878d5836fd43feed779c50f0b15d96fc9572b0b062f9e2fbd3b1fb6fe4c56463`|

The delivery inventory adds only README, replay and the copied Root inventory.
The historical run inventory is preserved. Authoritative raw logs are
`tx37-v2-{Debug,ReleaseSafe,ReleaseFast}.log` with SHAs respectively
`cd5a7263cf2acda10f46704d3c973c67ac6f398acac402c284bef28f7745e8c4`,
`6b0092363d3b81f82ce477a62f87b73f34490b5c7ae0bf112c7ece9860c5f5f2`,
`3d1181b07501127742ef03487a0d5d61f0ab07fc080ca23507872078302206f1`.

Real stream credit4096/payload8192 and connection credit16384/stream65536/
payload32768 block and recover via actual peer reads and encrypted native
MAX_STREAM_DATA/MAX_DATA. The private credit-grant helper is unused. Response
capture is fixed65536, request/write helper512, stream history16. The loop-only
deadline case separately stages a real >=500ms timer for outside write,
writable and finish; each result precedes that deadline within250ms, without
manual Root processing or peer sends, with identical Root input statistics.

Keep evidence profiles distinct: actual-engine37; Root's injected C-boundary
ownership/errno tests; and the explicitly authorized Root `Binding.wake`
failure seam. Neither a rare real native consume-then-flush failure nor an
actual OS submission failure was induced here. Wake failure preserves native
bytes and child intents, then restored normal transport proves exact retry.

`history.json` distinguishes the genuine old-API compile RED from fixture
compile diagnostics and historical v1 green runs. No runtime assertion was
weakened. Native005/XEV5b2c remain clean, pins unchanged; exact source/archive,
hpack/gitlink and clock-domain details are in `source_profile.json` and README.

`replay.sh` derives its own directory and defaults to adjacent `project_v2/`,
with explicit verified native005/XEV5b2c/offline-package/Zig inputs. Syntax
check passes; Root owns fresh extracted replay and full-payload packaging.
Local STOP/RESET, outgoing streams and external-client/release acceptance
remain open. Smoke/security/sanitizer/fuzz campaigns remain user-deferred.
