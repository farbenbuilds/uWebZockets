# Public peer-BIDI transmit checkpoint

The final actual-App cohort passes 37/37 functional tests, 0 anchors, 16/16 steps
in Debug, ReleaseSafe and ReleaseFast. It combines the unchanged 26 RX/public
cases with 11 new TX cases. Final entry point: `tests/tx_main.zig`.

## Frozen inputs

The 33-file run inventory `provenance/tx37_run_inputs.sha256` has SHA256
`cc8bf3c71cb87e329892a7a1ea417027cab990b768e197b3f030c4136b1f7def`.
The 257-file actual Root snapshot `project_v2/` is identified by
`provenance/project_v2_inputs.sha256`, SHA256
`810931c3eb4975bf19e729acc705e2d9c568176bccc96f7118ecfc498343c915`.
Both inventories verify unchanged after all three modes. `project_v1/` and
earlier manifests/logs are historical inputs. README/replay are post-run
documentation additions, covered separately by the delivery inventory.
The original RX source artifact is
`benchmarks/results/webtransport_public_receive_v1/2026_11_16/raw_evidence_archive.tgz`,
SHA256 `40b629cc3e81f39a29d0627eead126a417c2a2f22cd76f7d52defbdcd4b06fac`.

Native lsquic is 005ab244169f269689e511d6b77dd2187e318df1; libxev is
5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5. Both working trees were clean.
Production pins remain unchanged. All C dependencies use the existing Zig
vendor builders and Zig 0.16.0. The actual App handles public registration,
admission, callbacks, writes, writable interest, cancellation and finish over
native HTTP/3/TLS, Linux loopback UDP and xev. Native stream callbacks are not substituted by the fixture. The explicit
Root wake dependency fault is described separately below.

Native scheduling retains the inherited synthetic fixture clock. Production
App pending expiry uses its real OS awake clock. Deadline-wake assertions use
the real Linux monotonic clock and read the actual armed xev timer deadline;
these clock domains are distinct. The wake test is Linux-specific functional
proof, not a throughput or general latency benchmark.

The prior lifecycle source/history artifact retains native005 and XEV5b2c:
`benchmarks/results/webtransport_child_lifecycle_v1/2026_11_16/raw_evidence_archive.tgz`,
SHA256 `3e27ce7137f3791cf977d0b4c83bee4ea72c873b1af125c3a13616695b2a8418`,
12,891,820 bytes. Its same-directory README documents the source/history layout.
Actual compiled hpack is fda48e02491d865cce00612be8cc10c2622b8e55; its native
gitlink remains cf0f70dd10b352194c97448eb5d00b4aa484f531. Actual qpack and
native gitlink are 91567706c41c0d97ab8dc576873ecd472d7869fa.

## New proof and bounds

The 11 TX cases prove callback binary echo; copied accepted-prefix ownership;
binary writes after RX EOF and independent RESET; stream and connection credit
blocking/recovery; explicit retry without a writable callback; one-shot
writable disarm/rearm without spin; open-time interest deferred until ownership
and actual typed publication; STOP blocking TX while RX continues; wake-failure
rollback; public App shutdown in writable; and external-operation deadline wake.
Peer payload, FIN, reset codes, close ownership/accounting and healthy HTTP
checks remain real transport observations. A finished TX half is independent
of the still-open RX half. Closed handles reject later writes/interest.

Stream credit uses the existing pre-engine 4096-byte advertised local-BIDI
profile and an 8192-byte payload. Connection credit uses a new pre-engine-only
profile: MAX_DATA 16384, stream credit 65536, fixed windows with auto-tuning off,
and 32768 payload bytes. Peer reads are paused before child construction, then
enabled through public native `wantread`. Actual reads cause actual encrypted
MAX_STREAM_DATA/MAX_DATA progress. Copy-only diagnostics distinguish stream
credit exhaustion from connection exhaustion. The inherited private-window
`grant_response_credit` helper is not called by this cohort.

The response capture is a separate fixed 65536-byte array per client record.
The request/write helper bound remains 512, history remains 16 records, and all
original 26 test source files remain unchanged. Only the new fixture's builder
path/name and two C fixture files differ from the 29 inherited inputs. There
is no Root queue or native flag/credit/allocator mutation in the new tests.

The explicitly labeled wake-fault case temporarily replaces only Root
`Binding.wake` with a function returning WakeFailed, after admission and typed
publication. Write, finish, cancel and enable-interest must leave native bytes,
accepted count and relevant child intents unchanged. The callback is restored;
the same bytes are then sent once, followed by normal FIN and further RX.
This dependency fault is separate from normal native-wire proof.

The loop-only wake case independently stages an actual timer at least 500 ms
away before external write, external writable interest and later finish.
Each result must arrive within 250 ms and before the original deadline. Only
xev drives Root during each observation: no manual `engine.process`, no new
client UDP sends, and decrypted Root input statistics must remain identical.
Client receive/processing may queue ACKs, which are sent after that phase.

## Final commands and results

From the fixture directory, each mode ran serially with authorized loopback
socket access. `commands.txt` in sibling `evidence/` expands the exact command
for each mode; its common form is:

```sh
ulimit -c 0
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-uni-global-cache \
  /tmp/zig-x86_64-linux-0.16.0/zig build test \
  --system /tmp/uwz-wt-child-callbacks-20261116/zig-pkg \
  --cache-dir /tmp/uwz-wt-public-streams-cache \
  -Dproject-source=/tmp/uwz-wt-public-tx-20261117/project_v2 \
  -Dtest-source=tests/tx_main.zig -Doptimize="$MODE" \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-uni-credit-20261116 \
  -Dlibxev-source=/tmp/uwz-gro-libxev -j2 --summary all
```

| Mode | Session | Result | Log SHA256 |
| --- | --- | --- | --- |
| Debug |63704|exit0,37/37,16/16|`cd5a7263cf2acda10f46704d3c973c67ac6f398acac402c284bef28f7745e8c4`|
| ReleaseSafe |69358|exit0,37/37,16/16|`6b0092363d3b81f82ce477a62f87b73f34490b5c7ae0bf112c7ece9860c5f5f2`|
| ReleaseFast |30477|exit0,37/37,16/16|`3d1181b07501127742ef03487a0d5d61f0ab07fc080ca23507872078302206f1`|

The API-baseline compile RED is the missing public write member on old frozen
RX `project_v4`. Subsequent enum/exhaustiveness/clock diagnostics were fixture
compile mistakes, not product failures. The actual v1 first echo and 36-case
cohort passed. V2 additionally clears native errno and has Root adapter-fault
tests; this fixture does not claim a real native consume-then-flush failure
occurred. `history.json` retains each classification and raw log hash.
The profiles remain separate: these 37 actual-engine cases, Root's injected
C-boundary ownership/errno adapter tests, and this fixture's Root wake-callback
failure seam. No actual OS submission failure was induced by the wake seam.

## Replay and limits

Set `UWZ_ZIG`, `UWZ_LSQUIC_SOURCE`, `UWZ_LIBXEV_SOURCE`, `UWZ_PACKAGE_DIR`
to the compiler, verified source trees and offline Zig packages, then run
`sh replay.sh Debug`, ReleaseSafe or ReleaseFast. The script derives its own
directory, defaults to adjacent `project_v2/`, verifies both frozen inventories
and uses `--system` to prevent dependency fetching. Optional settings are
`UWZ_PROJECT_SOURCE`, `UWZ_CACHE_DIR`, `UWZ_JOBS`, `ZIG_GLOBAL_CACHE_DIR`.
Source authenticity follows the referenced archive/manifests; directory names
alone are not revision proof. Loopback UDP permission is required.

This increment supports peer-BIDI sending and writable notifications. Local
STOP/RESET commands, outgoing child creation, external-client acceptance,
production pin activation and full WebTransport/release acceptance remain
open. Dedicated smoke/security/sanitizer/fuzz campaigns remain user-deferred.
