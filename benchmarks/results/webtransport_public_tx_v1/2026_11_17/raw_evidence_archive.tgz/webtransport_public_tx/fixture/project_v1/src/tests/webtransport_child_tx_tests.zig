const std = @import("std");
const child = @import("test_support").webtransport_child_runtime;

test "WebTransport transmit ownership survives failure after native reader consumption" {
    for ([_]child.WriteStatus{ .closed, .failed }) |status| {
        const attempt = child.complete_write(3072, status);
        try std.testing.expectEqual(@as(usize, 3072), try attempt.result);
        try std.testing.expect(attempt.failed);
    }
}

test "WebTransport transmit partial and blocked progress retain their accepted prefix" {
    for ([_]child.WriteStatus{ .progress, .blocked }) |status| {
        const attempt = child.complete_write(17, status);
        try std.testing.expectEqual(@as(usize, 17), try attempt.result);
        try std.testing.expect(!attempt.failed);
    }
}

test "WebTransport transmit zero acceptance reports backpressure or terminal failure" {
    const blocked = child.complete_write(0, .blocked);
    try std.testing.expectError(error.WouldBlock, blocked.result);
    try std.testing.expect(!blocked.failed);
    const no_progress = child.complete_write(0, .progress);
    try std.testing.expectError(error.WouldBlock, no_progress.result);
    const closed = child.complete_write(0, .closed);
    try std.testing.expectError(error.WriteClosed, closed.result);
    try std.testing.expect(!closed.failed);
    const failed = child.complete_write(0, .failed);
    try std.testing.expectError(error.WriteFailed, failed.result);
    try std.testing.expect(failed.failed);
}
