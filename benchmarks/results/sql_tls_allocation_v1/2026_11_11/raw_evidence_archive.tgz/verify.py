#!/usr/bin/env python3
"""Verify allocation evidence integrity; success does not pass the allocation gate."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("directory", type=Path, nargs="?", default=Path(__file__).resolve().parent)
parser.add_argument("--resolve", action="store_true")
parser.add_argument("--enforce-zero", action="store_true", help="exit 1 when the strict allocation gate fails")
args = parser.parse_args()
root = args.directory.resolve()
manifest = root / "files.sha256"
if manifest.exists():
    for line in manifest.read_text().splitlines():
        expected, name = line.split("  ", 1)
        path = root / name
        assert path.resolve().is_relative_to(root), "unsafe manifest path"
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, f"checksum mismatch: {name}"
statuses = json.loads((root / "run-status.json").read_text())
summary = {"evidence_integrity": "PASS", "samples_per_mode": 256, "warmup_queries_per_mode": 16, "inflight": 1, "startup_and_authentication": "EXCLUDED", "modes": {}}
for mode in ("plaintext", "tls"):
    assert statuses[mode]["exit_code"] == 0
    assert statuses[mode]["interposer_self_test"] == "PASS"
    log = (root / f"{mode}.stdout.log").read_text()
    assert re.search(r"^samples=256 errors=0 duration_ns=\d+$", log, re.M)
    rows = list(csv.DictReader((root / f"{mode}.csv").open()))
    assert len(rows) == 256
    assert [int(row["sample"]) for row in rows] == list(range(256))
    fields = ("malloc_calls", "calloc_calls", "realloc_calls", "free_calls", "requested_bytes")
    expected = (0, 0, 0, 0, 0) if mode == "plaintext" else (2, 0, 0, 2, 213)
    assert {tuple(int(row[key]) for key in fields) for row in rows} == {expected}
    sites = sorted({row[key] for row in rows for key in ("malloc_site_0", "malloc_site_1")})
    assert sites == (["0"] if mode == "plaintext" else ["14e4f1c"])
    summary["modes"][mode] = {"queries": len(rows), "query_errors": 0, "every_query": dict(zip(fields, expected)), "totals": {key: sum(int(row[key]) for row in rows) for key in fields}, "malloc_return_pcs_hex": sites}
allocated = sum(mode["totals"][key] for mode in summary["modes"].values() for key in ("malloc_calls", "calloc_calls", "realloc_calls"))
summary["strict_all_c_steady_query_allocation_gate"] = "FAILED" if allocated else "PASS"
if args.resolve:
    binary = root / "bin/sql_tls_allocation_probe"
    text = subprocess.check_output(["addr2line", "-Cfipe", str(binary), "0x14e4f1b"], text=True)
    assert "bssl::SSLBuffer::EnsureCap" in text
    assert "ssl_buffer.cc:72" in text
    summary["malloc_symbol_resolution"] = text.strip()
print(json.dumps(summary, indent=2))
if args.enforce_zero and allocated:
    raise SystemExit(1)
