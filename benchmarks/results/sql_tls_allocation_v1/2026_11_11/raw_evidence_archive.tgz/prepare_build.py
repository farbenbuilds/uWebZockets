#!/usr/bin/env python3
"""Retarget only this temporary consumer's local dependency path."""
import argparse
import json
from pathlib import Path
import re

parser = argparse.ArgumentParser()
parser.add_argument("repository", type=Path)
args = parser.parse_args()
manifest = Path(__file__).resolve().parent / "build.zig.zon"
text = manifest.read_text()
text, count = re.subn(r'\.path = "[^"\n]*"', lambda _: ".path = " + json.dumps(str(args.repository.resolve())), text, count=1)
assert count == 1
manifest.write_text(text)
