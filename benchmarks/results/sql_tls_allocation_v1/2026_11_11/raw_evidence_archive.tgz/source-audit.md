# Pinned-source allocation audit

The strict all-C steady-query allocation gate is FAILED. No TLS allocation exception is approved by this artifact. SQLite SQL-ALLOC-001 does not authorize this boundary.

## SQL and TLS call path

- `src/sql/connection.zig:352` `pump_tls` drives the handshake and verifies `SSL_get_verify_result`; normal writes call `SSL_write` at line 372. The application transmit slice is bounded to 16 KiB per call.
- `src/sql/connection.zig:405` `consume_tls` writes ciphertext into the fixed-capacity BIO pair and calls `SSL_read` at line 415 with an 8192-byte stack plaintext array. BIO/session storage allocated at startup does not replace BoringSSL record storage.
- `src/crypto/tls_client.zig:56-59` sets both protocol bounds to TLS 1.3. Lines 63-67 load the supplied CA and enable peer verification; lines 154-156 require name verification. SQL supplies the verified PostgreSQL session protocol without HTTP ALPN.
- `ssl/ssl_lib.cc:948` `SSL_write` invokes the TLS method's `write_app_data`. `ssl/s3_pkt.cc:38` `tls_write_app_data` calls `do_tls_write`; `do_tls_write` at line 194 calls `write_buffer.EnsureCap` before sealing and flushing.
- `ssl/ssl_lib.cc:833` `ssl_read_impl` opens application data and calls `ssl_handle_open_record`; `ssl/ssl_buffer.cc:205` handles partial records by extending the read buffer. `ssl_read_buffer_extend_to` at line 164 calls `DiscardConsumed` and `EnsureCap` before reading the ciphertext.

All BoringSSL paths above refer to revision `d3bf4795ad5b79d646cddf2fec687da5b9b502db`, Zig package `N-V-__8AAA5Ieg5843crc8uXWdNhmmfStwJqA-9TknJSx3_n`. Archived source snapshots and hashes pin the inspected contents.

## Allocation lifetime

`ssl/internal.h:1041` defines `SSLBuffer`, with only a five-byte `SSL3_RT_HEADER_LENGTH` inline array at line 1090. `ssl/ssl_buffer.cc:49` `EnsureCap` uses that inline array for the record header, then directly calls `malloc(new_cap + SSL3_ALIGN_PAYLOAD - 1)` at line 72 for larger buffers. The implementation explicitly bypasses `OPENSSL_malloc`. `Clear` at line 39 frees external storage and resets capacity. Empty `DiscardConsumed` at line 113 calls `Clear`; `tls_write_buffer_flush` at line 258 calls `Clear` after flush at line 268. Therefore preallocating a BIO or warming up a session does not retain these record buffers for subsequent queries.

The measured return PC for both malloc calls per TLS query is `0x14e4f1c`. Resolving PC minus one in the archived non-PIE ELF binary gives `bssl::SSLBuffer::EnsureCap(unsigned long, unsigned long)`, `ssl/ssl_buffer.cc:72`. This directly attributes the allocation entry point. The source read/write paths explain why both directions can allocate; the experiment does not independently label each of the two calls as a particular wire record.

## Public API search and alternatives

The inspected pinned public `include/openssl/ssl.h` and `include/openssl/mem.h` surface exposes no suitable supported per-session caller-owned record-buffer or allocator override found by this audit. `SSL_CTX_set1_buffer_pool` at `ssl.h:769` pools certificates, not transport records. Replacing `OPENSSL_malloc` would not intercept the raw malloc in `SSLBuffer` anyway. This is a scoped source finding, not a proof about every possible future backend.

The glibc interposer is instrumentation only: it changes process allocator symbols and uses thread-local hidden state, so it is not a production workaround. This audit proposes no new TLS record layer, key-material handoff, vendor patch/overlay, dependency pin change, or weakened verification. The truthful release choices are a separately approved, narrowly documented exception or keeping the strict requirement failed until a supported design meets it. Plaintext control results do not substitute for verified TLS.

## Measurement boundary and limitations

The test-only probe uses the public SQL backend with one in-flight query, one application worker, eight initialized pool sockets, sixteen warmups, and 256 measured cached prepared queries. It waits for `Db.ready()` before any warmup. The statement is `SELECT id, randomnumber FROM World WHERE id=$1`, parameter int4 1; it validates one row with id 1 and an int4 randomnumber. Credentials, URL strings, runtime trust certificates and keys are not archived.

Each scope starts immediately before `Db.query` and ends at the start of the completion callback, before row validation and output. `src/sql/db.zig:225` executes the connection before the begin trace hook at line 233, so the instrumentation deliberately does not use that late trace hook as its start marker. One in-flight request avoids overlapping scopes. Handshake, authentication, initial statement preparation and warmup, app initialization and teardown, result validation, CSV output and summary printing are excluded.

The wrapper counts malloc, calloc, realloc and non-null free calls on the query's worker thread, sums requested bytes, and forwards directly to glibc's corresponding __libc entry points. Its in-binary self-test checks malloc(17), calloc(3,5), realloc(31), and two frees for 63 requested bytes before app initialization; a successful probe cannot bypass this check. Builtin elimination is disabled for those functions, and the final ELF symbol table confirms the wrapper definitions. Requested bytes are not resident memory or peak retained memory.

Counters do not cover allocations on other threads, direct mmap/aligned allocation entry points, or calls outside the explicit query scopes. These limits cannot invalidate the positive malloc evidence. They do prevent treating a zero control as proof of all-process, all-API zero allocation. Buffered cleanup can fall outside a scope; the measured two non-null frees per query are simply the observed count. Counts and sizes apply to this fixed query/fixture, not all workloads. Post-handshake KeyUpdate/tickets, errors, reconnects and larger/fragmented responses were not separately forced. No throughput or latency comparison is asserted.
