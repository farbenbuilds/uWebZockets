# Reproduction

This archive includes the measured Linux x86_64/glibc non-PIE executable, its test-only wrapper/probe sources, raw CSVs, output logs, source snapshots and checksums. `verify.py --resolve` verifies checksums and the captured result, and resolves the recorded malloc return PC in the included executable. Verification succeeds when the recorded evidence is consistent; the strict allocation gate remains FAILED.

```
python3 verify.py --resolve
```

`python3 verify.py --enforce-zero` additionally enforces strict zero allocation and intentionally exits 1 on this captured evidence. The archived `strict-gate-exit-status.json` records this actual gate invocation and exit code.

To rerun, provide a PostgreSQL 17 instance on 127.0.0.1:55432 with database/user `uwz_test`. Both password-authenticated plaintext development connections and verified TLS connections must reach the same database. Supply an ephemeral CA trusted by the client and a server certificate with DNS SAN `localhost`. Keep runtime trust material and credentials outside this archive. Create `World(id integer PRIMARY KEY, randomnumber integer NOT NULL)` with a row whose id is 1. The randomnumber may be any int4. The probe checks exactly one matching row. No fixture administration is performed by the runner.

Create a private environment file containing `POSTGRES_PASSWORD=...` (or `PGPASSWORD=...`) without echoing it. Run:

```
python3 run_probe.py --binary bin/sql_tls_allocation_probe \
  --credential-file /private/path/fixture.env \
  --ca-file /private/path/ca.pem --output /tmp/sql-allocation-rerun
```

The runner sets host/port/user/database explicitly, toggles only plaintext versus verified TLS, and does not print or copy credentials or trust material. Its successful output confirms both executable invocations returned zero, including the executable's allocation-interposer self-test. Do not pass a production database: the fixture uses loopback test names and a fixed read query.

To rebuild the executable, use Zig 0.16.0 and a repository working tree matching `source-files.sha256` and the pinned dependencies in the archived `snapshots/project/build.zig.zon`. This was a dirty v2.3 implementation working tree, so the HEAD identifier alone does not identify all SQL source. The targeted snapshots explain the relevant boundary; the full repository/dependency source is not duplicated in the archive. Verify the source checksums against that working tree before rebuilding.

```
python3 prepare_build.py /absolute/path/to/matching/uWebZockets
ZIG_GLOBAL_CACHE_DIR=/tmp/sql-allocation-zig-cache zig build \
  -Doptimize=ReleaseSafe -j2 --summary all
python3 run_probe.py --binary zig-out/bin/sql_tls_allocation_probe \
  --credential-file /private/path/fixture.env \
  --ca-file /private/path/ca.pem --output /tmp/sql-allocation-rerun
```

`prepare_build.py` changes only this extracted temporary consumer's path dependency. BoringSSL and the other native libraries compile through the repository's Zig build graph. Do not modify production code, dependency caches, allocator policy or TLS verification to run the probe. The recorded return PC is specific to the included binary; rebuilding may change addresses, so resolve newly captured return PCs with that rebuilt binary rather than forcing the recorded address assertion.

The initial measurement build used `ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache`, `zig build -Doptimize=ReleaseSafe -j2 --summary all`, and a `/tmp/uwz_tls_alloc_audit` path consumer. `build-final.log` records the successful build. Python, readelf and addr2line are evidence tooling only, not library build dependencies.
