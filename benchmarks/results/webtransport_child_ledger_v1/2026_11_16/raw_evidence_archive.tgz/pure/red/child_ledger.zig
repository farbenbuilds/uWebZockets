const std = @import("std");

/// Native receive facts; unknown sizes stay absent rather than becoming zero.
pub const ReceiveSnapshot = struct {
    final_size: ?u64 = null,
    reliable_size: ?u64 = null,
    reset_error: ?u64 = null,
    reset_visible: bool = false,
    stop_error: ?u64 = null,
    fin_received: bool = false,
    read_cancelled: bool = false,
};

/// Final gaps are a subset of accounted bytes, never another amount to add.
pub const AccountingDelta = struct {
    accounted_bytes: u64 = 0,
    final_gap_bytes: u64 = 0,
};

pub const ReceiveTerminal = enum(u8) { none, eof, reset };
pub const CloseState = enum(u8) { final_known, abandoned };
pub const LedgerError = error{
    InvalidSnapshot,
    InvalidPrefix,
    FinalSizeChanged,
    FinalSizeBelowRead,
    FinalSizeBelowPrefix,
    ErrorCodeChanged,
    SizeOverflow,
    ReceiveComplete,
    IncompleteEof,
    Closed,
};

pub fn snapshot_valid(snapshot: ReceiveSnapshot) bool {
    _ = snapshot;
    return false;
}

/// Caller-owned receive accounting; initialize before observing native facts.
pub const Ledger = struct {
    receive_prefix_size: u8,
    payload_read: u64 = 0,
    accounted_bytes: u64 = 0,
    final_size: ?u64 = null,
    final_payload_size: ?u64 = null,
    reliable_size: ?u64 = null,
    reset_error: ?u64 = null,
    stop_error: ?u64 = null,
    reset_visible: bool = false,
    fin_received: bool = false,
    read_cancelled: bool = false,
    receive_terminal: ReceiveTerminal = .none,
    stop_delivered: bool = false,
    closed: bool = false,

    pub fn init(receive_prefix_size: u8) LedgerError!Ledger {
        return .{ .receive_prefix_size = receive_prefix_size };
    }

    pub fn record_read(ledger: *Ledger, payload_bytes: u64) LedgerError!AccountingDelta {
        _ = ledger;
        _ = payload_bytes;
        return .{};
    }

    pub fn observe(ledger: *Ledger, snapshot: ReceiveSnapshot) LedgerError!AccountingDelta {
        _ = ledger;
        _ = snapshot;
        return .{};
    }

    pub fn take_reset(ledger: *Ledger) ?u64 {
        _ = ledger;
        return null;
    }

    pub fn take_stop(ledger: *Ledger) ?u64 {
        _ = ledger;
        return null;
    }

    pub fn record_eof(ledger: *Ledger) LedgerError!bool {
        _ = ledger;
        return false;
    }

    pub fn close(ledger: *Ledger) CloseState {
        _ = ledger;
        return .abandoned;
    }
};
