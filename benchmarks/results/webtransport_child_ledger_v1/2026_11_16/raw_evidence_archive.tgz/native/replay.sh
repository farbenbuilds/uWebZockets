#!/bin/sh
set -eu
ulimit -c 0
uwz_ledger_checkpoint=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
uwz_ledger_zig=${UWZ_LEDGER_ZIG:-/tmp/zig-x86_64-linux-0.16.0/zig}
uwz_ledger_source=${UWZ_LEDGER_LSQUIC_SOURCE:-/tmp/uwz-lsquic-wt-streams-20261113}
uwz_ledger_packages=${UWZ_LEDGER_PACKAGE_DIR:-/tmp/uwz-lsquic-uni-harness/zig-pkg}
uwz_ledger_cache=${UWZ_LEDGER_GLOBAL_CACHE:-/tmp/uwz-uni-global-cache}
cd "$uwz_ledger_checkpoint/harness"
if test "$#" -eq 0; then
    set -- Debug ReleaseSafe ReleaseFast
fi
for uwz_ledger_mode in "$@"; do
    case "$uwz_ledger_mode" in
        Debug|ReleaseSafe|ReleaseFast) ;;
        *) printf '%s\n' "unsupported mode: $uwz_ledger_mode" >&2; exit 2 ;;
    esac
    ZIG_GLOBAL_CACHE_DIR="$uwz_ledger_cache" "$uwz_ledger_zig" build test \
        --system "$uwz_ledger_packages" \
        -Doptimize="$uwz_ledger_mode" -Dlsquic-source="$uwz_ledger_source" \
        -j2 --summary all
done
