# Child receive-ledger checkpoint

The six functional native cases in `harness/tests/ledger_native.zig` pass in
Debug, ReleaseSafe and ReleaseFast. This is actual native HTTP/TLS over bounded
encrypted in-memory packet queues, with the inherited synthetic native clock.
It does not use UDP, libxev or the project's Engine/App, and does not establish
public child I/O, positive App child delivery or independent-client support.
The pure ledger's separate twelve-case cohort and Root's checks belong to the
combined handoff; their results are not added to this six-case count.

The exact project copies are `harness/project/backend.zig` (c09ae489...) and
`harness/project/child_ledger.zig` (95c45beb...). The copied namespace only keeps
the real translated C types and ledger snapshot type shared. No fork source or
production pin was changed. The native source is frozen clean commit
2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c; full tracked native input hashes are in
`harness/provenance/native_source_inputs.sha256`. Supply that complete source
snapshot from the separate native-candidate archive linked by the combined
handoff, or the identical clean checkout when
replaying. Dependency URLs and Zig hashes remain in `harness/build.zig.zon`.
No libxev source snapshot is needed by this profile; the recorded XEV identity
is explicitly unused.

All three final modes use compiled-source manifest SHA-256
2ac9f46db7cb2aab73ba3d93dc903d946b627b24693f67e4e2d3cf8c7c54ffcf.
The authoritative final logs and source checks are in `harness/provenance/`.
`harness/README.md` explains each proof, pointer lifetime and the exact limits;
`harness/provenance/history.md` retains the intended missing-adapter compile
RED, two environment-only failures, the fixture-finalization failure, and the
later review correction. Earlier logs retain their original meaning.
The README was replaced only after the final modes terminated, so the final
archived manifest includes newer documentation without rewriting run manifests.

Run `sh replay.sh Debug` (or ReleaseSafe/ReleaseFast); omit the mode to run all
three. Replay requires Zig 0.16.0, the exact native source and populated immutable
BoringSSL/qpack/hpack/zlib package inputs. The script accepts explicit paths and
disables package fetching. It uses a writable cache and disables core dumps.
The archive contains source, logs, licenses and manifests; no caches, libraries,
executables, runtime TLS-key files or external symlinks are included. Dedicated
smoke, security, sanitizer and fuzz campaigns remain deferred.
