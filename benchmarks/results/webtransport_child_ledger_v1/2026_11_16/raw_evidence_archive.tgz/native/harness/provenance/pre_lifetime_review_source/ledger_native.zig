const std = @import("std");
const c = @import("c");
const project = @import("project");
const backend = project.backend;
const ledger = project.child_ledger;
const testing = std.testing;

const payload = [_]u8{ 0x41, 0, 0xff, 'r', 'a', 'w', 0x54, 0x40, 0, 0xfe };
const max_steps = 20000;

/// Copies evidence only while the native fixture owns a valid callback pointer.
const ChildObservation = struct {
    id: u64 = 0,
    info: backend.StreamInfo = .{},
    receive: ?ledger.Ledger = null,
    last_snapshot: backend.ReceiveSnapshot = .{},
    close_snapshot: backend.ReceiveSnapshot = .{},
    close_state: ?ledger.CloseState = null,
    bytes: [128]u8 = @splat(0),
    received: usize = 0,
    typed_calls: usize = 0,
    data_calls: usize = 0,
    eof_calls: usize = 0,
    reset_calls: usize = 0,
    stop_calls: usize = 0,
    close_calls: usize = 0,
    accounted_delta: u64 = 0,
    gap_delta: u64 = 0,
    data_before_terminal: bool = false,
    fin_known_before_eof: bool = false,
};

/// One pair has at most eight native fixture stream contexts per endpoint.
const Observation = struct {
    children: [8]ChildObservation = @splat(.{}),
    count: usize = 0,
    failure: ?anyerror = null,
};

fn child_by_id(observation: *Observation, id: u64) ?*ChildObservation {
    for (observation.children[0..observation.count]) |*child| {
        if (child.id == id) return child;
    }
    return null;
}

fn observe_snapshot(child: *ChildObservation, native: ?*c.lsquic_stream) !void {
    var snapshot: backend.ReceiveSnapshot = .{};
    try testing.expectEqual(backend.QueryResult.ok, backend.read_receive(native, &snapshot));
    const delta = try child.receive.?.observe(snapshot);
    child.accounted_delta += delta.accounted_bytes;
    child.gap_delta += delta.final_gap_bytes;
    child.last_snapshot = snapshot;
}

fn observe_native(observation: *Observation, id: u64, event: c.enum_uwz_wt_event, native: ?*c.lsquic_stream, bytes: [*c]const u8, size: usize) !void {
    if (event == c.UWZ_WT_EVENT_TYPED) {
        try testing.expect(child_by_id(observation, id) == null);
        try testing.expect(observation.count < observation.children.len);
        const child = &observation.children[observation.count];
        try testing.expectEqual(backend.QueryResult.ok, backend.read_stream(native, &child.info));
        try testing.expectEqual(backend.Association.child, child.info.association);
        try testing.expectEqual(backend.Initiator.peer, child.info.initiator);
        child.id = id;
        child.receive = try ledger.Ledger.init(child.info.receive_prefix_size);
        child.typed_calls = 1;
        observation.count += 1;
        try observe_snapshot(child, native);
        return;
    }
    const child = child_by_id(observation, id) orelse return;
    if (event == c.UWZ_WT_EVENT_DATA) {
        try testing.expect(bytes != null and size > 0);
        try testing.expect(size <= child.bytes.len - child.received);
        try testing.expectEqual(ledger.ReceiveTerminal.none, child.receive.?.receive_terminal);
        child.data_before_terminal = true;
        const delta = try child.receive.?.record_read(size);
        child.accounted_delta += delta.accounted_bytes;
        child.gap_delta += delta.final_gap_bytes;
        @memcpy(child.bytes[child.received..][0..size], bytes[0..size]);
        child.received += size;
        child.data_calls += 1;
    }
    try observe_snapshot(child, native);
    if (event == c.UWZ_WT_EVENT_DATA and child.last_snapshot.fin_received) {
        try testing.expectEqual(ledger.ReceiveTerminal.none, child.receive.?.receive_terminal);
        child.fin_known_before_eof = true;
    }
    if (event == c.UWZ_WT_EVENT_EOF) {
        try testing.expect(try child.receive.?.record_eof());
        child.eof_calls += 1;
        try testing.expect(!(try child.receive.?.record_eof()));
    }
    if (event == c.UWZ_WT_EVENT_RESET) {
        try testing.expectEqual(@as(?u64, 373), child.receive.?.take_reset());
        child.reset_calls += 1;
        try testing.expectEqual(@as(?u64, null), child.receive.?.take_reset());
    }
    if (event == c.UWZ_WT_EVENT_STOP) {
        try testing.expectEqual(@as(?u64, 0x100), child.receive.?.take_stop());
        child.stop_calls += 1;
        try testing.expectEqual(@as(?u64, null), child.receive.?.take_stop());
    }
    if (event == c.UWZ_WT_EVENT_CLOSE) {
        child.close_snapshot = child.last_snapshot;
        child.close_state = child.receive.?.close();
        child.close_calls += 1;
    }
}

fn native_observer(context: ?*anyopaque, role: c.enum_uwz_wt_role, id: u64, event: c.enum_uwz_wt_event, native: ?*c.lsquic_stream, bytes: [*c]const u8, size: usize) callconv(.c) void {
    if (role != c.UWZ_WT_SERVER or context == null) return;
    const observation: *Observation = @ptrCast(@alignCast(context.?));
    if (observation.failure != null) return;
    observe_native(observation, id, event, native, bytes, size) catch |err| {
        observation.failure = err;
    };
}

fn checked(observation: *const Observation) !void {
    if (observation.failure) |err| return err;
}

fn pump(fixture: *c.struct_uwz_wt_fixture, observation: *const Observation) !void {
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_pump(fixture, 1));
    try checked(observation);
}

fn create_pair(observation: *Observation) !*c.struct_uwz_wt_fixture {
    const fixture = c.uwz_wt_fixture_create(null, null) orelse return error.FixtureInitialization;
    errdefer c.uwz_wt_fixture_destroy(fixture);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_observe(fixture, native_observer, observation));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_connect(fixture));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_handshake(fixture));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_open_connect(fixture));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_await_headers(fixture, c.UWZ_WT_SERVER));
    try testing.expectEqual(backend.CreateResult.ok, backend.accept_connect(c.uwz_wt_fixture_stream(fixture, c.UWZ_WT_SERVER, 0)));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_send_success(fixture));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_await_headers(fixture, c.UWZ_WT_CLIENT));
    try testing.expectEqual(backend.CreateResult.ok, backend.accept_connect(c.uwz_wt_fixture_stream(fixture, c.UWZ_WT_CLIENT, 0)));
    try checked(observation);
    return fixture;
}

fn open_child(fixture: *c.struct_uwz_wt_fixture, observation: *Observation, direction: backend.Direction) !u64 {
    try testing.expectEqual(backend.CreateResult.ok, backend.create_child(c.uwz_wt_fixture_connection(fixture, c.UWZ_WT_CLIENT), 0, direction));
    const outgoing = c.uwz_wt_fixture_last_child(fixture, c.UWZ_WT_CLIENT) orelse return error.NoOutgoingChild;
    const id = c.lsquic_stream_id(outgoing);
    for (0..max_steps) |_| {
        if (child_by_id(observation, id)) |child| {
            try testing.expectEqual(direction, child.info.direction);
            try testing.expectEqual(@as(u8, 3), child.info.receive_prefix_size);
            try testing.expectEqual(@as(u8, 0), child.info.send_prefix_size);
            try testing.expectEqual(@as(u64, 0), child.info.session_id);
            return id;
        }
        try pump(fixture, observation);
    }
    return error.TypedChildTimeout;
}

fn native_child(fixture: *c.struct_uwz_wt_fixture, role: c.enum_uwz_wt_role, id: u64) !*c.lsquic_stream {
    return c.uwz_wt_fixture_stream(fixture, role, id) orelse error.NativeChildClosed;
}

fn await_received(fixture: *c.struct_uwz_wt_fixture, observation: *Observation, id: u64, size: usize) !void {
    for (0..max_steps) |_| {
        if (child_by_id(observation, id).?.received == size) return;
        try pump(fixture, observation);
    }
    return error.PayloadTimeout;
}

fn await_close(fixture: *c.struct_uwz_wt_fixture, observation: *Observation, id: u64) !void {
    for (0..max_steps) |_| {
        if (child_by_id(observation, id).?.close_calls == 1) return;
        try pump(fixture, observation);
    }
    return error.CloseTimeout;
}

fn assert_close_snapshot(fixture: *c.struct_uwz_wt_fixture, child: *const ChildObservation) !void {
    var native: c.struct_uwz_wt_stream_snapshot = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_stream_snapshot(fixture, c.UWZ_WT_SERVER, child.id, &native));
    try testing.expectEqual(@as(c_uint, 1), native.close_callbacks);
    try testing.expectEqual(@as(c_int, c.LSQUIC_SRG_OK), native.close_receive_result);
    try testing.expectEqual(backend.QueryResult.ok, @as(backend.QueryResult, if (native.close_info_result == c.LSQUIC_WTS_OK) .ok else .invalid));
    try testing.expectEqual(child.close_snapshot.final_size != null, native.close_receive.flags & c.LSQUIC_SRS_FINAL_SIZE_KNOWN != 0);
    if (child.close_snapshot.final_size) |final| {
        try testing.expectEqual(final, native.close_receive.final_size);
        try testing.expectEqual(child.close_snapshot.reliable_size.?, native.close_receive.reliable_size);
    }
    try testing.expectEqual(@as(usize, 1), child.close_calls);
    try testing.expect(child.receive.?.closed);
    try testing.expect(c.uwz_wt_fixture_stream(fixture, c.UWZ_WT_SERVER, child.id) == null);
}

fn finish_child(fixture: *c.struct_uwz_wt_fixture, observation: *Observation, id: u64) !void {
    const server = try native_child(fixture, c.UWZ_WT_SERVER, id);
    try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_close(server));
    if (child_by_id(observation, id).?.info.direction == .bidi) {
        if (c.uwz_wt_fixture_stream(fixture, c.UWZ_WT_CLIENT, id)) |client| {
            try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_close(client));
        }
    }
    try await_close(fixture, observation, id);
    try assert_close_snapshot(fixture, child_by_id(observation, id).?);
    var peer: c.struct_uwz_wt_stream_snapshot = undefined;
    for (0..max_steps) |_| {
        try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_stream_snapshot(fixture, c.UWZ_WT_CLIENT, id, &peer));
        if (peer.close_callbacks == 1) break;
        try pump(fixture, observation);
    }
    try testing.expectEqual(@as(c_uint, 1), peer.close_callbacks);
    try testing.expect(c.uwz_wt_fixture_connection(fixture, c.UWZ_WT_SERVER) != null);
    try testing.expect(c.uwz_wt_fixture_stream(fixture, c.UWZ_WT_SERVER, 0) != null);
}

fn payload_and_fin(direction: backend.Direction) !void {
    var observation: Observation = .{};
    const fixture = try create_pair(&observation);
    defer c.uwz_wt_fixture_destroy(fixture);
    const id = try open_child(fixture, &observation, direction);
    const outgoing = try native_child(fixture, c.UWZ_WT_CLIENT, id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_write(outgoing, &payload, payload.len, 1));
    const child = child_by_id(&observation, id).?;
    for (0..max_steps) |_| {
        if (child.eof_calls == 1) break;
        try pump(fixture, &observation);
    }
    try testing.expectEqual(@as(usize, 1), child.eof_calls);
    try testing.expectEqualSlices(u8, &payload, child.bytes[0..child.received]);
    try testing.expect(child.data_before_terminal and child.fin_known_before_eof);
    try testing.expectEqual(@as(u64, payload.len), child.receive.?.payload_read);
    try testing.expectEqual(@as(u64, payload.len), child.receive.?.accounted_bytes);
    try testing.expectEqual(@as(?u64, payload.len + 3), child.receive.?.final_size);
    try testing.expectEqual(@as(?u64, payload.len), child.receive.?.final_payload_size);
    try testing.expectEqual(@as(u64, payload.len), child.accounted_delta);
    try testing.expectEqual(ledger.ReceiveTerminal.eof, child.receive.?.receive_terminal);
    try finish_child(fixture, &observation, id);
    try testing.expectEqual(ledger.CloseState.final_known, child.close_state.?);
}

test "native incoming UNI excludes prefix and records EOF only after read zero" {
    try payload_and_fin(.uni);
}

test "native incoming BIDI excludes prefix and records EOF only after read zero" {
    try payload_and_fin(.bidi);
}

test "native hidden reliable RESET accounts unread final tail once then publishes error once" {
    var observation: Observation = .{};
    const fixture = try create_pair(&observation);
    defer c.uwz_wt_fixture_destroy(fixture);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_pause_reads(fixture, c.UWZ_WT_SERVER, 1));
    const id = try open_child(fixture, &observation, .uni);
    const outgoing = try native_child(fixture, c.UWZ_WT_CLIENT, id);
    try testing.expectEqual(@as(isize, payload.len), c.lsquic_stream_write(outgoing, &payload, payload.len));
    try testing.expectEqual(@as(c_int, c.LSQUIC_SRA_OK), c.lsquic_stream_reset_at(outgoing, 373, 7));
    const incoming = try native_child(fixture, c.UWZ_WT_SERVER, id);
    const child = child_by_id(&observation, id).?;
    for (0..max_steps) |_| {
        var snapshot: backend.ReceiveSnapshot = .{};
        try testing.expectEqual(backend.QueryResult.ok, backend.read_receive(incoming, &snapshot));
        if (snapshot.reset_error != null) break;
        try pump(fixture, &observation);
    }
    try observe_snapshot(child, incoming);
    try testing.expectEqual(@as(?u64, payload.len + 3), child.last_snapshot.final_size);
    try testing.expectEqual(@as(?u64, 7), child.last_snapshot.reliable_size);
    try testing.expectEqual(@as(?u64, 373), child.last_snapshot.reset_error);
    try testing.expect(!child.last_snapshot.reset_visible and !child.last_snapshot.fin_received);
    try testing.expectEqual(@as(u64, 0), child.receive.?.payload_read);
    try testing.expectEqual(@as(u64, payload.len), child.receive.?.accounted_bytes);
    try testing.expectEqual(@as(u64, payload.len), child.gap_delta);
    try testing.expectEqual(@as(?u64, null), child.receive.?.take_reset());
    try observe_snapshot(child, incoming);
    try testing.expectEqual(@as(u64, payload.len), child.accounted_delta);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_enable_reads(incoming));
    for (0..max_steps) |_| {
        if (child.reset_calls == 1) break;
        try pump(fixture, &observation);
    }
    try testing.expectEqual(@as(usize, 1), child.reset_calls);
    try testing.expectEqual(@as(usize, 0), child.eof_calls);
    try testing.expectEqualSlices(u8, payload[0..4], child.bytes[0..child.received]);
    try testing.expectEqual(@as(u64, 4), child.receive.?.payload_read);
    try testing.expectEqual(@as(u64, payload.len), child.accounted_delta);
    try testing.expectEqual(@as(u64, payload.len), child.receive.?.accounted_bytes);
    try testing.expectEqual(ledger.ReceiveTerminal.reset, child.receive.?.receive_terminal);
    try finish_child(fixture, &observation, id);
    try testing.expectEqual(ledger.CloseState.final_known, child.close_state.?);
}

test "native STOP has unknown receive final until a later peer FIN" {
    var observation: Observation = .{};
    const fixture = try create_pair(&observation);
    defer c.uwz_wt_fixture_destroy(fixture);
    const id = try open_child(fixture, &observation, .bidi);
    const outgoing = try native_child(fixture, c.UWZ_WT_CLIENT, id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_write(outgoing, &payload, payload.len, 0));
    try await_received(fixture, &observation, id, payload.len);
    try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_shutdown(outgoing, 0));
    const child = child_by_id(&observation, id).?;
    for (0..max_steps) |_| {
        if (child.stop_calls == 1) break;
        try pump(fixture, &observation);
    }
    try testing.expectEqual(@as(usize, 1), child.stop_calls);
    try testing.expectEqual(@as(?u64, 0x100), child.last_snapshot.stop_error);
    try testing.expectEqual(@as(?u64, null), child.last_snapshot.final_size);
    try testing.expectEqual(@as(usize, 0), child.close_calls);
    try testing.expect(!child.receive.?.closed);
    try testing.expectEqual(ledger.ReceiveTerminal.none, child.receive.?.receive_terminal);
    try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_shutdown(outgoing, 1));
    for (0..max_steps) |_| {
        if (child.eof_calls == 1) break;
        try pump(fixture, &observation);
    }
    try testing.expectEqual(@as(usize, 1), child.eof_calls);
    try testing.expectEqual(@as(usize, 1), child.stop_calls);
    try testing.expectEqual(@as(?u64, payload.len + 3), child.receive.?.final_size);
    try finish_child(fixture, &observation, id);
    try testing.expectEqual(ledger.CloseState.final_known, child.close_state.?);
}

test "native local read cancellation retains close until actual receive final" {
    var observation: Observation = .{};
    const fixture = try create_pair(&observation);
    defer c.uwz_wt_fixture_destroy(fixture);
    const id = try open_child(fixture, &observation, .bidi);
    const outgoing = try native_child(fixture, c.UWZ_WT_CLIENT, id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_write(outgoing, &payload, payload.len, 0));
    try await_received(fixture, &observation, id, payload.len);
    const incoming = try native_child(fixture, c.UWZ_WT_SERVER, id);
    const child = child_by_id(&observation, id).?;
    try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_close(incoming));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_process_role(fixture, c.UWZ_WT_SERVER, 20));
    try checked(&observation);
    try observe_snapshot(child, incoming);
    try testing.expect(child.last_snapshot.read_cancelled);
    try testing.expectEqual(@as(?u64, null), child.last_snapshot.final_size);
    try testing.expectEqual(@as(usize, 0), child.close_calls);
    try testing.expect(!child.receive.?.closed);
    try testing.expectEqual(incoming, try native_child(fixture, c.UWZ_WT_SERVER, id));
    try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_shutdown(outgoing, 1));
    try await_close(fixture, &observation, id);
    try assert_close_snapshot(fixture, child);
    try testing.expectEqual(@as(?u64, payload.len + 3), child.close_snapshot.final_size);
    try testing.expectEqual(ledger.CloseState.final_known, child.close_state.?);
}

test "native connection abort closes child with explicit unknown final size" {
    var observation: Observation = .{};
    const fixture = try create_pair(&observation);
    defer c.uwz_wt_fixture_destroy(fixture);
    const id = try open_child(fixture, &observation, .uni);
    const outgoing = try native_child(fixture, c.UWZ_WT_CLIENT, id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_write(outgoing, &payload, payload.len, 0));
    try await_received(fixture, &observation, id, payload.len);
    const child = child_by_id(&observation, id).?;
    try testing.expectEqual(@as(?u64, null), child.last_snapshot.final_size);
    c.lsquic_conn_abort(c.uwz_wt_fixture_connection(fixture, c.UWZ_WT_SERVER));
    try await_close(fixture, &observation, id);
    try assert_close_snapshot(fixture, child);
    try testing.expectEqual(@as(?u64, null), child.close_snapshot.final_size);
    try testing.expectEqual(@as(?u64, null), child.close_snapshot.reliable_size);
    try testing.expectEqual(ledger.CloseState.abandoned, child.close_state.?);
    try testing.expectEqual(@as(u64, payload.len), child.receive.?.accounted_bytes);
    try testing.expectEqual(@as(usize, 0), child.eof_calls);
    try testing.expectEqual(@as(usize, 0), child.reset_calls);
}
