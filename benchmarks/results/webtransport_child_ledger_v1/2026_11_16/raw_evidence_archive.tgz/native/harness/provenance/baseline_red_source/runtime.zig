const std = @import("std");
const boringssl = @import("vendor/boringssl.zig");
const lsquic = @import("vendor/lsquic.zig");
const sanitizers = @import("sanitizers.zig");
const zlib = @import("vendor/zlib.zig");

pub fn configure(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const sanitizer = sanitizers.configure(b, target, true);
    const bssl = boringssl.build(b, target, optimize, sanitizer);
    const z = zlib.build(b, target, optimize, sanitizer);
    const ls = lsquic.build(b, target, optimize, sanitizer, bssl, z, true, false, false);
    const backend_path = b.option([]const u8, "backend-source", "Repository backend source under test") orelse
        "/home/foo/Desktop/Repos/uWebZockets/src/quic/webtransport/backend.zig";
    const component_tests_path = b.option([]const u8, "component-tests-source", "Repository centralized backend component tests") orelse
        "/home/foo/Desktop/Repos/uWebZockets/src/tests/webtransport_runtime_tests.zig";
    const native_tests_path = b.option([]const u8, "native-tests-source", "Scratch native ledger test driver") orelse
        "tests/ledger_native.zig";

    const translate = b.addTranslateC(.{
        .root_source_file = b.path("fixtures/c.h"),
        .target = target,
        .optimize = optimize,
    });
    translate.addIncludePath(ls.include_root);
    translate.addIncludePath(bssl.include_root);
    translate.addIncludePath(b.path("fixtures"));
    const c_module = translate.createModule();
    const backend = b.createModule(.{
        .root_source_file = .{ .cwd_relative = backend_path },
        .target = target,
        .optimize = optimize,
        .imports = &.{.{ .name = "c", .module = c_module }},
    });
    const module = b.createModule(.{
        .root_source_file = b.path(native_tests_path),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
        .imports = &.{
            .{ .name = "c", .module = c_module },
            .{ .name = "backend", .module = backend },
        },
    });
    const test_support = b.createModule(.{
        .root_source_file = b.path("tests/test_support.zig"),
        .target = target,
        .optimize = optimize,
        .imports = &.{.{ .name = "backend", .module = backend }},
    });
    const component_module = b.createModule(.{
        .root_source_file = .{ .cwd_relative = component_tests_path },
        .target = target,
        .optimize = optimize,
        .link_libc = true,
        .imports = &.{
            .{ .name = "c", .module = c_module },
            .{ .name = "test_support", .module = test_support },
        },
    });
    for ([_]*std.Build.Module{ module, component_module }) |root_module| {
        root_module.addIncludePath(ls.include_root);
        root_module.addIncludePath(bssl.include_root);
        root_module.addIncludePath(ls.assembled_root.path(b, "src/liblsquic"));
        root_module.addIncludePath(ls.assembled_root.path(b, "src/lshpack"));
        root_module.addIncludePath(ls.assembled_root.path(b, "src/liblsquic/ls-qpack"));
        root_module.addIncludePath(b.path("fixtures"));
        root_module.addCSourceFiles(.{
            .files = &.{ "fixtures/uwz_quic_fixture.c", "fixtures/uwz_wt_bridge.c" },
            .flags = sanitizers.instrumented_flags(b, &.{
                "-std=gnu11",
                "-UNDEBUG",
                "-D__wrap_lsquic_time_now=lsquic_time_now",
                "-Wall",
                "-Wextra",
                "-fno-omit-frame-pointer",
            }, sanitizer),
        });
        root_module.linkLibrary(ls.library);
        root_module.linkLibrary(bssl.ssl);
        root_module.linkLibrary(bssl.crypto);
        root_module.linkLibrary(z.library);
        sanitizer.attach(root_module);
    }
    const tests = b.addTest(.{ .name = "uwz_wt_backend_native", .root_module = module });
    const component_tests = b.addTest(.{ .name = "uwz_wt_backend_components", .root_module = component_module });
    const run = sanitizers.add_run_artifact(b, tests, sanitizer.run);
    const component_run = sanitizers.add_run_artifact(b, component_tests, sanitizer.run);
    const test_step = b.step("test", "Run repository backend against real TLS engines");
    test_step.dependOn(&run.step);
    test_step.dependOn(&component_run.step);
    const compile_step = b.step("test-compile", "Compile the real TLS backend tests");
    compile_step.dependOn(&tests.step);
    compile_step.dependOn(&component_tests.step);
    const native_step = b.step("test-native", "Run four real TLS backend driver tests");
    native_step.dependOn(&run.step);
    const component_step = b.step("test-components", "Run six centralized repository tests against the candidate");
    component_step.dependOn(&component_run.step);
    const libraries_step = b.step("libraries", "Compile the exact native dependency graph");
    libraries_step.dependOn(&ls.library.step);
    b.default_step = test_step;
}
