const backend = @import("backend");

test "native receive snapshot adapter exists" {
    _ = backend.read_receive;
}
