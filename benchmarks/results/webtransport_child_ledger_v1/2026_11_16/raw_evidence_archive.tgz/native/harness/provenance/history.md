# Terminal history and source revisions

All runs used the frozen lsquic candidate 2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c.
No candidate/native dependency source was edited. Old harnesses remained frozen.

| Log | Exit | Meaning |
| --- | --- | --- |
| baseline-red-debug.log | 1 | Environment-only: default global cache under the home directory was read-only; compilation did not start. |
| baseline-red-snapshot-debug.log | 1 | Environment-only: top-level cache flag did not propagate through translate-c's subprocess; native libraries compiled, translator failed on the read-only default cache. |
| baseline-red-adapter-debug.log | 1 | Intended compile RED: the frozen pre-feature backend had no read_receive declaration. Actual translation and native graph succeeded. No runtime behavior is inferred. |
| native-first-green-debug.log | 1 | Five of six passed. Hidden-reset protocol/accounting assertions passed, then the scratch finish helper redundantly closed an already reset outgoing UNI and received native EBADF. |
| native-close-fixed-debug.log | 0 | Six of six passed. Outgoing UNI completes its real native close callback; BIDI closes explicitly; peer close exactly once is required. This row precedes the later pointer-lifetime proof fix. |
| native-lifetime-fixed-debug.log | 0 | Final source, six of six passed. |
| native-final-ReleaseSafe.log | 0 | Same final compiled source, six of six passed. |
| native-final-ReleaseFast.log | 0 | Same final compiled source, six of six passed. |

The intended RED uses backend SHA6c60688bc1fa757426853c48e374d6bd9c26cb8e789906a5c1b09773749e6591,
not the later Root implementation. Source snapshots and the original manifests
are retained. The original copied FIN helper also flushed after write shutdown;
the new bridge returns native shutdown's result for FIN and flushes only
non-FIN writes. The frozen older harness was not edited.

Review of the first passing driver found potential stale-pointer queries if a
future native close-retention regression occurred. The corrected driver
reacquires native handles after pumping; its local-cancellation test verifies
zero close callbacks and live identity before querying. STOP/local-cancellation
shutdown calls likewise reacquire handles. No protocol assertion was removed.
The pre-review passing source and its limited proof row remain preserved.
The independent architect accepted the final delta. Final driver SHA:
f149e8015acd521186703c3afc70b923eef9df09fe9c18cad24328037cb51510.

Final compiled-source manifest:
2ac9f46db7cb2aab73ba3d93dc903d946b627b24693f67e4e2d3cf8c7c54ffcf.
It passed before/after checks for Debug, ReleaseSafe and ReleaseFast. No source
was mutated during any build. All authoritative sessions terminated before
README/provenance packaging edits. The final README corrects inherited leaf
claims; this documentation-only change required no repeated passing run.

This is an actual encrypted in-memory HTTP/TLS fixture with a synthetic native
clock. It does not import Root Engine/App or use UDP/xev. Root's production
awake-clock pending-datagram expiry and earlier native App cohorts are separate
evidence. Connection destruction may close without final-size metadata; no
zero final size is invented for that case. All native-pointer queries occur
while fixture ownership or a native callback guarantees validity.
