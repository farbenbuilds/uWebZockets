# Native child receive-ledger cohort

This Zig 0.16.0 scratch harness tests immutable copies of the project's actual
`backend.read_receive` adapter and pure child receive ledger against native
lsquic `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c`.
It changes no production source, dependency pin or native fork source.

The profile uses two actual HTTP/TLS lsquic engines and BoringSSL. The existing
fixture sends real encrypted packets through fixed in-memory queues; it does
not use UDP, libxev, the project's Engine/App, or an independent client.
The inherited native fixture clock is synthetic. Production pending-datagram
expiry's real OS awake clock is not exercised by this cohort.

Six functional tests pass in Debug, ReleaseSafe and ReleaseFast. There is no
import-anchor test and the earlier leaf harness's ten tests are not rerun here.
The copied `tests/backend_native.zig` and `tests/test_support.zig` are retained
baseline references and are not imported by the current driver.

| Case | Actual native observation and ledger proof |
| --- | --- |
| Incoming UNI | Typed metadata has receive prefix 3; raw binary payload excludes it; FIN snapshot alone leaves terminal unset; actual read zero publishes EOF once; final raw size is payload plus 3. |
| Incoming BIDI | The same receive accounting and EOF proof applies to an incoming bidirectional child. |
| Reliable RESET | Server payload reads are paused after real classification. Actual reset final size 13, reliable boundary 7 and error 373 are known while reset is hidden. Initial final accounting charges ten payload bytes; later four actual reads add no duplicate charge; visible reset publishes once, without EOF. |
| STOP then FIN | Actual peer read shutdown produces STOP 0x100 while server receive final size remains absent. The ledger remains open; a later actual peer FIN supplies raw final size 13 and EOF. |
| Local read cancellation | Actual native close cancels reading, but twenty server processing calls with peer processing withheld produce no close callback or final size. Fresh native-pointer checks precede observation. After real peer FIN, native on-close supplies final size 13. |
| Connection abort | Actual connection abort invokes on-close with receive final size still absent; the ledger closes as abandoned and retains only the ten payload bytes actually accounted. |

The fixture's typed/data/EOF/reset/STOP/close observer receives explicit
fixture-owned userdata. It queries the actual adapter and feeds actual read
sizes/snapshots into the pure ledger while each native pointer is valid.
On-close copies both raw native and normalized snapshots before invalidating
the fixture's native pointer. No callbacks, frames, snapshots or native layouts
are fabricated; no production callback is replaced. This cohort covers incoming
client UNI and BIDI. TX and server-initiated child support remain open.

`project/backend.zig` is an exact source copy with SHA-256
`c09ae489eb8af13df09ddf412a40e681103ed0732e01894d728f6c9e4babcca5`;
`project/child_ledger.zig` is an exact source copy with SHA-256
`95c45beb37df0a5468d08b079ae52618939508c6a7a5dfc4079fdec8ed87b496`.
`project/module.zig` only places both files in one module with the same actual
translated C types. Native C/C++ dependencies compile through the copied Zig
helpers with the exact BoringSSL, qpack, hpack and zlib identities in
`build.zig.zon`. Native profile flags are fixture clock enabled, reset-ACK
observer disabled and SETTINGS observer disabled. No libxev source is used.

Run from this directory with the already populated immutable package inputs:

```sh
ulimit -c 0
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-uni-global-cache \
  /tmp/zig-x86_64-linux-0.16.0/zig build test \
  -Doptimize=Debug \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-streams-20261113 -j2 --summary all
```

Use ReleaseSafe or ReleaseFast for the other recorded modes. The sealed
checkpoint's `replay.sh` accepts these modes and supports explicit Zig,
package-directory, cache and native-source paths. It does not require network
access when the exact package inputs are present.

`provenance/native-lifetime-fixed-inputs.sha256` is the unchanged 19-file
compiled-source cohort for the final three modes. The README was replaced
only after all modes terminated; the final archived manifest adds this current
documentation without rewriting the historical run manifest.
`provenance/history.md` preserves environment failures, the intended missing
adapter RED, the first fixture-finalization failure, and the lifetime review
correction. No dedicated smoke, security, sanitizer or fuzz campaign ran.
This evidence does not activate WebTransport or establish positive Engine/App
child delivery, public child APIs, session flow-control integration or external
client interoperability.
