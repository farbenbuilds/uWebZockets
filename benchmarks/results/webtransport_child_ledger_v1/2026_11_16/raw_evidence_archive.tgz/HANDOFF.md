# WebTransport child receive ledger, 2026-11-16

Base project commit: `4ed0fcc2b34eb70f11f42c46222e533f4aba26a5`.
Zig: `/tmp/zig-x86_64-linux-0.16.0/zig` (0.16.0).
Production dependency pins, listener activation, Engine callbacks and App APIs
are unchanged. This is the first receive-accounting foundation for typed
children; it does not implement live child association or App child I/O.

`child_ledger.zig` has no imports, allocator, I/O or clock. The caller supplies
the actual receive-prefix length and copied native facts. Payload reads and
known final size account the maximum exactly once; the final gap is a subset
of the returned accounting delta. Reliable reset metadata can be known before
its error is deliverable. EOF requires an actual native read returning zero,
and STOP remains independent of the receive terminal event. Only native close
or connection destruction closes the ledger; unknown final size is abandoned,
never replaced with zero. Session closure and local read cancellation are not
permission to release a native context while final size is outstanding.

`backend.read_receive` validates native flags, absent values, size/error bounds
and field consistency before assigning output. Failed queries preserve output.
The full optional-contract check includes the required receive flags and
structure fields. The existing admission-cancellation reader is unchanged.

The accounting follows [draft-ietf-webtrans-http3-16 section 5.4](https://www.ietf.org/archive/id/draft-ietf-webtrans-http3-16.html#section-5.4): data limits
exclude the actual stream header and include reset streams' final body size.
The native API distinguishes known final size, RESET visibility, STOP, FIN and
local read cancellation. A FIN flag alone does not mean application EOF.

Reproduce the project checks after restoring the base repository and copying
the complete `root/` source overlay. `provenance/source.sha256` identifies all
297 tracked/new source and build inputs under src/builds/examples/tests/fuzz,
plus build.zig and build.zig.zon. User-owned vendor changes are excluded.

```sh
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache zig build test-unit --global-cache-dir /tmp/uwz-zig-cache --summary all
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache zig build test-compile -Doptimize=ReleaseSafe --global-cache-dir /tmp/uwz-zig-cache --summary all
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache zig build lib -Doptimize=ReleaseFast --global-cache-dir /tmp/uwz-zig-cache --summary all
sh scripts/check_conventions.sh
sh scripts/check_release_version.sh
```

The user deferred smoke and security campaigns. `test-unit` runs the full
centralized functional suite and archive-symbol check. `test-compile` compiles
the default test artifacts, including C smoke, without executing smoke.
No tests, defaults, assertions or thresholds were weakened.

The first full unit invocation ran in the network-restricted sandbox and
stalled in the existing loopback client's `PortSlot.wait`. The retained
explicit-executable backtrace identifies that test, rather than a ledger
transition. Stopping the test caused the runner to start another blocked test;
the owned build tree was then stopped (exit 137). Its initially empty log and
both diagnostic backtraces are retained. The unchanged suite was rerun with
loopback allowed; this is an environment correction, not a skipped test.

Final project results: 1022/1022 centralized tests in 20/20 steps, 27 seconds
at execution; ReleaseSafe test compilation 21/21 steps; ReleaseFast library
21/21 steps. The loopback run retains the same authentication/TLS rejection
diagnostics and io_uring errno-22 diagnostic present in the preceding
1009-test checkpoint; the build reports all tests passed. They are retained
unmodified, not suppressed. Conventions, release version and source inventory
verification passed. Both architecture and independent code review report no
required findings at backend c09ae489... / ledger 95c45beb... / tests a67ddc9b....

The exact formatter command was `zig fmt src builds examples tests fuzz`.
The retained helper temporarily protects nested package caches by same-filesystem
rename and restores them in `finally`; two cache directories were protected.
Formatting changed none of the 297 source/build inputs. All build handles
must be terminal before changing their corresponding source inputs.

`pure/` retains the genuine twelve-failure stub RED and twelve passing cases
in Debug, ReleaseSafe and ReleaseFast. The tiny support module imports the
actual pure project module. To reproduce from the restored project, use:

```sh
zig test -ODebug --dep test_support -Mroot=src/tests/webtransport_child_ledger_tests.zig --dep child_ledger -Mtest_support=/tmp/uwz-child-ledger-tests/test_support.zig -Mchild_ledger=src/quic/webtransport/child_ledger.zig
```

Supply writable local/global caches and restore the small support module at
the recorded path, or adjust only its path. Repeat with `-OReleaseSafe` and
`-OReleaseFast`. The standalone native cohort has a separate profile and does
not replace the project functional suite or independent-client acceptance.

The next integration must attach ledgers to existing global stream sidecars,
retain connection and parent-session generations, classify before HTTP
dispatch, bound and expire early children, and deliver bytes through an
explicit consumer. Supported public App child registration, application TX,
session flow accounting, independent draft-16 client acceptance, dependency
publication/pins and the other v2.3.0 release gates remain open.

The final standalone native cohort passes 6/6 tests and 13/13 build steps in
Debug, ReleaseSafe and ReleaseFast on source manifest
`2ac9f46db7cb2aab73ba3d93dc903d946b627b24693f67e4e2d3cf8c7c54ffcf`.
The reviewed driver is `f149e8015acd521186703c3afc70b923eef9df09fe9c18cad24328037cb51510`.
It uses real paired LSQUIC HTTP/TLS engines and encrypted packets delivered
through bounded in-memory queues, with the inherited synthetic native clock.
There is no UDP/xev/App/Engine integration in this cohort; XEV is not compiled
or used. Known-but-hidden RESET and local-cancel waiting states are established
by real held reads and server-only processing, not fabricated callbacks.
Snapshots queried during actual native close are copied before invalidation.
The complete native scaffold and its provenance are retained under `native/`.
