# Native half-control handoff

Final source commit: `3b4a98dfb60667b1dd431e02d4cffb9a4a19764a`.

Final cohort: **51/51 in Debug, ReleaseSafe and ReleaseFast**, 16/16 build steps
in each mode. The unchanged original37 plus14 new cases are imported by
`tests/half_main.zig`. Contract RED is retained against the prior frozen TX
snapshot; it failed for the missing public STOP declaration. There were no
product or staging failures in the half-control functional iterations.
Initial scope45,48,49 Debug passes are retained separately; final51 source is
identical across the three named final mode logs. Read results.json and
commands.txt for exact commands, status, case counts and log digests.

The fixture source tree is `fixture/`; its relocatable replay checks36 retained
fixture files and257 frozen Root source/build inputs. All33 prior fixture files,
including C helpers, are byte-identical to the previous TX proof. Root inputs
match implementation commit above. Native005 and XEV5b2c remain clean, local
proposals; production dependency pins were not changed.

The new cases manually service the engine via the inherited pump. External
loop-only wake proof belongs to the retained TX case. Native half-control
BLOCKED/INVALID/UNSUPPORTED and actual OS submission failures were not forced.
Dedicated smoke/security/sanitizer/fuzz campaigns remain user-deferred.

No live native build or test process remains; the warm cache is free.
Root owns final repository artifact documentation, archive, and publication.
