# Isolated WebTransport half-control functional proof

The fixture runs the actual App, UDP transport, TLS and lsquic proposal through
public child-stream callbacks. Its final cohort contains the unchanged 37 TX/RX
cases and 14 new local STOP/RESET cases. All limits and prior assertions remain
unchanged. This scratch build's `test` target runs these functional cases; it
does not run the repository's dedicated C smoke target.

The frozen `project_v1` source is equivalent to implementation commit
`3b4a98dfb60667b1dd431e02d4cffb9a4a19764a` for all 257 retained source/build
inputs. `provenance/project_v1_inputs.sha256` hashes those inputs. The separate
`provenance/half51_run_inputs.sha256` hashes 36 retained fixture/build/test files,
including the RED driver. The replay script checks both manifests before building.

## Replay

Use Zig 0.16.0, the unchanged offline Zig packages selected by `build.zig.zon`,
the native005 proposal `005ab244169f269689e511d6b77dd2187e318df1`, and XEV proposal
`5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`. Their native source/history archive is
retained in the repository at
`benchmarks/results/webtransport_child_lifecycle_v1/2026_11_16/raw_evidence_archive.tgz`
(SHA-256 `3e27ce7137f3791cf977d0b4c83bee4ea72c873b1af125c3a13616695b2a8418`).
This archive does not duplicate those external source trees or offline packages.
The native snapshot's ls-hpack gitlink is `cf0f70dd10b352194c97448eb5d00b4aa484f531`;
the actual compiled ls-hpack package is
`fda48e02491d865cce00612be8cc10c2622b8e55`. Actual ls-qpack and its gitlink both use
`91567706c41c0d97ab8dc576873ecd472d7869fa`.

Set the explicit paths below, then choose `Debug`, `ReleaseSafe`, or `ReleaseFast`:

```sh
UWZ_ZIG=/path/to/zig-0.16.0 \
UWZ_LSQUIC_SOURCE=/path/to/native005 \
UWZ_LIBXEV_SOURCE=/path/to/xev5b2c \
UWZ_PACKAGE_DIR=/path/to/offline-zig-packages \
UWZ_CACHE_DIR=/path/to/disposable-cache \
ZIG_GLOBAL_CACHE_DIR=/path/to/disposable-global-cache \
sh replay.sh Debug
```

The command requires loopback socket permission. It compiles all native C/C++
with Zig and makes no dependency publication or production pin change.
`UWZ_PROJECT_SOURCE` optionally selects an equivalent source snapshot.

## New cases

- Local STOP sends the exact mapped maximum-u32 error while binary TX/FIN continues.
- Local RESET sends exact mapped application error zero while later RX bytes/EOF continue.
- Different STOP/RESET codes survive a subsequent whole cancellation.
- A failed Root wake callback changes no native state or accepted intent; identical repeats
  need no second wake, and differing repeats fail.
- Opening, owner, generation, retired handle and peer-UNI direction guards are exercised.
- Accepted FIN cannot be replaced by RESET, and RX continues.
- Reentrant STOP stops after the first 2048-byte chunk of a proven 3072-byte prebuffer,
  suppresses subsequent RX callbacks and retains complete final-size accounting.
- STOP after EOF retains the completed RX observation and allows TX/FIN.
- RESET from data and writable callbacks leaves later RX live and disarms write interest.
- Local STOP preserves independent peer STOP notification.
- Peer-owned TX termination rejects replacement RESET codes without accepting an intent.
- Whole cancellation after only STOP or only RESET fills the missing half and preserves
  the previous half's error.

Every new case checks a healthy HTTP sibling, and inherited observation hooks check
single close ownership. No C fixture source changed from the previous TX cohort.
The new half-control cases explicitly service the engine through the inherited pump;
only the retained TX wake case proves progress from the UDP event loop alone.

## Limits

No actual native BLOCKED, INVALID or UNSUPPORTED half-control return was forced.
Live peer-BIDI RESET uses reliable prefix zero after handshake completion. The Root
wake-callback fault is distinct from an actual OS submit failure. Outgoing child
creation, positive/multi-session flow, independent external-client acceptance and
production dependency activation remain outside this proof. Dedicated smoke,
security, sanitizer and fuzz campaigns remain deferred by the user.

The RED log records the missing public STOP declaration against the frozen previous
TX source (`project_v2`, prior source commit `78fc2d62300c4fdf5cccf57efc3acdb798a1be97`).
The previous TX archive retains that source; it is not duplicated here.
