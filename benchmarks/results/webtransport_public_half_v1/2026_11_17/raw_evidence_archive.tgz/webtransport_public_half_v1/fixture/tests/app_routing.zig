const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const backend = support.webtransport_backend;
const testing = std.testing;

const config = support.config.default_config.with(.{
    .max_connections = 4,
    .max_datagram_size = 1200,
    .datagram_slots = 4,
    .max_h3_response_header_size = 16384,
});
const App = support.builder.configured_builder(config).AppType;

const RouteObservation = struct {
    application: *App,
    authorization_calls: usize = 0,
    datagram_calls: usize = 0,
    http_calls: usize = 0,
    datagram_reentry_returns: usize = 0,
    datagram_callback_depth: usize = 0,
    expected_session: u64 = 0,
    request_cooldown: bool = false,
    cooldown_deferred: bool = false,
    header_index: ?usize = null,
    last_size: usize = 0,
    last_bytes: [128]u8 = undefined,
    failed: bool = false,
};

const SettingsAction = enum { admit, reset, stop };

const DatagramExpectation = struct {
    selected: *const RouteObservation,
    other: *const RouteObservation,
    delivered: bool = true,
};

fn initialize_app() !App {
    return support.builder.Server.builder(testing.io).with_max_clients(4)
        .with_webtransport_datagrams(1200, 4).with_max_h3_response_header_size(16384)
        .build(testing.allocator);
}

fn record_header(observed: *RouteObservation, request: *support.Request) void {
    const pool = &observed.application.quic_transport.?.engine.header_pool;
    const address = @intFromPtr(request.path.ptr);
    for (pool.storage, 0..) |*header, index| {
        if (!pool.is_active(index)) continue;
        const base = @intFromPtr(header.storage.ptr);
        if (address >= base and address - base < header.storage.len) {
            observed.header_index = index;
            return;
        }
    }
    observed.failed = true;
}

fn authorize(context: *anyopaque, request: *support.Request, response: *support.public_api.Response) void {
    const observed: *RouteObservation = @ptrCast(@alignCast(context));
    observed.authorization_calls += 1;
    record_header(observed, request);
    const origin = request.get_unique_header("origin") orelse "";
    const authorization = request.get_unique_header("authorization") orelse "";
    if (!std.mem.eql(u8, origin, "https://localhost") or !std.mem.eql(u8, authorization, "Bearer admission-fixture")) {
        observed.failed = true;
    }
    response.end("200 OK", "") catch {
        observed.failed = true;
    };
}

fn datagram(context: *anyopaque, id: u64, payload: []const u8) void {
    const observed: *RouteObservation = @ptrCast(@alignCast(context));
    observed.datagram_calls += 1;
    const engine = &observed.application.quic_transport.?.engine;
    observed.datagram_callback_depth = engine.callback_depth;
    engine.process();
    observed.datagram_reentry_returns += 1;
    if (observed.request_cooldown) {
        engine.cooldown();
        observed.cooldown_deferred = engine.callback_depth > 0 and engine.cooldown_pending and !engine.in_cooldown;
    }
    if (id != observed.expected_session or payload.len > observed.last_bytes.len) {
        observed.failed = true;
        return;
    }
    @memcpy(observed.last_bytes[0..payload.len], payload);
    observed.last_size = payload.len;
}

fn health(context: *anyopaque, request: *support.Request, response: *support.public_api.Response) void {
    const observed: *RouteObservation = @ptrCast(@alignCast(context));
    observed.http_calls += 1;
    record_header(observed, request);
    if (!std.mem.eql(u8, request.path, "/header-overwrite") or !std.mem.eql(u8, request.body, "healthy-body")) {
        observed.failed = true;
    }
    response.end("200 OK", "healthy-response") catch {
        observed.failed = true;
    };
}

fn listen(application: *App, first: *RouteObservation, second: *RouteObservation) !u16 {
    try application.enable_http3_ephemeral();
    _ = try application.datagram_context("/wt", first, datagram);
    _ = try application.datagram_context("/other", second, datagram);
    _ = try application.route_context(.connect, "/wt", first, authorize);
    _ = try application.route_context(.connect, "/other", second, authorize);
    _ = try application.route_context(.post, "/header-overwrite", first, health);
    try application.listen_udp("127.0.0.1", 0);
    return application.quic_transport.?.local_address.ip4.port;
}

fn destroy_app(application: *App) void {
    if (application.quic_transport) |*transport| {
        transport.shutdown();
        var step: usize = 0;
        while (step < c.UWZ_APP_MAX_STEPS and !transport.is_drained()) : (step += 1) {
            application.loop.get_xev_loop().run(.no_wait) catch |err| {
                std.debug.panic("actual routing completion drain: {s}", .{@errorName(err)});
            };
        }
        std.debug.assert(transport.is_drained() and transport.close_complete);
        std.debug.assert(!transport.read_active and !transport.timer_active);
        std.debug.assert(!transport.read_cancel_active and !transport.timer_cancel_active);
    }
    application.shutdown() catch |err| {
        std.debug.panic("actual routing App shutdown: {s}", .{@errorName(err)});
    };
    application.deinit();
}

fn pump(application: *App, clients: []const *c.struct_uwz_app_client) !void {
    for (clients) |client| {
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_process(client));
        try testing.expect(c.uwz_app_client_send_udp(client) >= 0);
    }
    try application.loop.get_xev_loop().run(.no_wait);
    application.quic_transport.?.engine.process();
    for (clients) |client| try testing.expect(c.uwz_app_client_receive_udp(client) >= 0);
}

fn connection_index(application: *App, client: *c.struct_uwz_app_client) !usize {
    const pool = &application.quic_transport.?.engine.connections.pool;
    const port = c.uwz_app_client_port(client);
    for (pool.storage, 0..) |connection, index| {
        if (pool.is_active(index) and c.uwz_app_connection_peer_port(connection.native) == port) return index;
    }
    return error.MissingRoutingConnection;
}

fn snapshot(client: *c.struct_uwz_app_client) !c.struct_uwz_app_client_snapshot {
    var observed: c.struct_uwz_app_client_snapshot = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_observe(client, &observed));
    return observed;
}

fn response_snapshot(client: *c.struct_uwz_app_client, id: u64) !c.struct_uwz_app_response_snapshot {
    var observed: c.struct_uwz_app_response_snapshot = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_response(client, id, &observed));
    return observed;
}

fn handshake(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client) !usize {
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_connect(client));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, clients);
        const observed = try snapshot(client);
        if (observed.handshake_complete == 0 or observed.settings_callbacks == 0) continue;
        const index = connection_index(application, client) catch continue;
        if (application.quic_transport.?.engine.connections.pool.storage[index].peer != null) return index;
    }
    return error.RoutingHandshakeTimeout;
}

fn accept_session(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, path: [*:0]const u8, expected_id: u64) !usize {
    var input: c.struct_uwz_app_connect_request = .{
        .origin = "https://localhost",
        .authorization = "Bearer admission-fixture",
        .duplicate_origin = 0,
    };
    const id = c.uwz_app_client_open_connect_path(client, &input, path);
    try testing.expectEqual(expected_id, id);
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, clients);
        const observed = try response_snapshot(client, id);
        if (observed.header_callbacks == 0) continue;
        try testing.expectEqual(@as(c_uint, 200), observed.status_code);
        try testing.expectEqual(@as(c_uint, 0), observed.fin_received);
        try testing.expectEqual(backend.CreateResult.ok, backend.accept_connect(c.uwz_app_client_stream(client, id)));
        const index = try connection_index(application, client);
        const engine = &application.quic_transport.?.engine;
        try testing.expectEqual(.established, engine.connections.pool.storage[index].sessions.states[0]);
        try testing.expectEqual(@as(usize, 0), engine.header_pool.count_active());
        return index;
    }
    return error.RoutingConnectTimeout;
}

fn healthy_http(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client) !void {
    const body = "healthy-body";
    const id = c.uwz_app_client_open_post(client, "/header-overwrite", body.len);
    try testing.expect(id != std.math.maxInt(u64));
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, body, body.len, 1));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, clients);
        const observed = try response_snapshot(client, id);
        if (observed.fin_received == 0) continue;
        try testing.expectEqual(@as(c_uint, 200), observed.status_code);
        try testing.expectEqualSlices(u8, "healthy-response", observed.bytes[0..observed.received]);
        return;
    }
    return error.RoutingHealthyHttpTimeout;
}

fn native_input(native: ?*c.lsquic_conn) !c.struct_uwz_app_input_statistics {
    var observed: c.struct_uwz_app_input_statistics = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_connection_input_statistics(native, &observed));
    return observed;
}

fn settle(application: *App, clients: []const *c.struct_uwz_app_client, index: usize) !void {
    const native = application.quic_transport.?.engine.connections.pool.storage[index].native;
    var previous = try native_input(native);
    var quiet: usize = 0;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, clients);
        const current = try native_input(native);
        var empty = true;
        for (clients) |client| empty = empty and c.uwz_app_client_pending_packets(client) == 0;
        quiet = if (current.packets == previous.packets and empty) quiet + 1 else 0;
        if (quiet == 8) return;
        previous = current;
    }
    return error.RoutingSettleTimeout;
}

// One native writer event and one UDP packet isolate actual arrival, including
// when production deliberately drops its datagram before application dispatch.
fn wire_datagram(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, index: usize, session_id: u64, payload: []const u8, expected: DatagramExpectation) !void {
    try settle(application, clients, index);
    const selected_before = expected.selected.*;
    const other_before = expected.other.*;
    const native = application.quic_transport.?.engine.connections.pool.storage[index].native;
    const before = try native_input(native);
    const client_before = try snapshot(client);
    var bytes: [128]u8 = undefined;
    const length = try support.webtransport.encode_datagram(session_id, payload, &bytes);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_queue_datagram(client, &bytes, length));
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_process(client));
    const client_after = try snapshot(client);
    try testing.expectEqual(client_before.datagrams_written + 1, client_after.datagrams_written);
    try testing.expectEqual(@as(c_uint, 1), c.uwz_app_client_pending_packets(client));
    try testing.expectEqual(@as(c_int, 1), c.uwz_app_client_send_udp(client));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try application.loop.get_xev_loop().run(.no_wait);
        application.quic_transport.?.engine.process();
        const after = try native_input(native);
        if (after.packets == before.packets) continue;
        try testing.expectEqual(before.packets + 1, after.packets);
        try testing.expectEqual(before.undec_packets, after.undec_packets);
        try testing.expectEqual(before.dup_packets, after.dup_packets);
        try testing.expectEqual(before.err_packets, after.err_packets);
        try testing.expectEqual(other_before.datagram_calls, expected.other.datagram_calls);
        try testing.expectEqual(other_before.last_size, expected.other.last_size);
        try testing.expectEqualSlices(u8, other_before.last_bytes[0..other_before.last_size], expected.other.last_bytes[0..expected.other.last_size]);
        if (expected.delivered) {
            try testing.expectEqual(selected_before.datagram_calls + 1, expected.selected.datagram_calls);
            try testing.expectEqual(payload.len, expected.selected.last_size);
            try testing.expectEqualSlices(u8, payload, expected.selected.last_bytes[0..expected.selected.last_size]);
        } else {
            try testing.expectEqual(selected_before.datagram_calls, expected.selected.datagram_calls);
            try testing.expectEqual(selected_before.last_size, expected.selected.last_size);
            try testing.expectEqualSlices(u8, selected_before.last_bytes[0..selected_before.last_size], expected.selected.last_bytes[0..expected.selected.last_size]);
        }
        return;
    }
    return error.RoutingNativeDatagramArrivalTimeout;
}

fn expect_datagram(application: *App, index: usize, ordinal: u64, payload: []const u8) !void {
    try expect_datagram_id(application, index, 0, ordinal, payload);
}

fn expect_datagram_id(application: *App, index: usize, id: u64, ordinal: u64, payload: []const u8) !void {
    const observed = application.next_datagram(index) orelse return error.MissingAppDatagram;
    try testing.expectEqual(id, observed.session_id);
    try testing.expectEqual(ordinal, observed.sequence_number);
    try testing.expectEqualSlices(u8, payload, observed.payload);
}

fn close_session(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, index: usize) !void {
    var bytes: [32]u8 = undefined;
    const length = try support.webtransport.encode_close_session(0, "done", &bytes);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, 0, &bytes, length, 1));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, clients);
        const engine = &application.quic_transport.?.engine;
        if (engine.connections.pool.storage[index].sessions.open_count() != 0) continue;
        if (engine.stream_pool.count_active() > 1 or engine.header_pool.count_active() != 0) continue;
        try testing.expectEqual(@as(usize, 0), application.datagram_rings[index].len());
        return;
    }
    return error.RoutingCloseTimeout;
}

fn abort_connection(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client) !usize {
    const index = try connection_index(application, client);
    const engine = &application.quic_transport.?.engine;
    const handle = engine.connections.pool.storage[index].handle;
    c.lsquic_conn_abort(engine.connections.pool.storage[index].native);
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, clients);
        if (engine.connections.find(handle) != null) continue;
        try testing.expectEqual(@as(usize, 0), application.datagram_rings[index].len());
        return index;
    }
    return error.RoutingAbortTimeout;
}

fn server_stream_index(application: *App, index: usize, id: u64) !usize {
    const engine = &application.quic_transport.?.engine;
    const native = engine.connections.pool.storage[index].native;
    for (engine.stream_pool.storage, 0..) |*stream, stream_index| {
        if (!engine.stream_pool.is_active(stream_index)) continue;
        if (c.lsquic_stream_conn(stream.stream) == native and c.lsquic_stream_id(stream.stream) == id) return stream_index;
    }
    return error.MissingRoutingStream;
}

fn pending_settings_action(kind: SettingsAction, same_batch: bool) !void {
    var application = try initialize_app();
    defer destroy_app(&application);
    var first: RouteObservation = .{ .application = &application };
    var second: RouteObservation = .{ .application = &application };
    const port = try listen(&application, &first, &second);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_HELD_SETTINGS) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_connect(client));
    var index: usize = 0;
    var ready = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(&application, &clients);
        const observed = try snapshot(client);
        if (observed.handshake_complete == 0 or observed.settings_callbacks == 0) continue;
        index = connection_index(&application, client) catch continue;
        try testing.expectEqual(@as(c_uint, 1), observed.control_constructed);
        try testing.expectEqual(@as(c_uint, 1), observed.control_held);
        try testing.expectEqual(@as(u64, 0), observed.control_offset);
        try testing.expectEqual(@as(u64, 0), observed.control_buffered);
        ready = true;
        break;
    }
    try testing.expect(ready);
    const engine = &application.quic_transport.?.engine;
    const connection = &engine.connections.pool.storage[index];
    const canary: backend.Peer = .{ .initial_max_data = 0x12345678 };
    var peer = canary;
    try testing.expectEqual(backend.QueryResult.pending, backend.read_peer(connection.native, &peer));
    try testing.expectEqual(canary, peer);
    try testing.expect(connection.peer == null);
    var input: c.struct_uwz_app_connect_request = .{
        .origin = "https://localhost",
        .authorization = "Bearer admission-fixture",
        .duplicate_origin = 0,
    };
    const id = c.uwz_app_client_open_connect(client, &input);
    try testing.expectEqual(@as(u64, 0), id);
    var pending = false;
    var pending_index: usize = 0;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(&application, &clients);
        const stream_index = server_stream_index(&application, index, id) catch continue;
        const context = &engine.stream_contexts[stream_index];
        if (!context.state.pending_settings) continue;
        try testing.expect(context.http.header_set != null);
        try testing.expectEqual(@as(usize, 1), engine.header_pool.count_active());
        try testing.expectEqual(@as(usize, 0), first.authorization_calls);
        try testing.expectEqual(@as(usize, 0), connection.sessions.open_count());
        pending_index = stream_index;
        pending = true;
        break;
    }
    try testing.expect(pending);
    const native = c.uwz_app_client_stream(client, id) orelse return error.MissingClientConnect;
    if (kind == .admit) {
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_release_settings(client));
        var admitted = false;
        for (0..c.UWZ_APP_MAX_STEPS) |_| {
            try pump(&application, &clients);
            const accepted = try response_snapshot(client, id);
            if (accepted.header_callbacks == 0 or connection.peer == null) continue;
            try testing.expectEqual(@as(c_uint, 1), accepted.header_callbacks);
            try testing.expectEqual(@as(c_uint, 200), accepted.status_code);
            try testing.expectEqual(@as(c_uint, 0), accepted.fin_received);
            try testing.expectEqual(@as(usize, 1), first.authorization_calls);
            try testing.expectEqual(@as(usize, 1), connection.sessions.open_count());
            try testing.expectEqual(.established, connection.sessions.states[0]);
            try testing.expectEqual(@as(usize, 0), engine.header_pool.count_active());
            try testing.expectEqual(backend.QueryResult.ok, backend.read_peer(connection.native, &peer));
            try testing.expect(backend.peer_requirements_met(peer, .server));
            admitted = true;
            break;
        }
        try testing.expect(admitted);
        try testing.expectEqual(backend.CreateResult.ok, backend.accept_connect(native));
        try wire_datagram(&application, client, &clients, index, 0, "after-settings", .{ .selected = &first, .other = &second });
        try expect_datagram(&application, index, 0, "after-settings");
        try close_session(&application, client, &clients, index);
        try healthy_http(&application, client, &clients);
        try testing.expectEqual(@as(usize, 1), first.authorization_calls);
        try testing.expect(!first.failed);
        _ = try abort_connection(&application, client, &clients);
        return;
    }
    if (kind == .reset) {
        try testing.expectEqual(@as(c_int, c.LSQUIC_SRA_OK), c.lsquic_stream_reset_at(native, 0x10c, 0));
    } else {
        try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_shutdown(native, 0));
    }
    if (same_batch) {
        // Deliver the native cancellation before allowing any original
        // SETTINGS bytes out, while withholding public server processing.
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_process(client));
        const held = try snapshot(client);
        try testing.expectEqual(@as(c_uint, 1), held.control_held);
        try testing.expectEqual(@as(u64, 0), held.control_offset);
        try testing.expect(c.uwz_app_client_stage_pending_packets(client, engine.engine, engine) > 0);
        const server_native = engine.stream_pool.storage[pending_index].stream;
        var cancelled_native: c.struct_lsquic_stream_recv_state = undefined;
        try testing.expectEqual(@as(c_int, c.LSQUIC_SRG_OK), c.lsquic_stream_get_recv_state(server_native, &cancelled_native));
        const context = &engine.stream_contexts[pending_index];
        if (kind == .reset) {
            try testing.expect(cancelled_native.flags & @as(c_uint, c.LSQUIC_SRS_RESET_KNOWN) != 0);
            try testing.expect(cancelled_native.flags & @as(c_uint, c.LSQUIC_SRS_RESET_VISIBLE) == 0);
            try testing.expect(context.state.pending_settings and context.http.header_set != null);
            try testing.expectEqual(@as(usize, 1), engine.header_pool.count_active());
        } else {
            try testing.expect(cancelled_native.flags & @as(c_uint, c.LSQUIC_SRS_STOP_SENDING_KNOWN) != 0);
            // Native STOP notification is synchronous during packet input;
            // its actual callback already releases this decoded CONNECT.
            try testing.expect(!context.state.pending_settings and context.http.header_set == null);
            try testing.expectEqual(@as(usize, 0), engine.header_pool.count_active());
        }
        try testing.expectEqual(@as(usize, 0), first.authorization_calls);
        try testing.expect(connection.peer == null);
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_release_settings(client));
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_process(client));
        const sent = try snapshot(client);
        try testing.expect(sent.control_offset > 0);
        // SETTINGS follows the already-observed cancellation before one
        // public process turn; no frame or native peer cache is fabricated.
        try testing.expect(c.uwz_app_client_stage_pending_packets(client, engine.engine, engine) > 0);
        try testing.expectEqual(@as(usize, 0), first.authorization_calls);
        if (kind == .reset) try testing.expect(context.state.pending_settings and context.http.header_set != null);
        engine.process();
    } else {
        var released = false;
        for (0..c.UWZ_APP_MAX_STEPS) |_| {
            try pump(&application, &clients);
            if (engine.header_pool.count_active() != 0 or engine.stream_pool.count_active() != 0) continue;
            try testing.expect(connection.peer == null);
            try testing.expectEqual(backend.QueryResult.pending, backend.read_peer(connection.native, &peer));
            released = true;
            break;
        }
        try testing.expect(released);
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_release_settings(client));
    }
    var completed = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(&application, &clients);
        if (connection.peer == null or engine.header_pool.count_active() != 0 or engine.stream_pool.count_active() != 0) continue;
        completed = true;
        break;
    }
    try testing.expect(completed);
    try testing.expectEqual(backend.QueryResult.ok, backend.read_peer(connection.native, &peer));
    try testing.expect(backend.peer_requirements_met(peer, .server));
    try testing.expectEqual(@as(usize, 0), first.authorization_calls);
    try testing.expectEqual(@as(usize, 0), connection.sessions.open_count());
    const cancelled = try response_snapshot(client, id);
    try testing.expectEqual(@as(c_uint, 0), cancelled.header_callbacks);
    try healthy_http(&application, client, &clients);
    try testing.expectEqual(@as(usize, 0), first.authorization_calls);
    try testing.expect(!first.failed);
    _ = try abort_connection(&application, client, &clients);
}

test "pending SETTINGS CONNECT reset releases retained headers before SETTINGS" {
    try pending_settings_action(.reset, false);
}

test "pending SETTINGS CONNECT STOP releases retained headers before SETTINGS" {
    try pending_settings_action(.stop, false);
}

test "pending SETTINGS queued CONNECT reset cannot resurrect admission" {
    try pending_settings_action(.reset, true);
}

test "pending SETTINGS native STOP callback precedes later settings processing" {
    try pending_settings_action(.stop, true);
}

test "pending SETTINGS CONNECT admits exactly once after original settings release" {
    try pending_settings_action(.admit, false);
}

test "wire datagrams retain route after header reuse and isolate SID zero rings" {
    var application = try initialize_app();
    defer destroy_app(&application);
    var first: RouteObservation = .{ .application = &application };
    var second: RouteObservation = .{ .application = &application };
    const port = try listen(&application, &first, &second);
    const a = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(a);
    const b = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(b);
    const clients = [_]*c.struct_uwz_app_client{ a, b };
    _ = try handshake(&application, a, &clients);
    const ai = try accept_session(&application, a, &clients, "/wt", 0);
    const original_header = first.header_index orelse return error.MissingConnectHeaderObservation;
    const original_route = application.quic_transport.?.engine.connections.pool.storage[ai].session_route;
    try healthy_http(&application, a, &clients);
    try testing.expectEqual(original_header, first.header_index.?);
    try testing.expectEqual(original_route, application.quic_transport.?.engine.connections.pool.storage[ai].session_route);
    _ = try handshake(&application, b, &clients);
    const bi = try accept_session(&application, b, &clients, "/other", 0);
    try testing.expect(ai != bi);
    try wire_datagram(&application, a, &clients, ai, 0, "a-first", .{ .selected = &first, .other = &second });
    try wire_datagram(&application, b, &clients, bi, 0, "b-first", .{ .selected = &second, .other = &first });
    try testing.expectEqual(@as(usize, 1), first.datagram_calls);
    try testing.expectEqual(@as(usize, 1), second.datagram_calls);
    try expect_datagram(&application, ai, 0, "a-first");
    try expect_datagram(&application, bi, 0, "b-first");
    const received_before_unknown = first.datagram_calls;
    try wire_datagram(&application, a, &clients, ai, 4, "unknown-session", .{ .selected = &first, .other = &second, .delivered = false });
    try healthy_http(&application, a, &clients);
    try testing.expectEqual(received_before_unknown, first.datagram_calls);
    try testing.expect(application.next_datagram(ai) == null);
    for (0..4) |_| try wire_datagram(&application, a, &clients, ai, 0, "fill", .{ .selected = &first, .other = &second });
    try testing.expectEqual(@as(usize, 4), application.datagram_rings[ai].len());
    const before_drop = first.datagram_calls;
    try wire_datagram(&application, a, &clients, ai, 0, "overflow", .{ .selected = &first, .other = &second, .delivered = false });
    try healthy_http(&application, a, &clients);
    try testing.expectEqual(before_drop, first.datagram_calls);
    try testing.expectEqual(@as(u64, 1), application.datagram_rings[ai].dropped);
    try expect_datagram(&application, ai, 1, "fill");
    try wire_datagram(&application, a, &clients, ai, 0, "after-drop", .{ .selected = &first, .other = &second });
    for (2..5) |ordinal| try expect_datagram(&application, ai, ordinal, "fill");
    try expect_datagram(&application, ai, 6, "after-drop");
    try testing.expect(application.next_datagram(ai) == null);
    try wire_datagram(&application, a, &clients, ai, 0, "clear-drop", .{ .selected = &first, .other = &second });
    try close_session(&application, a, &clients, ai);
    try testing.expectEqual(@as(u64, 1), application.datagram_rings[ai].dropped);
    try testing.expect(first.datagram_callback_depth > 0 and second.datagram_callback_depth > 0);
    try testing.expectEqual(first.datagram_calls, first.datagram_reentry_returns);
    try testing.expectEqual(second.datagram_calls, second.datagram_reentry_returns);
    try testing.expect(!first.failed and !second.failed);
    _ = try abort_connection(&application, a, &clients);
    _ = try abort_connection(&application, b, &clients);
}

test "wire datagrams stop after Close and rings clear before connection generation reuse" {
    var application = try initialize_app();
    defer destroy_app(&application);
    var first: RouteObservation = .{ .application = &application };
    var second: RouteObservation = .{ .application = &application };
    const port = try listen(&application, &first, &second);
    const a = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(a);
    const b = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(b);
    const initial = [_]*c.struct_uwz_app_client{ a, b };
    _ = try handshake(&application, a, &initial);
    const ai = try accept_session(&application, a, &initial, "/wt", 0);
    _ = try handshake(&application, b, &initial);
    const bi = try accept_session(&application, b, &initial, "/other", 0);
    try wire_datagram(&application, a, &initial, ai, 0, "a-retained", .{ .selected = &first, .other = &second });
    try wire_datagram(&application, b, &initial, bi, 0, "b-retained", .{ .selected = &second, .other = &first });
    try close_session(&application, a, &initial, ai);
    const closed_calls = first.datagram_calls;
    try wire_datagram(&application, a, &initial, ai, 0, "after-close", .{ .selected = &first, .other = &second, .delivered = false });
    try testing.expectEqual(closed_calls, first.datagram_calls);
    try testing.expect(application.next_datagram(ai) == null);
    first.expected_session = 4;
    try testing.expectEqual(ai, try accept_session(&application, a, &initial, "/wt", 4));
    try wire_datagram(&application, a, &initial, ai, 4, "same-connection-session", .{ .selected = &first, .other = &second });
    try expect_datagram_id(&application, ai, 4, 1, "same-connection-session");
    try healthy_http(&application, a, &initial);
    try testing.expectEqual(@as(usize, 1), application.datagram_rings[bi].len());
    const old_handle = application.quic_transport.?.engine.connections.pool.storage[ai].handle;
    try testing.expectEqual(ai, try abort_connection(&application, a, &initial));
    const fresh = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(fresh);
    const clients = [_]*c.struct_uwz_app_client{ b, fresh };
    _ = try handshake(&application, fresh, &clients);
    first.expected_session = 0;
    const fi = try accept_session(&application, fresh, &clients, "/wt", 0);
    try testing.expectEqual(ai, fi);
    const table = &application.quic_transport.?.engine.connections;
    try testing.expect(table.find(old_handle) == null);
    try testing.expect(table.pool.storage[fi].handle.generation != old_handle.generation);
    try testing.expect(application.next_datagram(fi) == null);
    try wire_datagram(&application, fresh, &clients, fi, 0, "fresh-generation", .{ .selected = &first, .other = &second });
    try expect_datagram(&application, fi, 0, "fresh-generation");
    try expect_datagram(&application, bi, 0, "b-retained");
    try wire_datagram(&application, b, &clients, bi, 0, "b-survives", .{ .selected = &second, .other = &first });
    try expect_datagram(&application, bi, 1, "b-survives");
    try healthy_http(&application, b, &clients);
    try testing.expect(!first.failed and !second.failed);
    _ = try abort_connection(&application, fresh, &clients);
    _ = try abort_connection(&application, b, &clients);
}

// Service each byte until the actual native stream reader advances so the
// following write cannot collapse this case into an unfragmented capsule.
fn send_live_fragment(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, index: usize, byte: *const u8) !void {
    const stream_index = try server_stream_index(application, index, 0);
    const native = application.quic_transport.?.engine.stream_pool.storage[stream_index].stream;
    var before: c.struct_uwz_app_stream_diagnostics = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_stream_diagnose(native, &before));
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, 0, byte, 1, 0));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, clients);
        try testing.expectEqual(@as(usize, 1), application.quic_transport.?.engine.connections.pool.storage[index].sessions.open_count());
        var after: c.struct_uwz_app_stream_diagnostics = undefined;
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_stream_diagnose(native, &after));
        if (after.read_offset > before.read_offset and after.h3_frame_type == 0 and after.h3_data_remaining == 0) return;
    }
    return error.RoutingFragmentConsumptionTimeout;
}

test "flow off ignores fragmented invalid credit semantics before valid Close" {
    var application = try initialize_app();
    defer destroy_app(&application);
    var first: RouteObservation = .{ .application = &application };
    var second: RouteObservation = .{ .application = &application };
    const port = try listen(&application, &first, &second);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    _ = try handshake(&application, client, &clients);
    const index = try accept_session(&application, client, &clients, "/wt", 0);
    try wire_datagram(&application, client, &clients, index, 0, "retained-before-close", .{ .selected = &first, .other = &second });
    var invalid_credit: [32]u8 = undefined;
    const credit_size = try support.webtransport.encode_integer_capsule(support.webtransport.wt_max_streams_uni, (@as(u64, 1) << 60) + 1, &invalid_credit);
    try testing.expectError(error.InvalidStreamLimit, support.webtransport.decode_capsule(invalid_credit[0..credit_size]));
    for (invalid_credit[0..credit_size]) |*byte| try send_live_fragment(&application, client, &clients, index, byte);
    const after_credit = try response_snapshot(client, 0);
    try testing.expectEqual(@as(c_uint, 0), after_credit.fin_received);
    try testing.expectEqual(@as(c_uint, 0), after_credit.reset_events[0]);
    try testing.expectEqual(@as(c_uint, 0), after_credit.reset_events[1]);
    try testing.expectEqual(@as(usize, 1), application.datagram_rings[index].len());
    try wire_datagram(&application, client, &clients, index, 0, "after-ignored-credit", .{ .selected = &first, .other = &second });
    var drain: [16]u8 = undefined;
    const drain_size = try support.webtransport.encode_drain_session(&drain);
    for (drain[0..drain_size]) |*byte| try send_live_fragment(&application, client, &clients, index, byte);
    try testing.expectEqual(.draining, application.quic_transport.?.engine.connections.pool.storage[index].sessions.states[0]);
    try wire_datagram(&application, client, &clients, index, 0, "while-draining", .{ .selected = &first, .other = &second });
    try expect_datagram(&application, index, 0, "retained-before-close");
    try expect_datagram(&application, index, 1, "after-ignored-credit");
    const retained_drain = application.datagram_rings[index].peek() orelse return error.MissingDrainingDatagram;
    try testing.expectEqual(@as(u64, 0), retained_drain.session_id);
    try testing.expectEqual(@as(u64, 2), retained_drain.sequence_number);
    try testing.expectEqualSlices(u8, "while-draining", retained_drain.payload);
    var close: [32]u8 = undefined;
    const close_size = try support.webtransport.encode_close_session(17, "valid-close", &close);
    for (close[0 .. close_size - 1]) |*byte| try send_live_fragment(&application, client, &clients, index, byte);
    const server_index = try server_stream_index(&application, index, 0);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, 0, close[close_size - 1 ..].ptr, 1, 0));
    var capsule_closed = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(&application, &clients);
        const engine = &application.quic_transport.?.engine;
        const context = &engine.stream_contexts[server_index];
        const observed = try response_snapshot(client, 0);
        if (!context.close_received or observed.fin_received == 0) continue;
        try testing.expect(engine.stream_pool.is_active(server_index));
        try testing.expectEqual(@as(usize, 0), engine.connections.pool.storage[index].sessions.open_count());
        try testing.expectEqual(@as(usize, 0), application.datagram_rings[index].len());
        var received: c.struct_lsquic_stream_recv_state = undefined;
        try testing.expectEqual(@as(c_int, c.LSQUIC_SRG_OK), c.lsquic_stream_get_recv_state(context.http.stream, &received));
        try testing.expect(received.flags & @as(c_uint, c.LSQUIC_SRS_FIN_RECEIVED) == 0);
        var client_send: c.struct_uwz_app_stream_diagnostics = undefined;
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_stream_diagnose(c.uwz_app_client_stream(client, 0), &client_send));
        try testing.expectEqual(@as(c_uint, 0), client_send.send_shutdown);
        try testing.expectEqual(@as(c_uint, 0), observed.reset_events[0]);
        try testing.expectEqual(@as(c_uint, 0), observed.reset_events[1]);
        capsule_closed = true;
        break;
    }
    try testing.expect(capsule_closed);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, 0, "", 0, 1));
    var closed = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(&application, &clients);
        const engine = &application.quic_transport.?.engine;
        const observed = try response_snapshot(client, 0);
        if (observed.fin_received == 0 or engine.stream_pool.count_active() != 0 or engine.header_pool.count_active() != 0) continue;
        try testing.expectEqual(@as(usize, 0), engine.connections.pool.storage[index].sessions.open_count());
        try testing.expectEqual(@as(usize, 0), application.datagram_rings[index].len());
        try testing.expectEqual(@as(c_uint, 0), observed.reset_events[0]);
        try testing.expectEqual(@as(c_uint, 0), observed.reset_events[1]);
        closed = true;
        break;
    }
    try testing.expect(closed);
    try wire_datagram(&application, client, &clients, index, 0, "ignored-after-close", .{ .selected = &first, .other = &second, .delivered = false });
    try healthy_http(&application, client, &clients);
    try testing.expect(!first.failed and !second.failed);
    _ = try abort_connection(&application, client, &clients);
}

test "actual datagram callback defers engine cooldown until packet processing unwinds" {
    var application = try initialize_app();
    defer destroy_app(&application);
    var first: RouteObservation = .{ .application = &application, .request_cooldown = true };
    var second: RouteObservation = .{ .application = &application };
    const port = try listen(&application, &first, &second);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    _ = try handshake(&application, client, &clients);
    const index = try accept_session(&application, client, &clients, "/wt", 0);
    try wire_datagram(&application, client, &clients, index, 0, "request-cooldown", .{ .selected = &first, .other = &second });
    try testing.expect(first.cooldown_deferred);
    try testing.expect(first.datagram_callback_depth > 0);
    try testing.expectEqual(@as(usize, 1), first.datagram_reentry_returns);
    const engine = &application.quic_transport.?.engine;
    try testing.expectEqual(@as(usize, 0), engine.callback_depth);
    try testing.expect(!engine.cooldown_pending and !engine.in_cooldown);
    try testing.expectEqual(@as(c.enum_LSQUIC_CONN_STATUS, c.LSCONN_ST_GOING_AWAY), c.lsquic_conn_status(engine.connections.pool.storage[index].native, null, 0));
    try expect_datagram(&application, index, 0, "request-cooldown");
    try testing.expect(!first.failed and !second.failed);
    _ = try abort_connection(&application, client, &clients);
}

const EarlyObservation = struct {
    application: *App,
    authorization: *RouteObservation,
    connection_index: ?usize = null,
    count: usize = 0,
    sizes: [16]usize = .{0} ** 16,
    payloads: [16][128]u8 = undefined,
    session_ids: [16]u64 = .{0} ** 16,
    expected_session: u64 = 0,
    expected_authorizations: usize = 1,
    cooldown_on_first: bool = false,
    cooldown_was_deferred: bool = false,
    invalid_gate: bool = false,
};

fn early_datagram(context: *anyopaque, id: u64, payload: []const u8) void {
    const observed: *EarlyObservation = @ptrCast(@alignCast(context));
    const engine = &observed.application.quic_transport.?.engine;
    const index = observed.connection_index orelse {
        observed.invalid_gate = true;
        return;
    };
    const connection = &engine.connections.pool.storage[index];
    if (observed.authorization.authorization_calls != observed.expected_authorizations or
        connection.sessions.open_count() != 1 or connection.sessions.states[0] != .established or id != observed.expected_session)
    {
        observed.invalid_gate = true;
    }
    if (observed.count == observed.payloads.len or payload.len > observed.payloads[0].len) {
        observed.invalid_gate = true;
        return;
    }
    @memcpy(observed.payloads[observed.count][0..payload.len], payload);
    observed.sizes[observed.count] = payload.len;
    observed.session_ids[observed.count] = id;
    observed.count += 1;
    observed.authorization.datagram_calls += 1;
    @memcpy(observed.authorization.last_bytes[0..payload.len], payload);
    observed.authorization.last_size = payload.len;
    if (observed.cooldown_on_first and observed.count == 1) {
        engine.cooldown();
        observed.cooldown_was_deferred = engine.callback_depth > 0 and engine.cooldown_pending and !engine.in_cooldown;
    }
}

test "early wire datagrams before CONNECT replay FIFO only after authorized establishment" {
    var application = try initialize_app();
    defer destroy_app(&application);
    var authorization: RouteObservation = .{ .application = &application };
    const unused_route: RouteObservation = .{ .application = &application };
    var observed: EarlyObservation = .{ .application = &application, .authorization = &authorization };
    try application.enable_http3_ephemeral();
    _ = try application.datagram_context("/wt", &observed, early_datagram);
    _ = try application.route_context(.connect, "/wt", &authorization, authorize);
    try application.listen_udp("127.0.0.1", 0);
    const port = application.quic_transport.?.local_address.ip4.port;
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try handshake(&application, client, &clients);
    observed.connection_index = index;
    const before = try snapshot(client);
    try testing.expectEqual(@as(c_uint, 0), before.stream_callbacks);
    try wire_datagram(&application, client, &clients, index, 0, "early-A", .{ .selected = &authorization, .other = &unused_route, .delivered = false });
    try wire_datagram(&application, client, &clients, index, 0, "early-B", .{ .selected = &authorization, .other = &unused_route, .delivered = false });
    try testing.expectEqual(@as(usize, 0), authorization.authorization_calls);
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expectEqual(@as(usize, 0), application.datagram_rings[index].len());
    try testing.expectEqual(@as(c_uint, 0), (try snapshot(client)).stream_callbacks);
    try testing.expectEqual(index, try accept_session(&application, client, &clients, "/wt", 0));
    try testing.expectEqual(@as(usize, 1), authorization.authorization_calls);
    try testing.expectEqual(@as(usize, 2), observed.count);
    try testing.expect(!observed.invalid_gate);
    try testing.expectEqualSlices(u8, "early-A", observed.payloads[0][0..observed.sizes[0]]);
    try testing.expectEqualSlices(u8, "early-B", observed.payloads[1][0..observed.sizes[1]]);
    try expect_datagram(&application, index, 0, "early-A");
    try expect_datagram(&application, index, 1, "early-B");
    try testing.expect(application.next_datagram(index) == null);
    _ = try abort_connection(&application, client, &clients);
}

const module = @This();

pub const PendingSupport = struct {
    pub const Application = module.App;
    pub const RouteObserver = module.RouteObservation;
    pub const EarlyObserver = module.EarlyObservation;
    pub const initialize = module.initialize_app;
    pub const destroy = module.destroy_app;
    pub const pump = module.pump;
    pub const find_connection = module.connection_index;
    pub const client_snapshot = module.snapshot;
    pub const response_snapshot = module.response_snapshot;
    pub const handshake = module.handshake;
    pub const header_observation = module.record_header;
    pub const datagram_handler = module.early_datagram;
    pub const health_handler = module.health;
    pub const healthy_http = module.healthy_http;
    pub const native_input = module.native_input;
    pub const settle = module.settle;
    pub const close_zero_session = module.close_session;
    pub const abort_connection = module.abort_connection;
    pub const server_stream = module.server_stream_index;
};
