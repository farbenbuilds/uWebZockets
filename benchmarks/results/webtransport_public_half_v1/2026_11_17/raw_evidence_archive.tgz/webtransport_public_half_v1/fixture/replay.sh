#!/bin/sh
set -eu

uwz_fixture_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
uwz_mode=${1:-Debug}
if test "$#" -gt 1; then
    printf '%s\n' 'usage: sh replay.sh [Debug|ReleaseSafe|ReleaseFast]' >&2
    exit 2
fi
case "$uwz_mode" in
    Debug|ReleaseSafe|ReleaseFast) ;;
    *) printf '%s\n' 'unsupported optimization mode' >&2; exit 2 ;;
esac
uwz_zig=${UWZ_ZIG:-zig}
uwz_project=$(CDPATH= cd -- "${UWZ_PROJECT_SOURCE:-$uwz_fixture_dir/project_v1}" && pwd)
uwz_native=$(CDPATH= cd -- "${UWZ_LSQUIC_SOURCE:?Set the verified native005 source path}" && pwd)
uwz_xev=$(CDPATH= cd -- "${UWZ_LIBXEV_SOURCE:?Set the verified XEV5b2c source path}" && pwd)
uwz_packages=$(CDPATH= cd -- "${UWZ_PACKAGE_DIR:?Set the offline Zig package directory}" && pwd)
uwz_cache=${UWZ_CACHE_DIR:-"$uwz_fixture_dir/.zig-cache"}
uwz_jobs=${UWZ_JOBS:-2}
case "$uwz_jobs" in
    ''|*[!0-9]*|0) printf '%s\n' 'UWZ_JOBS must be positive' >&2; exit 2 ;;
esac
if test "$("$uwz_zig" version)" != 0.16.0; then
    printf '%s\n' 'Zig0.16.0 is required' >&2
    exit 2
fi
test -f "$uwz_native/include/lsquic.h"
test -f "$uwz_xev/src/main.zig"
cd "$uwz_fixture_dir"
sha256sum -c provenance/half51_run_inputs.sha256
(
    cd "$uwz_project"
    sha256sum -c "$uwz_fixture_dir/provenance/project_v1_inputs.sha256"
)
ulimit -c 0
exec "$uwz_zig" build test --system "$uwz_packages" --cache-dir "$uwz_cache" \
    "-Dproject-source=$uwz_project" -Dtest-source=tests/half_main.zig \
    "-Doptimize=$uwz_mode" "-Dlsquic-source=$uwz_native" \
    "-Dlibxev-source=$uwz_xev" "-j$uwz_jobs" --summary all
