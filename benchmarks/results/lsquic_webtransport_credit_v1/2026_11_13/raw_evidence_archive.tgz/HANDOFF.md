# WebTransport stream-credit prerequisite

Restore the prior SETTINGS proposal first. This incremental bundle requires
8b0ef12414cdcf7b8c20e0b9f4fceb321358c2d0 and contains the reviewed local tip
9f0088c58fe67cccf1871dc172c90c2ec6f97944. Verify/fetch the bundle and compare
proposal-inputs.sha256 after checkout. The working tree was clean. Root pins
and live capability records remain unchanged. This is review material, not a
production overlay or a published maintained-fork integration.

The native scaffold uses Zig 0.16.0 and unchanged exact dependency pins.
Relocate -Dlsquic-source, -Dfixture, -Dfixture-includes and -Dfixture-support
paths. The fixture uses shared uwz_quic_fixture.c, -Dfixture-hooks=true and
no settings observer. Set ulimit -c 0. It uses actual encrypted QUIC/TLS;
read-only transport parameter/native cap observations never mutate state.
The external run-credit.py records commands/statuses; its own exit status
is not the cohort result. Inspect each record and original log.

Initial failures were test setup: the frozen fixture copy lacked its shared
header, then lsquic_hash.h had to precede lsquic_conn.h. These are not RED
behavioral evidence. Original and corrected uni fixture inputs are retained.
The actual baseline disabled8 and enabled3 cases passed; enabled8 failed
because the decoded peer uni limit was3 instead of8. After the four-line
WT-only uni correction, all three passed. The separate raw RED used this
intermediate uni-only production source (SHA4044cf744b5871c7a0f3bc68db97057a322e5ed01cebe3402cef557c96069673)
and failed server-created stream1 cap32768 versus49152. The raw scenario
also reproduces on the bundle base: the uni correction does not affect it.
The final explicit directional fields fix both new-stream constructors.

The final combined fixture is SHA7939ca45a1b5c449077768250c9ed159420f4f8166d8b4af67c45588010b0ad8.
Focused all-case commands pass Debug/ReleaseSafe/ReleaseFast. Existing peer
lifecycle and encrypted SETTINGS writer regressions pass ReleaseSafe.
The final-gate manifest records upstream Debug and Windows GNU/macOS ARM64
production-library compilation with fixture hooks/observer disabled.
Cross-compilation is not foreign runtime evidence. No generated fixture
private key, dependency cache or compiled artifact is archived.

Remaining smoke/security runs are deferred. Actual asymmetric resumption,
exact byte-boundary exhaustion and WT server-bidi admission/classification
remain unproven. Raw child creation, association, directional prefix/reset
handling, Zig sessions, external client acceptance and fork publication are
still required; this checkpoint does not complete WebTransport or v2.3.0.
