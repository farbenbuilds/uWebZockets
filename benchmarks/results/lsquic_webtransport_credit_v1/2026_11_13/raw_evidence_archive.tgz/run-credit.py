import argparse
import hashlib
import json
import os
import pathlib
import resource
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--fixture', required=True)
parser.add_argument('--tag', required=True)
parser.add_argument('--mode', default='Debug')
parser.add_argument('selectors', nargs='+')
args = parser.parse_args()
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
source = pathlib.Path('/tmp/uwz-lsquic-wt-children-20261113')
harness = pathlib.Path('/tmp/uwz-lsquic-webtransport-harness')
fixture = pathlib.Path(args.fixture)
env = os.environ.copy()
env['ZIG_GLOBAL_CACHE_DIR'] = '/tmp/uwz-uni-global-cache'
results = []
for selector in args.selectors:
    log = pathlib.Path('/tmp/uwz-lsquic-wt-credit-' + args.tag + '-' + selector + '.log')
    assert not log.exists(), str(log)
    command = [
        '/tmp/zig-x86_64-linux-0.16.0/zig', 'build', 'test',
        '-Dlsquic-source=' + str(source), '-Dfixture=' + str(fixture),
        '-Dfixture-includes=' + str(source / 'src/liblsquic'),
        '-Dfixture-name=uwz_webtransport_credit',
        '-Dfixture-support=' + str(source / 'tests/uwz_quic_fixture.c'),
        '-Dfixture-hooks=true', '-Doptimize=' + args.mode,
        '-j2', '--summary', 'all', '--', selector,
    ]
    with log.open('w') as output:
        result = subprocess.run(command, cwd=harness, env=env,
                                stdout=output, stderr=subprocess.STDOUT)
    log.with_suffix('.exit').write_text(str(result.returncode) + '\n')
    record = {
        'command': command, 'exit': result.returncode, 'log': str(log),
        'fixture_sha256': hashlib.sha256(fixture.read_bytes()).hexdigest(),
        'full_conn_sha256': hashlib.sha256((source / 'src/liblsquic/lsquic_full_conn_ietf.c').read_bytes()).hexdigest(),
    }
    results.append(record)
    print(json.dumps(record), flush=True)
    print(log.read_text()[:1600], flush=True)
(harness / ('evidence/credit-' + args.tag + '.json')).write_text(json.dumps(results, indent=2) + '\n')
