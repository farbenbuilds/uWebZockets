#!/usr/bin/env python3
"""Restore a prerequisite bundle offline from an exact external official base."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

BUNDLE_SHA256 = 'fcd2eef3395e42b4198abe7d055038031b7438dbbfa40f44a4ef8fd731918da6'
BASE = 'd3bf4795ad5b79d646cddf2fec687da5b9b502db'
BASE_TREE = '92ce790e497fe2b5989d9dab81d5301a1b594b68'
COMMIT = '33406dd2383eff3e84059a763933b010cc5a663d'
TREE = '9bba91e966828b1d5e8ab51f9721a39446febc04'
BRANCH = 'proposal/sql-client-tls-reservations-20261117'


def git(repo, *args, check=True):
    return subprocess.run(['git', '-C', str(repo), *args], check=check,
                          capture_output=True, text=True)


def identity(repo, expression):
    return git(repo, 'rev-parse', '--verify', expression).stdout.strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('bundle', type=Path)
    parser.add_argument('base_repository', type=Path,
                        help='local complete-history Git repository with HEAD at the exact official base')
    parser.add_argument('destination', type=Path, help='absent output directory')
    args = parser.parse_args()
    destination = args.destination.absolute()
    if destination.exists() or destination.is_symlink():
        parser.error('destination must not exist; output was not changed')
    bundle = args.bundle.resolve(strict=True)
    base_repository = args.base_repository.resolve(strict=True)
    if hashlib.sha256(bundle.read_bytes()).hexdigest() != BUNDLE_SHA256:
        parser.error('bundle SHA256 mismatch; output was not created')
    with bundle.open('rb') as handle:
        header = []
        while True:
            line = handle.readline()
            if line == b'\n':
                break
            if not line:
                parser.error('bundle header is incomplete; output was not created')
            header.append(line.decode().rstrip('\n'))
    prerequisites = [line[1:].split(' ', 1)[0] for line in header if line.startswith('-')]
    refs = [line for line in header if line and not line.startswith(('#', '-', '@'))]
    if prerequisites != [BASE] or refs != [f'{COMMIT} refs/heads/{BRANCH}']:
        parser.error('bundle refs/prerequisite are unexpected; output was not created')
    try:
        base_head = identity(base_repository, 'HEAD^{commit}')
        base_tree = identity(base_repository, 'HEAD^{tree}')
        complete = git(base_repository, 'rev-parse', '--is-shallow-repository').stdout.strip() == 'false'
    except subprocess.CalledProcessError:
        parser.error('base repository must resolve the exact official base; output was not created')
    if base_head != BASE or base_tree != BASE_TREE or not complete:
        parser.error('wrong base: require exact official HEAD/tree and complete history; output was not created')

    subprocess.run(['git', 'init', '--quiet', str(destination)], check=True)
    git(destination, 'config', '--local', 'core.autocrlf', 'false')
    # A scoped fetch avoids cloning unrelated local candidate refs or objects.
    git(destination, 'fetch', '--quiet', '--no-tags', str(base_repository), BASE)
    git(destination, 'checkout', '--quiet', '--detach', BASE)
    candidate_before = git(destination, 'cat-file', '-e', COMMIT + '^{commit}', check=False)
    if candidate_before.returncode == 0:
        raise RuntimeError('Candidate unexpectedly exists before the bundle fetch')
    verified = git(destination, 'bundle', 'verify', str(bundle))
    git(destination, 'fetch', '--quiet', '--no-tags', str(bundle),
        f'refs/heads/{BRANCH}:refs/heads/{BRANCH}')
    git(destination, 'checkout', '--quiet', BRANCH)
    for expression, expected in [('HEAD^{commit}', COMMIT), ('HEAD^', BASE), ('HEAD^{tree}', TREE)]:
        if identity(destination, expression) != expected:
            raise RuntimeError(f'Unexpected restored {expression}')
    git(destination, 'diff', '--check', BASE, COMMIT)
    git(destination, 'fsck', '--full', '--strict')
    if git(destination, 'status', '--porcelain').stdout:
        raise RuntimeError('Restored proposal is dirty')
    print(json.dumps({
        'base_head': base_head, 'base_tree': base_tree,
        'external_complete_base_history_required': True,
        'base_history_embedded_in_bundle': False,
        'bundle_sha256': BUNDLE_SHA256, 'prerequisites': prerequisites,
        'candidate_object_absent_before_bundle_fetch': True,
        'bundle_verify_exit_code': verified.returncode,
        'restored_commit': COMMIT, 'restored_parent': BASE, 'restored_tree': TREE,
        'diff_check_passed': True, 'git_fsck_full_strict_exit_code': 0,
        'working_tree_clean': True, 'network_fetch_performed': False,
    }, indent=2))


if __name__ == '__main__':
    main()
