# Owned short TLS error data, Phase B

This isolated native candidate changes two functional paths and two comment-only
headers relative to Phase A. It is not production integration or the complete
PostgreSQL allocation gate. No PostgreSQL allocation exception is approved.
Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain user-deferred.

## Source and build

The immutable source input is the 8709-entry Phase A candidate, based on
BoringSSL d3bf4795ad5b79d646cddf2fec687da5b9b502db. Its matching libraries are
libssl.a 48e2928a79013579ddec9dea7bd1d750771e30a35d5091182db26af5555e960d
and libcrypto.a 2143f831f9f57907f47a51dfc0fae9942f33b8c3ca6d378cca6cc90b387ea4dd.
Protected vendor trees and previous producers remain unchanged.

`stage_b.patch` changes crypto/err/err.cc and ssl/tls_record.cc, with comments
only in crypto/err/internal.h and include/openssl/ssl.h. The cumulative
`candidate.patch` and `candidate_source/` cover fifteen paths. All 8709 source
entries are inventoried. `source_invariants.json` proves twenty-one existing
reservation, generic snapshot, formatter and mark function bodies unchanged,
and verifies that both header changes contain no code changes.

The full matching native Zig Debug build passed all six steps, including all
38 SSL translation units and crypto, using unchanged build inputs/source lists.
Compiler SHA is 2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c.
Actual matching libraries remain external to the selected evidence payload:

- libssl.a: b0b35e16a11c00529cbae09abab58d18cf5ec84c7596aff600d59267db0aba30
- libcrypto.a: e9cb29281bbc2b4dabb17863c1f7fbc51fdb93cb6ad2bdd016b481be443a1d9a

Compilation/linking use Zig only. Source restoration/evidence scripts do not
introduce a library build requirement.

## Ownership and memory

Each private error entry retains its data pointer and adds its own 32-byte
array. Null is absent data; a pointer to that entry's array is inline data;
every other non-null pointer owns a raw malloc block. The thread's popped-data
owner has a separate 32-byte array. No queue, saved-state or SSL array is
borrowed by another owner.

Copied payloads up to 31 bytes plus NUL use inline storage. Longer data retains
full heap spill; this threshold never truncates or rejects text. Empty text is
present data and returns STRING|MALLOCED, while an unset entry returns flags0.
Output MALLOCED means queue-owned non-static lifetime, not caller ownership.
Input MALLOCED independently requires OPENSSL_malloc provenance and is consumed
with OPENSSL_free once after either a successful or failed copy attempt.

Short replacement stages aliased bytes before clearing the old entry. Long
replacement duplicates before commit, so spill OOM preserves prior text and
metadata. Snapshot copy still clears its destination first; spill OOM keeps
the baseline best-effort metadata with absent optional text and reset marks.
Data-only setters preserve metadata and marks. Inline pop copies into the
independent thread slot; heap pop transfers ownership. Returned pointers are
assigned after this transfer and survive snapshot/SSL destruction until the
next call affecting that thread's queue.

Generic printf/concatenation generation and raw-buffer adoption remain intact,
including short formatted heap data and its original lifetime. Only the known
peer-alert text uses a checked 21-byte stack snprintf and copy-taking setter.
Fatal reason, callback order, malformed-alert rejection and no-response behavior
remain unchanged. Replacing old heap data or consuming MALLOCED input can free
memory even when the new text fits inline; there is no arbitrary-history zero
heap-operation promise.

Compiler layout proof in `layout_corrected/` measures this x86_64 Linux build:

| Private type | Phase A | Phase B |
| --- | ---: | ---: |
| Error entry | 24 | 56 |
| Thread ERR_STATE | 400 | 944 |
| Reserved fifteen-entry owner | 368 | 848 |
| Generic snapshot header | 16 | 16 |
| SSL3_STATE | 656 | 656 |

Alignment is eight bytes for these measured types. Two reserved startup owners
request 1696 raw C bytes, 960 more than Phase A; per-thread ERR storage grows by
544 bytes. The separate thread-local pointer table remains forty bytes, so a
cold other-thread restore requests 984 bytes in two mallocs. These values are
private host measurements, not public ABI promises. Other platform/runtime
gates remain separate.

## Direct RED and GREEN

`baseline_data_direct` was built and run against immutable Phase A before native
edits. All twelve functional rows pass; observe exits0 and the short-storage
gate exits1 after identical results. `candidate_data_direct` uses the exact same
source and counter against the new libraries; both modes exit0. The original
all-C counter is afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac,
with its unchanged 63-byte malloc/calloc/realloc/free self-test.

The measured setter/reserved-capture/restore/pop intervals change as follows:

| Payload | Phase A mallocs/requested bytes | Phase B |
| --- | --- | --- |
| Unset data | 0/0 | 0/0 |
| Empty text | 3/3 | 0/0 |
| 30 bytes | 3/93 | 0/0 |
| 31 bytes | 3/96 | 0/0 |
| 32 bytes | 3/99 | 3/99 |
| 6000 bytes | 3/18003 | 3/18003 |

Short whole/suffix alias replacement and full fifteen-entry wrap/mark/shrink
controls also become zero. Generic printf still allocates64 bytes and
concatenation10 bytes with original adoption timing. Valid short MALLOCED input
still incurs its required one input free. Generic one-entry saved-state capture
remains allocating: two allocations/72 bytes (header16 plus record56), versus
three/72 before (header16, record24 and copied32-byte string). Equal bytes in
that one example do not imply unchanged private record sizes.

`data_faults_candidate` adds twenty-one bounded ownership/fault/destructor rows:

- Warm short setter/capture/restore/pop succeeds under persistent raw-malloc
  failure without making any allocation attempt.
- Nonuniform long whole aliases preserve old text on OOM, and successful whole,
  32-byte and 31-byte suffix replacements copy before freeing old heap data.
- Length1, first/last peeks, popped-pointer validity before mutation,
  pop-without-data, remove-thread-state and setter mark preservation are checked.
- Valid OPENSSL inputs are consumed once on short/long success and spill OOM.
  An explicit default-allocator prefix/payload watch verifies OPENSSL_free erasure;
  arbitrary raw error data has no erasure contract.
- Both independent long-copy failures in reserved capture/restore and persistent
  failure of both copies preserve complete metadata and the expected optional
  data omissions. Generic header/array and both spill allocation failures are
  checked separately.
- Mixed fifteen-to-one-to-zero snapshots release stale long owners exactly once.
  Real pthread destruction handles popped inline, queued/popped long, and raw
  formatted short heap data; tracked raw long blocks balance2/2 and formatted
  heap data1/1. Thread startup storage is outside these data-owner watches.

These fault checks use the separately documented `data_fault.c` observer
derivative, not the original zero-proof counter. It adds persistent failure,
raw-owner watches and parent-visible post-thread-destructor accounting. All
fixed observation storage is test-only.

## Inherited controls and source restoration

All twenty-one Phase A selected programs rebuild and pass with the new libraries.
The generic/reserved profiles under `inherited_phase_a/` both use the current
matching pair; they are not mislabeled as the prior native library comparison.
The prior actual library comparison remains `baseline_data_direct` above.

Fourteen Phase A source/runner inputs and their originals are retained. Only
three C++ inputs have exact documented arithmetic changes in
`inherited_phase_a/input_lineage.json`: generic eight-capture bytes320 to576;
cold worker440 to984; two owner bytes736 to1696; cold factory400/440 to944/984.
No assertion, test, allocation family or ownership check is removed. These
updates follow measured entry56, worker944, owner848, header16 and table40.

The fifty-one older source/data inputs and the record orchestration driver stay
byte-identical. Output/sealer23-lifetime, AEAD24 epochs/12 initializer failures/
48 transitions/22-lifetime, incoming-handshake64 loops/21-lifetime,
record16-lifecycle/buffer/pair, and HKDF1440 differential controls all pass.
The 700 successful HKDF cases remain zero and 740 rejection results match.

Both restore modes reproduce all 8709 file types, modes, hashes and links:

```
python3 restore_source.py ORIGINAL_SOURCE ABSENT_OUTPUT
python3 restore_source.py --source-kind error-snapshot PHASE_A_SOURCE ABSENT_OUTPUT
```

Two existing-output, chmod-only and wrong-source-kind refusals happen before
creating an output directory. Full source trees, caches and raw native archives
are not selected payload members.

## Prebuilt replay and limits

`prebuilt_identity.json` selects twenty-four measured Debug executables. Replay
requires Python plus the external checksum-verified offline PKI helper:

```
python3 replay_prebuilt.py --pki-tool PKI_TOOL --output ABSENT_OUTPUT
```

The producer replay passes91 commands, including the deliberately expected
baseline short-gate exit1; all other commands exit0. Full recorded outputs match
and private PKI is removed. Five guards reject existing/inside-producer output,
wrong PKI helper, wrong binary inventory and a corrupted selected binary before
writing results. Their raw logs are retained, and the guard driver regenerates
its corrupt copies outside the producer. No private certificate/key bytes,
preliminary executable, native object/library or cache is selected.

The first layout probe incorrectly combined err.cc's deliberate
OPENSSL_malloc prohibition with SSL templates requiring that declaration. Its
failed source/log are retained. Separate ERR and SSL probes pass and produce
the layout proof above. No native source fix, macro weakening or failed-build
success claim followed from this fixture-only error.

Authentic peer-alert RED/GREEN and broader protocol controls are in the separate
wire producer. This producer establishes native ownership and inherited helper
evidence only. Production adoption, SQL teardown/cancellation/reconnect
attribution, maintained publication and PostgreSQL's complete request-path
allocation proof remain open.
