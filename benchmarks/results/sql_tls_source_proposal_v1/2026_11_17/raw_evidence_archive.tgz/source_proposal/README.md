# Compact BoringSSL proposal evidence

This payload contains a 17,000-byte prerequisite Git bundle for local proposal
`33406dd2383eff3e84059a763933b010cc5a663d`. It requires the exact official base
`d3bf4795ad5b79d646cddf2fec687da5b9b502db`.
**Complete base history is NOT embedded in this compact payload or bundle.**
Restoration needs an external local repository containing the complete official
base history, with its `HEAD` checked out at that exact base.

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| Included `boringssl_sql_client_tls_prerequisite.bundle` | 17000 | `fcd2eef3395e42b4198abe7d055038031b7438dbbfa40f44a4ef8fd731918da6` |
| External full-history `boringssl_sql_client_tls.bundle` | 253386995 | `d0d16daccb4a4c90131e6183d769194e9547622f608c19ec92485d2ff5be99be` |

The full-history bundle remains in the parent ignored SSD scratch directory,
outside root Git and outside this compact payload. Its use is optional when an
exact official base repository is already available. `external_inputs.json`
identifies that bundle, the official base, original source datasets, native build
outputs and previously delivered functional evidence as external inputs.
No local Git object database, base checkout, full source tree, compiler, native
archive or functional test executable is embedded here.

## Proposal and source origin

The immutable local commit is named
`uwz(sql): reserve client TLS storage and diagnostics`. Its parent is the exact
official base, and its tree is `9bba91e966828b1d5e8ab51f9721a39446febc04`.
It contains only the fifteen reviewed candidate file contents, as one initial
cumulative proposal. It preserves every official Git mode and unchanged blob.
No native source change, remote publication, repository creation or production
pin update was performed for this compact packaging.

The retained origin reports compare all 8,709 original files against the exact
Google upstream Git tree by SHA256 and type, with no extra or missing paths.
The extracted source package has 59 executable-bit differences (55 added, four
removed), fully enumerated in `evidence/source_origin.json`. None intersects the
407 native C/C++/assembly inputs, 167 `gen/` entries or fifteen changed paths.
Raw extracted-package modes differ from conventional Git checkout modes; the
proposal preserves official executable identity and exact reviewed content.

`evidence/` includes both full inventories, official blob mappings, the complete
proposal diff, candidate provenance and existing build/invariant result records.
Full source directories and native runtime evidence referenced by those records
are external, as declared in `external_inputs.json`.

## Offline restore and validation

From the extracted payload, provide an existing complete-history local base
repository with `HEAD` exactly at the official base, and choose an absent output:

```sh
python3 restore_prerequisite_bundle.py \
  boringssl_sql_client_tls_prerequisite.bundle \
  /absolute/path/to/official-base-repository \
  /absolute/absent/output
python3 verify_restored_source.py /absolute/absent/output
```

The helper rejects an existing destination, wrong bundle checksum, unexpected
bundle prerequisite/ref, wrong base `HEAD`/tree, or shallow base before creating
output. It fetches only exact base ancestry from the local base repository and
proves the candidate commit object is absent before fetching the bundle. It then
checks the proposal commit/parent/tree, clean working tree, `git diff --check`
and `git fsck --full --strict`. It performs no network fetch.

`base_fixture_verification.json` records that the base-only test fixture contains
10,637 official commits and no candidate object. `bundle_identity.json` records
the exact prerequisite and the expected verification failure in an empty Git
repository. `restore_roundtrip.json` records successful offline restoration using
the final helper. `restored_source_verification.json` checks all 8,709 restored
file contents against the reviewed candidate inventory and all modes against
official Git. `restore_guard_checks.json` records rejection of existing output,
wrong base and wrong bundle, with no new output created in the latter two cases.

The base-only fixture and restored repositories used for these checks are
external local validation workspaces and are not included in the compact archive.
Native runtime builds/tests were not rerun for this Git packaging. Dedicated
smoke, security, sanitizer, fuzz and scan campaigns remain user-deferred.
This evidence does not complete the PostgreSQL allocation contract and creates
no PostgreSQL allocation exception.
