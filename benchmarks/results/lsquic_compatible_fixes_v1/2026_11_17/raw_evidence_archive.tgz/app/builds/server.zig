const std = @import("std");
const boringssl = @import("vendor/boringssl.zig");
const libdeflate = @import("vendor/libdeflate.zig");
const lsquic = @import("vendor/lsquic.zig");
const sanitizers = @import("sanitizers.zig");
const zlib = @import("vendor/zlib.zig");

pub fn configure(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const sanitizer = sanitizers.configure(b, target, true);
    const project_path = b.option([]const u8, "project-source", "Actual project checkout") orelse "/home/foo/Desktop/Repos/uWebZockets";
    const project: std.Build.LazyPath = .{ .cwd_relative = project_path };
    const bssl = boringssl.build(b, target, optimize, sanitizer);
    const deflate = libdeflate.build(b, target, optimize, sanitizer);
    const z = zlib.build(b, target, optimize, sanitizer);
    const ls = lsquic.build(b, target, optimize, sanitizer, bssl, z, false, false, false);
    const xev_source = b.option([]const u8, "libxev-source", "Explicit reviewed scratch libxev source tree") orelse "/tmp/uwz-gro-libxev";
    const xev_impl = b.createModule(.{
        .root_source_file = .{ .cwd_relative = b.pathJoin(&.{ xev_source, "src/main.zig" }) },
        .target = target,
        .optimize = optimize,
    });
    const xev = b.createModule(.{
        .root_source_file = project.path(b, "src/core/xev.zig"),
        .target = target,
        .optimize = optimize,
        .imports = &.{.{ .name = "xev_impl", .module = xev_impl }},
    });
    const options = b.addOptions();
    options.addOption(bool, "sql", false);
    options.addOption(bool, "sqlite", false);
    const translate = b.addTranslateC(.{
        .root_source_file = project.path(b, "src/c.h"),
        .target = target,
        .optimize = optimize,
    });
    translate.addIncludePath(ls.include_root);
    translate.addIncludePath(bssl.include_root);
    translate.addIncludePath(deflate.include_root);
    translate.addIncludePath(z.include_root);
    const public = b.createModule(.{
        .root_source_file = project.path(b, "src/root.zig"),
        .target = target,
        .optimize = optimize,
        .imports = &.{
            .{ .name = "c", .module = translate.createModule() },
            .{ .name = "zslay", .module = b.dependency("zslay", .{ .target = target, .optimize = optimize }).module("zslay") },
            .{ .name = "xev", .module = xev },
            .{ .name = "module_options", .module = options.createModule() },
        },
    });
    const module = b.createModule(.{
        .root_source_file = b.path("server/main.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
        .link_libcpp = true,
        .imports = &.{.{ .name = "uWebZockets", .module = public }},
    });
    module.addIncludePath(ls.include_root);
    module.addIncludePath(bssl.include_root);
    module.addIncludePath(deflate.include_root);
    module.addIncludePath(z.include_root);
    module.addCSourceFile(.{ .file = project.path(b, "src/quic/lsquic_shim.c"), .flags = &.{"-std=c11"} });
    module.linkLibrary(ls.library);
    module.linkLibrary(bssl.ssl);
    module.linkLibrary(bssl.crypto);
    module.linkLibrary(deflate.library);
    module.linkLibrary(z.library);
    sanitizer.attach(module);
    const executable = b.addExecutable(.{ .name = "uwz_wt_independent_server", .root_module = module });
    b.installArtifact(executable);
    b.step("server", "Build bounded public-App acceptance server").dependOn(b.getInstallStep());
    const checks = b.addTest(.{ .name = "uwz_wt_fixture_identity", .root_module = module });
    const run_checks = b.addRunArtifact(checks);
    b.step("fixture-check", "Verify fixture route and generation guards").dependOn(&run_checks.step);
}
