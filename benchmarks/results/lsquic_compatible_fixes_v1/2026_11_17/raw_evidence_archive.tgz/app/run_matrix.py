import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

base = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--mode', choices=['Debug', 'ReleaseSafe', 'ReleaseFast'], required=True)
parser.add_argument('--run-id', default='final_v1')
args = parser.parse_args()
assert re.fullmatch(r'[a-z0-9_]+', args.run_id), 'invalid run identifier'
client = base / 'client/wt-oracle'
tools = base / 'client/wt-tools'
server = (base / 'server/out/bin/uwz_wt_independent_server' if args.mode == 'ReleaseSafe' else base / 'profiles' / args.mode / 'bin/uwz_wt_independent_server')
expected = {
    'Debug': '8ab0ffa274f349f2f45562af00bde7b1bc3e53edaf33daf496698e9045e91683',
    'ReleaseSafe': '75de0181f97466ea8024bfd7fa90da9368d20bf3d1b66d5fe4ff6991bf57a376',
    'ReleaseFast': '77977b5818142d2ecf5eb602d7f9c15772489ffd5fbe9f43e7961d5bd3cd4e59',
}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(client) == 'f86131a9e58cec24cf9ba94a8d2e191db667e0506ae5fa6cba6c2775a1fda178'
assert sha(server) == expected[args.mode]
pki = base / 'root_pki'
assert all((pki / n).exists() for n in ['ca.pem', 'server.pem', 'server.key'])
assert (pki / 'server.key').stat().st_mode & 0o777 == 0o600
cases = [
    ('legacy', 'datagrams', 'legacy', 'off', 1, '/wt', 1),
    ('datagrams', 'datagrams', 'positive', 'on', 2, '/wt', 1),
    ('streams', 'streams', 'positive', 'on', 1, '/wt', 1),
    ('reset', 'reset', 'positive', 'on', 1, '/wt', 1),
    ('flow', 'flow', 'positive', 'on', 1, '/wt', 1),
    ('credit', 'credit', 'positive', 'on', 1, '/wt', 1),
    ('isolation', 'isolation', 'positive', 'on', 2, '/wt', 1),
    ('connections', 'connections', 'positive', 'on', 2, '/wt', 1),
    ('namespace', 'datagrams', 'positive', 'on', 2, '/namespace', 2),
]
out = base / 'root_logs'
out.mkdir(exist_ok=True)
result_path = out / f'matrix_{args.mode}_{args.run_id}.json'
assert not result_path.exists(), result_path
results = {'mode': args.mode, 'run_id': args.run_id, 'client_sha256': sha(client), 'server_sha256': sha(server), 'root_commit': '77318a4ef6ae6dc74cfd156ad5a2b4f4bca414fb', 'native_commit': 'ed8f8f7642fbf4fc9399a0a6bb8f90b281e1f300', 'cases': [], 'complete': False}

def save():
    result_path.write_text(json.dumps(results, indent=2) + '\n')

save()
for name, scenario, profile, flow, sessions, route, source in cases:
    stem = f'{args.mode}_{name}_{args.run_id}'
    server_log = out / f'{stem}_server.log'
    client_log = out / f'{stem}_client.json'
    client_err = out / f'{stem}_client.stderr'
    assert not any(p.exists() for p in [server_log, client_log, client_err])
    port = json.loads(subprocess.check_output([str(tools), 'port'], text=True))['port']
    authority = f'https://127.0.0.1:{port}'
    server_cmd = [str(server), str(port), str(pki/'server.pem'), str(pki/'server.key'), profile]
    client_cmd = [str(client), 'product', '--scenario', scenario, '--url', authority+route, '--origin', authority, '--ca', str(pki/'ca.pem'), '--flow-control', flow, '--sessions', str(sessions), '--source', str(source), '--timeout', '45s']
    row = {'name': name, 'scenario': scenario, 'profile': profile, 'flow': flow, 'sessions': sessions, 'source': source, 'port': port, 'server_command': server_cmd, 'client_command': client_cmd, 'server_log': server_log.name, 'client_log': client_log.name, 'client_stderr': client_err.name}
    process = None
    failure = None
    try:
        with server_log.open('wb') as log:
            process = subprocess.Popen(server_cmd, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            row['owned_server_pid'] = process.pid
            end = time.monotonic() + 10
            while f'UWZ_READY port={port} profile={profile}' not in server_log.read_text(errors='replace'):
                if process.poll() is not None:
                    raise RuntimeError('server exited before READY')
                if time.monotonic() >= end:
                    raise RuntimeError('server READY deadline expired')
                time.sleep(0.01)
            with client_log.open('wb') as stdout, client_err.open('wb') as stderr:
                response = subprocess.run(client_cmd, stdout=stdout, stderr=stderr, timeout=60)
            row['client_exit_code'] = response.returncode
            if response.returncode != 0:
                raise RuntimeError('client returned nonzero')
            data = json.loads(client_log.read_text())
            assert data['pass'] is True and data['product_interop_verified'] is True
            assert data['webtransport_go_revision'] == '2a2b547d91a8a70e313e7ce61538b066554021b5'
            assert data['quic_go_revision'] == '793f74d8e03368c5aded128af6f48d21dbb47f73'
            assert data['product']['server_report_reconciled'] is True
            row['client_reconciled'] = True
    except Exception as error:
        failure = str(error)
        row['failure'] = failure
    finally:
        if process is not None:
            if process.poll() is None:
                process.send_signal(signal.SIGINT)
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                    row['forced_cleanup'] = True
            row['server_exit_code'] = process.returncode
        text = server_log.read_text(errors='replace') if server_log.exists() else ''
        row['normal_drain_marker'] = bool(re.search(r'UWZ_DRAINED .*errors=0 overflow=false', text))
        for key, path in [('server_log_sha256', server_log), ('client_log_sha256', client_log), ('client_stderr_sha256', client_err)]:
            if path.exists(): row[key] = sha(path)
        row['pass'] = failure is None and row.get('server_exit_code') == 0 and row['normal_drain_marker'] and not row.get('forced_cleanup', False)
        results['cases'].append(row)
        save()
    print(f"{args.mode} {name}: {'PASS' if row['pass'] else 'FAIL'} client={row.get('client_exit_code')} server={row.get('server_exit_code')}", flush=True)
    if not row['pass']:
        raise SystemExit(f'failed case {name}; see retained logs and {result_path}')
results['complete'] = True
save()
print(f'{args.mode}: all {len(cases)} cases passed', flush=True)
