#!/bin/sh
set -eu
uwz_base=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
uwz_mode=${1:-Debug}
uwz_run_id=${UWZ_RUN_ID:-replay_v1}
case "$uwz_mode" in Debug|ReleaseSafe|ReleaseFast) ;; *) exit 2 ;; esac
umask 077
uwz_created_pki=false
cleanup()
{
    if test "$uwz_created_pki" = true; then
        rm -f -- "$uwz_base/root_pki/ca.pem" "$uwz_base/root_pki/server.pem" "$uwz_base/root_pki/server.key"
        rmdir -- "$uwz_base/root_pki"
    fi
}
trap cleanup EXIT HUP INT TERM
if ! test -d "$uwz_base/root_pki"; then
    "$uwz_base/client/wt-tools" pki "$uwz_base/root_pki" > "$uwz_base/replay_pki_metadata.json"
    uwz_created_pki=true
fi
python3 "$uwz_base/run_matrix.py" --mode "$uwz_mode" --run-id "$uwz_run_id"
