#!/usr/bin/env python3
"""Restore the unchanged client executables from their retained offline artifact."""
import argparse
import hashlib
from pathlib import Path
import tarfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repository_root', type=Path)
    arguments = parser.parse_args()
    archive = arguments.repository_root / 'benchmarks/results/webtransport_independent_client_v1/2026_11_17/raw_evidence_archive.tgz'
    expected_archive = '11fe77a53dc966f924f3dc76f2b9ecbafedadfa7c4dd75b18edb7f40d491eb44'
    if hashlib.sha256(archive.read_bytes()).hexdigest() != expected_archive:
        raise ValueError('The retained client artifact checksum differs')
    entries = (
        ('wt-oracle', 11921687, 'f86131a9e58cec24cf9ba94a8d2e191db667e0506ae5fa6cba6c2775a1fda178'),
        ('wt-tools', 5252542, '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9'),
    )
    payloads = []
    with tarfile.open(archive, 'r:gz') as source:
        for name, size, digest in entries:
            member = source.getmember('client/' + name)
            if not member.isfile() or member.size != size:
                raise ValueError('Unexpected client artifact member: ' + name)
            with source.extractfile(member) as stream:
                payload = stream.read(size + 1)
            if len(payload) != size or hashlib.sha256(payload).hexdigest() != digest:
                raise ValueError('The client executable checksum differs: ' + name)
            payloads.append((name, digest, payload))
    destination = Path(__file__).resolve().parent / 'client'
    if destination.is_symlink():
        raise ValueError('Client destination must not be a symlink')
    destination.mkdir(exist_ok=True)
    for name, digest, payload in payloads:
        target = destination / name
        if target.exists() or target.is_symlink():
            if target.is_symlink() or not target.is_file():
                raise ValueError('Unexpected existing client destination: ' + name)
            if hashlib.sha256(target.read_bytes()).hexdigest() != digest:
                raise ValueError('Refusing to replace an existing executable: ' + name)
            if target.stat().st_mode & 0o111 == 0:
                raise ValueError('Existing client file is not executable: ' + name)
            continue
        with target.open('xb') as output:
            output.write(payload)
        target.chmod(0o755)
        print('Restored verified executable: ' + name)


if __name__ == '__main__':
    main()
