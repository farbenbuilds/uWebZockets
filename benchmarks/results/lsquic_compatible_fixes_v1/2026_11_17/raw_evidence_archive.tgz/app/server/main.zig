const std = @import("std");
const uz = @import("uWebZockets");
const wt = uz.webtransport_stream;
const children = @import("children.zig");
const max_sessions = 8;
const max_datagrams = 64;
const max_payload = 1200;

fn builder(io: std.Io, comptime positive: bool) @TypeOf(uz.Server.builder(io).with_max_clients(16).with_write_queue_size(2 * 1024 * 1024).with_webtransport_datagrams(max_payload, 64).with_webtransport_flow_limits(if (positive) .{ .data = 32, .streams_bidi = 1, .streams_uni = 1 } else .{})) {
    return uz.Server.builder(io).with_max_clients(16).with_write_queue_size(2 * 1024 * 1024).with_webtransport_datagrams(max_payload, 64).with_webtransport_flow_limits(if (positive) .{ .data = 32, .streams_bidi = 1, .streams_uni = 1 } else .{});
}
const App = @TypeOf(builder(undefined, true)).AppType;
const Session = struct {
    source: u16,
    ordinal: u16,
    connection_index: usize,
    generation: u64,
    session_id: u64,
    open: bool = true,
    closed: bool = false,
    open_count: usize = 1,
    closed_count: usize = 0,
    handle: wt.SessionHandle,
};
const ReportSession = struct { source: u16, ordinal: u16, connection_index: usize, generation: u64, session_index: usize, session_generation: u64, session_id: u64, open: bool, closed: bool, open_count: usize, closed_count: usize };
const ReportCommand = struct { command_id: u64, source: u16, ordinal: u16, direction: wt.Direction, size: usize, hold: bool, attempts: u32, result: []const u8, error_name: ?[]const u8, handle: ?children.Identity };
const Datagram = struct {
    source: u16,
    ordinal: u16,
    connection_index: usize,
    connection_generation: u64,
    session_id: u64,
    hex: []const u8,
};
const RingDatagram = struct { source: u16, ordinal: u16, connection_index: usize, connection_generation: u64, session_id: u64, sequence: u64, hex: []const u8 };
const Route = struct { state: *State, source: u16, ordinal: u16 };
const State = struct {
    app: *App,
    origin: []const u8,
    overflow: bool = false,
    sessions: [max_sessions]Session = undefined,
    session_count: usize = 0,
    datagrams: [max_datagrams]Datagram = undefined,
    datagram_hex: [max_datagrams][max_payload * 2]u8 = undefined,
    datagram_count: usize = 0,
    ring: [max_datagrams]RingDatagram = undefined,
    ring_hex: [max_datagrams][max_payload * 2]u8 = undefined,
    ring_count: usize = 0,
    child_state: children.State = .{},
};
const Report = struct { overflow: bool, errors: []const []const u8, sessions: []const ReportSession, datagrams: []const Datagram, ring: []const RingDatagram, children: []const children.Record, commands: []const ReportCommand };

fn hex_encode(buffer: []u8, bytes: []const u8) []const u8 {
    const alphabet = "0123456789abcdef";
    for (bytes, 0..) |byte, index| {
        buffer[index * 2] = alphabet[byte >> 4];
        buffer[index * 2 + 1] = alphabet[byte & 15];
    }
    return buffer[0 .. bytes.len * 2];
}

fn route_from(context: *anyopaque) *Route {
    return @ptrCast(@alignCast(context));
}

fn resolve_session(route: *Route, handle: wt.SessionHandle) ?*Session {
    const state = route.state;
    for (state.sessions[0..state.session_count]) |*session| {
        if (!std.meta.eql(session.handle, handle)) continue;
        if (session.source == route.source and session.ordinal == route.ordinal) return session;
        children.note_error(&state.child_state, "SessionCallbackRouteMismatch");
        return null;
    }
    children.note_error(&state.child_state, "UnknownSessionCallbackHandle");
    return null;
}

fn resolve_child(route: *Route, handle: wt.Handle) ?*children.Child {
    const state = route.state;
    const child = children.find(&state.child_state, handle) orelse return null;
    if (child.record.source != route.source or child.record.ordinal != route.ordinal) {
        children.note_error(&state.child_state, "ChildCallbackRouteMismatch");
        return null;
    }
    const session = resolve_session(route, child.session) orelse return null;
    if (session.session_id != child.record.session_id) {
        children.note_error(&state.child_state, "ChildCallbackSessionMismatch");
        return null;
    }
    return child;
}

fn session_open(context: *anyopaque, info: wt.SessionInfo) void {
    const route = route_from(context);
    const state = route.state;
    for (state.sessions[0..state.session_count]) |*session| {
        if (std.meta.eql(session.handle, info.handle)) {
            if (session.source != route.source or session.ordinal != route.ordinal) children.note_error(&state.child_state, "SessionCallbackRouteMismatch");
            session.open_count += 1;
            children.note_error(&state.child_state, "DuplicateSessionOpen");
            return;
        }
    }
    if (state.session_count == max_sessions) {
        state.overflow = true;
        return;
    }
    state.sessions[state.session_count] = .{ .source = route.source, .ordinal = route.ordinal, .connection_index = info.handle.connection_index, .generation = info.handle.connection_generation, .session_id = info.session_id, .handle = info.handle };
    state.session_count += 1;
}

fn session_closed(context: *anyopaque, event: wt.SessionClosedEvent) void {
    const route = route_from(context);
    const state = route.state;
    const session = resolve_session(route, event.handle) orelse return;
    if (session.session_id != event.session_id) {
        children.note_error(&state.child_state, "SessionCallbackIdMismatch");
        return;
    }
    session.closed = true;
    session.closed_count += 1;
    if (session.closed_count != 1) children.note_error(&state.child_state, "DuplicateSessionClose");
}

fn drain_ring(state: *State, connection_index: usize, connection_generation: u64) void {
    while (state.app.next_datagram(connection_index)) |value| {
        if (state.ring_count == max_datagrams or value.payload.len > max_payload) {
            state.overflow = true;
            return;
        }
        const index = state.ring_count;
        var source: u16 = 0;
        var ordinal: u16 = 0;
        for (state.sessions[0..state.session_count]) |session| {
            if (session.connection_index == connection_index and session.generation == connection_generation and session.session_id == value.session_id) {
                source = session.source;
                ordinal = session.ordinal;
                break;
            }
        }
        if (source == 0 or ordinal == 0) children.note_error(&state.child_state, "RingSessionIdentityMissing");
        state.ring[index] = .{ .source = source, .ordinal = ordinal, .connection_index = connection_index, .connection_generation = connection_generation, .session_id = value.session_id, .sequence = value.sequence_number, .hex = hex_encode(&state.ring_hex[index], value.payload) };
        state.ring_count += 1;
    }
}

fn datagram(context: *anyopaque, session_id: u64, payload: []const u8) void {
    const route = route_from(context);
    const state = route.state;
    if (state.datagram_count == max_datagrams or payload.len > max_payload) {
        state.overflow = true;
        return;
    }
    for (state.sessions[0..state.session_count]) |session| {
        if (session.closed or session.source != route.source or session.ordinal != route.ordinal or session.session_id != session_id) continue;
        const index = state.datagram_count;
        state.datagrams[index] = .{ .source = route.source, .ordinal = route.ordinal, .connection_index = session.connection_index, .connection_generation = session.generation, .session_id = session_id, .hex = hex_encode(&state.datagram_hex[index], payload) };
        state.datagram_count += 1;
        drain_ring(state, session.connection_index, session.generation);
        return;
    }
    state.overflow = true;
}

fn child_open(context: *anyopaque, info: wt.Info) bool {
    const route = route_from(context);
    const session = resolve_session(route, info.session) orelse return false;
    if (session.session_id != info.session_id) {
        children.note_error(&route.state.child_state, "ChildOpenSessionMismatch");
        return false;
    }
    return children.open(App, route.state.app, &route.state.child_state, route.source, route.ordinal, info);
}

fn child_data(context: *anyopaque, handle: wt.Handle, bytes: []const u8) bool {
    const route = route_from(context);
    _ = resolve_child(route, handle) orelse return false;
    const state = route.state;
    return children.data(App, state.app, &state.child_state, handle, bytes);
}

fn child_eof(context: *anyopaque, handle: wt.Handle, final_size: u64) void {
    const route = route_from(context);
    _ = resolve_child(route, handle) orelse return;
    const state = route.state;
    children.eof(App, state.app, &state.child_state, handle, final_size);
}

fn child_writable(context: *anyopaque, handle: wt.Handle) void {
    const route = route_from(context);
    const state = route.state;
    const child = resolve_child(route, handle) orelse return;
    child.record.writable_count += 1;
    children.flush(App, state.app, &state.child_state, child);
}

fn child_reset(context: *anyopaque, handle: wt.Handle, code: wt.ErrorCode, final_size: u64) void {
    const route = route_from(context);
    const state = route.state;
    const child = resolve_child(route, handle) orelse return;
    child.record.reset_code = children.numeric_code(code);
    child.record.reset_count += 1;
    if (child.record.reset_count != 1) children.note_error(&state.child_state, "DuplicateChildReset");
    child.record.reset_final_size = final_size;
}

fn child_stop(context: *anyopaque, handle: wt.Handle, code: wt.ErrorCode) void {
    const route = route_from(context);
    const state = route.state;
    const child = resolve_child(route, handle) orelse return;
    child.record.stop_code = children.numeric_code(code);
    child.record.stop_count += 1;
    if (child.record.stop_count != 1) children.note_error(&state.child_state, "DuplicateChildStop");
}

fn child_closed(context: *anyopaque, event: wt.ClosedEvent) void {
    const route = route_from(context);
    const state = route.state;
    const child = resolve_child(route, event.handle) orelse return;
    child.record.closed = true;
    child.record.closed_count += 1;
    if (child.record.closed_count != 1) children.note_error(&state.child_state, "DuplicateChildClose");
    child.record.closed_reason = event.reason;
    child.record.closed_final_size = event.final_payload_size;
    child.record.closed_accounted_bytes = event.accounted_bytes;
}

fn connect(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state = route_from(context).state;
    const origin = request.get_unique_header("origin") orelse "";
    if (!std.mem.eql(u8, origin, state.origin)) {
        response.end_best_effort("403 Forbidden", "Origin mismatch");
        return;
    }
    response.end_best_effort("200 OK", "");
}

fn health(_: *anyopaque, _: *uz.Request, response: *uz.Response) void {
    response.end_best_effort("200 OK", "ok");
}

fn report(context: *anyopaque, _: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    for (state.sessions[0..state.session_count]) |session| if (!session.closed) {
        drain_ring(state, session.connection_index, session.generation);
    };
    var records: [children.capacity]children.Record = undefined;
    for (state.child_state.children[0..state.child_state.count], 0..) |*child, index| records[index] = child.record;
    var sessions: [max_sessions]ReportSession = undefined;
    for (state.sessions[0..state.session_count], 0..) |session, index| sessions[index] = .{ .source = session.source, .ordinal = session.ordinal, .connection_index = session.connection_index, .generation = session.generation, .session_index = session.handle.index, .session_generation = session.handle.generation, .session_id = session.session_id, .open = session.open, .closed = session.closed, .open_count = session.open_count, .closed_count = session.closed_count };
    var commands: [children.capacity]ReportCommand = undefined;
    for (state.child_state.commands[0..state.child_state.command_count], 0..) |plan, index| commands[index] = .{ .command_id = plan.command_id, .source = plan.source, .ordinal = plan.ordinal, .direction = plan.direction, .size = plan.size, .hold = plan.hold, .attempts = plan.attempts, .result = plan.result, .error_name = plan.error_name, .handle = if (plan.handle) |handle| children.identity(handle) else null };
    const value = Report{ .overflow = state.overflow or state.child_state.overflow, .errors = state.child_state.errors[0..state.child_state.error_count], .sessions = sessions[0..state.session_count], .datagrams = state.datagrams[0..state.datagram_count], .ring = state.ring[0..state.ring_count], .children = records[0..state.child_state.count], .commands = commands[0..state.child_state.command_count] };
    var buffer: [2 * 1024 * 1024]u8 = undefined;
    response.json_buf(value, &buffer) catch |err| {
        state.overflow = true;
        std.log.err("report response: {s}", .{@errorName(err)});
    };
}

const ControlResponse = struct { command_id: u64, ok: bool, result: []const u8, error_name: ?[]const u8, handle: ?children.Identity, attempts: u32 };

fn respond_command(response: *uz.Response, plan: *const children.Command) void {
    var buffer: [512]u8 = undefined;
    response.json_buf(ControlResponse{ .command_id = plan.command_id, .ok = std.mem.eql(u8, plan.result, "ok"), .result = plan.result, .error_name = plan.error_name, .handle = if (plan.handle) |handle| children.identity(handle) else null, .attempts = plan.attempts }, &buffer) catch |err| std.log.err("control response: {s}", .{@errorName(err)});
}

fn control(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    control_inner(state, request, response) catch |err| {
        var buffer: [256]u8 = undefined;
        response.json_buf(.{ .command_id = @as(u64, 0), .ok = false, .result = "error", .error_name = @errorName(err) }, &buffer) catch |send_error| std.log.err("control error response: {s}", .{@errorName(send_error)});
    };
}

fn control_inner(state: *State, request: *uz.Request, response: *uz.Response) !void {
    const params = try request.query_params();
    const op = params.get("op") orelse return error.MissingOperation;
    if (std.mem.eql(u8, op, "finish") or std.mem.eql(u8, op, "retry")) {
        const id = (try params.get_int(u64, "command_id")) orelse return error.MissingCommand;
        const plan = children.command(&state.child_state, id) orelse return error.UnknownCommand;
        if (std.mem.eql(u8, op, "finish")) {
            children.finish(App, state.app, &state.child_state, plan);
        } else {
            if (plan.handle != null) return error.CommandAlreadyCreated;
            children.attempt(App, state.app, plan);
        }
        respond_command(response, plan);
        return;
    }
    const direction: wt.Direction = if (std.mem.eql(u8, op, "create_uni")) .uni else if (std.mem.eql(u8, op, "create_bidi")) .bidi else return error.UnknownOperation;
    const source = (try params.get_int(u16, "source")) orelse return error.MissingSource;
    const ordinal = (try params.get_int(u16, "ordinal")) orelse return error.MissingOrdinal;
    const size = (try params.get_int(usize, "size")) orelse return error.MissingSize;
    if (size > children.payload_capacity) return error.PayloadTooLarge;
    const hold_value = (try params.get_int(u8, "hold")) orelse 0;
    if (hold_value > 1) return error.InvalidHold;
    var selected: ?wt.SessionHandle = null;
    for (state.sessions[0..state.session_count]) |session| {
        if (session.source == source and session.ordinal == ordinal) {
            selected = session.handle;
            break;
        }
    }
    const session = selected orelse return error.UnknownSession;
    const plan = children.create(&state.child_state, source, ordinal, session, direction, size, hold_value == 1) orelse return error.CommandCapacityExceeded;
    children.attempt(App, state.app, plan);
    respond_command(response, plan);
}

fn serve(init: std.process.Init, port: u16, cert: [:0]const u8, key: [:0]const u8, comptime positive: bool) !void {
    var app = try builder(init.io, positive).build(std.heap.page_allocator);
    defer app.deinit();
    try app.enable_http3(cert, key);
    var origin_buffer: [64]u8 = undefined;
    const origin = try std.fmt.bufPrint(&origin_buffer, "https://127.0.0.1:{d}", .{port});
    var state = State{ .app = &app, .origin = origin };
    var routes = [_]Route{ .{ .state = &state, .source = 1, .ordinal = 1 }, .{ .state = &state, .source = 1, .ordinal = 2 }, .{ .state = &state, .source = 2, .ordinal = 1 }, .{ .state = &state, .source = 2, .ordinal = 2 } };
    const paths = [_][]const u8{ "/wt", "/other", "/namespace", "/namespace-other" };
    for (&routes, paths) |*route, path| {
        _ = try app.route_context(.connect, path, route, connect);
        _ = try app.datagram_context(path, route, datagram);
        _ = try app.webtransport_streams_context(path, route, .{ .open = child_open, .data = child_data, .eof = child_eof, .writable = child_writable, .reset = child_reset, .stop = child_stop, .closed = child_closed, .session_open = session_open, .session_closed = session_closed });
    }
    _ = try app.route_context(.get, "/health", &state, health);
    _ = try app.route_context(.get, "/report", &state, report);
    _ = try app.route_context(.get, "/control", &state, control);
    try app.listen_udp("127.0.0.1", port);
    try app.catch_shutdown_signals();
    std.log.info("UWZ_READY port={d} profile={s}", .{ port, if (positive) "positive" else "legacy" });
    try app.run();
    std.log.info("UWZ_DRAINED sessions={d} datagrams={d} ring={d} children={d} errors={d} overflow={}", .{ state.session_count, state.datagram_count, state.ring_count, state.child_state.count, state.child_state.error_count, state.overflow or state.child_state.overflow });
}

pub fn main(init: std.process.Init) !void {
    var args = std.process.Args.Iterator.init(init.minimal.args);
    _ = args.skip();
    const port = try std.fmt.parseInt(u16, args.next() orelse return error.MissingPort, 10);
    if (port == 0) return error.InvalidPort;
    const cert = args.next() orelse return error.MissingCertificate;
    const key = args.next() orelse return error.MissingKey;
    const profile = args.next() orelse return error.MissingProfile;
    if (std.mem.eql(u8, profile, "legacy")) return serve(init, port, cert, key, false);
    if (std.mem.eql(u8, profile, "positive")) return serve(init, port, cert, key, true);
    return error.InvalidProfile;
}

test "fixture rejects callbacks from another route and stale generations" {
    var state = State{ .app = undefined, .origin = "" };
    const parent = wt.SessionHandle{ .owner = 11, .connection_index = 0, .connection_generation = 3, .index = 1, .generation = 5 };
    const handle = wt.Handle{ .owner = 11, .index = 2, .generation = 7 };
    state.sessions[0] = .{ .source = 1, .ordinal = 1, .connection_index = 0, .generation = 3, .session_id = 0, .handle = parent };
    state.session_count = 1;
    state.child_state.children[0] = .{
        .record = .{ .source = 1, .ordinal = 1, .connection_index = 0, .connection_generation = 3, .session_index = 1, .session_generation = 5, .session_id = 0, .handle = children.identity(handle), .stream_id = 2, .direction = "peer_uni" },
        .handle = handle,
        .session = parent,
        .local = false,
        .bidi = false,
    };
    state.child_state.count = 1;
    var correct = Route{ .state = &state, .source = 1, .ordinal = 1 };
    var wrong = Route{ .state = &state, .source = 2, .ordinal = 1 };
    try std.testing.expect(resolve_session(&correct, parent) == &state.sessions[0]);
    try std.testing.expect(resolve_child(&correct, handle) == &state.child_state.children[0]);
    session_closed(&wrong, .{ .handle = parent, .session_id = 0, .reason = .completed });
    try std.testing.expect(!child_open(&wrong, .{ .handle = handle, .session = parent, .session_id = 0, .stream_id = 2, .direction = .uni, .initiator = .peer }));
    try std.testing.expect(!child_data(&wrong, handle, "x"));
    child_eof(&wrong, handle, 0);
    child_writable(&wrong, handle);
    child_reset(&wrong, handle, .{ .application = 42 }, 0);
    child_stop(&wrong, handle, .{ .application = 42 });
    child_closed(&wrong, .{ .handle = handle, .reason = .completed, .final_payload_size = 0, .accounted_bytes = 0 });
    try std.testing.expectEqual(@as(usize, 8), state.child_state.error_count);
    try std.testing.expectEqual(@as(usize, 0), state.sessions[0].closed_count);
    const record = state.child_state.children[0].record;
    try std.testing.expectEqual(@as(usize, 1), record.open_count);
    try std.testing.expectEqual(@as(usize, 0), record.data_count + record.eof_count + record.reset_count + record.stop_count + record.closed_count + record.writable_count);
    state.child_state.children[0].session.generation += 1;
    try std.testing.expect(!child_data(&correct, handle, "x"));
    var stale = handle;
    stale.generation += 1;
    try std.testing.expect(resolve_child(&correct, stale) == null);
    var stale_parent = parent;
    stale_parent.connection_generation += 1;
    try std.testing.expect(resolve_session(&correct, stale_parent) == null);
    try std.testing.expectEqual(@as(usize, 11), state.child_state.error_count);
    try std.testing.expectEqual(@as(usize, 0), state.child_state.children[0].record.received_len);
}
