const std = @import("std");
const wt = @import("uWebZockets").webtransport_stream;
pub const capacity = 32;
pub const payload_capacity = 8192;
pub const Identity = struct { index: usize, generation: u64 };
pub fn identity(handle: wt.Handle) Identity {
    return .{ .index = handle.index, .generation = handle.generation };
}
pub const Command = struct {
    command_id: u64,
    source: u16,
    ordinal: u16,
    direction: wt.Direction,
    size: usize,
    hold: bool,
    attempts: u32 = 0,
    result: []const u8 = "pending",
    error_name: ?[]const u8 = null,
    handle: ?wt.Handle = null,
    session: wt.SessionHandle,
};
pub const Record = struct {
    source: u16,
    ordinal: u16,
    connection_index: usize,
    connection_generation: u64,
    session_index: usize,
    session_generation: u64,
    session_id: u64,
    handle: Identity,
    stream_id: u64,
    direction: []const u8,
    command_id: ?u64 = null,
    received_hex: []const u8 = "",
    sent_hex: []const u8 = "",
    received_len: usize = 0,
    sent_len: usize = 0,
    eof: bool = false,
    finished: bool = false,
    reset_code: ?u64 = null,
    reset_final_size: ?u64 = null,
    stop_code: ?u64 = null,
    closed: bool = false,
    closed_reason: ?wt.CloseReason = null,
    closed_final_size: ?u64 = null,
    closed_accounted_bytes: u64 = 0,
    write_would_block: usize = 0,
    partial_writes: usize = 0,
    writable_count: usize = 0,
    open_count: usize = 1,
    data_count: usize = 0,
    eof_count: usize = 0,
    reset_count: usize = 0,
    stop_count: usize = 0,
    closed_count: usize = 0,
    write_calls: usize = 0,
};
pub const Child = struct {
    record: Record,
    handle: wt.Handle,
    session: wt.SessionHandle,
    received: [payload_capacity]u8 = undefined,
    outgoing: [payload_capacity]u8 = undefined,
    received_hex: [payload_capacity * 2]u8 = undefined,
    sent_hex: [payload_capacity * 2]u8 = undefined,
    outgoing_size: usize = 0,
    hold: bool = false,
    local: bool,
    bidi: bool,
};
pub const State = struct {
    children: [capacity]Child = undefined,
    count: usize = 0,
    commands: [capacity]Command = undefined,
    command_count: usize = 0,
    errors: [64][]const u8 = undefined,
    error_count: usize = 0,
    overflow: bool = false,
};

pub fn note_error(state: *State, name: []const u8) void {
    if (state.error_count == state.errors.len) {
        state.overflow = true;
        return;
    }
    state.errors[state.error_count] = name;
    state.error_count += 1;
}

pub fn find(state: *State, handle: wt.Handle) ?*Child {
    for (state.children[0..state.count]) |*child| if (std.meta.eql(child.handle, handle)) return child;
    note_error(state, "UnknownChildHandle");
    return null;
}

pub fn command(state: *State, id: u64) ?*Command {
    for (state.commands[0..state.command_count]) |*value| if (value.command_id == id) return value;
    return null;
}

pub fn hex_encode(buffer: []u8, bytes: []const u8) []const u8 {
    const alphabet = "0123456789abcdef";
    for (bytes, 0..) |byte, index| {
        buffer[index * 2] = alphabet[byte >> 4];
        buffer[index * 2 + 1] = alphabet[byte & 15];
    }
    return buffer[0 .. bytes.len * 2];
}

pub fn create(state: *State, source: u16, ordinal: u16, session: wt.SessionHandle, direction: wt.Direction, size: usize, hold: bool) ?*Command {
    if (state.command_count == capacity or size > payload_capacity) {
        state.overflow = true;
        return null;
    }
    const index = state.command_count;
    state.commands[index] = .{ .command_id = index + 1, .source = source, .ordinal = ordinal, .session = session, .direction = direction, .size = size, .hold = hold };
    state.command_count += 1;
    return &state.commands[index];
}

pub fn attempt(comptime App: type, app: *App, plan: *Command) void {
    plan.attempts += 1;
    const handle = app.webtransport_stream_create(plan.session, plan.direction) catch |err| {
        plan.result = if (err == error.WouldBlock) "would_block" else "error";
        plan.error_name = @errorName(err);
        return;
    };
    plan.handle = handle;
    plan.result = "ok";
    plan.error_name = null;
}

pub fn open(comptime App: type, app: *App, state: *State, source: u16, ordinal: u16, info: wt.Info) bool {
    for (state.children[0..state.count]) |*existing| {
        if (std.meta.eql(existing.handle, info.handle)) {
            existing.record.open_count += 1;
            note_error(state, "DuplicateChildOpen");
            return false;
        }
    }
    if (state.count == capacity) {
        state.overflow = true;
        return false;
    }
    const child = &state.children[state.count];
    child.* = .{
        .record = .{ .source = source, .ordinal = ordinal, .connection_index = info.session.connection_index, .connection_generation = info.session.connection_generation, .session_index = info.session.index, .session_generation = info.session.generation, .session_id = info.session_id, .handle = identity(info.handle), .stream_id = info.stream_id, .direction = if (info.initiator == .local) (if (info.direction == .uni) "local_uni" else "local_bidi") else (if (info.direction == .uni) "peer_uni" else "peer_bidi") },
        .handle = info.handle,
        .session = info.session,
        .local = info.initiator == .local,
        .bidi = info.direction == .bidi,
    };
    state.count += 1;
    if (child.local) {
        var plan: ?*Command = null;
        for (state.commands[0..state.command_count]) |*value| {
            if (value.handle) |handle| if (std.meta.eql(handle, info.handle)) {
                plan = value;
                break;
            };
        }
        const value = plan orelse {
            note_error(state, "UnknownLocalPlan");
            return false;
        };
        child.record.command_id = value.command_id;
        child.hold = value.hold;
        child.outgoing_size = value.size;
        const tag: usize = if (child.bidi) 73 else 41;
        for (child.outgoing[0..value.size], 0..) |*byte, index| byte.* = @truncate(index * 17 + @as(usize, source) * 7 + @as(usize, ordinal) * 3 + tag);
        arm(App, app, state, info.handle);
    }
    return true;
}

pub fn arm(comptime App: type, app: *App, state: *State, handle: wt.Handle) void {
    app.webtransport_stream_want_writable(handle, true) catch |err| note_error(state, @errorName(err));
}

pub fn flush(comptime App: type, app: *App, state: *State, child: *Child) void {
    if (child.record.closed or child.record.finished) return;
    while (child.record.sent_len < child.outgoing_size) {
        const suffix = child.outgoing[child.record.sent_len..child.outgoing_size];
        child.record.write_calls += 1;
        const size = app.webtransport_stream_write(child.handle, suffix) catch |err| {
            if (err == error.WouldBlock) {
                child.record.write_would_block += 1;
                arm(App, app, state, child.handle);
                return;
            }
            note_error(state, @errorName(err));
            return;
        };
        if (size == 0 or size > suffix.len) {
            note_error(state, "InvalidWritePrefix");
            return;
        }
        if (size < suffix.len) child.record.partial_writes += 1;
        child.record.sent_len += size;
        child.record.sent_hex = hex_encode(&child.sent_hex, child.outgoing[0..child.record.sent_len]);
    }
    if (child.hold or (!child.local and !child.record.eof)) return;
    app.webtransport_stream_finish(child.handle) catch |err| {
        note_error(state, @errorName(err));
        return;
    };
    child.record.finished = true;
}

pub fn data(comptime App: type, app: *App, state: *State, handle: wt.Handle, bytes: []const u8) bool {
    const child = find(state, handle) orelse return false;
    child.record.data_count += 1;
    if (bytes.len > payload_capacity - child.record.received_len) {
        state.overflow = true;
        return false;
    }
    @memcpy(child.received[child.record.received_len..][0..bytes.len], bytes);
    child.record.received_len += bytes.len;
    child.record.received_hex = hex_encode(&child.received_hex, child.received[0..child.record.received_len]);
    if (!child.local and child.bidi) {
        @memcpy(child.outgoing[child.outgoing_size..][0..bytes.len], bytes);
        child.outgoing_size += bytes.len;
        arm(App, app, state, handle);
    }
    return true;
}

pub fn eof(comptime App: type, app: *App, state: *State, handle: wt.Handle, final_size: u64) void {
    const child = find(state, handle) orelse return;
    child.record.eof = true;
    child.record.eof_count += 1;
    if (child.record.eof_count != 1) note_error(state, "DuplicateChildEof");
    if (final_size != child.record.received_len) note_error(state, "EofSizeMismatch");
    if (child.bidi and !child.local) arm(App, app, state, handle);
}

pub fn numeric_code(code: wt.ErrorCode) u64 {
    return switch (code) {
        .application => |value| value,
        .http3 => |value| value,
    };
}

pub fn finish(comptime App: type, app: *App, state: *State, plan: *Command) void {
    const handle = plan.handle orelse {
        plan.result = "error";
        plan.error_name = "CommandNotCreated";
        return;
    };
    const child = find(state, handle) orelse return;
    plan.hold = false;
    child.hold = false;
    if (!child.record.closed and !child.record.finished) arm(App, app, state, handle);
}
