const std = @import("std");
const server = @import("builds/server.zig");

pub fn build(b: *std.Build) void {
    server.configure(b);
}
