/* Copyright (c) 2026 LiteSpeed Technologies Inc.  See LICENSE. */
#include "lsquic.h"


void
lsquic_ietf_full_conn_test_path_exhaustion (unsigned flags, int ipv6);


int
main (void)
{
    const unsigned flags[] = { 0, LSENG_SERVER, LSENG_HTTP,
                               LSENG_SERVER | LSENG_HTTP };
    unsigned i;

    for (i = 0; i < sizeof(flags) / sizeof(flags[0]); ++i)
    {
        lsquic_ietf_full_conn_test_path_exhaustion(flags[i], 0);
        lsquic_ietf_full_conn_test_path_exhaustion(flags[i], 1);
    }
    return 0;
}
