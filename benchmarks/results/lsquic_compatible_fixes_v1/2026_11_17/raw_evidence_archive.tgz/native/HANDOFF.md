# LSQ-021 and LSQ-022 local backports

Frozen source: `/tmp/uwz-lsquic-upstream-backports-20261117`.
Base: `d1104a9fab040af659295a95fb448c971a7bc6de`.
LSQ-021: `8aca43c50bfa6995c3d007a8e75ad5145b5a2db8`.
LSQ-022/final: `ed8f8f7642fbf4fc9399a0a6bb8f90b281e1f300`.
Final tree: `26b4ecc1d026c2aa21a852c20a3f6d9e0ea7cbeb`.
The working tree is clean and all six changed-source hashes match independent
source review. Original candidates, root files, production pins and capability
flags were not changed by this implementation agent.

LSQ-021 adapts exact upstream `acd2bb73f681efeb28a7e32e4df1f8af61efbe1e`.
It stops buffered reads while QPACK is blocked or failed, rejects exhausted
prefixes, preserves decoder ownership, and also guards the candidate-only
reliable-reset header completion path. WebTransport classification and reliable
reset bounds remain intact. Adapted upstream tests preserve LSQ-001 stream-scoped
header errors, with a healthy same-connection sibling and exact header ownership.
A separate regression drives a real terminal decoder error, unblocks it, and
checks that reliable reset cannot resume or replace the retained decoder context.

LSQ-022 follows exact upstream `c638b57096d6a5bd0d6064382267c261bc7f9de4`.
Its entire production address-selection function matches upstream. A new private
assertion helper exercises the actual static function and full connection/path
layout: all-validated exhaustion, repeated tuples, every current/unvalidated
victim slot, existing tuple context refresh, and free-slot precedence. IPv4/IPv6
and four client/server HTTP/non-HTTP flag combinations preserve exact stored
addresses, flags, IDs, challenges, packet sizes, peer contexts and slot masks.
The helper is under the existing `#ifndef NDEBUG`; the ordinary test is registered
in the native test list and copied Zig harness. No new library build tool is used.

## Verified results

- Final-test RED on unchanged production: blocked prefix advanced beyond offset 3.
- Final-test reset-guard omission RED: terminal QPACK resume changed its context.
- Path RED before the production policy fix: validated path snapshot changed.
- Each targeted final GREEN: exit 0, 12/12 build steps.
- LSQ-021 original 83 plus reset subset: all 84 pass, 166/166 build steps.
- Combined final original 83 plus reset and path subsets: all 85 pass,
  168/168 build steps; exact distinct run names are retained in
  `combined_upstream_result.json`.
- Five retained executable cohorts pass in Debug, ReleaseSafe and ReleaseFast:
  receive, streams, stream_resets, reset_metadata and reset_headers. All 15
  process statuses and raw-log hashes are retained in `retained_matrix.json`.
  These native fixtures retain their synthetic clock/packet pumping and the
  receive fixture SETTINGS observer; Root owns the separate real public-App
  independent-client matrix.
- Independent read-only source reviews have no actionable findings.
- Fresh complete-object base import plus incremental bundle fetch passes strict
  `git fsck --full --strict`, with no alternates and exact final tip/tree.

`qpack_trial_records.json` distinguishes genuine REDs, fixture-adaptation trials,
removed diagnostic output, and two quota failures. The first all 84 log stopped
at 40960 bytes; the first path log is empty. Neither is test evidence. Both handles
were terminal before infrastructure retries. Root cleared only old inactive
reproducible cache/output data; assigned source and proof logs remained intact. The complete
retry and final matrices are retained separately.

## Replay and source recovery

`backports.bundle` is incremental and requires the original d110 commit from the
durable preceding publication-preparation archive. Import that complete original
history, verify the incremental bundle, fetch
`refs/heads/uwz/upstream-backports-20261117`, and check out final ed8. The fresh
import commands/statuses are recorded in `bundle_import_result.json`.
`changed_source/` and `combined_source.sha256` allow direct source inspection;
`lsq021.diff` and `lsq022.diff` preserve exact commit messages and changes.

The assertion-enabled external Zig scaffold is `harness/`; it uses Zig 0.16.0,
unchanged BoringSSL/QPACK/HPACK/zlib inputs from its pinned zon, and native Zig
source lists. Supply the existing offline package cache with `--system PATH`.
The actual cache was `/tmp/uwz-wt-child-callbacks-20261116/zig-pkg`; the
compiler was `/tmp/zig-x86_64-linux-0.16.0/zig` and global cache
`/tmp/uwz-zig-cache`. `harness/build.zig.zon` pins BoringSSL
`d3bf4795ad5b79d646cddf2fec687da5b9b502db`, QPACK
`91567706c41c0d97ab8dc576873ecd472d7869fa`, HPACK
`fda48e02491d865cce00612be8cc10c2622b8e55` and zlib 1.3.2, including
exact Zig package hashes.
For all 85 cases, run in `harness/`:

```sh
/tmp/zig-x86_64-linux-0.16.0/zig build test --system PATH \
  --cache-dir NEW_CACHE --global-cache-dir /tmp/uwz-zig-cache \
  -Dlsquic-source=RECOVERED_SOURCE -Dupstream-tests=true \
  -Doptimize=Debug -j2 --summary all
```

Add `-Donly=h3_framing_zero_size`, `-Donly=h3_framing_qpack_reset` or
`-Donly=uwz_path_exhaustion` for a focused case. The two RED source variants are
isolated clones in this implementation workspace; archived base/final commits,
final tests and `terminal_guard_mutation.json` identify their exact construction.
The path RED combines the unchanged LSQ-021 production function with the final
private helper/entrypoint, then checks the complete snapshot before the fix.

For retained cases, `replay_native.sh MODE CASE` accepts `UWZ_LSQUIC_SOURCE`,
`UWZ_ZIG`, `UWZ_PACKAGE_DIR`, `UWZ_CACHE_DIR` and `ZIG_GLOBAL_CACHE_DIR` overrides.
Use a fresh copied proof work directory when running the historical
`run_retained.py` matrix driver, which writes its output names in that directory.
Go/Python are not library build requirements; Python is external orchestration.

## Limits

These are unpublished proposals. Root owns the separate independent public-App
matrix and integration artifact. No dedicated smoke/security/sanitizer/fuzz/scan
campaign ran. Maintained-fork access, mirror synchronization/protection, reviewed
PR/merge, production pin/capability updates and broader v2.3.0 gates remain open.
No release or complete WebTransport activation is claimed here.
