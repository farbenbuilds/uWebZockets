from pathlib import Path
import subprocess, json, hashlib, datetime, os

proof = Path(__file__).resolve().parent
source = Path(os.environ.get('UWZ_LSQUIC_SOURCE', '/tmp/uwz-lsquic-upstream-backports-20261117'))
expected = 'ed8f8f7642fbf4fc9399a0a6bb8f90b281e1f300'
assert subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() == expected
cases = ['uwz_webtransport_receive', 'uwz_webtransport_streams', 'uwz_webtransport_stream_resets', 'uwz_reset_metadata', 'uwz_reset_headers']
rows = []
for mode in ['Debug', 'ReleaseSafe', 'ReleaseFast']:
    for case in cases:
        log = proof / (mode + '_' + case + '.log')
        command = ['sh', str(proof / 'replay_native.sh'), mode, case]
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with log.open('wb') as output:
            result = subprocess.run(command, cwd=proof, stdout=output, stderr=subprocess.STDOUT)
        row = {'mode': mode, 'case': case, 'command': command, 'started_utc': started, 'exit_code': result.returncode, 'log': log.name, 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
        rows.append(row)
        (proof / 'retained_matrix.json').write_text(json.dumps({'native_commit': expected, 'rows': rows, 'complete': len(rows) == 15 and all(item['exit_code'] == 0 for item in rows)}, indent=2) + '\n')
        print(mode, case, result.returncode, flush=True)
        if result.returncode != 0:
            raise SystemExit(result.returncode)
