# Exact 20-commit mapping

The existing eighteen mappings are unchanged. The final two rows append source-identical publication equivalents for actual upstream source corrections; they do not replace or rewrite the historical preparation.

| Ledger | Original source commit | Prepared publication commit | Exact source tree |
| --- | --- | --- | --- |
| LSQ-003 | `f2c1329fd116fa7f6d40d142aeb55359c4ad8501` | `f2c1329fd116fa7f6d40d142aeb55359c4ad8501` | `dfa1a2ef5c3f55339d5199e7c2986162946a6c33` |
| LSQ-004 | `f7bfd697c967f550bf59fc6a720f48a15d3191d7` | `f7bfd697c967f550bf59fc6a720f48a15d3191d7` | `e91ddbd7d1691716c837950ab032a6cde7323393` |
| LSQ-005 | `5accc8aea1d4a0fb2e02530686ab1ab42527f98f` | `5accc8aea1d4a0fb2e02530686ab1ab42527f98f` | `8e82fbe347228d212c49d65725db7bce2775a9af` |
| LSQ-006 | `1aaac18c467e8b19a481dc6ef96db2b798e76edc` | `1aaac18c467e8b19a481dc6ef96db2b798e76edc` | `47956f1a1604b3a9cb18604b30caa4632f316e98` |
| LSQ-007 | `0f7382b17b38d7fb0496a0b75b3c66ace79e49e8` | `0f7382b17b38d7fb0496a0b75b3c66ace79e49e8` | `b080c4adfe70eb31d80d5393431933b37691f593` |
| LSQ-008 | `3e6c31890cb7c48d933b5114136324c5113fb0a8` | `67690e1048efab8249b565daadfd21d6a8fa0415` | `87cfe4d1225153c4936496d544c4c1970a266500` |
| LSQ-009 | `c434c4ae3a2ad9f584d2c17536f800623ef36df6` | `38c7b0cfef0ebc20489d02ca1ee7507d9a65f50c` | `c52bbda47a322c6a63951e2157302a1153883f26` |
| LSQ-010 | `3640992bb231d3f0f2647e03fda6a2776fcc23ca` | `70521e37f5dfa887f46d9ae297b7677ae16b4c67` | `b8bb361bc2f96eabc6022d840da7325f5702daa3` |
| LSQ-011 | `74b8a8e1213b73b3c86f3b43c9b6437f30f0d908` | `54a596736fc37bf170a3f9418d5896f88dd860ec` | `fb1dcc818dd80033d25de05fa2e6959712375c48` |
| LSQ-012 | `8b0ef12414cdcf7b8c20e0b9f4fceb321358c2d0` | `68faccfba1d8e7a90d29630a9751f46b653ee0db` | `1d31e05c41dedb75a0f89153d3785fc802c49d47` |
| LSQ-013 | `9f0088c58fe67cccf1871dc172c90c2ec6f97944` | `aaf173d478239cdcd6c6332a9bee83ecf5df26a4` | `30b2379e9ad77915573da2115bf981a455d4e2b7` |
| LSQ-014 | `a1947ce3a4ceeb98413e53014cc87f72b6d89869` | `5e6d1b72c9dae173d4cb647a3753f077de598a4e` | `d66a671618ab66b7a06f0162783f26977ce5be9a` |
| LSQ-015 | `202ed8b9e92929d1ec62ffe2e5034d1a00fda355` | `b207f436ed79f361b877eca82aa55a6bd025eb21` | `61b0dcb12c7b68399007b37b09ea11503a2a9b10` |
| LSQ-016 | `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c` | `ebe6a0f90c631a76bd32e7367558f59cfee9d26f` | `e31304a900fdb5e642e2bff9338655e88b78539a` |
| LSQ-017 | `530e9e505eb04a0a4095b290f7eb052504ace94e` | `5dc663c7c2e957de919f59c012666f37bb6fc78d` | `c5615e6fda3359289d29fea1f9344ad4de549e81` |
| LSQ-018 | `005ab244169f269689e511d6b77dd2187e318df1` | `b435b008d51987ee9a4410b8b36b7d3f873860c1` | `09e792972fdfb9cdfa18fea06c2584e63de534b9` |
| LSQ-019 | `c8cf3fbc201a5d6f6acb6ae45af476cfcd5d7840` | `dba92a3246398e0f7e8902feb2bf858dd6407a50` | `c796cf9b986727a4042976d472979fd506e0a687` |
| LSQ-020 | `d1104a9fab040af659295a95fb448c971a7bc6de` | `172fb713eee0e4dddd9f87f58cd6e92a1d1b54b7` | `3f3004ea22d02ea42d8bbd28b511312def4ecf07` |
| LSQ-021 | `8aca43c50bfa6995c3d007a8e75ad5145b5a2db8` | `8951569ca26d73dd99fa5aa09f097c8b3bc3b68c` | `bf96a3c8817ce89aec05d6c687bdb6b55064a8d0` |
| LSQ-022 | `ed8f8f7642fbf4fc9399a0a6bb8f90b281e1f300` | `3d775d801ccf7c9f04e0cc6d33952d81c66dae1f` | `26b4ecc1d026c2aa21a852c20a3f6d9e0ea7cbeb` |

## Unchanged policy messages for the two source corrections

### LSQ-021

```text
uwz(h3): stop decoder entry after QPACK blocking or errors

Stop buffered frame consumption while a field section is blocked, retain
its context for cancellation, and reject exhausted or truncated prefixes.
Terminal errors also prevent candidate reliable-reset header completion.
Preserve WebTransport classification and stream-scoped header rejection.

Ledger: LSQ-021
Upstream: https://github.com/litespeedtech/lsquic/commit/
 acd2bb73f681efeb28a7e32e4df1f8af61efbe1e
Invariant: Blocked or failed field sections consume no later frame input;
 terminal QPACK errors never resume through reliable-reset completion.
Test evidence: Unchanged production fails the blocked-prefix assertion.
 The reset-guard omission changes retained decoder context after error.
 Both targeted regressions pass with the fix; all 84 native Linux Debug
 assertion cases pass, including the existing 83 and new reset subset.
Retirement criterion: The maintained base preserves equivalent blocked,
 terminal-error, decoder-ownership and reliable-reset behavior.
```

### LSQ-022

```text
uwz(quic): preserve validated paths when every slot is occupied

Reuse a free or unvalidated slot for a new tuple.  If every stored path is
validated, retain all addresses, challenges, flags, packet sizes and peer
contexts and keep the current path.  Existing tuples still refresh their
peer context without changing other state.

Ledger: LSQ-022
Upstream: litespeedtech/lsquic c638b57096d6a5bd0d6064382267c261bc7f9de4
Invariant: Unverified tuples never replace a validated path; no eligible
 victim preserves the full path table and used-slot mask unchanged.
Test evidence: The native path-exhaustion test fails on a full snapshot
 comparison before the fix and passes afterward for IPv4 and IPv6,
 client/server and HTTP/non-HTTP flags, every current/victim slot,
 repeated alternatives, existing matches and free-slot precedence.
Retirement criterion: The maintained base preserves equivalent validated
 path identity and full-table selection behavior.
```
