# Compact replay of the prepared backports

The compact distribution needs the two small incremental bundles, their input
locks, conversion scripts and retained proofs. Full original and prepared
bundles were separately imported and strictly checked during preparation;
those validation records remain retained. Their large duplicate histories can
be reconstructed from the earlier committed historical artifact and the two
deltas below.

Required historical archive:
`benchmarks/results/dependency_publication_v2_3/2026_11_17/raw_evidence_archive.tgz`.
Its exact SHA-256 is
`6f8b075f99e88b4a1fb4cce79466a5809c5f5de0bf40aaa36e21f398541677ad`.
The verifier checks that archive and both contained historical base bundle
hashes before importing anything.

| Delta | Required historical base | Follow-on tip |
| --- | --- | --- |
| `bundles/lsquic-original-backports-incremental.bundle` | `d1104a9fab040af659295a95fb448c971a7bc6de` | `ed8f8f7642fbf4fc9399a0a6bb8f90b281e1f300` |
| `bundles/lsquic-publication-backports-incremental.bundle` | `172fb713eee0e4dddd9f87f58cd6e92a1d1b54b7` | `3d775d801ccf7c9f04e0cc6d33952d81c66dae1f` |

After verifying the containing distribution's manifest, replay offline with
Git and Python 3:

```sh
python3 scripts/verify_incremental.py \
  /absolute/path/to/dependency_publication_v2_3/2026_11_17/raw_evidence_archive.tgz \
  /tmp/uwz-backport-delta-fresh-replay
```

Choose a new destination. Each delta must fail verification in an empty
repository, then pass after its exact retained historical base is imported.
The final original and prepared tips must each add exactly two commits and
produce tree `26b4ecc1d026c2aa21a852c20a3f6d9e0ea7cbeb`; strict full Git object
checks run afterward. The reconstructed histories then reproduce the
publication conversion twice, checking all twenty exact tree, source-diff,
parent and message mappings against `proofs/conversion.json`.

This script performs no network operation and adds no library build
requirement. The first eighteen mappings remain unchanged. LSQ-021 and
LSQ-022 retain the actual QPACK and validated-path source fixes; conversion
only maps parents and appends `Original-commit`. Native source under
`NDEBUG` is never transformed.

Original source reviews, targeted regressions and combined runtime evidence
remain separate from this Git-history replay. Maintained-fork mirror sync,
branch protections, assigned/labeled PR review, actual integration merge,
production pinning and normal-build activation still require their respective
evidence. No fork write, pin or capability change is performed by these tools.
