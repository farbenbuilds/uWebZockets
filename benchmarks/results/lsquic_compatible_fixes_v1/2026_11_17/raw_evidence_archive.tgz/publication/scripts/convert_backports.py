#!/usr/bin/env python3
"""Append two reviewed source commits to an unchanged prepared history offline."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


FIELDS = ('Ledger', 'Upstream', 'Invariant', 'Test evidence', 'Retirement criterion')


def git(repo, *args, input_bytes=None):
    result = subprocess.run(['git', '--no-replace-objects', '-C', str(repo), *args],
                            input=input_bytes, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, check=True)
    return result.stdout


def commit(repo, revision):
    raw = git(repo, 'cat-file', 'commit', revision)
    header, message = raw.split(b'\n\n', 1)
    lines = header.splitlines()
    if [line.split(b' ', 1)[0] for line in lines] != [b'tree', b'parent', b'author', b'committer']:
        raise ValueError('Expected an ordinary unsigned single-parent commit: ' + revision)
    return lines, message, raw


def patch(repo, parent, revision):
    return git(repo, 'diff-tree', '--no-commit-id', '--no-ext-diff', '--no-color',
               '--no-renames', '--binary', '--full-index', '-p', parent, revision)


def verify_historical(original, prepared, spec, history):
    if (spec['original_base'], spec['prepared_base'], spec['published_base']) != (history['original_tip'], history['publication_tip'], history['base']):
        raise ValueError('Original or prepared parent differs from the immutable historical proof')
    old_ids = git(original, 'rev-list', '--reverse', spec['published_base'] + '..' + spec['original_base']).decode().splitlines()
    new_ids = git(prepared, 'rev-list', '--reverse', spec['published_base'] + '..' + spec['prepared_base']).decode().splitlines()
    if old_ids != [row['original_commit'] for row in history['commits']] or new_ids != [row['publication_commit'] for row in history['commits']] or len(old_ids) != 18:
        raise ValueError('Historical ordered commit identities differ')
    for row in history['commits']:
        old_header, old_message, _ = commit(original, row['original_commit'])
        new_header, new_message, _ = commit(prepared, row['publication_commit'])
        if old_header[0] != ('tree ' + row['tree']).encode() or new_header[0] != old_header[0] or old_header[2:] != new_header[2:]:
            raise ValueError('Historical tree or author/committer bytes differ')
        if old_header[1] != ('parent ' + row['original_parent']).encode() or new_header[1] != ('parent ' + row['publication_parent']).encode():
            raise ValueError('Historical parent differs')
        if hashlib.sha256(old_message).hexdigest() != row['original_message_sha256'] or hashlib.sha256(new_message).hexdigest() != row['publication_message_sha256']:
            raise ValueError('Historical message differs')
        old_patch = patch(original, row['original_parent'], row['original_commit'])
        if hashlib.sha256(old_patch).hexdigest() != row['source_diff_sha256'] or old_patch != patch(prepared, row['publication_parent'], row['publication_commit']):
            raise ValueError('Historical source diff differs')
    old_tree = git(original, 'rev-parse', spec['original_base'] + '^{tree}').decode().strip()
    new_tree = git(prepared, 'rev-parse', spec['prepared_base'] + '^{tree}').decode().strip()
    if old_tree != history['final_tree'] or new_tree != old_tree:
        raise ValueError('Historical final source tree differs')


def validate(original, prepared, destination, spec, history):
    if destination.exists() or destination.is_symlink():
        raise ValueError('Destination already exists: ' + str(destination))
    verify_historical(original, prepared, spec, history)
    actual = git(original, 'rev-list', '--reverse', spec['original_base'] + '..' + spec['original_tip']).decode().splitlines()
    if actual != [row['original_commit'] for row in spec['commits']] or len(actual) != 2:
        raise ValueError('Expected exactly the two ordered follow-on source commits')
    previous = spec['original_base']
    checked = []
    for index, row in enumerate(spec['commits']):
        header, message, raw = commit(original, row['original_commit'])
        if header[0] != ('tree ' + row['tree']).encode() or header[1] != ('parent ' + previous).encode() or row['original_parent'] != previous:
            raise ValueError('Follow-on source parent or tree differs')
        if hashlib.sha256(raw).hexdigest() != row['original_object_sha256']:
            raise ValueError('Follow-on original commit bytes differ')
        if row['ledger'] != 'LSQ-' + str(index + 21).zfill(3):
            raise ValueError('Unexpected follow-on ledger allocation')
        for field in FIELDS:
            if sum(line.startswith((field + ': ').encode()) for line in message.splitlines()) != 1:
                raise ValueError('Expected complete unchanged canonical metadata: ' + field)
        if ('Ledger: ' + row['ledger']).encode() not in message.splitlines():
            raise ValueError('Existing ledger does not match input')
        if any(line.startswith(b'Original-commit: ') for line in message.splitlines()):
            raise ValueError('Original source commit already has publication metadata')
        new_message = message + (b'' if message.endswith(b'\n\n') else b'\n')
        new_message += ('Original-commit: ' + row['original_commit'] + '\n').encode()
        checked.append((row, header, message, new_message))
        previous = row['original_commit']
    if spec['commits'][-1]['tree'] != spec['final_tree']:
        raise ValueError('Final source tree differs from frozen follow-on input')
    return checked


def convert(original, prepared, destination, spec, history):
    checked = validate(original, prepared, destination, spec, history)
    subprocess.run(['git', 'init', '--bare', '--quiet', str(destination)], check=True)
    git(destination, 'fetch', '--no-tags', str(original), spec['original_tip'] + ':refs/heads/original-backports')
    git(destination, 'fetch', '--no-tags', str(prepared), spec['prepared_base'] + ':refs/heads/prepared-base')
    previous = spec['prepared_base']
    proof = []
    for row, header, message, new_message in checked:
        raw = b'\n'.join([header[0], ('parent ' + previous).encode(), *header[2:]]) + b'\n\n' + new_message
        revision = git(destination, 'hash-object', '-t', 'commit', '-w', '--stdin', input_bytes=raw).decode().strip()
        original_patch = patch(original, row['original_parent'], row['original_commit'])
        if original_patch != patch(destination, previous, revision):
            raise ValueError('Follow-on publication source diff changed')
        proof.append({'ledger': row['ledger'], 'original_commit': row['original_commit'],
                      'publication_commit': revision, 'original_parent': row['original_parent'],
                      'publication_parent': previous, 'tree': row['tree'], 'preserved_object': False,
                      'source_diff_sha256': hashlib.sha256(original_patch).hexdigest(),
                      'source_diff_bytes': len(original_patch),
                      'original_message_sha256': hashlib.sha256(message).hexdigest(),
                      'publication_message_sha256': hashlib.sha256(new_message).hexdigest(),
                      'original_ledger': None, 'author_committer_bytes_preserved': True,
                      'original_message_bytes_preserved_as_prefix': True})
        previous = revision
    git(destination, 'update-ref', 'refs/heads/' + spec['publication_branch'], previous, '0' * 40)
    git(destination, 'symbolic-ref', 'HEAD', 'refs/heads/' + spec['publication_branch'])
    git(destination, 'merge-base', '--is-ancestor', spec['prepared_base'], previous)
    git(destination, 'merge-base', '--is-ancestor', spec['published_base'], previous)
    git(destination, 'fsck', '--full', '--strict', '--no-reflogs')
    return {'schema': 1, 'base': spec['published_base'], 'original_tip': spec['original_tip'],
            'publication_tip': previous, 'historical_prepared_tip': spec['prepared_base'],
            'final_tree': spec['final_tree'], 'publication_branch': spec['publication_branch'],
            'commits': history['commits'] + proof, 'follow_on_commits': proof,
            'historical_mapping_unchanged': True, 'follow_on_source_changes': False,
            'publication_status': 'Unpublished source-identical preparation; combined runtime, maintained-fork publication and activation gates remain separate.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original_repo', type=Path)
    parser.add_argument('prepared_repo', type=Path)
    parser.add_argument('new_destination_repo', type=Path)
    parser.add_argument('conversion_input', type=Path)
    args = parser.parse_args()
    spec = json.loads(args.conversion_input.read_text())
    historical_bytes = (args.conversion_input.parent / 'historical_conversion.json').read_bytes()
    if hashlib.sha256(historical_bytes).hexdigest() != spec['historical_proof_sha256']:
        raise ValueError('Immutable historical conversion proof differs')
    result = convert(args.original_repo.resolve(strict=True), args.prepared_repo.resolve(strict=True),
                     args.new_destination_repo.absolute(), spec, json.loads(historical_bytes))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
