#!/usr/bin/env python3
"""Verify backport deltas after their exact retained historical base bundles."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile


def command(args, log, success=True):
    result = subprocess.run([str(value) for value in args], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    log.write(('$ ' + ' '.join(str(value) for value in args) + '\n').encode())
    log.write(result.stdout)
    log.write(result.stderr)
    log.write(('Exit: ' + str(result.returncode) + '\n').encode())
    if (result.returncode == 0) != success:
        raise ValueError('Unexpected command status: ' + str(result.returncode))
    return result.stdout


def verify_one(package, scratch, row, archive, expected_tree, log):
    delta = package / row['path']
    if hashlib.sha256(delta.read_bytes()).hexdigest() != row['sha256']:
        raise ValueError('Incremental bundle checksum differs')
    base_member = archive.getmember(row['historical_base_bundle_member'])
    if not base_member.isfile():
        raise ValueError('Historical base bundle is not a regular member')
    base_bytes = archive.extractfile(base_member).read()
    if hashlib.sha256(base_bytes).hexdigest() != row['historical_base_bundle_sha256']:
        raise ValueError('Historical base bundle checksum differs')
    base_bundle = scratch / (row['role'] + '-base.bundle')
    base_bundle.write_bytes(base_bytes)
    repo = scratch / (row['role'] + '.git')
    command(['git', 'init', '--bare', '--quiet', repo], log)
    command(['git', '-C', repo, 'bundle', 'verify', delta], log, success=False)
    command(['git', '-C', repo, 'bundle', 'verify', base_bundle], log)
    command(['git', '-C', repo, 'fetch', '--no-tags', base_bundle,
             row['historical_base_bundle_ref'] + ':refs/heads/historical-base'], log)
    base = command(['git', '-C', repo, 'rev-parse', 'refs/heads/historical-base'], log).decode().strip()
    if base != row['required_base']:
        raise ValueError('Imported historical base differs')
    command(['git', '-C', repo, 'bundle', 'verify', delta], log)
    command(['git', '-C', repo, 'fetch', '--no-tags', delta, row['ref'] + ':refs/heads/follow-on'], log)
    command(['git', '-C', repo, 'symbolic-ref', 'HEAD', 'refs/heads/follow-on'], log)
    tip = command(['git', '-C', repo, 'rev-parse', 'HEAD'], log).decode().strip()
    tree = command(['git', '-C', repo, 'rev-parse', 'HEAD^{tree}'], log).decode().strip()
    count = command(['git', '-C', repo, 'rev-list', '--count', base + '..HEAD'], log).decode().strip()
    if tip != row['commit'] or tree != expected_tree or count != '2':
        raise ValueError('Incremental tip, tree or ordered range differs')
    command(['git', '-C', repo, 'merge-base', '--is-ancestor', base, 'HEAD'], log)
    command(['git', '-C', repo, 'fsck', '--full', '--strict', '--no-reflogs'], log)
    return {'role': row['role'], 'required_base': base, 'tip': tip, 'tree': tree,
            'follow_on_commit_count': 2, 'empty_repository_refused': True,
            'exact_base_then_delta_import_and_strict_fsck': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('historical_archive', type=Path)
    parser.add_argument('new_scratch_directory', type=Path)
    args = parser.parse_args()
    package = Path(__file__).resolve().parent.parent
    expected_archive = json.loads((package / 'inputs/prior_evidence.json').read_text())[0]
    if hashlib.sha256(args.historical_archive.read_bytes()).hexdigest() != expected_archive['archive_sha256']:
        raise ValueError('Exact retained historical archive is required')
    scratch = args.new_scratch_directory.absolute()
    if scratch.exists() or scratch.is_symlink():
        raise ValueError('Replay destination already exists')
    inventory = json.loads((package / 'inputs/incremental_bundle_inventory.json').read_text())
    expected_tree = json.loads((package / 'inputs/conversion.json').read_text())['final_tree']
    scratch.mkdir()
    with (scratch / 'verification.log').open('wb') as log, tarfile.open(args.historical_archive, 'r:gz') as archive:
        results = [verify_one(package, scratch, row, archive, expected_tree, log) for row in inventory]
        expected_proof = json.loads((package / 'proofs/conversion.json').read_text())
        output_hashes = []
        for name in ['a', 'b']:
            output = command([sys.executable, package / 'scripts/convert_backports.py',
                              scratch / 'original.git', scratch / 'publication.git',
                              scratch / ('converted_' + name + '.git'),
                              package / 'inputs/conversion.json'], log)
            if json.loads(output) != expected_proof:
                raise ValueError('Conversion from reconstructed histories differs')
            (scratch / ('conversion_' + name + '.json')).write_bytes(output)
            output_hashes.append(hashlib.sha256(output).hexdigest())
        if output_hashes[0] != output_hashes[1]:
            raise ValueError('Reconstructed-history conversions differ')
    summary = {'historical_archive_sha256': expected_archive['archive_sha256'],
               'incremental_bundle_imports': results,
               'fresh_conversion_replays': 2, 'matching_commit_mapping_rows': 20,
               'conversion_output_sha256': output_hashes[0], 'network_access': False,
               'full_history_validation_retained_separately': True,
               'runtime_or_publication_gate': False}
    (scratch / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
