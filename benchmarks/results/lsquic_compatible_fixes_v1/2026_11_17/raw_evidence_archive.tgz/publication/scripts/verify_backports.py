#!/usr/bin/env python3
"""Verify full follow-on bundles and reproduce their source-identical history."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def command(args, log, success=True):
    result = subprocess.run([str(item) for item in args], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    log.write(('$ ' + ' '.join(str(item) for item in args) + '\n').encode())
    log.write(result.stdout)
    log.write(result.stderr)
    log.write(('Exit: ' + str(result.returncode) + '\n').encode())
    if (result.returncode == 0) != success:
        raise ValueError('Unexpected command status: ' + str(result.returncode))
    return result.stdout


def import_bundle(package, scratch, row, log):
    bundle = package / row['path']
    if hashlib.sha256(bundle.read_bytes()).hexdigest() != row['sha256']:
        raise ValueError('Bundle checksum differs: ' + row['path'])
    repo = scratch / (bundle.stem + '.git')
    command(['git', 'init', '--bare', '--quiet', repo], log)
    command(['git', '-C', repo, 'bundle', 'verify', bundle], log)
    command(['git', '-C', repo, 'fetch', '--no-tags', bundle, row['ref'] + ':refs/heads/retained'], log)
    command(['git', '-C', repo, 'symbolic-ref', 'HEAD', 'refs/heads/retained'], log)
    tip = command(['git', '-C', repo, 'rev-parse', 'HEAD'], log).decode().strip()
    if tip != row['commit']:
        raise ValueError('Imported tip differs')
    command(['git', '-C', repo, 'fsck', '--full', '--strict', '--no-reflogs'], log)
    return repo


def refusal_checks(package, scratch, original, prepared, spec, log):
    (scratch / 'historical_conversion.json').write_bytes((package / 'inputs/historical_conversion.json').read_bytes())
    scenarios = []
    wrong_parent = copy.deepcopy(spec)
    wrong_parent['prepared_base'] = spec['published_base']
    scenarios.append(('wrong_parent', wrong_parent))
    wrong_tree = copy.deepcopy(spec)
    wrong_tree['commits'][0]['tree'] = spec['final_tree']
    scenarios.append(('wrong_tree', wrong_tree))
    for name, altered in scenarios:
        input_file = scratch / (name + '.json')
        input_file.write_text(json.dumps(altered))
        destination = scratch / (name + '.git')
        command([sys.executable, package / 'scripts/convert_backports.py', original, prepared, destination, input_file], log, success=False)
        if destination.exists() or destination.is_symlink():
            raise ValueError('Rejected input wrote its destination: ' + name)
    existing = scratch / 'existing_destination'
    existing.mkdir()
    sentinel = existing / 'sentinel.txt'
    sentinel.write_bytes(b'Preserve this existing directory.\n')
    before = sentinel.read_bytes()
    command([sys.executable, package / 'scripts/convert_backports.py', original, prepared, existing, package / 'inputs/conversion.json'], log, success=False)
    if sentinel.read_bytes() != before or sorted(item.name for item in existing.iterdir()) != ['sentinel.txt']:
        raise ValueError('Existing destination changed')
    return ['wrong_parent', 'wrong_tree', 'existing_destination']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('new_scratch_directory', type=Path)
    args = parser.parse_args()
    package = Path(__file__).resolve().parent.parent
    scratch = args.new_scratch_directory.absolute()
    if scratch.exists() or scratch.is_symlink():
        raise ValueError('Replay destination already exists')
    scratch.mkdir()
    inventory = json.loads((package / 'inputs/bundle_inventory.json').read_text())
    spec = json.loads((package / 'inputs/conversion.json').read_text())
    expected = json.loads((package / 'proofs/conversion.json').read_text())
    with (scratch / 'verification.log').open('wb') as log:
        imported = {row['path']: import_bundle(package, scratch, row, log) for row in inventory}
        original = imported['bundles/lsquic-original-backports.bundle']
        prepared = imported['bundles/lsquic-publication-backports.bundle']
        outputs = []
        for name in ['a', 'b']:
            output = command([sys.executable, package / 'scripts/convert_backports.py', original, prepared, scratch / ('converted_' + name + '.git'), package / 'inputs/conversion.json'], log)
            if json.loads(output) != expected:
                raise ValueError('Replay differs from retained 20-commit proof')
            (scratch / ('conversion_' + name + '.json')).write_bytes(output)
            outputs.append(hashlib.sha256(output).hexdigest())
        if outputs[0] != outputs[1]:
            raise ValueError('Fresh conversions differ')
        refusals = refusal_checks(package, scratch, original, prepared, spec, log)
    summary = {'bundles_imported_and_strict_fsck': len(inventory), 'fresh_conversion_replays': 2,
               'conversion_output_sha256': outputs[0], 'unchanged_historical_mapping_rows': 18,
               'follow_on_source_identical_mapping_rows': 2, 'total_mapping_rows': 20,
               'publication_tip': expected['publication_tip'], 'final_tree': expected['final_tree'],
               'refusal_checks_before_destination_write': refusals,
               'network_access': False, 'runtime_or_publication_gate': False}
    (scratch / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
