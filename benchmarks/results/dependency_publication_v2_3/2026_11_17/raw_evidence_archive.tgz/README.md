# Historical candidate publication preparation

This is unpublished maintainer review material, not a package dependency, merge
approval, production pin or activation result. Root source is
`50a70a90e96c87cfa56a439c5e647dc99272eacd`.

The immutable lsquic candidate is
`d1104a9fab040af659295a95fb448c971a7bc6de`, based on published integration
`85bd081c9103c077a7cc98271d09334d0f1043d4`. Its separate metadata-prepared tip is
`172fb713eee0e4dddd9f87f58cd6e92a1d1b54b7` on
`sync/webtransport-metadata-20261117`. Both have final source tree
`3f3004ea22d02ea42d8bbd28b511312def4ecf07`.

The first five LSQ-003 through LSQ-007 commits remain byte-identical. The next
thirteen retain the original source trees, source diffs, ordering and author
and committer bytes, while completing the canonical metadata fields and
recording original commit identities. LSQ-008 through LSQ-020 are chronological
ledger entries. The receive observer's provisional identifier is preserved in
the conversion input/proof and `Original-ledger` field while its canonical
`Ledger` field becomes LSQ-019. Historical incomplete checkpoints and failing
regressions remain stated in their messages. Later passing evidence is not
attributed to those earlier commits. See `LEDGER.md` and
`proofs/conversion_a.json` for all eighteen mappings.

Compatibility and advisory follow-ups remain required. At this handoff's
read-only observation, the maintained lsquic mirror remains `cd23e526...`, while
upstream has advanced to `5baecbb15c06557bbf8fbc1586d6f4bbd025a2b6`. In particular,
upstream QPACK blocked-read and validated-path-table fixes require review and
applicable backports plus functional verification before this historical
candidate can be merged or activated. This conversion does not contain them.
Do not merge the prepared branch solely because its source identity proof passes.

The unchanged XEV-008 candidate
`5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5` has a separate complete bundle and
published parent `c49f6dfb83038c146232472c063e4b2681d098d8`. Its mirror/upstream
observation is `451a2bc03644c2b70fb28a808313d12989bfa8e3`. The authenticated
account had no push permission on either maintained fork. Root retains the
live permission/ref observations separately. Nothing has been written to a
maintained fork or upstream repository by this preparation.

## Offline verification

Python 3 and Git are external maintainer verification tools only. They are not
library build requirements. No network connection or existing repository is
needed for the retained bundle imports and conversion replay.

After verifying the archive's top-level checksum manifest, run:

```sh
python3 scripts/verify_handoff.py /tmp/uwz-fork-handoff-fresh-replay
```

Choose a new destination. The verifier refuses an existing directory. It
checks all six bundle checksums, verifies that each imports into an empty
repository without prerequisites, checks exact retained tips, and runs strict
Git object validation. It reproduces conversion into two fresh repositories,
compares all eighteen tree/parent/source-diff/message proofs and deterministic
output bytes, and checks published-base ancestry and the unchanged XEV-008
history. Wrong base, reordered commits and altered tree input must fail before
creating their destinations; an existing destination must stay unchanged.

The recorded replay passed six imports and strict object checks, two identical
conversions, eighteen source/metadata proofs and four refusal checks. Raw
commands and statuses are in `logs/offline_verification.log`. This is object,
history and reproducibility verification, not another runtime or security pass.

## Bundle contents

`inputs/bundle_inventory.json` pins every bundle, ref, commit, size and SHA-256.
The complete histories are:

- `bundles/lsquic-original.bundle`: immutable experimental candidate history.
- `bundles/lsquic-publication.bundle`: separate metadata-prepared history.
- `bundles/libxev-xev008.bundle`: unchanged XEV-008 and its full ancestry.
- Three unchanged QPACK/HPACK companion histories: QPACK `91567706...`, native
  lsquic HPACK gitlink `cf0f70dd...`, and Root package HPACK `fda48e02...`.

The companions come directly from the retained dependency archive, whose hash
is recorded in `inputs/companion_provenance.json`. The original XEV scratch
clone was partial; a no-local full clone failed on historical promisor objects.
Its complete unchanged history was recovered from the retained published-base
bundle plus the exact one-commit incremental range. The original failed clone
and initial bundle-ref naming attempt are retained in the logs; corrected
recovery and fresh full-bundle imports pass. This is not an upstream repository
corruption finding.

`inputs/runtime_evidence.json` records eleven durable repository README/archive
references and verified archive hashes. They retain native prerequisite,
three-mode App, lifecycle, credit and independent-client runtime evidence.
Large runtime binaries are not duplicated here. No new runtime coverage is
claimed for the metadata-prepared history: tree/source identity connects it to
the frozen historical evidence, subject to that evidence's stated limits.

Only review documents, scripts, proofs and Git history bundles are included.
No generated fixture PKI, authentication credentials, compiled executables or
build cache is included. Git bundles retain public upstream source history.

## Maintainer follow-through

1. Review the advisory/compatibility delta and append applicable fixes in a
   separate scratch branch, retaining this original-to-prepared mapping. Run
   the necessary functional regressions on the resulting source.
2. Freshly verify maintained-fork write authority, mirror equality and branch
   protection. Review and synchronize the lsquic mirror before publication;
   record the exact reviewed upstream range. Never push downstream work to
   a mirror branch or any upstream repository.
3. Import the chosen review branch without rewriting existing published refs.
   A local import of this historical branch, for review only, is:

   ```sh
   git fetch /absolute/path/to/bundles/lsquic-publication.bundle \
     refs/heads/sync/webtransport-metadata-20261117:refs/heads/sync/webtransport-metadata-20261117
   ```

   Do not push directly to `uwz/main` or `uwz/zig-0.16`. Publish only the
   reviewed scratch branch, then open a PR to the corresponding append-only
   integration branch with an owner and an existing repository label. Merge
   only after the required review and gates.
4. Fetch the actual published integration commit and retain its complete
   history. Only that resulting full commit can become a production pin.
   Update all four manifest views and hashes together; perform empty-cache,
   package-consumer and owning downstream checks. The prepared SHA is not a
   substitute for the merge result.
5. Activate WebTransport only after the normal pinned build passes the
   independent client/compliance gate and capability/support documentation is
   synchronized. Keep platform, allocation, performance and remaining release
   requirements open until independently proved. Dedicated smoke/security/
   sanitizer/fuzz/scan campaigns remain user-deferred; none is reported passed
   by this handoff.
