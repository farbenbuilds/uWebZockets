#!/usr/bin/env python3
"""Validate retained bundles and reproduce message-only history offline."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def command(args, log, expected_success=True):
    result = subprocess.run([str(arg) for arg in args], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    log.write(('$ ' + ' '.join(str(arg) for arg in args) + '\n').encode())
    log.write(result.stdout)
    log.write(result.stderr)
    log.write(('Exit: ' + str(result.returncode) + '\n').encode())
    if (result.returncode == 0) != expected_success:
        raise ValueError('Unexpected command status: ' + str(result.returncode))
    return result.stdout


def import_bundle(package, scratch, row, log):
    bundle = package / row['path']
    if hashlib.sha256(bundle.read_bytes()).hexdigest() != row['sha256']:
        raise ValueError('Bundle checksum mismatch: ' + row['path'])
    repo = scratch / (bundle.stem + '.git')
    command(['git', 'init', '--bare', '--quiet', repo], log)
    command(['git', '-C', repo, 'bundle', 'verify', bundle], log)
    command(['git', '-C', repo, 'fetch', '--no-tags', bundle, row['ref'] + ':refs/heads/retained'], log)
    command(['git', '-C', repo, 'symbolic-ref', 'HEAD', 'refs/heads/retained'], log)
    commit = command(['git', '-C', repo, 'rev-parse', 'HEAD'], log).decode().strip()
    if commit != row['commit']:
        raise ValueError('Imported commit does not match inventory')
    command(['git', '-C', repo, 'fsck', '--full', '--strict', '--no-reflogs'], log)
    return repo


def reject_bad_input(package, scratch, original, spec, log):
    scenarios = []
    wrong_base = copy.deepcopy(spec)
    wrong_base['base'] = spec['original_tip']
    scenarios.append(('wrong_base', wrong_base))
    wrong_order = copy.deepcopy(spec)
    wrong_order['commits'][5:7] = list(reversed(wrong_order['commits'][5:7]))
    scenarios.append(('wrong_order', wrong_order))
    wrong_tree = copy.deepcopy(spec)
    wrong_tree['commits'][-1]['tree'] = spec['commits'][0]['tree']
    scenarios.append(('wrong_tree', wrong_tree))
    for name, altered in scenarios:
        input_file = scratch / (name + '.json')
        destination = scratch / (name + '.git')
        input_file.write_text(json.dumps(altered))
        command([sys.executable, package / 'scripts/convert_history.py', original, destination, input_file], log, expected_success=False)
        if destination.exists() or destination.is_symlink():
            raise ValueError('Invalid input wrote its destination: ' + name)
    existing = scratch / 'existing_destination'
    existing.mkdir()
    sentinel = existing / 'sentinel.txt'
    sentinel.write_bytes(b'Preserve the existing destination.\n')
    before = sentinel.read_bytes()
    command([sys.executable, package / 'scripts/convert_history.py', original, existing, package / 'inputs/conversion.json'], log, expected_success=False)
    if sentinel.read_bytes() != before or sorted(p.name for p in existing.iterdir()) != ['sentinel.txt']:
        raise ValueError('Existing destination was changed')
    return ['wrong_base', 'wrong_order', 'wrong_tree', 'existing_destination']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('new_scratch_directory', type=Path)
    args = parser.parse_args()
    package = Path(__file__).resolve().parent.parent
    scratch = args.new_scratch_directory.absolute()
    if scratch.exists() or scratch.is_symlink():
        raise ValueError('Replay destination already exists: ' + str(scratch))
    scratch.mkdir()
    inventory = json.loads((package / 'inputs/bundle_inventory.json').read_text())
    spec = json.loads((package / 'inputs/conversion.json').read_text())
    expected = json.loads((package / 'proofs/conversion_a.json').read_text())
    with (scratch / 'verification.log').open('wb') as log:
        imported = {}
        for row in inventory:
            imported[row['path']] = import_bundle(package, scratch, row, log)
        original = imported['bundles/lsquic-original.bundle']
        output_hashes = []
        for name in ['a', 'b']:
            destination = scratch / ('converted_' + name + '.git')
            output = command([sys.executable, package / 'scripts/convert_history.py', original, destination, package / 'inputs/conversion.json'], log)
            if json.loads(output) != expected:
                raise ValueError('Replay does not reproduce all retained commit proofs')
            (scratch / ('conversion_' + name + '.json')).write_bytes(output)
            output_hashes.append(hashlib.sha256(output).hexdigest())
        if output_hashes[0] != output_hashes[1]:
            raise ValueError('Conversion outputs differ across fresh repositories')
        publication = imported['bundles/lsquic-publication.bundle']
        tree = command(['git', '-C', publication, 'rev-parse', 'HEAD^{tree}'], log).decode().strip()
        if tree != spec['final_tree']:
            raise ValueError('Publication bundle source tree differs')
        command(['git', '-C', publication, 'merge-base', '--is-ancestor', spec['base'], 'HEAD'], log)
        negatives = reject_bad_input(package, scratch, original, spec, log)
        xev = imported['bundles/libxev-xev008.bundle']
        command(['git', '-C', xev, 'merge-base', '--is-ancestor', 'c49f6dfb83038c146232472c063e4b2681d098d8', 'HEAD'], log)
    summary = {'bundles_imported_and_strict_fsck': len(inventory), 'conversion_replays': 2,
               'conversion_output_sha256': output_hashes[0], 'matching_commit_proofs': 18,
               'preserved_original_objects': 5, 'metadata_only_converted_objects': 13,
               'publication_tip': expected['publication_tip'], 'final_tree': tree,
               'negative_cases_rejected_before_destination_write': negatives,
               'network_access': False, 'runtime_or_activation_gate': False}
    (scratch / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
