#!/usr/bin/env python3
"""Prepare an offline publication history without changing any source tree."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


FIELDS = ('Ledger', 'Upstream', 'Invariant', 'Test evidence', 'Retirement criterion')


def git(repo, *args, input_bytes=None):
    result = subprocess.run(['git', '--no-replace-objects', '-C', str(repo), *args],
                            input=input_bytes, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, check=True)
    return result.stdout


def read_commit(repo, commit):
    raw = git(repo, 'cat-file', 'commit', commit)
    header, message = raw.split(b'\n\n', 1)
    lines = header.splitlines()
    keys = [line.split(b' ', 1)[0] for line in lines]
    if keys != [b'tree', b'parent', b'author', b'committer']:
        raise ValueError('Expected one unsigned parent with ordinary identity headers: ' + commit)
    return lines, message, raw


def publication_message(message, row):
    if row['preserve_object']:
        return message
    lines = message.decode('utf-8').splitlines()
    fields = row['metadata']
    for field in FIELDS:
        prefix = field + ': '
        matches = [i for i, line in enumerate(lines) if line.startswith(prefix)]
        if len(matches) > 1:
            raise ValueError('Duplicate original metadata field: ' + field)
        if not matches:
            continue
        index = matches[0]
        if field != 'Ledger' and lines[index] != prefix + fields[field]:
            raise ValueError('Original metadata value changed: ' + field)
        if field == 'Ledger':
            if lines[index] != prefix + row['original_ledger']:
                raise ValueError('Original ledger does not match conversion input')
            lines[index] = prefix + fields[field]
    text = '\n'.join(lines).rstrip() + '\n\n'
    for field in FIELDS:
        if not any(line.startswith(field + ': ') for line in lines):
            text += field + ': ' + fields[field] + '\n'
    text += 'Original-commit: ' + row['original_commit'] + '\n'
    if row.get('original_ledger'):
        text += 'Original-ledger: ' + row['original_ledger'] + '\n'
    return text.encode('utf-8')


def validate_input(source, destination, spec):
    if destination.exists() or destination.is_symlink():
        raise ValueError('Destination already exists: ' + str(destination))
    actual = git(source, 'rev-list', '--reverse', spec['base'] + '..' + spec['original_tip']).decode().splitlines()
    expected = [row['original_commit'] for row in spec['commits']]
    if actual != expected or len(actual) != 18:
        raise ValueError('The base, tip or ordered commit list does not match')
    previous = spec['base']
    checked = []
    for index, row in enumerate(spec['commits']):
        lines, message, raw = read_commit(source, row['original_commit'])
        tree = lines[0].decode().split(' ', 1)[1]
        parent = lines[1].decode().split(' ', 1)[1]
        if tree != row['tree'] or parent != previous or parent != row['original_parent']:
            raise ValueError('Original tree or parent differs: ' + row['original_commit'])
        if hashlib.sha256(raw).hexdigest() != row['original_object_sha256']:
            raise ValueError('Original commit bytes differ: ' + row['original_commit'])
        if row['preserve_object'] != (index < 5):
            raise ValueError('The first five objects must be preserved and only those five')
        metadata = row['metadata']
        if set(metadata) != set(FIELDS) or any(not value or '\n' in value for value in metadata.values()):
            raise ValueError('All canonical metadata fields require one explicit nonempty value')
        if metadata['Ledger'] != 'LSQ-' + str(index + 3).zfill(3):
            raise ValueError('Ledger allocation differs from the ordered contract')
        new_message = publication_message(message, row)
        if any(sum(line.startswith((field + ': ').encode()) for line in new_message.splitlines()) != 1 for field in FIELDS):
            raise ValueError('Each final message must contain every canonical field once')
        checked.append((row, lines, message, new_message))
        previous = row['original_commit']
    if spec['commits'][-1]['tree'] != spec['final_tree']:
        raise ValueError('Final tree does not match the frozen candidate')
    return checked


def convert(source, destination, spec):
    checked = validate_input(source, destination, spec)
    subprocess.run(['git', 'init', '--bare', '--quiet', str(destination)], check=True)
    git(destination, 'fetch', '--no-tags', str(source), spec['original_tip'] + ':refs/heads/original-candidate')
    previous = spec['base']
    proof = []
    for row, lines, original_message, new_message in checked:
        parent_header = ('parent ' + previous).encode()
        raw = b'\n'.join([lines[0], parent_header, *lines[2:]]) + b'\n\n' + new_message
        converted = git(destination, 'hash-object', '-t', 'commit', '-w', '--stdin', input_bytes=raw).decode().strip()
        if row['preserve_object'] and converted != row['original_commit']:
            raise ValueError('A preserved object changed')
        tree = git(destination, 'rev-parse', converted + '^{tree}').decode().strip()
        if tree != row['tree']:
            raise ValueError('Publication tree changed')
        original_patch = git(source, 'diff-tree', '--no-commit-id', '--no-ext-diff', '--no-color', '--no-renames', '--binary', '--full-index', '-p', row['original_parent'], row['original_commit'])
        publication_patch = git(destination, 'diff-tree', '--no-commit-id', '--no-ext-diff', '--no-color', '--no-renames', '--binary', '--full-index', '-p', previous, converted)
        if original_patch != publication_patch:
            raise ValueError('Publication source diff changed')
        proof.append({
            'ledger': row['metadata']['Ledger'], 'original_commit': row['original_commit'],
            'publication_commit': converted, 'original_parent': row['original_parent'],
            'publication_parent': previous, 'tree': tree, 'preserved_object': row['preserve_object'],
            'source_diff_sha256': hashlib.sha256(original_patch).hexdigest(),
            'source_diff_bytes': len(original_patch),
            'original_message_sha256': hashlib.sha256(original_message).hexdigest(),
            'publication_message_sha256': hashlib.sha256(new_message).hexdigest(),
            'original_ledger': row.get('original_ledger'),
            'author_committer_bytes_preserved': True,
        })
        previous = converted
    git(destination, 'update-ref', 'refs/heads/' + spec['publication_branch'], previous, '0' * 40)
    git(destination, 'symbolic-ref', 'HEAD', 'refs/heads/' + spec['publication_branch'])
    git(destination, 'merge-base', '--is-ancestor', spec['base'], previous)
    git(destination, 'fsck', '--full', '--strict', '--no-reflogs')
    return {'schema': 1, 'base': spec['base'], 'original_tip': spec['original_tip'],
            'publication_tip': previous, 'final_tree': spec['final_tree'],
            'publication_branch': spec['publication_branch'], 'commits': proof,
            'source_changes': False, 'publication_status': 'Unpublished metadata-prepared historical candidate; compatibility and advisory follow-ups remain required.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source_repo', type=Path)
    parser.add_argument('destination_repo', type=Path)
    parser.add_argument('conversion_input', type=Path)
    args = parser.parse_args()
    spec = json.loads(args.conversion_input.read_text())
    result = convert(args.source_repo.resolve(strict=True), args.destination_repo.absolute(), spec)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
