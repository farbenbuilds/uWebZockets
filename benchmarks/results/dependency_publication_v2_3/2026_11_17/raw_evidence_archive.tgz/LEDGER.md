# Prepared publication ledger

All rows describe unpublished review material. Original lsquic candidate and runtime evidence stay immutable. The metadata-prepared branch changes no source tree. Advisory and compatibility follow-ups, mirror synchronization, maintained-fork PR review and all required gates must precede merging or activation.

| Ledger | Original experimental commit | Metadata-prepared commit | Area |
| --- | --- | --- | --- |
| LSQ-003 | `f2c1329fd116fa7f6d40d142aeb55359c4ad8501` | `f2c1329fd116fa7f6d40d142aeb55359c4ad8501` | uwz(quic): match ACK callback function types |
| LSQ-004 | `f7bfd697c967f550bf59fc6a720f48a15d3191d7` | `f7bfd697c967f550bf59fc6a720f48a15d3191d7` | uwz(qpack): reserve storage for zero-capacity encoding |
| LSQ-005 | `5accc8aea1d4a0fb2e02530686ab1ab42527f98f` | `5accc8aea1d4a0fb2e02530686ab1ab42527f98f` | uwz(quic): release retired crypto streams on destruction |
| LSQ-006 | `1aaac18c467e8b19a481dc6ef96db2b798e76edc` | `1aaac18c467e8b19a481dc6ef96db2b798e76edc` | uwz(h3): assert the maintained stream-error contract |
| LSQ-007 | `0f7382b17b38d7fb0496a0b75b3c66ace79e49e8` | `0f7382b17b38d7fb0496a0b75b3c66ace79e49e8` | uwz(quic): expose bounded application uni streams |
| LSQ-008 | `3e6c31890cb7c48d933b5114136324c5113fb0a8` | `67690e1048efab8249b565daadfd21d6a8fa0415` | Reliable reset implementation checkpoint |
| LSQ-009 | `c434c4ae3a2ad9f584d2c17536f800623ef36df6` | `38c7b0cfef0ebc20489d02ca1ee7507d9a65f50c` | Negotiated reset runtime checkpoint |
| LSQ-010 | `3640992bb231d3f0f2647e03fda6a2776fcc23ca` | `70521e37f5dfa887f46d9ae297b7677ae16b4c67` | Reliable reset ACK and cleanup proof |
| LSQ-011 | `74b8a8e1213b73b3c86f3b43c9b6437f30f0d908` | `54a596736fc37bf170a3f9418d5896f88dd860ec` | Draft-16 SETTINGS generation |
| LSQ-012 | `8b0ef12414cdcf7b8c20e0b9f4fceb321358c2d0` | `68faccfba1d8e7a90d29630a9751f46b653ee0db` | Immutable peer SETTINGS publication |
| LSQ-013 | `9f0088c58fe67cccf1871dc172c90c2ec6f97944` | `aaf173d478239cdcd6c6332a9bee83ecf5df26a4` | Directional stream-credit limits |
| LSQ-014 | `a1947ce3a4ceeb98413e53014cc87f72b6d89869` | `5e6d1b72c9dae173d4cb647a3753f077de598a4e` | Child-stream implementation checkpoint |
| LSQ-015 | `202ed8b9e92929d1ec62ffe2e5034d1a00fda355` | `b207f436ed79f361b877eca82aa55a6bd025eb21` | Child callback and reset ordering |
| LSQ-016 | `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c` | `ebe6a0f90c631a76bd32e7367558f59cfee9d26f` | Child placement and GOAWAY isolation |
| LSQ-017 | `530e9e505eb04a0a4095b290f7eb052504ace94e` | `5dc663c7c2e957de919f59c012666f37bb6fc78d` | Coded receive-half cancellation |
| LSQ-018 | `005ab244169f269689e511d6b77dd2187e318df1` | `b435b008d51987ee9a4410b8b36b7d3f873860c1` | WebTransport UNI credit replenishment |
| LSQ-019 | `c8cf3fbc201a5d6f6acb6ae45af476cfcd5d7840` | `dba92a3246398e0f7e8902feb2bf858dd6407a50` | Pre-delivery receive observation |
| LSQ-020 | `d1104a9fab040af659295a95fb448c971a7bc6de` | `172fb713eee0e4dddd9f87f58cd6e92a1d1b54b7` | Receive publication snapshot flag |

The first five objects are unchanged. The following thirteen retain original author/committer bytes, all eighteen trees and each source diff. Original subjects and bodies remain, except the receive-observer ledger identifier is normalized with an explicit `Original-ledger` record. The original source message is retained in `inputs/original_messages/`. Historical WIP failures remain stated; final-tip evidence is not assigned to earlier checkpoints.

## LSQ-003: uwz(quic): match ACK callback function types

Ledger: LSQ-003

Upstream: None (downstream native sanitizer regression)

Invariant: ACK callbacks match the generator void-context types exactly.

Test evidence: The baseline real TLS handshake fails UBSan on the old casts. The combined candidate passes strict ASan, UBSan and LSan.

Retirement criterion: The base provides equivalent typed callbacks.

## LSQ-004: uwz(qpack): reserve storage for zero-capacity encoding

Ledger: LSQ-004

Upstream: None (downstream zero-dynamic-QPACK sanitizer regression)

Invariant: Physical encoding storage is nonempty while logical capacity stays zero when dynamic QPACK is disabled.

Test evidence: The old zero VLA bound fails UBSan in a real HTTP/3 response. The combined strict eight-group candidate suite passes.

Retirement criterion: The base handles zero capacity without zero VLAs.

## LSQ-005: uwz(quic): release retired crypto streams on destruction

Ledger: LSQ-005

Upstream: None (downstream immediate TLS teardown regression)

Invariant: Engine destruction releases service-owned retired crypto streams exactly once before freeing their connection and session.

Test evidence: An unchanged TLS-only immediate-destroy probe changes from 2170 leaked bytes to zero under strict ASan, UBSan and LSan.

Retirement criterion: The base reclaims service-only retired crypto.

## LSQ-006: uwz(h3): assert the maintained stream-error contract

Ledger: LSQ-006

Upstream: None (test synchronization with maintained LSQ-001)

Invariant: Malformed request headers reset their stream without a connection abort; a healthy sibling and one-shot header ownership hold.

Test evidence: The old baseline assertion fails. Strengthened request reset, decoded length, sibling and ownership checks pass all 83 existing native Linux Debug cases in the combined candidate.

Retirement criterion: The base tests the equivalent LSQ-001 policy.

## LSQ-007: uwz(quic): expose bounded application uni streams

Ledger: LSQ-007

Upstream: None (accepted WebTransport backend prerequisite)

Invariant: Synchronous uni creation consumes peer credit only on success, preserves HTTP critical streams and safely drains ownership.

Test evidence: Eight real encrypted-engine groups pass Debug, ReleaseSafe and strict ASan, UBSan and LSan, with controlled lifecycle omission regressions. Windows and macOS libraries cross-compile.

Retirement criterion: The base exposes equivalent creation and lifetime semantics. This primitive does not activate WebTransport.

## LSQ-008: Reliable reset implementation checkpoint

Ledger: LSQ-008

Upstream: None (downstream reliable-stream-reset draft-09 implementation)

Invariant: Preserve reliable-prefix packet and stream state while retaining full final-size flow accounting; this incomplete checkpoint keeps receive advertisement disabled.

Test evidence: Historical checkpoint: codec and receive checks and eight existing engine groups passed; targeted correction and end-to-end delivery checks were still pending. See the original message and reliable-reset evidence archive; later LSQ-009 and LSQ-010 complete its runtime follow-through.

Retirement criterion: The maintained base supplies equivalent draft-09 reliable reset state, prefix retention and final-size credit accounting.

## LSQ-009: Negotiated reset runtime checkpoint

Ledger: LSQ-009

Upstream: None (downstream reliable-stream-reset draft-09 runtime integration)

Invariant: Advertise negotiated receive support in live and ticket parameters, accept application-level reset frames and preserve independent receive state across local write reset.

Test evidence: Historical checkpoint: focused Debug cases and independent native quic-go interoperability passed, while six scaffold linking failures and the legacy send_headers assertion remained unresolved; ACK batching was pending. LSQ-010 records their later resolution.

Retirement criterion: The maintained base provides equivalent negotiated reliable-reset delivery, ticket parameters and independent half-state semantics.

## LSQ-010: Reliable reset ACK and cleanup proof

Ledger: LSQ-010

Upstream: None (downstream reliable-reset ACK and native fixture regressions)

Invariant: An encrypted eight-stream reset ACK scan visits each candidate and retained record exactly once; legacy fixtures preserve assertions while modelling quiescent reset service.

Test evidence: All 83 upstream Debug cases and 165 build steps passed; both reset sender roles passed shrink and batching; ten ReleaseSafe reset executables and Windows GNU/macOS ARM64 production compilation passed. Evidence: benchmarks/results/lsquic_reliable_reset_prerequisite_v1/2026_11_13/README.md.

Retirement criterion: The maintained base retains equivalent ACK batching, obsolete ACK handling and deferred native cleanup regressions.

## LSQ-011: Draft-16 SETTINGS generation

Ledger: LSQ-011

Upstream: None (downstream draft-ietf-webtrans-http3-16 SETTINGS writer)

Invariant: Default-off configuration validates inclusive bounds and emits draft-16 SETTINGS in fixed storage without changing disabled wire encodings.

Test evidence: Generation and configuration regressions passed Debug, ReleaseSafe and ReleaseFast in both roles, including exact limits and unchanged disabled inputs. This generation-only checkpoint still lacked peer snapshot publication and final broad gates, completed by LSQ-012.

Retirement criterion: The maintained base supplies equivalent opt-in bounded draft-16 SETTINGS generation and validation.

## LSQ-012: Immutable peer SETTINGS publication

Ledger: LSQ-012

Upstream: None (downstream draft-ietf-webtrans-http3-16 peer SETTINGS contract)

Invariant: Publish an immutable peer snapshot only after complete valid SETTINGS and actual handshake parameters; notify quiescently and preserve caller output on pending or error.

Test evidence: Peer lifecycle, bytewise and malformed control delivery, second-frame masking and pure state checks passed all three modes; 83 upstream Debug cases and Windows GNU/macOS ARM64 production compilation passed. Evidence: benchmarks/results/lsquic_webtransport_settings_v1/2026_11_13/README.md.

Retirement criterion: The maintained base provides equivalent immutable peer snapshots, handshake-derived support and quiescent lifecycle notification.

## LSQ-013: Directional stream-credit limits

Ledger: LSQ-013

Upstream: None (downstream WebTransport uni admission and IETF bidi send credit)

Invariant: With WebTransport enabled, client uni admission matches TLS advertisement; bidi send limits follow the stream initiator while disabled admission retains legacy policy.

Test evidence: Encrypted uni admission and TLS advertisement plus all four raw bidi halves passed Debug, ReleaseSafe and ReleaseFast; 83 upstream Debug cases and Windows GNU/macOS ARM64 production compilation passed. Actual resumed asymmetric traffic remained unverified. Evidence: benchmarks/results/lsquic_webtransport_credit_v1/2026_11_13/README.md.

Retirement criterion: The maintained base provides equivalent opt-in uni admission and initiator-selected bidi send limits.

## LSQ-014: Child-stream implementation checkpoint

Ledger: LSQ-014

Upstream: None (downstream draft-16 child-stream association checkpoint)

Invariant: Retain raw child creation, directional metadata and incremental prefix classification as an explicitly incomplete checkpoint requiring ordered typed publication.

Test evidence: Historical checkpoint: 41 focused Debug scenarios passed, but delayed SETTINGS still allowed RESET notification before typed publication. The failing regression remained unchanged; LSQ-015 fixes callback ordering and LSQ-016 completes placement and GOAWAY checks.

Retirement criterion: The maintained base supplies equivalent child factories and prefix classification with the later ordered-publication and placement fixes.

## LSQ-015: Child callback and reset ordering

Ledger: LSQ-015

Upstream: None (downstream draft-16 typed callback and reset accounting)

Invariant: Defer RESET and STOP notifications until typed publication, freeze accepted final size before receive suffix discard, and finish cancelled children after rejected negotiation.

Test evidence: Independent lifecycle failures reproduced before the fixes; 51 focused scenarios passed all three modes, with 83 upstream Debug cases and Windows GNU/macOS ARM64 production compilation passing. Placement findings remained open until LSQ-016.

Retirement criterion: The maintained base provides equivalent typed-before-terminal callbacks, final-size retention and rejected-negotiation child cleanup.

## LSQ-016: Child placement and GOAWAY isolation

Ledger: LSQ-016

Upstream: None (downstream draft-16 child placement and existing-session GOAWAY policy)

Invariant: Reject forbidden WT_STREAM placement at type completion while preserving default-off behavior, stream-local errors and existing-session child delivery across GOAWAY.

Test evidence: All 65 focused scenarios passed Debug, ReleaseSafe and ReleaseFast; all 83 upstream Debug cases and Windows GNU/macOS ARM64 production libraries passed. Independent API and lifecycle reviews had no remaining required findings. Evidence: benchmarks/results/lsquic_webtransport_children_v1/2026_11_16/README.md.

Retirement criterion: The maintained base enforces equivalent WT_STREAM placement, scope-correct rejection and existing-session GOAWAY isolation.

## LSQ-017: Coded receive-half cancellation

Ledger: LSQ-017

Upstream: None (downstream IETF application receive-half STOP_SENDING API)

Invariant: Explicit full-width receive cancellation is failure-atomic, preserves transmit state and peer errors, and retains queued STOP through packetization without losing native close progress.

Test evidence: Declaration and encrypted-wire failures were retained; six focused native Debug cases, 65 existing WT cases and 83 upstream cases passed before logger-only follow-through, whose core hashes were unchanged; full-width event-log RED/GREEN and final 15-case wrapper cohorts passed all three modes. Evidence: benchmarks/results/webtransport_coded_stop_v1/2026_11_16/README.md.

Retirement criterion: The maintained base exposes equivalent full-width failure-atomic receive cancellation and packetization-safe close progress.

## LSQ-018: WebTransport UNI credit replenishment

Ledger: LSQ-018

Upstream: None (downstream opt-in HTTP WebTransport UNI credit progress)

Invariant: Closing an opt-in peer UNI stream schedules coalesced MAX_STREAMS credit even when persistent HTTP/3 streams prevent the legacy half-window threshold.

Test evidence: The historical commit records the actual nine-case App/TLS/UDP Debug cohort, including creation past initial UNI credit with six persistent streams. Later broader mode/native results are retained separately in benchmarks/results/webtransport_child_lifecycle_v1/2026_11_16/README.md; they are not attributed to the earlier checkpoint run.

Retirement criterion: The maintained base supplies equivalent opt-in peer UNI replenishment with persistent critical and child streams.

## LSQ-019: Pre-delivery receive observation

Ledger: LSQ-019

Upstream: None (downstream draft-ietf-webtrans-http3-16 receive observation contract)

Invariant: Each published child's positive body high-water delta is reported once before application delivery/close, including NULL context; rejected unpublished children retain no receive observer ownership.

Test evidence: Eight observer groups pass Debug/ReleaseSafe/ReleaseFast; real delayed SETTINGS and early STOP regressions have retained RED/GREEN inputs; existing WT/reset fixtures and all 83 Linux Debug native assertion cases pass; frozen Root 67-case App/TLS/UDP cohort passes all three modes with observer absent.

Retirement criterion: An upstream or maintained base provides equivalent monotonic receive snapshots, quiescent pre-delivery accounting, rejected-association cleanup, and buffered-prefix boundary preservation.

## LSQ-020: Receive publication snapshot flag

Ledger: LSQ-020

Upstream: None (downstream draft-16 receive snapshot publication identity)

Invariant: Expose the existing native publication bit in receive snapshots without changing layout or scheduling; typed state publication does not imply completion of the typed callback.

Test evidence: The pre-change getter fails the actual receive-observer assertion. Final prepublication, delayed SETTINGS, observer, typed and close snapshot regressions passed eight groups in all three modes, inherited WT/reset fixtures and 83 Linux Debug native cases. Evidence: benchmarks/results/lsquic_receive_publication_v1/2026_11_17/README.md.

Retirement criterion: The maintained base exposes equivalent published-versus-never-published receive snapshot identity without conflating callback completion.

## XEV-008: unchanged typed poll cancellation

Original and prepared commit: `5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`. Full history is retained unchanged in `bundles/libxev-xev008.bundle`.

uwz(io_uring): preserve typed poll cancellation results

Ledger: XEV-008
Upstream: None (downstream UDP readiness cancellation)
Invariant: A kernel ECANCELED result for a poll completion reports
error.Canceled exactly once and preserves cancellation accounting.
Test evidence: The poll cancellation regression fails with Unexpected on
c49f6dfb83038c146232472c063e4b2681d098d8 and passes with this mapping.
Full native Debug and ReleaseSafe suites each pass 143 tests with four
existing platform exclusions; downstream GRO tests pass both Linux backends.
Retirement criterion: The maintained integration base contains an equivalent
poll ECANCELED mapping and lifecycle regression.
