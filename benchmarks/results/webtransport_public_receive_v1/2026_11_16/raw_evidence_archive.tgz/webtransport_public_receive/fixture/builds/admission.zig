const std = @import("std");
const boringssl = @import("vendor/boringssl.zig");
const libdeflate = @import("vendor/libdeflate.zig");
const lsquic = @import("vendor/lsquic.zig");
const sanitizers = @import("sanitizers.zig");
const zlib = @import("vendor/zlib.zig");

pub fn configure(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const sanitizer = sanitizers.configure(b, target, true);
    const project_path = b.option([]const u8, "project-source", "Actual project checkout under test") orelse
        "/tmp/uwz-wt-public-streams-20261116/project";
    const test_source = b.option([]const u8, "test-source", "Scratch actual App test driver") orelse "tests/children_main.zig";
    const test_filter = b.option([]const u8, "test-filter", "Run one selected functional case");
    const project: std.Build.LazyPath = .{ .cwd_relative = project_path };
    const bssl = boringssl.build(b, target, optimize, sanitizer);
    const deflate = libdeflate.build(b, target, optimize, sanitizer);
    const z = zlib.build(b, target, optimize, sanitizer);
    const ls = lsquic.build(b, target, optimize, sanitizer, bssl, z, true, false, true);
    const zslay = b.dependency("zslay", .{ .target = target, .optimize = optimize }).module("zslay");
    const libxev_source = b.option([]const u8, "libxev-source", "Explicit reviewed scratch libxev source tree");
    const xev_impl = if (libxev_source) |source|
        b.createModule(.{
            .root_source_file = .{ .cwd_relative = b.pathJoin(&.{ source, "src/main.zig" }) },
            .target = target,
            .optimize = optimize,
        })
    else
        b.dependency("libxev", .{ .target = target, .optimize = optimize }).module("xev");
    const xev = b.createModule(.{
        .root_source_file = project.path(b, "src/core/xev.zig"),
        .target = target,
        .optimize = optimize,
        .imports = &.{.{ .name = "xev_impl", .module = xev_impl }},
    });
    const options = b.addOptions();
    options.addOption(bool, "sql", false);
    options.addOption(bool, "sqlite", false);
    const translate = b.addTranslateC(.{
        .root_source_file = b.path("fixtures/admission_c.h"),
        .target = target,
        .optimize = optimize,
    });
    translate.addIncludePath(project.path(b, "src"));
    translate.addIncludePath(ls.include_root);
    translate.addIncludePath(bssl.include_root);
    translate.addIncludePath(deflate.include_root);
    translate.addIncludePath(z.include_root);
    translate.addIncludePath(b.path("fixtures"));
    const c_module = translate.createModule();
    const support = b.createModule(.{
        .root_source_file = project.path(b, "src/test_support.zig"),
        .target = target,
        .optimize = optimize,
        .imports = &.{
            .{ .name = "c", .module = c_module },
            .{ .name = "zslay", .module = zslay },
            .{ .name = "xev", .module = xev },
            .{ .name = "module_options", .module = options.createModule() },
        },
    });
    const module = b.createModule(.{
        .root_source_file = b.path(test_source),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
        .link_libcpp = true,
        .imports = &.{
            .{ .name = "c", .module = c_module },
            .{ .name = "test_support", .module = support },
        },
    });
    module.addIncludePath(ls.include_root);
    module.addIncludePath(bssl.include_root);
    module.addIncludePath(deflate.include_root);
    module.addIncludePath(z.include_root);
    module.addIncludePath(ls.assembled_root.path(b, "src/liblsquic"));
    module.addIncludePath(ls.assembled_root.path(b, "src/lshpack"));
    module.addIncludePath(ls.assembled_root.path(b, "src/liblsquic/ls-qpack"));
    module.addIncludePath(b.path("fixtures"));
    const fixture_flags = sanitizers.instrumented_flags(b, &.{
        "-std=gnu11",
        "-UNDEBUG",
        "-DHAVE_BORINGSSL",
        "-DLSQUIC_CONN_STATS=1",
        "-DLSQUIC_DEBUG_NEXT_ADV_TICK=1",
        "-DLSQUIC_WT_SETTINGS_TEST_OBSERVER=1",
        "-D__wrap_lsquic_time_now=lsquic_time_now",
        "-Wall",
        "-Wextra",
        "-fno-omit-frame-pointer",
    }, sanitizer);
    module.addCSourceFiles(.{
        .files = &.{ "fixtures/uwz_quic_fixture.c", "fixtures/uwz_app_client.c" },
        .flags = fixture_flags,
    });
    module.addCSourceFile(.{
        .file = project.path(b, "src/quic/lsquic_shim.c"),
        .flags = sanitizer.c_flags(),
    });
    module.linkLibrary(ls.library);
    module.linkLibrary(bssl.ssl);
    module.linkLibrary(bssl.crypto);
    module.linkLibrary(deflate.library);
    module.linkLibrary(z.library);
    sanitizer.attach(module);
    const filters = if (test_filter) |value|
        b.allocator.dupe([]const u8, &.{value}) catch @panic("out of memory")
    else
        &.{};
    const tests = b.addTest(.{ .name = "uwz_actual_app_public_streams", .root_module = module, .filters = filters });
    const run = sanitizers.add_run_artifact(b, tests, sanitizer.run);
    const test_step = b.step("test", "Run actual App admission over real TLS and loopback UDP");
    test_step.dependOn(&run.step);
    b.step("test-compile", "Compile the actual App admission harness").dependOn(&tests.step);
    b.default_step = test_step;
}
