# Public incoming WebTransport streams checkpoint

The final cohort passes 26/26 functional tests, with no import-only anchor,
in Debug, ReleaseSafe and ReleaseFast. Each build reports 16/16 steps and
exits zero. The selected entry point is `tests/children_main.zig`.

## Frozen inputs and profile

The 29-file run inventory is `provenance/public26_run_inputs.sha256`, SHA256
`45668273955fe3464fec42cf71832a7411d556c3f0dd09032994ecc36d932197`.
It is unchanged after all three modes. The actual Root source/build copy is
`project_v4/`, whose 255-file inventory is
`provenance/project_v4_inputs.sha256`, SHA256
`fcc59facfad8bc048d2b4a17d09d95613bc84b7fd9dd38d2725d07d4128f6ba5`.
Root snapshots `project/`, `project_v2/` and `project_v3/` remain historical
inputs; they are not the final replay source. README and replay were added
after the terminal runs and have a separate delivery inventory.

The explicit native source is lsquic
`005ab244169f269689e511d6b77dd2187e318df1`; the explicit libxev source is
`5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`. Both working trees were clean.
Production dependency pins remain unchanged. These proposals and the existing
Zig vendor builders compile through Zig 0.16.0, with actual translated C,
native HTTP/3 and TLS, Root App admission/dispatch, Linux loopback UDP and xev.
All six inherited C/header fixture inputs match their pre-migration hashes.
There are no substituted production callbacks or fabricated native flags.

Native scheduling uses the inherited synthetic fixture clock. The App pending
child expiry case uses the actual production awake clock and a real 1.1-second
sleep. No equivalence between those clock domains is claimed. The bounded
native queues and callback observations retain their original fixture limits.

Source/history for native005 and XEV5b2c is retained in the prior artifact
`benchmarks/results/webtransport_child_lifecycle_v1/2026_11_16/raw_evidence_archive.tgz`,
SHA256 `3e27ce7137f3791cf977d0b4c83bee4ea72c873b1af125c3a13616695b2a8418`
(12,891,820 bytes), documented by its same-directory README. It is referenced
rather than duplicated here. Actual compiled hpack is
`fda48e02491d865cce00612be8cc10c2622b8e55`; the native gitlink remains
`cf0f70dd10b352194c97448eb5d00b4aa484f531`. Actual qpack
`91567706c41c0d97ab8dc576873ecd472d7869fa` matches its native gitlink.

## Functional proof

Seventeen prior incoming-RX cases now register through public
`webtransport_streams_context` and use public Info, Handle, typed errors and
callbacks. Their original identity, payload, terminal, accounting, isolation,
quota, expiry and reentry assertions remain. Inherited private terminology in
one test title is historical; its invoked callbacks are public. Read-only Root
observations retain the original full-ID/generation assertions. BIDI EOF and
RESET are followed by explicit public finish, except cases that deliberately
hold the transmit half open. No fake datagram endpoint or datagram storage is
needed for the public stream-only startup.

Eight additional public cases cover WrongApp, stale/reused slot, invalid index
and generation, open-time NotReady, application cancellation, BIDI EOF/RESET
half independence, two route contexts, session notifications, Close application
code 37 before parent FIN, admission-callback cooldown and generation exhaustion.
EOF/RESET finish is checked at the real peer: an empty FIN arrives without a
peer transmit RESET. The generation exhaustion case intentionally supplies only
the Root stream-generation counter at maxInt(u64); real new UNI traffic must
be refused without wrapping or invalidating the previously admitted handle.
It changes no native protocol flags, credit or peer cache.

The twenty-sixth case stages two real children before CONNECT. Actual pending
iteration opens stream18 before stream14. At stream14's cooldown-triggering
open, stream18 is already active and consumer-owned, with its exact 3,072-byte
payload delivered in two callbacks and no receive terminal. The client sent
neither FIN nor RESET on either child before admission. The test requires no data after the trigger,
one shutdown close per owned child, one shutdown session notification and
empty Root pools/pending/retry storage. Real cancellation induces late peer
RESET final sizes, so final accounting is exactly 5 and 3,072 bytes rather than
invented zero/unknown sizes. Earlier attempts failed fixture staging or
fixture accounting assumptions; they do not establish a v3 sibling product RED.

The session shutdown test runs at the actual CONNECT authorization callback.
An attempted backpressured accepting-HEADERS boundary was not attained and is
not claimed covered. The two-route case uses two real connections, each SID0;
it does not prove multiplexed sessions on one connection.

## Commands and results

From the fixture directory, the exact final command below ran serially with
`MODE` set to Debug, ReleaseSafe and ReleaseFast. It ran with authorized
loopback socket access; sandbox EPERM from the first attempt is retained as
an environment failure.

```sh
ulimit -c 0
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-uni-global-cache \
  /tmp/zig-x86_64-linux-0.16.0/zig build test \
  --system /tmp/uwz-wt-child-callbacks-20261116/zig-pkg \
  --cache-dir /tmp/uwz-wt-public-streams-cache \
  -Dproject-source=/tmp/uwz-wt-public-streams-20261116/project_v4 \
  -Dtest-source=tests/children_main.zig -Doptimize="$MODE" \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-uni-credit-20261116 \
  -Dlibxev-source=/tmp/uwz-gro-libxev -j2 --summary all
```

| Mode | Session | Result | Log SHA256 |
| --- | --- | --- | --- |
| Debug | 40970 | exit0, 26/26, 16/16 | `b1d8cbe67ae6c547c3f20713b3575d1aadec4b8c71fe5db40adea1caa8e7e6b6` |
| ReleaseSafe | 44003 | exit0, 26/26, 16/16 | `ddd8c4f7bc4afb8b3c582bb1478e882c41ec61ed68e99c4e3393e2f29541c355` |
| ReleaseFast | 78726 | exit0, 26/26, 16/16 | `93ee9b155f60a518f887879de4bfd24f7973f0c604a709c6cd3391e2c1811463` |

The sibling `evidence/` directory contains raw logs, exits, exact commands,
results, history classification and input verification records. Historical
files whose names include `final` refer to their recorded earlier snapshots;
the three `public26-v4-*` rows above are authoritative. Initial socket EPERM,
diagnostic compile errors and a quota failure are not product failures.
Only inactive disposable cache objects were removed for quota recovery;
sources, packages, snapshots and logs were preserved.

## Relocatable replay and limits

Set `UWZ_ZIG`, `UWZ_LSQUIC_SOURCE`, `UWZ_LIBXEV_SOURCE` and
`UWZ_PACKAGE_DIR` to Zig 0.16.0, the exact native/XEV sources and the offline
Zig package directory, then run `sh ./replay.sh Debug` (or ReleaseSafe or
ReleaseFast). The script derives its own location, defaults to its adjacent
`project_v4/`, checks both frozen inventories and uses `--system` to prevent
dependency fetching. `UWZ_PROJECT_SOURCE`, `UWZ_CACHE_DIR`,
`ZIG_GLOBAL_CACHE_DIR` and `UWZ_JOBS` may override replay locations/resources.
Native/XEV source authenticity is verified against the referenced source
archive; the script does not infer an archive's revision from a directory name.
Run in an environment permitting loopback UDP sockets.

This is the first public incoming-stream increment: registration, RX/session
callbacks, handles, cancellation and explicit finish. Public writes, writable
events, outgoing creation, general TX/backpressure behavior, browser or
independent-client acceptance and production pin activation remain open. This
checkpoint is not full WebTransport or release acceptance. Smoke, dedicated
security, sanitizer and fuzz campaigns remain user-deferred.
