/* Copyright (c) 2026 uWebZockets contributors. See LICENSE. */
#ifndef UWZ_APP_CLIENT_H
#define UWZ_APP_CLIENT_H

#include <stddef.h>
#include <stdint.h>
#include "lsquic.h"

struct uwz_app_client;

enum uwz_app_client_variant {
    UWZ_APP_CLIENT_DEFAULT = 0,
    UWZ_APP_CLIENT_NO_WT = 1,
    UWZ_APP_CLIENT_SMALL_RESPONSE_CREDIT = 2,
    UWZ_APP_CLIENT_HELD_SETTINGS = 3,
    UWZ_APP_CLIENT_LARGE_DATAGRAM = 4,
    UWZ_APP_CLIENT_DELAYED_CLOSE = 5,
};

struct uwz_app_connect_request {
    const char *origin;
    const char *authorization;
    unsigned duplicate_origin;
};

enum {
    UWZ_APP_MAX_STEPS = 20000,
    UWZ_APP_MAX_STREAMS = 16,
    UWZ_APP_MAX_BODY = 512,
};

struct uwz_app_client_snapshot {
    uint64_t configured_max_data;
    uint64_t configured_bidi_local;
    uint64_t configured_bidi_remote;
    uint64_t configured_uni;
    uint64_t remote_error_code;
    unsigned handshake_complete;
    unsigned settings_callbacks;
    unsigned connection_closed;
    unsigned stream_callbacks;
    unsigned typed_callbacks;
    unsigned received_datagrams;
    unsigned datagrams_written;
    unsigned datagrams_received;
    unsigned configured_wt;
    unsigned configured_delay_onclose;
    unsigned configured_base_plpmtu;
    unsigned configured_max_plpmtu;
    unsigned control_constructed;
    unsigned control_held;
    uint64_t control_offset;
    uint64_t control_buffered;
    int connection_status;
    int closed_status;
    int remote_app_error;
    unsigned remote_reason_size;
    char remote_reason[96];
    unsigned local_reason_size;
    char local_reason[128];
};

struct uwz_app_stream_diagnostics {
    uint64_t send_limit;
    uint64_t send_offset;
    uint64_t receive_limit;
    uint64_t maximum_received;
    uint64_t read_offset;
    uint64_t stream_flags;
    uint64_t queue_flags;
    uint64_t buffered_bytes;
    uint64_t h3_data_remaining;
    uint64_t h3_frame_type;
    unsigned receive_window;
    unsigned send_headers_state;
    unsigned delayed_shutdown_write;
    unsigned send_shutdown;
};

struct uwz_app_peer_transport_diagnostics {
    uint64_t max_data;
    uint64_t bidi_local;
    uint64_t bidi_remote;
    uint64_t uni;
    uint64_t streams_bidi;
    uint64_t streams_uni;
};

struct uwz_app_input_statistics {
    uint64_t packets;
    uint64_t undec_packets;
    uint64_t dup_packets;
    uint64_t err_packets;
};

uint64_t uwz_app_stream_buffered_bytes(const lsquic_stream_t *);
int uwz_app_sibling_receive(const lsquic_stream_t *, uint64_t,
                             struct lsquic_stream_recv_state *);
int uwz_app_connection_input_statistics(lsquic_conn_t *, struct uwz_app_input_statistics *);
unsigned uwz_app_client_pending_packets(const struct uwz_app_client *);

struct uwz_app_response_snapshot {
    uint64_t stream_id;
    uint64_t reset_error_code[2];
    size_t received;
    unsigned header_callbacks;
    unsigned status_code;
    unsigned status_ok;
    unsigned fin_received;
    unsigned close_callbacks;
    unsigned reset_callbacks;
    unsigned reset_events[2];
    int reset_error_status[2];
    unsigned char bytes[UWZ_APP_MAX_BODY];
    struct lsquic_webtransport_stream_info new_info;
    struct lsquic_webtransport_stream_info typed_info;
    struct lsquic_webtransport_stream_info close_info;
    struct lsquic_stream_recv_state close_receive;
    int new_info_result;
    int typed_info_result;
    int close_info_result;
    int close_receive_result;
    unsigned typed_callbacks;
    unsigned read_callbacks;
};

/* No global init/cleanup: the actual project engine owns that reference. */
struct uwz_app_client *uwz_app_client_create(uint16_t server_port);
struct uwz_app_client *uwz_app_client_create_variant(uint16_t server_port,
                                                    enum uwz_app_client_variant);
void uwz_app_client_destroy(struct uwz_app_client *);
int uwz_app_client_connect(struct uwz_app_client *);
int uwz_app_client_process(struct uwz_app_client *);
int uwz_app_client_release_settings(struct uwz_app_client *);
int uwz_app_client_send_udp(struct uwz_app_client *);
int uwz_app_client_stage_pending_packets(struct uwz_app_client *, lsquic_engine_t *, void *peer_context);
int uwz_app_client_receive_udp(struct uwz_app_client *);
uint16_t uwz_app_client_port(const struct uwz_app_client *);
int uwz_app_client_observe(const struct uwz_app_client *, struct uwz_app_client_snapshot *);
int uwz_app_client_response(const struct uwz_app_client *, uint64_t,
                               struct uwz_app_response_snapshot *);
uint64_t uwz_app_client_open_connect(struct uwz_app_client *,
                                    const struct uwz_app_connect_request *);
uint64_t uwz_app_client_open_connect_path(struct uwz_app_client *,
                                        const struct uwz_app_connect_request *, const char *path);
uint64_t uwz_app_client_open_post(struct uwz_app_client *, const char *path, size_t body_size);
lsquic_conn_t *uwz_app_client_connection(struct uwz_app_client *);
lsquic_stream_t *uwz_app_client_stream(struct uwz_app_client *, uint64_t stream_id);
uint64_t uwz_app_client_last_stream_id(const struct uwz_app_client *);
int uwz_app_client_open_raw_uni(struct uwz_app_client *, uint64_t *stream_id);
int uwz_app_client_pause_child_reads(struct uwz_app_client *, int paused);
int uwz_app_client_enable_stream_reads(struct uwz_app_client *, uint64_t stream_id);
uint16_t uwz_app_connection_peer_port(lsquic_conn_t *);
int uwz_app_client_write(struct uwz_app_client *, uint64_t,
                            const unsigned char *, size_t, int fin);
int uwz_app_client_queue_datagram(struct uwz_app_client *, const unsigned char *, size_t);
int uwz_app_client_grant_response_credit(struct uwz_app_client *, uint64_t stream_id, unsigned window);
uint64_t uwz_app_stream_send_limit(const lsquic_stream_t *);
int uwz_app_stream_diagnose(const lsquic_stream_t *, struct uwz_app_stream_diagnostics *);
int uwz_app_peer_transport_diagnose(const lsquic_conn_t *, struct uwz_app_peer_transport_diagnostics *);

int uwz_app_udp_socket_new(void);
uint16_t uwz_app_udp_socket_port(int fd);
void uwz_app_udp_socket_close(int fd);

#endif
