# Public incoming-stream fixture handoff

READY: all fixture builds are terminal. The authoritative fixture is
`/tmp/uwz-wt-public-streams-20261116`, using its immutable `project_v4/` copy.
The public source slice was committed by Root as
`7ecfc6b9285779e89b99a95dc910efa8f8403c46`; this worker changed no Root or
native candidate source.

## Final evidence

`results.json` and `commands.txt` record exact final commands and terminal
sessions40970/44003/78726. Debug, ReleaseSafe and ReleaseFast each pass
26/26 functional tests,0 anchors,16/16 build steps,exit0. All final run inputs
and Root snapshot inputs verify unchanged after the three modes and after
documentation edits. No extra runtime rerun follows the final three modes.

The authoritative29-file fixture run manifest is
`fixture/provenance/public26_run_inputs.sha256`, SHA256
`45668273955fe3464fec42cf71832a7411d556c3f0dd09032994ecc36d932197`.
The255-file Root v4 inventory is
`fixture/provenance/project_v4_inputs.sha256`, SHA256
`fcc59facfad8bc048d2b4a17d09d95613bc84b7fd9dd38d2725d07d4128f6ba5`.
The32-file delivery inventory adds the final README, replay script and copied
Root inventory without changing the historical run manifest:
`fixture/provenance/public26_delivery_inputs.sha256`, SHA256
`28e981e20b1d1792e4f99bfed2b09aa14190fa08991fed4a6ddb0077153753c1`.

| Mode | Raw log SHA256 |
| --- | --- |
| Debug | `b1d8cbe67ae6c547c3f20713b3575d1aadec4b8c71fe5db40adea1caa8e7e6b6` |
| ReleaseSafe | `ddd8c4f7bc4afb8b3c582bb1478e882c41ec61ed68e99c4e3393e2f29541c355` |
| ReleaseFast | `93ee9b155f60a518f887879de4bfd24f7973f0c604a709c6cd3391e2c1811463` |

The final public callback observer SHA256 is
`bddc0f8aef6940696c1bf48bc0747935810ab0d0799eb8e7f4b0c5a2f0a48e86`;
the callback regression driver SHA256 is
`ee882882333f75d88b74164a281a4e6ea578ac4d8ef4e18fe0a229e4d44438bc`.
All six C/header fixture files match the inherited pre-migration manifest.
Native005 and XEV5b2c working trees were clean at final verification.

## Scope and history

The cohort is17 migrated RX cases,8 public-specific cases and1 owned-sibling
cooldown case. All notification entry points and cancel/finish operations use
the public API. Private read-only observations retain inherited identity and
ownership oracles. Generation exhaustion explicitly supplies only Root's
stream-generation counter; no native flag/credit mutation is used.

The final sibling case proves actual ownership before the later child's
cooldown open, exact3072bytes/2data callbacks, no post-trigger data or receive
terminal, shutdown causes for both children and their parent notification,
late native final accounting5/3072 and complete bounded storage retirement.
No sibling product RED was established onv3; prior failures are fixture
staging/terminal/accounting assumptions and diagnostic compilation. They are
preserved and classified in `history.json`. Earlier genuine reset-close and
session-shutdown cause failures remain distinct from those fixture failures.

The actual authorization-callback cooldown is covered. The attempted
backpressured accepting-HEADERS boundary was unattained. Two-route isolation
uses two connections atSID0; same-connection session multiplexing is not
claimed. Public writes/writable/outgoing, general TX/backpressure, external
client acceptance and published native pins remain open. No smoke, dedicated
security, sanitizer or fuzz campaign was run.

`source_profile.json` records exact native/XEV commits, compiled hpack versus
native gitlink, qpack, actual App/UDP/xev profile and separate clock domains.
Native scheduling remains synthetic; production App pending expiry uses real
OS awake time. Sources/history for native005 and XEV5b2c come from the prior
lifecycle archive documented in the fixture README, not a new duplicate.

The first sandbox EPERM, diagnostic compile failures, quota-blocked empty run
and wrong-cwd initial inventory check are environmental/fixture evidence.
The corrected inventory check passes. Only inactive disposable cache objects
were removed; sources, snapshots, packages, logs and manifests were preserved.

## Assembly and replay

Copy the fixture as `fixture/` and this evidence directory as `evidence/`.
Keep all historical source snapshots/provenance and Root versions. The script
derives its own directory, so that placement is relocatable. README and replay
are post-run documentation-only additions. `sh -n replay.sh` passes; the script
was not used to rerun the already-complete cohort. Replay requires verified
native/XEV source paths, the offline Zig package directory and Zig0.16.0.
Root owns the final full-payload manifest, archive verification and delivery.
