# Local proposal ledger

| ID | Fork | Local commit | Upstream reference | Invariant | Test evidence | Retirement criterion |
| --- | --- | --- | --- | --- | --- | --- |
| LSQ-WT-RECEIVE-20261117 | lsquic | c8cf3fbc201a5d6f6acb6ae45af476cfcd5d7840 | None; downstream draft-16 observation contract | A published child's monotonic body receive high-water is debited once before application delivery/close, including NULL context. Never-published rejection retains no observer ownership. | Eight native observer groups in all three modes, inherited native WT/reset fixtures, 83 Linux Debug assertion cases, and frozen Root 67-case functional cohort in all three modes. Retained runtime RED/GREEN sources for rejected SETTINGS and early STOP. | Maintained base provides equivalent receive snapshots, quiescent pre-delivery accounting, rejected-association cleanup, and buffered-prefix boundary preservation. |

This row records an unpublished local proposal. It is not a production pin or
permission to publish an upstream/fork change. The exact base remains
005ab244169f269689e511d6b77dd2187e318df1.
