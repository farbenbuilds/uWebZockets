# Local native WebTransport receive observer proposal

This is an unpublished append-only lsquic proposal based on Native005
`005ab244169f269689e511d6b77dd2187e318df1`. The branch is
`uwz/receive-observer-proposal-20261117` in
`/tmp/uwz-lsquic-wt-receive-20261117`. Final local commit is
`c8cf3fbc201a5d6f6acb6ae45af476cfcd5d7840`. No production pin, vendor input, old
proposal, or Root source is changed. No fork is pushed.

The public receive snapshot appends `received_end`, the monotonic QUIC receive
high-water including out-of-order offsets and reset final sizes. The optional
`on_webtransport_receive(stream, ctx, payload_delta)` observer receives the
incremental body high-water excluding the peer association prefix. A NULL
application stream context is supported. Native commits its per-stream body
cursor before callback reentry. Zero delta denotes a newly coalesced metadata
transition, including initial publication, FIN/reset, read cancellation, and
peer STOP. Getters and unchanged duplicate observations generate no event.

The observer runs after Native marks the child typed/public, before typed
application admission and later read/reset/close callbacks. Ingress, getters,
and public shutdown only stage work. The existing service queue and one flag
coalesce notifications; no event allocation or separate queue is added. A
never-published association carries no receive-observer self-reference, and
early STOP remains deferred until successful typed publication. Direct native
destruction flushes a published child's pending final debit before on_close.
Before publication, an application classifier probe must consume no child
body bytes. The native HTTP classifier stops at classification even when the
next buffered data frame contains child payload.

Stream-only cancellation does not retract typed classification. The typed
metadata callback can still run after an observer cancels that stream, so a
consumer must gate activation/admission on its cancellation and session
state. Connection abort suppresses subsequent typed/read callbacks. The new
abort regression covers connection abort, not stream-only callback
suppression. Engine destruction from a callback is outside the inherited
native callback-lifetime contract.

The accounting basis follows [RFC 9000 sections 4.4, 4.5 and 19.10](https://www.rfc-editor.org/rfc/rfc9000.html#section-4.5)
and [draft-ietf-webtrans-http3-16 section 5.4](https://www.ietf.org/archive/id/draft-ietf-webtrans-http3-16.html#section-5.4):
QUIC flow accounting includes final sizes and offset gaps; WebTransport session
data accounting excludes stream headers. The observer is a native observation
mechanism. It does not implement Root session admission, capsule policy,
unknown-parent accounting, credit recycling, or positive session flow.

## Replay

`native_source.tgz` is an exact source snapshot of the final commit.
To replay after moving this proof directory, extract it into an empty directory
and pass that path as UWZ_LSQUIC_SOURCE. `native_receive.patch` records the
single append-only change, and `native_receive.bundle` retains its Git object
with Native005 as an explicit prerequisite.

Use `sh replay_native.sh Debug`, `ReleaseSafe`, or `ReleaseFast`. The default
case is `uwz_webtransport_receive`. The script accepts the existing native
`uwz_webtransport_streams`, `uwz_webtransport_stream_resets`, and
`uwz_reset_metadata` fixtures as a second argument. `sh replay_native.sh Debug
upstream` runs the existing Linux Debug assertion manifest. All C/C++ builds
use Zig source lists. The new fixture alone enables the existing fixture-only
SETTINGS constructor hook; it holds the control-stream writer before any
bytes are queued and writes genuine SETTINGS through public stream APIs.

`sh replay_root67.sh Debug` (or ReleaseSafe/ReleaseFast) checks the unchanged
frozen Root project_v2 and fixture inventories before running the 67-case
actual App/TLS/UDP cohort retained in `frozen_root67_fixture`, copied unchanged
from `/tmp/uwz-wt-public-outgoing-delivery-20261117/fixture`. The recorded matrix
used that original path; the retained copy passes both original inventories.
It uses the new native
candidate with the optional receive observer absent. It does not activate
Root positive flow or consume the new callback.

The final combined Debug compatibility check additionally uses Root registry
`project_v4`, equivalent to `eebd42ee8dc618434f9d9025159c9d8885576861`.
`sh replay_combined.sh streams` or `datagrams` uses its unchanged retained
`frozen_registry_fixture` and the committed native candidate. The recorded
runs used `/tmp/uwz-wt-session-records-delivery-20261117/fixture`; the retained
copy passes its original 40 fixture and 258 Root hashes. Streams pass 67/67
and datagrams pass 33/33 in Debug, both with 16/16 build steps. These are two
driver counts with shared helpers, not 100 disjoint cases. No positive flow
is activated. Two inherited datagram cases retain their explicit private
receiver-window staging; see that fixture's README for its unchanged limits.

Defaults use `/tmp/zig-x86_64-linux-0.16.0/zig`, offline packages
`/tmp/uwz-wt-child-callbacks-20261116/zig-pkg`, XEV
`/tmp/uwz-gro-libxev` at `5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`, and
exclusive ignored workspace caches under
`/home/foo/Desktop/Repos/uWebZockets/.zig-cache/wt-native-receive-proof-20261117`.
The scripts accept UWZ_ZIG, UWZ_PACKAGE_DIR, UWZ_LSQUIC_SOURCE,
UWZ_LIBXEV_SOURCE, UWZ_CACHE_DIR, and ZIG_GLOBAL_CACHE_DIR overrides. Loopback
socket permission is required. Core dumps are disabled. Assertions remain
active in every native fixture mode.

## Final verification

| Check | Result | Logs |
| --- | --- | --- |
| New receive observer fixture, Debug | Eight groups pass | native-final-debug-v2.log |
| New fixture, ReleaseSafe and ReleaseFast | Eight groups pass in each mode | native-final-ReleaseSafe.log, native-final-ReleaseFast.log |
| Existing native WT streams, stream resets, reset metadata | Pass in Debug | native-final-uwz_webtransport_streams.log, native-final-uwz_webtransport_stream_resets.log, native-final-uwz_reset_metadata.log |
| Existing Linux Debug native assertion manifest | 83/83 run cases pass | native-final-upstream.log |
| Frozen old Root cohort, Debug/ReleaseSafe/ReleaseFast | 67/67 pass in each mode | root67-final-Debug.log, root67-final-ReleaseSafe.log, root67-final-ReleaseFast.log |
| Final registry Root v4 combined Debug compatibility | Streams 67/67 and datagrams 33/33 | combined-root-v4-Debug-streams.log, combined-root-v4-Debug-datagrams.log |

All recorded final commands completed with exit status 0. The final production
diff passed independent read-only review after two lifecycle findings were
reproduced and corrected. The reviewed production diff SHA-256 is
`f044d1257e6e7cbca1f4e43db6a010dbc76f0e791ff83dc6677016c8780f99e4`.

The explicit installed Graphify AST-only update also completed: 322 code
files, 4519 nodes, 16474 edges. Its analysis outputs moved to
`native_graphify_analysis`, keeping the committed native tree clean. The
extractor reported 50 partially extracted C files and 48 no-symbol inputs;
this graph is a navigation aid, not compilation proof. The first non-login
PATH attempt failed 127; the explicit installed executable succeeded.

## Regression evidence and limits

The new fixture has eight groups: out-of-order high-water/coalescing/getter
purity/duplicates/canceled reads/late FIN; hidden reliable-reset final gaps;
NULL context and destruction ordering; encrypted child body arriving before
its held prefix; late STOP accounting order; rejected delayed SETTINGS with
and without an early TLS STOP, live stream removal, and real MAX_STREAMS
recovery; and connection abort from the observer suppressing admission/data.
STREAM and RESET boundary cases call the real native ingress functions with
native packet/frame objects. They are native ingress unit cases, not encrypted
wire cases. Packet reordering, delayed SETTINGS, early STOP, and peer stream
credit recovery run actual TLS packets through the public native engines.

`contract-red.log` records missing observer/high-water fields against unchanged
Native005; `contract-green.log` compiles the new header. The first cache and
syntax-driver errors are setup failures. Early fixture compile/wait failures
remain labeled historical observations, not product claims. The v5/v6 logs
record the native classifier continuation defect and its correction.

`native-wait-ownership-runtime-red-v2.log` reaches one SETTINGS callback and
one close callback, then times out because the rejected stream remains in
the live native connection. Its exact source is retained in
`regression_inputs/wait_ownership_runtime_red_native_v2.tgz`.
`native-early-stop-red.log` fails the old publication assertion when a genuine
early TLS STOP is serviced before delayed SETTINGS. Its exact source is in
`regression_inputs/early_stop_runtime_red_native.tgz`. The final Debug log
`native-final-debug-v2.log` passes both corrections and the other six groups.

The first ReleaseSafe and Root compatibility attempts under /tmp failed on
scratch DiskQuota, including a Zig DWARF panic. These are environment failures.
Only this task's disposable caches moved to ignored workspace storage before
successful retries. No other worker's cache was used or swept.

Dedicated smoke/security/sanitizer/fuzz campaigns are user-deferred. This
proof does not claim production activation, full positive Root flow,
independent draft-16 client interoperability, non-Linux runtime, performance
measurements, native allocation freedom, or safe engine destruction from
inside callbacks. The inherited native callback-lifetime contract applies.
