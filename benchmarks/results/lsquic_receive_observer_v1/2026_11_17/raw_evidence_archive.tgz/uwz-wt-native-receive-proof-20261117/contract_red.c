#include <stddef.h>
#include <stdint.h>
#include "lsquic.h"

static void receive_state(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx,
                          uint64_t payload_delta)
{
    struct lsquic_stream_recv_state snapshot;
    (void) ctx;
    if (lsquic_stream_get_recv_state(stream, &snapshot) == LSQUIC_SRG_OK)
        (void) (snapshot.received_end + payload_delta);
}

static const struct lsquic_stream_if callbacks = {
    .on_webtransport_receive = receive_state,
};

int main(void) { return callbacks.on_webtransport_receive == NULL; }
