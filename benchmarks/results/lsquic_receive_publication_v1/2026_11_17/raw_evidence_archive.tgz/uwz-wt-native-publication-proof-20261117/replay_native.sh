#!/bin/sh
set -eu
uwz_proof=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
uwz_mode=${1:-Debug}
uwz_case=${2:-uwz_webtransport_receive}
case "$uwz_mode" in Debug|ReleaseSafe|ReleaseFast) ;; *) exit 2 ;; esac
case "$uwz_case" in
    uwz_webtransport_receive|uwz_webtransport_streams|uwz_webtransport_stream_resets|uwz_reset_metadata|upstream) ;;
    *) exit 2 ;;
esac
uwz_native=${UWZ_LSQUIC_SOURCE:-/tmp/uwz-lsquic-wt-receive-publication-20261117}
uwz_fixture_source=${UWZ_FIXTURE_SOURCE:-$uwz_native}
uwz_zig=${UWZ_ZIG:-/tmp/zig-x86_64-linux-0.16.0/zig}
uwz_packages=${UWZ_PACKAGE_DIR:-/tmp/uwz-wt-child-callbacks-20261116/zig-pkg}
uwz_cache=${UWZ_CACHE_DIR:-/home/foo/Desktop/Repos/uWebZockets/.zig-cache/wt-native-publication-20261117/native}
export ZIG_GLOBAL_CACHE_DIR=${ZIG_GLOBAL_CACHE_DIR:-/tmp/uwz-uni-global-cache}
cd "$uwz_proof/harness"
ulimit -c 0
if test "$uwz_case" = upstream; then
    exec "$uwz_zig" build test --system "$uwz_packages" --cache-dir "$uwz_cache" \
        "-Dlsquic-source=$uwz_native" -Dupstream-tests=true "-Doptimize=$uwz_mode" -j2 --summary all
fi
exec "$uwz_zig" build test --system "$uwz_packages" --cache-dir "$uwz_cache" \
    "-Dsettings-observer=$([ "$uwz_case" = uwz_webtransport_receive ] && echo true || echo false)" \
    "-Dlsquic-source=$uwz_native" "-Dfixture=$uwz_fixture_source/tests/$uwz_case.c" \
    "-Dfixture-includes=$uwz_native/src/liblsquic" \
    "-Dfixture-support=$uwz_native/tests/uwz_quic_fixture.c" \
    "-Dfixture-name=$uwz_case" "-Doptimize=$uwz_mode" -j2 --summary all
