# Native receive publication snapshot prerequisite

Base: c8cf3fbc201a5d6f6acb6ae45af476cfcd5d7840.

This local proposal exposes native publication in the existing receive snapshot
flags. It adds no struct fields, callback, queue or allocation. Publication is
committed before the receive observer and typed callback; the flag does not mean
the typed callback has completed. Root must ignore abort/destruction snapshots
once the connection generation is no longer live.

The receive fixture checks the bit is clear during native application-context
creation and delayed SETTINGS, set in observer and typed callbacks, and retained
at on_close. NULL application contexts and observer-triggered connection abort
are covered by existing fixture groups. Dedicated smoke/security campaigns are
user-deferred; this is ordinary functional verification only.

Run `sh replay_native.sh Debug`, `sh replay_native.sh ReleaseSafe`, or
`sh replay_native.sh ReleaseFast`. The script accepts explicit compiler/source/
package/cache environment overrides like the retained receive-observer proof.

Candidate: d1104a9fab040af659295a95fb448c971a7bc6de.

All seven recorded GREEN commands are terminal0. Receive8 passes in all three
optimization modes; inherited stream/reset/reset-metadata fixtures and 83
Linux Debug assertion run cases pass. The pre-change runtime RED exits1 at
the observer publication assertion. Independent production review is clear.
See verification.json for exact summaries and raw-log hashes.

For RED replay against the exact base source, retain the new assertion fixture
using UWZ_FIXTURE_SOURCE while setting UWZ_LSQUIC_SOURCE to the base checkout.
The incremental Git bundle requires c8cf3fbc; native_source.tgz is standalone
tracked source. No production pins or maintained-fork branches were changed.

Replay setup after extracting this proof:

```sh
mkdir native
# native_source.tgz contains only tracked source, with no build caches.
tar -xzf native_source.tgz -C native
UWZ_LSQUIC_SOURCE="$PWD/native" \
UWZ_ZIG=/tmp/zig-x86_64-linux-0.16.0/zig \
UWZ_PACKAGE_DIR=/tmp/uwz-wt-child-callbacks-20261116/zig-pkg \
UWZ_CACHE_DIR=/tmp/uwz-publication-replay-cache \
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-publication-global-cache \
sh replay_native.sh Debug
```

Compiler, package and cache directories are caller-supplied replay inputs.
The harness retains immutable package manifests and native Zig source lists.
The committed c8 base source is also retained in the repository artifact
`benchmarks/results/lsquic_receive_observer_v1/2026_11_17/raw_evidence_archive.tgz`.
The API documentation was line-wrapped after the first Debug GREEN; C/header/
fixture bytes stayed unchanged throughout all three optimization-mode runs.
AST output is navigation evidence and does not replace compilation proof.
