# LSQ-WT-PUBLISHED-20261117

Base: c8cf3fbc201a5d6f6acb6ae45af476cfcd5d7840.
Candidate: d1104a9fab040af659295a95fb448c971a7bc6de.

Invariant: a receive snapshot exposes whether Native typed state has been
published before receive-observer delivery, including when application context
is NULL. The bit is not proof that a typed callback has completed; connection
abort/destruction guards still apply at the consumer.

Implementation: append flag128 to the existing flags enum and OR it from
SMDF_WT_NOTIFIED. No struct-layout, wire-format, queue, allocation, timing or
callback-delivery change. Header/API reference and ordinary assertion fixture
are synchronized. No maintained-fork push or production dependency pin change.

Retirement criterion: equivalent maintained/upstream receive publication state
makes this downstream API addition unnecessary.

Evidence: runtime RED against c8cf3fbc, then receive8 GREEN in Debug,
ReleaseSafe and ReleaseFast; inherited native stream/reset/reset-metadata
fixtures pass. All 83 Linux ordinary assertion run cases pass (165/165
steps); the local candidate is committed and clean. Dedicated smoke/security
campaigns remain user-deferred.
