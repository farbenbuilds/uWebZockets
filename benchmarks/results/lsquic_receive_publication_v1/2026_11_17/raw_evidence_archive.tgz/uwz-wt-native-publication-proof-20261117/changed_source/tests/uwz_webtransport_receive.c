/* Copyright (c) 2026 uWebZockets contributors. See LICENSE. */
#define main inherited_streams_main
#include "uwz_webtransport_streams.c"
#undef main

#include <stddef.h>
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_packet_in.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"
#include "lsquic_conn_public.h"
#include "lsquic_mm.h"
#include "lsquic_malo.h"
#include "lsquic_engine_public.h"

enum { published_snapshot_flag = 128 };

struct receive_mark {
    unsigned notifications;
    unsigned typed;
    unsigned reads;
    unsigned resets;
    unsigned closed;
    unsigned last_observer_order;
    unsigned typed_order;
    unsigned reset_order;
    unsigned close_order;
    uint64_t total;
    uint64_t received_end;
    unsigned flags;
};

struct receive_fixture {
    struct streams_fixture base;
    struct lsquic_stream_if callbacks[2];
    struct receive_mark marks[2][STREAMS_MAX_STREAMS];
    unsigned sequence;
    unsigned ingress;
    unsigned hold_reads;
    unsigned null_context;
    unsigned abort_observer;
    unsigned observer_enabled;
    unsigned hold_settings;
    lsquic_stream_t *control;
};

static struct receive_fixture *
receive_owner(struct streams_endpoint *endpoint)
{
    const size_t offset = offsetof(struct receive_fixture, base)
        + (endpoint->se_server ? offsetof(struct streams_fixture, sf_server)
                              : offsetof(struct streams_fixture, sf_client));
    return (void *) ((unsigned char *) endpoint - offset);
}

void
lsquic_wt_settings_test_conn(struct lsquic_conn *conn,
                           struct lsquic_conn_public *conn_pub)
{
    struct streams_endpoint *endpoint = conn_pub->enpub->enp_stream_if_ctx;
    struct receive_fixture *fixture = receive_owner(endpoint);
    struct lsquic_hash_elem *element;
    lsquic_stream_id_t id = 2;
    (void) conn;
    if (!fixture->hold_settings || endpoint->se_server)
        return;
    element = lsquic_hash_find(conn_pub->all_streams, &id, sizeof(id));
    assert(element);
    fixture->control = lsquic_hashelem_getdata(element);
    assert(!fixture->control->tosend_off && !fixture->control->sm_n_buffered);
    assert(lsquic_stream_wantwrite(fixture->control, 0) >= 0);
}

static void
receive_settings(lsquic_conn_t *conn)
{
    struct streams_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);
    struct receive_fixture *fixture = receive_owner(endpoint);
    struct lsquic_webtransport_peer peer;
    if (!fixture->hold_settings || !endpoint->se_server)
    {
        settings_received(conn);
        return;
    }
    assert(!endpoint->se_settings_count);
    assert(LSQUIC_WTP_OK == lsquic_conn_get_webtransport_peer(conn, &peer));
    assert(!(peer.flags & LSQUIC_WTP_WT_ENABLED));
    ++endpoint->se_settings_count;
}

static struct streams_state *
receive_state(lsquic_stream_t *stream)
{
    struct streams_endpoint *endpoint = stream->conn_pub->enpub->enp_stream_if_ctx;
    struct streams_state *state = find_stream(endpoint, lsquic_stream_id(stream));
    assert(state && state->ss_stream == stream);
    return state;
}

static struct receive_mark *
receive_mark(struct streams_state *state)
{
    struct streams_endpoint *endpoint = state->ss_endpoint;
    return &receive_owner(endpoint)->marks[endpoint->se_server]
                                        [state - endpoint->se_streams];
}

static void
observe_receive(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx, uint64_t delta)
{
    struct streams_state *state = receive_state(stream);
    struct receive_fixture *fixture = receive_owner(state->ss_endpoint);
    struct receive_mark *mark = receive_mark(state);
    struct lsquic_stream_recv_state snapshot;
    struct lsquic_webtransport_stream_info info;
    uint64_t body;

    assert(!fixture->ingress && !mark->closed);
    assert(ctx == lsquic_stream_get_ctx(stream));
    assert(LSQUIC_WTS_OK == lsquic_stream_get_webtransport_info(stream, &info));
    assert(info.flags & LSQUIC_WTSF_CHILD);
    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream, &snapshot));
    assert(snapshot.flags & published_snapshot_flag);
    body = snapshot.received_end > info.receive_prefix_size
                                    ? snapshot.received_end - info.receive_prefix_size : 0;
    assert(body >= mark->total && delta == body - mark->total);
    mark->total += delta;
    mark->received_end = snapshot.received_end;
    mark->flags = snapshot.flags;
    mark->last_observer_order = ++fixture->sequence;
    ++mark->notifications;
    if (fixture->abort_observer && state->ss_endpoint->se_server)
    {
        fixture->abort_observer = 0;
        lsquic_conn_abort(state->ss_endpoint->se_conn);
    }
}

static lsquic_stream_ctx_t *
receive_new_stream(void *ctx, lsquic_stream_t *stream)
{
    struct streams_endpoint *endpoint = ctx;
    struct receive_fixture *fixture = receive_owner(endpoint);
    struct lsquic_stream_recv_state snapshot;
    lsquic_stream_ctx_t *state = new_stream(ctx, stream);
    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream, &snapshot));
    assert(!(snapshot.flags & published_snapshot_flag));
    if (fixture->null_context && endpoint->se_server && lsquic_stream_id(stream))
        return NULL;
    return state;
}

static void
receive_typed(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct streams_state *state = receive_state(stream);
    struct receive_fixture *fixture = receive_owner(state->ss_endpoint);
    struct receive_mark *mark = receive_mark(state);
    struct lsquic_stream_recv_state snapshot;
    assert(!fixture->ingress && !mark->typed);
    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream, &snapshot));
    assert(snapshot.flags & published_snapshot_flag);
    if (fixture->observer_enabled)
        assert(mark->notifications && mark->last_observer_order < fixture->sequence + 1);
    mark->typed_order = ++fixture->sequence;
    ++mark->typed;
    webtransport_stream(stream, (void *) state);
    if (fixture->hold_reads)
        assert(lsquic_stream_wantread(stream, 0) >= 0 || errno == EBADF);
    assert(ctx == lsquic_stream_get_ctx(stream));
}

static size_t
receive_probe(void *ctx, const unsigned char *bytes, size_t size, int fin)
{
    (void) ctx;
    (void) bytes;
    (void) size;
    (void) fin;
    return 0;
}

static void
receive_read(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct streams_state *state = receive_state(stream);
    struct receive_fixture *fixture = receive_owner(state->ss_endpoint);
    struct receive_mark *mark = receive_mark(state);
    struct lsquic_stream_recv_state snapshot;
    if (state->ss_id && !mark->typed)
    {
        /* Classification must not interpret an unframed child body as HTTP. */
        (void) lsquic_stream_readf(stream, receive_probe, NULL);
        return;
    }
    if (state->ss_id && mark->typed)
    {
        assert(!fixture->ingress);
        assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream, &snapshot));
        if (fixture->observer_enabled)
            assert(mark->received_end == snapshot.received_end);
        ++mark->reads;
    }
    (void) ctx;
    read_stream(stream, (void *) state);
}

static void
receive_reset(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx, int how)
{
    struct streams_state *state = receive_state(stream);
    struct receive_fixture *fixture = receive_owner(state->ss_endpoint);
    struct receive_mark *mark = receive_mark(state);
    struct lsquic_stream_recv_state snapshot;
    assert(!fixture->ingress && (how == 0 || how == 1));
    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream, &snapshot));
    if (fixture->observer_enabled && mark->typed)
        assert(mark->received_end == snapshot.received_end);
    mark->reset_order = ++fixture->sequence;
    ++mark->resets;
    assert(ctx == lsquic_stream_get_ctx(stream));
}

static void
receive_close(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct streams_state *state = receive_state(stream);
    struct receive_fixture *fixture = receive_owner(state->ss_endpoint);
    struct receive_mark *mark = receive_mark(state);
    struct lsquic_stream_recv_state snapshot;
    assert(!fixture->ingress && !mark->closed);
    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream, &snapshot));
    assert(!!(snapshot.flags & published_snapshot_flag)
           == !!(mark->typed || mark->notifications));
    if (fixture->observer_enabled && mark->typed)
        assert(mark->received_end == snapshot.received_end);
    mark->close_order = ++fixture->sequence;
    ++mark->closed;
    assert(ctx == lsquic_stream_get_ctx(stream));
    close_stream(stream, (void *) state);
}

static void
receive_endpoint_init(struct receive_fixture *fixture, unsigned server)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config = { 0 };
    struct streams_endpoint *endpoint = server ? &fixture->base.sf_server
                                              : &fixture->base.sf_client;
    struct lsquic_test_endpoint *transport = server ? &fixture->base.sf_transport.ltp_server
                                                  : &fixture->base.sf_transport.ltp_client;
    struct lsquic_test_endpoint *peer = server ? &fixture->base.sf_transport.ltp_client
                                             : &fixture->base.sf_transport.ltp_server;
    unsigned flags = LSENG_HTTP | (server ? LSENG_SERVER : 0);
    endpoint->se_server = server;
    fixture->callbacks[server] = streams_callbacks;
    fixture->callbacks[server].on_new_stream = receive_new_stream;
    fixture->callbacks[server].on_h3_settings = receive_settings;
    fixture->callbacks[server].on_webtransport_stream = receive_typed;
    fixture->callbacks[server].on_read = receive_read;
    fixture->callbacks[server].on_reset = receive_reset;
    fixture->callbacks[server].on_close = receive_close;
    fixture->callbacks[server].on_webtransport_receive = fixture->observer_enabled ? observe_receive : NULL;
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = 8;
    settings.es_init_max_streams_bidi = fixture->hold_settings ? 2 : 8;
    settings.es_max_streams_in = 0;
    settings.es_init_max_stream_data_bidi_local = 65536;
    settings.es_init_max_stream_data_bidi_remote = 65536;
    settings.es_init_max_stream_data_uni = 65536;
    settings.es_qpack_dec_max_size = 0;
    settings.es_qpack_dec_max_blocked = 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    settings.es_datagrams = 1;
    settings.es_reset_stream_at = 1;
    settings.es_webtransport.enabled = 1;
    settings.es_webtransport.initial_max_data = 65536;
    settings.es_webtransport.initial_max_streams_bidi = 16;
    settings.es_webtransport.initial_max_streams_uni = 16;
    assert(0 == lsquic_engine_check_settings(&settings, flags, NULL, 0));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &fixture->callbacks[server];
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_hsi_if = &streams_hsi;
    config.ltec_hsi_ctx = &endpoint->se_headers;
    config.ltec_alpn = "h3";
    config.ltec_tls = lsquic_test_tls_context_new(server, "h3");
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(transport, peer, &config, server ? 14101 : 14102));
    SSL_CTX_free(config.ltec_tls);
}

static void
receive_start(struct receive_fixture *fixture, unsigned hold, unsigned null_context,
              unsigned enabled, unsigned pending_settings)
{
    unsigned step;
    memset(fixture, 0, sizeof(*fixture));
    fixture->hold_reads = hold;
    fixture->null_context = null_context;
    fixture->observer_enabled = enabled;
    fixture->hold_settings = pending_settings;
    receive_endpoint_init(fixture, 0);
    receive_endpoint_init(fixture, 1);
    assert(lsquic_engine_connect(fixture->base.sf_transport.ltp_client.lte_engine,
        LSQVER_I001,
        (struct sockaddr *) &fixture->base.sf_transport.ltp_client.lte_address,
        (struct sockaddr *) &fixture->base.sf_transport.ltp_server.lte_address,
        &fixture->base.sf_transport.ltp_client, NULL, "localhost", 0, NULL, 0, NULL, 0));
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        if (fixture->base.sf_client.se_handshake_ok && fixture->base.sf_server.se_handshake_ok
            && fixture->base.sf_client.se_settings_count
            && (pending_settings || fixture->base.sf_server.se_settings_count))
            break;
        pump_step(&fixture->base);
    }
    assert(step < STREAMS_MAX_STEPS);
    for (step = 0; step < 20; ++step)
        pump_step(&fixture->base);
    if (!pending_settings)
        establish_parent(&fixture->base);
}

static void
receive_destroy(struct receive_fixture *fixture)
{
    lsquic_test_endpoint_destroy(&fixture->base.sf_transport.ltp_server);
    lsquic_test_endpoint_destroy(&fixture->base.sf_transport.ltp_client);
    assert(fixture->base.sf_client.se_headers.shp_created == fixture->base.sf_client.se_headers.shp_discarded);
    assert(fixture->base.sf_server.se_headers.shp_created == fixture->base.sf_server.se_headers.shp_discarded);
}

static void
receive_service(struct receive_fixture *fixture)
{
    lsquic_test_pair_process(&fixture->base.sf_transport, 1000);
}

static struct streams_state *
receive_child(struct receive_fixture *fixture, unsigned uni)
{
    struct streams_state *outgoing, *incoming = NULL;
    unsigned before = fixture->base.sf_client.se_stream_count, step;
    assert(LSQUIC_MWTS_OK == lsquic_conn_make_webtransport_stream(
        fixture->base.sf_client.se_conn, 0, uni ? LSQUIC_WTS_UNI : LSQUIC_WTS_BIDI));
    assert(fixture->base.sf_client.se_stream_count == before + 1);
    outgoing = &fixture->base.sf_client.se_streams[before];
    assert(0 == lsquic_stream_flush(outgoing->ss_stream));
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        incoming = find_stream(&fixture->base.sf_server, outgoing->ss_id);
        if (incoming && receive_mark(incoming)->typed)
            break;
        pump_step(&fixture->base);
    }
    assert(step < STREAMS_MAX_STEPS);
    return incoming;
}

static void
receive_inject(struct receive_fixture *fixture, struct streams_state *state,
               uint64_t offset, unsigned size, int fin)
{
    struct lsquic_mm *mm = state->ss_stream->conn_pub->mm;
    struct lsquic_packet_in *packet = lsquic_mm_get_packet_in(mm);
    struct stream_frame *frame = lsquic_malo_get(mm->malo.stream_frame);
    assert(packet && frame && size <= 128);
    packet->pi_data = lsquic_mm_get_packet_in_buf(mm, 128);
    assert(packet->pi_data);
    packet->pi_flags |= PI_OWN_DATA;
    memset(packet->pi_data, 'd', size);
    packet->pi_data_sz = size;
    packet->pi_refcnt = 1;
    memset(frame, 0, sizeof(*frame));
    frame->packet_in = packet;
    frame->data_frame.df_data = packet->pi_data;
    frame->data_frame.df_offset = offset;
    frame->data_frame.df_size = size;
    frame->data_frame.df_fin = fin;
    fixture->ingress = 1;
    assert(0 == lsquic_stream_frame_in(state->ss_stream, frame));
    fixture->ingress = 0;
}

static void
test_receive_high_water(void)
{
    struct receive_fixture fixture;
    struct streams_state *state;
    struct receive_mark *mark;
    struct lsquic_stream_recv_state snapshot;
    unsigned before, index;
    receive_start(&fixture, 1, 0, 1, 0);
    state = receive_child(&fixture, 0);
    mark = receive_mark(state);
    assert(mark->notifications == 1 && mark->total == 0 && mark->received_end == 3);
    before = mark->notifications;
    receive_inject(&fixture, state, 30, 5, 0);
    receive_inject(&fixture, state, 60, 5, 0);
    assert(mark->notifications == before);
    for (index = 0; index < 10; ++index)
    {
        assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(state->ss_stream, &snapshot));
        assert(snapshot.received_end == 65 && !(snapshot.flags & LSQUIC_SRS_FINAL_SIZE_KNOWN));
    }
    assert(mark->notifications == before);
    receive_service(&fixture);
    assert(mark->notifications == before + 1 && mark->total == 62);
    before = mark->notifications;
    receive_inject(&fixture, state, 60, 5, 0);
    receive_service(&fixture);
    assert(mark->notifications == before);
    fixture.ingress = 1;
    assert(0 == lsquic_stream_shutdown(state->ss_stream, 0));
    fixture.ingress = 0;
    assert(mark->notifications == before);
    receive_service(&fixture);
    assert(mark->notifications == before + 1 && mark->total == 62);
    assert(mark->flags & LSQUIC_SRS_READ_CANCELED);
    receive_inject(&fixture, state, 90, 5, 0);
    receive_service(&fixture);
    assert(mark->total == 92 && mark->received_end == 95 && !mark->reads);
    before = mark->notifications;
    receive_inject(&fixture, state, 95, 0, 1);
    receive_service(&fixture);
    assert(mark->notifications == before + 1 && mark->total == 92);
    assert(mark->flags & LSQUIC_SRS_FIN_RECEIVED);
    before = mark->notifications;
    receive_inject(&fixture, state, 95, 0, 1);
    receive_service(&fixture);
    assert(mark->notifications == before);
    receive_destroy(&fixture);
    assert(mark->closed && mark->last_observer_order < mark->close_order);
    puts("PASS receive high-water: OOO/coalescing/getter purity/duplicates/canceled reads/late FIN");
}

static void
test_receive_reset_gap(void)
{
    struct receive_fixture fixture;
    struct streams_state *state;
    struct receive_mark *mark;
    struct lsquic_stream_recv_state snapshot;
    unsigned before;
    receive_start(&fixture, 1, 0, 1, 0);
    state = receive_child(&fixture, 0);
    mark = receive_mark(state);
    before = mark->notifications;
    fixture.ingress = 1;
    assert(0 == lsquic_stream_reset_at_in(state->ss_stream, 99, UINT64_C(0x123456789), 70, 1));
    fixture.ingress = 0;
    assert(mark->notifications == before);
    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(state->ss_stream, &snapshot));
    assert(snapshot.received_end == 99 && snapshot.final_size == 99);
    assert(!(snapshot.flags & LSQUIC_SRS_RESET_VISIBLE));
    receive_service(&fixture);
    assert(mark->notifications == before + 1 && mark->total == 96 && !mark->resets);
    before = mark->notifications;
    fixture.ingress = 1;
    assert(0 == lsquic_stream_reset_at_in(state->ss_stream, 99, UINT64_C(0x123456789), 70, 1));
    fixture.ingress = 0;
    receive_service(&fixture);
    assert(mark->notifications == before);
    fixture.ingress = 1;
    assert(0 == lsquic_stream_shutdown(state->ss_stream, 0));
    fixture.ingress = 0;
    receive_service(&fixture);
    assert(mark->total == 96 && mark->resets == 1);
    assert(mark->flags & LSQUIC_SRS_RESET_VISIBLE);
    assert(mark->last_observer_order < mark->reset_order);
    receive_destroy(&fixture);
    puts("PASS receive reset: hidden final gap/cursor dedup/cancel visibility before reset callback");
}

static void
test_receive_null_and_destroy(void)
{
    struct receive_fixture fixture;
    struct streams_state *state;
    struct receive_mark *mark;
    receive_start(&fixture, 1, 1, 1, 0);
    state = receive_child(&fixture, 1);
    mark = receive_mark(state);
    assert(!lsquic_stream_get_ctx(state->ss_stream) && mark->notifications == 1);
    receive_inject(&fixture, state, 30, 5, 0);
    assert(mark->total == 0);
    receive_destroy(&fixture);
    assert(mark->total == 32 && mark->closed);
    assert(mark->last_observer_order < mark->close_order);
    puts("PASS receive NULL context: prefix exclusion/delta retained before direct engine destruction");
}

static void
test_receive_wire_order(void)
{
    struct receive_fixture fixture;
    struct streams_state *outgoing, *incoming = NULL;
    struct streams_held_packets held = { 0 };
    struct receive_mark *mark;
    unsigned before, step;
    receive_start(&fixture, 0, 0, 1, 0);
    before = fixture.base.sf_client.se_stream_count;
    assert(LSQUIC_MWTS_OK == lsquic_conn_make_webtransport_stream(
        fixture.base.sf_client.se_conn, 0, LSQUIC_WTS_BIDI));
    outgoing = &fixture.base.sf_client.se_streams[before];
    assert(0 == lsquic_stream_flush(outgoing->ss_stream));
    receive_service(&fixture);
    hold_packets(&fixture.base.sf_transport.ltp_server, &held);
    assert(held.shp_count);
    assert(sizeof(child_payload) == (size_t) lsquic_stream_write(outgoing->ss_stream,
                                                              child_payload, sizeof(child_payload)));
    assert(0 == lsquic_stream_flush(outgoing->ss_stream));
    receive_service(&fixture);
    lsquic_test_deliver_all(&fixture.base.sf_transport.ltp_server);
    incoming = find_stream(&fixture.base.sf_server, outgoing->ss_id);
    assert(incoming && !receive_mark(incoming)->typed);
    mark = receive_mark(incoming);
    assert(mark->notifications == 0);
    release_packets(&fixture.base.sf_transport.ltp_server, &held);
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        if (mark->typed && incoming->ss_received == sizeof(child_payload))
            break;
        pump_step(&fixture.base);
    }
    if (step == STREAMS_MAX_STEPS)
        fprintf(stderr, "wire wait: observed=%llu end=%llu typed=%u reads=%u received=%zu read_offset=%llu qflags=%x flags=%x readable=%d\n",
            (unsigned long long) mark->total, (unsigned long long) mark->received_end,
            mark->typed, mark->reads, incoming->ss_received,
            (unsigned long long) incoming->ss_stream->read_offset,
            incoming->ss_stream->sm_qflags, incoming->ss_stream->stream_flags,
            lsquic_stream_readable(incoming->ss_stream));
    assert(step < STREAMS_MAX_STEPS && mark->total == sizeof(child_payload));
    assert(mark->last_observer_order < mark->typed_order && incoming->ss_received == sizeof(child_payload));
    receive_destroy(&fixture);
    puts("PASS receive real TLS ordering: encrypted payload before held prefix/debit before typed and data");
}

static void
test_receive_stop_order(void)
{
    struct receive_fixture fixture;
    struct streams_state *state;
    struct receive_mark *mark;
    unsigned before;
    receive_start(&fixture, 1, 0, 1, 0);
    state = receive_child(&fixture, 0);
    mark = receive_mark(state);
    before = mark->notifications;
    receive_inject(&fixture, state, 3, 4, 0);
    fixture.ingress = 1;
    lsquic_stream_stop_sending_in(state->ss_stream, UINT64_C(0x100000000));
    fixture.ingress = 0;
    assert(mark->notifications == before && !mark->resets);
    receive_service(&fixture);
    assert(mark->total == 4 && mark->resets == 1);
    assert(mark->last_observer_order < mark->reset_order);
    receive_destroy(&fixture);
    puts("PASS receive STOP ordering: ingress stages/debit before late STOP callback");
}

static void
test_receive_rejected_settings(unsigned early_stop)
{
    static const unsigned char empty_settings[] = { 0, 4, 0 };
    struct receive_fixture fixture;
    struct streams_state *outgoing, *incoming = NULL;
    struct lsquic_conn_public *conn_pub;
    struct receive_mark *mark;
    lsquic_stream_id_t id;
    unsigned before, step;
    int result;

    receive_start(&fixture, 1, 0, 1, 1);
    assert(fixture.control && !fixture.base.sf_server.se_settings_count);
    /* Reserve session-shaped stream 0; this native lifecycle test has no App. */
    lsquic_conn_make_stream(fixture.base.sf_client.se_conn);
    assert(LSQUIC_MWTS_OK == lsquic_stream_accept_webtransport(
        fixture.base.sf_client.se_streams[0].ss_stream));
    before = fixture.base.sf_client.se_stream_count;
    assert(LSQUIC_MWTS_OK == lsquic_conn_make_webtransport_stream(
        fixture.base.sf_client.se_conn, 0, LSQUIC_WTS_BIDI));
    outgoing = &fixture.base.sf_client.se_streams[before];
    id = outgoing->ss_id;
    assert(id == 4 && 0 == lsquic_stream_flush(outgoing->ss_stream));
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        incoming = find_stream(&fixture.base.sf_server, id);
        if (incoming && (incoming->ss_stream->sm_qflags & SMQF_WT_WAIT))
            break;
        pump_step(&fixture.base);
    }
    assert(step < STREAMS_MAX_STEPS && !fixture.base.sf_server.se_settings_count);
    mark = receive_mark(incoming);
    assert(!mark->typed && !mark->notifications);
    {
        struct lsquic_stream_recv_state snapshot;
        assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(incoming->ss_stream, &snapshot));
        assert(!(snapshot.flags & published_snapshot_flag));
    }
    conn_pub = incoming->ss_stream->conn_pub;
    assert(LSQUIC_MWTS_BLOCKED == lsquic_conn_make_webtransport_stream(
        fixture.base.sf_client.se_conn, 0, LSQUIC_WTS_BIDI));
    if (early_stop)
    {
        assert(0 == lsquic_stream_shutdown(outgoing->ss_stream, 0));
        for (step = 0; step < STREAMS_MAX_STEPS; ++step)
        {
            pump_step(&fixture.base);
            if (incoming->ss_stream->sm_dflags & SMDF_WT_STOP_PENDING)
                break;
        }
        assert(step < STREAMS_MAX_STEPS && !mark->typed && !mark->resets);
    }
    assert(0 == lsquic_stream_close(incoming->ss_stream));
    assert(sizeof(empty_settings) == (size_t) lsquic_stream_write(fixture.control,
                                        empty_settings, sizeof(empty_settings)));
    assert(0 == lsquic_stream_flush(fixture.control));
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        pump_step(&fixture.base);
        if (mark->closed && !lsquic_hash_find(conn_pub->all_streams, &id, sizeof(id)))
            break;
    }
    assert(fixture.base.sf_server.se_settings_count == 1);
    assert(mark->closed == 1);
    assert(step < STREAMS_MAX_STEPS);
    assert(!mark->typed && !mark->notifications && mark->closed == 1);
    assert(lsquic_conn_status(fixture.base.sf_server.se_conn, NULL, 0) == LSCONN_ST_CONNECTED);
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        result = lsquic_conn_make_webtransport_stream(
            fixture.base.sf_client.se_conn, 0, LSQUIC_WTS_BIDI);
        if (result == LSQUIC_MWTS_OK)
            break;
        assert(result == LSQUIC_MWTS_BLOCKED);
        pump_step(&fixture.base);
    }
    assert(step < STREAMS_MAX_STEPS);
    receive_destroy(&fixture);
    printf("PASS receive rejected SETTINGS: earlySTOP%u/pending association/cancel/no observer ownership/live free/credit recovery\n", early_stop);
}

static void
test_receive_abort_guard(void)
{
    struct receive_fixture fixture;
    struct streams_state *state;
    struct receive_mark *mark;
    receive_start(&fixture, 1, 0, 1, 0);
    fixture.abort_observer = 1;
    assert(LSQUIC_MWTS_OK == lsquic_conn_make_webtransport_stream(
        fixture.base.sf_client.se_conn, 0, LSQUIC_WTS_BIDI));
    state = &fixture.base.sf_client.se_streams[fixture.base.sf_client.se_stream_count - 1];
    assert(0 == lsquic_stream_flush(state->ss_stream));
    for (unsigned step = 0; step < 50; ++step)
        pump_step(&fixture.base);
    state = find_stream(&fixture.base.sf_server, state->ss_id);
    assert(state);
    mark = receive_mark(state);
    assert(mark->notifications && !mark->typed && !mark->reads);
    receive_destroy(&fixture);
    puts("PASS receive callback abort: no typed/read callback after observer closes connection");
}

int
main(void)
{
    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    test_receive_high_water();
    test_receive_reset_gap();
    test_receive_null_and_destroy();
    test_receive_wire_order();
    test_receive_stop_order();
    test_receive_rejected_settings(0);
    test_receive_rejected_settings(1);
    test_receive_abort_guard();
    lsquic_global_cleanup();
    return 0;
}
