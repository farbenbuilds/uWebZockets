# Graph Report - uwz-lsquic-wt-receive-publication-20261117  (2026-11-17)

## Corpus Check
- 322 files · ~676,500 words
- Verdict: corpus is large enough that graph structure adds value.
- Unclassified: 16 file(s) not represented in the graph (top: (none) 5, .pl 3, .in 2)

## Summary
- 4519 nodes · 16477 edges · 164 communities (148 shown, 16 thin omitted)
- Extraction: 75% EXTRACTED · 25% INFERRED · 0% AMBIGUOUS · INFERRED: 4119 edges (avg confidence: 0.85)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `c8cf3fbc`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- lsquic_full_conn_ietf.c
- lsquic_stream.c
- lsquic_stream_shutdown
- string
- lsquic_send_ctl.c
- stdlib
- test_stream.c
- lsquic_full_conn.c
- lsquic_hash.h
- test_h3_framing.c
- queue.h
- lsquic_engine.c
- lsquic_bbr.c
- lsquic_packet_out_avail
- uwz_webtransport_receive.c
- lsquic_conn_get_ctx
- full_conn_ci_tick
- lsquic_handshake.c
- lsquic_hashelem_getdata
- ls-sfparser.c
- lsquic_parse_ietf_v1.c
- test_qenc_hdl.c
- lsquic_malo_put
- lsquic_frame_reader.c
- lsquic_di_hash.c
- lsquic_parse_gquic_be.c
- uwz_webtransport_streams.c
- uwz_webtransport_frame_errors.c
- lsquic_pofi_first
- lsquic_mm_get_packet_in
- lsquic_global_init
- lsquic_xxhash.c
- lsquic_adaptive_cc.c
- uwz_uni_stream.c
- prog_prep
- lsquic_crypto.c
- lsquic_enc_sess_ietf.c
- lsquic_ev_log.c
- lsquic_mini_conn_ietf.c
- init_test_objs
- uwz_reset_ack.c
- prog_stop
- lsquic_mm_init
- lsquic_engine_init_settings
- uwz_webtransport_settings_delivery.c
- uwz_webtransport_stream_resets.c
- vint_val2bits
- lsquic_mini_conn.c
- lsquic_frame_writer.c
- uwz_webtransport_peer.c
- lsquic_attq.c
- lsquic_hash_insert
- lsquic_rapidhash.h
- lsquic_spi_first
- lsquic_time_now
- lsxpack_header_get_name
- lsquic_str_len
- lsquic_packet_out.h
- lsquic_frab_list.h
- lsquic_pr_queue.c
- new_conn_common
- lsquic_rechist.c
- lsquic_stream_id_t
- test_trechist.c
- iquic_packno_bits2len
- uwz_reset_metadata.c
- lsquic_str.h
- uwz_reset_http.c
- lsquic_str_cstr
- iquic_esf_decrypt_packet
- lsquic_hpi.c
- init_test
- lsquic_http1x_if.c
- ietf_v1_gen_ack_frame
- lsquic_set.c
- lsquic_str_delete
- lsquic_packet_in_t
- uwz_webtransport_settings_state.c
- allocate_packet_out
- test_lost_prefix_reset_first
- test_ack_merge.c
- init_test
- lsquic_mm_get_4k
- lsquic_stream_ctx_t
- lsquic_stream_maybe_reset
- lsquic_arr.h
- iquic_esfi_create_client
- lsquic_stream_accept_webtransport
- lsquic_mm_get_packet_in_buf
- lsquic_log_to_fstream
- ietf_mini_conn_ci_packet_in
- lsquic_time_t
- lsquic_tp_decode
- lsquic_test_deliver_all
- http_server_on_new_conn
- lsquic_iquic_gen_retry_pkt
- lsquic_frab_list_empty
- test_rechist.c
- test_http1x_if.c
- test_ackparse_gquic_le.c
- lsxpack_header.h
- lsquic_frame_reader_new
- lsquic_engine_add_conn_to_tickable
- lsquic_qdec_hdl.c
- duck_client_on_conn_closed
- IMICO_PROC_FRAME_ARGS
- lsquic_packet_in_t
- lsquic_gen_ver_tags
- main
- run_test
- test_frozen_connection_credit
- test_raw_directional_credit
- lsquic_alarmset_unset
- lsquic_time_t
- LSQUIC Contributor Guidance
- SSL
- gen_long_pkt_header
- insert_cert
- mini_conn_ci_destroy
- lsquic_cid2str
- reconstruct_packet_number
- main
- uwz_reset_codec.c
- test_wire
- lsquic_eng_hist.h
- test_goaway_gquic_le.c
- lsquic_stream_ctx_t
- prog_process_conns
- try_to_begin_migration
- pool_stats
- create_client
- test_streamgen.c
- uwz_webtransport_config.c
- keylog_open_file
- ietf_mini_conn_ci_next_packet_to_send
- lsquic_stream_ctx_t
- lsquic_stream_ctx_t
- common_cert_set_2.c
- common_cert_set_3.c
- lsquic_prq_new_req_ext
- lsquic_qenc_hdl.h
- highest_bit_set
- lsquic_conn_id
- lsquic_stream_ctx_t
- qm_trace
- create_streams
- drop_SSL
- lsquic_ev_log_packet_in
- lsquic_mini_conn_new
- on_close
- test_quic_le_floats.c
- test_wuf_gquic_le.c
- perf_server_on_close
- if
- run_endpoint.sh
- lsquic_conn_id
- lsquic_data_in_nocopy_new
- gquic_Q046_gen_crypto_frame
- lsquic_stream_conn

## God Nodes (most connected - your core abstractions)
1. `lsquic_stream_destroy()` - 101 edges
2. `lsquic_stream_write()` - 92 edges
3. `lsquic_stream_flush()` - 90 edges
4. `lsquic_stream_shutdown()` - 80 edges
5. `lsquic_stream_wantwrite()` - 77 edges
6. `lsquic_stream_wantread()` - 75 edges
7. `lsquic_conn_get_ctx()` - 71 edges
8. `lsquic_packet_out_avail()` - 68 edges
9. `lsquic_time_now()` - 67 edges
10. `lsquic_stream_read()` - 49 edges

## Surprising Connections (you probably didn't know these)
- `duck_client_on_conn_closed()` --calls--> `lsquic_conn_get_ctx()`  [INFERRED]
  bin/duck_client.c → src/liblsquic/lsquic_conn.c
- `duck_client_on_conn_closed()` --calls--> `lsquic_conn_set_ctx()`  [INFERRED]
  bin/duck_client.c → src/liblsquic/lsquic_conn.c
- `duck_server_on_conn_closed()` --calls--> `lsquic_conn_set_ctx()`  [INFERRED]
  bin/duck_server.c → src/liblsquic/lsquic_conn.c
- `duck_on_dg_write()` --calls--> `lsquic_conn_close()`  [INFERRED]
  bin/duck_server.c → src/liblsquic/lsquic_conn.c
- `duck_on_datagram()` --calls--> `lsquic_conn_abort()`  [INFERRED]
  bin/duck_server.c → src/liblsquic/lsquic_conn.c

## Import Cycles
- None detected.

## Communities (164 total, 16 thin omitted)

### Community 0 - "lsquic_full_conn_ietf.c"
Cohesion: 0.02
Nodes (163): lsquic_alarmset_set(), lsquic_crand_get_nybble(), lsquic_engine_retire_cid(), lsquic_frab_list_init(), abort_push_stream(), ack_alarm_expired(), ack_rechist_first(), ack_rechist_next() (+155 more)

### Community 1 - "lsquic_stream.c"
Cohesion: 0.03
Nodes (173): lsquic_cfcw_incr_max_recv_off(), lsquic_cfcw_incr_read_off(), lsquic_data_in_error_new(), can_publish_h3_settings(), process_crypto_frame_client(), process_streams_read_events(), publish_h3_settings(), service_streams() (+165 more)

### Community 2 - "lsquic_stream_shutdown"
Cohesion: 0.03
Nodes (139): duck_client_on_datagram(), echo_client_on_close(), echo_client_on_new_stream(), echo_client_on_read(), echo_client_on_write(), read_stdin(), echo_server_on_new_stream(), echo_server_on_read() (+131 more)

### Community 3 - "string"
Cohesion: 0.04
Nodes (48): lsquic_is_valid_iquic_hs_packet(), lsquic_Q046_parse_packet_in_short_begin(), lsquic_get_alt_svc_versions(), compare_ackis(), main(), run_test(), test_ack_block_count_expansion_regression(), alarm_cb() (+40 more)

### Community 4 - "lsquic_send_ctl.c"
Cohesion: 0.04
Nodes (112): lsquic_alarmset_is_set(), full_conn_ci_record_addrs(), ietf_full_conn_ci_early_data_failed(), ietf_full_conn_ci_packet_too_large(), mtu_probe_too_large(), process_retry_packet(), lsquic_pacer_cleanup(), lsquic_pacer_loss_event() (+104 more)

### Community 5 - "stdlib"
Cohesion: 0.04
Nodes (36): ends_in_pem(), file2cert(), init_x509_cert_store(), verify_server_cert(), buffer_read(), buffer_size(), header_read(), header_size() (+28 more)

### Community 6 - "test_stream.c"
Cohesion: 0.09
Nodes (89): lsquic_conn_cap_avail(), lsquic_send_ctl_n_scheduled(), lsquic_send_ctl_next_packet_to_send(), lsquic_send_ctl_sent_packet(), lsquic_stream_destroy(), lsquic_stream_flush(), lsquic_stream_frame_in(), lsquic_stream_priority() (+81 more)

### Community 7 - "lsquic_full_conn.c"
Cohesion: 0.04
Nodes (80): lsquic_generate_cid_gquic(), lsquic_sess_resume_version(), ack_alarm_expired(), apply_peer_settings(), conn_decrypt_packet(), conn_is_stateless_reset(), conn_is_stream_closed(), conn_mark_stream_closed() (+72 more)

### Community 8 - "lsquic_hash.h"
Cohesion: 0.08
Nodes (21): lsquic_cfcw_get_max_recv_window(), lsquic_logger_log0(), frec_arr_pofi_first(), frec_arr_pofi_next(), sfcw_maybe_increase_max_window(), lsquic_varint_read(), lsquic_engine_add_conn_to_tickable(), lsquic_engine_add_conn_to_tickable() (+13 more)

### Community 9 - "test_h3_framing.c"
Cohesion: 0.07
Nodes (67): lsquic_send_ctl_set_max_bpq_count(), lsquic_stream_get_hset(), lsquic_stream_readable(), lsquic_stream_send_headers(), lsquic_stream_set_pwritev_params(), lsquic_stream_verify_len(), stream_is_read_reset(), assert_header_stream_reset() (+59 more)

### Community 10 - "queue.h"
Cohesion: 0.05
Nodes (25): ack_info, lsquic_engine_public, lsquic_mm, lsquic_packet_in, lsquic_packet_out, malo, mini_conn, lsquic_calc_stream_frame_header_sz_gquic() (+17 more)

### Community 11 - "lsquic_engine.c"
Cohesion: 0.07
Nodes (69): send_unsent(), lsquic_conn_get_peer_ctx(), lsquic_conn_log_cid(), add_conn_to_hash(), apply_hp(), cce_iter_first(), cce_iter_next(), check_deadline() (+61 more)

### Community 12 - "lsquic_bbr.c"
Cohesion: 0.08
Nodes (61): bbr_app_limited(), calculate_cwnd(), calculate_pacing_rate(), calculate_recovery_window(), check_if_full_bw_reached(), enter_probe_bw_mode(), enter_startup_mode(), get_min_rtt() (+53 more)

### Community 13 - "lsquic_packet_out_avail"
Cohesion: 0.08
Nodes (69): lsquic_cfcw_get_fc_recv_off(), full_conn_ci_write_ack(), generate_ack_frame(), generate_blocked_frame(), generate_connection_close_packet(), generate_goaway_frame(), generate_ping_frame(), generate_rst_stream_frame() (+61 more)

### Community 14 - "uwz_webtransport_receive.c"
Cohesion: 0.10
Nodes (57): lsquic_conn_make_webtransport_stream(), lsquic_stream_get_ctx(), lsquic_stream_get_recv_state(), assert_rejected(), close_stream(), new_stream(), reset_stream(), snapshot_send() (+49 more)

### Community 15 - "lsquic_conn_get_ctx"
Cohesion: 0.05
Nodes (45): echo_client_on_conn_closed(), display_cert_chain(), hsk_status_ok(), http_client_on_conn_closed(), http_client_on_conncloseframe_received(), http_client_on_hsk_done(), http_client_on_sess_resume_info(), qif_client_on_conn_closed() (+37 more)

### Community 16 - "full_conn_ci_tick"
Cohesion: 0.05
Nodes (57): lsquic_alarmset_mintime(), lsquic_alarmset_ring_expired(), conn_ok_to_close(), full_conn_ci_ack_snapshot(), full_conn_ci_can_write_ack(), full_conn_ci_is_tickable(), full_conn_ci_next_tick_time(), full_conn_ci_tick() (+49 more)

### Community 17 - "lsquic_handshake.c"
Cohesion: 0.07
Nodes (47): lsquic_serialize_fnv128_short(), combine_path_id_pack_num(), decode_packno(), decrypt_packet(), determine_diversification_key(), get_hs_state(), gquic2_apply_hp(), gquic2_esf_decrypt_packet() (+39 more)

### Community 18 - "lsquic_hashelem_getdata"
Cohesion: 0.08
Nodes (51): delete_certs(), lookup_cert(), check_tickable_conns_again(), drop_all_mini_conns(), find_conn_by_srst(), lsquic_engine_cooldown(), calc_mem_used(), collect_stream_counts() (+43 more)

### Community 19 - "ls-sfparser.c"
Cohesion: 0.11
Nodes (43): if(), input(), ls_sf_parse(), ls_sfp_alloc(), ls_sfp__create_buffer(), ls_sfp__delete_buffer(), ls_sfp_ensure_buffer_stack(), ls_sfp__flush_buffer() (+35 more)

### Community 20 - "lsquic_parse_ietf_v1.c"
Cohesion: 0.06
Nodes (36): ietf_v1_ack_frequency_frame_size(), ietf_v1_blocked_frame_size(), ietf_v1_datagram_frame_size(), ietf_v1_frame_with_varints_size(), ietf_v1_gen_ack_frequency_frame(), ietf_v1_gen_blocked_frame(), ietf_v1_gen_frame_with_varints(), ietf_v1_gen_max_data_frame() (+28 more)

### Community 21 - "test_qenc_hdl.c"
Cohesion: 0.07
Nodes (43): lsquic_frab_list_cleanup(), lsquic_frab_list_size(), hcso_on_close(), hcso_on_read(), one_byte_limit_size(), lsquic_qdh_cleanup(), lsquic_qdh_header_in_begin(), qdh_log_and_clean_exp_rec() (+35 more)

### Community 22 - "lsquic_malo_put"
Cohesion: 0.12
Nodes (42): bw_sampler_abort_conn(), lsquic_bw_sampler_app_limited(), lsquic_bw_sampler_cleanup(), lsquic_bw_sampler_entry_count(), lsquic_bw_sampler_packet_acked(), lsquic_bw_sampler_packet_lost(), lsquic_bw_sampler_packet_sent(), nocopy_di_destroy() (+34 more)

### Community 23 - "lsquic_frame_reader.c"
Cohesion: 0.07
Nodes (26): lsquic_http_setting_id2str(), decode_and_pass_payload(), find_target_stream(), fr_get_stream_id(), read_contin(), read_headers(), read_headers_block_fragment(), read_headers_block_fragment_and_padding() (+18 more)

### Community 24 - "lsquic_di_hash.c"
Cohesion: 0.06
Nodes (24): block_write(), ctz(), has_bytes_after(), hash_di_frame_done(), hash_di_get_frame(), hash_di_insert_frame(), hash_di_readable_bytes(), hash_find() (+16 more)

### Community 25 - "lsquic_parse_gquic_be.c"
Cohesion: 0.07
Nodes (24): gquic_packno_bits2len(), lsquic_gquic_be_gen_blocked_frame(), lsquic_gquic_be_gen_crypto_frame(), lsquic_gquic_be_gen_goaway_frame(), lsquic_gquic_be_gen_reg_pkt_header(), lsquic_gquic_be_gen_rst_frame(), lsquic_gquic_be_gen_stop_waiting_frame(), lsquic_gquic_be_gen_stream_frame() (+16 more)

### Community 26 - "uwz_webtransport_streams.c"
Cohesion: 0.13
Nodes (35): header_set_ptr(), lsxpack_header_set_offset2(), lsquic_conn_going_away(), lsquic_logger_init(), assert_child_info(), assert_parent(), claim_headers(), close_stream() (+27 more)

### Community 27 - "uwz_webtransport_frame_errors.c"
Cohesion: 0.14
Nodes (32): echo_client_on_new_conn(), perf_client_on_new_conn(), perf_create_streams(), lsquic_conn_make_stream(), lsquic_conn_status(), lsquic_stream_get_webtransport_info(), assert_going_away_live(), close_stream() (+24 more)

### Community 28 - "lsquic_pofi_first"
Cohesion: 0.10
Nodes (36): lsquic_packet_out_ack_reset_frames(), lsquic_packet_out_ack_streams(), lsquic_packet_out_chop_regen(), lsquic_packet_out_destroy(), lsquic_packet_out_elide_reset_stream_frames(), lsquic_packet_out_pad_over(), lsquic_packet_out_turn_on_fin(), lsquic_packet_out_zero_pad() (+28 more)

### Community 29 - "lsquic_mm_get_packet_in"
Cohesion: 0.08
Nodes (32): process_ver_neg_packet(), lsquic_mm_get_packet_in(), lsquic_mm_put_packet_in(), lsquic_packet_in_nonce(), lsquic_packet_in_ver_first(), lsquic_packet_in_ver_next(), lsquic_cid_from_packet(), lsquic_ietf_v1_parse_packet_in_begin() (+24 more)

### Community 30 - "lsquic_global_init"
Cohesion: 0.10
Nodes (36): load_cert(), hash_conns_by_addr(), lsquic_engine_destroy(), lsquic_engine_new(), lsquic_engine_quic_versions(), full_conn_ci_destroy(), lsquic_global_cleanup(), lsquic_global_init() (+28 more)

### Community 31 - "lsquic_xxhash.c"
Cohesion: 0.16
Nodes (27): XXH32(), XXH32_createState(), XXH32_digest(), XXH32_digest_endian(), XXH32_endian_align(), XXH32_freeState(), XXH32_reset(), XXH32_update() (+19 more)

### Community 32 - "lsquic_adaptive_cc.c"
Cohesion: 0.07
Nodes (14): adaptive_cc_ack(), adaptive_cc_begin_ack(), adaptive_cc_was_quiet(), cubic_reset(), cubic_update(), in_slow_start(), lsquic_cubic_ack(), lsquic_cubic_init() (+6 more)

### Community 33 - "uwz_uni_stream.c"
Cohesion: 0.18
Nodes (32): lsquic_conn_make_uni_stream(), lsquic_conn_n_pending_streams(), lsquic_test_fail_next_hash_insert(), lsquic_test_fail_next_stream_new(), lsquic_test_hash_insert_failures_pending(), lsquic_test_stream_new_failures_pending(), assert_h3_critical(), assert_payload() (+24 more)

### Community 34 - "prog_prep"
Cohesion: 0.14
Nodes (35): main(), usage(), main(), usage(), main(), usage(), main(), usage() (+27 more)

### Community 35 - "lsquic_crypto.c"
Cohesion: 0.09
Nodes (23): lshkdf_expand(), lsquic_aes_aead_dec(), lsquic_aes_aead_enc(), lsquic_c255_gen_share_key(), lsquic_crypto_init(), lsquic_export_key_material(), lsquic_export_key_material_simple(), lsquic_fnv1a_128_3() (+15 more)

### Community 36 - "lsquic_enc_sess_ietf.c"
Cohesion: 0.10
Nodes (25): apply_hp(), apply_hp_batch(), apply_hp_immediately(), flush_hp_batch(), header_prot_inited(), iquic_esf_alg_keysize(), iquic_esf_cipher(), iquic_esf_encrypt_packet() (+17 more)

### Community 37 - "lsquic_ev_log.c"
Cohesion: 0.12
Nodes (29): lsquic_ev_log_action_stream_frame(), lsquic_ev_log_blocked_frame_in(), lsquic_ev_log_cert_chain(), lsquic_ev_log_check_certs(), lsquic_ev_log_connection_close_frame_in(), lsquic_ev_log_create_connection(), lsquic_ev_log_crypto_frame_in(), lsquic_ev_log_generated_crypto_frame() (+21 more)

### Community 38 - "lsquic_mini_conn_ietf.c"
Cohesion: 0.09
Nodes (19): iquic_esfi_init_server_tp(), cryst_get_conn(), ietf_mini_conn_ci_packet_sent(), ietf_mini_conn_ci_record_addrs(), imico_chlo_has_been_consumed(), imico_dispatch_stream_events(), imico_find_stream_frame(), imico_maybe_process_params() (+11 more)

### Community 39 - "init_test_objs"
Cohesion: 0.15
Nodes (32): lsquic_stream_call_on_close(), lsquic_stream_dispatch_write_events(), lsquic_stream_is_write_reset(), lsquic_stream_uh_in(), lsquic_stream_write_avail(), stream_dispatch_write_events_loop(), stream_writeable(), lsquic_stream_acked() (+24 more)

### Community 40 - "uwz_reset_ack.c"
Cohesion: 0.16
Nodes (25): lsquic_test_packet_deliver(), lsquic_test_packet_take(), assert_latest_reset(), assert_metadata(), assert_other_queues_empty(), cleanup_fixture(), close_stream(), collect_only_ack() (+17 more)

### Community 41 - "prog_stop"
Cohesion: 0.08
Nodes (21): echo_server_on_conn_closed(), echo_server_on_new_conn(), create_another_conn_or_stop(), client_on_conn_closed(), client_on_goaway_received(), client_on_new_conn(), server_on_conn_closed(), server_on_new_conn() (+13 more)

### Community 42 - "lsquic_mm_init"
Cohesion: 0.17
Nodes (26): lsquic_frame_reader_destroy(), lsquic_frame_writer_destroy(), lsquic_frame_writer_max_header_list_size(), lsquic_frame_writer_new(), headers_on_settings(), lsquic_headers_stream_destroy(), lsquic_mm_cleanup(), lsquic_mm_init() (+18 more)

### Community 43 - "lsquic_engine_init_settings"
Cohesion: 0.17
Nodes (28): lsquic_engine_check_settings(), lsquic_engine_init_settings(), webtransport_settings_error(), get_tls_context(), lookup_certificate(), lsquic_test_endpoint_init(), lsquic_test_tls_context_new(), init_endpoint() (+20 more)

### Community 44 - "uwz_webtransport_settings_delivery.c"
Cohesion: 0.18
Nodes (25): append_varint(), assert_canary(), assert_pending(), assert_unchanged(), cleanup_fixture(), connection_closed(), handshake_done(), hold_auto_writer() (+17 more)

### Community 45 - "uwz_webtransport_stream_resets.c"
Cohesion: 0.21
Nodes (24): lsquic_test_endpoint_destroy(), lsquic_test_pair_process(), assert_bidi_child_info(), assert_parent(), assert_reset_child_info(), claim_headers(), close_stream(), establish_parent() (+16 more)

### Community 46 - "vint_val2bits"
Cohesion: 0.12
Nodes (27): hcso_encode_setting(), hcso_setting_type2bits(), hcso_write_number_frame(), hqft2str(), lsquic_hcso_write_cancel_push(), lsquic_hcso_write_max_push_id(), lsquic_hcso_write_priority_update(), lsquic_hcso_write_settings() (+19 more)

### Community 47 - "lsquic_mini_conn.c"
Cohesion: 0.09
Nodes (13): continue_handshake(), count_zero_bytes(), highest_bit_set(), least_unacked(), lowest_bit_set(), mini_rechist_first(), mini_rechist_next(), mini_stream_has_data() (+5 more)

### Community 48 - "lsquic_frame_writer.c"
Cohesion: 0.15
Nodes (24): calc_headers_size(), check_headers_case(), check_headers_size(), count_uppercase(), have_oversize_strings(), hfc_init(), hfc_save_ptr(), hfc_terminate_frame() (+16 more)

### Community 49 - "uwz_webtransport_peer.c"
Cohesion: 0.18
Nodes (22): lsquic_conn_get_webtransport_peer(), assert_canary(), assert_close_snapshot(), assert_completed(), assert_peer_matches(), close_stream(), connection_closed(), handshake_done() (+14 more)

### Community 50 - "lsquic_attq.c"
Cohesion: 0.17
Nodes (22): attq_heapify(), attq_swap(), attq_verify(), lsquic_attq_add(), lsquic_attq_count_before(), lsquic_attq_create(), lsquic_attq_destroy(), lsquic_attq_next() (+14 more)

### Community 51 - "lsquic_hash_insert"
Cohesion: 0.18
Nodes (25): buffer_priority_update(), can_give_peer_streams_credit(), conn_is_receive_only_stream(), conn_is_send_only_stream(), conn_is_stream_closed(), conn_mark_stream_closed(), create_bidi_stream_out(), find_stream_by_id() (+17 more)

### Community 52 - "lsquic_rapidhash.h"
Cohesion: 0.16
Nodes (19): hash_req(), lsquic_purga_add(), lsquic_purga_cids_per_page(), lsquic_purga_contains(), lsquic_purga_destroy(), lsquic_purga_get_bloom_stats(), lsquic_purga_new(), purga_get_page() (+11 more)

### Community 53 - "lsquic_spi_first"
Cohesion: 0.16
Nodes (23): process_streams_read_events(), process_streams_ready_to_send(), process_streams_write_events(), add_stream_to_spi(), find_and_set_lowest_priority(), find_and_set_next_priority(), have_non_critical_streams(), lsquic_spi_drop_high() (+15 more)

### Community 54 - "lsquic_time_now"
Cohesion: 0.26
Nodes (24): gettimeofday(), lsquic_rechist_cleanup(), lsquic_rechist_init(), lsquic_rechist_received(), lsquic_time_now(), main(), test1(), test2() (+16 more)

### Community 55 - "lsxpack_header_get_name"
Cohesion: 0.13
Nodes (20): calc_sample_stats(), display_stat(), hset_dump(), interop_server_hset_add_header(), lsxpack_header_get_name(), lsxpack_header_get_value(), lsquic_ev_log_generated_http_headers(), lsquic_http_parse_pfv() (+12 more)

### Community 56 - "lsquic_str_len"
Cohesion: 0.24
Nodes (18): comp_ls_str(), get_certs_entries(), get_certs_hash(), get_entries_size(), lsquic_compress_certs(), lsquic_decompress_certs(), lsquic_get_common_cert(), lsquic_get_common_certs_hash() (+10 more)

### Community 57 - "lsquic_packet_out.h"
Cohesion: 0.18
Nodes (22): lsquic_ev_log_packet_sent(), lsquic_packet_out_ecn(), lsquic_packet_out_enc_level(), lsquic_packet_out_ipv6(), lsquic_packet_out_kp(), lsquic_packet_out_loss_bit(), lsquic_packet_out_packno_bits(), lsquic_packet_out_pubres() (+14 more)

### Community 58 - "lsquic_frab_list.h"
Cohesion: 0.10
Nodes (19): frab_left_to_read(), frab_left_to_write(), frab_write_to(), fral_get_frab(), lsquic_frab_list_mem_used(), lsquic_frab_list_read(), lsquic_frab_list_write(), lsquic_frame_reader_mem_used() (+11 more)

### Community 59 - "lsquic_pr_queue.c"
Cohesion: 0.11
Nodes (7): evanescent_conn_ci_packet_not_sent(), evanescent_conn_ci_packet_sent(), evanescent_conn_ci_tick(), prq_free_conn(), put_req(), main(), test_one_stk()

### Community 60 - "new_conn_common"
Cohesion: 0.12
Nodes (18): lsquic_alarmset_init(), lsquic_alarmset_init_alarm(), lsquic_alarmset_log(), cfcw_maybe_increase_max_window(), lsquic_cfcw_fc_offsets_changed(), lsquic_cfcw_init(), lsquic_conn_cap_init(), ietf_full_conn_init() (+10 more)

### Community 61 - "lsquic_rechist.c"
Cohesion: 0.14
Nodes (16): ack_rechist_largest_recv(), holes_after(), process_stop_waiting_frame(), find_free_slot(), lsquic_rechist_copy_ranges(), lsquic_rechist_cutoff(), lsquic_rechist_largest_packno(), lsquic_rechist_largest_recv() (+8 more)

### Community 62 - "lsquic_stream_id_t"
Cohesion: 0.12
Nodes (19): ietf_v1_calc_stream_frame_header_sz(), ietf_v1_gen_crypto_frame(), ietf_v1_gen_max_stream_data_frame(), ietf_v1_gen_rst_frame(), ietf_v1_gen_stop_sending_frame(), ietf_v1_gen_stream_blocked_frame(), ietf_v1_gen_stream_frame(), ietf_v1_gen_two_varints() (+11 more)

### Community 63 - "test_trechist.c"
Cohesion: 0.26
Nodes (16): find_free_slot(), lsquic_trechist_contains(), lsquic_trechist_copy_ranges(), lsquic_trechist_first(), lsquic_trechist_insert(), lsquic_trechist_iter(), lsquic_trechist_max(), lsquic_trechist_next() (+8 more)

### Community 64 - "iquic_packno_bits2len"
Cohesion: 0.13
Nodes (19): iquic_packno_bits2len(), gen_long_pkt_header(), ietf_v1_gen_reg_pkt_header(), ietf_v1_packno_bits2len(), ietf_v1_packout_header_size_long_by_flags(), ietf_v1_packout_header_size_long_by_packet(), ietf_v1_packout_header_size_short(), ietf_v1_packout_max_header_size() (+11 more)

### Community 65 - "uwz_reset_metadata.c"
Cohesion: 0.20
Nodes (15): close_stream(), connection_closed(), find_stream(), goaway_received(), handshake_done(), main(), new_connection(), new_stream() (+7 more)

### Community 66 - "lsquic_str.h"
Cohesion: 0.17
Nodes (15): lsquic_c255_get_pub_key(), cached_certs_match(), config_has_correct_size(), determine_rtts(), gen_rej1_data(), gen_shlo_data(), get_valid_scfg(), lsquic_enc_session_handle_chlo() (+7 more)

### Community 67 - "uwz_reset_http.c"
Cohesion: 0.21
Nodes (15): assert_connected(), cleanup_fixture(), close_stream(), connection_closed(), handshake_done(), main(), make_client_uni(), new_connection() (+7 more)

### Community 68 - "lsquic_str_cstr"
Cohesion: 0.12
Nodes (17): lsquic_get_certs_count(), lsquic_bio_to_crt(), free_compressed_cert(), generate_crt(), get_tag_val_u32(), get_tag_value_i32(), get_tag_value_i64(), handle_chlo_reply_verify_prof() (+9 more)

### Community 69 - "iquic_esf_decrypt_packet"
Cohesion: 0.15
Nodes (14): cleanup_crypto_ctx(), cry_sm_set_read_secret(), cry_sm_set_write_secret(), decode_packno(), get_crypto_params(), init_crypto_ctx(), iquic_esf_decrypt_packet(), log_crypto_ctx() (+6 more)

### Community 70 - "lsquic_hpi.c"
Cohesion: 0.19
Nodes (16): add_stream_to_hpi(), free_heap_elems(), hpi_drop_high_or_non_high(), lsquic_hpi_cleanup(), lsquic_hpi_drop_high(), lsquic_hpi_drop_non_high(), lsquic_hpi_first(), lsquic_hpi_init() (+8 more)

### Community 71 - "init_test"
Cohesion: 0.27
Nodes (18): record_dcid(), lsquic_send_ctl_cidlen_change(), assert_scheduled_accounting(), cleanup_test(), destroy_unscheduled_packet(), init_test(), main(), new_ping_packet() (+10 more)

### Community 72 - "lsquic_http1x_if.c"
Cohesion: 0.20
Nodes (14): add_header_to_uh(), add_pseudo_header(), add_real_header(), code_str_to_reason(), convert_pseudo_headers(), convert_request_pseudo_headers(), convert_response_pseudo_headers(), h1h_create_header_set() (+6 more)

### Community 73 - "ietf_v1_gen_ack_frame"
Cohesion: 0.14
Nodes (8): lsquic_gquic_be_gen_ack_frame(), lsquic_gquic_be_write_float_time16(), ietf_v1_calc_packno_bits(), ietf_v1_gen_ack_frame(), write_packno(), rechist_first(), rechist_largest_recv(), rechist_next()

### Community 74 - "lsquic_set.c"
Cohesion: 0.20
Nodes (15): lsquic_set32_add(), lsquic_set32_check_elems_sorted(), lsquic_set32_cleanup(), lsquic_set32_has(), lsquic_set32_init(), lsquic_set32_insert_set_elem(), lsquic_set32_merge_set_elems(), lsquic_set64_add() (+7 more)

### Community 75 - "lsquic_str_delete"
Cohesion: 0.26
Nodes (14): lsquic_crt_cleanup(), lsquic_crt_init(), free_c_cert_item(), lsquic_enc_session_deserialize_sess_resume(), lsquic_enc_session_destroy(), lsquic_handshake_cleanup(), make_c_cert_item(), lsquic_str_append() (+6 more)

### Community 76 - "lsquic_packet_in_t"
Cohesion: 0.15
Nodes (15): lsquic_conn_copy_and_release_pi_data(), conn_decrypt_packet(), conn_decrypt_packet_or(), imico_maybe_delay_processing(), insert_into_deferred(), mini_conn_ci_packet_in(), mini_conn_ci_Q050_packet_in(), process_crypto_frame() (+7 more)

### Community 77 - "uwz_webtransport_settings_state.c"
Cohesion: 0.32
Nodes (15): on_setting(), lsquic_wt_peer_set_transport(), lsquic_wt_setting_apply(), assert_applied(), assert_canaries(), assert_transport(), assert_unchanged(), init_probe() (+7 more)

### Community 78 - "allocate_packet_out"
Cohesion: 0.14
Nodes (15): allocate_packet_out(), in_acked_range(), mini_conn_ci_record_addrs(), mini_stream_fin(), mini_stream_size(), next_packno(), process_ack_frame(), record_inord_packno() (+7 more)

### Community 79 - "test_lost_prefix_reset_first"
Cohesion: 0.16
Nodes (14): lsquic_stream_get_reset_error(), assert_healthy(), assert_pending_reset(), cleanup_fixture(), consume_prefix(), consume_reset(), find_stream(), init_fixture() (+6 more)

### Community 80 - "test_ack_merge.c"
Cohesion: 0.19
Nodes (13): lsquic_ev_log_ack_frame_in(), lsquic_ev_log_generated_ack_frame(), process_ack_frame(), log_invalid_ack_frame(), process_ack_frame(), lsquic_acki2str(), lsquic_merge_acks(), lsquic_senhist_tostr() (+5 more)

### Community 81 - "init_test"
Cohesion: 0.34
Nodes (14): lsquic_bw_sampler_get_bw(), lsquic_send_ctl_get_bw(), ack_one(), cleanup_test(), init_test(), main(), new_packet(), test_adaptive_switch_with_info_keeps_sampler() (+6 more)

### Community 82 - "lsquic_mm_get_4k"
Cohesion: 0.14
Nodes (14): check_server_tps_for_violations(), get_peer_transport_params(), iquic_esfi_data_in(), readf_cb(), fw_alloc(), verify_retry_packet(), heap_nonincr_bucket(), lsquic_mm_get_4k() (+6 more)

### Community 83 - "lsquic_stream_ctx_t"
Cohesion: 0.13
Nodes (15): feed_hcsi_reader(), hcsi_on_close(), hcsi_on_new(), hcsi_on_write(), unicla_on_close(), unicla_on_new(), unicla_on_write(), unicla_readf() (+7 more)

### Community 84 - "lsquic_stream_maybe_reset"
Cohesion: 0.14
Nodes (15): lsquic_qdh_cancel_stream(), lsquic_qdh_cancel_stream_id(), lsquic_qdh_header_in_continue(), lsquic_qdh_take_hsi_error(), lsquic_qdh_unref_stream(), qdh_header_read_results(), qdh_hsi_process_wrapper(), qdh_maybe_destroy_hblock_ctx() (+7 more)

### Community 85 - "lsquic_arr.h"
Cohesion: 0.24
Nodes (8): lsquic_arr_cleanup(), lsquic_arr_count(), lsquic_arr_get(), lsquic_arr_init(), lsquic_arr_push(), lsquic_arr_shift(), main(), test1()

### Community 86 - "iquic_esfi_create_client"
Cohesion: 0.22
Nodes (14): cleanup_hp(), cleanup_hsk_crypto(), free_handshake_keys(), free_vn_save(), gen_trans_params(), init_frals(), iquic_esfi_create_client(), iquic_esfi_create_server() (+6 more)

### Community 87 - "lsquic_stream_accept_webtransport"
Cohesion: 0.13
Nodes (12): full_conn_ci_get_param(), calc_drain_time(), ietf_full_conn_ci_drain_time(), ietf_full_conn_ci_get_info(), ietf_full_conn_ci_get_param(), ietf_full_conn_ci_set_param(), lsquic_stream_accept_webtransport(), webtransport_connection_ready() (+4 more)

### Community 88 - "lsquic_mm_get_packet_in_buf"
Cohesion: 0.22
Nodes (14): gquic_decrypt_packet(), lsquic_mm_get_packet_in_buf(), lsquic_mm_get_packet_out(), lsquic_mm_put_packet_in_buf(), lsquic_mm_put_packet_out(), maybe_shrink_packet_in_bufs(), maybe_shrink_packet_out_bufs(), packet_in_index() (+6 more)

### Community 89 - "lsquic_log_to_fstream"
Cohesion: 0.20
Nodes (14): lsquic_log_to_fstream(), lsquic_logger_lopt(), lsquic_set_log_level(), lsquic_str_to_log_level(), lsquic_str_to_logger_module(), main(), main(), test_post_quiescence_explosion() (+6 more)

### Community 90 - "ietf_mini_conn_ci_packet_in"
Cohesion: 0.19
Nodes (13): ietf_mini_conn_ci_abort_error(), ietf_mini_conn_ci_packet_in(), imico_build_ack_frame(), imico_maybe_validate_by_dcid(), imico_parse_regular_packet(), imico_peer_addr_validated(), imico_process_packet_frame(), imico_received_packet_is_dup() (+5 more)

### Community 91 - "lsquic_time_t"
Cohesion: 0.21
Nodes (14): ietf_mini_conn_ci_next_tick_time(), ietf_mini_conn_ci_tick(), imico_calc_retx_timeout(), imico_generate_ack(), imico_generate_acks(), imico_generate_conn_close(), imico_generate_handshake_done(), imico_generate_ping() (+6 more)

### Community 92 - "lsquic_tp_decode"
Cohesion: 0.17
Nodes (13): lsquic_tp_decode(), lsquic_tp_decode_27(), tpi_val_2_enum(), decode_file(), main(), params_are_equal(), run_test(), test_oversized_param_len() (+5 more)

### Community 93 - "lsquic_test_deliver_all"
Cohesion: 0.36
Nodes (14): lsquic_test_deliver_all(), assert_connected(), claim_header_set(), cleanup_fixture(), find_stream(), main(), pump(), queue_peer_stop() (+6 more)

### Community 94 - "http_server_on_new_conn"
Cohesion: 0.15
Nodes (10): http_server_on_conn_closed(), http_server_on_goaway(), http_server_on_new_conn(), log_peer_cert_chain(), perf_server_on_conn_closed(), perf_server_on_new_conn(), lsquic_conn_get_full_peer_cert_chain(), lsquic_conn_get_sni() (+2 more)

### Community 95 - "lsquic_iquic_gen_retry_pkt"
Cohesion: 0.18
Nodes (10): lsquic_iquic_gen_retry_pkt(), get_or_generate_state(), lsquic_tg_generate_resume(), lsquic_tg_generate_retry(), lsquic_tg_new(), lsquic_tg_validate_token(), setup_nonce_prk(), tokgen_generate_token() (+2 more)

### Community 96 - "lsquic_frab_list_empty"
Cohesion: 0.19
Nodes (13): chsk_ietf_on_close(), chsk_ietf_on_new_stream(), chsk_ietf_on_read(), chsk_ietf_on_write(), cry_sm_flush_flight(), cry_sm_write_message(), iquic_esfi_handshake_confirmed(), iquic_esfi_post_handshake() (+5 more)

### Community 97 - "test_rechist.c"
Cohesion: 0.36
Nodes (11): verify_ack_frame(), lsquic_rechist_first(), lsquic_rechist_next(), main(), rechist2str(), test4(), test5(), test6() (+3 more)

### Community 98 - "test_http1x_if.c"
Cohesion: 0.41
Nodes (13): add_request_pseudo_headers(), main(), make_xhdr(), new_hset(), new_hset_with_limit(), process_header(), test_bad_pseudo_value(), test_bad_real_header() (+5 more)

### Community 99 - "test_ackparse_gquic_le.c"
Cohesion: 0.33
Nodes (10): main(), n_acked(), test1(), test2(), test3(), test4(), test5(), test6() (+2 more)

### Community 100 - "lsxpack_header.h"
Cohesion: 0.23
Nodes (11): hset_prepare_decode(), interop_server_hset_prepare_decode(), lsxpack_header_get_dec_size(), lsxpack_header_mark_val_changed(), lsxpack_header_prepare_decode(), lsxpack_header_set_idx(), lsxpack_header_set_offset(), lsxpack_header_set_qpack_idx() (+3 more)

### Community 101 - "lsquic_frame_reader_new"
Cohesion: 0.15
Nodes (9): hfh_get_length(), hft_to_string(), lsquic_frame_reader_new(), lsquic_frame_reader_read(), prepare_for_payload(), read_http_frame_header(), headers_on_close(), headers_on_new_stream() (+1 more)

### Community 102 - "lsquic_engine_add_conn_to_tickable"
Cohesion: 0.21
Nodes (11): lsquic_engine_add_conn_to_tickable(), full_conn_ci_abort(), full_conn_ci_going_away(), ietf_full_conn_ci_abort(), ietf_full_conn_ci_want_datagram_write(), heapify_min_heap(), lsquic_mh_insert(), lsquic_mh_pop() (+3 more)

### Community 103 - "lsquic_qdec_hdl.c"
Cohesion: 0.24
Nodes (8): qdh_begin_out(), qdh_in_on_close(), qdh_in_on_new(), qdh_in_on_write(), qdh_out_on_close(), qdh_out_on_new(), qdh_out_on_read(), qdh_write_type()

### Community 104 - "duck_client_on_conn_closed"
Cohesion: 0.18
Nodes (8): duck_client_on_conn_closed(), duck_client_on_hsk_done(), duck_client_on_new_conn(), duck_on_datagram(), duck_on_dg_write(), duck_server_on_conn_closed(), duck_server_on_new_conn(), lsquic_conn_want_datagram_write()

### Community 105 - "IMICO_PROC_FRAME_ARGS"
Cohesion: 0.18
Nodes (11): ietf_mini_conn_ci_destroy(), ignore_init(), imico_count_zero_bytes(), imico_destroy_packet(), imico_process_ack_frame(), imico_process_connection_close_frame(), imico_process_invalid_frame(), imico_process_invalid_frame_pv() (+3 more)

### Community 106 - "lsquic_packet_in_t"
Cohesion: 0.21
Nodes (10): is_handshake_stream_id(), process_blocked_frame(), process_goaway_frame(), process_invalid_frame(), process_packet_frame(), process_ping_frame(), process_regular_packet(), process_rst_stream_frame() (+2 more)

### Community 107 - "lsquic_gen_ver_tags"
Cohesion: 0.18
Nodes (10): lsquic_generate_gquic_reset(), lsquic_gquic_gen_ver_nego_pkt(), ietf_v1_parse_new_conn_id(), lsquic_ietf_v1_gen_ver_nego_pkt(), popcount(), lsquic_Q046_gen_ver_nego_pkt(), popcount(), lsquic_gen_ver_tags() (+2 more)

### Community 108 - "main"
Cohesion: 0.26
Nodes (10): lsquic_qlog_cert_chain(), lsquic_qlog_check_certs(), lsquic_qlog_create_connection(), lsquic_qlog_hsk_completed(), lsquic_qlog_packet_rx(), lsquic_qlog_sess_resume(), lsquic_qlog_version_negotiation(), hex_digit() (+2 more)

### Community 109 - "run_test"
Cohesion: 0.20
Nodes (11): cleanup_test_ctx(), init_test_ctx(), make_rst_stream_frame(), make_stream_frame(), my_gsf_read(), my_pri_new_packet(), new_input_packet(), new_packet() (+3 more)

### Community 110 - "test_frozen_connection_credit"
Cohesion: 0.35
Nodes (11): assert_healthy(), assert_reset(), cleanup_fixture(), find_stream(), init_fixture(), main(), make_stream(), pump_step() (+3 more)

### Community 111 - "test_raw_directional_credit"
Cohesion: 0.24
Nodes (11): actual_peer_parameters(), assert_connected_ready(), assert_raw_received(), assert_send_cap(), find_stream(), main(), prove_client_receive_admission(), pump_step() (+3 more)

### Community 112 - "lsquic_alarmset_unset"
Cohesion: 0.20
Nodes (10): lsquic_alarmset_is_inited(), lsquic_alarmset_unset(), lsquic_crand_get_byte(), force_queueing_ack_app(), handshake_failed(), ietf_full_conn_ci_hsk_done(), ietf_full_conn_ci_retx_timeout(), lsquic_send_ctl_begin_optack_detection() (+2 more)

### Community 113 - "lsquic_time_t"
Cohesion: 0.25
Nodes (10): calc_retx_timeout(), generate_ack_and_stop_waiting(), handle_losses_and_have_unsent(), have_packets_to_send(), mini_conn_ci_next_tick_time(), mini_conn_ci_tick(), mini_destroy_packet(), mini_rechist_init() (+2 more)

### Community 114 - "LSQUIC Contributor Guidance"
Cohesion: 0.20
Nodes (9): APIs, documentation, and generated files, Building, C style, Commit messages, LSQUIC Contributor Guidance, Repository map and architecture, Scope and sources of truth, Testing (+1 more)

### Community 115 - "SSL"
Cohesion: 0.29
Nodes (7): cry_sm_send_alert(), iquic_lookup_cert(), iquic_new_session_cb(), iquic_ssl_sess_to_resume_info(), lsquic_ssl_sess_to_resume_info(), maybe_create_SSL_SESSION(), verify_server_cert_callback()

### Community 117 - "gen_long_pkt_header"
Cohesion: 0.24
Nodes (9): gen_long_pkt_header(), gen_short_pkt_header(), gquic_Q046_calc_packno_bits(), gquic_Q046_gen_reg_pkt_header(), gquic_Q046_packout_header_size(), gquic_Q046_packout_header_size_long(), gquic_Q046_packout_header_size_short(), gquic_Q046_packout_size() (+1 more)

### Community 118 - "insert_cert"
Cohesion: 0.31
Nodes (6): find_cert(), gen_iasn_key(), get_sni_SSL_CTX(), handle_chlo_frames_data(), insert_cert(), s_free_cert_hash_item()

### Community 119 - "mini_conn_ci_destroy"
Cohesion: 0.22
Nodes (8): lsquic_logger_log2(), ctz(), drop_packets_out(), inord_to_str(), maybe_log_enc_sess_history(), mini_conn_ci_destroy(), process_connection_close_frame(), warning_is_warranted()

### Community 120 - "lsquic_cid2str"
Cohesion: 0.31
Nodes (7): lsquic_conn_stats_diff(), update_busy_detector(), full_conn_ci_log_stats(), ietf_full_conn_ci_log_stats(), lsquic_cid2str(), lsquic_logger_log1(), lsquic_logger_log3()

### Community 121 - "reconstruct_packet_number"
Cohesion: 0.28
Nodes (8): reconstruct_packet_number(), process_stop_waiting_frame(), lsquic_restore_packno(), lsquic_packet_in_packno_bits(), main(), run_pbt(), run_rpt(), test_restore()

### Community 122 - "main"
Cohesion: 0.36
Nodes (8): main(), n_acked(), test1(), test2(), test3(), test4(), test5(), test6()

### Community 123 - "uwz_reset_codec.c"
Cohesion: 0.50
Nodes (8): assert_atomic_failure(), assert_frame(), main(), test_boundaries(), test_frame(), test_invalid_fields(), test_nonminimal_fields(), write_varint()

### Community 124 - "test_wire"
Cohesion: 0.39
Nodes (9): assert_failure(), find(), finish(), main(), pump(), start(), test_contract(), test_reset_before_send() (+1 more)

### Community 125 - "lsquic_eng_hist.h"
Cohesion: 0.29
Nodes (5): eng_hist_clear_cur(), eng_hist_init(), eng_hist_tick(), log_hist_slice(), lsquic_eng_hist_log()

### Community 126 - "test_goaway_gquic_le.c"
Cohesion: 0.36
Nodes (6): main(), run_gen_tests(), run_parse_tests(), main(), run_gen_tests(), run_parse_tests()

### Community 127 - "lsquic_stream_ctx_t"
Cohesion: 0.43
Nodes (6): close_stream(), hset_in(), new_stream(), read_stream(), reset_stream(), write_stream()

### Community 128 - "prog_process_conns"
Cohesion: 0.38
Nodes (6): prog_is_stopped(), prog_process_conns(), prog_timer_handler(), prog_usr2_handler(), read_handler(), read_using_recvmmsg()

### Community 129 - "try_to_begin_migration"
Cohesion: 0.43
Nodes (7): lsquic_bw_sampler_init(), try_to_begin_migration(), lsquic_tp_has_pref_ipv4(), lsquic_tp_has_pref_ipv6(), lsquic_tp_to_str(), lsquic_tp_to_str_27(), lsquic_is_zero()

### Community 130 - "pool_stats"
Cohesion: 0.29
Nodes (7): pool_stats, ps_calls, ps_max, ps_max_avg, ps_max_var, ps_objs_all, ps_objs_out

### Community 131 - "create_client"
Cohesion: 0.38
Nodes (6): create_client(), init_storage(), main(), test_bad_resume(), test_chlo_tag(), test_truncated_certs()

### Community 132 - "test_streamgen.c"
Cohesion: 0.52
Nodes (6): main(), reset_ctx(), run_test(), stream_tosend_fin(), stream_tosend_read(), stream_tosend_size()

### Community 133 - "uwz_webtransport_config.c"
Cohesion: 0.57
Nodes (6): assert_canary(), assert_result(), check_configuration(), main(), test_cases(), test_defaults()

### Community 134 - "keylog_open_file"
Cohesion: 0.40
Nodes (4): keylog_log_line(), keylog_open_file(), prog_new_session_cb(), lsquic_ssl_to_conn()

### Community 135 - "ietf_mini_conn_ci_next_packet_to_send"
Cohesion: 0.33
Nodes (6): ietf_mini_conn_ci_is_tickable(), ietf_mini_conn_ci_next_packet_to_send(), imico_can_send(), remove_ack_frame(), lsquic_packet_out_equal_dcids(), offset_to_dcid()

### Community 136 - "lsquic_stream_ctx_t"
Cohesion: 0.53
Nodes (4): on_close(), on_hset_in(), on_new_stream(), on_reset()

### Community 137 - "lsquic_stream_ctx_t"
Cohesion: 0.53
Nodes (4): close_stream(), new_stream(), read_stream(), write_stream()

### Community 140 - "lsquic_prq_new_req_ext"
Cohesion: 0.40
Nodes (4): schedule_req_packet(), get_req(), lsquic_prq_new_req(), lsquic_prq_new_req_ext()

### Community 141 - "lsquic_qenc_hdl.h"
Cohesion: 0.40
Nodes (4): apply_uni_stream_class(), lsquic_qdh_has_enc_stream(), lsquic_qeh_has_dec_stream(), lsquic_stream_set_stream_if()

### Community 142 - "highest_bit_set"
Cohesion: 0.40
Nodes (5): highest_bit_set(), imico_bitmask_rechist_next(), imico_packno_is_largest(), lsquic_imico_rechist_first(), lsquic_imico_rechist_next()

### Community 144 - "lsquic_stream_ctx_t"
Cohesion: 0.60
Nodes (3): close_stream(), new_stream(), write_stream()

### Community 145 - "qm_trace"
Cohesion: 0.40
Nodes (5): qm_trace, lastfile, lastline, prevfile, prevline

### Community 146 - "create_streams"
Cohesion: 0.67
Nodes (3): create_streams(), http_client_on_new_conn(), qif_client_on_new_conn()

### Community 147 - "drop_SSL"
Cohesion: 0.50
Nodes (3): cache_info(), drop_SSL(), no_sess_ticket()

### Community 148 - "lsquic_ev_log_packet_in"
Cohesion: 0.50
Nodes (3): lsquic_ev_log_packet_in(), lsquic_packet_in_ecn(), lsquic_packet_in_spin_bit()

### Community 149 - "lsquic_mini_conn_new"
Cohesion: 0.50
Nodes (3): lsquic_mini_conn_new(), packet_in_is_ok(), main()

### Community 151 - "test_quic_le_floats.c"
Cohesion: 0.83
Nodes (3): main(), run_from_float_tests(), run_to_float_tests()

### Community 152 - "test_wuf_gquic_le.c"
Cohesion: 0.83
Nodes (3): main(), run_gen_tests(), run_parse_tests()

## Knowledge Gaps
- **10 isolated node(s):** `ps_calls`, `ps_max`, `ps_max_avg`, `ps_max_var`, `ps_objs_all` (+5 more)
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 539 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)
- **16 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `lsquic_time_now()` connect `lsquic_time_now` to `lsquic_full_conn_ietf.c`, `lsquic_stream.c`, `lsquic_stream_shutdown`, `lsquic_send_ctl.c`, `stdlib`, `lsquic_full_conn.c`, `lsquic_engine.c`, `lsquic_packet_out_avail`, `lsquic_conn_get_ctx`, `full_conn_ci_tick`, `create_streams`, `lsquic_hashelem_getdata`, `test_qenc_hdl.c`, `prog_prep`, `lsquic_mini_conn_ietf.c`, `lsquic_attq.c`, `lsxpack_header_get_name`, `new_conn_common`, `allocate_packet_out`, `test_ack_merge.c`, `lsquic_frab_list_empty`, `test_ackparse_gquic_le.c`, `IMICO_PROC_FRAME_ARGS`, `main`, `mini_conn_ci_destroy`?**
  _High betweenness centrality (0.008) - this node is a cross-community bridge._
- **Are the 94 inferred relationships involving `lsquic_stream_destroy()` (e.g. with `full_conn_ci_destroy()` and `create_bidi_stream_out()`) actually correct?**
  _`lsquic_stream_destroy()` has 94 INFERRED edges - model-reasoned connections that need verification._
- **What connects `ps_calls`, `ps_max`, `ps_max_avg` to the rest of the system?**
  _10 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `lsquic_full_conn_ietf.c` be split into smaller, more focused modules?**
  _Cohesion score 0.01804613958932839 - nodes in this community are weakly interconnected._
- **Why does `perf_server_on_new_conn()` connect `http_server_on_new_conn` to `stdlib`?**
  _High betweenness centrality (0.005) - this node is a cross-community bridge._
- **Should `lsquic_stream.c` be split into smaller, more focused modules?**
  _Cohesion score 0.02654687579310695 - nodes in this community are weakly interconnected._
- **Should `lsquic_stream_shutdown` be split into smaller, more focused modules?**
  _Cohesion score 0.031578947368421054 - nodes in this community are weakly interconnected._