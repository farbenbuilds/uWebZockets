const std = @import("std");
const boringssl = @import("sdk/builds/vendor/boringssl.zig");
const sanitizers = @import("sdk/builds/sanitizers.zig");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const sanitizer = sanitizers.configure(b, target, true);
    const native = boringssl.build(b, target, optimize, sanitizer);
    const install_crypto = b.addInstallArtifact(native.crypto, .{});
    const install_ssl = b.addInstallArtifact(native.ssl, .{});
    const native_step = b.step("native", "Compile the complete normal crypto source list");
    native_step.dependOn(&install_crypto.step);
    native_step.dependOn(&install_ssl.step);
    const proof_step = b.step("proof", "Run native allocation-domain and CBB proof");
    add_proof(b, target, optimize, native, proof_step, "public_api_proof", false);
    add_proof(b, target, optimize, native, proof_step, "domain_proof", true);
    add_proof(b, target, optimize, native, proof_step, "hook_proof", true);
    add_partial_hook(b, target, optimize, native, proof_step, "partial_alloc", "-DPARTIAL_ALLOC");
    add_partial_hook(b, target, optimize, native, proof_step, "partial_free", "-DPARTIAL_FREE");
    add_partial_hook(b, target, optimize, native, proof_step, "partial_size", "-DPARTIAL_SIZE");
    add_sdallocx(b, target, optimize, native, sanitizer, proof_step);
    const baseline_step = b.step("bio-baseline", "Run the unchanged ordinary BIO pair allocation control");
    add_proof(b, target, optimize, native, baseline_step, "ordinary_bio_control", true);
    proof_step.dependOn(baseline_step);
    add_proof(b, target, optimize, native, proof_step, "bio_public_api_proof", false);
    add_proof(b, target, optimize, native, proof_step, "bio_pair_proof", true);
    const construction_baseline = b.step("construction-baseline", "Run ordinary SSL construction and inherit failure controls");
    add_proof(b, target, optimize, native, construction_baseline, "construction_control", true);
    add_proof(b, target, optimize, native, construction_baseline, "inherit_failure_control", true);
    proof_step.dependOn(construction_baseline);
    add_construction_public(b, target, optimize, native, proof_step, "ssl_construction_public", false);
    add_construction_public(b, target, optimize, native, proof_step, "ssl_construction_hook", true);
    add_proof(b, target, optimize, native, proof_step, "ssl_construction_proof", true);
    const handshake_step = b.step("handshake-build", "Compile the separate fresh-fixture TLS compatibility proof");
    const handshake_module = b.createModule(.{ .target = target, .optimize = optimize, .link_libc = true, .link_libcpp = true, .strip = true });
    handshake_module.addSystemIncludePath(native.include_root);
    handshake_module.addCSourceFile(.{ .file = b.path("proof/ssl_construction_handshake.cc"), .flags = &.{ "-std=c++17", "-Wall", "-Wextra", "-Werror", "-fno-exceptions", "-fno-rtti" } });
    handshake_module.linkLibrary(native.ssl);
    handshake_module.linkLibrary(native.crypto);
    const handshake_executable = b.addExecutable(.{ .name = "ssl_construction_handshake", .root_module = handshake_module });
    const handshake_install = b.addInstallArtifact(handshake_executable, .{});
    handshake_step.dependOn(&handshake_install.step);
    const wire_step = b.step("wire-proof", "Run the native exact-class wire storage proof");
    add_wire_public(b, target, optimize, native, wire_step, "wire_public", false);
    add_wire_public(b, target, optimize, native, wire_step, "wire_hook", true);
    add_wire_cpp(b, target, optimize, native, wire_step, "wire_proof", true);
    const wire_handshake = b.step("wire-handshake-build", "Compile fresh-fixture owned-wire TLS compatibility checks");
    add_wire_cpp(b, target, optimize, native, wire_handshake, "wire_handshake", false);
}

fn add_wire_public(
    b: *std.Build,
    target: std.Build.ResolvedTarget,
    optimize: std.builtin.OptimizeMode,
    native: boringssl.Artifacts,
    step: *std.Build.Step,
    name: []const u8,
    hooks: bool,
) void {
    const module = b.createModule(.{ .target = target, .optimize = optimize, .link_libc = true, .link_libcpp = true, .strip = true });
    module.addSystemIncludePath(native.include_root);
    module.addCSourceFile(.{ .file = b.path("proof/wire_public.c"), .flags = &.{ "-std=c11", "-Wall", "-Wextra", "-Werror" } });
    if (hooks) module.addCMacro("WIRE_FULL_HOOK", "1");
    module.linkLibrary(native.ssl);
    module.linkLibrary(native.crypto);
    const executable = b.addExecutable(.{ .name = name, .root_module = module });
    const install = b.addInstallArtifact(executable, .{});
    const run = b.addRunArtifact(executable);
    step.dependOn(&install.step);
    step.dependOn(&run.step);
}

fn add_wire_cpp(
    b: *std.Build,
    target: std.Build.ResolvedTarget,
    optimize: std.builtin.OptimizeMode,
    native: boringssl.Artifacts,
    step: *std.Build.Step,
    name: []const u8,
    execute: bool,
) void {
    const module = b.createModule(.{ .target = target, .optimize = optimize, .link_libc = true, .link_libcpp = true, .strip = true });
    module.addSystemIncludePath(native.include_root);
    module.addSystemIncludePath(b.path("boringssl"));
    module.addSystemIncludePath(b.path("."));
    module.addCSourceFile(.{ .file = b.path(b.fmt("proof/{s}.cc", .{name})), .flags = &.{ "-std=c++17", "-DBORINGSSL_IMPLEMENTATION", "-fno-access-control", "-UNDEBUG", "-Wall", "-Wextra", "-Werror", "-fno-exceptions", "-fno-rtti" } });
    module.addCSourceFile(.{ .file = b.path("proof/allocation_scope.c"), .flags = &.{ "-std=c11", "-fno-builtin" } });
    module.linkLibrary(native.ssl);
    module.linkLibrary(native.crypto);
    const executable = b.addExecutable(.{ .name = name, .root_module = module });
    const install = b.addInstallArtifact(executable, .{});
    step.dependOn(&install.step);
    if (execute) {
        const run = b.addRunArtifact(executable);
        step.dependOn(&run.step);
    }
}

fn add_construction_public(
    b: *std.Build,
    target: std.Build.ResolvedTarget,
    optimize: std.builtin.OptimizeMode,
    native: boringssl.Artifacts,
    proof_step: *std.Build.Step,
    name: []const u8,
    full_hooks: bool,
) void {
    const module = b.createModule(.{ .target = target, .optimize = optimize, .link_libc = true, .link_libcpp = true, .strip = true });
    module.addSystemIncludePath(native.include_root);
    module.addCSourceFile(.{ .file = b.path("proof/ssl_construction_public.c"), .flags = &.{ "-std=c11", "-Wall", "-Wextra", "-Werror" } });
    if (full_hooks) module.addCMacro("SSL_CONSTRUCTION_FULL_HOOK", "1");
    module.linkLibrary(native.ssl);
    module.linkLibrary(native.crypto);
    const executable = b.addExecutable(.{ .name = name, .root_module = module });
    const install = b.addInstallArtifact(executable, .{});
    const run = b.addRunArtifact(executable);
    proof_step.dependOn(&install.step);
    proof_step.dependOn(&run.step);
}

fn add_partial_hook(
    b: *std.Build,
    target: std.Build.ResolvedTarget,
    optimize: std.builtin.OptimizeMode,
    native: boringssl.Artifacts,
    proof_step: *std.Build.Step,
    name: []const u8,
    definition: []const u8,
) void {
    const module = b.createModule(.{ .target = target, .optimize = optimize, .link_libc = true, .link_libcpp = true, .strip = true });
    module.addSystemIncludePath(native.include_root);
    module.addSystemIncludePath(b.path("boringssl"));
    module.addCSourceFile(.{
        .file = b.path("proof/partial_hook_proof.cc"),
        .flags = &.{ "-std=c++17", "-Wall", "-Wextra", "-Werror", definition },
    });
    module.addCSourceFile(.{ .file = b.path("proof/allocation_scope.c"), .flags = &.{ "-std=c11", "-fno-builtin" } });
    module.linkLibrary(native.crypto);
    const executable = b.addExecutable(.{ .name = name, .root_module = module });
    const install = b.addInstallArtifact(executable, .{});
    const run = b.addRunArtifact(executable);
    proof_step.dependOn(&install.step);
    proof_step.dependOn(&run.step);
}

fn add_sdallocx(
    b: *std.Build,
    target: std.Build.ResolvedTarget,
    optimize: std.builtin.OptimizeMode,
    native: boringssl.Artifacts,
    sanitizer: sanitizers.Config,
    proof_step: *std.Build.Step,
) void {
    const module = b.createModule(.{ .target = target, .optimize = optimize, .link_libc = true, .link_libcpp = true, .strip = true });
    module.addSystemIncludePath(native.include_root);
    module.addCSourceFile(.{
        .file = b.path("proof/sdallocx_proof.cc"),
        .flags = &.{ "-std=c++17", "-Wall", "-Wextra", "-Werror" },
    });
    const sized_native = boringssl.build(b, target, optimize, sanitizer);
    sized_native.crypto.root_module.addCMacro("BORINGSSL_DETECT_SDALLOCX", "1");
    module.linkLibrary(sized_native.crypto);
    const executable = b.addExecutable(.{ .name = "sdallocx_proof", .root_module = module });
    const install = b.addInstallArtifact(executable, .{});
    const run = b.addRunArtifact(executable);
    proof_step.dependOn(&install.step);
    proof_step.dependOn(&run.step);
}

fn add_proof(
    b: *std.Build,
    target: std.Build.ResolvedTarget,
    optimize: std.builtin.OptimizeMode,
    native: boringssl.Artifacts,
    proof_step: *std.Build.Step,
    name: []const u8,
    cpp: bool,
) void {
    const module = b.createModule(.{
        .target = target,
        .optimize = optimize,
        .link_libc = true,
        .link_libcpp = cpp,
        .strip = true,
    });
    module.addSystemIncludePath(native.include_root);
    module.addSystemIncludePath(b.path("boringssl"));
    module.addCSourceFile(.{
        .file = b.path(b.fmt("proof/{s}.{s}", .{ name, if (cpp) "cc" else "c" })),
        .flags = &.{ if (cpp) "-std=c++17" else "-std=c11", "-Wall", "-Wextra", "-Werror", "-fno-exceptions", "-fno-rtti" },
    });
    if (std.mem.eql(u8, name, "domain_proof") or std.mem.eql(u8, name, "ordinary_bio_control") or std.mem.eql(u8, name, "bio_pair_proof") or std.mem.eql(u8, name, "hook_proof") or std.mem.eql(u8, name, "construction_control") or std.mem.eql(u8, name, "ssl_construction_proof")) {
        module.addCSourceFile(.{ .file = b.path("proof/allocation_scope.c"), .flags = &.{ "-std=c11", "-fno-builtin" } });
    }
    module.linkLibrary(native.crypto);
    if (std.mem.eql(u8, name, "bio_pair_proof") or std.mem.eql(u8, name, "construction_control") or std.mem.eql(u8, name, "inherit_failure_control") or std.mem.eql(u8, name, "ssl_construction_public") or std.mem.eql(u8, name, "ssl_construction_proof")) module.linkLibrary(native.ssl);
    const executable = b.addExecutable(.{ .name = name, .root_module = module });
    const install = b.addInstallArtifact(executable, .{});
    const run = b.addRunArtifact(executable);
    if (std.mem.eql(u8, name, "inherit_failure_control")) run.addArg("--expect-fixed");
    proof_step.dependOn(&install.step);
    proof_step.dependOn(&run.step);
}
