# Independent wire-storage contract review

Final reviewed contract SHA-256:
`0c39aaeb956630908242a3d2f5e79b27e041cda19420f6e2ca14677d60901e97`.
Status: contract review sealed; no actionable findings remain in this revision.
This is a source-contract review before product implementation, not approval of
the native/SDK implementation or the strict PostgreSQL gate.

Sources: the immutable native parent under
`../tls-owned-ssl-construction-20261118/boringssl` and its SDK, with the identities
stated in `contract.md:14–19`. Graphify queries preceded source exploration.
Applied AGENTS.md, CODING_CONVENTION.md, reviewer/crypto_tls instructions,
code-review-and-quality, and the requested structural quality lens with project
overrides. No native, SDK, proof, build, counter, fixture, or publication input
was changed by this reviewer.

## Findings

No actionable findings remain.

The original P2 ALPN/ALPS admission finding is resolved by
`contract.md:72–85`: empty context ALPN is checked separately from empty actual
SSL ALPN and ALPS, and the admitted configuration must remain within its captured
limits during use. This excludes the client EncryptedExtensions path at
`ssl/tls13_client.cc:931–957` from the declared F bound while preserving SQL's
empty-ALPN behavior.

The initialization ambiguity is resolved by `contract.md:119–131,182–186`.
There are nine eager persistent allocations and three full-capacity transient
roles, without probes or caches. Persistent shortage fails binding; transient
shortage fails the later operation. The SDK validates the full twelve-role
plan. This correctly avoids promising future availability from arbitrary
callbacks. Building three temporary BUF_MEM roots and their payloads plus two
record payloads, then reserving the existing transcript payload last before
nonfailing commits, needs no fourth wire descriptor and gives a concrete rollback
order. Implementation must prove that final commit is in fact nonfailing.

## Verification gaps and required follow-through

- The draft is not an executable component ledger. Native implementation must
  still publish checked H/R/T/F/I and E expressions, raw request classes/counts,
  layout changes, constructor bounds, and actual startup/RSS evidence. No
  numeric 0.8 MiB estimate was accepted as a bound.
- The exact role count is source-consistent for the restricted flow: the
  transcript descriptor is constructor-owned; the wire domain supplies the
  other three BUF_MEM descriptors, four BUF payloads, two records, and three
  transient payloads. `ssl_done_writing_client_hello`
  (`ssl/handshake_client.cc:288–292`) resets key-share bytes, and retry setup also
  resets them before its CBB (`ssl/extensions.cc:2395–2397,2466–2492`). Cookie
  copying completes before `next_message`
  (`ssl/tls13_client.cc:274–286,349–356`). These facts need regression evidence;
  the observed fixture peak cannot replace them.
- Preserve CBB's existing ownership bit through bounded capacity and transfer.
  `CBB_finish` transfers the root, clears its pointer, and returns the logical
  length (`crypto/bytestring/cbb.cc:147–178`); the full allocation extent must
  remain available through OPENSSL provenance for cleansing/release. Packing
  with the extra bit has not been compiled/measured.
- `SSLBuffer` ordinary payloads are direct malloc roots
  (`ssl/ssl_buffer.cc:64–86,129–151`). The new explicit owner must prevent
  querying OPENSSL provenance on them. Full-capacity owned record requests and
  releases have not been executed.
- Existing preparation/readiness guards, 5/27 logical KeyUpdate limits,
  empty-buffer semantics, transcript-descriptor rollback, cold ERR controls,
  successful/failed clear/free, SDK 2N stability/teardown, all three suites, and
  DNS/IP/CA/development behavior still require the contract's planned tests.
  `SSL_clear` is destructive (`ssl/ssl_lib.cc:3902–3949`); its failure is not a
  rollback promise.
- No implementation tests or project gates ran for this read-only draft review.
  The full trace grammar/membership derivations were inspected through their
  report, not replayed. The unrelated one-byte cross-fixture CA causal claim in
  `inventory_evidence/REPORT.md` is already assigned to Root for correction and
  does not change paired counter equality.

No actionable ownership or structural defect remains in the proposed twelve-role
contract. This review closes no full-goal gate and does not accept unimplemented
runtime or allocation claims.
