# Independent wire proof review

Result: no actionable findings remain in the frozen proof/build inputs.
The new wire proofs and their recorded ReleaseSafe executions are accepted for
their stated scopes. This is not approval of a total TLS allocation claim, the
strict PostgreSQL gate, or the separately pending inherited/full-suite evidence.

## Exact inputs

All five current files and recorded modes match
`proof_evidence/root_final_wire_inputs.json`, SHA-256
`de1f72f68e89a1b479163d537dde197218234867d9ee6bc775d714dbfe9447ba`:

| Input | SHA-256 |
| --- | --- |
| `proof/wire_public.c` | `078542f6117aa0f50b44348f274464db4434d5d66e1d0b151f546f5da2f031d9` |
| `proof/wire_proof.cc` | `f4b97d1ac0a3d74ae9387de94b96f83b13925edca6f8fd363e1fb0f17b132252` |
| `proof/wire_handshake.cc` | `b21e2432575296da629482c3d2d51b2d6705a9a8b3ee8901af5c73328eda1cae` |
| `proof/wire_test_storage.h` | `66917900f25bbbfa246a469e1e14f70c70c2db1a3c623136e62be7eb5e01bf56` |
| `build.zig` | `03de9578a90a577418feea35a407ca5b3a1262115e89d14008b611304e1eb162` |

The frozen native manifest is
`6fb0396e4a2a2b29d95d109e12f9ce64a52cf708479062a39da245e981a1f766`;
the accepted amended contract is
`34bb38ba77211604d77d725352370bd9874214a68d9c302e84504ebf63265ab9`.
The input manifest also binds the separately reviewed SDK manifest; this pass
does not extend into SDK implementation review.

## Proof assessment

- The storage observer matches wire requests by exact class, checks class shape,
  offsets, stride and counts, records individual live roots, verifies complete
  raw cleansing plus untouched stride padding, and requires balanced release.
  It does not treat the constructor's larger-slot policy as the wire policy.
- Persistent faults cover attempts 1 through 9, preserve the original
  constructor-owned transcript descriptor, require no partial profile and no
  wire liveness, then retry binding with the same storage. Independent generic
  builder and actual framed-HRR faults cover the three transient allocations.
- Twelve simultaneous roles are exercised, not inferred from an allocation/free
  total. Fixed CBB ownership, overflow rejection without a second request,
  CBB-to-Array transfer, role-specific I/T/F limits, record retention and repeated
  two-domain clear/free cycles have assertions.
- Cold process/thread queries count every allocator category and requested
  bytes. The separate cold-thread ERR/RNG control now requires successful
  operations and a nonzero counter observation; final output records one malloc,
  two callocs and 1304 bytes. Context-byte/ERR stability and malformed/overflow
  cases complement the independently reviewed pure helper call graph.
- The C-only public caller and full weak-hook image compile and execute against
  the new declarations; the hook case rejects binding before domain callbacks.
  The ordinary direct-buffer and fixed-input ciphertext differential controls
  remain explicitly allocating controls. The 63-byte counter self-test remains
  intact and passes.
- Final normal handshake rows leave the context immutable and retain preparation
  and KeyUpdate assertions. The three immutable CLIENT/callback resumption rows
  assert unsupported readiness and make no preparation claim. They capture real
  resumable tickets, clear, install a ticket and require both peers to report
  actual session reuse. No automatic callback-ticket adoption is assumed.
- The oversized-cookie check now compares attempts and liveness to captured
  pre-HRR state. The initial ClientHello legitimately retains an encoded
  key-share payload, so assuming nine live blocks at that point was incorrect.
  The exact excessive-size error, no additional attempts and final cleanup
  assertions remain. The initial failed/invalid observations are not accepted as
  successful final evidence.
- Both public fatal-alert regressions retain their original RED observations.
  The final proof checks the same flight roots/live count and zero C operations
  during partial-ClientHello alert forwarding, and rejects binding after an
  unbound direct alert followed by clear, before callbacks.

## Recorded results checked

`proof_evidence/wire_final_combined_build.json` records exit 0 for the combined
`proof wire-proof wire-handshake-build -Doptimize=ReleaseSafe` command. Its raw
log reports 67/67 build steps and all new wire rows pass. The recorded alert
retention changes from RED live 10 -> 8 to GREEN live 10 -> 10 with identical
roots; the alert/clear latch changes from RED successful binding/nine callbacks
to GREEN rejected binding/zero callbacks.

`proof_evidence/wire_handshake_final_run.json` records exit 0. The raw log has 36
compatibility rows: 27 initial handshake completions and nine expected rejection
rows, including three IPv6 identity checks and three additional resumed
handshakes. All three suites, DNS/IPv4, trust/name/protocol rejection,
development verification disabled with wrong trust/name inputs, HRR, fragment
sizes and backpressure are exercised. Nine separately labeled framed-cookie rows
cover one-byte/60000-byte cookies, all three transient faults, second-HRR
rejection and oversized input. They explicitly make no verified-handshake claim.

The executed handshake SHA-256
`3203651f095b97194e29297b2645efe92d670b76897f5fb8b4ab30e926b0bbc4`
matches the current retained binary. The reviewer inspected and reconciled these
recorded results and did not launch another build or fixture run.

## Remaining verification limits

- The separate inherited 26-case Debug and calloc-aware ReleaseSafe campaigns
  are not accepted by this report; their observer compatibility, source/binary
  identities and final results require their own evidence review.
- IPv6 is an actual verified TLS identity over memory BIOs, not an IPv6 socket
  test. Large-cookie cases prove framed processing and echo, not a complete
  authenticated server handshake. Helper boundary tests are not substitutes for
  the separately described real TLS cases.
- These local thread-scoped counters do not replace the original six worker-wide
  PostgreSQL lifecycle intervals. The 43/86 selected-call removal, complete
  remaining allocation families, startup/RSS, live SDK suites, Safe/Fast and
  project format/convention/version gates remain separate delivery obligations.
- No dedicated smoke/security/sanitizer/fuzz campaign ran or was required by
  this review. Configured gates and the user's deferral remain unchanged.
