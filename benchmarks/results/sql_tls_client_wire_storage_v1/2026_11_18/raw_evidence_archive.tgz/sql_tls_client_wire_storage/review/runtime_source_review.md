# Independent wire SDK source review

No actionable findings in the frozen six-file runtime diff or Root's two shared
bindings. Source and the recorded focused nine-test result are accepted within
this scope; full integration and native proof remain pending.

Contract SHA256: `8902628fe58934321c069fe34231b86aadeb82f14652264629f63fefc77f69a3`.
Runtime identity SHA256: `bd55df8e173232b7d57ce3ea98f850636f4d650ab3a12de2897f06c0a5e43ed4`.
Runtime patch SHA256: `9d29478d32e5f8a42b25f4e97d4fea1f4d45f7032d2bbf27661e51c95b560b27`.

Independently verified all 501 immutable parent SDK contents/modes against
identity e9b6135a8da083cbdac2bb51554f15e6602397ba9c05e555c330b61be92372bf.
The candidate contains exactly those source paths plus the two new files, for
503 sources after excluding generated dependency/cache/output directories.
All six runtime hashes match the frozen identity. Existing-file changes are
limited to tls_client, Connection, Db, main test import, Root's conditional
test-support alias and the native-builder path. The eight inherited constructor
tests remain byte-identical. Details: runtime_source_scope_check.json.

Ownership and correctness checks:

- `sdk/src/sql/wire_storage.zig:23` copies the public native record and all
  twelve class entries by value. Neither Storage nor its callbacks borrow a
  Db.init stack table or private native layout formula.
- Lines 34-60 validate positive geometry, power-of-two compatible alignments,
  aligned offsets/strides, checked extent/end/count/metadata arithmetic,
  in-bounds regions, nonoverlap, unique exact raw-size/alignment classes and
  matching block totals. Init checks backing/metadata capacity and base alignment
  before constructing roots. Its per-slot arithmetic is bounded by those checks.
- Lines 96-121 allocate only an exact raw-size/alignment match in an unoccupied
  slot; no larger-class borrowing, heap fallback, growth or waiting exists.
  Release checks owning range, exact root, live state, raw extent and alignment
  before immediate reuse. Invalid native release contracts panic rather than
  mutating unrelated metadata. A copied Storage cannot reacquire its descriptor
  because its context still identifies the original address.
- `sdk/src/sql/db.zig:80` derives wire bytes/count/alignment from the initialized
  context and checks 2N backing/metadata products before allocating. Separate
  normal/cancellation slices are disjoint; descriptors are initialized only
  after their arrays have stable addresses. Startup errdefers unwind every new
  resource and prior resources; no Session exists during that allocation phase.
- `sdk/src/crypto/tls_client.zig:210` binds after SNI, actual ALPN and verification
  identity setup and before publishing SSL/BIO pointers into Session. Errors
  retain existing endpoint/SSL rollback. Ordinary, BIO-only and constructor-only
  paths preserve their previous behavior; wire-only is explicitly supported.
  SQL still requests verified TLS1.3 without ALPN. The actual HTTP ALPN case
  rejects binding before wire callbacks, as required by the new profile.
- `sdk/src/sql/db.zig:264` deinitializes both Session arrays and checks all three
  domains' liveness before releasing any backing/metadata/context. Dormant normal
  and cancellation Sessions may still own wire objects and are included.
  Descriptors remain in Connection while Session resets. No preparation,
  admission, callback, deadline, quarantine, cancellation or interval movement
  occurs in this diff.

The structural lens found no actionable regression. The distinct exact-class
allocator is isolated in a 122-line SQL module rather than a general allocator
framework. Connection adds one field and TLS retains one initialization flow.
Final line counts: tls_client 257, Connection 881, Db 585, new tests 382.
No file crosses the review threshold and no gate is weakened.

Recorded focused evidence was inspected: the SQL+SQLite-enabled exact-filter
command exits zero, with raw summary 23/23 steps and 9/9 tests, without skips.
Tests cover native geometry, malformed/overflow/overlapping geometry, exact-class
exhaustion/reuse, moved storage and by-value copying, all observed binding failure
indices with cleansing/balanced releases/three-owner cleanup, DNS/IPv4/IPv6 and
development setup through repeated clear, actual HTTP ALPN rejection, independent
owners and retained BIO refs, existing initializers, and startup allocation
failures with both dormant Session arrays. The clean missing-module compile RED
is retained separately from the initial invalid defer syntax error; neither is
misrepresented as runtime failure evidence.

Verification gaps:

- The unfiltered 1214-test SDK suite, root live suite, original same-fixture six
  lifecycle intervals, Safe/Fast builds and final combined gates remain pending.
  This reviewer inspected the focused run and did not repeat it.
- These SDK tests establish identity setup and clear behavior, not verified
  handshakes, HRR/cookie/CBB limits, resumption, pure-query effects or complete
  native no-fallback behavior. The separate native source/proof review owns those
  requirements, including the accepted post-clear resumption amendment.
- No SDK death tests execute malformed native release callbacks; the explicit
  root/extent/alignment/liveness failure checks were inspected in source.
- Formatting/convention/version success is recorded by the runtime owner;
  those commands were not independently repeated in this source pass.
- Complete PostgreSQL allocation/capacity, remaining crypto/session/ERR/RNG/thread
  ownership, production publication/pins and other roadmap work stay open.
  Dedicated smoke/security/sanitizer/fuzz campaigns remain user-deferred.

Applied AGENTS.md, CODING_CONVENTION.md, reviewer/specialist instructions,
code-review-and-quality, the scoped structural lens and Zig guidance. Graph-first
queries preceded source exploration. No source, build, proof, runtime record,
parent, pin or publication state was edited; only requested SSD review artifacts
were written. No nested agent or external review CLI was used.
