# Focused SSL_clear and TLS 1.3 resumption contract review

Reviewed base contract SHA-256:
`0c39aaeb956630908242a3d2f5e79b27e041cda19420f6e2ca14677d60901e97`.
Its accepted independent review, `review/contract_review.md`, has SHA-256
`96e2211ff18a0fb85b03c3dd279489537b966bb97b3a0cbf8c55cf933a0bbd9d`.
Final amended contract SHA-256:
`8902628fe58934321c069fe34231b86aadeb82f14652264629f63fefc77f69a3`.
Status: amendment review sealed; no actionable contract findings remain.
Review source is the immutable native parent in
`../tls-owned-ssl-construction-20261118/boringssl`, identity
`4b2feb7f16a45250c88feb1ab57a24fd3ea0196f8cde777cd87c9f8ba54d3699`.
Graphify preceded this focused source traversal. No product or proof inputs were
edited and no executable campaign ran.

## Result

Root's applied amendment is accepted at source level. Preserve the existing
`SSL_clear` session handoff and admit same-profile TLS 1.3 resumption after an
owned clear. Keep the public initial binder fresh and without an explicitly
configured resumption session. The existing twelve serialized-wire roles and
H/R/T/F/I bounds cover the amended flow; no additional wire role was found.

The base contract's broad resumed-session exclusion is resolved in the amended
`contract.md:75–78,231–239`. Initial public binding remains fresh; clear preserves
session behavior, permits pre-I/O same-profile ticket setup, keeps the existing
wire bounds, and requires a genuine resumed witness. No automatic ticket adoption
is introduced. The implementation must not apply the initial fresh-only check
to internal reconstruction or the permitted post-clear handshake.

## Exact source basis

- `ssl/ssl_lib.cc:3908–3935`: `SSL_clear` takes a reference to the prior client
  `s3->established_session`, frees/recreates S3, then calls `SSL_set_session` on
  the reconstructed SSL. Preserve this order and destructive failure behavior.
- `ssl/handshake_client.cc:351–375`: ordinary handshake startup discards expired,
  unusable, wrong-version or wrong-transport sessions through its existing
  policy. Preserve these decisions. `:387–399` uses at most the same maximum
  compatibility session ID already included in H. `:402–419` selects the same
  key-share and ClientHello construction paths.
- `ssl/extensions.cc:1935–1946`: one existing session contributes a reference to
  `hs->pre_shared_keys`. Imported PSK credentials remain excluded by the profile.
  The collection is semantic state, not a serialized-wire payload.
- `ssl/extensions.cc:1980–2081`: the PSK identity (ticket), age, length vectors,
  zero binder and final binder all occupy children or spans of the existing
  ClientHello CBB. The function flushes that root and overwrites the reserved
  binder bytes in place. `:4559–4566` places the PSK extension last in the same
  outer u16 extensions vector. There is no second message CBB or ticket copy in
  this serialization path.
- `ssl/tls13_enc.cc:562–631`: binder generation uses fixed stack byte arrays,
  spans of the existing ClientHello, and a scoped EVP hash context. It calls
  `SSLTranscript::CopyToHashContext`; `ssl/ssl_transcript.cc:143–153` either
  copies the rolling hash or hashes the existing raw buffer. It does not add a
  transcript payload or append the truncated ClientHello to the raw transcript.
  EVP/hash/HKDF allocations remain separate crypto ownership work.
- `ssl/tls13_client.cc:220–223,327–340,364–378`: HRR uses the same synthetic
  message_hash transformation, hashes HRR, filters incompatible PSK hashes and
  builds the second ClientHello through `ssl_add_client_hello`. Key-share and
  cookie lifetimes remain those already reviewed. A mismatched ticket hash can
  remove the PSK; ordinary full-handshake fallback remains covered.
- `ssl/tls13_client.cc:576–608`: a valid selected session sets
  `s3->session_reused=true`, duplicates authentication state, and initializes the
  same key schedule. `ssl/tls13_enc.cc:64–72` frees the raw transcript before
  the final ServerHello is hashed at `ssl/tls13_client.cc:633–635`.
- `ssl/tls13_client.cc:418–423,743–754`: resumed handshakes skip CertificateRequest
  and certificate processing, apart from the existing optional reverify path.
  With early data, ALPN/ALPS and Channel ID absent, the client final flight is
  Finished plus any already queued compatibility CCS, a subset of the declared
  anonymous Certificate+Finished+CCS bound. The Finished message reuses the same
  main message CBB (`ssl/tls13_both.cc:658–675`).

## Bound and ownership implication

H already includes the entire encodable u16 extensions vector, including a PSK
identity, ticket age, vector lengths and binder. A ticket that cannot fit the
outer PSK/extension encoding must retain ordinary encoding failure; do not grow
the owned CBB, add a ticket-sized spare, or truncate the ticket. R remains a
ServerHello syntax/message-ceiling bound. T still holds only first ClientHello,
or synthetic message_hash + HRR + second ClientHello, and binder hashing does not
increase that raw byte sequence. I still follows the existing incoming message
ceiling. P and the two record payload bounds are unchanged. F covers either
resumed Finished output or full fallback output with the same fragment limits.

Ticket/session objects, the `Vector<SSLPreSharedKey>` backing, EVP contexts and
crypto scratch are outside this selected wire family and remain full-goal work.
This amendment is not a claim of allocation-free resumption.

## Accepted wording and pending executable evidence

The current contract applies these reviewed requirements:

1. Separate initial public binding from internal clear reconstruction. Initial
   binding rejects an explicitly configured resumption session. Internal
   reconstruction preserves the domain and allows the normal saved-session
   handoff; same-profile TLS 1.3 resumption must not trip a fresh-only check.
2. Permit ordinary pre-I/O `SSL_set_session` setup on the already-owned SSL after
   a successful clear, using a valid ticket obtained under the same profile.
   Keep no emitted early data, empty ALPN/ALPS, and the captured bounds. Preserve
   ordinary ticket rejection/expiry and full-handshake fallback behavior.
3. Include an actual resumption witness that asserts `SSL_session_reused()==1`
   after completing the second verified TLS 1.3 handshake, along with owned
   storage liveness/teardown and ordinary-client differential behavior. Exercise
   the HRR/second-ClientHello binder path and rejected-PSK fallback through normal
   correctness tests; do not treat successful full fallback as resumed coverage.

The witness needs a real resumable ticket: bare `SSL_clear` does not itself
adopt a newly received TLS 1.3 ticket. `ssl/tls13_client.cc:1375–1385` creates a
separate session and passes it to `new_session_cb`, without replacing
`s3->established_session`. `ssl/ssl_session.cc:457–463` classifies ticketless TLS
1.3 sessions as not resumable. Capture a ticket with the public callback, retain
its reference, call `SSL_clear`, then call `SSL_set_session(ticket)` before I/O
(`ssl/ssl_session.cc:1154–1164`). Preserve a separate bare-clear test to confirm
the original saved-session behavior without inventing ticket adoption. Do not
enable SQL's intentionally discarded tickets merely to obtain this witness.

No actionable contract issue remains in the exact amended revision above. The
executable evidence remains pending; this source-contract acceptance is not
implementation acceptance or a passing full-goal gate. No implementation diff,
compile result, runtime result or source acceptance was inferred from this pass.
