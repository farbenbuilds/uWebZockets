# Independent native wire-storage source review

Result: no actionable source findings in the assigned snapshot. This is source
review acceptance only; runtime proof, combined SDK acceptance and project/full-
goal gates remain pending.

This final review supersedes the earlier acceptance of manifest `0dc463c5…`
and diff `56fcfeb1…`. The pre-alert inputs remain retained as
`native_source_identity_pre_alert.json` and `native_pre_alert.diff`.

## Reviewed identities and scope

- Candidate manifest: `native_evidence/native_source_identity.json`, SHA-256
  `6fb0396e4a2a2b29d95d109e12f9ce64a52cf708479062a39da245e981a1f766`, 8710
  listed files. All sixteen changed candidate files and their recorded modes
  were independently checked against this manifest with no mismatch.
- Reviewed complete diff: `native_evidence/native.diff`, SHA-256
  `9345cf2e348f3d8f8465ff99414cc2546896c7d8a8fc141afe6ca7790480fdef`.
- Immutable parent: `../tls-owned-ssl-construction-20261118/boringssl`, supplied
  full-tree identity
  `4b2feb7f16a45250c88feb1ab57a24fd3ea0196f8cde777cd87c9f8ba54d3699`.
  This review did not independently repeat Root's full-parent tree hash.
- Accepted contract: SHA-256
  `34bb38ba77211604d77d725352370bd9874214a68d9c302e84504ebf63265ab9`, including
  the separately reviewed clear/resumption and narrow alert-path amendments.

Applied AGENTS.md, CODING_CONVENTION.md, reviewer and crypto_tls instructions,
code-review-and-quality and the requested structural quality lens. Graphify
preceded code exploration. No native, SDK, proof, build, counter, fixture or
publication input was changed by this reviewer.

## Source conclusions

The pure query uses constant named-group/cipher lookups and the checked BUF_MEM
growth helper. The H/R/T/F/I expressions remain within the source u24 and u16
ceilings before unchecked constant-size arithmetic; class addition, stride,
count multiplication and total addition are checked. It merges exact raw size
and alignment classes and accounts for all twelve roles
(`ssl/ssl_lib.cc:517–696`, `crypto/buf/buf.cc:39–58`).

The actual-SSL guard is separate from the context guard, admits configured
DNS/IP verification parameters, rejects SSL-only ALPN/ALPS/ECH and compares
actual sizing geometry to the context (`ssl/ssl_lib.cc:756–825`). The nine-block
transaction allocates three temporary descriptors and payloads plus two records
before reserving the existing transcript payload last. Only moves, release and
adoption follow that allocation (`ssl/ssl_lib.cc:708–741`). Its rollback does not
need a fourth descriptor or reassign the constructor-owned descriptor.

Transient message and key-share builders retain CBB ownership while forbidding
growth. Cookie storage retains a separate logical length. Persistent input,
plaintext, flight and transcript paths check their own logical roles before
growth; ordinary record roots remain direct malloc/free roots and are never
provenance-probed. Existing 5/27 logical KeyUpdate guards are preserved despite
larger physical capacities. No additional serialized-wire role or hidden routing
was found in the admitted paths.

`client_wire_io_started` intentionally latches for the lifetime of an SSL,
including across an unowned clear. It is set on the first attempted handshake,
peek/read, write or shutdown, and affects only new public binder admission.
Direct `SSL_send_fatal_alert` now also latches it before dispatch or retry
(`ssl/ssl_lib.cc:1965–1968`), closing the alert-only/clear/rebind gap.
Already-owned clear reconstructs through `tls_new` and the internal preparation
helper, bypassing the public fresh-only guard (`ssl/s3_lib.cc:77–83`). Leaving
the latch set therefore preserves the accepted owned-clear/resumption flow.

The second alert fix preserves the canonical owned flight when `do_tls_write`
forwards a remaining flight into record storage before KeyUpdate preparation
(`ssl/s3_pkt.cc:212–226`). It cleanses the forwarded bytes, clears logical
length/offset and retains both wire allocations. The ordinary release branch and
the independent 5/27 KeyUpdate validation remain unchanged. These two narrow
fixes match `contract.md:219–225` and add no role or bound.

No actionable structural regression was found in the sixteen-path diff. The new
helpers carry allocation bounds or ownership invariants; the CBB capacity bit
and reuse of existing pending fields avoid an additional payload router/cache.

## Verification gaps

- No implementation executable or project gate was run by this reviewer. The
  reported initial 11/11 native compile, 14/14 wire unit result and 9/9 focused
  SDK result were task context for the pre-alert snapshot, not independently
  reproduced or accepted as final evidence. The final rebuild is pending.
- The native source proofs and inherited twenty-five proofs remain pending,
  including cold pure-query effects, malformed profiles, every persistent and
  transient OOM point, full raw cleansing, CBB layout/transfer, exact class
  agreement, failure rollback and repeated successful/failed clear/free.
- Both public alert regressions must pass against this final snapshot: partial
  ClientHello/WANT_WRITE followed by direct fatal alert retains the owned flight
  roots and contents correctly; an unbound direct alert followed by clear must
  not reopen initial binding. Their original failing observations must remain
  part of the evidence rather than being overwritten.
- Actual verified handshakes remain pending for all suites, arbitrary CA,
  DNS/IPv4/IPv6 and development verification behavior, fragmented/coalesced
  bounds, min/max fragments, HRR with cookie and second ClientHello, ordinary
  differential outcomes, backpressure, and genuine post-clear resumption with
  `SSL_session_reused()==1`. An unowned failed-I/O/clear/bind-rejection regression
  should preserve the lifetime-latch intent.
- The same six original worker-wide fixture intervals must still measure the
  claimed 43/86 selected-call removal with unchanged counters, callbacks, pool
  and preparation invariants. Startup/RSS, full live suites, Safe/Fast and
  format/convention/version gates remain delivery obligations. The strict
  PostgreSQL gate remains red until its entire objective is independently met.

Dedicated smoke/security/sanitizer/fuzz campaigns remain user-deferred. This
review did not start them or weaken any configured gate.
