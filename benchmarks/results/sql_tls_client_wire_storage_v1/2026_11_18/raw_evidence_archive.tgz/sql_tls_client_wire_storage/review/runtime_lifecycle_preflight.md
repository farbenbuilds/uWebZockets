# Lifecycle comparison preflight

No actionable findings in Root's compare_lifecycle.py adaptation.
This accepts the comparison's expected target and preserved checks, not a
measured candidate reduction or final suite result. Those runs remain pending.

Reviewed helper SHA256:
`c689f0176d3cb3b7513f835786cb63158674d2dc2fee00f90945e8130266046b`.
Its only differences from the previously reviewed constructor helper are the
expected malloc/free/byte reduction and the corresponding error diagnostic.
Six-round/scenario checks, strict-zero false, complete scope, observed callbacks,
interval equality, callback/pool/preparation/cancellation/generation invariants,
output protection and recorded input hashes are unchanged.

Independently summed the ten selected_wire_storage families in the actual
inventory_evidence/families/families.json. Scopes 2, 3 and 4 each contain exactly
43 mallocs, 0 callocs, 0 reallocs, 43 nonnull frees and 306262 requested bytes.
Scopes 5, 6 and 7 each contain precisely twice that vector. Thus the new expected
43/306262 per construction and the existing one-versus-two construction factors
match the retained inventory, without moving any family into an exception.
The helper still requires the full PostgreSQL allocation result to remain RED.

Actual probe bc552c885af280e4ad6ac7ba0c1b752e6c42ccdb3589f5f0434380ce68d0c159,
counter afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac,
run_lifecycle.py and run_sdk_check.py were rehashed against the immutable
owned-constructor parent and are byte-identical. check_comparison.py is also
byte-identical. The original worker interval and its runtime validation remain
in the unchanged probe/runner. No interval narrowing or callback work exemption
was introduced by this adaptation.

Comparison acceptance uses explicit require/conditional failure, with zero
Python assert statements. Those checks remain active under Python -O. Actual
valid and malformed-report replay will be repeated against final raw reports
after Root's exclusive run rather than manufacturing candidate measurements.

The inventory's exact lifetime limitation remains material: eight new prepared
blocks survive a callback boundary while the corresponding interval frees retire
older blocks. Equal malloc/free removal is not a claim that the new blocks all
die in that same interval, nor a capacity proof. Fresh paired control/candidate
measurements must determine final absolute vectors and verify the target.

Recorded preflight inputs and per-scope sums are in
runtime_lifecycle_preflight.json. Final contract SHA256 is
34bb38ba77211604d77d725352370bd9874214a68d9c302e84504ebf63265ab9;
final SDK identity is
5e2a5c8b807782fbfc095f944b9ac64ef2d48909ed1ad92683a4b88d9f9dfd5f.
Root states runtime source is unchanged from the accepted source review; no
new runtime implementation acceptance is inferred from this helper-only pass.

Pending: final same-fixture six-round raw reports and semantic comparison,
optimized valid/negative controls, unfiltered live SDK 1214/root 1182 results,
raw Safe/Fast evidence and final combined delivery claims. No builds, live
fixture work, source/helper changes, campaigns or nested agents ran in this pass.
Only requested review artifacts were written.
