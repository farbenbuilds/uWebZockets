#!/usr/bin/env python3
"""Exercise optimized-Python restore rejection before output creation."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess


def require(condition, message):
    if not condition:
        raise SystemExit(message)


delivery = Path(__file__).resolve().parent
work = delivery.parent
packet = delivery / 'packet/sql_tls_client_wire_storage'
repo = work.parents[1]
parent = repo / '.zig-cache/tls-owned-ssl-construction-20261118/boringssl'
out = delivery / 'verification/restore_regressions_final'
out.mkdir(parents=True, exist_ok=False)
empty = out / 'empty_parent'
empty.mkdir()
existing = out / 'already_exists'
existing.mkdir()
immutable = out / 'immutable'
immutable.mkdir()
(immutable / 'files.sha256').write_text('')
env = dict(os.environ, PYTHONOPTIMIZE='1')
records = []


def run_case(name, input_packet, input_parent, destination, diagnostic, extra=(), exists_before=False):
    command = ['python3', '-O', str(input_packet / 'restore.py'), '--parent', str(input_parent),
               '--output', str(destination), *extra]
    result = subprocess.run(command, env=env, capture_output=True)
    output = result.stdout + result.stderr
    (out / (name + '.log')).write_bytes(output)
    require(result.returncode != 0 and diagnostic.encode() in output, 'case did not reject as expected: ' + name)
    require(destination.exists() == exists_before, 'negative case created output: ' + name)
    records.append({'name': name, 'command': command, 'optimized_python': True,
                    'exit_code': result.returncode, 'output_created': False,
                    'output_existed_before': exists_before, 'expected_diagnostic': diagnostic})


run_case('wrong_file_set', packet, empty, out / 'bad_set_output', 'source file set differs')
wrong_parent = out / 'wrong_native_parent'
shutil.copytree(parent, wrong_parent, ignore=shutil.ignore_patterns('.git'))
parent_entries = json.loads((packet / 'source_identity/parent_native_identity.json').read_text())['files']
wrong_source = wrong_parent / parent_entries[0]['path']
original_source = wrong_source.read_bytes()
original_mode = wrong_source.stat().st_mode & 0o777
wrong_source.write_bytes(original_source + b'\nchanged native input\n')
run_case('wrong_native_hash', packet, wrong_parent, out / 'bad_parent_output', 'source hash:')
wrong_source.write_bytes(original_source)
wrong_source.chmod(original_mode ^ 0o100)
run_case('wrong_native_mode', packet, wrong_parent, out / 'bad_parent_mode_output', 'source mode:')
shutil.rmtree(wrong_parent)
run_case('wrong_compiler', packet, parent, out / 'bad_compiler_output',
         'compiler hash differs', ('--zig', '/bin/true'))
for name, suffix in [('quote', '"output'), ('backslash', '\\output'), ('control', '\noutput')]:
    run_case('unsupported_' + name, packet, parent, out / suffix, 'must not contain')
run_case('existing_output', packet, parent, existing, 'output already exists', exists_before=True)
run_case('inside_evidence', packet, parent, immutable / 'output', 'outside an evidence artifact')
run_case('inside_parent', packet, parent, parent / 'restore_negative_output', 'output overlaps native parent')
run_case('inside_packet', packet, parent, packet / 'restore_negative_output', 'outside an evidence artifact')

bad = out / 'bad_packet'
shutil.copytree(packet, bad)


def altered_file_case(name, relative, operation, diagnostic):
    path = bad / relative
    original = path.read_bytes()
    mode = path.stat().st_mode & 0o777
    try:
        operation(path)
        run_case(name, bad, parent, out / (name + '_output'), diagnostic)
    finally:
        if path.is_symlink():
            path.unlink()
        path.write_bytes(original)
        path.chmod(mode)


sdk = json.loads((packet / 'source_identity/sdk_final_source_identity.json').read_text())['files'][0]['path']
overlay = json.loads((packet / 'source_identity/native_source_identity.json').read_text())['changed_paths'][0]
proof_entries = json.loads((packet / 'source_identity/final_proof_identity.json').read_text())['proof_files']
proof = next(entry['path'] for entry in proof_entries if entry['path'].startswith('proof/'))
replay = 'lifecycle_consumer/probe.zig'


def corrupt(path):
    path.write_bytes(path.read_bytes() + b'\ncorrupted restore test input\n')


def change_mode(path):
    path.chmod((path.stat().st_mode & 0o777) ^ 0o100)


for name, relative in [('sdk', 'sdk/' + sdk), ('candidate', 'candidate_files/' + overlay),
                       ('proof', proof), ('proof_build', 'build.zig'), ('replay', replay)]:
    altered_file_case('wrong_' + name + '_hash', relative, corrupt, 'source hash:')
    altered_file_case('wrong_' + name + '_mode', relative, change_mode, 'source mode:')


def linked_sdk(path):
    path.unlink()
    path.symlink_to(packet / 'sdk' / sdk)


altered_file_case('linked_sdk', 'sdk/' + sdk, linked_sdk, 'source symlink:')
for name, folder, diagnostic in [('sdk', 'sdk', 'source file set differs'),
        ('candidate', 'candidate_files', 'source file set differs'), ('proof', 'proof', 'proof file set differs'),
        ('replay', 'lifecycle_consumer', 'lifecycle source file set differs')]:
    extra = bad / folder / 'unexpected_source_input'
    extra.write_text('extra source input\n')
    try:
        run_case('extra_' + name + '_file', bad, parent, out / ('extra_' + name + '_output'), diagnostic)
    finally:
        extra.unlink()


def unsafe_identity(path):
    value = json.loads(path.read_text())
    value['files'][0]['path'] = '../unsafe_source'
    path.write_text(json.dumps(value))


altered_file_case('unsafe_sdk_identity', 'source_identity/sdk_final_source_identity.json',
                  unsafe_identity, 'unsafe identity path:')


def changed_manifest(path):
    lines = path.read_text().splitlines()
    expected, name = lines[0].split('  ', 1)
    lines[0] = ('0' if expected[0] != '0' else '1') + expected[1:] + '  ' + name
    path.write_text('\n'.join(lines) + '\n')


altered_file_case('wrong_packet_manifest', 'files.sha256', changed_manifest, 'packet hash:')
altered_file_case('wrong_public_evidence_hash', 'contract.md', corrupt, 'proof contract binding differs')
def wrong_proof_binding(path, field):
    value = json.loads(path.read_text())
    value[field] = '0' * 64
    path.write_text(json.dumps(value) + '\n')


altered_file_case('wrong_proof_sdk_binding', 'source_identity/final_proof_identity.json',
                  lambda path: wrong_proof_binding(path, 'sdk_identity_sha256'), 'proof SDK identity binding differs')
altered_file_case('wrong_proof_contract_binding', 'source_identity/final_proof_identity.json',
                  lambda path: wrong_proof_binding(path, 'contract_sha256'), 'proof contract binding differs')
for name, operation, diagnostic in [('missing', lambda path: path.unlink(), 'source is not a regular file:'),
        ('hash', corrupt, 'source hash:'), ('mode', change_mode, 'source mode:')]:
    altered_file_case('auxiliary_plan_' + name, 'proof_evidence/wire_inherited_plan.json', operation, diagnostic)
shutil.rmtree(bad)
record = {'helper_sha256': hashlib.sha256((packet / 'restore.py').read_bytes()).hexdigest(),
          'negative_cases': records, 'all_rejected': True, 'case_count': len(records)}
(out / 'results.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'negative_cases': len(records), 'all_rejected': True}))
