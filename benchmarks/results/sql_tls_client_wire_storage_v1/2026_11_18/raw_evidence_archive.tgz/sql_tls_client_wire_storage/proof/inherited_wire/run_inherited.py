#!/usr/bin/env python3
"""Rebuild the exact retained TLS component inputs against supplied candidate libraries."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cases(path):
    tree = ast.parse(path.read_text())
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'CASES' for t in node.targets):
            return ast.literal_eval(node.value)
    raise ValueError('retained lifecycle case list missing: ' + str(path))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work', type=Path, required=True)
    parser.add_argument('--native-prefix', type=Path, required=True)
    parser.add_argument('--fixture', type=Path, required=True)
    parser.add_argument('--zig', type=Path, required=True)
    parser.add_argument('--global-cache', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--calloc-aware-faults', action='store_true')
    args = parser.parse_args()
    work = args.work.resolve(strict=True)
    inputs = Path(__file__).resolve().parent / 'inputs'
    output = args.output.absolute()
    if output.exists() or output.is_symlink() or output.resolve().is_relative_to(inputs):
        raise ValueError('choose an absent output outside immutable inputs')
    plan = json.loads((work / 'proof_evidence/wire_inherited_plan.json').read_text())
    identities = {(inputs / Path(archive['path']).parent.parent.name / item['member']).resolve(): item['sha256']
                  for archive in plan['archives'] for item in archive['members']}
    if any(sha(path) != digest for path, digest in identities.items()):
        raise ValueError('inherited input differs from final archive manifest')
    native = work / 'boringssl'
    libs = [args.native_prefix.resolve(strict=True) / 'lib/libssl.a',
            args.native_prefix.resolve(strict=True) / 'lib/libcrypto.a']
    if any(not path.is_file() for path in libs):
        raise ValueError('Root must install matching candidate SSL and crypto libraries first')
    fixture = [args.fixture.resolve(strict=True) / name for name in ['server.pem', 'server.key', 'ca.pem']]
    if any(not path.is_file() for path in fixture):
        raise ValueError('fixture requires server.pem, server.key and ca.pem')
    output.mkdir(parents=True)
    environment = dict(os.environ, ZIG_GLOBAL_CACHE_DIR=str(args.global_cache.resolve()),
                       ZIG_LOCAL_CACHE_DIR=str(output / 'zig-cache'), PYTHONDONTWRITEBYTECODE='1', PYTHONOPTIMIZE='0')
    zig = str(args.zig.resolve(strict=True))
    commands = []

    def run(command, stem):
        command = [str(value) for value in command]
        with (output / (stem + '.stdout')).open('w') as stdout, (output / (stem + '.stderr')).open('w') as stderr:
            result = subprocess.run(command, cwd=output, env=environment, stdout=stdout, stderr=stderr, timeout=60)
        commands.append({'command': command, 'exit_code': result.returncode, 'stdout': stem + '.stdout', 'stderr': stem + '.stderr'})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode != 0:
            raise RuntimeError(stem + ' failed: ' + str(result.returncode))
        return output / (stem + '.stdout')

    includes = ['-isystem', str(work), '-isystem', str(native), '-isystem', str(native / 'include')]
    cpp = [zig, 'c++', '-std=c++17', '-O0', '-g0', '-UNDEBUG', '-fno-omit-frame-pointer',
           '-Wall', '-Wextra', '-Werror', '-DBORINGSSL_IMPLEMENTATION', *includes]
    cflags = [zig, 'cc', '-std=c11', '-O0', '-g0', '-UNDEBUG', '-Wall', '-Wextra', '-Werror',
              '-fno-builtin', *includes]
    ku = inputs / 'sql_tls_ku_output_v1'
    ready = inputs / 'sql_tls_readiness_v1'
    helper = ku / 'helper'
    aead = helper / 'regressions/aead'
    hs = helper / 'regressions/hs'
    record = helper / 'regressions/inherited_record'
    hkdf = helper / 'regressions/inherited_hkdf'
    layout = run([*cpp, '-Xclang', '-fdump-record-layouts', '-c', aead / 'layout_probe.cc', '-o', output / 'layout.o'], 'layout')

    def aead_record(text):
        match = re.search(r'^\s*0 \| class bssl::SSLAEADContext\n', text, re.M)
        if match is None:
            raise ValueError('SSLAEADContext compiler record missing')
        return text[match.start():text.find('\n\n', match.start())]

    if aead_record(layout.read_text()) != aead_record((aead / 'baseline_layout.stdout').read_text()):
        raise ValueError('pinned AEAD layout changed; do not adjust the retained assertion')
    source = (native / 'ssl/ssl_lib.cc').read_text()
    start = source.index('static size_t client_storage_digest_size(')
    end = source.index('\nenum ssl_client_storage_readiness_t ', start)
    expected_mapping = 'BSSL_NAMESPACE_BEGIN\n' + source[start:end] + '\nBSSL_NAMESPACE_END\n'
    mapping = ready / 'native/predicates_final_v3/source/digest_mapping.h'
    if mapping.read_text() != expected_mapping:
        raise ValueError('archived digest helper differs from candidate source; review required')
    entries = [
        ('output_direct', helper/'output_direct.cc', [helper/'allocation_scope.c'], [], None),
        ('output_failures', helper/'output_failures.cc', [helper/'allocation_scope.c', helper/'seal_fault.c'], [], 'EVP_AEAD_CTX_seal_scatter'),
        ('output_lifecycle', helper/'output_lifecycle.cc', [helper/'hs_fault_alloc.c'], [], None),
        ('aead_direct', aead/'aead_direct.cc', [aead/'allocation_scope.c'], [], None),
        ('aead_init_failures', aead/'aead_init_failures.cc', [aead/'allocation_scope.c', aead/'aead_inject.c'], [], 'EVP_AEAD_CTX_init_with_direction'),
        ('aead_transitions', aead/'aead_transitions.cc', [aead/'allocation_scope.c'], [], None),
        ('aead_lifecycle', aead/'aead_lifecycle.cc', [aead/'hs_fault_alloc.c', aead/'aead_inject.c'], [], 'EVP_AEAD_CTX_init_with_direction'),
        ('hs_buffer_helper', hs/'hs_buffer_helper.cc', [hs/'allocation_scope.c'], ['-DUWZ_HS_RESERVATION=1'], None),
        ('hs_lifecycle', hs/'hs_lifecycle.cc', [hs/'hs_fault_alloc.c'], [], None),
        ('buffer_test', record/'buffer_test.cc', [record/'buffer_allocation_scope.c', record/'cleansed_free_hook.c'], [], None),
        ('tls_pair_test', record/'tls_pair_test.cc', [record/'buffer_allocation_scope.c', record/'cleansed_free_hook.c'], [], None),
        ('record_lifecycle', record/'lifecycle_test.cc', [record/'lifecycle_alloc.c'], [], None),
        ('hkdf_witness', hkdf/'hkdf_witness.cc', [hkdf/'allocation_scope.c'], [], None),
        ('key_update_witness', ku/'wire/key_update_witness.cc', [ku/'wire/allocation_scope.c'], ['-DUWZ_RESERVE_KEY_UPDATE_OUTPUT=1'], None),
        ('protocol_witness', ku/'wire/protocol_witness.cc', [ku/'wire/allocation_scope.c'], ['-DUWZ_RESERVE_KEY_UPDATE_CONTEXT=1','-DUWZ_RESERVE_KEY_UPDATE_OUTPUT=1'], None),
        ('control_witness', ku/'wire/control_witness.cc', [ku/'wire/allocation_scope.c'], ['-DUWZ_RESERVE_KEY_UPDATE_CONTEXT=1','-DUWZ_RESERVE_KEY_UPDATE_OUTPUT=1'], None),
    ]
    for name, directory in [('conformance','conformance_final'), ('guards','guards_final'),
                            ('predicates','predicates_final_v3'), ('faults','faults_final'), ('initial','initial_final')]:
        folder = ready / 'native' / directory / 'source'
        counter = folder / ('ticket_fault.c' if name == 'faults' else 'allocation_scope.c')
        if name == 'faults' and args.calloc_aware_faults:
            counter = work/'proof_evidence/wire_calloc_fault_observer.c'
        entries.append(('readiness_' + name, folder/('readiness_' + name + '.cc'), [counter], ['-fno-access-control'], None))
    entries.extend([
        ('readiness_baseline', ready/'wire/readiness_witness.cc', [ready/'wire/allocation_scope.c'], [], None),
        ('readiness_wire', ready/'wire/query_extended_witness.cc', [ready/'wire/allocation_scope.c'], ['-DUWZ_READINESS_API=1'], None),
        ('runtime_controls', ready/'runtime_controls/measured/source/runtime_controls.cc', [ready/'runtime_controls/measured/source/allocation_scope.c'], [], None),
        ('purity_allocator_only', ready/'purity/final_pure/purity_witness.cc', [ready/'purity/final_pure/allocation_scope.c'], ['-DUWZ_ONCE_OBSERVER=0'], None),
        ('purity_once_observed', ready/'purity/final_pure/purity_witness.cc', [ready/'purity/final_pure/allocation_scope.c', ready/'purity/final_pure/once_observer.cc'], ['-DUWZ_ONCE_OBSERVER=1'], None),
    ])
    objects = {}
    for name, main_source, support, flags, wrap in entries:
        compiled = []
        for path in support:
            if path not in objects:
                obj = output / ('support_' + str(len(objects)) + '.o')
                run([*(cpp if path.suffix == '.cc' else cflags), '-iquote', str(ready/'native/faults_final/source'), '-c', path, '-o', obj], 'compile_support_' + str(len(objects)))
                objects[path] = obj
            compiled.append(objects[path])
        binary = output / name
        if wrap is None:
            run([*cpp, *flags, main_source, *compiled, *libs, '-pthread', '-s', '-o', binary], 'build_' + name)
            continue
        obj = output / (name + '.o')
        run([*cpp, *flags, '-c', main_source, '-o', obj], 'compile_' + name)
        run([*cpp, helper/'layout_probe.cc', '-v', '-s', '-o', output/'link_probe'], 'link_template_' + name)
        stderr = (output / ('link_template_' + name + '.stderr')).read_text()
        line = next(line for line in stderr.splitlines() if line.startswith('ld.lld '))
        arguments = shlex.split(line)[1:]
        arguments[arguments.index('-o') + 1] = str(binary)
        indexes = [index for index, token in enumerate(arguments) if token.endswith('.o') and Path(token).name not in ('crt1.o','crti.o','crtn.o')]
        if len(indexes) != 1:
            raise ValueError('unexpected Zig link-template object inventory')
        index = indexes[0]
        arguments[index:index+1] = [str(obj), *map(str, compiled), *map(str, libs)]
        run([zig, 'ld.lld', *arguments, '--wrap=' + wrap], 'build_' + name)
    private_fixture = output/'ephemeral-pki'
    private_fixture.mkdir(mode=0o700)
    original_fixture = fixture
    fixture = [private_fixture/name for name in ['server.pem','server.key','ca.pem']]
    try:
        for original, destination in zip(original_fixture, fixture):
            with destination.open('xb') as handle:
                os.chmod(destination, 0o600)
                handle.write(original.read_bytes())
        for name in ['output_direct','output_failures','aead_transitions','tls_pair_test','readiness_conformance','readiness_guards','readiness_faults','runtime_controls']:
            run([output/name, *fixture], 'run_' + name)
        for name in ['aead_direct','aead_init_failures','buffer_test','readiness_predicates','readiness_initial']:
            run([output/name], 'run_' + name)
        for name, recipe in [('output_lifecycle',helper/'run_lifecycle.py'),('aead_lifecycle',aead/'run_lifecycle.py'),
                             ('hs_lifecycle',hs/'run_lifecycle.py'),('record_lifecycle',record/'run_cases.py')]:
            for case in cases(recipe):
                run([output/name, *fixture, case], 'run_' + name + '_' + case)
        run([output/'hs_buffer_helper', *fixture, '--require-zero'], 'run_hs_buffer_helper')
        run([output/'hkdf_witness', '--require-zero'], 'run_hkdf_witness')
        run([sys.executable, '-B', hkdf/'compare_results.py', hkdf/'prior_baseline.stdout', output/'run_hkdf_witness.stdout'], 'verify_hkdf_differential')
        run([output/'key_update_witness', *fixture, output/'key_update_operations.csv', output/'key_update_summary.jsonl', '--require-zero'], 'run_key_update_witness')
        protocol = output/'protocol_data'; protocol.mkdir()
        run([output/'protocol_witness', *fixture, protocol/'operations.csv', protocol/'summary.jsonl'], 'run_protocol_witness')
        run([sys.executable, '-B', ku/'wire/verify_protocol.py', protocol], 'verify_protocol_witness')
        run([output/'control_witness', *fixture, output/'controls_operations.csv', output/'controls_summary.jsonl'], 'run_control_witness')
        run([sys.executable, '-B', ku/'wire/verify_controls.py', output, '--operations', 'controls_operations.csv', '--summary', 'controls_summary.jsonl', '--key-update-reserved', '--key-update-output-reserved'], 'verify_control_witness')
        for name, folder in [('readiness_baseline','baseline_primary'),('readiness_wire','query_final')]:
            target = output/folder; target.mkdir()
            run([output/name, *fixture, target/'operations.csv', target/'events.jsonl', target/'states.jsonl', target/'summary.jsonl'], 'run_' + name)
        for observer in ['allocator_only','once_observed']:
            for suite in ['0x1301','0x1302','0x1303']:
                for mode in ['observe','strict']:
                    stem = 'run_purity_' + observer + '_' + suite + '_' + mode
                    run([output/('purity_'+observer), *fixture, suite, output/(stem+'.jsonl'), mode], stem)
    finally:
        for path in fixture:
            if path.exists():
                path.unlink()
        private_fixture.rmdir()
    for folder in ['baseline_primary','query_final']:
        (output/folder/'result.json').write_text(json.dumps({'complete':True,'private_pki_removed':not private_fixture.exists()})+'\n')
    verifier = Path(__file__).resolve().parent/'verify_readiness_wire_safe.py' if args.calloc_aware_faults else ready/'wire/verify_wire.py'
    run([sys.executable, '-B', verifier, output], 'verify_readiness_wire')
    if any(sha(path) != digest for path, digest in identities.items()):
        raise ValueError('immutable inherited source changed during execution')
    result = {'complete':True,'executables':len(entries),'commands':len(commands),'candidate_libraries':{str(path):sha(path) for path in libs},
              'compiler_sha256':sha(Path(zig)),'source_manifest_sha256':sha(work/'proof_evidence/wire_inherited_plan.json'),
              'optimization':'Debug harness -O0 -UNDEBUG; supplied candidate native library optimization recorded by Root',
              'readiness_verifier_sha256':sha(verifier),'calloc_aware_fault_observer':args.calloc_aware_faults,'fault_observer_sha256':sha(work/'proof_evidence/wire_calloc_fault_observer.c') if args.calloc_aware_faults else None,'pinned_AEAD_layout_unchanged':True,'archived_digest_helper_matches_candidate':True,'source_members_unchanged':len(identities),
              'ordinary_allocator_counter_and_fault_observers_separate':True,'owned_fixture_copies_removed':not private_fixture.exists(),'whole_handshake_zero_claim':False}
    (output/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
