# Complete client wire-storage ownership

Status: Root resolves independent contract findings below; final review pending.
No product source edits.
The active objective remains all v2.3.0 requirements in TODO.md, including the
complete PostgreSQL allocation gate and other open roadmap work.

## Authoritative parent and actual remaining work

Previous turn is verified progress: ab28afaf4a5ada3ec9c5630db5a52748ea40252d is
committed and server-verified on origin/impl/implement-2.3.0. Main and protected
vendor state remain read-only. SQLite SQL-ALLOC-001 does not apply to PostgreSQL.

The complete immutable native parent is ../tls-owned-ssl-construction-20261118/
boringssl, 8709 source files, identity
4b2feb7f16a45250c88feb1ab57a24fd3ea0196f8cde777cd87c9f8ba54d3699.
Its SDK contains 501 source files, identity
e9b6135a8da083cbdac2bb51554f15e6602397ba9c05e555c330b61be92372bf.
Root has verified all parent and fresh local copies by bytes and Git modes.
No source ancestor, production pin, new remote or publication may change.

Fresh paired observation uses the unchanged counter and worker-wide intervals.
All six functional cases match. Each failure round counts 242 mallocs, 2 callocs,
244 frees and 340927 requested bytes; cancellation doubles those totals. No
realloc occurs. Accepted full trace and exact event/group/lifetime membership
are retained under inventory_evidence; no trace-completeness gate is weakened.

The selected actual wire family per new connection is:

| Family | Mallocs/frees | Requested bytes |
|---|---:|---:|
| Transcript payload | 1 | 1896 |
| Incoming hs_buf | 4 | 1516 |
| Pending flight | 7 | 2456 |
| Pending handshake plaintext | 2 | 112 |
| Outgoing message CBB | 9 | 5235 |
| Serialized key-share CBB/Array | 5 | 3860 |
| Initial record input growth | 7 | 1565 |
| Post-handshake input reservation | 2 | 158424 |
| Two record reservations | 2 | 131070 |
| KeyUpdate output reservation | 4 | 128 |
| Total | 43 | 306262 |

The trace contains HRR and a second ClientHello. Eight new prepared blocks
survive the callback boundary; observed frees retire older blocks. The observed
peak is neither a capacity bound nor proof of same-interval release. Target
removal is 43 mallocs/frees per failure and 86 per cancellation, with original
scope/callback/pool semantics unchanged; final measured values are authoritative.

## Scope and admission

Own this entire family through initial handshake, HRR, preparation, established
reuse and clear/free. Include HRR cookie bytes even when this fixture sends no
cookie. Keep constructor and BIO budgets separate. No hidden owner/router,
global/thread allocator, finite spare SSL stock, admission pause, delayed
callback/destruction, heap fallback or narrowed accounting is permitted.

Preserve every currently exposed SQL TLS option: TLS1.3, arbitrary caller CA
bundles, verified DNS/IPv4/IPv6 identity and no HTTP ALPN, plus the existing common
client development verify=false behavior. Ordinary native APIs keep their
behavior when the new owned profile is disabled.

The new profile additionally requires a TLS1.3-only untouched client, no emitted
early data, Channel ID, ECH/ClientHelloInner/ECH GREASE, credential-adding cert
callback, alternate certificate-compression builder or extension-permutation
storage. Reuse the constructor clone-shape guards where applicable. Legal
cipher/group IDs, flags lengths, uniqueness/encodability and arithmetic must be
checked without ERR insertion. TLS cipher GREASE and fallback SCSV are admitted
and included in sizing. Arbitrary trust contents and verification scalars/flags/
depth and read-only observation callbacks remain admitted.

The context query requires empty context ALPN. The binder independently requires
empty actual-SSL ALPN and application-settings (ALPS) configuration. SSL-only
ALPS must not slip through a context-only guard and add a client
EncryptedExtensions flight absent from F. The initial public binder excludes
resumed session/early-data state: currently exposed SQL connections start fresh.
Same-profile TLS1.3 resumption after clear is supported as described below.
These exclusions do not change ordinary entry points.

The query validates context configuration; the binder validates the actual SSL
configuration after SNI/name/protocol setup. Configured SSL DNS/IP parameters
must not be rejected by blindly applying the context's empty-identity clone
predicate. Configuration must remain admitted and within captured limits during
use. Max send fragments throughout 512..16384 are covered. Any new ordering or
mutation restriction is documented for this profile; no ordinary setter is
silently clamped to an easier budget.

## Additive native interface and explicit ownership

In include/openssl/ssl.h define named flat records:

```c
#define SSL_CLIENT_WIRE_STORAGE_MAX_CLASSES 12
typedef struct ssl_client_wire_storage_class_st {
  size_t raw_bytes;
  size_t alignment;
  size_t stride;
  size_t offset;
  size_t count;
} SSL_CLIENT_WIRE_STORAGE_CLASS;
typedef struct ssl_client_wire_storage_requirements_st {
  size_t bytes;
  size_t alignment;
  size_t class_count;
  size_t block_count;
  SSL_CLIENT_WIRE_STORAGE_CLASS classes[SSL_CLIENT_WIRE_STORAGE_MAX_CLASSES];
} SSL_CLIENT_WIRE_STORAGE_REQUIREMENTS;

int SSL_client_wire_storage_requirements(
    const SSL_CTX *ctx, SSL_CLIENT_WIRE_STORAGE_REQUIREMENTS *out);
int SSL_set_client_wire_storage_domain(
    SSL *ssl, const OPENSSL_ALLOCATION_DOMAIN *domain);
```

The query has no allocation, ERR, hooks, RNG, once/thread initialization,
callbacks, reference mutation, clock or I/O effects. Null output fails;
accessible output is completely zero on failure. Check all bounds before
publishing output. Never call existing invalid-input helpers that push ERR.

Bind only a configured fresh TLS1.3 client before its first TLS I/O. An attached
empty BIO is allowed. Reject malformed descriptors, unsupported profile,
incompatible hooks and repeated/late binding before callbacks. Binding initializes
the nine persistent roles at full capacity and commits only on success. The
three transient CBB/key-share/cookie roles allocate at full capacity on use;
there are no probe allocations or extra native caches. A domain may reject an
operation: persistent shortage fails binding, transient shortage fails that
later bounded operation. Arbitrary callbacks cannot promise future availability.
The SDK validates and supplies the entire twelve-role plan before binding.
All failures have no heap fallback. Bind failure releases all new wire blocks
and leaves no active partial profile; the existing constructor-owned descriptor
remains correctly owned/freeable. Cold ERR allocation is a separate control,
never silently warmed inside a claimed cold operation.

Store a documented explicit owner/profile on SSLImpl and propagate it to the
transcript and SSLBuffer objects. New native fields are permitted; report
measured object/layout/ordinary-request changes and updated constructor bounds.
Do not hide owners or roles in payload/prefix formats. Exact-root provenance
lookups retain the established hook-first rule. The domain descriptor, callbacks,
backing and metadata survive the last wire release, including clear failure.

## Native bound ledger and fixed classes

Derive component expressions from actual source constants. No private formula,
object/header size or numeric total is copied into Zig.

- M=max(SSL3_RT_MAX_PLAIN_LENGTH,max_cert_list), preserving the existing u24 body
  ceiling and setters. Incoming I=M+(SSL3_HM_HEADER_LENGTH-1)+16384 includes an
  incomplete message followed by a full coalesced record.
- H consists of the handshake header, legacy version, random, maximum session
  ID, uint16 cipher vector, one compression method and a full uint16 extension
  vector. C counts actual TLS1.3 ciphers plus enabled GREASE/fallback entries.
- R=min(M+handshake_header,maximum encoded ServerHello). T covers a synthetic
  message_hash plus HRR plus second ClientHello, and at least the first H.
  Raw transcript is freed before the final ServerHello is hashed; certificate
  chain bytes do not accumulate in it.
- F=max(ClientHello null-cipher record flight at minimum fragment512 plus CCS,
  anonymous Certificate+Finished flight with actual cipher overhead and CCS).
  Do not assume the second expression fits without checking it.
- P=SSL3_RT_MAX_PLAIN_LENGTH. Cookie/key-share payloads each use UINT16_MAX.

Preserve BUF_MEM growth geometry via one checked pure helper shared with real
reserve: E(x)=4*((x+3)/3). Check addition/multiplication overflow. Explicit-domain
first payload reserve must not infer its owner from the separately constructor-
owned transcript descriptor.

Use the actual source ceilings: kMaxHandshakeSize=(1u<<24)-1, configured setter
clamping, u24 parser length and max(16384,max_cert_list) client message bound.
Reject impossible raw configuration or overflow before callbacks. Query sizing
and actual SSL settings must agree for fields affecting H/I/T/F; the SDK makes
no per-SSL sizing overrides. A captured max_cert_list is not silently raised or
reclamped after binding. Source-reviewed pure validation uses NamedGroups and
known cipher identities without calling ERR-producing version/cipher helpers.

Twelve simultaneous roles before equal-class merging:

1. Three BUF_MEM descriptors: input, pending plaintext, pending flight.
2. Four full-capacity payloads: E(I), E(T), E(P), E(F).
3. Two SSLBuffer payloads of 65535 bytes each, derived from its actual capacity
   and alignment constants.
4. Main message CBB payload H; key-share payload UINT16_MAX; cookie payload
   UINT16_MAX, with Array logical lengths retained separately from backing.

The nine persistent binding allocations are three descriptors, the four
BUF_MEM payloads (including transcript) and two records. Build temporary roots/
payloads and records first; reserve the existing transcript descriptor's payload
last, followed only by nonfailing commits, so rollback needs no fourth wire
descriptor. Transient payload classes remain unoccupied until their operations.

Current SSLBuffer uses direct malloc(65535), with no OPENSSL prefix. Ordinary
buffers continue direct release. Owned buffers use the explicit memory domain
and OPENSSL release, with correct raw extents/cleansing. Do not inspect an
ordinary direct-malloc base as an OPENSSL provenance root.

Use GetAllocationDomainRequirements for every owned request. Merge only exact
(raw_bytes,alignment) matches; sum proven live-role counts. Compute checked
stride, offset, block_count and total bytes. The SDK matches exact classes,
never best-fit. Full-capacity buffers/builders and role-specific pre-growth
checks eliminate realloc overlap. Raw-size matching alone does not justify a
wrong role borrowing another class after overgrowth. Prove key-share retry
reset order; if legitimate overlapping versions exist, adjust the ledger rather
than changing protocol behavior to force the count.

CBB root bookkeeping is embedded in public CBB.u.base. A named fixed_capacity
bit distinguishes full-capacity owned builders. Ordinary initializers clear it;
the private bounded-owned initializer sets it; reserve rejects beyond cap before
realloc. Existing can_resize ownership semantics govern cleanup/finish, including
CBB-to-Array transfer. Verify actual layout; do not assume unchanged packing.

Default startup cost is expected near 0.8 MiB per physical connection, roughly
12–25 MiB for 2N=16–32; actual native query and startup/RSS evidence are required.
This is this family's budget, not a total TLS capacity proof.

## Canonical lifecycle and preparation

Retain the owned input/pending buffers and records while clearing logical
lengths at the same protocol transitions. Preserve all readiness/pending-state,
cipher, callback and borrowed-data conditions.

Root-authorized alert-path amendment: an application or alert write forwarding
an owned pending flight retains its descriptor and payload even before
KeyUpdate output preparation. After copying to record storage, cleanse the
forwarded flight bytes and clear its logical length/offset. Ordinary paths and
the existing 5/27 KeyUpdate checks retain their behavior. A direct public
SSL_send_fatal_alert is a first TLS I/O attempt; its lifetime binding latch
survives SSL_clear even if no handshake call preceded the alert.

KeyUpdate preparation already assigns its two descriptors/data directly to the
same s3->pending_hs_data and s3->pending_flight fields. Reuse these existing EMPTY
fields after every original check; no aliases or buffer merging are needed.
Preserve the 5/27 logical output limits and set key_update_output_cipher only
after validation. AEAD spares/candidates remain separate crypto ownership work.

SSL_clear releases old S3 wire objects before reconstructing the same explicit
profile. Preserve existing destructive failure semantics: cleanup/freeability,
not rollback to old connection state. No permanent generation/bump cursor grows
with clear. Free releases exact owners immediately, including empty retained
buffers; metadata is not reset merely because a connection phase is dormant.

Preserve ordinary clear/session semantics. An already-owned cleared SSL can
install a valid same-profile TLS1.3 ticket with SSL_set_session before I/O;
ALPN/ALPS/early-data restrictions and captured sizing limits still hold. PSK
identity/binder bytes use the existing main ClientHello CBB and full extension
budget. Binder hashing uses stack/EVP crypto state, not another wire role;
resumed Finished(+CCS) fits F. No automatic adoption of callback-delivered tickets
is introduced. The actual resumed witness must capture a resumable ticket via
new_session_cb, clear, install it, complete verification and require
SSL_session_reused()==1. Bare clear alone is not such a witness.

## SDK integration and permitted source paths

New src/sql/wire_storage.zig owns named requirements/class/block/storage types.
Validate checked shape/ranges/nonoverlap/alignment and metadata count. Copy
requirements into stable storage; no slice may borrow a Db.init stack value.
Exact-class allocation and exact-root release perform no allocation or I/O.

Each stable normal and cancellation Connection owns its wire descriptor outside
Session. Db queries after ClientContext initialization, checks 2N bytes and block
metadata totals, initializes in place and covers every startup-failure path.
Add wire to the existing named SessionDomains input, preserving ordinary and
BIO/constructor-only initializers. Bind after identity/protocol configuration,
before TLS I/O. Existing preparation, admission, deadlines, pool, callbacks,
quarantine and teardown order stay intact. Destroy both Session arrays before
wire/constructor/BIO backing and context. No production adoption occurs here.

Native paths: include/openssl/{ssl.h,bytestring.h}; crypto/bytestring/
{cbb.cc,internal.h}; crypto/buf/buf.cc and new internal.h; ssl/{ssl_lib.cc,
internal.h,s3_lib.cc,ssl_transcript.cc,s3_both.cc,s3_pkt.cc,tls_method.cc,ssl_buffer.cc,
extensions.cc,tls13_client.cc}. Additional paths need Root approval. Review
handshake_client.cc,tls13_enc.cc,tls13_both.cc,ssl_versions.cc,ssl_key_share.cc
for exact ledger and helper boundaries even if unchanged.

SDK runtime paths: src/crypto/tls_client.zig; src/sql/{wire_storage.zig,
connection.zig,db.zig}; centralized tests/main import. Root serializes shared
src/test_support.zig and builds/vendor/boringssl.zig edits. Native, runtime,
verification and delivery owners do not modify each other's source inputs.

## Evidence order and acceptance

1. Independent contract/bound/lifetime review, then Root freezes scope.
2. Actual parent counter/stack RED already retained. Capture any new missing
   interface or operation-specific RED before implementation.
3. Implement complete native family plus stable SDK storage; verify exact native
   query/allocator agreement, no role overgrowth/fallback, all OOM cleanup sites.
4. Test pure cold query, invalid profiles/overflow, full raw cleansing, every
   binding/CBB/cookie failure, fragmented/coalesced limit edges, HRR/large cookie/
   second ClientHello/rejected second HRR, min/max fragments, backpressure,
   interleaved owners and many clear/free cycles. Differential plaintext and
   ciphertext tests use fixed inputs; actual TLS1.3 verification spans all three
   suites, arbitrary CA and DNS/IP behavior. Distinguish framed-byte tests from
   complete verified handshakes.
5. Re-run inherited reservation/readiness/record/HKDF/AEAD-control cases affected
   by retention/preparation changes, not only the last constructor proof. Keep
   every existing assertion meaningful and preserve any initial failures.
6. Same fresh fixture: original six lifecycle intervals, counter and source;
   every functional/callback/pool/preparation invariant equal. Exact 43/86-call
   target must be measured; no retrospective narrowing or reclassification.
7. Full live SDK/root suites alone, Safe/Fast and fmt/convention/version checks;
   source/binary identities, independent review and replayable artifacts, commit
   and push to origin/impl/implement-2.3.0.

Dedicated smoke/security/sanitizer/fuzz campaigns remain user-deferred, with
configured gates unchanged. CertificateVerify input CBB, semantic key-share
objects, cert/ASN1/X509, EVP/math, negotiated/reserved AEADs, sessions and
ERR/RNG/thread facilities remain required full-goal ownership work. Native
publication/pins, production adoption, total TLS capacity, D-5 throughput and
other open v2.3.0 requirements remain required. This scope closes no full gate.
