; ModuleID = '/home/foo/Desktop/Repos/uWebZockets/.zig-cache/tls-handshake-ownership-20261118/layout_evidence/public_layout.c'
source_filename = "/home/foo/Desktop/Repos/uWebZockets/.zig-cache/tls-handshake-ownership-20261118/layout_evidence/public_layout.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-windows-gnu"

@wire_layout_cbb_size = dso_local constant i64 48, align 8
@wire_layout_cbb_align = dso_local constant i64 8, align 8
@wire_layout_root_size = dso_local constant i64 32, align 8
@wire_layout_root_offset = dso_local constant i64 16, align 8
@wire_layout_buf_size = dso_local constant i64 24, align 8
@wire_layout_buf_align = dso_local constant i64 8, align 8

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 21.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "/home/foo/Desktop/Repos/uWebZockets/.zig-cache/tls-handshake-ownership-20261118/layout_evidence/public_layout.c", directory: "/home/foo/Desktop/Repos/uWebZockets", checksumkind: CSK_MD5, checksum: "c642db853adcfd3a7ec08290ec261e8b")
!2 = !{i32 2, !"CodeView", i32 1}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{i32 1, !"wchar_size", i32 2}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"uwtable", i32 2}
!7 = !{i32 7, !"frame-pointer", i32 2}
!8 = !{i32 1, !"MaxTLSAlign", i32 65536}
!9 = !{!"clang version 21.1.0"}
