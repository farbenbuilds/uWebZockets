; ModuleID = '/home/foo/Desktop/Repos/uWebZockets/.zig-cache/tls-handshake-ownership-20261118/layout_evidence/public_layout.c'
source_filename = "/home/foo/Desktop/Repos/uWebZockets/.zig-cache/tls-handshake-ownership-20261118/layout_evidence/public_layout.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux5.10.0-gnu2.31.0"

@wire_layout_cbb_size = constant i64 48, align 8
@wire_layout_cbb_align = constant i64 8, align 8
@wire_layout_root_size = constant i64 32, align 8
@wire_layout_root_offset = constant i64 16, align 8
@wire_layout_buf_size = constant i64 24, align 8
@wire_layout_buf_align = constant i64 8, align 8

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 7, !"Dwarf Version", i32 4}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"clang version 21.1.0"}
