#include <stddef.h>
#include <openssl/bytestring.h>
#include <openssl/buf.h>
const unsigned long long wire_layout_cbb_size=sizeof(CBB);
const unsigned long long wire_layout_cbb_align=_Alignof(CBB);
const unsigned long long wire_layout_root_size=sizeof(((CBB*)0)->u.base);
const unsigned long long wire_layout_root_offset=offsetof(CBB,u.base);
const unsigned long long wire_layout_buf_size=sizeof(BUF_MEM);
const unsigned long long wire_layout_buf_align=_Alignof(BUF_MEM);
