// Copyright 2026 The BoringSSL Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0

#ifndef OPENSSL_HEADER_CRYPTO_BUF_INTERNAL_H
#define OPENSSL_HEADER_CRYPTO_BUF_INTERNAL_H

#include <openssl/buf.h>
#include <openssl/mem.h>

#include "../internal.h"

BSSL_NAMESPACE_BEGIN

// BUF_MEM_allocation_size is the checked growth geometry used by reserve.
bool BUF_MEM_allocation_size(size_t capacity, size_t *out);

// BUF_MEM_reserve_with_domain assigns the first payload to an explicit owner.
// The descriptor may belong to a separate owner. Existing data is forbidden.
bool BUF_MEM_reserve_with_domain(BUF_MEM *buf, size_t capacity,
                                 const OPENSSL_ALLOCATION_DOMAIN *domain);

BSSL_NAMESPACE_END

#endif  // OPENSSL_HEADER_CRYPTO_BUF_INTERNAL_H
