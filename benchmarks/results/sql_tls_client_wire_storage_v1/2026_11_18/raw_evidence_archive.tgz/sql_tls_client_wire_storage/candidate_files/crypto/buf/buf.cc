// Copyright 1995-2016 The OpenSSL Project Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <openssl/buf.h>

#include <string.h>

#include <openssl/err.h>
#include <openssl/mem.h>

#include "../internal.h"
#include "../mem_internal.h"
#include "internal.h"


using namespace bssl;

BUF_MEM *BUF_MEM_new() { return New<BUF_MEM>(); }

void BUF_MEM_free(BUF_MEM *buf) {
  if (buf == nullptr) {
    return;
  }
  OPENSSL_free(buf->data);
  Delete(buf);
}

bool bssl::BUF_MEM_allocation_size(size_t capacity, size_t *out) {
  if (out == nullptr) {
    return false;
  }
  *out = 0;
  if (capacity > SIZE_MAX - 3) {
    return false;
  }
  size_t n = (capacity + 3) / 3;
  if (n > SIZE_MAX / 4) {
    return false;
  }
  *out = n * 4;
  return true;
}

bool bssl::BUF_MEM_reserve_with_domain(
    BUF_MEM *buf, size_t capacity, const OPENSSL_ALLOCATION_DOMAIN *domain) {
  size_t allocation_size;
  if (buf->data != nullptr || buf->max != 0 || buf->length != 0 ||
      !BUF_MEM_allocation_size(capacity, &allocation_size)) {
    OPENSSL_PUT_ERROR(BUF, ERR_R_SHOULD_NOT_HAVE_BEEN_CALLED);
    return false;
  }
  buf->data = static_cast<char *>(
      OPENSSL_malloc_with_domain(allocation_size, domain));
  if (buf->data == nullptr) {
    return false;
  }
  buf->max = allocation_size;
  return true;
}

int BUF_MEM_reserve(BUF_MEM *buf, size_t cap) {
  if (buf->max >= cap) {
    return 1;
  }
  size_t alloc_size;
  if (!BUF_MEM_allocation_size(cap, &alloc_size)) {
    OPENSSL_PUT_ERROR(BUF, ERR_R_OVERFLOW);
    return 0;
  }

  char *new_buf =
      reinterpret_cast<char *>(OPENSSL_realloc(buf->data, alloc_size));
  if (new_buf == nullptr) {
    return 0;
  }

  buf->data = new_buf;
  buf->max = alloc_size;
  return 1;
}

size_t BUF_MEM_grow(BUF_MEM *buf, size_t len) {
  if (!BUF_MEM_reserve(buf, len)) {
    return 0;
  }
  if (buf->length < len) {
    OPENSSL_memset(&buf->data[buf->length], 0, len - buf->length);
  }
  buf->length = len;
  return len;
}

size_t BUF_MEM_grow_clean(BUF_MEM *buf, size_t len) {
  return BUF_MEM_grow(buf, len);
}

int BUF_MEM_append(BUF_MEM *buf, const void *in, size_t len) {
  // Work around a C language bug. See https://crbug.com/1019588.
  if (len == 0) {
    return 1;
  }
  size_t new_len = buf->length + len;
  if (new_len < len) {
    OPENSSL_PUT_ERROR(BUF, ERR_R_OVERFLOW);
    return 0;
  }
  if (!BUF_MEM_reserve(buf, new_len)) {
    return 0;
  }
  OPENSSL_memcpy(buf->data + buf->length, in, len);
  buf->length = new_len;
  return 1;
}

char *BUF_strdup(const char *str) { return OPENSSL_strdup(str); }

size_t BUF_strnlen(const char *str, size_t max_len) {
  return OPENSSL_strnlen(str, max_len);
}

char *BUF_strndup(const char *str, size_t size) {
  return OPENSSL_strndup(str, size);
}

size_t BUF_strlcpy(char *dst, const char *src, size_t dst_size) {
  return OPENSSL_strlcpy(dst, src, dst_size);
}

size_t BUF_strlcat(char *dst, const char *src, size_t dst_size) {
  return OPENSSL_strlcat(dst, src, dst_size);
}

void *BUF_memdup(const void *data, size_t size) {
  return OPENSSL_memdup(data, size);
}
