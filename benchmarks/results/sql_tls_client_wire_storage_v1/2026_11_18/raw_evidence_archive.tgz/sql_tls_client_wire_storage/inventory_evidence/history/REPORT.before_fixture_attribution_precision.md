# Fresh TLS lifecycle allocation family inventory, 2026-11-18

Ordinary performance observation toward v2.3.0. No native or SDK source, original
counter body, lifecycle interval, allocator route, assertion or gate changed.
The exact archived observer is rebound only through its local dependency path
to the immutable post-SSL-constructor SDK. All execution is Linux x86-64,
Zig 0.16.0, ReleaseSafe. This is causal input for the next native storage closure;
it is not acceptance of that implementation or of the full PostgreSQL gate.

## Accepted full worker result

The interval remains `worker first Db.query submission through final callback
entry; includes overlapping close/reconnect/cancel`. One fresh parent-owned
loopback PostgreSQL TLS fixture supplies both executable runs.

| Scenario | Rounds | malloc | calloc | realloc | nonnull free | Requested libc bytes each |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| failure_reconnect | 3 | 242 | 2 | 0 | 244 | 340927 |
| deadline_cancel | 3 | 484 | 4 | 0 | 488 | 681854 |

Control and trace each completed all six functional rounds with no functional
failure and expected exit 1, `NonZeroLifecycleAllocations`. Every counter field
matches within this fresh pair. The new CA changes the prior fixture's totals
by one byte per new TLS connection; no cross-fixture byte value is substituted.
The original 63-byte self-test is intact and passes.

`paired/analysis` is the accepted final analyzer output. Its final-marker replay
also accepts the unchanged trace under `grammar_regressions/accepted_original`.
There are 14063 events, 925 operation/stack groups, 689 raw return addresses,
4285 closed pointer lifetimes, no untracked free/realloc, and no loss, recursion,
truncation, empty stack, unwind or boundary error. All allocation stacks reach
the executable entry. Six malformed global marker regressions are rejected;
original and derived helpers reject optimized Python before reading inputs.

## Measured selected wire-storage family

Every failure round has the following actual allocating paths. Each cancellation
round repeats every family's operation and byte vector exactly twice. All
selected calls are malloc (zero calloc/realloc). Nonnull frees are attributed to
the exact retired pointer's allocating family, rather than guessed from a free
caller's name. The size column is observed libc request size, including any
BoringSSL allocation header already present in that request; it is not a TLS
plaintext capacity or a source bound.

| Family | malloc | nonnull free | Requested bytes | New-origin pointer peak bytes | Actual size x count |
| --- | ---: | ---: | ---: | ---: | --- |
| handshake_transcript_payload | 1 | 1 | 1896 | 1896 | 1896x1 |
| incoming_handshake_buffer | 4 | 4 | 1516 | 1388 | 32x1, 128x1, 216x1, 1140x1 |
| pending_flight_buffer | 7 | 7 | 2456 | 1936 | 20x1, 32x3, 108x1, 328x1, 1904x1 |
| pending_handshake_data_buffer | 2 | 2 | 112 | 112 | 32x1, 80x1 |
| outgoing_handshake_cbb | 9 | 9 | 5235 | 4219 | 72x3, 136x2, 264x2, 1409x1, 2810x1 |
| key_share_encoding_cbb | 5 | 5 | 3860 | 3580 | 72x2, 136x1, 1196x1, 2384x1 |
| handshake_record_input_growth | 7 | 7 | 1565 | 876 | 13x1, 35x1, 81x1, 100x1, 167x1, 293x1, 876x1 |
| prepared_post_handshake_buffer | 2 | 2 | 158424 | 158424 | 32x1, 158392x1 |
| prepared_record_buffers | 2 | 2 | 131070 | 131070 | 65535x2 |
| prepared_key_update_output_buffers | 4 | 4 | 128 | 128 | 16x1, 32x2, 48x1 |

Combined selected storage is 43 malloc / 43 nonnull free / 306262 requested
bytes per failure round, and 86 / 86 / 612524 bytes per cancellation round.
Subtracting only these observed calls leaves 199 malloc / 2 calloc / 201 free /
34665 requested bytes per failure round; this arithmetic is not a passing gate.

Actual source paths are preserved in `wire_allocation_sites.json` and complete
inline/physical stacks in `paired/analysis/callsite_inventory.json`. They include:

- `SSLTranscript::AddToBufferOrHash -> BUF_MEM_append` for transcript payload.
- `tls_append_handshake_data -> BUF_MEM_new/BUF_MEM_append` for incoming bytes.
- `add_record_to_flight -> BUF_MEM_new/BUF_MEM_reserve` for pending flight.
- `tls_add_message_borrowed -> BUF_MEM_new/BUF_MEM_append` for encrypted pending handshake data.
- `tls_init_message -> CBB_init`, ClientHello extension CBB growth, and Finished CBB output.
- `ssl_setup_key_shares -> CBB_init`, hybrid key-share Generate CBB growth and EC key-share Generate CBB growth.
- `SSLBuffer::EnsureCap` during `ssl_run_handshake`, then `SSL_reserve_record_buffers`,
  `SSL_reserve_client_post_handshake_buffer` and `SSL_reserve_key_update_output_buffers` during preparation.

HelloRetryRequest and the second ClientHello execute in this trace. No positive
HRR-cookie byte allocation is observed. Unexecuted positive-cookie paths still
need source-derived bounds and behavior coverage when implemented.

## Exact lifetime implication

Of the 43 selected allocations in the first failure interval, 35 die before its
end. Eight newly prepared blocks (post-handshake descriptor+data, two record
buffers, two key-update output descriptors+data) survive the final callback
boundary, totaling 289622 requested bytes. They retire in the next failure
interval; the first interval's eight corresponding frees retire older/startup
connection pointers. Thus equal allocation/free counts do not prove release of
the newly allocated blocks within that interval.

The new-origin selected pointer peak is 289622 bytes in all six intervals.
The all-observed-origin selected peak is 2316976 bytes, including eight resident
connection sets installed earlier in the trace. These are observed returned
pointer sums. They exclude allocator metadata, unobserved pre-installation
activity, internal libc realloc peaks, other threads and unexecuted paths, and
do not establish any storage capacity bound. All selected interval-origin
blocks eventually retire before observer STOP. Exact peak pointer sets,
allocation/release sequences, scope boundaries and later-release profiles are
retained under `lifetime_peaks/` and `families/lifetimes.json`.

## Separate remaining native families

Per failure round (cancellation is exactly twice these operation/byte vectors):

| Family | malloc | calloc | nonnull free | Requested bytes |
| --- | ---: | ---: | ---: | ---: |
| certificate_asn1_x509 | 137 | 0 | 137 | 14216 |
| certificate_verify_input_bytes | 1 | 0 | 1 | 234 |
| crypto_math_evp | 31 | 0 | 31 | 5191 |
| handshake_aead_contexts | 4 | 0 | 4 | 2432 |
| key_share_crypto_objects_and_scratch | 13 | 0 | 13 | 8936 |
| other_native_tls_crypto | 10 | 0 | 10 | 440 |
| prepared_error_state | 0 | 2 | 2 | 1696 |
| prepared_key_update_aead_context | 1 | 0 | 1 | 608 |
| tls_session_object | 2 | 0 | 2 | 912 |

The separate CertificateVerify input CBB allocation is 234 bytes. Architecture
must explicitly decide whether to include this signature-input byte array in
the same closure; it is not silently counted as an outgoing TLS message.
The 7824-byte hybrid key-share object remains in the crypto family, separately
from its CBB encoded bytes. `other_native_tls_crypto` contains the actual ten
native stack descriptor/backing allocations (48/40 bytes each); their full
certificate/session/ex-data callers remain visible rather than inferred into
the selected wire family. Native session, AEAD, ERR and crypto allocations do
not disappear merely because the selected storage family is closed.

## Evidence and replay

`commands.json` retains exact argv, cwd, optimization, exit status and raw output
paths for the build, paired fixture run, marker regressions and three derivation
commands. `build.log` preserves the first sandbox cache-manifest write failure;
`build_escalated.log` preserves the authorized retry, whose raw result begins
`Build Summary: 19/19 steps succeeded`. Live output is retained unchanged under
`paired/control`, `paired/trace`, `paired_run.log` and `paired/analysis.log`.

`event_membership/events.json` maps every one of the 14063 original events to
its accepted physical-stack group and, where nonnull, its allocating or retired
pointer family. `families/allocation_groups.json` records exact group membership
and source chains. `families/lifetimes.json` records pointer-level allocation /
release event and group indices. Each derivation reconciles all seven original
vectors, including the 63-byte self-test, and is independently bound to input
hashes. No original event, source, analyzer or assertion was edited.

`prepared_inputs.json`, complete `native_source_identity.json` and
`sdk_source_identity.json`, `source_verification_after.json`, and
`executed_input_identities.json` bind sources, modes, toolchain and executables.
The complete native tree (8709 files) and SDK tree (501 files) match their
previous immutable hashes, modes and source path sets after this work.
Both executed ELF files are retained as `bin/control` and `bin/trace`.
No credentials or allocation payload bytes are stored in these outputs.

No smoke, security, sanitizer or fuzz campaign ran for this observation.
Fixture ownership and cleanup remain with the parent task.
