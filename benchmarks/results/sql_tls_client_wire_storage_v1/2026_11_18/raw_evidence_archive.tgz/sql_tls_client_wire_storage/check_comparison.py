#!/usr/bin/env python3
"""Keep the lifecycle comparison's original scope and outcome gates effective."""
import argparse
import copy
import json
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--work', type=Path, required=True)
args = parser.parse_args()
work = args.work.resolve()
parent = work / 'lifecycle_evidence/parent/lifecycle.json'
candidate = json.loads((work / 'lifecycle_evidence/owned/lifecycle.json').read_text())
out = work / 'comparison_regressions'
out.mkdir(exist_ok=False)

def mutate(report, label):
    if label == 'missing_rounds':
        report['completed_rounds'] = 5
    elif label == 'unobserved_callback':
        report['rounds'][0]['callbacks'][0]['observed'] = False
    elif label == 'changed_interval':
        report['interval'] = 'narrowed query-only scope'
    else:
        report['rounds'][0]['allocations']['mallocs'] += 1

cases = [('missing_rounds', 'incomplete rounds'),
         ('unobserved_callback', 'incomplete callback records'),
         ('changed_interval', 'allocation interval changed'),
         ('wrong_allocation_delta', 'observed allocation reduction differs')]
results = []
for label, diagnostic in cases:
    report = copy.deepcopy(candidate)
    mutate(report, label)
    source = out / (label + '.json')
    source.write_text(json.dumps(report, indent=2) + '\n')
    command = [sys.executable, '-O', str(work / 'compare_lifecycle.py'),
               '--control', str(parent), '--candidate', str(source),
               '--output', str(out / (label + '_unexpected_output'))]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (out / (label + '.log')).write_text(result.stdout)
    if result.returncode == 0 or diagnostic not in result.stdout:
        raise SystemExit('comparison gate failed: ' + label)
    results.append({'case': label, 'exit_code': result.returncode,
                    'diagnostic': diagnostic, 'command': command})
(out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
print('all four optimized-Python comparison rejection controls passed')
