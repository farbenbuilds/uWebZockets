#include <openssl/ssl.h>
int main(void) {
 SSL_CLIENT_WIRE_STORAGE_REQUIREMENTS out = {0};
 return SSL_client_wire_storage_requirements(0, &out) +
        SSL_set_client_wire_storage_domain(0, 0);
}
