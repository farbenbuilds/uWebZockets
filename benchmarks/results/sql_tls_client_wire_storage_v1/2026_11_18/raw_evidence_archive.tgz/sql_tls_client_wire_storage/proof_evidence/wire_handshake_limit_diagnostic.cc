#include "wire_test_storage.h"

struct handshake_observations {
    size_t client_hellos;
    SSL_SESSION *ticket;
};
static void observe_handshake(int writing, int, int type, const void *buffer, size_t length, SSL *, void *argument)
{
    auto *observations = static_cast<handshake_observations *>(argument);
    if (writing && type == SSL3_RT_HANDSHAKE && length >= 4 &&
        static_cast<const uint8_t *>(buffer)[0] == SSL3_MT_CLIENT_HELLO) observations->client_hellos++;
}
static int capture_ticket(SSL *ssl, SSL_SESSION *session)
{
    auto *observations = static_cast<handshake_observations *>(SSL_get_app_data(ssl));
    if (observations == nullptr || observations->ticket != nullptr) return 0;
    observations->ticket = session;
    return 1;
}
static bool fixture_path(char *output, size_t capacity, const char *directory, const char *name)
{
    const int length = snprintf(output, capacity, "%s/%s", directory, name);
    return length >= 0 && static_cast<size_t>(length) < capacity;
}
struct handshake_result {
    bool complete;
    bool fatal;
    size_t write_retries;
    uint32_t client_error;
    uint32_t server_error;
};
static int handshake_step(SSL *ssl, bool *complete, uint32_t *error, size_t *write_retries)
{
    if (*complete) return 1;
    ERR_clear_error();
    const int result = SSL_do_handshake(ssl);
    if (result == 1) { *complete = true; return 1; }
    const int ssl_error = SSL_get_error(ssl, result);
    if (ssl_error == SSL_ERROR_WANT_WRITE) { (*write_retries)++; return 0; }
    if (ssl_error == SSL_ERROR_WANT_READ) return 0;
    *error = ERR_peek_error();
    return -1;
}
static handshake_result drive_handshake(SSL *client, SSL *server)
{
    bool client_complete = false, server_complete = false;
    handshake_result result = {};
    for (size_t step = 0; step < 65536; step++) {
        if (handshake_step(client, &client_complete, &result.client_error, &result.write_retries) < 0 ||
            handshake_step(server, &server_complete, &result.server_error, &result.write_retries) < 0) {
            result.fatal = true; return result;
        }
        if (client_complete && server_complete) { result.complete = true; return result; }
        if (client_complete && !server_complete) {
            uint8_t unexpected;
            ERR_clear_error();
            const int read = SSL_read(client, &unexpected, 1);
            const int error = SSL_get_error(client, read);
            if (read > 0 || (error != SSL_ERROR_WANT_READ && error != SSL_ERROR_WANT_WRITE)) {
                result.fatal = true; result.client_error = ERR_peek_error(); return result;
            }
        }
    }
    return result;
}
static int transfer_application(SSL *writer, SSL *reader, uint8_t seed)
{
    uint8_t input[4096], output[4096];
    for (size_t index = 0; index < sizeof(input); index++) input[index] = static_cast<uint8_t>(seed + index * 37);
    size_t written = 0, received = 0;
    for (size_t step = 0; step < 65536 && (written != sizeof(input) || received != sizeof(output)); step++) {
        if (written != sizeof(input)) {
            ERR_clear_error();
            const int result = SSL_write(writer, input + written, static_cast<int>(sizeof(input) - written));
            const int error = SSL_get_error(writer, result);
            if (result > 0) written += static_cast<size_t>(result);
            else REQUIRE(error == SSL_ERROR_WANT_READ || error == SSL_ERROR_WANT_WRITE);
        }
        if (received != sizeof(output)) {
            ERR_clear_error();
            const int result = SSL_read(reader, output + received, static_cast<int>(sizeof(output) - received));
            const int error = SSL_get_error(reader, result);
            if (result > 0) received += static_cast<size_t>(result);
            else REQUIRE(error == SSL_ERROR_WANT_READ || error == SSL_ERROR_WANT_WRITE);
        }
    }
    REQUIRE(written == sizeof(input) && received == sizeof(output) && memcmp(input, output, sizeof(input)) == 0);
    return 0;
}
static int prepare_owned_client(SSL *client)
{
    REQUIRE(SSL_get_client_storage_readiness(client) == ssl_client_storage_ready);
    REQUIRE(SSL_reserve_record_buffers(client));
    REQUIRE(SSL_reserve_client_post_handshake_buffer(client));
    REQUIRE(SSL_reserve_key_update_context(client));
    REQUIRE(SSL_reserve_key_update_output_buffers(client));
    REQUIRE(SSL_reserve_error_state(client));
    REQUIRE(SSL_discard_client_session_tickets(client));
    REQUIRE(SSL_get_client_storage_readiness(client) == ssl_client_storage_ready);
    return 0;
}
static int attach_pair(SSL *client, SSL *server, size_t capacity)
{
    BIO *a = nullptr, *b = nullptr;
    REQUIRE(BIO_new_bio_pair(&a, capacity, &b, capacity));
    SSL_set_bio(client, a, a); SSL_set_bio(server, b, b);
    SSL_set_accept_state(server);
    return 0;
}
static int run_verified(const char *directory, uint16_t cipher, size_t scenario, size_t fragment, bool resume, size_t bio_capacity = 1024)
{
    wire_storage constructor = {}, wire = {};
    bssl::UniquePtr<SSL_CTX> client_ctx(make_wire_context(scenario != 5));
    bssl::UniquePtr<SSL_CTX> server_ctx(SSL_CTX_new(TLS_server_method()));
    REQUIRE(client_ctx && server_ctx);
    char path[1024];
    REQUIRE(fixture_path(path, sizeof(path), directory, scenario == 3 ? "untrusted.pem" : "ca.pem"));
    REQUIRE(SSL_CTX_load_verify_locations(client_ctx.get(), path, nullptr));
    REQUIRE(fixture_path(path, sizeof(path), directory, "server.pem"));
    REQUIRE(SSL_CTX_use_certificate_chain_file(server_ctx.get(), path));
    REQUIRE(fixture_path(path, sizeof(path), directory, "server.key"));
    REQUIRE(SSL_CTX_use_PrivateKey_file(server_ctx.get(), path, SSL_FILETYPE_PEM));
    REQUIRE(SSL_CTX_check_private_key(server_ctx.get()));
    const uint16_t version = scenario == 4 ? TLS1_2_VERSION : TLS1_3_VERSION;
    REQUIRE(SSL_CTX_set_min_proto_version(server_ctx.get(), version));
    REQUIRE(SSL_CTX_set_max_proto_version(server_ctx.get(), version));
    REQUIRE(SSL_CTX_set1_tls13_ciphers(client_ctx.get(), &cipher, nullptr, 1));
    REQUIRE(SSL_CTX_set1_tls13_ciphers(server_ctx.get(), &cipher, nullptr, 1));
    REQUIRE(SSL_CTX_set1_groups_list(client_ctx.get(), "X25519:P-256"));
    REQUIRE(SSL_CTX_set1_groups_list(server_ctx.get(), "P-256"));
    if (resume) {
        SSL_CTX_set_session_cache_mode(client_ctx.get(), SSL_SESS_CACHE_CLIENT);
        SSL_CTX_sess_set_new_cb(client_ctx.get(), capture_ticket);
    }
    handshake_observations observations = {};
    REQUIRE(initialize_constructor(&constructor, client_ctx.get()) && initialize_wire(&wire, client_ctx.get()));
    bssl::UniquePtr<SSL> client(SSL_new_client_with_construction_domain(client_ctx.get(), &constructor.domain));
    bssl::UniquePtr<SSL> server(SSL_new(server_ctx.get()));
    REQUIRE(client && server);
    SSL_set_app_data(client.get(), &observations);
    SSL_set_msg_callback(client.get(), observe_handshake);
    SSL_set_msg_callback_arg(client.get(), &observations);
    REQUIRE(SSL_set_max_send_fragment(client.get(), fragment));
    REQUIRE(SSL_set_max_send_fragment(server.get(), fragment));
    REQUIRE(SSL_set_tlsext_host_name(client.get(), "localhost"));
    if (scenario == 1) REQUIRE(X509_VERIFY_PARAM_set1_ip_asc(SSL_get0_param(client.get()), "127.0.0.1"));
    else REQUIRE(SSL_set1_host(client.get(), scenario == 2 ? "wrong.example.test" : "localhost"));
    REQUIRE(attach_pair(client.get(), server.get(), bio_capacity) == 0);
    REQUIRE(SSL_set_client_wire_storage_domain(client.get(), &wire.domain));
    const handshake_result result = drive_handshake(client.get(), server.get());
    const long verified = SSL_get_verify_result(client.get());
    const bool success = scenario <= 1 || scenario == 5;
    size_t resumed = 0;
    if (success) {
        REQUIRE(result.complete && !result.fatal && observations.client_hellos == 2 && result.write_retries != 0);
        REQUIRE(bssl::FromOpaque(client.get())->s3->used_hello_retry_request);
        REQUIRE(SSL_version(client.get()) == TLS1_3_VERSION && SSL_version(server.get()) == TLS1_3_VERSION);
        REQUIRE(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(client.get())) == cipher);
        REQUIRE(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(server.get())) == cipher);
        REQUIRE(scenario == 5 || verified == X509_V_OK);
        REQUIRE(transfer_application(client.get(), server.get(), 19) == 0);
        REQUIRE(transfer_application(server.get(), client.get(), 73) == 0);
        if (resume) {
            REQUIRE(observations.ticket != nullptr);
            SSL_CTX_set_session_cache_mode(client_ctx.get(), SSL_SESS_CACHE_OFF);
            SSL_CTX_sess_set_new_cb(client_ctx.get(), nullptr);
        }
        REQUIRE(prepare_owned_client(client.get()) == 0);
        const size_t old_wire_attempts = wire.attempts;
        REQUIRE(SSL_key_update(server.get(), SSL_KEY_UPDATE_REQUESTED));
        REQUIRE(transfer_application(server.get(), client.get(), 151) == 0);
        REQUIRE(transfer_application(client.get(), server.get(), 211) == 0);
        REQUIRE(wire.attempts == old_wire_attempts);
        if (resume) {
            REQUIRE(observations.ticket != nullptr && SSL_SESSION_is_resumable(observations.ticket));
            REQUIRE(SSL_clear(client.get()));
            SSL_set_bio(client.get(), nullptr, nullptr); server.reset(SSL_new(server_ctx.get()));
            REQUIRE(server && SSL_set_session(client.get(), observations.ticket));
            SSL_set_connect_state(client.get());
            REQUIRE(attach_pair(client.get(), server.get(), bio_capacity) == 0);
            const handshake_result retried = drive_handshake(client.get(), server.get());
            REQUIRE(retried.complete && !retried.fatal && SSL_session_reused(client.get()) && SSL_session_reused(server.get()));
            REQUIRE(transfer_application(client.get(), server.get(), 41) == 0 && transfer_application(server.get(), client.get(), 83) == 0);
            REQUIRE(prepare_owned_client(client.get()) == 0);
            resumed = 1;
        }
    } else {
        REQUIRE(!result.complete && result.fatal);
        if (scenario == 2) REQUIRE(verified == X509_V_ERR_HOSTNAME_MISMATCH);
        if (scenario == 3) REQUIRE(verified == X509_V_ERR_UNABLE_TO_GET_ISSUER_CERT_LOCALLY || verified == X509_V_ERR_SELF_SIGNED_CERT_IN_CHAIN);
        if (scenario == 4) REQUIRE(ERR_GET_REASON(result.server_error) == SSL_R_UNSUPPORTED_PROTOCOL || ERR_GET_REASON(result.client_error) == SSL_R_TLSV1_ALERT_PROTOCOL_VERSION);
    }
    SSL_SESSION_free(observations.ticket);
    client.reset(); server.reset();
    REQUIRE(storage_empty(constructor) && storage_empty(wire));
    printf("wire_verified_handshake cipher=0x%04x scenario=%zu fragment=%zu bio_capacity=%zu complete=%d verify=%ld hellos=%zu write_retries=%zu resumed=%zu wire_alloc=%zu wire_free=%zu peak=%zu whole_handshake_zero_claim=0\n",
           cipher, scenario, fragment, bio_capacity, result.complete, verified, observations.client_hellos, result.write_retries, resumed, wire.allocations, wire.releases, wire.peak);
    return 0;
}

static int drain_network(BIO *network, uint8_t *output, size_t capacity, size_t *length)
{
    while (BIO_pending(network) != 0) {
        REQUIRE(*length < capacity);
        const int result = BIO_read(network, output + *length, static_cast<int>(capacity - *length));
        REQUIRE(result > 0);
        *length += static_cast<size_t>(result);
    }
    return 0;
}
static int collect_handshakes(const uint8_t *records, size_t length, uint8_t *output, size_t capacity, size_t *used)
{
    size_t offset = 0; *used = 0;
    while (offset < length) {
        REQUIRE(length - offset >= 5);
        const size_t record_length = (size_t{records[offset + 3]} << 8) | records[offset + 4];
        REQUIRE(record_length <= length - offset - 5);
        if (records[offset] == SSL3_RT_HANDSHAKE) {
            REQUIRE(record_length <= capacity - *used);
            memcpy(output + *used, records + offset + 5, record_length); *used += record_length;
        } else {
            REQUIRE(records[offset] == SSL3_RT_CHANGE_CIPHER_SPEC || records[offset] == SSL3_RT_ALERT);
        }
        offset += 5 + record_length;
    }
    return 0;
}
static int encode_retry(const uint8_t *session, size_t session_length, size_t cookie_length,
                        uint8_t *records, size_t capacity, size_t *record_length)
{
    uint8_t handshake[66000], cookie[60000];
    REQUIRE(cookie_length <= sizeof(cookie));
    for (size_t index = 0; index < cookie_length; index++) cookie[index] = static_cast<uint8_t>(index * 29 + 13);
    CBB root, body, sid, extensions, value;
    REQUIRE(CBB_init_fixed(&root, handshake, sizeof(handshake)));
    REQUIRE(CBB_add_u8(&root, SSL3_MT_SERVER_HELLO) && CBB_add_u24_length_prefixed(&root, &body));
    REQUIRE(CBB_add_u16(&body, TLS1_2_VERSION) && CBB_add_bytes(&body, bssl::kHelloRetryRequest, 32));
    REQUIRE(CBB_add_u8_length_prefixed(&body, &sid) && CBB_add_bytes(&sid, session, session_length));
    REQUIRE(CBB_add_u16(&body, 0x1301) && CBB_add_u8(&body, 0) && CBB_add_u16_length_prefixed(&body, &extensions));
    REQUIRE(CBB_add_u16(&extensions, 43) && CBB_add_u16_length_prefixed(&extensions, &value) && CBB_add_u16(&value, TLS1_3_VERSION));
    REQUIRE(CBB_add_u16(&extensions, 51) && CBB_add_u16_length_prefixed(&extensions, &value) && CBB_add_u16(&value, 23));
    REQUIRE(CBB_add_u16(&extensions, 44) && CBB_add_u16_length_prefixed(&extensions, &value));
    CBB cookie_value;
    REQUIRE(CBB_add_u16_length_prefixed(&value, &cookie_value) && CBB_add_bytes(&cookie_value, cookie, cookie_length));
    REQUIRE(CBB_flush(&root));
    const size_t handshake_length = CBB_len(&root);
    CBB output;
    REQUIRE(CBB_init_fixed(&output, records, capacity));
    for (size_t offset = 0; offset < handshake_length;) {
        const size_t chunk = std::min(size_t{16384}, handshake_length - offset);
        REQUIRE(CBB_add_u8(&output, SSL3_RT_HANDSHAKE) && CBB_add_u16(&output, TLS1_2_VERSION));
        REQUIRE(CBB_add_u16(&output, static_cast<uint16_t>(chunk)) && CBB_add_bytes(&output, handshake + offset, chunk));
        offset += chunk;
    }
    *record_length = CBB_len(&output);
    CBB_cleanup(&output); CBB_cleanup(&root);
    return 0;
}
static int feed_retry(SSL *client, BIO *network, const uint8_t *records, size_t length,
                      uint8_t *output, size_t capacity, size_t *used, bool *fatal, uint32_t *reason)
{
    size_t offset = 0; *used = 0; *fatal = false; *reason = 0;
    for (size_t step = 0; step < 65536; step++) {
        if (offset < length) {
            const size_t available = BIO_ctrl_get_write_guarantee(network);
            const size_t amount = std::min(available, length - offset);
            if (amount != 0) {
                const int written = BIO_write(network, records + offset, static_cast<int>(amount));
                REQUIRE(written > 0); offset += static_cast<size_t>(written);
            }
        }
        ERR_clear_error();
        const int result = SSL_do_handshake(client);
        const int error = SSL_get_error(client, result);
        REQUIRE(result != 1);
        REQUIRE(drain_network(network, output, capacity, used) == 0);
        if (error != SSL_ERROR_WANT_READ && error != SSL_ERROR_WANT_WRITE) {
            *fatal = true; *reason = ERR_peek_error(); return 0;
        }
        if (offset == length && error == SSL_ERROR_WANT_READ && BIO_pending(SSL_get_rbio(client)) == 0) return 0;
    }
    return __LINE__;
}
static int verify_cookie_echo(const uint8_t *records, size_t length, size_t cookie_length)
{
    uint8_t messages[131072]; size_t used;
    REQUIRE(collect_handshakes(records, length, messages, sizeof(messages), &used) == 0);
    CBS all, body, value, extensions; uint8_t type; uint16_t legacy;
    CBS_init(&all, messages, used);
    REQUIRE(CBS_get_u8(&all, &type) && type == SSL3_MT_CLIENT_HELLO && CBS_get_u24_length_prefixed(&all, &body));
    REQUIRE(CBS_len(&all) == 0 && CBS_get_u16(&body, &legacy) && CBS_skip(&body, 32));
    REQUIRE(CBS_get_u8_length_prefixed(&body, &value) && CBS_get_u16_length_prefixed(&body, &value));
    REQUIRE(CBS_get_u8_length_prefixed(&body, &value) && CBS_get_u16_length_prefixed(&body, &extensions));
    bool found = false;
    while (CBS_len(&extensions) != 0) {
        uint16_t extension;
        REQUIRE(CBS_get_u16(&extensions, &extension) && CBS_get_u16_length_prefixed(&extensions, &value));
        if (extension != 44) continue;
        CBS cookie;
        REQUIRE(!found && CBS_get_u16_length_prefixed(&value, &cookie) && CBS_len(&value) == 0 && CBS_len(&cookie) == cookie_length);
        for (size_t index = 0; index < cookie_length; index++) REQUIRE(CBS_data(&cookie)[index] == static_cast<uint8_t>(index * 29 + 13));
        found = true;
    }
    REQUIRE(found && CBS_len(&body) == 0);
    return 0;
}
static int run_cookie_framing(size_t cookie_length, size_t fault, size_t *operations, bool oversized = false)
{
    wire_storage constructor = {}, wire = {};
    bssl::UniquePtr<SSL_CTX> ctx(make_wire_context(false));
    REQUIRE(ctx && SSL_CTX_set1_groups_list(ctx.get(), "X25519:P-256"));
    if (oversized) SSL_CTX_set_max_cert_list(ctx.get(), 16384);
    const uint16_t cipher = 0x1301;
    REQUIRE(SSL_CTX_set1_tls13_ciphers(ctx.get(), &cipher, nullptr, 1));
    REQUIRE(initialize_constructor(&constructor, ctx.get()) && initialize_wire(&wire, ctx.get()));
    bssl::UniquePtr<SSL> client(SSL_new_client_with_construction_domain(ctx.get(), &constructor.domain));
    REQUIRE(client && SSL_set_client_wire_storage_domain(client.get(), &wire.domain));
    BIO *internal = nullptr, *external = nullptr;
    REQUIRE(BIO_new_bio_pair(&internal, 0, &external, 0));
    bssl::UniquePtr<BIO> network(external);
    SSL_set_bio(client.get(), internal, internal);
    uint8_t records[131072], messages[131072]; size_t length = 0, used = 0;
    ERR_clear_error();
    const int first = SSL_do_handshake(client.get());
    REQUIRE(SSL_get_error(client.get(), first) == SSL_ERROR_WANT_READ);
    REQUIRE(drain_network(network.get(), records, sizeof(records), &length) == 0);
    REQUIRE(collect_handshakes(records, length, messages, sizeof(messages), &used) == 0 && used >= 39);
    const size_t session_length = messages[38];
    REQUIRE(session_length <= 32 && 39 + session_length <= used);
    uint8_t retry[66000]; size_t retry_length;
    REQUIRE(encode_retry(messages + 39, session_length, cookie_length, retry, sizeof(retry), &retry_length) == 0);
    const size_t before = wire.attempts;
    wire.fail_attempt = fault == 0 ? 0 : before + fault;
    bool fatal; uint32_t reason;
    REQUIRE(feed_retry(client.get(), network.get(), retry, retry_length, records, sizeof(records), &length, &fatal, &reason) == 0);
    if (oversized) {
        REQUIRE(fatal && ERR_GET_REASON(reason) == SSL_R_EXCESSIVE_MESSAGE_SIZE);
        auto *state = bssl::FromOpaque(client.get());
        fprintf(stderr,"oversize_diagnostic fatal=%d packed=%u reason=%d before_attempts=%zu attempts=%zu allocations=%zu releases=%zu live=%zu M=%u capturedM=%zu incoming=%zu hs_present=%d\n",fatal,reason,ERR_GET_REASON(reason),before,wire.attempts,wire.allocations,wire.releases,wire.live,state->max_cert_list,state->client_wire_limits.max_message,state->s3->hs_buf?state->s3->hs_buf->length:0,state->s3->hs!=nullptr);
        REQUIRE(wire.attempts == before && wire.live == 9);
    } else if (fault == 0) {
        *operations = wire.attempts - before;
        REQUIRE(!fatal && *operations != 0 && verify_cookie_echo(records, length, cookie_length) == 0);
        REQUIRE(wire.peak == 12 && wire.live == 9 && !wire.bad);
        REQUIRE(bssl::FromOpaque(client.get())->s3->hs->cookie.empty() && bssl::FromOpaque(client.get())->s3->hs->key_share_bytes.empty());
        REQUIRE(feed_retry(client.get(), network.get(), retry, retry_length, records, sizeof(records), &length, &fatal, &reason) == 0);
        REQUIRE(fatal && ERR_GET_REASON(reason) == SSL_R_UNEXPECTED_MESSAGE);
    } else {
        REQUIRE(fatal && wire.failure_hits == 1 && wire.attempts >= wire.fail_attempt);
    }
    client.reset(); network.reset();
    REQUIRE(storage_empty(constructor) && storage_empty(wire));
    printf("wire_framed_HRR_cookie bytes=%zu fault=%zu oversized=%d operations=%zu peak=%zu alloc=%zu free=%zu second_HRR_rejected=%d verified_handshake_claim=0 whole_handshake_zero_claim=0\n",
           cookie_length, fault, oversized, *operations, wire.peak, wire.allocations, wire.releases, !oversized && fault == 0);
    return 0;
}

int main(int argc, char **argv)
{
    if (argc != 2 || !uwz_alloc_self_test()) return 2;
    size_t failed = 0, rows = 0;
    for (uint16_t cipher : {uint16_t{0x1301}, uint16_t{0x1302}, uint16_t{0x1303}}) {
        for (size_t scenario = 0; scenario < 6; scenario++) {
            const int line = run_verified(argv[1], cipher, scenario, 16384, scenario == 0);
            rows++;
            if (line == 0) continue;
            printf("wire_handshake_failure cipher=0x%04x scenario=%zu line=%d\n", cipher, scenario, line); failed++;
        }
        const int pressure_line = run_verified(argv[1], cipher, 0, 512, false, 17);
        rows++;
        if (pressure_line != 0) {
            printf("wire_handshake_backpressure_failure cipher=0x%04x line=%d\n", cipher, pressure_line); failed++;
        }
        for (size_t fragment : {size_t{512}, size_t{1024}, size_t{4096}}) {
            const int line = run_verified(argv[1], cipher, 0, fragment, false);
            rows++;
            if (line == 0) continue;
            printf("wire_handshake_fragment_failure cipher=0x%04x fragment=%zu line=%d\n", cipher, fragment, line); failed++;
        }
    }
    size_t framed_rows = 0;
    for (size_t cookie_length : {size_t{1}, size_t{60000}}) {
        size_t operations = 0;
        const int baseline = run_cookie_framing(cookie_length, 0, &operations); framed_rows++;
        if (baseline != 0) {
            printf("wire_cookie_baseline_failure bytes=%zu line=%d\n", cookie_length, baseline); failed++;
            continue;
        }
        for (size_t fault = 1; fault <= operations; fault++) {
            const int line = run_cookie_framing(cookie_length, fault, &operations); framed_rows++;
            if (line == 0) continue;
            printf("wire_cookie_fault_failure bytes=%zu fault=%zu line=%d\n", cookie_length, fault, line); failed++;
        }
    }
    size_t oversize_operations = 0;
    const int oversize_line = run_cookie_framing(60000, 0, &oversize_operations, true); framed_rows++;
    if (oversize_line != 0) {
        printf("wire_cookie_oversize_failure line=%d\n", oversize_line); failed++;
    }
    printf("wire_framed_result rows=%zu verified_handshake_claim=0\n", framed_rows);
    printf("wire_verified_result rows=%zu failed=%zu IPv6_handshake_claim=0 whole_handshake_zero_claim=0\n", rows, failed);
    return failed != 0;
}
