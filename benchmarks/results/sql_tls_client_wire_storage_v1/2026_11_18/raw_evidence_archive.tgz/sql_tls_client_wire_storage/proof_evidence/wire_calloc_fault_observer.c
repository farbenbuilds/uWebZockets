/* Separate test observer; never linked into normal allocation measurements. */
#include "ticket_fault.h"
#include <errno.h>
#include <stdlib.h>
#include <string.h>

extern void *__libc_malloc(size_t size);
extern void *__libc_calloc(size_t count, size_t size);
extern void *__libc_realloc(void *pointer, size_t size);
extern void __libc_free(void *pointer);

struct AllocationRecord {
    void *pointer;
    size_t size;
    int live;
    int require_cleanse;
};

/* One fixture OS thread owns all fixed records, watches and fault routing. */
static _Thread_local struct AllocationRecord records[96];
static _Thread_local size_t record_count;
static _Thread_local size_t arm_ordinal;
static _Thread_local size_t fail_ordinal;
static _Thread_local size_t match_size;
static _Thread_local int armed;
static _Thread_local struct TicketFaultStats stats;

static void track(void *pointer, size_t size, int require_cleanse)
{
    if (record_count == 96) abort();
    for (size_t index = 0; index < record_count; index++) {
        if (records[index].live && records[index].pointer == pointer) abort();
    }
    records[record_count++] = (struct AllocationRecord){pointer, size, 1, require_cleanse};
    stats.live++;
}

__attribute__((noinline)) void *malloc(size_t size)
{
    if (armed) {
        arm_ordinal++;
        stats.attempts++;
        stats.requested_bytes += size;
        if ((match_size && size == match_size) || (fail_ordinal && arm_ordinal == fail_ordinal)) {
            stats.matches++;
            if (stats.injected == 0) {
                stats.injected++;
                errno = ENOMEM;
                return NULL;
            }
        }
    }
    void *pointer = __libc_malloc(size);
    if (!armed || !pointer) return pointer;
    track(pointer, size, 0);
    stats.successful++;
    memset(pointer, 0xa5, size);
    return pointer;
}

/* ReleaseSafe may fold native malloc-plus-zeroing into calloc. */
__attribute__((noinline)) void *calloc(size_t count, size_t size)
{
    if (size != 0 && count > SIZE_MAX / size) {
        errno = ENOMEM;
        return NULL;
    }
    const size_t bytes = count * size;
    if (armed) {
        stats.calloc_calls++;
        arm_ordinal++;
        stats.attempts++;
        stats.requested_bytes += bytes;
        if ((match_size && bytes == match_size) ||
            (fail_ordinal && arm_ordinal == fail_ordinal)) {
            stats.matches++;
            if (stats.injected == 0) {
                stats.injected++;
                errno = ENOMEM;
                return NULL;
            }
        }
    }
    void *pointer = __libc_calloc(count, size);
    if (!armed || !pointer) return pointer;
    track(pointer, bytes, 0);
    stats.successful++;
    return pointer;
}

__attribute__((noinline)) void *realloc(void *pointer, size_t size)
{
    if (armed) stats.realloc_calls++;
    return __libc_realloc(pointer, size);
}

__attribute__((noinline)) void free(void *pointer)
{
    size_t matched = 96;
    for (size_t index = 0; index < record_count; index++) {
        if (!records[index].live || records[index].pointer != pointer) continue;
        matched = index;
        const volatile unsigned char *bytes = pointer;
        for (size_t offset = 0; offset < records[index].size; offset++) {
            if (bytes[offset] == 0) continue;
            if (!records[index].require_cleanse) {
                stats.unwatched_nonzero_frees++;
                break;
            }
            if (!stats.cleanse_failures) {
                stats.first_uncleansed_size = records[index].size;
                stats.first_uncleansed_site = (uintptr_t)__builtin_return_address(0);
            }
            stats.cleanse_failures++;
            break;
        }
        records[index].live = 0;
        stats.live--;
        break;
    }
    __libc_free(pointer);
    if (matched != 96) stats.actual_frees++;
}

void ticket_fault_reset(void)
{
    if (armed || stats.live) abort();
    memset(records, 0, sizeof(records));
    memset(&stats, 0, sizeof(stats));
    record_count = arm_ordinal = fail_ordinal = match_size = 0;
}

void ticket_fault_arm_ordinal(size_t ordinal)
{
    if (armed) abort();
    armed = 1;
    arm_ordinal = 0;
    fail_ordinal = ordinal;
    match_size = 0;
}

void ticket_fault_arm_size(size_t size)
{
    if (armed || size == 0) abort();
    armed = 1;
    arm_ordinal = fail_ordinal = 0;
    match_size = size;
}

void ticket_fault_disarm(void)
{
    armed = 0;
    arm_ordinal = fail_ordinal = match_size = 0;
}

void ticket_fault_watch(void *openssl_pointer, size_t payload_size)
{
    if (armed || !openssl_pointer) abort();
    // Exact pinned default x86_64 allocator prefix; verify before watching.
    unsigned char *raw = (unsigned char *)openssl_pointer - 8;
    size_t actual;
    memcpy(&actual, raw, sizeof(actual));
    if (actual != payload_size) abort();
    track(raw, payload_size + 8, 1);
    stats.watched++;
}

struct TicketFaultStats ticket_fault_read(void) { return stats; }
