#!/usr/bin/env python3
"""Retain the exact live pointers at observed wire-family peaks."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import struct

if not __debug__:
    raise SystemExit("optimized Python is unsupported: derivation assertions must remain enabled")

parser = argparse.ArgumentParser()
parser.add_argument("--families", type=Path, required=True)
parser.add_argument("--events", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
assert not args.output.exists()
rows = json.loads((args.families / "families.json").read_text())
selected = {row["family"] for row in rows if row["selected_wire_storage"]}
source = args.families / "lifetimes.json"
lifetimes = json.loads(source.read_text())
allocations = {}
releases = {}
for block in lifetimes["closed"] + lifetimes["live_at_stop"]:
    assert block["allocation_sequence"] not in allocations
    allocations[block["allocation_sequence"]] = block
    if "release_sequence" in block:
        releases[block["release_sequence"]] = block
live = {}
peak_records = {}
boundaries = {}
record = struct.Struct("<70Q4I")
for row in record.iter_unpack(args.events.read_bytes()):
    sequence, scope = row[:2]
    operation, active = row[70:72]
    if sequence in releases:
        block = releases[sequence]
        assert live.pop(block["pointer"])["allocation_sequence"] == block["allocation_sequence"]
    if sequence in allocations:
        block = allocations[sequence]
        assert block["pointer"] not in live
        live[block["pointer"]] = block
    if operation == 5:
        boundaries[scope] = {"begin_sequence": sequence}
    if scope not in range(2, 8):
        continue
    if active or operation == 6:
        buckets = {"combined_selected_wire_storage": [block for block in live.values() if block["family"] in selected]}
        for family in selected:
            buckets[family] = [block for block in buckets["combined_selected_wire_storage"] if block["family"] == family]
        for family, blocks in buckets.items():
            for origin, subset in (("all_observed_origins", blocks),
                                   ("allocated_in_this_scope", [block for block in blocks if block["allocation_scope"] == scope])):
                key = (scope, family, origin)
                total = sum(block["requested_bytes"] for block in subset)
                if key not in peak_records or total > peak_records[key]["requested_bytes"]:
                    peak_records[key] = dict(scope=scope, family=family, origin=origin, sequence=sequence,
                                             requested_bytes=total, live_blocks=len(subset), blocks=subset.copy())
    if operation == 6:
        boundaries[scope]["end_sequence"] = sequence

for row in rows:
    if row["family"] not in selected:
        continue
    for scope in range(2, 8):
        for origin, expected in (("all_observed_origins", "peak_live_bytes"),
                                 ("allocated_in_this_scope", "peak_scope_origin_live_bytes")):
            assert peak_records[(scope, row["family"], origin)]["requested_bytes"] == row["scopes"][str(scope)][expected]
metadata = json.loads((args.families / "metadata.json").read_text())
for scope in range(2, 8):
    assert peak_records[(scope, "combined_selected_wire_storage", "allocated_in_this_scope")]["requested_bytes"] == metadata["combined_selected_wire_storage"][str(scope)]["peak_scope_origin_live_bytes"]
args.output.mkdir(parents=True)
(args.output / "peak_pointer_sets.json").write_text(json.dumps(list(peak_records.values()), indent=2) + "\n")
release_profiles = []
for scope in range(2, 8):
    end = boundaries[scope]["end_sequence"]
    blocks = [block for block in lifetimes["closed"] if block["allocation_scope"] == scope and block["family"] in selected]
    profile = dict(scope=scope, selected_allocations=len(blocks),
                   released_before_interval_end=sum(block["release_sequence"] < end for block in blocks),
                   survive_interval_end=sum(block["release_sequence"] > end for block in blocks),
                   surviving_requested_bytes=sum(block["requested_bytes"] for block in blocks if block["release_sequence"] > end),
                   released_later_scope_counts=dict(Counter(block["release_scope"] for block in blocks if block["release_sequence"] > end)))
    release_profiles.append(profile)
(args.output / "release_profiles.json").write_text(json.dumps(release_profiles, indent=2) + "\n")
(args.output / "inputs.json").write_text(json.dumps({str(p.resolve()): hashlib.sha256(p.read_bytes()).hexdigest() for p in (source, args.families / "metadata.json", args.events, Path(__file__))}, indent=2) + "\n")
print(json.dumps(dict(peak_records=len(peak_records), reconciled_selected_family_peaks=True,
                      scope_2_release_profile=release_profiles[0])))
