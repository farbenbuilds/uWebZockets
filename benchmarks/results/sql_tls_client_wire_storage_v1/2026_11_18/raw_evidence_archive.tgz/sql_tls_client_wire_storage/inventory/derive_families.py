#!/usr/bin/env python3
"""Attribute accepted raw events to explicit native allocation call paths."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import struct

if not __debug__:
    raise SystemExit("optimized Python is unsupported: derivation assertions must remain enabled")

parser = argparse.ArgumentParser()
parser.add_argument("--accepted-analysis", type=Path, required=True)
parser.add_argument("--events", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
assert not args.output.exists()
groups_path = args.accepted_analysis / "callsite_inventory.json"
groups = json.loads(groups_path.read_text())
accepted = json.loads((args.accepted_analysis / "summary.json").read_text())
assert accepted["trace_complete_for_recorded_worker"]
assert accepted["global_trace_scope_grammar_validated"]


def native_chain(group):
    return [dict(function=entry["function"], location=entry["location"].split("/boringssl/", 1)[1])
            for frame in group["stack"] for entry in frame["inline_chain"]
            if "/boringssl/" in entry["location"]]


def allocation_family(group):
    chain = native_chain(group)
    names = "\n".join(entry["function"] for entry in chain)
    locations = "\n".join(entry["location"] for entry in chain)
    if "SSL_reserve_record_buffers" in names:
        return "prepared_record_buffers"
    if "SSL_reserve_client_post_handshake_buffer" in names:
        return "prepared_post_handshake_buffer"
    if "SSL_reserve_key_update_output_buffers" in names:
        return "prepared_key_update_output_buffers"
    if "bssl::SSLBuffer::" in names:
        return "handshake_record_input_growth"
    if "BUF_MEM_" in names:
        if "bssl::SSLTranscript::" in names:
            return "handshake_transcript_payload"
        if "bssl::tls_append_handshake_data" in names:
            return "incoming_handshake_buffer"
        if "bssl::add_record_to_flight" in names:
            return "pending_flight_buffer"
        if "bssl::tls_add_message_borrowed" in names:
            return "pending_handshake_data_buffer"
        return "other_buf_mem"
    if "CBB_" in names or "cbb_buffer_" in names:
        if "crypto/x509/" in locations or "crypto/asn1/" in locations:
            return "certificate_asn1_x509"
        if "bssl::ssl_setup_key_shares" in names:
            return "key_share_encoding_cbb"
        if "bssl::tls_init_message" in names or "bssl::ssl_add_client_hello" in names:
            return "outgoing_handshake_cbb"
        if "bssl::tls13_get_cert_verify_signature_input" in names:
            return "certificate_verify_input_bytes"
        return "other_cbb"
    if "SSL_reserve_error_state" in names:
        return "prepared_error_state"
    if "SSL_reserve_key_update_context" in names:
        return "prepared_key_update_aead_context"
    if "bssl::SSLAEADContext::" in names:
        return "handshake_aead_contexts"
    if "SSLKeyShare::Create" in names or "KeyShare::" in names:
        return "key_share_crypto_objects_and_scratch"
    if "bssl::New<bssl::SSLSession" in names:
        return "tls_session_object"
    if "crypto/x509/" in locations or "crypto/asn1/" in locations or "crypto/pool/" in locations:
        return "certificate_asn1_x509"
    if "crypto/evp/" in locations or "crypto/fipsmodule/" in locations:
        return "crypto_math_evp"
    if "crypto/err/" in locations or "crypto/thread" in locations or "crypto/rand/" in locations:
        return "thread_err_rand_state"
    if chain:
        return "other_native_tls_crypto"
    return "observer_or_application_libc"


operations = {1: "malloc", 2: "calloc", 3: "realloc", 4: "free"}
group_lookup = {}
classified = []
for index, group in enumerate(groups):
    key = (group["operation"], tuple(frame["raw_ip"] for frame in group["stack"]))
    assert key not in group_lookup
    group_lookup[key] = index
    if group["operation"] == "free":
        continue
    classified.append({"group_index": index, "family": allocation_family(group),
                       "operation": group["operation"],
                       "active_events": group["active_events"],
                       "active_requested_bytes": group["active_requested_bytes"],
                       "native_chain": native_chain(group)})
family_by_group = {row["group_index"]: row["family"] for row in classified}
wire_families = {
    "prepared_record_buffers", "prepared_post_handshake_buffer", "prepared_key_update_output_buffers",
    "handshake_record_input_growth", "handshake_transcript_payload", "incoming_handshake_buffer",
    "pending_flight_buffer", "pending_handshake_data_buffer", "key_share_encoding_cbb",
    "outgoing_handshake_cbb",
}
per_scope = {scope: defaultdict(Counter) for scope in range(1, 8)}
active_sizes = defaultdict(Counter)
active_groups = defaultdict(Counter)
live = {}
lifetimes = []
live_bytes = Counter()
live_blocks = Counter()
scope_peaks = {}
new_scope_peaks = {}
scope_start = {}
scope_end = {}
wire_peak = {}
new_wire_peak = {}
outside_origin_releases = Counter()
record = struct.Struct("<70Q4I")
raw = args.events.read_bytes()
assert len(raw) == accepted["event_count"] * record.size
for index, row in enumerate(record.iter_unpack(raw)):
    sequence, scope, pointer, old_pointer, size, count = row[:6]
    operation, active, frame_count, flags = row[70:]
    assert sequence == index and flags == 0
    if operation == 5:
        scope_start[scope] = dict(bytes=dict(live_bytes), blocks=dict(live_blocks))
        scope_peaks[scope] = Counter(live_bytes)
        new_scope_peaks[scope] = Counter()
        wire_peak[scope] = sum(live_bytes[family] for family in wire_families)
        new_wire_peak[scope] = 0
    if operation <= 4:
        group_index = group_lookup[(operations[operation], tuple(row[6:6 + frame_count]))]
        releases = operation == 4 or (operation == 3 and (pointer or size == 0))
        retired = old_pointer if operation == 3 else pointer
        if releases and retired:
            assert retired in live
            old = live.pop(retired)
            family = old["family"]
            live_bytes[family] -= old["requested_bytes"]
            live_blocks[family] -= 1
            old.update(release_sequence=sequence, release_scope=scope, release_operation=operations[operation],
                       release_group_index=group_index)
            lifetimes.append(old)
            if active:
                per_scope[scope][family]["free" if operation == 4 else "realloc_release"] += 1
                if old["allocation_scope"] != scope:
                    outside_origin_releases[(scope, family)] += 1
        if operation in (1, 2, 3):
            family = family_by_group[group_index]
            requested = size * count if operation == 2 else size
            if active:
                per_scope[scope][family][operations[operation]] += 1
                per_scope[scope][family]["bytes"] += requested
                active_sizes[family][requested] += 1
                active_groups[family][group_index] += 1
            if pointer:
                assert pointer not in live
                live[pointer] = dict(pointer=pointer, family=family, requested_bytes=requested,
                                     allocation_sequence=sequence, allocation_scope=scope,
                                     allocation_operation=operations[operation], allocation_group_index=group_index)
                live_bytes[family] += requested
                live_blocks[family] += 1
    if active:
        for family, current in live_bytes.items():
            scope_peaks[scope][family] = max(scope_peaks[scope][family], current)
        new_live = Counter()
        for block in live.values():
            if block["allocation_scope"] == scope:
                new_live[block["family"]] += block["requested_bytes"]
        for family, current in new_live.items():
            new_scope_peaks[scope][family] = max(new_scope_peaks[scope][family], current)
        wire_peak[scope] = max(wire_peak[scope], sum(live_bytes[family] for family in wire_families))
        new_wire_peak[scope] = max(new_wire_peak[scope], sum(new_live[family] for family in wire_families))
    if operation == 6:
        scope_end[scope] = dict(bytes=dict(live_bytes), blocks=dict(live_blocks))

for scope in range(1, 8):
    totals = Counter()
    for counters in per_scope[scope].values():
        totals.update(counters)
    vector = dict(mallocs=totals["malloc"], callocs=totals["calloc"], reallocs=totals["realloc"],
                  frees=totals["free"], bytes=totals["bytes"])
    assert vector == accepted["scope_vectors"][str(scope)]

families = sorted(set(row["family"] for row in classified))
summary = []
for family in families:
    scopes = {}
    for scope in range(2, 8):
        counters = per_scope[scope][family]
        scopes[scope] = dict(malloc=counters["malloc"], calloc=counters["calloc"], realloc=counters["realloc"],
                             free=counters["free"], requested_bytes=counters["bytes"],
                             start_live_bytes=scope_start[scope]["bytes"].get(family, 0),
                             end_live_bytes=scope_end[scope]["bytes"].get(family, 0),
                             peak_live_bytes=scope_peaks[scope][family],
                             peak_scope_origin_live_bytes=new_scope_peaks[scope][family],
                             frees_of_blocks_allocated_outside_scope=outside_origin_releases[(scope, family)])
    own_lifetimes = [row for row in lifetimes if row["family"] == family and row["allocation_scope"] in range(2, 8)]
    summary.append(dict(family=family, selected_wire_storage=family in wire_families, scopes=scopes,
                        active_sizes=dict(sorted(active_sizes[family].items())),
                        active_group_counts=dict(active_groups[family]),
                        closed_interval_origin_lifetimes=len(own_lifetimes),
                        interval_origin_blocks_live_at_stop=sum(block["family"] == family and block["allocation_scope"] != 0 for block in live.values()),
                        release_scope_distribution=dict(Counter(row["release_scope"] for row in own_lifetimes))))
args.output.mkdir(parents=True)
(args.output / "families.json").write_text(json.dumps(summary, indent=2) + "\n")
(args.output / "allocation_groups.json").write_text(json.dumps(classified, indent=2) + "\n")
(args.output / "lifetimes.json").write_text(json.dumps(dict(closed=lifetimes, live_at_stop=list(live.values())), indent=2) + "\n")
combined = {}
for scope in range(2, 8):
    counters = Counter()
    for family in wire_families:
        counters.update(per_scope[scope][family])
    combined[scope] = dict(counters, peak_known_live_bytes=wire_peak[scope],
                           peak_scope_origin_live_bytes=new_wire_peak[scope])
metadata = dict(accepted_analysis=str(args.accepted_analysis.resolve()), optimization="ReleaseSafe",
                allocator_routes_changed=False, source_or_gate_changes=False,
                family_assignment="Explicit allocating stack path; nonnull free attributed by exact retired pointer origin, including allocations before the interval. Null frees excluded exactly as original counters.",
                combined_selected_wire_storage=combined,
                limits="Observed libc requested sizes and simultaneous returned-pointer lifetimes on one installed worker only; no capacity bound, allocator metadata, pre-install activity, other threads, or unexecuted path claim.",
                inputs={str(p.resolve()): hashlib.sha256(p.read_bytes()).hexdigest() for p in (groups_path, args.events, args.accepted_analysis / "summary.json", Path(__file__))})
(args.output / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
print(json.dumps(dict(reconciled_scopes=7, allocation_groups=len(classified), families=len(summary),
                      selected_wire_storage_scope_2=combined[2])))
