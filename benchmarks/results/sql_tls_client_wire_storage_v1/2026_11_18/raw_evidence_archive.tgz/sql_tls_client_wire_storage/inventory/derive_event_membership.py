#!/usr/bin/env python3
"""Bind every raw event to accepted stack and allocating-pointer families."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import struct

if not __debug__:
    raise SystemExit("optimized Python is unsupported: derivation assertions must remain enabled")

parser = argparse.ArgumentParser()
parser.add_argument("--analysis", type=Path, required=True)
parser.add_argument("--families", type=Path, required=True)
parser.add_argument("--events", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
assert not args.output.exists()
group_path = args.analysis / "callsite_inventory.json"
family_path = args.families / "allocation_groups.json"
lifetime_path = args.families / "lifetimes.json"
groups = json.loads(group_path.read_text())
family_by_group = {row["group_index"]: row["family"] for row in json.loads(family_path.read_text())}
group_by_stack = {(group["operation"], tuple(frame["raw_ip"] for frame in group["stack"])): index
                  for index, group in enumerate(groups)}
lifetimes = json.loads(lifetime_path.read_text())
blocks = lifetimes["closed"] + lifetimes["live_at_stop"]
allocated = {block["allocation_sequence"]: block for block in blocks}
released = {block["release_sequence"]: block for block in lifetimes["closed"]}
operations = {1: "malloc", 2: "calloc", 3: "realloc", 4: "free", 5: "scope_begin", 6: "scope_end", 7: "trace_start", 8: "trace_stop"}
vectors = {scope: Counter() for scope in range(1, 8)}
membership = []
for row in struct.Struct("<70Q4I").iter_unpack(args.events.read_bytes()):
    sequence, scope, pointer, old_pointer, size, count = row[:6]
    operation, active, frame_count, flags = row[70:]
    entry = dict(sequence=sequence, scope=scope, active=bool(active), operation=operations[operation],
                 pointer=pointer, old_pointer=old_pointer, requested_bytes=size * count if operation == 2 else size,
                 group_index=None, allocating_family=None, release_family=None, release_allocation_sequence=None)
    if operation <= 4:
        group_index = group_by_stack[(operations[operation], tuple(row[6:6 + frame_count]))]
        entry["group_index"] = group_index
        if operation in (1, 2, 3):
            entry["allocating_family"] = family_by_group[group_index]
            if pointer:
                assert allocated[sequence]["allocation_group_index"] == group_index
                assert allocated[sequence]["family"] == entry["allocating_family"]
        if sequence in released:
            entry["release_family"] = released[sequence]["family"]
            entry["release_allocation_sequence"] = released[sequence]["allocation_sequence"]
            assert released[sequence]["release_group_index"] == group_index
        if active and operation in (1, 2, 3):
            vectors[scope][{1: "mallocs", 2: "callocs", 3: "reallocs"}[operation]] += 1
            vectors[scope]["bytes"] += entry["requested_bytes"]
        if active and operation == 4 and pointer:
            vectors[scope]["frees"] += 1
            assert sequence in released
    membership.append(entry)
summary = json.loads((args.analysis / "summary.json").read_text())
for scope in range(1, 8):
    assert {key: vectors[scope][key] for key in ("mallocs", "callocs", "reallocs", "frees", "bytes")} == summary["scope_vectors"][str(scope)]
assert len(membership) == summary["event_count"]
args.output.mkdir(parents=True)
(args.output / "events.json").write_text(json.dumps(membership, indent=2) + "\n")
(args.output / "inputs.json").write_text(json.dumps({str(p.resolve()): hashlib.sha256(p.read_bytes()).hexdigest() for p in (group_path, family_path, lifetime_path, args.events, Path(__file__))}, indent=2) + "\n")
print(json.dumps(dict(events=len(membership), accepted_vectors_reconciled=7, lifetime_and_stack_membership_validated=True)))
