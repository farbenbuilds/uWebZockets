#!/usr/bin/env python3
"""Scan staged public inputs for this fixture's secrets, then retire it."""
import argparse
import base64
import json
from pathlib import Path
import shutil
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--packet', type=Path, required=True)
args = parser.parse_args()
fixture = Path(__file__).resolve().parent
work = fixture.parent
private = fixture / 'private_fixture'
packet = args.packet.resolve()
if not packet.is_dir() or not packet.is_relative_to(work / 'delivery'):
    raise SystemExit('expected staged packet inside this delivery workspace')
if not private.is_dir() or private.is_symlink():
    raise SystemExit('owned private fixture is unavailable')

values = dict(line.split('=', 1) for line in (private / 'postgres.env').read_text().splitlines())
passwords = [values['POSTGRES_PASSWORD']]
passwords.extend(json.loads((private / 'unicode_passwords.json').read_text()).values())
patterns = set()
for value in passwords:
    patterns.add(value.encode())
    patterns.add(json.dumps(value, ensure_ascii=True)[1:-1].encode())
for key in private.glob('*.key'):
    data = key.read_bytes()
    patterns.add(data)
    patterns.add(base64.b64decode(b''.join(line for line in data.splitlines()
                                          if not line.startswith(b'-----')),
                                 validate=True))
if not patterns or any(len(value) < 16 for value in patterns):
    raise SystemExit('invalid generated-secret scan inputs')

files = 0
size = 0
for path in packet.rglob('*'):
    if path.is_symlink():
        raise SystemExit('unexpected packet symlink')
    if not path.is_file():
        continue
    data = path.read_bytes()
    if any(value in data for value in patterns):
        raise SystemExit('generated fixture secret found in staged public input')
    files += 1
    size += len(data)
if files == 0:
    raise SystemExit('empty packet')

container = (private / 'container.id').read_text().strip()
result = subprocess.run(['docker', 'inspect', '--format',
                         '{{ index .Config.Labels "uwz.sql-experiment" }}', container],
                        check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
if result.stdout.strip() != 'handshake-ownership-20261118':
    raise SystemExit('container ownership label differs')
subprocess.run(['docker', 'rm', '--force', container], check=True,
               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
result = subprocess.run(['docker', 'inspect', container],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
if result.returncode == 0:
    raise SystemExit('fixture container still exists')
shutil.rmtree(private)

output = work / 'delivery_evidence'
output.mkdir(exist_ok=True)
(output / 'generated_secret_scan.json').write_text(json.dumps({
    'scanned_staged_files': files, 'scanned_bytes': size,
    'generated_secret_patterns': len(patterns), 'generated_secret_matches': 0,
    'includes_password_UTF8_and_JSON_encodings': True,
    'includes_complete_generated_private_keys': True,
    'private_key_representations': ['PEM', 'DER'],
    'secret_values_recorded': False,
}, indent=2) + '\n')
(output / 'fixture_cleanup.json').write_text(json.dumps({
    'owned_container_label_verified': True, 'owned_container_removed': True,
    'private_fixture_removed': not private.exists(),
    'live_fixture_consumers_completed_before_cleanup': True,
}, indent=2) + '\n')
print('Staged secret scan passed; owned container and private fixture removed')
