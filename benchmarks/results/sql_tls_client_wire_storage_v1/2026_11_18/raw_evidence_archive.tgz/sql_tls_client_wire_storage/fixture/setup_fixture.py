#!/usr/bin/env python3
"""Provision only this experiment's disposable loopback PostgreSQL fixture."""
import json
import os
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parent
private = root / "private_fixture"
private.mkdir(mode=0o700, exist_ok=False)
os.umask(0o077)
credential = private / "postgres.env"
credential.write_text("POSTGRES_PASSWORD=" + os.urandom(24).hex() +
                      "\nPOSTGRES_USER=uwz_test\nPOSTGRES_DB=uwz_test\n")
image = "postgres@sha256:f4c66b820c6f974249089d3d16d86a3698eae11e8746eb6644b2271031e91232"

def command(args, **kwargs):
    return subprocess.run(args, check=True, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, **kwargs).stdout.decode().strip()

with (private / "openssl.log").open("wb") as log:
    for args in (
        ["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
         "-keyout", str(private / "ca.key"), "-out", str(private / "ca.pem"),
         "-days", "1", "-subj", "/CN=uwz-sql-lifecycle-inventory-ca"],
        ["openssl", "req", "-newkey", "rsa:2048", "-nodes",
         "-keyout", str(private / "server.key"), "-out", str(private / "server.csr"),
         "-subj", "/CN=localhost"],
    ):
        subprocess.run(args, check=True, stdout=log, stderr=log)
    (private / "extensions.cnf").write_text(
        "subjectAltName=DNS:localhost,IP:127.0.0.1\nextendedKeyUsage=serverAuth\n")
    subprocess.run(["openssl", "x509", "-req", "-in", str(private / "server.csr"),
                    "-CA", str(private / "ca.pem"), "-CAkey", str(private / "ca.key"),
                    "-CAcreateserial", "-out", str(private / "server.pem"),
                    "-days", "1", "-extfile", str(private / "extensions.cnf")],
                   check=True, stdout=log, stderr=log)

container = command(["docker", "run", "--detach", "--rm", "--memory", "512m", "--cpus", "2",
                     "--label", "uwz.sql-experiment=handshake-ownership-20261118", "--env-file", str(credential),
                     "--publish", "127.0.0.1::5432", "--tmpfs", "/var/lib/postgresql/data", image])
(private / "container.id").write_text(container + "\n")
try:
    for attempt in range(30):
        result = subprocess.run(["docker", "exec", container, "pg_isready", "-h", "127.0.0.1",
                                 "-U", "uwz_test", "-d", "uwz_test"],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if result.returncode == 0:
            break
        time.sleep(1)
    else:
        raise RuntimeError("fixture readiness timed out")
    command(["docker", "exec", container, "mkdir", "-p", "/tmp/uwz_sql_tls"])
    for name in ("server.pem", "server.key"):
        command(["docker", "cp", str(private / name), container + ":/tmp/uwz_sql_tls/" + name])
    command(["docker", "exec", container, "chown", "-R", "postgres:postgres", "/tmp/uwz_sql_tls"])
    command(["docker", "exec", container, "chmod", "600", "/tmp/uwz_sql_tls/server.key"])
    psql = ["docker", "exec", container, "psql", "-U", "uwz_test", "-d", "uwz_test", "-v", "ON_ERROR_STOP=1"]
    command(psql + ["-c", "ALTER SYSTEM SET ssl = 'on'",
                    "-c", "ALTER SYSTEM SET ssl_cert_file = '/tmp/uwz_sql_tls/server.pem'",
                    "-c", "ALTER SYSTEM SET ssl_key_file = '/tmp/uwz_sql_tls/server.key'",
                    "-c", "SELECT pg_reload_conf()",
                    "-c", "CREATE TABLE World (id integer PRIMARY KEY, randomnumber integer NOT NULL)",
                    "-c", "INSERT INTO World VALUES (1,42)"])
    for attempt in range(30):
        if command(psql + ["-Atc", "SHOW ssl"]) == "on":
            break
        time.sleep(1)
    else:
        raise RuntimeError("fixture TLS reload timed out")
    mapping = command(["docker", "port", container, "5432/tcp"])
    port = int(mapping.rsplit(":", 1)[1])
    (root / "fixture.json").write_text(json.dumps({"port": port, "image": image,
        "server_version": command(psql + ["-Atc", "SHOW server_version"]),
        "ssl": "on", "scope": "isolated temporary PostgreSQL fixture"}, indent=2) + "\n")
    print("isolated PostgreSQL fixture ready; private credentials were not printed")
except BaseException:
    subprocess.run(["docker", "rm", "--force", container], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    raise
