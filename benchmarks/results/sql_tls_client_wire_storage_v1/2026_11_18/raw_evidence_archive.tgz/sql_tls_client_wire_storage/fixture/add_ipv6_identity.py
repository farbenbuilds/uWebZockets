#!/usr/bin/env python3
"""Issue an additional in-memory TLS identity witness from the owned test CA."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--fixture', type=Path, required=True)
args = parser.parse_args()
fixture = args.fixture.resolve()
private = fixture / 'private_fixture'
certificate = private / 'ipv6_server.pem'
if certificate.exists():
    raise SystemExit('IPv6 witness certificate already exists')
extension = private / 'ipv6_extensions.cnf'
extension.write_text('subjectAltName=DNS:localhost,IP:127.0.0.1,IP:::1\nextendedKeyUsage=serverAuth\n')
extension.chmod(0o600)
command = ['openssl', 'x509', '-req', '-in', str(private / 'server.csr'),
           '-CA', str(private / 'ca.pem'), '-CAkey', str(private / 'ca.key'),
           '-set_serial', '3', '-out', str(certificate), '-days', '1',
           '-extfile', str(extension)]
with (private / 'ipv6_openssl.log').open('wb') as log:
    subprocess.run(command, check=True, stdout=log, stderr=log)
certificate.chmod(0o600)
record = {'certificate_sha256': hashlib.sha256(certificate.read_bytes()).hexdigest(),
          'public_identities': ['localhost', '127.0.0.1', '::1'],
          'uses_original_fixture_key_and_CA': True,
          'original_server_certificate_changed': False,
          'TCP_IPv6_transport_claim': False}
(fixture / 'ipv6_identity.json').write_text(json.dumps(record, indent=2) + '\n')
print('Additional IPv6 identity certificate issued; original fixture unchanged')
