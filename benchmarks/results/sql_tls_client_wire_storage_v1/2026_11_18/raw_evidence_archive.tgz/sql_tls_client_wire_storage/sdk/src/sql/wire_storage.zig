//! Worker-confined exact-class slots for native TLS handshake and record storage.
const std = @import("std");
const c = @import("c");

/// The public native interface bounds the copied class table.
pub const max_classes: usize = c.SSL_CLIENT_WIRE_STORAGE_MAX_CLASSES;
/// One native-derived class owns equal raw extents at fixed aligned offsets.
pub const Class = struct { raw_bytes: usize = 0, alignment: usize = 0, stride: usize = 0, offset: usize = 0, count: usize = 0 };
/// Geometry is copied by value so no descriptor borrows startup stack storage.
pub const Requirements = struct {
    bytes: usize = 0,
    alignment: usize = 0,
    class_count: usize = 0,
    block_count: usize = 0,
    classes: [max_classes]Class = [_]Class{.{}} ** max_classes,
};
/// Backing and metadata remain borrowed until the final native release.
pub const Error = error{ InvalidRequirements, StorageTooSmall, MetadataTooSmall, StorageMisaligned, StorageUnavailable, StorageBusy };
/// Exact slot roots and extents remain fixed while liveness changes independently.
pub const Block = struct { offset: usize = 0, raw_bytes: usize = 0, alignment: usize = 0, live: bool = false };

/// Native sizing owns every private buffer, object and allocation-header bound.
pub fn requirements(context: *const c.SSL_CTX) Error!Requirements {
    var native: c.SSL_CLIENT_WIRE_STORAGE_REQUIREMENTS = std.mem.zeroes(c.SSL_CLIENT_WIRE_STORAGE_REQUIREMENTS);
    if (c.SSL_client_wire_storage_requirements(context, &native) != 1) return error.InvalidRequirements;
    var result: Requirements = .{ .bytes = native.bytes, .alignment = native.alignment, .class_count = native.class_count, .block_count = native.block_count };
    for (native.classes, 0..) |class, index| {
        result.classes[index] = .{ .raw_bytes = class.raw_bytes, .alignment = class.alignment, .stride = class.stride, .offset = class.offset, .count = class.count };
    }
    try validate_requirements(result);
    return result;
}

fn class_end(class: Class, bytes: usize, alignment: usize) Error!usize {
    if (class.raw_bytes == 0 or class.count == 0 or class.stride < class.raw_bytes) return error.InvalidRequirements;
    if (class.alignment == 0 or !std.math.isPowerOfTwo(class.alignment)) return error.InvalidRequirements;
    if (alignment % class.alignment != 0) return error.InvalidRequirements;
    if (class.offset % class.alignment != 0 or class.stride % class.alignment != 0) return error.InvalidRequirements;
    const extent = std.math.mul(usize, class.stride, class.count) catch return error.InvalidRequirements;
    const end = std.math.add(usize, class.offset, extent) catch return error.InvalidRequirements;
    if (end > bytes) return error.InvalidRequirements;
    return end;
}

fn validate_requirements(value: Requirements) Error!void {
    if (value.bytes == 0 or value.alignment == 0 or value.block_count == 0) return error.InvalidRequirements;
    if (value.class_count == 0 or value.class_count > max_classes) return error.InvalidRequirements;
    if (!std.math.isPowerOfTwo(value.alignment) or value.bytes % value.alignment != 0) return error.InvalidRequirements;
    var count: usize = 0;
    for (value.classes[0..value.class_count], 0..) |class, index| {
        const end = try class_end(class, value.bytes, value.alignment);
        count = std.math.add(usize, count, class.count) catch return error.InvalidRequirements;
        for (value.classes[0..index]) |previous| {
            if (class.raw_bytes == previous.raw_bytes and class.alignment == previous.alignment) return error.InvalidRequirements;
            const previous_end = try class_end(previous, value.bytes, value.alignment);
            if (class.offset < previous_end and previous.offset < end) return error.InvalidRequirements;
        }
    }
    if (count != value.block_count) return error.InvalidRequirements;
    _ = std.math.mul(usize, count, @sizeOf(Block)) catch return error.InvalidRequirements;
}

/// Bind only in place; descriptor, table, metadata and backing outlive native use.
pub const Storage = struct {
    backing: []u8 = &.{},
    blocks: []Block = &.{},
    required: Requirements = .{},
    domain: c.OPENSSL_ALLOCATION_DOMAIN = .{ .context = null, .allocate = null, .release = null },
    live_count: usize = 0,

    pub fn init(self: *Storage, backing: []u8, blocks: []Block, required: Requirements) Error!void {
        if (self.live_count != 0) return error.StorageBusy;
        try validate_requirements(required);
        if (backing.len < required.bytes) return error.StorageTooSmall;
        if (blocks.len < required.block_count) return error.MetadataTooSmall;
        if (@intFromPtr(backing.ptr) % required.alignment != 0) return error.StorageMisaligned;
        self.* = .{ .backing = backing[0..required.bytes], .blocks = blocks[0..required.block_count], .required = required };
        var index: usize = 0;
        for (required.classes[0..required.class_count]) |class| {
            for (0..class.count) |slot| {
                self.blocks[index] = .{ .offset = class.offset + slot * class.stride, .raw_bytes = class.raw_bytes, .alignment = class.alignment };
                index += 1;
            }
        }
        self.domain = .{ .context = self, .allocate = allocate_raw, .release = release_raw };
    }

    /// Reusing a physical connection requires all preceding wire owners to be gone.
    pub fn domain_for_session(self: *Storage) Error!*const c.OPENSSL_ALLOCATION_DOMAIN {
        if (self.backing.len == 0 or self.domain.context != @as(?*anyopaque, self)) return error.StorageUnavailable;
        if (self.live_count != 0) return error.StorageBusy;
        return &self.domain;
    }
};

fn allocate_raw(context: ?*anyopaque, bytes: usize, alignment: usize) callconv(.c) ?*anyopaque {
    const self: *Storage = @ptrCast(@alignCast(context orelse return null));
    for (self.blocks) |*block| {
        if (block.live or bytes != block.raw_bytes or alignment != block.alignment) continue;
        block.live = true;
        self.live_count += 1;
        return @ptrCast(self.backing.ptr + block.offset);
    }
    return null;
}

fn release_raw(context: ?*anyopaque, pointer: ?*anyopaque, bytes: usize, alignment: usize) callconv(.c) void {
    const self: *Storage = @ptrCast(@alignCast(context orelse @panic("SQL wire release has no owner")));
    const address = @intFromPtr(pointer orelse @panic("SQL wire release has no block"));
    const base = @intFromPtr(self.backing.ptr);
    if (address < base or address - base >= self.backing.len) @panic("SQL wire release is outside storage");
    for (self.blocks) |*block| {
        if (block.offset != address - base) continue;
        if (!block.live) @panic("SQL wire release does not match a live slot");
        if (bytes != block.raw_bytes) @panic("SQL wire release extent differs");
        if (alignment != block.alignment) @panic("SQL wire release alignment differs");
        block.live = false;
        self.live_count -= 1;
        return;
    }
    @panic("SQL wire release is not a slot root");
}
