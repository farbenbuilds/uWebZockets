//! Worker-confined fixed slots for native SSL construction and identity setup.
const std = @import("std");
const c = @import("c");

/// Native-derived raw bounds keep private object and header sizes in BoringSSL.
pub const Requirements = struct {
    bytes: usize = 0,
    alignment: usize = 0,
    block_bytes: usize = 0,
    block_count: usize = 0,
};
/// Storage and metadata remain borrowed until the final native release.
pub const Error = error{ InvalidRequirements, StorageTooSmall, MetadataTooSmall, StorageMisaligned, StorageUnavailable, StorageBusy };
/// Each fixed slot records the exact raw extent required at release.
pub const Block = struct { bytes: usize = 0, alignment: usize = 0, live: bool = false };

/// Queries construction, one SNI and one verification identity, plus clear reuse.
pub fn requirements(context: *const c.SSL_CTX, max_server_name_bytes: usize) Error!Requirements {
    var native: c.SSL_CLIENT_CONSTRUCTION_REQUIREMENTS = .{ .bytes = 0, .alignment = 0, .block_bytes = 0, .block_count = 0 };
    if (c.SSL_client_construction_storage_requirements(context, max_server_name_bytes, &native) != 1) return error.InvalidRequirements;
    const result: Requirements = .{ .bytes = native.bytes, .alignment = native.alignment, .block_bytes = native.block_bytes, .block_count = native.block_count };
    try validate_requirements(result);
    return result;
}

fn validate_requirements(value: Requirements) Error!void {
    if (value.bytes == 0 or value.alignment == 0 or value.block_bytes == 0 or value.block_count == 0) return error.InvalidRequirements;
    if (!std.math.isPowerOfTwo(value.alignment)) return error.InvalidRequirements;
    if (value.block_bytes % value.alignment != 0) return error.InvalidRequirements;
    const bytes = std.math.mul(usize, value.block_bytes, value.block_count) catch return error.InvalidRequirements;
    if (bytes != value.bytes) return error.InvalidRequirements;
}

/// Bind only in place; descriptor, metadata and backing outlive every SSL owner.
pub const Storage = struct {
    backing: []u8 = &.{},
    blocks: []Block = &.{},
    required: Requirements = .{},
    domain: c.OPENSSL_ALLOCATION_DOMAIN = .{ .context = null, .allocate = null, .release = null },
    live_count: usize = 0,

    pub fn init(self: *Storage, backing: []u8, blocks: []Block, required: Requirements) Error!void {
        if (self.live_count != 0) return error.StorageBusy;
        try validate_requirements(required);
        if (backing.len < required.bytes) return error.StorageTooSmall;
        if (blocks.len < required.block_count) return error.MetadataTooSmall;
        if (@intFromPtr(backing.ptr) % required.alignment != 0) return error.StorageMisaligned;
        @memset(blocks[0..required.block_count], .{});
        self.* = .{ .backing = backing[0..required.bytes], .blocks = blocks[0..required.block_count], .required = required };
        self.domain = .{ .context = self, .allocate = allocate_raw, .release = release_raw };
    }

    /// A new SSL starts only after every prior construction-owned object is gone.
    pub fn domain_for_session(self: *Storage) Error!*const c.OPENSSL_ALLOCATION_DOMAIN {
        if (self.backing.len == 0 or self.domain.context != @as(?*anyopaque, self)) return error.StorageUnavailable;
        if (self.live_count != 0) return error.StorageBusy;
        return &self.domain;
    }
};

fn allocate_raw(context: ?*anyopaque, bytes: usize, alignment: usize) callconv(.c) ?*anyopaque {
    const self: *Storage = @ptrCast(@alignCast(context orelse return null));
    if (bytes == 0 or bytes > self.required.block_bytes or alignment != self.required.alignment) return null;
    for (self.blocks, 0..) |*block, index| {
        if (block.live) continue;
        block.* = .{ .bytes = bytes, .alignment = alignment, .live = true };
        self.live_count += 1;
        return @ptrCast(self.backing.ptr + index * self.required.block_bytes);
    }
    return null;
}

fn release_raw(context: ?*anyopaque, pointer: ?*anyopaque, bytes: usize, alignment: usize) callconv(.c) void {
    const self: *Storage = @ptrCast(@alignCast(context orelse @panic("SQL SSL release has no owner")));
    const address = @intFromPtr(pointer orelse @panic("SQL SSL release has no block"));
    const base = @intFromPtr(self.backing.ptr);
    if (address < base or address - base >= self.backing.len) @panic("SQL SSL release is outside storage");
    const offset = address - base;
    if (offset % self.required.block_bytes != 0) @panic("SQL SSL release is not a slot root");
    const block = &self.blocks[offset / self.required.block_bytes];
    if (!block.live) @panic("SQL SSL release does not match a live slot");
    if (bytes != block.bytes) @panic("SQL SSL release extent differs");
    if (alignment != block.alignment) @panic("SQL SSL release alignment differs");
    block.* = .{};
    self.live_count -= 1;
}
