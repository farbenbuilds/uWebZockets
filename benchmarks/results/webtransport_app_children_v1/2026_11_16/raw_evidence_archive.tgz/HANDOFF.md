# Private incoming-child delivery artifact

Start with root-evidence/HANDOFF.md and root-evidence/root/commands.txt.
root-evidence/ contains all final functional results and read-only reviews.
native-proof/ contains the independently tested current257-input source copy.
The selected incoming UNI case passes all three optimization modes; the
existing33-test App cohort passes Debug. Broader child draft cases are unrun.
native-history/ preserves original REDs, source copies and earlier histories;
its inherited README and earlier pass manifests are historical. Three later
fixture files differ from the original43539 Debug pass; the current exact
bytes have fresh Root-owned three-mode positive and Debug regression proof.

libxev-source/ retains the complete clean tracked5b2cde22... proposal source.
The native lsquic source/history is retained in the preceding repository
artifact benchmarks/results/webtransport_coded_stop_v1/2026_11_16/
raw_evidence_archive.tgz. Extract its native checkpoint source/ at the required
530e9e505eb04a0a4095b290f7eb052504ace94e commit. Metadata is repeated here for
exact package/gitlink identities. Root production pins remain unchanged.
Use Zig0.16.0, the recorded immutable dependencies, and ordinary Linux
loopback/io_uring permissions. Replay scripts use shell and Zig. Synthetic
native scheduling and real Binding awake time remain distinct. No child TTL
or broader new native lifecycle proof is claimed by this checkpoint.

Verify files.sha256 after extraction. Smoke/security campaigns remain deferred.
v2.3.0 is incomplete; public child I/O/TX, broader native acceptance,
multi-session flow accounting, independent-client and publication gates remain.
