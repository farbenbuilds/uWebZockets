# Same-connection WebTransport multi-session ordinary native evidence

The 11-case multi-session baseline and unchanged 18-case positive-flow,
77-case combined stream/debt, and 33-case datagram drivers pass in Debug,
ReleaseSafe, and ReleaseFast. A separately added authorization-refusal case
also passes in each mode. All 15 final invocations exited 0. Driver counts
overlap; they are not independent feature totals or performance measurements.

Final Root implementation commit:
`a6c744fc44a24c5b3b65558d15c20dfebf690afd`.
The ring prerequisite is `64ccd279922bf1a762799560d04e5dba39a467ab`.
All 266 retained v1 source/build/include hashes, including build metadata,
match Root after its final review and formatting work.

| Optimization mode | Multi-session baseline | Positive flow | Combined stream/debt | Datagrams | Separate refusal case |
| --- | --- | --- | --- | --- | --- |
| Debug | 11/11 | 18/18 | 77/77 | 33/33 | 1/1 |
| ReleaseSafe | 11/11 | 18/18 | 77/77 | 33/33 | 1/1 |
| ReleaseFast | 11/11 | 18/18 | 77/77 | 33/33 | 1/1 |

[final_matrix.json](final_matrix.json) binds every final count, optimization
mode, terminal status, raw log SHA256, and source driver.
[final_statuses.tsv](final_statuses.tsv) gives the same final statuses.
Every passing raw log contains its exact `N/N tests passed` summary and
`Build Summary: 16/16 steps succeeded`. Raw log bytes are preserved.

## Reproduction and source binding

The sibling `uwz-wt-multi-session-native-20261117` directory contains only
fixture/build sources and the RED/v1 Root source snapshots. `project_red` is
Root commit `c5b4a423b09288f10e9f0f7b96af05c618bb3e6b`, before the admission
gate relaxation. `project_v1` is the tested implementation; its source manifest
and independent copy check are retained here. No resnapshot was needed for
the final commits because the source bytes did not change.

The exact successful baseline commands were:

```sh
env UWZ_PROJECT_SOURCE=/tmp/uwz-wt-multi-session-native-20261117/project_v1 \
  sh /tmp/uwz-wt-multi-session-native-20261117/replay.sh Debug multi
sh /tmp/uwz-wt-multi-session-native-20261117/run_ordinary_matrix.sh Debug flow debt datagrams
sh /tmp/uwz-wt-multi-session-native-20261117/run_ordinary_matrix.sh ReleaseSafe multi flow debt datagrams
sh /tmp/uwz-wt-multi-session-native-20261117/run_ordinary_matrix.sh ReleaseFast multi flow debt datagrams
```

The separate corrected refusal case used `sh replay.sh Debug refusal` with
the explicit v1 source override, then:

```sh
sh /tmp/uwz-wt-multi-session-native-20261117/run_ordinary_matrix.sh ReleaseSafe refusal
sh /tmp/uwz-wt-multi-session-native-20261117/run_ordinary_matrix.sh ReleaseFast refusal
```

All loopback commands used host permission, `login=false`, `--system`, `-j2`,
and `--summary all`. Resolved compiler, external source, package and cache paths
at execution are recorded in the JSON. Zig was 0.16.0.

The 11-case source, helper and driver remain byte-identical to the
matrix-start hashes in [fixture_inputs_at_matrix_sha256.txt](fixture_inputs_at_matrix_sha256.txt).
The immutable copy is `trial_sources/baseline_eleven/tests`; `multi11` selects
it. The refusal case uses a separate copied support module and driver, so it
did not change or inflate the 11-case matrix. Every inherited test and C fixture
input remains byte-identical to the finalized positive-flow fixture; see
[inherited_inputs_sha256.txt](inherited_inputs_sha256.txt).

Replay defaults to local snapshot/cache paths after extraction. Set the
compiler/package/Native/libxev overrides for another machine. Native and libxev
remain external; their exact revisions and existing committed artifact SHA256
values are recorded in [external_inputs.json](external_inputs.json). No Native
source, maintained fork, dependency pin, or upstream repository was modified.

## Genuine regression proof

The actual RED command was:

```sh
env UWZ_PROJECT_SOURCE=/tmp/uwz-wt-multi-session-native-20261117/project_red \
  sh /tmp/uwz-wt-multi-session-native-20261117/replay.sh Debug multi-red
```

Native and Zig compilation succeeded. The test then exited 1 with the raw
[second-CONNECT result](red-second-connect-debug.log):

```text
second positive CONNECT sid=4 status=0 reset=10b authorizations=1 sessions=1
expected 200, found 0
Build Summary: 14/16 steps succeeded (1 failed); 0/1 tests passed (1 failed)
```

The resulting baseline proves both SID 0 and SID 4 are established on one
connection with distinct routes/handles, while zero or unilateral intent still
rejects concurrent CONNECT before authorization and admits a later fresh SID.

## Isolation boundaries

The new cases observe peer UNI/BIDI and local child traffic through the proper
session route; independent sender data/BIDI/UNI exhaustion and grants; B-only
writable recovery; early future-session debt import and over-limit rejection;
draining policy; and saturated eight-slot lease reuse with a higher generation.

Six CONNECT termination causes are tested with a live sibling: Close, RESET,
EOF, STOP, semantic flow violation and malformed capsule. Each preserves the
sibling handle, child traffic, full budget snapshot and route. Interleaved
queued datagrams retain only the sibling's original connection-wide ordinals
1/3/5/7, FIFO payloads, and lifetime drop counter 1. Late retired-SID datagrams
are rejected; subsequent sibling delivery retains ordinal 9.

The Debug raw output captures actual partial native CONNECT acceptance:

```text
isolated credit output Aaccepted=462 Apending=2/7 Adesired=463 Bdata=3 Bbidi=3 Buni=3
```

A's advertised limit stays 462 while only 2 of its pending capsule's 7 bytes
are accepted. Meanwhile B emits and fully accepts its own data, BIDI and UNI
grants on CONNECT 4. Resuming A's public read interest completes its wire
recovery without changing B's snapshot. New tests do not mutate private Native
settings or receive windows.

The separate refusal case checks HTTP 403 with no B session-open/close notice,
retirement of B's queued early child/debt/datagram, survival of A's handle,
child, budget and queued datagrams, stale B delivery rejection, and admission
of fresh SID 8. Queued A/fresh-B datagrams retain ordinals 0/1/2.

## Preserved fixture failures and corrections

All unsuccessful trial sources and raw logs are retained and labeled in the
JSON. They do not weaken the final assertions:

- An initial budget case filled all eight Root stream slots before its final
  HTTP request. It now performs public FIN and asserts slot reclamation before
  checking HTTP recovery.
- The initial cooldown expectation incorrectly required immediate zero Native
  leases. Diagnostics show CONNECT 0 still has an unknown final size on a
  going-away connection after both logical sessions close. The corrected case
  first requires exact-once shutdown notices, cleared records/index, children,
  pending stores, retries and FIFO, with no further application data. It then
  sends a real peer FIN and requires complete Root lease release without
  duplicate notices. The separate connection-abort branch drains without FIN.
  No production abort or forced final-offset accounting was added.
- The first refusal compile needed an explicit conversion between two named
  key types. This was a fixture compile error, with no runtime verdict.
- An initial refusal trial attempted a redundant FIN on an already-closed
  Native CONNECT. The corrected case requires the actual close callback
  exactly once and a null native stream before proceeding.

Historical status metadata initially pointed failed refusal rows at filenames
later used by corrected logs. Those rows now point to the exact preserved
redundant-FIN failures; the observed corrected Debug status 0 was appended.
The original TSVs remain byte-for-byte under `historical_original_matrix_statuses`.
[matrix_provenance_repairs.json](matrix_provenance_repairs.json) records hashes,
old/new paths, source bindings, and observed file mtimes without inventing
execution timestamps. Independent review verified all corrected rows and seven
repair hashes. Raw log content was never normalized.

Passing logs retain the existing `unowned child receive cancellation failed:
invalid` warnings and occasional literal `failed command` diagnostics alongside
terminal status 0 and passing build summaries.

## Limits

Graceful cooldown logically retires sessions but may await peer FIN or later
connection teardown for physical Native CONNECT release. Shared-Native tests
do not establish independent-client acceptance. Native accept-API failure was
not forced through new test hooks; Root owns its static rollback review.
Two inherited datagram reset-credit tests retain their explicitly labeled
private-window step. Dedicated smoke, security, sanitizer, fuzz and scan
campaigns were deferred and were not run. Caches, binaries, certificates,
private keys and credentials are excluded from the archive.
