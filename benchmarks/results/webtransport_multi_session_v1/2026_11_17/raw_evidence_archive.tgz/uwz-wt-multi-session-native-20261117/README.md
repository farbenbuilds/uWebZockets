# Same-connection WebTransport multi-session functional fixture

This fixture runs ordinary functional cases through the configured App, real
TLS, and loopback UDP. It changes no dependency pin, maintained fork, or Native
source. Dedicated smoke, security, sanitizer, fuzz, and scan campaigns remain
deferred.

`project_red` retains Root commit
`c5b4a423b09288f10e9f0f7b96af05c618bb3e6b`, before the bilateral-positive
second-CONNECT gate relaxation. `project_v1` retains the tested implementation.
Source manifests, independent copy checks, trial sources, and raw results live
in the sibling `uwz-wt-multi-session-evidence-20261117` directory.

Run `sh replay.sh MODE multi`, `sh replay.sh MODE flow`,
`sh replay.sh MODE debt`, or `sh replay.sh MODE datagrams`. MODE is Debug,
ReleaseSafe, or ReleaseFast. The separate multi-session driver has 11 cases;
some cases contain an explicit scenario table. The unchanged inherited drivers
have 18 positive-flow, 77 combined stream/debt, and 33 datagram cases. These
drivers share helpers and feature scenarios; the counts are not disjoint.
`multi11` selects the immutable baseline copy. A separate `refusal` driver
uses a copied support module to prove the later authorization-refusal case;
the 11-case matrix sources were never changed for that addition.

The new suite exercises two live CONNECTs with different SIDs/routes on one
Native connection; peer UNI/BIDI and local child routing; independent sender
data/BIDI/UNI limits, grants and writable notifications; early future-session
debt and pre-authorization rejection; six scoped termination causes preserving
sibling children, budgets, datagram FIFO order, original connection-wide
ordinals and the lifetime drop counter; flow-off/unilateral rejection followed
by a later fresh session; draining policy; connection-wide cleanup; forced
full-pool lease reuse; and independently blocked CONNECT credit writers.

Cooldown is graceful. The test first verifies exact-once logical retirement,
cleared session records/index, children, pending debt/datagrams, retries and
application FIFO. It then records the lingering Native CONNECT lease with
unknown final size, sends a real peer FIN, and requires complete Root lease
release without duplicate notices. It does not claim cooldown autonomously
finishes every CONNECT. The separate connection-abort path requires complete
release without a peer FIN. The earlier premature-zero-lease expectation and
its raw diagnostics are retained as a fixture-policy correction, not as a
production regression.

Reproduce the actual second-CONNECT RED with:

```sh
UWZ_PROJECT_SOURCE="$PWD/project_red" sh replay.sh Debug multi-red
```

The RED driver intentionally retains the original singleton observer used to
prove pre-authorization H3_REQUEST_REJECTED on the old source. The separate
multi driver supplies per-SID observers for the resulting implementation.

The C client and all inherited tests are byte-identical to the finalized
positive-flow fixture. Two inherited datagram reset-credit cases retain a
private native receive-window increment before real wire updates:
"actual App retries blocked message reset after real peer response credit" and
"actual App retries reset after blocked Close capsule delays local FIN".
The inherited callback-order injection retains its original scope and label.
New cases use startup settings, public stream operations/read interest, actual
CONNECT capsules and actual UDP datagrams; they do not mutate private Native
settings or receive windows.

The reviewed Native source is
`d1104a9fab040af659295a95fb448c971a7bc6de`; libxev is
`5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`; compiler is Zig 0.16.0. Both
external source artifacts and their exact archive SHA256 values are recorded
in the evidence metadata. Compiler, packages, Native and libxev remain external
inputs. Set `UWZ_ZIG`, `UWZ_PACKAGE_DIR`, `UWZ_LSQUIC_SOURCE`, and
`UWZ_LIBXEV_SOURCE` after relocation. `UWZ_PROJECT_SOURCE`, `UWZ_CACHE_DIR`,
`UWZ_TEST_FILTER`, `UWZ_EVIDENCE_DIR`, and `ZIG_GLOBAL_CACHE_DIR` override replay
and matrix paths. Retained loopback runs use host permission and `login=false`.
After extraction, the default project source and local build cache are relative
to the fixture directory. The `multi-red` selector defaults to `project_red`;
other selectors default to `project_v1`.

These shared-Native functional cases do not establish independent-client
acceptance, dependency-fork publication, or performance measurements.
