#!/usr/bin/env python3
"""Reconcile complete getter purity records without running native programs."""
import hashlib
import json
from pathlib import Path
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    base = Path(__file__).resolve().parent
    assert sys.argv[1:] in [[], ['--check-only']]
    current = json.loads((base / 'prebuilt_identity.json').read_text())
    historical = json.loads((base / 'original_measured_identity.json').read_text())
    assert set(current['binaries']) == set(historical['binaries']) and len(current['binaries']) == 4
    expected_status = {'null': 0, 'server': 0, 'fresh': 1, 'ready': 2, 'policy': 0, 'partial': 1}
    reason_order = [1201, 1202, 1203, 1204, 1205, 1204, 1202, 1201, 1202, 1201, 1202]
    entries = {1201: (101, 3, 'purity_first.cc', 'short text'),
               1202: (202, 3, 'purity_second.cc', 'L' * 512),
               1203: (303, 0, 'purity_third.cc', ''),
               1204: (404, 3, 'purity_fourth.cc', ''),
               1205: (505, 3, 'purity_fifth.cc', 'last text')}
    all_rows = {}
    records = []
    for image in ['interim_once_red_alias', 'final_pure']:
        directory = base / image
        result = json.loads((directory / 'result.json').read_text())
        assert result['complete'] and result['private_pki_removed'] and not (directory / 'private_pki').exists()
        commands = json.loads((directory / 'commands.json').read_text())
        assert len(commands) == 17 and all(row['exit_code'] == row['expected_exit_code'] for row in commands)
        for name, checksum in result['binaries'].items():
            assert historical['binaries'][image + '/' + name] == checksum
            assert sha(directory / name) == current['binaries'][image + '/' + name]
        for program in ['allocator_only', 'once_observed']:
            for suite in ['0x1301', '0x1302', '0x1303']:
                observe = directory / (program + '_' + suite + '_observe.jsonl')
                strict = directory / (program + '_' + suite + '_strict.jsonl')
                assert observe.read_bytes() == strict.read_bytes()
                rows = [json.loads(line) for line in observe.read_text().splitlines()]
                assert rows[0]['original_counter_selftest_bytes'] == 63
                assert rows[0]['pthread_once_observer'] == (program == 'once_observed')
                assert rows[0]['direct_crypto_once_instrumentation'] is False
                queries = [row for row in rows if 'state_unchanged' in row]
                cold = [row for row in rows if 'getter_did_not_warm_err' in row]
                queues = [row for row in rows if 'fifo_full_metadata_text_flags' in row]
                errors = [row for row in rows if 'error_observation' in row]
                assert len(queries) == 30 and len(cold) == 6 and len(queues) == 6 and len(errors) == 66
                for row in queries:
                    case = row['case'].split('_', 1)[1]
                    assert row['status'] == expected_status[case]
                    assert row['state_unchanged'] and row['observers_unchanged']
                    assert all(row[key] == 0 for key in ['malloc', 'calloc', 'realloc', 'free', 'bytes'])
                    once = (10 if suite == '0x1302' else 7) if image == 'interim_once_red_alias' and program == 'once_observed' and case == 'ready' else 0
                    assert row['pthread_once'] == once
                for row in cold:
                    assert row['first_err_malloc'] == 2 and row['first_err_calloc'] == 0 and row['first_err_bytes'] == 984
                    assert row['second_err_zero'] and row['getter_did_not_warm_err']
                for row in queues:
                    assert row['fifo_full_metadata_text_flags'] and row['marks'] == [4, 2]
                    assert row['short_and_long_popped_pointer_preserved']
                    observed = [entry for entry in errors if entry['case'] == row['case']]
                    assert [entry['reason'] for entry in observed] == reason_order
                    for entry in observed:
                        line, flags, file, data = entries[entry['reason']]
                        assert (entry['line'], entry['flags'], entry['file'], entry['data']) == (line, flags, file, data)
                        assert entry['packed'] >> 24 == 16
                if program == 'once_observed':
                    assert rows[1] == {'public_pthread_calibration': True, 'observed_entries': 2, 'initializer': 1}
                    assert rows[2] == {'bssl_once_chain_calibration': True, 'requested_calls': 2, 'observed_pthread_entries': 2, 'initializer': 1}
                expected_impure = 5 if image == 'interim_once_red_alias' and program == 'once_observed' else 0
                assert rows[-1] == {'functional_checks_complete': True, 'impure_getters': expected_impure}
                records.append({'image': image, 'program': program, 'suite': suite,
                                'getter_rows_per_selector': 30, 'cold_threads_per_selector': 6,
                                'queue_metadata_rows_per_selector': 66,
                                'observed_pthread_once_per_selector': sum(row['pthread_once'] for row in queries) if program == 'once_observed' else None,
                                'allocator_only_once_metric_uninstrumented': program == 'allocator_only'})
                all_rows[image, program, suite] = rows
    for program in ['allocator_only', 'once_observed']:
        for suite in ['0x1301', '0x1302', '0x1303']:
            before = all_rows['interim_once_red_alias', program, suite]
            after = all_rows['final_pure', program, suite]
            if program == 'allocator_only':
                assert before == after
                continue
            def normalize(rows):
                return [{key: value for key, value in row.items() if key not in ['pthread_once', 'impure_getters']} for row in rows]
            assert normalize(before) == normalize(after)
    assert sha(base / 'allocation_scope.c') == 'afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac'
    result = {'complete': True, 'native_program_runs': 24, 'getter_observations': 720,
              'serial_cold_thread_checks': 144, 'retained_error_metadata_rows': 1584,
              'source_interposer_unchanged': True, 'observe_strict_bytes_identical_within_each_variant': True,
              'baseline_final_allocator_control_records_identical': True,
              'other_baseline_final_observer_records_identical': True,
              'allowed_cross_image_fields': ['pthread_once', 'impure_getters'],
              'records': records}
    if not sys.argv[1:]:
        (base / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'records'}, indent=2))


if __name__ == '__main__':
    main()
