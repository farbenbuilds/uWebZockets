#!/usr/bin/env python3
"""Check the exact selected getter-purity payload without changing it."""
import hashlib
from pathlib import Path


def main():
    base = Path(__file__).resolve().parent
    names = (base / 'payload_files.txt').read_text().splitlines()
    hashes = {name: checksum for checksum, name in
              (line.split('  ', 1) for line in (base / 'files.sha256').read_text().splitlines())}
    assert len(names) == len(set(names)) and set(names) == set(hashes) | {'files.sha256'}
    for name, checksum in hashes.items():
        path = base / name
        assert not path.is_symlink() and path.is_file()
        assert hashlib.sha256(path.read_bytes()).hexdigest() == checksum, name
    print('PASS selected purity payload:', len(names), 'files,', len(hashes), 'checks')


if __name__ == '__main__':
    main()
