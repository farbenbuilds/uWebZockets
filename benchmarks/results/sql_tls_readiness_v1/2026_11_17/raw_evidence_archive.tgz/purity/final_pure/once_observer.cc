// Test-only glibc forwarding observer; the allocator interposer is unchanged.
#include <pthread.h>
#include <stdint.h>

// Each measured getter runs serially on the thread that owns these counters.
static thread_local bool active;
static thread_local uint64_t pthread_calls;

extern "C" int real_pthread_once(pthread_once_t *, void (*)());
__asm__(".symver real_pthread_once,__pthread_once@GLIBC_2.2.5");

extern "C" int pthread_once(pthread_once_t *once, void (*initialize)())
{
    if (active) pthread_calls++;
    return real_pthread_once(once, initialize);
}

extern "C" void purity_once_begin(void)
{
    pthread_calls = 0;
    active = true;
}

extern "C" void purity_once_end(void) { active = false; }
extern "C" uint64_t purity_pthread_once_calls(void) { return pthread_calls; }
