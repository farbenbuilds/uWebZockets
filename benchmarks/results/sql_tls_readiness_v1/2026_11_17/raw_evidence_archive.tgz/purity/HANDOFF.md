# TLS client-readiness getter purity handoff

Verified scope: the getter alone, on the recorded native non-FIPS Linux x86_64
glibc build in Debug (-O0 -g). This is separate from the author's all-six API,
64-subset, field/fault conformance and the wire consumer proof. No native source,
pin, SDK, production code or Git change was made by this verifier.

## Result

The interim once-defective image has zero measured getter heap operations, but
its READY getter enters pthread_once 7 / 10 / 7 times for AES128-GCM,
AES256-GCM and ChaCha20-Poly1305. Five READY observations per process produce
35 / 50 / 35 entries. Observe exits0; the unchanged strict purity gate exits1
only after every functional check completes. The corrected image records zero
once entries and strict exits0 for every suite.

Allocator-only controls are separate programs and report zero malloc, calloc,
realloc, non-null-free and requested bytes on both images. Their once metric is
explicitly uninstrumented, not evidence of zero once calls. The derivative uses
the same unchanged all-C counter and adds an independently identified observer.

| Image | libssl.a SHA-256 | libcrypto.a SHA-256 |
|---|---|---|
| Interim, fresh-version fixed / once defective | 7ba1be300d5a0132e05c85c0bf9219b6bc8614d27979e4a1c8762cfdb57d1249 | 81dc6cdb55911be30332fc18fee7589e7c62d87114794dc93e4546a410b42f60 |
| Final pure correction | 621c98febb1606e01423b5045beb69a8d18d0e48831790745e0a275dda9335cd | e130b330cef9b9349f4ef0e9dd381fe100dd42d287d72411adbd711ad76c551c |

The superseded initial SSL_version fallback image is not this interim control.
Its fresh-client bug belongs to the author's separate conformance evidence.
The interim header subset exactly matches Root's immutable initial header tree;
interim_stage_readiness.patch and interim_build_commands.json retain the exact
version-fixed source/build lineage. Matching interim archives were copied before
the author replaced owned artifacts. Final compilation used corrected headers
and exactly the final matching archives above.

## Focused cases and measured boundary

Each image executes two programs, three independent singleton-suite processes,
and observe/strict selectors: 12 runs, 360 getter calls. Across both images,
24 primary runs retain 720 getter observations, 144 serial cold-thread checks
and 1,584 complete synthetic error-metadata observations. Observe/strict raw
records are byte-identical within each program/suite/image.

Every run checks null, server, fresh client, completed READY, callback-policy
UNSUPPORTED and authentic partial-handshake PENDING. CA/localhost verification,
TLS1.3 and both actual negotiated suite IDs are asserted. The pending case seals
a real three-byte KeyUpdate prefix on the server and consumes it with public
client SSL_read/WANT_READ. Native pending is present while SSL_pending,
SSL_has_pending and external BIO pending all report0. No client crypto, sequence,
key or session state is fabricated. This purity fixture does not replace the
wire completion/consumer proof.

The all-C counter covers only the complete getter. Its original source SHA is
`afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac`;
each native invocation passes malloc1/calloc1/realloc1/free2/63-byte self-test.
No counter filtering, threshold change or prewarming workaround was introduced.

Each cold case transfers the SSL serially to a new pthread. Before its getter,
that worker performs no ERR call. An independently counted subsequent first
ERR_peek_error then records2 mallocs/984 requested bytes; a second ERR call
records zero operations. The getter therefore did not create/warm that worker's
ERR state. pthread creation, protocol setup, logging and teardown are outside
the getter interval. No unrelated algorithm factory is manually warmed.

Populated queue cases cover five distinct reason/file/line entries, no-data
versus empty-data flags, inline text and a512-byte long string, exact FIFO, two
marks with pop-to-mark results4 then2, and both short and long popped pointers
remaining valid across the getter. Raw records retain actual packed codes,
files, lines, flags and complete synthetic text. The getter cannot append an
error even for null/server/policy rejection without failing these checks.

Whole SSLImpl/S3 representations are compared in memory around every getter,
then cleansed. No SSL/key/session bytes or hashes are persisted. Calibrated trap
BIO read/write/control callbacks and message/info/session observers must remain
unchanged. Direct trap read/write/control calls prove the BIO counters work;
real handshake message/info callbacks are required positive controls.

## Separate real once observer

The attempted GNU --wrap link failed in pinned Zig c++ argument parsing, both
with its default linker and an attempted -fuse-ld=lld selection. Those failed
source/command/stderr snapshots remain selected as tool-limit evidence; their
preliminary executables/objects are not selected. No new linker requirement was
added and the failure was not treated as a native result.

The accepted observer instead defines public pthread_once in the derivative
executable and forwards every call, with identical arguments/return value, to
`__pthread_once@GLIBC_2.2.5`. Actual libc dynamic symbols show that real alias at
the same address as both public pthread_once versions. Actual derivative ELF
symbols show the public definition and versioned real import.

The exact unchanged crypto/thread_pthread.cc lines45-47 are:

    void CRYPTO_once(CRYPTO_once_t *once, void (*init)()) {
      BSSL_CHECK(pthread_once(once, init) == 0);
    }

This Linux/pthread source chain unconditionally reaches the observed public
entry. Direct CRYPTO_once instrumentation is explicitly false in the reports;
there is no invented direct counter. Calibration outside getter scope calls
public pthread_once twice and then bssl::CRYPTO_once twice on separate local
controls: each group records2 entries and exactly1 real initializer invocation.
No dlsym, native/archive mutation, lazy observer initialization inside the getter,
or method-call filtering is used. The observer counts warm entries as well.
`once_observer_provenance.json`, symbol outputs and the exact source snapshot
bind the chain. This is not a FIPS or cross-platform validation claim.

## Reconciliation and replay

verify_results.py independently checks all raw query statuses, heap/once counts,
first/second ERR controls, full synthetic FIFO metadata/marks/pointer results,
calibration, command statuses, executable identities and PKI removal. Baseline
and final allocator-only records match exactly. In derivative records, only the
strictly checked pthread_once count and impure_getters summary differ.

The source-free replay validates four current executable IDs, uses no compiler,
headers or native archive, runs24 programs/720 getter calls and requires every
raw result to match retained bytes. Its completed26-command producer replay is
prebuilt_replay/. Private PKI was removed. Six replay guards reject existing,
protected child, combined native/wire siblings, dangling output and wrong helper
paths before mutation. replay_stage/ and guard_root/ are unselected scratch.

Current executable validation uses prebuilt_identity.json. The byte-identical
original_measured_identity.json and per-run result/provenance IDs are historical
original Debug measurements. A delivery-only strip may update only current
binary hashes and the existing delivery_stripping flag, with an archived
original map and explicit ELF proof; historical measured IDs remain unchanged.

## Exact commands and retained inputs

Primary roots are relative to /home/foo/Desktop/Repos/uWebZockets. The two full
build/replay invocations are recorded below; every compiler/native invocation,
expected status and stdout/stderr is in each image's commands.json.

```sh
env PYTHONDONTWRITEBYTECODE=1 python3 .zig-cache/sql-tls-readiness-purity-20261117/run_purity.py --headers /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-preparation-integration-20261117/boringssl --ssl /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-readiness-purity-20261117/interim_once_red_libs/libssl.a --crypto /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-readiness-purity-20261117/interim_once_red_libs/libcrypto.a --ssl-sha256 7ba1be300d5a0132e05c85c0bf9219b6bc8614d27979e4a1c8762cfdb57d1249 --crypto-sha256 81dc6cdb55911be30332fc18fee7589e7c62d87114794dc93e4546a410b42f60 --pki-tool /tmp/uwz-wt-upstream-backport-client-20261117/client/wt-tools --output /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-readiness-purity-20261117/interim_once_red_alias --expect-once-red
env PYTHONDONTWRITEBYTECODE=1 python3 .zig-cache/sql-tls-readiness-purity-20261117/run_purity.py --headers /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-client-readiness-fixed-20261117/boringssl --ssl /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-client-readiness-fixed-20261117/native_out/lib/libssl.a --crypto /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-client-readiness-fixed-20261117/native_out/lib/libcrypto.a --ssl-sha256 621c98febb1606e01423b5045beb69a8d18d0e48831790745e0a275dda9335cd --crypto-sha256 e130b330cef9b9349f4ef0e9dd381fe100dd42d287d72411adbd711ad76c551c --pki-tool /tmp/uwz-wt-upstream-backport-client-20261117/client/wt-tools --output /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-readiness-purity-20261117/final_pure
env PYTHONDONTWRITEBYTECODE=1 python3 .zig-cache/sql-tls-readiness-purity-20261117/verify_results.py --check-only
env PYTHONDONTWRITEBYTECODE=1 python3 .zig-cache/sql-tls-readiness-purity-20261117/replay_stage/replay_prebuilt.py --pki-tool /tmp/uwz-wt-upstream-backport-client-20261117/client/wt-tools --output /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-readiness-purity-20261117/prebuilt_replay
```

Original successful build outputs are interim_once_red_alias/ and final_pure/;
these exact recorded commands cannot overwrite existing outputs; choose new absent output paths for a repeat. The compiler is pinned Zig0.16.0 SHA
`2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c`.
The offline PKI helper SHA is
`531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9`.
All new bulk source/cache/results stayed on workspace SSD. Native archives,
objects, caches, private PKI, preliminary binaries and replay-stage copies are
excluded from the selected payload. Source snapshots and provenance retain the
original counter, helper lineage, native source hashes and observer chain.

Dedicated smoke/security/sanitizer/fuzz/scan campaigns were neither run nor
claimed. This proves the scoped getter contract on the recorded target; it does
not close native publication, consumer integration, full SQL request allocation
or platform/release gates. Root owns combined final delivery/replay and pushes
to impl/implement-2.3.0.
