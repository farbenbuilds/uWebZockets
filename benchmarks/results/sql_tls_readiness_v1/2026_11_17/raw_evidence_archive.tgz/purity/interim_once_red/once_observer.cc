// Test-only derivative observer; the original allocator interposer is unchanged.
#include <pthread.h>
#include <stdint.h>

// Each measured getter runs serially on the thread that owns these counters.
static thread_local bool active;
static thread_local uint64_t crypto_calls;
static thread_local uint64_t pthread_calls;

extern "C" void real_crypto_once(int *, void (*)())
    __asm__("__real__ZN4bssl11CRYPTO_onceEPiPFvvE");
extern "C" void wrapped_crypto_once(int *, void (*)())
    __asm__("__wrap__ZN4bssl11CRYPTO_onceEPiPFvvE");
extern "C" int __real_pthread_once(pthread_once_t *, void (*)());

extern "C" void wrapped_crypto_once(int *once, void (*initialize)())
{
    if (active) crypto_calls++;
    real_crypto_once(once, initialize);
}

extern "C" int __wrap_pthread_once(pthread_once_t *once, void (*initialize)())
{
    if (active) pthread_calls++;
    return __real_pthread_once(once, initialize);
}

extern "C" void purity_once_begin(void)
{
    crypto_calls = pthread_calls = 0;
    active = true;
}

extern "C" void purity_once_end(void) { active = false; }
extern "C" uint64_t purity_crypto_once_calls(void) { return crypto_calls; }
extern "C" uint64_t purity_pthread_once_calls(void) { return pthread_calls; }
