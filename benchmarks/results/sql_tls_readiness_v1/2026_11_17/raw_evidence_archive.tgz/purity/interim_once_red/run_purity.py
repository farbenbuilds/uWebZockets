#!/usr/bin/env python3
"""Compile focused getter purity controls with immutable native identities."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--headers', type=Path, required=True)
    parser.add_argument('--ssl', type=Path, required=True)
    parser.add_argument('--crypto', type=Path, required=True)
    parser.add_argument('--ssl-sha256', required=True)
    parser.add_argument('--crypto-sha256', required=True)
    parser.add_argument('--pki-tool', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--expect-once-red', action='store_true')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    output = args.output.absolute()
    if output.exists() or output.is_symlink() or output == base or not output.resolve().is_relative_to(base):
        raise ValueError('Choose an absent output strictly within this owned scratch')
    headers = args.headers.resolve(strict=True)
    ssl = args.ssl.resolve(strict=True)
    crypto = args.crypto.resolve(strict=True)
    helper = args.pki_tool.resolve(strict=True)
    zig = Path('/tmp/zig-x86_64-linux-0.16.0/zig')
    if sha(ssl) != args.ssl_sha256 or sha(crypto) != args.crypto_sha256:
        raise ValueError('Matching native archive identities differ')
    if sha(zig) != '2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c':
        raise ValueError('Compiler identity differs')
    if sha(helper) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('Offline PKI tool identity differs')
    if sha(base / 'allocation_scope.c') != 'afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac':
        raise ValueError('Original allocator interposer differs')
    output.mkdir(mode=0o700)
    for name in ['purity_witness.cc', 'once_observer.cc', 'allocation_scope.c', 'run_purity.py']:
        shutil.copy2(base / name, output / name)
    header_names = ['include/openssl/ssl.h', 'include/openssl/err.h', 'include/openssl/bio.h',
                    'crypto/internal.h', 'ssl/internal.h']
    provenance = {'headers': str(headers), 'header_sha256': {name: sha(headers / name) for name in header_names},
                  'archives': {'libssl.a': sha(ssl), 'libcrypto.a': sha(crypto)},
                  'archive_paths': {'libssl.a': str(ssl), 'libcrypto.a': str(crypto)},
                  'compiler_sha256': sha(zig), 'pki_tool_sha256': sha(helper),
                  'fixture_sha256': {name: sha(base / name) for name in ['purity_witness.cc', 'once_observer.cc', 'allocation_scope.c']},
                  'optimization': 'Debug (-O0 -g)', 'expect_once_red': args.expect_once_red,
                  'observer_scope': 'Separate true-forwarding CRYPTO_once/pthread_once derivative; original allocator unchanged',
                  'target_scope': 'Native non-FIPS Linux x86_64; no FIPS validation claim'}
    (output / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    environment = dict(os.environ)
    environment['ZIG_GLOBAL_CACHE_DIR'] = str(base / 'zig_global_cache')
    commands = []
    def run(command, label, expected=0):
        with (output / (label + '.stdout')).open('wb') as out, (output / (label + '.stderr')).open('wb') as err:
            result = subprocess.run(command, cwd=output, env=environment, stdout=out, stderr=err)
        commands.append({'command': command, 'exit_code': result.returncode, 'expected_exit_code': expected})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        print(label, result.returncode, flush=True)
        if result.returncode != expected:
            raise RuntimeError('Unexpected command status: ' + label)
    private_pki = output / 'private_pki'
    complete = False
    summaries = []
    try:
        run([str(zig), 'cc', '-std=c11', '-O0', '-g', '-c', str(base / 'allocation_scope.c'),
             '-o', str(output / 'allocation_scope.o')], 'compile-counter')
        run([str(zig), 'c++', '-std=c++17', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
             '-c', str(base / 'once_observer.cc'), '-o', str(output / 'once_observer.o')], 'compile-once-observer')
        for observer in [False, True]:
            name = 'once_observed' if observer else 'allocator_only'
            command = [str(zig), 'c++', '-std=c++17', '-O0', '-g', '-fno-omit-frame-pointer',
                       '-Wall', '-Wextra', '-Werror', '-DBORINGSSL_IMPLEMENTATION',
                       '-DUWZ_ONCE_OBSERVER=' + str(int(observer)), '-isystem', str(headers),
                       '-isystem', str(headers / 'include'), str(base / 'purity_witness.cc'),
                       str(output / 'allocation_scope.o')]
            if observer:
                command += [str(output / 'once_observer.o'),
                            '-Wl,--wrap=_ZN4bssl11CRYPTO_onceEPiPFvvE', '-Wl,--wrap=pthread_once']
            command += [str(ssl), str(crypto), '-pthread', '-o', str(output / name)]
            run(command, 'compile-' + name)
        run([str(helper), 'pki', str(private_pki)], 'offline-pki')
        for observer in [False, True]:
            name = 'once_observed' if observer else 'allocator_only'
            for suite in ['0x1301', '0x1302', '0x1303']:
                raw = []
                for mode in ['observe', 'strict']:
                    label = name + '_' + suite + '_' + mode
                    report = output / (label + '.jsonl')
                    expected = int(mode == 'strict' and observer and args.expect_once_red)
                    command = [str(output / name), *[str(private_pki / n) for n in ['server.pem', 'server.key', 'ca.pem']],
                               suite, str(report), mode]
                    run(command, label, expected)
                    rows = [json.loads(line) for line in report.read_text().splitlines()]
                    query_rows = [row for row in rows if 'state_unchanged' in row]
                    cold_rows = [row for row in rows if 'getter_did_not_warm_err' in row]
                    queue_rows = [row for row in rows if 'fifo_full_metadata_text_flags' in row]
                    CHECKS = (len(query_rows) == 30 and len(cold_rows) == 6 and len(queue_rows) == 6
                              and rows[-1]['functional_checks_complete']
                              and all(all(row[k] == 0 for k in ['malloc', 'calloc', 'realloc', 'free', 'bytes']) for row in query_rows))
                    if not CHECKS:
                        raise ValueError('Focused purity result scope/counts differ')
                    once_total = sum(row['crypto_once'] + row['pthread_once'] for row in query_rows)
                    if observer and args.expect_once_red:
                        if once_total == 0 or rows[-1]['impure_getters'] == 0:
                            raise ValueError('Expected genuine once-path RED was not observed')
                    elif once_total != 0 or rows[-1]['impure_getters'] != 0:
                        raise ValueError('Expected pure getter result differs')
                    summaries.append({'program': name, 'suite': suite, 'mode': mode,
                                      'getter_calls': len(query_rows), 'cold_serial_threads': len(cold_rows),
                                      'queue_cases': len(queue_rows), 'once_calls': once_total,
                                      'impure_getters': rows[-1]['impure_getters'], 'exit_code': expected})
                    raw.append(report.read_bytes())
                if raw[0] != raw[1]:
                    raise ValueError('Observe and strict data differ')
        complete = True
    finally:
        if private_pki.exists():
            entries = list(private_pki.iterdir())
            if {p.name for p in entries} - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected private PKI file')
            for path in entries:
                path.unlink()
            private_pki.rmdir()
        (output / 'result.json').write_text(json.dumps({'complete': complete, 'private_pki_removed': not private_pki.exists(),
            'summaries': summaries, 'binaries': {name: sha(output / name) for name in ['allocator_only', 'once_observed'] if (output / name).exists()}}, indent=2) + '\n')
    print('PASS focused getter purity; expected once RED=' + str(args.expect_once_red))


if __name__ == '__main__':
    main()
