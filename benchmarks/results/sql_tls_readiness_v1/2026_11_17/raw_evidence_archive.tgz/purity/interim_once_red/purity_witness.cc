#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/mem.h>
#include <openssl/ssl.h>
#include <openssl/ssl3.h>
#include <openssl/x509_vfy.h>
#include "ssl/internal.h"
#include <initializer_list>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK(value) do { if (!(value)) fail(__LINE__, #value); } while (0)

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
#if UWZ_ONCE_OBSERVER
void purity_once_begin(void);
void purity_once_end(void);
uint64_t purity_crypto_once_calls(void);
uint64_t purity_pthread_once_calls(void);
#endif
}

struct allocation_counts {
    uint64_t malloc_calls, calloc_calls, realloc_calls, free_calls, bytes;
};

struct observer_counts {
    uint64_t bio_read, bio_write, bio_ctrl, message, info, session;
};

struct tls_pair {
    SSL_CTX *client_context, *server_context;
    SSL *client, *server;
    observer_counts observers;
};

struct state_snapshot {
    bool present, has_s3;
    unsigned char ssl[sizeof(bssl::SSLImpl)];
    unsigned char s3[sizeof(bssl::SSL3_STATE)];
};

struct query_result {
    int status;
    allocation_counts counts;
    uint64_t crypto_once, pthread_once;
    bool state_unchanged, observers_unchanged;
};

struct thread_case {
    const char *label;
    SSL *ssl;
    int expected;
    observer_counts *observers;
    query_result result;
    allocation_counts first_err, second_err;
};

static void fail(int line, const char *expression)
{
    fprintf(stderr, "check failed at line %d: %s\n", line, expression);
    abort();
}

static allocation_counts counts(void)
{
    return {uwz_alloc_malloc_calls(), uwz_alloc_calloc_calls(),
        uwz_alloc_realloc_calls(), uwz_alloc_free_calls(), uwz_alloc_requested_bytes()};
}

static bool empty_counts(allocation_counts value)
{
    return value.malloc_calls == 0 && value.calloc_calls == 0 &&
        value.realloc_calls == 0 && value.free_calls == 0 && value.bytes == 0;
}

static void save_state(state_snapshot *snapshot, const SSL *ssl)
{
    snapshot->present = ssl != nullptr;
    if (ssl == nullptr) return;
    const auto *native = bssl::FromOpaque(ssl);
    memcpy(snapshot->ssl, native, sizeof(*native));
    snapshot->has_s3 = native->s3 != nullptr;
    if (native->s3) memcpy(snapshot->s3, native->s3, sizeof(*native->s3));
}

static bool state_equal(const state_snapshot *snapshot, const SSL *ssl)
{
    if (!snapshot->present) return ssl == nullptr;
    const auto *native = bssl::FromOpaque(ssl);
    return memcmp(snapshot->ssl, native, sizeof(*native)) == 0 &&
        snapshot->has_s3 == (native->s3 != nullptr) &&
        (!native->s3 || memcmp(snapshot->s3, native->s3, sizeof(*native->s3)) == 0);
}

static query_result measure_query(SSL *ssl, observer_counts *observers)
{
    state_snapshot before{};
    save_state(&before, ssl);
    const observer_counts previous = observers ? *observers : observer_counts{};
#if UWZ_ONCE_OBSERVER
    purity_once_begin();
#endif
    uwz_alloc_begin();
    const int status = SSL_get_client_storage_readiness(ssl);
    uwz_alloc_end();
#if UWZ_ONCE_OBSERVER
    purity_once_end();
    const uint64_t crypto_once = purity_crypto_once_calls();
    const uint64_t pthread_once = purity_pthread_once_calls();
#else
    const uint64_t crypto_once = 0, pthread_once = 0;
#endif
    const allocation_counts measured = counts();
    const bool unchanged = state_equal(&before, ssl);
    // Object snapshots remain in memory only and may contain traffic secrets.
    OPENSSL_cleanse(&before, sizeof(before));
    return {status, measured, crypto_once, pthread_once, unchanged,
        !observers || memcmp(&previous, observers, sizeof(previous)) == 0};
}

static unsigned int record(FILE *output, const char *label, query_result result, int expected)
{
    CHECK(result.status == expected && result.state_unchanged && result.observers_unchanged);
    fprintf(output, "{\"case\":\"%s\",\"status\":%d,\"malloc\":%llu,\"calloc\":%llu,\"realloc\":%llu,\"free\":%llu,\"bytes\":%llu,\"crypto_once\":%llu,\"pthread_once\":%llu,\"state_unchanged\":true,\"observers_unchanged\":true}\n",
        label, result.status, (unsigned long long)result.counts.malloc_calls,
        (unsigned long long)result.counts.calloc_calls, (unsigned long long)result.counts.realloc_calls,
        (unsigned long long)result.counts.free_calls, (unsigned long long)result.counts.bytes,
        (unsigned long long)result.crypto_once, (unsigned long long)result.pthread_once);
    return !empty_counts(result.counts) || result.crypto_once != 0 || result.pthread_once != 0;
}

static void *cold_thread(void *argument)
{
    auto *row = static_cast<thread_case *>(argument);
    row->result = measure_query(row->ssl, row->observers);
    // The first ERR operation is deliberately after the counted getter.
    uwz_alloc_begin();
    const uint32_t first = ERR_peek_error();
    uwz_alloc_end();
    row->first_err = counts();
    uwz_alloc_begin();
    const uint32_t second = ERR_peek_error();
    uwz_alloc_end();
    row->second_err = counts();
    CHECK(first == 0 && second == 0);
    CHECK(row->first_err.malloc_calls + row->first_err.calloc_calls > 0);
    CHECK(empty_counts(row->second_err));
    return nullptr;
}

static unsigned int run_cold(FILE *output, const char *label, SSL *ssl, int expected,
                            observer_counts *observers)
{
    thread_case row{label, ssl, expected, observers, {}, {}, {}};
    pthread_t thread;
    CHECK(pthread_create(&thread, nullptr, cold_thread, &row) == 0);
    CHECK(pthread_join(thread, nullptr) == 0);
    const unsigned int impure = record(output, label, row.result, expected);
    fprintf(output, "{\"case\":\"%s\",\"first_err_malloc\":%llu,\"first_err_calloc\":%llu,\"first_err_bytes\":%llu,\"second_err_zero\":true,\"getter_did_not_warm_err\":true}\n",
        label, (unsigned long long)row.first_err.malloc_calls,
        (unsigned long long)row.first_err.calloc_calls, (unsigned long long)row.first_err.bytes);
    return impure;
}

static void message_callback(int, int, int, const void *, size_t, SSL *, void *argument)
{
    static_cast<observer_counts *>(argument)->message++;
}

static void info_callback(const SSL *ssl, int, int)
{
    static_cast<observer_counts *>(SSL_get_app_data(ssl))->info++;
}

static int session_callback(SSL *ssl, SSL_SESSION *)
{
    static_cast<observer_counts *>(SSL_get_app_data(ssl))->session++;
    return 0;
}

static void peer_result(SSL *ssl, int result)
{
    if (result > 0) return;
    const int error = SSL_get_error(ssl, result);
    CHECK(error == SSL_ERROR_WANT_READ || error == SSL_ERROR_WANT_WRITE);
}

static void configure_pair(tls_pair *pair, const char *certificate, const char *key,
                           const char *ca, uint16_t suite)
{
    pair->client_context = SSL_CTX_new(TLS_method());
    pair->server_context = SSL_CTX_new(TLS_method());
    CHECK(pair->client_context && pair->server_context);
    for (SSL_CTX *context : {pair->client_context, pair->server_context}) {
        CHECK(SSL_CTX_set1_tls13_ciphers(context, &suite, nullptr, 1));
        CHECK(SSL_CTX_set_min_proto_version(context, TLS1_3_VERSION));
        CHECK(SSL_CTX_set_max_proto_version(context, TLS1_3_VERSION));
        SSL_CTX_set_msg_callback(context, message_callback);
        SSL_CTX_set_msg_callback_arg(context, &pair->observers);
    }
    CHECK(SSL_CTX_set_num_tickets(pair->server_context, 0));
    SSL_CTX_set_session_cache_mode(pair->client_context, SSL_SESS_CACHE_SERVER);
    CHECK(SSL_CTX_use_certificate_chain_file(pair->server_context, certificate));
    CHECK(SSL_CTX_use_PrivateKey_file(pair->server_context, key, SSL_FILETYPE_PEM));
    CHECK(SSL_CTX_check_private_key(pair->server_context));
    CHECK(SSL_CTX_load_verify_locations(pair->client_context, ca, nullptr));
    SSL_CTX_set_verify(pair->client_context, SSL_VERIFY_PEER, nullptr);
    pair->client = SSL_new(pair->client_context); pair->server = SSL_new(pair->server_context);
    CHECK(pair->client && pair->server);
    CHECK(SSL_set_tlsext_host_name(pair->client, "localhost"));
    CHECK(SSL_set1_host(pair->client, "localhost"));
    CHECK(SSL_set_app_data(pair->client, &pair->observers));
    CHECK(SSL_set_app_data(pair->server, &pair->observers));
    SSL_set_info_callback(pair->client, info_callback); SSL_set_info_callback(pair->server, info_callback);
    SSL_set_connect_state(pair->client); SSL_set_accept_state(pair->server);
    BIO *client_bio = nullptr, *server_bio = nullptr;
    CHECK(BIO_new_bio_pair(&client_bio, 1024, &server_bio, 1024));
    SSL_set_bio(pair->client, client_bio, client_bio);
    SSL_set_bio(pair->server, server_bio, server_bio);
}

static void complete_pair(tls_pair *pair, uint16_t suite)
{
    bool client = false, server = false;
    for (unsigned int i = 0; i < 10000 && (!client || !server); i++) {
        if (!client) { const int result = SSL_do_handshake(pair->client); client = result == 1; if (!client) peer_result(pair->client, result); }
        if (!server) { const int result = SSL_do_handshake(pair->server); server = result == 1; if (!server) peer_result(pair->server, result); }
    }
    CHECK(client && server && SSL_get_verify_result(pair->client) == X509_V_OK);
    CHECK(SSL_get0_peer_certificates(pair->client) != nullptr);
    CHECK(SSL_version(pair->client) == TLS1_3_VERSION && SSL_version(pair->server) == TLS1_3_VERSION);
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->client)) == suite);
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->server)) == suite);
    CHECK(pair->observers.message > 0 && pair->observers.info > 0);
}

static int trap_create(BIO *bio) { BIO_set_init(bio, 1); return 1; }
static int trap_read(BIO *bio, char *, int) { static_cast<observer_counts *>(BIO_get_data(bio))->bio_read++; return -1; }
static int trap_write(BIO *bio, const char *, int) { static_cast<observer_counts *>(BIO_get_data(bio))->bio_write++; return -1; }
static long trap_ctrl(BIO *bio, int, long, void *) { static_cast<observer_counts *>(BIO_get_data(bio))->bio_ctrl++; return 0; }

static BIO_METHOD *trap_method(void)
{
    BIO_METHOD *method = BIO_meth_new(BIO_TYPE_FILTER, "readiness purity trap");
    CHECK(method && BIO_meth_set_create(method, trap_create));
    CHECK(BIO_meth_set_read(method, trap_read) && BIO_meth_set_write(method, trap_write));
    CHECK(BIO_meth_set_ctrl(method, trap_ctrl));
    return method;
}

static BIO *attach_trap(tls_pair *pair, BIO_METHOD *method)
{
    BIO *original = SSL_get_rbio(pair->client);
    CHECK(original == SSL_get_wbio(pair->client) && BIO_up_ref(original));
    BIO *filter = BIO_new(method);
    CHECK(filter); BIO_set_data(filter, &pair->observers);
    CHECK(BIO_push(filter, original) == filter);
    SSL_set_bio(pair->client, filter, filter);
    const observer_counts before = pair->observers;
    char byte = 0;
    CHECK(BIO_read(filter, &byte, 1) == -1 && BIO_write(filter, &byte, 1) == -1);
    CHECK(BIO_ctrl(filter, BIO_CTRL_PENDING, 0, nullptr) == 0);
    CHECK(pair->observers.bio_read == before.bio_read + 1 &&
        pair->observers.bio_write == before.bio_write + 1 &&
        pair->observers.bio_ctrl == before.bio_ctrl + 1);
    return filter;
}

static void detach_trap(tls_pair *pair, BIO *filter)
{
    BIO *original = BIO_pop(filter);
    CHECK(original); SSL_set_bio(pair->client, original, original);
}

struct expected_error { int reason, line, flags; const char *file; const char *data; };

static void push_error(expected_error expected)
{
    ERR_put_error(ERR_LIB_SSL, 0, expected.reason, expected.file, expected.line);
    if (expected.flags) ERR_set_error_data(const_cast<char *>(expected.data), ERR_FLAG_STRING);
}

static void check_error(FILE *output, const char *label, expected_error expected, bool pop)
{
    const char *file = nullptr, *data = nullptr;
    int line = 0, flags = 0;
    const uint32_t packed = pop ? ERR_get_error_line_data(&file, &line, &data, &flags)
        : ERR_peek_last_error_line_data(&file, &line, &data, &flags);
    CHECK(ERR_GET_LIB(packed) == ERR_LIB_SSL && ERR_GET_REASON(packed) == expected.reason);
    CHECK(file && strcmp(file, expected.file) == 0 && line == expected.line);
    CHECK(flags == expected.flags && data && strcmp(data, expected.data) == 0);
    fprintf(output,"{\"case\":\"%s\",\"error_observation\":true,\"pop\":%s,\"packed\":%u,\"reason\":%d,\"file\":\"%s\",\"line\":%d,\"flags\":%d,\"data\":\"%s\"}\n",
        label,pop ? "true" : "false",packed,ERR_GET_REASON(packed),file,line,flags,data);
}

static unsigned int queue_cases(FILE *output, const char *label, SSL *ssl, int status,
                                observer_counts *observers)
{
    char long_text[513]; memset(long_text, 'L', sizeof(long_text) - 1); long_text[sizeof(long_text)-1] = 0;
    const expected_error entries[] = {{1201,101,3,"purity_first.cc","short text"},
        {1202,202,3,"purity_second.cc",long_text},{1203,303,0,"purity_third.cc",""},
        {1204,404,3,"purity_fourth.cc",""},{1205,505,3,"purity_fifth.cc","last text"}};
    ERR_clear_error(); for (const auto &entry : entries) push_error(entry);
    unsigned int impure = record(output, label, measure_query(ssl, observers), status);
    for (const auto &entry : entries) check_error(output,label,entry,true);
    CHECK(ERR_get_error() == 0);
    for (size_t i = 0; i < 5; i++) { push_error(entries[i]); if (i == 1 || i == 3) CHECK(ERR_set_mark()); }
    impure += record(output, label, measure_query(ssl, observers), status);
    CHECK(ERR_pop_to_mark()); check_error(output,label,entries[3],false);
    CHECK(ERR_pop_to_mark()); check_error(output,label,entries[1],false);
    CHECK(!ERR_pop_to_mark() && ERR_peek_error() == 0);
    for (bool long_data : {false, true}) {
        const expected_error popped{1299,909,3,"purity_popped.cc",long_data ? long_text : "popped short"};
        push_error(popped); push_error(entries[0]); push_error(entries[1]);
        const char *file = nullptr, *data = nullptr; int line = 0, flags = 0;
        const uint32_t packed = ERR_get_error_line_data(&file, &line, &data, &flags);
        CHECK(ERR_GET_REASON(packed) == popped.reason && line == popped.line && flags == 3);
        CHECK(strcmp(file, popped.file) == 0 && strcmp(data, popped.data) == 0);
        impure += record(output, label, measure_query(ssl, observers), status);
        CHECK(strcmp(data, popped.data) == 0);
        check_error(output,label,entries[0],true); check_error(output,label,entries[1],true); CHECK(ERR_get_error() == 0);
    }
    fprintf(output,"{\"case\":\"%s\",\"fifo_full_metadata_text_flags\":true,\"marks\":[4,2],\"short_and_long_popped_pointer_preserved\":true}\n",label);
    return impure;
}

static void partial_control(tls_pair *pair)
{
    const uint8_t prefix[] = {SSL3_MT_KEY_UPDATE, 0, 0};
    uint8_t encrypted[128]; size_t length = 0;
    CHECK(bssl::tls_seal_record(bssl::FromOpaque(pair->server), encrypted, &length,
        sizeof(encrypted), SSL3_RT_HANDSHAKE, prefix, sizeof(prefix)));
    CHECK(BIO_write(SSL_get_wbio(pair->server), encrypted, static_cast<int>(length)) == static_cast<int>(length));
    uint8_t unused;
    const int result = SSL_read(pair->client, &unused, 1);
    CHECK(result == -1 && SSL_get_error(pair->client, result) == SSL_ERROR_WANT_READ);
    CHECK(SSL_pending(pair->client) == 0 && SSL_has_pending(pair->client) == 0);
    CHECK(BIO_ctrl_pending(SSL_get_rbio(pair->client)) == 0);
}

#if UWZ_ONCE_OBSERVER
// Calibration initializes only this local once control, not a crypto method.
static thread_local unsigned int calibration_initializers;
static void calibration_initialize(void) { calibration_initializers++; }
static void calibrate_once(FILE *output)
{
    bssl::CRYPTO_once_t once = PTHREAD_ONCE_INIT;
    purity_once_begin();
    bssl::CRYPTO_once(&once, calibration_initialize);
    bssl::CRYPTO_once(&once, calibration_initialize);
    purity_once_end();
    CHECK(purity_crypto_once_calls() == 2 && purity_pthread_once_calls() == 2);
    CHECK(calibration_initializers == 1);
    fprintf(output,"{\"observer_calibration\":true,\"crypto_once\":2,\"pthread_once\":2,\"initializer\":1}\n");
}
#endif

int main(int argc, char **argv)
{
    CHECK(argc == 7);
    const unsigned long suite_value = strtoul(argv[4], nullptr, 0);
    CHECK(suite_value == 0x1301 || suite_value == 0x1302 || suite_value == 0x1303);
    const uint16_t suite = static_cast<uint16_t>(suite_value);
    const bool strict = strcmp(argv[6], "strict") == 0;
    CHECK(strict || strcmp(argv[6], "observe") == 0);
    FILE *output = fopen(argv[5], "wb"); CHECK(output && uwz_alloc_self_test());
    fprintf(output,"{\"suite\":%u,\"original_counter_selftest_bytes\":63,\"once_observer\":%s}\n",suite,UWZ_ONCE_OBSERVER ? "true" : "false");
#if UWZ_ONCE_OBSERVER
    calibrate_once(output);
#endif
    tls_pair pair{}; configure_pair(&pair, argv[1], argv[2], argv[3], suite);
    BIO_METHOD *method = trap_method();
    unsigned int impure = run_cold(output, "cold_null", nullptr, ssl_client_storage_unsupported, nullptr);
    impure += run_cold(output, "cold_server", pair.server, ssl_client_storage_unsupported, &pair.observers);
    impure += queue_cases(output,"queue_null",nullptr,ssl_client_storage_unsupported,nullptr);
    impure += queue_cases(output,"queue_server",pair.server,ssl_client_storage_unsupported,&pair.observers);
    BIO *filter = attach_trap(&pair, method);
    impure += run_cold(output,"cold_fresh",pair.client,ssl_client_storage_pending,&pair.observers);
    impure += queue_cases(output,"queue_fresh",pair.client,ssl_client_storage_pending,&pair.observers);
    detach_trap(&pair, filter); complete_pair(&pair, suite);
    filter = attach_trap(&pair, method);
    impure += run_cold(output,"cold_ready",pair.client,ssl_client_storage_ready,&pair.observers);
    impure += queue_cases(output,"queue_ready",pair.client,ssl_client_storage_ready,&pair.observers);
    SSL_CTX_sess_set_new_cb(pair.client_context, session_callback);
    impure += run_cold(output,"cold_policy",pair.client,ssl_client_storage_unsupported,&pair.observers);
    impure += queue_cases(output,"queue_policy",pair.client,ssl_client_storage_unsupported,&pair.observers);
    SSL_CTX_sess_set_new_cb(pair.client_context, nullptr);
    detach_trap(&pair, filter); partial_control(&pair);
    filter = attach_trap(&pair, method);
    impure += run_cold(output,"cold_partial",pair.client,ssl_client_storage_pending,&pair.observers);
    impure += queue_cases(output,"queue_partial",pair.client,ssl_client_storage_pending,&pair.observers);
    detach_trap(&pair, filter);
    SSL_free(pair.client); SSL_free(pair.server);
    SSL_CTX_free(pair.client_context); SSL_CTX_free(pair.server_context); BIO_meth_free(method);
    fprintf(output,"{\"functional_checks_complete\":true,\"impure_getters\":%u}\n",impure);
    CHECK(fclose(output) == 0);
    return strict && impure != 0 ? 1 : 0;
}
