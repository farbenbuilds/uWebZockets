#!/usr/bin/env python3
"""Replay four retained getter-purity programs without sources or compilers."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pki-tool', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    protected = base
    for parent in base.parents:
        if (parent / 'restore_pki_tool.py').is_file():
            protected = parent
            break
    output = args.output.absolute()
    if output.exists() or output.is_symlink() or output.resolve().is_relative_to(protected.resolve()):
        raise ValueError('Choose an absent output outside the complete evidence tree')
    helper = args.pki_tool.resolve(strict=True)
    if sha(helper) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('PKI tool identity differs')
    identity = json.loads((base / 'prebuilt_identity.json').read_text())
    expected = {image + '/' + program for image in ['interim_once_red_alias', 'final_pure']
                for program in ['allocator_only', 'once_observed']}
    if set(identity['binaries']) != expected:
        raise ValueError('Unexpected current executable inventory')
    for name, checksum in identity['binaries'].items():
        if (base / name).is_symlink() or sha(base / name) != checksum:
            raise ValueError('Current executable identity differs: ' + name)
    output.mkdir(mode=0o700)
    environment = dict(os.environ)
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    commands = []
    def run(command, label, expected_status=0):
        with (output / (label + '.stdout')).open('wb') as out, (output / (label + '.stderr')).open('wb') as err:
            result = subprocess.run(command, cwd=output, env=environment, stdout=out, stderr=err)
        commands.append({'command': command, 'exit_code': result.returncode, 'expected_exit_code': expected_status})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode != expected_status:
            raise RuntimeError('Unexpected replay command status: ' + label)
    pki = output / 'private_pki'
    complete = False
    count = 0
    try:
        run([sys.executable, str(base / 'verify_results.py'), '--check-only'], 'verify-retained')
        run([str(helper), 'pki', str(pki)], 'offline-pki')
        for image in ['interim_once_red_alias', 'final_pure']:
            for program in ['allocator_only', 'once_observed']:
                for suite in ['0x1301', '0x1302', '0x1303']:
                    for mode in ['observe', 'strict']:
                        label = image + '_' + program + '_' + suite + '_' + mode
                        report = output / (label + '.jsonl')
                        expected_status = int(image == 'interim_once_red_alias' and program == 'once_observed' and mode == 'strict')
                        command = [str(base / image / program), *[str(pki / name) for name in ['server.pem', 'server.key', 'ca.pem']],
                                   suite, str(report), mode]
                        run(command, label, expected_status)
                        retained = base / image / (program + '_' + suite + '_' + mode + '.jsonl')
                        if report.read_bytes() != retained.read_bytes():
                            raise ValueError('Raw purity replay differs: ' + label)
                        count += 1
        complete = True
    finally:
        if pki.exists():
            paths = list(pki.iterdir())
            if {path.name for path in paths} - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected private PKI file')
            for path in paths:
                path.unlink()
            pki.rmdir()
        (output / 'result.json').write_text(json.dumps({'complete': complete, 'runs': count,
            'getter_calls': count * 30, 'private_pki_removed': not pki.exists(),
            'current_binaries': identity['binaries']}, indent=2) + '\n')
    print('PASS source-free purity replay: ' + str(count) + ' runs, PKI removed')


if __name__ == '__main__':
    main()
