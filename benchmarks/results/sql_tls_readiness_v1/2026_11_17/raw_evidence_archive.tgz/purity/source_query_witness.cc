#include <openssl/err.h>
#include <openssl/ssl.h>
#include <openssl/ssl3.h>
#include <openssl/x509_vfy.h>
#include "ssl/internal.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK(value) do { if (!(value)) fail(__LINE__, #value); } while (0)

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

struct allocation_counts {
    uint64_t malloc_calls;
    uint64_t calloc_calls;
    uint64_t realloc_calls;
    uint64_t free_calls;
    uint64_t requested_bytes;
};

struct measured_result {
    int result;
    int error;
    allocation_counts counts;
};

struct protocol_observations {
    unsigned int sent_finished;
    unsigned int received_finished;
    unsigned int received_tickets;
    unsigned int received_key_updates;
    unsigned int sent_key_updates;
    uint8_t received_modes[96];
    uint8_t sent_modes[96];
    bool invalid;
    const uint8_t *expected_tickets;
    size_t expected_ticket_bytes;
    size_t observed_ticket_bytes;
    bool ticket_bytes_exact;
    unsigned int alert_count;
    uint8_t alerts[8][3];
};

struct tls_pair {
    SSL_CTX *client_context;
    SSL_CTX *server_context;
    SSL *client;
    SSL *server;
    protocol_observations client_observations;
    protocol_observations server_observations;
};

struct phase_result {
    allocation_counts counts;
    unsigned int operations;
    unsigned int retries;
};

static void fail(int line, const char *expression)
{
    fprintf(stderr, "check failed at line %d: %s\n", line, expression);
    ERR_print_errors_fp(stderr);
    abort();
}

static allocation_counts snapshot_counts(void)
{
    return {uwz_alloc_malloc_calls(), uwz_alloc_calloc_calls(),
            uwz_alloc_realloc_calls(), uwz_alloc_free_calls(),
            uwz_alloc_requested_bytes()};
}

static void add_counts(allocation_counts *total, allocation_counts value)
{
    total->malloc_calls += value.malloc_calls;
    total->calloc_calls += value.calloc_calls;
    total->realloc_calls += value.realloc_calls;
    total->free_calls += value.free_calls;
    total->requested_bytes += value.requested_bytes;
}

static bool retry_error(int error)
{
    return error == SSL_ERROR_WANT_READ || error == SSL_ERROR_WANT_WRITE;
}

static void check_peer_result(SSL *ssl, int result)
{
    if (result > 0) return;
    CHECK(retry_error(SSL_get_error(ssl, result)));
}

static void observe_message(int is_write, int version, int content_type,
                            const void *buffer, size_t length, SSL *ssl,
                            void *argument)
{
    (void)ssl;
    protocol_observations *observed = static_cast<protocol_observations *>(argument);
    const uint8_t *bytes = static_cast<const uint8_t *>(buffer);
    if (content_type == SSL3_RT_ALERT && length == 2) {
        if (observed->alert_count == 8) { observed->invalid = true; return; }
        const unsigned int index = observed->alert_count++;
        observed->alerts[index][0] = static_cast<uint8_t>(is_write);
        observed->alerts[index][1] = bytes[0];
        observed->alerts[index][2] = bytes[1];
        return;
    }
    if (content_type != SSL3_RT_HANDSHAKE || length == 0) return;
    if (bytes[0] == SSL3_MT_FINISHED) {
        if (is_write) observed->sent_finished++; else observed->received_finished++;
        return;
    }
    if (bytes[0] == SSL3_MT_NEWSESSION_TICKET) {
        if (is_write) return;
        observed->received_tickets++;
        if (version != TLS1_3_VERSION || length < 4) { observed->invalid = true; return; }
        if (observed->expected_tickets != nullptr) {
            const size_t remaining = observed->expected_ticket_bytes - observed->observed_ticket_bytes;
            if (length > remaining || memcmp(bytes, observed->expected_tickets + observed->observed_ticket_bytes, length) != 0)
                observed->invalid = true;
            else observed->observed_ticket_bytes += length;
        }
        return;
    }
    if (bytes[0] != SSL3_MT_KEY_UPDATE) return;
    if (version != TLS1_3_VERSION || length != 5 || bytes[1] || bytes[2] || bytes[3] != 1 || bytes[4] > 1) {
        observed->invalid = true;
        return;
    }
    unsigned int *count = is_write ? &observed->sent_key_updates : &observed->received_key_updates;
    uint8_t *modes = is_write ? observed->sent_modes : observed->received_modes;
    if (*count == 96) { observed->invalid = true; return; }
    modes[(*count)++] = bytes[4];
}

static void configure_pair(tls_pair *pair, const char *certificate,
                         const char *private_key, const char *ca,
                         unsigned int tickets, uint16_t suite, int cache_mode, size_t bio_capacity)
{
    pair->client_context = SSL_CTX_new(TLS_method());
    pair->server_context = SSL_CTX_new(TLS_method());
    CHECK(pair->client_context && pair->server_context);
    CHECK(SSL_CTX_set1_tls13_ciphers(pair->client_context, &suite, nullptr, 1));
    CHECK(SSL_CTX_set1_tls13_ciphers(pair->server_context, &suite, nullptr, 1));
    CHECK(SSL_CTX_set_min_proto_version(pair->client_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_max_proto_version(pair->client_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_min_proto_version(pair->server_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_max_proto_version(pair->server_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_num_tickets(pair->server_context, tickets));
    SSL_CTX_set_session_cache_mode(pair->client_context, cache_mode);
    CHECK(SSL_CTX_get_session_cache_mode(pair->client_context) == cache_mode);
    CHECK(SSL_CTX_sess_get_new_cb(pair->client_context) == nullptr);
    CHECK(SSL_CTX_use_certificate_chain_file(pair->server_context, certificate));
    CHECK(SSL_CTX_use_PrivateKey_file(pair->server_context, private_key,
                                     SSL_FILETYPE_PEM));
    CHECK(SSL_CTX_check_private_key(pair->server_context));
    CHECK(SSL_CTX_load_verify_locations(pair->client_context, ca, nullptr));
    SSL_CTX_set_verify(pair->client_context, SSL_VERIFY_PEER, nullptr);
    SSL_CTX_set_msg_callback(pair->client_context, observe_message);
    SSL_CTX_set_msg_callback_arg(pair->client_context, &pair->client_observations);
    SSL_CTX_set_msg_callback(pair->server_context, observe_message);
    SSL_CTX_set_msg_callback_arg(pair->server_context, &pair->server_observations);
    pair->client = SSL_new(pair->client_context);
    pair->server = SSL_new(pair->server_context);
    CHECK(pair->client && pair->server);
    CHECK(SSL_set_tlsext_host_name(pair->client, "localhost"));
    CHECK(SSL_set1_host(pair->client, "localhost"));
    SSL_set_connect_state(pair->client);
    SSL_set_accept_state(pair->server);
    BIO *client_bio = nullptr;
    BIO *server_bio = nullptr;
    CHECK(BIO_new_bio_pair(&client_bio, bio_capacity, &server_bio, bio_capacity));
    SSL_set_bio(pair->client, client_bio, client_bio);
    SSL_set_bio(pair->server, server_bio, server_bio);
}

static void verify_pair(tls_pair *pair, uint16_t suite)
{
    CHECK(SSL_version(pair->client) == TLS1_3_VERSION);
    CHECK(SSL_version(pair->server) == TLS1_3_VERSION);
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->client)) == suite);
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->server)) == suite);
    CHECK(SSL_get_verify_result(pair->client) == X509_V_OK);
    CHECK(SSL_get0_peer_certificates(pair->client) != nullptr);
    CHECK(pair->client_observations.received_tickets == 0);
}

static void complete_pair(tls_pair *pair)
{
    bool client_done = false, server_done = false;
    for (unsigned int i = 0; i < 10000 && (!client_done || !server_done); i++) {
        if (!client_done) {
            const int result = SSL_do_handshake(pair->client);
            if (result == 1) client_done = true; else check_peer_result(pair->client, result);
        }
        if (!server_done) {
            const int result = SSL_do_handshake(pair->server);
            if (result == 1) server_done = true; else check_peer_result(pair->server, result);
        }
    }
    CHECK(client_done && server_done);
    verify_pair(pair, 0x1301);
}

static measured_result measured_read(SSL *client, void *output, int length)
{
    uwz_alloc_begin();
    const int result = SSL_read(client, output, length);
    const int error = result > 0 ? SSL_ERROR_NONE : SSL_get_error(client, result);
    uwz_alloc_end();
    return {result, error, snapshot_counts()};
}

static measured_result measured_write(SSL *client, const void *input, int length)
{
    uwz_alloc_begin();
    const int result = SSL_write(client, input, length);
    const int error = result > 0 ? SSL_ERROR_NONE : SSL_get_error(client, result);
    uwz_alloc_end();
    return {result, error, snapshot_counts()};
}

struct error_entry {
    uint32_t packed;
    int line;
    int flags;
    bool has_data;
    char file[512];
    char data[256];
};

struct error_queue {
    error_entry entries[15];
    size_t count;
};

struct output_files {
    FILE *operations;
    FILE *events;
    unsigned int event_index;
};

static void copy_text(char *output, size_t capacity, const char *input)
{
    CHECK(input != nullptr && strlen(input) < capacity);
    memcpy(output, input, strlen(input) + 1);
}

static error_queue capture_queue(void)
{
    error_queue queue{};
    for (;;) {
        const char *file = nullptr, *data = nullptr;
        int line = 0, flags = 0;
        const uint32_t packed = ERR_get_error_line_data(&file, &line, &data, &flags);
        if (packed == 0) return queue;
        CHECK(queue.count < 15);
        error_entry *entry = &queue.entries[queue.count++];
        entry->packed = packed; entry->line = line; entry->flags = flags;
        copy_text(entry->file, sizeof(entry->file), file ? file : "");
        entry->has_data = (flags & ERR_FLAG_STRING) != 0;
        CHECK(data != nullptr);
        if (entry->has_data) CHECK(strncmp(data, "SSL alert number ", 17) == 0);
        else CHECK(flags == 0 && data[0] == 0);
        copy_text(entry->data, sizeof(entry->data), data);
    }
}

static void print_string(FILE *output, const char *value)
{
    fputc('"', output);
    for (const unsigned char *p = reinterpret_cast<const unsigned char *>(value); *p; p++) {
        if (*p == '"' || *p == 92) fputc(92, output);
        CHECK(*p >= 32 && *p < 127);
        fputc(*p, output);
    }
    fputc('"', output);
}

static void print_queue(FILE *output, const error_queue *queue)
{
    fputc('[', output);
    for (size_t i = 0; i < queue->count; i++) {
        const error_entry *entry = &queue->entries[i];
        fprintf(output, "%s{\"packed\":%u,\"library\":%d,\"reason\":%d,\"line\":%d,\"flags\":%d,\"file\":", i ? "," : "", entry->packed, ERR_GET_LIB(entry->packed), ERR_GET_REASON(entry->packed), entry->line, entry->flags);
        print_string(output, entry->file);
        fprintf(output, ",\"data\":");
        print_string(output, entry->data);
        fputc('}', output);
    }
    fputc(']', output);
}

static void record_captured_operation(output_files *files, unsigned int round, const char *row,
                              const char *phase, measured_result operation,
                              const protocol_observations *observed,
                              phase_result *result, const error_queue *queue)
{
    const allocation_counts count = operation.counts;
    fprintf(files->operations, "%u,%s,%s,%u,%d,%d,%llu,%llu,%llu,%llu,%llu,%u,%u,%u\n",
            round, row, phase, result->operations, operation.result, operation.error,
            (unsigned long long)count.malloc_calls, (unsigned long long)count.calloc_calls,
            (unsigned long long)count.realloc_calls, (unsigned long long)count.free_calls,
            (unsigned long long)count.requested_bytes, observed->received_tickets,
            observed->received_key_updates, observed->sent_key_updates);
    fprintf(files->events, "{\"index\":%u,\"case\":\"%s\",\"phase\":\"%s\",\"step\":%u,\"result\":%d,\"error\":%d,\"queue\":", files->event_index++, row, phase, round, operation.result, operation.error);
    print_queue(files->events, queue);
    fprintf(files->events, ",\"observed_alerts\":[");
    for (unsigned int i = 0; i < observed->alert_count; i++) fprintf(files->events, "%s[%u,%u,%u]", i ? "," : "", observed->alerts[i][0], observed->alerts[i][1], observed->alerts[i][2]);
    fprintf(files->events, "],\"received_tickets\":%u}\n", observed->received_tickets);
    CHECK(fflush(files->operations) == 0 && fflush(files->events) == 0);
    add_counts(&result->counts, count); result->operations++;
    if (operation.result <= 0) result->retries++;
}

static error_queue record_full_operation(output_files *files, unsigned int round, const char *row,
                              const char *phase, measured_result operation,
                              const protocol_observations *observed, phase_result *result)
{
    const error_queue queue = capture_queue();
    record_captured_operation(files, round, row, phase, operation, observed, result, &queue);
    return queue;
}

static void record_operation(output_files *files, unsigned int round, const char *row,
                              const char *phase, measured_result operation,
                              const protocol_observations *observed, phase_result *result)
{
    const error_queue queue = record_full_operation(files, round, row, phase, operation, observed, result);
    CHECK(queue.count == 0);
}

static phase_result read_payload(tls_pair *pair, const uint8_t *payload,
                                  int length, output_files *operations,
                                  unsigned int round, const char *row)
{
    uint8_t received[4096];
    CHECK(length == sizeof(received));
    bool written = false;
    int offset = 0;
    phase_result result{};
    for (unsigned int i = 0; i < 10000 && (!written || offset != length); i++) {
        if (!written) {
            const int sent = SSL_write(pair->server, payload, length);
            if (sent > 0) {
                CHECK(sent == length);
                written = true;
            } else check_peer_result(pair->server, sent);
        }
        if (offset == length) continue;
        const int remaining = length - offset;
        measured_result operation = measured_read(pair->client, received + offset,
                                                   remaining < 257 ? remaining : 257);
        record_operation(operations, round, row, "read", operation,
                          &pair->client_observations, &result);
        if (operation.result > 0) offset += operation.result;
        else CHECK(retry_error(operation.error));
    }
    CHECK(written && offset == length);
    CHECK(memcmp(received, payload, length) == 0);
    return result;
}

static phase_result write_reply(tls_pair *pair, const uint8_t *payload,
                                 int length, output_files *operations,
                                 unsigned int round, const char *row)
{
    uint8_t received[4096];
    CHECK(length == sizeof(received));
    bool written = false;
    int offset = 0;
    phase_result result{};
    for (unsigned int i = 0; i < 10000 && (!written || offset != length); i++) {
        if (!written) {
            measured_result operation = measured_write(pair->client, payload, length);
            record_operation(operations, round, row, "response_write", operation,
                              &pair->client_observations, &result);
            if (operation.result > 0) {
                CHECK(operation.result == length);
                written = true;
            } else CHECK(retry_error(operation.error));
        }
        if (offset == length) continue;
        const int remaining = length - offset;
        const int count = SSL_read(pair->server, received + offset,
                                   remaining < 257 ? remaining : 257);
        if (count > 0) offset += count;
        else check_peer_result(pair->server, count);
    }
    CHECK(written && offset == length);
    CHECK(memcmp(received, payload, length) == 0);
    return result;
}

static void print_counts(FILE *output, allocation_counts counts)
{
    fprintf(output, "{\"malloc\":%llu,\"calloc\":%llu,\"realloc\":%llu,\"free\":%llu,\"bytes\":%llu}",
            (unsigned long long)counts.malloc_calls,
            (unsigned long long)counts.calloc_calls,
            (unsigned long long)counts.realloc_calls,
            (unsigned long long)counts.free_calls,
            (unsigned long long)counts.requested_bytes);
}

struct public_state {
    int pending;
    int has_pending;
    size_t client_input;
    size_t server_input;
};

static bool counts_zero(allocation_counts value)
{
    return value.malloc_calls == 0 && value.calloc_calls == 0 && value.realloc_calls == 0 &&
        value.free_calls == 0 && value.requested_bytes == 0;
}

static public_state pending_state(tls_pair *pair)
{
    return {SSL_pending(pair->client), SSL_has_pending(pair->client),
        BIO_ctrl_pending(SSL_get_rbio(pair->client)), BIO_ctrl_pending(SSL_get_rbio(pair->server))};
}

static void require_public_empty(public_state state)
{
    CHECK(state.pending == 0 && state.has_pending == 0 && state.client_input == 0 && state.server_input == 0);
}

static void sample_state(FILE *output, tls_pair *pair, const char *row, const char *label,
                          int expected_query)
{
    const public_state state = pending_state(pair);
    fprintf(output, "{\"case\":\"%s\",\"state\":\"%s\",\"pending\":%d,\"has_pending\":%d,\"client_external_input\":%zu,\"server_external_input\":%zu,\"received_updates\":%u,\"sent_updates\":%u,\"peer_received_updates\":%u,", row, label, state.pending, state.has_pending, state.client_input, state.server_input, pair->client_observations.received_key_updates, pair->client_observations.sent_key_updates, pair->server_observations.received_key_updates);
#if defined(UWZ_READINESS_API)
    ERR_clear_error();
    OPENSSL_PUT_ERROR(SSL, ERR_R_INTERNAL_ERROR);
    ERR_add_error_data(1, "readiness sentinel");
    const char *before_file = nullptr, *before_data = nullptr;
    int before_line = 0, before_flags = 0;
    const uint32_t before = ERR_peek_error_line_data(&before_file, &before_line, &before_data, &before_flags);
    CHECK(before != 0 && before_data != nullptr);
    char saved_data[64]; copy_text(saved_data, sizeof(saved_data), before_data);
    const unsigned int received = pair->client_observations.received_key_updates;
    const unsigned int sent = pair->client_observations.sent_key_updates;
    uwz_alloc_begin();
    const int status = SSL_get_client_storage_readiness(pair->client);
    uwz_alloc_end();
    const allocation_counts counts = snapshot_counts();
    const char *after_file = nullptr, *after_data = nullptr;
    int after_line = 0, after_flags = 0;
    const uint32_t after = ERR_peek_error_line_data(&after_file, &after_line, &after_data, &after_flags);
    CHECK(before == after && before_line == after_line && before_flags == after_flags);
    CHECK(strcmp(before_file, after_file) == 0 && strcmp(saved_data, after_data) == 0);
    CHECK(counts_zero(counts) && received == pair->client_observations.received_key_updates && sent == pair->client_observations.sent_key_updates);
    CHECK(expected_query < 0 || status == expected_query);
    ERR_clear_error();
    fprintf(output, "\"query_available\":true,\"query\":%d,\"query_err_preserved\":true,\"query_counts\":", status); print_counts(output, counts);
#else
    (void)expected_query;
    fprintf(output, "\"query_available\":false,\"query\":null,\"query_err_preserved\":null,\"query_counts\":null");
#endif
    fprintf(output, "}\n"); CHECK(fflush(output) == 0);
}

static void bundle(FILE *output, tls_pair *pair, const char *row, const char *label)
{
    const int results[] = {SSL_reserve_record_buffers(pair->client),
        SSL_reserve_client_post_handshake_buffer(pair->client), SSL_reserve_key_update_context(pair->client),
        SSL_reserve_key_update_output_buffers(pair->client), SSL_reserve_error_state(pair->client),
        SSL_discard_client_session_tickets(pair->client)};
    for (int value : results) CHECK(value == 1);
    CHECK(ERR_peek_error() == 0);
    fprintf(output, "{\"case\":\"%s\",\"bundle\":\"%s\",\"results\":[1,1,1,1,1,1]}\n", row, label);
}

static void peer_fragment(tls_pair *pair, const uint8_t *input, size_t length)
{
    uint8_t encrypted[128]; size_t encrypted_length = 0;
    CHECK(bssl::tls_seal_record(bssl::FromOpaque(pair->server), encrypted, &encrypted_length,
        sizeof(encrypted), SSL3_RT_HANDSHAKE, input, length));
    CHECK(BIO_write(SSL_get_wbio(pair->server), encrypted, static_cast<int>(encrypted_length)) == static_cast<int>(encrypted_length));
}

static measured_result read_control(tls_pair *pair, output_files *output,
                                     phase_result *calls, const char *row, const char *phase)
{
    uint8_t unused[257];
    const measured_result result = measured_read(pair->client, unused, sizeof(unused));
    const error_queue queue = record_full_operation(output, 0, row, phase, result, &pair->client_observations, calls);
    CHECK(result.result == -1 && result.error == SSL_ERROR_WANT_READ && queue.count == 0);
    return result;
}

static void flush_control(tls_pair *pair, output_files *output, phase_result *calls,
                            FILE *states, const char *row)
{
    uwz_alloc_begin();
    const int result = SSL_write(pair->client, nullptr, 0);
    const int error = result < 0 ? SSL_get_error(pair->client, result) : -1;
    uwz_alloc_end();
    const measured_result operation{result,error,snapshot_counts()};
    const error_queue queue = record_full_operation(output, 0, row, "zero_control_flush", operation, &pair->client_observations, calls);
    CHECK(result == 0 && queue.count == 0);
    fprintf(states, "{\"case\":\"%s\",\"zero_control_flush_return\":0,\"ssl_get_error_called\":false,\"documented_zero_success\":true}\n", row);
}

static void free_pair(tls_pair *pair)
{
    SSL_free(pair->client); SSL_free(pair->server);
    SSL_CTX_free(pair->client_context); SSL_CTX_free(pair->server_context);
}

static void run_partial(const char *certificate, const char *private_key, const char *ca,
                          output_files *output, FILE *states, FILE *summary)
{
    const char *row = "prepared_fragmented_key_update";
    tls_pair pair{}; configure_pair(&pair,certificate,private_key,ca,0,0x1301,SSL_SESS_CACHE_SERVER,1024);
    complete_pair(&pair); require_public_empty(pending_state(&pair));
    sample_state(states,&pair,row,"pre_bundle_idle",2); bundle(states,&pair,row,"initial");
    phase_result controls{};
    read_control(&pair,output,&controls,row,"idle_read");
    require_public_empty(pending_state(&pair)); sample_state(states,&pair,row,"a_idle_before_probe",2);
    const uint8_t key_update[] = {SSL3_MT_KEY_UPDATE,0,0,1,SSL_KEY_UPDATE_REQUESTED};
    peer_fragment(&pair,key_update,3);
    read_control(&pair,output,&controls,row,"partial_header_read");
    require_public_empty(pending_state(&pair)); CHECK(pair.client_observations.received_key_updates == 0);
    sample_state(states,&pair,row,"b_partial_before_probe",1);
    peer_fragment(&pair,key_update + 3,2);
    CHECK(bssl::tls13_rotate_traffic_key(bssl::FromOpaque(pair.server),evp_aead_seal));
    read_control(&pair,output,&controls,row,"complete_requested_read");
    require_public_empty(pending_state(&pair)); CHECK(pair.client_observations.received_key_updates == 1);
    CHECK(pair.client_observations.received_modes[0] == SSL_KEY_UPDATE_REQUESTED);
    sample_state(states,&pair,row,"c_requested_output_before_probe",1);
    flush_control(&pair,output,&controls,states,row);
    CHECK(pair.client_observations.sent_key_updates == 1 && pair.client_observations.sent_modes[0] == SSL_KEY_UPDATE_NOT_REQUESTED);
    CHECK(BIO_ctrl_pending(SSL_get_rbio(pair.server)) != 0);
    sample_state(states,&pair,row,"native_idle_with_external_response",2);
    uint8_t unused[257]; const int peer = SSL_read(pair.server,unused,sizeof(unused));
    CHECK(peer == -1 && SSL_get_error(pair.server,peer) == SSL_ERROR_WANT_READ);
    CHECK(pair.server_observations.received_key_updates == 1 && pair.server_observations.received_modes[0] == SSL_KEY_UPDATE_NOT_REQUESTED);
    require_public_empty(pending_state(&pair)); sample_state(states,&pair,row,"d_drained_ready",2);
    bundle(states,&pair,row,"repeat_after_control");
    uint8_t payload[4096]; for (size_t i = 0; i < sizeof(payload); i++) payload[i] = static_cast<uint8_t>(i * 13 + 7);
    const phase_result reads = read_payload(&pair,payload,sizeof(payload),output,1,row);
    const phase_result writes = write_reply(&pair,payload,sizeof(payload),output,1,row);
    require_public_empty(pending_state(&pair)); sample_state(states,&pair,row,"e_payload_ready",2);
    CHECK(!pair.client_observations.invalid && !pair.server_observations.invalid);
    CHECK(pair.client_observations.alert_count == 0 && pair.server_observations.alert_count == 0);
    fprintf(summary,"{\"case\":\"%s\",\"suite\":4865,\"verified_ca_hostname\":true,\"a_b_public_pending_tuple_identical\":true,\"fragment_header_bytes\":3,\"legacy_guard_probes\":false,\"api2_a_result\":null,\"api2_b_result\":null,\"api2_pending_response_result\":null,\"api2_after_result\":null,\"valid_control_completed\":true,\"peer_only_sealing_rotation\":true,\"client_private_state_staged\":false,\"received_updates\":1,\"sent_updates\":1,\"peer_received_updates\":1,\"payload_each_direction\":4096,\"payload_exact\":true,\"control_operations\":%u,\"control_counts\":",row,controls.operations);
    print_counts(summary,controls.counts); fprintf(summary,",\"read_operations\":%u,\"write_operations\":%u,\"read_counts\":",reads.operations,writes.operations);
    print_counts(summary,reads.counts); fprintf(summary,",\"write_counts\":"); print_counts(summary,writes.counts); fprintf(summary,"}\n");
    free_pair(&pair);
}

int main(int argc, char **argv)
{
    CHECK(argc == 8 && uwz_alloc_self_test());
    output_files output{fopen(argv[4],"wx"),fopen(argv[5],"wx"),0};
    FILE *states = fopen(argv[6],"wx"), *summary = fopen(argv[7],"wx");
    CHECK(output.operations && output.events && states && summary);
    fprintf(output.operations,"step,scenario,phase,operation,result,error,malloc,calloc,realloc,free,bytes,received_tickets,received_key_updates,sent_key_updates\n");
    run_partial(argv[1],argv[2],argv[3],&output,states,summary);
    CHECK(fclose(output.operations)==0 && fclose(output.events)==0 && fclose(states)==0 && fclose(summary)==0);
    puts("PASS: public pending A/B ambiguity, valid authenticated fragmented requested KeyUpdate, zero control flush and payload completion");
    return 0;
}
