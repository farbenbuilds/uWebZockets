#!/usr/bin/env python3
"""Check replay/restoration refuse evidence-tree outputs before creating files."""
import argparse,hashlib,json,pathlib,shutil,subprocess,sys

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def files(root):
 return {p.relative_to(root).as_posix():('link',str(p.readlink())) if p.is_symlink() else ('file',sha(p)) if p.is_file() else ('directory',None) for p in root.rglob('*')}
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('output',type=pathlib.Path);a.add_argument('--runner',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent/'replay_prebuilt.py');a.add_argument('--restore',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent/'restore_source.py');x=a.parse_args();out=x.output.absolute();runner=x.runner.resolve(strict=True);restore=x.restore.resolve(strict=True)
 if out.exists() or out.is_symlink():raise ValueError('Choose an absent guard result directory')
 out.mkdir(mode=0o700);fixture=out/'fixture';fixture.mkdir();combined=fixture/'combined';combined.mkdir();(combined/'files.sha256').write_text('combined evidence marker\n');native=combined/'native';native.mkdir();(native/'files.sha256').write_text('native evidence marker\n');existing=fixture/'existing';existing.mkdir();(existing/'sentinel').write_text('keep unchanged\n');alias=fixture/'linked-parent';alias.symlink_to(native,target_is_directory=True);source=fixture/'input';source.mkdir()
 shutil.copy2(runner,native/'replay_prebuilt.py');shutil.copy2(restore,native/'restore_source.py')
 cases=[('existing',existing),('inside_own',native/'new-output'),('inside_combined',combined/'root_checks'/'new-output'),('symlink_parent',alias/'new-output')];results=[]
 for tool in ['replay','restore']:
  selected=cases+([('inside_input',source/'new-output')] if tool=='restore' else [])
  for name,destination in selected:
   before=files(fixture)
   if tool=='replay':command=[sys.executable,str(native/'replay_prebuilt.py'),str(destination),'--payload',str(native),'--openssl','/nonexistent/replay-guard-must-not-call-openssl']
   else:command=[sys.executable,str(native/'restore_source.py'),str(source),str(destination),'--source-kind','error-data']
   expected=('Choose an absent output directory' if tool=='replay' else 'Choose an absent source destination') if name=='existing' else ('Destination must not be inside input source' if name=='inside_input' else ('Output' if tool=='replay' else 'Destination')+' must be outside payload and enclosing evidence roots')
   r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE);stem=tool+'_'+name
   (out/(stem+'.stdout')).write_bytes(r.stdout);(out/(stem+'.stderr')).write_bytes(r.stderr);after=files(fixture)
   assert r.returncode!=0 and expected in r.stderr.decode(),(stem,r.returncode,r.stderr)
   assert before==after,(stem,'evidence fixture mutated')
   assert name=='existing' or (not destination.exists() and not destination.is_symlink())
   results.append({'case':stem,'command':command,'exit_code':r.returncode,'expected_error':expected,'fixture_unchanged':True,'new_output_absent':name!='existing'})
 (out/'results.json').write_text(json.dumps({'complete':True,'runner_sha256':sha(runner),'restore_sha256':sha(restore),'guard_source_sha256':sha(pathlib.Path(__file__).resolve()),'refusal_cases':results},indent=2)+'\n');print(json.dumps({'complete':True,'refusals':len(results),'runner_sha256':sha(runner),'restore_sha256':sha(restore),'guard_source_sha256':sha(pathlib.Path(__file__).resolve())}))
if __name__=='__main__':main()
