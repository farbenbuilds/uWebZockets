#include <openssl/ssl.h>

static_assert(ssl_client_storage_unsupported == 0, "stable unsupported value");
static_assert(ssl_client_storage_pending == 1, "stable pending value");
static_assert(ssl_client_storage_ready == 2, "stable ready value");

int main() {
  return SSL_get_client_storage_readiness(nullptr) != ssl_client_storage_unsupported;
}
