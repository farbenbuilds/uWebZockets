#include "ticket_pair.h"
#include "ticket_fault.h"

using StorageCall=int(*)(SSL *);
static const StorageCall calls[]={SSL_reserve_record_buffers,SSL_reserve_client_post_handshake_buffer,SSL_reserve_key_update_context,SSL_reserve_key_update_output_buffers,SSL_reserve_error_state,SSL_discard_client_session_tickets};
static void fault_query(const char *name,SSL *ssl){
 ticket_fault_reset();ticket_fault_arm_ordinal(1);
 auto status=SSL_get_client_storage_readiness(ssl);
 ticket_fault_disarm();auto stats=ticket_fault_read();
 CHECK(status==ssl_client_storage_ready&&stats.attempts==0&&stats.injected==0&&stats.calloc_calls==0&&stats.realloc_calls==0&&stats.actual_frees==0);
 printf("{\"case\":\"%s\",\"status\":2,\"armed_fault_attempts\":0,\"injected\":0}\n",name);
}
int main(int argc,char **argv){
 CHECK(argc==4);
 for(size_t i=0;i<6;i++){
  PeerPair pair=make_pair(argv,TLS1_3_VERSION,4096);ERR_clear_error();
  fault_query("ready_under_armed_first_allocation_fault",pair.client);
  ticket_fault_reset();ticket_fault_arm_ordinal(1);int result=calls[i](pair.client);ticket_fault_disarm();auto failure=ticket_fault_read();
  CHECK(result==(i==5?1:0));CHECK(failure.injected==(i==5?0u:1u));
  CHECK(SSL_get_client_storage_readiness(pair.client)==ssl_client_storage_ready);
  printf("{\"case\":\"ready_does_not_promise_allocation_success\",\"opt_in_index\":%zu,\"actual_result\":%d,\"injected\":%llu}\n",i,result,(unsigned long long)failure.injected);
  destroy_pair(&pair);CHECK(ticket_fault_read().live==0);ticket_fault_reset();ERR_clear_error();
 }
 PeerPair pair=make_pair(argv,TLS1_3_VERSION,4096);for(StorageCall call:calls)CHECK(call(pair.client)==1);
 fault_query("fully_prepared_under_armed_fault",pair.client);
 ticket_fault_reset();ticket_fault_arm_ordinal(1);for(StorageCall call:calls)CHECK(call(pair.client)==1);ticket_fault_disarm();auto repeat=ticket_fault_read();CHECK(repeat.attempts==0&&repeat.injected==0&&repeat.calloc_calls==0&&repeat.realloc_calls==0&&repeat.actual_frees==0);
 puts("{\"case\":\"all_six_idempotent_repeat_under_armed_fault\",\"allocation_attempts\":0}");destroy_pair(&pair);CHECK(ticket_fault_read().live==0);
 puts("PASS separate fault observer; original counter remains unchanged and normal zero proof is separate");
}
