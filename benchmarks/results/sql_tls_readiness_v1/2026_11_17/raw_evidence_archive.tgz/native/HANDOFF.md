# TLS client-storage readiness: author handoff

The pure getter classifies ordinary TLS1.3 clients as UNSUPPORTED0, PENDING1 or READY2. READY means the six existing opt-in eligibility guards pass absent allocation failure, under serialized, nonreentrant mutation of each SSL. It enables nothing. External transport draining and peer/name verification remain caller responsibilities. Incomplete native handshake data is visible to this getter even when public pending getters report zero.

Native source is frozen at stage patch `6772a629cc9e6e09c3e06dca857576bb03a1553185d54a0d52ce6f4e2a333b3b`. The cumulative patch is `ff26397acc9c93492f736f9d4bd6b6d3010ec2352e613e1ee63404e9daa3c83a`. Source contains8709 entries,17 cumulative changed paths from pinned BoringSSL d3bf4795ad5b79d646cddf2fec687da5b9b502db. Exactly five paths differ from the immutable error-data base:

- include/openssl/ssl.h: `7e9f8c3ae727725473d2b1ea2cda5eab1d3e58260b655eae274471c8b7e4e138`
- ssl/ssl_lib.cc: `08c6f95d7bd080812729868223e44ad439a97c2e9c6ca547b452da0a2a79951b`
- ssl/ssl_aead_ctx.cc: `1e2e7cab5370c4a55f255c3d3ed9fde74a70f312029058ae27ef2bf3dc36d8ba`
- crypto/internal.h: `82a83995418b7485a5cef44636870cc726026c0021a7adf3ba973ec0d923056c`
- crypto/fipsmodule/cipher/e_aes.cc.inc: `058199cb72531980b06a07c74b75a93cf38747ac051f560dcaf5ce1698911011`

The six opt-in bodies are byte-identical (`six_body_identity.json`), as are initializing key_update_aead and InitForKeyUpdate. Pure context matching retains exact method identity, nonce and flag checks. AES matching uses the existing method-storage address accessors without invoking initialization. The readiness-local digest size switch exactly mirrors wire-version/PRF behavior without digest factories. No layout, source-list or default-policy change exists. Generated files, source lists, build templates/flags and private layouts are unchanged.

Full Debug native Zig graph passed6/6 with all38 SSL translation units and matching crypto. Exact invocation/compiler identity and source hashes are in build_commands.json. Selected matching archives, retained externally but excluded from payload:

- libssl.a: `621c98febb1606e01423b5045beb69a8d18d0e48831790745e0a275dda9335cd`
- libcrypto.a: `e130b330cef9b9349f4ef0e9dd381fe100dd42d287d72411adbd711ad76c551c`

The five selected author programs all pass:

| Directory | Program | JSON rows | Scope |
| --- | --- | ---: | --- |
| conformance_final | readiness_conformance |935| all64 legal partial subsets, actual six-call bundle and repeat; all3 actually negotiated suites |
| guards_final | readiness_guards |63| pending/transient fields; unsupported modes/shutdown/policy/session/cipher/secret/owner invariants; retained-empty owners; discard dominance |
| predicates_final_v3 | readiness_predicates |78|9 exact method identity cases;48 initialized-old/pure context differential cases;21 PRF/wire digest branches plus invalid metadata |
| faults_final | readiness_faults |14| no attempted allocation under armed fault; READY permits opt-in OOM; prepared six-call repeat makes no attempt |
| initial_final | readiness_initial |1| genuine fresh native-version0/public-fallback771 client returns PENDING1 |

Normal runs use the unchanged all-C counter SHA afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac and its selftest63. Faults use a separate explicitly identified observer; they are not substituted for normal zero evidence. Warm query rows have all malloc/calloc/realloc/free/requested-byte fields zero and SSL/S3/active-context bytes unchanged. Guard and context mismatch fixtures are direct-unit tests, never authenticated-wire claims. The digest fixture contains the exact extracted production static helper with recorded hash. Actual old factories run outside counted pure scopes.

Independent verifier owns cold-thread ERR/marks/popped-pointer/BIO/observer/CRYPTO_once proof. Independent wire author owns authenticated fragment/control/backpressure interoperability. Their results are separate from these five author programs; no such proof is claimed here before their acceptance. Independent source review of final6772a629 found no remaining finding for the promised native static target. No FIPS-validation or untested shared/prefixed-build claim is made.

Superseded lineage is retained as source/log/result records, with no selected preliminary executables. Baseline compile query-missing RED is baseline_compile_red_corrected (first driver-only -fsyntax-only/-Werror failure is separately marked invalid). initial_fallback_red is genuine runtime exit1 from the public SSL_version compatibility fallback; initial_fallback_green and initial_final preserve correction. build-native-purity-fix.log records a missing MD5 header compile failure; build-native-purity-corrected.log is the final matching successful graph. predicates_final and predicates_final_corrected preserve fixture-only constructor/API compile mistakes; predicates_final_v3 is the selected success. Earlier native images/build IDs remain historical records.

Rebuild any selected focused program with run_readiness.py NATIVE_ROOT ABSENT_OUTPUT --program NAME --zig COMPILER. It accepts supplied existing matching native archives/header source, uses Zig compilation only, records commands, generates ephemeral localhost PKI when needed and removes it even on runtime failure. replay_prebuilt.py ABSENT_OUTPUT validates the complete whitelist/manifest plus five selected current executable identities, then runs all five with fresh ephemeral PKI and no native build. The portable prebuilt replay requires Python3 and openssl; these are evidence tools, not production build dependencies.

restore_source.py --source-kind baseline|error-data INPUT ABSENT_OUTPUT verifies all8709 input paths/types/modes/links/hashes before output creation and installs the17 recorded candidate snapshots. Original source input is the pinned immutable d3bf package, never protected vendor. Inventories retain package modes; official Git mode publication is Root-owned. Source restoration controls/replay results should be reviewed separately; this handoff does not claim an unrun restore test.

payload_files.txt and files.sha256 are the closed payload whitelist and hash manifest; files.sha256 alone is not self-hashed. Only the five current Debug executables in prebuilt_identity.json are selected. Native .a/.o, caches, full source trees, PKI and preliminary executables are excluded. Root may strip staged copies, update only current binary hashes and staged manifest/identity, preserve all historical measured source/archive IDs, and retain originals unchanged. Root owns publication/commit/push to impl/implement-2.3.0. Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain deferred and unclaimed.

Evidence-tool guard revision: replay and restoration canonicalize destination paths and refuse their own payload or any ancestor evidence root marked by files.sha256 before writes. Restoration retains its input-source descendant refusal. replay_guard_controls records9 successful no-write refusals: existing, own-payload, combined-root sibling and symlink-parent outputs for both tools, plus restoration inside input. The control runs actual script copies under native/ within a synthetic combined root; fixture paths/types/content remain unchanged. Guard source SHA 87ac6f4ac97a9d55ba530972f2e13a765a40571b3d545774c5f9105d0ff5401c. Replay source SHA 9b702669148cba9c7c79f3796b04f38dc5f8758868242f22f5f169548c8dd7b8; restore source SHA a1f981a5265ce6cb5ccf9d96e86ba2b356daf25c9c17c3a98bb2c28adcc2713b. replay_guard_history retains the initial182-file handoff/manifest/whitelist identities as historical records. Native patch, all five selected executable identities and all measured program source/log/results remain unchanged.
