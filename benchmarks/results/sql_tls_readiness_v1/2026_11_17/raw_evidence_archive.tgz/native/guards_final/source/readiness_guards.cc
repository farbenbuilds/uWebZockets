#include "readiness_checks.h"

static int new_session(SSL *, SSL_SESSION *) { return 0; }

int main(int argc, char **argv) {
  CHECK(argc == 4 && uwz_alloc_self_test() == 1);
  query_exact("null", nullptr, ssl_client_storage_unsupported);
  PeerPair p = make_pair(argv, TLS1_3_VERSION, 4096);
  SSL *ssl=p.client;
  auto *impl=bssl::FromOpaque(ssl);
  auto *s=impl->s3;
  query_exact("server",p.server,ssl_client_storage_unsupported);
  query_exact("unprepared_completed",ssl,ssl_client_storage_ready);
  auto *original_s=s;impl->s3=nullptr;query_exact("missing_s3",ssl,ssl_client_storage_unsupported);impl->s3=original_s;
  const auto old_version=s->version;s->version=TLS1_2_VERSION;query_exact("known_tls12",ssl,ssl_client_storage_unsupported);s->version=old_version;
  const SSL_QUIC_METHOD quic={};impl->quic_method=&quic;query_exact("quic",ssl,ssl_client_storage_unsupported);impl->quic_method=nullptr;
  for(auto shutdown:{bssl::ssl_shutdown_close_notify,bssl::ssl_shutdown_error}){
    s->read_shutdown=shutdown;query_exact("read_shutdown",ssl,ssl_client_storage_unsupported);s->read_shutdown=bssl::ssl_shutdown_none;
    s->write_shutdown=shutdown;query_exact("write_shutdown",ssl,ssl_client_storage_unsupported);s->write_shutdown=bssl::ssl_shutdown_none;
  }
  const int old_policy=SSL_CTX_get_session_cache_mode(p.client_context);
  SSL_CTX_set_session_cache_mode(p.client_context,SSL_SESS_CACHE_OFF);query_exact("cache_off_zero",ssl,ssl_client_storage_ready);
  SSL_CTX_set_session_cache_mode(p.client_context,SSL_SESS_CACHE_SERVER);query_exact("cache_server_two",ssl,ssl_client_storage_ready);
  SSL_CTX_set_session_cache_mode(p.client_context,SSL_SESS_CACHE_CLIENT);query_exact("cache_client",ssl,ssl_client_storage_unsupported);
  SSL_CTX_set_session_cache_mode(p.client_context,SSL_SESS_CACHE_BOTH);query_exact("cache_both",ssl,ssl_client_storage_unsupported);
  SSL_CTX_set_session_cache_mode(p.client_context,old_policy);
  SSL_CTX_sess_set_new_cb(p.client_context,new_session);query_exact("new_session_callback_policy",ssl,ssl_client_storage_unsupported);SSL_CTX_sess_set_new_cb(p.client_context,nullptr);
  {auto ctx=std::move(impl->session_ctx);query_exact("missing_effective_context",ssl,ssl_client_storage_unsupported);impl->session_ctx=std::move(ctx);}
  {auto session=std::move(s->established_session);s->initial_handshake_complete=false;query_exact("initial_precedes_missing_session",ssl,ssl_client_storage_pending);s->initial_handshake_complete=true;query_exact("missing_session",ssl,ssl_client_storage_unsupported);s->established_session=std::move(session);}
  auto *session=s->established_session.get();const SSL_CIPHER *cipher=session->cipher;
  session->cipher=nullptr;query_exact("missing_cipher",ssl,ssl_client_storage_unsupported);session->cipher=cipher;
  {auto ctx=std::move(s->aead_read_ctx);query_exact("missing_read_context",ssl,ssl_client_storage_unsupported);s->aead_read_ctx=std::move(ctx);}
  {auto ctx=std::move(s->aead_write_ctx);query_exact("missing_write_context",ssl,ssl_client_storage_unsupported);s->aead_write_ctx=std::move(ctx);}
  auto read_secret=s->read_traffic_secret;s->read_traffic_secret.pop_back();query_exact("read_secret_length",ssl,ssl_client_storage_unsupported);s->read_traffic_secret=read_secret;OPENSSL_cleanse(read_secret.data(),read_secret.size());
  auto write_secret=s->write_traffic_secret;s->write_traffic_secret.pop_back();query_exact("write_secret_length",ssl,ssl_client_storage_unsupported);s->write_traffic_secret=write_secret;OPENSSL_cleanse(write_secret.data(),write_secret.size());
  auto old_wire=session->ssl_version;session->ssl_version=0xffff;query_exact("invalid_session_wire_version",ssl,ssl_client_storage_unsupported);session->ssl_version=old_wire;
  auto old_fragment=impl->max_send_fragment;for(unsigned n:{511u,16385u}){impl->max_send_fragment=n;query_exact("invalid_fragment_bound",ssl,ssl_client_storage_unsupported);}impl->max_send_fragment=old_fragment;
  for(unsigned n:{512u,16384u}){impl->max_send_fragment=n;query_exact("valid_fragment_bound",ssl,ssl_client_storage_ready);}impl->max_send_fragment=old_fragment;
  prepare_bits(ssl,63);query_exact("all_retained_empty",ssl,ssl_client_storage_ready);
  uint8_t byte=0;
  s->pending_app_data=bssl::Span<uint8_t>(&byte,1);query_exact("pending_app_data",ssl,ssl_client_storage_pending);s->pending_app_data={};
  s->pending_write=bssl::Span<const uint8_t>(&byte,1);query_exact("pending_write",ssl,ssl_client_storage_pending);s->pending_write={};
#define PENDING_FIELD(field,value) do {auto before=s->field;s->field=value;query_exact(#field,ssl,ssl_client_storage_pending);s->field=before;}while(0)
  PENDING_FIELD(unreported_bytes_written,1);PENDING_FIELD(has_message,true);PENDING_FIELD(alert_dispatch,true);PENDING_FIELD(key_update_pending,true);PENDING_FIELD(pending_flight_offset,1);
#undef PENDING_FIELD
  s->read_buffer.DidWrite(1);query_exact("read_buffer",ssl,ssl_client_storage_pending);s->read_buffer.Clear();
  s->write_buffer.DidWrite(1);query_exact("write_buffer",ssl,ssl_client_storage_pending);s->write_buffer.Clear();
  for(BUF_MEM *buffer:{s->hs_buf.get(),s->pending_hs_data.get(),s->pending_flight.get()}){CHECK(buffer&&buffer->data&&buffer->length==0);buffer->length=1;query_exact("pending_owned_buffer",ssl,ssl_client_storage_pending);buffer->length=0;}
  {auto spare=std::move(s->key_update_spare);s->key_update_candidate=spare.get();query_exact("borrowed_candidate_precedes_spare_invariant",ssl,ssl_client_storage_pending);s->key_update_candidate=nullptr;query_exact("missing_required_spare",ssl,ssl_client_storage_unsupported);s->key_update_spare=std::move(spare);}
  s->key_update_cipher=nullptr;query_exact("orphan_spare",ssl,ssl_client_storage_unsupported);s->key_update_cipher=cipher;
  {auto spare=std::move(s->key_update_spare);s->key_update_spare=bssl::SSLAEADContext::CreateNullCipher();s->key_update_spare->cipher_=cipher;query_exact("nonempty_spare",ssl,ssl_client_storage_unsupported);s->key_update_spare->cipher_=nullptr;s->key_update_spare=std::move(spare);}
  SSL_CIPHER other=*cipher;other.protocol_id=0x1302;s->key_update_cipher=&other;query_exact("wrong_context_marker",ssl,ssl_client_storage_unsupported);s->key_update_cipher=cipher;
  s->key_update_output_cipher=&other;query_exact("wrong_output_marker",ssl,ssl_client_storage_unsupported);s->key_update_output_cipher=cipher;
  {auto buffer=std::move(s->pending_hs_data);query_exact("missing_plaintext_owner",ssl,ssl_client_storage_unsupported);s->pending_hs_data=std::move(buffer);}
  {auto buffer=std::move(s->pending_flight);query_exact("missing_ciphertext_owner",ssl,ssl_client_storage_unsupported);s->pending_flight=std::move(buffer);}
  for(BUF_MEM *buffer:{s->pending_hs_data.get(),s->pending_flight.get()}){auto *data=buffer->data;buffer->data=nullptr;query_exact("missing_output_data",ssl,ssl_client_storage_unsupported);buffer->data=data;auto cap=buffer->max;buffer->max=buffer==s->pending_hs_data.get()?4:26;query_exact("short_output_capacity",ssl,ssl_client_storage_unsupported);buffer->max=cap;}
  {auto owner=std::move(s->reserved_read_error);query_exact("alert_owner_only",ssl,ssl_client_storage_unsupported);s->reserved_read_error=std::move(owner);}
  {auto owner=std::move(s->reserved_alert_error);query_exact("read_owner_only",ssl,ssl_client_storage_unsupported);s->reserved_alert_error=std::move(owner);}
  SSL_CTX_set_session_cache_mode(p.client_context,SSL_SESS_CACHE_BOTH);SSL_CTX_sess_set_new_cb(p.client_context,new_session);query_exact("active_discard_dominates_context_change",ssl,ssl_client_storage_ready);conformance_bundle(ssl);
  destroy_pair(&p);
  bssl::UniquePtr<SSL_CTX> dtls_ctx(SSL_CTX_new(DTLS_method()));bssl::UniquePtr<SSL> dtls(SSL_new(dtls_ctx.get()));SSL_set_connect_state(dtls.get());query_exact("dtls",dtls.get(),ssl_client_storage_unsupported);
  puts("PASS direct-unit metadata/owner guards; private states are not wire evidence");
}
