#include <ssl/internal.h>
#include <openssl/ssl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

#define REQUIRE(value) do { if (!(value)) { fprintf(stderr, "FAIL line%d: %s\n", __LINE__, #value); abort(); } } while (0)

int main() {
  REQUIRE(uwz_alloc_self_test() == 1);
  SSL_CTX *context = SSL_CTX_new(TLS_method());
  REQUIRE(context != nullptr);
  REQUIRE(SSL_CTX_set_min_proto_version(context, TLS1_3_VERSION));
  REQUIRE(SSL_CTX_set_max_proto_version(context, TLS1_3_VERSION));
  SSL *client = SSL_new(context);
  REQUIRE(client != nullptr);
  SSL_set_connect_state(client);
  const auto *state = bssl::FromOpaque(client)->s3;
  const int negotiated = state->version;
  const int compatibility = SSL_version(client);
  REQUIRE(negotiated == 0 && compatibility == TLS1_2_VERSION);
  uwz_alloc_begin();
  const auto result = SSL_get_client_storage_readiness(client);
  uwz_alloc_end();
  REQUIRE(uwz_alloc_malloc_calls() == 0 && uwz_alloc_calloc_calls() == 0 &&
          uwz_alloc_realloc_calls() == 0 && uwz_alloc_free_calls() == 0 &&
          uwz_alloc_requested_bytes() == 0);
  printf("{\"case\":\"fresh_public_client\",\"native_negotiated_version\":%d,\"public_compatibility_version\":%d,\"readiness\":%d,\"expected_pending\":1,\"heap_operations\":0}\n",
         negotiated, compatibility, result);
  SSL_free(client);
  SSL_CTX_free(context);
  return result == ssl_client_storage_pending ? 0 : 1;
}
