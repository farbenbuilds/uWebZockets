#include "readiness_checks.h"

static void subsets(char **arguments) {
  for (unsigned bits = 0; bits < 64; bits++) {
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 4096);
    query_exact("fresh_completed", pair.client, ssl_client_storage_ready);
    prepare_bits(pair.client, bits);
    query_exact("legal_partial_subset", pair.client, ssl_client_storage_ready);
    conformance_bundle(pair.client);
    conformance_bundle(pair.client);
    destroy_pair(&pair);
  }
  puts("PASS all64 legal partial subsets: READY before/after each actual six-call bundle and idempotent repeat");
}

static void suites(char **arguments) {
  const uint16_t suites[] = {0x1301, 0x1302, 0x1303};
  for (uint16_t suite : suites) {
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 4096, suite);
    query_exact("supported_suite", pair.client, ssl_client_storage_ready);
    conformance_bundle(pair.client);
    conformance_bundle(pair.client);
    destroy_pair(&pair);
  }
  puts("PASS three actually negotiated suites with six-call conformance");
}

int main(int argc, char **argv) {
  CHECK(argc == 4 && uwz_alloc_self_test() == 1);
  static_assert(ssl_client_storage_unsupported == 0, "stable unsupported value");
  static_assert(ssl_client_storage_pending == 1, "stable pending value");
  static_assert(ssl_client_storage_ready == 2, "stable ready value");
  subsets(argv);
  suites(argv);
  puts("PASS focused readiness-to-real-opt-in conformance; no wire-state fabrication");
}
