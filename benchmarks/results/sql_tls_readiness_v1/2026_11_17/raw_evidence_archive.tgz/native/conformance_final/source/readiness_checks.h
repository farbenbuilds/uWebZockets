#ifndef UWZ_READINESS_CHECKS_H
#define UWZ_READINESS_CHECKS_H

#include "ticket_pair.h"

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

using StorageCall = int (*)(SSL *);

struct StorageStep {
  const char *name;
  StorageCall call;
};

static const StorageStep kStorageSteps[] = {
    {"record", SSL_reserve_record_buffers},
    {"incoming", SSL_reserve_client_post_handshake_buffer},
    {"context", SSL_reserve_key_update_context},
    {"output", SSL_reserve_key_update_output_buffers},
    {"errors", SSL_reserve_error_state},
    {"tickets", SSL_discard_client_session_tickets},
};

struct ReadinessCounts {
  uint64_t mallocs;
  uint64_t callocs;
  uint64_t reallocs;
  uint64_t frees;
  uint64_t bytes;
};

static inline ReadinessCounts finish_counts() {
  uwz_alloc_end();
  return {uwz_alloc_malloc_calls(), uwz_alloc_calloc_calls(),
          uwz_alloc_realloc_calls(), uwz_alloc_free_calls(), uwz_alloc_requested_bytes()};
}

static inline void require_zero(const ReadinessCounts &counts) {
  CHECK(counts.mallocs == 0 && counts.callocs == 0 && counts.reallocs == 0 &&
        counts.frees == 0 && counts.bytes == 0);
}

static inline void query_exact(const char *name, const SSL *ssl,
                               enum ssl_client_storage_readiness_t expected) {
  const auto *impl = ssl ? bssl::FromOpaque(ssl) : nullptr;
  const auto *state = impl ? impl->s3 : nullptr;
  uint8_t ssl_before[sizeof(bssl::SSLImpl)] = {};
  uint8_t state_before[sizeof(bssl::SSL3_STATE)] = {};
  uint8_t read_before[sizeof(bssl::SSLAEADContext)] = {};
  uint8_t write_before[sizeof(bssl::SSLAEADContext)] = {};
  if (impl) memcpy(ssl_before, impl, sizeof(ssl_before));
  if (state) {
    memcpy(state_before, state, sizeof(state_before));
    if (state->aead_read_ctx) memcpy(read_before, state->aead_read_ctx.get(), sizeof(read_before));
    if (state->aead_write_ctx) memcpy(write_before, state->aead_write_ctx.get(), sizeof(write_before));
  }
  uwz_alloc_begin();
  const auto actual = SSL_get_client_storage_readiness(ssl);
  const ReadinessCounts counts = finish_counts();
  CHECK(actual == expected);
  require_zero(counts);
  if (impl) CHECK(memcmp(ssl_before, impl, sizeof(ssl_before)) == 0);
  if (state) {
    CHECK(memcmp(state_before, state, sizeof(state_before)) == 0);
    if (state->aead_read_ctx) CHECK(memcmp(read_before, state->aead_read_ctx.get(), sizeof(read_before)) == 0);
    if (state->aead_write_ctx) CHECK(memcmp(write_before, state->aead_write_ctx.get(), sizeof(write_before)) == 0);
  }
  OPENSSL_cleanse(ssl_before, sizeof(ssl_before));
  OPENSSL_cleanse(state_before, sizeof(state_before));
  OPENSSL_cleanse(read_before, sizeof(read_before));
  OPENSSL_cleanse(write_before, sizeof(write_before));
  printf("{\"case\":\"%s\",\"status\":%d,\"heap_operations\":0,\"ssl_and_crypto_state_unchanged\":true}\n", name, actual);
}

static inline void prepare_bits(SSL *ssl, unsigned bits) {
  for (size_t index = 0; index < sizeof(kStorageSteps) / sizeof(kStorageSteps[0]); index++) {
    if ((bits & (1u << index)) != 0) CHECK(kStorageSteps[index].call(ssl) == 1);
  }
}

static inline void conformance_bundle(SSL *ssl) {
  for (const StorageStep &step : kStorageSteps) {
    CHECK(step.call(ssl) == 1);
    query_exact(step.name, ssl, ssl_client_storage_ready);
  }
}

#endif
