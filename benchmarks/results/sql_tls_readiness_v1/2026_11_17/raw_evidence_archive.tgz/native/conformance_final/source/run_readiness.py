#!/usr/bin/env python3
"""Compile and replay focused client-storage readiness evidence."""
import argparse,hashlib,json,os,pathlib,shutil,subprocess

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('native_root',type=pathlib.Path);a.add_argument('output',type=pathlib.Path);a.add_argument('--program',choices=['conformance','guards','predicates','faults','initial'],required=True);a.add_argument('--zig',default='/tmp/zig-x86_64-linux-0.16.0/zig');a.add_argument('--prebuilt',type=pathlib.Path);x=a.parse_args()
 base=pathlib.Path(__file__).resolve().parent;n=x.native_root.resolve(strict=True);out=x.output.absolute()
 if out.exists() or out.is_symlink():raise ValueError('Choose an absent output directory')
 out.mkdir(mode=0o700);src=out/'source';src.mkdir();name='readiness_'+x.program
 names=[name+'.cc','allocation_scope.c','run_readiness.py']
 if x.program not in ['initial','predicates']:names+=['ticket_pair.h','readiness_checks.h']
 if x.program=='faults':names+=['ticket_fault.c','ticket_fault.h']
 for f in names:shutil.copy2(base/f,src/f)
 assert sha(src/'allocation_scope.c')=='afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac'
 if x.program=='predicates':
  text=(n/'boringssl/ssl/ssl_lib.cc').read_text();start=text.index('static size_t client_storage_digest_size(');end=text.index('\nenum ssl_client_storage_readiness_t ',start)
  (src/'digest_mapping.h').write_text('BSSL_NAMESPACE_BEGIN\n'+text[start:end]+'\nBSSL_NAMESPACE_END\n')
 env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(base/'global-cache'));commands=[]
 def run(cmd,stem):
  with (out/(stem+'.stdout')).open('wb') as so,(out/(stem+'.stderr')).open('wb') as se:r=subprocess.run([str(c) for c in cmd],stdout=so,stderr=se,cwd=out,env=env)
  commands.append({'command':[str(c) for c in cmd],'exit_code':r.returncode,'stem':stem});(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  if r.returncode:raise RuntimeError(str(out/stem))
 libs=[n/'native_out/lib/libssl.a',n/'native_out/lib/libcrypto.a'];binary=out/name
 if x.prebuilt:shutil.copy2(x.prebuilt,binary)
 else:
  counter='ticket_fault.c' if x.program=='faults' else 'allocation_scope.c'
  run([x.zig,'cc','-std=c11','-O0','-g','-Wall','-Wextra','-Werror','-c',src/counter,'-o',out/'counter.o'],'build-counter')
  run([x.zig,'c++','-std=c++17','-O0','-g','-Wall','-Wextra','-Werror','-fno-access-control','-DBORINGSSL_IMPLEMENTATION','-isystem',n/'boringssl','-isystem',n/'boringssl/include',src/(name+'.cc'),out/'counter.o',*libs,'-o',binary],'build-program')
 pki=out/'ephemeral-pki'
 try:
  args=[]
  if x.program in ['conformance','guards','faults']:
   pki.mkdir(mode=0o700)
   run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',pki/'key.pem','-out',pki/'cert.pem','-days','1','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost'],'pki')
   args=[pki/'cert.pem',pki/'key.pem',pki/'cert.pem']
  run([binary,*args],'run')
 finally:
  if pki.exists():shutil.rmtree(pki)
 rows=[]
 for line in (out/'run.stdout').read_text().splitlines():
  if line.startswith('{'):rows.append(json.loads(line))
 (out/'results.json').write_text(json.dumps({'complete':True,'program':x.program,'query_rows':len(rows),'binary_sha256':sha(binary),'archives_sha256':{p.name:sha(p) for p in libs},'source_sha256':{p.name:sha(p) for p in src.iterdir()},'ephemeral_pki_removed':not pki.exists(),'scope':'focused readiness metadata/conformance; private invariant fixtures explicitly direct-unit only; no dedicated campaign'},indent=2)+'\n')
 print(json.dumps({'program':x.program,'complete':True,'query_rows':len(rows),'binary_sha256':sha(binary)}))
if __name__=='__main__':main()
