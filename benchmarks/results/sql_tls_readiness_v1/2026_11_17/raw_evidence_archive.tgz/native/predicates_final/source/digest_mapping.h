BSSL_NAMESPACE_BEGIN
static size_t client_storage_digest_size(const SSLSession *session) {
  uint16_t version;
  if (!ssl_protocol_version_from_wire(&version, session->ssl_version)) {
    return 0;
  }
  switch (session->cipher->algorithm_prf) {
    case SSL_HANDSHAKE_MAC_DEFAULT:
      return version >= TLS1_2_VERSION ? SHA256_DIGEST_LENGTH
                                     : MD5_DIGEST_LENGTH + SHA_DIGEST_LENGTH;
    case SSL_HANDSHAKE_MAC_SHA256:
      return SHA256_DIGEST_LENGTH;
    case SSL_HANDSHAKE_MAC_SHA384:
      return SHA384_DIGEST_LENGTH;
    default:
      return 0;
  }
}

BSSL_NAMESPACE_END
