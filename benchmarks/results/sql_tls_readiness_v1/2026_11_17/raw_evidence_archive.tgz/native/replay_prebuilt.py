#!/usr/bin/env python3
"""Validate and replay the five selected readiness programs without rebuilding."""
import argparse,hashlib,json,os,pathlib,shutil,subprocess

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('output',type=pathlib.Path);a.add_argument('--payload',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent);a.add_argument('--openssl',default='openssl');x=a.parse_args()
 base=x.payload.resolve(strict=True);out=x.output.absolute()
 if out.exists() or out.is_symlink():raise ValueError('Choose an absent output directory')
 out=out.resolve()
 evidence_roots=[base]+[parent for parent in base.parents if (parent/'files.sha256').exists() or (parent/'files.sha256').is_symlink()]
 if any(out.is_relative_to(root) for root in evidence_roots):raise ValueError('Output must be outside payload and enclosing evidence roots')
 allow=(base/'payload_files.txt').read_text().splitlines();manifest={}
 for line in (base/'files.sha256').read_text().splitlines():
  digest,relative=line.split('  ',1);manifest[relative]=digest
 if set(manifest)!=(set(allow)-{'files.sha256'}):raise ValueError('Whitelist/manifest differ')
 for relative in allow:
  q=pathlib.PurePosixPath(relative)
  if q.is_absolute() or '..' in q.parts:raise ValueError('Unsafe payload name')
  p=base/relative
  if p.is_symlink() or not p.is_file():raise ValueError('Payload type differs: '+relative)
  if relative!='files.sha256' and sha(p)!=manifest[relative]:raise ValueError('Payload hash differs: '+relative)
 identity=json.loads((base/'prebuilt_identity.json').read_text())
 for relative,digest in identity['binaries'].items():
  if relative not in manifest or sha(base/relative)!=digest:raise ValueError('Selected executable identity differs')
 out.mkdir(mode=0o700);pki=out/'ephemeral-pki';pki.mkdir(mode=0o700);commands=[];selected=[]
 def run(cmd,stem):
  with (out/(stem+'.stdout')).open('wb') as so,(out/(stem+'.stderr')).open('wb') as se:r=subprocess.run([str(c) for c in cmd],cwd=out,stdout=so,stderr=se)
  commands.append({'command':[str(c) for c in cmd],'exit_code':r.returncode,'stem':stem});(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  if r.returncode:raise RuntimeError('Replay failed: '+stem)
 try:
  run([x.openssl,'req','-x509','-newkey','rsa:2048','-nodes','-keyout',pki/'key.pem','-out',pki/'cert.pem','-days','1','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost'],'pki')
  for relative,expected in identity['expected_query_rows'].items():
   binary=base/relative;name=binary.name;args=[pki/'cert.pem',pki/'key.pem',pki/'cert.pem'] if name in ['readiness_conformance','readiness_guards','readiness_faults'] else []
   run([binary,*args],name);rows=[json.loads(s) for s in (out/(name+'.stdout')).read_text().splitlines() if s.startswith('{')]
   if len(rows)!=expected:raise ValueError('Unexpected query row count: '+name)
   selected.append({'binary':relative,'sha256':sha(binary),'rows':len(rows),'exit_code':0})
 finally:
  shutil.rmtree(pki)
 (out/'results.json').write_text(json.dumps({'complete':True,'selected_programs':selected,'commands':len(commands),'ephemeral_pki_removed':not pki.exists(),'identity_sha256':sha(base/'prebuilt_identity.json'),'payload_manifest_sha256':sha(base/'files.sha256')},indent=2)+'\n')
 print(json.dumps({'complete':True,'programs':len(selected),'commands':len(commands),'query_rows':sum(r['rows'] for r in selected),'ephemeral_pki_removed':not pki.exists()}))
if __name__=='__main__':main()
