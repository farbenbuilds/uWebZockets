#include <ssl/internal.h>
#include <openssl/md5.h>
#include <openssl/sha.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "digest_mapping.h"

extern "C" {void uwz_alloc_begin(void);void uwz_alloc_end(void);uint64_t uwz_alloc_malloc_calls(void);uint64_t uwz_alloc_calloc_calls(void);uint64_t uwz_alloc_realloc_calls(void);uint64_t uwz_alloc_free_calls(void);uint64_t uwz_alloc_requested_bytes(void);int uwz_alloc_self_test(void);}
#define CHECK(x) do{if(!(x)){fprintf(stderr,"check failed %d: %s\n",__LINE__,#x);abort();}}while(0)
using namespace bssl;

// Exact pre-correction initialized predicate, used only outside purity scopes.
static const EVP_AEAD *old_key_update_aead(const SSL_CIPHER *cipher) {
  if(cipher==nullptr||SSL_CIPHER_get_min_version(cipher)!=TLS1_3_VERSION)return nullptr;
  const EVP_AEAD *aead;size_t mac_len,iv_len;
  if(!ssl_cipher_get_evp_aead(&aead,&mac_len,&iv_len,cipher,TLS1_3_VERSION)||mac_len!=0||iv_len!=12||(aead!=EVP_aead_aes_128_gcm_tls13()&&aead!=EVP_aead_aes_256_gcm_tls13()&&aead!=EVP_aead_chacha20_poly1305()))return nullptr;
  return aead;
}
static bool old_context(const SSLAEADContext *ctx,const SSL_CIPHER *cipher){
 const EVP_AEAD *aead=old_key_update_aead(cipher);
 return ctx!=nullptr&&aead!=nullptr&&ctx->cipher_==cipher&&EVP_AEAD_CTX_aead(ctx->ctx_.get())==aead&&ctx->fixed_nonce_.size()==12&&ctx->variable_nonce_len_==8&&!ctx->variable_nonce_included_in_record_&&!ctx->random_variable_nonce_&&ctx->xor_fixed_nonce_&&!ctx->omit_length_in_ad_&&ctx->ad_is_header_;
}
static void zero(){uwz_alloc_end();CHECK(uwz_alloc_malloc_calls()==0&&uwz_alloc_calloc_calls()==0&&uwz_alloc_realloc_calls()==0&&uwz_alloc_free_calls()==0&&uwz_alloc_requested_bytes()==0);}
static void compare(const char *name,const SSLAEADContext *ctx,const SSL_CIPHER *cipher,bool expected){
 bool old=old_context(ctx,cipher);CHECK(old==expected);uwz_alloc_begin();bool current=SSLAEADContext::IsKeyUpdateContext(ctx,cipher);zero();CHECK(current==old);printf("{\"case\":\"%s\",\"equivalent\":true,\"expected\":%d,\"heap_operations\":0}\n",name,expected);
}
static void method_case(const char *name,const EVP_AEAD *method,size_t length,bool expected){uwz_alloc_begin();bool matches=aes_gcm_tls13_method_matches(method,length);zero();CHECK(matches==expected);printf("{\"case\":\"%s\",\"method_identity\":true,\"heap_operations\":0}\n",name);}
int main(){
 CHECK(uwz_alloc_self_test()==1);
 method_case("null_method",nullptr,16,false);
 const EVP_AEAD *a128=EVP_aead_aes_128_gcm_tls13(),*a256=EVP_aead_aes_256_gcm_tls13();
 method_case("exact_aes128",a128,16,true);method_case("exact_aes256",a256,32,true);method_case("wrong_aes256",a256,16,false);method_case("wrong_aes128",a128,32,false);method_case("invalid_selector",a128,24,false);method_case("generic_same_keysize",EVP_aead_aes_128_gcm(),16,false);method_case("tls12_same_keysize",EVP_aead_aes_128_gcm_tls12(),16,false);method_case("chacha_wrong_method",EVP_aead_chacha20_poly1305(),32,false);
 for(uint16_t suite:{0x1301,0x1302,0x1303}){
  const SSL_CIPHER *cipher=SSL_get_cipher_by_value(suite);CHECK(cipher);
  const EVP_AEAD *method=old_key_update_aead(cipher);uint8_t key[32]={},iv[12]={};
  auto ctx=SSLAEADContext::Create(evp_aead_seal,TLS1_3_VERSION,cipher,MakeConstSpan(key).first(EVP_AEAD_key_length(method)),{},iv);CHECK(ctx);
  compare("legal_context",ctx.get(),cipher,true);compare("null_context",nullptr,cipher,false);compare("null_cipher",ctx.get(),nullptr,false);compare("legacy_cipher",ctx.get(),SSL_get_cipher_by_value(0xc02f),false);
  SSL_CIPHER fake=*cipher;fake.algorithm_mac=0;compare("wrong_mac",ctx.get(),&fake,false);fake=*cipher;fake.algorithm_enc=SSL_AES128;compare("unsupported_encryption",ctx.get(),&fake,false);
  auto *prior=ctx->cipher_;ctx->cipher_=nullptr;compare("wrong_cipher_identity",ctx.get(),cipher,false);ctx->cipher_=prior;
  const EVP_AEAD *prior_method=ctx->ctx_.get()->aead;ctx->ctx_.get()->aead=EVP_aead_aes_128_gcm();compare("wrong_same_size_method",ctx.get(),cipher,false);ctx->ctx_.get()->aead=nullptr;compare("absent_method",ctx.get(),cipher,false);ctx->ctx_.get()->aead=prior_method;
  auto nonce=ctx->fixed_nonce_;ctx->fixed_nonce_.pop_back();compare("short_fixed_nonce",ctx.get(),cipher,false);ctx->fixed_nonce_=nonce;OPENSSL_cleanse(nonce.data(),nonce.size());
  auto variable=ctx->variable_nonce_len_;ctx->variable_nonce_len_=7;compare("wrong_variable_nonce_length",ctx.get(),cipher,false);ctx->variable_nonce_len_=variable;
#define FLAG(field) do{bool previous=ctx->field;ctx->field=!previous;compare(#field,ctx.get(),cipher,false);ctx->field=previous;}while(0)
  FLAG(variable_nonce_included_in_record_);FLAG(random_variable_nonce_);FLAG(xor_fixed_nonce_);FLAG(omit_length_in_ad_);FLAG(ad_is_header_);
#undef FLAG
 }
 const uint16_t wires[]={TLS1_VERSION,TLS1_1_VERSION,TLS1_2_VERSION,TLS1_3_VERSION,DTLS1_VERSION,DTLS1_2_VERSION,DTLS1_3_VERSION};
 const uint32_t prfs[]={SSL_HANDSHAKE_MAC_DEFAULT,SSL_HANDSHAKE_MAC_SHA256,SSL_HANDSHAKE_MAC_SHA384};
 SSL_CIPHER cipher=*SSL_get_cipher_by_value(0x1301);UniquePtr<SSL_SESSION> owner(SSL_SESSION_new());CHECK(owner);auto *session=FromOpaque(owner.get());session->cipher=&cipher;
 for(uint16_t wire:wires)for(uint32_t prf:prfs){session->ssl_version=wire;cipher.algorithm_prf=prf;size_t old=EVP_MD_size(ssl_session_get_digest(session));uwz_alloc_begin();size_t current=client_storage_digest_size(session);zero();CHECK(current==old);printf("{\"case\":\"digest_equivalence\",\"wire\":%u,\"prf\":%u,\"bytes\":%zu,\"heap_operations\":0}\n",wire,prf,current);}
 session->ssl_version=0xffff;CHECK(client_storage_digest_size(session)==0);session->ssl_version=TLS1_3_VERSION;cipher.algorithm_prf=0xffffffff;CHECK(client_storage_digest_size(session)==0);
 puts("PASS direct-unit exact method identities, initialized guard differential and exact extracted production digest mapping; no fabricated wire claim");
}
