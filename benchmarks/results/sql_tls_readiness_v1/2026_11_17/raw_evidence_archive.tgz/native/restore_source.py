#!/usr/bin/env python3
"""Restore the exact readiness source from upstream or the frozen error-data base."""
import argparse,hashlib,json,os,pathlib,shutil,stat

def main():
 base=pathlib.Path(__file__).resolve().parent;a=argparse.ArgumentParser(description=__doc__);a.add_argument('--source-kind',choices=['baseline','error-data'],default='baseline');a.add_argument('source',type=pathlib.Path);a.add_argument('destination',type=pathlib.Path);x=a.parse_args();source=x.source.resolve(strict=True);destination=x.destination.absolute()
 if destination.exists() or destination.is_symlink():raise ValueError('Choose an absent source destination')
 destination=destination.resolve()
 if destination.resolve().is_relative_to(source):raise ValueError('Destination must not be inside input source')
 evidence_roots=[base]+[parent for parent in base.parents if (parent/'files.sha256').exists() or (parent/'files.sha256').is_symlink()]
 if any(destination.is_relative_to(root) for root in evidence_roots):raise ValueError('Destination must be outside payload and enclosing evidence roots')
 inventory=json.loads((base/('original_source_inventory.json' if x.source_kind=='baseline' else 'baseline_inventory.json')).read_text());names={e['path'] for e in inventory['entries']};actual={p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file() or p.is_symlink()}
 if actual!=names:raise ValueError('Input source file set differs')
 for e in inventory['entries']:
  relative=pathlib.PurePosixPath(e['path'])
  if relative.is_absolute() or '..' in relative.parts:raise ValueError('Unsafe inventory path')
  p=source/e['path'];info=p.lstat()
  if stat.S_IMODE(info.st_mode)!=e['mode']:raise ValueError('Input source mode differs: '+e['path'])
  if e['kind']=='symlink':
   if not p.is_symlink() or os.readlink(p)!=e['target']:raise ValueError('Input source symlink differs: '+e['path'])
  elif not stat.S_ISREG(info.st_mode) or hashlib.sha256(p.read_bytes()).hexdigest()!=e['sha256']:raise ValueError('Input source type/hash differs: '+e['path'])
 provenance=json.loads((base/'provenance.json').read_text());candidate=json.loads((base/'candidate_source_inventory.json').read_text());modes={e['path']:e['mode'] for e in candidate['entries'] if e['kind']=='file'};payloads=[]
 for relative,checksum in provenance['snapshot_sha256'].items():
  q=pathlib.PurePosixPath(relative)
  if relative not in names or q.is_absolute() or '..' in q.parts:raise ValueError('Unsafe candidate source path')
  data=(base/'candidate_source'/relative).read_bytes()
  if hashlib.sha256(data).hexdigest()!=checksum:raise ValueError('Candidate source hash differs: '+relative)
  payloads.append((relative,data))
 shutil.copytree(source,destination,symlinks=True)
 for relative,data in payloads:
  target=destination/relative;target.chmod(stat.S_IMODE(target.stat().st_mode)|stat.S_IWUSR);target.write_bytes(data);target.chmod(modes[relative])
 print('Restored exact readiness candidate; '+str(len(names))+' entries verified before output creation.')
if __name__=='__main__':main()
