# Local client TLS readiness source proposal

This compact source proof retains two append-only local BoringSSL proposal
commits. It makes no remote publication or production pin change.

| Identity | Full value |
| --- | --- |
| Official base | `d3bf4795ad5b79d646cddf2fec687da5b9b502db` |
| Official tree | `92ce790e497fe2b5989d9dab81d5301a1b594b68` |
| Initial storage/diagnostics proposal | `33406dd2383eff3e84059a763933b010cc5a663d` |
| Readiness proposal | `f6176c03304e835d315cf4d9cbd86fc27e979f95` |
| Readiness parent | `33406dd2383eff3e84059a763933b010cc5a663d` |
| Readiness tree | `e46cd3464cb187f6ea7086d75e9140b0e9874262` |
| Bundle SHA256 | `2fe9e7c2b7e42aa0fde6c8f0c85cd3680f05d912e9edf7c4f9fd86d0ef0b50e0` |

The included bundle is 20,831 bytes and requires exactly the official base.
**Complete base history is NOT embedded.** Neither a full source tree, Git object
database, cache, native archive nor the older 253 MB full-history bundle is
included. External inputs are declared in `external_inputs.json`.

The readiness commit is named
`uwz(sql): expose pure client TLS storage readiness`. It changes exactly five
paths (156 additions and three deletions), and the combined proposal changes
seventeen paths against official upstream. No unrelated/generated/license file
or official Git mode changes. The earlier fifteen-path commit remains immutable.

`source/` retains exact inventories, blob mappings and diffs. All 8,709 source
contents match the reviewed native candidate and all Git modes match official
upstream. The five-path reviewed patch was independently reconstructed in a
temporary Git index before commit. The original extracted package's 59
executable-bit differences are preserved as evidence in the original origin
report; they are not imported into Git and do not affect native build inputs.

## Offline restore

Verify the top-level payload manifest, then supply a local complete-history
repository whose HEAD is exactly the official base. Choose an absent output
canonically outside this payload, any enclosing artifact and that base repository:

```sh
sha256sum -c files.sha256
python3 restore_source_proposal.py \
  boringssl_sql_client_tls_readiness.bundle \
  /absolute/path/to/official-base-repository \
  /absolute/absent/output
python3 verify_source_proposal.py /absolute/absent/output
```

The helper fetches only local base ancestry, proves both local proposal commit
objects are absent before the bundle fetch, then restores the exact two-commit
chain. It checks commit/parent/tree, clean status, `git diff --check` and
`git fsck --full --strict`. It performs no network fetch. Canonical input guards
also recognize enclosing artifact roots through ancestor `files.sha256` files.

`checks/` records the positive offline roundtrip, complete 8,709-file source and
mode verification in both committed and restored repositories, exact prerequisite
verification, expected missing-base failure and seven no-write refusal controls.
Those controls cover existing output, wrong base, wrong bundle, output inside
the payload or base repository, a symlink alias, and output inside an enclosing
artifact. Validation repositories and output directories are external workspaces,
not payload members.

This payload proves source identity and Git restoration only. Final native,
wire, purity/once and SDK dynamic acceptance belongs to Root's combined evidence
artifact and its independent review; it is not duplicated or claimed here.
Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain user-deferred.
The complete PostgreSQL allocation contract is not established by this source
proposal, and no PostgreSQL allocation exception is approved.
