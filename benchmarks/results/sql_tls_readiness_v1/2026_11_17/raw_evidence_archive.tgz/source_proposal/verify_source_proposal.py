#!/usr/bin/env python3
"""Verify the Git proposal and restored checkout against all reviewed inputs."""
import hashlib
import argparse
import json
import os
from pathlib import Path
import stat
import subprocess

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / 'source'
BASE = 'd3bf4795ad5b79d646cddf2fec687da5b9b502db'
PARENT = '33406dd2383eff3e84059a763933b010cc5a663d'
COMMIT = 'f6176c03304e835d315cf4d9cbd86fc27e979f95'
TREE = 'e46cd3464cb187f6ea7086d75e9140b0e9874262'


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])


def verify_checkout(repo, official, candidate, mapping):
    if git(repo, 'rev-parse', 'HEAD').decode().strip() != COMMIT:
        raise RuntimeError('Unexpected proposal commit')
    if git(repo, 'rev-parse', 'HEAD^').decode().strip() != PARENT:
        raise RuntimeError('Unexpected proposal parent')
    if git(repo, 'rev-parse', 'HEAD^^').decode().strip() != BASE:
        raise RuntimeError('Unexpected official base behind the two local proposals')
    if git(repo, 'rev-parse', 'HEAD^{tree}').decode().strip() != TREE:
        raise RuntimeError('Unexpected proposal tree')
    if git(repo, 'rev-parse', '--is-shallow-repository').decode().strip() != 'false':
        raise RuntimeError('Proposal history is shallow')
    if git(repo, 'status', '--porcelain'):
        raise RuntimeError('Proposal checkout is dirty')
    tree = {}
    for line in git(repo, 'ls-tree', '-rz', '--full-tree', COMMIT).split(b'\0'):
        if line:
            fields, path = line.split(b'\t', 1)
            mode, kind, blob = fields.decode().split()
            tree[path.decode()] = (mode, kind, blob)
    if tree.keys() != official.keys() or tree.keys() != candidate.keys():
        raise RuntimeError('Unexpected proposal path set')
    tree_mismatches = []
    for path in sorted(tree):
        expected_blob = mapping[path]['proposal_blob'] if path in mapping else official[path]['git_blob']
        expected = (official[path]['git_mode'], official[path]['git_kind'], expected_blob)
        if tree[path] != expected:
            tree_mismatches.append(path)
    if tree_mismatches:
        raise RuntimeError(f'Unexpected mode/type/blob: {tree_mismatches}')
    paths = set()
    mismatches = []
    for directory, dirs, files in os.walk(repo):
        if Path(directory) == repo:
            dirs.remove('.git')
        for name in files:
            file = Path(directory) / name
            path = file.relative_to(repo).as_posix()
            paths.add(path)
            metadata = file.lstat()
            if (path not in candidate or not stat.S_ISREG(metadata.st_mode)
                    or hashlib.sha256(file.read_bytes()).hexdigest() != candidate[path]['sha256']
                    or bool(metadata.st_mode & 0o111) != (official[path]['git_mode'] == '100755')):
                mismatches.append(path)
    if paths != candidate.keys() or mismatches:
        raise RuntimeError(f'Checkout does not match reviewed bytes/upstream Git modes: {mismatches}')
    changed = git(repo, 'diff', '--name-only', '-z', BASE, COMMIT).decode().strip('\0').split('\0')
    if sorted(changed) != sorted(mapping):
        raise RuntimeError('Unexpected committed diff paths')
    readiness = json.loads((ROOT / 'source/readiness_git_mapping.json').read_text())['paths']
    readiness_changed = git(repo, 'diff', '--name-only', '-z', PARENT, COMMIT).decode().strip('\0').split('\0')
    if sorted(readiness_changed) != sorted(row['path'] for row in readiness) or len(readiness_changed) != 5:
        raise RuntimeError('Unexpected five-path readiness delta')
    if len(changed) != 17 or any(path.startswith('gen/') or 'license' in path.lower() for path in changed):
        raise RuntimeError('Unexpected cumulative/generated/license change')
    git(repo, 'diff', '--check', BASE, COMMIT)
    return {'commit': COMMIT, 'parent': PARENT, 'official_base': BASE, 'tree': TREE, 'verified_files': len(paths),
            'changed_paths': len(changed), 'readiness_delta_paths': len(readiness_changed),
            'no_generated_or_license_change': True, 'all_candidate_file_sha256_match': True,
            'all_git_modes_match_official': True, 'all_unchanged_blobs_match_official': True,
            'all_changed_blobs_match_reviewed_snapshots': True, 'working_tree_clean': True,
            'complete_history': True, 'diff_check_passed': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('restored_repository', type=Path)
    args = parser.parse_args()
    official = {x['path']: x for x in json.loads((ROOT / 'source/official_tree_inventory.json').read_text())['entries']}
    candidate = {x['path']: x for x in json.loads((INPUTS / 'candidate_source_inventory.json').read_text())['entries']}
    mapping = {x['path']: x for x in json.loads((ROOT / 'source/cumulative_git_mapping.json').read_text())['paths']}
    report = verify_checkout(args.restored_repository.resolve(strict=True), official, candidate, mapping)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
