#!/usr/bin/env python3
"""Restore a prerequisite bundle offline from an exact external official base."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

BUNDLE_SHA256 = '2fe9e7c2b7e42aa0fde6c8f0c85cd3680f05d912e9edf7c4f9fd86d0ef0b50e0'
BASE = 'd3bf4795ad5b79d646cddf2fec687da5b9b502db'
BASE_TREE = '92ce790e497fe2b5989d9dab81d5301a1b594b68'
PARENT = '33406dd2383eff3e84059a763933b010cc5a663d'
COMMIT = 'f6176c03304e835d315cf4d9cbd86fc27e979f95'
TREE = 'e46cd3464cb187f6ea7086d75e9140b0e9874262'
BRANCH = 'proposal/sql-client-tls-readiness-20261117'


def git(repo, *args, check=True):
    return subprocess.run(['git', '-C', str(repo), *args], check=check,
                          capture_output=True, text=True)


def identity(repo, expression):
    return git(repo, 'rev-parse', '--verify', expression).stdout.strip()


def canonical_input_roots(bundle, base_repository):
    script = Path(__file__).resolve()
    roots = {script.parent, base_repository}
    for path in (script, bundle):
        roots.update(parent for parent in path.parents if (parent / 'files.sha256').is_file())
    if git(base_repository, 'rev-parse', '--is-bare-repository').stdout.strip() == 'false':
        roots.add(Path(git(base_repository, 'rev-parse', '--show-toplevel').stdout.strip()).resolve())
    roots.add(Path(git(base_repository, 'rev-parse', '--absolute-git-dir').stdout.strip()).resolve())
    common = Path(git(base_repository, 'rev-parse', '--git-common-dir').stdout.strip())
    roots.add((common if common.is_absolute() else base_repository / common).resolve())
    return roots


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('bundle', type=Path)
    parser.add_argument('base_repository', type=Path,
                        help='local complete-history Git repository with HEAD at the exact official base')
    parser.add_argument('destination', type=Path, help='absent output directory')
    args = parser.parse_args()
    provided_destination = args.destination.absolute()
    if provided_destination.exists() or provided_destination.is_symlink():
        parser.error('destination must not exist; output was not changed')
    destination = provided_destination.resolve(strict=False)
    bundle = args.bundle.resolve(strict=True)
    base_repository = args.base_repository.resolve(strict=True)
    if hashlib.sha256(bundle.read_bytes()).hexdigest() != BUNDLE_SHA256:
        parser.error('bundle SHA256 mismatch; output was not created')
    with bundle.open('rb') as handle:
        header = []
        while True:
            line = handle.readline()
            if line == b'\n':
                break
            if not line:
                parser.error('bundle header is incomplete; output was not created')
            header.append(line.decode().rstrip('\n'))
    prerequisites = [line[1:].split(' ', 1)[0] for line in header if line.startswith('-')]
    refs = [line for line in header if line and not line.startswith(('#', '-', '@'))]
    if prerequisites != [BASE] or refs != [f'{COMMIT} refs/heads/{BRANCH}']:
        parser.error('bundle refs/prerequisite are unexpected; output was not created')
    try:
        base_head = identity(base_repository, 'HEAD^{commit}')
        base_tree = identity(base_repository, 'HEAD^{tree}')
        complete = git(base_repository, 'rev-parse', '--is-shallow-repository').stdout.strip() == 'false'
    except subprocess.CalledProcessError:
        parser.error('base repository must resolve the exact official base; output was not created')
    if base_head != BASE or base_tree != BASE_TREE or not complete:
        parser.error('wrong base: require exact official HEAD/tree and complete history; output was not created')
    for input_root in canonical_input_roots(bundle, base_repository):
        if destination.is_relative_to(input_root):
            parser.error('output must be canonically outside payload/enclosing artifact and input base repository; output was not created')

    subprocess.run(['git', 'init', '--quiet', str(destination)], check=True)
    git(destination, 'config', '--local', 'core.autocrlf', 'false')
    # A scoped fetch avoids cloning unrelated local candidate refs or objects.
    git(destination, 'fetch', '--quiet', '--no-tags', str(base_repository), BASE)
    git(destination, 'checkout', '--quiet', '--detach', BASE)
    for proposal_commit in (PARENT, COMMIT):
        candidate_before = git(destination, 'cat-file', '-e', proposal_commit + '^{commit}', check=False)
        if candidate_before.returncode == 0:
            raise RuntimeError('A local proposal unexpectedly exists before the bundle fetch')
    verified = git(destination, 'bundle', 'verify', str(bundle))
    git(destination, 'fetch', '--quiet', '--no-tags', str(bundle),
        f'refs/heads/{BRANCH}:refs/heads/{BRANCH}')
    git(destination, 'checkout', '--quiet', BRANCH)
    for expression, expected in [('HEAD^{commit}', COMMIT), ('HEAD^', PARENT), ('HEAD^^', BASE), ('HEAD^{tree}', TREE)]:
        if identity(destination, expression) != expected:
            raise RuntimeError(f'Unexpected restored {expression}')
    git(destination, 'diff', '--check', BASE, COMMIT)
    git(destination, 'fsck', '--full', '--strict')
    if git(destination, 'status', '--porcelain').stdout:
        raise RuntimeError('Restored proposal is dirty')
    print(json.dumps({
        'base_head': base_head, 'base_tree': base_tree,
        'external_complete_base_history_required': True,
        'base_history_embedded_in_bundle': False,
        'bundle_sha256': BUNDLE_SHA256, 'prerequisites': prerequisites,
        'candidate_object_absent_before_bundle_fetch': True,
        'both_local_proposals_absent_before_bundle_fetch': True,
        'canonical_output_outside_inputs': True,
        'bundle_verify_exit_code': verified.returncode,
        'restored_commit': COMMIT, 'restored_parent': PARENT, 'restored_official_base': BASE, 'restored_tree': TREE,
        'diff_check_passed': True, 'git_fsck_full_strict_exit_code': 0,
        'working_tree_clean': True, 'network_fetch_performed': False,
    }, indent=2))


if __name__ == '__main__':
    main()
