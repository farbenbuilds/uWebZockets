# Pure readiness context predicate correction

Read-only narrow plan, 2026-11-17. Root's existing enum/API/READY contract remains unchanged. No producer, source, gate or artifact edits and no builds/tests were performed; only this report is written. Root can release the concrete five-path correction after this handoff. Do not broaden it into allocator/lifecycle or crypto refactoring.

## Exact fix and five-path scope

The frozen source is `.zig-cache/sql-tls-error-data-fixed-20261117/boringssl`. The readiness author works in a separate candidate; original producers/publication commits stay immutable.

1. include/openssl/ssl.h: retain the accepted query enum/declaration/docs; describe strict pure behavior. No new public crypto API.
2. ssl/ssl_lib.cc: retain readiness classification; use native s3->version so a fresh unknown-version client remains PENDING, not SSL_version's public legacy fallback. Replace digest factory calls with the exact pure size mapping below.
3. ssl/ssl_aead_ctx.cc: make existing SSLAEADContext::IsKeyUpdateContext use the exact pure method identity mapping below, preserving every existing cipher/nonce/flag test. Keep its declaration, layout and call sites unchanged. Keep key_update_aead used for actual InitForKeyUpdate initialization unchanged.
4. crypto/internal.h: declare exactly this non-exported BSSL-namespace internal predicate:

       bool aes_gcm_tls13_method_matches(const EVP_AEAD *method,
                                        size_t key_len);

5. crypto/fipsmodule/cipher/e_aes.cc.inc: define that predicate next to the existing two TLS13 AES method definitions, using their existing generated storage-address accessors:

       key_len == 16 -> method ==
         EVP_aead_aes_128_gcm_tls13_storage_bss_get()
       key_len == 32 -> method ==
         EVP_aead_aes_256_gcm_tls13_storage_bss_get()
       any other selector -> false

Null method returns false. These are pointer-identity comparisons only: no table read, factory, CRYPTO_once, initializer, mutex or ERR operation. Do not return an uninitialized method pointer, add OPENSSL_EXPORT, add a public header declaration, add new storage, or change the method initializer macro. key_len selects the known AES128/AES256 method identity; it is not a heuristic comparison against a method's key_len field.

No change to crypto/cipher/e_chacha20poly1305.cc is needed: its EVP_aead_chacha20_poly1305() at line400 is already a direct return of the address of an immutable static table, without DEFINE_DATA/CRYPTO_once. No ssl/internal.h, layout, generated-source-list or default-policy change is needed. Existing six opt-in function bodies remain unchanged.

## Why the current chain violates purity

ssl_aead_ctx.cc:40-55 key_update_aead calls ssl_cipher_get_evp_aead and then calls AES128/AES256/ChaCha factories for pointer filtering. IsKeyUpdateContext invokes it before even rejecting a null context. crypto/fipsmodule/delocate.h:57-68 DEFINE_DATA unconditionally calls CRYPTO_once; it is not limited to FIPS builds. The AES TLS13 factories at e_aes.cc.inc:1204/1218 use this macro. AES256 or ChaCha first use can initialize an unrelated AES method during readiness; even an already initialized method still routes through CRYPTO_once.

Default malloc counters alone cannot detect this contract violation. Neither hidden prewarming nor a statement that the selected digest/method “should already be warm” is acceptable.

## Exact IsKeyUpdateContext equivalence

Implement the pure expected-identity branch from the inspected ssl_cipher_get_evp_aead (ssl_cipher.cc:462-537), not key/nonce-length heuristics:

- Reject null ctx/cipher as false without calling any factory.
- Require SSL_CIPHER_get_min_version(cipher)==TLS1_3_VERSION. This getter is pure field logic at ssl_cipher.cc:1511-1522.
- Require cipher->algorithm_mac==SSL_AEAD.
- SSL_AES128GCM selects aes_gcm_tls13_method_matches(actual_method,16).
- SSL_AES256GCM selects aes_gcm_tls13_method_matches(actual_method,32).
- SSL_CHACHA20POLY1305 requires actual_method==EVP_aead_chacha20_poly1305(), the already-pure constant-address getter.
- Other encryption algorithms are false.
- After exact identity matches, require EVP_AEAD_nonce_length(actual_method)==12. The old helper derives TLS13 fixed-IV length from this method metadata; retaining this read preserves that invariant without initialization. The pointer check must precede dereferencing method metadata.
- Preserve unchanged ctx->cipher_==cipher, fixed_nonce_.size()==12, variable_nonce_len_==8, !variable_nonce_included_in_record_, !random_variable_nonce_, xor_fixed_nonce_, !omit_length_in_ad_, and ad_is_header_. Do not add new tag/key-length restrictions or remove a check.

This retains exact algorithm-method identity even for an inconsistent active context with the wrong same-sized method. It does not infer validity from successful construction, a cached boolean or method-size resemblance. No new cached expected pointer is needed. The existing initializing helper still initializes methods when actual cryptographic initialization requires them.

## Pure digest-size mapping

ssl_session_get_digest (ssl_session.cc:224-227) reaches ssl_get_handshake_digest (ssl_cipher.cc:539-554), which calls DEFINE_METHOD_FUNCTION EVP_sha* factories. Do not invoke that path in readiness, even for a completed handshake.

Use a private readiness-local metadata function or switch in ssl_lib.cc. Obtain protocol version from session->ssl_version through ssl_protocol_version_from_wire, a pure switch at ssl_versions.cc:30-54. Invalid metadata returns no size/UNSUPPORTED without asserting through an initializing getter. Then exactly mirror the existing mapping:

- SSL_HANDSHAKE_MAC_DEFAULT: protocol version >=TLS1_2_VERSION -> SHA256_DIGEST_LENGTH (32); earlier -> MD5_DIGEST_LENGTH + SHA_DIGEST_LENGTH (36).
- SSL_HANDSHAKE_MAC_SHA256 -> SHA256_DIGEST_LENGTH (32).
- SSL_HANDSHAKE_MAC_SHA384 -> SHA384_DIGEST_LENGTH (48).
- Unknown PRF -> no size/UNSUPPORTED.

Compare both traffic-secret lengths to this result, preserving the accepted readiness check. Do not merely assume AES256 means48 or all other methods mean32. Normal completed ordinary TLS1.3 sessions use32/48; the full mapping mirrors the actual existing helper without initializing a digest. Leave ssl_session_get_digest and generic digest behavior untouched.

## Remaining pure chain and boundaries

The inspected/reviewed leaves are metadata only: EVP_AEAD_CTX_aead, EVP_AEAD_nonce_length, EVP_AEAD_max_overhead, EVP_MD_size itself, IsKeyUpdateSpare, SSL_CIPHER_get_min_version, ssl_protocol_version_from_wire and version/init/mode/state field reads. No digest factory is needed once the size mapping is local.

tls_key_update_output_bound_valid (s3_both.cc:42-51) becomes pure transitively when IsKeyUpdateContext is pure. Its SSL_max_seal_overhead path (tls_record.cc:512-530) reads active MaxOverhead and flags. MaxOverhead/ExplicitNonceLen read method/nonce metadata and CRYPTO_fuzzer_mode_enabled; normal production is an inline false value, fuzz configuration reads its existing atomic flag. This is not an initializer or mutex. Preserve existing fuzz-output eligibility; do not alter a fuzz mode or claim a deferred campaign ran.

The AES storage accessors already exist for both method tables. DEFINE_BSS_GET uses a direct static BSS address in normal builds; in the FIPS/static branch it uses the existing prefixed BCM storage-address accessor. The new predicate stays inside the owning translation unit and uses these existing accessors, rather than exposing addresses or reaching into FIPS storage from SSL. No new BSS symbol/generated assembly or cryptographic method table is introduced.

Current production compilation is the existing non-FIPS native Zig graph; prove it there and retain target/source identities. Preserve existing namespace/prefix/visibility conventions for the internal C++ symbol. The helper is not a new installed public crypto API or a FIPS-validation claim. The source boundary must be reviewed with build/vendor for existing prefixed/static/shared configurations; do not change FIPS build configuration or add a build tool. No validated FIPS status follows from this proposal.

## Focused acceptance and delivery

- Fresh-process AES128, AES256 and ChaCha readiness rows: no CRYPTO_once invocation, initializer/mutex, method-table change, ERR warming/mutation, BIO callback or heap operation in the getter. Test each suite in an independent process; earlier suites must not warm later controls.
- Preserve the fresh-client native version0 PENDING RED->GREEN. No missing-session/cipher digest path runs before the initial-handshake PENDING decision.
- Independently test the AES pure predicate with null/unsupported selector, exact AES128/256 identities and wrong TLS12/generic/same-sized AEAD identities. It compares addresses without initializing unrelated tables. Test pure IsKeyUpdateContext with all existing nonce/flag/cipher mismatches; wrong method must remain false.
- Differential metadata predicate versus the old initialized guard on the same legal/mismatch context fixtures, and digest-size switch versus existing initialized digest helper for every PRF/version branch. Baseline factory calls belong outside the pure-query accounting interval.
- READY still implies all six actual calls succeed absent OOM, including retained-empty owners, all-three suites, installed spare/output/error pairs, repeated enable and active-discard dominance. Existing fragment/output/error/context-policy wire and purity controls remain mandatory.
- Use source call-chain review and a separate once/initialization observation in addition to unchanged malloc counters. Do not weaken or filter the original all-C allocator counter/self-test.
- No layout/size/source-list/default-policy changes; existing opt-in bodies unchanged. Rebuild the complete native candidate through Zig source lists, retain the exact five-path delta/inventory and obtain independent crypto/build boundary review. Native/wire acceptance remains required before SQL consumer release. Dedicated campaigns remain deferred and unclaimed.

Crypto author owns the five-path correction; crypto reviewer checks exact identity and helper purity; build/vendor reviews the internal symbol boundary and Zig artifacts; verification owns fresh-process once/ERR/BIO/heap observations plus existing readiness conformance. Root approves implementation/integration and appends reviewed commits without rewriting immutable publication history. Push only impl/implement-2.3.0.
