import hashlib
import json
from pathlib import Path
import subprocess
import sys

repo = Path(__file__).resolve().parents[2]
checks = Path(__file__).resolve().parent
stage = repo / '.zig-cache/sql-tls-readiness-evidence-20261117'
controls = repo / '.zig-cache/sql-tls-readiness-root-controls-20261117'
controls.mkdir(exist_ok=False)
(controls / 'combined_alias').symlink_to(stage, target_is_directory=True)
tool = stage / 'tools/wt-tools'
rows = []


def snapshot():
    result = {}
    for name in ('native', 'wire', 'purity', 'source_proposal'):
        for path in (stage / name).rglob('*'):
            if path.is_file():
                result[path.relative_to(stage).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


before = snapshot()
for name in ('native', 'wire', 'purity'):
    script = stage / name / 'replay_prebuilt.py'
    existing = controls / (name + '_existing')
    existing.mkdir()
    (existing / 'marker').write_text('preserve existing output\n')
    targets = {
        'existing': existing,
        'own_payload': stage / name / 'forbidden_output',
        'combined_sibling': stage / 'root_checks' / (name + '_forbidden'),
        'symlink_parent': controls / 'combined_alias' / name / 'forbidden_alias',
    }
    for case, destination in targets.items():
        command = [sys.executable, str(script)]
        if name == 'native':
            command.append(str(destination))
        else:
            command += ['--pki-tool', str(tool), '--output', str(destination)]
        result = subprocess.run(command, capture_output=True, text=True)
        assert result.returncode != 0, (name, case)
        if case == 'existing':
            assert list(existing.iterdir()) == [existing / 'marker']
            assert (existing / 'marker').read_text() == 'preserve existing output\n'
        else:
            assert not destination.exists()
        rows.append({'component': name, 'case': case, 'command': command,
                     'exit_code': result.returncode, 'stdout': result.stdout,
                     'stderr': result.stderr, 'output_unchanged_or_absent': True})

assert snapshot() == before
(checks / 'delivery_guard_results.json').write_text(json.dumps({
    'controls_passed': len(rows), 'component_payload_hashes_unchanged': len(before),
    'results': rows,
}, indent=2) + '\n')
print(json.dumps({'controls_passed': len(rows), 'payload_hashes_unchanged': len(before)}))
