# TLS client storage readiness source review

Source verdict: no remaining actionable finding for the accepted non-FIPS native static Zig target. The focused source/evidence review is complete; SQL consumer integration and final combined-delivery checks remain Root-owned.

Reviewed the readiness contract and Root-approved pure-context correction against immutable Phase B. Current patch SHA256 is `6772a629cc9e6e09c3e06dca857576bb03a1553185d54a0d52ce6f4e2a333b3b`. The initial two-file cut (`f7e8f312...`) and intermediate pure cut (`5b329d2f...`) are superseded. Only this requested report was written.

## Source findings addressed

The initial `SSL_version` call classified a fresh unnegotiated client as UNSUPPORTED because the public getter returns historical TLS1.2 for native version zero. The final getter reads `state->version`; unknown version reaches the initial-handshake PENDING branch, while actual negotiated non-TLS1.3 versions retain unsupported precedence.

The initial context predicate and digest lookup reached DEFINE_METHOD_FUNCTION/CRYPTO_once. The approved correction removes those paths from readiness. AES identity compares the supplied method pointer with the exact existing AES128/AES256 BSS storage addresses; it does not initialize, read or expose an uninitialized method table. ChaCha retains its existing immutable constant-address getter. IsKeyUpdateContext still checks the supported TLS1.3 cipher/MAC/encryption mapping, exact method identity, nonce_length 12, cipher association, fixed/variable nonce sizes and every original private flag. Identity is checked before method metadata is dereferenced. The initializing key_update_aead helper and InitForKeyUpdate factory are unchanged.

The readiness-local digest-size switch exactly mirrors the existing PRF/wire-version mapping: DEFAULT gives 32 at TLS1.2 or later and 36 earlier; SHA256 gives 32; SHA384 gives 48. Invalid wire version or unknown PRF gives unsupported without assertion, digest factory, ERR operation or initialization. Both secret lengths are checked against the result.

## Independent source and boundary verification

Applied the retained unified patch in memory against frozen Phase B and confirmed exact current source bytes. Independently hashed all 8,709 candidate entries: exact path sets, regular types and modes; only the five approved file contents differ. Generated sources/lists, layouts and unrelated files are unchanged. All six existing API bodies match their original bytes and retained guard hashes.

Current file SHA256 values:

- `include/openssl/ssl.h`: `7e9f8c3ae727725473d2b1ea2cda5eab1d3e58260b655eae274471c8b7e4e138`
- `ssl/ssl_lib.cc`: `08c6f95d7bd080812729868223e44ad439a97c2e9c6ca547b452da0a2a79951b`
- `ssl/ssl_aead_ctx.cc`: `1e2e7cab5370c4a55f255c3d3ed9fde74a70f312029058ae27ef2bf3dc36d8ba`
- `crypto/internal.h`: `82a83995418b7485a5cef44636870cc726026c0021a7adf3ba973ec0d923056c`
- `crypto/fipsmodule/cipher/e_aes.cc.inc`: `058199cb72531980b06a07c74b75a93cf38747ac051f560dcaf5ce1698911011`

The enum values remain explicitly 0/1/2. Guard precedence matches the contract: shutdown/mode/context policy, incomplete handshake, transient union including borrowed candidate, then established-session/key/output/error-owner invariants. Raw SERVER2 cache mode remains eligible; installed discard dominates later cache/callback changes. Retained-empty owners are accepted without invented pointer-null requirements. Documentation explicitly excludes certificate/name verification and external BIO/transport readiness. The change adds no owner/state storage or speculative layer; the private identity helper owns the exact BSS-address invariant at the existing crypto translation-unit boundary.

The private declaration and definition use BSSL_NAMESPACE conventions, preserving the optional inline prefix namespace. e_aes.cc.inc is already included by bcm.cc, so no source-list change is required. Normal DEFINE_BSS_GET returns existing static storage; the FIPS/static branch uses the existing prefixed BCM storage-address accessor. Neither path invokes method initialization. No public crypto header, OPENSSL_EXPORT entry, generated symbol map, new table or build-tool dependency is added.

Reviewed the completed native build record/log (6/6 steps, 38 SSL translation units) and independently matched all five source hashes and both actual archive hashes: libssl `621c98febb1606e01423b5045beb69a8d18d0e48831790745e0a275dda9335cd`; libcrypto `e130b330cef9b9349f4ef0e9dd381fe100dd42d287d72411adbd711ad76c551c`. The copied build/vendor and sanitizer graphs match production. The genuine missing-MD5-header failure was fixed with an explicit include and retained as lineage; no gate was weakened. No build was duplicated by this review.

Readelf confirms the identical private C++ helper name is defined once as GLOBAL HIDDEN in libcrypto and referenced by libssl. This is appropriate for the promised static graph. Separately linked shared libraries would need a visible internal boundary; shared/prefixed/FIPS configurations have not been built or claimed validated here. No FIPS validation status follows from this source change.

## Focused evidence review status

The three frozen base producer handoffs have now been independently reviewed. Native conformance/guards/predicates/fault/fresh-client records, fresh-process once/ERR/BIO/heap purity, authenticated prepared/unprepared/backpressure wire behavior, current manifests and portable replay records reconcile without a remaining observed-behavior finding. Exact scope and identities are in `/tmp/uwz-pg-tls-client-readiness-evidence-review-20261117.md`.

Root closed both explicit original-plan coverage gaps with a separate immutable-source runtime supplement. Independent source/raw/25-file payload review confirms genuinely negotiated verified TLS1.2 returns UNSUPPORTED0 and a public write-header callback during an actual borrowed KeyUpdate candidate returns PENDING1. Both getter intervals have zero original-counter operations and unchanged native/ERR bytes. Real requested-update/response processing and exact authenticated payloads each way reach READY after drain. The original three producers and native patch remain frozen. Detailed identities, observer meaning, portable replay closure and target limits are in the evidence review; no required runtime control was waived.

Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain deferred and unclaimed. Production pins, SQL adoption and the whole PostgreSQL allocation contract remain open. Root owns the subsequent SQL implementation/review and final staged delivery acceptance; this review does not close the complete PostgreSQL allocation contract.
