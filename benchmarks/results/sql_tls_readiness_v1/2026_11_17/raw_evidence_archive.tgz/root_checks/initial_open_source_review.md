# TLS client storage readiness source review

Status: open; two source findings require closure. Dynamic conformance/build and authenticated wire evidence remain pending. This report covers the initial frozen two-file addition against Phase B; it is not approval for consumer integration.

## Findings

1. **P2 — An unnegotiated ordinary client is incorrectly UNSUPPORTED.** In `.zig-cache/sql-tls-client-readiness-fixed-20261117/boringssl/ssl/ssl_lib.cc:771`, `SSL_version(ssl)` is used to reject known non-TLS1.3 versions before the initial-handshake PENDING branch. However, `ssl_versions.cc:246` deliberately reports TLS1_2_VERSION when native `s3->version` is zero. A fresh client configured for TLS1.3 therefore returns UNSUPPORTED before negotiation, contrary to the explicit unknown-version/initial-handshake contract. Read actual negotiated-version metadata for this rejection, preserving the specified unsupported-mode/policy precedence.

2. **P2 — The query can lazily initialize unrelated global AEAD method tables.** The calls at `ssl/ssl_lib.cc:797` reach `ssl_aead_ctx.cc:40` (`key_update_aead`). Its method-pointer filter calls the AES128 and AES256 TLS1.3 getters even for another selected cipher. These getters are `DEFINE_METHOD_FUNCTION` at `crypto/fipsmodule/cipher/e_aes.cc.inc:1204` and `:1218`; the actual macro in `crypto/fipsmodule/delocate.h:57` invokes `CRYPTO_once` and can initialize global method storage. Generic completed TLS context creation only obtains the selected AEAD (`ssl_aead_ctx.cc:125`), so a first unprepared AES256 or ChaCha query need not have warmed the unrelated method tables. This violates the accepted no-lazy-initialization/mutex-path contract, including failures; zero heap and ERR counters alone cannot demonstrate this property. The plan's assumption that this existing predicate is pure needs an explicit reviewed resolution preserving exact six-call eligibility. Root has assigned the architect to that decision.

## Completed source checks

The assigned initial freeze matches header SHA256 `6b5b45d7ebfaaa169f31840136a11f94acc35a880c0a34b0bc40a80604467ed7`, implementation SHA256 `ceaa2665b5fd641d9373f09a6e3fbeead5dd6ddc7407384ad93133ea9194b6b2`, and patch SHA256 `f7e8f3125e2de6cccf05584aa6206ae3e05ca4a39935a9af2ce69c33d27d026c`.

Independently compared all 8,709 actual baseline/candidate files: exact path sets, regular types and modes, with only `include/openssl/ssl.h` and `ssl/ssl_lib.cc` content changed. All six existing API bodies remain byte-identical and match their recorded guard hashes. The enum values are explicitly 0/1/2. Apart from the findings, the query covers the specified transient union, checks borrowed candidates before installed spare invariants, directly reads the established session after completion, accepts retained-empty owners, rejects one-sided error owners, accepts raw SERVER2 cache mode, and preserves active-discard precedence over later cache/callback changes. The public documentation excludes peer/name verification and external BIO/transport readiness.

The implementation adds no owner or state storage and does not relax an existing guard. Pure metadata leaves were inspected, rather than inferred from names. The existing digest method accessors also use DEFINE_METHOD_FUNCTION; a final purity design must account for the entire helper path, not only the AEAD filter.

## Pending closure

Await the corrected source freeze and approved purity seam, then re-review the minimal delta, source identities and unchanged six bodies. The author owns native build/direct conformance; the wire verifier owns actual fragmented/coalesced record and post-handshake progress, including unprepared and early-Finished cases. Cold-thread ERR absence, complete queue/mark/popped-string preservation, trap BIO/observer counts, armed allocation-failure controls, all-six success/idempotence across supported suites and partial subsets still require final evidence review. No build, runtime test or dedicated campaign was duplicated by this read-only review. Only this requested report was written.
