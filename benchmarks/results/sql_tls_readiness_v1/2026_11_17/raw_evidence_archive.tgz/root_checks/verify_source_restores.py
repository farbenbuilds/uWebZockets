import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess
import sys

repo = Path(__file__).resolve().parents[2]
checks = Path(__file__).resolve().parent
producer = repo / '.zig-cache/sql-tls-client-readiness-fixed-20261117'
original = Path('/tmp/uwz-wt-child-callbacks-20261116/zig-pkg/N-V-__8AAA5Ieg5843crc8uXWdNhmmfStwJqA-9TknJSx3_n')
previous = repo / '.zig-cache/sql-tls-error-data-fixed-20261117/boringssl'
inventory = json.loads((producer / 'candidate_source_inventory.json').read_text())['entries']
rows = []


def run(name, kind, source, destination, expected):
    command = [sys.executable, str(producer / 'restore_source.py'),
               '--source-kind', kind, str(source), str(destination)]
    result = subprocess.run(command, capture_output=True, text=True)
    (checks / (name + '.stdout')).write_text(result.stdout)
    (checks / (name + '.stderr')).write_text(result.stderr)
    assert (result.returncode == 0) == expected, (name, result.returncode)
    if not expected:
        assert not destination.exists()
    row = {'name': name, 'command': command, 'exit_code': result.returncode,
           'output_created': destination.exists(), 'expected_success': expected}
    rows.append(row)
    return row


def verify(source):
    actual = {p.relative_to(source).as_posix() for p in source.rglob('*')
              if p.is_file() or p.is_symlink()}
    assert actual == {row['path'] for row in inventory}
    for row in inventory:
        path = source / row['path']
        assert row['kind'] == 'file' and stat.S_ISREG(path.lstat().st_mode)
        assert stat.S_IMODE(path.stat().st_mode) == row['mode']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
    return len(actual)


for kind, source in [('baseline', original), ('error-data', previous)]:
    destination = repo / ('.zig-cache/sql-tls-readiness-restored-' + kind + '-20261117')
    row = run('restore_' + kind, kind, source, destination, True)
    row['verified_candidate_entries'] = verify(destination)

existing = repo / '.zig-cache/sql-tls-readiness-restored-baseline-20261117'
before = verify(existing)
command = [sys.executable, str(producer / 'restore_source.py'), str(original), str(existing)]
result = subprocess.run(command, capture_output=True, text=True)
assert result.returncode != 0 and verify(existing) == before
rows.append({'name': 'existing_destination', 'command': command,
             'exit_code': result.returncode, 'existing_entries_unchanged': before,
             'stdout': result.stdout, 'stderr': result.stderr})

run('wrong_source_kind', 'error-data', original,
    repo / '.zig-cache/sql-tls-readiness-wrong-kind-out-20261117', False)
bad = repo / '.zig-cache/sql-tls-readiness-bad-input-20261117'
shutil.copytree(previous, bad)
path = bad / 'ssl/ssl_lib.cc'
mode = stat.S_IMODE(path.stat().st_mode)
path.chmod(mode ^ stat.S_IXUSR)
run('wrong_file_mode', 'error-data', bad,
    repo / '.zig-cache/sql-tls-readiness-wrong-mode-out-20261117', False)
path.chmod(mode)
path.write_bytes(path.read_bytes() + b'\n')
run('wrong_file_hash', 'error-data', bad,
    repo / '.zig-cache/sql-tls-readiness-wrong-hash-out-20261117', False)
(checks / 'source_restore_results.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps({'successful_restores': 2, 'entries_per_restore': len(inventory),
                  'refusal_controls': 4, 'all_expected_outcomes': True}))
