# TLS client readiness focused evidence review

No actionable findings remain in the accepted native readiness source and focused evidence. The separately frozen runtime supplement closes the genuinely negotiated TLS1.2 negative and live borrowed-candidate callback coverage gaps. Final combined-delivery checks and SQL consumer integration remain Root-owned.

This review is read-only and concerns the accepted non-FIPS native static target. It does not approve SQL consumer integration, production pins, publication or the whole PostgreSQL allocation contract. No native build or runtime matrix was duplicated; retained source, binary identities, logs, raw data and read-only reconciliation checks were independently inspected.

## Native conformance

Verified final 205-name whitelist and 204 hashes, five selected ELF identities and all source/result/command bindings. Current HANDOFF SHA256 is `634103e19124853dfbfd34204ad9b6974d3daba489c063a648d8a20ded1fc888`; manifest is `aac03b65e620a4726e1fc844a31a805543b84fd570e08b9969e30040e711aa73`; executable identity is `295c9ef4c9ad0994a0da251ae5601fa8c56f018b7a5d031f48aabe3c49750b51`.

The five programs retain 1,091 JSON evidence rows: 935 conformance, 63 direct-unit guards, 78 method/digest comparisons, 14 separate fault/OOM rows and one genuine fresh-client row. These are not 1,091 getter calls. The 64 legal partial subsets run on 0x1301; separate 0x1301/0x1302/0x1303 cases check the actual six-call bundle and repeat. Each conformance step requires actual return1, READY between calls and zero original-counter getter operations. Complete SSL/S3 and active-context representations remain unchanged across the getter and are cleansed afterward.

The guard fixtures explicitly identify private metadata construction. They cover precedence, retained-empty owners, SERVER2/OFF versus CLIENT/callback policy, active discard dominance, missing/mismatched context/session/secret/output/error owners and the transient union. They are not presented as authentic wire construction. Predicate tests preserve initialized-old versus pure truth across all three suites and private nonce/flag/method/cipher mismatches. The exact production digest helper is extracted and hash-bound; its 21 PRF/wire combinations match the initializing helper outside the measured interval. Invalid metadata is rejected. Fault rows use the separately identified observer, preserving the original all-C counter for normal zero evidence; READY does not promise allocation success.

The fresh-client RED-to-GREEN preserves native version0/public fallback771, changes the result from0 to PENDING1, and records zero getter allocation. Superseded compile/fixture mistakes are retained and separated from selected successes. The handoff's overly broad unchanged-native-input wording was corrected; generated files, source lists, build templates/flags and private layouts are unchanged, while the five approved native contents differ.

The portable replay has five program invocations/six commands, 1,091 rows, exact retained stdout and PKI removal. Its manifest binding intentionally remains the pre-documentation-correction `7ddee772...`; the final executable identity, measured inputs/results and all non-HANDOFF payload entries remain unchanged. Independently validated the final corrected manifest. Nine real-script guards preserve fixture paths/types/content and refuse existing, own/combined/symlink-parent outputs, plus restore-inside-input. Root's two 8,709-entry restores and four additional refusals remain separate recorded controls.

## Getter purity

Verified 255 selected names/254 hashes, four current ELF identities and unchanged historical maps. Manifest SHA256 is `8c0c63a5451edff736fefe184d1ed8b6ef8090d437a9c262e342985c1b5fd9f2`; current identity is `2239319c119edf3b1b4d400ea82fd5f00ff1ade2c9e4a26206483a1ea1e6e627`.

The final image has 12 independent process runs, 360 getter calls and 72 cold worker cases across three actual suites and two separately built fixture variants/selectors. Every getter has original malloc/calloc/realloc/non-null-free/requested-byte counts0. The derivative also records pthread_once0. Every first ERR operation after the cold worker's getter observes two mallocs/984 bytes; the second is zero. No ERR operation precedes that getter on the worker. Queue tests preserve all synthetic reason/file/line/data/flags, FIFO, marks and both inline/long popped pointers; calibrated BIO and message/info/session observers and SSL/S3 bytes remain unchanged. Snapshots are cleansed and no SSL/key/session bytes or hashes are logged.

The version-fixed but once-defective interim image remains a genuine negative control: unchanged functional/heap/ERR records, with READY once entries7/10/7 and strict process totals35/50/35 for the three suites. Its strict selectors exit1 only after functional checks complete. The normal allocator-only variant does not instrument once; zero once is not inferred from that variant.

Reviewed the GNU-wrap failures as tool-limit history. The selected derivative forwards unchanged arguments/return values to real `__pthread_once@GLIBC_2.2.5`, without dlsym or method filtering. Independently checked actual libc alias addresses, executable public-definition/versioned-import symbols and the exact BoringSSL pthread source. Both public and BoringSSL calibrations observe two entries/one initializer. The observer counts warm entries too, so prewarming cannot conceal the original defect. Read-only complete-result reconciliation passes all 720 observations, 144 cold controls and 1,584 full synthetic metadata observations across both images.

The four-binary source-free replay retains 24 invocations/720 getters/26 commands with exact raw bytes and expected statuses; PKI is removed. Six output/helper refusals pass. Its combined-root protection uses the ancestor `restore_pki_tool.py` marker; the final combined delivery must retain that bootstrap script. Native/wire wrappers use enclosing files.sha256 markers.

## Authenticated wire behavior

Verified 88 selected names/87 hashes, two current ELF identities and unchanged historical maps. Manifest SHA256 is `9dc33375890140b2cbbe80a7add6e53d1b459e2d4ed7e20e4910c378a6d3766a`; current identity is `2d4d26d5be9bf55a40f39ffbb37e3eadf28260ca2a8faacc6ddead6a682d44d5`.

The bounded final wire proof uses actual 0x1301 CA/localhost-verified TLS/BIO pairs: three rows, 556 client I/O calls and 25 getter intervals. Every getter has all five original count fields0 and preserves seeded ERR/observer state. Independently recomputed the complete IO/event/state verifier. The prepared row's first 29 operation/event records exactly match the immutable discovery baseline. Legacy rejecting probes are removed from the final consumer source; opt-ins occur only in the successful bundle.

The unprepared early-Finished case asserts server Finished sent/client Finished unsent before sealing the real three-byte peer prefix. Inspected native server key installation: the application write key exists at server Finished and client Finished changes only the read side, so no sequence/key reset is fabricated. Prefix and suffix use the old peer key, with rotation only after completion. At actual client handshake return, native READY may coexist with 25 inbound and 64 outbound external bytes. Consuming the prefix yields PENDING with all public pending/BIO values zero. The first bundle waits for real completion/response/drain. Its pre-reservation controls honestly retain 12 malloc/12 free/1,561 bytes; first bundles retain 11 malloc/291,926 bytes.

The BIO17 row preserves a negative WANT_WRITE zero-length flush, reads a second valid control between identical null/zero retries, drains the 17-byte response prefix and 10-byte tail, and observes exactly one NOT_REQUESTED response. Return0 is correctly treated as documented zero-length success without SSL_get_error. Authenticated exact 4,096-byte payloads each way prove resulting key/sequence ordering. Only the server peer is sealed/rotated privately; client crypto/parser/session state is not staged. Native READY with external output is explicit and never substitutes for transport drain.

The two-binary portable replay retains all 585 I/O calls plus 25 getter samples byte-for-byte; eight canonical output/helper refusals pass. Selected payloads exclude native archives, objects, caches, PKI and preliminary executables.

## Two-control runtime supplement

Independently reviewed the separate 25-file/24-hash payload and one current ELF, without changing or rerunning the three base producers. Manifest SHA256 is `1c6ff53409ba122b93a15725583e491ff81d7370362cc8a9107f4d679d05bc93`; executable identity is `b58ba8f7edf1a480060f81117f68adf0215573dc4815b2dc98efb22e12edacf2`; selected binary is `d3277a1b0e2bcea5953a3e35e96feb9b5b7a6da2e306e885a8f74d7edb9221c0`. Source, measured raw records, compiler, unchanged pair/counter, final native archives and pinned private-layout hashes all reconcile.

The first row genuinely negotiates and verifies TLS1.2 on test-only contexts: both versions are771 and the getter returns UNSUPPORTED0 with all five original allocation fields zero and complete native/ERR state unchanged. Production TLS1.3 policy is untouched.

The second row observes the public client's write-header callback while actual protocol execution has a nonnull borrowed KeyUpdate candidate, absent spare and temporarily moved plaintext owner. It invokes the getter once and obtains PENDING1. Source order matches tls13_set_traffic_key -> tls_set_write_state -> pending-handshake flush -> record-header callback, before candidate commit. No client keys, sequence, parser or owner state is staged. Only the getter is inside the original allocator interval; ERR-slot lookup and SSL/S3/current/candidate/944-byte ERR snapshots are outside it. The extent is bound to unchanged pinned err.cc and same-target static layout assertions. All comparisons pass and copies are cleansed without logging secret bytes/hashes.

A real peer REQUESTED update, exactly one NOT_REQUESTED response and exact authenticated 4,096-byte payloads each way prove protocol completion; the candidate clears and READY returns after both BIO inputs drain. No outer I/O zero claim is made. The source-free replay records one program invocation/two commands/two rows, exact retained stdout and removed PKI. Both original runtime coverage gaps are closed; no required matrix was waived or weakened.

## Default SDK compatibility and boundaries

Independently checked Root's actual 407 expected native compiler commands/38 SSL units, one corrected source/header root, five source hashes, translated enum/API, actual SDK archive hashes and raw 23/23-step summary: 1,158/1,182 tests passed, 24 live PostgreSQL tests skipped. This is default SDK compatibility, not implemented SQL preparation or PostgreSQL allocation evidence.

All current focused programs bind final source patch `6772a629...` and matching archives `621c98fe...`/`e130b330...`; Phase B and interim once-defective images remain separately identified. Shared/prefixed/FIPS/non-glibc/cross-platform configurations and dedicated campaigns are not claimed. Root owns final staged stripping/replays/archive checks, publication, consumer integration and broader lifecycle/platform/release work.
