# Pure TLS client storage readiness prerequisite

Read-only architect contract, 2026-11-17. Root accepts the source-level unsupported-seam proof in `/tmp/uwz-pg-sql-reservation-adoption-plan-20261117.md` and has released the native query author under that accepted proof and this exact contract. The focused authenticated TLS/BIO witness runs independently and remains required, together with native review/conformance, before consumer integration release. No native/repository/build/evidence edits or tests were performed by the architect; only this requested temporary report was written.

Baseline: immutable `.zig-cache/sql-tls-error-data-fixed-20261117/boringssl`, 15 cumulative paths/8709 source entries, originally BoringSSL d3bf4795ad5b79d646cddf2fec687da5b9b502db plus reviewed proposals. Publication's local cumulative commit33406dd2383eff3e84059a763933b010cc5a663d remains immutable; a later query commit appends. No normal-only consumer release or reservation-guard probing is allowed. No allocator/lifecycle redesign belongs here.

## Exact public API

Add only to native include/openssl/ssl.h and ssl/ssl_lib.cc:

    enum ssl_client_storage_readiness_t {
      ssl_client_storage_unsupported = 0,
      ssl_client_storage_pending = 1,
      ssl_client_storage_ready = 2,
    };

    OPENSSL_EXPORT enum ssl_client_storage_readiness_t
    SSL_get_client_storage_readiness(const SSL *ssl);

These three numeric values are explicit and stable. The consumer compares the enum values explicitly; it must not treat nonzero as ready. No output parameters, allocation, owner handle, new context option or callback is added. Place the documentation/declaration next to the six existing client storage/policy APIs.

READY means every nonallocation eligibility/invariant check of the six listed native APIs is satisfied on the same serial state. It does not enable any option, verify certificates, initialize ERR, promise successful allocation, or establish external transport/BIO readiness. The caller must still verify the peer/name, drain/check its paired BIO/ciphertext/socket writes, and apply the options before another mutating SSL operation.

PENDING means TLS state must progress before the native guard union is eligible. It is not a fatal error, an indication to spin, or a promise that an operation can progress without external input/output. UNSUPPORTED means mode/error/policy/invariant conditions currently prevent this preparation; the query does not append diagnostic errors. Neither status changes TLS behavior.

## Pure query boundary

The function only reads SSL/native metadata. Existing constant/pure helpers may be used: mode/version/init getters, SSLAEADContext::IsKeyUpdateContext/IsKeyUpdateSpare, established-session cipher/digest metadata, and tls_key_update_output_bound_valid. Inspect actual helper bodies; do not invoke a helper merely because its name appears read-only.

It must not call any ERR function (including peek or clear), allocation/deallocation, thread-local initialization, BIO_ctrl/BIO callback, observer, certificate verification, SSL IO, clock or random function. No cache lookup, mutex, lazy initialization or owner mutation is added. In particular it must not warm a cold serial destination thread's ERR state. The native query cannot know whether an arbitrary external BIO has output waiting; this remains a caller-owned check rather than a callback hidden inside a “pure” getter.

The installed state has no new memory cost. Keep all six existing opt-in bodies unchanged if feasible. A focused union query may duplicate their guards deliberately; do not broadly refactor functioning opt-ins merely to add it. The conformance tests below prove that the query remains aligned with those actual functions.

## Classification precedence and exact guard union

Apply the following order to avoid interpreting transient KeyUpdate installation as owner corruption:

1. UNSUPPORTED immediately for null SSL, missing S3, server, DTLS or QUIC, or read/write shutdown other than ssl_shutdown_none. A known negotiated version other than TLS1.3 is UNSUPPORTED. Do not dereference missing state or invoke an error-reporting path.
2. The effective session context must exist. Unless client_session_ticket discard is already active, a context with SSL_SESS_CACHE_CLIENT or a non-null new_session_cb is UNSUPPORTED. When discard is active, later cache/callback changes are ignored for readiness, matching the existing one-way policy. Do not require exact cache mode OFF: raw SERVER2 without the client bit is eligible.
3. An otherwise ordinary client with initial handshake incomplete or SSL_in_init true is PENDING. Unknown version before negotiation is not alone an unsupported mode; after a negotiated non-TLS1.3 version it is UNSUPPORTED as above. No session/AEAD digest assertions are reached before completion.
4. Any of the transient fields below is PENDING, before inspecting spare/current AEAD owner invariants that may be temporarily changing. Shutdown/error and stable context-policy rejection retain their precedence above.
5. Once transient state is empty, validate the completed session/cipher/AEAD and installed-owner invariants below. Failure is UNSUPPORTED, never READY. Otherwise return READY.

Transient PENDING union (direct native fields):

- pending_app_data or pending_write nonempty;
- unreported_bytes_written nonzero;
- read_buffer or write_buffer nonempty;
- has_message, alert_dispatch or key_update_pending true;
- key_update_candidate non-null;
- hs_buf exists and its length is nonzero;
- pending_hs_data exists and its length is nonzero;
- pending_flight exists and its length is nonzero;
- pending_flight_offset nonzero.

A non-null retained buffer/owner with zero logical length is not itself PENDING. Allocated empty handshake/output/record storage must remain READY when its other invariants hold. Partial record/header/ciphertext is reported when held in native read_buffer; partial post-handshake message/header is reported by hs_buf even when SSL_has_pending is false. Complete but unconsumed/coalesced handshake data is also PENDING. Data remaining only in the external memory BIO is intentionally outside this pure native query and is checked by the consumer.

Completed-session and key/output invariants:

- Read the established_session field after completion and reject a missing session/cipher; do not use a getter path which asserts an initial-handshake object exists when an inconsistent completed session lacks one.
- Both active aead_read_ctx and aead_write_ctx satisfy SSLAEADContext::IsKeyUpdateContext with the established session cipher. Both traffic secret lengths equal the established digest size. Supported contexts are the same AES128-GCM, AES256-GCM and ChaCha20-Poly1305 TLS1.3 contexts as the existing opt-in.
- tls_key_update_output_bound_valid holds: ordinary TLS1.3 client, max_send_fragment in512..16384, compatible write context, and exact seal overhead kKeyUpdateCiphertextLength-kKeyUpdatePlaintextLength (27-5=22).
- If key_update_cipher is installed, it equals session->cipher and key_update_spare satisfies IsKeyUpdateSpare. If key_update_cipher is null, key_update_spare must also be null. A temporarily borrowed candidate was already classified PENDING, before this check.
- If key_update_output_cipher is installed, it equals session->cipher; pending_hs_data exists, has non-null data and max>=5; pending_flight exists, has non-null data and max>=27. Their logical lengths and flight offset are already zero. If output mode is not installed, empty preexisting descriptors do not alone make readiness false; the actual opt-in replaces them on success.
- Reserved read/alert error owners are both absent or both present. A one-sided pair is UNSUPPORTED. Do not inspect or borrow opaque ERR snapshot data.
- Existing incoming-handshake and record opt-ins may already be installed. Accept their retained-empty states as their existing functions do; do not invent a new requirement that their pointers be null or require a fresh SSL.

This is the union of SSL_reserve_record_buffers, SSL_reserve_client_post_handshake_buffer, SSL_reserve_key_update_context, SSL_reserve_key_update_output_buffers, SSL_reserve_error_state, and SSL_discard_client_session_tickets, located at exact candidate ssl/ssl_lib.cc:759,779,823,886,949,997. Existing pure key-context helpers are ssl/ssl_aead_ctx.cc:58-79; output-bound helper is ssl/s3_both.cc:42-51. The native SSL_has_pending limitation is ssl/ssl_lib.cc:1907-1912. No opt-in guard is relaxed.

## READY conformance postcondition

With no intervening mutation of SSL, its effective context or relevant configuration, and absent startup allocation failure, READY must imply that all six actual calls return1 in this order:

record buffers -> incoming post-handshake buffer -> KeyUpdate context -> KeyUpdate output -> error snapshots -> validated ticket discard.

The query itself remains READY between successful calls and after the whole bundle when all lengths are empty. Repeating the enabled bundle succeeds idempotently. Allocation failure can still make a call return0; it does not contradict READY. The existing record partial-reservation failure/free requirement and other failure ownership remain unchanged. Conversely, PENDING/UNSUPPORTED tests must not invoke a rejecting opt-in merely as a consumer readiness probe; dedicated conformance tests may compare the native functions on labeled independent control instances.

## Focused RED and conformance matrix

Wire verification is preparing an authenticated TLS/BIO reproduction without private client-state staging. Preserve exact baseline source/library identities, original counter/self-test and source-derived public observations. The architect's source proof is already accepted, but no runtime witness is claimed by this report.

Required rows before/after implementation:

- Idle completed verified client for each supported suite: READY, then six real calls succeed, query unchanged and no query allocations. Repeat with all owners retained-empty and with each legal partial subset installed.
- Initial handshake on a normal client: PENDING, then successful verified completion reaches READY. Server/DTLS/QUIC, negotiated TLS1.2 negative fixture, null, error and shutdown states: UNSUPPORTED with zero query side effects. Do not enable TLS1.2 in production.
- Real partial encrypted record/header in native read_buffer: PENDING. Partial authenticated post-handshake header/message in hs_buf, despite SSL_pending=0/SSL_has_pending=0/WANT_READ: PENDING. Deliver the remaining valid fragments, process them through real SSL IO and reach READY after output is flushed. Test complete/coalesced controls before consumption and multiple controls, with no fabricated client sequence/key/session state.
- Requested KeyUpdate, pending handshake plaintext/flight, BIO-backpressured ciphertext, write retries/unreported bytes and a borrowed candidate observed through an allowed read-only callback: PENDING while native transient state exists. Use actual IO for reachable states. Label internal invariant unit fixtures separately where public construction is impossible; they do not replace the real wire proof.
- External BIO output only, with all native guards empty: native READY is permitted, BIO callback is not invoked by the query, and the consumer must still flush before enabling. Similarly, raw input queued only in the external BIO is not silently classified by a native field-only query. This distinction must be explicit in docs/tests.
- Context cache CLIENT/new-session callback enabled before discard: UNSUPPORTED. Raw mode SERVER2 or OFF with no callback: eligible. Enable discard, then mutate context cache/callback: READY remains possible, preserving its accepted dominant policy. No callback is invoked by the getter.
- Valid installed AEAD spare/output capacities/error pair and non-null empty hs/output buffers: READY. Invalid cipher association, spare state, output capacity or one-sided error owner: UNSUPPORTED in focused read-only invariant tests. No new validation of impossible arbitrary memory corruption is promised.
- Cold serial destination thread: query null/unsupported and an already-established client without any ERR calls on that thread, with counters covering only query. Require zero malloc/calloc/realloc/non-null-free, no ERR TLS object creation and no queue warming. Confirm by a read-only TLS-state check or by independently measured subsequent first ERR use; do not initialize the queue to test its prior absence. SSL ownership handoff remains serial.
- Existing populated ERR queue: complete reason/file/line/data/flags, marks, FIFO and a popped-data pointer survive every getter call unchanged. Querying invalid SSL must not append an error. Peer strings remain independent of SSL lifetime, as established previously.
- Attach a counted/trap BIO control implementation in a safe fixture and verify the getter performs no BIO callback, IO or observer. Query repeatedly across statuses; retain strict counters and exact before/after state observations.
- Allocation-failure control: READY queried with an armed failure injector stays nonallocating; subsequent real reservation can fail and follows its unchanged cleanup contract. No failure is relabeled as PENDING.

## Event-order contract for the later SQL preparation

The query is necessary but does not itself drive IO. After verified SSL_do_handshake returns1, SQL enters `.tls_preparing` before StartupMessage or CancelRequest. Existing absolute startup/cancel deadlines remain armed. No main pool admission occurs until later PostgreSQL authentication and ReadyForQuery; no pool-wide pause is introduced.

First drain existing ciphertext and network-BIO output through the normal short-write/completion path. Process already-buffered controls; immediately classify negative SSL_read/SSL_write results before another SSL/ERR operation. WANT_READ waits for input only when progress requires it; WANT_WRITE drains output then retries. A native PENDING status never converts a valid partial control into failure and never spins without progress. Complete/coalesced controls can require both directions even before PostgreSQL application bytes are allowed.

A requested KeyUpdate may leave a response pending while SSL_read returns WANT_READ. The existing public header ssl.h:410-414 explicitly documents SSL_write(ssl,buf,0) as flushing pending control messages and returning0 on success. Use that documented zero-length control flush when needed, emit no PostgreSQL bytes, and treat0 as SUCCESS for this operation. Do not pass it through the ordinary tls_retry(0) failure path. Negative returns receive immediate SSL_get_error classification. Exact s3_pkt.cc:145-245 flushes pending_hs_data/flight and uncorks key_update_pending without requiring nonempty application data. Drain resulting BIO/ciphertext output and requery; this prevents a pre-Startup response/readiness deadlock.

Application plaintext before Startup/Cancel is unsolicited PostgreSQL data and fails closed; never discard it to attain READY. When native status is READY and all current caller/BIO input/output, active writes and ciphertext are drained, invoke all six synchronously, check every result, then queue Startup/Cancel exactly once. Future socket input arriving after that serial decision is handled under the enabled native paths. Each fresh main/cancel handshake repeats preparation. Failure or deadline uses existing cancel/drain/TlsFailed behavior; no deadline extension, cache override or partial admission is added.

Official protocol references: [TLS1.3 post-handshake messages](https://www.rfc-editor.org/rfc/rfc8446.html#section-4.6), [record fragmentation and key boundaries](https://www.rfc-editor.org/rfc/rfc8446.html#section-5.1). KeyUpdate can follow the server's Finished before the client finishes; NewSessionTicket follows receipt of client Finished. Test fragment construction obeys record/key-boundary rules. The pinned local ssl.h documents zero-length control flushing; no new flush API or generic SSL_write semantics change is proposed.

## Ownership and release

Crypto author owns only the new declaration/docs in include/openssl/ssl.h and pure implementation in ssl/ssl_lib.cc, in a new exact-copy candidate. Existing six function bodies stay untouched unless a concrete reviewed contradiction is demonstrated. Wire verifier owns the real authenticated reproduction and transitions; direct verifier owns cold-thread, ERR/BIO purity and READY-to-actual-call conformance. Independent reviewer checks guard union, classification precedence, pure helpers, idempotence and evidence. Build/vendor owns exact Zig-only build/source inventory. Root separately authorizes implementation, accepts evidence, appends the publication commit and later releases consumer integration.

Acceptance is the exact enum/API plus all-six eligibility postcondition, correct pending-fragment/output handling, zero query allocation/ERR/BIO effects including a cold serial thread, unchanged existing API bodies/default behavior, and independently reviewed focused evidence. Dedicated campaigns remain deferred and unclaimed. No consumer integration is released until fragment-compatible readiness and output progress are proven. Root commits/pushes only origin/impl/implement-2.3.0.
