#include "ticket_pair.h"

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

// Read-only observation of the exact pinned err.cc layout; never installs state.
struct ErrorEntryLayout {
  const char *file;
  char *data;
  uint32_t packed;
  uint16_t line;
  unsigned mark : 1;
  char inline_data[32];
};
struct ErrorStateLayout {
  ErrorEntryLayout errors[ERR_NUM_ERRORS];
  unsigned top;
  unsigned bottom;
  char *to_free;
  char popped_inline_data[32];
};
static_assert(sizeof(ErrorEntryLayout)==56 && sizeof(ErrorStateLayout)==944,
              "pinned native error layout");

struct Observation {
  unsigned borrowed_headers;
  unsigned client_received_requested;
  unsigned client_sent_response;
  unsigned server_received_response;
  int callback_status;
  bool callback_native_unchanged;
  bool callback_err_unchanged;
};

static int observe_query(SSL *ssl, int expected, bool *native_unchanged,
                         bool *err_unchanged) {
  const auto *impl=bssl::FromOpaque(ssl);
  const auto *s=impl->s3;
  const void *err=bssl::CRYPTO_get_thread_local(bssl::OPENSSL_THREAD_LOCAL_ERR);
  CHECK(s && s->aead_read_ctx && s->aead_write_ctx && err);
  uint8_t ssl_before[sizeof(bssl::SSLImpl)];
  uint8_t s3_before[sizeof(bssl::SSL3_STATE)];
  uint8_t read_before[sizeof(bssl::SSLAEADContext)];
  uint8_t write_before[sizeof(bssl::SSLAEADContext)];
  uint8_t candidate_before[sizeof(bssl::SSLAEADContext)]={};
  uint8_t err_before[sizeof(ErrorStateLayout)];
  memcpy(ssl_before,impl,sizeof(ssl_before));
  memcpy(s3_before,s,sizeof(s3_before));
  memcpy(read_before,s->aead_read_ctx.get(),sizeof(read_before));
  memcpy(write_before,s->aead_write_ctx.get(),sizeof(write_before));
  if(s->key_update_candidate)memcpy(candidate_before,s->key_update_candidate,sizeof(candidate_before));
  memcpy(err_before,err,sizeof(err_before));
  // No outer I/O allocation scope is active. Only this getter is measured.
  uwz_alloc_begin();
  const int status=SSL_get_client_storage_readiness(ssl);
  uwz_alloc_end();
  const uint64_t mallocs=uwz_alloc_malloc_calls(),callocs=uwz_alloc_calloc_calls();
  const uint64_t reallocs=uwz_alloc_realloc_calls(),frees=uwz_alloc_free_calls();
  const uint64_t bytes=uwz_alloc_requested_bytes();
  *native_unchanged=memcmp(ssl_before,impl,sizeof(ssl_before))==0 &&
      memcmp(s3_before,s,sizeof(s3_before))==0 &&
      memcmp(read_before,s->aead_read_ctx.get(),sizeof(read_before))==0 &&
      memcmp(write_before,s->aead_write_ctx.get(),sizeof(write_before))==0 &&
      (!s->key_update_candidate || memcmp(candidate_before,s->key_update_candidate,sizeof(candidate_before))==0);
  *err_unchanged=err==bssl::CRYPTO_get_thread_local(bssl::OPENSSL_THREAD_LOCAL_ERR) && memcmp(err_before,err,sizeof(err_before))==0;
  OPENSSL_cleanse(ssl_before,sizeof(ssl_before));
  OPENSSL_cleanse(s3_before,sizeof(s3_before));
  OPENSSL_cleanse(read_before,sizeof(read_before));
  OPENSSL_cleanse(write_before,sizeof(write_before));
  OPENSSL_cleanse(candidate_before,sizeof(candidate_before));
  OPENSSL_cleanse(err_before,sizeof(err_before));
  CHECK(status==expected && mallocs==0 && callocs==0 && reallocs==0 && frees==0 && bytes==0);
  CHECK(*native_unchanged && *err_unchanged);
  return status;
}

static void message(int write_p,int version,int type,const void *buffer,size_t length,
                    SSL *ssl,void *argument) {
  auto *observation=static_cast<Observation *>(argument);
  const auto *s=bssl::FromOpaque(ssl)->s3;
  if(type==SSL3_RT_HANDSHAKE && length==5 && version==TLS1_3_VERSION) {
    const auto *bytes=static_cast<const uint8_t *>(buffer);
    if(bytes[0]==SSL3_MT_KEY_UPDATE) {
      CHECK(bytes[1]==0 && bytes[2]==0 && bytes[3]==1);
      if(!SSL_is_server(ssl) && !write_p) {CHECK(bytes[4]==SSL_KEY_UPDATE_REQUESTED);observation->client_received_requested++;}
      if(!SSL_is_server(ssl) && write_p) {CHECK(bytes[4]==SSL_KEY_UPDATE_NOT_REQUESTED);observation->client_sent_response++;}
      if(SSL_is_server(ssl) && !write_p) {CHECK(bytes[4]==SSL_KEY_UPDATE_NOT_REQUESTED);observation->server_received_response++;}
    }
  }
  if(SSL_is_server(ssl) || !write_p || type!=SSL3_RT_HEADER || !s->key_update_candidate)return;
  CHECK(version==0 && length==SSL3_RT_HEADER_LENGTH && s->key_update_spare==nullptr);
  CHECK(s->pending_hs_data==nullptr && s->key_update_cipher!=nullptr);
  observation->borrowed_headers++;
  CHECK(observation->borrowed_headers==1);
  observation->callback_status=observe_query(ssl,ssl_client_storage_pending,
      &observation->callback_native_unchanged,&observation->callback_err_unchanged);
}

static void transfer(SSL *from,SSL *to,const uint8_t *data,size_t length) {
  CHECK(length==4096);
  const int written=SSL_write(from,data,length);
  CHECK(written==static_cast<int>(length));
  uint8_t received[4096];
  size_t offset=0;
  for(unsigned attempts=0;offset<length && attempts<32;attempts++) {
    const int read=SSL_read(to,received+offset,length-offset);
    if(read>0)offset+=read;
    else CHECK(retry(to,read));
  }
  CHECK(offset==length && memcmp(data,received,length)==0);
  OPENSSL_cleanse(received,sizeof(received));
}

int main(int argc,char **argv) {
  CHECK(argc==4 && uwz_alloc_self_test()==1);
  {
    PeerPair pair=make_pair(argv,TLS1_2_VERSION,16384);
    CHECK(SSL_version(pair.client)==TLS1_2_VERSION && SSL_version(pair.server)==TLS1_2_VERSION);
    ERR_clear_error();
    bool native_unchanged=false,err_unchanged=false;
    const int status=observe_query(pair.client,ssl_client_storage_unsupported,
                                   &native_unchanged,&err_unchanged);
    printf("{\"case\":\"negotiated_verified_tls12\",\"status\":%d,\"client_version\":%d,\"server_version\":%d,\"peer_and_hostname_verified\":true,\"malloc_calls\":0,\"calloc_calls\":0,\"realloc_calls\":0,\"free_calls\":0,\"requested_bytes\":0,\"native_unchanged\":true,\"err_unchanged\":true,\"test_only_context\":true}\n",status,SSL_version(pair.client),SSL_version(pair.server));
    destroy_pair(&pair);
  }
  PeerPair pair=make_pair(argv,TLS1_3_VERSION,16384);
  CHECK(SSL_reserve_record_buffers(pair.client));
  CHECK(SSL_reserve_client_post_handshake_buffer(pair.client));
  CHECK(SSL_reserve_key_update_context(pair.client));
  CHECK(SSL_reserve_key_update_output_buffers(pair.client));
  CHECK(SSL_reserve_error_state(pair.client));
  CHECK(SSL_discard_client_session_tickets(pair.client));
  CHECK(SSL_get_client_storage_readiness(pair.client)==ssl_client_storage_ready);
  Observation observation={};
  SSL_set_msg_callback(pair.client,message);SSL_set_msg_callback_arg(pair.client,&observation);
  SSL_set_msg_callback(pair.server,message);SSL_set_msg_callback_arg(pair.server,&observation);
  CHECK(SSL_key_update(pair.server,SSL_KEY_UPDATE_REQUESTED));
  uint8_t from_peer[4096],from_client[4096];
  for(size_t i=0;i<4096;i++){from_peer[i]=static_cast<uint8_t>((i*29+17)%251);from_client[i]=static_cast<uint8_t>((i*43+61)%251);}
  transfer(pair.server,pair.client,from_peer,sizeof(from_peer));
  CHECK(observation.borrowed_headers==1 && observation.callback_status==ssl_client_storage_pending);
  CHECK(bssl::FromOpaque(pair.client)->s3->key_update_candidate==nullptr);
  transfer(pair.client,pair.server,from_client,sizeof(from_client));
  CHECK(observation.client_received_requested==1 && observation.client_sent_response==1 && observation.server_received_response==1);
  CHECK(SSL_get_client_storage_readiness(pair.client)==ssl_client_storage_ready);
  CHECK(BIO_ctrl_pending(SSL_get_rbio(pair.client))==0 && BIO_ctrl_pending(SSL_get_rbio(pair.server))==0);
  printf("{\"case\":\"real_borrowed_key_update_callback\",\"status\":%d,\"write_header_callbacks_while_candidate_live\":%u,\"candidate_observed_nonnull\":true,\"spare_observed_absent\":true,\"pending_plaintext_owner_borrowed\":true,\"malloc_calls\":0,\"calloc_calls\":0,\"realloc_calls\":0,\"free_calls\":0,\"requested_bytes\":0,\"native_unchanged\":true,\"err_unchanged\":true,\"client_received_requested\":%u,\"client_sent_not_requested\":%u,\"peer_received_not_requested\":%u,\"authenticated_payload_bytes_each_direction\":4096,\"payloads_exact\":true,\"ready_after_drain\":true,\"client_private_mutation\":false,\"outer_io_allocation_scope\":false}\n",observation.callback_status,observation.borrowed_headers,observation.client_received_requested,observation.client_sent_response,observation.server_received_response);
  OPENSSL_cleanse(from_peer,sizeof(from_peer));OPENSSL_cleanse(from_client,sizeof(from_client));
  destroy_pair(&pair);
}
