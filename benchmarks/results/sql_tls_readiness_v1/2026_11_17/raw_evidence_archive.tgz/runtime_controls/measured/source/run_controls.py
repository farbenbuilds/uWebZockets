#!/usr/bin/env python3
"""Build the two bounded runtime readiness controls against exact final libraries."""
import argparse,hashlib,json,os,pathlib,shutil,subprocess

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('native_root',type=pathlib.Path);a.add_argument('output',type=pathlib.Path);a.add_argument('--zig',default='/tmp/zig-x86_64-linux-0.16.0/zig');x=a.parse_args();base=pathlib.Path(__file__).resolve().parent;native=x.native_root.resolve(strict=True);out=x.output.absolute().resolve()
 if out.exists() or out.is_symlink():raise ValueError('Choose an absent output directory')
 protected=[base]+[p for p in base.parents if (p/'files.sha256').exists()]
 if any(out.is_relative_to(p) for p in protected):raise ValueError('Output must be outside payload and enclosing evidence roots')
 libs={n:native/'native_out/lib'/n for n in ['libssl.a','libcrypto.a']};expected={'libssl.a':'621c98febb1606e01423b5045beb69a8d18d0e48831790745e0a275dda9335cd','libcrypto.a':'e130b330cef9b9349f4ef0e9dd381fe100dd42d287d72411adbd711ad76c551c'};assert {n:sha(p) for n,p in libs.items()}==expected
 out.mkdir(mode=0o700);source=out/'source';source.mkdir()
 for f in ['runtime_controls.cc','ticket_pair.h','allocation_scope.c','run_controls.py']:shutil.copy2(base/f,source/f)
 assert sha(source/'allocation_scope.c')=='afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac'
 env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(base/'global-cache'));commands=[]
 def run(command,stem):
  with (out/(stem+'.stdout')).open('wb') as so,(out/(stem+'.stderr')).open('wb') as se:r=subprocess.run([str(c) for c in command],cwd=out,env=env,stdout=so,stderr=se)
  commands.append({'command':[str(c) for c in command],'stem':stem,'exit_code':r.returncode});(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  if r.returncode:raise RuntimeError(str(out/stem))
 run([x.zig,'cc','-std=c11','-O0','-g','-Wall','-Wextra','-Werror','-c',source/'allocation_scope.c','-o',out/'allocation_scope.o'],'build-counter')
 binary=out/'runtime_controls'
 run([x.zig,'c++','-std=c++17','-O0','-g','-Wall','-Wextra','-Werror','-DBORINGSSL_IMPLEMENTATION','-isystem',native/'boringssl','-isystem',native/'boringssl/include',source/'runtime_controls.cc',out/'allocation_scope.o',*libs.values(),'-o',binary],'build-controls')
 pki=out/'ephemeral-pki';pki.mkdir(mode=0o700)
 try:
  run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',pki/'key.pem','-out',pki/'cert.pem','-days','1','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost'],'pki')
  run([binary,pki/'cert.pem',pki/'key.pem',pki/'cert.pem'],'runtime')
 finally:shutil.rmtree(pki)
 rows=[json.loads(line) for line in (out/'runtime.stdout').read_text().splitlines()];assert len(rows)==2;assert rows[0]['status']==0 and rows[1]['status']==1
 (out/'results.json').write_text(json.dumps({'complete':True,'rows':rows,'binary_sha256':sha(binary),'native_archives_sha256':expected,'compiler_sha256':sha(pathlib.Path(x.zig)),'source_sha256':{p.name:sha(p) for p in source.iterdir()},'native_stage_patch_sha256':sha(native/'stage_readiness.patch'),'native_err_source_sha256':sha(native/'boringssl/crypto/err/err.cc'),'native_ssl_internal_sha256':sha(native/'boringssl/ssl/internal.h'),'counter_selftest63':True,'ephemeral_pki_removed':not pki.exists(),'scope':'two real runtime controls; only getter intervals are allocator-measured; no private client staging'},indent=2)+'\n');print(json.dumps({'complete':True,'rows':len(rows),'binary_sha256':sha(binary),'ephemeral_pki_removed':not pki.exists()}))
if __name__=='__main__':main()
