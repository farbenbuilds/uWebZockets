#!/usr/bin/env python3
"""Replay closed readiness wire evidence without compiler/native sources/archives."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pki-tool',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();base=Path(__file__).resolve().parent
    given=args.output.absolute()
    if given.exists() or given.is_symlink():raise ValueError('Choose an absent output directory')
    output=given.resolve(strict=False)
    protected=[base,*[parent for parent in base.parents if (parent/'files.sha256').is_file()]]
    if any(output.is_relative_to(parent) for parent in protected):raise ValueError('Keep output outside producer and enclosing artifact')
    helper=args.pki_tool.resolve(strict=True)
    if digest(helper)!='531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':raise ValueError('PKI helper checksum differs')
    identity=json.loads((base/'prebuilt_identity.json').read_text())
    if set(identity['binaries'])!={'baseline_primary/readiness_witness','query_final/readiness_witness'}:raise ValueError('Unexpected executable inventory')
    for name,checksum in identity['binaries'].items():
        if digest(base/name)!=checksum:raise ValueError('Executable checksum differs: '+name)
    output.mkdir(parents=True,mode=0o700);commands=[];complete=False;pki=output/'private_pki'

    def run(command,name):
        with (output/(name+'.stdout')).open('wb') as out,(output/(name+'.stderr')).open('wb') as err:
            result=subprocess.run(command,cwd=output,stdout=out,stderr=err)
        commands.append({'command':command,'exit_code':result.returncode})
        if result.returncode!=0:raise RuntimeError('Unexpected command status: '+name)

    def cleanup_pki():
        if not pki.exists():return
        names={path.name for path in pki.iterdir()}
        if names-{'ca.pem','server.pem','server.key'}:raise ValueError('Unexpected PKI output')
        for name in names:(pki/name).unlink()
        pki.rmdir()

    try:
        try:
            run([str(helper),'pki',str(pki)],'pki_metadata')
            arguments=[str(pki/name) for name in ('server.pem','server.key','ca.pem')]
            for name in ('baseline_primary','query_final'):
                target=output/name;target.mkdir()
                parts=('operations.csv','events.jsonl','states.jsonl','summary.jsonl')
                run([str(base/name/'readiness_witness'),*arguments,*[str(target/part) for part in parts]],name)
                for part in parts:
                    if (target/part).read_bytes()!=(base/name/part).read_bytes():raise ValueError('Replay differs: '+name+'/'+part)
                shutil.copy2(base/name/'provenance.json',target/'provenance.json')
        finally:cleanup_pki()
        for name in ('baseline_primary','query_final'):
            (output/name/'result.json').write_text(json.dumps({'complete':True,'private_pki_removed':not pki.exists(),
                'binary_sha256':digest(base/name/'readiness_witness')},indent=2)+'\n')
        run([sys.executable,str(base/'verify_wire.py'),str(output)],'verification')
        complete=True
    finally:
        cleanup_pki()
        (output/'results.json').write_text(json.dumps({'complete':complete,'commands':commands,'canonical_output':str(output),
            'private_pki_removed':not pki.exists(),'requires_compiler_native_source_or_archives':False,
            'complete_postgresql_gate_closed':False},indent=2)+'\n')
    print('PASS readiness baseline/final exact raw replay, three real rows,25zero getters; PKI removed')


if __name__=='__main__':main()
