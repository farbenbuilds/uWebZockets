# Authenticated TLS storage readiness witness

The frozen baseline proves that public pending getters plus WANT_READ cannot establish storage readiness. The corrected pure query then distinguishes real pending input/output from native idle, while transport/BIO readiness remains a separate caller condition. This closes the bounded wire prerequisite; complete PostgreSQL/v2.3 adoption and lifecycle allocation work remain open.

## Selected results

| Evidence | Native image | Real scope |
|---|---|---|
| `baseline_primary/` | Immutable Phase B b0b35e16/e9cb2928 | One verified prepared connection,29 client IO calls; public idle A and valid partial-header B expose identical pending tuple, but API2 accepts A and rejects B |
| `query_final/` | Corrected readiness621c98fe/e130b330 | Three verified rows,556 client IO calls,25 getter intervals; every getter has zero malloc/calloc/realloc/non-null-free/requested bytes and preserves seeded ERR metadata and observer counts |

All pairs use actual public singleton0x1301 configuration with null flags on both contexts, assert both negotiated IDs/TLS1.3 and verify CA/localhost. The exact counter/selftest remains unchanged: SHA256 `afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac`, malloc1/calloc1/realloc1/free2/requested63B. Compiler/link mode is Zig0.16 Debug `-O0 -g`. Compiler cache, new source/output and PKI use owned workspace SSD paths. No diagnostic interposer replaces this counter.

In baseline A and B, SSL_pending=0, SSL_has_pending=0, both paired external BIO queues are empty, and the last SSL_read is-1/WANT_READ. A repeated API2 call returns1 at A, but0 at B with packed268435522, SSL library16/reason66 (ERR_R_SHOULD_NOT_HAVE_BEEN_CALLED), empty data/flags0, ssl_lib.cc802. B contains three authenticated KeyUpdate handshake-header bytes. Completing the remaining two bytes under the old peer key, then rotating only peer TX, processes a requested update. A public zero-length control flush, actual peer response processing and exact4096B each direction under the new keys all succeed. The baseline guard calls are explicitly discovery-only; they are not a consumer readiness strategy and do not turn valid pending TLS into TlsFailed.

The final source deletes the legacy probe function/calls entirely. The only API2 use is inside the actual six-call bundle, after READY and external drain. Its prepared row reproduces all29 baseline IO operation tuples, counts and callback events exactly. Native states are READY2 at idle, PENDING1 for the consumed partial header and pending requested response, and READY2 after flushing/draining. The prepared row's IO remains zero in all count fields.

The unprepared row queues a real sealed three-byte KeyUpdate prefix behind the server Finished before client Finished is sent. Source asserts server sentFinished1/client sentFinished0 before sealing; both peers then finish the genuine verified handshake. Pinned tls13_server.cc1171 installs server application write keys before client Finished, and1446–1456 does not reinstall that write key. At the actual client handshake return, the getter is correctly READY2 while25 incoming control ciphertext bytes and64 outgoing Finished bytes remain externally queued. Caller transport is therefore not idle. Consuming the prefix yields PENDING1 even though SSL_pending/SSL_has_pending/BIO queues are all zero. Real completion, requested-response flush and full drain precede the first six successful enables and exact4096B payloads. Its pre-reservation control IO honestly measures12malloc/12free/1561B. Every initial bundle measures11malloc/291926B; repeat bundles are zero. These startup costs are visible and are not part of the pure-getter zero claim.

The BIO17 row verifies zero-length SSL_write returning-1/WANT_WRITE, a second authenticated NOT_REQUESTED update read between unchanged nullptr/0 retries, partial old-response drain17+10 bytes, retry return0 success and exactly one response received by the peer. Final payloads authenticate server epoch2/client epoch1 ordering without staging client keys, sequence or parser state. All prepared backpressure IO is zero. A partial encrypted record is PENDING1; retained output stays PENDING1 across the intervening read. Native READY2 is permitted once only the10-byte external tail remains, but the caller still drains it before the repeated bundle/application data.

Zero-length control success follows baseline ssl.h410–414 (the documented text is retained in the candidate): return0 is success for this operation. Negative returns get immediate SSL_get_error classification. The IO log uses error=-1 as an explicit “not called” sentinel for successful zero-length writes, with `ssl_get_error_called:false`; it never fabricates SSL_ERROR_NONE or classifies this0 as transport failure.

All three fresh clients now report PENDING1 before handshake, covering the corrected native-version0 classification. `query_primary/` and `query_witness.cc` preserve the earlier prepared-only image as superseded: that prototype passed prepared states but its public-version fallback misclassified a fresh client. Its raw records/source and historical hash inventory are retained; its duplicate preliminary executable is unselected. The final rows use only the corrected matching libraries. `baseline_primary/`, its source/driver snapshots and hash inventory remain immutable.

`verify_wire.py` reconciles every current IO/event row, all25 getter samples, the exact prepared baseline match, actual startup costs, request/response counts, zero retry inputs/order and payloads. Getter intervals also preserve a seeded reason/file/line/data/flags tuple and sent/received observer counts. Full cold-thread ERR warming, marks/FIFO/popped pointers, BIO trap and unsupported-mode purity are owned and reported by the separate purity/conformance verifiers; this wire report does not claim those runs.

## Native identities and source scope

Baseline source/libs: `.zig-cache/sql-tls-error-data-fixed-20261117`.

- libssl.a `b0b35e16a11c00529cbae09abab58d18cf5ec84c7596aff600d59267db0aba30`
- libcrypto.a `e9cb29281bbc2b4dabb17863c1f7fbc51fdb93cb6ad2bdd016b481be443a1d9a`

Corrected matching source/libs: `.zig-cache/sql-tls-client-readiness-fixed-20261117`.

- libssl.a `621c98febb1606e01423b5045beb69a8d18d0e48831790745e0a275dda9335cd`
- libcrypto.a `e130b330cef9b9349f4ef0e9dd381fe100dd42d287d72411adbd711ad76c551c`

Per-run provenance binds actual archives, compiler arguments and source/header subsets; source lists are explicitly subsets, not whole-tree manifests. The native owner retains complete source/build provenance. `readiness_witness.cc` is frozen baseline discovery, `query_witness.cc` is the superseded prepared-query input, and `query_extended_witness.cc` is the corrected final three-row consumer proof. Helpers seal/rotate only the real server peer. No client-private state is read or staged. No production/native/pin/protected-vendor edits were made by this verifier. No keys, session/context bytes or hashes are logged.

`original_measured_identity.json`, baseline/superseded historical inventories and raw result/provenance binary IDs describe original measured Debug files and remain unchanged. Current validation uses `prebuilt_identity.json` and `payload_manifest.json`. Delivery may strip only selected staged ELF copies, refresh the two current executable hashes and `delivery_stripping` false→true plus corresponding current manifest entries under explicit ELF proof. Historical records are never refreshed to match stripped copies. `verify_frozen.py` validates the current closed payload only.

## Portable replay

```sh
python3 /ABS/wire/replay_prebuilt.py --pki-tool /ABS/wt-tools --output /ABS/ABSENT_EXTERNAL_OUTPUT
```

The offline PKI helper must be SHA256 `531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9`; original path `/tmp/uwz-wt-upstream-backport-client-20261117/client/wt-tools`. Two selected programs need no compiler/native source/archives at replay. The wrapper validates current binary IDs, generates fresh PKI, compares every replay CSV/event/state/summary byte against retained measurements and runs the reconciliation verifier. Owned ephemeral PKI is removed in finally blocks.

Replay completed into the absent external SSD path `.zig-cache/sql-tls-readiness-wire-replay-20261117`; raw logs/results are copied into `replay_evidence/`. Output is canonicalized before creation and rejected inside its own producer or any enclosing ancestor carrying a `files.sha256` marker. `replay_guards.json` records8 refusals before writes, including nested/outer artifact siblings, a symlinked parent into the artifact, relative parent paths and a dangling final symlink. Existing outputs and wrong helper checksums are refused too. Root must repeat full replay from the final staged delivery after stripping.

For recompilation, use an absent output with explicit native root/helper: `run_wire.py NATIVE_ROOT PKI_HELPER ABSENT_OUTPUT` for original discovery, or append `--query-api --extended` for the corrected final source. Exact commands/statuses are retained in each measurement directory. The closed allowlist omits objects, compiler caches, snippet intermediates and duplicate preliminary executables. Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain user-deferred and unclaimed. Root owns integration, final review, publication and commit/push.
