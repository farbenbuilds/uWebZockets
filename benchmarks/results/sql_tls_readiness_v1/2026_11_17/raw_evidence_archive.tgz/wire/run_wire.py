#!/usr/bin/env python3
"""Build/run the authenticated native-readiness prerequisite witness."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root',type=Path);parser.add_argument('pki_helper',type=Path);parser.add_argument('output',type=Path)
    parser.add_argument('--query-api',action='store_true');parser.add_argument('--extended',action='store_true');args=parser.parse_args()
    if args.extended and not args.query_api:raise ValueError('Extended consumer rows require actual query API')
    base=Path(__file__).resolve().parent;native=args.native_root.resolve(strict=True);helper=args.pki_helper.resolve(strict=True);output=args.output.absolute()
    if output.exists() or output.is_symlink():raise ValueError('Choose absent output')
    if digest(helper)!='531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':raise ValueError('PKI helper differs')
    if digest(base/'allocation_scope.c')!='afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac':raise ValueError('Counter differs')
    output.mkdir(mode=0o700);zig='/tmp/zig-x86_64-linux-0.16.0/zig';env=dict(os.environ);env['ZIG_GLOBAL_CACHE_DIR']=str(base/'zig_global_cache')
    source=base/('query_extended_witness.cc' if args.extended else 'query_witness.cc' if args.query_api else 'readiness_witness.cc');binary=output/'readiness_witness';archives=[native/'native_out/lib/libssl.a',native/'native_out/lib/libcrypto.a']
    source_paths=['ssl/ssl_lib.cc','ssl/tls13_enc.cc','ssl/tls13_server.cc','ssl/s3_both.cc','ssl/s3_pkt.cc','include/openssl/ssl.h','ssl/internal.h']
    provenance={'native_root':str(native),'archive_sha256':{p.name:digest(p) for p in archives},'fixture_sha256':digest(source),
        'counter_sha256':digest(base/'allocation_scope.c'),'optimization':'Debug (-O0 -g)','compiler':zig,
        'compiler_cache':env['ZIG_GLOBAL_CACHE_DIR'],'query_api_enabled':args.query_api,'extended_consumer_rows':args.extended,
        'native_source_subset_sha256':{name:digest(native/'boringssl'/name) for name in source_paths},'pki_helper_sha256':digest(helper)}
    (output/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n');commands=[];pki=output/'private_pki';complete=False
    def run(command,name):
        with (output/(name+'.stdout')).open('wb') as out,(output/(name+'.stderr')).open('wb') as err:
            result=subprocess.run(command,cwd=output,env=env,stdout=out,stderr=err)
        commands.append({'command':command,'exit_code':result.returncode});(output/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        if result.returncode!=0:raise RuntimeError('Command failed: '+name)
    try:
        run([zig,'cc','-std=c11','-O0','-g','-c',str(base/'allocation_scope.c'),'-o',str(output/'allocation_scope.o')],'build-counter')
        run([zig,'c++','-std=c++17','-O0','-g','-fno-omit-frame-pointer','-Wall','-Wextra','-Werror','-DBORINGSSL_IMPLEMENTATION',
            *(['-DUWZ_READINESS_API=1'] if args.query_api else []),'-isystem',str(native/'boringssl'),'-isystem',str(native/'boringssl/include'),
            str(source),str(output/'allocation_scope.o'),*[str(p) for p in archives],'-o',str(binary)],'build-witness')
        run([str(helper),'pki',str(pki)],'pki-metadata')
        run([str(binary),*[str(pki/name) for name in ('server.pem','server.key','ca.pem')],*[str(output/name) for name in ('operations.csv','events.jsonl','states.jsonl','summary.jsonl')]],'run')
        complete=True
    finally:
        if pki.exists():
            names={p.name for p in pki.iterdir()}
            if names-{'ca.pem','server.pem','server.key'}:raise ValueError('Unexpected PKI files')
            for name in names:(pki/name).unlink()
            pki.rmdir()
        (output/'result.json').write_text(json.dumps({'complete':complete,'private_pki_removed':not pki.exists(),
            'binary_sha256':digest(binary) if binary.exists() else None},indent=2)+'\n')
    print('PASS authenticated pending ambiguity/completion; query '+('enabled' if args.query_api else 'unavailable baseline')+'; PKI removed')


if __name__=='__main__':main()
