#!/usr/bin/env python3
"""Validate closed current readiness payload and its two executable identities."""
import hashlib
import json
from pathlib import Path


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    base=Path(__file__).resolve().parent
    manifest=json.loads((base/'payload_manifest.json').read_text())
    names=set((base/'payload_allowlist.txt').read_text().splitlines())
    assert names==set(manifest['sha256'])|{'payload_manifest.json'}
    for name,checksum in manifest['sha256'].items():
        path=base/name;assert path.is_file() and not path.is_symlink() and digest(path)==checksum,name
    identity=json.loads((base/'prebuilt_identity.json').read_text());assert len(identity['binaries'])==2
    for name,checksum in identity['binaries'].items():assert digest(base/name)==checksum,name
    print('PASS current readiness payload '+str(len(names))+' files/two executable IDs; historical records unchanged')


if __name__=='__main__':main()
