#!/usr/bin/env python3
"""Reconcile readiness statuses, real control progress and exact allocation scopes."""
import argparse
import csv
import json
from pathlib import Path

FIELDS=('malloc','calloc','realloc','free','bytes')


def zero(counts):return all(value==0 for value in counts.values())


def read_rows(path):return [json.loads(line) for line in path.read_text().splitlines()]


def verify(base):
    original=base/'baseline_primary';current=base/'query_final'
    old_states=read_rows(original/'states.jsonl');old_summary=read_rows(original/'summary.jsonl')
    assert len(old_summary)==1 and old_summary[0]['a_b_public_pending_tuple_identical']
    a=next(row for row in old_states if row.get('state')=='a_idle_before_probe')
    b=next(row for row in old_states if row.get('state')=='b_partial_before_probe')
    pending=('pending','has_pending','client_external_input','server_external_input')
    assert [a[k] for k in pending]==[b[k] for k in pending]==[0,0,0,0]
    probes=[row for row in old_states if 'probe' in row]
    assert [row['result'] for row in probes]==[1,0,0,1]
    for row in probes:
        assert row['legacy_discovery_only'] and zero(row['counts'])
        if row['result']==0:assert len(row['queue'])==1 and (row['queue'][0]['library'],row['queue'][0]['reason'])==(16,66)
        else:assert row['queue']==[]
    states=read_rows(current/'states.jsonl');rows=read_rows(current/'summary.jsonl')
    names=('prepared_fragmented_key_update','unprepared_control_before_client_finished','zero_flush_read_between_backpressure')
    assert [row['case'] for row in rows]==list(names)
    operations=list(csv.DictReader((current/'operations.csv').open()));events=read_rows(current/'events.jsonl')
    assert len(operations)==len(events)==556
    old_operations=list(csv.DictReader((original/'operations.csv').open()))
    old_events=read_rows(original/'events.jsonl')
    assert operations[:29]==old_operations and events[:29]==old_events
    for index,(op,event) in enumerate(zip(operations,events)):
        assert event['index']==index and event['case']==op['scenario'] and event['phase']==op['phase']
        assert (event['result'],event['error'])==(int(op['result']),int(op['error'])) and event['queue']==[]
        if op['phase']=='zero_control_flush':assert (int(op['result']),int(op['error']))==(0,-1)
    queries=[row for row in states if 'state' in row]
    assert len(queries)==25 and not any('probe' in row for row in states)
    assert all(row['query_available'] and row['query_err_preserved'] and zero(row['query_counts']) for row in queries)
    assert all(row['query'] in (1,2) for row in queries)
    assert [row['query'] for row in queries if row['state']=='fresh_initial']==[1,1,1]
    for row in rows:
        assert row['verified_ca_hostname'] and row['payload_exact'] and row['payload_each_direction']==4096
        assert not row['client_private_state_staged'] and not row['legacy_guard_probes']
        selected=[op for op in operations if op['scenario']==row['case']]
        controls=[op for op in selected if op['phase'] not in ('read','response_write')]
        reads=[op for op in selected if op['phase']=='read'];writes=[op for op in selected if op['phase']=='response_write']
        assert (len(controls),len(reads),len(writes))==(row['control_operations'],row['read_operations'],row['write_operations'])
        for group,key in [(controls,'control_counts'),(reads,'read_counts'),(writes,'write_counts')]:
            assert {field:sum(int(op[field]) for op in group) for field in FIELDS}==row[key]
        assert sum(max(int(op['result']),0) for op in reads)==4096
        assert sum(max(int(op['result']),0) for op in writes)==4096
        if row['case']!='unprepared_control_before_client_finished':assert all(int(op[field])==0 for op in selected for field in FIELDS)
        assert row['received_updates']==(2 if row['case']==names[2] else 1)
        assert row['sent_updates']==row['peer_received_updates']==1
    early=rows[1];assert early['unprepared_at_first_fragment'] and early['server_finished_before_client_finished']
    assert early['control_counts']=={'malloc':12,'calloc':0,'realloc':0,'free':12,'bytes':1561}
    assert zero(early['read_counts']) and zero(early['write_counts'])
    at_return=next(row for row in queries if row['state']=='at_client_handshake_return')
    assert at_return['query']==2 and at_return['client_external_input']==25 and at_return['server_external_input']==64
    hidden=[row for row in queries if row['state'] in ('b_partial_before_probe','unprepared_partial_pending')]
    assert len(hidden)==2 and all(row['query']==1 and [row[k] for k in pending]==[0,0,0,0] for row in hidden)
    assert all(row['query']==1 for row in queries if row['state'] in ('partial_ciphertext_pending','after_read_still_write_pending','response_partial_write_pending','requested_output_pending','c_requested_output_before_probe'))
    external=[row for row in queries if row['query']==2 and (row['client_external_input'] or row['server_external_input'])]
    assert len(external)==4
    assert [row['server_external_input'] for row in external]==[27,64,27,10]
    bundles=[row for row in states if 'bundle' in row]
    assert len(bundles)==5 and all(row['results']==[1,1,1,1,1,1] for row in bundles)
    first=[row for row in bundles if row['bundle'] in ('initial','first_after_real_control')]
    assert len(first)==3 and all(row['startup_counts']=={'malloc':11,'calloc':0,'realloc':0,'free':0,'bytes':291926} for row in first)
    assert all(zero(row['startup_counts']) for row in bundles if row not in first)
    retries=[op for op in operations if op['phase']=='zero_flush_want_write']
    assert len(retries)==1 and (int(retries[0]['result']),int(retries[0]['error']))==(-1,3)
    between=[op for op in operations if op['phase']=='read_between_zero_retries']
    assert len(between)==1 and (int(between[0]['result']),int(between[0]['error']))==(-1,2)
    ordered=next(row for row in states if 'zero_retry_input_stable' in row)
    assert ordered['zero_retry_input_stable'] and ordered['read_between_zero_retries'] and ordered['response_exactly_once']
    assert ordered['response_external_prefix']==17 and ordered['response_external_tail']==10
    for directory in (original,current):
        result=json.loads((directory/'result.json').read_text());assert result['complete'] and result['private_pki_removed']
    return {'baseline_real_pending_counterexample':True,'prepared_io_semantics_counts_callbacks_match_frozen_baseline':True,'query_wire_rows':3,'client_io_calls':556,'getter_calls':25,
        'query_five_count_fields_zero':True,'query_seeded_err_and_observers_preserved':True,
        'unprepared_control_io_counts':early['control_counts'],'first_bundle_requested_bytes':291926,
        'getters_do_not_establish_external_idle':True,'external_ready_observations':external,
        'zero_flush_success_not_classified_as_tls_failure':True,'read_between_zero_retries_and_exact_once_ordering':True,
        'cold_thread_bio_trap_full_err_purity_owned_separately':True,'complete_postgresql_gate_closed':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('base',type=Path)
    print(json.dumps(verify(parser.parse_args().base),indent=2))


if __name__=='__main__':main()
