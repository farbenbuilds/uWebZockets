#!/usr/bin/env python3
"""Verify the archived files and reconstruct the paired result from raw records."""
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import sys


CONTROL = 'baseline/install/bin/sql_httparena'
CANDIDATE = 'install/bin/sql_httparena'
WRK = 'tooling/root/usr/bin/wrk'
LUA = 'runner/async_db.lua'
POOL = 'src/sql/pool.zig'
DELTAS = {'builds/examples.zig', POOL}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def mode(path):
    return stat.S_IMODE(path.stat().st_mode)


def files(root):
    found = set()
    for path in root.rglob('*'):
        require(not path.is_symlink(), f'Unexpected link: {path}')
        if path.is_dir():
            continue
        require(path.is_file(), f'Expected a regular file: {path}')
        found.add(path.relative_to(root).as_posix())
    return found


def verify_manifest(root):
    entries = load(root / 'payload_manifest.json')['files']
    seen = set()
    for entry in entries:
        name = entry['path']
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts and name not in seen, f'Invalid manifest path: {name}')
        seen.add(name)
        require(mode(root / path) == entry['mode'] and sha(root / path) == entry['sha256'], f'Payload identity differs: {name}')
    require(files(root) == seen | {'payload_manifest.json'}, 'Archive file inventory differs')
    return len(seen)


def verify_source(root, decision, build):
    parent = load(root / 'parent_identity.json')
    baseline = load(root / 'baseline/packaged_source_identity.json')
    delta = load(root / 'source_delta.json')
    source = {entry['path']: (entry['sha256'], int(entry['mode'], 8)) for entry in parent['files']}
    original = {entry['path']: (entry['sha256'], entry['mode']) for entry in baseline['files']}
    require(source == original and len(source) == len(parent['files']) == 346 and files(root / 'source') == set(source),
            'Baseline or candidate source inventory differs')
    changes = {entry['path']: entry for entry in delta['changes']}
    require(set(changes) == files(root / 'parent_source') == DELTAS and len(delta['changes']) == 2,
            'Expected exactly two candidate source deltas')
    digests = {}
    for name, (expected_sha, expected_mode) in source.items():
        path = root / 'source' / name
        require(mode(path) == expected_mode, f'Unexpected candidate source mode: {name}')
        if name not in changes:
            require(sha(path) == expected_sha, f'Unexpected candidate source change: {name}')
            continue
        change = changes[name]
        prior = root / 'parent_source' / name
        digest = sha(path)
        require(sha(prior) == change['parent_sha256'] == expected_sha and mode(prior) == int(change['mode'], 8) == expected_mode
                and digest == change['candidate_sha256'] != expected_sha, f'Candidate delta differs: {name}')
        digests['source/' + name] = digest
    require(digests == build['source_sha256'] and delta['candidate_binary'] == build['binary'], 'Build input identity differs')
    require(parent['source_commit'] == baseline['commit'] == delta['original_source_commit'] and
            decision['baseline_commit'] == delta['baseline_commit'], 'Source commit identities differ')
    require(decision['production_pool_sha256'] == sha(root / 'parent_source' / POOL) and
            decision['candidate_pool_sha256'] == sha(root / 'source' / POOL), 'Decision source hashes differ')


def verify_inputs(root, build):
    baseline = load(root / 'baseline/build/result.json')
    candidate = build['binary']
    tools = load(root / 'tooling/identity.json')
    require(baseline['exit_code'] == build['exit_code'] == 0, 'Build command failed')
    require(sha(root / CONTROL) == baseline['binary_sha256'] and (root / CONTROL).stat().st_size == baseline['binary_bytes'],
            'Control ELF differs')
    require(sha(root / CANDIDATE) == candidate['sha256'] and mode(root / CANDIDATE) == int(candidate['mode'], 8) and
            (root / CANDIDATE).stat().st_size == candidate['bytes'], 'Candidate ELF differs')
    require(sha(root / WRK) == tools['wrk_sha256'] and
            sha(root / 'tooling/wrk_4.1.0-4build3_amd64.deb') == tools['package_sha256'], 'wrk package differs')
    for entry in load(root / 'baseline/archived_inputs.json')['files']:
        path = root / 'archived_fixture' / Path(entry['member']).name
        require(sha(path) == entry['sha256'] and mode(path) == entry['mode'], f'Archived fixture differs: {path.name}')
    fixture = load(root / 'fixture.json')
    original = load(root / 'baseline/fixture.json')
    require(fixture['seed_sha256'] == original['seed_sha256'] == sha(root / 'archived_fixture/pgdb-seed.sql') and
            fixture['image'] == original['image'] == (root / 'archived_fixture/image.txt').read_text().strip() and
            fixture['seed_rows'] == original['seed_rows'] == 100000 and fixture['expected_rows'] == 8237, 'Fixture identity differs')
    cleanup = load(root / 'cleanup.json')
    history = load(root / 'fixture/unit_database_history.json')
    require(history['exit_code'] == 0 and history['post_measurement_cluster_observation']['tcp_clients'] == 0 and
            history['argv'][2] == fixture['container'], 'Owned fixture consumers did not exit')
    require(cleanup['container_removed_or_absent'] is True and cleanup['private_inputs_removed'] is True and
            cleanup['matched_database_containers'] == 1 and cleanup['label'] == fixture['label'] and
            cleanup['ownership_token_sha256'] == hashlib.sha256(fixture['owner_token'].encode()).hexdigest(), 'Cleanup identity differs')


def verify_prelaunch(root):
    paths = {'runner/measure.py', LUA, 'verification/verify.py', 'verification/test_verify.py', CANDIDATE, CONTROL,
             WRK, 'fixture.json', 'fixture/expected_items.jsonl'}
    observed = set()
    for line in (root / 'verification/prelaunch.sha256').read_text().splitlines():
        digest, original = line.split()
        work, name = original.removeprefix('.zig-cache/').split('/', 1)
        if work == 'async-db-performance-20261118' and name != WRK:
            name = 'baseline/' + name
        require(name in paths and name not in observed and sha(root / name) == digest, f'Prelaunch identity differs: {name}')
        observed.add(name)
    require(paths == observed, 'Prelaunch script and runtime inventory differs')


def main():
    root = Path(__file__).resolve().parent
    count = verify_manifest(root)
    decision = load(root / 'decision.json')
    build = load(root / 'build/result.json')
    verify_source(root, decision, build)
    verify_inputs(root, build)
    verify_prelaunch(root)
    run = root / 'measurements/run_01'
    result = subprocess.check_output([sys.executable, '-B', root / 'verification/verify.py', run,
                                      '--items', root / 'fixture/expected_items.jsonl', '--fixture', root / 'fixture.json',
                                      '--control', root / CONTROL, '--candidate', root / CANDIDATE,
                                      '--wrk', root / WRK, '--lua', root / LUA])
    raw = json.loads(result)
    require(raw == load(run / 'verified.json'), 'Recomputed benchmark differs from retained verification')
    require(decision['status'].startswith('rejected;') and decision['throughput_gate_met'] == raw['throughput_gate_met']
            and decision['target_rps'] == raw['throughput_threshold_rps'], 'Retention decision or throughput gate differs')
    ranges = raw['timed_run_observed_ranges']
    print(f'Verified {count} payload files, 346 baseline files, eight cases, and 100 exact fixed responses.')
    print(f"HTTP median requests/s: {ranges['control']['rps']['median']:.3f} control, {ranges['candidate']['rps']['median']:.3f} candidate.")
    print('Candidate rejected. 300,000 requests/s gate:', 'met' if raw['throughput_gate_met'] else 'unmet')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, subprocess.CalledProcessError) as error:
        raise SystemExit(f'Verification failed: {error}') from error
