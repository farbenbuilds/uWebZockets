import copy
import unittest

from verify import client_cpu, proc_cpu, recorded_clock, request_shape_calls, require_same_clock, snapshot_cpu


APP, DB = "ab" * 32, "cd" * 32


def proc_record(pid, user, system, start):
    idle = " 0"
    return f"{pid} (name with ) in it) S" + idle * 10 + f" {user} {system}" + idle * 6 + f" {start}"


def resources(app_usage, pg_usage, app_user, app_system, app_start=800):
    return {
        "application": {
            "pid": 11, "cgroup": f"0::/system.slice/docker-{APP}.scope\n",
            "cpu.stat": f"usage_usec {app_usage}\nuser_usec {app_usage // 2}\nsystem_usec {app_usage // 2}",
            "proc_stat": proc_record(11, app_user, app_system, app_start),
        },
        "postgres": {
            "pid": 12, "cgroup": f"0::/docker/{DB}\n",
            "cpu.stat": f"usage_usec {pg_usage}\nuser_usec {pg_usage // 2}\nsystem_usec {pg_usage // 2}",
            "proc_stat": proc_record(12, 10, 20, 140),
        },
    }


class VerifyTests(unittest.TestCase):
    def test_proc_stat_command_with_parenthesis(self):
        self.assertEqual(proc_cpu(proc_record(100, 421, 87, 9001), 100), (421, 87, 9001))
        with self.assertRaisesRegex(ValueError, "Unexpected PID"):
            proc_cpu(proc_record(200, 421, 87, 9001), 100)

    def test_cpu_deltas_use_cgroup_and_pid(self):
        first = resources(100, 200, 5, 10)
        second = resources(30_100, 60_200, 7, 11)
        totals = snapshot_cpu(first, second, 11, 12, APP, DB, 100)
        self.assertEqual(totals["application_process"], {"usage_usec": 30_000, "user_usec": 20_000, "system_usec": 10_000})
        self.assertEqual(totals["application_cgroup"]["usage_usec"], 30_000)
        self.assertEqual(totals["postgres_cgroup"]["usage_usec"], 60_000)

    def test_cpu_rejects_reused_pid_and_wrong_scope(self):
        first = resources(100, 200, 5, 10)
        second = resources(30_100, 60_200, 7, 11, app_start=801)
        with self.assertRaisesRegex(ValueError, "PID changed"):
            snapshot_cpu(first, second, 11, 12, APP, DB, 100)
        changed = copy.deepcopy(first)
        changed["postgres"]["cgroup"] = f"0::/unrelated/docker-{DB}-suffix.scope\n"
        next_snapshot = resources(30_100, 60_200, 7, 11)
        next_snapshot["postgres"]["cgroup"] = changed["postgres"]["cgroup"]
        with self.assertRaisesRegex(ValueError, "does not identify postgres"):
            snapshot_cpu(changed, next_snapshot, 11, 12, APP, DB, 100)
        with self.assertRaisesRegex(ValueError, "Invalid CPU counter delta"):
            snapshot_cpu(resources(20_100, 30_200, 6, 10), first, 11, 12, APP, DB, 100)

    def test_client_cpu_checks_exit_and_duplicate_fields(self):
        raw = "\tUser time (seconds): 7.31\n\tSystem time (seconds): 5.00\n\tExit status: 0\n"
        self.assertEqual(client_cpu(raw)["usage_usec"], 12_310_000)
        with self.assertRaisesRegex(ValueError, "nonzero client exit"):
            client_cpu(raw.replace("Exit status: 0", "Exit status: 10"))
        with self.assertRaisesRegex(ValueError, "duplicate"):
            client_cpu(raw + "\tUser time (seconds): 8.00\n")

    def test_rotating_shapes_and_thread_duplicates(self):
        raw = "\n".join(f"UWZ_WRK_GENERATED thread={thread} calls=12 limit_5=3 limit_10=3 limit_20=2 limit_35=2 limit_50=2"
                        for thread in range(1, 9))
        self.assertEqual(request_shape_calls(raw), {5: 24, 10: 24, 20: 16, 35: 16, 50: 16})
        with self.assertRaisesRegex(ValueError, "shape rotation"):
            request_shape_calls(raw.replace("limit_50=2", "limit_50=3", 1))
        with self.assertRaisesRegex(ValueError, "duplicated wrk thread"):
            request_shape_calls(raw.replace("thread=8", "thread=7"))

    def test_clock_coordinates_accept_separate_inodes(self):
        raw = f"time:[101]\ntime:[101]\nmonotonic 0 0\nboottime 0 0\n{'ab' * 32}\n"
        host = recorded_clock(raw)
        require_same_clock(host, recorded_clock(raw.replace("101", "202")))
        with self.assertRaisesRegex(ValueError, "differing clock coordinates"):
            require_same_clock(host, recorded_clock(raw.replace("monotonic 0 0", "monotonic 0 1")))
        with self.assertRaisesRegex(ValueError, "Invalid Linux time namespace"):
            recorded_clock(raw.replace("101", "202", 1))


if __name__ == "__main__":
    unittest.main()
