import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import statistics


WORKERS, THREADS, CONNECTIONS = 32, 8, 1024
PERCENTILES = (50, 90, 95, 99)
LIMITS = (5, 10, 20, 35, 50)
PAIR_ORDER = (("control", "candidate"), ("candidate", "control"), ("control", "candidate"))
CONTROL_SHA = "836f823e81f6d8fd7242dfc5b3910ceb6d72930bc7a115c05aff01c79e09989b"
LUA_SHA = "2ca83b5f5a30fc9fe46bd8e9fba9e852dd3afd0809d586ba00edb0a237ad7750"
WRK_SHA = "f6536e3f9479584fa2b4a97d12c56671487be9f1011f309dc7a3b1bb0f6ea06c"
SEED_SHA = "f020c2c6851ea1c53cd1b90c94baadd5645b2fc3e4caed5b0daf71a61bff9e21"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def unique_fields(entries):
    result = dict(entries)
    require(len(result) == len(entries), "Duplicate JSON field")
    return result


def recorded_clock(raw):
    inode, child_inode, monotonic, boottime, kernel = raw.splitlines()
    offsets = [line.split() for line in (monotonic, boottime)]
    require(re.fullmatch(r"time:\[\d+\]", inode) and re.fullmatch(r"[0-9a-f]{64}", kernel)
            and inode == child_inode and [row[0] for row in offsets] == ["monotonic", "boottime"], "Invalid Linux time namespace evidence")
    require(all(len(row) == 3 and 0 <= int(row[2]) < 1_000_000_000 for row in offsets), "Invalid time namespace offsets")
    return {"inode": inode, "child_inode": child_inode, "kernel_boot_sha256": kernel,
            "offsets_ns": {clock: 1_000_000_000 * int(seconds) + int(nanos) for clock, seconds, nanos in offsets}}


def require_same_clock(host, app):
    require(app["kernel_boot_sha256"] == host["kernel_boot_sha256"]
            and app["offsets_ns"] == host["offsets_ns"] == {"monotonic": 0, "boottime": 0},
            "Application and host have differing clock coordinates")


def case_path(root, mode, pair):
    return root / (f"pair_{pair:02}_{mode}" if pair else f"{mode}_fixed")


def cgroup_container(cgroup, container):
    lines = re.findall(r"^0::(.+)$", cgroup, re.M)
    return len(lines) == 1 and Path(lines[0]).name in (container, f"docker-{container}.scope")


def proc_cpu(raw, pid):
    beginning, counters = raw.rsplit(")", 1)
    require(int(beginning.split(" (", 1)[0]) == pid, "Unexpected PID in /proc stat")
    fields = counters.split()
    user, system, start_tick = (int(fields[index]) for index in (11, 12, 19))
    require(min(user, system, start_tick) >= 0, "Negative /proc stat ticks")
    return user, system, start_tick


def snapshot_cpu(first, second, app_pid, db_pid, container, db_container, clock_ticks):
    totals = {}
    for role, pid, cid in (("application", app_pid, container), ("postgres", db_pid, db_container)):
        start, end = first[role], second[role]
        require(start["pid"] == end["pid"] == pid and start["cgroup"] == end["cgroup"]
                and cgroup_container(start["cgroup"], cid), f"CPU snapshot does not identify {role}")
        usage = [dict(line.split() for line in state["cpu.stat"].splitlines()) for state in (start, end)]
        fields = ("usage_usec", "user_usec", "system_usec")
        delta = {field: int(usage[1][field]) - int(usage[0][field]) for field in fields}
        require(min(delta.values()) >= 0 and delta["usage_usec"] > 0, f"Invalid CPU counter delta for {role}")
        totals[role + "_cgroup"] = delta
        usersys = [proc_cpu(state["proc_stat"], pid) for state in (start, end)]
        require(usersys[0][2] == usersys[1][2] and min(usersys[1][i] - usersys[0][i] for i in (0, 1)) >= 0,
                f"PID changed or CPU ticks decreased for {role}")
        if role == "application":
            user, system = ((usersys[1][i] - usersys[0][i]) * 1_000_000 / clock_ticks for i in (0, 1))
            totals["application_process"] = {"usage_usec": user + system, "user_usec": user, "system_usec": system}
    return totals


def client_cpu(raw):
    require(re.findall(r"^\s*Exit status: (\d+)\s*$", raw, re.M) == ["0"], "GNU time reported a nonzero client exit")
    readings = [re.findall(rf"^\s*{key} time \(seconds\): (\d+\.\d+)\s*$", raw, re.M) for key in ("User", "System")]
    require(all(len(bucket) == 1 for bucket in readings), "Missing or duplicate GNU time CPU fields")
    user, system = (round(float(bucket[0]) * 1_000_000) for bucket in readings)
    require(user + system > 0, "GNU time client CPU was zero")
    return {"usage_usec": user + system, "user_usec": user, "system_usec": system}


def request_shape_calls(raw):
    rows = re.findall(r"^UWZ_WRK_GENERATED thread=(\d+) calls=(\d+) (.+)$", raw, re.M)
    require([int(thread) for thread, _, _ in rows] == list(range(1, THREADS + 1)), "Missing or duplicated wrk thread")
    totals = Counter()
    for _, count, values in rows:
        cycles, remainder = divmod(int(count), len(LIMITS))
        expected = {limit: cycles + (index < remainder) for index, limit in enumerate(LIMITS)}
        seen = [(int(limit), int(calls)) for limit, calls in re.findall(r"limit_(\d+)=(\d+)", values)]
        require(int(count) > 0 and seen == list(expected.items()), "Unexpected wrk shape rotation")
        totals.update(dict(seen))
    return dict(totals)


def read_window(case, label, seconds, metadata, app_pid, db_pid, container):
    command = read(case / f"{label}.command.json")
    argv = command["argv"]
    expected = [metadata["wrk"]["path"], "-t", str(THREADS), "-c", str(CONNECTIONS), "-d", f"{seconds}s",
                "--timeout", "2s", "--latency", "-s", metadata["lua"]["path"], f"http://127.0.0.1:{metadata['http_port']}"]
    require(argv[:5] == ["env", "LC_ALL=C", "/usr/bin/time", "-v", "-o"] and argv[6:] == expected
            and Path(argv[5]).name == f"{label}.client_time.txt", f"Unexpected wrk command {case.name}/{label}")
    raw = (case / f"{label}.stdout").read_text()
    summary, = re.findall(r"^UWZ_WRK (.+)$", raw, re.M)
    stats = {name: int(value) for name, value in re.findall(r"(\w+)=(\d+)", summary)}
    completed, duration = stats["completed"], stats["duration_us"]
    require(command["exit_code"] == 0 and completed > 0 and duration >= seconds * 1_000_000,
            f"Unhealthy client {case.name}/{label}")
    require(all(stats[name] == 0 for name in ("status", "connect", "read", "write", "timeout")),
            f"Client errors {case.name}/{label}")
    delays = [stats[f"p{p}_us"] for p in PERCENTILES]
    require(delays == sorted(delays) and min(delays) > 0, "Invalid wrk latency percentile")
    before, after = (read(case / f"{label}_{when}.resources.json") for when in ("before", "after"))
    launch, reaped = command["monotonic_before_spawn_ns"], command["monotonic_after_reap_ns"]
    require(before["monotonic_start_ns"] <= before["monotonic_end_ns"] <= launch
            and launch + duration * 1_000 <= reaped <= after["monotonic_start_ns"] <= after["monotonic_end_ns"],
            f"CPU sampling did not bracket the client interval {case.name}/{label}")
    cpu = snapshot_cpu(before, after, app_pid, db_pid, container, metadata["db_container"], metadata["proc_clock_ticks_per_second"])
    cpu["wrk_process"] = client_cpu((case / f"{label}.client_time.txt").read_text())
    stats["rps"] = completed * 1_000_000 / duration
    stats["generated_calls_by_limit"] = request_shape_calls(raw)
    stats["client_monotonic_ns"] = (launch, reaped)
    stats["cpu_usec"] = cpu
    stats["cpu_usec_per_completed_request"] = {role: values["usage_usec"] / completed for role, values in cpu.items()}
    return stats


def fixed_responses(case, rows):
    responses = read(case / "fixed_responses.json")
    shapes = Counter()
    for response in responses:
        require(response["status"] == 200 and response["version"] == 11, "Fixed response is not HTTP/1.1 200")
        headers = {key.lower(): val for key, val in response["headers"]}
        request = response["request"]
        limit = request["limit"]
        require(len(headers) == len(response["headers"]) and headers.get("content-type") == "application/json"
                and headers.get("content-length") == str(len(response["body_utf8"].encode("utf-8"))) and request["method"] == "GET"
                and request["path"] == f"/async-db?min=10&max=50&limit={limit}", "Incorrect fixed request or content type")
        payload = json.loads(response["body_utf8"], object_pairs_hook=unique_fields)
        require(set(payload) == {"items", "count"} and type(payload["count"]) is int and payload["count"] == limit
                and len(payload["items"]) == len({item["id"] for item in payload["items"]}) == limit, "Fixed payload has wrong count")
        for item in payload["items"]:
            require(10 <= item["price"] <= 50 and json.dumps(item, sort_keys=True) == json.dumps(rows[item["id"]], sort_keys=True),
                    "Fixed payload has incorrect typed fields or PostgreSQL values")
        shapes[limit] += 1
    require(shapes == {limit: 10 for limit in LIMITS}, "Fixed requests do not cover the exact five shapes")
    return len(responses)


def raw_stats(case, label):
    snapshots = [read(path) for path in sorted(case.glob(f"pg_{label}_*.stdout"))]
    require(len(snapshots) >= 2 and snapshots[-1] == snapshots[-2] and snapshots[-1]["tcp_clients"] == 0,
            f"PostgreSQL statistics did not settle {case.name}/{label}")
    return snapshots[-1]


def verify_case(case, mode, fixed, rows, metadata, db_pid):
    summary = read(case / "summary.json")
    host = metadata["clock_namespace"]
    app = recorded_clock((case / "app_clock_namespace.stdout").read_text())
    host_app_ns = read(case / "app_host_clock_namespace.json")
    link_verified = host_app_ns.get("time_inode") == app["inode"]
    link_unavailable = "time_inode" not in host_app_ns and host_app_ns.get("unavailable_time_inode_errno") in (1, 13)
    app_pid = int((case / "app_pid.stdout").read_text())
    require(app == summary["clock_namespace"] and (link_verified or link_unavailable)
            and host_app_ns["pid"] == app_pid, f"Clock namespace mismatch {case.name}")
    require_same_clock(host, app)
    require(summary["valid"] is True and summary["io_uring_fds"] == WORKERS and summary["mode"] == mode,
            f"Original runner marked invalid or unexpected configuration {case.name}")
    run_cmd, stop_cmd, remove_cmd = (read(case / f"app_{label}.command.json") for label in ("run", "stop", "remove"))
    require(run_cmd["exit_code"] == stop_cmd["exit_code"] == remove_cmd["exit_code"] == 0, f"Lifecycle command failed {case.name}")
    executable = metadata["executables"][mode]
    argv = run_cmd["argv"]
    mounts = [value for option, value in zip(argv, argv[1:]) if option == "--mount"]
    require(mounts ==
            [f"type=bind,source={executable['path']},target=/server,readonly"]
            and metadata["sha256"][executable["path"]] == executable["sha256"] and argv[-3:] == ["--entrypoint", "/server", metadata["db_image"]]
            and argv[argv.index("--network") + 1] == "host" and "--pull=never" in argv,
            f"Incorrect normal executable or image mode {case.name}")
    require({value for option, value in zip(argv, argv[1:]) if option == "--env"} ==
            {"DATABASE_MAX_CONN=256", f"UWZ_HTTP_PORT={metadata['http_port']}"}, f"Incorrect application arguments {case.name}")
    state = read(case / "app_final_state.stdout")
    require(state["ExitCode"] == 0 and not state["OOMKilled"], f"Application exit was unhealthy {case.name}")
    cid = (case / "app_run.stdout").read_text().strip()
    require(cgroup_container(host_app_ns["cgroup"], cid),
            f"Host PID cgroup does not identify the immutable application container {case.name}")
    labels = read(case / "app_ownership.json")["labels"]
    claimed = read(case / "app_verify_ownership.stdout")
    require(re.fullmatch(r"[0-9a-f]{64}", cid) and stop_cmd["argv"][-1] == remove_cmd["argv"][-1] == cid
            and labels["uwz.measurement"] == "sql-pool-dispatch-20261118" and labels["uwz.role"] == "application"
            and re.fullmatch(r"[0-9a-f]{32}", labels["uwz.run-owner"])
            and all(claimed[key] == value for key, value in labels.items()), f"Application ownership mismatch {case.name}")
    before, after = (raw_stats(case, label) for label in ("before", "after"))
    scans = after["seq_scan"] - before["seq_scan"]
    require(before["reset_at"] == after["reset_at"] and (before["idx_scan"] or 0) == (after["idx_scan"] or 0),
            f"Unexpected PostgreSQL index scans or reset {case.name}")
    readiness = read(sorted(case.glob("ready_sql_*.stdout"))[-1])
    require(readiness["tcp_clients"] == WORKERS * 8 and readiness["ssl_clients"] == 0, f"Unexpected SQL pool readiness {case.name}")
    fd_log = (case / "application_limits_and_fds.stdout").read_text()
    require(fd_log.count("anon_inode:[io_uring]") == WORKERS
            and re.search(r"^Max open files\s+524288\s+524288\s+files", fd_log, re.M)
            and re.search(r"^Max locked memory\s+unlimited\s+unlimited\s+bytes", fd_log, re.M), f"Invalid app resources {case.name}")
    raw_log = "\n".join((case / f"app_logs.{stream}").read_text() for stream in ("stdout", "stderr"))
    require(re.findall(r"benchmark SQL workers=(\d+) connections=(\d+)", raw_log) == [("32", "256")]
            and "query timing start worker=" not in raw_log and "diagnostic SQL worker override=" not in raw_log,
            f"Unexpected application startup mode {case.name}")
    route_counts = [tuple(map(int, fields)) for fields in re.findall(
        r"benchmark database rendered_queries=(\d+) empty_fallbacks=(\d+) rejected_responses=(\d+)", raw_log)]
    require(len(route_counts) == WORKERS and all(empty == rejected == 0 for _, empty, rejected in route_counts),
            f"Application route counters are missing or nonzero {case.name}")
    rendered = sum(row[0] for row in route_counts)
    require(summary["rendered_queries"] == rendered and summary["seq_scan_delta"] == scans,
            f"Application or PostgreSQL summary differs from raw evidence {case.name}")
    if fixed:
        completed = fixed_responses(case, rows)
        require(completed == rendered == scans, f"Drained counters do not reconcile {case.name}")
        loads = {}
    else:
        loads = {label: read_window(case, label, seconds, metadata, app_pid, db_pid, cid)
                 for label, seconds in (("warmup", 5), ("timed", 10))}
        require(loads["warmup"]["client_monotonic_ns"][1] <= loads["timed"]["client_monotonic_ns"][0],
                f"Overlapping wrk invocations {case.name}")
        completed = sum(sample["completed"] for sample in loads.values())
        require(completed <= rendered == scans <= completed + 2 * CONNECTIONS, f"Deadline counters do not reconcile {case.name}")
    require(summary["completed"] == completed, f"Client summary does not reconcile {case.name}")
    return {"mode": mode, "wrk": loads, "completed": completed, "rendered": rendered, "seq_scans": scans,
            "rendered_minus_completed": rendered - completed, "items_seq_tup_read_delta": after["seq_tup_read"] - before["seq_tup_read"],
            "clock_binding": {"host": host, "app": app, "host_pid_time_inode_verified": link_verified,
                              "host_pid_time_inode_unavailable_errno": host_app_ns.get("unavailable_time_inode_errno")}}


def file_digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def database_pid(root, fixture_path, metadata):
    fixture = read(fixture_path)
    require(fixture["seed_rows"] == metadata["db_seed_rows"] == 100000
            and fixture["seed_sha256"] == metadata["db_seed_sha256"] == SEED_SHA, "Unexpected database seed")
    digest = file_digest(fixture_path)
    require(any(Path(path).name == "fixture.json" and sha == digest for path, sha in metadata["sha256"].items()),
            "Database fixture digest mismatch")
    cid, actual_image_id, image, pid, bindings, labels = map(json.loads, (root / "db_identity.stdout").read_text().splitlines())
    require(cid == fixture["container"] == metadata["db_container"] and image == fixture["image"] == metadata["db_image"]
            and actual_image_id == (root / "db_expected_image_id.stdout").read_text().strip()
            and pid > 0 and fixture["pg_host_port"] == metadata["pg_host_port"] and fixture["http_port"] == metadata["http_port"]
            and bindings == [{"HostIp": "127.0.0.1", "HostPort": str(fixture["pg_host_port"])}], "Database fixture identity mismatch")
    expected_labels = {"uwz.sql-experiment": fixture["label"], "uwz.role": "database", "uwz.run-token": fixture["owner_token"]}
    require(all(labels[key] == value for key, value in expected_labels.items()), "Database fixture ownership mismatch")
    return pid


def verify(root, items, fixture, executable_paths):
    metadata = read(root / "metadata.json")
    require(metadata["python_monotonic_clock"]["implementation"] == "clock_gettime(CLOCK_MONOTONIC)", "Wrong Python clock")
    require(recorded_clock((root / "host_clock_namespace.txt").read_text()) == metadata["clock_namespace"],
            "Host Linux time namespace differs from raw observation")
    items_rows = [json.loads(line) for line in items.read_text().splitlines() if line]
    rows = {row["id"]: row for row in items_rows}
    require(len(rows) == len(items_rows) == metadata["fixture_rows_exported"], "Incorrect item reference count")
    require((root / "app_final_inventory.stdout").read_text() == "", "Experiment left application containers")
    items_digest = hashlib.sha256(items.read_bytes()).hexdigest()
    require(any(digest == items_digest and Path(path).name == "expected_items.jsonl" for path, digest in metadata["sha256"].items()),
            "PostgreSQL comparison export does not have the measured fingerprint")
    modes = ("control", "candidate")
    identities = metadata["executables"] | {"wrk": metadata["wrk"], "lua": metadata["lua"]}
    require(identities["control"]["sha256"] == CONTROL_SHA and identities["candidate"]["sha256"] != CONTROL_SHA
            and identities["lua"]["sha256"] == LUA_SHA and identities["wrk"]["sha256"] == WRK_SHA,
            "Unexpected control, candidate, client, or Lua fingerprint")
    require(all(metadata["sha256"][identity["path"]] == identity["sha256"] for identity in identities.values()),
            "Inconsistent executable or script digests")
    for mode, path in executable_paths.items():
        require(file_digest(path) == identities[mode]["sha256"], f"Executable or Lua digest mismatch for {mode}")
    elf_sections = re.split(r"^File: (.+)$", (root / "elf.stdout").read_text(), flags=re.M)[1:]
    elf = dict(zip(elf_sections[::2], elf_sections[1::2]))
    for mode in modes:
        body = elf[identities[mode]["path"]]
        require("ELF64" in body and "Advanced Micro Devices X86-64" in body and "INTERP" not in body,
                f"Application {mode} is not the expected x86-64 static ELF mode")
    require(metadata["parameters"] == {"min": 10, "max": 50, "rotating_limits": list(LIMITS), "pipeline_depth": 1}
            and metadata["paired_run_order"] == [list(pair) for pair in PAIR_ORDER], "Unexpected recorded benchmark profile")
    db_pid = database_pid(root, fixture, metadata)
    control_fixed = case_path(root, "control", 0)
    candidate_fixed = case_path(root, "candidate", 0)
    require(read(control_fixed / "app_remove.command.json")["monotonic_after_reap_ns"]
            < read(candidate_fixed / "app_run.command.json")["monotonic_before_spawn_ns"], "Fixed validations overlap or are reversed")
    fixed = {mode: verify_case(case_path(root, mode, 0), mode, True, rows, metadata, db_pid) for mode in modes}
    last_exit = read(candidate_fixed / "app_remove.command.json")["monotonic_after_reap_ns"]
    pairs = []
    for num, order in enumerate(PAIR_ORDER, 1):
        pair = {}
        for mode in order:
            case = case_path(root, mode, num)
            started = read(case / "app_run.command.json")["monotonic_before_spawn_ns"]
            require(last_exit < started, "Paired cases overlap or were not run in the declared order")
            last_exit = read(case / "app_remove.command.json")["monotonic_after_reap_ns"]
            pair[mode] = verify_case(case, mode, False, rows, metadata, db_pid)
        control, candidate = (case_metrics(pair[mode]) for mode in modes)
        pair["candidate_minus_control_percent"] = {metric: 100 * (candidate[metric] / value - 1) for metric, value in control.items()}
        pairs.append(pair)
    metrics = list(case_metrics(pairs[0]["control"]))
    intervals = {mode: {metric: summarize_values([case_metrics(pair[mode])[metric] for pair in pairs]) for metric in metrics}
                 for mode in modes}
    deltas = {metric: summarize_values([pair["candidate_minus_control_percent"][metric] for pair in pairs]) for metric in metrics}
    return {"valid": True, "fixed": fixed, "pairs": pairs, "timed_run_observed_ranges": intervals,
            "paired_candidate_minus_control_percent": deltas, "file_digests_checked": sorted(executable_paths),
            "throughput_threshold_rps": 300000, "throughput_gate_met": intervals["candidate"]["rps"]["median"] > 300000}


def case_metrics(case):
    timed = case["wrk"]["timed"]
    metrics = {key: timed[key] for key in ("rps", *(f"p{p}_us" for p in PERCENTILES))}
    metrics.update({role + "_cpu_usec_per_completed_request": value for role, value in timed["cpu_usec_per_completed_request"].items()})
    return metrics


def summarize_values(values):
    return {"min": min(values), "median": statistics.median(values), "max": max(values)}


def main():
    parser = argparse.ArgumentParser(description="Offline verification of paired SQL dispatch measurements")
    parser.add_argument("measurements", type=Path)
    parser.add_argument("--items", type=Path, required=True)
    parser.add_argument("--fixture", type=Path, required=True)
    for mode in ("control", "candidate", "wrk", "lua"):
        parser.add_argument("--" + mode, type=Path)
    args = parser.parse_args()
    binaries = {mode: getattr(args, mode) for mode in ("control", "candidate", "wrk", "lua") if getattr(args, mode)}
    result = verify(args.measurements, args.items, args.fixture, binaries)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
