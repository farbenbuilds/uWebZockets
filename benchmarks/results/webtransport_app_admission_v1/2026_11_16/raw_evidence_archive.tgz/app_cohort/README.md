# Actual App admission verification checkpoint

This package contains the actual scratch build, C client fixtures, eight-case
Zig driver, historical source snapshots and terminal logs, and the exact
42-file runtime/build source manifest for the reviewed libxev candidate.
The root agent supplies the matching project-source changes and the archived
lsquic candidate separately. Production dependency pins remain unchanged.

Native inputs:

- lsquic: `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c`, clean source at
  `/tmp/uwz-lsquic-wt-streams-20261113`.
- libxev: `5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`, clean source at
  `/tmp/uwz-gro-libxev`. Its exact required source files are included in
  `libxev_source`; `inputs.sha256` verifies those 42 files.
- Zig: 0.16.0. Other C dependencies and package hashes are fixed in
  `harness/build.zig.zon`; all native C/C++ is compiled by Zig.

Replay requires a Linux host with real loopback UDP and io_uring access. The
managed sandbox denied socket creation, so recorded functional runs used the
authorized real-loopback execution context. No callback or drained state is
simulated. Set `UWZ_PROJECT_SOURCE`, `UWZ_LSQUIC_SOURCE`, `UWZ_LIBXEV_SOURCE`,
or `UWZ_ZIG` if the restored sources/compiler have different paths. The script
links an existing project `zig-pkg` directory when available; no package cache
or compiled artifact is archived.

```sh
sh replay.sh Debug
sh replay.sh ReleaseSafe
sh replay.sh ReleaseFast
```

`harness/README.md` describes the ordinary UDP seam, the narrow encrypted
cooldown staging seam, actual App lifecycle drain, protocol assertions, and
the private native receive-credit grant. `evidence.md` records diagnostics
and proof limits. Final mode results and manifests are in `results.md`.

The 124-row before/after manifest is retained for continuity with the earlier
root runs; it covers selected project/runtime inputs, the candidate reference
headers, historical evidence, and the tracked libxev tree. It is not presented
as a complete compiler dependency list. The package-level manifest additionally
hashes every included scratch source, copied native source, log, and provenance
file. The root checkpoint records the complete matching project changes.
