# Native reset after local FIN: source feasibility

Scope: read-only inspection of lsquic candidate commit
`2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c`. No native source change or
runtime verification was performed.

The explicit public `lsquic_stream_reset_at` can queue an ordinary zero-prefix
reset after the local write side has already sent FIN, provided the native
stream object is still valid and the other normal preconditions hold:

- `src/liblsquic/lsquic_stream.c:4811` checks native type, critical stream
  restrictions, close callback completion, previous reset state, connection
  state, live handshake/parameters, header-send state, credit, and final size.
  It does not reject `STREAM_FIN_SENT` or `STREAM_U_WRITE_DONE`.
- The commit path records the combined send offset as immutable reset final
  size, clears pending close bookkeeping, sets reset/write-done state, and
  queues `SMQF_SEND_RST`.
- `src/liblsquic/lsquic_full_conn_ietf.c:3048` sends the queued reset without
  a FIN guard. Its reset generator at line 2608 uses an ordinary RESET_STREAM
  when reliable size is zero, carrying the recorded final size and error.
- On a still-live peer stream, `lsquic_stream_reset_at_in` at stream source
  line 1287 accepts reset after received FIN only when final sizes match.
  Notification at lines 1442-1469 excludes already closed/notified objects,
  rather than excluding prior FIN or application EOF by itself.

This differs from `lsquic_stream_maybe_reset` at line 4688, which suppresses
new reset after FIN/write-done. The explicit backend reset wrapper is the
appropriate path to examine for a late H3_MESSAGE_ERROR (0x10e).

For the planned CloseCapsule trailing-data case, the peer must keep its send
half open after receiving the server FIN. That keeps both native stream
objects valid while the server observes the late incoming bytes and requests
the error reset. Once on_close has completed, the pointer is invalid and the
explicit reset API cannot be used. The server must retain enough parent
receive/context state to detect those bytes after session close.

This establishes source feasibility only. A real packet/callback test must
still prove final-size consistency, native error delivery after FIN, context
lifetime, and unchanged unrelated streams before claiming this case works.
