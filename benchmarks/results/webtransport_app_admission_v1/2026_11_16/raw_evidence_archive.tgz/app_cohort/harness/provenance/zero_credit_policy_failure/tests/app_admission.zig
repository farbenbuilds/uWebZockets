const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const backend = support.webtransport_backend;
const testing = std.testing;

const app_config: support.config.ServerConfig = support.config.default_config.with(.{
    .max_connections = 4,
    .max_datagram_size = 1200,
    .datagram_slots = 4,
});
const App = support.builder.configured_builder(app_config).AppType;
const allowed_origin = "https://localhost";
const allowed_authorization = "Bearer admission-fixture";

/// Fixed callback evidence shared by the real router and datagram endpoint.
const Observation = struct {
    authorization_calls: usize = 0,
    middleware_calls: usize = 0,
    middleware_continues: bool = false,
    datagram_calls: usize = 0,
    response_failed: bool = false,
    datagram_session: u64 = std.math.maxInt(u64),
    datagram_size: usize = 0,
    datagram_bytes: [128]u8 = undefined,
};

/// Registration selects only existing App routes and middleware.
const RouteMode = enum { exact, any_fallback, middleware_success, middleware_success_continue, missing_endpoint };

/// One real header-time rejection with its required HTTP status.
const DenialCase = struct {
    origin: ?[*:0]const u8 = allowed_origin,
    authorization: ?[*:0]const u8 = allowed_authorization,
    duplicate_origin: bool = false,
    mode: RouteMode = .exact,
    status: u32,
    authorization_calls: usize = 0,
};

/// Native reset expectations distinguish rejected requests from queued headers.
const ResetExpectation = struct {
    code: u64,
    forbid_headers: bool = true,
};

/// The ordinary route records whether native cooldown owned its callback.
const CooldownObservation = struct {
    application: *App,
    calls: usize = 0,
    in_cooldown: bool = false,
    reentry_returned: bool = false,
    response_failed: bool = false,
    body_matches: bool = false,
};

fn initialize_app() !App {
    return support.builder.Server.builder(testing.io)
        .with_max_clients(4)
        .with_webtransport_datagrams(1200, 4)
        .build(testing.allocator);
}

fn authorize(context: *anyopaque, request: *support.Request, response: *support.public_api.Response) void {
    const observation: *Observation = @ptrCast(@alignCast(context));
    observation.authorization_calls += 1;
    const origin = request.get_unique_header("origin") orelse "";
    const authorization = request.get_unique_header("authorization") orelse "";
    const status: []const u8 = if (!std.mem.eql(u8, origin, allowed_origin))
        "403 Forbidden"
    else if (!std.mem.eql(u8, authorization, allowed_authorization))
        "401 Unauthorized"
    else
        "200 OK";
    response.end(status, "") catch {
        observation.response_failed = true;
    };
}

fn middleware_success(context: *anyopaque, _: *support.Request, response: *support.public_api.Response) support.radix.MiddlewareResult {
    const observation: *Observation = @ptrCast(@alignCast(context));
    observation.middleware_calls += 1;
    response.end("200 OK", "") catch {
        observation.response_failed = true;
    };
    return if (observation.middleware_continues) .continue_dispatch else .stop;
}

fn datagram(context: *anyopaque, session_id: u64, payload: []const u8) void {
    const observation: *Observation = @ptrCast(@alignCast(context));
    observation.datagram_calls += 1;
    observation.datagram_session = session_id;
    std.debug.assert(payload.len <= observation.datagram_bytes.len);
    @memcpy(observation.datagram_bytes[0..payload.len], payload);
    observation.datagram_size = payload.len;
}

fn cooldown_handler(context: *anyopaque, request: *support.Request, response: *support.public_api.Response) void {
    const observation: *CooldownObservation = @ptrCast(@alignCast(context));
    const engine = &observation.application.quic_transport.?.engine;
    observation.calls += 1;
    observation.in_cooldown = engine.in_cooldown;
    observation.body_matches = std.mem.eql(u8, request.body, "cooldown-body");
    engine.process();
    observation.reentry_returned = true;
    response.end("200 OK", "cooldown-ok") catch {
        observation.response_failed = true;
    };
}

fn listen(application: *App, observation: *Observation, mode: RouteMode) !u16 {
    try application.enable_http3_ephemeral();
    if (mode != .missing_endpoint) _ = try application.datagram_context("/wt", observation, datagram);
    _ = try application.route_context(if (mode == .any_fallback) .any else .connect, "/wt", observation, authorize);
    if (mode == .middleware_success or mode == .middleware_success_continue) {
        observation.middleware_continues = mode == .middleware_success_continue;
        _ = try application.use(observation, middleware_success);
    }
    try application.listen_udp("127.0.0.1", 0);
    try testing.expect(application.quic_transport != null);
    const transport = &application.quic_transport.?;
    try testing.expect(transport.started);
    try testing.expect(transport.read_active);
    try testing.expect(!transport.is_drained());
    try testing.expect(transport.engine.binding != null);
    const port = transport.local_address.ip4.port;
    try testing.expect(port != 0);
    return port;
}

fn destroy_app(application: *App) void {
    if (application.quic_transport) |*transport| {
        transport.shutdown();
        var step: usize = 0;
        while (step < c.UWZ_APP_MAX_STEPS and !transport.is_drained()) : (step += 1) {
            application.loop.get_xev_loop().run(.no_wait) catch |err| {
                std.debug.panic("actual App completion drain failed: {s}", .{@errorName(err)});
            };
        }
        if (!transport.is_drained()) std.debug.panic("actual App completion drain exceeded bound", .{});
        std.debug.assert(transport.close_complete);
        std.debug.assert(!transport.read_active and !transport.timer_active);
        std.debug.assert(!transport.read_cancel_active and !transport.timer_cancel_active);
    }
    application.shutdown() catch |err| {
        std.debug.panic("actual App shutdown failed after transport drain: {s}", .{@errorName(err)});
    };
    application.deinit();
}

fn client_snapshot(client: *c.struct_uwz_app_client) !c.struct_uwz_app_client_snapshot {
    var snapshot: c.struct_uwz_app_client_snapshot = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_observe(client, &snapshot));
    return snapshot;
}

fn response_snapshot(client: *c.struct_uwz_app_client, id: u64) !c.struct_uwz_app_response_snapshot {
    var snapshot: c.struct_uwz_app_response_snapshot = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_response(client, id, &snapshot));
    return snapshot;
}

fn dump_peer_parameters(label: []const u8, native: ?*c.lsquic_conn) void {
    var peer: c.struct_uwz_app_peer_transport_diagnostics = std.mem.zeroes(c.struct_uwz_app_peer_transport_diagnostics);
    const result = c.uwz_app_peer_transport_diagnose(native, &peer);
    std.debug.print("{s} native peer TP result={d} data={d} bidi_local={d} bidi_remote={d} uni={d} streams={d}/{d}\n", .{
        label, result, peer.max_data, peer.bidi_local, peer.bidi_remote, peer.uni, peer.streams_bidi, peer.streams_uni,
    });
}

fn dump_native_stream(label: []const u8, native: ?*c.lsquic_stream) void {
    var stream: c.struct_uwz_app_stream_diagnostics = std.mem.zeroes(c.struct_uwz_app_stream_diagnostics);
    const result = c.uwz_app_stream_diagnose(native, &stream);
    std.debug.print("{s} native stream result={d} send={d}/{d} recv={d}/{d} read={d} window={d} flags=0x{x}/0x{x} header_state={d} buffered={d}\n", .{
        label,              result,                stream.send_offset,  stream.send_limit,  stream.maximum_received,   stream.receive_limit,
        stream.read_offset, stream.receive_window, stream.stream_flags, stream.queue_flags, stream.send_headers_state, stream.buffered_bytes,
    });
}

fn dump_client(client: *c.struct_uwz_app_client) void {
    var observed: c.struct_uwz_app_client_snapshot = std.mem.zeroes(c.struct_uwz_app_client_snapshot);
    const result = c.uwz_app_client_observe(client, &observed);
    std.debug.print("client diagnostics result={d} HS={d} SETTINGS={d} status={d} closed={d} streams={d} UDP={d} config WT={d} data={d} bidi_local={d} bidi_remote={d} uni={d}\n", .{
        result,                       observed.handshake_complete,    observed.settings_callbacks,     observed.connection_status,
        observed.connection_closed,   observed.stream_callbacks,      observed.received_datagrams,     observed.configured_wt,
        observed.configured_max_data, observed.configured_bidi_local, observed.configured_bidi_remote, observed.configured_uni,
    });
    std.debug.print("client close status={d} remote_app={d} remote_code=0x{x} remote={s} local={s}\n", .{
        observed.closed_status,                               observed.remote_app_error, observed.remote_error_code, observed.remote_reason[0..observed.remote_reason_size],
        observed.local_reason[0..observed.local_reason_size],
    });
    dump_peer_parameters("client", c.uwz_app_client_connection(client));
    var index: usize = 0;
    while (index < observed.stream_callbacks and index < c.UWZ_APP_MAX_STREAMS) : (index += 1) {
        const id: u64 = @intCast(index * 4);
        var response: c.struct_uwz_app_response_snapshot = std.mem.zeroes(c.struct_uwz_app_response_snapshot);
        if (c.uwz_app_client_response(client, id, &response) != 0) continue;
        std.debug.print("client stream {d} status={d} headers={d} FIN={d} reset={d}/{d} errors={d}/{d}\n", .{
            id,                       response.status_code,     response.header_callbacks,    response.fin_received,
            response.reset_events[0], response.reset_events[1], response.reset_error_code[0], response.reset_error_code[1],
        });
        dump_native_stream("client", c.uwz_app_client_stream(client, id));
    }
}

fn dump_timeout(application: *App, client: *c.struct_uwz_app_client, observed: *const Observation) void {
    dump_client(client);
    if (application.quic_transport) |*transport| {
        const engine = &transport.engine;
        std.debug.print("server diagnostics connections={d} HTTP={d} headers={d} auth={d} depth={d} cooldown={}\n", .{
            engine.connections.pool.count_active(), engine.stream_pool.count_active(), engine.header_pool.count_active(),
            observed.authorization_calls,           engine.callback_depth,             engine.in_cooldown,
        });
        for (engine.connections.pool.storage, 0..) |*connection, index| {
            if (!engine.connections.pool.is_active(index)) continue;
            std.debug.print("server connection {d} generation={d} streams={d} peer={} sessions={d}/{s} route={?} parent={?}\n", .{
                index,                            connection.handle.generation,            connection.stream_count,  connection.peer != null,
                connection.sessions.open_count(), @tagName(connection.sessions.states[0]), connection.session_route, connection.session_stream,
            });
            dump_peer_parameters("server", connection.native);
        }
        for (engine.stream_contexts, 0..) |*context, index| {
            if (!engine.stream_pool.is_active(index)) continue;
            std.debug.print("server sidecar {d} role={s} phase={s} status={d} headers_sent={} pending_reset={?} session={}\n", .{
                index,                     @tagName(context.state.role), @tagName(context.http.response_phase), context.http.response_status_code,
                context.http.headers_sent, context.pending_reset,        context.state.session != null,
            });
            dump_native_stream("server", context.http.stream);
        }
    }
}

fn pump(application: *App, clients: []const *c.struct_uwz_app_client) !void {
    for (clients) |client| {
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_process(client));
        try testing.expect(c.uwz_app_client_send_udp(client) >= 0);
    }
    try application.loop.get_xev_loop().run(.no_wait);
    application.quic_transport.?.engine.process();
    for (clients) |client| try testing.expect(c.uwz_app_client_receive_udp(client) >= 0);
}

fn connection_index(application: *App, client: *c.struct_uwz_app_client) !usize {
    const table = &application.quic_transport.?.engine.connections;
    const port = c.uwz_app_client_port(client);
    for (table.pool.storage, 0..) |connection, index| {
        if (!table.pool.is_active(index)) continue;
        if (c.uwz_app_connection_peer_port(connection.native) == port) return index;
    }
    return error.MissingConnection;
}

fn stream_context_index(application: *App, client: *c.struct_uwz_app_client, id: u64) !usize {
    const engine = &application.quic_transport.?.engine;
    const conn_index = try connection_index(application, client);
    const native_connection = engine.connections.pool.storage[conn_index].native;
    for (engine.stream_pool.storage, 0..) |*http, index| {
        if (!engine.stream_pool.is_active(index)) continue;
        if (c.lsquic_stream_id(http.stream) != id) continue;
        if (c.lsquic_stream_conn(http.stream) == native_connection) return index;
    }
    return error.MissingStreamContext;
}

fn handshake(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client) !void {
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_connect(client));
    var step: usize = 0;
    while (step < c.UWZ_APP_MAX_STEPS) : (step += 1) {
        try pump(application, clients);
        const observed = try client_snapshot(client);
        if (observed.handshake_complete == 0 or observed.settings_callbacks == 0) continue;
        const index = connection_index(application, client) catch continue;
        const connection = &application.quic_transport.?.engine.connections.pool.storage[index];
        if (connection.peer == null) continue;
        try testing.expectEqual(@as(c_uint, 1), observed.settings_callbacks);
        try testing.expect(observed.received_datagrams > 0);
        try testing.expectEqual(@as(c_uint, 0), observed.typed_callbacks);
        try testing.expectEqual(@as(usize, 0), connection.sessions.open_count());
        var peer: backend.Peer = .{};
        try testing.expectEqual(backend.QueryResult.ok, backend.read_peer(c.uwz_app_client_connection(client), &peer));
        try testing.expect(backend.peer_requirements_met(peer, .client));
        return;
    }
    return error.AppHandshakeTimeout;
}

fn open_connect(client: *c.struct_uwz_app_client, denial: DenialCase) !u64 {
    var input: c.struct_uwz_app_connect_request = .{
        .origin = if (denial.origin) |value| value else null,
        .authorization = if (denial.authorization) |value| value else null,
        .duplicate_origin = @intFromBool(denial.duplicate_origin),
    };
    const id = c.uwz_app_client_open_connect(client, &input);
    try testing.expect(id != std.math.maxInt(u64));
    return id;
}

fn await_status(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, id: u64, status: u32) !c.struct_uwz_app_response_snapshot {
    var step: usize = 0;
    while (step < c.UWZ_APP_MAX_STEPS) : (step += 1) {
        try pump(application, clients);
        const response = try response_snapshot(client, id);
        if (response.header_callbacks == 0) continue;
        try testing.expectEqual(@as(c_uint, 1), response.header_callbacks);
        try testing.expectEqual(status, response.status_code);
        return response;
    }
    return error.AppConnectResponseTimeout;
}

fn await_rejection_fin(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, id: u64) !void {
    var step: usize = 0;
    while (step < c.UWZ_APP_MAX_STEPS) : (step += 1) {
        try pump(application, clients);
        const response = try response_snapshot(client, id);
        if (response.fin_received != 0) return;
    }
    return error.AppRejectionFinTimeout;
}

fn await_reset_error(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, id: u64, expected: ResetExpectation) !void {
    var step: usize = 0;
    while (step < c.UWZ_APP_MAX_STEPS) : (step += 1) {
        try pump(application, clients);
        const response = try response_snapshot(client, id);
        if (response.reset_events[0] == 0) continue;
        try testing.expectEqual(@as(c_uint, 1), response.reset_events[0]);
        try testing.expectEqual(@as(c_int, c.LSQUIC_SERR_AVAILABLE), response.reset_error_status[0]);
        try testing.expectEqual(expected.code, response.reset_error_code[0]);
        if (expected.forbid_headers) try testing.expectEqual(@as(c_uint, 0), response.header_callbacks);
        return;
    }
    return error.AppResetErrorTimeout;
}

fn accept_session(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client) !usize {
    const id = try open_connect(client, .{ .status = 200 });
    try testing.expectEqual(@as(u64, 0), id);
    const response = try await_status(application, client, clients, id, 200);
    try testing.expectEqual(@as(c_uint, 0), response.fin_received);
    try testing.expectEqual(@as(c_uint, 0), response.close_callbacks);
    try testing.expectEqual(backend.CreateResult.ok, backend.accept_connect(c.uwz_app_client_stream(client, id)));
    const index = try connection_index(application, client);
    const connection = &application.quic_transport.?.engine.connections.pool.storage[index];
    try testing.expectEqual(@as(usize, 1), connection.sessions.open_count());
    try testing.expectEqual(.established, connection.sessions.states[0]);
    try testing.expect(connection.session_route != null);
    try testing.expect(connection.session_stream != null);
    const stream_context = &application.quic_transport.?.engine.stream_contexts[connection.session_stream.?];
    try testing.expect(stream_context.state.session != null);
    try testing.expect(stream_context.state.lease.active);
    var stream_info: backend.StreamInfo = .{};
    try testing.expectEqual(backend.QueryResult.ok, backend.read_stream(stream_context.http.stream, &stream_info));
    try testing.expectEqual(backend.Association.connect, stream_info.association);
    try testing.expectEqual(@as(u64, 0), stream_info.session_id);
    const native_stream_context = c.lsquic_stream_get_ctx(stream_context.http.stream) orelse return error.MissingNativeStreamContext;
    try testing.expectEqual(@intFromPtr(stream_context), @intFromPtr(native_stream_context));
    const native_context = c.lsquic_conn_get_ctx(connection.native) orelse return error.MissingNativeContext;
    try testing.expectEqual(@intFromPtr(connection), @intFromPtr(native_context));
    for (0..20) |_| try pump(application, clients);
    const held_response = try response_snapshot(client, id);
    try testing.expectEqual(@as(c_uint, 0), held_response.fin_received);
    try testing.expectEqual(@as(c_uint, 0), held_response.close_callbacks);
    try testing.expectEqual(@as(usize, 1), connection.sessions.open_count());
    return index;
}

fn abort_connection(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client) !void {
    const index = try connection_index(application, client);
    const engine = &application.quic_transport.?.engine;
    const handle = engine.connections.pool.storage[index].handle;
    c.lsquic_conn_abort(engine.connections.pool.storage[index].native);
    var step: usize = 0;
    while (step < c.UWZ_APP_MAX_STEPS) : (step += 1) {
        try pump(application, clients);
        if (engine.connections.find(handle) != null) continue;
        try testing.expectEqual(@as(usize, 0), engine.connections.pool.storage[index].sessions.open_count());
        try testing.expectEqual(@as(usize, 0), application.datagram_rings[index].len());
        return;
    }
    return error.AppConnectionAbortTimeout;
}

fn run_denial(denial: DenialCase) !void {
    var application = try initialize_app();
    defer destroy_app(&application);
    var observed: Observation = .{};
    const port = try listen(&application, &observed, denial.mode);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    errdefer dump_timeout(&application, client, &observed);
    const clients = [_]*c.struct_uwz_app_client{client};
    try handshake(&application, client, &clients);
    const id = try open_connect(client, denial);
    _ = try await_status(&application, client, &clients, id, denial.status);
    try await_rejection_fin(&application, client, &clients, id);
    const index = try connection_index(&application, client);
    const connection = &application.quic_transport.?.engine.connections.pool.storage[index];
    try testing.expectEqual(@as(usize, 0), connection.sessions.open_count());
    try testing.expectEqual(denial.authorization_calls, observed.authorization_calls);
    const expected_middleware_calls: usize = if (denial.mode == .middleware_success or denial.mode == .middleware_success_continue) 1 else 0;
    try testing.expectEqual(expected_middleware_calls, observed.middleware_calls);
    try testing.expect(!observed.response_failed);
    try abort_connection(&application, client, &clients);
}

test "actual App admits authorized WebTransport CONNECT before client EOF" {
    var application = try initialize_app();
    defer destroy_app(&application);
    var observed: Observation = .{};
    const port = try listen(&application, &observed, .exact);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    errdefer dump_timeout(&application, client, &observed);
    const clients = [_]*c.struct_uwz_app_client{client};
    try handshake(&application, client, &clients);
    _ = try accept_session(&application, client, &clients);
    try testing.expectEqual(@as(usize, 1), observed.authorization_calls);
    try testing.expect(!observed.response_failed);
    try abort_connection(&application, client, &clients);
}

test "actual App rejects missing duplicate forbidden Origin and unauthorized CONNECT" {
    const cases = [_]DenialCase{
        .{ .origin = null, .status = 400 },
        .{ .origin = "", .status = 400 },
        .{ .duplicate_origin = true, .status = 400 },
        .{ .origin = "https://forbidden.example", .status = 403, .authorization_calls = 1 },
        .{ .authorization = null, .status = 401, .authorization_calls = 1 },
    };
    for (cases) |denial| try run_denial(denial);
}

test "actual App rejects fallback middleware success and missing datagram endpoint" {
    const cases = [_]DenialCase{
        .{ .mode = .any_fallback, .status = 405 },
        .{ .mode = .middleware_success, .status = 403 },
        .{ .mode = .middleware_success_continue, .status = 403 },
        .{ .mode = .missing_endpoint, .status = 404 },
    };
    for (cases) |denial| try run_denial(denial);
}

test "actual App limits one session per connection and separates session zero on two connections" {
    var application = try initialize_app();
    defer destroy_app(&application);
    var observed: Observation = .{};
    const port = try listen(&application, &observed, .exact);
    const first = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(first);
    errdefer dump_timeout(&application, first, &observed);
    const second = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(second);
    errdefer dump_client(second);
    const clients = [_]*c.struct_uwz_app_client{ first, second };
    try handshake(&application, first, clients[0..1]);
    const first_index = try accept_session(&application, first, clients[0..1]);
    const calls_before_excessive = observed.authorization_calls;
    const duplicate = try open_connect(first, .{ .status = 0 });
    try testing.expectEqual(@as(u64, 4), duplicate);
    try await_reset_error(&application, first, clients[0..1], duplicate, .{ .code = 0x10b });
    try testing.expectEqual(calls_before_excessive, observed.authorization_calls);
    try testing.expectEqual(@as(usize, 1), application.quic_transport.?.engine.connections.pool.storage[first_index].sessions.open_count());
    try handshake(&application, second, &clients);
    const second_index = try accept_session(&application, second, &clients);
    try testing.expect(first_index != second_index);
    try testing.expectEqual(@as(usize, 2), application.quic_transport.?.engine.connections.pool.count_active());
    try abort_connection(&application, first, &clients);
    try testing.expectEqual(@as(usize, 1), application.quic_transport.?.engine.connections.pool.storage[second_index].sessions.open_count());
    try abort_connection(&application, second, &clients);
}

test "actual App resets extended CONNECT from peer without WT setting before authorization" {
    var application = try initialize_app();
    defer destroy_app(&application);
    var observed: Observation = .{};
    const port = try listen(&application, &observed, .exact);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_NO_WT) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    errdefer dump_timeout(&application, client, &observed);
    const clients = [_]*c.struct_uwz_app_client{client};
    try handshake(&application, client, &clients);
    const index = try connection_index(&application, client);
    const connection = &application.quic_transport.?.engine.connections.pool.storage[index];
    try testing.expect(!connection.peer.?.wt_enabled);
    try testing.expect(connection.peer.?.quic_datagram);
    try testing.expect(connection.peer.?.reliable_reset);
    const id = try open_connect(client, .{ .status = 0 });
    try await_reset_error(&application, client, &clients, id, .{ .code = 0x10e });
    try testing.expectEqual(@as(usize, 0), observed.authorization_calls);
    try testing.expectEqual(@as(usize, 0), connection.sessions.open_count());
    try abort_connection(&application, client, &clients);
}

test "actual App cooldown invokes ordinary callback and guards public process reentry" {
    var application = try initialize_app();
    defer destroy_app(&application);
    var observed: Observation = .{};
    var cooldown: CooldownObservation = .{ .application = &application };
    _ = try application.route_context(.post, "/cooldown", &cooldown, cooldown_handler);
    const port = try listen(&application, &observed, .exact);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    errdefer dump_timeout(&application, client, &observed);
    const clients = [_]*c.struct_uwz_app_client{client};
    try handshake(&application, client, &clients);
    const body = "cooldown-body";
    const id = c.uwz_app_client_open_post(client, "/cooldown", body.len);
    try testing.expect(id != std.math.maxInt(u64));
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, body.ptr, 1, 0));
    const engine = &application.quic_transport.?.engine;
    var step: usize = 0;
    while (step < c.UWZ_APP_MAX_STEPS) : (step += 1) {
        try pump(&application, &clients);
        const index = stream_context_index(&application, client, id) catch continue;
        if (engine.stream_pool.storage[index].body_length == 1) break;
    }
    try testing.expect(step < c.UWZ_APP_MAX_STEPS);
    try testing.expectEqual(@as(usize, 0), cooldown.calls);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, body[1..].ptr, body.len - 1, 1));
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_process(client));
    // Stage actual encrypted packets without the public process call that would
    // dispatch the ready route before native cooldown begins processing.
    try testing.expect(c.uwz_app_client_stage_pending_packets(client, engine.engine, engine) > 0);
    try testing.expectEqual(@as(usize, 0), cooldown.calls);
    try testing.expect(!engine.in_cooldown);
    engine.cooldown();
    try testing.expectEqual(@as(usize, 1), cooldown.calls);
    try testing.expect(cooldown.in_cooldown);
    try testing.expect(cooldown.reentry_returned);
    try testing.expect(cooldown.body_matches);
    try testing.expect(!cooldown.response_failed);
    try testing.expect(!engine.in_cooldown);
    _ = try await_status(&application, client, &clients, id, 200);
    try await_rejection_fin(&application, client, &clients, id);
    const response = try response_snapshot(client, id);
    try testing.expectEqualSlices(u8, "cooldown-ok", response.bytes[0..response.received]);
}

test "actual App retries blocked message reset after real peer response credit" {
    var application = try initialize_app();
    defer destroy_app(&application);
    var observed: Observation = .{};
    const port = try listen(&application, &observed, .exact);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_ZERO_RESPONSE_CREDIT) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    errdefer dump_timeout(&application, client, &observed);
    const clients = [_]*c.struct_uwz_app_client{client};
    try handshake(&application, client, &clients);
    const id = try open_connect(client, .{ .status = 0 });
    // A prohibited HTTP/2 stream-credit capsule travels as actual HTTP DATA.
    const prohibited = [_]u8{ 0x99, 0x0b, 0x4d, 0x3e, 0 };
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, &prohibited, prohibited.len, 0));
    const engine = &application.quic_transport.?.engine;
    const conn_index = try connection_index(&application, client);
    var context_index: usize = 0;
    var step: usize = 0;
    while (step < c.UWZ_APP_MAX_STEPS) : (step += 1) {
        try pump(&application, &clients);
        context_index = stream_context_index(&application, client, id) catch continue;
        if (engine.stream_contexts[context_index].pending_reset == null) continue;
        break;
    }
    try testing.expect(step < c.UWZ_APP_MAX_STEPS);
    const context = &engine.stream_contexts[context_index];
    try testing.expectEqual(@as(u64, 0x10e), context.pending_reset.?);
    try testing.expect(context.state.session == null);
    try testing.expectEqual(@as(usize, 0), engine.connections.pool.storage[conn_index].sessions.open_count());
    try testing.expectEqual(@as(usize, 1), observed.authorization_calls);
    try testing.expectEqual(@as(u64, 0), c.uwz_app_stream_send_limit(context.http.stream));
    const before_credit = try response_snapshot(client, id);
    try testing.expectEqual(@as(c_uint, 0), before_credit.header_callbacks);
    try testing.expectEqual(@as(c_uint, 0), before_credit.reset_events[0]);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_grant_response_credit(client, id, 65536));
    try await_reset_error(&application, client, &clients, id, .{ .code = 0x10e, .forbid_headers = false });
    step = 0;
    while (step < c.UWZ_APP_MAX_STEPS) : (step += 1) {
        try pump(&application, &clients);
        if (engine.stream_pool.count_active() == 0 and engine.header_pool.count_active() == 0) break;
    }
    try testing.expect(step < c.UWZ_APP_MAX_STEPS);
    try testing.expectEqual(@as(usize, 0), engine.connections.pool.storage[conn_index].sessions.open_count());
    try abort_connection(&application, client, &clients);
}
