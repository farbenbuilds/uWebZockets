/* Copyright (c) 2026 uWebZockets contributors. See LICENSE. */
#ifndef UWZ_APP_CLIENT_H
#define UWZ_APP_CLIENT_H

#include <stddef.h>
#include <stdint.h>
#include "lsquic.h"

struct uwz_app_client;

struct uwz_app_connect_request {
    const char *origin;
    const char *authorization;
    unsigned duplicate_origin;
};

enum {
    UWZ_APP_MAX_STEPS = 20000,
    UWZ_APP_MAX_STREAMS = 8,
    UWZ_APP_MAX_BODY = 512,
};

struct uwz_app_client_snapshot {
    unsigned handshake_complete;
    unsigned settings_callbacks;
    unsigned connection_closed;
    unsigned stream_callbacks;
    unsigned typed_callbacks;
    unsigned received_datagrams;
    unsigned datagrams_written;
    unsigned datagrams_received;
};

struct uwz_app_response_snapshot {
    uint64_t stream_id;
    uint64_t reset_error_code[2];
    size_t received;
    unsigned header_callbacks;
    unsigned status_code;
    unsigned status_ok;
    unsigned fin_received;
    unsigned close_callbacks;
    unsigned reset_callbacks;
    unsigned reset_events[2];
    int reset_error_status[2];
    unsigned char bytes[UWZ_APP_MAX_BODY];
};

/* No global init/cleanup: the actual project engine owns that reference. */
struct uwz_app_client *uwz_app_client_create(uint16_t server_port);
void uwz_app_client_destroy(struct uwz_app_client *);
int uwz_app_client_connect(struct uwz_app_client *);
int uwz_app_client_process(struct uwz_app_client *);
int uwz_app_client_send_udp(struct uwz_app_client *);
int uwz_app_client_receive_udp(struct uwz_app_client *);
uint16_t uwz_app_client_port(const struct uwz_app_client *);
int uwz_app_client_observe(const struct uwz_app_client *, struct uwz_app_client_snapshot *);
int uwz_app_client_response(const struct uwz_app_client *, uint64_t,
                               struct uwz_app_response_snapshot *);
uint64_t uwz_app_client_open_connect(struct uwz_app_client *,
                                    const struct uwz_app_connect_request *);
lsquic_conn_t *uwz_app_client_connection(struct uwz_app_client *);
lsquic_stream_t *uwz_app_client_stream(struct uwz_app_client *, uint64_t stream_id);
uint16_t uwz_app_connection_peer_port(lsquic_conn_t *);
int uwz_app_client_write(struct uwz_app_client *, uint64_t,
                            const unsigned char *, size_t, int fin);
int uwz_app_client_queue_datagram(struct uwz_app_client *, const unsigned char *, size_t);

int uwz_app_udp_socket_new(void);
uint16_t uwz_app_udp_socket_port(int fd);
void uwz_app_udp_socket_close(int fd);

#endif
