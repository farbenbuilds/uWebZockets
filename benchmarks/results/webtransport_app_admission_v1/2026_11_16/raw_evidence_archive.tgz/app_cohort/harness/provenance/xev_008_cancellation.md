# Real io_uring poll cancellation prerequisite

The first actual App Debug RED terminated with zero of four tests passing.
The positive request reached its intended missing-admission response timeout.
During real deferred teardown, the published libxev input also reported
unexpected errno 125 from `Completion.invoke`'s poll branch. The original
inputs, manifest, and unmodified log remain in `actual_first_red/`.

The cancellation path is:

1. Actual `quic_transport.start` arms a Linux UDP readiness poll.
2. Harness teardown calls actual `transport.shutdown`, then `close_socket`.
3. `close_socket` uses `core_loop.cancel` on the active read completion and
   starts the actual socket close; the timer has its independent cancellation.
4. The kernel delivers ECANCELED for the io_uring poll. Published
   `c49f6dfb83038c146232472c063e4b2681d098d8` maps every negative poll result
   through `posix.unexpectedErrno` at backend `io_uring.zig:695`.
5. That helper emits the diagnostic before the transport callback can inspect
   the result. The transport clears `read_active` and disarms on shutdown;
   setting any completion or drain flag manually would bypass the real path.

The reviewed XEV-008 proposal is the clean local libxev commit
`5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`. It is exactly one commit beyond
the published pin. Its only runtime change adds `.CANCELED => error.Canceled`
to that exact poll result switch. It also adds a native regression requiring
one poll callback, one cancellation callback, typed `Canceled`, dead completion
states, zero active operations, and an empty submissions queue. The commit
message contains the ledger invariant and prior review/test evidence; this
agent has not rerun those checks.

The scratch-only `-Dlibxev-source` selects that tree's actual `src/main.zig`
under the unchanged production `src/core/xev.zig` shim. The io_uring backend,
actual cancels, and all bounded drain assertions remain active. No error is
ignored or converted by the harness. Omitting the option still selects the
published dependency; its failed RED row remains failed. The maintained fork,
fetched package inputs, production manifests, and pins are untouched.

`xev_candidate_head.txt`, `xev_candidate_status.txt`, and
`xev_candidate_sources.sha256` record the full HEAD, clean status, and tracked
source/build-input hashes. The source manifest is relative to
`/tmp/uwz-gro-libxev`. `xev_008_review.diff` records the reviewed commit range
for provenance and is never applied by the build.

The coordinator is being implemented independently by the root agent. Current
root source hashes must be refreshed only after its next explicit freeze;
the preserved RED manifest describes the earlier source row. No passing
admission, cancellation, or full-client interoperability result is inferred
from this static diagnosis.
