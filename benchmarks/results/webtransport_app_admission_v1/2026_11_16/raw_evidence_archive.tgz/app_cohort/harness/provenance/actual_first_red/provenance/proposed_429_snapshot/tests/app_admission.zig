const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const backend = support.webtransport_backend;
const testing = std.testing;

const app_config: support.config.ServerConfig = support.config.default_config.with(.{
    .max_connections = 4,
    .max_datagram_size = 1200,
    .datagram_slots = 4,
});
const App = support.builder.configured_builder(app_config).AppType;
const allowed_origin = "https://localhost";
const allowed_authorization = "Bearer admission-fixture";

/// Fixed callback evidence shared by the real router and datagram endpoint.
const Observation = struct {
    authorization_calls: usize = 0,
    middleware_calls: usize = 0,
    datagram_calls: usize = 0,
    response_failed: bool = false,
    datagram_session: u64 = std.math.maxInt(u64),
    datagram_size: usize = 0,
    datagram_bytes: [128]u8 = undefined,
};

/// Registration selects only existing App routes and middleware.
const RouteMode = enum { exact, any_fallback, middleware_success, missing_endpoint };

/// One real header-time rejection with its required HTTP status.
const DenialCase = struct {
    origin: ?[*:0]const u8 = allowed_origin,
    authorization: ?[*:0]const u8 = allowed_authorization,
    duplicate_origin: bool = false,
    mode: RouteMode = .exact,
    status: u32,
    authorization_calls: usize = 0,
};

fn initialize_app() !App {
    return support.builder.Server.builder(testing.io)
        .with_max_clients(4)
        .with_webtransport_datagrams(1200, 4)
        .build(testing.allocator);
}

fn authorize(context: *anyopaque, request: *support.Request, response: *support.public_api.Response) void {
    const observation: *Observation = @ptrCast(@alignCast(context));
    observation.authorization_calls += 1;
    const origin = request.get_unique_header("origin") orelse "";
    const authorization = request.get_unique_header("authorization") orelse "";
    const status: []const u8 = if (!std.mem.eql(u8, origin, allowed_origin))
        "403 Forbidden"
    else if (!std.mem.eql(u8, authorization, allowed_authorization))
        "401 Unauthorized"
    else
        "200 OK";
    response.end(status, "") catch {
        observation.response_failed = true;
    };
}

fn middleware_success(context: *anyopaque, _: *support.Request, response: *support.public_api.Response) support.radix.MiddlewareResult {
    const observation: *Observation = @ptrCast(@alignCast(context));
    observation.middleware_calls += 1;
    response.end("200 OK", "") catch {
        observation.response_failed = true;
    };
    return .stop;
}

fn datagram(context: *anyopaque, session_id: u64, payload: []const u8) void {
    const observation: *Observation = @ptrCast(@alignCast(context));
    observation.datagram_calls += 1;
    observation.datagram_session = session_id;
    std.debug.assert(payload.len <= observation.datagram_bytes.len);
    @memcpy(observation.datagram_bytes[0..payload.len], payload);
    observation.datagram_size = payload.len;
}

fn listen(application: *App, observation: *Observation, mode: RouteMode) !u16 {
    try application.enable_http3_ephemeral();
    if (mode != .missing_endpoint) _ = try application.datagram_context("/wt", observation, datagram);
    _ = try application.route_context(if (mode == .any_fallback) .any else .connect, "/wt", observation, authorize);
    if (mode == .middleware_success) _ = try application.use(observation, middleware_success);
    try application.listen_udp("127.0.0.1", 0);
    try testing.expect(application.quic_transport != null);
    const transport = &application.quic_transport.?;
    try testing.expect(transport.started);
    try testing.expect(transport.read_active);
    try testing.expect(!transport.is_drained());
    try testing.expect(transport.engine.binding != null);
    const port = transport.local_address.ip4.port;
    try testing.expect(port != 0);
    return port;
}

fn destroy_app(application: *App) void {
    if (application.quic_transport) |*transport| {
        transport.shutdown();
        var step: usize = 0;
        while (step < c.UWZ_APP_MAX_STEPS and !transport.is_drained()) : (step += 1) {
            application.loop.get_xev_loop().run(.no_wait) catch |err| {
                std.debug.panic("actual App completion drain failed: {s}", .{@errorName(err)});
            };
        }
        if (!transport.is_drained()) std.debug.panic("actual App completion drain exceeded bound", .{});
        std.debug.assert(transport.close_complete);
        std.debug.assert(!transport.read_active and !transport.timer_active);
        std.debug.assert(!transport.read_cancel_active and !transport.timer_cancel_active);
    }
    application.shutdown() catch |err| {
        std.debug.panic("actual App shutdown failed after transport drain: {s}", .{@errorName(err)});
    };
    application.deinit();
}

fn client_snapshot(client: *c.struct_uwz_app_client) !c.struct_uwz_app_client_snapshot {
    var snapshot: c.struct_uwz_app_client_snapshot = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_observe(client, &snapshot));
    return snapshot;
}

fn response_snapshot(client: *c.struct_uwz_app_client, id: u64) !c.struct_uwz_app_response_snapshot {
    var snapshot: c.struct_uwz_app_response_snapshot = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_response(client, id, &snapshot));
    return snapshot;
}

fn pump(application: *App, clients: []const *c.struct_uwz_app_client) !void {
    for (clients) |client| {
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_process(client));
        try testing.expect(c.uwz_app_client_send_udp(client) >= 0);
    }
    try application.loop.get_xev_loop().run(.no_wait);
    application.quic_transport.?.engine.process();
    for (clients) |client| try testing.expect(c.uwz_app_client_receive_udp(client) >= 0);
}

fn connection_index(application: *App, client: *c.struct_uwz_app_client) !usize {
    const table = &application.quic_transport.?.engine.connections;
    const port = c.uwz_app_client_port(client);
    for (table.pool.storage, 0..) |connection, index| {
        if (!table.pool.is_active(index)) continue;
        if (c.uwz_app_connection_peer_port(connection.native) == port) return index;
    }
    return error.MissingConnection;
}

fn handshake(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client) !void {
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_connect(client));
    var step: usize = 0;
    while (step < c.UWZ_APP_MAX_STEPS) : (step += 1) {
        try pump(application, clients);
        const observed = try client_snapshot(client);
        if (observed.handshake_complete == 0 or observed.settings_callbacks == 0) continue;
        const index = connection_index(application, client) catch continue;
        const connection = &application.quic_transport.?.engine.connections.pool.storage[index];
        if (connection.peer == null) continue;
        try testing.expectEqual(@as(c_uint, 1), observed.settings_callbacks);
        try testing.expect(observed.received_datagrams > 0);
        try testing.expectEqual(@as(c_uint, 0), observed.typed_callbacks);
        try testing.expectEqual(@as(usize, 0), connection.sessions.open_count());
        var peer: backend.Peer = .{};
        try testing.expectEqual(backend.QueryResult.ok, backend.read_peer(c.uwz_app_client_connection(client), &peer));
        try testing.expect(backend.peer_requirements_met(peer, .client));
        return;
    }
    return error.AppHandshakeTimeout;
}

fn open_connect(client: *c.struct_uwz_app_client, denial: DenialCase) !u64 {
    var input: c.struct_uwz_app_connect_request = .{
        .origin = if (denial.origin) |value| value else null,
        .authorization = if (denial.authorization) |value| value else null,
        .duplicate_origin = @intFromBool(denial.duplicate_origin),
    };
    const id = c.uwz_app_client_open_connect(client, &input);
    try testing.expect(id != std.math.maxInt(u64));
    return id;
}

fn await_status(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, id: u64, status: u32) !c.struct_uwz_app_response_snapshot {
    var step: usize = 0;
    while (step < c.UWZ_APP_MAX_STEPS) : (step += 1) {
        try pump(application, clients);
        const response = try response_snapshot(client, id);
        if (response.header_callbacks == 0) continue;
        try testing.expectEqual(@as(c_uint, 1), response.header_callbacks);
        try testing.expectEqual(status, response.status_code);
        return response;
    }
    return error.AppConnectResponseTimeout;
}

fn await_rejection_fin(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, id: u64) !void {
    var step: usize = 0;
    while (step < c.UWZ_APP_MAX_STEPS) : (step += 1) {
        try pump(application, clients);
        const response = try response_snapshot(client, id);
        if (response.fin_received != 0) return;
    }
    return error.AppRejectionFinTimeout;
}

fn accept_session(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client) !usize {
    const id = try open_connect(client, .{ .status = 200 });
    try testing.expectEqual(@as(u64, 0), id);
    const response = try await_status(application, client, clients, id, 200);
    try testing.expectEqual(@as(c_uint, 0), response.fin_received);
    try testing.expectEqual(@as(c_uint, 0), response.close_callbacks);
    try testing.expectEqual(backend.CreateResult.ok, backend.accept_connect(c.uwz_app_client_stream(client, id)));
    const index = try connection_index(application, client);
    const connection = &application.quic_transport.?.engine.connections.pool.storage[index];
    try testing.expectEqual(@as(usize, 1), connection.sessions.open_count());
    try testing.expectEqual(.established, connection.sessions.states[0]);
    try testing.expect(connection.session_route != null);
    try testing.expect(connection.session_stream != null);
    const stream_context = &application.quic_transport.?.engine.stream_contexts[connection.session_stream.?];
    try testing.expect(stream_context.state.session != null);
    try testing.expect(stream_context.state.lease.active);
    var stream_info: backend.StreamInfo = .{};
    try testing.expectEqual(backend.QueryResult.ok, backend.read_stream(stream_context.http.stream, &stream_info));
    try testing.expectEqual(backend.Association.connect, stream_info.association);
    try testing.expectEqual(@as(u64, 0), stream_info.session_id);
    const native_stream_context = c.lsquic_stream_get_ctx(stream_context.http.stream) orelse return error.MissingNativeStreamContext;
    try testing.expectEqual(@intFromPtr(stream_context), @intFromPtr(native_stream_context));
    const native_context = c.lsquic_conn_get_ctx(connection.native) orelse return error.MissingNativeContext;
    try testing.expectEqual(@intFromPtr(connection), @intFromPtr(native_context));
    for (0..20) |_| try pump(application, clients);
    const held_response = try response_snapshot(client, id);
    try testing.expectEqual(@as(c_uint, 0), held_response.fin_received);
    try testing.expectEqual(@as(c_uint, 0), held_response.close_callbacks);
    try testing.expectEqual(@as(usize, 1), connection.sessions.open_count());
    return index;
}

fn abort_connection(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client) !void {
    const index = try connection_index(application, client);
    const engine = &application.quic_transport.?.engine;
    const handle = engine.connections.pool.storage[index].handle;
    c.lsquic_conn_abort(engine.connections.pool.storage[index].native);
    var step: usize = 0;
    while (step < c.UWZ_APP_MAX_STEPS) : (step += 1) {
        try pump(application, clients);
        if (engine.connections.find(handle) != null) continue;
        try testing.expectEqual(@as(usize, 0), engine.connections.pool.storage[index].sessions.open_count());
        try testing.expectEqual(@as(usize, 0), application.datagram_rings[index].len());
        return;
    }
    return error.AppConnectionAbortTimeout;
}

fn run_denial(denial: DenialCase) !void {
    var application = try initialize_app();
    defer destroy_app(&application);
    var observed: Observation = .{};
    const port = try listen(&application, &observed, denial.mode);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    try handshake(&application, client, &clients);
    const id = try open_connect(client, denial);
    _ = try await_status(&application, client, &clients, id, denial.status);
    try await_rejection_fin(&application, client, &clients, id);
    const index = try connection_index(&application, client);
    const connection = &application.quic_transport.?.engine.connections.pool.storage[index];
    try testing.expectEqual(@as(usize, 0), connection.sessions.open_count());
    try testing.expectEqual(denial.authorization_calls, observed.authorization_calls);
    try testing.expect(!observed.response_failed);
    try abort_connection(&application, client, &clients);
}

test "actual App admits authorized WebTransport CONNECT before client EOF" {
    var application = try initialize_app();
    defer destroy_app(&application);
    var observed: Observation = .{};
    const port = try listen(&application, &observed, .exact);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    try handshake(&application, client, &clients);
    _ = try accept_session(&application, client, &clients);
    try testing.expectEqual(@as(usize, 1), observed.authorization_calls);
    try testing.expect(!observed.response_failed);
    try abort_connection(&application, client, &clients);
}

test "actual App rejects missing duplicate forbidden Origin and unauthorized CONNECT" {
    const cases = [_]DenialCase{
        .{ .origin = null, .status = 400 },
        .{ .origin = "", .status = 400 },
        .{ .duplicate_origin = true, .status = 400 },
        .{ .origin = "https://forbidden.example", .status = 403, .authorization_calls = 1 },
        .{ .authorization = null, .status = 401, .authorization_calls = 1 },
    };
    for (cases) |denial| try run_denial(denial);
}

test "actual App rejects fallback middleware success and missing datagram endpoint" {
    const cases = [_]DenialCase{
        .{ .mode = .any_fallback, .status = 405 },
        .{ .mode = .middleware_success, .status = 403 },
        .{ .mode = .missing_endpoint, .status = 404 },
    };
    for (cases) |denial| try run_denial(denial);
}

test "actual App limits one session per connection and separates session zero on two connections" {
    var application = try initialize_app();
    defer destroy_app(&application);
    var observed: Observation = .{};
    const port = try listen(&application, &observed, .exact);
    const first = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(first);
    const second = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(second);
    const clients = [_]*c.struct_uwz_app_client{ first, second };
    try handshake(&application, first, clients[0..1]);
    const first_index = try accept_session(&application, first, clients[0..1]);
    const duplicate = try open_connect(first, .{ .status = 429 });
    try testing.expectEqual(@as(u64, 4), duplicate);
    _ = try await_status(&application, first, clients[0..1], duplicate, 429);
    try await_rejection_fin(&application, first, clients[0..1], duplicate);
    try testing.expectEqual(@as(usize, 1), application.quic_transport.?.engine.connections.pool.storage[first_index].sessions.open_count());
    try handshake(&application, second, &clients);
    const second_index = try accept_session(&application, second, &clients);
    try testing.expect(first_index != second_index);
    try testing.expectEqual(@as(usize, 2), application.quic_transport.?.engine.connections.pool.count_active());
    try abort_connection(&application, first, &clients);
    try testing.expectEqual(@as(usize, 1), application.quic_transport.?.engine.connections.pool.storage[second_index].sessions.open_count());
    try abort_connection(&application, second, &clients);
}
