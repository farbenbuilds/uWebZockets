/* Copyright (c) 2026 uWebZockets contributors. See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/queue.h>
#include <openssl/ssl.h>
#include "lsquic.h"
#include "lsxpack_header.h"
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_packet_in.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"
#include "lsquic_conn_public.h"
#include "lsquic_mm.h"
#include "lsquic_engine_public.h"
#include "lsquic_enc_sess.h"
#include "lsquic_conn.h"
#include "lsquic_sizes.h"
#include "lsquic_trans_params.h"
#include "uwz_quic_fixture.h"
#include "uwz_webtransport_fixture.h"
#include "uwz_app_client.h"

#ifdef NDEBUG
#error "uwz_app_client requires active assertions"
#endif

struct uwz_app_request {
    lsquic_stream_t *native;
    struct uwz_app_response_snapshot observation;
};

struct uwz_app_client {
    struct lsquic_test_pair transport;
    lsquic_conn_t *native;
    int udp_fd;
    struct uwz_app_client_snapshot observation;
    struct uwz_app_request requests[UWZ_APP_MAX_STREAMS];
    struct streams_header_pool headers;
    size_t datagram_size;
    unsigned char datagram[128];
};

int
uwz_app_udp_socket_new(void)
{
    struct sockaddr_in address;
    int fd = socket(AF_INET, SOCK_DGRAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);

    if (fd < 0)
        return -1;
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (bind(fd, (struct sockaddr *) &address, sizeof(address)))
    {
        close(fd);
        return -1;
    }
    return fd;
}

uint16_t
uwz_app_udp_socket_port(int fd)
{
    struct sockaddr_in address;
    socklen_t size = sizeof(address);

    if (getsockname(fd, (struct sockaddr *) &address, &size)
        || size != sizeof(address) || address.sin_family != AF_INET)
        return 0;
    return ntohs(address.sin_port);
}

void
uwz_app_udp_socket_close(int fd)
{
    if (fd >= 0)
        assert(close(fd) == 0);
}

static struct uwz_app_request *
find_request(struct uwz_app_client *client, uint64_t id)
{
    unsigned index;

    for (index = 0; index < client->observation.stream_callbacks; ++index)
        if (client->requests[index].observation.stream_id == id)
            return &client->requests[index];
    return NULL;
}

static lsquic_conn_ctx_t *
new_connection(void *ctx, lsquic_conn_t *conn)
{
    struct uwz_app_client *client = ctx;

    assert(!client->native);
    client->native = conn;
    return (lsquic_conn_ctx_t *) client;
}

static void
handshake_done(lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct uwz_app_client *client = (void *) lsquic_conn_get_ctx(conn);

    assert(client && status == LSQ_HSK_OK);
    client->observation.handshake_complete = 1;
}

static void
settings_received(lsquic_conn_t *conn)
{
    struct uwz_app_client *client = (void *) lsquic_conn_get_ctx(conn);

    assert(client && client->native == conn);
    ++client->observation.settings_callbacks;
}

static void
connection_closed(lsquic_conn_t *conn)
{
    struct uwz_app_client *client = (void *) lsquic_conn_get_ctx(conn);

    assert(client && client->native == conn);
    client->observation.closed_status = lsquic_conn_status(conn,
        client->observation.local_reason, sizeof(client->observation.local_reason));
    client->observation.local_reason[sizeof(client->observation.local_reason) - 1] = 0;
    client->observation.local_reason_size = (unsigned) strlen(client->observation.local_reason);
    ++client->observation.connection_closed;
    client->native = NULL;
    lsquic_conn_set_ctx(conn, NULL);
}

static lsquic_stream_ctx_t *
new_stream(void *ctx, lsquic_stream_t *stream)
{
    struct uwz_app_client *client = ctx;
    struct uwz_app_request *request;

    assert(stream && client->observation.stream_callbacks < UWZ_APP_MAX_STREAMS);
    request = &client->requests[client->observation.stream_callbacks++];
    request->native = stream;
    request->observation.stream_id = lsquic_stream_id(stream);
    assert(lsquic_stream_wantread(stream, 1) >= 0);
    return (lsquic_stream_ctx_t *) request;
}

static void
close_frame_received(lsquic_conn_t *conn, int app_error, uint64_t code,
                     const char *reason, int reason_size)
{
    struct uwz_app_client *client = (void *) lsquic_conn_get_ctx(conn);
    size_t size = reason_size > 0 ? (size_t) reason_size : 0;

    assert(client);
    client->observation.remote_app_error = app_error;
    client->observation.remote_error_code = code;
    if (size >= sizeof(client->observation.remote_reason))
        size = sizeof(client->observation.remote_reason) - 1;
    if (size && reason)
        memcpy(client->observation.remote_reason, reason, size);
    client->observation.remote_reason[size] = 0;
    client->observation.remote_reason_size = (unsigned) size;
}

static void
headers_received(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct uwz_app_request *request = (void *) ctx;
    struct streams_header_set *set;
    const struct lsxpack_header *header;
    unsigned index;

    assert(request && request->native == stream);
    ++request->observation.header_callbacks;
    set = lsquic_stream_get_hset(stream);
    assert(set && set->shs_active && set->shs_complete);
    for (index = 0; index < set->shs_count; ++index)
    {
        header = &set->shs_fields[index].shf_header;
        if (header->name_len == 7
            && !memcmp(lsxpack_header_get_name(header), ":status", 7)
            && header->val_len == 3)
        {
            const unsigned char *value = (const unsigned char *) lsxpack_header_get_value(header);
            assert(value[0] >= '1' && value[0] <= '5');
            assert(value[1] >= '0' && value[1] <= '9');
            assert(value[2] >= '0' && value[2] <= '9');
            request->observation.status_code = (value[0] - '0') * 100
                                            + (value[1] - '0') * 10 + value[2] - '0';
            if (request->observation.status_code == 200)
                request->observation.status_ok += 1;
        }
    }
    discard_header_set(set);
}

static void
read_stream(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct uwz_app_request *request = (void *) ctx;
    struct uwz_app_response_snapshot *out = &request->observation;
    ssize_t size;

    assert(request && request->native == stream);
    while (out->received < sizeof(out->bytes))
    {
        size = lsquic_stream_read(stream, out->bytes + out->received,
                                sizeof(out->bytes) - out->received);
        if (size > 0)
        {
            out->received += (size_t) size;
            continue;
        }
        if (size < 0)
        {
            assert(errno == EAGAIN || errno == EWOULDBLOCK || out->reset_callbacks);
            return;
        }
        out->fin_received = 1;
        assert(lsquic_stream_wantread(stream, 0) >= 0);
        assert(lsquic_stream_shutdown(stream, 0) == 0);
        return;
    }
    assert(0 && "bounded response body exhausted");
}

static void
write_stream(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) ctx;
    assert(lsquic_stream_wantwrite(stream, 0) >= 0);
}

static void
close_stream(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct uwz_app_request *request = (void *) ctx;

    assert(request && request->native == stream && !request->observation.close_callbacks);
    ++request->observation.close_callbacks;
    request->native = NULL;
}

static void
reset_stream(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx, int how)
{
    struct uwz_app_request *request = (void *) ctx;

    assert(request && request->native == stream && (how == 0 || how == 1));
    request->observation.reset_error_status[how] = lsquic_stream_get_reset_error(
        stream, how, &request->observation.reset_error_code[how]);
    ++request->observation.reset_events[how];
    ++request->observation.reset_callbacks;
}

static void
typed_stream(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct uwz_app_client *client = (void *) lsquic_conn_get_ctx(lsquic_stream_conn(stream));

    (void) ctx;
    ++client->observation.typed_callbacks;
}

static ssize_t
write_datagram(lsquic_conn_t *conn, void *buffer, size_t capacity)
{
    struct uwz_app_client *client = (void *) lsquic_conn_get_ctx(conn);
    size_t size = client->datagram_size;

    assert(size && size <= capacity);
    memcpy(buffer, client->datagram, size);
    client->datagram_size = 0;
    ++client->observation.datagrams_written;
    lsquic_conn_want_datagram_write(conn, 0);
    return (ssize_t) size;
}

static void
receive_datagram(lsquic_conn_t *conn, const void *buffer, size_t size)
{
    struct uwz_app_client *client = (void *) lsquic_conn_get_ctx(conn);

    (void) buffer;
    (void) size;
    ++client->observation.datagrams_received;
}

static const struct lsquic_stream_if client_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_conncloseframe_received = close_frame_received,
    .on_hsk_done = handshake_done,
    .on_h3_settings = settings_received,
    .on_new_stream = new_stream,
    .on_hset_in = headers_received,
    .on_webtransport_stream = typed_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_reset = reset_stream,
    .on_dg_write = write_datagram,
    .on_datagram = receive_datagram,
};

struct uwz_app_client *
uwz_app_client_create_variant(uint16_t server_port, enum uwz_app_client_variant variant)
{
    struct uwz_app_client *client;
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    int result;

    if (!server_port || variant < UWZ_APP_CLIENT_DEFAULT
        || variant > UWZ_APP_CLIENT_SMALL_RESPONSE_CREDIT)
        return NULL;
    client = calloc(1, sizeof(*client));
    if (!client)
        return NULL;
    client->udp_fd = uwz_app_udp_socket_new();
    if (client->udp_fd < 0)
    {
        free(client);
        return NULL;
    }
    client->transport.ltp_server.lte_address.sin_family = AF_INET;
    client->transport.ltp_server.lte_address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    client->transport.ltp_server.lte_address.sin_port = htons(server_port);
    lsquic_engine_init_settings(&settings, LSENG_HTTP);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_bidi = 8;
    settings.es_init_max_streams_uni = 8;
    settings.es_qpack_dec_max_size = 0;
    settings.es_qpack_dec_max_blocked = 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    settings.es_max_udp_payload_size_rx = 2048;
    settings.es_datagrams = 1;
    settings.es_reset_stream_at = 1;
    settings.es_webtransport.enabled = variant != UWZ_APP_CLIENT_NO_WT;
    if (variant == UWZ_APP_CLIENT_SMALL_RESPONSE_CREDIT)
        settings.es_init_max_stream_data_bidi_local = 4096;
    client->observation.configured_max_data = settings.es_init_max_data;
    client->observation.configured_bidi_local = settings.es_init_max_stream_data_bidi_local;
    client->observation.configured_bidi_remote = settings.es_init_max_stream_data_bidi_remote;
    client->observation.configured_uni = settings.es_init_max_stream_data_uni;
    client->observation.configured_wt = settings.es_webtransport.enabled;
    assert(lsquic_engine_check_settings(&settings, LSENG_HTTP, NULL, 0) == 0);
    memset(&config, 0, sizeof(config));
    config.ltec_flags = LSENG_HTTP;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &client_callbacks;
    config.ltec_stream_if_ctx = client;
    config.ltec_hsi_if = &streams_hsi;
    config.ltec_hsi_ctx = &client->headers;
    config.ltec_alpn = "h3";
    config.ltec_tls = lsquic_test_tls_context_new(0, "h3");
    if (!config.ltec_tls)
    {
        uwz_app_client_destroy(client);
        return NULL;
    }
    result = lsquic_test_endpoint_init(&client->transport.ltp_client,
        &client->transport.ltp_server, &config, uwz_app_udp_socket_port(client->udp_fd));
    SSL_CTX_free(config.ltec_tls);
    if (result)
    {
        uwz_app_client_destroy(client);
        return NULL;
    }
    return client;
}

struct uwz_app_client *
uwz_app_client_create(uint16_t server_port)
{
    return uwz_app_client_create_variant(server_port, UWZ_APP_CLIENT_DEFAULT);
}

void
uwz_app_client_destroy(struct uwz_app_client *client)
{
    if (!client)
        return;
    lsquic_test_endpoint_destroy(&client->transport.ltp_client);
    assert(client->headers.shp_created == client->headers.shp_discarded);
    uwz_app_udp_socket_close(client->udp_fd);
    free(client);
}

int
uwz_app_client_connect(struct uwz_app_client *client)
{
    if (!client || client->native)
        return -1;
    return lsquic_engine_connect(client->transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &client->transport.ltp_client.lte_address,
                (struct sockaddr *) &client->transport.ltp_server.lte_address,
                &client->transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0) ? 0 : -1;
}

int
uwz_app_client_process(struct uwz_app_client *client)
{
    if (!client)
        return -1;
    lsquic_test_pair_process(&client->transport, 1000);
    return 0;
}

int
uwz_app_client_send_udp(struct uwz_app_client *client)
{
    struct lsquic_test_packet packet;
    ssize_t size;
    unsigned count = 0;

    if (!client)
        return -1;
    while (client->transport.ltp_server.lte_incoming.ltq_count)
    {
        if (lsquic_test_packet_take(&client->transport.ltp_server, 0, &packet))
            return -1;
        size = sendto(client->udp_fd, packet.ltp_bytes, packet.ltp_size, MSG_DONTWAIT,
                      (struct sockaddr *) &client->transport.ltp_server.lte_address,
                      sizeof(client->transport.ltp_server.lte_address));
        if (size < 0 || (size_t) size != packet.ltp_size)
            return -1;
        ++count;
    }
    return (int) count;
}

int
uwz_app_client_stage_pending_packets(struct uwz_app_client *client,
                                     lsquic_engine_t *server, void *peer_context)
{
    struct lsquic_test_packet packet;
    unsigned count = 0;

    if (!client || !server || !peer_context)
        return -1;
    while (client->transport.ltp_server.lte_incoming.ltq_count)
    {
        if (lsquic_test_packet_take(&client->transport.ltp_server, 0, &packet))
            return -1;
        if (lsquic_engine_packet_in(server, packet.ltp_bytes, packet.ltp_size,
                (struct sockaddr *) &client->transport.ltp_server.lte_address,
                (struct sockaddr *) &client->transport.ltp_client.lte_address,
                peer_context, 0) < 0)
            return -1;
        ++count;
    }
    return (int) count;
}

int
uwz_app_client_receive_udp(struct uwz_app_client *client)
{
    struct lsquic_test_packet packet;
    ssize_t size;
    unsigned count = 0;

    if (!client)
        return -1;
    while (count < LSQUIC_TEST_MAX_PACKETS)
    {
        size = recv(client->udp_fd, packet.ltp_bytes, sizeof(packet.ltp_bytes), MSG_DONTWAIT);
        if (size < 0 && (errno == EAGAIN || errno == EWOULDBLOCK))
            return (int) count;
        if (size <= 0)
            return -1;
        packet.ltp_size = (size_t) size;
        if (lsquic_test_packet_deliver(&client->transport.ltp_client, &packet) < 0)
            return -1;
        ++client->observation.received_datagrams;
        ++count;
    }
    return (int) count;
}

uint16_t
uwz_app_client_port(const struct uwz_app_client *client)
{
    return client ? ntohs(client->transport.ltp_client.lte_address.sin_port) : 0;
}

int
uwz_app_client_observe(const struct uwz_app_client *client,
                          struct uwz_app_client_snapshot *out)
{
    if (!client || !out)
        return -1;
    *out = client->observation;
    out->connection_status = client->native ? lsquic_conn_status(client->native, NULL, 0) : -1;
    return 0;
}

int
uwz_app_client_response(const struct uwz_app_client *client, uint64_t id,
                           struct uwz_app_response_snapshot *out)
{
    unsigned index;

    if (!client || !out)
        return -1;
    for (index = 0; index < client->observation.stream_callbacks; ++index)
    {
        if (client->requests[index].observation.stream_id != id)
            continue;
        *out = client->requests[index].observation;
        return 0;
    }
    return -1;
}

uint64_t
uwz_app_client_open_connect(struct uwz_app_client *client,
                            const struct uwz_app_connect_request *input)
{
    static const char *const fields[] = {
        ":methodCONNECT", ":protocolwebtransport-h3", ":schemehttps",
        ":authoritylocalhost", ":path/wt",
    };
    static const unsigned name_sizes[] = { 7, 9, 7, 10, 5 };
    struct lsxpack_header encoded[8];
    struct lsquic_http_headers headers = { 5, encoded };
    struct uwz_app_request *request;
    char origin_field[128], authorization_field[128];
    unsigned index, before;
    int size;

    if (!client || !client->native || !input || input->duplicate_origin > 1)
        return UINT64_MAX;
    before = client->observation.stream_callbacks;
    lsquic_conn_make_stream(client->native);
    if (client->observation.stream_callbacks != before + 1)
        return UINT64_MAX;
    request = &client->requests[before];
    for (index = 0; index < 5; ++index)
        lsxpack_header_set_offset2(&encoded[index], fields[index], 0,
                    name_sizes[index], name_sizes[index], strlen(fields[index]) - name_sizes[index]);
    if (input->origin)
    {
        size = snprintf(origin_field, sizeof(origin_field), "origin%s", input->origin);
        if (size < 6 || (size_t) size >= sizeof(origin_field))
            return UINT64_MAX;
        lsxpack_header_set_offset2(&encoded[headers.count++], origin_field, 0, 6, 6, (unsigned) size - 6);
        if (input->duplicate_origin)
            lsxpack_header_set_offset2(&encoded[headers.count++], origin_field, 0, 6, 6, (unsigned) size - 6);
    }
    if (input->authorization)
    {
        size = snprintf(authorization_field, sizeof(authorization_field), "authorization%s", input->authorization);
        if (size < 13 || (size_t) size >= sizeof(authorization_field))
            return UINT64_MAX;
        lsxpack_header_set_offset2(&encoded[headers.count++], authorization_field, 0, 13, 13, (unsigned) size - 13);
    }
    if (lsquic_stream_send_headers(request->native, &headers, 0)
        || lsquic_stream_flush(request->native))
        return UINT64_MAX;
    return request->observation.stream_id;
}

lsquic_conn_t *
uwz_app_client_connection(struct uwz_app_client *client)
{
    return client ? client->native : NULL;
}

uint64_t
uwz_app_client_open_post(struct uwz_app_client *client, const char *path, size_t body_size)
{
    static const char *const fields[] = {
        ":methodPOST", ":schemehttps", ":authoritylocalhost",
    };
    static const unsigned name_sizes[] = { 7, 7, 10 };
    struct lsxpack_header encoded[5];
    struct lsquic_http_headers headers = { 5, encoded };
    struct uwz_app_request *request;
    char path_field[128], length_field[40];
    unsigned index, before;
    int size;

    if (!client || !client->native || !path || body_size > UWZ_APP_MAX_BODY)
        return UINT64_MAX;
    before = client->observation.stream_callbacks;
    lsquic_conn_make_stream(client->native);
    if (client->observation.stream_callbacks != before + 1)
        return UINT64_MAX;
    request = &client->requests[before];
    for (index = 0; index < 3; ++index)
        lsxpack_header_set_offset2(&encoded[index], fields[index], 0,
                    name_sizes[index], name_sizes[index], strlen(fields[index]) - name_sizes[index]);
    size = snprintf(path_field, sizeof(path_field), ":path%s", path);
    if (size < 6 || (size_t) size >= sizeof(path_field))
        return UINT64_MAX;
    lsxpack_header_set_offset2(&encoded[3], path_field, 0, 5, 5, (unsigned) size - 5);
    size = snprintf(length_field, sizeof(length_field), "content-length%zu", body_size);
    if (size < 15 || (size_t) size >= sizeof(length_field))
        return UINT64_MAX;
    lsxpack_header_set_offset2(&encoded[4], length_field, 0, 14, 14, (unsigned) size - 14);
    if (lsquic_stream_send_headers(request->native, &headers, 0)
        || lsquic_stream_flush(request->native))
        return UINT64_MAX;
    return request->observation.stream_id;
}

lsquic_stream_t *
uwz_app_client_stream(struct uwz_app_client *client, uint64_t id)
{
    struct uwz_app_request *request;

    if (!client)
        return NULL;
    request = find_request(client, id);
    return request ? request->native : NULL;
}

uint16_t
uwz_app_connection_peer_port(lsquic_conn_t *connection)
{
    const struct sockaddr *local, *peer;

    if (!connection || lsquic_conn_get_sockaddr(connection, &local, &peer)
        || !peer || peer->sa_family != AF_INET)
        return 0;
    return ntohs(((const struct sockaddr_in *) peer)->sin_port);
}

int
uwz_app_client_write(struct uwz_app_client *client, uint64_t id,
                        const unsigned char *bytes, size_t size, int fin)
{
    struct uwz_app_request *request;
    ssize_t written;

    if (!client || !bytes || size > UWZ_APP_MAX_BODY || (fin != 0 && fin != 1))
        return -1;
    request = find_request(client, id);
    if (!request || !request->native)
        return -1;
    written = lsquic_stream_write(request->native, bytes, size);
    if (written < 0 || (size_t) written != size)
        return -1;
    /* Shutdown packetizes pending bytes and FIN; flush rejects the closed side. */
    if (fin)
        return lsquic_stream_shutdown(request->native, 1);
    return lsquic_stream_flush(request->native);
}

int
uwz_app_client_queue_datagram(struct uwz_app_client *client,
                              const unsigned char *bytes, size_t size)
{
    if (!client || !client->native || !bytes || !size
        || size > sizeof(client->datagram) || client->datagram_size)
        return -1;
    if (lsquic_conn_set_min_datagram_size(client->native, size))
        return -1;
    memcpy(client->datagram, bytes, size);
    client->datagram_size = size;
    lsquic_conn_want_datagram_write(client->native, 1);
    return 0;
}

int
uwz_app_client_grant_response_credit(struct uwz_app_client *client, uint64_t id, unsigned window)
{
    struct uwz_app_request *request;
    struct lsquic_stream *stream;

    if (!client || !client->native || window < 16384 || window > 1024 * 1024)
        return -1;
    request = find_request(client, id);
    if (!request || !request->native)
        return -1;
    stream = request->native;
    if (stream->fc.sf_max_recv_win != 4096 || stream->fc.sf_recv_off != 4096)
        return -1;
    /* The native receive-window update queues a real MAX_STREAM_DATA frame. */
    stream->fc.sf_max_recv_win = window;
    if (lsquic_stream_update_sfcw(stream, stream->fc.sf_max_recv_off)
        || stream->fc.sf_recv_off < window || !(stream->sm_qflags & SMQF_SEND_WUF))
        return -1;
    lsquic_engine_add_conn_to_tickable(stream->conn_pub->enpub, client->native);
    return 0;
}

uint64_t
uwz_app_stream_send_limit(const lsquic_stream_t *stream)
{
    return stream ? stream->max_send_off : UINT64_MAX;
}

int
uwz_app_stream_diagnose(const lsquic_stream_t *stream,
                        struct uwz_app_stream_diagnostics *out)
{
    if (!stream || !out)
        return -1;
    memset(out, 0, sizeof(*out));
    out->send_limit = stream->max_send_off;
    out->send_offset = stream->tosend_off;
    out->receive_limit = stream->fc.sf_recv_off;
    out->maximum_received = stream->fc.sf_max_recv_off;
    out->read_offset = stream->read_offset;
    out->receive_window = stream->fc.sf_max_recv_win;
    out->stream_flags = stream->stream_flags;
    out->queue_flags = stream->sm_qflags;
    out->send_headers_state = stream->sm_send_headers_state;
    out->buffered_bytes = stream->sm_n_buffered;
    return 0;
}

int
uwz_app_peer_transport_diagnose(const lsquic_conn_t *connection,
                                struct uwz_app_peer_transport_diagnostics *out)
{
    const struct transport_params *params;

    if (!connection || !out || !(connection->cn_flags & LSCONN_IETF)
        || (connection->cn_flags & LSCONN_MINI) || !connection->cn_esf.i
        || !connection->cn_enc_session)
        return -1;
    params = connection->cn_esf.i->esfi_get_peer_transport_params(connection->cn_enc_session);
    if (!params)
        return -1;
    out->max_data = params->tp_init_max_data;
    out->bidi_local = params->tp_init_max_stream_data_bidi_local;
    out->bidi_remote = params->tp_init_max_stream_data_bidi_remote;
    out->uni = params->tp_init_max_stream_data_uni;
    out->streams_bidi = params->tp_init_max_streams_bidi;
    out->streams_uni = params->tp_init_max_streams_uni;
    return 0;
}
