# Actual App WebTransport admission harness

This new scratch scaffold leaves both earlier harnesses unchanged. It imports
the actual project `src/test_support.zig`, App, builder, UDP transport, QUIC
engine, router, request/response, ownership state, and backend. One translated
C module includes the actual `src/c.h` and the scratch native client header;
there are no simulated native functions, layouts, or server callbacks.

## Functional seam and scope

The driver builds the actual App with
`Server.builder(io).with_max_clients(4).with_webtransport_datagrams(1200, 4)`,
enables its supported ephemeral HTTP/3 TLS contexts, registers the actual
`datagram_context` and explicit CONNECT `route_context`, and calls `listen_udp`
at its final stable address. The route handler checks Origin and authorization
and completes an empty response through the real `Response.end` interface.

The native candidate client enables real WT SETTINGS, QUIC datagrams, and
reliable reset, then sends actual extended CONNECT headers with draft-16
`webtransport-h3`, Origin, and optional authorization. Its bounded packet queue
is sent from a real bound client UDP socket to the actual App listener. The
driver services `xev.run(.no_wait)`, the production engine's normal processing
function, and native client UDP input. Both server receive and server output
therefore use the real transport paths.

Four tests cover:

1. Authorized non-FIN 200 before client EOF, native client/server CONNECT
   metadata, established per-connection session storage, actual connctx and
   streamctx identities, active stream lease, and cleanup after native abort.
2. Missing, empty, and duplicate Origin (400), forbidden Origin (403), and
   missing authorization (401), with no admitted session and terminal response
   FIN. Origin and authorization policy belongs to the actual route handler.
3. `.any` fallback (405), middleware-produced 200 returning either `.stop` or
   `.continue_dispatch` (both rejected as 403 with one middleware call and no
   CONNECT handler call), and a
   missing datagram endpoint (404), with no admitted session.
4. A second flow-control-off session on the same connection, reset with actual
   `H3_REQUEST_REJECTED` (0x10b), zero response headers, and no extra admission
   handler call, followed
   by another native TLS connection whose independent session ID is also zero.
   Aborting the first connection must preserve the second session.

The excessive-session reset follows
[draft-16 Section 5.1](https://www.ietf.org/archive/id/draft-ietf-webtrans-http3-16.html#section-5.1).
The original proposed 429 assertion and its input manifest are preserved under
`provenance/proposed_429_snapshot`; that proposal had not been executed.

The client bridge has a bounded native QUIC datagram sender ready for the
following wire-delivery extension. The current four tests do not invoke it
and make no wire-datagram delivery or ring-clear evidence claim beyond
checking an empty ring after teardown. Native engine child integration,
external-client interoperability, and publication remain outside this cohort.

## Real lifecycle drain

The App stays at one address after listening. Teardown calls the transport's
real `shutdown`, services its xev loop at most 20,000 nonblocking iterations,
and observes `is_drained` after actual close, read, timer, and cancellation
completions. It checks the actual completion flags, then calls App `shutdown`
and `deinit`. No drained, active, completion, or App-running field is assigned
by the harness. Client native engines are destroyed before the App releases
its owned lsquic global reference. TLS keys and certificates stay in memory.

## Inputs and provenance

- Native candidate:
  `/tmp/uwz-lsquic-wt-streams-20261113`, clean commit
  `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c`.
- Exact native build helpers and pinned package manifest are copied from
  `/tmp/uwz-wt-zig-engine-harness`. The scratch lsquic source override is
  unchanged; the actual project's dependency pins and build graph are untouched.
- `zig-pkg` links to the already populated project package directory.
- The optional scratch `-Dlibxev-source=/tmp/uwz-gro-libxev` selects the actual
  reviewed XEV-008 source at full commit
  `5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`. This is a second explicit
  candidate input; the published libxev pin and default selection are unchanged.
- `uwz_quic_fixture.c`, `uwz_quic_fixture.h`, and
  `uwz_webtransport_fixture.h` are unchanged candidate fixture copies.
- The adapted client retains the corrected FIN helper: write shutdown is
  returned directly for FIN; only non-FIN writes call flush.
- Source manifests cover only source, build inputs, and provenance text. They
  contain no caches, binaries, generated TLS keys, or package source copies.

The root agent requested an intermediate source freeze for a genuine RED.
At this freeze the actual App binding and WT negotiation exist, but the root
header path still processes ordinary CONNECT without header-time admission.
The positive test should expose that missing behavior before the root agent
implements the coordinator. No test or build has been run by the scaffold
agent, and no passing result is claimed.

The root's first actual RED terminated with all four tests failing at the
missing header-time response, and exposed the published io_uring poll
cancellation diagnostic during teardown. That original failed row is preserved
under `provenance/actual_first_red`. The reviewed XEV-008 input maps the exact
kernel poll cancellation to typed `Canceled`; the real drain path is retained.
See `provenance/xev_008_cancellation.md` for the source diagnosis and hashes.
The coordinator's next source freeze and root rerun remain pending.

```sh
cd /tmp/uwz-wt-app-admission-harness
/tmp/zig-x86_64-linux-0.16.0/zig build test-compile \
  -Doptimize=Debug \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-streams-20261113 \
  -Dlibxev-source=/tmp/uwz-gro-libxev \
  --summary all
/tmp/zig-x86_64-linux-0.16.0/zig build test \
  -Doptimize=Debug \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-streams-20261113 \
  -Dlibxev-source=/tmp/uwz-gro-libxev \
  --summary all
```
