# Actual App WebTransport admission harness

This new scratch scaffold leaves both earlier harnesses unchanged. It imports
the actual project `src/test_support.zig`, App, builder, UDP transport, QUIC
engine, router, request/response, ownership state, and backend. One translated
C module includes the actual `src/c.h` and the scratch native client header;
there are no simulated native functions, layouts, or server callbacks.

## Functional seam and scope

The driver builds the actual App with
`Server.builder(io).with_max_clients(4).with_webtransport_datagrams(1200, 4)`,
with supported `with_max_h3_response_header_size(16384)`,
enables its supported ephemeral HTTP/3 TLS contexts, registers the actual
`datagram_context` and explicit CONNECT `route_context`, and calls `listen_udp`
at its final stable address. The route handler checks Origin and authorization
and completes an empty response through the real `Response.end` interface.

The native candidate client enables real WT SETTINGS, QUIC datagrams, and
reliable reset, then sends actual extended CONNECT headers with draft-16
`webtransport-h3`, Origin, and optional authorization. Its bounded packet queue
is sent from a real bound client UDP socket to the actual App listener. The
driver services `xev.run(.no_wait)`, the production engine's normal processing
function, and native client UDP input. Both server receive and server output
therefore use the real transport paths.

Eight tests cover:

1. Authorized non-FIN 200 before client EOF, native client/server CONNECT
   metadata, established per-connection session storage, actual connctx and
   streamctx identities, active stream lease, and cleanup after native abort.
2. Missing, empty, and duplicate Origin (400), forbidden Origin (403), and
   missing authorization (401), with no admitted session and terminal response
   FIN. Origin and authorization policy belongs to the actual route handler.
3. `.any` fallback (405), middleware-produced 200 returning either `.stop` or
   `.continue_dispatch` (both rejected as 403 with one middleware call and no
   CONNECT handler call), and a
   missing datagram endpoint (404), with no admitted session.
4. A second flow-control-off session on the same connection, reset with actual
   `H3_REQUEST_REJECTED` (0x10b), zero response headers, and no extra admission
   handler call, followed
   by another native TLS connection whose independent session ID is also zero.
   Aborting the first connection must preserve the second session.
5. A client that omits WT SETTINGS while retaining QUIC datagram and reset
   support still sends extended CONNECT. The actual response must be a native
   H3_MESSAGE_ERROR reset (0x10e), with no HTTP headers or authorization call.
6. An ordinary POST's real encrypted final-body packets are narrowly staged
   through native `packet_in` without public engine processing. Public
   `cooldown` then invokes the actual pending route during its native process
   step. That callback records `in_cooldown`, calls public `engine.process`,
   and must return with the exact ordinary response intact.
7. The native HTTP/3 sanity minimum of 4096 response-credit bytes blocks an
   actual response header field with 4091 literal tilde bytes. Its QPACK and
   HTTP framing exceed that credit. A prohibited capsule must close the session and
   leave sidecar `pending_reset = 0x10e` without a premature peer reset. The
   fixture grants real native QUIC receive credit and requires the queued
   reset to reach the peer, then verifies HTTP/header pools drain.
8. The same blocked head receives a valid Close capsule followed by trailing
   DATA. The actual native `STREAM_DELAYED_SW` flag must be set before additional
   credit; pending H3_MESSAGE_ERROR reset, peer reset, and pool cleanup are required.

The excessive-session reset follows
[draft-16 Section 5.1](https://www.ietf.org/archive/id/draft-ietf-webtrans-http3-16.html#section-5.1).
The original proposed 429 assertion and its input manifest are preserved under
`provenance/proposed_429_snapshot`; that proposal had not been executed.

The client bridge has a bounded native QUIC datagram sender ready for the
following wire-delivery extension. The current eight tests do not invoke it
and make no wire-datagram delivery or ring-clear evidence claim beyond
checking an empty ring after teardown. Native engine child integration,
external-client interoperability, and publication remain outside this cohort.

The first four cases retain the complete UDP receive seam. Case six's staging
seam changes scheduling only: every staged packet is produced and encrypted
by the actual native client, consumed by real server `packet_in`, and
dispatched by actual native cooldown processing. It never invokes a callback
manually or sets an engine state flag.

For case seven, no public lsquic receive-window grant API exists. The narrow
scratch C helper uses the candidate's real private stream/flow-control types,
raises its actual 4096-byte receive window, calls native `lsquic_stream_update_sfcw`,
and makes the actual connection tickable. The candidate then encodes and
encrypts MAX_STREAM_DATA, which traverses the normal UDP path. No native frame
is manually encoded and no server send limit is assigned. These private C
helpers use the same relevant native layout defines as the candidate library.
Native decoding consumes part of the blocked header and may already queue an
automatic MAX_STREAM_DATA update. The assertions prove the reset is pending
before additional peer credit and arrives after real native credit; they do
not attribute recovery solely to the explicit window grant.
The scratch decoded-header field capacity is 8192 bytes so this bounded large
response can be decoded; all other shared fixture logic is retained.
The pre-review driver and bridge are preserved in `provenance/pre_review_fixes`.

## Real lifecycle drain

The App stays at one address after listening. Teardown calls the transport's
real `shutdown`, services its xev loop at most 20,000 nonblocking iterations,
and observes `is_drained` after actual close, read, timer, and cancellation
completions. It checks the actual completion flags, then calls App `shutdown`
and `deinit`. No drained, active, completion, or App-running field is assigned
by the harness. Client native engines are destroyed before the App releases
its owned lsquic global reference. TLS keys and certificates stay in memory.

## Inputs and provenance

- Native candidate:
  `/tmp/uwz-lsquic-wt-streams-20261113`, clean commit
  `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c`.
- Exact native build helpers and pinned package manifest are copied from
  `/tmp/uwz-wt-zig-engine-harness`. The scratch lsquic source override is
  unchanged; the actual project's dependency pins and build graph are untouched.
- `zig-pkg` links to the already populated project package directory.
- The optional scratch `-Dlibxev-source=/tmp/uwz-gro-libxev` selects the actual
  reviewed XEV-008 source at full commit
  `5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`. This is a second explicit
  candidate input; the published libxev pin and default selection are unchanged.
- `uwz_quic_fixture.c` and `uwz_quic_fixture.h` are unchanged candidate fixture
  copies. `uwz_webtransport_fixture.h` changes only decoded-field capacity from
  1024 to 8192 bytes; the original is preserved with the zero-credit failure.
- The adapted client retains the corrected FIN helper: write shutdown is
  returned directly for FIN; only non-FIN writes call flush.
- Source manifests cover only source, build inputs, and provenance text. They
  contain no caches, binaries, generated TLS keys, or package source copies.

The first intermediate freeze preceded header-time admission and deliberately
exposed the missing non-FIN success response. Historical source snapshots and
terminal logs preserve that RED and subsequent diagnostic failures.

The root's first actual RED terminated with all four tests failing at the
missing header-time response, and exposed the published io_uring poll
cancellation diagnostic during teardown. That original failed row is preserved
under `provenance/actual_first_red`. The reviewed XEV-008 input maps the exact
kernel poll cancellation to typed `Canceled`; the real drain path is retained.
See `provenance/xev_008_cancellation.md` for the source diagnosis and hashes.
After the coordinator flush correction, the original zero-credit case still
failed during TLS: native `es_check_tp_sanity` requires client HTTP/3 response
credit of at least 4096. That policy rejection and its exact source snapshot
are preserved in `provenance/zero_credit_policy_failure`. The corrected
4096-credit seven-case cohort passed Debug, with identical before/after input
manifests, in `provenance/seven_case_green`. The eighth delayed-FIN variant is
the only subsequent test addition; final mode results are recorded separately.

```sh
cd /tmp/uwz-wt-app-admission-harness
/tmp/zig-x86_64-linux-0.16.0/zig build test-compile \
  -Doptimize=Debug \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-streams-20261113 \
  -Dlibxev-source=/tmp/uwz-gro-libxev \
  --summary all
/tmp/zig-x86_64-linux-0.16.0/zig build test \
  -Doptimize=Debug \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-streams-20261113 \
  -Dlibxev-source=/tmp/uwz-gro-libxev \
  --summary all
```
