# Terminal verification results

The same eight-case driver and both frozen native candidates passed:

| Mode | Authoritative session | Exit | Tests | Build steps |
| --- | ---: | ---: | ---: | ---: |
| Debug | 26701 | 0 | 8/8 | 16/16 |
| ReleaseSafe | 7808 | 0 | 8/8 | 16/16 |
| ReleaseFast | 25188 | 0 | 8/8 | 16/16 |

Before/after comparison manifest for all three runs:
`df5196974fdee760fba06b183324fac66d5a55ac3ac94b2267554df76f6f6923`.
All 124 rows matched after each terminal run; both native worktrees remained
clean. The additional package manifest covers every archived scratch fixture
and helper, including the intentionally enlarged decoded-header field buffer.

Final log SHA-256:

- Debug: `fdf56805d0aa79dc598ec8a40aa461dd086d2e8fd7dbe5250bf9771de84c9597`
- ReleaseSafe: `6b5893142f527d5f19967794c145a4bdac288d98c7b9f3827ac51f76ae56eb38`
- ReleaseFast: `421dba632f94b000dbc9986f845ca6451d66ac3bd17348aeb6da16f678e93bfb`

Each terminal log and captured exit file is under `harness/provenance`.
The original absolute log paths were
`/tmp/uwz-wt-app-admission-final-debug.log`,
`/tmp/uwz-wt-app-admission-final-release-safe.log`, and
`/tmp/uwz-wt-app-admission-final-release-fast.log`.

The recorded command for each mode was:

```sh
cd /tmp/uwz-wt-app-admission-harness
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-uni-global-cache \
  /tmp/zig-x86_64-linux-0.16.0/zig build test \
  -Doptimize=Debug \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-streams-20261113 \
  -Dlibxev-source=/tmp/uwz-gro-libxev -j2 --summary all
```

ReleaseSafe and ReleaseFast changed only `-Doptimize`. Log redirection and
immediate captured shell exit produced the archived logs and `.exit` files.
`replay.sh` selects the included exact libxev source instead of its original
absolute worktree path; its content matches the recorded source manifest.

Historical failures remain failures:

| Row | Outcome | Preserved evidence |
| --- | --- | --- |
| Initial published-libxev admission RED | 0/4; missing admission and poll-cancel diagnostic | `actual_first_red/first_red.log`, source snapshot/manifests |
| First coordinator Debug | 4/7; non-FIN 200 timeout, zero-credit handshake failure | `coordinator_first_run/first_debug.log`, exact root manifest |
| First diagnostic compile | translation-unit include-order failure; no tests ran | `diagnostic_compile_failure/compile.log`, failing C source |
| Diagnostic sandbox run | 0/7 from socket EPERM; no functional protocol result | `diagnostic_fixed_debug.log`, captured exit |
| Diagnostic real loopback | 4/7; actual send offset/credit localized missing flush | `diagnostic_loopback_debug.log`, before/after manifests |
| Flush-fixed zero-credit Debug | 6/7; transport-error0x8 before request | `zero_credit_policy_failure/`, source/manifests/log |
| 4096-credit grant precondition | 6/7; actual header stash/pending reset reached, scratch guard rejected automatic offset progress | `small_credit_grant_precondition_failure/` |
| Corrected seven-case Debug | 7/7, terminal0 | `seven_case_green/` |

No failed row has been dropped, relabeled as passing, or inferred to pass
against a different source input. No further functional features were added
after the eighth paired delayed-FIN case.
