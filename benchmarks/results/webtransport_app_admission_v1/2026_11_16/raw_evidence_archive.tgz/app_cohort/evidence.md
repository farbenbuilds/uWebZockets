# Diagnostic evidence and scope

The original published-libxev RED remains failed. It exposed missing
header-time admission and the published io_uring poll-cancellation diagnostic.
The reviewed XEV-008 source is a second explicit verification input; selecting
it does not update the project's manifest or infer a pass for the published
fork. Both earlier runtime/backend and engine harnesses remain frozen.

After real coordinator implementation, the first seven-case run passed four
tests. Actual native diagnostics showed authorized responses in streaming
phase with `headers_sent=true`, server send offset zero, and peer response
credit 6291456. Root's production flush correction subsequently passed both
authorized session groups. Its native write callback remains armed while a
header stash is pending, then flushes/disarms after completion.

The original blocked-response fixture advertised zero bidi-local receive
credit. It failed TLS before any request or authorization callback: the peer
sent QUIC transport error 0x8, `bad transport parameters`. Frozen native
`lsquic_enc_sess_ietf.c:1912-1946` explains the failure: HTTP/3
`es_check_tp_sanity` requires the peer's bidi stream-data parameter to be
present and at least 0x1000. This is policy validation, not a zero-varint
encoding defect. The failing driver, bridge, original shared header, input
manifests and terminal log remain in
`harness/provenance/zero_credit_policy_failure`.

The corrected stress fixture advertises the accepted 4096-byte minimum and
returns one exact 4096-byte HTTP header field (`x: `, 4091 literal tilde bytes,
CRLF) through the public response API. QPACK/HTTP framing makes the serialized
head larger than peer credit. Native observations proved send offset/limit
4096/4096, header-send state 2, session closed and `pending_reset=0x10e`, with
no peer response headers or reset before additional credit. The shared decoded
header field bound alone changes from 1024 to 8192; the exact source diff and
both hashes are included. App response storage uses the supported 16384-byte
builder configuration. No native policy, source, or stream limit is patched.

The first corrected stress run reached the desired pending reset but exposed
an overly strict scratch grant precondition. Native decoding had consumed the
partial header and advanced its receive offset to 6432 while the receive
window remained 4096. The helper now validates the actual fixed initial
window and bounded current offset before raising it and invoking native SFCW
update. The decoder may have already queued automatic MAX_STREAM_DATA; the
assertions prove recovery after additional real native peer credit, without
claiming the explicit grant is its sole cause. The candidate encodes,
encrypts and sends every resulting QUIC frame through real UDP.

The eighth paired stress case sends a valid CLOSE_WEBTRANSPORT_SESSION capsule
followed by trailing DATA while the head is stashed. It requires the actual
native STREAM_DELAYED_SW bit, session closure and pending H3_MESSAGE_ERROR,
then real peer reset 0x10e and HTTP/header pool cleanup after credit. It shares
all credit and reset assertions with the prohibited-capsule case.

Open evidence gaps at this checkpoint: CONNECT-before-client-SETTINGS combined
with queued RESET/STOP, positive wire datagram delivery/ring clear, ignored
flow-control capsule followed by valid Close on wire, and positive typed child
stream integration through actual App. Typed child role transitions have pure
unit coverage and earlier real native backend evidence; this cohort does not
claim positive App child I/O. External-client interoperability is unclaimed.
No sanitizer, smoke, fuzz, scan, or security campaign was performed here.
