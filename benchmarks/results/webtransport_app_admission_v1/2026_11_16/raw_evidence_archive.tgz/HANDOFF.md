# App admission checkpoint handoff

Base project commit: `a42fa9017e877ca35af24d56eb7334446f432098`.
`project_overlay/` contains all 18 changed/new Zig files for this checkpoint;
`project_source_inputs.sha256` hashes their exact bytes relative to that
directory. Overlay them on a fresh checkout of the base commit to reconstruct
the tested project source. The public documentation and this checkpoint's
status are also retained under `project_docs/`.

## Verification

Zig was `/tmp/zig-x86_64-linux-0.16.0/zig`, version 0.16.0. Root runs used
`ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache` and these commands from the project:

```sh
zig build test-unit -j2 --summary all
zig build test-compile -Doptimize=ReleaseSafe -j2 --summary all
zig build lib -Doptimize=ReleaseFast -j2 --summary all
zig fmt src builds examples tests fuzz
sh scripts/check_conventions.sh
sh scripts/check_release_version.sh
git diff --check
```

The central suite passed 991/991 tests in 20/20 steps. ReleaseSafe compilation
and the ReleaseFast library each passed 21/21 steps. `root_checks/` retains
their terminal logs and captured exits. The exact final formatter command
protected/restored two nested generated package/cache directories; all 18
tested source hashes remained identical. Conventions, metadata and diff checks
passed. AST-only `graphify update .` refreshed ignored graph output.

The default `zig build test` was not executed because it also runs the C ABI
smoke target deferred by the user. No assertion, test or default target was
disabled. ReleaseSafe compiled smoke targets without executing them. Dedicated
smoke, sanitizer, fuzz and security campaigns remain deferred.

`capsule_isolated/` retains the worker's actual decoder/test scaffold and
historical/final logs. Its 16-case final codec cohort passed in Debug,
ReleaseSafe and ReleaseFast, 3/3 build steps each. Its build file records the
original absolute project paths; change only those paths for a relocated
checkout. Final source hashes are the same as the overlay's decoder and tests.

## Actual App/native cohort

The sibling `app_cohort/` directory contains the separately frozen complete
scaffold package. Verify its `package_inputs.sha256`; see `README.md`,
`results.md`, `evidence.md` and `harness/README.md` there for commands and
precise seams. Eight cases passed in all three modes, 16/16 steps per run.
Every run's selected 124-row before/after manifest matched. Its additional
package manifest covers all included scratch inputs; neither manifest is
represented as a complete transitive compiler-dependency inventory.

Replay with its `replay.sh` and the reconstructed project. Set
`UWZ_PROJECT_SOURCE`, `UWZ_LSQUIC_SOURCE` and `UWZ_ZIG` for restored locations.
The exact required libxev source snapshot is included. The lsquic candidate
is retained separately in the repository's
`benchmarks/results/lsquic_webtransport_children_v1/2026_11_16/` artifact.

Native candidate identities:

- lsquic: `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c`.
- libxev: `5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`.

Both native worktrees stayed clean. Published lsquic
`85bd081c9103c077a7cc98271d09334d0f1043d4` and libxev
`c49f6dfb83038c146232472c063e4b2681d098d8` remain unchanged in every production
manifest view. The libxev candidate supplies the reviewed poll-cancellation
fix required by the real io_uring teardown; this is an explicit verification
input, not evidence that the published backend passed that cohort.

## Failures and review

Original native-cohort failures and meaningful input snapshots are preserved
in `app_cohort/harness/provenance/`. The initial missing-admission failure,
published libxev cancellation diagnostic, absent CONNECT flush, include-order
compile failure, sandbox socket denial, zero-credit transport sanity rejection
and scratch credit-grant precondition failure remain labeled failures. The
native sanity policy requires at least 4096 bytes of bidi-local credit. The
corrected test uses that real limit and a larger serialized response head;
it does not disable policy or mutate server native state. Partial header
decoding may queue automatic credit, so the evidence claims recovery after
additional native peer credit, without assigning it solely to the explicit
client grant.

Early root API compile trials are not all reconstructable from complete
historical source snapshots. They are not counted as functional passes.
The final overlay, native cohort and all claimed final results are retained.

Independent App/router review found no required findings. Decoder review
accepted strict defaults and flow-off skip policy. Coordinator review found
cooldown reentry, missing-prerequisite error mapping, pending cancellation,
flow-off capsule validation and blocked-reset issues. Those were corrected;
the delayed-FIN retry and flush follow-up were re-reviewed. A final flush
failure finding was corrected by invalidating the session/route before the
asynchronous native close. Final engine hash:
`a315950f99d1f40642998ff124ca44cf23d34171c58361b5f8f38294f03aff8b`.
Final stream hash:
`a750a9dbc9db6471e21d2db8c329729f70f5504a529a14d3554baa605f64290e`.
Independent scaffold review found no actionable functional-proof findings in
the final eight cases. Its final provenance pass verified every one of the
217 package entries, 16 scratch sources and 42 included libxev sources,
matched all final log hashes and captured exits, and found no required issues.
Reviews were read-only; test execution is separately
attributed above.

## Remaining work

The published dependency pin keeps live WT disabled. Wire datagram delivery
and ring clearing, pending-SETTINGS RESET/STOP execution, ignored flow-control
capsules followed by Close on wire, bounded early associations, positive App
typed children, multi-session flow accounting, independent draft-16 client
acceptance and fork publication/pin synchronization remain open. The native
reset tests do not close these separate gates.

The broader v2.3.0 goal also retains its PostgreSQL TLS allocation and quiet-host
throughput gates, external HttpArena owner/release acceptance, platform and
second-machine evidence, fork closure and measured kTLS gates. SQLite's
SQL-ALLOC-001 exception is approved; PostgreSQL's SQL-ALLOC-002 is not. No
release/tag is created and no deferred check is claimed as passing.
