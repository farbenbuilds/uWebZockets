pub const webtransport_capsule_stream = @import("decoder");
