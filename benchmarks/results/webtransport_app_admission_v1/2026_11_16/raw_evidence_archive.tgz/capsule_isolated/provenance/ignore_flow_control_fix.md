# Negotiated flow-control capsule skipping

Draft-16 section 5.1 requires ignoring any flow-control capsule when session
flow control is disabled. Source:
https://www.ietf.org/archive/id/draft-ietf-webtrans-http3-16.html#section-5.1
The existing strict decoder validated complete known flow-control payloads,
including stream limits, before the engine could ignore them. It therefore
rejected reordered or semantically invalid flow-control input in that mode.

Options.ignore_flow_control defaults false. Decoder{} and Decoder.init(.{})
preserve strict behavior. Decoder.init(.{ .ignore_flow_control = true })
classifies the six flow-control capsule types for skipped-payload handling
before applying known-payload size or value validation. The header-completion
Event.unknown(type) still reports each capsule exactly once. Unknown declared
payload lengths remain full 62-bit values and are skipped incrementally;
framing and EOF completion remain mandatory. HTTP/2-only types 0x190b4d3e and
0x190b4d42 remain reported unknown events for the engine to reject explicitly.
Known close/drain validation and the 1044-byte carry bound are unchanged.

The prior strict-v1 files, first RED and all 11-test run logs/hashes are retained
under strict_v1/. The follow-up compile RED demonstrates the missing Options
API; ignore-flow-runtime-red.log then records 12 passing / 4 failing actual tests
before the policy gate. Failures include InvalidLength, InvalidStreamLimit and
NeedMoreData. The final 16 tests pass Debug, ReleaseSafe and ReleaseFast in 3/3
steps each using the actual centralized test file and decoder with only a
scratch test_support alias. No full project builds, smoke tests, scans or
other root source edits were performed. Root owns combined integration gates
and independent review.

New coverage includes every flow-control type with malformed 9-byte payload,
all six types with maximum declared length and truncated skip, excessive
stream limits followed by valid close, nonminimal/empty framing, HTTP/2-only
type notification, and all 11 unchanged strict-mode cases.
