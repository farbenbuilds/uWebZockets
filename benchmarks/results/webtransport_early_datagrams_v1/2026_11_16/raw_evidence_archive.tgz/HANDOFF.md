# Bounded early WebTransport datagrams

Base project commit: `aea6959966227ca05d6f723a21020e8692d7b7c9`.
Overlay `project_overlay/` on a full checkout of that commit. Its ten changed
or new Zig files are verified by `project_overlay_inputs.sha256`. The complete
246-file tracked-plus-new source/build inventory is `project_inputs.sha256`.
Restore package/generated-vendor inputs from the full checkout; the overlay is
not a standalone repository. `project_docs/` records the final status docs.

## Implemented contract

The private candidate backend now copies early payloads into separate
startup-owned entry, terminal-ID and payload slabs. The global pending capacity
is four times engine connection capacity; one connection generation can hold
at most four entries across its pending session IDs. Physical stride is 2048;
the separate App per-payload limit is enforced before enqueue. Ordinary
established dispatch reads no clock and allocates nothing.

The pure Store receives timestamps explicitly, expires at deadline equality,
uses saturating deadline addition, preserves per-key FIFO, and copies a taken
payload into caller output while removing its entry before any callback.
Engine drains only after authorization, establishment and header release,
revalidating connection, session, native cancellation and cooldown state after
every callback. A local dispatch ordinal is allocated for each eligible
dispatch attempt, including ring-full drops. Pending enqueue, rejection and
expiry allocate no ordinal. The ordinal is not a wire sequence number.

Retirement purges one exact connection-generation/session key and records a
bounded terminal identity without eviction or expiry during unknown buffering.
If it cannot record another terminal, only that connection latches
unknown buffering off. Already queued future-session entries remain intact;
new packets for still-unconfirmed IDs drop, even if an earlier packet for that
ID is queued. Established/draining dispatch and confirmed current accepting WT
remain eligible. Connection close clears both stores before generation reuse;
cooldown disables new unknown buffering before clearing both stores.

## Clock domains and native seam

Production expiry reads the real monotonic awake clock through a named private
Binding callback using App's existing std.Io context. Pure code reads no clock.
Engine reads it only for pending enqueue, expiry, drain and pending deadlines.
The one-second pending deadline participates in transport wakeup selection.

The retained native fixture uses its inherited **synthetic native scheduling
clock**, separately from this production OS-awake clock. This profile is
documented in `app_cohort/clock_domains.md`; no new native clock override was
introduced. The functional expiry case waits about 1.1 real awake seconds
without busy-advancing synthetic native time. Pure tests prove exact boundary,
zero-lifetime and saturation behavior deterministically.

Real native DATAGRAM writing, TLS and loopback UDP are retained. Actual packet
counts and unchanged decryption/duplicate/error counters support isolated
arrival inferences; the native library has no dedicated datagram receive
counter. Queued cancellation cases stage genuine encrypted input to expose
native RESET-known-before-notification and synchronous STOP ordering. These
seams do not replace production callbacks, mutate server peer state, or claim
real-time native scheduling/interoperability. See the scaffold's exact scope.

## Verification

`pure_queue_isolated/` retains the actual new pure Store, canonical identity
and centralized test scaffold. Sixteen tests pass Debug, ReleaseSafe and
ReleaseFast, 3/3 steps per mode. The initial missing-module RED is a compile
failure, not a runtime behavioral reproduction. The separate real native RED
below proves the missing end-to-end behavior.

Fresh published-dependency checks in `root_checks/` passed:

- `zig build test-unit -j2 --summary all`: 1009/1009 tests, 20/20 steps.
- `zig build test-compile -Doptimize=ReleaseSafe -j2 --summary all`: 21/21.
- `zig build lib -Doptimize=ReleaseFast -j2 --summary all`: 21/21.
- Required formatting, conventions, release metadata and diff checks.

The root compiler is Zig0.16.0 at `/tmp/zig-x86_64-linux-0.16.0/zig`, with
`ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache`. Formatting protected/restored nested
generated directories and left every tested source hash unchanged. AST-only
graphify refreshed ignored code output.

The default test target executes the user-deferred C smoke target;
`test-unit` runs the complete central suite and archive symbol check. The
ReleaseSafe compilation did not execute compiled smoke binaries. Dedicated
smoke, sanitizer, fuzz and security campaigns remain deferred. No test,
threshold, assertion or default target was weakened or disabled.

## Actual native results and replay

The sibling `app_cohort/` package contains all exact scratch inputs, mode
results, captured exits, source comparisons, original failure snapshots,
review fixes and replay commands. Its final cohort contains 33 Zig tests:
32 functional cases plus one import-discovery anchor. Final terminal logs and
matching source hashes are recorded in its `results.md`.

The recorded final runs passed 33/33 tests and 16/16 steps each, with captured
exit0: Debug16322, ReleaseSafe61791 and ReleaseFast19128. They comprise 17
retained functional cases and 15 new early-datagram cases, plus one anchor.
Original run documentation incorrectly said 16 new; the documentation-only
correction, original documents/manifests and unchanged code checks are retained
in `app_cohort/harness/provenance/docs_count_revision/`. No test rerun is
credited to that wording correction.

Use its `replay.sh` with `UWZ_PROJECT_SOURCE` pointing to the reconstructed full
project, `UWZ_LSQUIC_SOURCE` to the restored candidate and `UWZ_ZIG` as needed.
The required libxev sources are included. Native source identities are:

- lsquic `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c`; restore from the
  separate `lsquic_webtransport_children_v1/2026_11_16` artifact.
- libxev `5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`; required snapshot
  and manifest are retained in the scaffold package.

Both source trees stay clean. Production pins
`85bd081c9103c077a7cc98271d09334d0f1043d4` and
`c49f6dfb83038c146232472c063e4b2681d098d8` are unchanged. The candidate's
existing SETTINGS-constructor observer is a separately recorded test compile
profile that pauses/resumes original client control-writer bytes; no source
patch or fabricated settings are used.

The baseline real native RED observed datagrams A/B arriving before any
client-bidi stream, with no early authorization/callback/ring delivery. Actual
CONNECT0 then authorized and returned a non-FIN200, but zero callbacks replayed
where two were required. All prior 18 tests passed. Full source/log snapshots
are preserved in the new scaffold, while older checkpoints remain frozen.

The first implementation run passed 30/32 and exposed a real logical bound
mistake: App's complete connection ring span was supplied instead of one
payload's stride. A real 1472-MTU client delivered a 1201-byte payload against
the configured1200 bound, proving the failure before the one-line correction.
The other failed expectation incorrectly treated an already queued but
unconfirmed future ID as eligible for new packets after terminal exhaustion.
The architect explicitly reaffirmed retain-A/drop-new-B; no production policy
was changed to satisfy that expectation. Original evidence remains labeled.

Later proof refinements verify that exhaustion leaves other connections
enabled and that native RESET_KNOWN without RESET_VISIBLE stops an already
established session's datagram before deferred notification, while preserving
a pending future session and its ordinal0 replay. Any intermediate compiler
failure or weaker passing row is credited only for its actual assertions.

## Independent review and remaining work

The pure queue/identity/16 tests and their three-mode evidence were reviewed
read-only without required findings. Integration review checked allocation
rollback, exact retirement, reverse close ordering, generation reuse,
callback-safe copying, time/ordinal boundaries and clock-free established
dispatch. Changed-work review confirmed the payload-unit correction and two
central tests covering all startup allocation failures, overflow before
allocation and successful ownership/deinit.

Native fixture review resolved the per-connection exhaustion-isolation proof
gap. Separate review verified the final RESET-known-before-datagram sequence.
Reviewers did not run builds; their scope is distinct from the retained actual
execution. Root verifies the final combined archive by fresh extraction and
every payload hash.

Final provenance closure verified all 252 resealed scaffold package entries,
19 archived inputs, 18 unchanged code inputs, 42 required libxev files,
246 project inputs, native profiles, all three final logs/exits, and the
preserved original documentation/manifests. The documentation count correction
has no remaining required findings. Outer overlay, root checks and handoff
verification are owned by the root integrator.

This slice implements early datagrams only. Early child-stream association,
positive App child I/O, multi-session accounting, independent draft-16 client
acceptance and maintained-fork publication/pin synchronization remain open.
The published backend still rejects unsupported live WT; no release or tag
is created. The broader v2.3.0 goal retains strict PostgreSQL TLS allocation,
quiet-host throughput, HttpArena owner/release acceptance, native platform and
second-machine evidence, fork closure and measured kTLS gates. SQLite
SQL-ALLOC-001 is approved; PostgreSQL SQL-ALLOC-002 is not.
