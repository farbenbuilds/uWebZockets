const std = @import("std");
pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const pending = b.createModule(.{
        .root_source_file = .{ .cwd_relative = "/home/foo/Desktop/Repos/uWebZockets/src/quic/webtransport/pending_datagrams.zig" },
        .target = target,
        .optimize = optimize,
    });
    const support = b.createModule(.{
        .root_source_file = b.path("test_support.zig"),
        .target = target,
        .optimize = optimize,
        .imports = &.{.{ .name = "pending", .module = pending }},
    });
    const root = b.createModule(.{
        .root_source_file = .{ .cwd_relative = "/home/foo/Desktop/Repos/uWebZockets/src/tests/webtransport_pending_datagram_tests.zig" },
        .target = target,
        .optimize = optimize,
        .imports = &.{.{ .name = "test_support", .module = support }},
    });
    const tests = b.addTest(.{ .root_module = root });
    const run = b.addRunArtifact(tests);
    const step = b.step("test", "Run actual centralized pending-datagram pure tests");
    step.dependOn(&run.step);
    b.default_step = step;
}
