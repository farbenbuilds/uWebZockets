# Pure pending WebTransport datagram store

The isolated build imports the actual project pending_datagrams.zig and its
canonical identity.zig. Its test root is the actual centralized
webtransport_pending_datagram_tests.zig. The scratch test_support only aliases
the pending module; no project native backend or callback is simulated.

Store owns no allocation. Storage retains the original caller-provided entry,
payload and terminal slices, and Policy remains visible for the engine owner.
Indexed active/free lists preserve per-key FIFO without moving payload strides.
All expiry decisions use supplied microseconds; saturated deadlines expire at
equality, including maxInt(u64). Zero TTL is permitted and becomes ineligible
on the next time-bearing operation at that timestamp. Output must not alias
Store backing regions; take_into copies and unlinks before returning to caller
code, so subsequent queue mutation cannot overwrite the copied payload.

enqueue first expires old entries, then rejects retired identity, physical
payload overflow, per-connection quota or global exhaustion. Rejection leaves
retained entries untouched. Quota groups all session IDs within the exact
connection index/generation. retire always purges its exact key, then remembers
it without expiry/eviction if terminal capacity exists. Duplicate remembered
retirement succeeds without consuming another terminal. Exhaustion is reported
explicitly for the engine to latch its separate conservative early-data policy.
clear_connection removes both pending data and terminals only for that exact
connection generation. next_deadline computes the earliest pending time even
when supplied timestamps do not follow insertion order.

The initial RED fails because pending_datagrams.zig did not exist. All sixteen
actual centralized tests subsequently pass Debug, ReleaseSafe and ReleaseFast
in 3/3 build steps each. Debug evidence is first-green.log; unchanged sources
were not rerun merely to rename the log. final-runs.json records each actual
command, working directory, log and exit code. final_inputs.sha256 covers all
three project files and both scratch build/namespace files and validates after
the final mode. Zig version is 0.16.0.

Coverage includes input-copy ownership and matching FIFO, unrelated keys,
per-connection quotas across sessions and generations, global fullness,
oversized-payload rejection and retained-entry atomicity, exact expiry and
recovery, earliest deadlines, saturated maximum timestamps, zero TTL/payload,
small-output atomicity, copy-out before caller mutation, exact retirement,
terminal-budget exhaustion/duplicate behavior, permanent terminal identities,
exact generation cleanup and geometry/overflow failures before mutation.

Commands from this directory:

```sh
zig build test -Doptimize=Debug --summary all
zig build test -Doptimize=ReleaseSafe --summary all
zig build test -Doptimize=ReleaseFast --summary all
```

No full-root build, root conventions/release checks, graph update, native
runtime tests, smoke/security/sanitizer/fuzz campaign, commit or push was run
by this worker. The root agent owns combined integration and independent
review. No old capsule files or checkpoints were changed.
