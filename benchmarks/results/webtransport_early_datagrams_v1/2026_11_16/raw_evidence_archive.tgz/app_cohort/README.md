# Actual early datagram verification checkpoint

This package contains the isolated actual App/native harness, exact source
inputs, terminal logs, historical failures, contract clarification, review
follow-ups and replay commands. The final driver has 33 Zig tests: 32 functional
cases plus one import anchor. It retains 17 predecessor functional cases and
adds 15 early-datagram cases. The breakdown is 8 admission, 10 routing
(including the baseline early case), and 14 pending-datagram cases.
Predecessor harnesses/checkpoints remain untouched.

The baseline RED proved two actual datagrams arrived before any CONNECT and
were lost after real authorization/non-FIN200. The first feature run found a
real logical-bound regression: an actual 1201-byte payload occupied pending
storage because the binding used a total slab size rather than one 1200-byte
ring stride. The root corrected that production bound. A separate failed latch
expectation was clarified by the architect and is preserved separately; it is
not called a production defect. See `results.md` and the provenance notes.

Coverage includes pending SETTINGS, FIFO/quota/global bounds, actual oversized
wire input, real-clock expiry, dispatch ordinals, exact SID retirement, future
SID survival, per-connection terminal exhaustion/latches, generation reuse,
callback-triggered cooldown and queued RESET-known-before-datagram protection.
The actual handler verifies authorization and established session state on each
new queued delivery. Native packet/writer counters prove isolated arrival;
they are explicitly an inference from a known DATAGRAM-bearing packet rather
than a native per-DATAGRAM receive counter. Named queued cancellation cases
stage actual native-encrypted packets directly to control ordering, without
callback replacement or fabricated frames/cache state.

Clock domains are explicit: native TLS/QUIC scheduling inherits the existing
deterministic SYNTHETIC fixture clock. Production pending expiry uses the
actual private App binding std.Io.awake OS clock and one-second TTL. Its native
functional case performs a real 1100 ms awake sleep. Synthetic native-clock
advancement is not presented as OS-clock expiry proof.

Immutable candidate inputs remain clean, and production pins are unchanged:

- lsquic `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c`.
- libxev `5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`.

The root supplies the matching project source overlay and complete archived
lsquic source. This package includes the exact required 42-file libxev runtime
and build source snapshot, its manifest, LICENSE and README. The copied zon
pins the other native dependencies; Zig compiles all C/C++ from source. The
existing native SETTINGS constructor observer profile is enabled; no candidate
source or package-cache source is patched.

Replay requires Zig 0.16.0, Linux loopback UDP and io_uring access outside the
managed socket sandbox. Set `UWZ_PROJECT_SOURCE`, `UWZ_LSQUIC_SOURCE`,
`UWZ_LIBXEV_SOURCE` or `UWZ_ZIG` for relocated inputs. The script can link an
existing project package directory; no cache, binary or TLS key is archived.

```sh
sh replay.sh Debug
sh replay.sh ReleaseSafe
sh replay.sh ReleaseFast
```

`harness/README.md` describes the precise assertions. Source/build inventories
and candidate identities allow matching the root overlay. The root owns its
unit/build gates and final integration. Child stream I/O, multi-session flow
control, independent-client interoperability, dependency promotion and other
planned gates remain open. Dedicated smoke/security/sanitizer/fuzz campaigns
remain deferred.
