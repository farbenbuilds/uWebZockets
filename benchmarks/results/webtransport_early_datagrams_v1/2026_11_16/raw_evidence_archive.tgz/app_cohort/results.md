# Authoritative results

The exact final reviewed source passed all three modes:

| Mode | Session | Exit | Zig tests | Functional cases | Build steps |
| --- | ---: | ---: | ---: | ---: | ---: |
| Debug | 16322 | 0 | 33/33 | 32 | 16/16 |
| ReleaseSafe | 61791 | 0 | 33/33 | 32 | 16/16 |
| ReleaseFast | 19128 | 0 | 33/33 | 32 | 16/16 |

One Zig test is the import anchor. Source comparison manifest SHA-256:
`b420c5589eaedd25cceec1671bb71a5fee927f5016606f04276b2779bf08f9de`.
All 19 scratch source/build inputs and all 246 matching project source/build
inputs matched after every mode. Project inventory SHA-256:
`892d02156f7f27adac4aa7efeacb81b8d93d2f5285763dfa917cfb9044cb48ba`.
Both native candidate worktrees stayed clean; scratch Zig formatting passed.

Final log SHA-256:

- Debug: `8143bece2591a612474425dc491bcc40d84bd319b2a90c585bed1d2ce0421f81`
- ReleaseSafe: `25499a5f3c1db1dc46c0ab4b525add1d9ed5acb033296725c94f983384052be4`
- ReleaseFast: `a81fd6197f03a824592e6170811fcc312305b055c313999e38dc8a5d7aee249b`

Matching logs, immediate shell exit files and source/project check outputs are
under `harness/provenance/final_*`. Root owns the broader repository gates.

The command for each recorded mode was:

```sh
cd /tmp/uwz-wt-app-pending-harness
ulimit -c 0
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-uni-global-cache \
  /tmp/zig-x86_64-linux-0.16.0/zig build test \
  -Doptimize=Debug \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-streams-20261113 \
  -Dlibxev-source=/tmp/uwz-gro-libxev -j2 --summary all
```

Only optimize changed for ReleaseSafe and ReleaseFast. Real loopback access
used the explicitly authorized execution context. Transport/TLS timing used
the inherited SYNTHETIC native fixture clock; production expiry used real
std.Io.awake time and the actual 1100 ms sleep. These clocks are not conflated.

Historical rows remain distinct:

| Row | Terminal outcome | Meaning and retained evidence |
| --- | --- | --- |
| Baseline RED4903 | exit1,18/19 Zig tests | Prior18 passed; new early FIFO replay failed expected2/found0 after proved wire arrival and actual authorized CONNECT0. Full snapshot in `baseline_red_snapshot`; log SHA338cd545b7417f38b85bd8b19fd76a98b85f8b9aa393b5e077c2aeac0e826115. |
| First feature52360 | exit1; no tests ran | One unused scratch helper parameter. Failed source/compile log in `feature_first_compile_failure`; removed only unused input. |
| Feature22367 | exit1,30/32 Zig tests | Actual 1201-byte native payload violated logical pending bound; separately an initial unconfirmed-latch expectation needed architect clarification. Full matching sources/root runtime copies in `feature_first_functional_red`; log SHAe9aa795922bc3290bae5fd205cfb5ca62ffd2a4c803065d4f9a18724a6f180a0. |
| Bound/contract51983 | exit0,32/32 Zig tests | Logical-bound fix and clarified retain-A/drop-unconfirmed-B policy passed; `feature_first_green`. It lacks the later RESET-known dispatcher case and post-exhaustion healthy-connection assertions. |
| RESET guard44416 | exit0,33/33 Zig tests | Added actual cancellation-first established-parent DG guard proof; `reset_guard_first_green`. Later unaffected-connection latch scope assertions were not yet present. |
| Final reviewed modes | exit0,33/33 each | All required review refinements and source checks present; final logs listed above. |

Original failures were not dropped or inferred to pass against another input.
The root-owned payload-bound fix and explicit latch-policy clarification are
documented separately. Earlier GREEN rows are not credited with later proof.
No native source/pin change or dedicated smoke/security/sanitizer/fuzz campaign
was performed for this cohort.
