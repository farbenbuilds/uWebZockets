# Native and clock profile

The required source identities are the unchanged lsquic candidate
`2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c` and reviewed libxev candidate
`5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`. Full HEAD/tree identities and
empty dirty-status records are included. Project base identity is recorded in
`project_base_head.txt`; the root supplies the matching production overlay.

The final copied lsquic helper calls `lsquic.build(..., true, false, true)`:
existing fixture-clock indirections enabled, reset-ack observer disabled,
existing SETTINGS constructor observer enabled. No native fork source or
dependency-package source is rewritten. Matching C fixture layout definitions
include LSQUIC_CONN_STATS=1, LSQUIC_DEBUG_NEXT_ADV_TICK=1 and HAVE_BORINGSSL.
The exact source lists, flags and link graph are archived.

The constructor observer holds the actual client critical control writer2 and
resumes its original buffered SETTINGS bytes. Ordinary packet input/output is
real native TLS/QUIC plus loopback UDP and the actual App transport. Explicit
queued-reset timing cases feed actual encrypted packets directly to native
input, never manually invoking or replacing production callbacks.

The inherited native clock is SYNTHETIC and deterministic. Production pending
expiry instead samples the private App binding's real std.Io.awake clock. The
functional expiry case waits1100 real awake milliseconds for the one-second
TTL. Pure queue tests with caller-supplied times are separate evidence owned
by the root. See harness/provenance/clock_domains.md for all historical rows.

For actual oversized wire input, only the new LARGE_DATAGRAM client variant
sets supported base/max PLPMTU1472. Its native bounded queue buffer is2048 and
both peers advertise receive capacity2048. The test requires constructor values,
actual native writer and one-packet arrival proof before checking rejection at
the single-ring logical bound1200. Native writer rejection is not credited as
engine bounds coverage. This client startup configuration is no native patch.

Required42-file libxev runtime/build sources are included with the original
verified inputs manifest, plus LICENSE/README. Other native dependencies are
fixed by the copied zon; all are built using Zig. Production pins stay unchanged.
