# Terminal-budget contract clarification

The first feature run expected a second datagram for a previously queued but
still unconfirmed future SID to be enqueued after the connection's unknown
admission latch was set. That source and failure remain preserved in
`feature_first_functional_red`; it is not relabeled as a production defect.

The root architect explicitly clarified the accepted policy:

> Queued A does not prove confirmed WT. After terminal exhaustion retain A,
> drop new B while SID4 is unconfirmed; CONNECT4 drains only A. Subsequent
> associated DG4 works normally.

The corrected case therefore requires pending A to survive unrelated SID0
retirement, verifies neither later unconfirmed B nor unknown SID8 replaces A,
then requires actual CONNECT4 to replay exactly A with dispatch ordinal0.
A fresh real DG4 after establishment must reach callback/ring with ordinal1.
The latch remains set through session close, unconfirmed closed IDs cannot
resurrect, actual CONNECT8 remains usable, and connection-generation reuse
clears the latch with a fresh ordinal0. No root policy change was requested.
