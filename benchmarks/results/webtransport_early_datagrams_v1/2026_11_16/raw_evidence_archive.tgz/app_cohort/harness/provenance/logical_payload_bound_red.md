# Actual logical-payload bound failure

The first functional feature run used the supported native client startup
configuration base/max PLPMTU1472 and transmitted a 1201-byte application
payload in a real native DATAGRAM. Native writer count, one queued/sent UDP
packet and target native packet-statistics arrival assertions all passed.
The pending queue then contained one entry instead of rejecting it. This is
actual wire evidence, not client-writer rejection or a pure geometry check.

The root diagnosed the binding bound: App.datagram_stride is the total
per-connection slab (four times1200), while each ring payload_stride is1200.
Binding max_payload had used the former and was clamped only to physical2048.
The root owns the correction to use the actual ring's single-payload stride.
The failed sources, four matching project runtime files, terminal log, exit
and before/after manifests remain in `feature_first_functional_red`.
