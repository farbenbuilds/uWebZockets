# Clock domains for every native row

All native rows in this harness inherit the frozen routing cohort's existing
deterministic synthetic native-clock profile. The native C fixture supplies
the process-wide clock wrapper and advances it through the existing pair
process API. That transport/TLS scheduling clock is not real wall time.
No new clock override or mutable global was introduced for this feature.

Production early-datagram expiry uses the private App binding's actual
std.Io.awake OS-clock callback, with a one-second policy lifetime. The expiry
functional case waits1100 real awake milliseconds through std.Io.sleep before
admission. It does not busy-pump synthetic native time or assign queue timestamps.
Pure module tests use explicit caller-provided times for deterministic boundary
coverage; those are separate from this actual OS-clock functional case.

This statement applies to the preserved baseline RED, compilation failure,
first functional RED, policy-clarification and all later GREEN/mode rows.
Frozen predecessor source snapshots are retained verbatim rather than edited
to insert later provenance wording.
