# Actual early WebTransport datagram harness

This new scratch tree extends the frozen routing cohort; all predecessor
harnesses/checkpoints remain untouched. The driver has33 Zig tests:32
functional cases plus one import anchor. It retains17 prior functional cases
and adds16 early-datagram cases. The actual project App, native TLS/QUIC,
loopback UDP transport, router and backend run together with bounded fixtures.

The baseline RED sent actual native DG0 A/B before any client-bidirectional
stream, proved arrival and no preauthorization delivery, then completed real
authorized CONNECT0/non-FIN200. The original engine lost both payloads: expected
two callbacks, found zero. Exact baseline sources/runtime copies/logs remain
under `provenance/baseline_red_snapshot`.

## Required behavior and proof

- Early DG0 and DG0 received while actual client SETTINGS/header admission are
  pending stay out of App callbacks/rings until authorization and establishment.
  The actual handler checks that state at each callback. Retained payloads
  replay FIFO into exact callback history and ring bytes.
- Global storage is16 entries for this four-connection App, with four per
  connection, physical2048-byte slots and a logical1200-byte ring payload bound.
  Per-connection overflow retains the first four; four live connections fill
  all16 and drain independently. App ring exhaustion is tested separately.
- Local ordinals are assigned immediately before eligible direct/drained
  delivery, including App ring-full drops. Enqueue rejection, expiry and retired
  unknown IDs consume none. They are dispatch ordinals, not wire sequence fields.
- Expiry uses the production private binding's real std.Io.awake clock with a
  one-second lifetime. A single actual1100ms sleep precedes admission; expired
  data does not replay and a fresh direct datagram gets ordinal0.
- An unknown future SID4 queued before live SID0 survives Close0 and receives
  its ordinal after the live payload. Normal HTTP, refusals, RESET, STOP and
  Close retire exact SIDs; unrelated pending data survives and retired IDs never
  resurrect. Connection abort clears pending data/tombstones before generation
  reuse, with a fresh handle, latch and ordinal0.
- Global terminal-record exhaustion retains previously queued A but rejects
  new packets for an unconfirmed SID, including later B for the same future
  SID. Confirmed active WT delivery remains usable. Only the affected connection
  latches unknown admission off; other live connections remain enabled. The
  latch persists until connection close, and fresh generation state resets it.
- The first drained callback requests actual engine.cooldown. Remaining queued
  bytes and existing tombstones clear, no second drained callback occurs,
  native GOING_AWAY proves deferred cooldown, and later eligible direct delivery
  remains usable with the next dispatch ordinal.
- The established-parent cancellation case stages actual RESET before actual
  DG0 while native RESET_KNOWN is set but RESET_VISIBLE is clear. No public
  server process runs between packets. The datagram must not reach App/ring or
  consume an ordinal; ordinary notification then retires0 and future4 survives.

Each ordinary DG uses real native writer output and exactly one isolated
queued/sent UDP packet. Native target packet count must advance exactly once
without undecodable, duplicate or error increases. This is a bounded inference
from a known DATAGRAM-bearing packet, not a native per-DATAGRAM receive counter.
The explicitly named queued cancellation cases stage native-encrypted packets
directly into actual native packet input to control ordering; they do not claim
xev receive timing for that seam or manually invoke/replace callbacks.

## Bounds regression and clarified policy

The first feature run exposed a real logical bound bug: App.datagram_stride
was the total per-connection slab, rather than one ring payload stride. With
legitimate native base/max PLPMTU1472, an actual1201-byte payload arrived and
incorrectly occupied pending storage. The root corrected Binding.max_payload
to the actual ring payload_stride1200. Native writer rejection is never treated
as engine bounds evidence. The bounded client DG buffer is2048 only in this tree.

That row also preserved an initial unconfirmed-SID latch expectation. The
architect clarified that queued A is retained but does not itself confirm WT:
later unconfirmed B drops after latching; CONNECT4 drains A and associated
delivery then works. The failed expectation, explicit clarification and revised
assertions remain separate in provenance; no production policy change is claimed.

## Inputs, clocks and lifecycle

Native candidates remain clean and unchanged:

- lsquic `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c`.
- libxev `5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`.

The copied native build uses the existing SETTINGS constructor observer to hold
the actual client control writer2 and resume its original buffered bytes.
No native source, package source, production dependency pin, peer cache or wire
frame is patched. Relevant native layout definitions match in the C bridge.

The inherited native fixture clock is deterministic and synthetic, and is
explicitly separate from production's real awake expiry clock. See
`provenance/clock_domains.md` for every recorded row. TLS material stays in
memory. Teardown calls actual transport shutdown, drains real xev completions
within the bound, then calls App shutdown/deinit without assigning drain flags.

```sh
ulimit -c 0
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-uni-global-cache \
  /tmp/zig-x86_64-linux-0.16.0/zig build test \
  -Doptimize=Debug \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-streams-20261113 \
  -Dlibxev-source=/tmp/uwz-gro-libxev -j2 --summary all
```

Use real Linux loopback/io_uring permissions; the managed socket sandbox is
insufficient. Core dumps are disabled. Mode results are recorded only after
authoritative termination and before/after source checks. Positive App child
stream I/O and external-client interoperability remain outside this cohort;
smoke, security, sanitizer and fuzz campaigns remain deferred.
