test {
    _ = @import("app_admission.zig");
    _ = @import("app_routing.zig");
}
