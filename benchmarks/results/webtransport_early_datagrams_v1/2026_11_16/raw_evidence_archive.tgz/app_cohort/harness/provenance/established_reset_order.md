# Established parent cancellation before notification

This added functional case targets the actual datagram dispatcher preflight.
After real CONNECT0 establishment it retains an unrelated early SID4 datagram,
then generates and stages actual client RESET packets without public server
processing. Native receive state must report RESET_KNOWN while RESET_VISIBLE
is still clear and the actual root session is still open.

The fixture then generates exactly one actual native DATAGRAM-bearing packet
for SID0 and stages that encrypted packet after RESET, still without public
processing. Native packet counters and writer/packet counts prove arrival;
callback/ring state and dispatch ordinal must remain unchanged. Only afterward
does public processing publish ordinary reset notification and release the
parent. SID4 must survive that exact-key retirement and later replay with
ordinal0 after actual CONNECT4. No callback is replaced or invoked manually,
and no peer/cache/cancellation state or wire frame is fabricated.
