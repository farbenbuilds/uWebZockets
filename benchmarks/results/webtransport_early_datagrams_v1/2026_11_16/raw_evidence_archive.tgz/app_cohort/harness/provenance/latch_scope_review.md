# Affected-connection latch scope

The earlier terminal-exhaustion case checked the two healthy connections'
unknown-admission flags only before the target's failed retirement. Its
passing32-test snapshot remains in `feature_first_green`; the added reset
guard33-test row is preserved in `reset_guard_first_green`. Neither row is
credited with the stronger affected-connection scope proof.

The refined case additionally requires both healthy live connections to keep
unknown_early_disabled false immediately after the target's seventeenth
terminal retirement fails, after its later session retirement, and after its
abort. Only the affected target latches on terminal-budget exhaustion.
Cooldown's separate all-current-connections cancellation policy is unchanged.
No project source fix is implied by this coverage finding.
