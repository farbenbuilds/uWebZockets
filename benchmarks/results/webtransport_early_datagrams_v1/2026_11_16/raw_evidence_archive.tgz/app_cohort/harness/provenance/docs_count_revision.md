# Post-run documentation count correction

This revision changes README counts only after the final native runs. The
correct total is 32 functional cases: 8 admission plus 10 routing (including
the new baseline early case) plus 14 pending-datagram cases. Thus 17 cases
were retained and 15 were added; one import anchor gives 33 Zig tests.

No code, build graph, dependency, test assertion, clock profile or test result
changed, and no modes were rerun. The native scheduling clock remains the
inherited SYNTHETIC fixture clock; production expiry remains real std.Io.awake.

Original checked run documents and manifests are preserved verbatim under
`docs_count_revision/`. The original run source manifest remains
`b420c5589eaedd25cceec1671bb71a5fee927f5016606f04276b2779bf08f9de`;
its README hash was
`a95b5c86005cb8cbda9c2cf5dad08ca1ede494fec416d5005da707463eba1aec`.
Original archived19-source and package manifest hashes were respectively
`4dc36bcce28d6d20c06cad1859b65b6b379f442f2c33f57264b32b4a3f920094`
and `fac9d9e53e96477b179a325313c567220be9e2105e122703daafffb1a89396b8`.
Those historical manifests and successful check records describe the original
run/archive, while regenerated archive manifests describe the corrected docs.
