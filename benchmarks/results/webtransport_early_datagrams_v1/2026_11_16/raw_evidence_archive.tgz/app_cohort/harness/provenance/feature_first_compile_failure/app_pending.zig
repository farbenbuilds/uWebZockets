const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const shared = @import("app_routing.zig").PendingSupport;
const App = shared.Application;
const Observer = shared.EarlyObserver;
const RouteObserver = shared.RouteObserver;
const backend = support.webtransport_backend;
const testing = std.testing;

const Accepted = struct {
    id: u64 = 0,
    authorization_calls: usize = 1,
    mark_client: bool = true,
};

const Cancel = enum { reset, stop };

fn pending_count(application: *const App) usize {
    return application.quic_transport.?.engine.pending_datagrams.?.store.pending_count;
}

fn terminal_count(application: *const App) usize {
    return application.quic_transport.?.engine.pending_datagrams.?.store.terminal_count;
}

fn authorize(context: *anyopaque, request: *support.Request, response: *support.public_api.Response) void {
    const observed: *Observer = @ptrCast(@alignCast(context));
    observed.authorization.authorization_calls += 1;
    shared.header_observation(observed.authorization, request);
    const origin = request.get_unique_header("origin") orelse "";
    const authorization = request.get_unique_header("authorization") orelse "";
    const accepted = std.mem.eql(u8, origin, "https://localhost") and std.mem.eql(u8, authorization, "Bearer admission-fixture");
    response.end(if (accepted) "200 OK" else "403 Forbidden", "") catch {
        observed.authorization.failed = true;
    };
}

fn listen(application: *App, observed: *Observer) !u16 {
    try application.enable_http3_ephemeral();
    _ = try application.datagram_context("/wt", observed, shared.datagram_handler);
    _ = try application.route_context(.connect, "/wt", observed, authorize);
    _ = try application.route_context(.post, "/header-overwrite", observed.authorization, shared.health_handler);
    try application.listen_udp("127.0.0.1", 0);
    return application.quic_transport.?.local_address.ip4.port;
}

fn open_connect(client: *c.struct_uwz_app_client, origin: [*:0]const u8) !u64 {
    var request: c.struct_uwz_app_connect_request = .{
        .origin = origin,
        .authorization = "Bearer admission-fixture",
        .duplicate_origin = 0,
    };
    const id = c.uwz_app_client_open_connect(client, &request);
    try testing.expect(id != std.math.maxInt(u64));
    return id;
}

fn accept(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, observed: *Observer, expected: Accepted) !usize {
    observed.expected_session = expected.id;
    observed.expected_authorizations = expected.authorization_calls;
    try testing.expectEqual(expected.id, try open_connect(client, "https://localhost"));
    return await_accepted(application, client, clients, observed, expected);
}

fn await_accepted(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, observed: *Observer, expected: Accepted) !usize {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try shared.pump(application, clients);
        const response = try shared.response_snapshot(client, expected.id);
        if (response.header_callbacks == 0) continue;
        try testing.expectEqual(@as(c_uint, 1), response.header_callbacks);
        try testing.expectEqual(@as(c_uint, 200), response.status_code);
        try testing.expectEqual(@as(c_uint, 0), response.fin_received);
        try testing.expectEqual(expected.authorization_calls, observed.authorization.authorization_calls);
        const index = try shared.find_connection(application, client);
        try testing.expectEqual(index, observed.connection_index.?);
        const engine = &application.quic_transport.?.engine;
        try testing.expectEqual(.established, engine.connections.pool.storage[index].sessions.states[0]);
        try testing.expectEqual(@as(usize, 0), engine.header_pool.count_active());
        if (expected.mark_client) {
            try testing.expectEqual(backend.CreateResult.ok, backend.accept_connect(c.uwz_app_client_stream(client, expected.id)));
        }
        return index;
    }
    return error.PendingAdmissionTimeout;
}

fn held_handshake(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client) !usize {
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_connect(client));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try shared.pump(application, clients);
        const snapshot = try shared.client_snapshot(client);
        if (snapshot.handshake_complete == 0 or snapshot.settings_callbacks == 0) continue;
        const index = shared.find_connection(application, client) catch continue;
        try testing.expectEqual(@as(c_uint, 1), snapshot.control_constructed);
        try testing.expectEqual(@as(c_uint, 1), snapshot.control_held);
        try testing.expectEqual(@as(u64, 0), snapshot.control_offset);
        try testing.expectEqual(@as(u64, 0), snapshot.control_buffered);
        const connection = &application.quic_transport.?.engine.connections.pool.storage[index];
        try testing.expect(connection.peer == null);
        const canary: backend.Peer = .{ .initial_max_data = 77 };
        var peer = canary;
        try testing.expectEqual(backend.QueryResult.pending, backend.read_peer(connection.native, &peer));
        try testing.expectEqual(canary, peer);
        return index;
    }
    return error.PendingHeldHandshakeTimeout;
}

fn await_pending_headers(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, index: usize) !void {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try shared.pump(application, clients);
        const stream_index = shared.server_stream(application, index, 0) catch continue;
        const context = &application.quic_transport.?.engine.stream_contexts[stream_index];
        if (!context.state.pending_settings) continue;
        try testing.expect(context.http.header_set != null);
        return;
    }
    return error.PendingHeldHeaderTimeout;
}

// This isolates a real native DATAGRAM-bearing packet without consuming any
// target client-bidirectional stream as an ordinary HTTP barrier.
fn wire(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, index: usize, session_id: u64, payload: []const u8) !void {
    try shared.settle(application, clients, index);
    const native = application.quic_transport.?.engine.connections.pool.storage[index].native;
    const before = try shared.native_input(native);
    const client_before = try shared.client_snapshot(client);
    var bytes: [2048]u8 = undefined;
    const size = try support.webtransport.encode_datagram(session_id, payload, &bytes);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_queue_datagram(client, &bytes, size));
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_process(client));
    try testing.expectEqual(client_before.datagrams_written + 1, (try shared.client_snapshot(client)).datagrams_written);
    try testing.expectEqual(@as(c_uint, 1), c.uwz_app_client_pending_packets(client));
    try testing.expectEqual(@as(c_int, 1), c.uwz_app_client_send_udp(client));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try application.loop.get_xev_loop().run(.no_wait);
        application.quic_transport.?.engine.process();
        const after = try shared.native_input(native);
        if (after.packets == before.packets) continue;
        try testing.expectEqual(before.packets + 1, after.packets);
        try testing.expectEqual(before.undec_packets, after.undec_packets);
        try testing.expectEqual(before.dup_packets, after.dup_packets);
        try testing.expectEqual(before.err_packets, after.err_packets);
        return;
    }
    return error.PendingNativeDatagramArrivalTimeout;
}

fn expect_callback(observed: *const Observer, index: usize, session_id: u64, payload: []const u8) !void {
    try testing.expect(observed.count > index);
    try testing.expectEqual(session_id, observed.session_ids[index]);
    try testing.expectEqualSlices(u8, payload, observed.payloads[index][0..observed.sizes[index]]);
    try testing.expect(!observed.invalid_gate);
}

fn expect_ring(application: *App, index: usize, session_id: u64, ordinal: u64, payload: []const u8) !void {
    const datagram = application.next_datagram(index) orelse return error.MissingPendingReplay;
    try testing.expectEqual(session_id, datagram.session_id);
    try testing.expectEqual(ordinal, datagram.sequence_number);
    try testing.expectEqualSlices(u8, payload, datagram.payload);
}

test "pending quota retains four FIFO entries without assigning enqueue ordinals" {
    var application = try shared.initialize();
    defer shared.destroy(&application);
    var route: RouteObserver = .{ .application = &application };
    var observed: Observer = .{ .application = &application, .authorization = &route };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try shared.handshake(&application, client, &clients);
    observed.connection_index = index;
    const payloads = [_][]const u8{ "quota-A", "quota-B", "quota-C", "quota-D", "quota-E-drop" };
    for (payloads) |payload| try wire(&application, client, &clients, index, 0, payload);
    const store = &application.quic_transport.?.engine.pending_datagrams.?.store;
    try testing.expectEqual(@as(usize, 16), store.storage.entries.len);
    try testing.expectEqual(@as(usize, 16), store.storage.terminals.len);
    try testing.expectEqual(@as(usize, 16 * 2048), store.storage.payloads.len);
    try testing.expectEqual(@as(usize, 2048), store.policy.payload_stride);
    try testing.expectEqual(@as(usize, 4), store.policy.per_connection_limit);
    try testing.expectEqual(@as(u64, 1000000), store.policy.lifetime_us);
    try testing.expectEqual(@as(usize, 4), pending_count(&application));
    const connection = &application.quic_transport.?.engine.connections.pool.storage[index];
    try testing.expectEqual(@as(u64, 0), connection.receive_ordinal);
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expectEqual(@as(usize, 0), application.datagram_rings[index].len());
    _ = try accept(&application, client, &clients, &observed, .{});
    try testing.expectEqual(@as(usize, 0), pending_count(&application));
    try testing.expectEqual(@as(usize, 4), observed.count);
    for (payloads[0..4], 0..) |payload, ordinal| try expect_callback(&observed, ordinal, 0, payload);
    try testing.expectEqual(@as(u64, 4), connection.receive_ordinal);
    try testing.expectEqual(@as(usize, 4), application.datagram_rings[index].len());
    try testing.expectEqual(@as(u64, 0), application.datagram_rings[index].dropped);
    try wire(&application, client, &clients, index, 0, "direct-ring-full");
    try testing.expectEqual(@as(usize, 4), observed.count);
    try testing.expectEqual(@as(u64, 1), application.datagram_rings[index].dropped);
    try expect_ring(&application, index, 0, 0, payloads[0]);
    try wire(&application, client, &clients, index, 0, "direct-after-full");
    try expect_callback(&observed, 4, 0, "direct-after-full");
    for (payloads[1..4], 1..) |payload, ordinal| try expect_ring(&application, index, 0, ordinal, payload);
    try expect_ring(&application, index, 0, 5, "direct-after-full");
    try testing.expectEqual(@as(u64, 6), connection.receive_ordinal);
    _ = try shared.abort_connection(&application, client, &clients);
}

test "pending datagrams expire on real awake time without consuming dispatch ordinals" {
    var application = try shared.initialize();
    defer shared.destroy(&application);
    var route: RouteObserver = .{ .application = &application };
    var observed: Observer = .{ .application = &application, .authorization = &route };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try shared.handshake(&application, client, &clients);
    observed.connection_index = index;
    try wire(&application, client, &clients, index, 0, "expires-before-connect");
    try testing.expectEqual(@as(usize, 1), pending_count(&application));
    try testing.expectEqual(@as(usize, 0), observed.count);
    try std.Io.sleep(testing.io, .fromMilliseconds(1100), .awake);
    _ = try accept(&application, client, &clients, &observed, .{});
    try testing.expectEqual(@as(usize, 0), pending_count(&application));
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expect(application.next_datagram(index) == null);
    try wire(&application, client, &clients, index, 0, "fresh-after-expiry");
    try expect_callback(&observed, 0, 0, "fresh-after-expiry");
    try expect_ring(&application, index, 0, 0, "fresh-after-expiry");
    _ = try shared.abort_connection(&application, client, &clients);
}

test "pending future SID four survives Close zero and dispatches after live zero" {
    var application = try shared.initialize();
    defer shared.destroy(&application);
    var route: RouteObserver = .{ .application = &application };
    var observed: Observer = .{ .application = &application, .authorization = &route };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try shared.handshake(&application, client, &clients);
    observed.connection_index = index;
    _ = try accept(&application, client, &clients, &observed, .{});
    try wire(&application, client, &clients, index, 4, "future-four");
    try testing.expectEqual(@as(usize, 1), pending_count(&application));
    try testing.expectEqual(@as(usize, 0), observed.count);
    try wire(&application, client, &clients, index, 0, "live-zero");
    try expect_callback(&observed, 0, 0, "live-zero");
    try expect_ring(&application, index, 0, 0, "live-zero");
    try shared.close_zero_session(&application, client, &clients, index);
    try testing.expectEqual(@as(usize, 1), pending_count(&application));
    try wire(&application, client, &clients, index, 0, "retired-zero");
    try testing.expectEqual(@as(usize, 1), pending_count(&application));
    try testing.expectEqual(@as(usize, 1), observed.count);
    _ = try accept(&application, client, &clients, &observed, .{ .id = 4, .authorization_calls = 2 });
    try testing.expectEqual(@as(usize, 0), pending_count(&application));
    try expect_callback(&observed, 1, 4, "future-four");
    try expect_ring(&application, index, 4, 1, "future-four");
    try testing.expectEqual(@as(usize, 2), observed.count);
    _ = try shared.abort_connection(&application, client, &clients);
}

test "early datagrams wait through actual pending SETTINGS and retained CONNECT headers" {
    var application = try shared.initialize();
    defer shared.destroy(&application);
    var route: RouteObserver = .{ .application = &application };
    var observed: Observer = .{ .application = &application, .authorization = &route };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_HELD_SETTINGS) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try held_handshake(&application, client, &clients);
    observed.connection_index = index;
    try wire(&application, client, &clients, index, 0, "before-settings-A");
    try testing.expectEqual(@as(usize, 1), pending_count(&application));
    try testing.expectEqual(@as(u64, 0), try open_connect(client, "https://localhost"));
    try await_pending_headers(&application, client, &clients, index);
    try wire(&application, client, &clients, index, 0, "held-header-B");
    try testing.expectEqual(@as(usize, 2), pending_count(&application));
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expectEqual(@as(usize, 0), route.authorization_calls);
    try testing.expectEqual(@as(usize, 0), application.datagram_rings[index].len());
    try testing.expectEqual(@as(u64, 0), application.quic_transport.?.engine.connections.pool.storage[index].receive_ordinal);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_release_settings(client));
    _ = try await_accepted(&application, client, &clients, &observed, .{});
    try testing.expectEqual(@as(usize, 0), pending_count(&application));
    try testing.expectEqual(@as(usize, 2), observed.count);
    try expect_callback(&observed, 0, 0, "before-settings-A");
    try expect_callback(&observed, 1, 0, "held-header-B");
    try expect_ring(&application, index, 0, 0, "before-settings-A");
    try expect_ring(&application, index, 0, 1, "held-header-B");
    _ = try shared.abort_connection(&application, client, &clients);
}

test "actual oversized early datagram is rejected before pending allocation" {
    var application = try shared.initialize();
    defer shared.destroy(&application);
    var route: RouteObserver = .{ .application = &application };
    var observed: Observer = .{ .application = &application, .authorization = &route };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_LARGE_DATAGRAM) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try shared.handshake(&application, client, &clients);
    observed.connection_index = index;
    const configured = try shared.client_snapshot(client);
    try testing.expectEqual(@as(c_uint, 1472), configured.configured_base_plpmtu);
    try testing.expectEqual(@as(c_uint, 1472), configured.configured_max_plpmtu);
    const oversized = [_]u8{'x'} ** 1201;
    // A writer rejection is a fixture/MTU failure, not engine bounds proof.
    try wire(&application, client, &clients, index, 0, &oversized);
    try testing.expectEqual(@as(usize, 0), pending_count(&application));
    try testing.expectEqual(@as(usize, 0), observed.count);
    try wire(&application, client, &clients, index, 0, "within-logical-bound");
    try testing.expectEqual(@as(usize, 1), pending_count(&application));
    _ = try accept(&application, client, &clients, &observed, .{});
    try testing.expectEqual(@as(usize, 1), observed.count);
    try expect_callback(&observed, 0, 0, "within-logical-bound");
    try expect_ring(&application, index, 0, 0, "within-logical-bound");
    _ = try shared.abort_connection(&application, client, &clients);
}

fn retirement_case(refused: bool) !void {
    var application = try shared.initialize();
    defer shared.destroy(&application);
    var route: RouteObserver = .{ .application = &application };
    var observed: Observer = .{ .application = &application, .authorization = &route };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try shared.handshake(&application, client, &clients);
    observed.connection_index = index;
    try wire(&application, client, &clients, index, 0, "retire-only-zero");
    try wire(&application, client, &clients, index, 4, "retain-future-four");
    try testing.expectEqual(@as(usize, 2), pending_count(&application));
    if (refused) {
        try testing.expectEqual(@as(u64, 0), try open_connect(client, "https://forbidden"));
        var finished = false;
        for (0..c.UWZ_APP_MAX_STEPS) |_| {
            try shared.pump(&application, &clients);
            const response = try shared.response_snapshot(client, 0);
            if (response.fin_received == 0) continue;
            try testing.expectEqual(@as(c_uint, 403), response.status_code);
            try testing.expectEqual(@as(usize, 1), route.authorization_calls);
            finished = true;
            break;
        }
        try testing.expect(finished);
    } else {
        try shared.healthy_http(&application, client, &clients);
        try testing.expectEqual(@as(usize, 0), route.authorization_calls);
    }
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expectEqual(@as(usize, 1), pending_count(&application));
    try testing.expectEqual(@as(usize, 1), terminal_count(&application));
    try wire(&application, client, &clients, index, 0, "late-retired-zero");
    try testing.expectEqual(@as(usize, 1), pending_count(&application));
    _ = try accept(&application, client, &clients, &observed, .{ .id = 4, .authorization_calls = if (refused) 2 else 1 });
    try testing.expectEqual(@as(usize, 1), observed.count);
    try expect_callback(&observed, 0, 4, "retain-future-four");
    try expect_ring(&application, index, 4, 0, "retain-future-four");
    try testing.expectEqual(@as(usize, 0), pending_count(&application));
    try wire(&application, client, &clients, index, 0, "retired-after-admission");
    try testing.expectEqual(@as(usize, 1), observed.count);
    try testing.expectEqual(@as(usize, 0), pending_count(&application));
    try wire(&application, client, &clients, index, 4, "eligible-four");
    try expect_callback(&observed, 1, 4, "eligible-four");
    try expect_ring(&application, index, 4, 1, "eligible-four");
    try testing.expect(!route.failed);
    _ = try shared.abort_connection(&application, client, &clients);
}

test "normal HTTP SID retirement purges only its pending association" {
    try retirement_case(false);
}

test "refused CONNECT retirement purges only its pending association" {
    try retirement_case(true);
}

fn cancellation_case(kind: Cancel) !void {
    var application = try shared.initialize();
    defer shared.destroy(&application);
    var route: RouteObserver = .{ .application = &application };
    var observed: Observer = .{ .application = &application, .authorization = &route };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_HELD_SETTINGS) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try held_handshake(&application, client, &clients);
    observed.connection_index = index;
    try wire(&application, client, &clients, index, 0, "cancel-before-settings");
    try testing.expectEqual(@as(usize, 1), pending_count(&application));
    try testing.expectEqual(@as(u64, 0), try open_connect(client, "https://localhost"));
    try await_pending_headers(&application, client, &clients, index);
    const native = c.uwz_app_client_stream(client, 0) orelse return error.MissingCancellationStream;
    if (kind == .reset) {
        try testing.expectEqual(@as(c_int, c.LSQUIC_SRA_OK), c.lsquic_stream_reset_at(native, 0x10c, 0));
    } else {
        try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_shutdown(native, 0));
    }
    var cancelled = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try shared.pump(&application, &clients);
        const engine = &application.quic_transport.?.engine;
        if (engine.header_pool.count_active() != 0 or engine.stream_pool.count_active() != 0) continue;
        try testing.expectEqual(@as(usize, 0), pending_count(&application));
        try testing.expectEqual(@as(usize, 1), terminal_count(&application));
        try testing.expect(engine.connections.pool.storage[index].peer == null);
        cancelled = true;
        break;
    }
    try testing.expect(cancelled);
    try wire(&application, client, &clients, index, 0, "late-cancelled-zero");
    try testing.expectEqual(@as(usize, 0), pending_count(&application));
    try testing.expectEqual(@as(usize, 0), route.authorization_calls);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_release_settings(client));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try shared.pump(&application, &clients);
        if (application.quic_transport.?.engine.connections.pool.storage[index].peer != null) break;
    }
    _ = try accept(&application, client, &clients, &observed, .{ .id = 4 });
    try testing.expectEqual(@as(usize, 0), observed.count);
    try wire(&application, client, &clients, index, 4, "fresh-after-cancel");
    try expect_callback(&observed, 0, 4, "fresh-after-cancel");
    try expect_ring(&application, index, 4, 0, "fresh-after-cancel");
    _ = try shared.abort_connection(&application, client, &clients);
}

test "pending SETTINGS RESET retires queued session before authorization" {
    try cancellation_case(.reset);
}

test "pending SETTINGS STOP retires queued session before authorization" {
    try cancellation_case(.stop);
}

test "connection abort purges early bytes before generation reuse" {
    var application = try shared.initialize();
    defer shared.destroy(&application);
    var route: RouteObserver = .{ .application = &application };
    var observed: Observer = .{ .application = &application, .authorization = &route };
    const port = try listen(&application, &observed);
    const original = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(original);
    const original_clients = [_]*c.struct_uwz_app_client{original};
    const index = try shared.handshake(&application, original, &original_clients);
    observed.connection_index = index;
    try wire(&application, original, &original_clients, index, 0, "old-generation-zero");
    try wire(&application, original, &original_clients, index, 4, "old-generation-four");
    try testing.expectEqual(@as(usize, 2), pending_count(&application));
    const old_handle = application.quic_transport.?.engine.connections.pool.storage[index].handle;
    _ = try shared.abort_connection(&application, original, &original_clients);
    try testing.expectEqual(@as(usize, 0), pending_count(&application));
    try testing.expectEqual(@as(usize, 0), terminal_count(&application));
    const fresh = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(fresh);
    const clients = [_]*c.struct_uwz_app_client{fresh};
    const fresh_index = try shared.handshake(&application, fresh, &clients);
    try testing.expectEqual(index, fresh_index);
    observed.connection_index = fresh_index;
    const table = &application.quic_transport.?.engine.connections;
    try testing.expect(table.find(old_handle) == null);
    try testing.expect(table.pool.storage[fresh_index].handle.generation != old_handle.generation);
    _ = try accept(&application, fresh, &clients, &observed, .{});
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expect(application.next_datagram(fresh_index) == null);
    try wire(&application, fresh, &clients, fresh_index, 0, "fresh-generation-only");
    try expect_callback(&observed, 0, 0, "fresh-generation-only");
    try expect_ring(&application, fresh_index, 0, 0, "fresh-generation-only");
    _ = try shared.abort_connection(&application, fresh, &clients);
}

test "cooldown requested by first drained callback clears the remaining queue" {
    var application = try shared.initialize();
    defer shared.destroy(&application);
    var route: RouteObserver = .{ .application = &application };
    var observed: Observer = .{ .application = &application, .authorization = &route, .cooldown_on_first = true };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try shared.handshake(&application, client, &clients);
    observed.connection_index = index;
    try shared.healthy_http(&application, client, &clients);
    try testing.expectEqual(@as(usize, 1), terminal_count(&application));
    for ([_][]const u8{ "drain-first", "drain-cancel-B", "drain-cancel-C" }) |payload| {
        try wire(&application, client, &clients, index, 4, payload);
    }
    try testing.expectEqual(@as(usize, 3), pending_count(&application));
    _ = try accept(&application, client, &clients, &observed, .{ .id = 4, .mark_client = false });
    try testing.expectEqual(@as(usize, 1), observed.count);
    try expect_callback(&observed, 0, 4, "drain-first");
    try testing.expect(observed.cooldown_was_deferred);
    const engine = &application.quic_transport.?.engine;
    try testing.expect(!engine.cooldown_pending and !engine.in_cooldown and engine.callback_depth == 0);
    try testing.expectEqual(@as(c.enum_LSQUIC_CONN_STATUS, c.LSCONN_ST_GOING_AWAY), c.lsquic_conn_status(engine.connections.pool.storage[index].native, null, 0));
    try testing.expectEqual(@as(usize, 0), pending_count(&application));
    try testing.expectEqual(@as(usize, 0), terminal_count(&application));
    try testing.expect(engine.connections.pool.storage[index].unknown_early_disabled);
    try expect_ring(&application, index, 4, 0, "drain-first");
    try wire(&application, client, &clients, index, 4, "direct-after-going-away");
    try testing.expectEqual(@as(usize, 2), observed.count);
    try expect_callback(&observed, 1, 4, "direct-after-going-away");
    try expect_ring(&application, index, 4, 1, "direct-after-going-away");
    try testing.expectEqual(@as(usize, 0), pending_count(&application));
    _ = try shared.abort_connection(&application, client, &clients);
}

test "global pending storage holds four bounded entries for each live connection" {
    var application = try shared.initialize();
    defer shared.destroy(&application);
    var route: RouteObserver = .{ .application = &application };
    var observed: Observer = .{ .application = &application, .authorization = &route };
    const port = try listen(&application, &observed);
    var clients: [4]*c.struct_uwz_app_client = undefined;
    var created: usize = 0;
    defer for (clients[0..created]) |client| c.uwz_app_client_destroy(client);
    for (&clients) |*client| {
        client.* = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
        created += 1;
    }
    var indices: [4]usize = undefined;
    for (clients, 0..) |client, client_index| {
        indices[client_index] = try shared.handshake(&application, client, &clients);
        for (0..4) |entry| {
            var payload: [16]u8 = undefined;
            const bytes = try std.fmt.bufPrint(&payload, "client{d}-entry{d}", .{ client_index, entry });
            try wire(&application, client, &clients, indices[client_index], 0, bytes);
        }
        try testing.expectEqual((client_index + 1) * 4, pending_count(&application));
    }
    try testing.expectEqual(@as(usize, 16), pending_count(&application));
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expect(!observed.invalid_gate);
    for (clients, 0..) |client, client_index| {
        const index = indices[client_index];
        observed.connection_index = index;
        _ = try accept(&application, client, &clients, &observed, .{ .authorization_calls = client_index + 1 });
        try testing.expectEqual(16 - (client_index + 1) * 4, pending_count(&application));
        try testing.expectEqual((client_index + 1) * 4, observed.count);
        for (0..4) |entry| {
            var payload: [16]u8 = undefined;
            const bytes = try std.fmt.bufPrint(&payload, "client{d}-entry{d}", .{ client_index, entry });
            try expect_callback(&observed, client_index * 4 + entry, 0, bytes);
            try expect_ring(&application, index, 0, entry, bytes);
        }
    }
    for (clients) |client| _ = try shared.abort_connection(&application, client, &clients);
    try testing.expectEqual(@as(usize, 0), pending_count(&application));
    try testing.expectEqual(@as(usize, 0), terminal_count(&application));
}

fn close_session_id(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, index: usize, id: u64) !void {
    var close: [32]u8 = undefined;
    const size = try support.webtransport.encode_close_session(0, "done", &close);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, &close, size, 1));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try shared.pump(application, clients);
        const engine = &application.quic_transport.?.engine;
        if (engine.connections.pool.storage[index].sessions.open_count() != 0) continue;
        if (engine.stream_pool.count_active() != 0 or engine.header_pool.count_active() != 0) continue;
        try testing.expect(application.next_datagram(index) == null);
        return;
    }
    return error.PendingSessionCloseTimeout;
}

test "terminal budget exhaustion latches unknown associations without purging a queued future ID" {
    var application = try shared.initialize();
    defer shared.destroy(&application);
    var route: RouteObserver = .{ .application = &application };
    var observed: Observer = .{ .application = &application, .authorization = &route };
    const port = try listen(&application, &observed);
    const target = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(target);
    const first = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(first);
    const second = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(second);
    const clients = [_]*c.struct_uwz_app_client{ target, first, second };
    const target_index = try shared.handshake(&application, target, &clients);
    observed.connection_index = target_index;
    try wire(&application, target, &clients, target_index, 4, "future-before-exhaustion");
    const first_index = try shared.handshake(&application, first, &clients);
    const second_index = try shared.handshake(&application, second, &clients);
    for (0..8) |_| try shared.healthy_http(&application, first, &clients);
    for (0..8) |_| try shared.healthy_http(&application, second, &clients);
    try testing.expectEqual(@as(usize, 16), terminal_count(&application));
    const pool = &application.quic_transport.?.engine.connections.pool;
    try testing.expect(!pool.storage[first_index].unknown_early_disabled);
    try testing.expect(!pool.storage[second_index].unknown_early_disabled);
    try testing.expect(!pool.storage[target_index].unknown_early_disabled);
    try testing.expectEqual(@as(usize, 1), pending_count(&application));
    // This seventeenth terminal cannot be recorded; only this connection's
    // future unknown-association admission is disabled until its close.
    try shared.healthy_http(&application, target, &clients);
    try testing.expect(pool.storage[target_index].unknown_early_disabled);
    try testing.expectEqual(@as(usize, 16), terminal_count(&application));
    try testing.expectEqual(@as(usize, 1), pending_count(&application));
    try wire(&application, target, &clients, target_index, 4, "known-future-after-latch");
    try testing.expectEqual(@as(usize, 2), pending_count(&application));
    try wire(&application, target, &clients, target_index, 8, "new-unknown-after-latch");
    try testing.expectEqual(@as(usize, 2), pending_count(&application));
    _ = try accept(&application, target, &clients, &observed, .{ .id = 4 });
    try testing.expectEqual(@as(usize, 2), observed.count);
    try expect_callback(&observed, 0, 4, "future-before-exhaustion");
    try expect_callback(&observed, 1, 4, "known-future-after-latch");
    try expect_ring(&application, target_index, 4, 0, "future-before-exhaustion");
    try expect_ring(&application, target_index, 4, 1, "known-future-after-latch");
    try close_session_id(&application, target, &clients, target_index, 4);
    try testing.expect(pool.storage[target_index].unknown_early_disabled);
    try wire(&application, target, &clients, target_index, 4, "late-closed-after-latch");
    try testing.expectEqual(@as(usize, 0), pending_count(&application));
    try testing.expectEqual(@as(usize, 2), observed.count);
    _ = try accept(&application, target, &clients, &observed, .{ .id = 8, .authorization_calls = 2 });
    try testing.expectEqual(@as(usize, 2), observed.count);
    try wire(&application, target, &clients, target_index, 8, "eligible-after-latch");
    try expect_callback(&observed, 2, 8, "eligible-after-latch");
    try expect_ring(&application, target_index, 8, 2, "eligible-after-latch");
    try testing.expectEqual(@as(usize, 0), pending_count(&application));
    try testing.expectEqual(@as(usize, 16), terminal_count(&application));
    const old_handle = pool.storage[target_index].handle;
    _ = try shared.abort_connection(&application, target, &clients);
    const fresh = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(fresh);
    const fresh_clients = [_]*c.struct_uwz_app_client{ first, second, fresh };
    const fresh_index = try shared.handshake(&application, fresh, &fresh_clients);
    try testing.expectEqual(target_index, fresh_index);
    try testing.expect(application.quic_transport.?.engine.connections.find(old_handle) == null);
    try testing.expect(pool.storage[fresh_index].handle.generation != old_handle.generation);
    try testing.expect(!pool.storage[fresh_index].unknown_early_disabled);
    observed.connection_index = fresh_index;
    _ = try accept(&application, fresh, &fresh_clients, &observed, .{ .authorization_calls = 3 });
    try testing.expectEqual(@as(usize, 3), observed.count);
    try wire(&application, fresh, &fresh_clients, fresh_index, 0, "fresh-latch-generation");
    try expect_callback(&observed, 3, 0, "fresh-latch-generation");
    try expect_ring(&application, fresh_index, 0, 0, "fresh-latch-generation");
    _ = try shared.abort_connection(&application, fresh, &fresh_clients);
    _ = try shared.abort_connection(&application, first, &fresh_clients);
    try testing.expectEqual(@as(usize, 8), terminal_count(&application));
    _ = try shared.abort_connection(&application, second, &fresh_clients);
    try testing.expectEqual(@as(usize, 0), terminal_count(&application));
}
