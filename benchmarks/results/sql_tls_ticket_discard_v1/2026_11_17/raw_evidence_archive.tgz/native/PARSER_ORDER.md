# Pinned ticket validation and effects

All source paths refer to the exact d3bf4795 baseline plus the preceding native
proposals. reference_map.before.txt/reference_map.final.txt locate the complete
scoped ticket, callback, time and PSK sites in the retained baseline/current
files. handshake.cc's ssl_parse_extensions and extensions.cc's request-flags
parser are primary semantic references; neither file is changed here.

Three shared file-local stages mutate explicit borrowed CBS cursors or named
data outputs. They perform no allocation, I/O, clock, callback or error-queue
operation:

1. parse_ticket_prefix reads lifetime, age-add, nonce and a nonempty ticket.
2. parse_ticket_extensions reads the outer extension vector and rejects a body
   trailer.
3. validate_ticket_extensions scans all framing and recognized duplicates first,
   then validates early_data, then flags. Unknown extension duplicates remain
   ignored. Unknown request flags and flag bytes beyond SSLFlags remain allowed;
   empty or trailing-zero flag vectors retain their original rejection.

The generic path remains duplicate -> time rebase -> prefix -> ticket copy ->
outer vector/body framing -> timeout/PSK -> extension semantics -> finalization.
The discard path invokes the same three stages consecutively without constructing
a session. No generic validate-first reordering or whole extension-parser
refactor was introduced. In particular, generic duplicate OOM precedes malformed
prefix checks, ticket-copy OOM precedes outer-vector checks, and PSK derivation
precedes extension semantics.

| Named error | SSL reason | Alert | Original order |
| --- | --- | --- | --- |
| kDecodeError | DECODE_ERROR | DECODE_ERROR | alert, error |
| kMalformedExtensions | PARSE_TLSEXT | DECODE_ERROR | error, alert |
| kDuplicateExtension | DUPLICATE_EXTENSION | ILLEGAL_PARAMETER | error, alert |
| kQuicEarlyData | DECODE_ERROR | ILLEGAL_PARAMETER | alert, error |
| kFlagsDecode | DECODE_ERROR | DECODE_ERROR | error, alert |
| kFlagsTrailingZero | DECODE_ERROR | ILLEGAL_PARAMETER | error, alert |

The effects bridge emits those reasons/alerts only after a pure stage returns.
kDecodeError covers prefix, outer-vector/body and early-data body framing.
Generic QUIC still requires a present early_data value of 0xffffffff. The new
ordinary-reader opt-in rejects QUIC at startup. Recognized duplicate checking
still covers only early_data and tls_flags and precedes either body validation,
including combined-invalid inputs.

Initial opt-in checks the effective session_ctx used by generic ticket
publication. OFF (0) and SERVER (2) satisfy the no-CLIENT-bit condition; CLIENT,
BOTH and any new-session callback do not. Once enabled, an otherwise valid idle
repeat succeeds before rechecking the initial context condition. The SSL3_STATE
flag governs future ordinary ticket reads despite later shared-context changes;
it changes no sibling, exported session or established-session getter.

The flag's lifetime follows SSL3_STATE. Successful SSL_clear resets it. A
preflight clear failure retaining the old state preserves it. Existing clear
code frees old state before allocating replacement, so destructive replacement
OOM has no rollback or usable-old-connection guarantee; this proposal does not
change clear effects. The public external-record-layer ticket construction API
continues through the generic path and may allocate even on an opted-in SSL.
