# Validated client ticket discard proposal

This isolated native proposal adds SSL_discard_client_session_tickets. It does
not adopt a production dependency, pin or maintained fork. Its exact baseline
is BoringSSL d3bf4795ad5b79d646cddf2fec687da5b9b502db with the preceding record,
fixed-HKDF, handshake-buffer, AEAD-context and KeyUpdate-output proposals. The
prior experiment roots remain immutable. Input package identity remains in
input_provenance.json. Source, caches and build outputs stay in this assigned
workspace SSD subtree.

## Policy and validation

The independent startup API accepts an idle, completed ordinary TLS 1.3 client;
its caller must have verified the peer CA and hostname. Servers, DTLS, QUIC,
shutdown/error, pending data/messages/writes/flights/updates and borrowed AEAD
candidates are rejected. Initial enablement checks the effective session_ctx:
the CLIENT cache bit must be absent and the new-session callback null. OFF (0)
and SERVER (2) satisfy that bit test. An already-enabled otherwise valid idle
repeat returns success before rechecking those initial context conditions.

The SSL3_STATE flag is one-way for that connection and dominates later shared
context cache/callback changes. It affects no sibling or previously exported
session, undoes no already-resumed handshake and changes no established-session
getter ownership. Future ordinary-reader tickets retain message callbacks and
syntax/extension validation, but skip session duplication, new-ticket callbacks,
time rebasing, PSK derivation and synthetic IDs. The pre-existing shutdown-ignore
branch remains first. The explicit external-record-layer ticket-construction
API stays generic and may allocate even on an opted-in SSL.

Three shared file-local pure stages borrow prefix, outer-vector/body and
extension data. They perform no allocation, callback, clock, I/O or error-queue
operation. All extension framing and recognized duplicates are scanned before
early_data semantics, then flags. Unknown extensions, unknown duplicate types
and unknown request flags retain their original acceptance. Named errors are
translated at the effects boundary with the original SSL reason, alert and
alert-versus-error ordering. PARSER_ORDER.md records the complete map.

The generic path retains duplicate -> time rebase -> prefix -> ticket copy ->
outer-vector/body framing -> timeout/PSK -> extension semantics -> finalization,
including allocation-failure precedence. This is not a wholesale validate-first
generic refactor. Generic callback return/ownership behavior remains in place.

Flag lifetime follows SSL3_STATE. Successful SSL_clear resets it; preflight
failure retaining old state preserves it. Existing destructive replacement-state
OOM destroys old state without rollback, which is not claimed to preserve a
usable old connection. SSL_free destroys the policy. Existing clear code and
the four earlier reservation functions remain byte-identical; their hashes are
retained in provenance.json. Mutating SSL I/O remains serialized/non-reentrant;
observation callbacks remain supported.

## Source, build and evidence

Root authorized edits only after a genuine cache-OFF/null-callback allocation
RED from three verified TLS 1.3 pairs, six real initial tickets and 75 complete
client calls with exact 4096-byte bidirectional application data. Baseline read
rows report 12 mallocs/12 frees/1600 requested bytes, with writes allocating
nothing. Observe exited zero and the unchanged strict-ticket assertion exited
one with identical data rows. The original 63-byte all-C interposer self-test
passed; generated private PKI was removed.

Exactly four current files differ among 8709 entries: ssl.h, internal.h,
ssl_lib.cc and tls13_client.cc. The cumulative proposal changes 12 unique files
from the exact original package. Full inventories, source_difference.json and
all 12 candidate snapshots retain those identities. Current diff SHA-256 is
e1e858e8aff28cee3aa1e1be1e6cd0a40fb0fe9b6b3ec91c546ff9902e2649dc.

The full crypto library and all 38 SSL translation units were rebuilt together
through unchanged Zig 0.16.0 native source lists using a fresh workspace cache.
The process exited zero; all six steps succeeded. build_commands.json records
the exact command and compiler/input hashes; build-native.log and
native_archives.json retain output and actual archive identities. Debug archive
bytes vary with source paths and are provenance, not portable rebuild hash
requirements. No CMake, regenerated input or external build tool was added.

Root reports the primary candidate witness passes strict zero-allocation across
three fresh 0x1301 pairs, six real initial tickets and 75 complete client SSL
calls; the final unreserved control still exits one. The expanded three-suite,
late/synthetic-ticket syntax, malformed-wire, generic export/resumption and
inherited matrices have separate evidence owners. Their commands, statuses and
raw hashes are authoritative; this source payload does not infer unreported
results. In particular, a synthetically constructed opaque ticket is a syntax
and ownership witness, not a resumption proof.

The direct owner reports 37 vectors matching baseline/new-generic allocation
counts, error queues, alert-observation ordering and session metadata. Eleven
valid discard vectors report zero heap operations, time callbacks and new-session
callbacks; 26 malformed vectors preserve parity, including four combined-invalid
precedence cases. First-enable startup reports zero allocator operations and
requested bytes. Actual SSL3_STATE remains 640 bytes, using existing padding.
An idle repeat after changing the shared context to CLIENT plus a callback
succeeds; its dedicated counter measurement and the broader policy/lifecycle
matrices remain companion-owned rather than inferred from this direct result.

## Source restoration

The payload allowlist retains four baseline files, 12 cumulative snapshots, the
current minimal patch, full inventories, provenance, reference maps, parser-order
notes, build inputs/logs and source restoration evidence. Full native source
copies, archives, object/cache files, private PKI and secrets are excluded.

From a copied payload directory, restore the exact original package to an absent
destination and invoke the native source-list builder:

    python3 restore_source.py /path/to/exact-original-package ./boringssl
    /path/to/zig build -Doptimize=Debug --cache-dir /path/to/new-workspace-cache \
      -p native_out -j2 --summary all

The exact preceding KeyUpdate-output proposal is accepted only with explicit
--source-kind ku-output. Both modes verify the full old file set and hashes and
all 12 snapshots before creating a new directory. Existing destinations are
refused; cached input is never modified. No patch executable is required. Python
prepares external evidence and is not a library build dependency. All SSL units
must build together from the restored source.

restore_validation.json records successful prior-KU-output restoration with
exact 8709-entry final-candidate equality, an existing-output rejection and
rejection of KU-output input presented as the original package. The owned
generated workspace source copy was removed. Positive original-package
restoration from the final copied layout remains Root-owned and is not claimed
here.

## Remaining scope

Valid ticket-session construction is one allocation component. Fatal-error,
reconnect and other lifetime paths, inherited custom-BIO flush limitations,
maintenance/publication and production activation remain separate requirements.
SQL-ALLOC-002 and the complete strict PostgreSQL allocation gate stay open.
No PostgreSQL allocation exception, whole-lifetime guarantee or FIPS certification
is claimed. Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain
user-deferred.
