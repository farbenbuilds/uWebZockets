# Ticket-discard final delivery review

Result: no actionable findings in the bounded pre-archive delivery review.

Reviewed the combined `.zig-cache/sql-tls-ticket-discard-evidence-20261117`
layout read-only. The core review remains
`/tmp/uwz-pg-tls-ticket-discard-review-20261117.md`: native patch
`e1e858e8aff28cee3aa1e1be1e6cd0a40fb0fe9b6b3ec91c546ff9902e2649dc`,
SSL archive `b9891425c059d826fd83a3335fe72207d73cebe992521ca6df473aaba0bfe88f`,
crypto archive `0d5945f932ce7620c2c4d431ce1cf85db95900ef134e84d88d2d088f960feaa9`.
This review changed no source, test, documentation or delivered payload.

Independently rechecked all 42 native, 915 helper, 240 wire-JSON and 10 transform
manifest entries. The native allowlist is separately retained; the eventual
combined manifest covers it and the subtree manifests. Both original producer
manifests and all 1,155 producer entries remain unchanged. All 1,121 staged
entries outside the 32 executables and two current identity maps remain equal
to their measured originals, including wrappers, assertions, source, build
records and raw results. Original wire JSON metadata outside its hash map is
preserved. Both identity maps differ only as authorized: delivered hashes,
explicit delivery sizes and transform link, plus wire's current
`delivery_stripping: false -> true`. The archived original value stays false.

Recomputed all 32 original-to-delivery hashes, byte counts, permissions and ELF
proofs using the inspected bounded comparison in
`delivery_transform/strip_delivery.py:23`. Totals are 585,633,688 -> 163,616,600
bytes. Entrypoint/ABI identity, complete program-header tuples, every allocated
section and normalized PT_LOAD bytes match; only section-table coordinates are
excluded from mapped-byte comparison. Debug sections are removed and regular
symbol tables remain. Transform manifest SHA-256 is
`e282b384f0441e3e9df937d199695246e56a3797e23e704c02c87254ee85f2f8`.

Reviewed both `replay_prebuilt.py` wrappers, retained nine helper/four wire
guard records, `restore_pki_tool.py`, and source bootstrap code/results. Both
canonical parent markers select the complete combined evidence root; otherwise
the own-tree fallback applies. Output and identity refusals precede directory
creation and PKI work. Current executable maps are checked, expected baseline
strict failures remain failures, outcome comparisons remain enabled, and
cleanup removes only the owned three-file PKI fixture. Retained final copied-
layout results reconcile 107 helper commands and 24 wire commands, including
two expected exit-1 wire strict controls; both complete flags and private-PKI
removal flags are true. No functional matrix was rerun by this reviewer.

Independently hashed both restored source trees against all 8,709 final
inventory entries and all 314 protected production inputs. Existing-output
refusals and wrong-source-mode rejection before writing are retained. Bootstrap
pins the complete offline archive and exact regular PKI member/size/hash, refuses
conflicting destinations, and writes exclusively. The temporary restored tool
is currently present and hash-correct; `root_checks/package_archive.py:29`
checks and omits it. No private keys, certificates, native archives or objects
are retained in the staged payload.

Reviewed `root_checks/package_archive.py:21` through its final verification:
it accepts regular files, rejects symlinks and excluded artifact types, hashes
all retained payloads, writes one archive, bounds its compressed size, then
reopens it and checks exact unique member inventory, regular member types and
every payload hash before publishing the archive and outer checksum. Final
archive construction, compressed-member verification and final outer checksums
remain Root-owned subsequent steps; this report does not claim them executed.

Inner/outer READMEs, `external_inputs.json`, `docs/sql.md` and the ticket section
of `tasks/plan.md` accurately distinguish measured Debug provenance from current
delivery identities, synthetic protocol inputs from genuine exported-session
resumption, healthy zero-count rows from fatal-path semantics, and watched S3
erasure from raw ERR allocation accounting. Clear's preserving/destructive
lifetime distinction and preliminary fixture/observer corrections remain
explicit. Retained ordinary unit evidence reports 1,158 passes/24 live-fixture
skips; format leaves 314 inputs unchanged, and ordinary project checks report
zero exits. No dedicated deferred campaign or production pin/adoption change is
claimed. PostgreSQL's complete request-path allocation gate remains open and
no PostgreSQL allocation exception is approved.

Review frozen against the files read above. No additional runtime, build or
security campaign is required by this bounded review.
