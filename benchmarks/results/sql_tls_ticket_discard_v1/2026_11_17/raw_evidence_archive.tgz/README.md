# Validated client ticket-discard evidence

This isolated proposal adds SSL_discard_client_session_tickets for idle,
completed ordinary TLS 1.3 clients. It fully validates future received tickets
then skips unused session construction. Initial enable requires client caching
disabled and a null new-session callback; the per-SSL policy then dominates
later context changes. Existing exports and established getters remain valid.
The explicit external ticket factory stays generic. The flag follows S3
lifetime, including the documented preserving/destructive clear distinction.
Enable and idle repeat use no heap; S3 stays 640 bytes in the measured build.
Production pins and the complete PostgreSQL allocation gate remain open.

After fresh extraction, verify and replay from this directory:

```sh
sha256sum -c files.sha256
python3 restore_pki_tool.py /absolute/path/to/uWebZockets
python3 helper/replay_prebuilt.py --pki-tool tools/wt-tools --output /tmp/uwz-ticket-helper-final-replay
python3 wire/replay_prebuilt.py --pki-tool tools/wt-tools --output /tmp/uwz-ticket-wire-final-replay
```

Choose absent output directories outside this entire evidence tree. The PKI
helper is restored from the checksum-pinned existing independent-client artifact
in external_inputs.json. No network, compiler, native archives or objcopy is
needed for prebuilt replay. Wrappers verify current delivery identities, exact
outcomes and expected RED/GREEN statuses; owned private PKI is removed.
Both complete root replays pass after transformation: 107 helper commands and
24 wire commands with expected statuses. Their raw outputs and post-replay
checksums are retained under root_checks/.

Measured programs use Zig Debug. Existing GNU objcopy --strip-debug removes
debug information from 32 staged delivery executables, reducing 585633688 to
163616600 bytes. Sources, assertions, raw results and native compile/link inputs
are unchanged. delivery_transform/HANDOFF.md and manifest.json preserve original
and current identities, commands, allocated sections, ABI/entrypoints, program
layout, normalized load-byte proofs, symbol tables and permissions. Section
table coordinates and full hashes deliberately differ. Wire's current
delivery_stripping flag is true; the original false map remains archived.
Current prebuilt maps and delivery byte fields identify actual delivered copies.
Producer handoffs describe measured Debug programs. Helper uses files.sha256;
wire uses payload_manifest.json:sha256. The top manifest covers every payload.

Source/build evidence is under native/, helper evidence under helper/ and
encrypted protocol/resumption/controls under wire/. Reviews and root checks are
retained separately. The primary proof is three fresh 0x1301 pairs/six real
initial tickets/75 client calls: baseline/unopted RED and discard GREEN. The
expanded 27-row/1320-call protocol matrix negotiates all three suites, with nine
healthy zero-count rows and eighteen fatal rows retaining full queue/alert
semantics. Late opaque tickets are synthetic protocol inputs; genuine three-row/
228-call chains separately prove old exports still resume and opt-in works after
resumption. All twelve/255 public controls become zero with earlier reservations
plus discard. Error paths remain outside the healthy zero claim.

Direct evidence covers 37 syntax vectors, six generic callback ownership rows,
twelve candidate policy rows, three exact OOM/order rows, twenty lifecycle cases
and two clear boundaries. Raw ERR saved-state frees have no OPENSSL erasure
contract; counters/fault routing stay complete and explicit watched S3 erasure
checks remain strong. Preliminary fixture/observer corrections are classified;
no native fix or gate weakening resulted. All 51 inherited inputs are unchanged
and record/HS/HKDF/AEAD/output regressions pass against final archives.

native/HANDOFF.md documents restoration from the exact original pinned package
or explicit prior-KeyUpdate-output input. Both reproduce all 8709 final source
entries and refuse conflicting/wrong inputs, as recorded in root_checks/.

Ordinary formatting leaves 314 source/build inputs unchanged; SQL/SQLite tests
pass 1158 cases with 24 live-PostgreSQL fixture skips. Dedicated smoke, security,
sanitizer, fuzz and scan campaigns stay user-deferred. Fatal/error/reconnect,
maintained publication, production adoption and full PostgreSQL proof remain
work. No PostgreSQL allocation exception is approved.
