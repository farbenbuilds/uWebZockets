#!/usr/bin/env python3
"""Check selected frozen payload hashes and the retained baseline source freeze."""
import hashlib
import json
from pathlib import Path


def main():
    base=Path(__file__).resolve().parent
    manifest=json.loads((base/'payload_manifest.json').read_text())
    expected=set((base/'payload_allowlist.txt').read_text().splitlines())
    assert expected==set(manifest['sha256'])|{'payload_manifest.json'}
    for name,checksum in manifest['sha256'].items():
        path=base/name
        assert path.is_file() and not path.is_symlink()
        assert hashlib.sha256(path.read_bytes()).hexdigest()==checksum,name
    for name,checksum in json.loads((base/'baseline_frozen.json').read_text()).items():
        assert hashlib.sha256((base/name).read_bytes()).hexdigest()==checksum,name
    print('PASS: '+str(len(expected))+' selected payload files and original baseline freeze')


if __name__=='__main__':main()
