#!/usr/bin/env python3
"""Reconcile three real-ticket callback and resumption chains."""
import argparse
import csv
import json
from pathlib import Path

FIELDS=('malloc','calloc','realloc','free','bytes')
SUITES=(0x1301,0x1302,0x1303)


def verify(directory):
    rows=[json.loads(line) for line in (directory/'summary.jsonl').read_text().splitlines()]
    operations=list(csv.DictReader((directory/'operations.csv').open()))
    assert [row['suite'] for row in rows]==list(SUITES)
    count=0
    for row in rows:
        selected=[op for op in operations if op['scenario']==str(row['suite'])+'_real_initial_resumption']
        assert all(row[name] for name in ('tls13_verified','hostname_verified','ordinary_callback_owned',
            'earlier_export_preserved_after_enable','actual_session_reused_both_peers','resumed_before_enable',
            'resumed_after_enable_and_tickets','late_opaque_nonresumption_test','payloads_exact'))
        assert row['initial_real_tickets_exported']==row['resumed_initial_real_tickets']==2
        assert row['payload_bytes_each_phase_direction']==4096
        assert all(int(op['error']) in (0,2,3) for op in selected)
        for steps,prefix in [({'0'},'initial_capture'),({'1','2'},'active_original'),({'3'},'active_resumed')]:
            phase_ops=[op for op in selected if op['step'] in steps]
            reads=[op for op in phase_ops if op['phase'] in ('read','late_opaque_read')]
            writes=[op for op in phase_ops if op['phase']=='response_write']
            assert len(reads)+len(writes)==len(phase_ops)
            assert sum(max(int(op['result']),0) for op in reads)==4096
            assert sum(max(int(op['result']),0) for op in writes)==4096
            for group,suffix in [(reads,'read'),(writes,'write')]:
                counts={field:sum(int(op[field]) for op in group) for field in FIELDS}
                assert counts==row[prefix+'_'+suffix]
                if row['discarded'] and prefix!='initial_capture':assert all(value==0 for value in counts.values())
        count+=len(selected)
    assert count==len(operations)
    return {'rows_verified':3,'operations_verified':count,'actual_suites':list(SUITES),
        'real_initial_callback_export_and_resumption':True,'earlier_export_nonrevocation':True,
        'opt_in_after_actual_resumed_handshake':True,'synthetic_late_input_not_resumption_tested':True,
        'sensitive_session_bytes_logged':False,'strict_postgresql_gate_closed':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('directory',type=Path)
    print(json.dumps(verify(parser.parse_args().directory),indent=2))


if __name__=='__main__':main()
