#!/usr/bin/env python3
"""Build the unchanged three-suite KeyUpdate zero-allocation assertion."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('pki_helper', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--discard', action='store_true')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    native = args.native_root.resolve(strict=True)
    helper = args.pki_helper.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    if digest(helper) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('The retained PKI helper checksum differs')
    archives = [native / 'native_out/lib/libssl.a', native / 'native_out/lib/libcrypto.a']
    source_names = ['include/openssl/ssl.h', 'ssl/internal.h', 'ssl/ssl_lib.cc',
        'ssl/ssl_aead_ctx.cc', 'ssl/tls13_enc.cc', 'ssl/tls_method.cc', 'ssl/tls13_client.cc']
    provenance = {'native_archive_sha256': {p.name:digest(p) for p in archives},
        'native_source_sha256': {name:digest(native / 'boringssl' / name) for name in source_names},
        'fixture_sha256':digest(base/'ticket_witness.cc'),
        'counter_sha256':digest(base/'allocation_scope.c'),
        'reserved':args.discard,'optimization':'Debug (-O0 -g)',
        'cipher_configuration':'SSL_CTX_set1_tls13_ciphers singleton protocol ID with null flags on both peers'}
    output.mkdir(mode=0o700)
    (output/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
    environment=dict(os.environ)
    environment['ZIG_GLOBAL_CACHE_DIR']='/tmp/uwz-zig-cache'
    zig='/tmp/zig-x86_64-linux-0.16.0/zig'
    commands=[]

    def run(command,name,expected=0):
        with (output/(name+'.stdout')).open('wb') as stdout,(output/(name+'.stderr')).open('wb') as stderr:
            result=subprocess.run(command,cwd=output,env=environment,stdout=stdout,stderr=stderr)
        commands.append({'command':command,'exit_code':result.returncode,'expected_exit_code':expected})
        (output/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        if result.returncode!=expected:raise RuntimeError('Unexpected status: '+name)

    pki=output/'private_pki'
    binary=output/'ticket_witness'
    complete=False
    try:
        run([zig,'cc','-O0','-g','-c',str(base/'allocation_scope.c'),'-o',str(output/'allocation_scope.o')],'build-counter')
        flags=[zig,'c++','-std=c++17','-O0','-g','-Wall','-Wextra','-Werror',
            '-isystem',str(native/'boringssl/include')]
        if args.discard:flags.append('-DUWZ_DISCARD_CLIENT_TICKETS=1')
        run([*flags,str(base/'ticket_witness.cc'),str(output/'allocation_scope.o'),
            *[str(p) for p in archives],'-o',str(binary)],'build-witness')
        run([str(helper),'pki',str(pki)],'pki-metadata')
        arguments=[str(pki/name) for name in ['server.pem','server.key','ca.pem']]
        run([str(binary),*arguments,str(output/'observe_operations.csv'),str(output/'observe_summary.jsonl'),'--observe'],'observe')
        run([str(binary),*arguments,str(output/'strict_operations.csv'),str(output/'strict_summary.jsonl'),'--require-zero-tickets'],'strict',0 if args.discard else 1)
        assert (output/'observe_operations.csv').read_bytes()==(output/'strict_operations.csv').read_bytes()
        assert (output/'observe_summary.jsonl').read_bytes()==(output/'strict_summary.jsonl').read_bytes()
        rows=[json.loads(line) for line in (output/'observe_summary.jsonl').read_text().splitlines()]
        assert len(rows)==3 and {row['suite'] for row in rows}=={0x1301}
        for row in rows:
            assert row['tls13_verified'] and row['hostname_verified'] and row['payloads_exact']
            if args.discard:assert all(v==0 for phase in ['client_read','client_write'] for v in row[phase].values())
            else:
                assert row['client_read']=={'malloc':12,'calloc':0,'realloc':0,'free':12,'bytes':1600}
                assert row['client_write']=={'malloc':0,'calloc':0,'realloc':0,'free':0,'bytes':0}
        complete=True
    finally:
        if pki.exists():
            names={p.name for p in pki.iterdir()}
            if names-{'ca.pem','server.pem','server.key'}:raise ValueError('Unexpected PKI contents')
            for name in names:(pki/name).unlink()
            pki.rmdir()
        (output/'result.json').write_text(json.dumps({'complete':complete,'strict_exit_code':0 if args.discard else 1,
            'private_pki_removed':not pki.exists(),'binary_sha256':digest(binary) if binary.exists() else None},indent=2)+'\n')
    print('PASS: three fresh real-ticket pairs; strict ticket gate '+('GREEN' if args.discard else 'RED'))


if __name__=='__main__':main()
