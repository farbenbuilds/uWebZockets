#include <openssl/err.h>
#include <openssl/ssl.h>
#include <openssl/ssl3.h>
#include <openssl/x509_vfy.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK(value) do { if (!(value)) fail(__LINE__, #value); } while (0)

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

struct allocation_counts {
    uint64_t malloc_calls;
    uint64_t calloc_calls;
    uint64_t realloc_calls;
    uint64_t free_calls;
    uint64_t requested_bytes;
};

struct measured_result {
    int result;
    int error;
    allocation_counts counts;
};

struct protocol_observations {
    unsigned int received_tickets;
    unsigned int received_key_updates;
    unsigned int sent_key_updates;
    uint8_t received_modes[96];
    uint8_t sent_modes[96];
    bool invalid;
};

struct tls_pair {
    SSL_CTX *client_context;
    SSL_CTX *server_context;
    SSL *client;
    SSL *server;
    protocol_observations client_observations;
    protocol_observations server_observations;
};

struct phase_result {
    allocation_counts counts;
    unsigned int operations;
    unsigned int retries;
};

static void fail(int line, const char *expression)
{
    fprintf(stderr, "check failed at line %d: %s\n", line, expression);
    ERR_print_errors_fp(stderr);
    abort();
}

static allocation_counts snapshot_counts(void)
{
    return {uwz_alloc_malloc_calls(), uwz_alloc_calloc_calls(),
            uwz_alloc_realloc_calls(), uwz_alloc_free_calls(),
            uwz_alloc_requested_bytes()};
}

static void add_counts(allocation_counts *total, allocation_counts value)
{
    total->malloc_calls += value.malloc_calls;
    total->calloc_calls += value.calloc_calls;
    total->realloc_calls += value.realloc_calls;
    total->free_calls += value.free_calls;
    total->requested_bytes += value.requested_bytes;
}

static bool retry_error(int error)
{
    return error == SSL_ERROR_WANT_READ || error == SSL_ERROR_WANT_WRITE;
}

static void check_peer_result(SSL *ssl, int result)
{
    if (result > 0) return;
    CHECK(retry_error(SSL_get_error(ssl, result)));
}

static void observe_message(int is_write, int version, int content_type,
                            const void *buffer, size_t length, SSL *ssl,
                            void *argument)
{
    (void)ssl;
    if (content_type != SSL3_RT_HANDSHAKE || length == 0) return;
    const uint8_t *bytes = static_cast<const uint8_t *>(buffer);
    protocol_observations *observed =
        static_cast<protocol_observations *>(argument);
    if (bytes[0] == SSL3_MT_NEWSESSION_TICKET) {
        if (!is_write) observed->received_tickets++;
        if (version != TLS1_3_VERSION || length < 4) observed->invalid = true;
        return;
    }
    if (bytes[0] != SSL3_MT_KEY_UPDATE) return;
    if (version != TLS1_3_VERSION || length != 5 || bytes[1] != 0 ||
        bytes[2] != 0 || bytes[3] != 1 || bytes[4] > 1) {
        observed->invalid = true;
        return;
    }
    unsigned int *count = is_write ? &observed->sent_key_updates :
                                     &observed->received_key_updates;
    uint8_t *modes = is_write ? observed->sent_modes : observed->received_modes;
    if (*count == 96) {
        observed->invalid = true;
        return;
    }
    modes[*count] = bytes[4];
    (*count)++;
}

static void prepare_pair(tls_pair *pair, const char *certificate,
                         const char *private_key, const char *ca,
                         unsigned int tickets, uint16_t suite)
{
    pair->client_context = SSL_CTX_new(TLS_method());
    pair->server_context = SSL_CTX_new(TLS_method());
    CHECK(pair->client_context && pair->server_context);
    CHECK(SSL_CTX_set1_tls13_ciphers(pair->client_context, &suite, nullptr, 1));
    CHECK(SSL_CTX_set1_tls13_ciphers(pair->server_context, &suite, nullptr, 1));
    CHECK(SSL_CTX_set_min_proto_version(pair->client_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_max_proto_version(pair->client_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_min_proto_version(pair->server_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_max_proto_version(pair->server_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_num_tickets(pair->server_context, tickets));
    SSL_CTX_set_session_cache_mode(pair->client_context, SSL_SESS_CACHE_OFF);
    CHECK(SSL_CTX_get_session_cache_mode(pair->client_context) == SSL_SESS_CACHE_OFF);
    CHECK(SSL_CTX_sess_get_new_cb(pair->client_context) == nullptr);
    CHECK(SSL_CTX_use_certificate_chain_file(pair->server_context, certificate));
    CHECK(SSL_CTX_use_PrivateKey_file(pair->server_context, private_key,
                                     SSL_FILETYPE_PEM));
    CHECK(SSL_CTX_check_private_key(pair->server_context));
    CHECK(SSL_CTX_load_verify_locations(pair->client_context, ca, nullptr));
    SSL_CTX_set_verify(pair->client_context, SSL_VERIFY_PEER, nullptr);
    SSL_CTX_set_msg_callback(pair->client_context, observe_message);
    SSL_CTX_set_msg_callback_arg(pair->client_context, &pair->client_observations);
    SSL_CTX_set_msg_callback(pair->server_context, observe_message);
    SSL_CTX_set_msg_callback_arg(pair->server_context, &pair->server_observations);
    pair->client = SSL_new(pair->client_context);
    pair->server = SSL_new(pair->server_context);
    CHECK(pair->client && pair->server);
    CHECK(SSL_set_tlsext_host_name(pair->client, "localhost"));
    CHECK(SSL_set1_host(pair->client, "localhost"));
    SSL_set_connect_state(pair->client);
    SSL_set_accept_state(pair->server);
    BIO *client_bio = nullptr;
    BIO *server_bio = nullptr;
    CHECK(BIO_new_bio_pair(&client_bio, 1024, &server_bio, 1024));
    SSL_set_bio(pair->client, client_bio, client_bio);
    SSL_set_bio(pair->server, server_bio, server_bio);
    bool client_done = false;
    bool server_done = false;
    for (unsigned int i = 0; i < 10000 && (!client_done || !server_done); i++) {
        if (!client_done) {
            int result = SSL_do_handshake(pair->client);
            if (result == 1) client_done = true;
            else check_peer_result(pair->client, result);
        }
        if (!server_done) {
            int result = SSL_do_handshake(pair->server);
            if (result == 1) server_done = true;
            else check_peer_result(pair->server, result);
        }
    }
    CHECK(client_done && server_done);
    CHECK(SSL_version(pair->client) == TLS1_3_VERSION);
    CHECK(SSL_version(pair->server) == TLS1_3_VERSION);
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->client)) == suite);
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->server)) == suite);
    CHECK(SSL_get_verify_result(pair->client) == X509_V_OK);
    CHECK(SSL_get0_peer_certificates(pair->client) != nullptr);
    CHECK(pair->client_observations.received_tickets == 0);
}

static measured_result measured_read(SSL *client, void *output, int length)
{
    uwz_alloc_begin();
    const int result = SSL_read(client, output, length);
    const int error = result > 0 ? SSL_ERROR_NONE : SSL_get_error(client, result);
    uwz_alloc_end();
    return {result, error, snapshot_counts()};
}

static measured_result measured_write(SSL *client, const void *input, int length)
{
    uwz_alloc_begin();
    const int result = SSL_write(client, input, length);
    const int error = result > 0 ? SSL_ERROR_NONE : SSL_get_error(client, result);
    uwz_alloc_end();
    return {result, error, snapshot_counts()};
}

static void record_operation(FILE *output, unsigned int round, const char *row,
                              const char *phase, measured_result operation,
                              const protocol_observations *observed,
                              phase_result *result)
{
    const allocation_counts count = operation.counts;
    fprintf(output, "%u,%s,%s,%u,%d,%d,%llu,%llu,%llu,%llu,%llu,%u,%u,%u\n",
            round, row, phase, result->operations, operation.result, operation.error,
            (unsigned long long)count.malloc_calls,
            (unsigned long long)count.calloc_calls,
            (unsigned long long)count.realloc_calls,
            (unsigned long long)count.free_calls,
            (unsigned long long)count.requested_bytes,
            observed->received_tickets, observed->received_key_updates,
            observed->sent_key_updates);
    add_counts(&result->counts, count);
    result->operations++;
    if (operation.result <= 0) result->retries++;
}

static phase_result read_payload(tls_pair *pair, const uint8_t *payload,
                                  int length, FILE *operations,
                                  unsigned int round, const char *row)
{
    uint8_t received[4096];
    CHECK(length == sizeof(received));
    bool written = false;
    int offset = 0;
    phase_result result{};
    for (unsigned int i = 0; i < 10000 && (!written || offset != length); i++) {
        if (!written) {
            const int sent = SSL_write(pair->server, payload, length);
            if (sent > 0) {
                CHECK(sent == length);
                written = true;
            } else check_peer_result(pair->server, sent);
        }
        if (offset == length) continue;
        const int remaining = length - offset;
        measured_result operation = measured_read(pair->client, received + offset,
                                                   remaining < 257 ? remaining : 257);
        record_operation(operations, round, row, "read", operation,
                          &pair->client_observations, &result);
        if (operation.result > 0) offset += operation.result;
        else CHECK(retry_error(operation.error));
    }
    CHECK(written && offset == length);
    CHECK(memcmp(received, payload, length) == 0);
    return result;
}

static phase_result write_reply(tls_pair *pair, const uint8_t *payload,
                                 int length, FILE *operations,
                                 unsigned int round, const char *row)
{
    uint8_t received[4096];
    CHECK(length == sizeof(received));
    bool written = false;
    int offset = 0;
    phase_result result{};
    for (unsigned int i = 0; i < 10000 && (!written || offset != length); i++) {
        if (!written) {
            measured_result operation = measured_write(pair->client, payload, length);
            record_operation(operations, round, row, "response_write", operation,
                              &pair->client_observations, &result);
            if (operation.result > 0) {
                CHECK(operation.result == length);
                written = true;
            } else CHECK(retry_error(operation.error));
        }
        if (offset == length) continue;
        const int remaining = length - offset;
        const int count = SSL_read(pair->server, received + offset,
                                   remaining < 257 ? remaining : 257);
        if (count > 0) offset += count;
        else check_peer_result(pair->server, count);
    }
    CHECK(written && offset == length);
    CHECK(memcmp(received, payload, length) == 0);
    return result;
}

static void print_counts(FILE *output, allocation_counts counts)
{
    fprintf(output, "{\"malloc\":%llu,\"calloc\":%llu,\"realloc\":%llu,\"free\":%llu,\"bytes\":%llu}",
            (unsigned long long)counts.malloc_calls,
            (unsigned long long)counts.calloc_calls,
            (unsigned long long)counts.realloc_calls,
            (unsigned long long)counts.free_calls,
            (unsigned long long)counts.requested_bytes);
}

static bool zero_counts(allocation_counts counts)
{
    return counts.malloc_calls == 0 && counts.calloc_calls == 0 &&
        counts.realloc_calls == 0 && counts.free_calls == 0 && counts.requested_bytes == 0;
}

static unsigned int run_round(unsigned int round, const char *certificate,
                               const char *private_key, const char *ca,
                               FILE *operations, FILE *summary)
{
    tls_pair pair{};
    const uint16_t suite = 0x1301;
    prepare_pair(&pair, certificate, private_key, ca, 2, suite);
    CHECK(SSL_reserve_record_buffers(pair.client));
    CHECK(SSL_reserve_client_post_handshake_buffer(pair.client));
    CHECK(SSL_reserve_key_update_context(pair.client));
    CHECK(SSL_reserve_key_update_output_buffers(pair.client));
#if defined(UWZ_DISCARD_CLIENT_TICKETS)
    CHECK(SSL_discard_client_session_tickets(pair.client));
    const bool discarded = true;
#else
    const bool discarded = false;
#endif
    uint8_t payload[4096];
    for (size_t i = 0; i < sizeof(payload); i++) payload[i] = static_cast<uint8_t>(i * 13 + round);
    const phase_result reads = read_payload(&pair, payload, sizeof(payload), operations, round, "initial_tickets");
    const phase_result writes = write_reply(&pair, payload, sizeof(payload), operations, round, "initial_tickets");
    CHECK(!pair.client_observations.invalid && !pair.server_observations.invalid);
    CHECK(pair.client_observations.received_tickets == 2);
    CHECK(pair.client_observations.received_key_updates == 0 && pair.client_observations.sent_key_updates == 0);
    CHECK(pair.server_observations.received_key_updates == 0);
    fprintf(summary, "{\"round\":%u,\"suite\":%u,\"client_negotiated_suite\":%u,\"server_negotiated_suite\":%u,\"discarded\":%s,\"tls13_verified\":true,\"hostname_verified\":true,\"received_tickets\":2,\"cache_mode\":0,\"new_callback_null\":true,\"payload_bytes_each_direction\":4096,\"payloads_exact\":true,\"read_operations\":%u,\"write_operations\":%u,\"read_retries\":%u,\"write_retries\":%u,\"client_read\":",
        round, suite, suite, suite, discarded ? "true" : "false", reads.operations,
        writes.operations, reads.retries, writes.retries);
    print_counts(summary, reads.counts);
    fprintf(summary, ",\"client_write\":");
    print_counts(summary, writes.counts);
    fprintf(summary, "}\n");
    const unsigned int allocating = !zero_counts(reads.counts) || !zero_counts(writes.counts);
    SSL_free(pair.client);
    SSL_free(pair.server);
    SSL_CTX_free(pair.client_context);
    SSL_CTX_free(pair.server_context);
    return allocating;
}

int main(int argc, char **argv)
{
    CHECK(argc == 7);
    const bool strict = strcmp(argv[6], "--require-zero-tickets") == 0;
    CHECK(strict || strcmp(argv[6], "--observe") == 0);
    CHECK(uwz_alloc_self_test());
    FILE *operations = fopen(argv[4], "wx");
    FILE *summary = fopen(argv[5], "wx");
    CHECK(operations && summary);
    fprintf(operations, "round,scenario,phase,operation,result,error,malloc,calloc,realloc,free,bytes,received_tickets,received_key_updates,sent_key_updates\n");
    unsigned int allocating = 0;
    for (unsigned int round = 0; round < 3; round++)
        allocating += run_round(round, argv[1], argv[2], argv[3], operations, summary);
    CHECK(fclose(operations) == 0 && fclose(summary) == 0);
    fprintf(stderr, "FUNCTIONAL_PASS: three fresh verified ticket pairs, exact bidirectional payloads, self_test63=PASS; allocating_pairs=%u\n", allocating);
    return strict && allocating ? 1 : 0;
}
