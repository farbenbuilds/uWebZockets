#include <openssl/err.h>
#include <openssl/ssl.h>
#include <openssl/ssl3.h>
#include <openssl/x509_vfy.h>
#include "ssl/internal.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK(value) do { if (!(value)) fail(__LINE__, #value); } while (0)

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

struct allocation_counts {
    uint64_t malloc_calls;
    uint64_t calloc_calls;
    uint64_t realloc_calls;
    uint64_t free_calls;
    uint64_t requested_bytes;
};

struct measured_result {
    int result;
    int error;
    allocation_counts counts;
};

struct protocol_observations {
    unsigned int received_tickets;
    unsigned int received_key_updates;
    unsigned int sent_key_updates;
    uint8_t received_modes[96];
    uint8_t sent_modes[96];
    bool invalid;
    const uint8_t *expected_tickets;
    size_t expected_ticket_bytes;
    size_t observed_ticket_bytes;
    bool ticket_bytes_exact;
    unsigned int alert_count;
    uint8_t alerts[8][3];
};

struct tls_pair {
    SSL_CTX *client_context;
    SSL_CTX *server_context;
    SSL *client;
    SSL *server;
    protocol_observations client_observations;
    protocol_observations server_observations;
};

struct phase_result {
    allocation_counts counts;
    unsigned int operations;
    unsigned int retries;
};

static void fail(int line, const char *expression)
{
    fprintf(stderr, "check failed at line %d: %s\n", line, expression);
    ERR_print_errors_fp(stderr);
    abort();
}

static allocation_counts snapshot_counts(void)
{
    return {uwz_alloc_malloc_calls(), uwz_alloc_calloc_calls(),
            uwz_alloc_realloc_calls(), uwz_alloc_free_calls(),
            uwz_alloc_requested_bytes()};
}

static void add_counts(allocation_counts *total, allocation_counts value)
{
    total->malloc_calls += value.malloc_calls;
    total->calloc_calls += value.calloc_calls;
    total->realloc_calls += value.realloc_calls;
    total->free_calls += value.free_calls;
    total->requested_bytes += value.requested_bytes;
}

static bool retry_error(int error)
{
    return error == SSL_ERROR_WANT_READ || error == SSL_ERROR_WANT_WRITE;
}

static void check_peer_result(SSL *ssl, int result)
{
    if (result > 0) return;
    CHECK(retry_error(SSL_get_error(ssl, result)));
}

static void observe_message(int is_write, int version, int content_type,
                            const void *buffer, size_t length, SSL *ssl,
                            void *argument)
{
    (void)ssl;
    protocol_observations *observed = static_cast<protocol_observations *>(argument);
    const uint8_t *bytes = static_cast<const uint8_t *>(buffer);
    if (content_type == SSL3_RT_ALERT && length == 2) {
        if (observed->alert_count == 8) { observed->invalid = true; return; }
        const unsigned int index = observed->alert_count++;
        observed->alerts[index][0] = static_cast<uint8_t>(is_write);
        observed->alerts[index][1] = bytes[0];
        observed->alerts[index][2] = bytes[1];
        return;
    }
    if (content_type != SSL3_RT_HANDSHAKE || length == 0) return;
    if (bytes[0] == SSL3_MT_NEWSESSION_TICKET) {
        if (is_write) return;
        observed->received_tickets++;
        if (version != TLS1_3_VERSION || length < 4) { observed->invalid = true; return; }
        if (observed->expected_tickets != nullptr) {
            const size_t remaining = observed->expected_ticket_bytes - observed->observed_ticket_bytes;
            if (length > remaining || memcmp(bytes, observed->expected_tickets + observed->observed_ticket_bytes, length) != 0)
                observed->invalid = true;
            else observed->observed_ticket_bytes += length;
        }
        return;
    }
    if (bytes[0] != SSL3_MT_KEY_UPDATE) return;
    if (version != TLS1_3_VERSION || length != 5 || bytes[1] || bytes[2] || bytes[3] != 1 || bytes[4] > 1) {
        observed->invalid = true;
        return;
    }
    unsigned int *count = is_write ? &observed->sent_key_updates : &observed->received_key_updates;
    uint8_t *modes = is_write ? observed->sent_modes : observed->received_modes;
    if (*count == 96) { observed->invalid = true; return; }
    modes[(*count)++] = bytes[4];
}

static void prepare_pair(tls_pair *pair, const char *certificate,
                         const char *private_key, const char *ca,
                         unsigned int tickets, uint16_t suite, int cache_mode)
{
    pair->client_context = SSL_CTX_new(TLS_method());
    pair->server_context = SSL_CTX_new(TLS_method());
    CHECK(pair->client_context && pair->server_context);
    CHECK(SSL_CTX_set1_tls13_ciphers(pair->client_context, &suite, nullptr, 1));
    CHECK(SSL_CTX_set1_tls13_ciphers(pair->server_context, &suite, nullptr, 1));
    CHECK(SSL_CTX_set_min_proto_version(pair->client_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_max_proto_version(pair->client_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_min_proto_version(pair->server_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_max_proto_version(pair->server_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_num_tickets(pair->server_context, tickets));
    SSL_CTX_set_session_cache_mode(pair->client_context, cache_mode);
    CHECK(SSL_CTX_get_session_cache_mode(pair->client_context) == cache_mode);
    CHECK(SSL_CTX_sess_get_new_cb(pair->client_context) == nullptr);
    CHECK(SSL_CTX_use_certificate_chain_file(pair->server_context, certificate));
    CHECK(SSL_CTX_use_PrivateKey_file(pair->server_context, private_key,
                                     SSL_FILETYPE_PEM));
    CHECK(SSL_CTX_check_private_key(pair->server_context));
    CHECK(SSL_CTX_load_verify_locations(pair->client_context, ca, nullptr));
    SSL_CTX_set_verify(pair->client_context, SSL_VERIFY_PEER, nullptr);
    SSL_CTX_set_msg_callback(pair->client_context, observe_message);
    SSL_CTX_set_msg_callback_arg(pair->client_context, &pair->client_observations);
    SSL_CTX_set_msg_callback(pair->server_context, observe_message);
    SSL_CTX_set_msg_callback_arg(pair->server_context, &pair->server_observations);
    pair->client = SSL_new(pair->client_context);
    pair->server = SSL_new(pair->server_context);
    CHECK(pair->client && pair->server);
    CHECK(SSL_set_tlsext_host_name(pair->client, "localhost"));
    CHECK(SSL_set1_host(pair->client, "localhost"));
    SSL_set_connect_state(pair->client);
    SSL_set_accept_state(pair->server);
    BIO *client_bio = nullptr;
    BIO *server_bio = nullptr;
    CHECK(BIO_new_bio_pair(&client_bio, 1024, &server_bio, 1024));
    SSL_set_bio(pair->client, client_bio, client_bio);
    SSL_set_bio(pair->server, server_bio, server_bio);
    bool client_done = false;
    bool server_done = false;
    for (unsigned int i = 0; i < 10000 && (!client_done || !server_done); i++) {
        if (!client_done) {
            int result = SSL_do_handshake(pair->client);
            if (result == 1) client_done = true;
            else check_peer_result(pair->client, result);
        }
        if (!server_done) {
            int result = SSL_do_handshake(pair->server);
            if (result == 1) server_done = true;
            else check_peer_result(pair->server, result);
        }
    }
    CHECK(client_done && server_done);
    CHECK(SSL_version(pair->client) == TLS1_3_VERSION);
    CHECK(SSL_version(pair->server) == TLS1_3_VERSION);
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->client)) == suite);
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->server)) == suite);
    CHECK(SSL_get_verify_result(pair->client) == X509_V_OK);
    CHECK(SSL_get0_peer_certificates(pair->client) != nullptr);
    CHECK(pair->client_observations.received_tickets == 0);
}

static measured_result measured_read(SSL *client, void *output, int length)
{
    uwz_alloc_begin();
    const int result = SSL_read(client, output, length);
    const int error = result > 0 ? SSL_ERROR_NONE : SSL_get_error(client, result);
    uwz_alloc_end();
    return {result, error, snapshot_counts()};
}

static measured_result measured_write(SSL *client, const void *input, int length)
{
    uwz_alloc_begin();
    const int result = SSL_write(client, input, length);
    const int error = result > 0 ? SSL_ERROR_NONE : SSL_get_error(client, result);
    uwz_alloc_end();
    return {result, error, snapshot_counts()};
}

static void record_operation(FILE *output, unsigned int round, const char *row,
                              const char *phase, measured_result operation,
                              const protocol_observations *observed,
                              phase_result *result)
{
    const allocation_counts count = operation.counts;
    fprintf(output, "%u,%s,%s,%u,%d,%d,%llu,%llu,%llu,%llu,%llu,%u,%u,%u\n",
            round, row, phase, result->operations, operation.result, operation.error,
            (unsigned long long)count.malloc_calls,
            (unsigned long long)count.calloc_calls,
            (unsigned long long)count.realloc_calls,
            (unsigned long long)count.free_calls,
            (unsigned long long)count.requested_bytes,
            observed->received_tickets, observed->received_key_updates,
            observed->sent_key_updates);
    add_counts(&result->counts, count);
    result->operations++;
    if (operation.result <= 0) result->retries++;
}

static phase_result read_payload(tls_pair *pair, const uint8_t *payload,
                                  int length, FILE *operations,
                                  unsigned int round, const char *row)
{
    uint8_t received[4096];
    CHECK(length == sizeof(received));
    bool written = false;
    int offset = 0;
    phase_result result{};
    for (unsigned int i = 0; i < 10000 && (!written || offset != length); i++) {
        if (!written) {
            const int sent = SSL_write(pair->server, payload, length);
            if (sent > 0) {
                CHECK(sent == length);
                written = true;
            } else check_peer_result(pair->server, sent);
        }
        if (offset == length) continue;
        const int remaining = length - offset;
        measured_result operation = measured_read(pair->client, received + offset,
                                                   remaining < 257 ? remaining : 257);
        record_operation(operations, round, row, "read", operation,
                          &pair->client_observations, &result);
        if (operation.result > 0) offset += operation.result;
        else CHECK(retry_error(operation.error));
    }
    CHECK(written && offset == length);
    CHECK(memcmp(received, payload, length) == 0);
    return result;
}

static phase_result write_reply(tls_pair *pair, const uint8_t *payload,
                                 int length, FILE *operations,
                                 unsigned int round, const char *row)
{
    uint8_t received[4096];
    CHECK(length == sizeof(received));
    bool written = false;
    int offset = 0;
    phase_result result{};
    for (unsigned int i = 0; i < 10000 && (!written || offset != length); i++) {
        if (!written) {
            measured_result operation = measured_write(pair->client, payload, length);
            record_operation(operations, round, row, "response_write", operation,
                              &pair->client_observations, &result);
            if (operation.result > 0) {
                CHECK(operation.result == length);
                written = true;
            } else CHECK(retry_error(operation.error));
        }
        if (offset == length) continue;
        const int remaining = length - offset;
        const int count = SSL_read(pair->server, received + offset,
                                   remaining < 257 ? remaining : 257);
        if (count > 0) offset += count;
        else check_peer_result(pair->server, count);
    }
    CHECK(written && offset == length);
    CHECK(memcmp(received, payload, length) == 0);
    return result;
}

static void print_counts(FILE *output, allocation_counts counts)
{
    fprintf(output, "{\"malloc\":%llu,\"calloc\":%llu,\"realloc\":%llu,\"free\":%llu,\"bytes\":%llu}",
            (unsigned long long)counts.malloc_calls,
            (unsigned long long)counts.calloc_calls,
            (unsigned long long)counts.realloc_calls,
            (unsigned long long)counts.free_calls,
            (unsigned long long)counts.requested_bytes);
}

struct saved_sessions {
    SSL_SESSION *values[4];
    unsigned int count;
    bool invalid;
};

static int retain_session(SSL *ssl, SSL_SESSION *session)
{
    saved_sessions *saved = static_cast<saved_sessions *>(SSL_get_app_data(ssl));
    if (!saved || saved->count == 4) {
        if (saved) saved->invalid = true;
        return 0;
    }
    saved->values[saved->count++] = session;
    return 1;
}

static void reserve_storage(tls_pair *pair)
{
    CHECK(SSL_reserve_record_buffers(pair->client));
    CHECK(SSL_reserve_client_post_handshake_buffer(pair->client));
    CHECK(SSL_reserve_key_update_context(pair->client));
    CHECK(SSL_reserve_key_update_output_buffers(pair->client));
}

static void enable_policy(tls_pair *pair)
{
#if defined(UWZ_DISCARD_CLIENT_TICKETS)
    CHECK(SSL_discard_client_session_tickets(pair->client));
#else
    (void)pair;
#endif
}

static void exchange_pair(tls_pair *pair, uint16_t suite, unsigned int step,
                           const char *name, FILE *operations,
                           phase_result *reads, phase_result *writes)
{
    uint8_t payload[4096];
    for (size_t i = 0; i < sizeof(payload); i++) payload[i] = static_cast<uint8_t>(i * 7 + suite + step);
    *reads = read_payload(pair, payload, sizeof(payload), operations, step, name);
    *writes = write_reply(pair, payload, sizeof(payload), operations, step, name);
}

static void emit_late_opaque(tls_pair *pair, FILE *operations, unsigned int step,
                             const char *name, phase_result *reads)
{
    uint8_t plaintext[] = {SSL3_MT_NEWSESSION_TICKET,0,0,22, 0,1,0x51,0x80,
        1,2,3,4, 1,0xa5, 0,8, 1,2,3,4,5,6,7,8, 0,0};
    pair->client_observations.expected_tickets = plaintext;
    pair->client_observations.expected_ticket_bytes = sizeof(plaintext);
    pair->client_observations.observed_ticket_bytes = 0;
    uint8_t encrypted[128];
    size_t length = 0;
    CHECK(bssl::tls_seal_record(bssl::FromOpaque(pair->server), encrypted, &length,
        sizeof(encrypted), SSL3_RT_HANDSHAKE, plaintext, sizeof(plaintext)));
    CHECK(BIO_write(SSL_get_wbio(pair->server), encrypted, static_cast<int>(length)) == static_cast<int>(length));
    uint8_t unused[257];
    const measured_result operation = measured_read(pair->client, unused, sizeof(unused));
    record_operation(operations, step, name, "late_opaque_read", operation,
                      &pair->client_observations, reads);
    CHECK(operation.result < 0 && retry_error(operation.error));
    CHECK(!pair->client_observations.invalid);
    CHECK(pair->client_observations.observed_ticket_bytes == sizeof(plaintext));
    pair->client_observations.expected_tickets = nullptr;
    pair->client_observations.expected_ticket_bytes = 0;
}

static void prepare_resumed(tls_pair *pair, const tls_pair *original,
                             SSL_SESSION *session, uint16_t suite)
{
    pair->client_context = original->client_context;
    pair->server_context = original->server_context;
    CHECK(SSL_CTX_up_ref(pair->client_context) && SSL_CTX_up_ref(pair->server_context));
    pair->client = SSL_new(pair->client_context);
    pair->server = SSL_new(pair->server_context);
    CHECK(pair->client && pair->server);
    SSL_set_msg_callback(pair->client, observe_message);
    SSL_set_msg_callback_arg(pair->client, &pair->client_observations);
    SSL_set_msg_callback(pair->server, observe_message);
    SSL_set_msg_callback_arg(pair->server, &pair->server_observations);
    CHECK(SSL_set_tlsext_host_name(pair->client, "localhost") && SSL_set1_host(pair->client, "localhost"));
    CHECK(SSL_set_session(pair->client, session));
    SSL_set_connect_state(pair->client);
    SSL_set_accept_state(pair->server);
    BIO *client_bio = nullptr, *server_bio = nullptr;
    CHECK(BIO_new_bio_pair(&client_bio, 1024, &server_bio, 1024));
    SSL_set_bio(pair->client, client_bio, client_bio);
    SSL_set_bio(pair->server, server_bio, server_bio);
    bool client_done = false, server_done = false;
    for (unsigned int i = 0; i < 10000 && (!client_done || !server_done); i++) {
        if (!client_done) {
            const int value = SSL_do_handshake(pair->client);
            if (value == 1) client_done = true;
            else check_peer_result(pair->client, value);
        }
        if (!server_done) {
            const int value = SSL_do_handshake(pair->server);
            if (value == 1) server_done = true;
            else check_peer_result(pair->server, value);
        }
    }
    CHECK(client_done && server_done && SSL_version(pair->client) == TLS1_3_VERSION);
    CHECK(SSL_session_reused(pair->client) && SSL_session_reused(pair->server));
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->client)) == suite);
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->server)) == suite);
    CHECK(SSL_get_verify_result(pair->client) == X509_V_OK && SSL_get0_peer_certificates(pair->client));
    CHECK(pair->client_observations.received_tickets == 0);
}

#if defined(UWZ_DISCARD_CLIENT_TICKETS)
static void require_zero(allocation_counts value)
{
    CHECK(value.malloc_calls == 0 && value.calloc_calls == 0 && value.realloc_calls == 0);
    CHECK(value.free_calls == 0 && value.requested_bytes == 0);
}
#endif

static void run_chain(uint16_t suite, const char *certificate, const char *private_key,
                       const char *ca, FILE *operations, FILE *summary)
{
    char name[64];
    CHECK(snprintf(name, sizeof(name), "%u_real_initial_resumption", suite) > 0);
    tls_pair original{};
    prepare_pair(&original, certificate, private_key, ca, 2, suite, SSL_SESS_CACHE_CLIENT);
    reserve_storage(&original);
    saved_sessions saved{};
    CHECK(SSL_set_app_data(original.client, &saved));
    SSL_CTX_sess_set_new_cb(original.client_context, retain_session);
    phase_result initial_reads{}, initial_writes{};
    exchange_pair(&original, suite, 0, name, operations, &initial_reads, &initial_writes);
    CHECK(saved.count == 2 && !saved.invalid && original.client_observations.received_tickets == 2);
    CHECK(SSL_SESSION_has_ticket(saved.values[0]) && SSL_SESSION_has_ticket(saved.values[1]));
    SSL_CTX_sess_set_new_cb(original.client_context, nullptr);
    SSL_CTX_set_session_cache_mode(original.client_context, SSL_SESS_CACHE_SERVER);
    CHECK(SSL_CTX_get_session_cache_mode(original.client_context) == SSL_SESS_CACHE_SERVER);
    enable_policy(&original);
    phase_result late_reads{}, late_writes{};
    emit_late_opaque(&original, operations, 1, name, &late_reads);
    phase_result after_late_reads{}, after_late_writes{};
    exchange_pair(&original, suite, 2, name, operations, &after_late_reads, &after_late_writes);
    add_counts(&late_reads.counts, after_late_reads.counts);
    late_reads.operations += after_late_reads.operations;
    late_writes = after_late_writes;
    CHECK(original.client_observations.received_tickets == 3 && saved.count == 2);
    CHECK(SSL_SESSION_has_ticket(saved.values[0]));
    tls_pair resumed{};
    prepare_resumed(&resumed, &original, saved.values[0], suite);
    reserve_storage(&resumed);
    enable_policy(&resumed);
    CHECK(SSL_session_reused(resumed.client) && SSL_session_reused(resumed.server));
    phase_result resumed_reads{}, resumed_writes{};
    exchange_pair(&resumed, suite, 3, name, operations, &resumed_reads, &resumed_writes);
    CHECK(resumed.client_observations.received_tickets == 2 && saved.count == 2);
    CHECK(SSL_session_reused(resumed.client) && SSL_session_reused(resumed.server));
    CHECK(!original.client_observations.invalid && !resumed.client_observations.invalid);
#if defined(UWZ_DISCARD_CLIENT_TICKETS)
    require_zero(late_reads.counts); require_zero(late_writes.counts);
    require_zero(resumed_reads.counts); require_zero(resumed_writes.counts);
    const bool discarded = true;
#else
    const bool discarded = false;
#endif
    fprintf(summary, "{\"suite\":%u,\"discarded\":%s,\"tls13_verified\":true,\"hostname_verified\":true,\"initial_real_tickets_exported\":2,\"ordinary_callback_owned\":true,\"earlier_export_preserved_after_enable\":true,\"actual_session_reused_both_peers\":true,\"resumed_before_enable\":true,\"resumed_after_enable_and_tickets\":true,\"resumed_initial_real_tickets\":2,\"late_opaque_nonresumption_test\":true,\"payloads_exact\":true,\"payload_bytes_each_phase_direction\":4096,\"initial_capture_read\":", suite, discarded ? "true" : "false");
    print_counts(summary, initial_reads.counts);
    fprintf(summary, ",\"initial_capture_write\":"); print_counts(summary, initial_writes.counts);
    fprintf(summary, ",\"active_original_read\":"); print_counts(summary, late_reads.counts);
    fprintf(summary, ",\"active_original_write\":"); print_counts(summary, late_writes.counts);
    fprintf(summary, ",\"active_resumed_read\":"); print_counts(summary, resumed_reads.counts);
    fprintf(summary, ",\"active_resumed_write\":"); print_counts(summary, resumed_writes.counts);
    fprintf(summary, "}\n");
    SSL_free(resumed.client); SSL_free(resumed.server);
    SSL_CTX_free(resumed.client_context); SSL_CTX_free(resumed.server_context);
    SSL_free(original.client); SSL_free(original.server);
    SSL_CTX_free(original.client_context); SSL_CTX_free(original.server_context);
    for (unsigned int i = 0; i < saved.count; i++) SSL_SESSION_free(saved.values[i]);
}

int main(int argc, char **argv)
{
    CHECK(argc == 6 && uwz_alloc_self_test());
    FILE *operations = fopen(argv[4], "wx"), *summary = fopen(argv[5], "wx");
    CHECK(operations && summary);
    fprintf(operations, "step,scenario,phase,operation,result,error,malloc,calloc,realloc,free,bytes,received_tickets,received_key_updates,sent_key_updates\n");
    const uint16_t suites[] = {0x1301, 0x1302, 0x1303};
    for (uint16_t suite : suites) run_chain(suite, argv[1], argv[2], argv[3], operations, summary);
    CHECK(fclose(operations) == 0 && fclose(summary) == 0);
    puts("PASS: three real-initial-ticket export/resumption chains; earlier export and already-resumed state preserved");
    return 0;
}
