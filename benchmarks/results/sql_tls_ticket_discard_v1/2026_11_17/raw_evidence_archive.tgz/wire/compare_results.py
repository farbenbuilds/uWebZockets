#!/usr/bin/env python3
"""Compare deterministic semantics separately from measured allocator changes."""
import argparse
import csv
import json
from pathlib import Path

FIELDS=('malloc','calloc','realloc','free','bytes')


def summaries(directory,name):
    return [json.loads(line) for line in (directory/name).read_text().splitlines()]


def semantic(value):
    if isinstance(value,dict):
        if set(value)==set(FIELDS):return None
        return {key:semantic(item) for key,item in value.items() if key!='discarded' and not (isinstance(item,dict) and set(item)==set(FIELDS))}
    if isinstance(value,list):return [semantic(item) for item in value]
    return value


def operation_semantics(path):
    with path.open() as stream:
        return [{key:value for key,value in row.items() if key not in FIELDS} for row in csv.DictReader(stream)]


def compare(base):
    report=[]
    for suffix in ('','_protocol','_resumption','_controls'):
        first=base/('baseline'+suffix);candidate=base/('candidate'+suffix)
        op='operations.csv' if suffix else 'observe_operations.csv'
        summary='summary.jsonl' if suffix else 'observe_summary.jsonl'
        a=summaries(first,summary);b=summaries(candidate,summary)
        assert semantic(a)==semantic(b),suffix+' summary semantics differ'
        assert operation_semantics(first/op)==operation_semantics(candidate/op),suffix+' call/error/callback sequence differs'
        unreserved=None
        if suffix!='_controls':
            unreserved=base/('candidate_unreserved'+suffix)
            assert (first/op).read_bytes()==(unreserved/op).read_bytes(),suffix+' unreserved operation/counter bytes differ'
            assert (first/summary).read_bytes()==(unreserved/summary).read_bytes(),suffix+' unreserved summary/counter bytes differ'
        deltas=[]
        for before,after in zip(a,b):
            phases={}
            for key,value in before.items():
                if isinstance(value,dict) and set(value)==set(FIELDS):
                    phases[key]={'baseline':value,'discard':after[key]}
            deltas.append({'suite':before.get('suite',before.get('cipher_suite')),
                'scenario':before.get('scenario','real_initial_resumption' if suffix=='_resumption' else 'initial_native'),
                'round':before.get('round'),'phases':phases})
        report.append({'group':suffix.lstrip('_') or 'primary','rows':len(a),
            'operations':len(operation_semantics(first/op)),
            'summary_semantics_identical':True,'full_call_error_callback_sequence_identical':True,
            'full_error_library_reason_queues_and_alert_order_identical':suffix=='_protocol',
            'new_unreserved_raw_operation_and_counter_bytes_identical':None if unreserved is None else True,
            'measured_phases':deltas})
    return {'comparisons':report,'sensitive_ticket_session_bytes_compared_or_logged':False,
        'counter_differences_do_not_weaken_healthy_zero_assertion':True,'strict_postgresql_gate_closed':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('directory',type=Path)
    print(json.dumps(compare(parser.parse_args().directory),indent=2))


if __name__=='__main__':main()
