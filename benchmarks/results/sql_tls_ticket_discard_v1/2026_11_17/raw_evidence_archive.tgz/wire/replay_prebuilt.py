#!/usr/bin/env python3
"""Replay ticket discard gates, encrypted protocol cases and real-session chains."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pki-tool', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    evidence_root = base
    if ((base.parent / 'restore_pki_tool.py').is_file() and
            (base.parent / 'native/HANDOFF.md').is_file()):
        evidence_root = base.parent
    output = args.output.absolute()
    helper = args.pki_tool.resolve(strict=True)
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    if output.resolve().is_relative_to(evidence_root):
        raise ValueError('Keep output outside retained evidence')
    if digest(helper) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('The retained PKI helper checksum differs')
    expected = {'baseline/ticket_witness', 'candidate/ticket_witness',
        'candidate_unreserved/ticket_witness', 'baseline_protocol/protocol_witness',
        'candidate_protocol/protocol_witness', 'candidate_unreserved_protocol/protocol_witness',
        'baseline_controls/control_witness', 'candidate_controls/control_witness',
        'baseline_resumption/resumption_witness','candidate_resumption/resumption_witness',
        'candidate_unreserved_resumption/resumption_witness'}
    identity = json.loads((base/'prebuilt_identity.json').read_text())
    if set(identity['binaries']) != expected:
        raise ValueError('Unexpected retained binary inventory')
    for name, checksum in identity['binaries'].items():
        if digest(base/name) != checksum:
            raise ValueError('Retained executable checksum differs: '+name)
    output.mkdir(parents=True, mode=0o700)
    commands = []
    pki = output/'private_pki'
    complete = False

    def run(command, name, expected_status=0):
        with (output/(name+'.stdout')).open('wb') as out,(output/(name+'.stderr')).open('wb') as err:
            result = subprocess.run(command,cwd=output,stdout=out,stderr=err)
        commands.append({'command':command,'exit_code':result.returncode,'expected_exit_code':expected_status})
        if result.returncode != expected_status:
            raise RuntimeError('Unexpected command status: '+name)

    def compare_files(directory,names):
        for name in names:
            if (output/directory/name).read_bytes() != (base/directory/name).read_bytes():
                raise ValueError('Replay bytes differ: '+directory+'/'+name)

    try:
        run([str(helper),'pki',str(pki)],'pki_metadata')
        arguments = [str(pki/name) for name in ['server.pem','server.key','ca.pem']]
        for name in ['baseline','candidate','candidate_unreserved']:
            target=output/name
            target.mkdir()
            for mode in ['observe','strict']:
                status=1 if mode=='strict' and name!='candidate' else 0
                option='--observe' if mode=='observe' else '--require-zero-tickets'
                run([str(base/name/'ticket_witness'),*arguments,
                    str(target/(mode+'_operations.csv')),str(target/(mode+'_summary.jsonl')),
                    option],name+'_'+mode,status)
                compare_files(name,[mode+'_operations.csv',mode+'_summary.jsonl'])
        for name in ['baseline_protocol','candidate_protocol','candidate_unreserved_protocol',
                     'baseline_controls','candidate_controls','baseline_resumption',
                     'candidate_resumption','candidate_unreserved_resumption']:
            target=output/name
            target.mkdir()
            control=name.endswith('controls')
            kind='control' if control else 'resumption' if name.endswith('resumption') else 'protocol'
            run([str(base/name/(kind+'_witness')),*arguments,str(target/'operations.csv'),
                str(target/'summary.jsonl')],name)
            verifier='verify_controls.py' if control else 'verify_'+kind+'.py'
            command=[sys.executable,str(base/verifier),str(target)]
            if control:
                command.extend(['--operations','operations.csv','--summary','summary.jsonl',
                    '--key-update-reserved','--key-update-output-reserved'])
                if name=='candidate_controls':command.append('--discard-tickets')
            run(command,name+'_verification')
            compare_files(name,['operations.csv','summary.jsonl'])
        run([sys.executable,str(base/'compare_results.py'),str(output)],'comparison')
        complete=True
    finally:
        if pki.exists():
            names={path.name for path in pki.iterdir()}
            if names-{'ca.pem','server.pem','server.key'}:
                raise ValueError('Unexpected PKI output; refusing broad cleanup')
            for name in names:(pki/name).unlink()
            pki.rmdir()
        (output/'results.json').write_text(json.dumps({
            'complete':complete,'commands':commands,'private_pki_removed':not pki.exists(),
            'requires_compiler_native_archives_or_source':False,
            'strict_postgresql_gate_closed':False},indent=2)+'\n')
    print('PASS: genuine ticket RED/GREEN/RED, three-suite protocol/resumption and12 controls replay exactly; private PKI removed')


if __name__=='__main__':main()
