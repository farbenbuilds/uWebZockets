# Encrypted ticket discard witness

The complete-call ticket gate is RED on the immutable baseline, GREEN with `SSL_discard_client_session_tickets`, and RED on the candidate without that opt-in. No native or repository source was edited by this verifier.

## Retained measurements

All executables were measured in Debug (`-O0 -g`) using Zig 0.16.0. Complete client `SSL_read`/`SSL_write` calls and immediate error classification are inside the counter interval; peer preparation, setup, PKI, file output and cleanup are outside. Callbacks only inspect/count/compare fixed caller-owned bytes. The unchanged all-C interposer is SHA256 `afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac`. Each executable first requires its self-test: malloc1/calloc1/realloc1/free2/requested63B.

| Group | Variants | Rows / client calls per variant | Outcome |
|---|---:|---:|---|
| Genuine initial-ticket gate | baseline, new unreserved, new discard | 3 / 75 per observe or strict run | Six real tickets, valid exact4096B each direction; observe exits0 in all modes, strict exits1/1/0 |
| Encrypted protocol | baseline, new unreserved, new discard | 27 / 1320 | Nine healthy discard rows zero; eighteen malformed rows preserve full error queues and alert order |
| Real initial-ticket callback and resumption | baseline, new unreserved, new discard | 3 / 228 | Two real saved sessions per suite; earlier exported session genuinely resumes on both peers after enable; enabling on already-resumed connection preserves state |
| Original public controls | baseline, new discard | 12 / 255 | All candidate client read/write phases zero; requested/unrequested KeyUpdate and exact payloads preserved |

The first gate intentionally repeats three fresh pairs on actual suite0x1301; its frozen runner's inherited docstring mentions three suites, but its assertions and raw summaries accurately specify three fresh0x1301 pairs. The separate protocol and real-resumption matrices publicly configure singleton0x1301/0x1302/0x1303 with null flags on both contexts, require configuration success, and assert both actual negotiated IDs plus CA/localhost verification.

Every baseline gate read of two real tickets allocates/frees12objects/1600B. In the three-suite protocol matrix, real initial tickets allocate/free12objects/1600B for0x1301/0x1303 and1632B for0x1302. Six fragmented/coalesced synthetic tickets cost36malloc/36free/3888B; the unknown-extension case costs6malloc/6free/648B. All these healthy read phases and subsequent writes become zero for all five count fields with discard. Invalid inputs remain outside the zero gate. Real-session export intentionally precedes opt-in and retains12allocations/zero immediate frees; sessions are released once after both connections finish.

`comparison.json` reconciles every operation/result/error/callback sequence and summary semantic field, including the full encoded library/reason queues and ordered client/server alerts. New-unreserved raw operation and summary bytes, including counters, equal baseline exactly. `error_queue_reference.json` additionally decodes the full error words. `baseline_frozen.json` binds the unchanged original gate sources. `control_startup_delta.patch` records the exact delta from the previous control fixture: the already-required KU output reservation is unconditional, and the new ticket opt-in is conditional. No earlier counter, producer or results were modified.

## Protocol and resumption scope

Default native server handshake code produces the real initial tickets. Late protocol inputs are deliberately synthetic opaque ticket contents, sealed by the native server's `tls_seal_record` and delivered through its actual BIO after an exact bidirectional application exchange. No client parser or cipher fields are staged. Those synthetic contents are syntax/protocol inputs and are **not claimed server-resumable**. The separate real initial-ticket export/resumption chain uses actual server-issued tickets and public `SSL_set_session`.

The bounded protocol groups are: real initial tickets; six late tickets with handshake headers split at1/2/3 plus coalescing/repetition; duplicated unknown extensions and unknown TLS flag bits; empty ticket; trailing extension bytes before malformed flag semantics; duplicate flags; malformed early_data before malformed flags; malformed flags; and duplicate early_data before body semantics. Complete known synthetic message bytes are compared in memory through the ordinary callback. A malformed message callback is an observation before semantic rejection; expected fatal reason and actual peer alert receipt are required separately. No real ticket, PSK, session/context bytes or hashes are persisted.

The resumption chain captures two callback-owned real tickets before opt-in, then removes the callback and sets SERVER cache mode before enabling. A later synthetic input does not revoke the earlier exported session. A new verified pair genuinely resumes that saved session on both peers, then enables the policy after that resumed handshake and processes two real initial tickets allocation-free. Cache/CB eligibility, shared-context policy changes, pure parser boundaries, clear/failure lifecycle and generic callback ownership are independently owned by the helper verifier.

This is a bounded ordinary TLS1.3 client functional/allocation witness. Serialized non-reentrant I/O and all four prior storage reservations are prerequisites. Startup, malformed/error, reconnect and complete PostgreSQL integration are outside the healthy zero claim. The full PostgreSQL gate remains open. Dedicated smoke/security/sanitizer/fuzz/scan campaigns were deferred by the user.

## Provenance

Baseline source/build: `/tmp/uwz-pg-tls-ku-output-fixed-20261117`.

- libssl.a `d31754ee7e9275161863588c10433c5c6ace99dc9ab44040072d73c2c7c514bf`
- libcrypto.a `b77e5b0e23987f8d8bdb29e84eb156e9f1d46ba4a8dd7a592cd3bde9823e522b`

Final candidate source/build: `/home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-ticket-discard-fixed-20261117`, author source diff e1e858e8.

- libssl.a `b9891425c059d826fd83a3335fe72207d73cebe992521ca6df473aaba0bfe88f`
- libcrypto.a `0d5945f932ce7620c2c4d431ce1cf85db95900ef134e84d88d2d088f960feaa9`

Each measurement directory retains exact compiler/link/run commands, raw output, source/archive SHA256 and operation CSV/JSONL. Native source hash maps are explicitly scoped subsets, not whole-tree manifests; complete linked archive hashes bind each tested implementation. `reserved` in the original gate provenance selects the ticket-discard compile option. `prebuilt_identity.json` records the eleven original measured Debug executables. Root may make separately identified delivery-only stripped copies using its established ELF-preservation proof; original measured identities remain in the producer measurement records.

## Replay

Run from any location with an absent external output directory:

```sh
python3 /ABS/wire/replay_prebuilt.py --pki-tool /ABS/wt-tools --output /ABS/absent-external-output
```

Exact required PKI helper SHA256 is `531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9`; original tool path is `/tmp/uwz-wt-upstream-backport-client-20261117/client/wt-tools`. No compiler, native source or archive is needed for prebuilt replay. All eleven executables run, primary observe and strict status are checked, each protocol/resumption/control verifier runs, all raw operation/summary output bytes must match retained measurements, and the cross-variant semantic comparison runs. Owned ephemeral PKI is removed in a finally block.

Replay completed successfully at `/home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-ticket-discard-replay-20261117`; `replay_evidence/` retains its raw results and logs. `replay_guards.json` records rejection of existing outputs, standalone own-tree output, and both native/helper siblings inside a recognized combined evidence root. Guards execute before output creation. The combined-root detection is inherited from the hardened prior delivery wrapper; standalone fallback confines its own tree.

For rebuilding, `run_tickets.py NATIVE_ROOT PKI_HELPER ABSENT_OUTPUT [--discard]` preserves the original gate; `build_run.py NATIVE_ROOT PKI_HELPER ABSENT_OUTPUT --fixture protocol|resumption|control [--discard]` runs the bounded groups. Exact invocations and outcomes are retained per directory in `commands.json`.

The frozen payload allowlist excludes native archives, object files, caches, private PKI and duplicate/preliminary executables. It contains the eleven selected measured executables, all raw measurement records, source/deltas, comparison/replay scripts and reports. Root owns packaging and commit/push.
