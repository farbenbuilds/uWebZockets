#include <openssl/err.h>
#include <openssl/ssl.h>
#include <openssl/ssl3.h>
#include <openssl/x509_vfy.h>
#include "ssl/internal.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK(value) do { if (!(value)) fail(__LINE__, #value); } while (0)

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

struct allocation_counts {
    uint64_t malloc_calls;
    uint64_t calloc_calls;
    uint64_t realloc_calls;
    uint64_t free_calls;
    uint64_t requested_bytes;
};

struct measured_result {
    int result;
    int error;
    allocation_counts counts;
};

struct protocol_observations {
    unsigned int received_tickets;
    unsigned int received_key_updates;
    unsigned int sent_key_updates;
    uint8_t received_modes[96];
    uint8_t sent_modes[96];
    bool invalid;
    const uint8_t *expected_tickets;
    size_t expected_ticket_bytes;
    size_t observed_ticket_bytes;
    bool ticket_bytes_exact;
    unsigned int alert_count;
    uint8_t alerts[8][3];
};

struct tls_pair {
    SSL_CTX *client_context;
    SSL_CTX *server_context;
    SSL *client;
    SSL *server;
    protocol_observations client_observations;
    protocol_observations server_observations;
};

struct phase_result {
    allocation_counts counts;
    unsigned int operations;
    unsigned int retries;
};

static void fail(int line, const char *expression)
{
    fprintf(stderr, "check failed at line %d: %s\n", line, expression);
    ERR_print_errors_fp(stderr);
    abort();
}

static allocation_counts snapshot_counts(void)
{
    return {uwz_alloc_malloc_calls(), uwz_alloc_calloc_calls(),
            uwz_alloc_realloc_calls(), uwz_alloc_free_calls(),
            uwz_alloc_requested_bytes()};
}

static void add_counts(allocation_counts *total, allocation_counts value)
{
    total->malloc_calls += value.malloc_calls;
    total->calloc_calls += value.calloc_calls;
    total->realloc_calls += value.realloc_calls;
    total->free_calls += value.free_calls;
    total->requested_bytes += value.requested_bytes;
}

static bool retry_error(int error)
{
    return error == SSL_ERROR_WANT_READ || error == SSL_ERROR_WANT_WRITE;
}

static void check_peer_result(SSL *ssl, int result)
{
    if (result > 0) return;
    CHECK(retry_error(SSL_get_error(ssl, result)));
}

static void observe_message(int is_write, int version, int content_type,
                            const void *buffer, size_t length, SSL *ssl,
                            void *argument)
{
    (void)ssl;
    protocol_observations *observed = static_cast<protocol_observations *>(argument);
    const uint8_t *bytes = static_cast<const uint8_t *>(buffer);
    if (content_type == SSL3_RT_ALERT && length == 2) {
        if (observed->alert_count == 8) { observed->invalid = true; return; }
        const unsigned int index = observed->alert_count++;
        observed->alerts[index][0] = static_cast<uint8_t>(is_write);
        observed->alerts[index][1] = bytes[0];
        observed->alerts[index][2] = bytes[1];
        return;
    }
    if (content_type != SSL3_RT_HANDSHAKE || length == 0) return;
    if (bytes[0] == SSL3_MT_NEWSESSION_TICKET) {
        if (is_write) return;
        observed->received_tickets++;
        if (version != TLS1_3_VERSION || length < 4) { observed->invalid = true; return; }
        if (observed->expected_tickets != nullptr) {
            const size_t remaining = observed->expected_ticket_bytes - observed->observed_ticket_bytes;
            if (length > remaining || memcmp(bytes, observed->expected_tickets + observed->observed_ticket_bytes, length) != 0)
                observed->invalid = true;
            else observed->observed_ticket_bytes += length;
        }
        return;
    }
    if (bytes[0] != SSL3_MT_KEY_UPDATE) return;
    if (version != TLS1_3_VERSION || length != 5 || bytes[1] || bytes[2] || bytes[3] != 1 || bytes[4] > 1) {
        observed->invalid = true;
        return;
    }
    unsigned int *count = is_write ? &observed->sent_key_updates : &observed->received_key_updates;
    uint8_t *modes = is_write ? observed->sent_modes : observed->received_modes;
    if (*count == 96) { observed->invalid = true; return; }
    modes[(*count)++] = bytes[4];
}

static void prepare_pair(tls_pair *pair, const char *certificate,
                         const char *private_key, const char *ca,
                         unsigned int tickets, uint16_t suite, int cache_mode)
{
    pair->client_context = SSL_CTX_new(TLS_method());
    pair->server_context = SSL_CTX_new(TLS_method());
    CHECK(pair->client_context && pair->server_context);
    CHECK(SSL_CTX_set1_tls13_ciphers(pair->client_context, &suite, nullptr, 1));
    CHECK(SSL_CTX_set1_tls13_ciphers(pair->server_context, &suite, nullptr, 1));
    CHECK(SSL_CTX_set_min_proto_version(pair->client_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_max_proto_version(pair->client_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_min_proto_version(pair->server_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_max_proto_version(pair->server_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_num_tickets(pair->server_context, tickets));
    SSL_CTX_set_session_cache_mode(pair->client_context, cache_mode);
    CHECK(SSL_CTX_get_session_cache_mode(pair->client_context) == cache_mode);
    CHECK(SSL_CTX_sess_get_new_cb(pair->client_context) == nullptr);
    CHECK(SSL_CTX_use_certificate_chain_file(pair->server_context, certificate));
    CHECK(SSL_CTX_use_PrivateKey_file(pair->server_context, private_key,
                                     SSL_FILETYPE_PEM));
    CHECK(SSL_CTX_check_private_key(pair->server_context));
    CHECK(SSL_CTX_load_verify_locations(pair->client_context, ca, nullptr));
    SSL_CTX_set_verify(pair->client_context, SSL_VERIFY_PEER, nullptr);
    SSL_CTX_set_msg_callback(pair->client_context, observe_message);
    SSL_CTX_set_msg_callback_arg(pair->client_context, &pair->client_observations);
    SSL_CTX_set_msg_callback(pair->server_context, observe_message);
    SSL_CTX_set_msg_callback_arg(pair->server_context, &pair->server_observations);
    pair->client = SSL_new(pair->client_context);
    pair->server = SSL_new(pair->server_context);
    CHECK(pair->client && pair->server);
    CHECK(SSL_set_tlsext_host_name(pair->client, "localhost"));
    CHECK(SSL_set1_host(pair->client, "localhost"));
    SSL_set_connect_state(pair->client);
    SSL_set_accept_state(pair->server);
    BIO *client_bio = nullptr;
    BIO *server_bio = nullptr;
    CHECK(BIO_new_bio_pair(&client_bio, 1024, &server_bio, 1024));
    SSL_set_bio(pair->client, client_bio, client_bio);
    SSL_set_bio(pair->server, server_bio, server_bio);
    bool client_done = false;
    bool server_done = false;
    for (unsigned int i = 0; i < 10000 && (!client_done || !server_done); i++) {
        if (!client_done) {
            int result = SSL_do_handshake(pair->client);
            if (result == 1) client_done = true;
            else check_peer_result(pair->client, result);
        }
        if (!server_done) {
            int result = SSL_do_handshake(pair->server);
            if (result == 1) server_done = true;
            else check_peer_result(pair->server, result);
        }
    }
    CHECK(client_done && server_done);
    CHECK(SSL_version(pair->client) == TLS1_3_VERSION);
    CHECK(SSL_version(pair->server) == TLS1_3_VERSION);
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->client)) == suite);
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->server)) == suite);
    CHECK(SSL_get_verify_result(pair->client) == X509_V_OK);
    CHECK(SSL_get0_peer_certificates(pair->client) != nullptr);
    CHECK(pair->client_observations.received_tickets == 0);
}

static measured_result measured_read(SSL *client, void *output, int length)
{
    uwz_alloc_begin();
    const int result = SSL_read(client, output, length);
    const int error = result > 0 ? SSL_ERROR_NONE : SSL_get_error(client, result);
    uwz_alloc_end();
    return {result, error, snapshot_counts()};
}

static measured_result measured_write(SSL *client, const void *input, int length)
{
    uwz_alloc_begin();
    const int result = SSL_write(client, input, length);
    const int error = result > 0 ? SSL_ERROR_NONE : SSL_get_error(client, result);
    uwz_alloc_end();
    return {result, error, snapshot_counts()};
}

static void record_operation(FILE *output, unsigned int round, const char *row,
                              const char *phase, measured_result operation,
                              const protocol_observations *observed,
                              phase_result *result)
{
    const allocation_counts count = operation.counts;
    fprintf(output, "%u,%s,%s,%u,%d,%d,%llu,%llu,%llu,%llu,%llu,%u,%u,%u\n",
            round, row, phase, result->operations, operation.result, operation.error,
            (unsigned long long)count.malloc_calls,
            (unsigned long long)count.calloc_calls,
            (unsigned long long)count.realloc_calls,
            (unsigned long long)count.free_calls,
            (unsigned long long)count.requested_bytes,
            observed->received_tickets, observed->received_key_updates,
            observed->sent_key_updates);
    add_counts(&result->counts, count);
    result->operations++;
    if (operation.result <= 0) result->retries++;
}

static phase_result read_payload(tls_pair *pair, const uint8_t *payload,
                                  int length, FILE *operations,
                                  unsigned int round, const char *row)
{
    uint8_t received[4096];
    CHECK(length == sizeof(received));
    bool written = false;
    int offset = 0;
    phase_result result{};
    for (unsigned int i = 0; i < 10000 && (!written || offset != length); i++) {
        if (!written) {
            const int sent = SSL_write(pair->server, payload, length);
            if (sent > 0) {
                CHECK(sent == length);
                written = true;
            } else check_peer_result(pair->server, sent);
        }
        if (offset == length) continue;
        const int remaining = length - offset;
        measured_result operation = measured_read(pair->client, received + offset,
                                                   remaining < 257 ? remaining : 257);
        record_operation(operations, round, row, "read", operation,
                          &pair->client_observations, &result);
        if (operation.result > 0) offset += operation.result;
        else CHECK(retry_error(operation.error));
    }
    CHECK(written && offset == length);
    CHECK(memcmp(received, payload, length) == 0);
    return result;
}

static phase_result write_reply(tls_pair *pair, const uint8_t *payload,
                                 int length, FILE *operations,
                                 unsigned int round, const char *row)
{
    uint8_t received[4096];
    CHECK(length == sizeof(received));
    bool written = false;
    int offset = 0;
    phase_result result{};
    for (unsigned int i = 0; i < 10000 && (!written || offset != length); i++) {
        if (!written) {
            measured_result operation = measured_write(pair->client, payload, length);
            record_operation(operations, round, row, "response_write", operation,
                              &pair->client_observations, &result);
            if (operation.result > 0) {
                CHECK(operation.result == length);
                written = true;
            } else CHECK(retry_error(operation.error));
        }
        if (offset == length) continue;
        const int remaining = length - offset;
        const int count = SSL_read(pair->server, received + offset,
                                   remaining < 257 ? remaining : 257);
        if (count > 0) offset += count;
        else check_peer_result(pair->server, count);
    }
    CHECK(written && offset == length);
    CHECK(memcmp(received, payload, length) == 0);
    return result;
}

static void print_counts(FILE *output, allocation_counts counts)
{
    fprintf(output, "{\"malloc\":%llu,\"calloc\":%llu,\"realloc\":%llu,\"free\":%llu,\"bytes\":%llu}",
            (unsigned long long)counts.malloc_calls,
            (unsigned long long)counts.calloc_calls,
            (unsigned long long)counts.realloc_calls,
            (unsigned long long)counts.free_calls,
            (unsigned long long)counts.requested_bytes);
}

struct ticket_case {
    const char *name;
    uint8_t messages[1024];
    size_t length;
    size_t fragments[24];
    size_t fragment_count;
    unsigned int tickets;
    bool initial;
    bool fatal;
    uint8_t expected_alert;
    uint32_t expected_reason;
};

struct error_codes {
    uint32_t values[16];
    size_t count;
};

struct protocol_result {
    phase_result reads;
    phase_result writes;
    error_codes client_errors;
    error_codes peer_errors;
    int terminal_error;
    int peer_error;
    size_t client_bytes;
    size_t peer_bytes;
};

static error_codes drain_errors(void)
{
    error_codes result{};
    uint32_t value;
    while ((value = ERR_get_error()) != 0) {
        CHECK(result.count < 16);
        result.values[result.count++] = (static_cast<uint32_t>(ERR_GET_LIB(value)) << 24) |
            static_cast<uint32_t>(ERR_GET_REASON(value));
    }
    return result;
}

static void append_phase(phase_result *total, phase_result phase)
{
    add_counts(&total->counts, phase.counts);
    total->operations += phase.operations;
    total->retries += phase.retries;
}

static void reserve_profiles(tls_pair *pair)
{
    CHECK(SSL_reserve_record_buffers(pair->client));
    CHECK(SSL_reserve_client_post_handshake_buffer(pair->client));
    CHECK(SSL_reserve_key_update_context(pair->client));
    CHECK(SSL_reserve_key_update_output_buffers(pair->client));
#if defined(UWZ_DISCARD_CLIENT_TICKETS)
    CHECK(SSL_discard_client_session_tickets(pair->client));
#endif
}

static void exchange_payload(tls_pair *pair, uint16_t suite, unsigned int step,
                              const char *name, FILE *operations,
                              protocol_result *result)
{
    uint8_t payload[4096];
    for (size_t i = 0; i < sizeof(payload); i++) payload[i] = static_cast<uint8_t>(i * 17 + suite + step);
    append_phase(&result->reads, read_payload(pair, payload, sizeof(payload), operations, step, name));
    append_phase(&result->writes, write_reply(pair, payload, sizeof(payload), operations, step, name));
    result->client_bytes += sizeof(payload);
    result->peer_bytes += sizeof(payload);
}

static size_t add_extension(uint8_t *out, uint16_t type, const uint8_t *data, size_t length)
{
    CHECK(length <= 65535);
    out[0] = static_cast<uint8_t>(type >> 8);
    out[1] = static_cast<uint8_t>(type);
    out[2] = static_cast<uint8_t>(length >> 8);
    out[3] = static_cast<uint8_t>(length);
    if (length != 0) memcpy(out + 4, data, length);
    return length + 4;
}

static size_t make_ticket(uint8_t *out, uint8_t nonce,
                          const uint8_t *extensions, size_t extension_length)
{
    const size_t body_length = 22 + extension_length;
    out[0] = SSL3_MT_NEWSESSION_TICKET;
    out[1] = static_cast<uint8_t>(body_length >> 16);
    out[2] = static_cast<uint8_t>(body_length >> 8);
    out[3] = static_cast<uint8_t>(body_length);
    out[4] = 0; out[5] = 1; out[6] = 0x51; out[7] = 0x80;
    out[8] = 1; out[9] = 2; out[10] = 3; out[11] = 4;
    out[12] = 1; out[13] = nonce;
    out[14] = 0; out[15] = 8;
    for (size_t i = 0; i < 8; i++) out[16 + i] = static_cast<uint8_t>(i * 11 + nonce);
    out[24] = static_cast<uint8_t>(extension_length >> 8);
    out[25] = static_cast<uint8_t>(extension_length);
    if (extension_length) memcpy(out + 26, extensions, extension_length);
    return body_length + 4;
}

static void prepare_case(ticket_case *test, unsigned int scenario)
{
    static const char *names[] = {"initial_native", "late_fragmented_coalesced_opaque",
        "late_unknown_duplicates_flags", "empty_ticket", "trailing_extensions",
        "duplicate_flags", "bad_early_before_flags", "bad_flags", "duplicate_early_before_body"};
    CHECK(scenario < 9);
    test->name = names[scenario];
    if (scenario == 0) { test->initial = true; test->tickets = 2; return; }
    if (scenario == 1) {
        for (unsigned int i = 0; i < 6; i++) {
            const size_t length = make_ticket(test->messages + test->length, static_cast<uint8_t>(i + 1), nullptr, 0);
            test->length += length;
            if (i < 3) {
                test->fragments[test->fragment_count++] = i + 1;
                test->fragments[test->fragment_count++] = length - i - 1;
            } else if (i == 4) test->fragments[test->fragment_count++] = length * 2;
            else if (i == 5) test->fragments[test->fragment_count++] = length;
        }
        test->tickets = 6;
        return;
    }
    uint8_t extensions[96];
    size_t length = 0;
    const uint8_t flags_valid[] = {1, 1};
    const uint8_t flags_bad[] = {1, 0};
    const uint8_t early_bad[] = {0, 0, 1};
    const uint8_t early_good[] = {0, 0, 0, 1};
    if (scenario == 2) {
        const uint8_t flags_unknown[] = {5, 0, 0, 0, 0, 0x80};
        length += add_extension(extensions + length, 0xfffe, nullptr, 0);
        length += add_extension(extensions + length, 0xfffe, nullptr, 0);
        length += add_extension(extensions + length, TLSEXT_TYPE_tls_flags, flags_unknown, sizeof(flags_unknown));
    }
    if (scenario == 4 || scenario == 6 || scenario == 7) {
        if (scenario == 6) length += add_extension(extensions + length, TLSEXT_TYPE_early_data, early_bad, sizeof(early_bad));
        length += add_extension(extensions + length, TLSEXT_TYPE_tls_flags, flags_bad, sizeof(flags_bad));
    }
    if (scenario == 5) {
        length += add_extension(extensions + length, TLSEXT_TYPE_tls_flags, flags_valid, sizeof(flags_valid));
        length += add_extension(extensions + length, TLSEXT_TYPE_tls_flags, flags_valid, sizeof(flags_valid));
    }
    if (scenario == 8) {
        length += add_extension(extensions + length, TLSEXT_TYPE_early_data, early_bad, sizeof(early_bad));
        length += add_extension(extensions + length, TLSEXT_TYPE_early_data, early_good, sizeof(early_good));
    }
    test->length = make_ticket(test->messages, 10, extensions, length);
    if (scenario == 3) {
        test->messages[14] = 0; test->messages[15] = 0;
        test->messages[16] = 0; test->messages[17] = 0;
        test->length = 18;
        test->messages[3] = 14;
    }
    if (scenario == 4) {
        test->messages[test->length++] = 0x11;
        test->messages[3]++;
    }
    test->fragments[test->fragment_count++] = test->length;
    test->tickets = 1;
    test->fatal = scenario >= 3;
    test->expected_reason = scenario == 5 || scenario == 8 ? SSL_R_DUPLICATE_EXTENSION : SSL_R_DECODE_ERROR;
    test->expected_alert = scenario == 5 || scenario == 7 || scenario == 8 ? SSL_AD_ILLEGAL_PARAMETER : SSL_AD_DECODE_ERROR;
}

static void feed_fragment(tls_pair *pair, const uint8_t *input, size_t length,
                          const char *name, unsigned int step, FILE *operations,
                          protocol_result *result)
{
    uint8_t encrypted[2048];
    size_t encrypted_length = 0;
    CHECK(bssl::tls_seal_record(bssl::FromOpaque(pair->server), encrypted,
        &encrypted_length, sizeof(encrypted), SSL3_RT_HANDSHAKE, input, length));
    size_t written = 0;
    for (unsigned int attempt = 0; attempt < 100 && written < encrypted_length; attempt++) {
        const int count = BIO_write(SSL_get_wbio(pair->server), encrypted + written,
                                    static_cast<int>(encrypted_length - written));
        CHECK(count > 0 || BIO_should_retry(SSL_get_wbio(pair->server)));
        if (count > 0) written += static_cast<size_t>(count);
        uint8_t unused[257];
        const measured_result operation = measured_read(pair->client, unused, sizeof(unused));
        record_operation(operations, step, name, "ticket_read", operation,
                          &pair->client_observations, &result->reads);
        CHECK(operation.result <= 0);
        if (!retry_error(operation.error)) {
            result->terminal_error = operation.error;
            result->client_errors = drain_errors();
            break;
        }
    }
    CHECK(written == encrypted_length);
}

static void print_errors(FILE *output, const error_codes *errors)
{
    fputc('[', output);
    for (size_t i = 0; i < errors->count; i++) fprintf(output, "%s%u", i ? "," : "", errors->values[i]);
    fputc(']', output);
}

static void print_alerts(FILE *output, const protocol_observations *observed)
{
    fputc('[', output);
    for (unsigned int i = 0; i < observed->alert_count; i++) fprintf(output, "%s[%u,%u,%u]",
        i ? "," : "", observed->alerts[i][0], observed->alerts[i][1], observed->alerts[i][2]);
    fputc(']', output);
}

static void run_case(uint16_t suite, unsigned int scenario,
                      const char *certificate, const char *private_key, const char *ca,
                      FILE *operations, FILE *summary)
{
    ticket_case test{};
    prepare_case(&test, scenario);
    char name[96];
    CHECK(snprintf(name, sizeof(name), "%u_%s", suite, test.name) > 0);
    const int cache_mode = test.initial ? SSL_SESS_CACHE_OFF : SSL_SESS_CACHE_SERVER;
    tls_pair pair{};
    prepare_pair(&pair, certificate, private_key, ca, test.initial ? 2 : 0, suite, cache_mode);
    reserve_profiles(&pair);
    protocol_result result{};
    if (test.initial) exchange_payload(&pair, suite, 0, name, operations, &result);
    else {
        CHECK(pair.client_observations.received_tickets == 0);
        exchange_payload(&pair, suite, 0, name, operations, &result);
        CHECK(pair.client_observations.received_tickets == 0);
        pair.client_observations.expected_tickets = test.messages;
        pair.client_observations.expected_ticket_bytes = test.length;
        pair.client_observations.ticket_bytes_exact = true;
        size_t offset = 0;
        for (size_t i = 0; i < test.fragment_count; i++) {
            feed_fragment(&pair, test.messages + offset, test.fragments[i], name,
                           static_cast<unsigned int>(i + 1), operations, &result);
            offset += test.fragments[i];
            if (result.terminal_error != 0) break;
        }
        CHECK(offset == test.length);
    }
    CHECK(pair.client_observations.received_tickets == test.tickets);
    if (test.fatal) {
        CHECK(result.terminal_error == SSL_ERROR_SSL && result.client_errors.count != 0);
        CHECK((result.client_errors.values[result.client_errors.count - 1] & 0xffffff) == test.expected_reason);
        CHECK(pair.client_observations.alert_count == 1);
        CHECK(pair.client_observations.alerts[0][0] == 1 && pair.client_observations.alerts[0][1] == SSL3_AL_FATAL);
        CHECK(pair.client_observations.alerts[0][2] == test.expected_alert);
        ERR_clear_error();
        uint8_t unused[257];
        const int value = SSL_read(pair.server, unused, sizeof(unused));
        CHECK(value < 0);
        result.peer_error = SSL_get_error(pair.server, value);
        result.peer_errors = drain_errors();
        CHECK(result.peer_error == SSL_ERROR_SSL && pair.server_observations.alert_count == 1);
        CHECK(pair.server_observations.alerts[0][0] == 0 && pair.server_observations.alerts[0][1] == SSL3_AL_FATAL);
        CHECK(pair.server_observations.alerts[0][2] == test.expected_alert);
    } else {
        if (!test.initial) exchange_payload(&pair, suite, 20, name, operations, &result);
        CHECK(SSL_key_update(pair.server, SSL_KEY_UPDATE_NOT_REQUESTED));
        exchange_payload(&pair, suite, 21, name, operations, &result);
        CHECK(SSL_key_update(pair.server, SSL_KEY_UPDATE_REQUESTED));
        exchange_payload(&pair, suite, 22, name, operations, &result);
        CHECK(pair.client_observations.received_key_updates == 2 && pair.client_observations.sent_key_updates == 1);
        CHECK(pair.server_observations.received_key_updates == 1);
        CHECK(pair.client_observations.received_modes[0] == 0 && pair.client_observations.received_modes[1] == 1);
        CHECK(pair.server_observations.received_modes[0] == 0);
        CHECK(pair.client_observations.alert_count == 0 && pair.server_observations.alert_count == 0);
#if defined(UWZ_DISCARD_CLIENT_TICKETS)
        CHECK(result.reads.counts.malloc_calls == 0 && result.reads.counts.calloc_calls == 0);
        CHECK(result.reads.counts.realloc_calls == 0 && result.reads.counts.free_calls == 0 && result.reads.counts.requested_bytes == 0);
        CHECK(result.writes.counts.malloc_calls == 0 && result.writes.counts.calloc_calls == 0);
        CHECK(result.writes.counts.realloc_calls == 0 && result.writes.counts.free_calls == 0 && result.writes.counts.requested_bytes == 0);
#endif
    }
    CHECK(!pair.client_observations.invalid && !pair.server_observations.invalid);
    CHECK(test.initial || pair.client_observations.observed_ticket_bytes == test.length);
#if defined(UWZ_DISCARD_CLIENT_TICKETS)
    const bool discarded = true;
#else
    const bool discarded = false;
#endif
    fprintf(summary, "{\"suite\":%u,\"scenario\":\"%s\",\"discarded\":%s,\"tls13_verified\":true,\"hostname_verified\":true,\"client_negotiated_suite\":%u,\"server_negotiated_suite\":%u,\"cache_mode\":%d,\"initial_real_ticket\":%s,\"issued_after_warm_payload\":%s,\"synthetic_opaque_nonresumption_test\":%s,\"received_tickets\":%u,\"complete_synthetic_bytes_exact\":%s,\"client_received_bytes\":%zu,\"server_received_bytes\":%zu,\"terminal_error\":%d,\"peer_error\":%d,\"client_key_updates\":%u,\"client_sent_updates\":%u,\"peer_received_updates\":%u,\"read_operations\":%u,\"write_operations\":%u,\"client_error_queue\":",
        suite, test.name, discarded ? "true" : "false", suite, suite, cache_mode,
        test.initial ? "true" : "false", test.initial ? "false" : "true", test.initial ? "false" : "true",
        pair.client_observations.received_tickets, test.initial ? "null" : "true",
        result.client_bytes, result.peer_bytes, result.terminal_error, result.peer_error,
        pair.client_observations.received_key_updates, pair.client_observations.sent_key_updates,
        pair.server_observations.received_key_updates, result.reads.operations, result.writes.operations);
    print_errors(summary, &result.client_errors);
    fprintf(summary, ",\"peer_error_queue\":"); print_errors(summary, &result.peer_errors);
    fprintf(summary, ",\"client_alerts\":"); print_alerts(summary, &pair.client_observations);
    fprintf(summary, ",\"peer_alerts\":"); print_alerts(summary, &pair.server_observations);
    fprintf(summary, ",\"client_read\":"); print_counts(summary, result.reads.counts);
    fprintf(summary, ",\"client_write\":"); print_counts(summary, result.writes.counts);
    fprintf(summary, "}\n");
    SSL_free(pair.client); SSL_free(pair.server);
    SSL_CTX_free(pair.client_context); SSL_CTX_free(pair.server_context);
}

int main(int argc, char **argv)
{
    CHECK(argc == 6 && uwz_alloc_self_test());
    FILE *operations = fopen(argv[4], "wx"), *summary = fopen(argv[5], "wx");
    CHECK(operations && summary);
    fprintf(operations, "step,scenario,phase,operation,result,error,malloc,calloc,realloc,free,bytes,received_tickets,received_key_updates,sent_key_updates\n");
    const uint16_t suites[] = {0x1301, 0x1302, 0x1303};
    for (uint16_t suite : suites) {
        for (unsigned int scenario = 0; scenario < 9; scenario++)
            run_case(suite, scenario, argv[1], argv[2], argv[3], operations, summary);
    }
    CHECK(fclose(operations) == 0 && fclose(summary) == 0);
    puts("PASS: 27 actual-suite encrypted ticket rows, valid payloads, full error queues and alert order");
    return 0;
}
