# Delivery-only debug stripping

The measured ticket-discard programs were built in Debug with Zig 0.16.0.
This packaging step removed nonallocated debug sections from 32 staged delivery
copies: 21 helper executables and 11 wire executables. Total executable bytes
changed from 585,633,688 to 163,616,600. Optimization settings and native code
were preserved; no compilation, optimization or relinking occurred.

`manifest.json` maps every original measured SHA-256 and byte count to its
actual delivered SHA-256 and byte count, with the exact command, tool identity
and ELF comparison result. Original identity maps are archived unchanged as
`original_helper_prebuilt_identity.json` and
`original_wire_prebuilt_identity.json`. Original subtree manifests are retained
as `original_helper_files.sha256` and `original_wire_payload_manifest.json`.
Current identity maps identify the actual delivered executable hashes and add
explicit `delivery_bytes` maps and the `delivery_transform` link.

Wire's current `delivery_stripping` metadata was explicitly authorized to change
from false to true. The original false value remains in its archived identity
map. All other original identity field values remain unchanged, including
helper's complete baseline/candidate native archive maps and both optimization
fields. Those optimization descriptions remain historical measured Debug
metadata. Existing separate `measured_debug_identity.json` files, where present,
remain byte-for-byte unchanged. Historical build, provenance and raw result
records retain their original measured identities.

The two producer manifest formats remain distinct. Helper keeps its
`files.sha256`; wire keeps the `sha256` map in `payload_manifest.json`. Only
payload hash values were refreshed in those current manifests. Wire's other
JSON metadata fields remain unchanged. No `files.sha256` or other new standard
manifest was added inside wire, and neither replay wrapper was modified.

Root explicitly authorized this operation after copying and verifying both
frozen producer allowlists. `authorization.json` and its embedded copy in
`manifest.json` retain exact counts, manifest identities and the additional
wire metadata permission. Immutable original producers remain on workspace SSD:

- Helper: `.zig-cache/sql-tls-ticket-discard-verify-20261117`, with 916 selected
  payload files, 915 manifest hash entries and 21 executables.
- Wire: `.zig-cache/sql-tls-ticket-discard-wire-20261117`, with 241 selected
  payload files, 240 manifest hash entries and 11 executables.

All roots are relative to `/home/foo/Desktop/Repos/uWebZockets`. Bulk scratch
outputs also stay on workspace SSD, under
`.zig-cache/sql-tls-ticket-discard-delivery-packaging-20261117`.

The operation used existing `/usr/bin/objcopy --strip-debug`, GNU Binutils for
Ubuntu 2.46. Its executable SHA-256 is
`05f4473d24f7330a9b13f43d007d619a2e792e33de453cd7533a2d97c30da770`.
The complete version output and every actual command are recorded. No tool was
installed. This is artifact packaging only and adds no native compilation,
linking, source-replay or project build dependency. Prebuilt replay needs
neither objcopy nor a compiler.

Prior evidence established that pinned Zig 0.16.0 `objcopy --strip-debug`
ELF-to-ELF output returns `error: unimplemented` at
`lib/compiler/objcopy.zig:207`. The historical observation and pinned Zig
identity are retained in `manifest.json`; no new probe was run.

Before any staged replacement, all 32 outputs passed the bounded little-endian
ELF64 x86-64 comparison. Each inventory is bounded to 1 through 32 executables
and must equal Root's exact authorized count. The entrypoint and ELF ABI
identity, every program-header tuple and every allocated section's name, type,
flags, address, size, alignment, entry size, linked-section meaning and payload
remain equal. Every PT_LOAD byte range matches after normalizing only ELF
section-table coordinates: `e_shoff` at offset 40 for 8 bytes, `e_shnum` at
offset 60 for 2 bytes and `e_shstrndx` at offset 62 for 2 bytes. Original debug
sections are absent from delivery copies; regular symbol tables remain present.
Complete file bytes and hashes differ after stripping.

`verify_delivery.py` independently rechecks both frozen producer manifest
identities, all 1,155 original producer hash entries, archived original identity
maps, exactly 1,121 staged entries outside the 32 executables and two current
identity maps, both current submanifest payload sets, all 32 measured-to-delivery
maps and runtime ELF proofs, and all 32 regular symbol tables. It rejects other
identity-field changes and other wire JSON manifest metadata changes. Its result
is `post_transform_verification.json`. Native and measurement-fixture sources,
assertions, raw results, inputs and replay wrappers in those manifests remain
unchanged. There is no wrapper transformation step.

To regenerate a delivery executable from its original Debug input, use the
recorded command shape:

```sh
/usr/bin/objcopy --strip-debug ORIGINAL_DEBUG_EXECUTABLE NEW_DELIVERY_EXECUTABLE
```

Require the original input identity, preserve executable permissions and compare
ELF properties before replacement. `strip_delivery.py` records this one-time
staging operation, explicit workspace roots, Root authorization requirement and
refusal of existing transformation outputs. For a fresh namespace, adapt only
those roots after preparing and authorizing fresh original inputs. Do not rerun
it against the stripped delivery tree. Source rebuilds can have path-dependent
Debug hashes and must record their own measured identities.

Static verification used:

```sh
env PYTHONDONTWRITEBYTECODE=1 python3 delivery_transform/verify_delivery.py
```

This verifier needs the original producer roots above. No functional replay,
smoke, security or additional native test campaign ran during this packaging
step. Root owns both complete final copied-layout replays against delivered
binaries and final archive verification.
