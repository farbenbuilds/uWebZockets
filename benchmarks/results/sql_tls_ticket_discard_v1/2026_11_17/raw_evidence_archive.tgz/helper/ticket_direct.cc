#include "ticket_observe.h"

static void print_errors(const uint32_t *errors, size_t count)
{
    putchar('[');
    for (size_t index = 0; index < count; index++) {
        if (index) putchar(',');
        printf("%u", errors[index]);
    }
    putchar(']');
}

static void run_vector(char **arguments, const VectorSpec *spec, bool discard)
{
    TicketInput input;
    build_ticket(spec->id, &input);
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    TicketObservations observation = {};
    prepare(&pair, &input, &observation);
    auto *established = bssl::FromOpaque(pair.client)->s3->established_session.get();
    CHECK(established && SSL_get_session(pair.client) == established);
    SSL_SESSION *owned_getter = SSL_get1_session(pair.client);
    CHECK(owned_getter == established);
    const uint32_t old_early_data = established->ticket_max_early_data;
    const bool old_names_flag = established->is_resumable_across_names;
    if (input.seeded_base_metadata) {
        // Direct copy-semantics fixture, not a peer resumption claim.
        established->ticket_max_early_data = 1234;
        established->is_resumable_across_names = true;
    }
    test_clock.active = &observation;
#if TICKET_DISCARD_API
    if (discard) {
        uwz_alloc_begin();
        CHECK(SSL_discard_client_session_tickets(pair.client));
        uwz_alloc_end();
        const AllocationCounts startup = counts();
        CHECK(zero_counts(&startup));
        CHECK(observation.times == 0 && observation.event_count == 0);
    }
#else
    CHECK(!discard);
#endif
    // Enabled per-SSL policy must dominate subsequent shared-CTX settings.
    SSL_CTX_set_session_cache_mode(pair.client_context, SSL_SESS_CACHE_CLIENT);
    SSL_CTX_sess_set_new_cb(pair.client_context, new_session);
#if TICKET_DISCARD_API
    if (discard) CHECK(SSL_discard_client_session_tickets(pair.client));
#endif
    ERR_clear_error();
    uwz_alloc_begin();
    const bool result = process_ticket(pair.client, &input);
    uwz_alloc_end();
    const AllocationCounts measured = counts();
    test_clock.active = nullptr;
    uint32_t errors[32];
    size_t error_count = 0;
    uint32_t value;
    while ((value = ERR_get_error()) != 0) {
        CHECK(error_count < 32);
        errors[error_count++] = error_code(value);
    }
    CHECK(result == spec->valid);
    CHECK(observation.messages == 1 && observation.times == (discard ? 0 : 1));
    CHECK(observation.sessions == (spec->valid && !discard ? 1 : 0));
    CHECK(observation.alerts == (spec->valid ? 0 : 1));
    CHECK(SSL_get_session(pair.client) == established && owned_getter == established);
    if (spec->valid && discard) CHECK(zero_counts(&measured));
    if (spec->valid && !discard) CHECK(observation.metadata_valid && measured.malloc_calls > 0);
    printf("{\"case\":\"%s\",\"discard\":%s,\"valid\":%s,\"result\":%s,"
        "\"body_bytes\":%zu,\"messages\":%zu,\"times\":%zu,\"sessions\":%zu,"
        "\"alerts\":%zu,\"alert_level\":%u,\"alert_description\":%u,\"events\":\"%s\","
        "\"event_errors\":", spec->name, discard ? "true" : "false", spec->valid ? "true" : "false",
        result ? "true" : "false", input.length, observation.messages, observation.times,
        observation.sessions, observation.alerts, observation.alert_level, observation.alert_description,
        observation.events);
    print_errors(observation.event_errors, observation.event_count);
    printf(",\"errors\":");
    print_errors(errors, error_count);
    printf(",\"metadata_valid\":%s,\"established_getters_unchanged\":true,"
        "\"malloc\":%llu,\"calloc\":%llu,\"realloc\":%llu,\"free\":%llu,\"bytes\":%llu,"
        "\"sizeof_ssl3_state\":%zu}\n", observation.metadata_valid ? "true" : "false",
        static_cast<unsigned long long>(measured.malloc_calls),
        static_cast<unsigned long long>(measured.calloc_calls),
        static_cast<unsigned long long>(measured.realloc_calls),
        static_cast<unsigned long long>(measured.free_calls),
        static_cast<unsigned long long>(measured.bytes), sizeof(bssl::SSL3_STATE));
    established->ticket_max_early_data = old_early_data;
    established->is_resumable_across_names = old_names_flag;
    SSL_SESSION_free(owned_getter);
    destroy_pair(&pair);
}

int main(int argc, char **argv)
{
    CHECK(argc == 5);
    const bool discard = strcmp(argv[4], "discard") == 0;
    CHECK(discard || strcmp(argv[4], "generic") == 0);
    CHECK(uwz_alloc_self_test());
    OPENSSL_PUT_ERROR(SSL, SSL_R_DECODE_ERROR);
    ERR_clear_error();
    for (const VectorSpec &spec : vector_specs) run_vector(argv, &spec, discard);
    puts("PASS: 37 direct synthetic ticket syntax/metadata/order vectors; self-test63; no resumption claim");
}
