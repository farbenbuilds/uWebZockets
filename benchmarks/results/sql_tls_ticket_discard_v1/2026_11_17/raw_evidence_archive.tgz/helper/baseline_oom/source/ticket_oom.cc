#include "ticket_vectors.h"
#include "ticket_fault.h"

struct FaultObservation {
    size_t times;
    size_t alerts;
    uint8_t alert_level;
    uint8_t alert_description;
    char events[16];
    uint32_t event_errors[16];
    size_t event_count;
};

struct FaultClock {
    FaultObservation *active;
    uint64_t seconds;
};

// The pinned clock callback has no userdata; one test OS thread owns routing.
static thread_local FaultClock fault_clock = {};

static uint32_t encoded_error(uint32_t error)
{
    return (static_cast<uint32_t>(ERR_GET_LIB(error)) << 24) | ERR_GET_REASON(error);
}

static void note(FaultObservation *observation, char kind)
{
    CHECK(observation->event_count < 15);
    observation->events[observation->event_count] = kind;
    observation->event_errors[observation->event_count] = encoded_error(ERR_peek_last_error());
    observation->events[++observation->event_count] = 0;
}

static void time_callback(const SSL *ssl, struct timeval *out)
{
    CHECK(!ssl);
    out->tv_sec = static_cast<time_t>(fault_clock.seconds);
    out->tv_usec = 0;
    if (!fault_clock.active) return;
    fault_clock.active->times++;
    note(fault_clock.active, 'T');
}

static void alert_callback(int writing, int version, int type, const void *bytes,
                           size_t length, SSL *ssl, void *argument)
{
    (void)version;
    (void)ssl;
    if (!writing || type != SSL3_RT_ALERT || length != 2) return;
    auto *observation = static_cast<FaultObservation *>(argument);
    const uint8_t *data = static_cast<const uint8_t *>(bytes);
    observation->alerts++;
    observation->alert_level = data[0];
    observation->alert_description = data[1];
    note(observation, 'A');
}

static void print_codes(const uint32_t *codes, size_t length)
{
    putchar('[');
    for (size_t index = 0; index < length; index++) {
        if (index) putchar(',');
        printf("%u", codes[index]);
    }
    putchar(']');
}

static void run_case(char **arguments, unsigned kind)
{
    TicketInput input;
    build_ticket(kind == 1 ? max_fields : short_lifetime, &input);
    if (kind == 1) {
        // Valid 257-byte ticket, malformed outer extensions vector after copying.
        input.body[input.length - 2] = 0;
        input.body[input.length - 1] = 4;
    }
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    CHECK(SSL_reserve_record_buffers(pair.client));
    FaultObservation observation = {};
    fault_clock.seconds = SSL_SESSION_get_time(SSL_get_session(pair.client)) + 1;
    SSL_CTX_set_current_time_cb(pair.client_context, time_callback);
    SSL_set_msg_callback(pair.client, alert_callback);
    SSL_set_msg_callback_arg(pair.client, &observation);
    CBS body;
    CBS_init(&body, input.body, input.length);
    ticket_fault_reset();
    ERR_clear_error();
    fault_clock.active = &observation;
    if (kind == 0) ticket_fault_arm_ordinal(1);
    else ticket_fault_arm_size(257 + 8);
    auto session = bssl::tls13_create_session_with_ticket(bssl::FromOpaque(pair.client), &body);
    ticket_fault_disarm();
    fault_clock.active = nullptr;
    CHECK(!session);
    uint32_t errors[32];
    size_t error_count = 0;
    uint32_t error;
    while ((error = ERR_get_error()) != 0) {
        CHECK(error_count < 32);
        errors[error_count++] = encoded_error(error);
    }
    const TicketFaultStats measured = ticket_fault_read();
    CHECK(measured.injected == (kind == 2 ? 0 : 1));
    CHECK(observation.times == (kind == 0 ? 0 : 1));
    CHECK(observation.alerts == (kind == 0 ? 0 : 1));
    destroy_pair(&pair);
    const TicketFaultStats final = ticket_fault_read();
    CHECK(final.live == 0 && final.actual_frees == final.successful);
    CHECK(final.cleanse_failures == 0 && final.calloc_calls == 0 && final.realloc_calls == 0);
    const char *names[] = {"duplicate_oom_before_malformed_prefix", "ticket_copy_oom_before_vector_error",
        "malformed_prefix_before_ticket_copy"};
    printf("{\"case\":\"%s\",\"scope\":\"direct_generic_factory_oom_order\","
        "\"times\":%zu,\"alerts\":%zu,\"alert_level\":%u,\"alert_description\":%u,"
        "\"events\":\"%s\",\"event_errors\":", names[kind], observation.times,
        observation.alerts, observation.alert_level, observation.alert_description, observation.events);
    print_codes(observation.event_errors, observation.event_count);
    printf(",\"errors\":");
    print_codes(errors, error_count);
    printf(",\"attempts\":%llu,\"injected\":%llu,\"successful\":%llu,\"actual_frees\":%llu,"
        "\"live\":0,\"cleanse_failures\":0}\n",
        static_cast<unsigned long long>(final.attempts), static_cast<unsigned long long>(final.injected),
        static_cast<unsigned long long>(final.successful), static_cast<unsigned long long>(final.actual_frees));
}

int main(int argc, char **argv)
{
    CHECK(argc == 4);
    OPENSSL_PUT_ERROR(SSL, SSL_R_DECODE_ERROR);
    ERR_clear_error();
    for (unsigned kind = 0; kind < 3; kind++) run_case(argv, kind);
    puts("PASS: generic duplicate/time/prefix/ticket-copy/vector OOM and alert/error precedence");
}
