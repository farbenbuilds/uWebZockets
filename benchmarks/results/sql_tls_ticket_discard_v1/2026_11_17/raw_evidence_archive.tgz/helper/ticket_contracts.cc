#include "ticket_observe.h"

static void session_freed(void *parent, void *pointer, CRYPTO_EX_DATA *data,
                          int index, long argument, void *extra)
{
    (void)parent;
    (void)data;
    (void)index;
    (void)argument;
    (void)extra;
    if (pointer) static_cast<SessionLifetime *>(pointer)->frees++;
}

static void ownership(char **arguments, uint16_t suite, bool retain, int lifetime_index)
{
    TicketInput input;
    build_ticket(minimal, &input);
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024, suite);
    SessionLifetime lifetime = {};
    TicketObservations observation = {};
    observation.lifetime = &lifetime;
    observation.lifetime_index = lifetime_index;
    observation.take_ownership = retain;
    prepare(&pair, &input, &observation);
    SSL_CTX_set_session_cache_mode(pair.client_context, SSL_SESS_CACHE_CLIENT);
    SSL_CTX_sess_set_new_cb(pair.client_context, new_session);
    SSL_SESSION *established = SSL_get_session(pair.client);
    SSL_SESSION *owned_getter = SSL_get1_session(pair.client);
    CHECK(owned_getter == established);
    test_clock.active = &observation;
    uwz_alloc_begin();
    CHECK(process_ticket(pair.client, &input));
    uwz_alloc_end();
    const AllocationCounts measured = counts();
    CHECK(!zero_counts(&measured) && measured.malloc_calls > 0);
    test_clock.active = nullptr;
    CHECK(observation.messages == 1 && observation.times == 1 && observation.sessions == 1);
    CHECK(observation.metadata_valid && observation.alerts == 0);
    CHECK(SSL_get_session(pair.client) == established);
    CHECK(lifetime.frees == (retain ? 0 : 1));
    CHECK((observation.retained != nullptr) == retain);
    if (retain) CHECK(observation.retained != established);
    destroy_pair(&pair);
    CHECK(SSL_SESSION_get_protocol_version(owned_getter) == TLS1_3_VERSION);
    CHECK(lifetime.frees == (retain ? 0 : 1));
    if (retain) {
        const uint8_t *ticket;
        size_t length;
        SSL_SESSION_get0_ticket(observation.retained, &ticket, &length);
        CHECK(length == 1 && ticket[0] == 7);
        CHECK(SSL_SESSION_get_protocol_version(observation.retained) == TLS1_3_VERSION);
        SSL_SESSION_free(observation.retained);
        observation.retained = nullptr;
    }
    CHECK(lifetime.frees == 1);
    SSL_SESSION_free(owned_getter);
    printf("{\"case\":\"generic_callback_ownership\",\"suite\":%u,\"callback_return\":%u,"
        "\"session_callback_calls\":1,\"session_tag_frees\":1,\"retained_outlives_ssl_ctx\":%s,"
        "\"established_getters_unchanged\":true,\"synthetic_ticket_not_resumption_proof\":true,"
        "\"malloc\":%llu,\"calloc\":%llu,\"realloc\":%llu,\"free\":%llu,\"bytes\":%llu}\n",
        suite, retain, retain ? "true" : "false",
        static_cast<unsigned long long>(measured.malloc_calls),
        static_cast<unsigned long long>(measured.calloc_calls),
        static_cast<unsigned long long>(measured.realloc_calls),
        static_cast<unsigned long long>(measured.free_calls),
        static_cast<unsigned long long>(measured.bytes));
}

#if TICKET_DISCARD_API
static void enable(SSL *ssl, int expected)
{
    ERR_clear_error();
    uwz_alloc_begin();
    CHECK(SSL_discard_client_session_tickets(ssl) == expected);
    uwz_alloc_end();
    const AllocationCounts measured = counts();
    CHECK(zero_counts(&measured));
    CHECK(bssl::FromOpaque(ssl)->s3->discard_client_session_tickets == static_cast<bool>(expected));
    if (!expected) CHECK(ERR_peek_error() != 0);
    ERR_clear_error();
}

static void initial_policy(char **arguments, long mode, bool callback)
{
    TicketInput input;
    build_ticket(minimal, &input);
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    TicketObservations observation = {};
    prepare(&pair, &input, &observation);
    SSL_CTX_set_session_cache_mode(pair.client_context, mode);
    SSL_CTX_sess_set_new_cb(pair.client_context, callback ? new_session : nullptr);
    const int expected = !(mode & SSL_SESS_CACHE_CLIENT) && !callback;
    SSL_SESSION *established = SSL_get_session(pair.client);
    enable(pair.client, expected);
    CHECK(SSL_get_session(pair.client) == established);
    CHECK(SSL_CTX_get_session_cache_mode(pair.client_context) == mode);
    CHECK(SSL_CTX_sess_get_new_cb(pair.client_context) == (callback ? new_session : nullptr));
    if (expected) {
        SSL_CTX_set_session_cache_mode(pair.client_context, SSL_SESS_CACHE_BOTH);
        SSL_CTX_sess_set_new_cb(pair.client_context, new_session);
        enable(pair.client, 1);
        test_clock.active = &observation;
        uwz_alloc_begin();
        CHECK(process_ticket(pair.client, &input));
        uwz_alloc_end();
        const AllocationCounts measured = counts();
        CHECK(zero_counts(&measured));
        test_clock.active = nullptr;
        CHECK(observation.messages == 1 && observation.times == 0 && observation.sessions == 0);
        CHECK(SSL_get_session(pair.client) == established);
    }
    printf("{\"case\":\"initial_cache_callback_policy\",\"cache_mode\":%ld,"
        "\"callback_present\":%s,\"enabled\":%s,\"api_heap_operations\":0,"
        "\"later_context_changes_preserve_policy\":%s}\n", mode, callback ? "true" : "false",
        expected ? "true" : "false", expected ? "true" : "null");
    destroy_pair(&pair);
}

static void session_context_policy(char **arguments, bool original_safe)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    SSL_CTX_set_session_cache_mode(pair.client_context,
        original_safe ? SSL_SESS_CACHE_SERVER : SSL_SESS_CACHE_BOTH);
    SSL_CTX_sess_set_new_cb(pair.client_context, original_safe ? nullptr : new_session);
    SSL_CTX *replacement = SSL_CTX_new(TLS_method());
    CHECK(replacement);
    SSL_CTX_set_session_cache_mode(replacement,
        original_safe ? SSL_SESS_CACHE_BOTH : SSL_SESS_CACHE_SERVER);
    SSL_CTX_sess_set_new_cb(replacement, original_safe ? new_session : nullptr);
    CHECK(SSL_set_SSL_CTX(pair.client, replacement));
    CHECK(bssl::FromOpaque(pair.client)->session_ctx.get() == bssl::FromOpaque(pair.client_context));
    CHECK(bssl::FromOpaque(pair.client)->ctx.get() == bssl::FromOpaque(replacement));
    enable(pair.client, original_safe ? 1 : 0);
    printf("{\"case\":\"session_ctx_guard\",\"original_session_ctx_safe\":%s,"
        "\"current_ctx_opposite_policy\":true,\"guard_uses_session_ctx\":true,\"api_heap_operations\":0}\n",
        original_safe ? "true" : "false");
    destroy_pair(&pair);
    SSL_CTX_free(replacement);
}

static PeerPair make_sibling(PeerPair *original)
{
    PeerPair pair = {};
    CHECK(SSL_CTX_up_ref(original->client_context) && SSL_CTX_up_ref(original->server_context));
    pair.client_context = original->client_context;
    pair.server_context = original->server_context;
    pair.client = SSL_new(pair.client_context);
    pair.server = SSL_new(pair.server_context);
    CHECK(pair.client && pair.server);
    CHECK(SSL_set_tlsext_host_name(pair.client, "localhost"));
    CHECK(SSL_set1_host(pair.client, "localhost"));
    attach_bios(&pair, 1024);
    handshake(&pair, TLS1_3_VERSION);
    return pair;
}

static void sibling_policy(char **arguments)
{
    TicketInput input;
    build_ticket(minimal, &input);
    PeerPair first = make_pair(arguments, TLS1_3_VERSION, 1024);
    TicketObservations first_observation = {}, second_observation = {};
    prepare(&first, &input, &first_observation);
    enable(first.client, 1);
    PeerPair second = make_sibling(&first);
    prepare(&second, &input, &second_observation);
    CHECK(!bssl::FromOpaque(second.client)->s3->discard_client_session_tickets);
    SSL_CTX_set_session_cache_mode(first.client_context, SSL_SESS_CACHE_CLIENT);
    SSL_CTX_sess_set_new_cb(first.client_context, new_session);
    enable(first.client, 1);
    enable(second.client, 0);
    test_clock.active = &first_observation;
    uwz_alloc_begin();
    CHECK(process_ticket(first.client, &input));
    uwz_alloc_end();
    const AllocationCounts discarded = counts();
    CHECK(zero_counts(&discarded));
    test_clock.active = &second_observation;
    uwz_alloc_begin();
    CHECK(process_ticket(second.client, &input));
    uwz_alloc_end();
    const AllocationCounts generic = counts();
    test_clock.active = nullptr;
    CHECK(first_observation.messages == 1 && first_observation.times == 0 && first_observation.sessions == 0);
    CHECK(second_observation.messages == 1 && second_observation.times == 1 && second_observation.sessions == 1);
    CHECK(generic.malloc_calls > 0 && second_observation.metadata_valid);
    puts("{\"case\":\"shared_ctx_sibling_isolation\",\"active_policy_survives_late_context_change\":true,"
         "\"sibling_keeps_generic_callback_and_time\":true,\"active_helper_heap_operations\":0}");
    destroy_pair(&first);
    destroy_pair(&second);
}

static void explicit_external_factory(char **arguments)
{
    TicketInput input;
    build_ticket(minimal, &input);
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    TicketObservations observation = {};
    prepare(&pair, &input, &observation);
    enable(pair.client, 1);
    uint8_t frame[66004];
    frame[0] = SSL3_MT_NEWSESSION_TICKET;
    frame[1] = (input.length >> 16) & 255;
    frame[2] = (input.length >> 8) & 255;
    frame[3] = input.length & 255;
    memcpy(frame + 4, input.body, input.length);
    SSL_SESSION *established = SSL_get_session(pair.client);
    test_clock.active = &observation;
    uwz_alloc_begin();
    SSL_SESSION *created = SSL_process_tls13_new_session_ticket(pair.client, frame, input.length + 4);
    uwz_alloc_end();
    const AllocationCounts measured = counts();
    test_clock.active = nullptr;
    CHECK(created && metadata_valid(bssl::FromOpaque(created), &observation));
    CHECK(observation.times == 1 && observation.sessions == 0 && observation.messages == 0);
    CHECK(measured.malloc_calls > 0 && SSL_get_session(pair.client) == established);
    CHECK(bssl::FromOpaque(pair.client)->s3->discard_client_session_tickets);
    SSL_SESSION_free(created);
    puts("{\"case\":\"explicit_external_ticket_factory\",\"ordinary_reader_policy_still_active\":true,"
         "\"explicit_factory_remains_generic_and_allocating\":true,\"time_calls\":1,"
         "\"established_getter_unchanged\":true,\"synthetic_ticket_not_resumption_proof\":true}");
    destroy_pair(&pair);
}
#endif

int main(int argc, char **argv)
{
    CHECK(argc == 4);
    CHECK(uwz_alloc_self_test());
    OPENSSL_PUT_ERROR(SSL, SSL_R_DECODE_ERROR);
    ERR_clear_error();
    const int lifetime_index = SSL_SESSION_get_ex_new_index(0, nullptr, nullptr, nullptr, session_freed);
    CHECK(lifetime_index >= 0);
    const uint16_t suites[] = {0x1301, 0x1302, 0x1303};
    for (uint16_t suite : suites) {
        ownership(argv, suite, false, lifetime_index);
        ownership(argv, suite, true, lifetime_index);
    }
#if TICKET_DISCARD_API
    const long modes[] = {SSL_SESS_CACHE_OFF, SSL_SESS_CACHE_SERVER, SSL_SESS_CACHE_CLIENT, SSL_SESS_CACHE_BOTH};
    for (long mode : modes) {
        initial_policy(argv, mode, false);
        initial_policy(argv, mode, true);
    }
    session_context_policy(argv, true);
    session_context_policy(argv, false);
    sibling_policy(argv);
    explicit_external_factory(argv);
#endif
    puts("PASS: generic callback ownership; candidate cache/context/external-factory policy contracts when enabled; self-test63");
}
