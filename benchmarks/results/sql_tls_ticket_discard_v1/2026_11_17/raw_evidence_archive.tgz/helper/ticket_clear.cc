#include "ticket_pair.h"
#include "ticket_fault.h"

static void exchange(SSL *sender, SSL *receiver)
{
    const uint8_t input[] = {1,3,5,7,9,11,13,15,17};
    uint8_t output[sizeof(input)];
    CHECK(SSL_write(sender, input, sizeof(input)) == static_cast<int>(sizeof(input)));
    CHECK(SSL_read(receiver, output, sizeof(output)) == static_cast<int>(sizeof(output)));
    CHECK(memcmp(input, output, sizeof(input)) == 0);
}

static void clear_case(char **arguments, bool destructive)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    CHECK(SSL_discard_client_session_tickets(pair.client));
    auto *ssl = bssl::FromOpaque(pair.client);
    auto *original_state = ssl->s3;
    SSL_SESSION *established = SSL_get_session(pair.client);
    if (!destructive) {
        // Public shedding makes the existing SSL_clear preflight fail.
        SSL_set_shed_handshake_config(pair.client, 1);
        SSL_set_renegotiate_mode(pair.client, ssl_renegotiate_never);
        CHECK(!ssl->config);
    }
    ticket_fault_reset();
    ticket_fault_watch(original_state, sizeof(*original_state));
    ticket_fault_arm_ordinal(1);
    CHECK(SSL_clear(pair.client) == 0);
    ticket_fault_disarm();
    const TicketFaultStats measured = ticket_fault_read();
    CHECK(measured.watched == 1 && measured.successful == 0);
    CHECK(measured.cleanse_failures == 0);
    if (destructive) {
        // Baseline clear frees old S3 before attempting its replacement.
        CHECK(ssl->s3 == nullptr);
        CHECK(measured.attempts == 1 && measured.injected == 1);
        CHECK(measured.live == 0 && measured.actual_frees == 1);
    } else {
        CHECK(ssl->s3 == original_state && ssl->s3->discard_client_session_tickets);
        CHECK(SSL_get_session(pair.client) == established);
        CHECK(measured.attempts == 0 && measured.injected == 0);
        CHECK(measured.live == 1 && measured.actual_frees == 0);
        exchange(pair.client, pair.server);
        exchange(pair.server, pair.client);
        CHECK(ssl->s3 == original_state && ssl->s3->discard_client_session_tickets);
    }
    destroy_pair(&pair);
    const TicketFaultStats final = ticket_fault_read();
    CHECK(final.live == 0 && final.actual_frees == 1 && final.cleanse_failures == 0);
    CHECK(final.calloc_calls == 0 && final.realloc_calls == 0);
    printf("{\"case\":\"%s\",\"scope\":\"public_clear_default_glibc_watched_s3\","
        "\"sizeof_s3\":%zu,\"watched_raw_bytes\":%zu,\"attempts\":%llu,\"injected\":%llu,"
        "\"watched_owners\":1,\"watched_actual_frees\":1,\"watched_cleanse_failures\":0,"
        "\"live\":0,\"old_connection_preserved\":%s,\"replacement_s3_absent\":%s}\n",
        destructive ? "clear_replacement_oom_destroys_old_state" : "clear_preflight_preserves_live_state",
        sizeof(bssl::SSL3_STATE), sizeof(bssl::SSL3_STATE) + 8,
        static_cast<unsigned long long>(final.attempts), static_cast<unsigned long long>(final.injected),
        destructive ? "false" : "true", destructive ? "true" : "false");
    ERR_clear_error();
}

int main(int argc, char **argv)
{
    CHECK(argc == 4);
    OPENSSL_PUT_ERROR(SSL, SSL_R_DECODE_ERROR);
    ERR_clear_error();
    clear_case(argv, false);
    clear_case(argv, true);
    puts("PASS: preserving clear preflight and destructive replacement OOM; watched S3 erased/freed exactly once");
}
