#ifndef UWZ_TICKET_OBSERVE_H
#define UWZ_TICKET_OBSERVE_H
#include "ticket_vectors.h"
#include <openssl/sha.h>

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

struct AllocationCounts {
    uint64_t malloc_calls;
    uint64_t calloc_calls;
    uint64_t realloc_calls;
    uint64_t free_calls;
    uint64_t bytes;
};

struct SessionLifetime {
    size_t frees;
};

struct TicketObservations {
    const TicketInput *expected;
    SessionLifetime *lifetime;
    SSL_SESSION *retained;
    int lifetime_index;
    bool take_ownership;
    bool metadata_valid;
    size_t messages;
    size_t times;
    size_t sessions;
    size_t alerts;
    uint8_t alert_level;
    uint8_t alert_description;
    uint32_t base_timeout;
    char events[32];
    uint32_t event_errors[32];
    size_t event_count;
};

struct TestClock {
    TicketObservations *active;
    uint64_t seconds;
};

// The pinned time callback has no userdata; one fixture OS thread owns routing.
static thread_local TestClock test_clock = {};

static uint32_t error_code(uint32_t value)
{
    return (static_cast<uint32_t>(ERR_GET_LIB(value)) << 24) | ERR_GET_REASON(value);
}

static void event(TicketObservations *observation, char kind)
{
    CHECK(observation->event_count < 31);
    observation->events[observation->event_count] = kind;
    observation->event_errors[observation->event_count] = error_code(ERR_peek_last_error());
    observation->events[++observation->event_count] = 0;
}

static void current_time(const SSL *ssl, struct timeval *clock)
{
    CHECK(ssl == nullptr);
    clock->tv_sec = static_cast<time_t>(test_clock.seconds);
    clock->tv_usec = 0;
    if (!test_clock.active) return;
    test_clock.active->times++;
    event(test_clock.active, 'T');
}

static void message(int writing, int version, int type, const void *bytes,
                     size_t length, SSL *ssl, void *argument)
{
    (void)version;
    (void)ssl;
    auto *observation = static_cast<TicketObservations *>(argument);
    const uint8_t *data = static_cast<const uint8_t *>(bytes);
    if (!writing && type == SSL3_RT_HANDSHAKE && length >= 4 &&
        data[0] == SSL3_MT_NEWSESSION_TICKET) {
        observation->messages++;
        event(observation, 'M');
    }
    if (writing && type == SSL3_RT_ALERT && length == 2) {
        observation->alerts++;
        observation->alert_level = data[0];
        observation->alert_description = data[1];
        event(observation, 'A');
    }
}

static bool metadata_valid(const bssl::SSLSession *session, const TicketObservations *observation)
{
    if (!observation->expected) return true;
    const TicketInput *input = observation->expected;
    uint8_t digest[SHA256_DIGEST_LENGTH];
    CHECK(SHA256(input->body + input->ticket_offset, input->ticket_length, digest));
    const uint32_t rebased = observation->base_timeout ? observation->base_timeout - 1 : 0;
    const uint32_t expected_timeout = std::min(rebased, input->lifetime);
    const bool valid = session->ticket_age_add == input->age_add &&
        session->ticket.size() == input->ticket_length &&
        memcmp(session->ticket.data(), input->body + input->ticket_offset, input->ticket_length) == 0 &&
        session->timeout == expected_timeout && session->ticket_max_early_data == input->early_data &&
        session->is_resumable_across_names == input->across_names &&
        session->session_id.size() == sizeof(digest) &&
        memcmp(session->session_id.data(), digest, sizeof(digest)) == 0 &&
        session->ticket_age_add_valid && !session->not_resumable;
    if (!valid) fprintf(stderr,
        "metadata: age=%u/%u ticket=%zu/%zu timeout=%u/%u early=%u/%u names=%u/%u idlen=%zu hashok=%u agevalid=%u notresumable=%u\n",
        session->ticket_age_add, input->age_add, session->ticket.size(), input->ticket_length,
        session->timeout, expected_timeout, session->ticket_max_early_data, input->early_data,
        session->is_resumable_across_names, input->across_names, session->session_id.size(),
        session->session_id.size() == sizeof(digest) && memcmp(session->session_id.data(), digest, sizeof(digest)) == 0,
        session->ticket_age_add_valid, session->not_resumable);
    return valid;
}

static int new_session(SSL *ssl, SSL_SESSION *session)
{
    auto *observation = static_cast<TicketObservations *>(SSL_get_app_data(ssl));
    CHECK(observation);
    observation->sessions++;
    event(observation, 'N');
    observation->metadata_valid = metadata_valid(bssl::FromOpaque(session), observation);
    CHECK(observation->metadata_valid);
    if (observation->lifetime) {
        CHECK(SSL_SESSION_set_ex_data(session, observation->lifetime_index, observation->lifetime));
    }
    if (observation->take_ownership) observation->retained = session;
    return observation->take_ownership;
}

static AllocationCounts counts(void)
{
    return {uwz_alloc_malloc_calls(), uwz_alloc_calloc_calls(),
        uwz_alloc_realloc_calls(), uwz_alloc_free_calls(), uwz_alloc_requested_bytes()};
}

static bool zero_counts(const AllocationCounts *value)
{
    return value->malloc_calls == 0 && value->calloc_calls == 0 && value->realloc_calls == 0 &&
        value->free_calls == 0 && value->bytes == 0;
}

static void prepare(PeerPair *pair, const TicketInput *input, TicketObservations *observation)
{
    CHECK(SSL_reserve_record_buffers(pair->client));
    CHECK(SSL_reserve_client_post_handshake_buffer(pair->client));
    CHECK(SSL_reserve_key_update_context(pair->client));
    CHECK(SSL_reserve_key_update_output_buffers(pair->client));
    observation->expected = input;
    observation->base_timeout = SSL_SESSION_get_timeout(SSL_get_session(pair->client));
    test_clock.seconds = SSL_SESSION_get_time(SSL_get_session(pair->client)) + 1;
    SSL_CTX_set_current_time_cb(pair->client_context, current_time);
    SSL_set_msg_callback(pair->client, message);
    SSL_set_msg_callback_arg(pair->client, observation);
    CHECK(SSL_set_app_data(pair->client, observation));
}

static bool process_ticket(SSL *ssl, const TicketInput *input)
{
    uint8_t framed[66004];
    framed[0] = SSL3_MT_NEWSESSION_TICKET;
    framed[1] = (input->length >> 16) & 255;
    framed[2] = (input->length >> 8) & 255;
    framed[3] = input->length & 255;
    memcpy(framed + 4, input->body, input->length);
    auto *implementation = bssl::FromOpaque(ssl);
    CHECK(bssl::tls_append_handshake_data(implementation,
        bssl::Span(framed).first(input->length + 4)));
    bssl::SSLMessage parsed;
    CHECK(bssl::tls_get_message(implementation, &parsed));
    const bool result = bssl::tls13_process_new_session_ticket(implementation, parsed);
    bssl::tls_next_message(implementation);
    return result;
}

#endif
