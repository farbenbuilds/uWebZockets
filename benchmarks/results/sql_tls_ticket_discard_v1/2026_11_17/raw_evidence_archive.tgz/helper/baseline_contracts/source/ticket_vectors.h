#ifndef UWZ_TICKET_VECTORS_H
#define UWZ_TICKET_VECTORS_H
#include "ticket_pair.h"

enum VectorId {
    minimal, lifetime_zero, max_fields, max_ticket, max_extensions, early_valid,
    early_max, flags_across_names, flags_unknown_high, unknown_duplicates, copied_absent,
    short_lifetime, short_age, missing_nonce_length, truncated_nonce, truncated_ticket_length,
    empty_ticket, truncated_ticket, truncated_extensions_length, truncated_extensions,
    trailing_body, truncated_extension_header, truncated_extension_value, duplicate_early,
    duplicate_flags, empty_early, short_early, long_early, empty_flags, zero_flags,
    short_flags, extra_flags, trailing_zero_flags, early_bad_later_duplicate,
    flags_bad_later_truncation, early_bad_flags_bad, flags_bad_early_bad,
};

struct VectorSpec {
    const char *name;
    VectorId id;
    bool valid;
};

static constexpr VectorSpec vector_specs[] = {
    {"minimal", minimal, true}, {"lifetime_zero", lifetime_zero, true},
    {"max_fields", max_fields, true}, {"max_ticket", max_ticket, true},
    {"max_extensions", max_extensions, true}, {"early_valid", early_valid, true},
    {"early_max", early_max, true}, {"flags_across_names", flags_across_names, true},
    {"flags_unknown_high", flags_unknown_high, true}, {"unknown_duplicates", unknown_duplicates, true},
    {"copied_absent", copied_absent, true}, {"short_lifetime", short_lifetime, false},
    {"short_age", short_age, false}, {"missing_nonce_length", missing_nonce_length, false},
    {"truncated_nonce", truncated_nonce, false}, {"truncated_ticket_length", truncated_ticket_length, false},
    {"empty_ticket", empty_ticket, false}, {"truncated_ticket", truncated_ticket, false},
    {"truncated_extensions_length", truncated_extensions_length, false},
    {"truncated_extensions", truncated_extensions, false}, {"trailing_body", trailing_body, false},
    {"truncated_extension_header", truncated_extension_header, false},
    {"truncated_extension_value", truncated_extension_value, false},
    {"duplicate_early", duplicate_early, false}, {"duplicate_flags", duplicate_flags, false},
    {"empty_early", empty_early, false}, {"short_early", short_early, false},
    {"long_early", long_early, false}, {"empty_flags", empty_flags, false},
    {"zero_flags", zero_flags, false}, {"short_flags", short_flags, false},
    {"extra_flags", extra_flags, false}, {"trailing_zero_flags", trailing_zero_flags, false},
    {"early_bad_later_duplicate", early_bad_later_duplicate, false},
    {"flags_bad_later_truncation", flags_bad_later_truncation, false},
    {"early_bad_flags_bad", early_bad_flags_bad, false}, {"flags_bad_early_bad", flags_bad_early_bad, false},
};

struct ByteWriter {
    uint8_t *bytes;
    size_t length;
    size_t capacity;
};

struct TicketInput {
    uint8_t body[66000];
    size_t length;
    size_t ticket_offset;
    size_t ticket_length;
    uint32_t lifetime;
    uint32_t age_add;
    uint32_t early_data;
    bool across_names;
    bool seeded_base_metadata;
};

static void put_byte(ByteWriter *writer, uint8_t value)
{
    CHECK(writer->length < writer->capacity);
    writer->bytes[writer->length++] = value;
}

static void put_u16(ByteWriter *writer, size_t value)
{
    CHECK(value <= 65535);
    put_byte(writer, value >> 8);
    put_byte(writer, value & 255);
}

static void put_u32(ByteWriter *writer, uint32_t value)
{
    put_byte(writer, value >> 24);
    put_byte(writer, (value >> 16) & 255);
    put_byte(writer, (value >> 8) & 255);
    put_byte(writer, value & 255);
}

static void put_bytes(ByteWriter *writer, const uint8_t *bytes, size_t length)
{
    CHECK(length <= writer->capacity - writer->length);
    if (length) memcpy(writer->bytes + writer->length, bytes, length);
    writer->length += length;
}

static void extension(ByteWriter *writer, uint16_t type, const uint8_t *bytes, size_t length)
{
    put_u16(writer, type);
    put_u16(writer, length);
    put_bytes(writer, bytes, length);
}

static size_t build_extensions(VectorId id, uint8_t *output)
{
    ByteWriter writer = {output, 0, 65535};
    const uint8_t early[] = {0, 0, 4, 0, 9};
    const uint8_t maximum[] = {255, 255, 255, 255};
    const uint8_t flags[] = {2, 0, 1};
    const uint8_t unknown[] = {5, 0, 0, 0, 0, 1};
    const uint8_t zero[] = {1, 0};
    const uint8_t no_flags[] = {0};
    const uint8_t extra[] = {1, 1, 1};
    switch (id) {
        case early_valid: extension(&writer, TLSEXT_TYPE_early_data, early, 4); break;
        case early_max: extension(&writer, TLSEXT_TYPE_early_data, maximum, 4); break;
        case flags_across_names: extension(&writer, TLSEXT_TYPE_tls_flags, flags, sizeof(flags)); break;
        case flags_unknown_high: extension(&writer, TLSEXT_TYPE_tls_flags, unknown, sizeof(unknown)); break;
        case unknown_duplicates:
            extension(&writer, 0xface, nullptr, 0);
            extension(&writer, 0xface, early, 3);
            break;
        case max_extensions:
            put_u16(&writer, 0xface);
            put_u16(&writer, 65531);
            memset(output + writer.length, 0x7c, 65531);
            writer.length += 65531;
            break;
        case truncated_extension_header: put_bytes(&writer, early, 3); break;
        case truncated_extension_value:
            put_u16(&writer, TLSEXT_TYPE_early_data);
            put_u16(&writer, 4);
            break;
        case duplicate_early:
            extension(&writer, TLSEXT_TYPE_early_data, early, 4);
            extension(&writer, TLSEXT_TYPE_early_data, early, 4);
            break;
        case duplicate_flags:
            extension(&writer, TLSEXT_TYPE_tls_flags, flags, sizeof(flags));
            extension(&writer, TLSEXT_TYPE_tls_flags, flags, sizeof(flags));
            break;
        case empty_early: extension(&writer, TLSEXT_TYPE_early_data, nullptr, 0); break;
        case short_early: extension(&writer, TLSEXT_TYPE_early_data, early, 3); break;
        case long_early: extension(&writer, TLSEXT_TYPE_early_data, early, 5); break;
        case empty_flags: extension(&writer, TLSEXT_TYPE_tls_flags, nullptr, 0); break;
        case zero_flags: extension(&writer, TLSEXT_TYPE_tls_flags, no_flags, sizeof(no_flags)); break;
        case short_flags: extension(&writer, TLSEXT_TYPE_tls_flags, flags, 2); break;
        case extra_flags: extension(&writer, TLSEXT_TYPE_tls_flags, extra, sizeof(extra)); break;
        case trailing_zero_flags: extension(&writer, TLSEXT_TYPE_tls_flags, zero, sizeof(zero)); break;
        case early_bad_later_duplicate:
            extension(&writer, TLSEXT_TYPE_early_data, early, 3);
            extension(&writer, TLSEXT_TYPE_tls_flags, flags, sizeof(flags));
            extension(&writer, TLSEXT_TYPE_tls_flags, flags, sizeof(flags));
            break;
        case flags_bad_later_truncation:
            extension(&writer, TLSEXT_TYPE_tls_flags, nullptr, 0);
            put_bytes(&writer, early, 3);
            break;
        case early_bad_flags_bad:
            extension(&writer, TLSEXT_TYPE_early_data, early, 3);
            extension(&writer, TLSEXT_TYPE_tls_flags, zero, sizeof(zero));
            break;
        case flags_bad_early_bad:
            extension(&writer, TLSEXT_TYPE_tls_flags, zero, sizeof(zero));
            extension(&writer, TLSEXT_TYPE_early_data, early, 3);
            break;
        default: break;
    }
    return writer.length;
}

static void build_ticket(VectorId id, TicketInput *result)
{
    memset(result, 0, sizeof(*result));
    result->lifetime = id == lifetime_zero ? 0 : 2400;
    result->age_add = 0x12345678;
    if (id == max_fields || id == max_ticket) {
        result->lifetime = result->age_add = UINT32_MAX;
    }
    result->early_data = id == early_valid ? 1024 : (id == early_max ? UINT32_MAX : 0);
    // This pin copies the early-data allowance, but not the names flag.
    result->across_names = id == flags_across_names;
    result->seeded_base_metadata = id == copied_absent;
    if (result->seeded_base_metadata) result->early_data = 1234;
    const size_t nonce_length = id == max_fields || id == max_ticket ? 255 : 0;
    const size_t ticket_length = id == max_ticket ? 65535 : (id == max_fields ? 257 : 1);
    ByteWriter writer = {result->body, 0, sizeof(result->body)};
    put_u32(&writer, result->lifetime);
    put_u32(&writer, result->age_add);
    put_byte(&writer, nonce_length);
    for (size_t index = 0; index < nonce_length; index++) put_byte(&writer, index * 3);
    put_u16(&writer, id == empty_ticket ? 0 : ticket_length);
    result->ticket_offset = writer.length;
    result->ticket_length = id == empty_ticket ? 0 : ticket_length;
    for (size_t index = 0; index < result->ticket_length; index++) put_byte(&writer, index * 19 + 7);
    uint8_t extensions[65535];
    const size_t extension_length = build_extensions(id, extensions);
    const size_t vector_offset = writer.length;
    put_u16(&writer, extension_length);
    put_bytes(&writer, extensions, extension_length);
    switch (id) {
        case short_lifetime: writer.length = 3; break;
        case short_age: writer.length = 7; break;
        case missing_nonce_length: writer.length = 8; break;
        case truncated_nonce: result->body[8] = 255; writer.length = 9; break;
        case truncated_ticket_length: writer.length = 10; break;
        case truncated_ticket:
            result->body[9] = 0;
            result->body[10] = 2;
            writer.length = 12;
            break;
        case truncated_extensions_length: writer.length = vector_offset + 1; break;
        case truncated_extensions:
            result->body[vector_offset] = 0;
            result->body[vector_offset + 1] = 4;
            break;
        case trailing_body: put_byte(&writer, 9); break;
        default: break;
    }
    result->length = writer.length;
}

#endif
