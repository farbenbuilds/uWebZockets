#!/usr/bin/env python3
"""Check generic compatibility and shared validation/error ordering for ticket discard."""
import argparse
import hashlib
import json
from pathlib import Path


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline_generic', type=Path)
    parser.add_argument('candidate_generic', type=Path)
    parser.add_argument('candidate_discard', type=Path)
    args = parser.parse_args()
    baseline, generic, discard = [rows(path) for path in
        [args.baseline_generic, args.candidate_generic, args.candidate_discard]]
    assert len(baseline) == len(generic) == len(discard) == 37
    assert baseline == generic, 'Generic result/metadata/allocator/error/event parity changed'
    semantic = ('case', 'valid', 'result', 'body_bytes', 'messages', 'alerts',
                'alert_level', 'alert_description', 'errors', 'established_getters_unchanged')
    valid = 0
    for before, after in zip(baseline, discard):
        assert {key: before[key] for key in semantic} == {key: after[key] for key in semantic}, before['case']
        assert after['discard'] is True and after['times'] == after['sessions'] == 0
        indices = [index for index, kind in enumerate(before['events']) if kind not in 'TN']
        assert ''.join(before['events'][index] for index in indices) == after['events']
        assert [before['event_errors'][index] for index in indices] == after['event_errors']
        if not before['valid']:
            continue
        valid += 1
        assert before['malloc'] > 0 and before['metadata_valid']
        assert all(after[key] == 0 for key in ['malloc', 'calloc', 'realloc', 'free', 'bytes'])
    assert valid == 11
    priority_names = ('early_bad_later_duplicate', 'flags_bad_later_truncation',
        'early_bad_flags_bad', 'flags_bad_early_bad')
    assert all(any(row['case'] == name and not row['valid'] for row in baseline) for name in priority_names)
    print(json.dumps({'vectors': 37, 'valid': valid, 'malformed': 37 - valid,
        'generic_exact_parity': True, 'discard_validation_error_alert_observation_parity': True,
        'combined_invalid_precedence_vectors': list(priority_names),
        'discard_valid_helper_heap_operations': 0,
        'discard_ticket_session_or_time_callbacks': 0,
        'synthetic_inputs_resumption_claimed': False,
        'input_sha256': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in
            [args.baseline_generic, args.candidate_generic, args.candidate_discard]}}, indent=2))


if __name__ == '__main__':
    main()
