#ifndef UWZ_TICKET_FAULT_H
#define UWZ_TICKET_FAULT_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

struct TicketFaultStats {
    uint64_t attempts;
    uint64_t matches;
    uint64_t successful;
    uint64_t injected;
    uint64_t watched;
    uint64_t live;
    uint64_t actual_frees;
    uint64_t cleanse_failures;
    uint64_t calloc_calls;
    uint64_t realloc_calls;
    uint64_t requested_bytes;
    size_t first_uncleansed_size;
    uintptr_t first_uncleansed_site;
};

void ticket_fault_reset(void);
void ticket_fault_arm_ordinal(size_t ordinal);
void ticket_fault_arm_size(size_t size);
void ticket_fault_disarm(void);
void ticket_fault_watch(void *openssl_pointer, size_t payload_size);
struct TicketFaultStats ticket_fault_read(void);

#ifdef __cplusplus
}
#endif
#endif
