# Validated client ticket discard: direct and inherited evidence

This frozen payload contains bounded native Debug (`-O0 -g`) functional evidence. It does not close the strict PostgreSQL gate or authorize a production pin/fork change. Dedicated smoke, security, sanitizer, fuzz and scan campaigns were deferred by the user. No native or repository source was edited by this verifier.

Candidate complete native build: `/home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-ticket-discard-fixed-20261117`, source patch `e1e858e8` (author owns full provenance). SSL archive SHA256 `b9891425c059d826fd83a3335fe72207d73cebe992521ca6df473aaba0bfe88f`; crypto `0d5945f932ce7620c2c4d431ce1cf85db95900ef134e84d88d2d088f960feaa9`. Baseline is the immutable prior output-buffer candidate `/tmp/uwz-pg-tls-ku-output-fixed-20261117`; SSL `d31754ee7e9275161863588c10433c5c6ace99dc9ab44040072d73c2c7c514bf`; crypto `b77e5b0e23987f8d8bdb29e84eb156e9f1d46ba4a8dd7a592cd3bde9823e522b`. Every included source-build directory records exact commands, statuses, archive/source hashes and raw stdout/stderr.

## Accepted new evidence

- `baseline_direct_final` and `candidate_direct_final`: 37 fixed helper vectors, 11 valid and 26 malformed, including four combined-invalid precedence cases. Generic return values, metadata, allocation/free counts, message/time/session/alert event order and exact error queues match baseline. Discard preserves validation/alert/message behavior and skips ticket-session/time callbacks; all 11 valid discard helper calls have zero heap operations. `direct_differential.json` records the accepted comparison. Binary/opaque ticket bytes here prove syntax and ownership only, not peer resumability.
- `baseline_contracts_final` and `candidate_contracts_final`: six generic callback return0/1 ownership rows across actual negotiated 0x1301/0x1302/0x1303 match exactly. Callback return0 native release and return1 caller-owned release each trigger the session ex-data lifetime marker exactly once. Retained callback/get1 references survive SSL and CTX destruction; established getters stay unchanged. Twelve candidate policy rows cover cache0/2 acceptance, CLIENT/BOTH/callback rejection, original session_ctx guards after SSL_set_SSL_CTX, later shared-CTX changes, sibling isolation, and the explicitly generic public external-ticket factory.
- `baseline_oom_final` and `candidate_oom_final`: three generic-factory failure-order cases match exactly: session-duplicate OOM before malformed prefix; ticket-copy OOM before malformed outer vector; malformed prefix before ticket-copy attempt. Error/alert queues and time order remain exact. All observer-tracked malloc owners are actually freed. A raw 16-byte ERR saved-state allocation is reported as an unwatched nonzero free, not claimed to have an OpenSSL erasure contract.
- `candidate_lifecycle_final`: 20 eligibility/lifecycle cases pass, including idempotence, already-enabled pending plaintext, real pending plaintext/partial record/backpressured write and continuation, queued KeyUpdate/native pending-flight rejection, healthy bidirectional traffic, null/unfinished/server/TLS1.2, configured-only DTLS/QUIC, public shutdown/fatal saved-error rejection, successful clear plus fresh CA/name-verified nonresumed handshake and update traffic, and sibling isolation. The native tls_flush pending-flight case is explicitly internal scope; it does not fabricate TLS peer traffic. Snapshots of actual traffic secrets and key contexts are caller-owned and explicitly cleansed.
- `candidate_clear_final`: two public clear boundaries pass. Public handshake-config shedding causes preflight clear failure, preserving the original live S3, flag, established getter and bidirectional traffic. Replacement S3 allocation OOM occurs after old S3 destruction and leaves S3 null; the connection is closed safely. This preserves baseline destructive-clear behavior rather than asserting whole-operation rollback. Each positively watched default-glibc/OpenSSL-prefixed S3 payload640/raw648 bytes is fully erased and actually freed exactly once.

Valid initial enable and idle repeat each perform zero malloc/calloc/realloc/free/requested bytes with the unchanged original all-C observer. `sizeof(SSL3_STATE)` is measured640 in both baseline and candidate; no startup allocation or state-size increase is inferred from estimates. Original counter SHA256 `afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac`, self-test63 requested bytes, remains byte-identical.

## Inherited evidence

`regressions/source_preservation.json` proves byte-identical prior source/runtime inputs, all rebuilt against the exact new complete archives. Accepted outcomes: output bounds/encoding/erasure helpers plus3 sealer failures and23 lifecycle cases; AEAD24 fresh/reused epochs,12 populated-initializer failures,48 transitions and22 lifecycle cases; handshake-buffer64 fragment loops plus21 lifecycle cases; record16 lifecycle cases plus buffer/pair witnesses; HKDF1440 cases (700 successful zero-heap and740 rejected, baseline semantic/error parity). HKDF rejected paths carry no universal zero-allocation claim. No prior encrypted wire matrix was duplicated here; the separate wire owner retains actual ticket export/resumption and encrypted protocol evidence.

## Replaying without a compiler

From either the standalone helper directory or a combined evidence tree:

```sh
python3 /ABS/helper/replay_prebuilt.py --pki-tool /ABS/wt-tools --output /ABS/ABSENT_EXTERNAL
python3 /ABS/helper/check_replay_guards.py --pki-tool /ABS/wt-tools --output /ABS/ANOTHER_ABSENT_EXTERNAL
```

The PKI helper SHA256 must be `531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9`. Output must be absent and outside the protected evidence tree. When both parent `restore_pki_tool.py` and `native/HANDOFF.md` exist, the whole combined root is excluded; standalone layouts exclude the helper tree only. The9-case guard proof uses the valid helper so helper errors cannot mask scope rejection. Replay checks the exact21-binary inventory/hashes before execution, compares deterministic stdout with retained originals, reruns semantic comparisons, generates fresh owned PKI and removes only its three expected files in finally. Native source, archives and a compiler are not required. `prebuilt_replay/results.json` and `replay_guards/results.json` retain successful execution and cleanup evidence.

`prebuilt_identity.json` describes delivery binaries; `measured_debug_identity.json` preserves original measured unstripped Debug identities. The parent may strip delivery debug using its separate GNU objcopy/ELF proof and update delivery identities only. Preserve measured identities. The frozen allowlist excludes objects, native archives, caches, PKI, cores, layout-only executables and preliminary duplicate binaries.

## Preliminary fixture corrections

All failed preliminary source/logs, commands, classifications and omitted executable identities are retained. They are not accepted green evidence:

1. `copied_absent` initially expected a seeded names flag to be copied. Exact baseline `SSL_SESSION_dup` copies the early-data limit but does not copy the names flag; the constructor defaults it false. The corrected absent-extension expectation is early1234/namesfalse. The encoded known-flags true vector and every semantic/error assertion remain.
2. The baseline-only callback build exposed an unused helper with `-Werror`. The final fixture explicitly asserts generic ticket construction allocates, preserving warning gates and the intended generic-path evidence.
3. The OOM observer initially demanded erasure of every C allocation. The diagnostic code address maps to baseline `bssl::ERR_SAVE_STATE_free`, `crypto/err/err.cc:765`, raw malloc/free16-byte storage outside OPENSSL_free. Final observation keeps raw malloc/free/fault accounting, reports unwatched nonzero frees, and requires erasure only on positively watched OpenSSL-prefixed S3 owners. No native source or ordinary zero gate changed.

The clear runner initially inherited an OOM scope-description string; its provenance retains an explicit scope-annotation correction, without changing the measured source/archive identities or results. `orchestration_notes.json` records two rejected driver CLI invocations and their corrected accepted forms.
