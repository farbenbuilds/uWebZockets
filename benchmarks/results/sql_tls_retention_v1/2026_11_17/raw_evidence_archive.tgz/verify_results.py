#!/usr/bin/env python3
"""Check the exact accounting contract and sample outcomes for this experiment."""
import csv
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
fields = ("malloc_calls", "calloc_calls", "realloc_calls", "free_calls", "requested_bytes")
summary = {}
for experiment in ("baseline_rerun", "prototype_off", "prototype_on"):
    directory = root / experiment
    statuses = json.loads((directory / "run-status.json").read_text())
    summary[experiment] = {}
    for mode in ("plaintext", "tls"):
        status = statuses[mode]
        assert status["exit_code"] == 0
        assert status["interposer_self_test"] == "PASS"
        log = (directory / (mode + ".stdout.log")).read_text()
        assert re.search(r"^samples=256 errors=0 duration_ns=\d+$", log, re.M)
        rows = list(csv.DictReader((directory / (mode + ".csv")).open()))
        assert len(rows) == 256
        assert [int(row["sample"]) for row in rows] == list(range(256))
        expected = (0, 0, 0, 0, 0)
        if mode == "tls" and experiment != "prototype_on":
            expected = (2, 0, 0, 2, 213)
        observed = {tuple(int(row[key]) for key in fields) for row in rows}
        assert observed == {expected}, (experiment, mode, observed)
        summary[experiment][mode] = {
            "queries": 256, "query_errors": 0,
            "every_query": dict(zip(fields, expected)),
            "totals": {key: sum(int(row[key]) for row in rows) for key in fields},
        }
assert (root / "buffer-test.log").read_text().startswith("PASS:")
assert (root / "tls-pair-test.log").read_text().startswith("PASS:")
summary["scope"] = "ordinary cached-query and record-buffer functional prototype only"
summary["production_strict_postgresql_gate"] = "NOT CLOSED; prototype not integrated and other post-handshake paths not proven"
(root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print("PASS: three 256-query plaintext/TLS comparisons, exact allocator self-test/accounting, buffer lifecycle and verified TLS BIO-pair functional proof")
