# Isolated record-buffer retention prototype

Baseline is the exact BoringSSL package for d3bf4795ad5b79d646cddf2fec687da5b9b502db,
not the different protected vendor checkout. No production source, pin, or build
graph changes are authorized here.

Add an explicitly opt-in native API, SSL_reserve_record_buffers. Accept only an
idle, completed, non-QUIC TLS 1.3 connection with no pending plaintext or write.
Allocate the existing SSLBuffer maximum, 65528 usable bytes plus seven alignment
bytes, for each direction before PostgreSQL startup. Total reservation is 131070
bytes per connection. Existing write calls can coalesce a pending handshake
flight and an application record; reserving only one application record would
introduce a smaller bound than the existing implementation.

Reserved buffers keep their allocation through Clear/DiscardConsumed and recover
their full capacity after consumed prefixes. EnsureCap may compact within the
fixed reservation, never allocate or grow. Cleanse discarded occupied bytes and
the full reservation before its actual free at SSL destruction. SSL_clear keeps
its existing destruction/recreation behavior and therefore drops the opt-in.
Reservation failure is a startup failure and requires the caller to free SSL.

Functional proof reuses the committed PostgreSQL allocation probe and its exact
glibc malloc/calloc/realloc/non-null-free accounting, including the 63-byte
self-test. A temporary committed project snapshot invokes reservation only after
successful handshake and X509 verification, before startup/authentication and
worker readiness. No exception or empty deallocator is introduced.

The measured cached-query scope does not cover every TLS 1.3 post-handshake path;
session tickets, KeyUpdate, protocol errors, reconnection, fragmentation, and
pending-flight allocation remain separate questions. This experiment cannot
certify the production SQL gate. Security/sanitizer/fuzz campaigns are deferred
by the user; source inspection and ordinary functional allocation proof proceed.

Cross-model review skipped: non-interactive child task. Parent will independently
review the artifact and choose any production integration or maintained source
procedure. An external native API and additional per-connection ownership need
review before adoption.
