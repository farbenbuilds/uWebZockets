# PostgreSQL TLS fixed record-buffer reservation experiment

The isolated prototype eliminates the observed two malloc/two free calls for
the ordinary warmed PostgreSQL query. This is not a production allocation-gate
closure: no production code or dependency pin changed, and all post-handshake
processing has not been proven allocation-free.

## Source and ownership

The native baseline is the exact Zig package corresponding to BoringSSL
`d3bf4795ad5b79d646cddf2fec687da5b9b502db`. The protected vendor checkout is
different and was neither used nor changed. `candidate.patch` describes only
four temporary native files:

- `boringssl/include/openssl/ssl.h`: explicit opt-in external native API.
- `boringssl/ssl/internal.h`: retained-capacity state and unconditional release.
- `boringssl/ssl/ssl_buffer.cc`: fixed reserve/reset/compact/cleanse lifecycle.
- `boringssl/ssl/ssl_lib.cc`: idle, completed, non-QUIC TLS 1.3 API preconditions.

`project/` is an isolated committed-source snapshot. Its dependency paths point
to existing packages and the temporary native copy. Its only application code
change invokes reservation after successful handshake and X509 verification,
before PostgreSQL startup/authentication and readiness. `caller.patch` records
that illustrative temporary change. No fork was pushed.

## Functional result

All modes used one in-flight query, eight initialized connections, sixteen
warmups and 256 measured queries. The disposable PostgreSQL fixture uses its
own random loopback port, ephemeral CA/certificate and private credentials.
The existing database on port 55432 was untouched.

| Binary/configuration | TLS malloc/calloc/realloc/free per query | Requested bytes |
| --- | --- | --- |
| Exact archived audit binary rerun | 2 / 0 / 0 / 2 | 213 |
| New full native build; reservation disabled | 2 / 0 / 0 / 2 | 213 |
| Same native build; temporary caller enables reservation | 0 / 0 / 0 / 0 | 0 |

All 256 queries in each mode completed without query errors and passed the
probe's exact result checks: one row, ID equal to 1, and successful int4 decoding
of the second column. The second value was not compared with the fixture's 42.
These checks run after the allocation scope closes. Plaintext was zero in all
three comparisons. The query/accounting source is
unchanged from the archived audit. Its direct glibc forwarding, thread-local
scope and 63-byte malloc/calloc/realloc/free self-test are preserved exactly.
The interval begins before Db.query and ends at callback entry. Startup,
authentication, warming, result validation, logging and teardown remain outside
that interval. No allocator-family exception or empty free is used.

Additional ordinary functional evidence:

- `buffer-test.log`: 256 full-capacity loops with 31 header lengths, prefix
  compaction, content preservation, payload alignment, restored capacity,
  cleansed occupied bytes and zero measured allocator calls. A separate observer
  confirms all 65535 allocated bytes are zero immediately before the actual
  destructor free. The original upper bound plus one is rejected. Null and
  unfinished TLS connections cannot enable the external API.
- `tls-pair-test.log`: verified TLS 1.3 with localhost name checking, a 1024-byte
  BIO pair and 257-byte plaintext reads. Seven record lengths through 16384 bytes
  pass under backpressure with zero measured allocator calls. Four startup
  allocations request exactly 262140 bytes for the two SSL objects. SSL_clear
  drops the opt-in and a fresh unfinished connection cannot reserve again.

Both native libraries and the consumer were compiled with Zig 0.16.0 through
the existing native source-list build; all 38 SSL translation units were rebuilt.
Build logs record 18/18 successful consumer build steps. The standalone tests
link those exact native archives. `verify_results.py` validates all sample
counts, outcomes and expected per-query accounting and writes `summary.json`.

## Bounds and lifecycle

Each direction reserves 65528 usable bytes plus seven alignment bytes, for
131070 bytes per SSL connection, before worker readiness. This is the existing
EnsureCap limit, not a new larger bound. A single app-record-sized reservation
would be insufficient because a write can coalesce a pending handshake flight
and application record. Consume may reduce usable tail capacity; the retained
path compacts inside its fixed allocation and restores full capacity. Requests
above the original maximum fail as before. It never grows after reservation.

Clear/DiscardConsumed preserve allocation while cleansing discarded occupied
bytes. The destructor cleanses the full allocation before its real free.
SSL_clear keeps upstream's destroy/recreate lifecycle and resets reservation.
The API requires empty record buffers, no pending plaintext or write, and a
fully completed TLS 1.3 handshake. Reservation failure requires SSL_free rather
than continuing with a partial reservation. TLS verification, TLS version
policy, certificates, plaintext publication and BIO retry behavior are unchanged.

## Remaining work before any adoption

This is an external native API addition and a per-SSL buffer ownership change.
Review upstream/fork maintenance and dependency integration policy before any
production adoption. Rebuild every SSL translation unit together; do not swap a
single object against an unmodified internal layout. The memory tradeoff is
131070 reserved bytes per connection, in addition to existing BIO/application
buffers. Eight SQL connections reserve 1048560 bytes.

Record buffers are only the two observed allocation sites. Pending-flight
storage, tickets/session creation, KeyUpdate, error paths, reconnection and
other handshake processing can allocate separately. The PostgreSQL cached-query
case and a ticket-disabled BIO-pair record case do not prove those paths.
The fixture does not test production deployments, concurrent SSL use, all
fragmentation patterns or every certificate configuration.

The parent's independent read-only native review found no confirmed lifecycle
defect in the reviewed candidate and verified the original 47 manifest-listed
files and all 1536 measured CSV rows. Its wording correction is incorporated
above; the review message is retained in `INDEPENDENT_REVIEW.txt`. That review
does not establish the following untested adoption prerequisites:

- Failure of the first reservation allocation and failure of the second after
  the first succeeds, including required SSL_free cleanup.
- Rejection with pending plaintext, partially consumed input, or pending write.
- Runtime rejection of excluded protocols: DTLS, QUIC, and pre-TLS-1.3 sessions.
- A successful new handshake and fresh reservation after SSL_clear. The current
  test checks reset/rejection before that new handshake only.
- The separate post-handshake allocation paths described above.

Dedicated security/sanitizer/fuzz/smoke campaigns were deferred by the user.
Only source inspection and ordinary functional allocation tests were performed.
Cross-model review was skipped in this non-interactive child task. The parent
completed the read-only review above and must choose any further integration.
There is no PostgreSQL allocation exception, and SQL-ALLOC-002 stays open.
