#!/usr/bin/env python3
"""Run the test-only allocation probe without echoing connection credentials."""
import argparse
import json
import os
from pathlib import Path
import shlex
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("--binary", type=Path, required=True)
parser.add_argument("--credential-file", type=Path, required=True)
parser.add_argument("--ca-file", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=True)
base = dict(os.environ)
for raw in args.credential_file.read_text().splitlines():
    line = raw.strip()
    if not line or line.startswith("#"):
        continue
    if line.startswith("export "):
        line = line[7:]
    key, value = line.split("=", 1)
    key = {"POSTGRES_PASSWORD": "PGPASSWORD", "POSTGRES_USER": "PGUSER", "POSTGRES_DB": "PGDATABASE"}.get(key, key)
    if key in {"PGHOST", "PGPORT", "PGUSER", "PGDATABASE", "PGPASSWORD"}:
        words = shlex.split(value)
        base[key] = words[0] if words else ""
base.update(PGHOST="127.0.0.1", PGPORT=str(json.loads((Path(__file__).resolve().parent / "fixture.json").read_text())["port"]), PGUSER="uwz_test", PGDATABASE="uwz_test")
statuses = {}
for mode in ("plaintext", "tls"):
    env = base.copy()
    env["UWZ_SQL_PROBE_OUTPUT"] = str((args.output / f"{mode}.csv").resolve())
    env["UWZ_SQL_ALLOW_PLAINTEXT"] = "1" if mode == "plaintext" else "0"
    env.pop("PGSSLROOTCERT", None)
    env.pop("PGSSLSERVERNAME", None)
    if mode == "tls":
        env["PGSSLROOTCERT"] = str(args.ca_file.resolve())
        env["PGSSLSERVERNAME"] = "localhost"
    with (args.output / f"{mode}.stdout.log").open("wb") as out:
        with (args.output / f"{mode}.stderr.log").open("wb") as err:
            result = subprocess.run([str(args.binary.resolve())], env=env, stdout=out, stderr=err, timeout=45)
    statuses[mode] = {"exit_code": result.returncode, "interposer_self_test": "PASS" if result.returncode == 0 else "UNCONFIRMED"}
    if result.returncode:
        raise SystemExit(f"{mode} probe failed; inspect credential-free output logs")
(args.output / "run-status.json").write_text(json.dumps(statuses, indent=2) + "\n")
print("plaintext and verified TLS probes completed; credentials were not recorded")
