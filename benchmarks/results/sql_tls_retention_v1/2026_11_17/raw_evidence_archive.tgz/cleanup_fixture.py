#!/usr/bin/env python3
"""Remove only the experiment's own disposable fixture and ephemeral secrets."""
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
private = root / "private_fixture"
identifier = private / "container.id"
if identifier.exists():
    container = identifier.read_text().strip()
    if len(container) != 64 or any(c not in "0123456789abcdef" for c in container):
        raise RuntimeError("invalid owned fixture identifier")
    subprocess.run(["docker", "rm", "--force", container], check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
if private.exists():
    shutil.rmtree(private)
(root / "fixture-cleanup.log").write_text(
    "PASS: owned disposable database removed; ephemeral credentials and key material removed\n")
print("owned disposable database and private fixture material removed")
