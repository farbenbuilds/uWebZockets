#!/bin/sh
set -eu
ulimit -c 0

uwz_checkpoint=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
uwz_mode=${1:-Debug}
case "$uwz_mode" in
    Debug|ReleaseSafe|ReleaseFast) ;;
    *) printf '%s\n' 'usage: sh replay.sh [Debug|ReleaseSafe|ReleaseFast]' >&2; exit 2 ;;
esac
uwz_project=${UWZ_PROJECT_SOURCE:-/home/foo/Desktop/Repos/uWebZockets}
uwz_lsquic=${UWZ_LSQUIC_SOURCE:-/tmp/uwz-lsquic-wt-streams-20261113}
uwz_libxev=${UWZ_LIBXEV_SOURCE:-$uwz_checkpoint/libxev_source}
uwz_zig=${UWZ_ZIG:-/tmp/zig-x86_64-linux-0.16.0/zig}
if [ ! -e "$uwz_checkpoint/harness/zig-pkg" ] && [ -d "$uwz_project/zig-pkg" ]; then
    ln -s "$uwz_project/zig-pkg" "$uwz_checkpoint/harness/zig-pkg"
fi
cd "$uwz_checkpoint/harness"
exec "$uwz_zig" build test -Doptimize="$uwz_mode" \
    -Dproject-source="$uwz_project" -Dlsquic-source="$uwz_lsquic" \
    -Dlibxev-source="$uwz_libxev" -j2 --summary all
