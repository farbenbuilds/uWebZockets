# Actual App routing checkpoint

This is an isolated extension of the frozen admission checkpoint. It retains
the exact prior eight-case driver and adds nine functional cases. The Zig
runner reports 18 tests: 17 functional cases plus one import-discovery anchor.
The required native input source, helper build graph, C fixtures, driver,
terminal logs, review follow-ups and source manifests are included. Earlier
harnesses/checkpoints remain unchanged.

New functional coverage:

- Real native DATAGRAM output reaches the App callback and per-connection ring
  with exact payload and local receive ordinal, after actual HeaderSet reuse
  by healthy ordinary HTTP on another path. Two session0 connections retain
  distinct route identity and isolated rings.
- Ring4 exhaustion, callback suppression on full, lifetime drop count, ordinal
  gap after drop, Close clear, same-connection session4 ordinal continuity,
  abort/connection-generation reuse and fresh ordinal0, plus healthy siblings.
- Actual client control writer2 holds original SETTINGS while TLS/server
  SETTINGS complete. CONNECT remains pending with retained headers/Auth0.
  Positive release admits exactly once; real RESET/STOP cancel before later
  SETTINGS processing. The stronger RESET case proves cancellation-known but
  not visible while the HeaderSet is retained, before original SETTINGS resumes.
  STOP is a synchronous native callback path, explicitly distinguished.
- Each invalid-semantics flow-off capsule byte is delivered and its actual
  native DATA payload exhausted before the next byte. Real DRAIN transitions
  the session to draining and allows a checked wire datagram. Valid Close
  clears the session/ring and sends server FIN before client EOF; subsequent
  client FIN drains pools. A real post-Close datagram is ignored and HTTP works.
- Real datagram callbacks exercise process reentry and deferred cooldown.
  Native GOING_AWAY proves cooldown's actual effect after outer packet input
  unwinds. Teardown drains real xev completions before App deinitialization.

Ordinary cases use full native TLS and loopback UDP through actual App xev
receive/output. Only the explicitly named queued cancellation/SETTINGS cases
and the retained prior cooldown case stage actual client-encrypted packets
directly through server native packet input to control scheduling. Those
timing seams do not claim xev receive ordering, invoke callbacks manually, or
fabricate frame bytes, native state or peer settings. See the driver README.

Negative datagram arrival is inferred from isolated actual native output: one
writer event, one queued packet, one UDP send, exactly one target native input
packet-count increment, and unchanged undecodable/duplicate/error counts while
client ticks are withheld. There is no native per-DATAGRAM receive counter.
Unchanged application observations and healthy HTTP barriers supplement that
explicitly bounded inference; finite pumping alone is not credited as arrival.

Frozen candidates are unchanged and production pins are untouched:

- lsquic `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c` at the original `/tmp`
  candidate tree. The root archive supplies its complete source separately.
- libxev `5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`; its exact42-file required
  runtime/build source snapshot is included and verified by `inputs.sha256`.
- The copied lsquic helper enables the candidate's existing constructor
  observer compile flag. It changes scheduling of the actual client writer;
  neither candidate source is patched. Package pins are fixed by the copied zon.

Replay requires Zig0.16.0 and Linux loopback/io_uring access outside the managed
socket sandbox. Set `UWZ_PROJECT_SOURCE`, `UWZ_LSQUIC_SOURCE`,
`UWZ_LIBXEV_SOURCE` or `UWZ_ZIG` when restoring sources elsewhere. The script can
link an existing project package directory; no cache or generated binary is
archived. Core dumps are disabled.

```sh
sh replay.sh Debug
sh replay.sh ReleaseSafe
sh replay.sh ReleaseFast
```

The project source manifests identify matching source inputs; the root
checkpoint supplies its reviewed project source snapshot and broader checks.
`results.md` records authoritative terminal rows and distinguishes compile
failures and earlier passing rows with weaker proof. `package_inputs.sha256`
hashes every included source, log and provenance file.

This cohort required no project or native source fix. It does not claim a
hidden STOP-notification race, old encrypted packet association with a new
connection generation, positive App child stream I/O, or external-client
interoperability. Smoke, security, sanitizer and fuzz campaigns remain deferred.
