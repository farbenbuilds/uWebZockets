# Exact native verification profile

The root project base is `d9f3305313bc2bdc1bc92f4701cd7113b4042653`.
Its production source was unchanged during this cohort. The full matching
project source/build inventory is `project_sources.before.sha256`; check it
from the restored project root. This package's18-file scratch source inventory
is `harness_source_inputs.sha256`, checked from this package root.

The explicit immutable inputs are lsquic
`2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c` and libxev
`5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`. Full HEAD/tree identities and
empty dirty-status outputs are included. Production pins and all zon views
remain unchanged. The copied zon fixes BoringSSL, qpack/hpack, libdeflate,
zlib and zslay identities; Zig compiles all native C/C++ from source.

The final copied lsquic helper arguments enable the predecessor's existing
fixture-clock indirections, disable the reset-ack observer, and enable the
candidate's already-implemented SETTINGS constructor observer:
`lsquic.build(..., true, false, true)`. The exact helper is archived. No source
overlay, native fork edit or package-cache source rewrite is applied.

The new observer flag is `LSQUIC_WT_SETTINGS_TEST_OBSERVER=1`. The C fixture
also uses the same relevant private-layout definitions as the native build:
`LSQUIC_CONN_STATS=1`, `LSQUIC_DEBUG_NEXT_ADV_TICK=1`, and `HAVE_BORINGSSL`.
The full flags, source lists, target settings and link inputs are in the
copied build graph and terminal logs. Assertions remain enabled in the C
fixture in all three modes.

The constructor observer locates actual client critical stream2 through the
candidate's real connection-public stream hash. It only schedules that native
writer using wantwrite, returning immediately for actual server contexts.
Original buffered SETTINGS bytes are resumed; no manual SETTINGS encoding or
peer cache assignment occurs. C diagnostic snapshots copy actual native
packet statistics, stream/HQ filter state and send-shutdown flags through the
candidate's actual private types. They do not mutate those observed fields.

The42 required libxev runtime/build source files are included under
`libxev_source` with their original manifest and all hashes verified. Its
LICENSE and README are also included. This is the reviewed XEV-008 candidate
input, not an update to the published dependency pin. Matching lsquic source
is provided by the root's previously archived native candidate cohort.
