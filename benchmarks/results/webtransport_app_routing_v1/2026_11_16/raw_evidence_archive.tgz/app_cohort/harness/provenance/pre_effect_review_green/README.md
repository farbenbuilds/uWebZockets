# Actual App routing and SETTINGS verification harness

This new isolated harness extends the frozen eight-case admission cohort.
`tests/app_admission.zig` remains byte-identical; earlier harnesses and the
admission checkpoint are untouched. The actual project App, router, UDP
transport, engine, backend and native C translation are imported together.
There are no fake native layouts/functions, callback replacements, peer-cache
assignments, manually invoked production callbacks, or assigned drain flags.

The full cohort has 18 Zig tests: 17 functional cases and one import-discovery
anchor. The functional breakdown is eight unchanged admission cases, two
datagram routing/lifetime cases, five held-SETTINGS cases, one fragmented
flow-control-off Close case, and one actual datagram-triggered cooldown case.

## Real packet and application evidence

Native client `on_dg_write` supplies bounded bytes after
`lsquic_conn_want_datagram_write`; candidate lsquic constructs and encrypts QUIC
DATAGRAM frames. The project WebTransport encoder writes only the application
datagram's quarter-stream-ID prefix. Client packets use actual bound loopback
UDP sockets; server input and output use the actual App xev UDP transport.

Each datagram is isolated after traffic settles: exactly one native writer
event, one queued native packet and one actual UDP send are required. The
server loop is then serviced without client ticks until the target native
connection's real input packet count increases exactly once. Undecryptable,
duplicate and error counts must remain unchanged. This is an inference from
the isolated known DATAGRAM-bearing packet and native packet counters, not a
native per-DATAGRAM receive counter. Negative delivery cases additionally
require unchanged callback/ring state and healthy ordinary HTTP progress.

Successful delivery checks both exact callback payload/size and ring payload,
session ID and local receive ordinal. The nonselected registered route's
callback count and prior payload remain unchanged. Two connections both use
session0 yet route to separate registered paths and rings. A real POST on a
different path reuses the exact bounded HeaderSet slot before datagrams arrive,
proving delivery uses retained route identity after request-header release.

Four ring slots fill; the fifth datagram is received but dropped without a
handler call. The next accepted ordinal skips the dropped receive ordinal.
The dropped lifetime count survives session clear. Valid Close clears queued
payloads; a real later datagram for the closed session is ignored. A new
session4 on the same connection keeps its receive ordinal, while a reused
connection slot has a new generation, an empty ring and fresh ordinal0.
The stale connection handle fails lookup. These tests do not claim an old
connection's encrypted packets can associate with a new TLS connection.

## Original SETTINGS writer scheduling

The copied build helper enables the candidate's existing
`LSQUIC_WT_SETTINGS_TEST_OBSERVER` compile profile. Its constructor callback
returns immediately for server connections. For a selected client it locates
actual critical stream2 in the native stream hash and holds its native writer
with `lsquic_stream_wantwrite(..., 0)` before/after ticks. No SETTINGS frame is
fabricated: resuming native wantwrite sends the original buffered writer bytes.
The native source tree remains clean at its original immutable commit.

With client SETTINGS held, real TLS and server SETTINGS complete, while actual
server `read_peer` remains PENDING with output unchanged. CONNECT retains its
actual HeaderSet, authorization count remains zero, and no session is open.
One positive control resumes the original writer and requires exactly one
authorization call, non-FIN200, native and cached peer completion, established
session, header release, and a real delivered datagram.

RESET and STOP before SETTINGS release must cancel pending admission and
release headers without later resurrection. The stronger ordering cases
generate and stage cancellation packets while control2 is still held, inspect
actual native receive state, then resume/stage original SETTINGS before one
public process turn. RESET_KNOWN must be set while RESET_VISIBLE remains clear
and the pending HeaderSet is still retained. This exercises the queued-reset
preflight ordering. STOP invokes its native callback synchronously during
packet input, so STOP_KNOWN and already-cleared header state are required
before SETTINGS resumes. The STOP case proves its direct callback path and
no resurrection; it does not claim a hidden STOP-notification race.

## Fragmentation, reentry and teardown

A WT_MAX_STREAMS_UNI capsule has a stream count rejected by the strict decoder.
Each byte is sent as actual HTTP DATA and serviced until the native stream
reader advances. Flow control is disabled, so this semantic error must be
ignored; the session and queued datagram remain live and another real datagram
is delivered. A fragmented valid Close plus EOF then clears session, ring and
HTTP/header pools without reset, and ordinary HTTP remains healthy.

Actual datagram handlers call public engine.process and must return under the
callback-depth guard. A separate real datagram handler requests engine.cooldown,
observes positive callback depth and deferred pending state without entering
cooldown, then verifies pending/depth clear after outer packet processing.
It does not call App.shutdown from the manual xev driver. Teardown calls real
transport shutdown, bounds xev completion draining, checks actual drained and
cancellation state, then calls App shutdown/deinit. TLS material stays in memory.

## Immutable inputs and replay

- lsquic: clean `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c` at
  `/tmp/uwz-lsquic-wt-streams-20261113`.
- libxev: clean `5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5` at
  `/tmp/uwz-gro-libxev`; the reviewed cancellation candidate is explicit.
- Production manifest pins stay unchanged. BoringSSL, qpack/hpack, libdeflate,
  zlib and zslay are fixed by the copied manifest and native build helpers.
- The shared decoded-header field capacity remains the prior cohort's explicit
  8192 bytes; the original1024 copy and intentional diff are in that checkpoint.

Run with real Linux loopback UDP/io_uring permissions; the managed socket
sandbox is insufficient. Core dumps are disabled in the recorded runs.

```sh
ulimit -c 0
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-uni-global-cache \
  /tmp/zig-x86_64-linux-0.16.0/zig build test \
  -Doptimize=Debug \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-streams-20261113 \
  -Dlibxev-source=/tmp/uwz-gro-libxev -j2 --summary all
```

Repeat with ReleaseSafe and ReleaseFast. Source snapshots, exact manifests,
terminal logs and review fixes are preserved under `provenance`; earlier
insufficient assertions are not credited with later proof. No production
source fix was required by this cohort. Positive App child stream I/O,
external-client interoperability, smoke, security, sanitizer and fuzz campaigns
remain outside this verification scope.
