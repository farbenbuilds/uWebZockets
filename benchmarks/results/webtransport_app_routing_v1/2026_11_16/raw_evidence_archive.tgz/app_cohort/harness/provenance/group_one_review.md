# Read-only review follow-up

The first group passed ring payload and callback-count assertions but did not
compare the callback's copied payload. That original source/log snapshot is
preserved under `group_one_green`; no callback-payload proof is attributed to
that row. The follow-up compares the selected handler's exact payload and size
after every successful native datagram, including overflow recovery and
connection reuse, and requires the other registered route's callback count,
last size, and last payload to remain unchanged. Negative cases also preserve
the selected route's prior callback observations.
