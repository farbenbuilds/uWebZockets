# Native effect and fragmentation proof review

The earlier passing rows checked cooldown wrapper flags but lacked an actual
native cooldown effect assertion. They also waited for raw native read offset
progress between one-byte writes, which could be HTTP DATA frame headers alone.
Their source/log rows remain preserved, including the pre-review ReleaseSafe
pass under `pre_effect_review_green`; they are not credited with these stronger
proofs. Neither gap was a demonstrated production defect.

The final cooldown case additionally requires the active native server
connection's public lsquic_conn_status to be LSCONN_ST_GOING_AWAY after the outer
packet processing unwinds. Clearing pending without native cooldown cannot
satisfy that assertion.

The observational C snapshot now copies actual sm_hq_filter.hqfi_left and
hqfi_type. Each fragment waits for both read-offset advance and a DATA filter
with zero payload remaining before the next one-byte write. In the frozen
native source, hq_decr_left subtracts actual application-read bytes and returns
the filter to the frame-header state only after payload is exhausted. These
fields are read through the candidate's real private types with matching layout
defines; no native or project state is assigned by the diagnostic helper.
