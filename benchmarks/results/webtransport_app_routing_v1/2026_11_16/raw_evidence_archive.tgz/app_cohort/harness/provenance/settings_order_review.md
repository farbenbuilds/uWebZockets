# Causal ordering review

The first four cancellation cases staged the cancellation and released
SETTINGS together. Their passing row is preserved in `group_two_green`, but
it did not isolate a queued-reset preflight race. The following source snapshot
and run distinguish the real native paths.

With control stream2 still held, native client reset/STOP output is generated
and its encrypted packets are staged through actual server packet_in without
public process. Native get_recv_state must already report the cancellation.
For RESET, RESET_KNOWN must be set while RESET_VISIBLE is clear and the actual
pending CONNECT/HeaderSet remains retained. Only then does the fixture resume
the original SETTINGS writer, stage its encrypted packets, and invoke one
public process turn. Admission must never run, and the retained header must
be released. This targets native service ordering: SETTINGS publication can
precede queued reset recheck.

STOP differs in the unchanged candidate: stop_sending_in calls on_reset
synchronously during packet_in. The fixture therefore requires STOP_KNOWN
and already-released pending/header state before SETTINGS is resumed. It
proves the ordinary real STOP cancellation path and subsequent no-resurrection,
not a hidden STOP notification or the preflight branch alone. A hidden STOP
notification for this already-decoded CONNECT is not forced by this fixture.
No callback replacement, native mutation, peer-cache assignment, or encoded
frame fabrication is used.
