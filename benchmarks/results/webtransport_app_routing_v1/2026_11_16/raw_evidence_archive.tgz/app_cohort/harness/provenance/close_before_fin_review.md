# Close action before client EOF

The earlier effect-fixed rows sent the final Close byte together with FIN.
Those passes prove Close-plus-EOF cleanup, but could not isolate Close action
from generic EOF cleanup. Their exact sources and Debug/ReleaseSafe logs are
preserved under `close_eof_limited_green`; they are not runtime failures and
are not credited with the stronger causal claim.

The final fragment is now sent with FIN disabled. Before sending any client
EOF, the test requires the actual production sidecar close_received flag,
session count zero, ring empty, and native server FIN received by the client.
It also requires the server's actual receive state to have no FIN_RECEIVED and
the native client STREAM_U_WRITE_DONE flag to remain clear. Only afterward is
an empty client FIN sent, followed by the original full pool drain, isolated
post-Close datagram rejection, and healthy HTTP sibling assertions. Ignoring
Close until EOF cannot satisfy this pre-EOF checkpoint.
