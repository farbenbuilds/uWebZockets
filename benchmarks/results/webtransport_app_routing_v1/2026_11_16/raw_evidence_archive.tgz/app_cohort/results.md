# Authoritative terminal results

The final reviewed source passed unchanged in all three modes:

| Mode | Session | Exit | Zig tests | Functional cases | Build steps |
| --- | ---: | ---: | ---: | ---: | ---: |
| Debug | 41131 | 0 | 18/18 | 17 | 16/16 |
| ReleaseSafe | 39754 | 0 | 18/18 | 17 | 16/16 |
| ReleaseFast | 11872 | 0 | 18/18 | 17 | 16/16 |

One additional Zig test is the import-discovery anchor; it is not described as
a distinct native functional case. Final source comparison manifest SHA-256:
`b39474a1c49182c00e9f7f2dccad5065eabaab10d7650e481d56e9a339412adb`.
Every archived 18-source input matched after each run, as did the observed
project runtime inputs. The complete matching242-file project source/build
inventory was checked unchanged after all modes. Both candidate trees stayed
clean. The predecessor16-source admission harness inventory also still matches.

Final log SHA-256:

- Debug: `a81885b45d6a7102bac6623b4e4ff1eb11e798761ce10ea2c75c97312fc9bb47`
- ReleaseSafe: `90df5e9c131e2b68ac1430ee1796118651f653f1f2fcccc99f290dc10e5031a1`
- ReleaseFast: `a6a79fbd267b596ecf7c3c75bd816532d1904de73a1595ac85765ebc8fafd22d`

The matching logs, immediate shell exit files and source/root check outputs
are `harness/provenance/close_fixed_*`. Scratch Zig formatting checks passed.
The root agent owns repository-wide checks and final integration.

The executed command in each mode was:

```sh
cd /tmp/uwz-wt-app-routing-harness
ulimit -c 0
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-uni-global-cache \
  /tmp/zig-x86_64-linux-0.16.0/zig build test \
  -Doptimize=Debug \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-streams-20261113 \
  -Dlibxev-source=/tmp/uwz-gro-libxev -j2 --summary all
```

Only `-Doptimize` changed for ReleaseSafe and ReleaseFast. Real loopback runs
used the explicitly authorized execution context because the managed sandbox
does not permit socket creation. Replay selects the identical included libxev
source content, with environment overrides for relocated inputs.

Historical rows remain scoped to their actual source and proof:

| Row | Terminal outcome | Scope and retained evidence |
| --- | --- | --- |
| First group compile | exit1; no tests ran | Two scratch helper-name shadow errors. Exact failing driver/log/manifests in `group_one_compile_failure`; corrected only the helper name. |
| Group1 Debug | exit0,11 Zig tests | Eight prior plus two DG cases and anchor. Ring payload checked; callback payload was not yet compared. Snapshot/log in `group_one_green`. |
| Group2 Debug | exit0,15 Zig tests | Four added RESET/STOP cases. Cancellation and SETTINGS were staged together, so queued preflight ordering was not isolated. `group_two_green`. |
| Group3 Debug | exit0,18 Zig tests | Callback payload, positive SETTINGS control, flow-off and cooldown cases added. Cancellation ordering and later native effect/fragment/Close causal proof remained weaker. `group_three_green_pre_order_review`. |
| Order-fixed Debug | exit0,18 Zig tests | Cancellation-first native state proof corrected. Later effect and Close refinements were not yet present. `order_fixed_green`. |
| Pre-effect Debug/ReleaseSafe | exit0,18 Zig tests | Wrapper cooldown flags and raw offset fragmentation alone did not prove native cooldown or actual payload exhaustion. `pre_effect_review_green` and historical `final_debug.log`. |
| Effect-fixed Debug/ReleaseSafe | exit0,18 Zig tests | Native GOING_AWAY and HQ DATA payload exhaustion verified. Close final byte still carried EOF, so Close action was not isolated. `close_eof_limited_green`. |
| Final Close/DRAIN modes | exit0,18 Zig tests in each mode | Actual DRAIN plus datagram delivery while draining; Close action/session/ring clear/serverFIN before clientEOF; every required review refinement present. `close_fixed_*`. |

Earlier passing rows are not failures of production, nor are they credited
with stronger assertions introduced later. All original logs/source snapshots
remain intact. No repository or native candidate source change was required.
