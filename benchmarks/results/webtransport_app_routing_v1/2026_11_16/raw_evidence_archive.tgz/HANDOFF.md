# App routing verification handoff

The production source is unchanged at project base commit
`d9f3305313bc2bdc1bc92f4701cd7113b4042653`. No dependency pin or activation
policy changed. `project_inputs.sha256` hashes all 242 tracked source/build
files in this inventory; `project_sources/` retains those exact files for
comparison. Restore the full base checkout for package and generated vendor
inputs before replay; this source subset is not a complete repository copy.
`project_docs/` contains this checkpoint's updated status documents.

## Final functional results

The sibling `app_cohort/` package extends the prior frozen admission scaffold.
Its final reviewed source passes 18 Zig tests in Debug, ReleaseSafe and
ReleaseFast, 16/16 build steps per mode. These are 17 functional cases and one
import-discovery anchor. Final source comparison manifest:
`b39474a1c49182c00e9f7f2dccad5065eabaab10d7650e481d56e9a339412adb`.

Final authoritative sessions and log hashes:

- Debug 41131, exit0:
  `a81885b45d6a7102bac6623b4e4ff1eb11e798761ce10ea2c75c97312fc9bb47`.
- ReleaseSafe 39754, exit0:
  `90df5e9c131e2b68ac1430ee1796118651f653f1f2fcccc99f290dc10e5031a1`.
- ReleaseFast 11872, exit0:
  `a6a79fbd267b596ecf7c3c75bd816532d1904de73a1595ac85765ebc8fafd22d`.

The `app_cohort/results.md` table distinguishes all earlier compile failures
and passing rows with weaker proof. Their original sources and logs remain
in `app_cohort/harness/provenance/`; none is credited with assertions added
later. All runtime inputs matched after the final runs, the full project
inventory stayed unchanged, and both native worktrees remained clean.

The fresh published-dependency central suite passed 991/991 tests in 20/20
steps. `root_checks/` contains its log and captured exit. Root checks used
Zig0.16.0 at `/tmp/zig-x86_64-linux-0.16.0/zig` and:

```sh
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache zig build test-unit -j2 --summary all
zig fmt src builds examples tests fuzz
sh scripts/check_conventions.sh
sh scripts/check_release_version.sh
git diff --check
```

The formatter protected/restored two nested generated directories. Every one
of the 242 tracked source/build hashes was unchanged before and after it.
Conventions, metadata and diff checks passed. AST-only graphify updated ignored
output. The default test target includes the deferred C smoke executable;
`test-unit` retains the complete central suite and archive symbol check.
No test, threshold, assertion or default build target was disabled. Dedicated
smoke, sanitizer, fuzz and security campaigns remain deferred by the user.

## Replay and native profile

Read `app_cohort/README.md`, `results.md`, `evidence.md`, the driver README
and `replay.sh`. Set `UWZ_PROJECT_SOURCE` to a full restored base checkout,
`UWZ_LSQUIC_SOURCE` to the retained candidate and `UWZ_ZIG` as needed, then run
`sh replay.sh Debug`, `ReleaseSafe` or `ReleaseFast` from that package.

- lsquic source: `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c`. Restore it
  from the separate `lsquic_webtransport_children_v1/2026_11_16` artifact.
- libxev source: `5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`. The exact
  required 42-file snapshot is included in `app_cohort/libxev_source`.
- Production lsquic `85bd081c9103c077a7cc98271d09334d0f1043d4` and libxev
  `c49f6dfb83038c146232472c063e4b2681d098d8` remain pinned unchanged.

The copied native build enables the candidate's existing SETTINGS constructor
observer. It ignores server contexts before interpreting client fixture data
and only pauses/resumes the original critical writer2 through native
wantwrite. No native source, peer cache, encoded SETTINGS or production
callback was substituted. The earlier admission scaffold remains frozen.
Native source identity and this test-only compile profile are separately
recorded; no claim is made that the observer was in the production build.

Normal cases use actual client TLS, loopback UDP, App xev reception, engine
callbacks and native output. The two queued cancellation cases stage actual
encrypted client packets directly into native input before one public process
call to expose causal ordering. The retained earlier cooldown case has its
own encrypted-packet staging seam. Neither is described as proof of xev receive
ordering. All cases drain actual completions before application destruction.

## Proof refinements and independent review

The final fixtures assert exact callback payloads separately from copied ring
contents, and preserve unselected-route observations. A single known native
datagram packet, writer/send counts and target input counters with unchanged
undecodable/duplicate/error counts support negative delivery assertions. This
is an isolated packet/source inference; the native engine exposes no dedicated
per-datagram receive counter. Healthy HTTP barriers supplement that proof.

The RESET case stages cancellation while SETTINGS is still held and observes
RESET_KNOWN without RESET_VISIBLE with pending request headers retained before
resuming original SETTINGS. STOP invokes native notification synchronously
during packet input and is explicitly documented as that separate path.
Positive held admission proves one authorization call after settings resumes.

Native HTTP DATA remaining-length observations ensure every capsule payload
byte is consumed before the next is sent. Invalid flow-off semantics are
ignored, DRAIN permits a checked datagram, and valid Close clears the session
and ring and sends server FIN while the client send half remains open and the
server has not received FIN. Client FIN is then sent separately for full pool
drain. Native GOING_AWAY after callback unwind proves actual deferred cooldown.

Read-only independent reviews found and resolved gaps in callback payload,
cancellation ordering, native effect, fragment consumption and Close/EOF
separation. Final source review has no remaining required findings. Final
driver SHA-256:
`a12470637018665c4cd2879ab4f6e7b8c35d0b306e95b05dea23c7ab57167fe7`.
C bridge:
`0ee1dcbdd9f7b054bf2f847148361cf4918a2d7ac18cd55a602feccc222c62a3`.
Header:
`33c0d0157da5ba9df586962625a10612f090f1e114504c4b0139ec19c3f11450`.
Reviewers did not run builds; execution and terminal evidence are attributed
separately above. The final provenance review verified all 205 scaffold package
entries, 18 scratch sources, 242 project inputs, 42 libxev sources, earlier
admission inputs, all final log hashes/exits and the replay profile; it found
no required issues. Outer handoff and root checks were verified by the root
integrator. No production defect or corresponding source fix was needed.

## Remaining goal requirements

The published pin keeps live WT disabled. Bounded early associations, positive
App typed children, multi-session flow accounting, independent draft-16 client
acceptance and maintained-fork publication/pin synchronization remain open.
This cohort does not establish external-client interoperability, positive App
child I/O, a hidden STOP-notification race, or old-key packet association after
connection reuse. Prior close/ring and peer-wait proof gaps are now covered
within the existing single-session, flow-off profile.

The broader v2.3.0 objective retains strict PostgreSQL TLS allocation and
quiet-host throughput gates, external HttpArena owner/release acceptance,
native platform and second-machine evidence, fork closure and measured kTLS
gates. SQLite SQL-ALLOC-001 is approved; PostgreSQL SQL-ALLOC-002 is not.
No release or tag is created and no deferred campaign is claimed as passing.
