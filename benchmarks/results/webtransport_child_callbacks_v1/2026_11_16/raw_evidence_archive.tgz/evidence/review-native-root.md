# Independent RX source and functional-proof review

No remaining actionable findings in the reviewed callback/reset fixes.

Reviewed Root and copied-project identities match:

- engine.zig: `548ae3b2b468f86a4a8787cf2d00ba3de50404f4640a7d56777157472a419fdc`.
- child_io.zig: `77050034bea4fa7ad2e103eb3a17bcad5447ec20373ceb69678042755760f576`.
- Callback driver: `9c4836a0362f16945fe806b5cb477d4d510428304006c759c8095e72fafae550`.
- Reset driver: `82616fa352208d7e54310fa993c1a030f7c47f26ae86c457617eadc32976f992`.
- Teardown driver: `f0fce1535ad94800775cbfa530c846bcaf93bf66bcf1a543956d972226252a32`.

The liveness guard now includes actual native connection status, stopping a
second read/delivery after a consumer aborts the connection. SST_CLOSED now
shuts down the application's remaining receive half; native RESET knowledge
or visibility alone does not perform that shutdown. Existing peer error codes
and first close causes remain intact.

Waiting association refreshes the authoritative receive snapshot before open.
The initial registration check was moved rather than duplicated. Only a
visible reset or cancelled receive half prevents admission; merely known,
hidden reliable-reset metadata remains eligible. Actual read accounting still
precedes data callbacks, and the last reliable payload precedes reset delivery.
Native close still queries metadata before releasing consumer and lease
ownership. No public API, native proposal, dependency pin or bound is changed.

The reviewed tests retain genuine abort/reset failures and exercise actual
peer/native APIs: independent BIDI STOP followed by continued RX and a different
full-width RESET; hidden final 15/reliable 7/prefix 3 delivering four bytes then
one reset with final/accounted payload 12; visible waiting reset suppressing
open while future session 4 survives; and callback shutdown/abort/rejection
with 3072 bytes already buffered and exact zero-or-2048-byte delivery limits.
They check terminal/accounting values and cleanup rather than only callbacks.

The parent Close test now sends the capsule without FIN and checks client
send_shutdown remains zero both before and after owned-child closure. It
therefore distinguishes capsule cancellation from later read-EOF cleanup.

Read `complete-incoming-Debug.log`: 17/17 functional tests and 16/16 build
steps passed. Log SHA-256:
`3e5d144e05ac2d1022ddb7149ce6fac190cc80e905062ea2ccfcfa664074ceb4`.
Native proposal 005ab244... and XEV inputs were held unchanged by this slice.
Other optimization modes and full Root checks were starting when this review
was prepared; this artifact does not claim their results.

This was a read-only source/evidence review; only this requested artifact was
written. The reviewer ran no builds, runtime tests, scans, smoke or security
campaigns. The result concerns private incoming RX support, not supported
public child APIs, application TX, multi-session flow accounting, independent
client acceptance, publication/pins or completion of v2.3.0.
