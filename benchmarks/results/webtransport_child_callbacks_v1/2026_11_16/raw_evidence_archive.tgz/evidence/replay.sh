#!/bin/sh
set -eu
ulimit -c 0
checkpoint=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
zig_bin=${ZIG:-zig}
mode=${1:-Debug}
cohort=${2:-incoming}
case "$mode" in Debug|ReleaseSafe|ReleaseFast) ;; *) exit 2 ;; esac
case "$cohort" in
    incoming) driver=tests/children_main.zig ;;
    existing) driver=tests/main.zig ;;
    *) exit 2 ;;
esac
cd "$checkpoint/app"
exec "$zig_bin" build test -Doptimize="$mode" \
  -Dproject-source="$checkpoint/app/project_cio" -Dtest-source="$driver" \
  -Dlsquic-source="$checkpoint/native-source" \
  -Dlibxev-source="$checkpoint/libxev-source" -j2 --summary all
