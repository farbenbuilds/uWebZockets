# Incoming child callback and RESET architecture review

Date: 2026-11-16. Read-only standard review of the private receive-only slice after Root base `36d4918`, retaining the prior structural review's ownership boundary. No required findings remain in the reviewed changes. This is scoped architecture/proof acceptance, not full v2.3.0 or release approval.

## Frozen inputs

Root and harness `project_cio` copies were verified identical:

- Engine SHA-256: `548ae3b2b468f86a4a8787cf2d00ba3de50404f4640a7d56777157472a419fdc`.
- Child I/O SHA-256: `77050034bea4fa7ad2e103eb3a17bcad5447ec20373ceb69678042755760f576`.
- `tests/app_child_callbacks.zig`: `9c4836a0362f16945fe806b5cb477d4d510428304006c759c8095e72fafae550`.
- `tests/app_child_resets.zig`: `82616fa352208d7e54310fa993c1a030f7c47f26ae86c457617eadc32976f992`.
- `tests/app_child_teardown.zig`: `f0fce1535ad94800775cbfa530c846bcaf93bf66bcf1a543956d972226252a32`.
- Fixture C SHA-256: `7439bac790b2837095e4913031563f53f97af92685d19a8da121cdf4eab7f3fa`.

Native proposal `005ab244169f269689e511d6b77dd2187e318df1`, the existing XEV candidate, and production dependency pins are unchanged by this slice. Earlier harnesses and evidence remain separate.

## Accepted fixes and ownership

1. Engine's concrete child live guard now uses the existing native connection status policy. A native USER_ABORTED status invalidates delivery immediately, before deferred connection-close callbacks clear the pointer. The retained abort RED delivered all 3072 bytes instead of the permitted first 2048; the fix adds no new abstraction.
2. Child I/O handles terminal STOP CLOSED by shutting down the application's receive half. A visible native RESET does not itself guarantee that half is closed. The retained RESET REDs include two owned-close timeouts, with diagnostic visible-reset/read-not-cancelled state.
3. Engine checks a fresh receive snapshot in every waiting-child association attempt, rather than only at initial registration. Visible reset/read cancellation suppresses admission and releases pending ownership; a hidden known reset remains eligible to deliver its promised reliable prefix. The retained waiting-reset RED opened the consumer incorrectly after later parent admission.

These decisions remain in their canonical boundaries: pure lifecycle/ledger facts; child_io native reads, notifications and cancellation; Engine connection/session association, quotas and leases. No public child API, hot-path allocation, new Root slab, native flag assignment, or generic callback framework was added. Engine is 1599 lines and child_io 204; Engine remains a size flag, but these small changes reuse existing policy and remove the initial-registration-only special case. No additional decomposition is required for this diff.

## Verifiable proof acceptance

- Callback cases send real raw UNI payload and FIN before CONNECT. Native contiguous readability proves all 3072 bytes are already buffered; receive snapshots agree before/after the query, waiting reservations remain intact, ledger payload_read is zero, and raw final size includes the actual prefix. The query may refresh derived native hash cursor fields; it is non-consuming, not bitwise read-only. It runs outside native read callbacks with a freshly resolved live pointer.
- Accepted-open cooldown owns exactly one eventual close with zero data. Data cooldown and native abort deliver exactly the first 2048-byte chunk, then no second chunk, EOF, RESET or STOP. All three retain known final payload/accounting of 3072. Actual deferred cooldown/USER_ABORTED observations and explicit lease/counter draining prevent cleanup in test defers from masking failure.
- A rejected open owns no close notification. Rejected data accounts the consumed native chunk, cancels only that owned child, and leaves its parent and healthy HTTP usable.
- Parent CLOSE is sent without FIN. The native client send_shutdown observation remains zero both after parent session removal and after the owned child closes. Future SID4 and another connection's SID0 child survive; subsequent CONNECT4 receives its buffered bytes under a new parent generation. This resolves the earlier Close-plus-FIN proof limitation.
- Actual BIDI STOP carries a full-width error, leaves receiving active for additional payload, and remains independent from a later full-width RESET. The consumer observes one STOP, one RESET, no EOF, final payload/accounting of 11, and one close; healthy HTTP remains usable.
- Hidden RESET_AT is genuinely known and invisible before admission, with raw final size 15 and reliable size 7. After the actual three-byte prefix is excluded, four payload bytes arrive before the reset callback, and final payload/accounting is 12. Event counters capture that ordering.
- A visible waiting RESET is delivered before parent admission and before expiry. It causes no consumer open; pending future SID4 survives and later delivers exactly once. Fresh anchor/native hash queries retain no target pointer across pumping.

## Results and remaining scope

The inspected `complete-incoming-Debug.log` reports 16/16 build steps and 17/17 tests passed. Genuine failure logs and source snapshots remain retained separately. This reviewer ran no builds and does not claim uninspected optimization modes or Root checks passed; Root owns authoritative process exits, final manifests, normal verification gates, integration, commit and push.

This closes the listed private incoming receive callback/reset acceptance slice. Public stream I/O and lifecycle APIs, TX, flow, broader multisession behavior, independent-client acceptance, dependency publication/pinning and full-goal release gates remain open. Dedicated smoke/security/fuzz/sanitizer campaigns remain deferred by the user. Only this requested scratch review artifact was written.
