# Incoming child callback/reset checkpoint

The full v2.3.0 goal remains active and incomplete. Root base is
36d491838c6bc459fcc901f6876d402f03066ef0. The exact final Engine and child_io
hashes are in results.json and both independent review artifacts. Production
pins and activation are unchanged. Native lsquic 005ab244169f269689e511d6b77dd2187e318df1 and XEV 5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5
are unchanged local proposals, not published production pins.

## Authoritative evidence

commands.txt records full commands; results.json records terminal outcomes.
All 17 actual App child cases pass in Debug, ReleaseSafe, ReleaseFast, 16/16 steps
per mode. The existing 33-case App cohort passes Debug (32 functional+1 import
anchor). All 1035 centralized functional tests pass, 20/20 steps. ReleaseSafe
test compilation and the ReleaseFast library pass 21/21 steps. Protected exact
formatting leaves 300 retained source/build inputs unchanged. Conventions,
release metadata and whitespace checks pass. Final 262-input source and Root
300-input manifests were verified. The reviews ran no tests themselves; their
preparation-time pending-check statements are historical. Final logs and this
coordinator's results are authoritative.

## Three genuine failures and fixes

1. callback-initial-Debug.log shows a native USER_ABORTED callback received
  3,072 bytes instead of the allowed first 2048. All 3072 bytes and FIN were
  staged before CONNECT, so another read was available immediately. The Root
  guard checked a live lease/pointer but not immediate native connection status.
  It now reuses native_connection_live before/after consumer calls. The exact
  baseline source is in abort-red-source/.
2. resets-initial-Debug.log and reset-close-diagnostic-Debug.log show visible
  reset events with no eventual owned close. The diagnostic observed phase
  closing, reset_visible=true, read_cancelled=false, no pending native actions
  and final 15 after data 4/reset 1. Native SST_CLOSED did not finish the user's
  read half. child_io now calls native shutdown(read) for that terminal result;
  delayed final-size ownership and the original peer error remain intact.
3. The same original cohort opened a consumer for an already-visible reset
  while waiting for its parent. Cancellation checking had run only at initial
  registration. The check now runs in associate_child for every waiting attempt,
  including reset callbacks; invalid snapshots fail closed. It rejects only
  read_cancelled or reset_visible, not reset knowledge alone. Original reset
  source and logs are preserved in resets-red-source/.

## Actual scope proved

The two cooldown cases and data-abort case stage 3072 actual payload bytes plus
FIN before authorization. The C observation calls the native data-input
readability interface without consuming bytes; the hash variant can refresh
its derived cursor/cache. No flags, payload, offsets, peer cache or credit are
manually assigned. Equal public receive snapshots and ledger.payload_read=0
are checked around observation. The pointer is reacquired from an active Root
lease and not kept across a pump.

Open-triggered cooldown accepts ownership but delivers no data. Data cooldown
and abort deliver exactly one 2048-byte chunk. All report final/accounted 3072,
no EOF/reset/STOP after cancellation, one owned close and drained counters.
The abort callback records actual USER_ABORTED immediately. Cooldown is observed
deferred in the callback and native GOING_AWAY afterward. Extra pumps precede
explicit parent completion; counters/leases drain before deferred cleanup.
Declined open sends exact mapped cancellation but owns no close. Declined data
cancels its owned child, with one complete borrowed chunk and healthy HTTP.

The strengthened parent test sends a Close capsule without FIN. Actual client
send_shutdown remains 0 before and after its child's owned close. Another
connection's SID0 and buffered future4 survive; CONNECT4 then admits future
bytes. This supersedes only the earlier Close-plus-FIN proof qualification.

Full-width BIDI STOP permits more RX payload, followed by an independent RESET
with another full-width code, one reset, no EOF and one peer-reset close.
Hidden RESET_AT is observed with native final 15,reliable 7, prefix 3 before parent
admission. Exactly 4 payload bytes precede the reset callback and final payload
12 is charged once, including its 8-byte final gap. Visible reset before
admission causes no consumer open and retains future4 for later admission.

Native scheduling time remains synthetic; App expiry uses real awake time.
The 17-case cohort includes the prior nine lifecycle cases, five callback/policy
cases and three reset cases. One prior parent case is strengthened, not counted
as a new case. Ordinary header/datagram regression has its separate 33 tests.

## Package and remaining work

app/ retains exact fixture/program inputs. native-source/ and libxev-source/
retain exact tracked source. Full native history is already in repository
benchmarks/results/webtransport_child_lifecycle_v1/2026_11_16/raw_evidence_archive.tgz
(SHA256 3e27ce7137f3791cf977d0b4c83bee4ea72c873b1af125c3a13616695b2a8418).
Its complete bundle was cloned and fscked offline in that checkpoint. This
change does not modify a native commit, dependency view, build graph or C ABI.
Actual hpack remains fda48e02491d865cce00612be8cc10c2622b8e55, distinct from
native gitlink cf0f70dd10b352194c97448eb5d00b4aa484f531; qpack 91567706c41c0d97ab8dc576873ecd472d7869fa matches.
Pinned package manifests and previous dependency metadata are retained.
Use Zig 0.16.0 and real Linux loopback/io_uring permissions with replay.sh.

Public child I/O/TX, outgoing application streams, positive/multi-session flow
accounting, independent draft-16 client acceptance and maintained-fork
publication/pins remain full-goal work. Other v2.3.0 allocation, performance,
platform and release requirements remain recorded in tasks/todo.md. Dedicated
smoke/security/sanitizer/fuzz campaigns remain user-deferred. No release or
full-goal completion is claimed by this private receive checkpoint.

The independently extracted source snapshot also replays all 17 Debug cases
(exit 0,16/16 steps), retained in evidence/relocated-replay-Debug.log. The initial
envelope SHA256 was 313508a377953eb2f53e99e5e17cf9b70e4cd321a21869dccc4f06bb35ddc09a.
The final envelope adds only this note and replay result; all262 program inputs
and the dependency snapshots remain identical.
