# Independent review evidence

The lifetime reviewer found early terminal-read publication and stranded
already-cancelled children after rejected SETTINGS; both were fixed and
re-reviewed. Deferred STOP notifications and accepted-final-size preservation
were also re-reviewed. An independent API review of the full child proposal
found forbidden control/response placements, premature waiting for a second
varint, and GOAWAY HTTP-rejection interactions. Genuine regressions reproduced
each required issue. Final re-review found no remaining required defect in the
reviewed delta. Reviewers were read-only and ran no builds or scans.

Final reviewed hashes:
stream.c cc2915c5608e3ca355f1ba45a015be6c04a455ddce4198047dee926a0e8072f7
full_conn_ietf.c 97778d923b647c492e49d185b2e3b837127c267a61197dc08d8a124d74f0864e
hcsi_reader.c 6e920189cc851b14a02b0140fa37d13c1aa1b1b5ddbdd4648e98e3578ad2e1c7
hcsi_reader.h 6b397ee6b0e859fdae0905f3ad17f837b9276d6135bc1edd395bdd9606f75d1b
normal fixture 481e400f376f7127e7442de8ae21dadcca4e638115caf7420a86889860938667
reset fixture 809697d45539ebb49f00d9744477d820249cd1b5578df8b886bb20d4320fa84d
classification fixture 2385d86dcb8055368e00141141a2820ecbf71fe2b87e493412c5a2139e09c9f1
frame fixture 12194cbebd03357ce3028ed658492917c8ed86f7f15d3ac7c06d28c9524f635d

The larger raw fixtures were reviewed as cohesive bounded TLS oracles; helper
reuse avoids duplicated endpoint setup. No mechanical line-count split was
required. Final aggregate gates are root-run evidence, not reviewer execution.
