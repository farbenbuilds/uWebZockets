# Native WebTransport child functional slice

Restore the prior child checkpoint a1947ce3a4ceeb98413e53014cc87f72b6d89869
from its archive chain first. Verify this incremental Git bundle, fetch HEAD
and check out 2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c. The bundle retains two subsequent
commits: callback/final-size lifecycle fixes, then placement and GOAWAY fixes.
Verify proposal-inputs.sha256 at the restored checkout. source/ also retains
all files changed since the stream-credit base for convenient inspection.
This is an unpublished proposal archive, never a production overlay.

Use Zig 0.16 and the retained native-scaffold exact dependencies. Relocate
-Dlsquic-source, -Dfixture, -Dfixture-includes and -Dfixture-support in the
original commands. Fixtures need their matching shared headers. The external
run-streams.py has hard-coded scratch paths to relocate; its process exit
status is not the cohort result. Inspect each record's native exit and log.
Set ulimit -c 0. The final matrix uses actual encrypted engines and no settings
observer; full upstream/cross gates disable fixture hooks and observer.

reviewed-child-matrix.json has twelve successful commands: normal 8 + reset 12
+ classification 33 + placement 12 in Debug, ReleaseSafe and ReleaseFast, totaling 195
scenario executions. reviewed-child-gates.json separately retains all 83
upstream Debug cases (165/165 steps) and Windows GNU/macOS ARM64 production
library compilation (9/9 each). Foreign compilation is not runtime proof.
All final command input hashes were compared with the frozen source before
committing. Earlier logs retain genuine REDs, intermediate fixes and setup
failures; historical-input-map.json explicitly lists unavailable intermediate
source versions. Only the complete final tree is claimed reproducible.

The GOAWAY child regression uses admitted CONNECT 0, typed child 4 and genuine
held encrypted packets; actual cutoff 0 is observed through the public native
logger, whose callback omits it. The queued ordinary GET regression observes
real server error 0x10b before releasing held GOAWAY. The zero-frame+FIN boundary case
uses a live HTTP-awaiting-headers sibling and makes no WT-session claim.
An early cleanup failure used invalid log level warning; corrected warn keeps
the assertion. An initial GOAWAY edit reached only the legacy handler; that
edit was reverted and the modern v1/v2 handler was fixed before final gates.

ABI compiler constants and immutable header inputs are under abi/. Their 30
successful probes cover Linux x86_64, Windows GNU x86_64 and macOS ARM64; earlier
Windows attempts missing WIN32 are retained as setup diagnostics. Old callback
offsets remain unchanged, but stream_if grows from 128 to 136 bytes and private stream grows
8 bytes; consumers and library must rebuild together. stream_info occupies 24 bytes.
Subsequent parser edits add no layout-bearing fields; the new reader flag uses
its existing 8-bit field. Full IETF connection size was not measured.

Native child-specific loss campaigns, asymmetric resumed limits, independent
draft-16 acceptance, bounded Zig runtime integration and maintained-fork
publication/pin updates remain open. Root capability bits stay unchanged.
Smoke/security/SAN/fuzz/scan runs remain deferred. The default root test target
was attempted while checkpointing and invoked a C ABI smoke that failed; that
run was terminated and is not a passing root test result. No subsequent root
smoke retry was performed. The native gates above do not replace root gates.

Caches, binaries and generated fixture private keys are excluded. ABI LLVM IR
is retained compiler evidence. prior-credit-final-gates.json preserves the
original command manifest omitted from the older credit archive, whose raw
logs were already retained. files.sha256 covers every payload file except
itself. This slice does not complete WebTransport or v2.3.0.
