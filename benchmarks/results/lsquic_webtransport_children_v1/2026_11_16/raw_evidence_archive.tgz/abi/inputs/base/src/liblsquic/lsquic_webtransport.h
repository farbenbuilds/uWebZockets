/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#ifndef LSQUIC_WEBTRANSPORT_H
#define LSQUIC_WEBTRANSPORT_H

#include "lsquic.h"
#include "lsquic_hq.h"

enum lsquic_wt_setting_status {
    LSQUIC_WT_SETTING_UNKNOWN = 0,
    LSQUIC_WT_SETTING_APPLIED = 1,
    LSQUIC_WT_SETTING_INVALID = -1,
};

/* Seen bits are separate from values so duplicate zero values are rejected. */
static inline enum lsquic_wt_setting_status
lsquic_wt_setting_apply (struct lsquic_webtransport_peer *peer, unsigned *seen,
                        uint64_t id, uint64_t value)
{
    uint64_t *field = NULL;
    uint64_t maximum = 1;
    unsigned flag = 0, bit;

    switch (id)
    {
    case HQSID_WT_ENABLED:
        flag = bit = LSQUIC_WTP_WT_ENABLED;
        break;
    case HQSID_ENABLE_CONNECT_PROTOCOL:
        flag = bit = LSQUIC_WTP_CONNECT;
        break;
    case HQSID_H3_DATAGRAM:
        flag = bit = LSQUIC_WTP_H3_DATAGRAM;
        break;
    case HQSID_WT_INITIAL_MAX_DATA:
        field = &peer->initial_max_data;
        maximum = (UINT64_C(1) << 62) - 1;
        bit = 1U << 3;
        break;
    case HQSID_WT_INITIAL_MAX_STREAMS_BIDI:
        field = &peer->initial_max_streams_bidi;
        maximum = UINT64_C(1) << 60;
        bit = 1U << 4;
        break;
    case HQSID_WT_INITIAL_MAX_STREAMS_UNI:
        field = &peer->initial_max_streams_uni;
        maximum = UINT64_C(1) << 60;
        bit = 1U << 5;
        break;
    default:
        return LSQUIC_WT_SETTING_UNKNOWN;
    }
    if ((*seen & bit) || value > maximum)
        return LSQUIC_WT_SETTING_INVALID;

    if (flag)
        peer->flags = (peer->flags & ~flag) | (value ? flag : 0);
    else
        *field = value;
    *seen |= bit;
    return LSQUIC_WT_SETTING_APPLIED;
}


/* Replace actual TP support; remembered support cannot survive its removal. */
static inline void
lsquic_wt_peer_set_transport (struct lsquic_webtransport_peer *peer,
                             unsigned datagrams, unsigned reliable_reset)
{
    peer->flags &= ~(LSQUIC_WTP_QUIC_DATAGRAM|LSQUIC_WTP_RELIABLE_RESET);
    if (datagrams)
        peer->flags |= LSQUIC_WTP_QUIC_DATAGRAM;
    if (reliable_reset)
        peer->flags |= LSQUIC_WTP_RELIABLE_RESET;
}

#endif
