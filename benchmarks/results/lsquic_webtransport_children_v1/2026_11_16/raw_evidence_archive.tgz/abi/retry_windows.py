import json, os, re, shlex, subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
zig='/tmp/zig-x86_64-linux-0.16.0/zig'
env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(root/'zig-global-cache'),ZIG_LOCAL_CACHE_DIR=str(root/'zig-local-cache'))
commands=json.loads((root/'commands.json').read_text())
results=json.loads((root/'results.json').read_text())
for label in ['base','current']:
    for scope in ['public','private']:
        for profile,defines in {'default':[],'legacy_wt':['-DLSQUIC_WEBTRANSPORT_SERVER_SUPPORT=1'],'no_history':['-DLSQUIC_KEEP_STREAM_HISTORY=0']}.items():
            if scope=='public' and profile=='no_history': continue
            name=f'{label}-x86_64-windows-gnu-{scope}-{profile}-win32'
            snap=root/'inputs'/label
            argv=[zig,'cc','-target','x86_64-windows-gnu','-DWIN32=1','-std=c11','-S','-emit-llvm','-O0','-g0','-fno-sanitize=all','-I'+str(snap/'include'),'-I'+str(snap/'src/liblsquic'),'-I'+str(snap/'wincompat')]+defines
            if label=='current': argv+=['-DABI_CURRENT=1']
            argv += [str(root/(scope+'_probe.c')),'-o',str(root/(name+'.ll'))]
            done=subprocess.run(argv,env=env,capture_output=True,text=True)
            (root/(name+'.stdout')).write_text(done.stdout)
            (root/(name+'.stderr')).write_text(done.stderr)
            commands.append({'argv':argv,'cwd':str(root),'exit_code':done.returncode,'stdout':name+'.stdout','stderr':name+'.stderr'})
            constants={}
            if done.returncode==0:
                constants={k:int(v) for k,v in re.findall(r'@abi_(\w+) = [^\n]*?constant i64 (\d+)',(root/(name+'.ll')).read_text())}
            results.append({'tree':label,'target':'x86_64-windows-gnu','scope':scope,'profile':profile,'exit_code':done.returncode,'constants':constants,'ir':name+'.ll','diagnostics':name+'.stderr'})
            print(name,'OK '+str(len(constants))+' constants' if done.returncode==0 else 'FAILED '+done.stderr[:1300],flush=True)
(root/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(root/'results.json').write_text(json.dumps(results,indent=2)+'\n')
(root/'commands.sh').write_text('#!/bin/sh\nset -eu\n'+''.join(f'export {k}={shlex.quote(env[k])}\n' for k in ['ZIG_GLOBAL_CACHE_DIR','ZIG_LOCAL_CACHE_DIR'])+'\n'.join((f'(cd {shlex.quote(x["cwd"])} && '+shlex.join(x['argv'])+')') for x in commands)+'\n')
