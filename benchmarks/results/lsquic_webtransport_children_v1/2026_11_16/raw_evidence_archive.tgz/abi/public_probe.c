#include <stddef.h>
#include <stdint.h>
#include "lsquic.h"
const unsigned long long abi_pointer_sizeof = sizeof(void *);
const unsigned long long abi_pointer_alignof = _Alignof(void *);
const unsigned long long abi_unsigned_sizeof = sizeof(unsigned);
const unsigned long long abi_unsigned_alignof = _Alignof(unsigned);
const unsigned long long abi_stream_if_sizeof = sizeof(struct lsquic_stream_if);
const unsigned long long abi_stream_if_alignof = _Alignof(struct lsquic_stream_if);
const unsigned long long abi_stream_if_on_new_conn_offset = offsetof(struct lsquic_stream_if, on_new_conn);
const unsigned long long abi_stream_if_on_goaway_received_offset = offsetof(struct lsquic_stream_if, on_goaway_received);
const unsigned long long abi_stream_if_on_conn_closed_offset = offsetof(struct lsquic_stream_if, on_conn_closed);
const unsigned long long abi_stream_if_on_new_stream_offset = offsetof(struct lsquic_stream_if, on_new_stream);
const unsigned long long abi_stream_if_on_read_offset = offsetof(struct lsquic_stream_if, on_read);
const unsigned long long abi_stream_if_on_write_offset = offsetof(struct lsquic_stream_if, on_write);
const unsigned long long abi_stream_if_on_close_offset = offsetof(struct lsquic_stream_if, on_close);
const unsigned long long abi_stream_if_on_dg_write_offset = offsetof(struct lsquic_stream_if, on_dg_write);
const unsigned long long abi_stream_if_on_datagram_offset = offsetof(struct lsquic_stream_if, on_datagram);
const unsigned long long abi_stream_if_on_hsk_done_offset = offsetof(struct lsquic_stream_if, on_hsk_done);
const unsigned long long abi_stream_if_on_new_token_offset = offsetof(struct lsquic_stream_if, on_new_token);
const unsigned long long abi_stream_if_on_sess_resume_info_offset = offsetof(struct lsquic_stream_if, on_sess_resume_info);
const unsigned long long abi_stream_if_on_reset_offset = offsetof(struct lsquic_stream_if, on_reset);
const unsigned long long abi_stream_if_on_conncloseframe_received_offset = offsetof(struct lsquic_stream_if, on_conncloseframe_received);
const unsigned long long abi_stream_if_on_hset_in_offset = offsetof(struct lsquic_stream_if, on_hset_in);
const unsigned long long abi_stream_if_on_h3_settings_offset = offsetof(struct lsquic_stream_if, on_h3_settings);
#ifdef ABI_CURRENT
const unsigned long long abi_stream_if_on_webtransport_stream_offset = offsetof(struct lsquic_stream_if, on_webtransport_stream);
const unsigned long long abi_stream_info_sizeof = sizeof(struct lsquic_webtransport_stream_info);
const unsigned long long abi_stream_info_alignof = _Alignof(struct lsquic_webtransport_stream_info);
const unsigned long long abi_stream_info_session_id_offset = offsetof(struct lsquic_webtransport_stream_info, session_id);
const unsigned long long abi_stream_info_send_prefix_size_offset = offsetof(struct lsquic_webtransport_stream_info, send_prefix_size);
const unsigned long long abi_stream_info_receive_prefix_size_offset = offsetof(struct lsquic_webtransport_stream_info, receive_prefix_size);
const unsigned long long abi_stream_info_flags_offset = offsetof(struct lsquic_webtransport_stream_info, flags);
const unsigned long long abi_stream_kind_sizeof = sizeof(enum lsquic_webtransport_stream_kind);
const unsigned long long abi_stream_kind_alignof = _Alignof(enum lsquic_webtransport_stream_kind);
const unsigned long long abi_stream_flags_sizeof = sizeof(enum lsquic_webtransport_stream_flags);
const unsigned long long abi_stream_flags_alignof = _Alignof(enum lsquic_webtransport_stream_flags);
#endif
const unsigned long long abi_peer_sizeof = sizeof(struct lsquic_webtransport_peer);
const unsigned long long abi_peer_alignof = _Alignof(struct lsquic_webtransport_peer);
const unsigned long long abi_peer_initial_max_data_offset = offsetof(struct lsquic_webtransport_peer, initial_max_data);
const unsigned long long abi_peer_initial_max_streams_bidi_offset = offsetof(struct lsquic_webtransport_peer, initial_max_streams_bidi);
const unsigned long long abi_peer_initial_max_streams_uni_offset = offsetof(struct lsquic_webtransport_peer, initial_max_streams_uni);
const unsigned long long abi_peer_flags_offset = offsetof(struct lsquic_webtransport_peer, flags);
const unsigned long long abi_wt_settings_sizeof = sizeof(struct lsquic_webtransport_settings);
const unsigned long long abi_wt_settings_alignof = _Alignof(struct lsquic_webtransport_settings);
const unsigned long long abi_wt_settings_initial_max_data_offset = offsetof(struct lsquic_webtransport_settings, initial_max_data);
const unsigned long long abi_wt_settings_initial_max_streams_bidi_offset = offsetof(struct lsquic_webtransport_settings, initial_max_streams_bidi);
const unsigned long long abi_wt_settings_initial_max_streams_uni_offset = offsetof(struct lsquic_webtransport_settings, initial_max_streams_uni);
const unsigned long long abi_wt_settings_enabled_offset = offsetof(struct lsquic_webtransport_settings, enabled);
const unsigned long long abi_engine_settings_sizeof = sizeof(struct lsquic_engine_settings);
const unsigned long long abi_engine_settings_alignof = _Alignof(struct lsquic_engine_settings);
const unsigned long long abi_engine_settings_es_versions_offset = offsetof(struct lsquic_engine_settings, es_versions);
const unsigned long long abi_engine_settings_es_max_batch_size_offset = offsetof(struct lsquic_engine_settings, es_max_batch_size);
const unsigned long long abi_engine_settings_es_max_udp_payload_size_rx_offset = offsetof(struct lsquic_engine_settings, es_max_udp_payload_size_rx);
const unsigned long long abi_engine_settings_es_preferred_address_offset = offsetof(struct lsquic_engine_settings, es_preferred_address);
const unsigned long long abi_engine_settings_es_qpack_enc_max_size_offset = offsetof(struct lsquic_engine_settings, es_qpack_enc_max_size);
const unsigned long long abi_engine_settings_es_webtransport_offset = offsetof(struct lsquic_engine_settings, es_webtransport);
#if LSQUIC_WEBTRANSPORT_SERVER_SUPPORT
const unsigned long long abi_engine_settings_es_webtransport_server_offset = offsetof(struct lsquic_engine_settings, es_webtransport_server);
const unsigned long long abi_engine_settings_es_max_webtransport_server_streams_offset = offsetof(struct lsquic_engine_settings, es_max_webtransport_server_streams);
#endif
