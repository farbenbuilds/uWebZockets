import datetime, hashlib, json, os, re, shlex, shutil, subprocess
from pathlib import Path
ROOT = Path(__file__).resolve().parent
ZIG = '/tmp/zig-x86_64-linux-0.16.0/zig'
TREES = {'base': Path('/tmp/uwz-lsquic-wt-children-20261113'), 'current': Path('/tmp/uwz-lsquic-wt-streams-20261113')}
TARGETS = ['x86_64-linux-gnu', 'x86_64-windows-gnu', 'aarch64-macos-none']
ENV = dict(os.environ, ZIG_GLOBAL_CACHE_DIR=str(ROOT/'zig-global-cache'), ZIG_LOCAL_CACHE_DIR=str(ROOT/'zig-local-cache'))
COMMANDS = []
def run(argv, name, cwd=None):
    result = subprocess.run(argv, cwd=cwd, env=ENV, capture_output=True, text=True)
    (ROOT/(name+'.stdout')).write_text(result.stdout)
    (ROOT/(name+'.stderr')).write_text(result.stderr)
    COMMANDS.append({'argv':argv, 'cwd':str(cwd or ROOT), 'exit_code':result.returncode, 'stdout':name+'.stdout', 'stderr':name+'.stderr'})
    return result

def abi(name, expression):
    return f'const unsigned long long abi_{name} = {expression};\n'
def layout(type_name, ctype, fields=()):
    s=abi(type_name+'_sizeof', f'sizeof({ctype})')
    s+=abi(type_name+'_alignof', f'_Alignof({ctype})')
    for field in fields:
        s+=abi(type_name+'_'+field+'_offset', f'offsetof({ctype}, {field})')
    return s

inputs={'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'trees':{}, 'zig':run([ZIG,'version'],'zig-version').stdout.strip(), 'environment_overrides':{k:ENV[k] for k in ['ZIG_GLOBAL_CACHE_DIR','ZIG_LOCAL_CACHE_DIR']}}
for label, tree in TREES.items():
    dst=ROOT/'inputs'/label
    manifest={}
    for subdir in ['include','src/liblsquic','wincompat']:
        for path in sorted((tree/subdir).rglob('*.h')):
            rel=path.relative_to(tree)
            output=dst/rel
            output.parent.mkdir(parents=True, exist_ok=True)
            data=path.read_bytes()
            output.write_bytes(data)
            manifest[str(rel)]=hashlib.sha256(data).hexdigest()
    # Keep the containing C declaration available for future independent reproduction.
    source=tree/'src/liblsquic/lsquic_full_conn_ietf.c'
    data=source.read_bytes()
    (dst/'src/liblsquic/lsquic_full_conn_ietf.c').write_bytes(data)
    manifest['src/liblsquic/lsquic_full_conn_ietf.c']=hashlib.sha256(data).hexdigest()
    inputs['trees'][label]={'source':str(tree), 'head':run(['git','rev-parse','HEAD'],label+'-head',tree).stdout.strip(), 'status':run(['git','status','--porcelain=v1'],label+'-status',tree).stdout, 'snapshot_sha256':manifest}
    (ROOT/(label+'-header-diff.patch')).write_text(run(['git','diff','9f0088c58fe67cccf1871dc172c90c2ec6f97944','--','include/lsquic.h','src/liblsquic/lsquic_stream.h','src/liblsquic/lsquic_conn.h','src/liblsquic/lsquic_conn_public.h'],label+'-header-diff',tree).stdout)
(ROOT/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')

public_includes='#include <stddef.h>\n#include <stdint.h>\n#include "lsquic.h"\n'
public=public_includes
public+=layout('pointer','void *')
public+=layout('unsigned','unsigned')
public+=layout('stream_if','struct lsquic_stream_if',['on_new_conn','on_goaway_received','on_conn_closed','on_new_stream','on_read','on_write','on_close','on_dg_write','on_datagram','on_hsk_done','on_new_token','on_sess_resume_info','on_reset','on_conncloseframe_received','on_hset_in','on_h3_settings'])
public+='#ifdef ABI_CURRENT\n'+abi('stream_if_on_webtransport_stream_offset','offsetof(struct lsquic_stream_if, on_webtransport_stream)')
public+=layout('stream_info','struct lsquic_webtransport_stream_info',['session_id','send_prefix_size','receive_prefix_size','flags'])
public+=layout('stream_kind','enum lsquic_webtransport_stream_kind')+layout('stream_flags','enum lsquic_webtransport_stream_flags')
public+='#endif\n'
public+=layout('peer','struct lsquic_webtransport_peer',['initial_max_data','initial_max_streams_bidi','initial_max_streams_uni','flags'])
public+=layout('wt_settings','struct lsquic_webtransport_settings',['initial_max_data','initial_max_streams_bidi','initial_max_streams_uni','enabled'])
public+=layout('engine_settings','struct lsquic_engine_settings',['es_versions','es_max_batch_size','es_max_udp_payload_size_rx','es_preferred_address','es_qpack_enc_max_size','es_webtransport'])
public+='#if LSQUIC_WEBTRANSPORT_SERVER_SUPPORT\n'+abi('engine_settings_es_webtransport_server_offset','offsetof(struct lsquic_engine_settings, es_webtransport_server)')+abi('engine_settings_es_max_webtransport_server_streams_offset','offsetof(struct lsquic_engine_settings, es_max_webtransport_server_streams)')+'#endif\n'
private=public_includes
private+='''#include <sys/queue.h>
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_hash.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_stream.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_conn_public.h"
#include "lsquic_conn.h"
'''
private+=layout('stream','struct lsquic_stream',['id','stream_flags','sm_bflags','sm_qflags','n_unacked','stream_if','st_ctx','conn_pub','tosend_off','sm_reset_stop_error','data_in','read_offset','fc','sm_hq_frame_arr','sm_hq_filter','sm_cont_len','sm_has_frame'])
private+='#ifdef ABI_CURRENT\n'+abi('stream_sm_wt_session_id_offset','offsetof(struct lsquic_stream, sm_wt_session_id)')+abi('stream_sm_wt_prefix_size_offset','offsetof(struct lsquic_stream, sm_wt_prefix_size)')+'#endif\n'
private+='#if LSQUIC_KEEP_STREAM_HISTORY\n'+abi('stream_sm_hist_idx_offset','offsetof(struct lsquic_stream, sm_hist_idx)')+abi('stream_sm_hist_buf_offset','offsetof(struct lsquic_stream, sm_hist_buf)')+'#endif\n'
private+='#if LSQUIC_WEBTRANSPORT_SERVER_SUPPORT\n'+abi('stream_legacy_session_offset','offsetof(struct lsquic_stream, webtransport_session_stream_id)')+'#endif\n'
private+=layout('conn','struct lsquic_conn',['cn_enc_session','cn_if','cn_conn_ctx','cn_flags'])
private+=layout('conn_iface','struct conn_iface')
private+=layout('conn_public','struct lsquic_conn_public',['all_streams','lconn','cp_flags','send_ctl','bytes_in','n_special_streams'])
(ROOT/'public_probe.c').write_text(public)
(ROOT/'private_probe.c').write_text(private)
results=[]
# LLVM initializers measure layout without linking or executing target code.
profiles={'default':[], 'legacy_wt':['-DLSQUIC_WEBTRANSPORT_SERVER_SUPPORT=1'], 'no_history':['-DLSQUIC_KEEP_STREAM_HISTORY=0']}
for target in TARGETS:
    for label in TREES:
        for scope in ['public','private']:
            for profile, defines in profiles.items():
                if scope=='public' and profile=='no_history': continue
                name=f'{label}-{target}-{scope}-{profile}'
                snap=ROOT/'inputs'/label
                argv=[ZIG,'cc','-target',target,'-std=c11','-S','-emit-llvm','-O0','-g0','-fno-sanitize=all','-I'+str(snap/'include'),'-I'+str(snap/'src/liblsquic'),'-I'+str(snap/'wincompat')]
                argv+=defines
                if label=='current': argv+=['-DABI_CURRENT=1']
                argv += [str(ROOT/(scope+'_probe.c')),'-o',str(ROOT/(name+'.ll'))]
                completed=run(argv,name)
                constants={}
                if completed.returncode==0:
                    ir=(ROOT/(name+'.ll')).read_text()
                    constants={key:int(value) for key,value in re.findall(r'@abi_(\w+) = [^\n]*?constant i64 (\d+)',ir)}
                results.append({'tree':label,'target':target,'scope':scope,'profile':profile,'exit_code':completed.returncode,'constants':constants,'ir':name+'.ll','diagnostics':name+'.stderr'})
                print(name, 'OK '+str(len(constants))+' constants' if completed.returncode==0 else 'FAILED '+completed.stderr[:500],flush=True)
(ROOT/'commands.json').write_text(json.dumps(COMMANDS,indent=2)+'\n')
(ROOT/'commands.sh').write_text('#!/bin/sh\nset -eu\n'+''.join(f'export {k}={shlex.quote(ENV[k])}\n' for k in ['ZIG_GLOBAL_CACHE_DIR','ZIG_LOCAL_CACHE_DIR'])+'\n'.join((f'(cd {shlex.quote(x["cwd"])} && '+shlex.join(x['argv'])+')') for x in COMMANDS)+'\n')
(ROOT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
