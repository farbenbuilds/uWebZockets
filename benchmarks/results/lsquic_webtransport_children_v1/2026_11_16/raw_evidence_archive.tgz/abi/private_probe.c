#include <stddef.h>
#include <stdint.h>
#include "lsquic.h"
#include <sys/queue.h>
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_hash.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_stream.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_conn_public.h"
#include "lsquic_conn.h"
const unsigned long long abi_stream_sizeof = sizeof(struct lsquic_stream);
const unsigned long long abi_stream_alignof = _Alignof(struct lsquic_stream);
const unsigned long long abi_stream_id_offset = offsetof(struct lsquic_stream, id);
const unsigned long long abi_stream_stream_flags_offset = offsetof(struct lsquic_stream, stream_flags);
const unsigned long long abi_stream_sm_bflags_offset = offsetof(struct lsquic_stream, sm_bflags);
const unsigned long long abi_stream_sm_qflags_offset = offsetof(struct lsquic_stream, sm_qflags);
const unsigned long long abi_stream_n_unacked_offset = offsetof(struct lsquic_stream, n_unacked);
const unsigned long long abi_stream_stream_if_offset = offsetof(struct lsquic_stream, stream_if);
const unsigned long long abi_stream_st_ctx_offset = offsetof(struct lsquic_stream, st_ctx);
const unsigned long long abi_stream_conn_pub_offset = offsetof(struct lsquic_stream, conn_pub);
const unsigned long long abi_stream_tosend_off_offset = offsetof(struct lsquic_stream, tosend_off);
const unsigned long long abi_stream_sm_reset_stop_error_offset = offsetof(struct lsquic_stream, sm_reset_stop_error);
const unsigned long long abi_stream_data_in_offset = offsetof(struct lsquic_stream, data_in);
const unsigned long long abi_stream_read_offset_offset = offsetof(struct lsquic_stream, read_offset);
const unsigned long long abi_stream_fc_offset = offsetof(struct lsquic_stream, fc);
const unsigned long long abi_stream_sm_hq_frame_arr_offset = offsetof(struct lsquic_stream, sm_hq_frame_arr);
const unsigned long long abi_stream_sm_hq_filter_offset = offsetof(struct lsquic_stream, sm_hq_filter);
const unsigned long long abi_stream_sm_cont_len_offset = offsetof(struct lsquic_stream, sm_cont_len);
const unsigned long long abi_stream_sm_has_frame_offset = offsetof(struct lsquic_stream, sm_has_frame);
#ifdef ABI_CURRENT
const unsigned long long abi_stream_sm_wt_session_id_offset = offsetof(struct lsquic_stream, sm_wt_session_id);
const unsigned long long abi_stream_sm_wt_prefix_size_offset = offsetof(struct lsquic_stream, sm_wt_prefix_size);
#endif
#if LSQUIC_KEEP_STREAM_HISTORY
const unsigned long long abi_stream_sm_hist_idx_offset = offsetof(struct lsquic_stream, sm_hist_idx);
const unsigned long long abi_stream_sm_hist_buf_offset = offsetof(struct lsquic_stream, sm_hist_buf);
#endif
#if LSQUIC_WEBTRANSPORT_SERVER_SUPPORT
const unsigned long long abi_stream_legacy_session_offset = offsetof(struct lsquic_stream, webtransport_session_stream_id);
#endif
const unsigned long long abi_conn_sizeof = sizeof(struct lsquic_conn);
const unsigned long long abi_conn_alignof = _Alignof(struct lsquic_conn);
const unsigned long long abi_conn_cn_enc_session_offset = offsetof(struct lsquic_conn, cn_enc_session);
const unsigned long long abi_conn_cn_if_offset = offsetof(struct lsquic_conn, cn_if);
const unsigned long long abi_conn_cn_conn_ctx_offset = offsetof(struct lsquic_conn, cn_conn_ctx);
const unsigned long long abi_conn_cn_flags_offset = offsetof(struct lsquic_conn, cn_flags);
const unsigned long long abi_conn_iface_sizeof = sizeof(struct conn_iface);
const unsigned long long abi_conn_iface_alignof = _Alignof(struct conn_iface);
const unsigned long long abi_conn_public_sizeof = sizeof(struct lsquic_conn_public);
const unsigned long long abi_conn_public_alignof = _Alignof(struct lsquic_conn_public);
const unsigned long long abi_conn_public_all_streams_offset = offsetof(struct lsquic_conn_public, all_streams);
const unsigned long long abi_conn_public_lconn_offset = offsetof(struct lsquic_conn_public, lconn);
const unsigned long long abi_conn_public_cp_flags_offset = offsetof(struct lsquic_conn_public, cp_flags);
const unsigned long long abi_conn_public_send_ctl_offset = offsetof(struct lsquic_conn_public, send_ctl);
const unsigned long long abi_conn_public_bytes_in_offset = offsetof(struct lsquic_conn_public, bytes_in);
const unsigned long long abi_conn_public_n_special_streams_offset = offsetof(struct lsquic_conn_public, n_special_streams);
