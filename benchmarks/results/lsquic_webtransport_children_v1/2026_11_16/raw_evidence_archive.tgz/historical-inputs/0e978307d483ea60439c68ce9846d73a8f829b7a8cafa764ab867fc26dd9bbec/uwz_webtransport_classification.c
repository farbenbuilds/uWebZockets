/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/queue.h>

#include <openssl/ssl.h>

#include "lsquic.h"
#include "uwz_quic_fixture.h"
#include "uwz_webtransport_fixture.h"

#ifdef NDEBUG
#error "uwz_webtransport_classification requires active assertions"
#endif

enum {
    CLASSIFY_MAX_STEPS = 20000,
    CLASSIFY_MAX_STREAMS = 16,
    CLASSIFY_CANARY = 0xA5,
    CLASSIFY_H3_NO_ERROR = 0x100,
    CLASSIFY_H3_FRAME_ERROR = 0x106,
    CLASSIFY_H3_ID_ERROR = 0x108,
};

enum classify_pending_mode {
    CLASSIFY_PENDING_NONE,
    CLASSIFY_PENDING_RESET,
    CLASSIFY_PENDING_STOP,
};

struct classify_endpoint;

struct classify_stream {
    struct classify_endpoint *cs_endpoint;
    lsquic_stream_t *cs_stream;
    lsquic_stream_id_t cs_id;
    unsigned cs_context_ready;
    unsigned cs_notifications;
    unsigned cs_fin;
    unsigned cs_closed;
    unsigned cs_reset_count;
    unsigned cs_stop_count;
    unsigned cs_read_reset;
    size_t cs_received;
    int cs_new_result;
    int cs_close_result;
    struct lsquic_webtransport_stream_info cs_new_info;
    struct lsquic_webtransport_stream_info cs_notified_info;
    struct lsquic_webtransport_stream_info cs_close_info;
    struct lsquic_stream_recv_state cs_close_recv;
    unsigned char cs_bytes[256];
};

struct classify_endpoint {
    lsquic_conn_t *ce_conn;
    uint64_t ce_expected_session;
    uint64_t ce_remote_error;
    unsigned ce_server;
    unsigned ce_raw;
    unsigned ce_handshake_ok;
    unsigned ce_settings;
    unsigned ce_stream_count;
    unsigned ce_notifications;
    unsigned ce_expected_prefix;
    unsigned ce_expected_uni;
    unsigned ce_expected_error;
    unsigned ce_read_http;
    enum classify_pending_mode ce_pending_mode;
    unsigned ce_closed;
    unsigned ce_remote_closes;
    int ce_remote_app_error;
    struct classify_stream ce_streams[CLASSIFY_MAX_STREAMS];
    struct streams_header_pool ce_headers;
};

struct classify_fixture {
    struct lsquic_test_pair cf_transport;
    struct classify_endpoint cf_client;
    struct classify_endpoint cf_server;
};

struct classify_info_probe {
    unsigned char cip_before[8];
    struct lsquic_webtransport_stream_info cip_info;
    unsigned char cip_after[8];
};

struct classify_encoding {
    const char *ce_name;
    uint64_t ce_session;
    unsigned ce_type_width;
    unsigned ce_session_width;
    unsigned ce_empty_reply;
};

static const unsigned char classify_payload[] = {
    0x41, 0, 0xFF, 0x54, 'r', 'a', 'w', 0,
};
static const unsigned char classify_reply[] = {
    0x41, 0x41, 0, 0xFE, 'r', 'e', 'p', 'l', 'y',
};
static const struct classify_encoding classify_encodings[] = {
    { "minimal", 0, 2, 1, 0 },
    { "full-width-session", UINT64_C(1) << 40, 2, 8, 1 },
    { "nonminimal-eight-byte", 4, 8, 8, 0 },
};


static int
query_info (const lsquic_stream_t *stream,
            struct lsquic_webtransport_stream_info *out)
{
    struct classify_info_probe probe;
    unsigned char before[sizeof(probe)];
    size_t index;
    int result;

    memset(&probe, CLASSIFY_CANARY, sizeof(probe));
    memcpy(before, &probe, sizeof(probe));
    result = lsquic_stream_get_webtransport_info(stream, &probe.cip_info);
    for (index = 0; index < sizeof(probe.cip_before); ++index)
        assert(probe.cip_before[index] == CLASSIFY_CANARY);
    for (index = 0; index < sizeof(probe.cip_after); ++index)
        assert(probe.cip_after[index] == CLASSIFY_CANARY);
    if (result == LSQUIC_WTS_OK)
        *out = probe.cip_info;
    else
        assert(0 == memcmp(before, &probe, sizeof(probe)));
    return result;
}


static void
assert_child_info (const struct classify_endpoint *endpoint,
                   const struct lsquic_webtransport_stream_info *info)
{
    assert(info->session_id == endpoint->ce_expected_session);
    assert(info->flags == (LSQUIC_WTSF_CHILD
                         | (endpoint->ce_expected_uni ? LSQUIC_WTSF_UNI : 0)));
    assert(info->send_prefix_size == 0);
    assert(info->receive_prefix_size == endpoint->ce_expected_prefix);
}


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct classify_endpoint *endpoint = ctx;

    assert(!endpoint->ce_conn && !endpoint->ce_closed);
    endpoint->ce_conn = conn;
    if (endpoint->ce_server)
        endpoint->ce_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct classify_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint && status == LSQ_HSK_OK);
    endpoint->ce_handshake_ok = 1;
}


static void
settings_received (lsquic_conn_t *conn)
{
    struct classify_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);
    struct lsquic_webtransport_peer peer;
    unsigned flags = LSQUIC_WTP_WT_ENABLED | LSQUIC_WTP_H3_DATAGRAM
                   | LSQUIC_WTP_QUIC_DATAGRAM | LSQUIC_WTP_RELIABLE_RESET;

    assert(endpoint && !endpoint->ce_raw && !endpoint->ce_settings);
    if (!endpoint->ce_server)
        flags |= LSQUIC_WTP_CONNECT;
    assert(LSQUIC_WTP_OK == lsquic_conn_get_webtransport_peer(conn, &peer));
    assert(peer.flags == flags);
    assert(peer.initial_max_data == 0);
    assert(peer.initial_max_streams_bidi == 0);
    assert(peer.initial_max_streams_uni == 0);
    ++endpoint->ce_settings;
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct classify_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint && endpoint->ce_conn == conn && !endpoint->ce_closed);
    endpoint->ce_conn = NULL;
    endpoint->ce_closed = 1;
    lsquic_conn_set_ctx(conn, NULL);
}


static void
remote_close (lsquic_conn_t *conn, int app_error, uint64_t error,
              const char *reason, int reason_len)
{
    struct classify_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    (void) reason;
    (void) reason_len;
    assert(endpoint && endpoint->ce_expected_error);
    if (endpoint->ce_remote_closes)
    {
        assert(endpoint->ce_remote_app_error == app_error);
        assert(endpoint->ce_remote_error == error);
    }
    endpoint->ce_remote_app_error = app_error;
    endpoint->ce_remote_error = error;
    ++endpoint->ce_remote_closes;
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct classify_endpoint *endpoint = ctx;
    struct classify_stream *state;
    unsigned outgoing;

    assert(stream && endpoint->ce_stream_count < CLASSIFY_MAX_STREAMS);
    state = &endpoint->ce_streams[endpoint->ce_stream_count++];
    state->cs_endpoint = endpoint;
    state->cs_stream = stream;
    state->cs_id = lsquic_stream_id(stream);
    state->cs_context_ready = 1;
    state->cs_new_result = query_info(stream, &state->cs_new_info);
    outgoing = (state->cs_id & 1) == endpoint->ce_server;
    if ((endpoint->ce_raw && (!(state->cs_id & 2) || !outgoing))
        || endpoint->ce_read_http)
        assert(lsquic_stream_wantread(stream, 1) >= 0);
    return (lsquic_stream_ctx_t *) state;
}


static void
webtransport_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct classify_stream *state = (void *) ctx;
    struct classify_endpoint *endpoint;

    assert(state && state->cs_stream == stream && state->cs_context_ready);
    assert(lsquic_stream_get_ctx(stream) == ctx);
    endpoint = state->cs_endpoint;
    assert(!endpoint->ce_raw && !endpoint->ce_expected_error);
    assert(!state->cs_closed && !state->cs_notifications);
    assert(!state->cs_reset_count && !state->cs_stop_count && !state->cs_read_reset);
    assert(!endpoint->ce_notifications);
    assert(LSQUIC_WTS_OK == query_info(stream, &state->cs_notified_info));
    assert_child_info(endpoint, &state->cs_notified_info);
    ++state->cs_notifications;
    ++endpoint->ce_notifications;
    assert(lsquic_stream_wantread(stream, 1) >= 0);
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct classify_stream *state = (void *) ctx;
    unsigned char bytes[64];
    ssize_t size;

    assert(state && state->cs_stream == stream && !state->cs_fin);
    while (1)
    {
        size = lsquic_stream_read(stream, bytes, sizeof(bytes));
        if (size > 0)
        {
            assert((size_t) size <= sizeof(state->cs_bytes) - state->cs_received);
            memcpy(state->cs_bytes + state->cs_received, bytes, size);
            state->cs_received += size;
            continue;
        }
        if (size < 0)
        {
            if (errno == ECONNRESET)
            {
                assert(state->cs_endpoint->ce_pending_mode == CLASSIFY_PENDING_RESET
                    && !state->cs_endpoint->ce_raw);
                assert(state->cs_notifications == 1 && state->cs_reset_count == 1);
                assert(!state->cs_read_reset && !state->cs_received);
                state->cs_read_reset = 1;
                assert(lsquic_stream_wantread(stream, 0) >= 0);
                assert(0 == lsquic_stream_shutdown(stream, 0));
                return;
            }
            assert(errno == EAGAIN || errno == EWOULDBLOCK);
            return;
        }
        state->cs_fin = 1;
        assert(lsquic_stream_wantread(stream, 0) >= 0);
        assert(0 == lsquic_stream_shutdown(stream, 0));
        return;
    }
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) stream;
    (void) ctx;
    assert(0 && "wire oracle writes through public synchronous APIs");
}


static void
close_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct classify_stream *state = (void *) ctx;

    assert(state && state->cs_stream == stream && !state->cs_closed);
    state->cs_close_result = query_info(stream, &state->cs_close_info);
    if (state->cs_endpoint->ce_pending_mode != CLASSIFY_PENDING_NONE
        && !state->cs_endpoint->ce_raw)
        assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream, &state->cs_close_recv));
    state->cs_closed = 1;
    state->cs_stream = NULL;
}


static void
stream_reset (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx, int how)
{
    struct classify_stream *state = (void *) ctx;
    struct lsquic_stream_recv_state metadata;
    struct lsquic_webtransport_stream_info info;
    struct lsquic_webtransport_peer peer;
    uint64_t error;
    unsigned known = LSQUIC_SRS_FINAL_SIZE_KNOWN | LSQUIC_SRS_RESET_KNOWN
                   | LSQUIC_SRS_RELIABLE_RESET_SEEN | LSQUIC_SRS_RESET_VISIBLE;

    assert(state && state->cs_stream == stream);
    if (state->cs_endpoint->ce_pending_mode == CLASSIFY_PENDING_STOP)
    {
        assert(!state->cs_closed);
        assert(LSQUIC_SERR_AVAILABLE == lsquic_stream_get_reset_error(stream, how, &error));
        assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream, &metadata));
        if (state->cs_endpoint->ce_raw)
        {
            assert(how == 0 && !state->cs_reset_count && !state->cs_notifications);
            assert(error == 0 && metadata.reset_error_code == 0);
            assert(metadata.final_size == 0 && metadata.reliable_size == 0);
            assert((metadata.flags & (LSQUIC_SRS_FINAL_SIZE_KNOWN
                    | LSQUIC_SRS_RESET_KNOWN | LSQUIC_SRS_RESET_VISIBLE))
                    == (LSQUIC_SRS_FINAL_SIZE_KNOWN
                    | LSQUIC_SRS_RESET_KNOWN | LSQUIC_SRS_RESET_VISIBLE));
            ++state->cs_reset_count;
            return;
        }
        assert(how == 1 && !state->cs_stop_count && !state->cs_reset_count);
        assert(state->cs_notifications == 1);
        assert(LSQUIC_WTS_OK == query_info(stream, &info));
        assert_child_info(state->cs_endpoint, &info);
        assert(error == CLASSIFY_H3_NO_ERROR);
        assert(metadata.flags & LSQUIC_SRS_STOP_SENDING_KNOWN);
        assert(metadata.stop_error_code == CLASSIFY_H3_NO_ERROR);
        ++state->cs_stop_count;
        assert(0 == lsquic_stream_shutdown(stream, 1));
        return;
    }
    if (state->cs_endpoint->ce_pending_mode == CLASSIFY_PENDING_RESET
        && !state->cs_endpoint->ce_raw)
    {
        assert(how == 0 && !state->cs_reset_count && !state->cs_read_reset);
        assert(state->cs_notifications == 1 && !state->cs_closed);
        assert(LSQUIC_WTP_OK == lsquic_conn_get_webtransport_peer(
                                        state->cs_endpoint->ce_conn, &peer));
        assert(LSQUIC_WTS_OK == query_info(stream, &info));
        assert_child_info(state->cs_endpoint, &info);
        assert(LSQUIC_SERR_AVAILABLE == lsquic_stream_get_reset_error(stream, how, &error));
        assert(error == 373);
        assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream, &metadata));
        assert((metadata.flags & known) == known);
        assert(metadata.final_size == 3 && metadata.reliable_size == 3);
        assert(metadata.reset_error_code == 373);
        ++state->cs_reset_count;
        return;
    }
    assert(state->cs_endpoint->ce_expected_error);
    assert(LSQUIC_SERR_AVAILABLE == lsquic_stream_get_reset_error(stream, how, &error));
}


static const struct lsquic_stream_if classify_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_h3_settings = settings_received,
    .on_conncloseframe_received = remote_close,
    .on_new_stream = new_stream,
    .on_webtransport_stream = webtransport_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_reset = stream_reset,
};


static void
pump_step (struct classify_fixture *fixture)
{
    lsquic_test_pair_process(&fixture->cf_transport, 1000);
    lsquic_test_deliver_all(&fixture->cf_transport.ltp_client);
    lsquic_test_deliver_all(&fixture->cf_transport.ltp_server);
}


static size_t
append_varint (unsigned char *bytes, size_t capacity, size_t offset,
               uint64_t value, unsigned width)
{
    unsigned index, tag;

    assert(width == 1 || width == 2 || width == 4 || width == 8);
    assert(value < (UINT64_C(1) << (width * 8 - 2)));
    assert(offset <= capacity && width <= capacity - offset);
    switch (width)
    {
    case 1: tag = 0; break;
    case 2: tag = 1; break;
    case 4: tag = 2; break;
    default: tag = 3; break;
    }
    for (index = 0; index < width; ++index)
        bytes[offset + width - index - 1] = (unsigned char) (value >> (index * 8));
    bytes[offset] |= tag << 6;
    return offset + width;
}


static struct classify_stream *
make_raw_stream (struct classify_endpoint *endpoint, unsigned uni)
{
    unsigned before = endpoint->ce_stream_count;
    struct classify_stream *state;

    assert(endpoint->ce_raw && endpoint->ce_conn);
    if (uni)
        assert(LSQUIC_MUS_OK == lsquic_conn_make_uni_stream(endpoint->ce_conn));
    else
        lsquic_conn_make_stream(endpoint->ce_conn);
    assert(endpoint->ce_stream_count == before + 1);
    state = &endpoint->ce_streams[before];
    assert(state->cs_stream && !!(state->cs_id & 2) == !!uni);
    assert((state->cs_id & 1) == endpoint->ce_server);
    return state;
}


static void
send_settings (struct classify_endpoint *raw)
{
    struct classify_stream *control;
    unsigned char bytes[32], payload[24];
    size_t size = 0, offset = 0;

    size = append_varint(payload, sizeof(payload), size, UINT64_C(0x2c7cf000), 4);
    size = append_varint(payload, sizeof(payload), size, 1, 1);
    size = append_varint(payload, sizeof(payload), size, 0x33, 1);
    size = append_varint(payload, sizeof(payload), size, 1, 1);
    if (raw->ce_server)
    {
        size = append_varint(payload, sizeof(payload), size, 8, 1);
        size = append_varint(payload, sizeof(payload), size, 1, 1);
    }
    offset = append_varint(bytes, sizeof(bytes), offset, 0, 1);
    offset = append_varint(bytes, sizeof(bytes), offset, 4, 1);
    offset = append_varint(bytes, sizeof(bytes), offset, size, 1);
    assert(size <= sizeof(bytes) - offset);
    memcpy(bytes + offset, payload, size);
    control = make_raw_stream(raw, 1);
    assert((ssize_t) (offset + size) == lsquic_stream_write(control->cs_stream,
                                                        bytes, offset + size));
    assert(0 == lsquic_stream_flush(control->cs_stream));
}


static void
init_endpoint (struct classify_fixture *fixture, unsigned server, unsigned raw)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct classify_endpoint *endpoint;
    struct lsquic_test_endpoint *transport, *peer;
    unsigned flags = (raw ? 0 : LSENG_HTTP) | (server ? LSENG_SERVER : 0);

    endpoint = server ? &fixture->cf_server : &fixture->cf_client;
    endpoint->ce_server = server;
    endpoint->ce_raw = raw;
    transport = server ? &fixture->cf_transport.ltp_server
                       : &fixture->cf_transport.ltp_client;
    peer = server ? &fixture->cf_transport.ltp_client
                  : &fixture->cf_transport.ltp_server;
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = 8;
    settings.es_init_max_streams_bidi = 8;
    /* Raw clients advertise uni credit through the legacy stream limit. */
    settings.es_max_streams_in = raw ? 8 : 0;
    settings.es_init_max_stream_data_bidi_local = 65536;
    settings.es_init_max_stream_data_bidi_remote = 65536;
    settings.es_init_max_stream_data_uni = 65536;
    settings.es_qpack_dec_max_size = 0;
    settings.es_qpack_dec_max_blocked = 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    settings.es_datagrams = 1;
    settings.es_reset_stream_at = 1;
    settings.es_webtransport.enabled = !raw;
    if (!raw)
    {
        settings.es_webtransport.initial_max_data = 65536;
        settings.es_webtransport.initial_max_streams_bidi = 16;
        settings.es_webtransport.initial_max_streams_uni = 16;
    }
    assert(0 == lsquic_engine_check_settings(&settings, flags, NULL, 0));
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &classify_callbacks;
    config.ltec_stream_if_ctx = endpoint;
    if (!raw)
    {
        config.ltec_hsi_if = &streams_hsi;
        config.ltec_hsi_ctx = &endpoint->ce_headers;
    }
    config.ltec_alpn = "h3";
    config.ltec_tls = lsquic_test_tls_context_new(server, "h3");
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(transport, peer, &config,
                                        server ? 12911 : 12912));
    SSL_CTX_free(config.ltec_tls);
}


static void
start_fixture (struct classify_fixture *fixture, unsigned raw_server,
               unsigned withhold_settings)
{
    struct classify_endpoint *raw, *http;
    unsigned step;

    memset(fixture, 0, sizeof(*fixture));
    init_endpoint(fixture, 0, !raw_server);
    init_endpoint(fixture, 1, raw_server);
    raw = raw_server ? &fixture->cf_server : &fixture->cf_client;
    http = raw_server ? &fixture->cf_client : &fixture->cf_server;
    assert(lsquic_engine_connect(fixture->cf_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture->cf_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture->cf_transport.ltp_server.lte_address,
                &fixture->cf_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
    for (step = 0; step < CLASSIFY_MAX_STEPS; ++step)
    {
        if (raw->ce_handshake_ok && http->ce_handshake_ok)
            break;
        pump_step(fixture);
    }
    assert(step < CLASSIFY_MAX_STEPS);
    if (withhold_settings)
    {
        for (step = 0; step < 20; ++step)
            pump_step(fixture);
        assert(raw->ce_conn && http->ce_conn && !http->ce_settings);
        assert(!http->ce_stream_count && !http->ce_notifications);
        assert(!raw->ce_notifications);
        return;
    }
    send_settings(raw);
    for (step = 0; step < CLASSIFY_MAX_STEPS && !http->ce_settings; ++step)
        pump_step(fixture);
    assert(step < CLASSIFY_MAX_STEPS);
    for (step = 0; step < 20; ++step)
        pump_step(fixture);
    assert(raw->ce_conn && http->ce_conn);
    assert(!http->ce_stream_count && !http->ce_notifications);
    assert(raw->ce_stream_count >= 2 && !raw->ce_notifications);
}


static struct classify_stream *
find_stream (struct classify_endpoint *endpoint, lsquic_stream_id_t id)
{
    unsigned index;

    for (index = 0; index < endpoint->ce_stream_count; ++index)
        if (endpoint->ce_streams[index].cs_id == id)
            return &endpoint->ce_streams[index];
    return NULL;
}


static void
send_fragment (struct classify_fixture *fixture, struct classify_stream *sender,
               const unsigned char *bytes, size_t size)
{
    struct lsquic_test_endpoint *receiver = sender->cs_endpoint->ce_server
                        ? &fixture->cf_transport.ltp_client
                        : &fixture->cf_transport.ltp_server;
    unsigned before = receiver->lte_packets_received;
    unsigned step;

    assert(sender->cs_stream && size > 0);
    assert((ssize_t) size == lsquic_stream_write(sender->cs_stream, bytes, size));
    assert(0 == lsquic_stream_flush(sender->cs_stream));
    for (step = 0; step < CLASSIFY_MAX_STEPS; ++step)
    {
        pump_step(fixture);
        if (receiver->lte_packets_received > before)
            break;
    }
    assert(step < CLASSIFY_MAX_STEPS);
    for (step = 0; step < 20; ++step)
        pump_step(fixture);
}


static void
assert_connected (const struct classify_fixture *fixture)
{
    assert(fixture->cf_client.ce_conn && fixture->cf_server.ce_conn);
    assert(!fixture->cf_client.ce_closed && !fixture->cf_server.ce_closed);
    assert(!fixture->cf_client.ce_remote_closes && !fixture->cf_server.ce_remote_closes);
    assert(LSCONN_ST_CONNECTED == lsquic_conn_status(fixture->cf_client.ce_conn, NULL, 0));
    assert(LSCONN_ST_CONNECTED == lsquic_conn_status(fixture->cf_server.ce_conn, NULL, 0));
}


static void
cleanup_fixture (struct classify_fixture *fixture)
{
    lsquic_test_endpoint_destroy(&fixture->cf_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture->cf_transport.ltp_server);
    assert(fixture->cf_client.ce_headers.shp_created
                                == fixture->cf_client.ce_headers.shp_discarded);
    assert(fixture->cf_server.ce_headers.shp_created
                                == fixture->cf_server.ce_headers.shp_discarded);
}


static void
test_prefix (unsigned raw_server, unsigned uni,
             const struct classify_encoding *encoding)
{
    struct classify_fixture fixture;
    struct classify_endpoint *raw, *http;
    struct classify_stream *outgoing, *incoming;
    struct lsquic_webtransport_stream_info info;
    unsigned char prefix[16];
    size_t size = 0, index;
    unsigned step;

    start_fixture(&fixture, raw_server, 0);
    raw = raw_server ? &fixture.cf_server : &fixture.cf_client;
    http = raw_server ? &fixture.cf_client : &fixture.cf_server;
    http->ce_expected_session = encoding->ce_session;
    http->ce_expected_uni = uni;
    http->ce_expected_prefix = encoding->ce_type_width + encoding->ce_session_width;
    size = append_varint(prefix, sizeof(prefix), size, uni ? 0x54 : 0x41,
                         encoding->ce_type_width);
    size = append_varint(prefix, sizeof(prefix), size, encoding->ce_session,
                         encoding->ce_session_width);
    assert(size == http->ce_expected_prefix && size <= 16);
    outgoing = make_raw_stream(raw, uni);
    /* Candidate classification is independent of application parent admission. */
    for (index = 0; index < size; ++index)
    {
        send_fragment(&fixture, outgoing, prefix + index, 1);
        assert_connected(&fixture);
        incoming = find_stream(http, outgoing->cs_id);
        if (index + 1 == size)
            break;
        assert(!http->ce_notifications);
        if (incoming)
        {
            assert(!incoming->cs_notifications && !incoming->cs_received);
            assert(LSQUIC_WTS_PENDING == query_info(incoming->cs_stream, &info));
        }
    }
    incoming = find_stream(http, outgoing->cs_id);
    assert(incoming && incoming->cs_stream && !incoming->cs_closed);
    assert(http->ce_notifications == 1 && incoming->cs_notifications == 1);
    assert(!incoming->cs_received && !incoming->cs_fin);
    assert(incoming->cs_new_result == LSQUIC_WTS_PENDING
        || incoming->cs_new_result == LSQUIC_WTS_OK);
    if (incoming->cs_new_result == LSQUIC_WTS_OK)
        assert_child_info(http, &incoming->cs_new_info);
    assert_child_info(http, &incoming->cs_notified_info);
    assert(LSQUIC_WTS_OK == query_info(incoming->cs_stream, &info));
    assert_child_info(http, &info);
    assert(sizeof(classify_payload) == (size_t) lsquic_stream_write(outgoing->cs_stream,
                                            classify_payload, sizeof(classify_payload)));
    assert(0 == lsquic_stream_shutdown(outgoing->cs_stream, 1));
    for (step = 0; step < CLASSIFY_MAX_STEPS && !incoming->cs_fin; ++step)
        pump_step(&fixture);
    assert(step < CLASSIFY_MAX_STEPS);
    assert(incoming->cs_received == sizeof(classify_payload));
    assert(0 == memcmp(incoming->cs_bytes, classify_payload, sizeof(classify_payload)));
    if (!uni)
    {
        assert(incoming->cs_stream && !incoming->cs_closed);
        if (!encoding->ce_empty_reply)
            assert(sizeof(classify_reply) == (size_t) lsquic_stream_write(incoming->cs_stream,
                                            classify_reply, sizeof(classify_reply)));
        assert(0 == lsquic_stream_shutdown(incoming->cs_stream, 1));
    }
    for (step = 0; step < CLASSIFY_MAX_STEPS; ++step)
    {
        if (incoming->cs_closed && outgoing->cs_closed)
            break;
        pump_step(&fixture);
    }
    assert(step < CLASSIFY_MAX_STEPS);
    assert(incoming->cs_fin && incoming->cs_notifications == 1);
    assert(incoming->cs_close_result == LSQUIC_WTS_OK);
    assert_child_info(http, &incoming->cs_close_info);
    assert(!outgoing->cs_notifications && !raw->ce_notifications);
    if (!uni)
    {
        assert(outgoing->cs_fin);
        assert(outgoing->cs_received == (encoding->ce_empty_reply ? 0 : sizeof(classify_reply)));
        if (!encoding->ce_empty_reply)
            assert(0 == memcmp(outgoing->cs_bytes, classify_reply, sizeof(classify_reply)));
    }
    assert_connected(&fixture);
    cleanup_fixture(&fixture);
    printf("PASS native prefix classification: raw-%s/%s/%s/prefix%u/bytewise SID completion/raw payload+FIN/context once/close metadata/connected\n",
           raw_server ? "server" : "client", uni ? "uni" : "bidi",
           encoding->ce_name, encoding->ce_type_width + encoding->ce_session_width);
}


static void
wait_for_error (struct classify_fixture *fixture, struct classify_endpoint *raw,
                struct classify_endpoint *http, uint64_t expected)
{
    unsigned step;

    for (step = 0; step < CLASSIFY_MAX_STEPS && !raw->ce_remote_closes; ++step)
        pump_step(fixture);
    assert(step < CLASSIFY_MAX_STEPS && raw->ce_remote_closes);
    assert(raw->ce_remote_app_error == 1 && raw->ce_remote_error == expected);
    assert(!raw->ce_notifications && !http->ce_notifications);
}


static void
test_invalid_session (unsigned raw_server, unsigned uni, uint64_t session)
{
    struct classify_fixture fixture;
    struct classify_endpoint *raw, *http;
    struct classify_stream *outgoing;
    unsigned char prefix[16];
    size_t size = 0;

    start_fixture(&fixture, raw_server, 0);
    raw = raw_server ? &fixture.cf_server : &fixture.cf_client;
    http = raw_server ? &fixture.cf_client : &fixture.cf_server;
    raw->ce_expected_error = http->ce_expected_error = 1;
    size = append_varint(prefix, sizeof(prefix), size, uni ? 0x54 : 0x41, 2);
    size = append_varint(prefix, sizeof(prefix), size, session, 1);
    outgoing = make_raw_stream(raw, uni);
    send_fragment(&fixture, outgoing, prefix, size);
    wait_for_error(&fixture, raw, http, CLASSIFY_H3_ID_ERROR);
    cleanup_fixture(&fixture);
    printf("PASS native invalid session shape: raw-%s/%s/SID%llu/H3_ID_ERROR/no typed notification\n",
           raw_server ? "server" : "client", uni ? "uni" : "bidi",
           (unsigned long long) session);
}


static void
test_late_type (void)
{
    struct classify_fixture fixture;
    struct classify_endpoint *raw, *http;
    struct classify_stream *outgoing;
    static const unsigned char unknown_frame[] = { 0x21, 0 };
    static const unsigned char late_type[] = { 0x40, 0x41, 0 };

    start_fixture(&fixture, 0, 0);
    raw = &fixture.cf_client;
    http = &fixture.cf_server;
    http->ce_read_http = 1;
    outgoing = make_raw_stream(raw, 0);
    send_fragment(&fixture, outgoing, unknown_frame, sizeof(unknown_frame));
    assert_connected(&fixture);
    assert(!http->ce_notifications);
    raw->ce_expected_error = http->ce_expected_error = 1;
    send_fragment(&fixture, outgoing, late_type, sizeof(late_type));
    wait_for_error(&fixture, raw, http, CLASSIFY_H3_FRAME_ERROR);
    cleanup_fixture(&fixture);
    puts("PASS native late WT_STREAM: client bidi/unknown zero-size first frame/H3_FRAME_ERROR/no typed notification");
}


static void
test_invalid_sessions (void)
{
    unsigned role, uni;
    uint64_t session;

    for (role = 0; role < 2; ++role)
        for (uni = 0; uni < 2; ++uni)
            for (session = 1; session <= 3; ++session)
                test_invalid_session(role, uni, session);
}


static void
test_pending_signal (unsigned raw_server, unsigned uni,
                     enum classify_pending_mode mode)
{
    struct classify_fixture fixture;
    struct classify_endpoint *raw, *http;
    struct classify_stream *outgoing, *incoming = NULL;
    struct lsquic_stream_recv_state metadata;
    struct lsquic_webtransport_stream_info info;
    struct lsquic_webtransport_peer peer;
    const unsigned char prefix[] = { 0x40, uni ? 0x54 : 0x41, 0 };
    uint64_t error = UINT64_C(0xA5A5A5A5A5A5A5A5);
    unsigned step;
    unsigned known = LSQUIC_SRS_FINAL_SIZE_KNOWN | LSQUIC_SRS_RESET_KNOWN
                   | LSQUIC_SRS_RELIABLE_RESET_SEEN;

    assert(mode == CLASSIFY_PENDING_RESET || (mode == CLASSIFY_PENDING_STOP && !uni));
    if (mode == CLASSIFY_PENDING_STOP)
        known = LSQUIC_SRS_STOP_SENDING_KNOWN;
    start_fixture(&fixture, raw_server, 1);
    raw = raw_server ? &fixture.cf_server : &fixture.cf_client;
    http = raw_server ? &fixture.cf_client : &fixture.cf_server;
    raw->ce_pending_mode = http->ce_pending_mode = mode;
    http->ce_expected_prefix = sizeof(prefix);
    http->ce_expected_uni = uni;
    outgoing = make_raw_stream(raw, uni);
    send_fragment(&fixture, outgoing, prefix, sizeof(prefix));
    incoming = find_stream(http, outgoing->cs_id);
    if (uni)
        assert(!incoming && !http->ce_stream_count);
    else
        assert(incoming && incoming->cs_stream && incoming->cs_context_ready);
    assert(!http->ce_notifications);
    if (mode == CLASSIFY_PENDING_RESET)
        assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(outgoing->cs_stream, 373, sizeof(prefix)));
    else
        assert(0 == lsquic_stream_shutdown(outgoing->cs_stream, 0));
    if (uni)
    {
        /* No public receive handle exists until the classifier publishes uni. */
        for (step = 0; step < CLASSIFY_MAX_STEPS && !outgoing->cs_closed; ++step)
        {
            pump_step(&fixture);
            assert(!http->ce_stream_count && !http->ce_notifications);
        }
        assert(step < CLASSIFY_MAX_STEPS && outgoing->cs_closed);
    }
    else
    {
        for (step = 0; step < CLASSIFY_MAX_STEPS; ++step)
        {
            pump_step(&fixture);
            assert(incoming->cs_stream && !incoming->cs_closed);
            assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(incoming->cs_stream, &metadata));
            if ((metadata.flags & known) == known)
                break;
        }
        assert(step < CLASSIFY_MAX_STEPS);
        assert((metadata.flags & known) == known);
        assert(LSQUIC_WTS_PENDING == query_info(incoming->cs_stream, &info));
        assert(!incoming->cs_notifications && !incoming->cs_reset_count
            && !incoming->cs_stop_count && !incoming->cs_read_reset);
        assert(!(metadata.flags & LSQUIC_SRS_RESET_VISIBLE));
        if (mode == CLASSIFY_PENDING_RESET)
        {
            assert(metadata.final_size == sizeof(prefix) && metadata.reliable_size == sizeof(prefix));
            assert(metadata.reset_error_code == 373);
            assert(LSQUIC_SERR_UNAVAILABLE == lsquic_stream_get_reset_error(incoming->cs_stream, 0, &error));
            assert(error == UINT64_C(0xA5A5A5A5A5A5A5A5));
        }
        else
        {
            assert(metadata.stop_error_code == CLASSIFY_H3_NO_ERROR);
            assert(!(metadata.flags & (LSQUIC_SRS_RESET_KNOWN | LSQUIC_SRS_FINAL_SIZE_KNOWN)));
            assert(metadata.final_size == 0 && metadata.reliable_size == 0);
        }
    }
    assert(LSQUIC_WTP_PENDING == lsquic_conn_get_webtransport_peer(http->ce_conn, &peer));
    assert_connected(&fixture);
    send_settings(raw);
    for (step = 0; step < CLASSIFY_MAX_STEPS; ++step)
    {
        incoming = find_stream(http, outgoing->cs_id);
        if (incoming && (mode == CLASSIFY_PENDING_RESET
                            ? incoming->cs_read_reset : incoming->cs_stop_count))
            break;
        pump_step(&fixture);
    }
    assert(step < CLASSIFY_MAX_STEPS);
    assert(http->ce_settings == 1 && http->ce_notifications == 1);
    assert(incoming->cs_notifications == 1);
    assert(!incoming->cs_received && !incoming->cs_fin);
    if (mode == CLASSIFY_PENDING_STOP)
    {
        assert(incoming->cs_stop_count == 1 && !incoming->cs_reset_count);
        assert(outgoing->cs_stream);
        assert(0 == lsquic_stream_shutdown(outgoing->cs_stream, 1));
    }
    else if (!uni)
    {
        assert(incoming->cs_stream);
        assert(0 == lsquic_stream_shutdown(incoming->cs_stream, 1));
    }
    for (step = 0; step < CLASSIFY_MAX_STEPS; ++step)
    {
        if (incoming->cs_closed && outgoing->cs_closed)
            break;
        pump_step(&fixture);
    }
    assert(step < CLASSIFY_MAX_STEPS);
    assert(incoming->cs_notifications == 1);
    assert(incoming->cs_close_result == LSQUIC_WTS_OK);
    assert_child_info(http, &incoming->cs_close_info);
    assert((incoming->cs_close_recv.flags & known) == known);
    assert(incoming->cs_close_recv.final_size == sizeof(prefix));
    assert(incoming->cs_close_recv.reliable_size == sizeof(prefix));
    if (mode == CLASSIFY_PENDING_RESET)
    {
        assert(incoming->cs_reset_count == 1 && !incoming->cs_stop_count);
        assert(incoming->cs_close_recv.flags & LSQUIC_SRS_RESET_VISIBLE);
        assert(incoming->cs_close_recv.reset_error_code == 373);
        if (!uni)
            assert(outgoing->cs_fin);
    }
    else
    {
        assert(incoming->cs_stop_count == 1 && !incoming->cs_reset_count);
        assert(incoming->cs_fin && outgoing->cs_reset_count == 1);
        assert(incoming->cs_close_recv.flags & LSQUIC_SRS_FINAL_SIZE_KNOWN);
        assert(incoming->cs_close_recv.flags & LSQUIC_SRS_FIN_RECEIVED);
        assert(!(incoming->cs_close_recv.flags & (LSQUIC_SRS_RESET_KNOWN
                    | LSQUIC_SRS_RELIABLE_RESET_SEEN | LSQUIC_SRS_RESET_VISIBLE)));
        assert(incoming->cs_close_recv.stop_error_code == CLASSIFY_H3_NO_ERROR);
        assert(!outgoing->cs_fin);
    }
    assert(!outgoing->cs_received && !outgoing->cs_notifications);
    assert(!raw->ce_notifications);
    assert_connected(&fixture);
    cleanup_fixture(&fixture);
    printf("PASS native pending SETTINGS %s: raw-%s/%s/prefix3/typed notification before %s/final3/R3/close metadata\n",
           mode == CLASSIFY_PENDING_RESET ? "reset373" : "STOP0x100",
           raw_server ? "server" : "client", uni ? "uni" : "bidi",
           mode == CLASSIFY_PENDING_RESET ? "reset0" : "reset1");
}


int
main (int argc, char **argv)
{
    unsigned all, uni_client, uni_server, bidi_client, bidi_server, invalid, late, pending;
    unsigned pending_bidi_client, pending_bidi_server, pending_uni_client, pending_uni_server;
    unsigned pending_stop, pending_stop_client, pending_stop_server;
    size_t index;

    assert(argc <= 2);
    assert(sizeof(struct lsquic_webtransport_stream_info) == 24);
    all = argc == 1 || 0 == strcmp(argv[1], "all");
    uni_client = all || 0 == strcmp(argv[1], "uni-client");
    uni_server = all || 0 == strcmp(argv[1], "uni-server");
    bidi_client = all || 0 == strcmp(argv[1], "bidi-client");
    bidi_server = all || 0 == strcmp(argv[1], "bidi-server");
    invalid = all || 0 == strcmp(argv[1], "invalid-id");
    late = all || 0 == strcmp(argv[1], "late-type");
    pending = all || 0 == strcmp(argv[1], "pending-reset");
    pending_bidi_client = pending || 0 == strcmp(argv[1], "pending-reset-bidi-client");
    pending_bidi_server = pending || 0 == strcmp(argv[1], "pending-reset-bidi-server");
    pending_uni_client = pending || 0 == strcmp(argv[1], "pending-reset-uni-client");
    pending_uni_server = pending || 0 == strcmp(argv[1], "pending-reset-uni-server");
    pending_stop = all || 0 == strcmp(argv[1], "pending-stop");
    pending_stop_client = pending_stop || 0 == strcmp(argv[1], "pending-stop-bidi-client");
    pending_stop_server = pending_stop || 0 == strcmp(argv[1], "pending-stop-bidi-server");
    assert(uni_client || uni_server || bidi_client || bidi_server || invalid || late
        || pending_bidi_client || pending_bidi_server || pending_uni_client || pending_uni_server
        || pending_stop_client || pending_stop_server);
    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    for (index = 0; index < sizeof(classify_encodings) / sizeof(classify_encodings[0]); ++index)
    {
        if (uni_client)
            test_prefix(0, 1, &classify_encodings[index]);
        if (uni_server)
            test_prefix(1, 1, &classify_encodings[index]);
        if (bidi_client)
            test_prefix(0, 0, &classify_encodings[index]);
        if (bidi_server)
            test_prefix(1, 0, &classify_encodings[index]);
    }
    if (invalid)
        test_invalid_sessions();
    if (late)
        test_late_type();
    if (pending_bidi_client)
        test_pending_signal(0, 0, CLASSIFY_PENDING_RESET);
    if (pending_bidi_server)
        test_pending_signal(1, 0, CLASSIFY_PENDING_RESET);
    if (pending_uni_client)
        test_pending_signal(0, 1, CLASSIFY_PENDING_RESET);
    if (pending_uni_server)
        test_pending_signal(1, 1, CLASSIFY_PENDING_RESET);
    if (pending_stop_client)
        test_pending_signal(0, 0, CLASSIFY_PENDING_STOP);
    if (pending_stop_server)
        test_pending_signal(1, 0, CLASSIFY_PENDING_STOP);
    lsquic_global_cleanup();
    return 0;
}
