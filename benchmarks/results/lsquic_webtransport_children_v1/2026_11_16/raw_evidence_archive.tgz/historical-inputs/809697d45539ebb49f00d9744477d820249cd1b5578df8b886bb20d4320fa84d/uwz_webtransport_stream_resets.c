/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/queue.h>

#include <openssl/ssl.h>

#include "lsquic.h"
#include "lsxpack_header.h"
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_packet_in.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"
#include "uwz_quic_fixture.h"
#include "uwz_webtransport_fixture.h"

#ifdef NDEBUG
#error "uwz_webtransport_stream_resets requires active assertions"
#endif

enum {
    STREAMS_MAX_STEPS = 20000,
    STREAMS_MAX_STREAMS = 8,
    STREAMS_CANARY = 0xA5,
};

struct streams_endpoint;

struct streams_state {
    struct streams_endpoint *ss_endpoint;
    lsquic_stream_t *ss_stream;
    lsquic_stream_id_t ss_id;
    unsigned ss_new_context;
    unsigned ss_hsets;
    unsigned ss_notifications;
    unsigned ss_callback_before_close;
    unsigned ss_fin;
    unsigned ss_closed;
    unsigned ss_local_reset;
    unsigned ss_unreset_stop;
    unsigned ss_stopped;
    unsigned ss_read_reset;
    unsigned ss_floor;
    unsigned ss_reset_events[2];
    uint64_t ss_final;
    uint64_t ss_reliable;
    uint64_t ss_errors[2];
    struct lsquic_stream_recv_state ss_close_recv;
    size_t ss_received;
    int ss_new_result;
    int ss_notification_result;
    int ss_close_result;
    struct lsquic_webtransport_stream_info ss_new_info;
    struct lsquic_webtransport_stream_info ss_notification_info;
    struct lsquic_webtransport_stream_info ss_close_info;
    unsigned char ss_bytes[128];
};

struct streams_endpoint {
    lsquic_conn_t *se_conn;
    unsigned se_server;
    unsigned se_handshake_ok;
    unsigned se_settings_count;
    unsigned se_stream_count;
    unsigned se_closed;
    unsigned se_reset_new_child;
    unsigned se_stop_child;
    unsigned se_unreset_stop;
    unsigned se_bidi_reset;
    struct streams_state se_streams[STREAMS_MAX_STREAMS];
    struct streams_header_pool se_headers;
};

struct streams_fixture {
    struct lsquic_test_pair sf_transport;
    struct streams_endpoint sf_client;
    struct streams_endpoint sf_server;
};

struct streams_info_probe {
    unsigned char sip_before[8];
    struct lsquic_webtransport_stream_info sip_info;
    unsigned char sip_after[8];
};

static const unsigned char reset_suffix[] = "frozen accepted application suffix";
static const unsigned char client_capsule[] = { 0x21, 2, 'o', 'k' };
static const unsigned char server_capsule[] = { 0x21, 2, 'h', 'i' };


static int
query_info (const lsquic_stream_t *stream, struct lsquic_webtransport_stream_info *out)
{
    struct streams_info_probe probe;
    unsigned char before[sizeof(probe)];
    size_t index;
    int result;

    memset(&probe, STREAMS_CANARY, sizeof(probe));
    memcpy(before, &probe, sizeof(probe));
    result = lsquic_stream_get_webtransport_info(stream, &probe.sip_info);
    for (index = 0; index < sizeof(probe.sip_before); ++index)
        assert(probe.sip_before[index] == STREAMS_CANARY);
    for (index = 0; index < sizeof(probe.sip_after); ++index)
        assert(probe.sip_after[index] == STREAMS_CANARY);
    if (result == LSQUIC_WTS_OK)
        *out = probe.sip_info;
    else
        assert(0 == memcmp(before, &probe, sizeof(probe)));
    return result;
}


static void
assert_bidi_child_info (const struct lsquic_webtransport_stream_info *info,
                       unsigned local)
{
    assert(info->session_id == 0);
    assert(info->flags == (LSQUIC_WTSF_CHILD | (local ? LSQUIC_WTSF_LOCAL : 0)));
    assert(info->send_prefix_size == (local ? 3U : 0U));
    assert(info->receive_prefix_size == (local ? 0U : 3U));
}


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct streams_endpoint *endpoint = ctx;

    assert(!endpoint->se_conn);
    endpoint->se_conn = conn;
    if (endpoint->se_server)
        endpoint->se_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct streams_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(status == LSQ_HSK_OK);
    endpoint->se_handshake_ok = 1;
}


static void
settings_received (lsquic_conn_t *conn)
{
    struct streams_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);
    struct lsquic_webtransport_peer peer;

    assert(endpoint && endpoint->se_conn == conn);
    ++endpoint->se_settings_count;
    assert(LSQUIC_WTP_OK == lsquic_conn_get_webtransport_peer(conn, &peer));
    assert(peer.flags == (endpoint->se_server ? 29U : 31U));
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct streams_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint && endpoint->se_conn == conn && !endpoint->se_closed);
    endpoint->se_closed = 1;
    endpoint->se_conn = NULL;
    lsquic_conn_set_ctx(conn, NULL);
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct streams_endpoint *endpoint = ctx;
    struct streams_state *state;

    assert(stream && endpoint->se_stream_count < STREAMS_MAX_STREAMS);
    state = &endpoint->se_streams[endpoint->se_stream_count++];
    state->ss_endpoint = endpoint;
    state->ss_unreset_stop = endpoint->se_unreset_stop;
    state->ss_stream = stream;
    state->ss_id = lsquic_stream_id(stream);
    state->ss_new_context = 1;
    state->ss_new_result = query_info(stream, &state->ss_new_info);
    if (!endpoint->se_reset_new_child || state->ss_id == 0
        || (state->ss_id & 1) != endpoint->se_server)
        return (lsquic_stream_ctx_t *) state;
    assert(state->ss_new_result == LSQUIC_WTS_OK);
    assert(state->ss_new_info.flags == (LSQUIC_WTSF_CHILD | LSQUIC_WTSF_LOCAL | LSQUIC_WTSF_UNI));
    assert(state->ss_new_info.send_prefix_size == 3);
    state->ss_floor = state->ss_new_info.send_prefix_size;
    if (endpoint->se_reset_new_child == 4)
        return (lsquic_stream_ctx_t *) state;
    assert(sizeof(reset_suffix) - 1 == (size_t) lsquic_stream_write(stream,
                                                reset_suffix, sizeof(reset_suffix) - 1));
    state->ss_final = state->ss_floor + sizeof(reset_suffix) - 1;
    if (endpoint->se_reset_new_child == 3)
        return (lsquic_stream_ctx_t *) state;
    if (endpoint->se_reset_new_child == 2)
        lsquic_stream_maybe_reset(stream, 373, 0);
    else
        assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(stream, 373, 0));
    state->ss_local_reset = 1;
    /* The actual reset commits its full final size before make returns. */
    assert(stream->sm_reset_tx_final == state->ss_final);
    assert(stream->sm_reset_tx_reliable >= state->ss_floor);
    assert(stream->sm_reset_tx_reliable <= state->ss_final);
    state->ss_reliable = stream->sm_reset_tx_reliable;
    return (lsquic_stream_ctx_t *) state;
}


static void
header_set_received (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct streams_state *state = (void *) ctx;

    assert(state && state->ss_stream == stream && state->ss_id == 0);
    ++state->ss_hsets;
}


static void
webtransport_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct streams_state *state = (void *) ctx;

    assert(state && state->ss_stream == stream && state->ss_new_context);
    ++state->ss_notifications;
    state->ss_callback_before_close = !state->ss_closed;
    state->ss_notification_result = query_info(stream, &state->ss_notification_info);
    assert(state->ss_id != 0);
    if (state->ss_endpoint->se_bidi_reset
        && (state->ss_id & 1) != state->ss_endpoint->se_server)
    {
        assert_bidi_child_info(&state->ss_notification_info, 0);
        assert(stream->tosend_off == 0 && !state->ss_local_reset);
        assert(sizeof(reset_suffix) - 1 == (size_t) lsquic_stream_write(stream,
                                                reset_suffix, sizeof(reset_suffix) - 1));
        state->ss_final = state->ss_endpoint->se_bidi_reset == 2 ? 0 : sizeof(reset_suffix) - 1;
        if (state->ss_endpoint->se_bidi_reset == 2)
        {
            lsquic_stream_maybe_reset(stream, 373, 0);
            assert(!(stream->stream_flags & STREAM_RESET_TX));
            assert(stream->sm_qflags & SMQF_SEND_RST);
            assert(stream->tosend_off == 0 && stream->sm_n_buffered == 0);
        }
        else
        {
            assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(stream, 373, 0));
            assert(stream->stream_flags & STREAM_RESET_TX);
            assert(stream->sm_reset_tx_final == state->ss_final);
            assert(stream->sm_reset_tx_reliable == 0);
        }
        state->ss_local_reset = 1;
        return;
    }
    if (state->ss_endpoint->se_stop_child
        && (state->ss_id & 1) != state->ss_endpoint->se_server)
    {
        assert(state->ss_notification_info.flags == (LSQUIC_WTSF_CHILD | LSQUIC_WTSF_UNI));
        assert(!state->ss_stopped);
        state->ss_stopped = 1;
        assert(0 == lsquic_stream_shutdown(stream, 0));
        return;
    }
    if (!(state->ss_notification_info.flags & LSQUIC_WTSF_UNI)
        || (state->ss_id & 1) != state->ss_endpoint->se_server)
        assert(lsquic_stream_wantread(stream, 1) >= 0);
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct streams_state *state = (void *) ctx;
    unsigned char bytes[32];
    ssize_t size;

    while (1)
    {
        size = lsquic_stream_read(stream, bytes, sizeof(bytes));
        if (size > 0)
        {
            assert((size_t) size <= sizeof(state->ss_bytes) - state->ss_received);
            if (state->ss_id != 0)
            {
                assert((size_t) size <= sizeof(reset_suffix) - 1 - state->ss_received);
                assert(0 == memcmp(bytes, reset_suffix + state->ss_received, size));
            }
            memcpy(state->ss_bytes + state->ss_received, bytes, size);
            state->ss_received += size;
            continue;
        }
        assert(size < 0);
        if (errno != ECONNRESET)
        {
            assert(errno == EAGAIN || errno == EWOULDBLOCK);
            return;
        }
        assert(state->ss_id != 0 && state->ss_notifications == 1);
        assert(state->ss_reset_events[0] == 1 && !state->ss_read_reset);
        state->ss_read_reset = 1;
        assert(lsquic_stream_wantread(stream, 0) >= 0);
        assert(0 == lsquic_stream_shutdown(stream, 0));
        return;
    }
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) stream;
    (void) ctx;
    assert(0 && "stream fixture writes through public synchronous APIs");
}


static void
close_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct streams_state *state = (void *) ctx;

    assert(state && state->ss_stream == stream && !state->ss_closed);
    state->ss_close_result = query_info(stream, &state->ss_close_info);
    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream, &state->ss_close_recv));
    state->ss_closed = 1;
    state->ss_stream = NULL;
}


static void
stream_reset (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx, int how)
{
    struct streams_state *state = (void *) ctx;
    struct lsquic_webtransport_stream_info info;
    struct lsquic_stream_recv_state metadata;
    uint64_t error = UINT64_MAX;
    unsigned known = LSQUIC_SRS_FINAL_SIZE_KNOWN | LSQUIC_SRS_RESET_KNOWN
                   | LSQUIC_SRS_RELIABLE_RESET_SEEN | LSQUIC_SRS_RESET_VISIBLE;

    assert(state && state->ss_stream == stream && state->ss_id != 0);
    if (!(state->ss_id & 2))
    {
        assert(how == 0 && state->ss_endpoint->se_bidi_reset);
        assert((state->ss_id & 1) == state->ss_endpoint->se_server);
        assert(state->ss_notifications == 1 && state->ss_callback_before_close);
        assert(LSQUIC_WTS_OK == query_info(stream, &info));
        assert_bidi_child_info(&info, 1);
        assert(LSQUIC_SERR_AVAILABLE == lsquic_stream_get_reset_error(stream, how, &error));
        assert(error == 373 && !state->ss_reset_events[how]);
        state->ss_reset_events[how] = 1;
        state->ss_errors[how] = error;
        assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream, &metadata));
        known &= ~LSQUIC_SRS_RELIABLE_RESET_SEEN;
        assert((metadata.flags & known) == known);
        assert(!(metadata.flags & LSQUIC_SRS_RELIABLE_RESET_SEEN));
        assert(metadata.final_size == (state->ss_endpoint->se_bidi_reset == 2
                                            ? 0 : sizeof(reset_suffix) - 1));
        assert(metadata.reliable_size == 0 && metadata.reset_error_code == 373);
        return;
    }
    if (how == 1)
    {
        if (state->ss_unreset_stop)
        {
            assert(!state->ss_local_reset);
            assert(stream->stream_flags & STREAM_RESET_TX);
            assert(stream->sm_reset_tx_final == state->ss_final);
            assert(stream->sm_reset_tx_reliable >= state->ss_floor);
            assert(stream->error_code == 0);
            state->ss_local_reset = 1;
            state->ss_reliable = stream->sm_reset_tx_reliable;
        }
        assert(state->ss_local_reset);
        assert((state->ss_id & 1) == state->ss_endpoint->se_server);
        assert(state->ss_notifications == 1 && state->ss_callback_before_close);
        assert(LSQUIC_WTS_OK == query_info(stream, &info));
        assert(info.flags == (LSQUIC_WTSF_CHILD | LSQUIC_WTSF_LOCAL | LSQUIC_WTSF_UNI));
        assert(info.session_id == 0 && info.send_prefix_size == 3);
        assert(LSQUIC_SERR_AVAILABLE == lsquic_stream_get_reset_error(stream, how, &error));
        assert(error == HEC_NO_ERROR && !state->ss_reset_events[how]);
        state->ss_reset_events[how] = 1;
        state->ss_errors[how] = error;
        assert(stream->stream_flags & STREAM_RESET_TX);
        assert(stream->sm_reset_tx_final == state->ss_final);
        assert(stream->sm_reset_tx_reliable >= state->ss_floor);
        assert(stream->sm_reset_tx_reliable == state->ss_reliable);
        assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream, &metadata));
        assert(metadata.flags & LSQUIC_SRS_STOP_SENDING_KNOWN);
        assert(metadata.stop_error_code == HEC_NO_ERROR);
        return;
    }
    if (state->ss_unreset_stop)
    {
        assert(how == 0 && (state->ss_id & 1) != state->ss_endpoint->se_server);
        assert(state->ss_notifications == 1 && state->ss_callback_before_close);
        assert(LSQUIC_WTS_OK == query_info(stream, &info));
        assert(info.flags == (LSQUIC_WTSF_CHILD | LSQUIC_WTSF_UNI));
        assert(info.session_id == 0 && info.receive_prefix_size == 3);
        assert(LSQUIC_SERR_AVAILABLE == lsquic_stream_get_reset_error(stream, how, &error));
        assert(error == 0 && !state->ss_reset_events[how]);
        state->ss_reset_events[how] = 1;
        state->ss_errors[how] = error;
        assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream, &metadata));
        assert((metadata.flags & known) == known);
        assert(metadata.final_size == 3 + sizeof(reset_suffix) - 1);
        assert(metadata.reliable_size >= info.receive_prefix_size);
        assert(metadata.reliable_size <= metadata.final_size);
        assert(metadata.reset_error_code == 0);
        return;
    }
    assert(how == 0 && (state->ss_id & 1) != state->ss_endpoint->se_server);
    assert(state->ss_notifications == 1 && state->ss_callback_before_close);
    assert(LSQUIC_WTS_OK == query_info(stream, &info));
    assert(info.flags == (LSQUIC_WTSF_CHILD | LSQUIC_WTSF_UNI));
    assert(info.session_id == 0 && info.receive_prefix_size == 3);
    assert(LSQUIC_SERR_AVAILABLE == lsquic_stream_get_reset_error(stream, how, &error));
    assert(error == 373 && !state->ss_reset_events[how]);
    state->ss_reset_events[how] = 1;
    state->ss_errors[how] = error;
    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream, &metadata));
    assert((metadata.flags & known) == known);
    assert(metadata.final_size == 3 + sizeof(reset_suffix) - 1);
    assert(metadata.reliable_size >= info.receive_prefix_size);
    assert(metadata.reliable_size <= metadata.final_size);
    assert(metadata.reset_error_code == 373);
}


static const struct lsquic_stream_if streams_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_h3_settings = settings_received,
    .on_new_stream = new_stream,
    .on_hset_in = header_set_received,
    .on_webtransport_stream = webtransport_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_reset = stream_reset,
};


static void
pump_step (struct streams_fixture *fixture)
{
    lsquic_test_pair_process(&fixture->sf_transport, 1000);
    lsquic_test_deliver_all(&fixture->sf_transport.ltp_client);
    lsquic_test_deliver_all(&fixture->sf_transport.ltp_server);
}


static void
init_endpoint (struct streams_fixture *fixture, unsigned server)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct streams_endpoint *endpoint;
    struct lsquic_test_endpoint *transport, *peer;
    unsigned flags = LSENG_HTTP | (server ? LSENG_SERVER : 0);

    endpoint = server ? &fixture->sf_server : &fixture->sf_client;
    endpoint->se_server = server;
    transport = server ? &fixture->sf_transport.ltp_server
                       : &fixture->sf_transport.ltp_client;
    peer = server ? &fixture->sf_transport.ltp_client
                  : &fixture->sf_transport.ltp_server;
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = 8;
    settings.es_init_max_streams_bidi = 8;
    settings.es_max_streams_in = 0;
    settings.es_init_max_stream_data_bidi_local = 65536;
    settings.es_init_max_stream_data_bidi_remote = 65536;
    settings.es_init_max_stream_data_uni = 65536;
    settings.es_qpack_dec_max_size = 0;
    settings.es_qpack_dec_max_blocked = 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    settings.es_datagrams = 1;
    settings.es_reset_stream_at = 1;
    settings.es_webtransport.enabled = 1;
    settings.es_webtransport.initial_max_data = 65536;
    settings.es_webtransport.initial_max_streams_bidi = 16;
    settings.es_webtransport.initial_max_streams_uni = 16;
    assert(0 == lsquic_engine_check_settings(&settings, flags, NULL, 0));
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &streams_callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_hsi_if = &streams_hsi;
    config.ltec_hsi_ctx = &endpoint->se_headers;
    config.ltec_alpn = "h3";
    config.ltec_tls = lsquic_test_tls_context_new(server, "h3");
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(transport, peer, &config,
                                        server ? 12901 : 12902));
    SSL_CTX_free(config.ltec_tls);
}


static void
start_fixture (struct streams_fixture *fixture)
{
    unsigned step;

    memset(fixture, 0, sizeof(*fixture));
    init_endpoint(fixture, 0);
    init_endpoint(fixture, 1);
    assert(lsquic_engine_connect(fixture->sf_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture->sf_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture->sf_transport.ltp_server.lte_address,
                &fixture->sf_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        if (fixture->sf_client.se_handshake_ok && fixture->sf_server.se_handshake_ok
            && fixture->sf_client.se_settings_count && fixture->sf_server.se_settings_count)
            break;
        pump_step(fixture);
    }
    assert(step < STREAMS_MAX_STEPS);
    assert(fixture->sf_client.se_settings_count == 1 && fixture->sf_server.se_settings_count == 1);
    for (step = 0; step < 20; ++step)
        pump_step(fixture);
    assert(!fixture->sf_client.se_stream_count && !fixture->sf_server.se_stream_count);
}


static struct streams_state *
find_stream (struct streams_endpoint *endpoint, lsquic_stream_id_t id)
{
    unsigned index;

    for (index = 0; index < endpoint->se_stream_count; ++index)
        if (endpoint->se_streams[index].ss_id == id)
            return &endpoint->se_streams[index];
    return NULL;
}


static void
send_connect (lsquic_stream_t *stream)
{
    /* draft-ietf-webtrans-http3-16 Section 3.2 requires webtransport-h3. */
    static const char *const fields[] = {
        ":methodCONNECT", ":protocolwebtransport-h3", ":schemehttps",
        ":authoritylocalhost", ":path/wt", "originhttps://localhost",
    };
    static const unsigned name_sizes[] = { 7, 9, 7, 10, 5, 6 };
    struct lsxpack_header encoded[6];
    struct lsquic_http_headers headers = { 6, encoded };
    unsigned index;

    for (index = 0; index < 6; ++index)
        lsxpack_header_set_offset2(&encoded[index], fields[index], 0,
                    name_sizes[index], name_sizes[index], strlen(fields[index]) - name_sizes[index]);
    assert(0 == lsquic_stream_send_headers(stream, &headers, 0));
    assert(0 == lsquic_stream_flush(stream));
}


static void
send_success (lsquic_stream_t *stream)
{
    static const char status[] = ":status200";
    struct lsxpack_header encoded;
    struct lsquic_http_headers headers = { 1, &encoded };

    lsxpack_header_set_offset2(&encoded, status, 0, 7, 7, 3);
    assert(0 == lsquic_stream_send_headers(stream, &headers, 0));
    assert(0 == lsquic_stream_flush(stream));
}


static void
assert_header_value (const struct streams_header_set *set,
                     const char *name, const char *value)
{
    const struct lsxpack_header *header;
    size_t name_size = strlen(name), value_size = strlen(value);
    unsigned index, matches = 0;

    for (index = 0; index < set->shs_count; ++index)
    {
        header = &set->shs_fields[index].shf_header;
        if (header->name_len != name_size
            || 0 != memcmp(lsxpack_header_get_name(header), name, name_size))
            continue;
        ++matches;
        assert(header->val_len == value_size);
        assert(0 == memcmp(lsxpack_header_get_value(header), value, value_size));
    }
    assert(matches == 1);
}


static void
claim_headers (struct streams_state *state, unsigned request)
{
    struct streams_header_set *set;

    assert(state && state->ss_stream && state->ss_hsets == 1);
    set = lsquic_stream_get_hset(state->ss_stream);
    assert(set && set->shs_active && set->shs_complete);
    if (request)
    {
        assert(set->shs_count == 6);
        assert_header_value(set, ":method", "CONNECT");
        assert_header_value(set, ":protocol", "webtransport-h3");
        assert_header_value(set, ":scheme", "https");
        assert_header_value(set, ":authority", "localhost");
        assert_header_value(set, ":path", "/wt");
        assert_header_value(set, "origin", "https://localhost");
    }
    else
    {
        assert(set->shs_count == 1);
        assert_header_value(set, ":status", "200");
    }
    discard_header_set(set);
}


static void
assert_parent (struct streams_state *state, unsigned local)
{
    struct lsquic_webtransport_stream_info info;

    assert(state && state->ss_stream && !state->ss_closed && !state->ss_notifications);
    assert(LSQUIC_WTS_OK == query_info(state->ss_stream, &info));
    assert(info.session_id == 0);
    assert(info.flags == (LSQUIC_WTSF_CONNECT | (local ? LSQUIC_WTSF_LOCAL : 0)));
    assert(info.send_prefix_size == 0 && info.receive_prefix_size == 0);
}


static void
establish_parent (struct streams_fixture *fixture)
{
    struct streams_state *client, *server = NULL;
    unsigned step;

    lsquic_conn_make_stream(fixture->sf_client.se_conn);
    client = find_stream(&fixture->sf_client, 0);
    assert(client && client->ss_stream);
    send_connect(client->ss_stream);
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        server = find_stream(&fixture->sf_server, 0);
        if (server && server->ss_hsets)
            break;
        pump_step(fixture);
    }
    assert(step < STREAMS_MAX_STEPS);
    claim_headers(server, 1);
    assert(LSQUIC_MWTS_OK == lsquic_stream_accept_webtransport(server->ss_stream));
    send_success(server->ss_stream);
    for (step = 0; step < STREAMS_MAX_STEPS && !client->ss_hsets; ++step)
        pump_step(fixture);
    assert(step < STREAMS_MAX_STEPS);
    claim_headers(client, 0);
    assert(LSQUIC_MWTS_OK == lsquic_stream_accept_webtransport(client->ss_stream));
    assert_parent(client, 1);
    assert_parent(server, 0);
    assert(lsquic_stream_wantread(client->ss_stream, 1) >= 0);
    assert(lsquic_stream_wantread(server->ss_stream, 1) >= 0);
    assert(sizeof(client_capsule) == (size_t) lsquic_stream_write(client->ss_stream,
                                                        client_capsule, sizeof(client_capsule)));
    assert(0 == lsquic_stream_flush(client->ss_stream));
    assert(sizeof(server_capsule) == (size_t) lsquic_stream_write(server->ss_stream,
                                                        server_capsule, sizeof(server_capsule)));
    assert(0 == lsquic_stream_flush(server->ss_stream));
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        if (client->ss_received == sizeof(server_capsule)
            && server->ss_received == sizeof(client_capsule))
            break;
        pump_step(fixture);
    }
    assert(step < STREAMS_MAX_STEPS);
    assert(0 == memcmp(client->ss_bytes, server_capsule, sizeof(server_capsule)));
    assert(0 == memcmp(server->ss_bytes, client_capsule, sizeof(client_capsule)));
    assert(!client->ss_fin && !server->ss_fin);
}


static void
assert_reset_child_info (const struct lsquic_webtransport_stream_info *info,
                         unsigned local)
{
    assert(info->session_id == 0);
    assert(info->flags == (LSQUIC_WTSF_CHILD | LSQUIC_WTSF_UNI
                                            | (local ? LSQUIC_WTSF_LOCAL : 0)));
    assert(info->send_prefix_size == (local ? 3U : 0U));
    assert(info->receive_prefix_size == (local ? 0U : 3U));
}


static void
test_reset_from_new (unsigned server_sender, unsigned ordinary)
{
    struct streams_fixture fixture;
    struct streams_endpoint *sender, *receiver;
    struct streams_state *outgoing, *incoming = NULL;
    unsigned before, step;

    start_fixture(&fixture);
    establish_parent(&fixture);
    sender = server_sender ? &fixture.sf_server : &fixture.sf_client;
    receiver = server_sender ? &fixture.sf_client : &fixture.sf_server;
    before = sender->se_stream_count;
    sender->se_reset_new_child = ordinary ? 2 : 1;
    assert(LSQUIC_MWTS_OK == lsquic_conn_make_webtransport_stream(sender->se_conn,
                                                                0, LSQUIC_WTS_UNI));
    sender->se_reset_new_child = 0;
    assert(sender->se_stream_count == before + 1);
    outgoing = &sender->se_streams[before];
    assert(outgoing->ss_local_reset && outgoing->ss_floor == 3);
    assert(outgoing->ss_final == 3 + sizeof(reset_suffix) - 1);
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        incoming = find_stream(receiver, outgoing->ss_id);
        if (outgoing->ss_closed && incoming && incoming->ss_closed)
            break;
        pump_step(&fixture);
    }
    assert(step < STREAMS_MAX_STEPS);
    assert(outgoing->ss_notifications == 1 && outgoing->ss_callback_before_close);
    assert(incoming->ss_notifications == 1 && incoming->ss_callback_before_close);
    assert(outgoing->ss_notification_result == LSQUIC_WTS_OK);
    assert(incoming->ss_notification_result == LSQUIC_WTS_OK);
    assert_reset_child_info(&outgoing->ss_notification_info, 1);
    assert_reset_child_info(&incoming->ss_notification_info, 0);
    assert(outgoing->ss_close_result == LSQUIC_WTS_OK && incoming->ss_close_result == LSQUIC_WTS_OK);
    assert_reset_child_info(&outgoing->ss_close_info, 1);
    assert_reset_child_info(&incoming->ss_close_info, 0);
    assert(incoming->ss_reset_events[0] == 1 && incoming->ss_errors[0] == 373);
    assert(incoming->ss_read_reset && !incoming->ss_fin);
    assert(incoming->ss_close_recv.final_size == outgoing->ss_final);
    assert(incoming->ss_close_recv.reliable_size == outgoing->ss_reliable);
    assert(incoming->ss_close_recv.reliable_size >= 3);
    assert(incoming->ss_close_recv.reset_error_code == 373);
    assert(incoming->ss_close_recv.flags & LSQUIC_SRS_RESET_VISIBLE);
    assert_parent(find_stream(&fixture.sf_client, 0), 1);
    assert_parent(find_stream(&fixture.sf_server, 0), 0);
    assert(fixture.sf_client.se_conn && fixture.sf_server.se_conn);
    lsquic_test_endpoint_destroy(&fixture.sf_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture.sf_transport.ltp_server);
    assert(fixture.sf_client.se_headers.shp_created == fixture.sf_client.se_headers.shp_discarded);
    assert(fixture.sf_server.se_headers.shp_created == fixture.sf_server.se_headers.shp_discarded);
    printf("PASS child reset inside on_new: %s sender/%sR0 normalized above prefix3/frozen accepted final/real receiver typed before RESET/error373/close metadata/HTTP parent intact\n",
           server_sender ? "server" : "client", ordinary ? "ordinary reset/" : "");
}


static void
test_stop_from_new (unsigned server_sender)
{
    struct streams_fixture fixture;
    struct streams_endpoint *sender, *receiver;
    struct streams_state *outgoing, *incoming = NULL;
    struct lsquic_test_endpoint *sender_transport, *receiver_transport;
    struct lsquic_test_packet held[LSQUIC_TEST_MAX_PACKETS];
    unsigned before, step, held_count = 0, index;

    start_fixture(&fixture);
    establish_parent(&fixture);
    sender = server_sender ? &fixture.sf_server : &fixture.sf_client;
    receiver = server_sender ? &fixture.sf_client : &fixture.sf_server;
    sender_transport = server_sender ? &fixture.sf_transport.ltp_server
                                     : &fixture.sf_transport.ltp_client;
    receiver_transport = server_sender ? &fixture.sf_transport.ltp_client
                                       : &fixture.sf_transport.ltp_server;
    before = sender->se_stream_count;
    sender->se_reset_new_child = 3;
    receiver->se_stop_child = 1;
    assert(LSQUIC_MWTS_OK == lsquic_conn_make_webtransport_stream(sender->se_conn,
                                                                0, LSQUIC_WTS_UNI));
    sender->se_reset_new_child = 0;
    assert(sender->se_stream_count == before + 1);
    outgoing = &sender->se_streams[before];
    assert(!outgoing->ss_local_reset && outgoing->ss_floor == 3);
    assert(outgoing->ss_final == 3 + sizeof(reset_suffix) - 1);
    lsquic_test_pair_process(&fixture.sf_transport, 1000);
    assert(receiver_transport->lte_incoming.ltq_count > 0);
    lsquic_test_deliver_all(receiver_transport);
    incoming = find_stream(receiver, outgoing->ss_id);
    assert(!incoming || (!incoming->ss_notifications && !incoming->ss_stopped));
    assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(outgoing->ss_stream, 373, 0));
    outgoing->ss_local_reset = 1;
    assert(outgoing->ss_stream->sm_reset_tx_final == outgoing->ss_final);
    assert(outgoing->ss_stream->sm_reset_tx_reliable >= outgoing->ss_floor);
    assert(outgoing->ss_stream->sm_reset_tx_reliable <= outgoing->ss_final);
    outgoing->ss_reliable = outgoing->ss_stream->sm_reset_tx_reliable;
    assert(outgoing->ss_local_reset && outgoing->ss_floor == 3);
    /* STOP must reach the frozen sender before the peer receives RESET. */
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        lsquic_test_pair_process(&fixture.sf_transport, 1000);
        while (receiver_transport->lte_incoming.ltq_count)
        {
            assert(held_count < LSQUIC_TEST_MAX_PACKETS);
            assert(0 == lsquic_test_packet_take(receiver_transport, 0, &held[held_count]));
            ++held_count;
        }
        lsquic_test_deliver_all(sender_transport);
        if (outgoing->ss_reset_events[1])
            break;
    }
    assert(step < STREAMS_MAX_STEPS && held_count > 0);
    assert(outgoing->ss_stream && !outgoing->ss_closed);
    assert(outgoing->ss_stream->stream_flags & STREAM_RST_SENT);
    for (index = 0; index < held_count; ++index)
        assert(lsquic_test_packet_deliver(receiver_transport, &held[index]) >= 0);
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        incoming = find_stream(receiver, outgoing->ss_id);
        if (outgoing->ss_closed && incoming && incoming->ss_closed)
            break;
        pump_step(&fixture);
    }
    assert(step < STREAMS_MAX_STEPS);
    assert(outgoing->ss_notifications == 1 && outgoing->ss_callback_before_close);
    assert(incoming->ss_notifications == 1 && incoming->ss_callback_before_close);
    assert(outgoing->ss_notification_result == LSQUIC_WTS_OK);
    assert(incoming->ss_notification_result == LSQUIC_WTS_OK);
    assert_reset_child_info(&outgoing->ss_notification_info, 1);
    assert_reset_child_info(&incoming->ss_notification_info, 0);
    assert(outgoing->ss_close_result == LSQUIC_WTS_OK && incoming->ss_close_result == LSQUIC_WTS_OK);
    assert_reset_child_info(&outgoing->ss_close_info, 1);
    assert_reset_child_info(&incoming->ss_close_info, 0);
    assert(incoming->ss_stopped && !incoming->ss_fin && !incoming->ss_read_reset);
    assert(incoming->ss_reset_events[0] == 1 && incoming->ss_errors[0] == 373);
    assert(outgoing->ss_reset_events[1] == 1 && outgoing->ss_errors[1] == HEC_NO_ERROR);
    assert(!outgoing->ss_reset_events[0] && !incoming->ss_reset_events[1]);
    assert(incoming->ss_close_recv.final_size == outgoing->ss_final);
    assert(incoming->ss_close_recv.reliable_size == outgoing->ss_reliable);
    assert(incoming->ss_close_recv.reliable_size >= 3);
    assert(incoming->ss_close_recv.reset_error_code == 373);
    assert(incoming->ss_close_recv.flags & LSQUIC_SRS_RESET_VISIBLE);
    assert(outgoing->ss_close_recv.flags & LSQUIC_SRS_STOP_SENDING_KNOWN);
    assert(outgoing->ss_close_recv.stop_error_code == HEC_NO_ERROR);
    assert_parent(find_stream(&fixture.sf_client, 0), 1);
    assert_parent(find_stream(&fixture.sf_server, 0), 0);
    assert(fixture.sf_client.se_conn && fixture.sf_server.se_conn);
    lsquic_test_endpoint_destroy(&fixture.sf_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture.sf_transport.ltp_server);
    assert(fixture.sf_client.se_headers.shp_created == fixture.sf_client.se_headers.shp_discarded);
    assert(fixture.sf_server.se_headers.shp_created == fixture.sf_server.se_headers.shp_discarded);
    printf("PASS child STOP_SENDING: %s sender/peer read shutdown/typed before STOP/error0x100/frozen final/prefix3 retained/reset373/one close/HTTP parent intact\n",
           server_sender ? "server" : "client");
}


static void
test_bidi_responder_reset (unsigned server_responder, unsigned ordinary)
{
    struct streams_fixture fixture;
    struct streams_endpoint *initiator, *responder;
    struct streams_state *local, *remote = NULL;
    unsigned before, step;

    start_fixture(&fixture);
    establish_parent(&fixture);
    responder = server_responder ? &fixture.sf_server : &fixture.sf_client;
    initiator = server_responder ? &fixture.sf_client : &fixture.sf_server;
    initiator->se_bidi_reset = responder->se_bidi_reset = ordinary ? 2 : 1;
    before = initiator->se_stream_count;
    assert(LSQUIC_MWTS_OK == lsquic_conn_make_webtransport_stream(initiator->se_conn,
                                                                0, LSQUIC_WTS_BIDI));
    assert(initiator->se_stream_count == before + 1);
    local = &initiator->se_streams[before];
    assert(local->ss_new_result == LSQUIC_WTS_OK);
    assert_bidi_child_info(&local->ss_new_info, 1);
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        remote = find_stream(responder, local->ss_id);
        if (local->ss_read_reset && remote && remote->ss_local_reset)
            break;
        pump_step(&fixture);
    }
    assert(step < STREAMS_MAX_STEPS);
    assert(local->ss_stream && remote->ss_stream && !local->ss_closed && !remote->ss_closed);
    assert(local->ss_notifications == 1 && local->ss_callback_before_close);
    assert(remote->ss_notifications == 1 && remote->ss_callback_before_close);
    assert(local->ss_notification_result == LSQUIC_WTS_OK);
    assert(remote->ss_notification_result == LSQUIC_WTS_OK);
    assert_bidi_child_info(&local->ss_notification_info, 1);
    assert_bidi_child_info(&remote->ss_notification_info, 0);
    assert(remote->ss_floor == 0 && remote->ss_reliable == 0);
    assert(remote->ss_final == (ordinary ? 0 : sizeof(reset_suffix) - 1));
    assert(local->ss_read_reset && !local->ss_fin && local->ss_received == 0);
    assert(local->ss_reset_events[0] == 1 && local->ss_errors[0] == 373);
    assert(!local->ss_reset_events[1] && !remote->ss_reset_events[0] && !remote->ss_reset_events[1]);
    assert_parent(find_stream(&fixture.sf_client, 0), 1);
    assert_parent(find_stream(&fixture.sf_server, 0), 0);
    assert(fixture.sf_client.se_conn && fixture.sf_server.se_conn);
    lsquic_test_endpoint_destroy(&fixture.sf_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture.sf_transport.ltp_server);
    assert(local->ss_closed && remote->ss_closed);
    assert(local->ss_close_result == LSQUIC_WTS_OK && remote->ss_close_result == LSQUIC_WTS_OK);
    assert_bidi_child_info(&local->ss_close_info, 1);
    assert_bidi_child_info(&remote->ss_close_info, 0);
    assert(local->ss_close_recv.final_size == remote->ss_final);
    assert(local->ss_close_recv.reliable_size == 0);
    assert(local->ss_close_recv.reset_error_code == 373);
    assert(local->ss_close_recv.flags & LSQUIC_SRS_RESET_VISIBLE);
    assert(!(local->ss_close_recv.flags & LSQUIC_SRS_RELIABLE_RESET_SEEN));
    assert(fixture.sf_client.se_headers.shp_created == fixture.sf_client.se_headers.shp_discarded);
    assert(fixture.sf_server.se_headers.shp_created == fixture.sf_server.se_headers.shp_discarded);
    printf("PASS bidi responder reset: %s responder/%sR0/send prefix0/real initiator typed before RESET/error373/final%llu/reliable0/one close/HTTP parent intact\n",
           server_responder ? "server" : "client", ordinary ? "ordinary " : "explicit ",
           (unsigned long long) remote->ss_final);
}


static void
test_stop_without_reset (unsigned server_sender)
{
    struct streams_fixture fixture;
    struct streams_endpoint *sender, *receiver;
    struct streams_state *outgoing, *incoming = NULL, *client_parent, *server_parent;
    struct lsquic_test_endpoint *receiver_transport;
    unsigned before, step;

    start_fixture(&fixture);
    establish_parent(&fixture);
    sender = server_sender ? &fixture.sf_server : &fixture.sf_client;
    receiver = server_sender ? &fixture.sf_client : &fixture.sf_server;
    receiver_transport = server_sender ? &fixture.sf_transport.ltp_client
                                       : &fixture.sf_transport.ltp_server;
    before = sender->se_stream_count;
    sender->se_reset_new_child = 4;
    sender->se_unreset_stop = receiver->se_unreset_stop = 1;
    receiver->se_stop_child = 1;
    assert(LSQUIC_MWTS_OK == lsquic_conn_make_webtransport_stream(sender->se_conn,
                                                                0, LSQUIC_WTS_UNI));
    sender->se_reset_new_child = 0;
    assert(sender->se_stream_count == before + 1);
    outgoing = &sender->se_streams[before];
    assert(outgoing->ss_new_result == LSQUIC_WTS_OK);
    assert_reset_child_info(&outgoing->ss_new_info, 1);
    assert(!outgoing->ss_local_reset && outgoing->ss_floor == 3);
    /* Make flushes only the prefix; this suffix must survive until STOP. */
    assert(sizeof(reset_suffix) - 1 == (size_t) lsquic_stream_write(outgoing->ss_stream,
                                                reset_suffix, sizeof(reset_suffix) - 1));
    outgoing->ss_final = outgoing->ss_floor + sizeof(reset_suffix) - 1;
    assert(outgoing->ss_stream->sm_n_buffered == sizeof(reset_suffix) - 1);
    assert(!(outgoing->ss_stream->stream_flags & (STREAM_RESET_TX | STREAM_RST_SENT)));
    assert(!(outgoing->ss_stream->sm_qflags & SMQF_SEND_RST));
    lsquic_test_pair_process(&fixture.sf_transport, 1000);
    assert(outgoing->ss_notifications == 1 && !outgoing->ss_reset_events[1]);
    assert(outgoing->ss_stream->sm_n_buffered == sizeof(reset_suffix) - 1);
    assert(outgoing->ss_stream->tosend_off == outgoing->ss_floor);
    assert(receiver_transport->lte_incoming.ltq_count > 0);
    lsquic_test_deliver_all(receiver_transport);
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        incoming = find_stream(receiver, outgoing->ss_id);
        if (outgoing->ss_closed && incoming && incoming->ss_closed)
            break;
        pump_step(&fixture);
    }
    assert(step < STREAMS_MAX_STEPS);
    assert(outgoing->ss_local_reset && outgoing->ss_reliable >= outgoing->ss_floor);
    assert(outgoing->ss_notifications == 1 && outgoing->ss_callback_before_close);
    assert(incoming->ss_notifications == 1 && incoming->ss_callback_before_close);
    assert(outgoing->ss_notification_result == LSQUIC_WTS_OK);
    assert(incoming->ss_notification_result == LSQUIC_WTS_OK);
    assert_reset_child_info(&outgoing->ss_notification_info, 1);
    assert_reset_child_info(&incoming->ss_notification_info, 0);
    assert(outgoing->ss_close_result == LSQUIC_WTS_OK && incoming->ss_close_result == LSQUIC_WTS_OK);
    assert_reset_child_info(&outgoing->ss_close_info, 1);
    assert_reset_child_info(&incoming->ss_close_info, 0);
    assert(outgoing->ss_reset_events[1] == 1 && outgoing->ss_errors[1] == HEC_NO_ERROR);
    assert(incoming->ss_reset_events[0] == 1 && incoming->ss_errors[0] == 0);
    assert(!outgoing->ss_reset_events[0] && !incoming->ss_reset_events[1]);
    assert(incoming->ss_stopped && !incoming->ss_read_reset && !incoming->ss_fin);
    assert(incoming->ss_received == 0);
    assert(incoming->ss_close_recv.final_size == outgoing->ss_final);
    assert(incoming->ss_close_recv.reliable_size == outgoing->ss_reliable);
    assert(incoming->ss_close_recv.reliable_size >= 3);
    assert(incoming->ss_close_recv.reset_error_code == 0);
    assert(incoming->ss_close_recv.flags & LSQUIC_SRS_RELIABLE_RESET_SEEN);
    assert(incoming->ss_close_recv.flags & LSQUIC_SRS_RESET_VISIBLE);
    assert(outgoing->ss_close_recv.flags & LSQUIC_SRS_STOP_SENDING_KNOWN);
    assert(outgoing->ss_close_recv.stop_error_code == HEC_NO_ERROR);
    client_parent = find_stream(&fixture.sf_client, 0);
    server_parent = find_stream(&fixture.sf_server, 0);
    assert_parent(client_parent, 1);
    assert_parent(server_parent, 0);
    assert(sizeof(client_capsule) == (size_t) lsquic_stream_write(client_parent->ss_stream,
                                                        client_capsule, sizeof(client_capsule)));
    assert(0 == lsquic_stream_flush(client_parent->ss_stream));
    assert(sizeof(server_capsule) == (size_t) lsquic_stream_write(server_parent->ss_stream,
                                                        server_capsule, sizeof(server_capsule)));
    assert(0 == lsquic_stream_flush(server_parent->ss_stream));
    for (step = 0; step < STREAMS_MAX_STEPS; ++step)
    {
        if (client_parent->ss_received == 2 * sizeof(server_capsule)
            && server_parent->ss_received == 2 * sizeof(client_capsule))
            break;
        pump_step(&fixture);
    }
    assert(step < STREAMS_MAX_STEPS);
    assert(0 == memcmp(client_parent->ss_bytes + sizeof(server_capsule), server_capsule,
                      sizeof(server_capsule)));
    assert(0 == memcmp(server_parent->ss_bytes + sizeof(client_capsule), client_capsule,
                      sizeof(client_capsule)));
    assert_parent(client_parent, 1);
    assert_parent(server_parent, 0);
    assert(fixture.sf_client.se_conn && fixture.sf_server.se_conn);
    lsquic_test_endpoint_destroy(&fixture.sf_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture.sf_transport.ltp_server);
    assert(fixture.sf_client.se_headers.shp_created == fixture.sf_client.se_headers.shp_discarded);
    assert(fixture.sf_server.se_headers.shp_created == fixture.sf_server.se_headers.shp_discarded);
    printf("PASS child STOP without prior reset: %s sender/buffered accepted suffix/typed before STOP/error0x100/frozen final/prefix3 retained/automatic reset0/one close/HTTP parent exchanges capsules\n",
           server_sender ? "server" : "client");
}


int
main (int argc, char **argv)
{
    unsigned client, server, ordinary_client, ordinary_server, stop_client, stop_server;
    unsigned bidi_client, bidi_server, bidi_ordinary_client, bidi_ordinary_server;
    unsigned unreset_client, unreset_server;

    assert(argc <= 2);
    client = argc == 1 || 0 == strcmp(argv[1], "all") || 0 == strcmp(argv[1], "uni-client");
    server = argc == 1 || 0 == strcmp(argv[1], "all") || 0 == strcmp(argv[1], "uni-server");
    ordinary_client = argc == 1 || 0 == strcmp(argv[1], "all")
                                     || 0 == strcmp(argv[1], "ordinary-client");
    ordinary_server = argc == 1 || 0 == strcmp(argv[1], "all")
                                     || 0 == strcmp(argv[1], "ordinary-server");
    stop_client = argc == 1 || 0 == strcmp(argv[1], "all")
                                 || 0 == strcmp(argv[1], "stop-client");
    stop_server = argc == 1 || 0 == strcmp(argv[1], "all")
                                 || 0 == strcmp(argv[1], "stop-server");
    bidi_client = argc == 1 || 0 == strcmp(argv[1], "all")
                                 || 0 == strcmp(argv[1], "bidi-responder-client");
    bidi_server = argc == 1 || 0 == strcmp(argv[1], "all")
                                 || 0 == strcmp(argv[1], "bidi-responder-server");
    bidi_ordinary_client = argc == 1 || 0 == strcmp(argv[1], "all")
                                 || 0 == strcmp(argv[1], "bidi-ordinary-client");
    bidi_ordinary_server = argc == 1 || 0 == strcmp(argv[1], "all")
                                 || 0 == strcmp(argv[1], "bidi-ordinary-server");
    unreset_client = argc == 1 || 0 == strcmp(argv[1], "all")
                                 || 0 == strcmp(argv[1], "stop-unreset-client");
    unreset_server = argc == 1 || 0 == strcmp(argv[1], "all")
                                 || 0 == strcmp(argv[1], "stop-unreset-server");
    assert(client || server || ordinary_client || ordinary_server || stop_client || stop_server
           || bidi_client || bidi_server || bidi_ordinary_client || bidi_ordinary_server
           || unreset_client || unreset_server);
    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    if (client)
        test_reset_from_new(0, 0);
    if (server)
        test_reset_from_new(1, 0);
    if (ordinary_client)
        test_reset_from_new(0, 1);
    if (ordinary_server)
        test_reset_from_new(1, 1);
    if (stop_client)
        test_stop_from_new(0);
    if (stop_server)
        test_stop_from_new(1);
    if (bidi_client)
        test_bidi_responder_reset(0, 0);
    if (bidi_server)
        test_bidi_responder_reset(1, 0);
    if (bidi_ordinary_client)
        test_bidi_responder_reset(0, 1);
    if (bidi_ordinary_server)
        test_bidi_responder_reset(1, 1);
    if (unreset_client)
        test_stop_without_reset(0);
    if (unreset_server)
        test_stop_without_reset(1);
    lsquic_global_cleanup();
    return 0;
}
