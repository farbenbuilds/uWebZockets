/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <openssl/ssl.h>

#include "lsquic.h"
#include "uwz_quic_fixture.h"
#include "uwz_webtransport_fixture.h"

#ifdef NDEBUG
#error "uwz_webtransport_frame_errors requires active assertions"
#endif

enum {
    FRAME_MAX_STEPS = 20000,
    FRAME_MAX_STREAMS = 8,
    FRAME_STREAM_BYTES = 256,
    FRAME_H3_FRAME_ERROR = 0x106,
    FRAME_H3_FRAME_UNEXPECTED = 0x105,
};

struct frame_endpoint;

struct frame_stream {
    struct frame_endpoint *fs_endpoint;
    lsquic_stream_t *fs_stream;
    lsquic_stream_id_t fs_id;
    size_t fs_received;
    unsigned fs_closed;
    unsigned fs_fin;
    unsigned fs_read_reset;
    unsigned char fs_bytes[FRAME_STREAM_BYTES];
};

struct frame_endpoint {
    lsquic_conn_t *fe_conn;
    uint64_t fe_remote_error;
    unsigned fe_raw;
    unsigned fe_http_webtransport;
    unsigned fe_server;
    unsigned fe_handshake_ok;
    unsigned fe_settings;
    unsigned fe_stream_count;
    unsigned fe_notifications;
    unsigned fe_closed;
    unsigned fe_remote_closes;
    int fe_remote_app_error;
    enum LSQUIC_CONN_STATUS fe_terminal_status;
    struct frame_stream fe_streams[FRAME_MAX_STREAMS];
    struct streams_header_pool fe_headers;
};

struct frame_fixture {
    struct lsquic_test_pair ff_transport;
    struct frame_endpoint ff_client;
    struct frame_endpoint ff_server;
};

static const unsigned char frame_bad_type[] = { 0x40, 0x41, 0 };
static const unsigned char frame_settings[] = {
    0, 4, 9, 0xAC, 0x7C, 0xF0, 0, 1, 0x33, 1, 8, 1,
};


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct frame_endpoint *endpoint = ctx;

    assert(conn && !endpoint->fe_conn && !endpoint->fe_closed);
    endpoint->fe_conn = conn;
    if (endpoint->fe_server)
        endpoint->fe_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct frame_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint && status == LSQ_HSK_OK);
    endpoint->fe_handshake_ok = 1;
}


static void
settings_received (lsquic_conn_t *conn)
{
    struct frame_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);
    struct lsquic_webtransport_peer peer;
    unsigned required = LSQUIC_WTP_WT_ENABLED | LSQUIC_WTP_H3_DATAGRAM
                      | LSQUIC_WTP_QUIC_DATAGRAM | LSQUIC_WTP_RELIABLE_RESET;

    assert(endpoint && !endpoint->fe_raw && !endpoint->fe_settings);
    assert(LSQUIC_WTP_OK == lsquic_conn_get_webtransport_peer(conn, &peer));
    assert((peer.flags & required) == required);
    assert(peer.flags & LSQUIC_WTP_CONNECT);
    ++endpoint->fe_settings;
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct frame_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint && endpoint->fe_conn == conn && !endpoint->fe_closed);
    endpoint->fe_terminal_status = lsquic_conn_status(conn, NULL, 0);
    endpoint->fe_closed = 1;
    endpoint->fe_conn = NULL;
    lsquic_conn_set_ctx(conn, NULL);
}


static void
remote_close (lsquic_conn_t *conn, int app_error, uint64_t error,
              const char *reason, int reason_len)
{
    struct frame_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    (void) reason;
    (void) reason_len;
    assert(endpoint && endpoint->fe_raw);
    if (endpoint->fe_http_webtransport)
        assert(app_error == 1 && error == FRAME_H3_FRAME_ERROR);
    else
        assert(app_error == 1 && error == FRAME_H3_FRAME_UNEXPECTED);
    assert(endpoint->fe_remote_closes < FRAME_MAX_STEPS);
    endpoint->fe_remote_app_error = app_error;
    endpoint->fe_remote_error = error;
    ++endpoint->fe_remote_closes;
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct frame_endpoint *endpoint = ctx;
    struct frame_stream *state;

    assert(stream && endpoint->fe_stream_count < FRAME_MAX_STREAMS);
    state = &endpoint->fe_streams[endpoint->fe_stream_count++];
    state->fs_endpoint = endpoint;
    state->fs_stream = stream;
    state->fs_id = lsquic_stream_id(stream);
    if (!(state->fs_id & 2) || (state->fs_id & 1) != endpoint->fe_server)
        assert(lsquic_stream_wantread(stream, 1) >= 0);
    return (lsquic_stream_ctx_t *) state;
}


static void
webtransport_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct frame_stream *state = (void *) ctx;

    assert(state && state->fs_stream == stream && !state->fs_closed);
    assert(state->fs_endpoint->fe_notifications < FRAME_MAX_STREAMS);
    ++state->fs_endpoint->fe_notifications;
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct frame_stream *state = (void *) ctx;
    unsigned char bytes[64];
    ssize_t size;

    assert(state && state->fs_stream == stream && !state->fs_closed);
    while (1)
    {
        size = lsquic_stream_read(stream, bytes, sizeof(bytes));
        if (size > 0)
        {
            assert((size_t) size <= sizeof(state->fs_bytes) - state->fs_received);
            memcpy(state->fs_bytes + state->fs_received, bytes, size);
            state->fs_received += size;
            continue;
        }
        if (size == 0)
        {
            assert(!state->fs_fin);
            state->fs_fin = 1;
            assert(lsquic_stream_wantread(stream, 0) >= 0);
            return;
        }
        if (errno == ECONNRESET)
        {
            assert(!state->fs_read_reset);
            state->fs_read_reset = 1;
            assert(lsquic_stream_wantread(stream, 0) >= 0);
            return;
        }
        assert(errno == EAGAIN || errno == EWOULDBLOCK);
        return;
    }
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) stream;
    (void) ctx;
    assert(0 && "frame-error fixture writes through public synchronous APIs");
}


static void
close_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct frame_stream *state = (void *) ctx;

    assert(state && state->fs_stream == stream && !state->fs_closed);
    state->fs_closed = 1;
    state->fs_stream = NULL;
}


static const struct lsquic_stream_if frame_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_h3_settings = settings_received,
    .on_conncloseframe_received = remote_close,
    .on_new_stream = new_stream,
    .on_webtransport_stream = webtransport_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
};


static void
pump_step (struct frame_fixture *fixture)
{
    lsquic_test_pair_process(&fixture->ff_transport, 1000);
    lsquic_test_deliver_all(&fixture->ff_transport.ltp_client);
    lsquic_test_deliver_all(&fixture->ff_transport.ltp_server);
}


static void
init_endpoint (struct frame_fixture *fixture, unsigned server, unsigned raw,
               unsigned webtransport)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct frame_endpoint *endpoint;
    struct lsquic_test_endpoint *transport, *peer;
    unsigned flags = (server ? LSENG_SERVER : 0) | (raw ? 0 : LSENG_HTTP);

    endpoint = server ? &fixture->ff_server : &fixture->ff_client;
    endpoint->fe_server = server;
    endpoint->fe_raw = raw;
    endpoint->fe_http_webtransport = webtransport;
    transport = server ? &fixture->ff_transport.ltp_server : &fixture->ff_transport.ltp_client;
    peer = server ? &fixture->ff_transport.ltp_client : &fixture->ff_transport.ltp_server;
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = 8;
    settings.es_init_max_streams_bidi = 8;
    settings.es_max_streams_in = raw ? 8 : 0;
    settings.es_init_max_stream_data_bidi_local = 65536;
    settings.es_init_max_stream_data_bidi_remote = 65536;
    settings.es_init_max_stream_data_uni = 65536;
    settings.es_qpack_dec_max_size = 0;
    settings.es_qpack_dec_max_blocked = 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    settings.es_datagrams = 1;
    settings.es_reset_stream_at = 1;
    assert(settings.es_webtransport.enabled == 0);
    if (!raw && webtransport)
    {
        settings.es_webtransport.enabled = 1;
        settings.es_webtransport.initial_max_data = 65536;
        settings.es_webtransport.initial_max_streams_bidi = 16;
        settings.es_webtransport.initial_max_streams_uni = 16;
    }
    assert(0 == lsquic_engine_check_settings(&settings, flags, NULL, 0));
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &frame_callbacks;
    config.ltec_stream_if_ctx = endpoint;
    if (!raw)
    {
        config.ltec_hsi_if = &streams_hsi;
        config.ltec_hsi_ctx = &endpoint->fe_headers;
    }
    config.ltec_alpn = "h3";
    config.ltec_tls = lsquic_test_tls_context_new(server, "h3");
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(transport, peer, &config,
                                        server ? 12931 : 12932));
    SSL_CTX_free(config.ltec_tls);
}


static struct frame_stream *
start_fixture (struct frame_fixture *fixture, unsigned raw_server, unsigned webtransport)
{
    struct frame_endpoint *raw, *http;
    struct frame_stream *control;
    unsigned before, step;

    memset(fixture, 0, sizeof(*fixture));
    init_endpoint(fixture, 0, !raw_server, webtransport);
    init_endpoint(fixture, 1, raw_server, webtransport);
    raw = raw_server ? &fixture->ff_server : &fixture->ff_client;
    http = raw_server ? &fixture->ff_client : &fixture->ff_server;
    assert(lsquic_engine_connect(fixture->ff_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture->ff_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture->ff_transport.ltp_server.lte_address,
                &fixture->ff_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
    for (step = 0; step < FRAME_MAX_STEPS; ++step)
    {
        if (raw->fe_handshake_ok && http->fe_handshake_ok)
            break;
        pump_step(fixture);
    }
    assert(step < FRAME_MAX_STEPS);
    before = raw->fe_stream_count;
    assert(LSQUIC_MUS_OK == lsquic_conn_make_uni_stream(raw->fe_conn));
    assert(raw->fe_stream_count == before + 1);
    control = &raw->fe_streams[before];
    assert((control->fs_id & 3) == (2U | raw_server));
    assert(sizeof(frame_settings) == (size_t) lsquic_stream_write(control->fs_stream,
                                                    frame_settings, sizeof(frame_settings)));
    assert(0 == lsquic_stream_flush(control->fs_stream));
    for (step = 0; step < FRAME_MAX_STEPS && !http->fe_settings; ++step)
        pump_step(fixture);
    assert(step < FRAME_MAX_STEPS && http->fe_settings == 1);
    assert(raw->fe_conn && http->fe_conn && !raw->fe_remote_closes);
    assert(LSCONN_ST_CONNECTED == lsquic_conn_status(raw->fe_conn, NULL, 0));
    assert(LSCONN_ST_CONNECTED == lsquic_conn_status(http->fe_conn, NULL, 0));
    assert(!raw->fe_notifications && !http->fe_notifications);
    return control;
}


static struct frame_stream *
find_stream (struct frame_endpoint *endpoint, lsquic_stream_id_t id)
{
    unsigned index;

    for (index = 0; index < endpoint->fe_stream_count; ++index)
        if (endpoint->fe_streams[index].fs_id == id)
            return &endpoint->fe_streams[index];
    return NULL;
}


static void
wait_for_frame_error (struct frame_fixture *fixture, unsigned raw_server)
{
    struct frame_endpoint *raw = raw_server ? &fixture->ff_server : &fixture->ff_client;
    struct frame_endpoint *http = raw_server ? &fixture->ff_client : &fixture->ff_server;
    unsigned step;

    for (step = 0; step < FRAME_MAX_STEPS; ++step)
    {
        if (raw->fe_remote_closes && http->fe_closed)
            break;
        pump_step(fixture);
        assert(!raw->fe_notifications && !http->fe_notifications);
    }
    assert(step < FRAME_MAX_STEPS);
    assert(raw->fe_remote_closes && raw->fe_remote_app_error == 1);
    if (http->fe_http_webtransport)
        assert(raw->fe_remote_error == FRAME_H3_FRAME_ERROR);
    else
        assert(raw->fe_remote_error == FRAME_H3_FRAME_UNEXPECTED);
    assert(http->fe_closed && http->fe_terminal_status == LSCONN_ST_ERROR);
    assert(!raw->fe_notifications && !http->fe_notifications);
}


static void
destroy_fixture (struct frame_fixture *fixture)
{
    struct frame_endpoint *endpoints[] = { &fixture->ff_client, &fixture->ff_server };
    unsigned endpoint_index, stream_index;

    lsquic_test_endpoint_destroy(&fixture->ff_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture->ff_transport.ltp_server);
    for (endpoint_index = 0; endpoint_index < 2; ++endpoint_index)
    {
        assert(endpoints[endpoint_index]->fe_closed);
        for (stream_index = 0; stream_index < endpoints[endpoint_index]->fe_stream_count;
             ++stream_index)
        {
            assert(endpoints[endpoint_index]->fe_streams[stream_index].fs_closed);
            assert(!endpoints[endpoint_index]->fe_streams[stream_index].fs_stream);
        }
        assert(endpoints[endpoint_index]->fe_headers.shp_created
               == endpoints[endpoint_index]->fe_headers.shp_discarded);
    }
}


static void
test_control_frame (unsigned raw_server)
{
    struct frame_fixture fixture;
    struct frame_stream *control;

    control = start_fixture(&fixture, raw_server, 1);
    assert(sizeof(frame_bad_type) == (size_t) lsquic_stream_write(control->fs_stream,
                                                    frame_bad_type, sizeof(frame_bad_type)));
    assert(0 == lsquic_stream_flush(control->fs_stream));
    wait_for_frame_error(&fixture, raw_server);
    destroy_fixture(&fixture);
    printf("PASS WT_STREAM placement: raw-%s/control after real SETTINGS/H3_FRAME_ERROR0x106/no typed child\n",
           raw_server ? "server" : "client");
}


static void
test_disabled_control_frame (unsigned raw_server)
{
    static const unsigned char data_frame[] = { 0, 0 };
    struct frame_fixture fixture;
    struct frame_stream *control;
    struct frame_endpoint *raw, *http;
    unsigned step;

    control = start_fixture(&fixture, raw_server, 0);
    raw = raw_server ? &fixture.ff_server : &fixture.ff_client;
    http = raw_server ? &fixture.ff_client : &fixture.ff_server;
    assert(!http->fe_http_webtransport && http->fe_settings == 1);
    assert(sizeof(frame_bad_type) == (size_t) lsquic_stream_write(control->fs_stream,
                                                    frame_bad_type, sizeof(frame_bad_type)));
    assert(0 == lsquic_stream_flush(control->fs_stream));
    for (step = 0; step < 20; ++step)
    {
        pump_step(&fixture);
        assert(raw->fe_conn && http->fe_conn && !raw->fe_remote_closes);
        assert(LSCONN_ST_CONNECTED == lsquic_conn_status(raw->fe_conn, NULL, 0));
        assert(LSCONN_ST_CONNECTED == lsquic_conn_status(http->fe_conn, NULL, 0));
        assert(!raw->fe_notifications && !http->fe_notifications);
    }
    assert(sizeof(data_frame) == (size_t) lsquic_stream_write(control->fs_stream,
                                                    data_frame, sizeof(data_frame)));
    assert(0 == lsquic_stream_flush(control->fs_stream));
    wait_for_frame_error(&fixture, raw_server);
    assert(raw->fe_remote_app_error == 1 && raw->fe_remote_error == FRAME_H3_FRAME_UNEXPECTED);
    assert(http->fe_closed && http->fe_terminal_status == LSCONN_ST_ERROR);
    assert(!raw->fe_notifications && !http->fe_notifications);
    destroy_fixture(&fixture);
    printf("PASS WT_STREAM default-off compatibility: raw-%s/control unknown0x41 ignored/connected until forbidden DATA/H3_FRAME_UNEXPECTED0x105/no typed child\n",
           raw_server ? "server" : "client");
}


static void
send_request (lsquic_stream_t *stream, unsigned connect)
{
    static const char *const get_fields[] = {
        ":methodGET", ":schemehttps", ":authoritylocalhost", ":path/",
    };
    static const unsigned get_sizes[] = { 7, 7, 10, 5 };
    static const char *const connect_fields[] = {
        ":methodCONNECT", ":protocolwebtransport-h3", ":schemehttps",
        ":authoritylocalhost", ":path/wt", "originhttps://localhost",
    };
    static const unsigned connect_sizes[] = { 7, 9, 7, 10, 5, 6 };
    const char *const *fields = connect ? connect_fields : get_fields;
    const unsigned *sizes = connect ? connect_sizes : get_sizes;
    struct lsxpack_header encoded[6];
    struct lsquic_http_headers headers = { connect ? 6 : 4, encoded };
    unsigned index, count = connect ? 6 : 4;

    for (index = 0; index < count; ++index)
        lsxpack_header_set_offset2(&encoded[index], fields[index], 0, sizes[index],
                                  sizes[index], strlen(fields[index]) - sizes[index]);
    assert(0 == lsquic_stream_send_headers(stream, &headers, 0));
    assert(0 == lsquic_stream_flush(stream));
    if (connect)
        assert(LSQUIC_MWTS_OK == lsquic_stream_accept_webtransport(stream));
}


static void
test_response_frame (unsigned connect)
{
    struct frame_fixture fixture;
    struct frame_stream *request, *response = NULL;
    struct lsquic_webtransport_stream_info info;
    unsigned before, step;

    start_fixture(&fixture, 1, 1);
    before = fixture.ff_client.fe_stream_count;
    lsquic_conn_make_stream(fixture.ff_client.fe_conn);
    assert(fixture.ff_client.fe_stream_count == before + 1);
    request = &fixture.ff_client.fe_streams[before];
    assert(request->fs_id == 0 && request->fs_stream);
    send_request(request->fs_stream, connect);
    if (connect)
    {
        assert(LSQUIC_WTS_OK == lsquic_stream_get_webtransport_info(request->fs_stream, &info));
        assert(info.flags == (LSQUIC_WTSF_CONNECT | LSQUIC_WTSF_LOCAL));
        assert(info.session_id == 0 && !info.send_prefix_size && !info.receive_prefix_size);
    }
    for (step = 0; step < FRAME_MAX_STEPS; ++step)
    {
        response = find_stream(&fixture.ff_server, request->fs_id);
        if (response && response->fs_received)
            break;
        pump_step(&fixture);
    }
    assert(step < FRAME_MAX_STEPS && response->fs_stream && response->fs_id == 0);
    assert(!fixture.ff_client.fe_notifications && !fixture.ff_server.fe_notifications);
    assert(sizeof(frame_bad_type) == (size_t) lsquic_stream_write(response->fs_stream,
                                                    frame_bad_type, sizeof(frame_bad_type)));
    assert(0 == lsquic_stream_flush(response->fs_stream));
    wait_for_frame_error(&fixture, 1);
    destroy_fixture(&fixture);
    printf("PASS WT_STREAM placement: response direction of local %s stream0/H3_FRAME_ERROR0x106/no typed child\n",
           connect ? "marked CONNECT" : "GET");
}


int
main (int argc, char **argv)
{
    unsigned control_client, control_server, response_get, response_connect;
    unsigned disabled_client, disabled_server;

    assert(argc <= 2);
    control_client = argc == 1 || 0 == strcmp(argv[1], "all")
                              || 0 == strcmp(argv[1], "control-client");
    control_server = argc == 1 || 0 == strcmp(argv[1], "all")
                              || 0 == strcmp(argv[1], "control-server");
    response_get = argc == 1 || 0 == strcmp(argv[1], "all")
                            || 0 == strcmp(argv[1], "response-get");
    response_connect = argc == 1 || 0 == strcmp(argv[1], "all")
                                || 0 == strcmp(argv[1], "response-connect");
    disabled_client = argc == 1 || 0 == strcmp(argv[1], "all")
                               || 0 == strcmp(argv[1], "disabled-control-client");
    disabled_server = argc == 1 || 0 == strcmp(argv[1], "all")
                               || 0 == strcmp(argv[1], "disabled-control-server");
    assert(control_client || control_server || response_get || response_connect
           || disabled_client || disabled_server);
    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    if (control_client)
        test_control_frame(0);
    if (control_server)
        test_control_frame(1);
    if (response_get)
        test_response_frame(0);
    if (response_connect)
        test_response_frame(1);
    if (disabled_client)
        test_disabled_control_frame(0);
    if (disabled_server)
        test_disabled_control_frame(1);
    lsquic_global_cleanup();
    return 0;
}
