#!/usr/bin/env python3
"""Replay retained KDF, public-control, and lifecycle binaries without a compiler."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pki-tool', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    helper = args.pki_tool.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent replay output directory')
    if output.resolve().is_relative_to(base):
        raise ValueError('Keep replay output outside the retained evidence tree')
    if sha(helper) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('The verified PKI helper checksum differs')
    identity = json.loads((base / 'prebuilt_identity.json').read_text())
    expected_binaries = {'baseline/hkdf_witness', 'candidate/hkdf_witness',
        'controls/results/control_witness', 'inherited/lifecycle_test',
        'inherited/buffer_test', 'inherited/tls_pair_test'}
    if set(identity['binaries']) != expected_binaries:
        raise ValueError('Unexpected retained binary inventory')
    for name, checksum in identity['binaries'].items():
        if sha(base / name) != checksum:
            raise ValueError('Retained binary checksum differs: ' + name)
    output.mkdir(mode=0o700, parents=True)
    records = []

    def run(command, stem, expected=0):
        with (output / (stem + '.stdout')).open('wb') as stdout, \
             (output / (stem + '.stderr')).open('wb') as stderr:
            result = subprocess.run(command, cwd=output, stdout=stdout, stderr=stderr)
        records.append({'command': command, 'exit_code': result.returncode,
                        'expected_exit_code': expected, 'stem': stem})
        if result.returncode != expected:
            raise RuntimeError('Unexpected command status: ' + stem)

    pki = output / 'private_pki'
    complete = False
    try:
        run([str(base / 'baseline/hkdf_witness'), '--require-zero'], 'baseline', 1)
        run([str(base / 'candidate/hkdf_witness'), '--require-zero'], 'candidate')
        run([sys.executable, str(base / 'compare_results.py'),
             str(output / 'baseline.stdout'), str(output / 'candidate.stdout')], 'differential')
        run([str(helper), 'pki', str(pki)], 'pki_metadata')
        arguments = [str(pki / name) for name in ['server.pem', 'server.key', 'ca.pem']]
        controls = output / 'controls'
        controls.mkdir()
        run([str(base / 'controls/results/control_witness'), *arguments,
             str(controls / 'operations.csv'), str(controls / 'summary.jsonl')], 'controls')
        run([sys.executable, str(base / 'controls/verify_results.py'), str(controls),
             '--operations', 'operations.csv', '--summary', 'summary.jsonl'], 'control_verification')
        replay_controls = json.loads((output / 'control_verification.stdout').read_text())
        retained_controls = json.loads((base / 'controls/results/verification.json').read_text())
        if replay_controls['observed_vectors'] != retained_controls['observed_vectors']:
            raise ValueError('Control allocation vectors differ from retained candidate')
        run([sys.executable, str(base / 'inherited/run_cases.py'), '--pki', str(pki),
             '--output', str(output / 'inherited')], 'lifecycle')
        replay_lifecycle = json.loads((output / 'inherited/results.json').read_text())
        retained_lifecycle = json.loads((base / 'inherited/results/results.json').read_text())
        if [row['result'] for row in replay_lifecycle['rows']] != [
                row['result'] for row in retained_lifecycle['rows']]:
            raise ValueError('Lifecycle outcomes differ from retained candidate')
        run([str(base / 'inherited/buffer_test')], 'buffer_test')
        run([str(base / 'inherited/tls_pair_test'), *arguments], 'tls_pair_test')
        complete = True
    finally:
        if pki.exists():
            names = {p.name for p in pki.iterdir()}
            if names - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected private fixture output; refusing broad cleanup')
            for name in names:
                (pki / name).unlink()
            pki.rmdir()
        (output / 'results.json').write_text(json.dumps({
            'complete': complete, 'commands': records,
            'private_pki_removed': not pki.exists(),
            'strict_postgresql_gate_closed': False,
            'requires_compiler_native_archives_or_native_source': False,
        }, indent=2) + '\n')
    print('PASS: baseline RED, candidate GREEN, 1440 differential cases, 12 control rows, 16 lifecycle cases and 2 inherited helpers; private PKI removed')


if __name__ == '__main__':
    main()
