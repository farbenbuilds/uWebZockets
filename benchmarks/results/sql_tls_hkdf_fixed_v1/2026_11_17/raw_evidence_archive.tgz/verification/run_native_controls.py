#!/usr/bin/env python3
"""Rebuild unchanged control and lifecycle witnesses against the KDF candidate."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('pki_helper', type=Path)
    parser.add_argument('--zig', default='/tmp/zig-x86_64-linux-0.16.0/zig')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    native = args.native_root.resolve(strict=True)
    helper = args.pki_helper.resolve(strict=True)
    if sha(helper) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('The verified PKI helper checksum differs')
    expected = json.loads((base / 'candidate/provenance.json').read_text())
    if sha(native / 'boringssl/crypto/fipsmodule/tls/kdf.cc.inc') != expected['native_source_sha256']:
        raise ValueError('Native KDF source differs from differential-tested candidate')
    retained_sources = {
        'include/openssl/ssl.h': 'd456d6ec611a3dd9f45fd2b701527875c66e589326cb158f8270d1146a959e2e',
        'ssl/internal.h': 'bdc63544965dfd787176a592a600ef0f86ad99aaacf5e204a4c59528bd691c37',
        'ssl/ssl_buffer.cc': '21f4621ef3fbed496a750d4723b450d8c6c83d47a74337801ab31b99c488bb38',
        'ssl/ssl_lib.cc': '6b4629af106bb53182465d8a6b8baf1dc56591594872333791296f008bd84827',
    }
    for name, checksum in retained_sources.items():
        if sha(native / 'boringssl' / name) != checksum:
            raise ValueError('Record-retention source changed: ' + name)
    control = base / 'controls'
    inherited = base / 'inherited'
    outputs = [control / 'results', inherited / 'build', inherited / 'results',
               inherited / 'lifecycle_test', inherited / 'buffer_test', inherited / 'tls_pair_test']
    if any(path.exists() or path.is_symlink() for path in outputs):
        raise ValueError('Witness output already exists; refusing overwrite')
    control_output, build_output = control / 'results', inherited / 'build'
    control_output.mkdir()
    build_output.mkdir()
    environment = dict(os.environ)
    environment['ZIG_GLOBAL_CACHE_DIR'] = '/tmp/uwz-zig-cache'
    commands = []
    archives = [native / 'native_out/lib/libssl.a', native / 'native_out/lib/libcrypto.a']
    provenance = {'native_archive_sha256': {p.name: sha(p) for p in archives},
                  'native_source_changed': True,
                  'native_kdf_sha256': expected['native_source_sha256'],
                  'record_retention_source_sha256': retained_sources,
                  'optimization': 'Debug (-O0 -g)',
                  'source_sha256': {str(p.relative_to(base)): sha(p)
                    for folder in [control, inherited] for p in folder.iterdir() if p.is_file()}}

    def run(command, log, expected_status=0):
        with log.open('wb') as stream:
            result = subprocess.run(command, cwd=base, env=environment,
                                    stdout=stream, stderr=subprocess.STDOUT)
        commands.append({'command': command, 'exit_code': result.returncode,
                         'log': str(log.relative_to(base))})
        (base / 'native_control_commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode != expected_status:
            raise RuntimeError('Command failed: ' + str(log))

    run([args.zig, 'cc', '-c', str(control / 'allocation_scope.c'), '-O0', '-g',
         '-fno-omit-frame-pointer', '-o', str(control_output / 'allocation_scope.o')],
        control_output / 'build-counter.log')
    common = [args.zig, 'c++', '-std=c++17', '-O0', '-g', '-Wall', '-Wextra',
              '-Werror', '-DBORINGSSL_IMPLEMENTATION', '-isystem', str(native),
              '-isystem', str(native / 'boringssl'), '-isystem', str(native / 'boringssl/include')]
    run([*common, str(control / 'control_witness.cc'), str(control_output / 'allocation_scope.o'),
         *[str(p) for p in archives], '-o', str(control_output / 'control_witness')],
        control_output / 'build-witness.log')
    cflags = [args.zig, 'cc', '-std=c11', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
              '-fno-builtin-malloc', '-fno-builtin-calloc', '-fno-builtin-realloc', '-fno-builtin-free']
    for stem in ['lifecycle_alloc', 'buffer_allocation_scope', 'cleansed_free_hook']:
        run([*cflags, '-c', str(inherited / (stem + '.c')), '-o', str(build_output / (stem + '.o'))],
            build_output / ('compile-' + stem + '.log'))
    run([*common, str(inherited / 'lifecycle_test.cc'), str(build_output / 'lifecycle_alloc.o'),
         *[str(p) for p in archives], '-o', str(inherited / 'lifecycle_test')],
        build_output / 'link-lifecycle.log')
    for stem in ['buffer_test', 'tls_pair_test']:
        run([*common, str(inherited / (stem + '.cc')),
             str(build_output / 'buffer_allocation_scope.o'), str(build_output / 'cleansed_free_hook.o'),
             *[str(p) for p in archives], '-o', str(inherited / stem)],
            build_output / ('link-' + stem + '.log'))
    pki = base / 'private_pki'
    if pki.exists() or pki.is_symlink():
        raise ValueError('Private PKI output already exists')
    try:
        run([str(helper), 'pki', str(pki)], control_output / 'pki_metadata.json')
        arguments = [str(pki / name) for name in ['server.pem', 'server.key', 'ca.pem']]
        run([str(control_output / 'control_witness'), *arguments,
             str(control_output / 'operations.csv'), str(control_output / 'summary.jsonl')],
            control_output / 'run.log')
        run([sys.executable, str(control / 'verify_results.py'), str(control_output),
             '--operations', 'operations.csv', '--summary', 'summary.jsonl'],
            control_output / 'verification.json')
        run([sys.executable, str(inherited / 'run_cases.py'), '--pki', str(pki),
             '--output', str(inherited / 'results')], build_output / 'lifecycle-driver.log')
        run([str(inherited / 'buffer_test')], build_output / 'buffer_test.log')
        run([str(inherited / 'tls_pair_test'), *arguments], build_output / 'tls_pair_test.log')
    finally:
        if pki.exists():
            names = {p.name for p in pki.iterdir()}
            if names - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected private fixture output; refusing broad cleanup')
            for name in names:
                (pki / name).unlink()
            pki.rmdir()
        (base / 'native_control_provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    print('PASS: 12 public control rows, 16 lifecycle cases, buffer and TLS-pair helpers; private PKI removed')


if __name__ == '__main__':
    main()
