# Fixed-buffer TLS HKDF verification

Final evidence is frozen under this directory. Native source and libraries are
owned by the separate `/tmp/uwz-pg-tls-hkdf-fixed-20261117` experiment.

The final `hkdf_witness.cc` uses a documented digest-function alias. Its
unchanged-baseline RED is `baseline/`; `preliminary/` preserves the earlier
source spelling and results with an explicit classification. The final and
preliminary baseline measurement rows are byte-identical. `baseline_frozen.json`
records the final baseline and exact fixture/interposer hashes.

- 1440 cases cover SHA-1/256/384/512, binary/empty label/context inputs,
  label lengths 248/249/250, context lengths 254/255/256, the maximum
  514-byte encoding, zero/digest/max-HKDF output boundaries and 65535/65536.
- Each output hash covers the complete 65,568-byte fixed buffer, including
  unwritten sentinel bytes. Valid encodings also compare every buffer byte
  against independent manual HkdfLabel serialization plus unchanged HKDF_expand.
  All return values and complete error library/reason queues match baseline.
- Baseline has 700 successful cases with malloc1/free1; candidate has 700
  successful cases with zero malloc/calloc/realloc/free/bytes. Both preserve
  the same 740 rejected cases. Invalid-path allocation is not claimed zero.
- The original all-C interposer is byte-identical and its self-test observes
  malloc1/calloc1/realloc1/free2 and 63 requested bytes. Error queues and
  digest dispatch are primed outside the complete-call measurement interval.
- Unchanged public control source and verifier validate 12 rows / 255 client
  SSL operations and all TLS/payload/peer-response checks. The read counts
  become initial tickets 14malloc/14free/2128B, non-requested KeyUpdate
  3/3/656B and requested KeyUpdate 9/7/1464B. The subsequent response write
  remains 0malloc/2free. Each vector is stable over three fresh pairs.
  Initially queued tickets are not arbitrary later tickets or PostgreSQL queries.
- Rebuilt unchanged inherited fixtures pass 16 lifecycle cases, 256 buffer
  retention loops and seven record sizes through 16,384 bytes under bounded
  BIO backpressure. Failure injection remains separate from ordinary counting.

`controls/baseline_summary_v2.jsonl` is the old raw summary; run
`python3 compare_controls.py` to recompute all count reductions offline.
`compare_results.py baseline/observe.stdout candidate/observe.stdout` checks
the strict differential and successful-call allocation assertions offline.

The prebuilt replay requires no compiler, native source or native archives:

```sh
python3 replay_prebuilt.py --pki-tool /absolute/path/to/wt-tools --output /tmp/uwz-hkdf-new-replay
```

The output must be absent and outside this evidence directory. The helper hash
is checked against the previously retained PKI helper. Six helper binaries are
checked against `prebuilt_identity.json`; `replay_validation/` retains a full
successful replay. Existing-output, inside-evidence and wrong-helper refusal
checks are in `replay_negative_results.json`. Owned temporary private PKI is
removed in a finally block. No certificates or private keys are retained here.

Source rebuild entry points are `run_witness.py NATIVE_ROOT NEW_OUTPUT`
and `run_native_controls.py NATIVE_ROOT PKI_HELPER`; the latter refuses
existing witness outputs, so use a fresh copy without the listed generated
outputs for source replay. These use Zig 0.16.0 Debug through the existing
complete native-library build; exact commands, archive/source identities and
logs are retained. This is ordinary functional/allocation evidence; deferred
smoke/security/sanitizer/fuzz campaigns were not run.

This removes one native KDF serialization allocation site. Strict PostgreSQL
request-path allocation remains open. No production pin, fork publication,
production API, FIPS certification or release-completion claim follows.
