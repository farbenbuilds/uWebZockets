#!/usr/bin/env python3
"""Recompute the retained control-count reductions from the two raw summaries."""
import hashlib
import json
from pathlib import Path


def main():
    base = Path(__file__).resolve().parent
    before_file = base / 'controls/baseline_summary_v2.jsonl'
    after_file = base / 'controls/results/summary.jsonl'
    before = [json.loads(row) for row in before_file.read_text().splitlines()]
    after = [json.loads(row) for row in after_file.read_text().splitlines()]
    fields = ('malloc', 'calloc', 'realloc', 'free', 'bytes')
    phases = ('client_read', 'client_response_write')
    assert len(before) == len(after) == 12
    rows = []
    for left, right in zip(before, after):
        assert {key: value for key, value in left.items() if key not in phases} == {
            key: value for key, value in right.items() if key not in phases}
        record = {'round': right['round'], 'scenario': right['scenario']}
        for phase in phases:
            record[phase] = {'before': left[phase], 'after': right[phase],
                'reduction': {key: left[phase][key] - right[phase][key] for key in fields}}
            assert all(value >= 0 for value in record[phase]['reduction'].values())
        rows.append(record)
    print(json.dumps({'rows': rows,
        'baseline_summary_sha256': hashlib.sha256(before_file.read_bytes()).hexdigest(),
        'candidate_summary_sha256': hashlib.sha256(after_file.read_bytes()).hexdigest(),
        'unchanged_protocol_and_payload_metadata': True,
        'strict_postgresql_gate_closed': False}, indent=2))


if __name__ == '__main__':
    main()
