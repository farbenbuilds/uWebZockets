# Scope and acceptance

The known TLS 1.3 label-encoding heap allocation has a fixed protocol bound:
2 output-length bytes, two vector-length bytes and two vectors of at most
255 bytes each. Preserve the six-byte protocol prefix, existing CBB builders
and unchanged HKDF implementation, with a 514-byte fixed CBB and a successful
flush before borrowing data/length. Preserve service-indicator control flow,
implicit output-length narrowing, errors, outputs and ownership.

Verification owns the unchanged-baseline RED and candidate GREEN with the
original all-C interposer and self-test; crypto owns the one-file source
change and complete rebuild. Independent review checks the code and evidence.
Acceptance requires 1440 equivalent result/error/full-buffer rows, zero heap
operations for 700 successful candidate calls, real control/payload checks,
unchanged original four record-retention files and exactly one source change
across all 8709 native files.

This is an isolated native candidate. No production pin, API or maintained
fork changes. No FIPS certification or validation claim. Strict PostgreSQL
request-path allocation requirements remain open for other TLS storage sites.
Dedicated smoke/security/sanitizer/fuzz/scan campaigns are user-deferred.
