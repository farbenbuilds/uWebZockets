# Fixed TLS 1.3 HKDF label encoding

This is an isolated native proposal, not production adoption or a dependency
pin. The baseline is the exact BoringSSL d3bf4795ad5b79d646cddf2fec687da5b9b502db
source plus the earlier four-file record-buffer reservation prototype.

Root approved the edit only after the independent verifier recorded the
unchanged require-zero assertion failing: 1440 deterministic cases, including
700 valid outputs with one malloc/one real free each and a passing 63-byte
interposer self-test. Verification results and fixture belong to the companion
verification evidence rather than this implementation payload.

Only crypto/fipsmodule/tls/kdf.cc.inc changes among 8709 native entries:

- Baseline SHA-256: 51ac1cd7a3686284238ab6ef2a60279d6a5011645101aeb66f736052c11552c5
- Candidate SHA-256: abce47c85d1ee69e68e748b5e67159dd3514899e437fe60421a15f83264236a2

Both encoded variable fields have one-byte lengths. The complete encoding is
bounded by 2 + 1 + 255 + 1 + 255 = 514 bytes; the six-byte TLS prefix leaves
249 caller label bytes. A fixed CBB builds into a local array, flushes the final
child before accessing its borrowed data/length, and cleans up without ownership
transfer or heap free. HKDF math, existing builders, output-length narrowing,
FIPS lock/unlock span, error exits and success-only service indication remain
unchanged. No FIPS certification is claimed.

The complete native crypto and all 38 SSL translation units were rebuilt
together using Zig 0.16.0 native source lists, fresh local cache and no CMake
or generated-source tool. build-native.log records terminal exit zero and all
6 steps succeeded; native_archives.json records actual archive identities.
Debug archive bytes depend on source paths and are provenance, not portable
rebuild hash requirements. The original four retention sources remain exact.

Root's independent verifier reports the candidate 1440-case differential and
manual-reference suite passes, with 700 successes requiring zero allocator
calls and all 740 rejection return/output/error results unchanged. Twelve
public TLS control rows covering 255 operations, the 16 reservation lifecycle
cases and inherited buffer/record proofs also pass. This file does not replace
their retained commands, statuses and raw hashes.

## Source restoration and build

The implementation payload retains no source cache, full native copy or native
archive. It includes the baseline KDF file, full changed KDF file and minimal
patch, all four earlier retention files, input/source manifests, provenance,
builder sources and commands.

Use restore_source.py with the exact unmodified baseline package, hash
N-V-__8AAA5Ieg5843crc8uXWdNhmmfStwJqA-9TknJSx3_n:

    python3 restore_source.py /path/to/exact-boringssl-package ./boringssl
    /path/to/zig build -Doptimize=Debug --cache-dir /tmp/uwz-new-hkdf-cache \
      -p native_out -j2 --summary all

An already reserved-buffer candidate is accepted only with explicit
--source-kind retention. The helper verifies the entire expected old file
set/hashes, including the old KDF hash, and all five retained snapshots before
creating an absent destination. It copies source into that new location only
and invokes no patch program. Existing destinations are refused. It never
modifies a cached input. Root owns delivery validation of the final restored
layout; no additional implementation-side replay is claimed for this helper.
Python is an external experiment preparation tool, not a library dependency.

## Remaining scope

This removes one measured allocator site, not every TLS allocation. Independent
public controls still observe residual calls during KeyUpdate and initial
session tickets. Record reservation, session/AEAD ownership, alerts, reconnects,
other post-handshake paths, maintenance policy and production integration retain
their separate requirements. SQL-ALLOC-002 remains open; no PostgreSQL allocation
exception or production gate closure is claimed. Dedicated smoke/security/
sanitizer/fuzz/scan campaigns remain user-deferred.
