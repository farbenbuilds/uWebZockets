#!/usr/bin/env python3
"""Restore the fixed-label experiment from exact baseline or retention inputs."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat


def main():
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-kind', choices=['baseline', 'retention'], default='baseline')
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    arguments = parser.parse_args()
    source = arguments.source.resolve(strict=True)
    destination = arguments.destination.absolute()
    if destination.exists() or destination.is_symlink():
        raise ValueError('Choose an absent source destination')
    if destination.resolve().is_relative_to(source):
        raise ValueError('Source destination must not be inside its input')
    inventory = json.loads((base / 'baseline_source_inventory.json').read_text())
    original = json.loads((base / 'input_provenance.json').read_text())
    provenance = json.loads((base / 'provenance.json').read_text())
    expected_names = {entry['path'] for entry in inventory['entries']}
    actual_names = {
        path.relative_to(source).as_posix()
        for path in source.rglob('*') if path.is_file() or path.is_symlink()
    }
    if actual_names != expected_names:
        raise ValueError('Input source file set differs from the pinned tree')
    for entry in inventory['entries']:
        relative = PurePosixPath(entry['path'])
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('Unsafe source inventory path')
        path = source / entry['path']
        if 'symlink' in entry:
            if not path.is_symlink() or os.readlink(path) != entry['symlink']:
                raise ValueError('Source symlink differs: ' + entry['path'])
            continue
        expected = entry['sha256']
        if arguments.source_kind == 'baseline':
            expected = original['source_baseline_sha256'].get(entry['path'], expected)
        if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('Input source checksum differs: ' + entry['path'])
    snapshots = []
    for name, expected in provenance['snapshot_sha256'].items():
        payload = (base / 'candidate_source' / name).read_bytes()
        if hashlib.sha256(payload).hexdigest() != expected:
            raise ValueError('Candidate snapshot checksum differs: ' + name)
        snapshots.append((name, payload))
    shutil.copytree(source, destination, symlinks=True)
    for name, payload in snapshots:
        target = destination / name
        target.chmod(stat.S_IMODE(target.stat().st_mode) | stat.S_IWUSR)
        target.write_bytes(payload)
    print('Restored exact fixed-label candidate; ' +
          str(len(expected_names)) + ' source entries verified.')


if __name__ == '__main__':
    main()
