# Fixed-storage TLS HKDF evidence

This isolated native candidate replaces one heap-backed HkdfLabel encoding
with fixed 514-byte storage. It does not change production pins or close the
strict PostgreSQL request-path allocation gate. No PostgreSQL allocation
exception, native publication, FIPS certification or release is claimed.

After extraction into a fresh directory, verify files.sha256. Restore the
checksum-pinned PKI helper from the existing repository artifact, then replay
the six exact retained Linux x86-64 binaries into a new external directory:

```sh
sha256sum -c files.sha256
python3 restore_pki_tool.py /absolute/path/to/uWebZockets
python3 verification/replay_prebuilt.py --pki-tool tools/wt-tools --output /tmp/uwz-hkdf-new-replay
```

Choose an absent output directory outside this extracted evidence. Replay
requires baseline RED exit 1 and candidate GREEN exit 0, 1440 semantic/output/error
comparisons, 12 public control rows, 16 lifecycle cases and both inherited
buffer/record helpers. It verifies six helper checksums and removes its private
PKI. No compiler, native archives or network access is required. Root's actual
delivery-layout replay is retained under root_checks/delivery_replay/.

The direct comparison has 700 successful candidate calls with no allocator
operations and 740 matching rejections. Remaining control allocations persist:
ticket read 14 malloc/14 free/2128 bytes; non-requested KeyUpdate 3/3/656 bytes; requested
KeyUpdate 9/7/1464 bytes; following write 0 malloc/2 free. These synthetic TLS/BIO call
counts are not PostgreSQL query measurements.

Read native/HANDOFF.md for exact source restoration and Zig-only native build
inputs. Root verified both source modes against one of the 8709 candidate entries;
source_restore_results.json records that proof and pre-write refusal checks.
The named digest-function alias is the final fixture; preliminary/ preserves
its older spelling and repeated baseline. external_inputs.json distinguishes
inherited historical metadata from this increment.

The outer repository result README explains complete scopes, counts, root
checks and artifact verification. Dedicated smoke/security/sanitizer/fuzz/scan
campaigns remain user-deferred. Root's ordinary SQL-enabled unit suite passed
1158 tests; 24 existing live PostgreSQL cases skipped without fixture settings.
