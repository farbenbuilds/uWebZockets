# Independent crypto review: fixed-storage TLS HKDF label encoding

Date: 2026-11-17. Read-only review of the isolated candidate and frozen verification payload. No source, fixture, wrapper, documentation, package, dependency pin or production policy was edited by this reviewer. No runtime tests, builds, security scans or deferred campaigns were repeated. Cross-model skipped: non-interactive context.

## Verdict

No confirmed correctness, ownership, bounds, compatibility or security defect was found in the reviewed one-file candidate, direct differential fixture, inherited functional evidence, or frozen prebuilt replay wrapper. This report covers the exact identities below. It does not approve production integration, assert FIPS certification, or close the PostgreSQL request-path allocation gate.

The accepted project bar remains no request-path allocation after startup. This change removes one native label-serialization allocation site. The remaining nonzero ticket/KeyUpdate client-I/O counts show that a strict request-path claim still needs further native work and appropriate production measurement. Startup, clear and teardown are not subject to an invented whole-lifetime zero-allocation rule or a blanket exemption for actual request-path work.

## Exact source and build scope

- Baseline is pinned BoringSSL `d3bf4795ad5b79d646cddf2fec687da5b9b502db` plus the original four-file record-buffer candidate, under `/tmp/uwz-pg-tls-lifecycle-20261117/boringssl`.
- Candidate is `/tmp/uwz-pg-tls-hkdf-fixed-20261117/boringssl`.
- Independently compared SHA256 inventories of both full native source trees: 8709 files each, identical file sets, exactly one differing file, `crypto/fipsmodule/tls/kdf.cc.inc`. All four record-retention files are unchanged.
- Baseline KDF SHA256: `51ac1cd7a3686284238ab6ef2a60279d6a5011645101aeb66f736052c11552c5`.
- Candidate KDF SHA256: `abce47c85d1ee69e68e748b5e67159dd3514899e437fe60421a15f83264236a2`.
- The complete source-list native rebuild log records 6/6 successful steps for crypto and all 38 SSL translation units. Both libraries were rebuilt together; individual SSL objects were not substituted.
- Independently checked actual linked candidate archive hashes against direct/control provenance: `libcrypto.a` is `526c71bd9f4ad4aa2266e65576a46cadd2b516f4bc3a347b4ef718159dc6f53b`; `libssl.a` is `595a0113af92db72cf8ad73a9d5e6cc3b0bc36f5f5d6820d1f7b6b9c2584ad80`.

## Native implementation review

References in this section use the candidate native tree unless otherwise stated.

1. `crypto/fipsmodule/tls/kdf.cc.inc:153` bounds the local buffer to `2 + 1 + 255 + 1 + 255 = 514` bytes. The first byte-length field includes the six-byte `tls13 ` prefix, leaving at most 249 caller-label bytes; the second field holds at most 255 context bytes. This covers every valid encoding accepted by the existing builders.
2. The change preserves all existing integer and length-prefixed CBB builders and their order (`:157`). `CBB_add_u16` still receives `out_len` through its existing implicit 16-bit narrowing. No extra input policy or digest change is introduced.
3. Pinned `crypto/bytestring/cbb.cc:59` makes fixed-CBB initialization infallible, non-resizing and non-owning. Its reserve helper checks addition overflow and fixed capacity before any copy (`:79`); fixed-capacity overflow and oversized one-byte child lengths both report CRYPTO/OVERFLOW (`:95`, `:273`). This removes label heap ownership while preserving the tested invalid-input result/reason behavior.
4. The final `CBB_flush` completes and invalidates the active child before `CBB_data` and `CBB_len` are evaluated (`kdf.cc.inc:164`, `:171`). Those accessors require no active child (`cbb.cc:288`, `:297`). HKDF consumes the borrowed bytes synchronously while the local buffer remains alive. No pointer escapes the function.
5. `CBB_cleanup` is applied only to the top-level CBB and frees storage only when `can_resize` is set (`cbb.cc:65`). It does not free the stack buffer on success or failure. The old `OPENSSL_free(hkdf_label)` was correctly removed.
6. Both error and success paths preserve the same FIPS service-indicator lock span and unlock sites. Successful HKDF completion alone reaches `TLSKDF_verify_service_indicator` (`kdf.cc.inc:155`, `:166`, `:174`). This is a source-level control-flow check; no FIPS-enabled runtime or certification claim follows.
7. Existing BoringSSL HKDF and digest implementations remain unchanged. No secret-dependent branch, comparison, output logging, local key copy, protocol downgrade, replay policy change or bypass of verification was added. The new local serialization storage holds label/context information, not a copied input secret or derived key.

## Direct fixture and RED/GREEN evidence

The final verification root is `/tmp/uwz-sql-tls-hkdf-evidence-20261117/verification`, copied from `/tmp/uwz-pg-tls-hkdf-verify-20261117`.

- Final `hkdf_witness.cc` SHA256 is `79842bb9f9d81d532290799c47240dcd180ca041c8a57f72018355dc5d146d9c`. The preliminary source differs only by the later documented digest-function alias. Final baseline and candidate use this same final fixture.
- The all-C allocation interposer remains byte-identical to the original: SHA256 `afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac`. Its recorded self-test remains 1 malloc, 1 calloc, 1 realloc, 2 non-null frees and 63 requested bytes.
- Accounting surrounds only the complete native helper call (`hkdf_witness.cc:144` after the alias refinement). Fixture initialization, error draining, manual encoding, unchanged `HKDF_expand` reference, full-buffer comparison, SHA256 hashing and logging are outside the interval. Digest dispatch and thread error queues are explicitly primed outside accounting; no first-use allocation guarantee is claimed.
- The 1440-case matrix covers four digests and a cross-product of empty/binary inputs, label lengths through 249 and rejected 250, context lengths through 255 and rejected 256, zero/digest/max-HKDF output boundaries and 65535/65536. The 514-byte maximum encoding is exercised with successful outputs for every digest.
- Valid encodings are independently serialized by the fixture and passed to unchanged `HKDF_expand`; the fixture compares return value, the entire 65,568-byte output buffer and error library/reason queues. Invalid encodings require rejection, a wholly unchanged sentinel buffer and errors. Tail sentinels are checked for every call.
- Independently parsed all final baseline/candidate rows and compared case identity, input/digest lengths, return value, encoding-validity flag, full error queue and full-buffer SHA256: all 1440 match.
- Independently verified 700 successful baseline calls have exactly 1 malloc and 1 free; all 700 successful candidate calls have zero malloc/calloc/realloc/free/requested bytes. The other 740 cases preserve rejection. No invalid-path zero-allocation claim is made.
- The recorded baseline `--require-zero` status is 1; candidate status is 0. Both observe/require-zero row sets are byte-identical within their respective build. The final comparator explicitly requires 1440 cases, 700 zero-allocation successes and 740 rejections; it does not merely accept the build driver's deliberately RED-compatible expected-status selection.
- Final baseline helper SHA256 is `16209d329d4b915826ab44e92f52977053703f148d7336f116c20670d459f3c0`; candidate helper is `26afba4b04e16e1a52727b13d7b6cc0ecb243362987482c5c82c5546bb59e1fd`.

The matrix proves compatibility for its defined inputs and warmed native helper interval. It is not an exhaustive proof for every pointer precondition, pathological `size_t` value, memory-pressure condition, digest/provider, target or initial thread state.

## TLS controls and inherited regressions

The original public control source and all inherited source hashes match their prior versions. Independently checked the linked archives and all 14 recorded compile/link/run command exit codes. All are zero.

Independently reconciled all 255 client operations against all twelve control summaries. The three fresh-pair rounds have identical vectors:

| Candidate client phase | malloc | non-null free | Requested bytes |
| --- | ---: | ---: | ---: |
| Ticket-free payload reads | 0 | 0 | 0 |
| Two initially queued tickets, cache OFF, reads | 14 | 14 | 2128 |
| Peer KeyUpdate NOT_REQUESTED, reads | 3 | 3 | 656 |
| Peer KeyUpdate REQUESTED, reads | 9 | 7 | 1464 |
| Following response/application writes | 0 | 2 | 0 |

All calloc/realloc counts remain zero. The source still requires verified TLS 1.3, explicit CA/name validation, exact payload acceptance and the requested peer response. Peer work and validation remain outside client accounting. These are synthetic TLS/BIO client-call counts, not PostgreSQL per-query measurements, and initially queued tickets are not arbitrary later ticket minting.

All sixteen inherited lifecycle case commands and their parsed results, source/binary hashes and stdout/stderr hashes were independently checked. They pass with zero live tracked reservations and zero cleanse failures. The buffer and TLS-pair logs record the 256 capacity/alignment/compaction iterations and seven record lengths through 16384 under bounded BIO backpressure/short reads. Their claims remain limited to tracked reservation ownership and the stated record cases; configured DTLS/QUIC fixtures remain eligibility negatives rather than completed interoperability tests.

## Frozen replay and delivery review

- `replay_prebuilt.py` SHA256 is `1aac9020f0531c8c086f43d77e97672d1741f670d9379f8f49062d2ed6bb79e6`. It requires an absent output outside its evidence tree, verifies the exact PKI helper and an exact six-helper inventory/hash set before output creation, explicitly expects baseline RED 1 and candidate GREEN 0, invokes the semantic comparator, checks control vectors and lifecycle outcomes against retained records, and stops on any unexpected subprocess status.
- Its `finally` cleanup accepts only the three named generated PKI files and removes only those files and their directory. It uses no broad recursive removal. The fixture helper is pinned to SHA256 `531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9`.
- The recorded producer replay has all nine expected statuses and reports private PKI removed. Recorded negative checks reject existing output, output inside evidence and a wrong helper before creating their requested fresh outputs. This reviewer did not repeat them.
- Independently verified all 183 entries in the staged verification `files.sha256`, all 184 listed payload files, and all six helper identities. No certificate, key or native library archive is in that payload. Retained compiler objects are historical build evidence, not replay requirements.
- Reviewed `HANDOFF.md`, source build drivers and the current outer benchmark README. They preserve scope, result limits, explicit FIPS non-claim, ordinary-counter/fault-observer separation and the open PostgreSQL gate. Debug-path-dependent source-built archive variation is recorded rather than treated as a changed source input or weakened source check.
- Root's retained ordinary unit log reports 1158/1182 passed with 24 existing live-PostgreSQL skips, not a fully exercised database integration run. Formatting records 314 unchanged inputs; conventions/version commands record exit zero. The outer README labels those skips and deferred campaigns explicitly. This reviewer inspected that evidence without rerunning it.

At report time, Root's exact copied-layout replay and native-source recovery/bootstrap packaging were still being finalized. Final outer archive/manifest verification, inclusion of this report, and any subsequent wrapper or prose edits need their normal artifact checks. This is not a request to rerun the already reviewed proofs or resume deferred campaigns.

No production source, pin, maintained fork, public TLS API or PostgreSQL exception is changed or approved. Other control/session/AEAD/flight/error allocations, production integration, error/reconnect attribution and strict request-path proof remain open. Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain user-deferred.
