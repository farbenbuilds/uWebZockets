# Exact-pin bounded client profile source facts, 2026-11-17

Scope
Read-only analysis of /tmp/uwz-pg-tls-retention-20261117/boringssl, baseline
BoringSSL d3bf4795ad5b79d646cddf2fec687da5b9b502db plus the existing four-file
record-retention candidate. All paths below are relative to that scratch root.
Graphify queries preceded new source exploration. No protected vendor source was
read, no source was changed, and no runtime checks/campaigns were run here.
This report is a design input, not an allocation-gate completion claim. The HKDF
label/CBB implementation plan belongs to another agent and is excluded here.

1. Nominal message limit is not an hs_buf capacity

ssl/handshake.cc:135-163, ssl_max_handshake_message_len:
- In init: default body limit 16,384, raised to max_cert_list when receiving
  certificates under the stated client/server verification conditions.
- After handshake, pre-TLS1.3: body limit 0; TLS1.3 server: body limit 1
  (KeyUpdate only); TLS1.3 client: max(16,384, max_cert_list), for tickets.
include/openssl/ssl.h:5417-5419 defines default max_cert_list as 1024*100,
therefore the current ordinary client post-handshake nominal limit is 102,400,
not 16,384. ssl/ssl_lib.cc:69-70 and 1740-1755 clamp public context/connection
max_cert_list setters at (1<<24)-1; the limit is copied from the context into
SSLImpl at ssl/ssl_lib.cc:464. Reducing the setting also reduces the permitted
certificate-chain size; this is not a ticket-only memory setting.

ssl/s3_both.cc:380-405, parse_message, only parses a 4-byte handshake header and
its u24-sized body. For an incomplete message it returns bytes_needed=4+len;
for an incomplete header it returns 4. ssl/s3_both.cc:422-440,
tls_can_accept_handshake_data, rejects an already complete head (the caller
should consume it first), then compares bytes_needed against 4+the nominal
limit. ssl/tls_record.cc:99-103 performs this check BEFORE decrypting the next
record. ssl/tls_record.cc:202-228 bounds the resulting TLS1.3 content to
<=16,384 bytes after stripping content type/padding. ssl/s3_pkt.cc:251-265 then
appends the ENTIRE handshake content via tls_append_handshake_data, which has
no independent cap (ssl/s3_both.cc:455-462).

Source-derived conservative append bound, for a fixed limit M and a fresh
post-handshake buffer: before an accepted append there is no complete message;
a known incomplete head has buffered length <=M+3 (or header length <=3), so
after one entire record the logical length is <=M+3+16,384. Default client:
118,787 bytes. This is a conservative bound, not a tested tight maximum or a
promise that a complete oversized head is independently rejected: parse_message
and tls_get_message do not perform that separate length comparison. Coalesced
messages and a final record containing trailing bytes matter to sizing.

crypto/buf/buf.cc:38-63 reserves 4*floor((requested_cap+3)/3), not exact capacity;
81-96 appends with overflow checking and no policy cap. For the above default
fresh-buffer bound, a newly grown allocation is at most 158,384 bytes. Existing
capacity inherited from an earlier larger setting/buffer use is a separate
case; this formula does not shrink an existing allocation. The bound assumes
M is fixed while the buffer is populated. SSL_set_max_cert_list remains
callable after startup; raising it after reservation would invalidate a bound
computed from the earlier value. Changing the context value does not update an
already copied SSLImpl value. A future profile must freeze/revalidate its
effective connection setting explicitly; current public APIs do not do so.

ssl/s3_both.cc:532-551 consumes one message with memmove and normally frees
hs_buf once empty after the handshake. ssl/tls_method.cc:28-39 releases an
empty initial-handshake hs_buf. The existing record-buffer retention candidate
does not retain these handshake buffers. A future retained bounded profile
must address descriptor/data lifetime plus append slack, coalescing and
fragmentation. Reserving only M+4 is not enough for this implementation's
whole-record append behavior. No reservation implementation is proposed here.

2. AEAD state is inline for the three TLS1.3 ciphers, but update is not atomic

ssl/internal.h:2986-2997 owns read/write contexts by separate UniquePtr and
stores traffic secrets in InplaceVectors. SSLAEADContext contains cipher,
ScopedEVP_AEAD_CTX, inline fixed_nonce and nonce/AAD flags
(ssl/internal.h:504-627). There is no existing public or internal rekey method
on SSLAEADContext; Create allocates a new object at ssl/ssl_aead_ctx.cc:62 and
initializes its EVP context at 116-119. On allocation/init failure the currently
installed object is untouched.

include/openssl/aead.h:222-235 embeds an aligned 560-byte state union in
EVP_AEAD_CTX; ScopedEVP_AEAD_CTX is StackAllocated (637-639).
ssl/ssl_cipher.cc:470-495 maps the TLS1.3 cipher choices to AES-128-GCM-TLS13,
AES-256-GCM-TLS13, or ChaCha20-Poly1305 with 12-byte fixed IV and no MAC key.
- crypto/fipsmodule/cipher/e_aes.cc.inc:1130-1159 embeds AES-GCM key plus
  min_next_nonce/mask and resets min_next_nonce=0 at init. It uses the inline
  GCM key initializer at 733-753; cleanup is empty at 777. Both TLS1.3 method
  tables select this init/cleanup at 1204-1229. GCM128_KEY is inline tables,
  AES_KEY and function pointers (crypto/fipsmodule/aes/internal.h:325-334);
  its initializer zeroes/fills that storage at aes/gcm.cc.inc:253-296.
- crypto/cipher/e_chacha20poly1305.cc:34-69 embeds a 32-byte key, validates
  tag/key length, copies the key, and has an empty cleanup routine.
The malloc/free matches elsewhere in e_aes.cc.inc (for generic EVP cipher IV
storage) are not these TLS1.3 AEAD initializer paths.

This makes reuse of the existing heap object technically plausible for an
explicit same-cipher, same-direction, established ordinary TLS1.3 profile.
It is not safe to replace Create with a blind init call at its current position:
crypto/fipsmodule/cipher/aead.cc.inc:82-105 sets ctx->aead BEFORE initializing
and sets it to nullptr on failure; it does not preserve or clean up a live old
context. Generic initializer/cleanup contracts are not a failure-atomic rekey
API. Initializer preconditions, state reset, and old-state retention on failure
must be proved for the selected ciphers before any mutation. In particular,
resetting only SSL's sequence and changing the key without resetting the
AES-GCM TLS13 nonce tracker would violate its monotonic nonce guard
(e_aes.cc.inc:1175-1193). The fixed IV and TLS1.3 nonce/AAD flags also must remain
consistent with the newly derived key.

3. KeyUpdate ownership/order that reuse must preserve

ssl/tls13_enc.cc:397-409 derives the next traffic secret into an inline local
copy, then calls tls13_set_traffic_key. That function derives key/IV and creates
the candidate context (176-211), calls the protocol state hook, and commits
the corresponding stored traffic secret ONLY AFTER hook success (214-225).

Read side: ssl/tls13_both.cc:716-738 validates exactly one request byte (0/1),
rotates the read key, then schedules a NOT_REQUESTED response if needed.
ssl/tls_method.cc:43-71 rejects unprocessed handshake bytes in the old epoch
before installing context/resetting read_sequence. The current message is
excluded by tls_has_unprocessed_handshake_data (s3_both.cc:442-453); trailing
bytes in that same old-key record are not. Mutating the installed read context
before this guard would change current failure behavior and state ordering.

Write side: tls13_add_key_update (tls13_both.cc:680-713) coalesces an already
pending update; otherwise it queues the KeyUpdate message, rotates the write
key for TLS, then marks key_update_pending. tls_set_write_state
(tls_method.cc:75-100) FIRST flushes pending plaintext handshake bytes, then
installs context and resets write_sequence. Thus KeyUpdate is sealed under
the old key while subsequent application records use the new key.

s3_both.cc:149-167 transfers ownership of pending_hs_data to a local and seals
it into pending_flight via add_record_to_flight:42-73. pending_flight is
ciphertext, not a reference to the old AEAD, so it may survive a key transition.
The old context is required until pending plaintext has been sealed. Failure
in this flush returns before the current context/traffic secret is replaced,
although the moved pending plaintext buffer is then destroyed; do not claim
all outgoing state is transactionally unchanged on every error.

s3_pkt.cc:130-153 checks pending-write retry consistency and drains existing
write ciphertext first. At 162-219 it flushes handshake plaintext, copies older
pending-flight ciphertext to the write buffer, seals new app data, then
uncorks key_update_pending. Backpressure retains the application input span
at 221-229. s3_both.cc:218-245 also writes prior write_buffer ciphertext before
pending_flight and keeps a partial-flight offset. Existing ciphertext does not
need the old key, but its wire order and retries must remain exact. Note
key_update_pending is uncorked when ciphertext is staged, before the final
transport flush necessarily completes; do not invent a stronger wire-complete
invariant from the nearby comment.

Role/protocol exclusions: TLS1.3 KeyUpdate is allowed for both client and server
and valid request bytes must still be honored. tls13_post_handshake only
accepts NST for clients; rejects QUIC KeyUpdate and >32 consecutive updates
(tls13_both.cc:38-41,741-761). Reading application data resets the counter at
ssl_lib.cc:923-925. TLS<1.3 takes the distinct renegotiation path
(ssl_lib.cc:789-819). QUIC creates placeholder contexts/calls external secret
callbacks (tls13_enc.cc:184-187; tls_method.cc:53-67,82-96).
DTLS is fundamentally different: it delays outgoing rotation until ACK
(tls13_both.cc:703); read state installs a next epoch and record-number cipher,
and write state retains prior epochs (ssl/dtls_method.cc:71-139). None of
those paths can be silently covered by ordinary TLS context reuse.
A narrowly scoped client profile must explicitly reject/exclude unsupported
role/protocol/handshake states at eligibility time while leaving generic paths
unchanged; no lifecycle implementation is analyzed or proposed here.

Caller-visible semantics: retain verified handshake/host and TLS1.3 negotiation,
valid incoming key updates and response ordering, malformed/control-message
alerts and limits, application-data delivery, SSL_get_error/WANT handling,
SSL_write retry-buffer rules, zero-length writes flushing queued control data,
and current callback invocation/message visibility when supported. The public
contracts are ssl.h:263-277,315-365; SSL_key_update requires a completed >=1.3
handshake and rejects QUIC at ssl_lib.cc:1009-1033. No caller should have to
pre-drain an unknown future ticket/update to satisfy a request-path contract.
Exact error/reconnect allocation attribution remains unresolved by this report.

4. Earliest unused-ticket discard after validation

Current tls13_process_new_session_ticket (ssl/tls13_client.cc:1217-1238)
ignores tickets during write shutdown BEFORE parsing, otherwise unconditionally
constructs a session and only THEN checks the effective session_ctx's CLIENT
cache bit and new_session_cb at 1231-1235. Cache off/null callback does not
currently avoid construction. Preserve the shutdown branch's existing policy.

The current parser's order is:
- SSL_SESSION_dup at 1243, clock/lifetime rebasing at 1249;
- scalar/nonce/ticket/extensions framing, nonempty ticket and no body trailer
  at 1251-1263, with ticket.CopyFrom already at 1258;
- timeout capping at 1266-1270; PSK derivation at 1272-1275;
- extension framing, recognized-duplicate handling and unknown-ignore policy
  at 1277-1284; helper ssl_parse_extensions is handshake.cc:175-227;
- early_data exactly u32/no trailer and QUIC's special limit at 1286-1301;
- flags syntax/unknown-flag policy at 1303-1312; flags helper is
  extensions.cc:391-433 (nonempty u8-length vector, no trailer/trailing zero,
  stack-local extraction; unknown request flags permitted).
The final existing syntax/extension validation completes at 1312, before fake
session-ID SHA256 and resumability bookkeeping at 1314-1320. Unknown extensions
are skipped by the helper; duplicate checking only tracks its recognized
SSLExtension entries. Preserve that current behavior, do not accidentally claim
the helper checks every unknown extension for duplication.

An allocation-saving discard has no ready-made insertion point in today's
order: allocations occurred before validation. The earliest logical point is
after the above framing, early_data and flags validations, with their outputs
parsed into scalar/CBS locals, and before session duplication, ticket copy,
clock/lifetime rebasing and PSK derivation. This requires splitting/reordering
parsing from retained-session construction; it is not a safe unconditional
return at function entry or merely an early test of cache flags. Span-backed
inputs must remain valid until the message is consumed by tls_next_message.
Use the effective session_ctx mode/callback at processing time; runtime option
or callback changes must not make an opted-out result silently resumable.
A conservative optional profile can require cache OFF AND no callback. The
existing function has a session sink only when both CLIENT caching AND a
callback are enabled, but expanding eligibility to any weaker condition is a
separate explicit contract choice. Resumption/callback users must keep session
creation and ownership transfer behavior. Message callbacks fire at
s3_both.cc:413-417 before this parser, so a discard must not hide valid received
messages from that observation. Current rebasing invokes the time source
(ssl_session.cc:169-170); whether an opt-out profile intentionally skips that
otherwise useless callback invocation should be documented rather than claimed
invisible. Reordering construction also changes allocation-failure precedence
relative to malformed-message errors; that is not proven equivalent here.

Unresolved work before adoption
- Frozen eligibility/bounds, retained control-buffer ownership, failure paths
  and lifecycle/clear proof are not implemented or verified here.
- AEAD rekey failure atomicity and all selected-cipher/platform behavior need
  functional evidence; source layout is not sufficient proof of correctness.
- Pending control flight and record buffers need independent bounds under
  fragmentation/coalescing, queued updates and nonblocking retry states.
- Ticket discard needs a validation/construction separation with a precise
  opt-out contract; existing options alone do not supply this behavior.
- Error/reconnect allocation accounting and dedicated deferred campaigns remain
  unresolved; no broader all-lifetime guarantee or automatic exemption is added.
