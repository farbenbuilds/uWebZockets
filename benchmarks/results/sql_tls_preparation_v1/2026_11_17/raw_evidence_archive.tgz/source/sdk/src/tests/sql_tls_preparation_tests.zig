const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const sql = support.sql;
const helpers = @import("tls_tests.zig");
const net = std.Io.net;

/// A real verified memory-BIO handshake feeds a production SQL socket callback.
const Fixture = struct {
    connection: sql.connection.Connection = .{},
    loop: support.loop.Loop = undefined,
    scheduler: support.timer.Scheduler = undefined,
    server_context: support.tls.TlsContext = undefined,
    client_context: *c.SSL_CTX = undefined,
    server: *c.SSL = undefined,
    server_bio: *c.BIO = undefined,
    peer: net.Stream = undefined,
    receive: [4096]u8 = undefined,
    response: [4096]u8 = undefined,
    transmit: [4096]u8 = undefined,
    ready_calls: usize = 0,
    close_calls: usize = 0,
    closed_failure: ?sql.RuntimeError = null,

    fn init(self: *Fixture, cancel: bool) !void {
        self.loop = try support.loop.init();
        errdefer support.loop.deinit(&self.loop);
        self.scheduler = try support.timer.Scheduler.init(std.testing.io);
        errdefer self.scheduler.deinit();
        self.server_context = try support.tls.TlsContext.init_ephemeral(.{});
        errdefer self.server_context.deinit();
        // Tickets are exercised separately from the handshake's Finished flight.
        try std.testing.expectEqual(@as(c_int, 1), c.SSL_CTX_set_num_tickets(self.server_context.ctx, 0));
        self.client_context = c.SSL_CTX_new(c.TLS_client_method()) orelse return error.ClientContextFailed;
        errdefer c.SSL_CTX_free(self.client_context);
        try std.testing.expectEqual(@as(c_int, 1), c.SSL_CTX_set_min_proto_version(self.client_context, c.TLS1_3_VERSION));
        try std.testing.expectEqual(@as(c_int, 1), c.SSL_CTX_set_max_proto_version(self.client_context, c.TLS1_3_VERSION));
        c.SSL_CTX_set_verify(self.client_context, c.SSL_VERIFY_PEER, null);
        const certificate = c.SSL_CTX_get0_certificate(self.server_context.ctx).?;
        try std.testing.expectEqual(@as(c_int, 1), c.X509_STORE_add_cert(c.SSL_CTX_get_cert_store(self.client_context), certificate));
        // The caller trusts this exact development leaf, rather than a CA.
        try std.testing.expectEqual(@as(c_int, 1), c.X509_STORE_set_flags(c.SSL_CTX_get_cert_store(self.client_context), c.X509_V_FLAG_PARTIAL_CHAIN));
        try self.connection.session.init_for_protocol(self.client_context, "localhost", true, .postgres);
        errdefer self.connection.session.deinit();
        self.server = c.SSL_new(self.server_context.ctx) orelse return error.ServerSessionFailed;
        errdefer c.SSL_free(self.server);
        self.server_bio = try helpers.attach_client_bio(self.server);
        errdefer _ = c.BIO_free(self.server_bio);
        c.SSL_set_accept_state(self.server);
        for (0..16) |_| {
            try handshake(self.connection.session.ssl.?);
            try transfer(self.connection.session.network_bio.?, self.server_bio);
            try handshake(self.server);
            try transfer(self.server_bio, self.connection.session.network_bio.?);
            if (c.SSL_is_init_finished(self.server) == 1 and c.SSL_is_init_finished(self.connection.session.ssl.?) == 1) break;
        }
        try std.testing.expectEqual(@as(c_int, 1), c.SSL_is_init_finished(self.server));
        try std.testing.expectEqual(@as(c_int, 1), c.SSL_is_init_finished(self.connection.session.ssl.?));
        try std.testing.expectEqual(@as(c_long, c.X509_V_OK), c.SSL_get_verify_result(self.connection.session.ssl.?));

        const address = try net.IpAddress.parse("127.0.0.1", 0);
        var listener = try address.listen(std.testing.io, .{});
        defer listener.deinit(std.testing.io);
        self.connection.receive = &self.receive;
        self.connection.response = &self.response;
        self.connection.transmit = &self.transmit;
        try self.connection.start(.{
            .loop = &self.loop,
            .scheduler = &self.scheduler,
            .io = std.testing.io,
            .config = .{
                .port = listener.socket.address.getPort(),
                .user = "preparation_test",
                .database = "preparation_test",
                .tls = .{ .ca_path = "caller_owned_trust", .server_name = "localhost" },
                .connect_timeout_ms = 1000,
            },
            .context = self,
            .index = 0,
            .ready = ready,
            .closed = closed,
            .complete = complete,
            .cancel_key = if (cancel) .{ .pid = 123, .secret = 456 } else null,
        });
        errdefer {
            self.connection.stop(error.ConnectionClosed);
            self.loop.xev_loop.run(.until_done) catch @panic("SQL fixture startup did not drain");
        }
        try self.settle();
        self.peer = try listener.accept(std.testing.io);
        errdefer self.peer.close(std.testing.io);
        try support.tcp.set_receive_timeout(self.peer.socket.handle, 1000);
        try self.settle();
        var ssl_request: [8]u8 = undefined;
        try read_exact(self.peer, &ssl_request);
        try std.testing.expectEqualSlices(u8, &.{ 0, 0, 0, 8, 4, 210, 22, 47 }, &ssl_request);
        try std.testing.expectEqualStrings("ssl_response", @tagName(self.connection.phase));
    }

    fn deinit(self: *Fixture) void {
        self.connection.stop(error.ConnectionClosed);
        self.loop.xev_loop.run(.until_done) catch @panic("SQL TLS fixture did not drain");
        self.connection.session.deinit();
        self.peer.close(std.testing.io);
        c.SSL_free(self.server);
        _ = c.BIO_free(self.server_bio);
        c.SSL_CTX_free(self.client_context);
        self.server_context.deinit();
        self.scheduler.deinit();
        support.loop.deinit(&self.loop);
    }

    fn settle(self: *Fixture) !void {
        for (0..16) |_| try self.loop.xev_loop.run(.no_wait);
    }

    fn begin(self: *Fixture) !void {
        try helpers.write_socket_request(std.testing.io, self.peer.socket.handle, "S");
        try self.loop.xev_loop.run(.once);
        try self.settle();
    }

    fn send(self: *Fixture, bytes: []const u8) !void {
        try helpers.write_socket_request(std.testing.io, self.peer.socket.handle, bytes);
        try self.loop.xev_loop.run(.once);
        try self.settle();
    }

    fn receive_startup(self: *Fixture, cancel: bool) !void {
        var ciphertext: [4096]u8 = undefined;
        var plaintext: [4096]u8 = undefined;
        var expected: [4096]u8 = undefined;
        const expected_len = if (cancel) try sql.pg_wire.cancel(&expected, 123, 456) else try sql.pg_wire.startup(&expected, "preparation_test", "preparation_test");
        for (0..8) |_| {
            var buffers = [_][]u8{&ciphertext};
            const count = try std.testing.io.vtable.netRead(std.testing.io.userdata, self.peer.socket.handle, &buffers);
            try std.testing.expect(count > 0);
            try bio_write(self.server_bio, ciphertext[0..count]);
            const length = c.SSL_read(self.server, &plaintext, plaintext.len);
            if (length <= 0) {
                const failure = c.SSL_get_error(self.server, length);
                try std.testing.expectEqual(@as(c_int, c.SSL_ERROR_WANT_READ), failure);
                continue;
            }
            try std.testing.expectEqualSlices(u8, expected[0..expected_len], plaintext[0..@intCast(length)]);
            try std.testing.expectEqual(@as(usize, 0), self.ready_calls);
            return;
        }
        return error.StartupNotReceived;
    }

    fn ready(context: *anyopaque, _: usize) void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        self.ready_calls += 1;
        std.debug.assert(self.connection.tls_prepared);
    }

    fn closed(context: *anyopaque, _: usize, failure: sql.RuntimeError) void {
        const self: *Fixture = @ptrCast(@alignCast(context));
        self.close_calls += 1;
        self.closed_failure = failure;
    }

    fn complete(_: *anyopaque, _: usize, _: sql.QueryOutcome) void {
        @panic("preparation cannot complete a query");
    }
};

fn handshake(ssl: *c.SSL) !void {
    const result = c.SSL_do_handshake(ssl);
    if (result == 1) return;
    const failure = c.SSL_get_error(ssl, result);
    try std.testing.expect(failure == c.SSL_ERROR_WANT_READ or failure == c.SSL_ERROR_WANT_WRITE);
}

fn bio_write(bio: *c.BIO, bytes: []const u8) !void {
    try std.testing.expectEqual(@as(c_int, @intCast(bytes.len)), c.BIO_write(bio, bytes.ptr, @intCast(bytes.len)));
}

fn transfer(source: *c.BIO, destination: *c.BIO) !void {
    var buffer: [4096]u8 = undefined;
    while (c.BIO_ctrl_pending(source) != 0) {
        const count = c.BIO_read(source, &buffer, buffer.len);
        try std.testing.expect(count > 0);
        try bio_write(destination, buffer[0..@intCast(count)]);
    }
}

fn read_exact(peer: net.Stream, bytes: []u8) !void {
    var offset: usize = 0;
    while (offset != bytes.len) {
        var buffers = [_][]u8{bytes[offset..]};
        const count = try std.testing.io.vtable.netRead(std.testing.io.userdata, peer.socket.handle, &buffers);
        if (count == 0) return error.UnexpectedEof;
        offset += count;
    }
}

fn key_update(fixture: *Fixture, output: []u8, requested: bool) ![]const u8 {
    try std.testing.expectEqual(@as(c_int, 1), c.SSL_key_update(fixture.server, if (requested) c.SSL_KEY_UPDATE_REQUESTED else c.SSL_KEY_UPDATE_NOT_REQUESTED));
    const zero = c.SSL_write(fixture.server, output.ptr, 0);
    try std.testing.expectEqual(@as(c_int, 0), zero);
    const count = c.BIO_read(fixture.server_bio, output.ptr, @intCast(output.len));
    try std.testing.expect(count > 6);
    return output[0..@intCast(count)];
}

test "sql TLS preparation: fragmented requested update waits before Startup and expires on its original deadline" {
    var fixture: Fixture = .{};
    try fixture.init(false);
    defer fixture.deinit();
    var record: [256]u8 = undefined;
    const control = try key_update(&fixture, &record, true);
    try bio_write(fixture.connection.session.network_bio.?, control[0..6]);
    const deadline = fixture.connection.deadline.deadline_ms;
    try fixture.begin();
    try std.testing.expectEqualStrings("tls_preparing", @tagName(fixture.connection.phase));
    try std.testing.expectEqual(@as(usize, 8), fixture.connection.transmit_len);
    try std.testing.expectEqual(@as(usize, 8), fixture.connection.transmit_sent);
    try std.testing.expectEqual(deadline, fixture.connection.deadline.deadline_ms);
    try std.testing.expectEqual(@as(usize, 0), fixture.ready_calls);
    fixture.scheduler.wheel.advance(deadline);
    try fixture.settle();
    try std.testing.expectEqual(@as(usize, 1), fixture.close_calls);
    try std.testing.expectEqual(@as(?sql.RuntimeError, error.QueryTimeout), fixture.closed_failure);
}

test "sql TLS preparation: fragmented update resumes once before Startup or auxiliary CancelRequest" {
    for ([_]bool{ false, true }) |cancel| {
        var fixture: Fixture = .{};
        try fixture.init(cancel);
        defer fixture.deinit();
        var record: [256]u8 = undefined;
        const control = try key_update(&fixture, &record, true);
        try bio_write(fixture.connection.session.network_bio.?, control[0..6]);
        try fixture.begin();
        try std.testing.expectEqualStrings("tls_preparing", @tagName(fixture.connection.phase));
        try fixture.send(control[6..]);
        try std.testing.expectEqualStrings(if (cancel) "canceling" else "authenticating", @tagName(fixture.connection.phase));
        try fixture.receive_startup(cancel);
        try std.testing.expectEqual(@as(usize, 0), c.BIO_ctrl_pending(fixture.connection.session.network_bio.?));
        try std.testing.expectEqual(fixture.connection.transmit_len, fixture.connection.transmit_sent);
        try std.testing.expectEqual(@as(usize, 0), fixture.close_calls);
        try std.testing.expect(fixture.connection.tls_prepared);
        if (cancel) {
            try std.testing.expect(fixture.connection.cancel_sent);
            continue;
        }
        const authentication = "R\x00\x00\x00\x08\x00\x00\x00\x00Z\x00\x00\x00\x05I";
        try std.testing.expectEqual(@as(c_int, authentication.len), c.SSL_write(fixture.server, authentication.ptr, authentication.len));
        var ciphertext: [256]u8 = undefined;
        const count = c.BIO_read(fixture.server_bio, &ciphertext, ciphertext.len);
        try std.testing.expect(count > 0);
        try fixture.send(ciphertext[0..@intCast(count)]);
        try std.testing.expectEqual(@as(usize, 1), fixture.ready_calls);
        fixture.connection.stop(error.ConnectionClosed);
        try fixture.settle();
        try std.testing.expect(!fixture.connection.tls_prepared);
    }
}

test "sql TLS preparation: unsolicited plaintext fails before Startup" {
    var fixture: Fixture = .{};
    try fixture.init(false);
    defer fixture.deinit();
    const unsolicited = "R\x00\x00\x00\x08\x00\x00\x00\x00Z\x00\x00\x00\x05I";
    try std.testing.expectEqual(@as(c_int, unsolicited.len), c.SSL_write(fixture.server, unsolicited.ptr, unsolicited.len));
    try transfer(fixture.server_bio, fixture.connection.session.network_bio.?);
    try fixture.begin();
    try std.testing.expectEqual(@as(?sql.RuntimeError, error.ProtocolError), fixture.closed_failure);
    try std.testing.expectEqual(@as(usize, 1), fixture.close_calls);
    try std.testing.expectEqual(@as(usize, 0), fixture.ready_calls);
}

test "sql TLS preparation: ineligible client cache fails without sending Startup" {
    var fixture: Fixture = .{};
    try fixture.init(false);
    defer fixture.deinit();
    _ = c.SSL_CTX_set_session_cache_mode(fixture.client_context, c.SSL_SESS_CACHE_CLIENT);
    try fixture.begin();
    try std.testing.expectEqual(@as(?sql.RuntimeError, error.TlsFailed), fixture.closed_failure);
    try std.testing.expectEqual(@as(usize, 1), fixture.close_calls);
    try std.testing.expectEqual(@as(usize, 0), fixture.ready_calls);
}

test "sql TLS preparation: idle verified session sends Startup without admitting a SQL slot" {
    var fixture: Fixture = .{};
    try fixture.init(false);
    defer fixture.deinit();
    try fixture.begin();
    try std.testing.expect(fixture.connection.tls_prepared);
    try std.testing.expectEqualStrings("authenticating", @tagName(fixture.connection.phase));
    try fixture.receive_startup(false);
}

test "sql TLS preparation: coalesced complete updates flush their response before Startup" {
    var fixture: Fixture = .{};
    try fixture.init(false);
    defer fixture.deinit();
    var first_record: [256]u8 = undefined;
    var second_record: [256]u8 = undefined;
    const first = try key_update(&fixture, &first_record, false);
    const second = try key_update(&fixture, &second_record, true);
    try bio_write(fixture.connection.session.network_bio.?, first);
    try bio_write(fixture.connection.session.network_bio.?, second);
    try fixture.begin();
    try std.testing.expect(fixture.connection.tls_prepared);
    try fixture.receive_startup(false);
    try std.testing.expectEqual(@as(c_int, 0), c.SSL_has_pending(fixture.connection.session.ssl.?));
    try std.testing.expectEqual(@as(usize, 0), c.BIO_ctrl_pending(c.SSL_get_rbio(fixture.connection.session.ssl.?)));
}

test "sql TLS preparation: peer close is classified before zero control-flush success" {
    var fixture: Fixture = .{};
    try fixture.init(false);
    defer fixture.deinit();
    try std.testing.expectEqual(@as(c_int, 0), c.SSL_shutdown(fixture.server));
    try transfer(fixture.server_bio, fixture.connection.session.network_bio.?);
    try fixture.begin();
    try std.testing.expectEqual(@as(?sql.RuntimeError, error.ConnectionClosed), fixture.closed_failure);
    try std.testing.expectEqual(@as(usize, 1), fixture.close_calls);
    try std.testing.expect(!fixture.connection.tls_prepared);
    try std.testing.expectEqual(@as(usize, 8), fixture.connection.transmit_len);
}
