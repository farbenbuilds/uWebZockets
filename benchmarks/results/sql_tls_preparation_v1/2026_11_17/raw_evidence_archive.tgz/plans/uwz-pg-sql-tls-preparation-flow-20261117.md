# Minimal SQL TLS preparation pump

Read-only control-flow follow-up, 2026-11-17. Reuses the accepted readiness/adoption reports. No implementation, builds, gates, artifacts, native candidates or repository files were changed. Only this requested temporary report is written.

## Result

Use one preparation SSL_read and one documented zero-length SSL_write control flush per invocation, followed by one readiness recheck if no output is queued. A second outer read is not required to process another complete control message: the pinned SSL_read implementation already loops through all complete controls/records until application data, an actual IO wait, close or failure. No persistent control-flush retry flag is needed for a zero-length write; the native write buffer preserves its retry obligation and ordering.

This conclusion applies to the actual ordinary TLS1.3 SQL client with the existing fixed memory BIO pair, no custom asynchronous TLS callbacks and serialized non-reentrant mutation. It is not a claim about arbitrary BIOs or DTLS/QUIC.

## Source proof for one read

Exact immutable native source: `.zig-cache/sql-tls-error-data-fixed-20261117/boringssl`.

- ssl/ssl_lib.cc:ssl_read_impl (about1120-1200) loops while pending_app_data is empty. A complete get_message is processed, next_message is called and execution continues around the loop. It does not return after one NewSessionTicket/KeyUpdate.
- The same loop opens another record and repeats on partial/refill/discard retry. It returns success only after application plaintext exists; preparation treats any such plaintext as unsolicited PostgreSQL input and fails ProtocolError before Startup/Cancel.
- ssl/ssl_buffer.cc:198-219 reads the BIO repeatedly until the required record length is reached. Its ordinary TLS WANT_READ return comes from a BIO_read unable to provide more bytes. With the fixed memory BIO, currently supplied bytes are exhausted; a partial header/record may remain in native storage.
- ssl_buffer.cc:263-299 makes successful refill/discard a retry of the outer SSL_read loop. Close/failure terminate normally; they are not a zero-progress control-message result.
- tls13_both.cc:tls13_post_handshake returns to that loop after valid tickets/updates. Requested updates can queue a response, so read WANT_READ does not imply output readiness. Partial hs_buf correctly remains native PENDING after input exhaustion.

Therefore a single positive-capacity SSL_read processes all complete buffered/coalesced controls reachable without another IO event. WANT_READ with a partial message requires more peer input, not another immediate read of the same empty BIO. WANT_WRITE requires output progress and retry through the next preparation invocation. No same-callback byte-budget loop or arbitrary retry count is needed.

A focused witness must confirm the fixed-memory-BIO postcondition: after WANT_READ and no new input event, there is no complete remaining readable control backlog. Do not replace this proof with SSL_has_pending: it omits hs_buf, which is why the new pure readiness query is required.

## Exact preparation pass

The pass runs only in `.tls_preparing`, entered after successful SSL_do_handshake and the existing peer/name verification, before queue_startup. Keep the original absolute startup/cancel deadline armed.

1. If a socket write is active, return: its completion is the next output event. If caller ciphertext has an unsent suffix, arm exactly that suffix and return. If network_bio has ciphertext output, copy one bounded chunk into the existing ciphertext array, arm its socket write, and return. Do not overwrite a buffer still used by an active write.
2. Read the pure native readiness status and current SSL read-BIO input count. UNSUPPORTED stops through the existing stable TLS failure/drain path. If native READY and read BIO input is zero, with caller/network output already empty, synchronously execute the six-call bundle, set prepared, and call existing queue_startup exactly once. Return from the preparation handler; the common application-write path must not run first.
3. Otherwise perform one SSL_read into a nonempty local buffer. A positive result means unsolicited pre-Startup/Cancel PostgreSQL plaintext: stop ProtocolError without delivering/dropping it. For every nonpositive result, call SSL_get_error immediately, before any other SSL/BIO/ERR operation. WANT_READ/WANT_WRITE continue preparation; close/EOF/fatal use the existing close/failure mapping and return. Read result0 is not the zero-write success exception.
4. Perform SSL_write(ssl, stable_non_null_buffer, 0) to flush controls. Return0 is documented SUCCESS for this operation and must not be passed to ordinary tls_retry(0). For a negative result, immediately call SSL_get_error; WANT_READ/WANT_WRITE are retryable, other results stop through the existing failure path. Keep the same non-null pointer and length0 for retries. No PG application bytes are supplied. A positive result is outside the documented zero-length result contract and must not be interpreted as transmitted Startup data.
5. Drain newly produced network-BIO ciphertext through the normal bounded socket-write path; if output exists, arm and return. The write completion reruns this same pass. Native output can exceed available BIO capacity across retries; the already-sealed native write buffer remains intact until those retries flush it.
6. If no output is queued and no new input event occurred, re-read native status and read-BIO input once. READY plus zero read-BIO/caller/output backlog enables the synchronous six-call bundle and queue_startup. PENDING with input exhausted means wait for the next read or already-armed write/deadline event; ensure the existing idempotent read arming remains active. Do not busy-loop on native PENDING, invent a new timer, or extend the absolute deadline.

No mutation, callback or IO may occur between the final readiness/transport checks and the six calls. Allocation failure still closes/drains the partially prepared session; READY does not promise allocation success. All six remain before application bytes and main SQL pool admission. Authentication and ReadyForQuery remain later independent requirements.

If a witness reveals a remaining complete input backlog or flushable output with no wakeup after this bounded pass, the one-pass assumptions have been contradicted and integration must stop for source diagnosis. Do not silently wait for unrelated future traffic, add a speculative unbounded loop, weaken a counter, or reject a valid partial control. The inspected fixed-BIO paths above do not produce that condition.

## Zero-write retry ordering: no extra persistent flag

The source supports read-then-zero retry after output drain; no tls_control_flush_pending boolean is required.

- s3_pkt.cc:do_tls_write (about130-153) validates write pointer/length/type only when pending_write is nonempty, and first flushes the existing native write_buffer before processing new handshake output.
- On flush failure, pending_write is installed only for nonempty application input (about245-249). A zero-length write leaves no borrowed application span and unreported_bytes_written remains0 through tls_write_app_data.
- A failed zero flush preserves already-sealed native ciphertext. A later SSL_read can progress the independent receive direction or queue another control response; it cannot replace those sealed old bytes. The next stable length0 call flushes that old write_buffer first, then any newly queued handshake data. Wire order and retry arguments are preserved.
- A read-side fatal/close may terminate preparation instead of completing a retry; that is the existing failure policy, not a lost successful write.

Thus every resumed pass may drain caller/BIO output, do a new read if native/input remains pending, then issue the same zero flush. Native readiness remains PENDING while a native write-buffer/flight obligation exists, so the bundle cannot bypass it. A boolean remembering “zero write in progress” would add state without proving an extra invariant for this zero-input operation.

ssl.h:410-414 explicitly documents length0 control flushing/zero success. Normal nonzero SSL_write retry rules and borrowed buffers remain unchanged and are not generalized from this special case.

## Integration site and bypass prevention

`Connection.pump_tls` currently calls queue_startup immediately after verified handshake success. Replace that transition with `.tls_preparing` and dispatch the preparation handler before its common application-write/deliver_ready tail. A preparation invocation that starts Startup/Cancel returns from its own branch; it must not fall through and perform an unrelated second application write.

`Connection.consume_tls` currently BIO-writes incoming ciphertext, calls pump_write, then runs a generic SSL_read loop whenever the resulting phase is no longer `.handshaking`/`.closing`. Checking only the resulting phase is insufficient: preparation may finish and enter `.authenticating` in that call.

Capture whether the callback entered with phase `.handshaking` or `.tls_preparing` before invoking pump_write. After the existing BIO_write and pump_write, return if that entry flag was true, if the current phase is either preparation phase, or if closing/dormant. This gives the handshake/preparation handler exclusive ownership of those input bytes even when it transitions to authentication in the same callback. No private SSL state is accessed by Zig. The final READY/rbio-empty decision proves there is no unread application/control input being abandoned when returning after successful preparation; future server authentication input arrives on a later read event.

Ordinary authentication/query consume_tls continues to use its existing generic reader. on_write already reruns pump_write after advancing cipher_sent. on_read already feeds bytes before pumping and re-arms the read. Preserve these completion edges and the existing close/cancel retirement path. A queued socket write supplies an output wakeup; partial input supplies a read wakeup; the absolute startup/cancel deadline supplies a terminal wakeup if the peer stops. No pool-wide admission/maintenance pause or additional request storage is introduced.

## Focused acceptance

- Initial handshake with pending Finished output, short writes and BIO backpressure reaches exactly one preparation, one six-call bundle and one Startup/Cancel emission.
- Complete/coalesced ticket and KeyUpdate controls are consumed by one read up to WANT; partial record/header/handshake states remain PENDING until later valid bytes, without a false failure or zero-progress spin.
- Requested update queues a response before Startup. Zero flush0 is success. Force negative WANT_WRITE, drain output, process an additional real peer control before repeating the same zero write, and verify exact response/wire ordering. Compare direct zero retry. No extra PG bytes appear.
- Read close0/fatal is mapped immediately and never mistaken for zero-flush success. Unsolicited positive plaintext fails ProtocolError without parser delivery.
- consume_tls entry in handshaking/preparing cannot run the generic reader after that same pump transitions to authenticating/canceling. Auth/query callbacks remain unchanged afterward.
- No output buffer overwrite, stranded native/read-BIO backlog, duplicate request, changed cancel deadline or admission pause. An incomplete peer that stops sending expires through the original timer and normal drain; repeated PENDING checks do not extend it.

All tests use real public TLS/BIO/SQL state where reachable; no private client-state staging. Ordinary functional/source review continues; dedicated campaigns remain deferred. Root alone releases implementation/integration and pushes impl/implement-2.3.0. This follow-up neither changes the accepted native API nor claims tests were run.
