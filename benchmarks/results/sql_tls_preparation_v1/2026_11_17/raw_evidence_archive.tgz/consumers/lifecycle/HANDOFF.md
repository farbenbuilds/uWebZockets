# Worker-wide lifecycle allocation probe

Author built only. `zig-out/bin/sql_tls_lifecycle_probe` compiled in
ReleaseSafe: 18/18 steps passed. No database fixture, credentials or Docker
resource was read or used by the author. Root owns execution and evidence. Root subsequently reported a completed real-PG
run; the runtime observations are distinguished from author-run checks below.
The initial fixed-array default-type compilation failure is retained in
`initial_build_failure.log`; corrected source is bound by `identity.json`.

Build from this directory:

```sh
/tmp/zig-x86_64-linux-0.16.0/zig build -Doptimize=ReleaseSafe --cache-dir ../consumer-cache --global-cache-dir ../global-cache --summary all
```

Run with Root's existing trusted fixture environment: `PGHOST`, `PGPORT`,
`PGUSER`, `PGDATABASE`, `PGPASSWORD`, `PGSSLROOTCERT`, `PGSSLSERVERNAME`, and
`UWZ_SQL_LIFECYCLE_OUTPUT` naming an owned SSD JSON output path. Do not print
the environment/password. This probe always requires verified TLS; it does
not implement the warmed probe's optional plaintext mode.

The probe runs three failure/reconnect rounds, then three deadline-cancel
rounds. Six ordinary Db leases remain held, leaving two configured slots for
the long query and target; a third query must enter the bounded waiter queue.
The long statement is `SELECT 42::int4 FROM pg_sleep(0.5)`. The failing target
terminates its own backend. The cancellation target sleeps for 30 seconds
under an absolute 50 ms query deadline. The queued query selects 42.

Each worker-thread allocation interval starts immediately before the first
Db.query submission and ends at the third/final callback entry. It includes
synchronous writes, target retirement/destruction, independent auxiliary
cancellation and fresh main-session reconnect/preparation while another query
remains active. No counter reset occurs at the target callback or during
maintenance. Callback observations and final counters occupy fixed storage;
JSON formatting/file output occur after all intervals and App.run.

The unchanged all-C interposer and original 63-byte malloc/calloc/realloc/free
self-test are copied exactly from the original consumer. SHA256 remains
`afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac`.
Neither original warmed consumer, its measured interval, the SDK, native
sources, allocator semantics, pins nor gates were changed.

Each round validates one callback per request; the target callback sees a
dormant connection with null SSL/network-BIO after destruction, the expected
ConnectionClosed or QueryTimeout, one failed slot and one bounded waiter.
Queued assignment/result must occur while the long request remains running,
on the replaced target slot with a new backend PID and higher lease generation.
Main target/prepared replacement flags, callback ordering/timestamps, pool
stats, counter snapshots, cancel/reconnect deltas and auxiliary send status
are emitted. Auxiliary preparation observed by the 1 ms timer is explicitly
an observation and may be missed between polls; actual successful auxiliary
send is additionally checked through cancel_requests and retained cancel_sent.

The original pool capacities, reconnect backoff, connection/cancel budgets,
quarantine and request API remain unchanged. One inline timer polls readiness
and enforces a bounded 30-second watchdog per round. There are no sleeps,
admission pauses, finite spare sessions, hidden allocator hooks or native edits.

Expected runtime interpretation, only after Root actually runs it:

- `completed_rounds: 6`, `functional_failure: null`: required scenarios passed.
- `strict_zero: false` plus `error.NonZeroLifecycleAllocations`: genuine strict
  lifecycle allocation RED, emitted only after complete functional success.
- Any functional failure/incomplete scope takes precedence over the strict
  allocation result. Partial records remain marked incomplete; they cannot be
  reported as successful zero-allocation proof.

Root subsequently reported six complete real-PG rounds with
`functional_failure: null`, `strict_zero: false`, expected exit 1. Each of the
three failure/reconnect rounds observed 268 mallocs, 2 callocs, 270 frees and
412698 requested bytes. Each of the three cancel rounds observed 536 mallocs,
4 callocs, 540 frees and 825396 requested bytes. Root reported prepared
reconnects and queued/long overlap, observed prepared/sent auxiliary cancel,
and zero cancel failures. These are Root-reported results; raw JSON/stderr
remain Root-owned and are not fabricated or copied here. Source identities
remain unchanged. Independent probe review is pending at this author handoff.

No full allocation-gate or peer-control-fault completion is claimed. Root owns
independent review, raw runtime evidence, source attribution, archive and Git
commit/push. The lifecycle requirement remains RED.
