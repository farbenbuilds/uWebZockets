const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const dependency = b.dependency("uwebzockets", .{
        .target = target,
        .optimize = optimize,
        .sql = true,
    });
    const module = dependency.module("uWebZockets");
    const root = b.createModule(.{
        .root_source_file = b.path("probe.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
    });
    root.addImport("uWebZockets", module);
    root.addImport("xev", module.import_table.get("xev").?);
    root.addCSourceFile(.{
        .file = b.path("allocation_scope.c"),
        .flags = &.{ "-std=c11", "-Wall", "-Wextra", "-Werror", "-fno-builtin-malloc", "-fno-builtin-calloc", "-fno-builtin-realloc", "-fno-builtin-free" },
    });
    const executable = b.addExecutable(.{ .name = "sql_tls_allocation_probe", .root_module = root });
    b.installArtifact(executable);
}
