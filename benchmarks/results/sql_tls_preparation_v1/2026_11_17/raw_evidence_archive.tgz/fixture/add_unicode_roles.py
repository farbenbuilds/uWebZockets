#!/usr/bin/env python3
"""Create only owned temporary roles; keep password text in stdin/private storage."""
from pathlib import Path
import json,os,subprocess
root=Path(__file__).resolve().parent
private=root/'private_fixture'
os.umask(0o077)
values={'UWZ_SQL_TEST_UNICODE_PASSWORD':os.urandom(16).hex()+'I\u00adX\u2168',
        'UWZ_SQL_TEST_CJK_PASSWORD':os.urandom(16).hex()+'\uf900'}
container=(private/'container.id').read_text().strip()
statements=[]
for role,key in [('uwz_unicode','UWZ_SQL_TEST_UNICODE_PASSWORD'),('uwz_unicode_cjk','UWZ_SQL_TEST_CJK_PASSWORD')]:
    statements.append("CREATE ROLE "+role+" LOGIN PASSWORD '"+values[key]+"';")
r=subprocess.run(['docker','exec','-i',container,'psql','-U','uwz_test','-d','uwz_test','-v','ON_ERROR_STOP=1'],input='\n'.join(statements).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
if r.returncode:
    raise SystemExit('owned Unicode role setup failed; credentials were not printed')
(private/'unicode_passwords.json').write_text(json.dumps(values)+'\n')
print('owned Unicode roles created; credentials were not printed')
