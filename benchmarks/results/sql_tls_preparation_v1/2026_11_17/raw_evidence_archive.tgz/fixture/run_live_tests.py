#!/usr/bin/env python3
"""Run ordinary SQL unit tests with privately provisioned fixture credentials."""
import argparse,json,os,subprocess,time
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--sdk',type=Path,required=True)
parser.add_argument('--cache-root',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--zig',type=Path,required=True)
args=parser.parse_args()
root=Path(__file__).resolve().parent
private=root/'private_fixture'
out=args.output.resolve()
for parent in (out,*out.parents):
    if (parent/'files.sha256').exists():
        raise SystemExit('output must be outside an evidence artifact')
out.mkdir(parents=True,exist_ok=False)
values=dict(line.split('=',1) for line in (private/'postgres.env').read_text().splitlines())
env=dict(os.environ)
env.update(UWZ_SQL_TEST_PASSWORD=values['POSTGRES_PASSWORD'],UWZ_SQL_TEST_PORT=str(json.loads((root/'fixture.json').read_text())['port']),UWZ_SQL_TEST_CA_PATH=str(private/'ca.pem'),UWZ_SQL_TEST_UNTRUSTED_CA_PATH=str(private/'untrusted.pem'))
env.update(json.loads((private/'unicode_passwords.json').read_text()))
cache=args.cache_root.resolve()
cmd=[str(args.zig.resolve()),'build','test-unit','-Dsql=true','-Dsqlite=true','--cache-dir',str(cache/'sdk-cache'),'--global-cache-dir',str(cache/'global-cache'),'--summary','all','-j4']
start=time.monotonic()
with (out/'tests.log').open('wb') as f:
    result=subprocess.run(cmd,cwd=args.sdk.resolve(),env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
(out/'result.json').write_text(json.dumps({'command':cmd,'exit_code':result.returncode,'elapsed_s':time.monotonic()-start,'private_credentials_recorded':False},indent=2)+'\n')
print({'exit_code':result.returncode,'log':str(out/'tests.log')})
raise SystemExit(result.returncode)
