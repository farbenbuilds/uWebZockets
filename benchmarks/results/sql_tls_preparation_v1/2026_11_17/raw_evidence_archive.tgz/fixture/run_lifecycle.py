#!/usr/bin/env python3
"""Record a strict lifecycle RED only after all functional assertions pass."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument("--binary", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parent
private = root / "private_fixture"
out = args.output.resolve()
for parent in (out, *out.parents):
    if (parent / "files.sha256").exists():
        raise SystemExit("output must be outside an evidence artifact")
out.mkdir(parents=True, exist_ok=False)
values = dict(line.split("=", 1) for line in (private / "postgres.env").read_text().splitlines())
env = dict(os.environ)
env.update(PGHOST="127.0.0.1", PGPORT=str(json.loads((root / "fixture.json").read_text())["port"]),
           PGUSER="uwz_test", PGDATABASE="uwz_test", PGPASSWORD=values["POSTGRES_PASSWORD"],
           PGSSLROOTCERT=str(private / "ca.pem"), PGSSLSERVERNAME="localhost",
           UWZ_SQL_LIFECYCLE_OUTPUT=str(out / "lifecycle.json"))
start = time.monotonic()
with (out / "stdout.log").open("wb") as stdout, (out / "stderr.log").open("wb") as stderr:
    result = subprocess.run([str(args.binary.resolve())], env=env, stdout=stdout,
                            stderr=stderr, timeout=45)
(out / "run_status.json").write_text(json.dumps({
    "exit_code": result.returncode, "expected_exit_code": 1,
    "elapsed_s": time.monotonic() - start,
    "private_credentials_recorded": False,
}, indent=2) + "\n")
report = json.loads((out / "lifecycle.json").read_text())
if result.returncode != 1 or report["functional_failure"] is not None or report["completed_rounds"] != 6 or report["strict_zero"]:
    raise SystemExit("expected functional success followed by strict allocation failure")
if "error: NonZeroLifecycleAllocations" not in (out / "stderr.log").read_text():
    raise SystemExit("strict failure reason did not match")
print("six functional lifecycle rounds passed; strict allocation RED retained")
