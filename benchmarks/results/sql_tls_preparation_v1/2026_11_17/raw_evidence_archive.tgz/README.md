# Isolated SQL TLS preparation evidence

This archive retains an implementation candidate and measured evidence. See the
repository result README for the measured table, verification and open gates.

`input_identity.json` identifies the root checkpoint, SDK baseline, compiler and
complete native source proposal. `source/sdk_files.json` binds all 497 candidate
SDK files. `source/sdk/` is an isolated snapshot: its private builder selects one
complete native tree; all four production dependency views remain unchanged.
`source/baseline/` retains the original SQL connection and centralized test root.

`developer_evidence/consumer_source.patch` contains only the SQL implementation
and centralized regressions. `isolated_build.patch` records the separate private
builder override. The archived commands/logs distinguish genuine behavioral RED,
setup failures, focused GREEN and broader build/test verification.

`consumers/` contains exact source/build inputs for the baseline, prepared and
lifecycle executables in `bin/`. The original query probe retains its submission
through callback-entry interval. Its fixture-specific typed value check runs
after counting ends. The lifecycle probe adds a separate worker-wide interval
through three overlapping requests; it does not redefine the original counter.
Its strict failure is expected only after all six functional rounds succeed.

`root_evidence/` retains real PostgreSQL CSV/JSON, source attribution, complete
ordinary live-unit results, independent reviews, source reconstruction and staged
replay records. The initial `.crt` filename mistake is retained separately from
the corrected `.pem` baseline. The developer's earlier full `test` command ran
configured C API smoke/header checks; subsequent commands use `test-unit`.
Dedicated security/sanitizer/fuzz/scan campaigns were not run.

Run `python3 replay.py --output /path/on/ssd/fresh-output` outside this artifact to
replay the three exact executables against a new owned PostgreSQL fixture. This
requires the recorded Linux glibc/Docker environment and pinned image access.
The driver records expected baseline/lifecycle strict RED, prepared strict GREEN,
and cleanup. It never prints fixture passwords or retains private fixture PKI.

`reconstruct_sdk.py` takes `--native-root`, `--output` and optional
`--variant baseline|prepared`. It verifies every native byte hash from the
8709-file identity and every frozen SDK file before copying into fresh output.
Only the copied isolated builder's absolute native path is selected. Native
package/Git permission differences are documented in the readiness prerequisite;
native source bytes must match exactly. Required native source and dependency
packages remain explicit external build inputs. No source overlay, fallback API
or production pin adoption is introduced.

Warmed-query zero allocation is established for the retained cases. Real failure,
reconnect and cancellation still allocate/free during active worker requests.
Per-reservation OOM, forced short-write/BIO pressure and the other consumer gaps
listed in the result README remain unverified. Full PostgreSQL zero allocation
and the v2.3.0 goal remain open; no PostgreSQL exception is granted here.
