# Isolated SQL TLS preparation integration

Production source is frozen at `src/sql/connection.zig` SHA256
`501d63f8dc94a90f6861b71a7a88277000c2f64f5fc403a4fbcb1f76b4c81c73`.
Root tracked files, native trees, prior producers, pins and all four zon views
were not edited. This SDK is a 496-file copy bound by `sdk_baseline.json`;
`copy_identity.json` records the single preexisting private-builder delta.

The SQL connection now enters `.tls_preparing` after verified handshake. It
drains caller/BIO ciphertext, processes buffered controls with one read and
immediate error classification, performs the documented stable zero-input
control flush, then rechecks readiness once. Only native READY plus empty
caller/BIO state permits the synchronous ordered six-call bundle. Every call
must return one; otherwise existing TlsFailed stop/completion retirement/free
handles partial ownership. The complete flag gates Startup, auxiliary Cancel,
application writes and admission, and resets on start and final teardown.
`consume_tls` preserves its entry preparation phase across the write pump.

Only these SDK paths differ from the tracked-file baseline:

- `builds/vendor/boringssl.zig`: private full absolute immutable native root.
- `src/sql/connection.zig`: preparation gate and bounded pump.
- `src/tests/main.zig`: centralized gated test import.
- `src/tests/sql_tls_preparation_tests.zig`: seven behavioral regressions.

`evidence/delta_identity.json` binds exact file hashes.
`evidence/consumer_source.patch` contains only the three SQL/test source paths;
its SHA256 is `a84f55f3e899d740582c27e73ecaec594df9989696a74a30757967178006e6eb`.
`evidence/isolated_build.patch` is the complete private builder delta from the
production manifest baseline, SHA256
`e1cc1ccad8f7cd173bedfc21411104e1acad4ee1f03fd3532b5d4024cd8609e0`.
`evidence/consumer.patch` records the combined delta relative to the copied
SDK, SHA256 `33631de8c2d1c482410467dfbac804094bd6e1735aaeb0ffb9f241e964119e34`.

The private builder uses only the immutable full
`sql-tls-preparation-integration-20261117/boringssl_final` root, normal native
source lists and normal build-time C translation. Its source identity is copied
to `evidence/native_final_source_identity.json`. Native patch identity remains
6772a629cc9e6e09c3e06dca857576bb03a1553185d54a0d52ce6f4e2a333b3b,
source commit f6176c03304e835d315cf4d9cbd86fc27e979f95. No dependency adoption
or publication is implied. `evidence/native_and_sdk_outputs.json` records the
actual Debug/ReleaseSafe/ReleaseFast archive identities produced here.

The genuine pre-edit behavioral RED is `evidence/red.log`: four failures on
unchanged SQL, including immediate authenticating with a fragmented control
record still pending. Setup compilation/verification failures are retained
separately. `evidence/sandbox_setup_failure.txt` explicitly states that its
initial setup excerpt was recovered after the original log was overwritten.

Final ordinary verification:

- Focused preparation: 7/7 tests, 20/20 steps.
- SQL+SQLite full tests: 1165/1189 pass, 24 live-PG skips, 26/26 steps.
- SQL-only full tests: 1151/1175 pass, 24 live-PG skips, 23/23 steps.
- SQL ReleaseSafe test compilation: 21/21 steps.
- SQL ReleaseFast production library: 21/21 steps.
- Full format, convention checks and release metadata 2.3.0: passed.

Exact commands, exits, results and log hashes are in
`evidence/commands_results.json`. Builds/tests required escalation for Zig
translate-c cache writes and loopback. No dedicated sanitizer, security, fuzz or scan campaign was launched. The
ordinary full `test` target inadvertently executed its configured C API smoke
and C++ header checks despite the smoke deferral. These executed checks are
retained truthfully in the logs; no claim that all smoke work stayed unrun is
made. Root corrected subsequent runtime checks to use `test-unit`.

Tests use genuine verified TLS1.3 memory-BIO handshakes with an explicitly
trusted development leaf, followed by production SQL SSLRequest/S socket
callbacks. They prove authenticated ciphertext-record fragmentation and
coalesced KeyUpdates, response-before-Startup decryption, original timeout,
Startup/Cancel emission, later SQL authentication/readiness, reset after drain,
unsolicited plaintext rejection, cache ineligibility and close_notify mapping.
They do not claim an actual socket TLS handshake or an authenticated fragmented
handshake message in hidden hs_buf. Root owns the separate real-PG socket
handshake/query/reconnect/cancel and allocation evidence.

Remaining consumer-test gaps: per-reservation native OOM fault indices, forced
socket short writes/BIO-capacity WANT_WRITE, ticket controls and hidden hs_buf
fragmentation. Existing accepted native evidence covers the readiness/control
prerequisite, but these specific consumer cases were not run here. Root's
independent source review is ongoing. No full PostgreSQL allocation-gate or
v2.3.0 completion claim is made: active lifecycle create/handshake/free costs
remain for the later design. Root owns archive/integration, graph refresh and
Git commit/push.
