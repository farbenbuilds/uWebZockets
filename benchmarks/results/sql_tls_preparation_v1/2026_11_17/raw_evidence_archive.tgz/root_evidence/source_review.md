# SQL TLS preparation: independent source review

Date: 2026-11-17. Scope: isolated `.zig-cache/sql-tls-sql-preparation-fixed-20261117/sdk`, compared with the recorded 496-file integration SDK baseline. This review changes no source, producer, pin, build, gate or Git state. Applicable reviewer/transport instructions, project conventions, code-review-and-quality, Zig 0.16 guidance and the requested structural maintainability lens were applied. Graphify was queried before scoped source exploration. The accepted reservation-adoption and bounded preparation-flow plans are the contract.

## Verdict

No actionable source finding in the reviewed candidate. This is a source verdict for the isolated consumer, not completion of its wider acceptance matrix, production adoption or PostgreSQL lifecycle zero-allocation work.

Independently recomputed `consumer.patch` SHA256: `33631de8c2d1c482410467dfbac804094bd6e1735aaeb0ffb9f241e964119e34`. All four candidate hashes match `evidence/delta_identity.json`:

- `builds/vendor/boringssl.zig`: `0fbc6c0ac0bf72f158e4d6f3565b30b1ff95cc9adbcd382edc613125c74e93aa`.
- `src/sql/connection.zig`: `501d63f8dc94a90f6861b71a7a88277000c2f64f5fc403a4fbcb1f76b4c81c73`.
- `src/tests/main.zig`: `d7c3425c0de4b9db4aa804b2866c2e0ee2908f5151dc2a9626ea5d83738ad2a0`.
- `src/tests/sql_tls_preparation_tests.zig`: `4d9e30d1f87d572976acc705345d3cd02126954c51a79d138f4e6fc817716d9b`.

All 496 baseline paths remain present with unchanged modes; only the three declared existing paths differ, plus the declared new test. The builder's absolute source root is explicitly isolated-only. It keeps source-list and include selection together; it is not an authorized production builder/pin change.

## Source conclusions

`connection.zig:367` enters `tls_preparing` only after successful handshake and existing certificate verification. `:397` preserves any active/unsent ciphertext until its completion and drains one bounded BIO chunk. `:420` performs at most one positive-capacity read, one stable non-null zero-input control write and one final readiness recheck per invocation. Nonpositive read and negative write paths classify immediately through `tls_retry` (`:466`); read close is classified before the zero-write success exception. Positive pre-Startup plaintext closes with ProtocolError.

`connection.zig:440` requires native READY and empty read-BIO/pending input before the synchronous six-call bundle. Calls remain ordered and require exactly 1; short-circuit failure stops and retires the whole session through existing cancellation/close gates. The prepared bit is assigned only after every call succeeds. `queue_startup` (`:298`) then re-enters the existing pump exactly once for Startup or Cancel, so the preparation return does not strand the application packet. No native guard probing, private client-state access, cache-policy override or compatibility fallback was added.

`consume_tls` (`:480`) captures entry phase before feeding/pumping and prevents a same-callback transition from bypassing preparation through the generic reader. Socket read/write completions preserve the next input/output wakeup; the original startup deadline remains armed until ordinary PostgreSQL readiness. Execution, startup and ready delivery retain prepared-state guards. Start and completed teardown reset the bit (`:123`, `:256`); SSL destruction still waits for all operation/cancel completions. Plaintext behavior and shared TLS defaults are unchanged.

The structural lens finds no actionable maintainability regression. The connection file grows 795 to 875 lines. One explicit phase and one successful-bundle invariant keep the change in its existing SQL owner; the bounded preparation and shared drain helpers avoid a second transport state machine, retry loop or persistent zero-flush flag. No mechanical file split is warranted.

## Evidence reviewed and remaining verification

Tests were reviewed before implementation. The initial four behavioral RED cases fail for missing preparation/early admission rather than compilation. Recorded final focused output is 7/7 passing, 20/20 steps. Tests use genuine verified public TLS sessions with real SQL socket callbacks and cover fragment timeout, fragment resumption for main and auxiliary Cancel, unsolicited plaintext, ineligible cache policy, idle startup, coalesced requested/unrequested KeyUpdates and peer close. They check original deadline, complete request bytes, preparation/reset and absence of premature ready callbacks. The fixture's explicit trusted-development-leaf/partial-chain setup is confined to tests; production trust is unchanged.

Recorded full SQL unit output is 1151/1175 passing, 24 skipped, 23/23 steps; ReleaseSafe compilation, ReleaseFast library, format, conventions and version logs are retained. These recorded runs were inspected, not independently rerun by this reviewer.

The seven focused tests pre-complete the verified memory-BIO handshake before driving the SQL socket; they alone do not prove a real initial Finished flight through the SQL callback, forced short socket writes/BIO pressure, zero-write WANT_WRITE with interleaved read, individual reservation OOM cleanup, or the complete certificate-negative/reconnect/cancellation matrix. Root owns the real PostgreSQL and allocation-lifecycle evidence still being collected. Review that evidence separately before claiming those acceptance items closed. Dedicated campaigns remain deferred; no native prerequisite, whole-PG zero-allocation or release-complete claim is made here.
