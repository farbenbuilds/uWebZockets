# SQL TLS lifecycle RED: independent review

Date: 2026-11-17. Read-only review of `.zig-cache/sql-tls-preparation-integration-20261117/lifecycle_consumer/{probe.zig,build.zig,build.zig.zon,allocation_scope.c}` and Root's `.zig-cache/sql-tls-sql-fixture-20261117/lifecycle` run. The accepted lifecycle allocation plan, project/reviewer instructions and applicable review, Zig and structural quality guidance were applied. Graphify preceded fresh SQL source questions. No source, producer, native library, pin, gate or Git state was changed; no runtime/build/campaign was rerun.

## Verdict

No actionable finding. The six recorded functional rounds support retaining an honest worker-wide allocation RED for this isolated prepared SQL candidate. They do not close PostgreSQL zero allocation or approve a lifecycle allocator.

## Identity

Independently computed SHA256:

- `probe.zig`: `bc552c885af280e4ad6ac7ba0c1b752e6c42ccdb3589f5f0434380ce68d0c159`.
- `build.zig`: `ce815e10a02b2a93e787a13955a8179e37a0f1278cede757bacb165d3a918c7c`.
- `build.zig.zon`: `95ebef50f580be4d00f44f29d591f278965afe74a779d3d7460e957487a9932b`.
- `allocation_scope.c`: `afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac`, byte-identical to the original retained counter.
- Current executable: `3769693be9465ef778390fea52e9a0bae8e94bcbeaac8d01c2b1f0ec7e44cf55`.
- `lifecycle.json`: `475b073e51bed6702aa9dbd73d9e2d4467bc5b95bdff291e3a39d0b175df1781`.
- `run_status.json`: `6bcc6976dbd1350c6e543775dd510329599a3e13451d4bf4627a679bf9627a17`.

The build consumes the reviewed isolated preparation SDK, enables SQL and links the original all-C counter only into this probe. No replacement native image, counter filter, allocator redirection or library policy is introduced. The unchanged self-test checks 1 malloc, 1 calloc, 1 realloc, 2 frees and 63 requested bytes; main requires its success before executing scenarios.

## Counter and scenario meaning

`probe.zig:168-203` retains six public pool leases, leaving two slots in the unchanged eight-slot pool. It submits a real 0.5-second query, a self-terminating or 50ms-deadline target, and a queued query. This constructs actual bounded waiter pressure without changing admission behavior. Default reconnect/cancel settings and production callback/maintenance paths remain intact.

The thread-local counter starts before the first Db.query submission (`:201`), so synchronous submission writes are included. It remains active across target destruction, failure callback, timer/maintenance work, replacement allocation/verified handshake/preparation, waiter assignment and auxiliary cancellation. It ends only at the third callback's entry (`:234-241`). In every recorded round that final callback belongs to the long query. Earlier callback inspections execute inside the same unfiltered scope. JSON serialization, fixture setup and final service teardown are outside the stated interval. This worker-wide measurement is distinct from the original warmed per-query Db.query-through-callback probe; it does not replace or narrow that probe.

`validate_callback` and `validate_round` (`:290-323`) require retired target requests, dormant sockets, null SSL/BIO, cleared preparation, a failed slot plus waiting request while the long query remains active, new PID/generation on the same slot, renewed preparation and exactly one reconnect. Cancellation uses the actual production auxiliary connection and original deadline. Recorded cancel-request completion is the library's transport lifecycle marker, not a PostgreSQL application acknowledgement.

Main writes the functional JSON before returning any error, returns a functional failure before the strict count failure, and reaches NonZeroLifecycleAllocations only after six completed rounds (`:416-450`). The structural pass finds no unnecessary production abstraction or state-machine growth: this bounded 451-line probe owns its own fixed records, timer and observations.

## Actual run reconciliation

Independent semantic assertions over the raw JSON pass all six rounds: three failure/reconnect followed by three deadline/cancel; all scopes complete; functional_failure null; strict_zero false. Exit status is 1 specifically with NonZeroLifecycleAllocations. Callback order is target, queued, long in every round. Targets are dormant/null SSL+BIO with 115 frees already counted at callback entry. Replacements use the same slot, changed backend PID and increasing lease generation, are prepared, and serve the waiter before the long query completes. All three auxiliary sessions are observed prepared and sent; completed cancel counters increase by one each with no cancellation failures.

Each failure/reconnect round records 268 malloc, 2 calloc, 0 realloc, 270 free and 412698 requested bytes. Each deadline/cancel round records 536 malloc, 4 calloc, 0 realloc, 540 free and 825396 requested bytes. First recorded malloc addresses independently resolve against this executable to the selected candidate's OPENSSL_malloc, crypto/mem.cc:204. Callback cumulative counts equal final round counts after waiter completion, so close/reconnect/cancel work was not moved beyond this interval to obtain the result.

## Limits

This is one retained local Linux/glibc real-PostgreSQL execution, reviewed without a duplicate runtime run. The original counter provides two malloc call sites, not a complete per-allocation ownership/peak-live inventory. That broader inventory, allocator design and its fault/bounds proof remain separate work. Preparation short-write/backpressure/OOM coverage gaps from the consumer source review remain open. No production pin adoption, broader target, dedicated campaign, full lifecycle GREEN or v2.3.0 completion claim follows from this RED checkpoint.
