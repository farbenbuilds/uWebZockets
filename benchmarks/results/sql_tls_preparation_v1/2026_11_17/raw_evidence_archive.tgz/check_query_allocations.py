#!/usr/bin/env python3
"""Apply the original strict all-C allocation check to one query CSV."""
import argparse
import csv
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("csv", type=Path)
args = parser.parse_args()
rows = list(csv.DictReader(args.csv.open()))
fields = ("malloc_calls", "calloc_calls", "realloc_calls", "free_calls", "requested_bytes")
if len(rows) != 256 or [int(row["sample"]) for row in rows] != list(range(256)):
    raise SystemExit("invalid sample inventory")
patterns = sorted({tuple(int(row[key]) for key in fields) for row in rows})
print(json.dumps({"samples": len(rows), "counter_patterns": [dict(zip(fields, row)) for row in patterns]}))
raise SystemExit(0 if all(value == 0 for row in patterns for value in row) else 1)
