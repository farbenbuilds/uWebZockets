#!/usr/bin/env python3
"""Replay the delivered query probes against a new owned PostgreSQL fixture."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
out = args.output.resolve()
if out == root or root in out.parents:
    raise SystemExit("output must be outside the artifact")
for parent in (out, *out.parents):
    if (parent / "files.sha256").exists():
        raise SystemExit("output must be outside an evidence artifact")
out.mkdir(parents=True, exist_ok=False)

def verify():
    for line in (root / "files.sha256").read_text().splitlines():
        expected, name = line.split("  ", 1)
        path = (root / name).resolve()
        if root not in path.parents or path.is_symlink():
            raise RuntimeError("invalid manifest path")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise RuntimeError("artifact hash mismatch: " + name)

records = []

def run(command, log, expected=0, env=None):
    with (out / log).open("wb") as stream:
        result = subprocess.run(command, env=env, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=120)
    records.append({"command": command, "log": log,
                    "exit_code": result.returncode, "expected_exit_code": expected})
    if result.returncode != expected:
        raise RuntimeError("unexpected exit; inspect " + log)

verify()
fixture = out / "fixture"
fixture.mkdir()
for name in ("setup_fixture.py", "run_probe.py", "run_lifecycle.py"):
    shutil.copy2(root / "fixture" / name, fixture / name)
private = fixture / "private_fixture"
try:
    run([sys.executable, str(fixture / "setup_fixture.py")], "fixture_setup.log")
    for variant in ("baseline", "prepared"):
        run([sys.executable, str(fixture / "run_probe.py"),
             "--binary", str(root / "bin" / ("sql_tls_" + variant + "_probe")),
             "--credential-file", str(private / "postgres.env"),
             "--ca-file", str(private / "ca.pem"),
             "--output", str(out / variant)], variant + ".log")
        for mode in ("plaintext", "tls"):
            expected = 1 if variant == "baseline" and mode == "tls" else 0
            run([sys.executable, str(root / "check_query_allocations.py"),
                 str(out / variant / (mode + ".csv"))],
                variant + "_" + mode + "_strict.log", expected)
    run([sys.executable, str(fixture / "run_lifecycle.py"),
         "--binary", str(root / "bin/sql_tls_lifecycle_probe"),
         "--output", str(out / "lifecycle")], "lifecycle.log")
finally:
    try:
        container_file = private / "container.id"
        if container_file.exists():
            container = container_file.read_text().strip()
            if len(container) != 64 or any(c not in "0123456789abcdef" for c in container):
                raise RuntimeError("owned fixture container ID is invalid")
            run(["docker", "rm", "--force", container], "fixture_cleanup.log")
    finally:
        if private.exists():
            shutil.rmtree(private)
        (out / "replay.json").write_text(json.dumps(records, indent=2) + "\n")
        verify()
print("baseline strict RED and prepared strict GREEN replayed; owned fixture cleaned")
