#!/usr/bin/env python3
"""Copy a frozen SDK into fresh output, selecting one complete native tree."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--native-root", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--variant", choices=("baseline", "prepared"), default="prepared")
args = parser.parse_args()
out = args.output.resolve()
native = args.native_root.resolve()
if out == root or root in out.parents:
    raise SystemExit("output must be outside the artifact")
if out == native or native in out.parents or out in native.parents:
    raise SystemExit("output and native input must be separate")
for parent in (out, *out.parents):
    if (parent / "files.sha256").exists():
        raise SystemExit("output must be outside an evidence artifact")
if out.exists():
    raise SystemExit("output must not exist")

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

sdk_files = json.loads((root / "source/sdk_files.json").read_text())
for row in sdk_files:
    if digest(root / "source/sdk" / row["path"]) != row["sha256"]:
        raise SystemExit("frozen SDK hash mismatch: " + row["path"])
native_files = json.loads((root / "source/native_final_source_identity.json").read_text())["entries"]
for row in native_files:
    path = native / row["path"]
    if not path.is_file() or path.is_symlink() or digest(path) != row["sha256"]:
        raise SystemExit("complete native tree hash mismatch: " + row["path"])

out.mkdir(parents=True)
sdk = out / "sdk"
shutil.copytree(root / "source/sdk", sdk)
if args.variant == "baseline":
    for name in ("src/sql/connection.zig", "src/tests/main.zig"):
        shutil.copy2(root / "source/baseline" / name, sdk / name)
    (sdk / "src/tests/sql_tls_preparation_tests.zig").unlink()
builder = sdk / "builds/vendor/boringssl.zig"
original = builder.read_text()
old = '"/home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-preparation-integration-20261117/boringssl_final"'
if original.count(old) != 1:
    raise SystemExit("isolated builder identity mismatch")
builder.write_text(original.replace(old, json.dumps(str(native))))
(out / "reconstruction.json").write_text(json.dumps({
    "variant": args.variant,
    "native_root": str(native),
    "native_files_verified": len(native_files),
    "native_modes": "Hashes bind regular-file bytes; package/Git permission differences are recorded in prerequisite evidence.",
    "sdk_files_verified": len(sdk_files),
    "isolated_builder_sha256": digest(builder),
    "production_dependency_adoption": False,
}, indent=2) + "\n")
print(sdk)
