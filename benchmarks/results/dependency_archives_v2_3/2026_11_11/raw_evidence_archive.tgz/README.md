# Retained active maintained-fork histories, 2026-11-11

These archives retain the exact active integration pins. They are provenance
artifacts, not new dependency pins, branches for publication, or release claims.
This archival task modified no source checkout, root manifest/index, fetched
package cache, or user submodule. The unpublished XEV-008 and lsquic proposals are excluded.

## Contents and verification

Each `.bundle` contains the complete parent repository history reachable from
its named commit, including commits, trees and blobs. Every bundle was verified
in a fresh empty bare repository, imported without network access, checked by
`git fsck --full --no-reflogs`, and inspected for missing objects, shallow state
and promisor packs. No bundle has external prerequisites. Exact trees, object
counts, command arrays, raw logs and SHA-256 values are retained.

| Repository | Commit | Scope | Commits | Reachable objects |
| --- | --- | --- | ---: | ---: |
| libxev | `c49f6dfb83038c146232472c063e4b2681d098d8` | Active maintained integration | 601 | 3147 |
| lsquic | `85bd081c9103c077a7cc98271d09334d0f1043d4` | Active maintained integration | 630 | 8858 |
| h1spec | `999ba9e8f318b1c0ebbff1278b98bc5833f1af18` | Active maintained integration | 22 | 66 |
| ls-qpack | `91567706c41c0d97ab8dc576873ecd472d7869fa` | lsquic-gitlink-and-root-build-pin | 523 | 2458 |
| ls-hpack | `cf0f70dd10b352194c97448eb5d00b4aa484f531` | lsquic-gitlink | 106 | 458 |
| ls-hpack | `fda48e02491d865cce00612be8cc10c2622b8e55` | existing-root-build-pin | 113 | 479 |

The three active pins were freshly resolved from their maintained integration
branches. Fork mirrors were compared with upstream default branches and matched;
exact observed refs and capture time are in `archive_records.json`. These were
read-only fetches and same-machine resolution, not a second-machine check.

No reusable complete active-pin Git bundle was found among the known retained
artifacts. Existing libxev/lsquic work clones were partial, the user h1spec clone
was shallow, and existing XEV-008 bundles were incremental proposals. Fresh bare
repositories under `work/` supplied complete histories without altering them.

## Nested and separately pinned sources

The active lsquic tree records these gitlinks:

- `src/liblsquic/ls-qpack`: `91567706c41c0d97ab8dc576873ecd472d7869fa`.
- `src/lshpack`: `cf0f70dd10b352194c97448eb5d00b4aa484f531`.

Both histories have separate companion bundles. There are no further gitlinks
in libxev, h1spec, or these qpack/hpack repositories. A parent bundle does not
embed a submodule history; `nested_source_coverage.json` maps every gitlink to
its companion archive.

The root build separately pins ls-hpack
`fda48e02491d865cce00612be8cc10c2622b8e55` and copies that source into lsquic's
`src/lshpack`. It is archived separately as the existing root build source.
Baseline commit `70a3e488bc6a754e63fd6f59690f68d9ca6e7d45` already has
that exact pin and assembly operation; this distinction is pre-existing and
is not described as a regression, reconciliation, or inferred design decision.
Baseline source copies and their hashes are retained in `provenance/` and
`baseline_pin_comparison.json`.

This package does not contain every root build input: BoringSSL, libdeflate,
zlib, zslay, the uWebZockets candidate itself, and its vendored SQLite are outside
this archive task. Complete Git object histories are not a claim that the entire
application build can run from these bundles alone.

## Replaying the proof

From this directory, with Git, Python 3 and SHA-256 tools installed:

```sh
sha256sum -c manifest.sha256
python3 verify_archives.py
```

The replay imports each bundle into a fresh temporary bare repository beneath
`verification/`, checks its exact commit/tree/history and object completeness,
and removes that temporary import. It requires no network, compiler, source
checkout, or existing repository. `verification/offline-replay.log` records the
successful original replay. The collector scripts and command logs document
creation; run collectors only in a new empty archival directory.

Initial complete-history fetches used:

```sh
git init --bare --quiet work/NAME.git
git -C work/NAME.git -c gc.auto=0 fetch --no-tags FORK_URL \
  refs/heads/INTEGRATION:refs/remotes/maintained/integration
```

`archive_records.json` supplies each exact name, URL and integration branch.
Companion fetches requested the three exact commits shown above directly from
`litespeedtech/ls-qpack` and `litespeedtech/ls-hpack`, into local archival refs.
No shallow or filtered fetch was used. `commands.json`,
`extra_source_commands.json` and `provenance/*-fetch.log` retain the details.

`deliverables.list` and `manifest.sha256` cover the portable archive package.
`work/` and the persistent verification import repositories are scratch copies,
excluded from those lists; the verified bundles already retain their histories.
Native Windows runtime, independent second-machine resolution, quiet-host
performance and proposal publication/merge remain open requirements.
