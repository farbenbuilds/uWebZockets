#!/usr/bin/env python3
"""Offline replay of every retained bundle in fresh empty repositories."""

import hashlib
import json
from pathlib import Path
import subprocess
import tempfile


root = Path(__file__).resolve().parent
manifest = root / "manifest.sha256"
if manifest.exists():
    for line in manifest.read_text().splitlines():
        expected, relative = line.split(maxsplit=1)
        path = (root / relative).resolve()
        assert path.is_relative_to(root) and path.is_file(), relative
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, relative

records = json.loads((root / "archive_records.json").read_text())["archives"]
records += json.loads((root / "extra_source_records.json").read_text())
for record in records:
    bundle = root / record["bundle"]
    assert hashlib.sha256(bundle.read_bytes()).hexdigest() == record["bundle_sha256"]
    with tempfile.TemporaryDirectory(prefix="offline-replay-", dir=root / "verification") as directory:
        repository = Path(directory) / "import.git"

        def git(*arguments):
            result = subprocess.run(["git", "-c", "gc.auto=0", *arguments], cwd=repository if repository.exists() else root, text=True, capture_output=True)
            assert result.returncode == 0, (arguments, result.stdout, result.stderr)
            return result.stdout.strip()

        git("init", "--bare", "--quiet", str(repository))
        git("bundle", "verify", str(bundle))
        git("fetch", "--no-tags", str(bundle), f"{record['archive_ref']}:{record['archive_ref']}")
        git("fsck", "--full", "--no-reflogs")
        assert git("rev-parse", "--is-shallow-repository") == "false"
        assert not list((repository / "objects").glob("pack/*.promisor"))
        assert git("rev-parse", record["archive_ref"]) == record["pin"]
        assert git("rev-parse", record["pin"] + "^{tree}") == record["tree"]
        assert int(git("rev-list", "--count", record["pin"])) == record["commits"]
        objects = git("rev-list", "--objects", "--missing=print", record["pin"]).splitlines()
        assert len(objects) == record["reachable_objects"]
        assert not any(line.startswith("?") for line in objects)
    print(f"PASS {record['bundle']}: complete history, {record['commits']} commits, {record['reachable_objects']} objects, no prerequisites or missing objects")
print("All six retained histories verified offline on this machine.")
