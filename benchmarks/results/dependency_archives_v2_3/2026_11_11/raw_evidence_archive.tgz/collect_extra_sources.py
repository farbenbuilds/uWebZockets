#!/usr/bin/env python3
"""Retain lsquic gitlinks and the distinct, pre-existing root hpack pin."""

import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parent
SOURCES = [
    ("ls-qpack", "91567706c41c0d97ab8dc576873ecd472d7869fa", "lsquic-gitlink-and-root-build-pin", "https://github.com/litespeedtech/ls-qpack"),
    ("ls-hpack", "cf0f70dd10b352194c97448eb5d00b4aa484f531", "lsquic-gitlink", "https://github.com/litespeedtech/ls-hpack"),
    ("ls-hpack", "fda48e02491d865cce00612be8cc10c2622b8e55", "existing-root-build-pin", "https://github.com/litespeedtech/ls-hpack"),
]
commands = []


def run(arguments, cwd, label, allowed=(0,)):
    result = subprocess.run(arguments, cwd=cwd, text=True, capture_output=True)
    (ROOT / "verification" / f"{label}.log").write_text(result.stdout + result.stderr)
    commands.append({"argv": arguments, "cwd": str(cwd), "exit_code": result.returncode, "log": f"verification/{label}.log"})
    if result.returncode not in allowed:
        raise RuntimeError(f"{label}: {result.returncode}: {result.stderr}")
    return result.stdout.strip()


records = []
for name, pin, role, url in SOURCES:
    repository = ROOT / "work" / f"{name}.git"
    label = f"{name}-{pin}"
    archive_ref = f"refs/archives/sources/{role}"
    bundle = ROOT / f"{label}.bundle"
    imported = ROOT / "verification" / f"{label}-import.git"
    assert run(["git", "rev-parse", "--is-shallow-repository"], repository, label + "-source-shallow") == "false"
    assert not list((repository / "objects").glob("pack/*.promisor"))
    assert not run(["git", "config", "--get-regexp", r"^remote\..*\.(promisor|partialclonefilter)$"], repository, label + "-source-promisor", allowed=(1,))
    run(["git", "fsck", "--full", "--no-reflogs"], repository, label + "-source-fsck")
    run(["git", "update-ref", archive_ref, pin], repository, label + "-archive-ref")
    run(["git", "bundle", "create", str(bundle), archive_ref], repository, label + "-create-bundle")
    run(["git", "init", "--bare", "--quiet", str(imported)], ROOT, label + "-init-import")
    run(["git", "bundle", "verify", str(bundle)], imported, label + "-bundle-verify-empty")
    assert run(["git", "bundle", "list-heads", str(bundle)], imported, label + "-bundle-heads") == f"{pin} {archive_ref}"
    run(["git", "fetch", "--no-tags", str(bundle), f"{archive_ref}:{archive_ref}"], imported, label + "-bundle-import")
    run(["git", "fsck", "--full", "--no-reflogs"], imported, label + "-import-fsck")
    assert run(["git", "rev-parse", "--is-shallow-repository"], imported, label + "-import-shallow") == "false"
    assert not list((imported / "objects").glob("pack/*.promisor"))
    objects = run(["git", "rev-list", "--objects", "--missing=print", pin], imported, label + "-import-objects")
    assert not any(value.startswith("?") for value in objects.splitlines())
    tree = run(["git", "rev-parse", f"{pin}^{{tree}}"], imported, label + "-import-tree")
    assert tree == run(["git", "rev-parse", f"{pin}^{{tree}}"], repository, label + "-source-tree")
    commits = int(run(["git", "rev-list", "--count", pin], imported, label + "-commit-count"))
    entries = run(["git", "ls-tree", "-r", "--full-tree", pin], imported, label + "-tree-inventory")
    gitlinks = []
    for value in entries.splitlines():
        if not value.startswith("160000 commit "):
            continue
        revision, path = value.split(" ", 2)[2].split("\t", 1)
        gitlinks.append({"path": path, "commit": revision})
    records.append({
        "name": name, "pin": pin, "role": role, "source": url,
        "bundle": bundle.name, "archive_ref": archive_ref,
        "bundle_sha256": hashlib.sha256(bundle.read_bytes()).hexdigest(),
        "bundle_bytes": bundle.stat().st_size, "commits": commits,
        "tree": tree, "reachable_objects": len(objects.splitlines()),
        "shallow": False, "promisor": False, "bundle_prerequisites": [],
        "missing_parent_repository_objects": 0, "nested_gitlinks": gitlinks,
    })

(ROOT / "extra_source_records.json").write_text(json.dumps(records, indent=2) + "\n")
(ROOT / "extra_source_commands.json").write_text(json.dumps(commands, indent=2) + "\n")
print(json.dumps(records, indent=2))
