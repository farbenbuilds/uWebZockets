#!/usr/bin/env python3
"""Retain full Git histories for the three active maintained-fork pins."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parent
PINS = [
    {
        "name": "libxev",
        "pin": "c49f6dfb83038c146232472c063e4b2681d098d8",
        "fork": "https://github.com/farbenbuilds/libxev",
        "integration": "uwz/zig-0.16",
        "mirror": "main",
        "upstream": "https://github.com/mitchellh/libxev",
        "upstream_branch": "main",
    },
    {
        "name": "lsquic",
        "pin": "85bd081c9103c077a7cc98271d09334d0f1043d4",
        "fork": "https://github.com/farbenbuilds/lsquic",
        "integration": "uwz/main",
        "mirror": "master",
        "upstream": "https://github.com/litespeedtech/lsquic",
        "upstream_branch": "master",
    },
    {
        "name": "h1spec",
        "pin": "999ba9e8f318b1c0ebbff1278b98bc5833f1af18",
        "fork": "https://github.com/farbenbuilds/h1spec",
        "integration": "uwz/main",
        "mirror": "main",
        "upstream": "https://github.com/uNetworking/h1spec",
        "upstream_branch": "main",
    },
]
COMMANDS = []


def run(arguments, cwd, label, allowed=(0,)):
    result = subprocess.run(arguments, cwd=cwd, capture_output=True, text=True)
    (ROOT / "verification" / f"{label}.log").write_text(result.stdout + result.stderr)
    COMMANDS.append({
        "argv": arguments,
        "cwd": str(cwd),
        "exit_code": result.returncode,
        "log": f"verification/{label}.log",
    })
    if result.returncode not in allowed:
        raise RuntimeError(f"{label}: exit {result.returncode}: {result.stderr}")
    return result.stdout.strip()


def git(repository, *arguments, label):
    return run(["git", "-c", "gc.auto=0", *arguments], repository, label)


def remote_ref(url, branch, label):
    output = run(["git", "ls-remote", "--exit-code", url, f"refs/heads/{branch}"], ROOT, label)
    revision, reference = output.split()
    assert reference == f"refs/heads/{branch}"
    return revision


records = []
for entry in PINS:
    name = entry["name"]
    pin = entry["pin"]
    repository = ROOT / "work" / f"{name}.git"
    imported = ROOT / "verification" / f"{name}-import.git"
    archive_ref = f"refs/archives/active-pins/{name}"
    bundle = ROOT / f"{name}-{pin}.bundle"
    assert git(repository, "rev-parse", "--is-shallow-repository", label=f"{name}-source-shallow") == "false"
    assert not list((repository / "objects").glob("pack/*.promisor"))
    promisor = run(["git", "config", "--get-regexp", r"^remote\..*\.(promisor|partialclonefilter)$"], repository, f"{name}-source-promisor", allowed=(1,))
    assert not promisor
    git(repository, "cat-file", "-e", f"{pin}^{{commit}}", label=f"{name}-commit-exists")
    tip = git(repository, "rev-parse", "refs/remotes/maintained/integration", label=f"{name}-integration-tip")
    git(repository, "merge-base", "--is-ancestor", pin, tip, label=f"{name}-integration-ancestry")
    git(repository, "fsck", "--full", "--no-reflogs", label=f"{name}-source-fsck")
    git(repository, "update-ref", archive_ref, pin, label=f"{name}-archive-ref")
    git(repository, "bundle", "create", str(bundle), archive_ref, label=f"{name}-create-bundle")
    run(["git", "init", "--bare", "--quiet", str(imported)], ROOT, f"{name}-init-import")
    git(imported, "bundle", "verify", str(bundle), label=f"{name}-bundle-verify-empty")
    heads = git(imported, "bundle", "list-heads", str(bundle), label=f"{name}-bundle-heads")
    assert heads == f"{pin} {archive_ref}"
    git(imported, "fetch", "--no-tags", str(bundle), f"{archive_ref}:{archive_ref}", label=f"{name}-bundle-import")
    git(imported, "fsck", "--full", "--no-reflogs", label=f"{name}-import-fsck")
    assert git(imported, "rev-parse", "--is-shallow-repository", label=f"{name}-import-shallow") == "false"
    assert not list((imported / "objects").glob("pack/*.promisor"))
    objects = git(imported, "rev-list", "--objects", "--missing=print", pin, label=f"{name}-import-object-list")
    assert not any(line.startswith("?") for line in objects.splitlines())
    imported_pin = git(imported, "rev-parse", archive_ref, label=f"{name}-import-pin")
    assert imported_pin == pin
    tree = git(imported, "rev-parse", f"{pin}^{{tree}}", label=f"{name}-import-tree")
    original_tree = git(repository, "rev-parse", f"{pin}^{{tree}}", label=f"{name}-source-tree")
    assert tree == original_tree
    commits = int(git(imported, "rev-list", "--count", pin, label=f"{name}-commit-count"))
    tree_entries = git(imported, "ls-tree", "-r", "--full-tree", pin, label=f"{name}-tree-inventory")
    gitlinks = []
    for line in tree_entries.splitlines():
        mode, kind, remainder = line.split(" ", 2)
        revision, path = remainder.split("\t", 1)
        if mode == "160000":
            assert kind == "commit"
            gitlinks.append({"path": path, "commit": revision, "history_included": False})
    modules = ""
    if gitlinks:
        modules = git(imported, "show", f"{pin}:.gitmodules", label=f"{name}-gitmodules")
    mirror = remote_ref(entry["fork"], entry["mirror"], f"{name}-live-mirror")
    upstream = remote_ref(entry["upstream"], entry["upstream_branch"], f"{name}-live-upstream")
    live_tip = remote_ref(entry["fork"], entry["integration"], f"{name}-live-integration")
    assert mirror == upstream
    assert live_tip == tip
    records.append({
        **entry,
        "archive_ref": archive_ref,
        "bundle": bundle.name,
        "bundle_sha256": hashlib.sha256(bundle.read_bytes()).hexdigest(),
        "bundle_bytes": bundle.stat().st_size,
        "integration_tip": tip,
        "live_mirror": mirror,
        "live_upstream": upstream,
        "pin_is_integration_ancestor": True,
        "tree": tree,
        "commits": commits,
        "reachable_objects": len(objects.splitlines()),
        "shallow": False,
        "promisor": False,
        "missing_parent_repository_objects": 0,
        "bundle_prerequisites": [],
        "nested_gitlinks": gitlinks,
        "gitmodules": modules,
    })

(ROOT / "archive_records.json").write_text(json.dumps({
    "recorded_utc": datetime.now(timezone.utc).isoformat(),
    "git_version": subprocess.check_output(["git", "--version"], text=True).strip(),
    "scope": "Same-machine retention of complete parent Git histories for active maintained-fork pins; nested repositories and separately pinned build inputs are not included.",
    "archives": records,
}, indent=2) + "\n")
(ROOT / "commands.json").write_text(json.dumps(COMMANDS, indent=2) + "\n")
print(json.dumps([{key: record[key] for key in ("name", "pin", "bundle_bytes", "bundle_sha256", "commits", "reachable_objects", "nested_gitlinks")} for record in records], indent=2))
