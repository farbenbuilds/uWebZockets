import argparse
import json
from pathlib import Path
import re

from runner.contract import COUNTERS, DURATION, FIXED, POOL, WARMUP, WORKERS, fixed_result, require
from runner.measure_host import WORLD_SQL
from runner.queries_pair_contract import FIXTURE, SEED_SHA, SEED_WORLD_SHA, WORK, WRK, WRK_SHA, affinity, digest, read, same_state
from runner.updates_pair_contract import CUTOFF_DEADLINE_NS, CUTOFF_IDLE_NS, SOURCE_SEAL, fixed_overlay, phase_changes, same_identity
from verification import verify_host as host
from verification import verify_queries_pair as query
from verification import verify_updates_pair as updates
from world_scaling.contract import (DIRECTORY, LABELS, PROFILES, TARGET_RPS, accepted_variant, app_argv,
                                    client_result, plan, summarize, work_account, workload, wrk_argv)


def timed_sample(case, label, seconds, path, profile, metadata, app_pid, container):
    command = query.command(case, label)
    recorded_case = Path(command["argv"][-1]).parent
    require(recorded_case.name == case.name and command["argv"] == wrk_argv(recorded_case, label, seconds, path, profile,
                                                                            metadata["wrk"], metadata["lua"], metadata["http_port"]),
            "Client did not run the declared capacity profile")
    chunks = (case / f"{label}.request.http").read_bytes().split(b"\r\n")
    require(chunks[0] == f"GET {path} HTTP/1.1".encode() and chunks[-2:] == [b"", b""], "Incorrect HTTP request")
    headers = dict(line.decode().split(": ", 1) for line in chunks[1:-2])
    require(len(headers) == len(chunks[1:-2]) and headers == {"Connection": "keep-alive", "User-Agent": "uwz-sql-local-v1",
             "Host": f"127.0.0.1:{metadata['http_port']}"}, "World HTTP request headers differ")
    raw = (case / f"{label}.stdout").read_text()
    connections, threads = PROFILES[profile]
    sample = client_result(raw, profile, seconds)
    first, last = (read(case / f"{label}_{when}.resources.json") for when in ("before", "after"))
    started, ended = command["monotonic_before_spawn_ns"], command["monotonic_after_reap_ns"]
    require(first["monotonic_start_ns"] <= first["monotonic_end_ns"] <= started
            and started + sample["duration_us"] * 1000 <= ended <= last["monotonic_start_ns"] <= last["monotonic_end_ns"],
            "World CPU samples do not bracket the client")
    cpu = host.snapshot_cpu(first, last, app_pid, metadata["db_pid"], container, metadata["db_container"], metadata["proc_clock_ticks_per_second"])
    cpu["wrk_process"] = host.client_cpu((case / f"{label}.client_time.txt").read_text())
    return sample | {"rps": sample["requests"] * 1_000_000 / sample["duration_us"], "cpu_usec": cpu,
                     "cpu_usec_per_response": {role: usage["usage_usec"] / sample["requests"] for role, usage in cpu.items()},
                     "wrk_estimated_thread_cpu_utilization": cpu["wrk_process"]["usage_usec"] / (threads * sample["duration_us"]),
                     "connection_setting": connections, "wrk_threads": threads, "client_clock_ns": [started, ended]}


def verify_app(case, metadata, fixture):
    cid = (case / "app_run.stdout").read_text().strip()
    require(re.fullmatch(r"[0-9a-f]{64}", cid), "Invalid World app container ID")
    labels = read(case / "app_ownership.json")["labels"]
    token = labels["uwz.run-owner"]
    require(re.fullmatch(r"[0-9a-f]{32}", token) and labels == LABELS | {"uwz.run-owner": token}, "Invalid World app owner")
    life = {name: query.command(case, "app_" + name)
            for name in ("run", "stop", "logs", "final_state", "remove", "verify_ownership", "pid", "clock_namespace")}
    require(all(life[name]["argv"][-1] == cid for name in ("stop", "logs", "final_state", "remove", "verify_ownership", "pid")),
            "App evidence targets a different container")
    inspected = read(case / "app_verify_ownership.stdout")
    require(all(inspected.get(key) == value for key, value in labels.items())
            and life["run"]["argv"] == app_argv(case.name, token, metadata["variant"]["binary"], fixture["image"], metadata["http_port"]),
            "Wrong mounted World binary or app ownership")
    state = read(case / "app_final_state.stdout")
    require(state["ExitCode"] == 0 and state["OOMKilled"] is False and state["Running"] is False, "Unhealthy World app exit")
    pid = int((case / "app_pid.stdout").read_text())
    binding = read(case / "app_host_clock_namespace.json")
    clock = host.recorded_clock((case / "app_clock_namespace.stdout").read_text())
    host.require_same_clock(metadata["clock_namespace"], clock)
    require(binding["pid"] == pid and host.cgroup_container(binding["cgroup"], cid)
            and (binding.get("time_inode") == clock["inode"] or binding.get("unavailable_time_inode_errno") in (1, 13)),
            "World cgroup or monotonic clock proof differs")
    ready = sorted(case.glob("ready_app_*.stdout"))[-1]
    raw = ready.read_text()
    inodes = set(re.findall(r"owned_listener_inode=(\d+)", raw))
    require(query.command(case, ready.stem)["argv"][:3] == ["docker", "exec", cid]
            and inodes and inodes <= set(re.findall(r"socket:\[(\d+)\]", raw))
            and raw.count("anon_inode:[io_uring]") == WORKERS and affinity(raw) == metadata["expected_application_affinity"],
            "World listener ownership or app worker affinity differs")
    logs = "\n".join((case / f"app_logs.{stream}").read_text() for stream in ("stdout", "stderr"))
    workers = re.findall(r"SQL benchmark worker=(\d+) pool=(\d+) slab_bytes=(\d+)", logs)
    require(sorted(int(index) for index, _, _ in workers) == list(range(WORKERS))
            and all(int(pool) == POOL and int(slab) > 0 for _, pool, slab in workers), "Wrong World app pool logs")
    for record in case.glob("ready_sql_*.command.json"):
        host.check_socket_argv(query.command(case, record.name.removesuffix(".command.json"))["argv"], fixture["pg_socket_port"], fixture["container"])
    return life, pid, cid


def verify_fixed(case, route, path, count, original):
    responses = read(case / "fixed_responses.json")
    require(len(responses) == FIXED, "Expected 50 serial fixed HTTP responses")
    rows = [row for response in responses for row in fixed_result(response, route, path, count)]
    if route != "updates":
        require(all(original[row["id"]] == row["randomNumber"] for row in rows), "Fixed World read differs from canonical seed")
    return rows


def verify_case(case, spec, metadata, fixture, settings, proof, prior, predecessor):
    summary = read(case / "summary.json")
    route, profile = spec["route"], spec["profile"]
    path, count = workload(route)
    require(summary["valid"] is True and all(summary[key] == value for key, value in spec.items())
            and (summary["path"], summary["count"]) == (path, count), "Invalid World capacity case")
    before, before_cmd, restored, restore_end, original = updates.verify_start(case, fixture, settings, proof, prior, predecessor)
    life, pid, cid = verify_app(case, metadata, fixture)
    app, stop, removal = (life[key] for key in ("run", "stop", "remove"))
    ready, ready_cmd = updates.observed(case, "ready_pair", fixture, settings, proof)
    end_load, end_cmd = updates.observed(case, "after_load", fixture, settings, proof)
    after, after_cmd = updates.settled(case, "after", fixture, settings, proof)
    same_state(before, ready)
    require(ready["tcp_clients"] == WORKERS * POOL and ready["active_tcp_clients"] == 0
            and restore_end <= before_cmd["monotonic_before_spawn_ns"] < before_cmd["monotonic_after_reap_ns"]
            <= app["monotonic_before_spawn_ns"] < app["monotonic_after_reap_ns"] <= ready_cmd["monotonic_before_spawn_ns"]
            and end_cmd["monotonic_after_reap_ns"] <= stop["monotonic_before_spawn_ns"] < stop["monotonic_after_reap_ns"]
            <= removal["monotonic_before_spawn_ns"] < removal["monotonic_after_reap_ns"] <= after_cmd["monotonic_before_spawn_ns"],
            "World SQL boundaries do not bracket the app")
    result = spec | {"path": path, "count": count, "restored": restored, "pg_before": before, "pg_ready": ready,
                     "pg_after_load": end_load, "pg_after": after}
    phases = [("before", before), ("ready", ready)]
    next_row, next_cmd = after, after_cmd
    if spec["phase"] == "fixed":
        rows = verify_fixed(case, route, path, count, original)
        clock = read(case / "client_clock.json")
        require(ready_cmd["monotonic_after_reap_ns"] <= clock["started_ns"] < clock["finished_ns"] <= end_cmd["monotonic_before_spawn_ns"],
                "Fixed World requests escape their recorded window")
        work = work_account(before, after, route, profile, FIXED, True)
        phases.append(("after_load", end_load))
        if route == "updates":
            export = query.db_command(case, "world_after_updates", fixture, WORLD_SQL)
            next_row, next_cmd = updates.settled(case, "probe", fixture, settings, proof)
            persisted = host.world_from((case / "world_after_updates.stdout").read_text())
            distinct = host.matching_world(original, rows, persisted)
            same_identity(after, next_row)
            require(distinct == len(fixed_overlay(rows)) and next_row["seq_scan"] == after["seq_scan"] + 1
                    and all(after[key] == next_row[key] for key in COUNTERS if key != "seq_scan")
                    and after_cmd["monotonic_after_reap_ns"] <= export["monotonic_before_spawn_ns"]
                    < export["monotonic_after_reap_ns"] <= next_cmd["monotonic_before_spawn_ns"], "Unexpected World persistence export")
            result["persisted_world"] = {"matched_rows": len(persisted), "distinct_updated_ids": distinct, "off_window_export_scans": 1}
            require(result["persisted_world"] == summary["persisted_world"], "World persistence summary differs")
    else:
        warm = timed_sample(case, "warmup", WARMUP, path, profile, metadata, pid, cid)
        timed = timed_sample(case, "timed", DURATION, path, profile, metadata, pid, cid)
        warm_end, warm_cmd = updates.observed(case, "after_warmup", fixture, settings, proof)
        quiet, quiet_cmd = updates.observed(case, "before_stop", fixture, settings, proof)
        cutoff = updates.verified_cutoff(case, fixture, cid, timed["client_clock_ns"][1], end_cmd["monotonic_after_reap_ns"],
                                         quiet_cmd["monotonic_before_spawn_ns"])
        require(ready_cmd["monotonic_after_reap_ns"] <= warm["client_clock_ns"][0] < warm["client_clock_ns"][1]
                <= warm_cmd["monotonic_before_spawn_ns"] < warm_cmd["monotonic_after_reap_ns"]
                <= timed["client_clock_ns"][0] < timed["client_clock_ns"][1] <= end_cmd["monotonic_before_spawn_ns"]
                and cutoff == summary["cutoff_quiet"] and quiet["tcp_clients"] == WORKERS * POOL and quiet["active_tcp_clients"] == 0
                and quiet_cmd["monotonic_after_reap_ns"] <= stop["monotonic_before_spawn_ns"], "World client/cutoff chronology differs")
        work = work_account(before, after, route, profile, warm["requests"] + timed["requests"], False)
        phases.extend([("after_warmup", warm_end), ("after_load", end_load), ("before_stop", quiet)])
        result.update({"warmup": warm, "timed": timed, "cutoff_quiet": cutoff, "pg_after_warmup": warm_end, "pg_before_stop": quiet})
    movement = phase_changes([*phases, ("drained", after)])
    require(work == summary["sql_work"] and movement == summary["maintenance_and_wal"], "World work or maintenance record differs")
    return result | {"sql_work": work, "maintenance_and_wal": movement}, next_row, next_cmd["monotonic_after_reap_ns"], cid


def verify(root):
    md = read(root / "metadata.json")
    require(md["profiles"] == {name: list(profile) for name, profile in PROFILES.items()} and md["plan"] == plan()
            and md["variant"] == accepted_variant() and md["target_rps"] == TARGET_RPS
            and (md["workers"], md["pool"], md["warmup_seconds"], md["timed_seconds"], md["fixed_count"], md["pipeline_depth"])
            == (WORKERS, POOL, WARMUP, DURATION, FIXED, 1)
            and (md["cutoff"]["timeout_ns"], md["cutoff"]["minimum_quiet_ns"]) == (CUTOFF_DEADLINE_NS, CUTOFF_IDLE_NS),
            "World capacity source, profiles or work settings drifted")
    require(read(root / "completed.json") == [spec["name"] for spec in plan()], "Not all predeclared capacity cases completed")
    fixture = read(FIXTURE)
    require(digest(FIXTURE) == "6e845754beeadbccb1e22b55d60d2eaeee4cd8a66a05a75cb968cec349ca57fa"
            and md["postgresql_loopback_auth"] == "scram-sha-256"
            and fixture["seed_sha256"] == digest(FIXTURE.with_name("world.sql")) == SEED_SHA
            and fixture["world_sha256"] == digest(Path(fixture["world_path"])) == SEED_WORLD_SHA, "Wrong restored World fixture")
    settings_path, listener_path = (Path(fixture[key]) for key in ("settings_path", "listener_path"))
    settings, listener = read(settings_path), read(listener_path)
    require(digest(settings_path) == fixture["settings_sha256"] and digest(listener_path) == fixture["listener_sha256"]
            and settings["policy"] == {"setting": "auto", "source": "default", "reset_val": "auto"}
            and settings["settings"]["autovacuum"] == "on" and settings["settings"]["server_version_num"] == "180006"
            and settings["extensions"] == ["plpgsql"], "Wrong World fixture settings")
    proof_path = FIXTURE.parent / "hba_repair/verified.json"
    proof = read(proof_path)
    require(digest(proof_path.with_name("after_hba.conf")) == proof["hba_sha256"], "Frozen SCRAM rule file changed")
    initial_storage, final_storage = [updates.verified_storage(root, label, fixture, proof) for label in ("initial", "final")]
    require(initial_storage == md["postgresql_initial_storage"] and final_storage == read(root / "postgresql_final_storage.json")
            and initial_storage["settings"] == final_storage["settings"], "World storage or WAL settings evidence differs")
    required_inputs = {str(path) for path in (FIXTURE, WRK, SOURCE_SEAL, proof_path, DIRECTORY / "producer.py", DIRECTORY / "contract.py",
                                              WORK / "runner/status.lua", WORK / "runner/contract.py")}
    recorded_workload = {"wrk": md["sha256"][md["wrk"]], "lua": md["sha256"][md["lua"]],
                         "contract": md["sha256"][str(WORK / "runner/contract.py")]}
    require(required_inputs <= md["sha256"].keys() and all(digest(Path(path)) == recorded for path, recorded in md["sha256"].items())
            and md["wrk"] == str(WRK) and digest(WRK) == WRK_SHA and md["lua"] == str(WORK / "runner/status.lua")
            and recorded_workload == host.workload_fingerprints(read(WORK / "measurements/bridge_count20/metadata.json")),
            "World harness or exact fixed client inputs drifted")
    frozen = WORK / "measurements/host_count20"
    masks = affinity(sorted((frozen / "fixed_updates").glob("ready_app_*.stdout"))[-1].read_text())
    require(md["client_affinity"] == read(frozen / "metadata.json")["client_affinity"]
            and md["expected_application_affinity"] == masks and host.recorded_clock((root / "host_clock_namespace.txt").read_text()) == md["clock_namespace"],
            "World CPU placement or host clock changed")
    for label in ("db_identity", "db_image_id", "db_listener"):
        query.command(root, label)
    cid, image_id, image, pid, ports, labels, network, binds, pg_cmd = map(json.loads, (root / "db_identity.stdout").read_text().splitlines())
    port = host.check_host_topology(fixture, md, ports, network, binds, pg_cmd)
    bound = read(root / "db_host_binding.json")
    require(cid == md["db_container"] == fixture["container"] == proof["container"] == listener["container"]
            and pid == md["db_pid"] == proof["pid"] == listener["pid"] == bound["pid"]
            and labels == proof["labels"] and labels["uwz.run-token"] == fixture["owner_token"]
            and image == md["db_image"] == fixture["image"] and image_id == (root / "db_image_id.stdout").read_text().strip()
            and bound["cgroup"] == listener["cgroup"] and host.cgroup_container(bound["cgroup"], cid)
            and md["http_port"] == fixture["http_port"] and settings["endpoint"] == {"listen_addresses": "127.0.0.1", "port": str(port)},
            "World capacity run used a different owned PostgreSQL process or endpoint")
    host.check_listener((root / "db_listener.stdout").read_text(), port, listener["inode"])
    results, ids = [], set()
    previous, end = None, 0
    for spec in plan():
        case, previous, end, app_id = verify_case(root / spec["name"], spec, md, fixture, settings, proof, previous, end)
        require(app_id not in ids, "World app container reused")
        ids.add(app_id)
        results.append(case)
    query.verify_recorded_auth(root, "final", fixture, settings, proof)
    terminal, terminal_cmd = updates.settled(root, "terminal", fixture, settings, proof)
    same_identity(previous, terminal)
    inventory = query.command(root, "app_final_inventory")
    require(end <= terminal_cmd["monotonic_before_spawn_ns"] < terminal_cmd["monotonic_after_reap_ns"]
            <= inventory["monotonic_before_spawn_ns"] and all(previous[key] == terminal[key] for key in COUNTERS)
            and inventory["argv"] == ["docker", "ps", "--all", "--quiet", "--no-trunc",
                *(part for key, value in LABELS.items() for part in ("--filter", f"label={key}={value}"))]
            and not (root / "app_final_inventory.stdout").read_bytes(), "World final app/session inventory differs")
    return {"valid": True, "capacity": summarize(results), "cases": results, "terminal_sql": terminal,
            "postgresql_storage": {"before": initial_storage, "after": final_storage},
            "generator_scope": "Aggregate wrk user+system CPU divided by configured thread count and measured duration. It is an observation, not a capacity ceiling."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Independently check raw World capacity evidence")
    parser.add_argument("measurements", type=Path)
    print(json.dumps(verify(parser.parse_args().measurements), indent=2))
