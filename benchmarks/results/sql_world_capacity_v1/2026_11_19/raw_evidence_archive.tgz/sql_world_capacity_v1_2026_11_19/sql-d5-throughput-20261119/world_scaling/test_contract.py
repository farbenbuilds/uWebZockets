from collections import Counter
from pathlib import Path
import unittest

from runner.contract import COUNTERS
from runner.queries_pair_contract import WORK, read
from runner.updates_pair_contract import CLIENTS, MAINTENANCE
from world_scaling.contract import PROFILES, ROUTES, accepted_variant, client_result, plan, summarize, work_account, workload, wrk_argv
from world_scaling.verify import timed_sample


def row(**changes):
    return dict.fromkeys((*COUNTERS, *CLIENTS, *MAINTENANCE, "n_tup_hot_upd", "n_tup_newpage_upd"), 0) | {
        "maintenance_running": False,
    } | changes


def work(reads, writes=0, **changes):
    return row(idx_scan=reads + writes, pkey_scans=reads + writes, n_tup_upd=writes, **changes)


def samples(throughput):
    cpu = {"application_cgroup": 1, "postgres_cgroup": 2, "wrk_process": .5}
    return [case | {"timed": {"rps": throughput(case), "p99_us": 1000, "cpu_usec_per_response": cpu,
                             "wrk_estimated_thread_cpu_utilization": .2}} for case in plan() if case["phase"] == "timed"]


class CapacityTests(unittest.TestCase):
    def test_exact_predeclared_cases(self):
        specs = plan()
        self.assertEqual(len({case["name"] for case in specs}), 39)
        self.assertEqual([case["route"] for case in specs[:3]], list(ROUTES))
        counted = Counter((case["profile"], case["route"], case["repetition"]) for case in specs[3:])
        self.assertEqual(counted, Counter((profile, route, rep) for profile in PROFILES for route in ROUTES for rep in (1, 2, 3)))

    def test_routes_are_unmodified(self):
        self.assertEqual(workload("db"), ("/db", 1))
        self.assertEqual(workload("queries"), ("/queries?count=20", 20))
        self.assertEqual(workload("updates"), ("/updates?count=20", 20))

    def test_cutoff_uses_actual_connections_without_reducing_work(self):
        for profile, (connections, _) in PROFILES.items():
            for route in ROUTES:
                with self.subTest(profile=profile, route=route):
                    _, count = workload(route)
                    cap = (100 + 2 * connections) * count
                    writes = cap if route == "updates" else 0
                    valid = work_account(row(), work(cap, writes), route, profile, 100, False)
                    self.assertEqual(valid["cutoff_requests"], 2 * connections)
                    self.assertEqual(valid["total_primary_key_scans"], cap + writes)
                    with self.assertRaisesRegex(ValueError, "cutoff"):
                        work_account(row(), work(cap + 1, writes), route, profile, 100, False)
                    with self.assertRaisesRegex(ValueError, "cutoff"):
                        work_account(row(), work(100 * count - 1, 100 * count if writes else 0), route, profile, 100, False)

    def test_zero_rollback_and_exact_serial_fixed_updates(self):
        result = work_account(row(), work(1000, 1000), "updates", "c192_t4", 50, True)
        self.assertEqual((result["select_scans"], result["updated_rows"], result["total_primary_key_scans"]), (1000, 1000, 2000))
        with self.assertRaises(ValueError):
            work_account(row(), work(1000, 999), "updates", "c192_t4", 50, True)
        for route in ROUTES:
            _, count = workload(route)
            with self.assertRaisesRegex(ValueError, "rolled back"):
                work_account(row(), work(100 * count, 100 * count if route == "updates" else 0, xact_rollback=1),
                             route, "c192_t8", 100, False)

    def test_parameterized_client_argv(self):
        path = Path("/world/test")
        for profile, (connections, threads) in PROFILES.items():
            argv = wrk_argv(path, "timed", 10, "/queries?count=20", profile, "/wrk", "/status.lua", 3000)
            self.assertEqual(argv[7:13], ["-t", str(threads), "-c", str(connections), "-d", "10s"])
            self.assertEqual(argv[18], "http://127.0.0.1:3000/queries?count=20")

    def test_actual_frozen_client_output_and_cpu_replay(self):
        original = WORK / "measurements/updates_scram_pair_01"
        case = original / "pair1_candidate"
        metadata = read(original / "metadata.json")
        result = timed_sample(case, "timed", 10, "/updates?count=20", "c192_t4", metadata,
                              int((case / "app_pid.stdout").read_text()), (case / "app_run.stdout").read_text().strip())
        self.assertGreater(result["rps"], 0)
        self.assertEqual((result["connection_setting"], result["wrk_threads"]), (192, 4))
        self.assertGreater(result["wrk_estimated_thread_cpu_utilization"], 0)
        with self.assertRaisesRegex(ValueError, "thread/connection"):
            client_result((case / "timed.stdout").read_text(), "c192_t8", 10)

    def test_route_target_requires_median_but_not_shared_profile(self):
        best = {"db": "c96_t4", "queries": "c192_t4", "updates": "c384_t4"}
        qualifies = summarize(samples(lambda case: 300001 if best[case["route"]] == case["profile"] else 299999))
        self.assertTrue(qualifies["each_route_has_a_median_strictly_above_target"])
        self.assertEqual({route: each["highest_observed_median_profile"] for route, each in qualifies["by_route"].items()}, best)
        one_high = summarize(samples(lambda case: 500000 if case["repetition"] == 1 else 300000))
        self.assertFalse(one_high["each_route_has_a_median_strictly_above_target"])
        self.assertEqual(one_high["profiles"]["c192_t8"]["db"]["qualifying_samples"], [True, False, False])

    def test_selects_accepted_elf_and_real_source(self):
        check = accepted_variant()
        self.assertTrue(check["binary_sha256"].startswith("ee926185"))
        self.assertTrue(check["source_sha256"].startswith("eb6721b9"))


if __name__ == "__main__":
    unittest.main()
