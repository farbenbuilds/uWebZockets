import argparse
import os
from pathlib import Path
import platform
import re
import secrets
import signal
import time

from runner import measure_updates_pair as updates
from runner.contract import COUNTERS, DURATION, FIXED, POOL, WARMUP, WORKERS, require
from runner.queries_pair_contract import (APP_ENV, FIXTURE, SEED_SHA, WORK, WRK, WRK_SHA, affinity, digest, read, same_state)
from runner.updates_pair_contract import CUTOFF_DEADLINE_NS, CUTOFF_IDLE_NS, SOURCE_SEAL, phase_changes, same_identity
from world_scaling.contract import (DIRECTORY, LABELS, PROFILES, TARGET_RPS, accepted_variant, app_argv,
                                    client_result, plan, work_account, workload, wrk_argv)


host, query = updates.host, updates.query


def run_client(args, case, label, seconds, path, profile, pid):
    before = host.resource_snapshot(args, case, f"{label}_before", pid)
    raw = host.run(case, label, wrk_argv(case, label, seconds, path, profile, args.wrk, args.lua, args.port))
    after = host.resource_snapshot(args, case, f"{label}_after", pid)
    sample = client_result(raw, profile, seconds)
    cpu = host.cpu_delta(before, after)
    require(all(cpu[role].get("usage_usec", 0) > 0 for role in ("application", "postgres"))
            and (case / f"{label}.request.http").is_file() and (case / f"{label}.client_time.txt").is_file(),
            "Invalid capacity latency, CPU or load evidence")
    return sample


def ready_app(args, case, container, before):
    host.app_ready(args, case, container)
    ready = updates.observe(args, case, "ready_pair")
    same_state(before, ready)
    require(ready["tcp_clients"] == WORKERS * POOL and ready["active_tcp_clients"] == 0, "Unexpected World SQL pool at readiness")
    pid = host.read_pid(case, "app_pid", container)
    host.save_json(case / "app_host_clock_namespace.json", host.host_clock_binding(pid, container))
    raw = host.run(case, "app_clock_namespace", ["docker", "exec", container, "sh", "-ec", "readlink /proc/1/ns/time\n"
                   "readlink /proc/1/ns/time_for_children\ncat /proc/1/timens_offsets\nsha256sum /proc/sys/kernel/random/boot_id | cut -d ' ' -f 1"])
    require(host.same_clock(host.clock_namespace(raw), args.clock_namespace), "World application monotonic clock changed")
    masks = affinity(sorted(case.glob("ready_app_*.stdout"))[-1].read_text())
    require(masks == args.app_affinity, "World application affinity changed")
    return ready, pid


def measure(args, spec, fixture, prior):
    case = args.output / spec["name"]
    case.mkdir()
    print(f"Starting {case.name}", flush=True)
    fixed = spec["phase"] == "fixed"
    path, count = workload(spec["route"])
    record = spec | {"path": path, "count": count, "valid": False}
    owner = secrets.token_hex(16)
    labels = LABELS | {"uwz.run-owner": owner}
    host.save_json(case / "app_ownership.json", {"labels": labels})
    container, after = None, None
    starting = False
    try:
        before = updates.initialize(args, case, fixture, prior)
        require(digest(args.binary) == args.binary_hash, "Selected accepted application binary changed")
        starting = True
        cid = host.run(case, "app_run", app_argv(case.name, owner, args.binary, args.image, args.port)).strip()
        require(re.fullmatch(r"[0-9a-f]{64}", cid), "Invalid capacity application container ID")
        container = cid
        ready, pid = ready_app(args, case, container, before)
        stops = [("before", before), ("ready", ready)]
        if fixed:
            started = time.monotonic_ns()
            returned = host.fixed_load(args, case, spec["route"], path, count)
            host.save_json(case / "client_clock.json", {"started_ns": started, "finished_ns": time.monotonic_ns()})
        else:
            record["warmup"] = run_client(args, case, "warmup", WARMUP, path, spec["profile"], pid)
            stops.append(("after_warmup", updates.observe(args, case, "after_warmup")))
            record["timed"] = run_client(args, case, "timed", DURATION, path, spec["profile"], pid)
        stops.append(("after_load", updates.observe(args, case, "after_load")))
        if not fixed:
            record["cutoff_quiet"] = updates.wait_cutoff(args, case, container)
            quiet = updates.observe(args, case, "before_stop")
            require(quiet["tcp_clients"] == WORKERS * POOL and quiet["active_tcp_clients"] == 0,
                    "World pool activity changed after cutoff")
            stops.append(("before_stop", quiet))
    except (OSError, RuntimeError, ValueError, KeyError) as error:
        record["failure"] = str(error)
    finally:
        if starting:
            container = container or host.find_owned_container(case, labels)
        if container is not None:
            record["app_state"] = host.collect_stop(case, container, labels)
    try:
        after = updates.stable_stats(args, case, "after")
        if "failure" not in record:
            state = record["app_state"]
            require(state["ExitCode"] == 0 and state["OOMKilled"] is False and not state["evidence_errors"], "Unhealthy World app cleanup")
            completed = FIXED if fixed else record["warmup"]["requests"] + record["timed"]["requests"]
            record["sql_work"] = work_account(before, after, spec["route"], spec["profile"], completed, fixed)
            record["maintenance_and_wal"] = phase_changes([*stops, ("drained", after)])
            if fixed and spec["route"] == "updates":
                after, record["persisted_world"] = updates.persisted(args, case, returned, after)
            record["valid"] = True
    except (OSError, RuntimeError, ValueError, KeyError) as error:
        record["failure"] = str(error)
    host.save_json(case / "summary.json", record)
    print(f"Finished {case.name} valid={record['valid']} {record.get('sql_work', record.get('failure', ''))}", flush=True)
    return record, after


def main():
    parser = argparse.ArgumentParser(description="Four-profile World capacity screen on one accepted binary")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output = args.output.resolve()
    require(args.output.parent == DIRECTORY / "measurements" and args.output.name.startswith("capacity_screen_"),
            "Use a fresh destination in world_scaling/measurements")
    variant = accepted_variant()
    args.binary, args.binary_hash = Path(variant["binary"]), variant["binary_sha256"]
    args.fixture, args.app_env, args.wrk, args.lua = FIXTURE, APP_ENV, WRK, WORK / "runner/status.lua"
    require(digest(WRK) == WRK_SHA and digest(FIXTURE) == "6e845754beeadbccb1e22b55d60d2eaeee4cd8a66a05a75cb968cec349ca57fa",
            "World fixture or client binary changed")
    frozen = WORK / "measurements/host_count20"
    frozen_meta = read(frozen / "metadata.json")
    mask = sorted((frozen / "fixed_updates").glob("ready_app_*.stdout"))[-1]
    args.app_affinity = affinity(mask.read_text())
    client_affinity = sorted(os.sched_getaffinity(0))
    require(client_affinity == frozen_meta["client_affinity"] and digest(args.lua) == frozen_meta["sha256"][str(args.lua)],
            "Client affinity or exact-status Lua differs")
    args.output.mkdir(parents=True)
    fixture = host.bind_fixture(args)
    require(fixture["seed_sha256"] == SEED_SHA and (args.db_user, args.db_name) == ("bench", "benchmark"),
            "Wrong owned World seed or application role")
    query.check_environment(args)
    hba = FIXTURE.parent / "hba_repair/verified.json"
    args.auth_proof = read(hba)
    initial_storage = updates.storage_observation(args, "initial")
    clock = time.get_clock_info("monotonic")
    require(clock.implementation == "clock_gettime(CLOCK_MONOTONIC)" and clock.monotonic and not clock.adjustable, "Wrong host clock")
    raw = (os.readlink("/proc/self/ns/time") + "\n" + os.readlink("/proc/self/ns/time_for_children") + "\n"
           + Path("/proc/self/timens_offsets").read_text() + digest(Path("/proc/sys/kernel/random/boot_id")) + "\n")
    args.clock_namespace = host.clock_namespace(raw)
    (args.output / "host_clock_namespace.txt").write_text(raw)
    inputs = (FIXTURE, hba, WRK, args.lua, SOURCE_SEAL, mask, Path(__file__), DIRECTORY / "contract.py",
              *(Path(module.__file__) for module in (host, query, updates)), WORK / "runner/contract.py",
              WORK / "runner/queries_pair_contract.py", WORK / "runner/updates_pair_contract.py")
    host.save_json(args.output / "metadata.json", {
        "recorded_at": host.now(), "purpose": "Exploratory capacity settings on one accepted source and binary",
        "profiles": PROFILES, "plan": plan(), "variant": variant, "target_rps": TARGET_RPS,
        "workers": WORKERS, "pool": POOL, "warmup_seconds": WARMUP, "timed_seconds": DURATION, "fixed_count": FIXED, "pipeline_depth": 1,
        "postgresql_network": "host_loopback", "postgresql_loopback_auth": "scram-sha-256", "pg_host_port": args.db_port,
        "db_container": args.db_container, "db_pid": args.db_pid, "db_image": args.image, "http_port": args.port,
        "wrk": str(WRK), "lua": str(args.lua), "kernel": platform.release(), "client_affinity": client_affinity,
        "expected_application_affinity": args.app_affinity, "clock_namespace": args.clock_namespace,
        "proc_clock_ticks_per_second": os.sysconf("SC_CLK_TCK"),
        "postgresql_initial_storage": initial_storage,
        "cutoff": {"timeout_ns": CUTOFF_DEADLINE_NS, "minimum_quiet_ns": CUTOFF_IDLE_NS,
                   "accounting": "Two client cutoffs, each at most the configured HTTP connections times unchanged route work"},
        "storage_scope": "Same logical World before each case. Physical table/index history, autonomous maintenance and cluster WAL can differ.",
        "sha256": {str(path): digest(path) for path in inputs},
    })
    prior = None
    completed = []
    try:
        for spec in plan():
            result, prior = measure(args, spec, fixture, prior)
            completed.append(spec["name"])
            host.save_json(args.output / "completed.json", completed)
            if not result["valid"]:
                return 2
        query.verify_db(args, args.output, "final", fixture, args.auth_proof)
        terminal = updates.stable_stats(args, args.output, "terminal")
        same_identity(prior, terminal)
        require(all(prior[key] == terminal[key] for key in COUNTERS), "Unexpected World activity after the final case")
        return 0
    finally:
        inventory = host.run(args.output, "app_final_inventory", ["docker", "ps", "--all", "--quiet", "--no-trunc",
                             *(part for key, value in LABELS.items() for part in ("--filter", f"label={key}={value}"))])
        require(not inventory, "An owned capacity application container remains")
        storage = updates.storage_observation(args, "final")
        host.save_json(args.output / "postgresql_final_storage.json", storage)
        require(storage["settings"] == initial_storage["settings"], "WAL/checkpoint settings changed")


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, host.interrupted)
    raise SystemExit(main())
