import json
from pathlib import Path
import re
import statistics

from runner.contract import FIXED, WORKERS, check_client, require, sql_work
from runner.queries_pair_contract import APP_ENV, CANDIDATE, COUNT
from runner.updates_pair_contract import account, drained, same_identity, sealed_variants


DIRECTORY = Path(__file__).resolve().parent
LABELS = {"uwz.sql-experiment": "sql-d5-throughput-20261119-host", "uwz.role": "application", "uwz.cohort": "world-capacity"}
PROFILES = {"c96_t4": (96, 4), "c192_t4": (192, 4), "c384_t4": (384, 4), "c192_t8": (192, 8)}
ROUTES = ("db", "queries", "updates")
REPETITIONS = 3
TARGET_RPS = 300_000


def accepted_variant():
    variant = sealed_variants()[CANDIDATE]
    require(variant["binary_sha256"] == "ee9261859ee0cd5f9271f15081520f5cae05426eb06bdf19d15d31774298f760"
            and variant["source_sha256"] == "eb6721b9d0e9dfc26f4ae206fce762b0661ac32cd45e46d82040b42ea967d9e9",
            "The accepted updates checkpoint binary or source drifted")
    return variant


def plan():
    output = [{"name": f"fixed_{route}", "phase": "fixed", "route": route, "profile": "c192_t4", "repetition": 0}
              for route in ROUTES]
    profiles = tuple(PROFILES)
    for index in range(REPETITIONS):
        for offset, profile in enumerate(profiles[index:] + profiles[:index]):
            start = (index + offset) % len(ROUTES)
            for route in ROUTES[start:] + ROUTES[:start]:
                output.append({"name": f"r{index + 1}_{profile}_{route}", "phase": "timed",
                               "route": route, "profile": profile, "repetition": index + 1})
    return output


def workload(route):
    require(route in ROUTES, "Unknown World route")
    if route == "db":
        return "/db", 1
    return f"/{route}?count={COUNT}", COUNT


def work_account(before, after, route, profile, completed, fixed):
    require(drained(before) and drained(after), "World work requires stable drained SQL endpoints")
    same_identity(before, after)
    cutoff = 0 if fixed else 2 * PROFILES[profile][0]
    if fixed:
        require(completed == FIXED, "Wrong fixed response count")
    _, count = workload(route)
    if route == "updates":
        return account(before, after, count, completed, cutoff)
    result = sql_work(before, after, route, count, completed, cutoff)
    require(result["deltas"]["xact_rollback"] == 0 and all(before[key] == after[key]
            for key in ("n_tup_hot_upd", "n_tup_newpage_upd")), "World read route rolled back or changed update statistics")
    selects = result.pop("read_scans")
    result.pop("reads_per_complete_request")
    return result | {"select_scans": selects, "total_primary_key_scans": result["deltas"]["pkey_scans"],
                     "selects_per_complete_request": count, "primary_key_scans_per_complete_request": count}


def wrk_argv(case, label, seconds, path, profile, wrk, lua, port):
    connections, threads = PROFILES[profile]
    return ["env", "LC_ALL=C", "/usr/bin/time", "-v", "-o", str(case / f"{label}.client_time.txt"), str(wrk),
            "-t", str(threads), "-c", str(connections), "-d", f"{seconds}s", "--timeout", "2s", "--latency",
            "-s", str(lua), f"http://127.0.0.1:{port}{path}", "--", str(case / f"{label}.request.http")]


def client_result(raw, profile, seconds):
    connections, threads = PROFILES[profile]
    require(re.findall(r"^\s*(\d+) threads and (\d+) connections\s*$", raw, re.M) == [(str(threads), str(connections))],
            "wrk output disagrees with the selected thread/connection count")
    line, = re.findall(r"^SQL_SAMPLE (.+)$", raw, re.M)
    sample = json.loads(line)
    check_client(sample, seconds)
    require(0 < sample["p50_us"] <= sample["p95_us"] <= sample["p99_us"], "Invalid HTTP latency distribution")
    return sample


def app_argv(case_name, token, binary, image, port):
    labels = LABELS | {"uwz.run-owner": token}
    return ["docker", "run", "--detach", "--pull=never", "--network", "host", "--name", f"uwz-d5-world-{case_name}-{token[:8]}",
            *(value for key, entry in labels.items() for value in ("--label", f"{key}={entry}")),
            "--security-opt", "seccomp=unconfined", "--ulimit", "memlock=-1:-1", "--ulimit", "nofile=524288:524288",
            "--stop-signal", "SIGTERM", "--env-file", str(APP_ENV), "--env", f"UWZ_SQL_WORKERS={WORKERS}",
            "--env", "UWZ_SQL_AFFINITY=1", "--env", f"UWZ_HTTP_PORT={port}",
            "--mount", f"type=bind,source={binary},target=/server,readonly", "--entrypoint", "/server", image]


def summarize(cases):
    profiles = {}
    for name, (connections, threads) in PROFILES.items():
        profiles[name] = {}
        for route in ROUTES:
            by_rep = sorted((case for case in cases if case["profile"] == name and case["route"] == route and case["phase"] == "timed"),
                            key=lambda each: each["repetition"])
            require([each["repetition"] for each in by_rep] == [1, 2, 3], "Missing predeclared capacity repetitions")
            samples = [case["timed"] for case in by_rep]
            rps = [sample["rps"] for sample in samples]
            p99 = [sample["p99_us"] for sample in samples]
            med = statistics.median(rps)
            roles = ("application_cgroup", "postgres_cgroup", "wrk_process")
            cpu = {role: [sample["cpu_usec_per_response"][role] for sample in samples] for role in roles}
            profiles[name][route] = {"connections": connections, "wrk_threads": threads,
                "rps_triplet": rps, "rps_median": med, "http_p99_usec_triplet": p99,
                "http_p99_usec_median": statistics.median(p99),
                "role_cpu_usec_per_response_triplets": cpu,
                "wrk_estimated_thread_cpu_utilization_triplet": [sample["wrk_estimated_thread_cpu_utilization"] for sample in samples],
                "qualifying_samples": [value > TARGET_RPS for value in rps], "median_strictly_above_target": med > TARGET_RPS}
    by_route = {}
    for route in ROUTES:
        best = max(PROFILES, key=lambda name: profiles[name][route]["rps_median"])
        by_route[route] = {"highest_observed_median_profile": best,
                          "highest_observed_median": profiles[best][route]["rps_median"],
                          "median_strictly_above_target": profiles[best][route]["median_strictly_above_target"]}
    return {"profiles": profiles, "by_route": by_route, "target_rps": TARGET_RPS,
            "each_route_has_a_median_strictly_above_target": all(row["median_strictly_above_target"] for row in by_route.values()),
            "scope": "Exploratory capacity settings on one unchanged binary and shared host."}
