#!/usr/bin/env python3
"""Verify the capacity run using only the three archived evidence packets."""
import argparse
import json
from pathlib import Path
import sys
import tarfile
import unittest

from bundle_files import check_manifest, inventory, load, require, sha


BUNDLE = Path(__file__).resolve().parent
WORK = BUNDLE / 'sql-d5-throughput-20261119'
RUN = WORK / 'world_scaling/measurements/capacity_screen_01'
RESULT_SHA = '5ad2bf10726841ab243be92e4e9708362b8cbd3ac9c6cdc137dcb0c6a25503ab'
ARCHIVES = {
    'queries': ('sql_world_queries_chunk_v1_2026_11_19',
                '965f2d156fdadfad52252ff3bc34885015ee4340fee9a8fc5113096d3a00d351'),
    'updates': ('sql_world_updates_chunk_v1_2026_11_19',
                'af164645eabbe06a5fc3fe14d7bee32e458366767b1f7c7d13cb955ab38de8b9'),
}


class RecordedPath(type(Path())):
    """Preserve original path strings while opening manifested archive inputs."""

    anchor = None
    files = {}

    def archive_name(self):
        path = Path(str(self))
        require(self.anchor is not None and path.is_absolute() and path.is_relative_to(self.anchor),
                f'Unrecognized recorded path: {path}')
        relative = path.relative_to(self.anchor)
        require('..' not in relative.parts and 'private' not in relative.parts, f'Unexpected archive input: {path}')
        return relative.as_posix()

    def archived(self):
        name = self.archive_name()
        require(name in self.files, f'Unmapped archived file: {name}')
        return self.files[name]

    def open(self, *args, **kwargs):
        return self.archived().open(*args, **kwargs)

    def stat(self, *, follow_symlinks=True):
        return self.archived().stat(follow_symlinks=follow_symlinks)

    def resolve(self, strict=False):
        self.archived().resolve(strict=strict)
        return self

    def glob(self, pattern, *args, **kwargs):
        require(not args and not kwargs, 'Unexpected archived glob options')
        root = self.archive_name()
        return (self / path.name for name in sorted(self.files)
                if (path := Path(name)).parent.as_posix() == root and path.match(pattern))


def check_prerequisite(arm, archive, root, receipt):
    name, digest = ARCHIVES[arm]
    require(root.name == receipt['root'] == name and sha(archive) == receipt['sha256'] == digest,
            f'Wrong {arm} prerequisite archive')
    manifest = root / 'payload_manifest.json'
    with tarfile.open(archive, 'r:gz') as sealed:
        item = sealed.getmember(f'{name}/payload_manifest.json')
        require(item.isfile() and sealed.extractfile(item).read() == manifest.read_bytes() and
                sha(manifest) == receipt['payload_manifest_sha256'], f'Extracted {arm} manifest differs from its exact tar')
    check_manifest(root)
    return {item['path'] for item in load(manifest)['files']}


def bind_files(archives, roots):
    dependency = load(BUNDLE / 'dependencies.json')
    require(dependency['archives'].keys() == ARCHIVES.keys(), 'Wrong prerequisite set')
    inventories = {arm: check_prerequisite(arm, archives[arm], roots[arm], dependency['archives'][arm])
                   for arm in ARCHIVES}
    files = {name: BUNDLE / name for name in inventory(BUNDLE)}
    for name, arm in dependency['artifacts'].items():
        require(arm in inventories and name in inventories[arm] and name not in files,
                f'Unexpected prerequisite binding: {name}')
        files[name] = roots[arm] / name
    RecordedPath.files = files


def check_prelaunch():
    seen = set()
    for line in (WORK / 'world_scaling/prelaunch.sha256').read_text().splitlines():
        digest, name = line.split(maxsplit=1)
        archive_path = name[3:] if name.startswith('../') else f'{WORK.name}/{name}'
        require(archive_path not in seen and archive_path in RecordedPath.files and
                sha(RecordedPath.files[archive_path]) == digest, f'Prelaunch identity differs: {name}')
        seen.add(archive_path)
    require(seen, 'Empty prelaunch receipt')


def bind_checkers(roots):
    sys.path[:0] = [str(WORK), str(roots['updates'] / WORK.name),
                   str(roots['queries'] / WORK.name), str(roots['queries'] / WORK.name / 'runner')]
    from runner import queries_pair_contract as queries
    from runner import updates_pair_contract as updates
    from verification import verify_queries_pair as query_checker
    from verification import verify_updates_pair as update_checker
    from world_scaling import contract, verify

    imports = {
        queries: 'runner/queries_pair_contract.py',
        updates: 'runner/updates_pair_contract.py',
        query_checker: 'verification/verify_queries_pair.py',
        update_checker: 'verification/verify_updates_pair.py',
        verify.host: 'verification/verify_host.py',
        contract: 'world_scaling/contract.py',
        verify: 'world_scaling/verify.py',
    }
    for module, path in imports.items():
        require(Path(module.__file__).resolve() == RecordedPath.files[f'{WORK.name}/{path}'],
                f'Unexpected checker import origin: {path}')

    build = Path(load(RUN / 'metadata.json')['variant']['build'])
    work = RecordedPath(str(build.parents[2]))
    require(work.name == WORK.name and work.parent.name == '.zig-cache', 'Unexpected recorded workspace anchor')
    RecordedPath.anchor = Path(str(work.parent))
    for module in (queries, updates, query_checker, update_checker, contract, verify):
        module.Path = RecordedPath
        module.WORK = work
        module.WRK = work.parent / 'async-db-performance-20261118/tooling/root/usr/bin/wrk'
        module.FIXTURE = work / 'host_fixture/fixture/fixture.json'
        module.APP_ENV = work / 'host_fixture/private/app.env'
        module.SOURCE_SEAL = work / 'verification/updates_pair_candidate.json'
    contract.DIRECTORY = verify.DIRECTORY = work / 'world_scaling'
    return verify


def run_tests():
    from world_scaling import test_contract

    require(Path(test_contract.__file__).resolve() == WORK / 'world_scaling/test_contract.py', 'Unexpected test import origin')
    suite = unittest.defaultTestLoader.loadTestsFromModule(test_contract)
    require(suite.countTestCases() == 8 and unittest.TextTestRunner().run(suite).wasSuccessful(),
            'Archived capacity contract tests failed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arm in ARCHIVES:
        parser.add_argument(f'--{arm}-archive', required=True, type=Path)
        parser.add_argument(f'--{arm}-root', required=True, type=Path)
    parser.add_argument('--test-checkers', action='store_true', help='also run the eight archived offline tests')
    args = parser.parse_args()
    count = check_manifest(BUNDLE)
    archives = {arm: getattr(args, f'{arm}_archive').resolve(strict=True) for arm in ARCHIVES}
    roots = {arm: getattr(args, f'{arm}_root').resolve(strict=True) for arm in ARCHIVES}
    bind_files(archives, roots)
    check_prelaunch()
    checker = bind_checkers(roots)
    verified = RUN / 'verified.json'
    require(sha(verified) == RESULT_SHA, 'Wrong frozen capacity result')
    result = checker.verify(RUN)
    require(json.loads(json.dumps(result)) == load(verified), 'Raw recomputation differs from the frozen capacity result')
    if args.test_checkers:
        run_tests()
    print(f'Authenticated both prerequisite payloads and verified {count} capacity payload files.')
    print(f"Recomputed {len(result['cases'])} cases, including all 36 timed samples and three fixed body cohorts.")
    print('No tested profile median crossed 300,000 requests/s for any route.')


if __name__ == '__main__':
    try:
        main()
    except (KeyError, OSError, ValueError, tarfile.TarError) as error:
        sys.exit(f'Capacity evidence verification failed: {error}')
