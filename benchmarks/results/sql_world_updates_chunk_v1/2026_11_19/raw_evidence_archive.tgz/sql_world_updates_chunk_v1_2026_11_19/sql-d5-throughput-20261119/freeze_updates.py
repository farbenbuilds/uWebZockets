#!/usr/bin/env python3
"""Freeze only the accepted named source inputs, then build the SQL candidate."""
import argparse
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import time


WORK = Path(__file__).resolve().parent
REPO = WORK.parent.parent
CONTROL = WORK / 'queries_candidate'
OUTPUT = WORK / 'updates_candidate'
BASE_SHA = 'ed80223d93ce26a5c0b1a0affc589ad60a849214a2c76401e67f7c36e09732b5'
COMMIT = 'ab6bf89ce520ff72a2006eb6148f72f4250da3bc'
CHANGES = {'examples/sql_postgres.zig', 'src/tests/sql_postgres_tests.zig'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def freeze(expected):
    assert not OUTPUT.exists(), 'Refusing an existing candidate destination'
    base = CONTROL / 'baseline_source_identity.json'
    assert sha(base) == BASE_SHA
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == COMMIT
    baseline = load(base)['files']
    assert len(baseline) == 348 and len({row['path'] for row in baseline}) == 348
    contents, changed = {}, set()
    for row in baseline:
        name = row['path']
        path = REPO / name
        assert not path.is_symlink() and path.resolve().is_relative_to(REPO)
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        if digest != row['sha256']:
            changed.add(name)
        if name in CHANGES:
            assert digest == expected[name], f'Unreviewed source: {name}'
        contents[name] = data
    assert changed == CHANGES, f'Unexpected source changes: {sorted(changed)}'
    doc = REPO / 'docs/sql.md'
    assert not doc.is_symlink() and sha(doc) == expected['docs/sql.md']
    OUTPUT.mkdir()
    source = OUTPUT / 'source'
    source.mkdir()
    entries = []
    for row in baseline:
        path = source / row['path']
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(contents[row['path']])
        path.chmod(row['mode'])
        entries.append({'path': row['path'], 'sha256': sha(path), 'mode': stat.S_IMODE(path.stat().st_mode)})
    documentation = OUTPUT / 'documentation/docs/sql.md'
    documentation.parent.mkdir(parents=True)
    documentation.write_bytes(doc.read_bytes())
    assert sha(documentation) == expected['docs/sql.md']
    patch = subprocess.check_output(['git', 'diff', COMMIT, '--', *sorted(CHANGES), 'docs/sql.md'], cwd=REPO)
    (OUTPUT / 'tracked.patch').write_bytes(patch)
    save(OUTPUT / 'baseline_source_identity.json', {
        'commit': COMMIT, 'uncommitted_candidate': True,
        'baseline_source_identity_sha256': BASE_SHA,
        'runtime_changes': ['examples/sql_postgres.zig'],
        'test_changes': ['src/tests/sql_postgres_tests.zig'],
        'documentation': {'path': 'docs/sql.md', 'sha256': sha(documentation)},
        'tracked_patch_sha256': sha(OUTPUT / 'tracked.patch'),
        'protected_vendor_build_inputs_used': False,
        'artifact_only_build_changes': False,
        'freeze_producer_sha256': sha(Path(__file__)),
        'files': entries,
    })
    assert all(sha(REPO / name) == expected[name] for name in expected)


def build():
    manifest = OUTPUT / 'baseline_source_identity.json'
    source = load(manifest)
    for row in source['files']:
        path = OUTPUT / 'source' / row['path']
        assert sha(path) == row['sha256'] and stat.S_IMODE(path.stat().st_mode) == row['mode']
    argv = list(load(CONTROL / 'baseline_build/result.json')['argv'])
    argv[argv.index('--prefix') + 1] = str(OUTPUT / 'install')
    directory = OUTPUT / 'baseline_build'
    assert not directory.exists(), 'Refusing existing build receipts'
    directory.mkdir()
    receipt = {'argv': argv, 'cwd': str(OUTPUT / 'source'), 'started_unix_ns': time.time_ns(),
               'source_identity_sha256': sha(manifest), 'zig_sha256': sha(Path(argv[0])),
               'source_commit': source['commit']}
    save(directory / 'command.json', receipt)
    start = time.monotonic()
    with (directory / 'build.log').open('w') as stream:
        result = subprocess.run(argv, cwd=receipt['cwd'], stdout=stream, stderr=subprocess.STDOUT)
    receipt.update({'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - start,
                    'finished_unix_ns': time.time_ns()})
    intact = all(sha(OUTPUT / 'source' / row['path']) == row['sha256'] and
                 stat.S_IMODE((OUTPUT / 'source' / row['path']).stat().st_mode) == row['mode']
                 for row in source['files']) and sha(manifest) == receipt['source_identity_sha256']
    receipt['source_integrity_after_build'] = intact
    if not intact:
        receipt['compiler_exit_code'] = result.returncode
        receipt['exit_code'] = 1
    if receipt['exit_code'] == 0:
        receipt['binaries'] = {}
        for name in ('sql_cluster_server', 'sql_query_probe'):
            path = OUTPUT / 'install/bin' / name
            receipt['binaries'][name] = {'path': str(path), 'sha256': sha(path),
                                         'bytes': path.stat().st_size, 'mode': stat.S_IMODE(path.stat().st_mode)}
    save(directory / 'result.json', receipt)
    print(json.dumps(receipt))
    raise SystemExit(receipt['exit_code'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('freeze', 'build'))
    parser.add_argument('--example-sha256')
    parser.add_argument('--tests-sha256')
    parser.add_argument('--doc-sha256')
    args = parser.parse_args()
    if args.action == 'freeze':
        expected = dict(zip(('examples/sql_postgres.zig', 'src/tests/sql_postgres_tests.zig', 'docs/sql.md'),
                            (args.example_sha256, args.tests_sha256, args.doc_sha256)))
        assert all(value and len(value) == 64 for value in expected.values())
        freeze(expected)
    else:
        build()
