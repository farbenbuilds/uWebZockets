import argparse
from collections import Counter
from contextlib import contextmanager
from itertools import groupby
import hashlib
import http.client
import json
import os
from pathlib import Path
import re
import secrets
import signal
import stat
import time

from developer import check_queries_lifecycle as shared
from runner.contract import require, unique_fields
from runner.queries_pair_contract import CANDIDATE, FIXTURE, digest, read
from runner.updates_pair_contract import sealed_variants


DIRECTORY = Path(__file__).resolve().parent
PRIVATE = FIXTURE.parents[1] / "private/world_integration.env"
IDENTITY = FIXTURE.with_name("unit_runtime_identity.json")
COUNTS = (1, 7, 8, 9, 20, 500)
SELECT = "SELECT id, randomnumber FROM World WHERE id=$1"
UPDATE = "UPDATE World SET randomnumber=$1 WHERE id=$2 RETURNING id,randomnumber"
CLIENTS_SQL = """
SELECT json_build_object(
 'tcp', count(*) FILTER(WHERE client_addr IS NOT NULL),
 'owned_tcp',count(*) FILTER(WHERE client_addr IS NOT NULL AND datname='uwz_world_test' AND usename='uwz_world_test'),
 'active_tcp',count(*) FILTER(WHERE client_addr IS NOT NULL AND state IS DISTINCT FROM 'idle'),
 'other',count(*) FILTER(WHERE client_addr IS NULL OR datname IS DISTINCT FROM 'uwz_world_test' OR usename IS DISTINCT FROM 'uwz_world_test'),
 'tls',count(*) FILTER(WHERE ssl))
FROM pg_stat_activity activity LEFT JOIN pg_stat_ssl USING(pid)
WHERE backend_type='client backend' AND pid<>pg_backend_pid();
"""
WORLD_SCHEMA_SQL = """
SELECT json_build_object(
 'oid', c.oid::bigint,'kind',c.relkind,'owner',pg_get_userbyid(c.relowner),'options',c.reloptions,
 'columns',(SELECT json_agg(json_build_array(attname,atttypid::bigint,attnotnull) ORDER BY attnum)
             FROM pg_attribute WHERE attrelid=c.oid AND attnum>0 AND NOT attisdropped),
 'constraints',(SELECT json_agg(json_build_array(oid::bigint,contype,conrelid::bigint,confrelid::bigint,
                        pg_get_constraintdef(oid)) ORDER BY oid) FROM pg_constraint WHERE conrelid=c.oid OR confrelid=c.oid),
 'indexes',(SELECT json_agg(json_build_array(indexrelid::bigint,pg_get_indexdef(indexrelid)) ORDER BY indexrelid)
            FROM pg_index WHERE indrelid=c.oid))
FROM pg_class c WHERE c.oid=to_regclass('public.world');
"""
INVENTORY_SQL = """
SELECT json_build_object(
 'relations',(SELECT json_agg(json_build_array(c.relname,c.oid::bigint,c.relkind,pg_get_userbyid(c.relowner)) ORDER BY c.relname)
              FROM pg_class c JOIN pg_namespace n ON c.relnamespace=n.oid WHERE n.nspname='public'
              AND (c.relname='world' OR left(c.relname,7)='uwz_ul_')),
 'functions',(SELECT json_agg(json_build_array(p.proname,p.oid::bigint,pg_get_userbyid(p.proowner),pg_get_functiondef(p.oid)) ORDER BY p.oid)
              FROM pg_proc p JOIN pg_namespace n ON p.pronamespace=n.oid WHERE n.nspname='public' AND left(p.proname,7)='uwz_ul_'),
 'view',(SELECT pg_get_viewdef(oid) FROM pg_class WHERE oid=to_regclass('public.world') AND relkind='v'));
"""
SNAPSHOT_SQL = """
SELECT json_build_object(
 'select_started',(SELECT CASE WHEN is_called THEN last_value ELSE 0 END FROM public.uwz_ul_select_seq),
 'update_started',(SELECT CASE WHEN is_called THEN last_value ELSE 0 END FROM public.uwz_ul_update_seq),
 'events_started',(SELECT CASE WHEN is_called THEN last_value ELSE 0 END FROM public.uwz_ul_event_seq),
 'committed',(SELECT coalesce(json_agg(row_to_json(log) ORDER BY event),'[]'::json) FROM public.uwz_ul_log log));
"""


def save(path, value, *, durable=False):
    temporary = path.with_suffix(path.suffix + ".new")
    with temporary.open("w") as output:
        output.write(json.dumps(value, indent=2) + "\n")
        if durable:
            output.flush()
            os.fsync(output.fileno())
    temporary.replace(path)
    if durable:
        descriptor = os.open(path.parent, os.O_DIRECTORY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)


def journal(context, table, value):
    with (context["output"] / f"{table}.jsonl").open("a") as target:
        target.write(json.dumps(value, separators=(",", ":")) + "\n")


def sql(context, statement):
    with defer_interruptions():
        try:
            return shared.sql(context, statement)
        finally:
            save(context["output"] / "commands.json", context["commands"])


def row(context, statement):
    raw = sql(context, statement)
    require(bool(raw), "Expected one lifecycle observation")
    return json.loads(raw)


def cluster_guard(context):
    guard = shared.fixture_guard(context)
    cid = context["fixture"]["container"]
    cgroup = Path(f"/proc/{guard['pid']}/cgroup").read_text()
    expected = context["identity"]
    require(cgroup == expected["cgroup"] and any(line.endswith("/docker-" + cid + ".scope") or line.endswith("/" + cid)
            for line in cgroup.splitlines() if line.startswith("0::")), "Lifecycle PostgreSQL cgroup identity changed")
    require(guard["labels"] == expected["labels"] and str(context["fixture"]["pg_socket_port"]) == context["private"]["PGPORT"],
            "Lifecycle fixture labels or ports differ")
    journal(context, "guards", guard | {"cgroup": cgroup})
    save(context["output"] / "commands.json", context["commands"])
    return guard


def clients(context, owned):
    deadline = time.monotonic() + 8
    while time.monotonic() < deadline:
        inventory = row(context, CLIENTS_SQL)
        require(inventory["other"] == inventory["tls"] == 0 and inventory["tcp"] == inventory["owned_tcp"] == owned,
                "Unexpected concurrent lifecycle SQL session")
        if inventory["active_tcp"] == 0:
            return inventory
        time.sleep(.05)
    raise RuntimeError("Lifecycle SQL did not settle")


def world(context, relation):
    require(relation in ("world", "uwz_ul_values"), "Unexpected lifecycle relation")
    result = row(context, f"SELECT json_agg(json_build_object('id',id,'randomNumber',randomnumber) ORDER BY id) FROM public.{relation};")
    require(len(result) == 10000 and [item["id"] for item in result] == list(range(1, 10001))
            and all(type(item["randomNumber"]) is int and 1 <= item["randomNumber"] <= 10000 for item in result),
            "Invalid complete lifecycle World export")
    return result


def scalar_world(values):
    return {item["id"]: item["randomNumber"] for item in values}


def world_digest(values):
    return hashlib.sha256(json.dumps(values, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def query_world_schema(context):
    schema = row(context, WORLD_SCHEMA_SQL)
    require(schema["oid"] > 0 and schema["kind"] == "r" and schema["owner"] == "uwz_world_test"
            and schema["columns"] == [["id", 23, True], ["randomnumber", 23, True]]
            and any(entry[1] == "f" and entry[3] == schema["oid"] for entry in schema["constraints"]),
            "Expected the owned original World table and inbound FK")
    return schema


def plain_inventory(schema):
    return {"relations": [["world", schema["oid"], "r", "uwz_world_test"]], "functions": None, "view": None}


def observer_plans(context):
    plans = {}
    for label, statement, types, arguments in (
        ("select", SELECT, "integer", "1"),
        ("update", UPDATE, "integer,integer", "7921,1"),
    ):
        plans[label] = row(context, f"PREPARE uwz_ul_probe({types}) AS {statement};\n"
                           f"EXPLAIN (FORMAT JSON) EXECUTE uwz_ul_probe({arguments});\nDEALLOCATE uwz_ul_probe;")
    require(row(context, SNAPSHOT_SQL) == {"select_started": 0, "update_started": 0, "events_started": 0, "committed": []},
            "Plan observation unexpectedly executed lifecycle operations")
    save(context["output"] / "observer_plans.json", plans)


def probe_inventory(context, original, nonce):
    installed = row(context, INVENTORY_SQL)
    catalog = {entry[0]: entry[1:] for entry in installed["relations"]}
    require(catalog["uwz_ul_values"] == [original["oid"], "r", "uwz_world_test"]
            and catalog["world"][1:] == ["v", "uwz_world_test"]
            and set(catalog) == {"world", "uwz_ul_values", "uwz_ul_log", "uwz_ul_log_pkey", "uwz_ul_control",
                                 "uwz_ul_control_pkey", "uwz_ul_select_seq", "uwz_ul_update_seq", "uwz_ul_event_seq"}
            and all(entry[3] == "uwz_world_test" for entry in installed["relations"])
            and {entry[0] for entry in installed["functions"]} == {"uwz_ul_visible", "uwz_ul_update"}
            and all(entry[2] == "uwz_world_test" for entry in installed["functions"]), "Lifecycle view/base ownership differs")
    require(row(context, "SELECT to_json(owner_nonce) FROM public.uwz_ul_control WHERE singleton;") == nonce, "Lifecycle nonce was not installed")
    return installed


def restore(context, original, original_world, installed, nonce):
    cluster_guard(context)
    clients(context, 0)
    require(probe_inventory(context, original, nonce) == installed, "Owned temporary lifecycle objects changed")
    oid = int(next(entry[1] for entry in installed["relations"] if entry[0] == "world"))
    seed = json.dumps([{"id": item["id"], "number": item["randomNumber"]} for item in original_world], separators=(",", ":"))
    quoted_seed = "$rows$" + seed + "$rows$"
    require(re.fullmatch(r"[0-9a-f]{32}", nonce), "Invalid lifecycle restore nonce")
    sql(context, f"""
BEGIN;
DO $guard$
BEGIN
    IF current_user <> 'uwz_world_test' OR current_database() <> 'uwz_world_test' OR inet_client_addr() IS NOT NULL
       OR EXISTS(SELECT 1 FROM pg_stat_activity WHERE backend_type='client backend' AND pid<>pg_backend_pid())
       OR to_regclass('public.uwz_ul_values')::oid IS DISTINCT FROM {int(original['oid'])}::oid
       OR to_regclass('public.world')::oid IS DISTINCT FROM {oid}::oid
       OR (SELECT owner_nonce FROM public.uwz_ul_control WHERE singleton) IS DISTINCT FROM '{nonce}' THEN
       RAISE EXCEPTION 'wrong lifecycle restoration ownership';
    END IF;
END;
$guard$;
LOCK TABLE public.uwz_ul_values IN ACCESS EXCLUSIVE MODE;
DROP VIEW public.world;
DROP FUNCTION public.uwz_ul_update();
DROP FUNCTION public.uwz_ul_visible(text,integer,integer);
DROP TABLE public.uwz_ul_log;
DROP TABLE public.uwz_ul_control;
DROP SEQUENCE public.uwz_ul_event_seq;
DROP SEQUENCE public.uwz_ul_update_seq;
DROP SEQUENCE public.uwz_ul_select_seq;
ALTER TABLE public.uwz_ul_values RENAME TO world;
UPDATE public.world t SET randomnumber=s.number
FROM jsonb_to_recordset({quoted_seed}::jsonb) AS s(id integer,number integer)
WHERE t.id=s.id AND t.randomnumber<>s.number;
COMMIT;
""")
    actual_schema, actual_world = query_world_schema(context), world(context, "world")
    require(actual_schema == original and actual_world == original_world, "Original World schema, FK or contents were not restored")
    require(row(context, INVENTORY_SQL) == plain_inventory(original), "Lifecycle observer objects remain")
    return {"schema": actual_schema, "world_sha256": world_digest(actual_world), "clients": clients(context, 0)}


def http(context, app, label, path):
    started = time.monotonic_ns()
    record = {"label": label, "path": path, "started_ns": started}
    connection = http.client.HTTPConnection("127.0.0.1", app["port"], timeout=14)
    try:
        connection.request("GET", path, headers={"Connection": "close"})
        result = connection.getresponse()
        record.update({"status": result.status, "version": result.version, "headers": result.getheaders()})
        payload = result.read()
        record["body_hex"] = payload.hex()
        record["body"] = payload.decode("utf-8")
    except (UnicodeError, http.client.HTTPException, OSError) as error:
        record["error"] = str(error)
        if isinstance(error, http.client.IncompleteRead):
            record["partial_hex"] = error.partial.hex()
    finally:
        connection.close()
        record["finished_ns"] = time.monotonic_ns()
        record["elapsed_seconds"] = (record["finished_ns"] - started) / 1e9
        journal(context, "responses", record)
    return record


def validate_response(record, expected):
    require("error" not in record and record["status"] == expected and record["version"] == 11,
            "Unexpected lifecycle HTTP response or transport error")
    headers = {name.lower(): value for name, value in record["headers"]}
    body = record["body"].encode()
    require(len(headers) == len(record["headers"]) and headers.get("content-type") == "application/json"
            and headers.get("content-length") == str(len(body)) and body.hex() == record["body_hex"], "Bad lifecycle HTTP response framing")
    if expected == 503:
        require(json.loads(record["body"], object_pairs_hook=unique_fields) == {"error": "SQL operation failed"},
                "Wrong SQL failure body")


def reset(context, fail, missing, delay):
    clients(context, 8)
    fail_sql = str(fail) if fail is not None else "NULL"
    missing_sql = str(missing) if missing is not None else "NULL"
    sql(context, f"""
BEGIN;
UPDATE public.uwz_ul_control SET fail_at={fail_sql},missing_at={missing_sql},sleep_seconds={delay};
TRUNCATE public.uwz_ul_log;
ALTER SEQUENCE public.uwz_ul_select_seq RESTART WITH 1;
ALTER SEQUENCE public.uwz_ul_update_seq RESTART WITH 1;
ALTER SEQUENCE public.uwz_ul_event_seq RESTART WITH 1;
COMMIT;
""")
    state = row(context, SNAPSHOT_SQL)
    require(state == {"select_started": 0, "update_started": 0, "events_started": 0, "committed": []}, "Lifecycle controls were not reset")
    return state


def request_groups(snapshot, pairs):
    logs = snapshot["committed"]
    require(snapshot["events_started"] == snapshot["select_started"] + snapshot["update_started"],
            "Started event sequence differs from independent SELECT/UPDATE sequences")
    require([entry["event"] for entry in logs] == list(range(1, len(logs) + 1)), "Committed lifecycle log has an event hole")
    for op, text in (("select", SELECT), ("update", UPDATE)):
        entries = [entry for entry in logs if entry["operation"] == op]
        require([entry["ordinal"] for entry in entries] == list(range(1, len(entries) + 1))
                and all(item["query_text"] == text for item in entries), "Wrong lifecycle statement or ordinal in committed log")
    groups = [list(entries) for _, entries in groupby(logs, key=lambda entry: entry["transaction_id"])]
    require(len({group[0]["transaction_id"] for group in groups}) == len(groups), "Transaction IDs reappear in noncontiguous groups")
    if pairs:
        for group in groups:
            require(len(group) % 2 == 0, "Committed batch lacks a SELECT/UPDATE pair")
            for selected, updated in zip(group[::2], group[1::2]):
                require((selected["operation"], updated["operation"]) == ("select", "update")
                        and selected["id"] == updated["id"] and selected["number"] == updated["old_number"] and updated["returned"],
                        "Wrong SQL pair order, old value, or returned update")
            require([entry["id"] for entry in group[1::2]] == sorted(entry["id"] for entry in group[1::2]), "Row-lock order differs")
    return groups


def check_response_rows(rows, groups):
    offset = 0
    for group in groups:
        writes = group[1::2]
        expected = [(item["id"], item["number"]) for item in writes]
        actual = [(item["id"], item["randomNumber"]) for item in rows[offset:offset + len(writes)]]
        require(Counter(expected) == Counter(actual)
                and all([number for ident, number in actual if ident == key] == [number for ident, number in expected if ident == key]
                        for key in {ident for ident, _ in expected}), "HTTP response does not match committed chunk writes and duplicate order")
        offset += len(writes)
    require(offset == len(rows), "HTTP chunk coverage differs")


def validate_case(response, snapshot, before, after, count, route, fail, missing, delay):
    validate_response(response, 503 if fail or missing or delay else 200)
    groups = request_groups(snapshot, route == "updates")
    writes = [entry for entry in snapshot["committed"] if entry["operation"] == "update"]
    selections = [entry for entry in snapshot["committed"] if entry["operation"] == "select"]
    overlay = {entry["id"]: entry["number"] for entry in writes}
    lengths = [len(group) for group in groups]
    require(scalar_world(after) == scalar_world(before) | overlay, "Committed SQL write history disagrees with the full World")
    if fail or missing or delay:
        committed = 8 if fail else 16
        require(len(writes) == len(selections) == committed and lengths == [16] * (committed // 8),
                "Unexpected commit boundary after lifecycle error")
        if fail:
            require(snapshot["select_started"] == snapshot["update_started"] == fail, "Incorrect started work at injected UPDATE error")
        elif missing:
            require(snapshot["select_started"] == snapshot["update_started"] == 16
                    and [entry["ordinal"] for entry in selections if not entry["returned"]] == [missing],
                    "Missing SELECT did not stop after the committed second chunk")
        else:
            require(9 <= response["elapsed_seconds"] <= 12 and 16 < snapshot["select_started"] <= count
                    and 16 <= snapshot["update_started"] <= snapshot["select_started"], "Original request deadline or active-chunk rollback differs")
    else:
        values = shared.worlds(response, count, single=route == "db")
        if route == "updates":
            require(snapshot["select_started"] == snapshot["update_started"] == len(writes) == count
                    and lengths == [2 * min(8, count - start) for start in range(0, count, 8)]
                    and all(entry["returned"] for entry in selections), "Wrong successful SQL update chunk boundaries")
            check_response_rows(values, groups)
            require(scalar_world(after) == scalar_world(before) | scalar_world(values), "Last returned duplicate value differs from persisted data")
        else:
            require(snapshot["select_started"] == len(selections) == count and snapshot["update_started"] == 0
                    and lengths == [min(16, count - start) for start in range(0, count, 16)]
                    and [(entry["id"], entry["number"]) for entry in selections] == [(item["id"], item["randomNumber"]) for item in values],
                    "Recovery read route issued different SQL or returned different data")
    return {"transaction_operation_counts": lengths, "committed_selects": len(selections),
            "committed_updates": len(writes), "duplicate_updates": len(writes) - len(overlay)}


def run_case(context, app, label, count, *, fail=None, missing=None, delay=0, route="updates"):
    reset_state = reset(context, fail, missing, delay)
    before = world(context, "uwz_ul_values")
    path = "/db" if route == "db" else f"/{route}?count={count}"
    journal(context, "cases", {"label": label, "event": "started", "path": path, "before_sha256": world_digest(before),
                               "reset": reset_state, "fail": fail, "missing": missing, "delay": delay})
    response = http(context, app, label, path)
    clients(context, 8)
    after = row(context, SNAPSHOT_SQL)
    rows_after = world(context, "uwz_ul_values")
    journal(context, "cases", {"label": label, "event": "observed", "snapshot": after, "after_sha256": world_digest(rows_after)})
    result = validate_case(response, after, before, rows_after, count, route, fail, missing, delay)
    journal(context, "cases", {"label": label, "event": "validated", **result})


def interrupted(signum, _frame):
    raise KeyboardInterrupt(signal.Signals(signum).name)


@contextmanager
def defer_interruptions():
    pending = []

    def defer_interrupt(signum, _frame):
        pending.append(signum)

    old = {item: signal.signal(item, defer_interrupt) for item in (signal.SIGTERM, signal.SIGINT)
           if signal.getsignal(item) != signal.SIG_IGN}
    try:
        yield
    finally:
        for item, handler in old.items():
            signal.signal(item, handler)
        if pending:
            interrupted(pending[0], None)


def start_owned_app(context):
    # Keep the child tracked if a signal arrives during the bounded readiness path.
    with defer_interruptions():
        return shared.start_app(context, "updates_lifecycle")


def main():
    require(__debug__, "Lifecycle launch requires assertion checks")
    parser = argparse.ArgumentParser(description="Owned PostgreSQL World updates HTTP lifecycle")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    require(output.parent == DIRECTORY and output.name.startswith("attempt_"), "Use a distinct lifecycle attempt directory")
    variant = sealed_variants()[CANDIDATE]
    binary = Path(variant["binary"])
    require(PRIVATE.is_file() and not PRIVATE.is_symlink() and stat.S_IMODE(PRIVATE.stat().st_mode) == 0o600
            and PRIVATE.stat().st_uid == os.getuid(), "Lifecycle environment must be owned and private")
    private = shared.load_private(PRIVATE)
    require(set(private) == {"PGHOST", "PGPORT", "PGUSER", "PGDATABASE", "PGPASSWORD", "UWZ_SQL_ALLOW_PLAINTEXT"}
            and re.fullmatch(r"[0-9a-f]{48}", private["PGPASSWORD"]), "Unexpected lifecycle app environment")
    output.mkdir()
    context = {"fixture": read(FIXTURE), "identity": read(IDENTITY), "private": private, "output": output,
               "expected_sessions": 8, "app_options": {"UWZ_SQL_WORKERS": "1", "UWZ_SQL_AFFINITY": "0"},
               "binary": binary, "commands": [], "apps": [], "stops": []}
    report = {"schema": "uwz_updates_http_lifecycle_v1", "status": "failed", "variant": variant,
              "producer_sha256": digest(Path(__file__)), "probe_sql_sha256": digest(DIRECTORY / "probe.sql"),
              "scope": "Sequential lifecycle on uwz_world_test. Distinct-ID PRNG generation order comes from separate controlled tests.",
              "http1_reset_scope": "Immediate HTTP/1 reset observation is not established here; caller-owned token cancellation is separately verified."}
    installed = None
    setup_attempted = False
    nonce = secrets.token_hex(16)
    signals = (signal.SIGINT, signal.SIGTERM)
    previous_signals = {item: signal.signal(item, interrupted) for item in signals}
    try:
        report["guard_before"] = cluster_guard(context)
        report["clients_before"] = clients(context, 0)
        original = query_world_schema(context)
        original_world = world(context, "world")
        require(row(context, INVENTORY_SQL) == plain_inventory(original),
                "Lifecycle fixture handoff must restore the original World table before installing this observer")
        report["original_schema"] = original
        report["original_world_sha256"] = world_digest(original_world)
        save(output / "world_before.json", original_world, durable=True)
        save(output / "prepared.json", {"guard": report["guard_before"], "original_schema": original,
             "retained_world": "world_before.json", "world_sha256": report["original_world_sha256"],
             "owner_nonce": nonce, "probe_sql_sha256": report["probe_sql_sha256"]}, durable=True)
        setup_attempted = True
        script = (DIRECTORY / "probe.sql").read_text()
        sql(context, script.replace("__OWNER__", nonce).replace("__WORLD_OID__", str(original["oid"])))
        installed = probe_inventory(context, original, nonce)
        report["temporary_objects"] = installed
        after_seed = world(context, "uwz_ul_values")
        require(all(item["randomNumber"] == 1 + (item["id"] * 7919) % 10000 for item in after_seed), "Canonical lifecycle data differed")
        journal(context, "guards", {"canonical_seed_sha256": world_digest(after_seed), "rows": len(after_seed), "base_oid": original["oid"]})
        observer_plans(context)
        require(digest(binary) == variant["binary_sha256"], "Updates lifecycle binary drifted before start")
        app = start_owned_app(context)
        require(Path(app["identity"]["executable"]) == binary, "Unexpected executable for the owned lifecycle child")
        journal(context, "apps", {"identity": app["identity"], "listener": app["listener"], "port": app["port"], "options": context["app_options"]})
        for count in COUNTS:
            run_case(context, app, f"healthy_{count}", count)
        run_case(context, app, "second_chunk_update_error", 20, fail=10)
        run_case(context, app, "second_chunk_missing_select", 20, missing=10)
        run_case(context, app, "original_update_deadline", 20, delay=.55)
        run_case(context, app, "recovery_db", 1, route="db")
        run_case(context, app, "recovery_queries", 20, route="queries")
        run_case(context, app, "recovery_updates", 20)
        report["status"] = "passed"
    except BaseException as error:
        report["error"] = repr(error)
        raise
    finally:
        for item in signals:
            signal.signal(item, signal.SIG_IGN)
        cleanup_errors = []
        for app in context["apps"]:
            try:
                if not app.get("stopped"):
                    shared.stop_app(context, app)
            except BaseException as error:
                cleanup_errors.append(repr(error))
        if setup_attempted:
            try:
                if installed is None:
                    cluster_guard(context)
                    clients(context, 0)
                    if row(context, INVENTORY_SQL) != plain_inventory(original):
                        installed = probe_inventory(context, original, nonce)
                    else:
                        require(query_world_schema(context) == original and world(context, "world") == original_world,
                                "Unsuccessful observer setup changed the original fixture")
                        report["setup_left_original_fixture"] = True
                if installed is not None:
                    report["restore"] = restore(context, original, original_world, installed, nonce)
            except BaseException as error:
                cleanup_errors.append(repr(error))
        report["stops"] = context["stops"]
        report["cleanup_errors"] = cleanup_errors
        save(output / "commands.json", context["commands"])
        if cleanup_errors:
            report["status"] = "failed"
        save(output / "result.json", report)
        for item, handler in previous_signals.items():
            signal.signal(item, handler)
        if cleanup_errors and "error" not in report:
            raise RuntimeError("Lifecycle cleanup failed; see preserved evidence")
    print(json.dumps({"status": report["status"], "app_exit": [entry["exit_code"] for entry in report["stops"]],
                      "restored_world_sha256": report["restore"]["world_sha256"]}))


if __name__ == "__main__":
    main()
