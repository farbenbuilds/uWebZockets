BEGIN;
DO $guard$
BEGIN
    IF current_user <> 'uwz_world_test' OR current_database() <> 'uwz_world_test'
       OR inet_client_addr() IS NOT NULL
       OR EXISTS(SELECT 1 FROM pg_stat_activity WHERE backend_type='client backend' AND pid<>pg_backend_pid()) THEN
        RAISE EXCEPTION 'wrong or active lifecycle fixture';
    END IF;
    IF NOT EXISTS(SELECT 1 FROM pg_class WHERE oid='public.world'::regclass
           AND oid=__WORLD_OID__ AND relkind='r' AND pg_get_userbyid(relowner)=current_user) THEN
        RAISE EXCEPTION 'wrong base World relation';
    END IF;
END;
$guard$;
LOCK TABLE public.world IN ACCESS EXCLUSIVE MODE;
UPDATE public.world SET randomnumber=1 + ((id * 7919) % 10000)
WHERE randomnumber<>1 + ((id * 7919) % 10000);
ALTER TABLE public.world RENAME TO uwz_ul_values;
CREATE SEQUENCE public.uwz_ul_select_seq CACHE 1;
CREATE SEQUENCE public.uwz_ul_update_seq CACHE 1;
CREATE SEQUENCE public.uwz_ul_event_seq CACHE 1;
CREATE TABLE public.uwz_ul_control (
    singleton boolean PRIMARY KEY CHECK (singleton),
    owner_nonce text NOT NULL CHECK (length(owner_nonce) = 32),
    fail_at bigint,
    missing_at bigint,
    sleep_seconds double precision NOT NULL
);
INSERT INTO public.uwz_ul_control VALUES (true, '__OWNER__', NULL, NULL, 0);
CREATE TABLE public.uwz_ul_log (
    event bigint PRIMARY KEY,
    operation text NOT NULL CHECK (operation IN ('select','update')),
    ordinal bigint NOT NULL,
    id integer NOT NULL,
    number integer NOT NULL,
    old_number integer NOT NULL,
    returned boolean NOT NULL,
    transaction_id bigint NOT NULL,
    query_text text NOT NULL
);
CREATE FUNCTION public.uwz_ul_visible(statement_text text, row_id integer, row_number integer)
RETURNS boolean LANGUAGE plpgsql VOLATILE AS $$
DECLARE
    ordinal bigint;
    event bigint;
    control public.uwz_ul_control%ROWTYPE;
    visible boolean;
BEGIN
    IF statement_text='UPDATE World SET randomnumber=$1 WHERE id=$2 RETURNING id,randomnumber' THEN
        RETURN true;
    END IF;
    IF statement_text IS DISTINCT FROM 'SELECT id, randomnumber FROM World WHERE id=$1' THEN
        RAISE EXCEPTION 'unexpected statement in lifecycle SELECT observer';
    END IF;
    event := nextval('public.uwz_ul_event_seq');
    ordinal := nextval('public.uwz_ul_select_seq');
    SELECT * INTO STRICT control FROM public.uwz_ul_control WHERE singleton;
    IF control.sleep_seconds > 0 THEN
        PERFORM pg_sleep(control.sleep_seconds);
    END IF;
    visible := control.missing_at IS NULL OR ordinal <> control.missing_at;
    INSERT INTO public.uwz_ul_log VALUES
      (event,'select',ordinal,row_id,row_number,row_number,visible,txid_current(),statement_text);
    RETURN visible;
END;
$$;
CREATE VIEW public.world AS SELECT id, randomnumber FROM public.uwz_ul_values
WHERE public.uwz_ul_visible(current_query(), id, randomnumber);
CREATE FUNCTION public.uwz_ul_update()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
    ordinal bigint;
    event bigint;
    control public.uwz_ul_control%ROWTYPE;
    actual public.uwz_ul_values%ROWTYPE;
BEGIN
    IF current_query() IS DISTINCT FROM 'UPDATE World SET randomnumber=$1 WHERE id=$2 RETURNING id,randomnumber'
       OR NEW.id IS DISTINCT FROM OLD.id THEN
        RAISE EXCEPTION 'unexpected statement or ID in lifecycle UPDATE observer';
    END IF;
    event := nextval('public.uwz_ul_event_seq');
    ordinal := nextval('public.uwz_ul_update_seq');
    SELECT * INTO STRICT control FROM public.uwz_ul_control WHERE singleton;
    IF ordinal = control.fail_at THEN
        RAISE EXCEPTION 'controlled lifecycle UPDATE failure';
    END IF;
    UPDATE public.uwz_ul_values SET randomnumber=NEW.randomnumber WHERE id=OLD.id
        RETURNING id,randomnumber INTO STRICT actual;
    INSERT INTO public.uwz_ul_log VALUES
      (event,'update',ordinal,actual.id,actual.randomnumber,OLD.randomnumber,true,txid_current(),current_query());
    NEW.id := actual.id;
    NEW.randomnumber := actual.randomnumber;
    RETURN NEW;
END;
$$;
CREATE TRIGGER uwz_ul_update INSTEAD OF UPDATE ON public.world
FOR EACH ROW EXECUTE FUNCTION public.uwz_ul_update();
COMMIT;
