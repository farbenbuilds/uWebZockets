import json
import os
from pathlib import Path
import signal
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from updates_http_lifecycle import producer as probe


def case_state(committed, started_selects=None, started_updates=None, missing=None):
    before = [{"id": index, "randomNumber": index + 1} for index in range(1, committed + 1)]
    after = [{"id": index, "randomNumber": index + 2} for index in range(1, committed + 1)]
    log = []
    for index in range(1, committed + 1):
        for op, text, event, number in (("select", probe.SELECT, 2 * index - 1, index + 1), ("update", probe.UPDATE, 2 * index, index + 2)):
            log.append({"operation": op, "query_text": text, "event": event, "ordinal": index, "id": index, "number": number,
                        "old_number": index + 1, "returned": op == "update" or index != missing, "transaction_id": (index - 1) // 8})
    selects = committed if started_selects is None else started_selects
    updates = committed if started_updates is None else started_updates
    return {"select_started": selects, "update_started": updates, "events_started": selects + updates, "committed": log}, before, after


def response(value, status=200, seconds=.1):
    body = json.dumps(value)
    return {"status": status, "version": 11, "body": body, "body_hex": body.encode().hex(), "elapsed_seconds": seconds,
            "headers": [["Content-Type", "application/json"], ["Content-Length", str(len(body.encode()))]]}


class LifecycleProbeTests(unittest.TestCase):
    def test_signal_during_owned_child_start_is_deferred_until_tracked(self):
        tracked = []

        def spawn(context, name):
            os.kill(os.getpid(), signal.SIGTERM)
            context.append(name)
            return name

        with patch.object(probe.shared, "start_app", side_effect=spawn):
            with self.assertRaisesRegex(KeyboardInterrupt, "SIGTERM"):
                probe.start_owned_app(tracked)
        self.assertEqual(tracked, ["updates_lifecycle"])

    def test_prepared_proof_can_be_durably_recorded(self):
        with TemporaryDirectory(dir=probe.DIRECTORY) as directory:
            record = Path(directory) / "prepared.json"
            expected = {"owner_nonce": "a" * 32, "original_schema": {"oid": 16419}, "world_sha256": "b" * 64}
            probe.save(record, expected, durable=True)
            self.assertEqual(json.loads(record.read_text()), expected)
            self.assertFalse(record.with_suffix(".json.new").exists())

    def test_signal_during_sql_waits_for_controller_and_evidence(self):
        def execute(context, statement):
            os.kill(os.getpid(), signal.SIGTERM)
            context["commands"].append({"statement": statement, "terminal": True})
            return ""

        with TemporaryDirectory(dir=probe.DIRECTORY) as directory:
            context = {"commands": [], "output": Path(directory)}
            with patch.object(probe.shared, "sql", side_effect=execute):
                with self.assertRaisesRegex(KeyboardInterrupt, "SIGTERM"):
                    probe.sql(context, "controlled mutating SQL")
            self.assertEqual(json.loads((Path(directory) / "commands.json").read_text()),
                             [{"statement": "controlled mutating SQL", "terminal": True}])

    def test_success_matches_writes_in_each_contiguous_chunk(self):
        state, before, after = case_state(20)
        values = [*reversed(after[:8]), *reversed(after[8:16]), *after[16:]]
        result = probe.validate_case(response(values), state, before, after, 20, "updates", None, None, 0)
        self.assertEqual(result["transaction_operation_counts"], [16, 16, 8])
        with self.assertRaisesRegex(ValueError, "committed chunk"):
            probe.validate_case(response(list(reversed(values))), state, before, after, 20, "updates", None, None, 0)

    def test_duplicate_updates_must_keep_tie_order(self):
        raw = [[{}, {"id": 5, "number": 22}, {}, {"id": 5, "number": 23}]]
        expected = [{"id": 5, "randomNumber": 22}, {"id": 5, "randomNumber": 23}]
        probe.check_response_rows(expected, raw)
        with self.assertRaisesRegex(ValueError, "duplicate order"):
            probe.check_response_rows(expected[::-1], raw)

    def test_started_update_error_differs_from_committed_counts(self):
        state, before, after = case_state(8, 10, 10)
        result = probe.validate_case(response({"error": "SQL operation failed"}, 503), state, before, after, 20, "updates", 10, None, 0)
        self.assertEqual(result["committed_updates"], 8)
        with self.assertRaisesRegex(ValueError, "Wrong lifecycle statement"):
            bad = state["committed"][0] | {"query_text": probe.UPDATE}
            probe.request_groups(state | {"committed": [bad, *state["committed"][1:]]}, True)

    def test_missing_select_allows_its_successful_chunk_to_commit(self):
        state, before, after = case_state(16, missing=10)
        result = probe.validate_case(response({"error": "SQL operation failed"}, 503), state, before, after, 20, "updates", None, 10, 0)
        self.assertEqual(result["committed_updates"], 16)
        with self.assertRaisesRegex(ValueError, "committed second chunk"):
            later = state | {"select_started": 17, "update_started": 17, "events_started": 34}
            probe.validate_case(response({"error": "SQL operation failed"}, 503), later, before, after, 20, "updates", None, 10, 0)

    def test_deadline_stops_active_chunk_with_previous_chunks_persisted(self):
        state, before, after = case_state(16, 19, 18)
        error = {"error": "SQL operation failed"}
        result = probe.validate_case(response(error, 503, 10), state, before, after, 20, "updates", None, None, .55)
        self.assertEqual(result["committed_updates"], 16)
        with self.assertRaisesRegex(ValueError, "deadline"):
            probe.validate_case(response(error, 503, 14), state, before, after, 20, "updates", None, None, .55)


if __name__ == "__main__":
    unittest.main()
