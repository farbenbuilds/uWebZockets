from pathlib import Path
import re
import stat

from .contract import FIXED, POOL, WORKERS, require, sql_work
from .queries_pair_contract import ARMS, CANDIDATE, CONTROL, COUNT, PAIRS, WORK, digest, read, source_receipts


EDGES = (1, 7, 8, 9, 20, 500)
SOURCE_SEAL = WORK / "verification/updates_pair_candidate.json"
RUNTIME_CHANGES = ("examples/sql_postgres.zig",)
TEST_CHANGES = ("src/tests/sql_postgres_tests.zig",)
DOCUMENTATION = Path("docs/sql.md")
MAINTENANCE = ("vacuum_count", "analyze_count", "last_vacuum", "last_analyze",
               "postmaster", "world_oid", "world_pkey_oid", "stats_reset", "conf_loaded")
AUTO_MAINTENANCE = ("autovacuum_count", "autoanalyze_count")
CLIENTS = ("tcp_clients", "bench_tcp_clients", "ssl_clients", "active_tcp_clients", "foreign_clients")
MOVING_OBSERVATIONS = ("wal_lsn", "checkpointer")
WAL_SETTINGS_SQL = """
SELECT json_object_agg(name,json_build_object('setting',setting,'unit',unit,'source',source) ORDER BY name)
FROM pg_settings
WHERE name IN ('max_wal_size','min_wal_size','checkpoint_timeout','checkpoint_completion_target',
               'checkpoint_warning','wal_compression','full_page_writes','autovacuum_naptime','synchronous_commit','fsync');
"""
CUTOFF_IDLE_NS = 1_000_000_000
CUTOFF_DEADLINE_NS = 12_000_000_000
CUTOFF_SQL = """
SELECT json_build_object(
  'foreign_clients',(SELECT count(*) FROM pg_stat_activity
    WHERE backend_type='client backend' AND pid<>pg_backend_pid()
      AND NOT (client_addr IS NOT NULL AND datname=current_database() AND usename=current_user)),
  'sessions',COALESCE(json_agg(json_build_object('pid',pid,'backend_start',backend_start,
      'state_change',state_change,'state',state,'wait_kind',wait_event_type,'wait_event',wait_event,
      'in_transaction',xact_start IS NOT NULL,'has_xid',backend_xid IS NOT NULL,'has_xmin',backend_xmin IS NOT NULL)
    ORDER BY pid),'[]'::json))
FROM pg_stat_activity
WHERE backend_type='client backend' AND client_addr IS NOT NULL AND datname=current_database() AND usename=current_user;
"""


def plan():
    blocks = (("primary", COUNT), *((f"edge_{count}", count) for count in EDGES if count != COUNT))
    return ([("fixed", arm, f"fixed_{arm}_{label}", count) for arm in ARMS for label, count in blocks]
            + [("timed", arm, f"pair{number}_{arm}", COUNT) for number, arms in enumerate(PAIRS, 1) for arm in arms])


def same_identity(before, after):
    require(all(before[key] == after[key] for key in MAINTENANCE),
            "Postmaster, relation, settings or manual maintenance changed during a case")


def drained(row):
    return all(row[key] == 0 for key in CLIENTS) and row["maintenance_running"] is False


def account(before, after, count, completed, cutoff):
    require(drained(before) and drained(after), "Updates require fully drained statistics")
    same_identity(before, after)
    if cutoff == 0:
        require(completed == FIXED, "Wrong number of serial fixed updates")
    work = sql_work(before, after, "updates", count, completed, cutoff)
    require(work["deltas"]["xact_rollback"] == 0, "Benchmark updates rolled back")
    selects = work.pop("read_scans")
    work.pop("reads_per_complete_request")
    hot = after["n_tup_hot_upd"] - before["n_tup_hot_upd"]
    paged = after["n_tup_newpage_upd"] - before["n_tup_newpage_upd"]
    require(min(hot, paged) >= 0 and hot + paged <= work["updated_rows"], "Unexpected HOT or new-page UPDATE accounting")
    return work | {"select_scans": selects, "total_primary_key_scans": work["deltas"]["pkey_scans"],
                   "selects_per_complete_request": count, "primary_key_scans_per_complete_request": 2 * count,
                   "hot_updates": hot, "new_page_updates": paged}


def http_socket_script(port):
    # LISTEN and kernel TIME_WAIT do not represent a live HTTP connection.
    return (f'awk -v port={port:04X} \'$2 ~ (":" port "$") && $4 != "0A" && $4 != "06" '
            "{ print $4 }' /proc/1/net/tcp /proc/1/net/tcp6")


def idle_signature(pool, socket_states):
    entries = pool["sessions"]
    if socket_states or pool["foreign_clients"] != 0 or len(entries) != WORKERS * POOL:
        return None
    if len({session["pid"] for session in entries}) != len(entries):
        return None
    for session in entries:
        if (session["state"], session["wait_kind"], session["wait_event"]) != ("idle", "Client", "ClientRead"):
            return None
        if any(session[key] is not False for key in ("in_transaction", "has_xid", "has_xmin")):
            return None
    return tuple((session["pid"], session["backend_start"], session["state_change"]) for session in entries)


def position(lsn):
    require(re.fullmatch(r"[0-9A-F]{1,8}/[0-9A-F]{1,8}", lsn), "Invalid PostgreSQL WAL position")
    high, low = (int(part, 16) for part in lsn.split("/"))
    return (high << 32) + low


def phase_changes(observations):
    result = {}
    for (first, before), (last, after) in zip(observations, observations[1:]):
        same_identity(before, after)
        wal = position(after["wal_lsn"]) - position(before["wal_lsn"])
        deltas = {key: after[key] - before[key] for key in AUTO_MAINTENANCE}
        first_checkpoint, last_checkpoint = before["checkpointer"], after["checkpointer"]
        require(first_checkpoint["stats_reset"] == last_checkpoint["stats_reset"]
                and first_checkpoint.keys() == last_checkpoint.keys(), "Checkpointer statistics identity changed")
        checkpoints = {key: last_checkpoint[key] - value for key, value in first_checkpoint.items() if type(value) is int}
        require(wal >= 0 and min(deltas.values()) >= 0, "WAL position or automatic maintenance count decreased")
        require(checkpoints and min(checkpoints.values()) >= 0, "Checkpointer counter decreased")
        result[f"{first}_to_{last}"] = {"cluster_wal_insert_bytes": wal, **deltas,
                                       "cluster_checkpointer_deltas": checkpoints,
                                       "maintenance_active_before": before["maintenance_running"],
                                       "maintenance_active_after": after["maintenance_running"]}
    return result


def parse_storage(raw):
    lines = raw.splitlines()
    require(len(lines) == 2, "Expected the owned PostgreSQL data mount")
    filesystem, kind, total, used, available, _percent, destination = lines[1].split()
    require(kind == "tmpfs" and destination == "/var/lib/postgresql" and filesystem == "tmpfs",
            "Unexpected PostgreSQL storage topology")
    total_bytes, used_bytes, available_bytes = (int(value) * 1024 for value in (total, used, available))
    require(total_bytes > 0 and min(used_bytes, available_bytes) >= 0 and used_bytes + available_bytes <= total_bytes,
            "Invalid PostgreSQL storage capacity")
    return {"mount": destination, "type": kind, "total_bytes": total_bytes, "used_bytes": used_bytes,
            "available_bytes": available_bytes}


def closure(manifest, directory):
    files = {}
    for entry in manifest["files"]:
        name = entry["path"]
        path = directory / name
        require(name not in files and path.resolve().is_relative_to(directory) and not path.is_symlink()
                and digest(path) == entry["sha256"] and stat.S_IMODE(path.stat().st_mode) == entry["mode"],
                f"Sealed source file changed: {name}")
        files[name] = entry["sha256"], entry["mode"]
    return files


def check_build_closure(control, candidate):
    require(control.keys() == candidate.keys() and len(control) == 348 and str(DOCUMENTATION) not in control,
            "The updates build must use the same 348 compiled-source inputs without documentation")
    changes = {name for name in control if control[name] != candidate[name]}
    require(changes == set(RUNTIME_CHANGES + TEST_CHANGES),
            "Unexpected updates candidate production or test change")


def check_documentation(root, record):
    folder = root / "documentation"
    document = folder / DOCUMENTATION
    require(record["path"] == str(DOCUMENTATION) and not document.is_symlink()
            and document.resolve().is_relative_to(folder) and digest(document) == record["sha256"],
            "The updates documentation snapshot differs from its separate seal")
    return document


def sealed_variants():
    baseline = source_receipts()[CANDIDATE]
    control = read(Path(baseline["source"]))
    control_build = read(Path(baseline["build"]))
    seal = read(SOURCE_SEAL)
    root = WORK / "updates_candidate"
    manifest_path = root / "baseline_source_identity.json"
    build_path = root / "baseline_build/result.json"
    binary = root / "install/bin/sql_cluster_server"
    source, build = read(manifest_path), read(build_path)
    selected = build["binaries"]["sql_cluster_server"]
    require(build["exit_code"] == 0 and digest(build_path) == seal["build_sha256"]
            and source["commit"] == build["source_commit"] == seal["source_commit"]
            and digest(manifest_path) == seal["source_sha256"] == build["source_identity_sha256"]
            and build["cwd"] == str(root / "source") and selected["path"] == str(binary)
            and not binary.is_symlink() and digest(binary) == selected["sha256"] == seal["binary_sha256"]
            and selected["sha256"] != baseline["binary_sha256"]
            and binary.stat().st_size == selected["bytes"] and stat.S_IMODE(binary.stat().st_mode) == selected["mode"],
            "The updates candidate does not match the sealed source, build and binary")
    argv = build["argv"]
    prefix = argv.index("--prefix")
    control_argv = control_build["argv"]
    require(argv[:prefix] == control_argv[:control_argv.index("--prefix")]
            and argv[prefix + 1:] == [str(root / "install"), "--summary", "all"]
            and digest(Path(argv[0])) == build["zig_sha256"] == control_build["zig_sha256"],
            "The updates candidate compiler or runtime build flags differ")
    old = closure(control, Path(control_build["cwd"]))
    new = closure(source, root / "source")
    require(seal["runtime_changes"] == list(RUNTIME_CHANGES) and seal["test_changes"] == list(TEST_CHANGES),
            "The updates source seal permits unexpected production or test paths")
    check_build_closure(old, new)
    document = check_documentation(root, seal["documentation"])
    return {CONTROL: baseline, CANDIDATE: {"source": str(manifest_path), "source_sha256": seal["source_sha256"],
            "build": str(build_path), "build_sha256": seal["build_sha256"],
            "binary": str(binary), "binary_sha256": seal["binary_sha256"],
            "documentation": str(document), "documentation_sha256": seal["documentation"]["sha256"]}}


def check_inputs(before, prior):
    require(drained(before) and before["n_mod_since_analyze"] == 0 and before["world_bytes"] > 0 and before["pkey_bytes"] > 0,
            "Canonical case baseline is not drained and freshly analyzed")
    if prior is not None:
        for key in ("postmaster", "world_oid", "world_pkey_oid", "stats_reset", "conf_loaded"):
            require(before[key] == prior[key], "Postmaster, fixture relations or configuration changed between cases")


def fixed_overlay(rows):
    return {row["id"]: row["randomNumber"] for row in rows}
