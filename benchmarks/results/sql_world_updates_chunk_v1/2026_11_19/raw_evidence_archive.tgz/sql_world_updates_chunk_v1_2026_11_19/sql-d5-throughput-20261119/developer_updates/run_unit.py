import hashlib,json,os,pathlib,re,shlex,subprocess,sys,time
root=pathlib.Path.cwd()
work=root/".zig-cache/sql-d5-throughput-20261119/developer_updates"
prefix=work/sys.argv[1]
env={k:v for k,v in os.environ.items() if not k.startswith("UWZ_SQL_TEST_")}
for line in (root/".zig-cache/sql-d5-throughput-20261119/host_fixture/private/unit.env").read_text().splitlines():
    values=shlex.split(line)
    if not values: continue
    if values[0]=="export": values=values[1:]
    for entry in values:
        key,value=entry.split("=",1)
        if key in ("UWZ_SQL_TEST_PASSWORD","UWZ_SQL_TEST_PORT"): env[key]=value
argv=[str(root/".zig-cache/toolchains/zig-x86_64-linux-0.16.0/zig"),"build","test-unit","-Dsql=true","-Dsqlite=true"]
if len(sys.argv)>2: argv.append("-Dtest-filter="+sys.argv[2])
argv += ["--global-cache-dir",str(root/".zig-cache/tls-domain-leaf-fixed-20261118/sdk-global-cache"),"--cache-dir",str(root/".zig-cache/sql-d5-throughput-20261119/developer/unit-local-cache"),"--summary","all"]
meta={"argv":argv,"started_unix":time.time(),"sources":{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ("examples/sql_postgres.zig","src/tests/sql_postgres_tests.zig","docs/sql.md")}}
with prefix.with_suffix(".stdout").open("wb") as out,prefix.with_suffix(".stderr").open("wb") as err:
    child=subprocess.Popen(argv,env=env,stdout=out,stderr=err)
    meta["pid"]=child.pid
    prefix.with_suffix(".json").write_text(json.dumps(meta,indent=2)+"\n")
    meta["exit_code"]=child.wait()
meta["finished_unix"]=time.time()
raw=prefix.with_suffix(".stdout").read_text(errors="replace")+prefix.with_suffix(".stderr").read_text(errors="replace")
meta["test_counts"]=re.findall(r"(?:\d+/?)+(?: tests? passed| pass| skip| fail| crashed)",raw)
prefix.with_suffix(".json").write_text(json.dumps(meta,indent=2)+"\n")
print(raw[-10000:])
raise SystemExit(meta["exit_code"])
