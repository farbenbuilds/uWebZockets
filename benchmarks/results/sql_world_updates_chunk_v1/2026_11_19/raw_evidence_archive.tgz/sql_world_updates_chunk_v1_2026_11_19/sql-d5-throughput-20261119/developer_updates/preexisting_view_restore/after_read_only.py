import hashlib,importlib.util,json,pathlib
base=pathlib.Path('.zig-cache/sql-d5-throughput-20261119')
work=base/'developer_updates/preexisting_view_restore/after'
spec=importlib.util.spec_from_file_location('owned_queries',base/'developer/check_queries_lifecycle.py')
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
context={'fixture':json.loads((base/'host_fixture/fixture/fixture.json').read_text()),'identity':json.loads((base/'host_fixture/fixture/unit_runtime_identity.json').read_text()),'private':module.load_private(base/'host_fixture/private/world_integration.env'),'commands':[]}
report={'read_only':True}
try:
 report['guard']=module.fixture_guard(context)
 assert pathlib.Path('/proc',str(context['identity']['pid']),'cgroup').read_text()==context['identity']['cgroup']
 listener=json.loads((base/'host_fixture/fixture/listener.json').read_text())
 actual_listener=module.command(context,listener['listener_argv'])
 assert 'listener=0100007F:E971 inode='+listener['inode'] in actual_listener
 report['listener']={'inode':listener['inode'],'address':'127.0.0.1','port':59761,'cgroup_matches':True}
 objects=json.loads(module.sql(context,"SELECT coalesce(json_agg(json_build_object('oid',c.oid::bigint,'name',c.relname,'kind',c.relkind,'owner',pg_get_userbyid(c.relowner)) ORDER BY c.relname),'[]'::json) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relname IN ('world','world_values','query_control','query_call_log','query_calls');"))
 report['objects']=objects
 world=next(item for item in objects if item['name']=='world')
 table='world' if world['kind']=='r' else 'world_values'
 target=next(item for item in objects if item['name']==table)
 assert target['oid']==16419 and target['kind']=='r' and target['owner']=='uwz_world_test'
 report['schema']=json.loads(module.sql(context,"SELECT json_build_object('oid',c.oid::bigint,'owner',pg_get_userbyid(c.relowner),'kind',c.relkind,'columns',(SELECT json_agg(json_build_object('name',a.attname,'type',a.atttypid,'number',a.attnum,'nullable',NOT a.attnotnull,'identity',a.attidentity,'generated',a.attgenerated) ORDER BY a.attnum) FROM pg_attribute a WHERE a.attrelid=c.oid AND a.attnum>0 AND NOT a.attisdropped),'constraints',(SELECT coalesce(json_agg(json_build_object('oid',p.oid::bigint,'name',p.conname,'type',p.contype,'keys',p.conkey,'foreign_table',p.confrelid::bigint,'foreign_keys',p.confkey,'definition',pg_get_constraintdef(p.oid)) ORDER BY p.oid),'[]'::json) FROM pg_constraint p WHERE p.conrelid=c.oid OR p.confrelid=c.oid),'indexes',(SELECT json_agg(json_build_object('oid',i.indexrelid::bigint,'keys',i.indkey::text,'unique',i.indisunique,'primary',i.indisprimary,'valid',i.indisvalid) ORDER BY i.indexrelid) FROM pg_index i WHERE i.indrelid=c.oid)) FROM pg_class c WHERE c.oid=16419;"))
 rows=json.loads(module.sql(context,'SELECT json_agg(s ORDER BY id) FROM (SELECT id,randomnumber FROM public.'+table+') s;'))
 assert len(rows)==10000 and [row['id'] for row in rows]==list(range(1,10001))
 assert all(1<=row['randomnumber']<=10000 for row in rows)
 canonical=json.dumps(rows,sort_keys=True,separators=(',',':')).encode()
 (work/'world_handoff_rows.json').write_bytes(canonical+b'\n')
 report.update({'rows':10000,'rows_sha256':hashlib.sha256(canonical).hexdigest(),'original_world_table_restored':world['kind']=='r','base_oid':target['oid']})
 report['sessions']=json.loads(module.sql(context,"SELECT json_build_object('test_tcp',(SELECT count(*) FROM pg_stat_activity WHERE usename IN ('uwz_test','uwz_world_test') AND client_addr IS NOT NULL),'all_tcp',(SELECT count(*) FROM pg_stat_activity WHERE client_addr IS NOT NULL),'other_test_controllers',(SELECT count(*) FROM pg_stat_activity WHERE usename IN ('uwz_test','uwz_world_test') AND backend_type='client backend' AND pid<>pg_backend_pid()));"))
 assert report['sessions']=={'test_tcp':0,'all_tcp':0,'other_test_controllers':0}
 report['status']='read_only_complete'
finally:
 report['commands']=context['commands']
 (work/'world_handoff_readonly.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ('status','original_world_table_restored','base_oid','rows','rows_sha256','sessions')}))
