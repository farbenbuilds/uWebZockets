import hashlib,json,pathlib,subprocess,sys,time
base=pathlib.Path('.zig-cache/sql-d5-throughput-20261119')
work=base/'developer_updates/preexisting_view_restore'
expected='aeef8b16710435a222ee7aa1e651d0e8b55c29b3de441f2b337d34a0f5fbe587'
readonly=(base/'developer_updates/check_world_handoff.py').read_text()
report={'expected_base_oid':16419,'expected_rows_sha256':expected,'commands':[],'mutation_attempted':False}
def run(path,label):
 argv=[sys.executable,str(path)]
 started=time.time()
 result=subprocess.run(argv,capture_output=True,text=True)
 (work/(label+'.stdout')).write_text(result.stdout)
 (work/(label+'.stderr')).write_text(result.stderr)
 report['commands'].append({'argv':argv,'exit_code':result.returncode,'started_unix':started,'finished_unix':time.time(),'stdout_path':str(work/(label+'.stdout')),'stderr_path':str(work/(label+'.stderr'))})
 assert result.returncode==0, result.stderr
 return result
try:
 for stage in ('before','after'):
  directory=work/stage
  directory.mkdir(exist_ok=False)
  script=work/(stage+'_read_only.py')
  assert readonly.count("work=base/'developer_updates'")==1
  script.write_text(readonly.replace("work=base/'developer_updates'","work=base/'developer_updates/preexisting_view_restore/"+stage+"'"))
 run(work/'before_read_only.py','before_read_only')
 before=json.loads((work/'before/world_handoff_readonly.json').read_text())
 previous=json.loads((base/'developer_updates/world_handoff_readonly.json').read_text())
 assert before['schema']==previous['schema']
 assert before['objects']==previous['objects']
 assert not before['original_world_table_restored'] and before['base_oid']==16419
 assert before['rows_sha256']==expected and before['sessions']=={'test_tcp':0,'all_tcp':0,'other_test_controllers':0}
 assert next(x for x in before['objects'] if x['name']=='world')['oid']==17245
 report['before_matches_handoff']=True
 report['mutation_attempted']=True
 run(work/'restore_world_view.py','restore')
 restored=json.loads((work/'lifecycle_restore_result_02.json').read_text())
 assert restored['status']=='restored' and restored['base_relation_after']=={'oid':16419,'kind':'r','owner':'uwz_world_test'}
 assert restored['before_contents_sha256']==restored['after_contents_sha256']==expected
 run(work/'after_read_only.py','after_read_only')
 after=json.loads((work/'after/world_handoff_readonly.json').read_text())
 assert after['original_world_table_restored'] and after['base_oid']==16419 and after['rows_sha256']==expected
 assert after['objects']==[{'oid':16419,'name':'world','kind':'r','owner':'uwz_world_test'}]
 assert before['schema']['columns']==after['schema']['columns']
 assert before['schema']['indexes']==after['schema']['indexes']
 old_constraints=before['schema']['constraints']; new_constraints=after['schema']['constraints']
 assert len(old_constraints)==len(new_constraints)
 for old,new in zip(old_constraints,new_constraints):
  assert {k:v for k,v in old.items() if k!='definition'}=={k:v for k,v in new.items() if k!='definition'}
  assert old['definition'].replace('REFERENCES world_values(','REFERENCES world(')==new['definition']
 assert (work/'before/world_handoff_rows.json').read_bytes()==(work/'after/world_handoff_rows.json').read_bytes()
 assert after['sessions']=={'test_tcp':0,'all_tcp':0,'other_test_controllers':0}
 report.update({'status':'restored_verified','base_oid':16419,'rows':10000,'before_rows_sha256':before['rows_sha256'],'after_rows_sha256':after['rows_sha256'],'columns_preserved':True,'constraint_identities_preserved':True,'fk_definition_only_table_rename':True,'index_identities_preserved':True,'sessions':after['sessions'],'all_subprocesses_reaped':True})
except BaseException as error:
 report['status']='failed';report['error']=repr(error)
 raise
finally:
 (work/'restoration_receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('status','base_oid','rows','after_rows_sha256','sessions','all_subprocesses_reaped')}))
