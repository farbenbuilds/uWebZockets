const std = @import("std");
pub fn main() void {
    for (0..10000) |seed| {
        var random = std.Random.DefaultPrng.init(seed);
        var ids: [8]i32 = undefined;
        for (&ids) |*id| {
            id.* = random.random().intRangeAtMost(i32, 1, 10000);
            _ = random.random().intRangeAtMost(i32, 1, 10000);
        }
        for (ids, 0..) |id, index| {
            for (ids[0..index]) |prior| {
                if (id != prior) continue;
                std.debug.print("seed={d} ids={any}\n", .{seed, ids});
                return;
            }
        }
    }
}
