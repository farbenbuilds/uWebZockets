import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from runner.contract import CONNECTIONS, COUNTERS, POOL, WORKERS
from runner.queries_pair_contract import ARMS, CANDIDATE, MAINTENANCE as RESTORE_EPOCH, WORK, digest, read, source_receipts
from runner.updates_pair_contract import (AUTO_MAINTENANCE, CLIENTS, CUTOFF_SQL, EDGES, MAINTENANCE, account,
                                          check_build_closure, check_documentation, closure, fixed_overlay,
                                          http_socket_script, idle_signature, parse_storage, phase_changes, plan, position)
from verification import verify_updates_pair
from verification.verify_host import matching_world


def snapshot(**changes):
    return dict.fromkeys((*COUNTERS, *MAINTENANCE, *CLIENTS, *AUTO_MAINTENANCE,
                         "n_tup_hot_upd", "n_tup_newpage_upd"), 0) | {
                             "maintenance_running": False, "wal_lsn": "0/100",
                             "checkpointer": {"stats_reset": None, "num_timed": 0, "num_requested": 0},
                         } | changes


def work(reads, writes, **changes):
    return snapshot(idx_scan=reads + writes, pkey_scans=reads + writes, n_tup_upd=writes, **changes)


def warm_pool():
    return {"foreign_clients": 0, "sessions": [
        {"pid": index, "backend_start": "startup", "state_change": "last command", "state": "idle",
         "wait_kind": "Client", "wait_event": "ClientRead", "in_transaction": False, "has_xid": False, "has_xmin": False}
        for index in range(1, WORKERS * POOL + 1)
    ]}


class UpdatesPairTests(unittest.TestCase):
    def test_control_is_retained_queries_elf(self):
        control = source_receipts()[CANDIDATE]
        self.assertEqual(control["binary_sha256"], "384795c818740c3d8bc96cc490ef1c8910c91455d506bba452dac577660be1b7")
        self.assertEqual(control["source_sha256"], "ed80223d93ce26a5c0b1a0affc589ad60a849214a2c76401e67f7c36e09732b5")

    def test_compiled_closure_matches_real_control_without_docs(self):
        root = WORK / "queries_candidate"
        actual = closure(read(root / "baseline_source_identity.json"), root / "source")
        self.assertEqual(len(actual), 348)
        self.assertNotIn("docs/sql.md", actual)
        candidate = actual | {"examples/sql_postgres.zig": ("a" * 64, 0o644),
                              "src/tests/sql_postgres_tests.zig": ("b" * 64, 0o644)}
        check_build_closure(actual, candidate)
        with self.assertRaisesRegex(ValueError, "without documentation"):
            check_build_closure(actual, candidate | {"docs/sql.md": ("c" * 64, 0o644)})
        with self.assertRaisesRegex(ValueError, "Unexpected updates candidate"):
            check_build_closure(actual, candidate | {"builds/testing.zig": ("c" * 64, 0o644)})

    def test_documentation_has_its_own_path_and_digest(self):
        with TemporaryDirectory(dir=WORK / "verification") as temporary:
            root = Path(temporary)
            document = root / "documentation/docs/sql.md"
            document.parent.mkdir(parents=True)
            document.write_text("Updated benchmark documentation.\n")
            record = {"path": "docs/sql.md", "sha256": digest(document)}
            self.assertEqual(check_documentation(root, record), document)
            with self.assertRaisesRegex(ValueError, "separate seal"):
                check_documentation(root, record | {"path": "source/docs/sql.md"})
            document.write_text("Drifted documentation.\n")
            with self.assertRaisesRegex(ValueError, "separate seal"):
                check_documentation(root, record)

    def test_replay_reads_restore_boundary_with_fixture_settings_and_auth_proof(self):
        fixture = {"pg_socket_port": 59761, "container": "a" * 64}
        settings = {"postmaster": "start"}
        proof = {"after": {"loaded": "reload"}}
        state = dict.fromkeys(RESTORE_EPOCH, 0) | snapshot() | {
            "postmaster": "start", "conf_loaded": "reload", "world_bytes": 4000, "pkey_bytes": 2000,
            "plan_cache_mode": "auto", "policy_source": "default", "shared_preload_libraries": "",
            "fsync": "on", "synchronous_commit": "on",
        }
        with TemporaryDirectory(dir=WORK / "verification") as temporary:
            case = Path(temporary)
            folder = case / "restore"
            folder.mkdir()
            for index in range(2):
                label = f"pg_before_{index:02}"
                (folder / f"{label}.stdout").write_text(json.dumps(state))
                (folder / f"{label}.command.json").write_text(json.dumps({
                    "exit_code": 0, "argv": ["docker", "exec", "--user", "postgres", fixture["container"], "psql",
                        "-X", "-w", "-At", "-h", "/var/run/postgresql", "-p", str(fixture["pg_socket_port"]),
                        "-U", "bench", "-d", "benchmark", "-v", "ON_ERROR_STOP=1", "-c", verify_updates_pair.query.STATS_SQL],
                    "monotonic_before_spawn_ns": 20 + index, "monotonic_after_reap_ns": 22 + index,
                }))
            boundary = state, {"monotonic_before_spawn_ns": 10, "monotonic_after_reap_ns": 15}
            before = state, {"monotonic_before_spawn_ns": 50, "monotonic_after_reap_ns": 55}
            with patch.object(verify_updates_pair, "settled", side_effect=[boundary, before]), patch.object(
                verify_updates_pair.query, "verify_restore", return_value=(state, 46, {1: 7920}),
            ) as restore:
                result = verify_updates_pair.verify_start(case, fixture, settings, proof, None, 0)
            self.assertEqual(result, (state, before[1], state, 46, {1: 7920}))
            restore.assert_called_once_with(case, fixture, settings, proof)

    def test_each_fixed_count_has_exactly_one_fresh_app_per_arm(self):
        for arm in ARMS:
            self.assertEqual(sorted(count for phase, mode, _, count in plan() if (phase, mode) == ("fixed", arm)), list(EDGES))
        self.assertEqual(len({case for _, _, case, _ in plan()}), 18)
        self.assertEqual([arm for phase, arm, _, _ in plan() if phase == "timed"],
                         ["control", "candidate", "candidate", "control", "control", "candidate"])

    def test_fixed_drained_exact_reads_and_writes_with_hot_subset(self):
        result = account(snapshot(), work(400, 400, n_tup_hot_upd=310, n_tup_newpage_upd=80), 8, 50, 0)
        self.assertEqual((result["select_scans"], result["updated_rows"], result["total_primary_key_scans"], result["hot_updates"]),
                         (400, 400, 800, 310))
        self.assertEqual((result["selects_per_complete_request"], result["primary_key_scans_per_complete_request"]), (8, 16))
        for read, write in ((399, 400), (400, 399), (401, 400), (400, 401)):
            with self.subTest(read=read, write=write), self.assertRaises(ValueError):
                account(snapshot(), work(read, write), 8, 50, 0)

    def test_open_idle_pool_statistics_rejected_even_when_exact(self):
        with self.assertRaisesRegex(ValueError, "drained"):
            account(snapshot(), work(400, 400, tcp_clients=96, bench_tcp_clients=96), 8, 50, 0)

    def test_deadline_cutoff_bounds_apply_to_reads_and_writes(self):
        cutoff = 2 * CONNECTIONS
        max_work = (1000 + cutoff) * 20
        self.assertEqual(account(snapshot(), work(max_work, max_work), 20, 1000, cutoff)["cutoff_requests"], 384)
        with self.assertRaisesRegex(ValueError, "Point reads"):
            account(snapshot(), work(max_work + 1, max_work), 20, 1000, cutoff)
        with self.assertRaisesRegex(ValueError, "Updates outside"):
            account(snapshot(), work(max_work, max_work + 1), 20, 1000, cutoff)

    def test_timed_updates_require_zero_seq_inserts_deletes_and_rollbacks(self):
        for changes in ({"seq_scan": 1}, {"n_tup_ins": 1}, {"n_tup_del": 1}, {"xact_rollback": 1}, {"xact_rollback": 385}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                account(snapshot(), work(2000, 2000, **changes), 20, 100, 384)

    def test_cutoff_requires_idle_same_owned_pool_and_no_live_sockets(self):
        clean = warm_pool()
        sig = idle_signature(clean, [])
        self.assertEqual(len(sig), 96)
        self.assertIsNone(idle_signature(clean, ["08"]))
        self.assertIsNone(idle_signature(clean | {"foreign_clients": 1}, []))
        changed = warm_pool()
        changed["sessions"][0]["state_change"] = "a later successful command"
        self.assertNotEqual(idle_signature(changed, []), sig)
        changed["sessions"][0]["has_xid"] = True
        self.assertIsNone(idle_signature(changed, []))

    def test_cutoff_replays_live_socket_or_subsecond_as_failure(self):
        fixture = {"container": "a" * 64, "pg_socket_port": 59761, "http_port": 31631}
        container = "b" * 64
        pool = warm_pool()
        with TemporaryDirectory(dir=WORK / "verification") as temporary:
            case = Path(temporary)
            for index, start in enumerate((10, 1_000_000_100)):
                for kind, argv, payload, first, last in (
                    ("pool", ["docker", "exec", "--user", "postgres", fixture["container"], "psql", "-X", "-w", "-At",
                              "-h", "/var/run/postgresql", "-p", str(fixture["pg_socket_port"]), "-U", "bench", "-d",
                              "benchmark", "-v", "ON_ERROR_STOP=1", "-c", CUTOFF_SQL], json.dumps(pool), start, start + 1),
                    ("http", ["docker", "exec", container, "sh", "-ec", http_socket_script(fixture["http_port"])], "", start + 2, start + 3),
                ):
                    label = f"{kind}_cutoff_{index:02}"
                    (case / f"{label}.stdout").write_text(payload)
                    (case / f"{label}.command.json").write_text(json.dumps({
                        "argv": argv, "exit_code": 0, "monotonic_before_spawn_ns": first, "monotonic_after_reap_ns": last,
                    }))
            result = verify_updates_pair.verified_cutoff(case, fixture, container, 1, 5, 2_000_000_000)
            self.assertEqual(result, {"first_sample": 0, "last_sample": 1, "quiet_ns": 1_000_000_087})
            cmd = case / "pool_cutoff_01.command.json"
            entry = read(cmd)
            cmd.write_text(json.dumps(entry | {"monotonic_before_spawn_ns": 900_000_000}))
            with self.assertRaisesRegex(ValueError, "transaction-free cutoff"):
                verify_updates_pair.verified_cutoff(case, fixture, container, 1, 5, 2_000_000_000)
            cmd.write_text(json.dumps(entry))
            (case / "http_cutoff_01.stdout").write_text("08\n")
            with self.assertRaisesRegex(ValueError, "transaction-free cutoff"):
                verify_updates_pair.verified_cutoff(case, fixture, container, 1, 5, 2_000_000_000)

    def test_manual_maintenance_is_not_attributed_to_workload(self):
        with self.assertRaisesRegex(ValueError, "manual maintenance"):
            account(snapshot(), work(400, 400, vacuum_count=1), 8, 50, 0)

    def test_default_maintenance_and_row_history_are_retained(self):
        before = snapshot()
        active = snapshot(maintenance_running=True, wal_lsn="0/200")
        after = work(400, 400, autovacuum_count=1, autoanalyze_count=1, wal_lsn="0/300", n_live_tup=10000, n_dead_tup=2)
        self.assertEqual(account(before, after, 8, 50, 0)["updated_rows"], 400)
        phases = phase_changes([("before", before), ("after_load", active), ("drained", after)])
        self.assertTrue(phases["before_to_after_load"]["maintenance_active_after"])
        self.assertEqual(phases["after_load_to_drained"]["autovacuum_count"], 1)
        self.assertEqual(phases["after_load_to_drained"]["cluster_wal_insert_bytes"], 256)

    def test_observed_storage_and_checkpoint_changes_are_separate_metadata(self):
        raw = "Filesystem Type 1024-blocks Used Available Capacity Mounted on\ntmpfs tmpfs 1024 16 1008 2% /var/lib/postgresql\n"
        self.assertEqual(parse_storage(raw)["available_bytes"], 1008 * 1024)
        with self.assertRaisesRegex(ValueError, "storage topology"):
            parse_storage(raw.replace("tmpfs", "overlay"))
        first = snapshot()
        last = snapshot(checkpointer={"stats_reset": None, "num_timed": 2, "num_requested": 1})
        phase = phase_changes([("early", first), ("late", last)])["early_to_late"]
        self.assertEqual(phase["cluster_checkpointer_deltas"], {"num_timed": 2, "num_requested": 1})
        with self.assertRaisesRegex(ValueError, "counter decreased"):
            phase_changes([("early", last), ("late", first)])
    def test_wal_segment_crossing_can_be_replayed(self):
        self.assertEqual(position("1/10") - position("0/FFFFFFF0"), 32)
        for lsn in ("0/FFFFFFFF1", "100000000/0", "-1/0"):
            with self.subTest(lsn=lsn), self.assertRaisesRegex(ValueError, "WAL"):
                position(lsn)
        with self.assertRaisesRegex(ValueError, "decreased"):
            phase_changes([("before", snapshot()), ("drained", snapshot(wal_lsn="0/FF"))])

    def test_persisted_duplicate_writes_use_last_returned_value(self):
        canonical = {1: 3, 2: 8, 3: 9}
        rows = [{"id": 2, "randomNumber": 14}, {"id": 1, "randomNumber": 10}, {"id": 2, "randomNumber": 20}]
        actual = {1: 10, 2: 20, 3: 9}
        self.assertEqual(fixed_overlay(rows), {2: 20, 1: 10})
        self.assertEqual(matching_world(canonical, rows, actual), 2)
        with self.assertRaisesRegex(ValueError, "Whole World differs"):
            matching_world(canonical, rows, actual | {2: 14})
        with self.assertRaisesRegex(ValueError, "Whole World differs"):
            matching_world(canonical, rows, actual | {3: 11})


if __name__ == "__main__":
    unittest.main()
