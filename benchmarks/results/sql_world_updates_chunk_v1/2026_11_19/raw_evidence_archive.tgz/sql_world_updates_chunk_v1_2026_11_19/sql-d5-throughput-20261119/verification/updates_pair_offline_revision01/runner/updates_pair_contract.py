from pathlib import Path
import re
import stat

from .contract import FIXED, require, sql_work
from .queries_pair_contract import ARMS, CANDIDATE, CONTROL, COUNT, PAIRS, WORK, digest, read, source_receipts


EDGES = (1, 7, 8, 9, 20, 500)
SOURCE_SEAL = WORK / "verification/updates_pair_candidate.json"
MAINTENANCE = ("vacuum_count", "analyze_count", "last_vacuum", "last_analyze",
               "postmaster", "world_oid", "world_pkey_oid", "stats_reset", "conf_loaded")
AUTO_MAINTENANCE = ("autovacuum_count", "autoanalyze_count")
CLIENTS = ("tcp_clients", "bench_tcp_clients", "ssl_clients", "active_tcp_clients", "foreign_clients")


def plan():
    blocks = (("primary", COUNT), *((f"edge_{count}", count) for count in EDGES if count != COUNT))
    return ([("fixed", arm, f"fixed_{arm}_{label}", count) for arm in ARMS for label, count in blocks]
            + [("timed", arm, f"pair{number}_{arm}", COUNT) for number, arms in enumerate(PAIRS, 1) for arm in arms])


def same_identity(before, after):
    require(all(before[key] == after[key] for key in MAINTENANCE),
            "Postmaster, relation, settings or manual maintenance changed during a case")


def drained(row):
    return all(row[key] == 0 for key in CLIENTS) and row["maintenance_running"] is False


def account(before, after, count, completed, cutoff):
    require(drained(before) and drained(after), "Updates require fully drained statistics")
    same_identity(before, after)
    if cutoff == 0:
        require(completed == FIXED, "Wrong number of serial fixed updates")
    work = sql_work(before, after, "updates", count, completed, cutoff)
    hot = after["n_tup_hot_upd"] - before["n_tup_hot_upd"]
    paged = after["n_tup_newpage_upd"] - before["n_tup_newpage_upd"]
    require(min(hot, paged) >= 0 and hot + paged <= work["updated_rows"], "Unexpected HOT or new-page UPDATE accounting")
    return work | {"hot_updates": hot, "new_page_updates": paged}


def position(lsn):
    require(re.fullmatch(r"[0-9A-F]{1,8}/[0-9A-F]{1,8}", lsn), "Invalid PostgreSQL WAL position")
    high, low = (int(part, 16) for part in lsn.split("/"))
    return (high << 32) + low


def phase_changes(observations):
    result = {}
    for (first, before), (last, after) in zip(observations, observations[1:]):
        same_identity(before, after)
        wal = position(after["wal_lsn"]) - position(before["wal_lsn"])
        deltas = {key: after[key] - before[key] for key in AUTO_MAINTENANCE}
        require(wal >= 0 and min(deltas.values()) >= 0, "WAL position or automatic maintenance count decreased")
        result[f"{first}_to_{last}"] = {"cluster_wal_insert_bytes": wal, **deltas,
                                       "maintenance_active_before": before["maintenance_running"],
                                       "maintenance_active_after": after["maintenance_running"]}
    return result


def closure(manifest, directory):
    files = {}
    for entry in manifest["files"]:
        name = entry["path"]
        path = directory / name
        require(name not in files and path.resolve().is_relative_to(directory) and not path.is_symlink()
                and digest(path) == entry["sha256"] and stat.S_IMODE(path.stat().st_mode) == entry["mode"],
                f"Sealed source file changed: {name}")
        files[name] = entry["sha256"], entry["mode"]
    return files


def sealed_variants():
    baseline = source_receipts()[CANDIDATE]
    control = read(Path(baseline["source"]))
    control_build = read(Path(baseline["build"]))
    seal = read(SOURCE_SEAL)
    root = WORK / "updates_candidate"
    manifest_path = root / "baseline_source_identity.json"
    build_path = root / "baseline_build/result.json"
    binary = root / "install/bin/sql_cluster_server"
    source, build = read(manifest_path), read(build_path)
    selected = build["binaries"]["sql_cluster_server"]
    require(build["exit_code"] == 0 and digest(build_path) == seal["build_sha256"]
            and source["commit"] == build["source_commit"] == seal["source_commit"]
            and digest(manifest_path) == seal["source_sha256"] == build["source_identity_sha256"]
            and build["cwd"] == str(root / "source") and selected["path"] == str(binary)
            and not binary.is_symlink() and digest(binary) == selected["sha256"] == seal["binary_sha256"]
            and selected["sha256"] != baseline["binary_sha256"]
            and binary.stat().st_size == selected["bytes"] and stat.S_IMODE(binary.stat().st_mode) == selected["mode"],
            "The updates candidate does not match the sealed source, build and binary")
    argv = build["argv"]
    prefix = argv.index("--prefix")
    require(argv[1:8] == control_build["argv"][1:8] and argv[prefix + 1:] == [str(root / "install"), "--summary", "all"]
            and digest(Path(argv[0])) == build["zig_sha256"] == control_build["zig_sha256"],
            "The updates candidate compiler or runtime build flags differ")
    old = closure(control, Path(control_build["cwd"]))
    new = closure(source, root / "source")
    changes = {name for name in old.keys() | new.keys() if old.get(name) != new.get(name)}
    require(seal["runtime_changes"] == ["examples/sql_postgres.zig"]
            and seal["test_changes"] == ["src/tests/sql_postgres_tests.zig"] and seal["doc_changes"] == ["docs/sql.md"]
            and old.keys() == new.keys() and len(new) == 348
            and changes == {"examples/sql_postgres.zig", "src/tests/sql_postgres_tests.zig", "docs/sql.md"},
            "Unexpected updates candidate production or test change")
    return {CONTROL: baseline, CANDIDATE: {"source": str(manifest_path), "source_sha256": seal["source_sha256"],
            "build": str(build_path), "build_sha256": seal["build_sha256"],
            "binary": str(binary), "binary_sha256": seal["binary_sha256"]}}


def check_inputs(before, prior):
    require(drained(before) and before["n_mod_since_analyze"] == 0 and before["world_bytes"] > 0 and before["pkey_bytes"] > 0,
            "Canonical case baseline is not drained and freshly analyzed")
    if prior is not None:
        for key in ("postmaster", "world_oid", "world_pkey_oid", "stats_reset", "conf_loaded"):
            require(before[key] == prior[key], "Postmaster, fixture relations or configuration changed between cases")


def fixed_overlay(rows):
    return {row["id"]: row["randomNumber"] for row in rows}
