import unittest

from runner.contract import CONNECTIONS, COUNTERS
from runner.queries_pair_contract import ARMS, CANDIDATE, source_receipts
from runner.updates_pair_contract import (AUTO_MAINTENANCE, CLIENTS, EDGES, MAINTENANCE, account, fixed_overlay,
                                          phase_changes, plan, position)
from verification.verify_host import matching_world


def snapshot(**changes):
    return dict.fromkeys((*COUNTERS, *MAINTENANCE, *CLIENTS, *AUTO_MAINTENANCE,
                         "n_tup_hot_upd", "n_tup_newpage_upd"), 0) | {
                             "maintenance_running": False, "wal_lsn": "0/100",
                         } | changes


def work(reads, writes, **changes):
    return snapshot(idx_scan=reads + writes, pkey_scans=reads + writes, n_tup_upd=writes, **changes)


class UpdatesPairTests(unittest.TestCase):
    def test_control_is_retained_queries_elf(self):
        control = source_receipts()[CANDIDATE]
        self.assertEqual(control["binary_sha256"], "384795c818740c3d8bc96cc490ef1c8910c91455d506bba452dac577660be1b7")
        self.assertEqual(control["source_sha256"], "ed80223d93ce26a5c0b1a0affc589ad60a849214a2c76401e67f7c36e09732b5")

    def test_each_fixed_count_has_exactly_one_fresh_app_per_arm(self):
        for arm in ARMS:
            self.assertEqual(sorted(count for phase, mode, _, count in plan() if (phase, mode) == ("fixed", arm)), list(EDGES))
        self.assertEqual(len({case for _, _, case, _ in plan()}), 18)
        self.assertEqual([arm for phase, arm, _, _ in plan() if phase == "timed"],
                         ["control", "candidate", "candidate", "control", "control", "candidate"])

    def test_fixed_drained_exact_reads_and_writes_with_hot_subset(self):
        result = account(snapshot(), work(400, 400, n_tup_hot_upd=310, n_tup_newpage_upd=80), 8, 50, 0)
        self.assertEqual((result["read_scans"], result["updated_rows"], result["hot_updates"]), (400, 400, 310))
        for read, write in ((399, 400), (400, 399), (401, 400), (400, 401)):
            with self.subTest(read=read, write=write), self.assertRaises(ValueError):
                account(snapshot(), work(read, write), 8, 50, 0)

    def test_open_idle_pool_statistics_rejected_even_when_exact(self):
        with self.assertRaisesRegex(ValueError, "drained"):
            account(snapshot(), work(400, 400, tcp_clients=96, bench_tcp_clients=96), 8, 50, 0)

    def test_deadline_cutoff_bounds_apply_to_reads_and_writes(self):
        cutoff = 2 * CONNECTIONS
        max_work = (1000 + cutoff) * 20
        self.assertEqual(account(snapshot(), work(max_work, max_work), 20, 1000, cutoff)["cutoff_requests"], 384)
        with self.assertRaisesRegex(ValueError, "Point reads"):
            account(snapshot(), work(max_work + 1, max_work), 20, 1000, cutoff)
        with self.assertRaisesRegex(ValueError, "Updates outside"):
            account(snapshot(), work(max_work, max_work + 1), 20, 1000, cutoff)

    def test_timed_updates_require_zero_seq_inserts_deletes_and_bounded_rollback(self):
        for changes in ({"seq_scan": 1}, {"n_tup_ins": 1}, {"n_tup_del": 1}, {"xact_rollback": 385}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                account(snapshot(), work(2000, 2000, **changes), 20, 100, 384)

    def test_manual_maintenance_is_not_attributed_to_workload(self):
        with self.assertRaisesRegex(ValueError, "manual maintenance"):
            account(snapshot(), work(400, 400, vacuum_count=1), 8, 50, 0)

    def test_default_maintenance_and_row_history_are_retained(self):
        before = snapshot()
        active = snapshot(maintenance_running=True, wal_lsn="0/200")
        after = work(400, 400, autovacuum_count=1, autoanalyze_count=1, wal_lsn="0/300", n_live_tup=10000, n_dead_tup=2)
        self.assertEqual(account(before, after, 8, 50, 0)["updated_rows"], 400)
        phases = phase_changes([("before", before), ("after_load", active), ("drained", after)])
        self.assertTrue(phases["before_to_after_load"]["maintenance_active_after"])
        self.assertEqual(phases["after_load_to_drained"]["autovacuum_count"], 1)
        self.assertEqual(phases["after_load_to_drained"]["cluster_wal_insert_bytes"], 256)

    def test_wal_segment_crossing_can_be_replayed(self):
        self.assertEqual(position("1/10") - position("0/FFFFFFF0"), 32)
        for lsn in ("0/FFFFFFFF1", "100000000/0", "-1/0"):
            with self.subTest(lsn=lsn), self.assertRaisesRegex(ValueError, "WAL"):
                position(lsn)
        with self.assertRaisesRegex(ValueError, "decreased"):
            phase_changes([("before", snapshot()), ("drained", snapshot(wal_lsn="0/FF"))])

    def test_persisted_duplicate_writes_use_last_returned_value(self):
        canonical = {1: 3, 2: 8, 3: 9}
        rows = [{"id": 2, "randomNumber": 14}, {"id": 1, "randomNumber": 10}, {"id": 2, "randomNumber": 20}]
        actual = {1: 10, 2: 20, 3: 9}
        self.assertEqual(fixed_overlay(rows), {2: 20, 1: 10})
        self.assertEqual(matching_world(canonical, rows, actual), 2)
        with self.assertRaisesRegex(ValueError, "Whole World differs"):
            matching_world(canonical, rows, actual | {2: 14})
        with self.assertRaisesRegex(ValueError, "Whole World differs"):
            matching_world(canonical, rows, actual | {3: 11})


if __name__ == "__main__":
    unittest.main()
