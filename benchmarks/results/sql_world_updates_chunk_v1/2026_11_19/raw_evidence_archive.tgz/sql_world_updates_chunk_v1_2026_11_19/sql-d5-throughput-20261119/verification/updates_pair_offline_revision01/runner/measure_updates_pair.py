import argparse
import json
import os
from pathlib import Path
import platform
import re
import secrets
import signal
import time

from runner import measure_queries_pair as query
from runner.contract import CONNECTIONS, COUNTERS, DURATION, FIXED, POOL, THREADS, WARMUP, WORKERS, require
from runner.queries_pair_contract import (APP_ENV, COUNT, FIXTURE, KEEP_RULE, WORK, WRK, WRK_SHA, affinity, digest,
                                          read, same_state)
from runner.updates_pair_contract import (EDGES, SOURCE_SEAL, account, check_inputs, drained, fixed_overlay,
                                          phase_changes, plan, same_identity, sealed_variants)


host = query.host
LABELS = host.RUN_LABELS | {"uwz.cohort": "updates-scram-pair"}
STATS_SQL = query.STATS_SQL.replace("  'world_bytes'", """
  'n_live_tup',t.n_live_tup,'n_dead_tup',t.n_dead_tup,'n_tup_newpage_upd',t.n_tup_newpage_upd,
  'relpages',(SELECT relpages FROM pg_class WHERE oid=t.relid),
  'world_reloptions',(SELECT reloptions FROM pg_class WHERE oid=t.relid),
  'autovacuum',current_setting('autovacuum'),'wal_lsn',pg_current_wal_insert_lsn()::text,
  'world_bytes'""")


def observe(args, directory, name):
    row = json.loads(query.db_sql(args, directory, name, STATS_SQL))
    host.check_postgres(args, row)
    require(row["conf_loaded"] == args.auth_proof["after"]["loaded"] and row["autovacuum"] == "on"
            and row["world_reloptions"] is None and row["foreign_clients"] == row["ssl_clients"] == 0
            and row["tcp_clients"] == row["bench_tcp_clients"] <= WORKERS * POOL,
            "Updates fixture settings or client inventory changed")
    return row


def stable_stats(args, directory, phase):
    previous = None
    for index in range(30):
        row = observe(args, directory, f"pg_{phase}_{index:02}")
        stable = {key: value for key, value in row.items() if key != "wal_lsn"}
        if stable == previous and drained(row):
            return row
        previous = stable
        time.sleep(1)
    raise RuntimeError(f"World statistics, clients or maintenance did not drain at {phase}")


def initialize(args, case, fixture, prior):
    boundary = stable_stats(args, case, "external_boundary")
    if prior is not None:
        same_identity(prior, boundary)
        require(all(prior[key] == boundary[key] for key in COUNTERS), "World activity drifted between measured cases")
    local = argparse.Namespace(**(vars(args) | {"output": case}))
    before = query.restore_world(local, fixture)
    snapshots = case / "restore"
    first = read(sorted(snapshots.glob("pg_before_*.stdout"))[-1])
    same_identity(boundary, first)
    require(all(boundary[key] == first[key] for key in COUNTERS), "World activity drifted before restoration")
    actual = stable_stats(args, case, "before")
    same_state(before, actual)
    check_inputs(actual, prior)
    return actual


def persisted(args, case, rows, after):
    raw = query.db_sql(args, case, "world_after_updates", host.WORLD_SQL)
    world_rows = host.typed_world([json.loads(line) for line in raw.splitlines()])
    world = {row["id"]: row["randomNumber"] for row in world_rows}
    overlay = fixed_overlay(rows)
    require(len(world_rows) == len(world) == 10000 and world == args.world | overlay,
            "Canonical World plus last returned serial updates differs from the database")
    probe = stable_stats(args, case, "probe")
    same_identity(after, probe)
    require(probe["seq_scan"] == after["seq_scan"] + 1
            and all(probe[key] == after[key] for key in COUNTERS if key != "seq_scan"),
            "Off-window World export did not account for exactly one additional sequential scan")
    return probe, {"matched_rows": len(world), "distinct_updated_ids": len(overlay), "off_window_export_scans": 1}


def measure_case(args, case, fixture, phase, arm, count, prior):
    case.mkdir()
    print(f"Starting {case.name}", flush=True)
    before = initialize(args, case, fixture, prior)
    path = f"/updates?count={count}"
    record = {"phase": phase, "arm": arm, "count": count, "valid": False}
    owner = secrets.token_hex(16)
    labels = LABELS | {"uwz.run-owner": owner}
    host.save_json(case / "app_ownership.json", {"labels": labels})
    container = None
    starting = False
    after = None
    try:
        require(digest(args.binary) == args.binary_hash, "Selected updates application binary changed")
        starting = True
        container_id = host.run(case, "app_run", [
            "docker", "run", "--detach", "--pull=never", "--network", "host", "--name", f"uwz-d5-update-{case.name}-{owner[:8]}",
            *(entry for key, value in labels.items() for entry in ("--label", f"{key}={value}")),
            "--security-opt", "seccomp=unconfined", "--ulimit", "memlock=-1:-1", "--ulimit", "nofile=524288:524288",
            "--stop-signal", "SIGTERM", "--env-file", args.app_env, "--env", f"UWZ_SQL_WORKERS={WORKERS}",
            "--env", "UWZ_SQL_AFFINITY=1", "--env", f"UWZ_HTTP_PORT={args.port}",
            "--mount", f"type=bind,source={args.binary},target=/server,readonly", "--entrypoint", "/server", args.image,
        ]).strip()
        require(re.fullmatch(r"[0-9a-f]{64}", container_id), "Unexpected updates application container ID")
        container = container_id
        host.app_ready(args, case, container)
        ready = observe(args, case, "ready_pair")
        same_state(before, ready)
        require(ready["tcp_clients"] == ready["bench_tcp_clients"] == WORKERS * POOL, "Expected the 96 plaintext bench sessions")
        app_pid = host.read_pid(case, "app_pid", container)
        host.save_json(case / "app_host_clock_namespace.json", host.host_clock_binding(app_pid, container))
        raw = host.run(case, "app_clock_namespace", ["docker", "exec", container, "sh", "-ec", "readlink /proc/1/ns/time\n"
                       "readlink /proc/1/ns/time_for_children\ncat /proc/1/timens_offsets\nsha256sum /proc/sys/kernel/random/boot_id | cut -d ' ' -f 1"])
        require(host.same_clock(host.clock_namespace(raw), args.clock_namespace), "Updates application clock differs")
        masks = affinity(sorted(case.glob("ready_app_*.stdout"))[-1].read_text())
        require(masks == args.app_affinity, "Updates application affinity changed")
        observations = [("before", before), ("ready", ready)]
        if phase == "fixed":
            started = time.monotonic_ns()
            returned = host.fixed_load(args, case, "updates", path, count)
            host.save_json(case / "client_clock.json", {"started_ns": started, "finished_ns": time.monotonic_ns()})
        else:
            record["warmup"] = query.run_client(args, case, "warmup", WARMUP, path, app_pid)
            observations.append(("after_warmup", observe(args, case, "after_warmup")))
            record["timed"] = query.run_client(args, case, "timed", DURATION, path, app_pid)
        observations.append(("after_load", observe(args, case, "after_load")))
    except (OSError, ValueError, KeyError, RuntimeError) as error:
        record["failure"] = str(error)
    finally:
        if starting:
            container = container or host.find_owned_container(case, labels)
        if container is not None:
            state = host.collect_stop(case, container, labels)
            record["app_state"] = state
    try:
        after = stable_stats(args, case, "after")
        if "failure" not in record:
            require(state["ExitCode"] == 0 and state["OOMKilled"] is False and not state["evidence_errors"],
                    "Owned updates application or cleanup was unhealthy")
            complete = FIXED if phase == "fixed" else record["warmup"]["requests"] + record["timed"]["requests"]
            cutoff = 0 if phase == "fixed" else 2 * CONNECTIONS
            record["sql_work"] = account(before, after, count, complete, cutoff)
            record["maintenance_and_wal"] = phase_changes([*observations, ("drained", after)])
            if phase == "fixed":
                after, record["persisted_world"] = persisted(args, case, returned, after)
            record["valid"] = True
    except (OSError, ValueError, KeyError, RuntimeError) as error:
        record["failure"] = str(error)
    host.save_json(case / "summary.json", record)
    print(f"Finished {case.name} valid={record['valid']} {record.get('sql_work', record.get('failure', ''))}", flush=True)
    return record, after


def main():
    parser = argparse.ArgumentParser(description="D-5 updates-only paired comparison on the corrected SCRAM fixture")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output = args.output.resolve()
    require(args.output.parent == WORK / "measurements" and args.output.name.startswith("updates_scram_pair"),
            "Record the comparison in the dedicated measurements directory")
    variants = sealed_variants()
    args.wrk, args.lua, args.fixture, args.app_env = WRK, Path(host.__file__).with_name("status.lua"), FIXTURE, APP_ENV
    require(digest(args.wrk) == WRK_SHA and digest(args.fixture) == "6e845754beeadbccb1e22b55d60d2eaeee4cd8a66a05a75cb968cec349ca57fa",
            "wrk or prepared host fixture identity changed")
    frozen_run = WORK / "measurements/host_count20"
    frozen = read(frozen_run / "metadata.json")
    mask_file = sorted((frozen_run / "fixed_updates").glob("ready_app_*.stdout"))[-1]
    client_affinity = sorted(os.sched_getaffinity(0))
    require(client_affinity == frozen["client_affinity"] and digest(args.lua) == frozen["sha256"][str(args.lua)],
            "wrk status script or client affinity differs from the established workload")
    args.app_affinity = affinity(mask_file.read_text())
    args.output.mkdir()
    fixture = host.bind_fixture(args)
    query.check_environment(args)
    auth = FIXTURE.parent / "hba_repair/verified.json"
    args.auth_proof = read(auth)
    clock = time.get_clock_info("monotonic")
    require(clock.implementation == "clock_gettime(CLOCK_MONOTONIC)" and clock.monotonic and not clock.adjustable, "Wrong host clock")
    raw = (os.readlink("/proc/self/ns/time") + "\n" + os.readlink("/proc/self/ns/time_for_children") + "\n"
           + Path("/proc/self/timens_offsets").read_text() + digest(Path("/proc/sys/kernel/random/boot_id")) + "\n")
    args.clock_namespace = host.clock_namespace(raw)
    (args.output / "host_clock_namespace.txt").write_text(raw)
    inputs = (args.wrk, args.lua, FIXTURE, auth, SOURCE_SEAL, mask_file, Path(__file__), Path(host.__file__), Path(query.__file__),
              *(Path(__file__).with_name(f"{name}.py") for name in ("contract", "queries_pair_contract", "updates_pair_contract")))
    host.save_json(args.output / "metadata.json", {
        "recorded_at": host.now(), "route": "updates", "count": COUNT, "edges": EDGES, "plan": plan(), "variants": variants,
        "keep_rule": KEEP_RULE, "workers": WORKERS, "pool": POOL, "connections": CONNECTIONS, "threads": THREADS,
        "warmup_seconds": WARMUP, "timed_seconds": DURATION, "fixed_count": FIXED, "pipeline_depth": 1,
        "postgresql_network": "host_loopback", "postgresql_loopback_auth": "scram-sha-256", "pg_host_port": args.db_port,
        "db_container": args.db_container, "db_pid": args.db_pid, "db_image": args.image, "http_port": args.port,
        "wrk": str(args.wrk), "lua": str(args.lua), "kernel": platform.release(), "client_affinity": client_affinity,
        "expected_application_affinity": args.app_affinity, "clock_namespace": args.clock_namespace,
        "proc_clock_ticks_per_second": os.sysconf("SC_CLK_TCK"),
        "initialization_scope": "Every case starts from the same canonical logical World after an off-window restore and VACUUM ANALYZE. Physical history can differ.",
        "status_scope": "Exact HTTP 200 from the Lua response hook. Timed HTTP bodies are not decoded.",
        "maintenance_scope": "Default PostgreSQL automatic maintenance remains enabled and its CPU is included. WAL position deltas are cluster-wide.",
        "sha256": {str(path): digest(path) for path in inputs},
    })
    prior = None
    completed = []
    try:
        for phase, arm, name, count in plan():
            args.binary = Path(variants[arm]["binary"])
            args.binary_hash = variants[arm]["binary_sha256"]
            result, prior = measure_case(args, args.output / name, fixture, phase, arm, count, prior)
            completed.append(name)
            host.save_json(args.output / "completed.json", completed)
            if not result["valid"]:
                return 2
        query.verify_db(args, args.output, "final", fixture, args.auth_proof)
        return 0
    finally:
        inventory = host.run(args.output, "app_final_inventory", ["docker", "ps", "--all", "--quiet", "--no-trunc",
                             *(part for key, value in LABELS.items() for part in ("--filter", f"label={key}={value}"))])
        require(not inventory, "An owned updates application container remains")


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, host.interrupted)
    raise SystemExit(main())
