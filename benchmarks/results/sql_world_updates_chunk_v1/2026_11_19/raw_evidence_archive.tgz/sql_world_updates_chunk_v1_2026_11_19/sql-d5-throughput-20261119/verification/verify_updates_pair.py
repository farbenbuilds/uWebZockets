import argparse
import json
from pathlib import Path
import re

from runner.contract import CONNECTIONS, COUNTERS, DURATION, FIXED, POOL, THREADS, WARMUP, WORKERS, fixed_result, require
from runner.measure_host import WORLD_SQL
from runner.measure_updates_pair import LABELS, STATS_SQL
from runner.queries_pair_contract import (APP_ENV, COUNT, FIXTURE, KEEP_RULE, SEED_SHA, SEED_WORLD_SHA,
                                          WORK, WRK, WRK_SHA, affinity, decision, digest, read, same_state)
from runner.updates_pair_contract import (CUTOFF_DEADLINE_NS, CUTOFF_IDLE_NS, CUTOFF_SQL, EDGES, SOURCE_SEAL,
                                          MOVING_OBSERVATIONS, WAL_SETTINGS_SQL, account, check_inputs, drained,
                                          fixed_overlay, http_socket_script, idle_signature, parse_storage, phase_changes,
                                          plan, same_identity, sealed_variants)
from verification import verify_host as host
from verification import verify_queries_pair as query


def observed(directory, label, fixture, settings, proof):
    cmd = query.db_command(directory, label, fixture, STATS_SQL)
    row = read(directory / f"{label}.stdout")
    query.check_snapshot(row, settings, proof, row["bench_tcp_clients"])
    require(row["tcp_clients"] <= WORKERS * POOL and row["autovacuum"] == "on" and row["world_reloptions"] is None,
            "Incorrect updates fixture settings or socket scope")
    return row, cmd


def settled(directory, phase, fixture, settings, proof):
    files = sorted(directory.glob(f"pg_{phase}_*.stdout"))
    require(len(files) >= 2, f"Missing drained observations: {directory.name}/{phase}")
    records = [observed(directory, path.stem, fixture, settings, proof) for path in files]
    first, last = [{key: value for key, value in record.items() if key not in MOVING_OBSERVATIONS} for record, _ in records[-2:]]
    require(first == last and drained(records[-1][0]), "Updates statistics or maintenance did not drain")
    return records[-1]


def verify_app(case, metadata, fixture, arm):
    cid = (case / "app_run.stdout").read_text().strip()
    require(re.fullmatch(r"[0-9a-f]{64}", cid), "Invalid updates app container ID")
    labels = read(case / "app_ownership.json")["labels"]
    token = labels["uwz.run-owner"]
    require(re.fullmatch(r"[0-9a-f]{32}", token) and labels == LABELS | {"uwz.run-owner": token},
            "Invalid updates application nonce or role")
    lifecycle = {name: query.command(case, "app_" + name)
                 for name in ("run", "stop", "logs", "final_state", "remove", "verify_ownership", "pid", "clock_namespace")}
    require(all(lifecycle[name]["argv"][-1] == cid for name in ("stop", "logs", "final_state", "remove", "verify_ownership", "pid")),
            "App evidence targets another container")
    inspected = read(case / "app_verify_ownership.stdout")
    require(all(inspected.get(key) == value for key, value in labels.items()), "App ownership labels missing")
    binary = metadata["variants"][arm]["binary"]
    expected_run = ["docker", "run", "--detach", "--pull=never", "--network", "host", "--name",
                    f"uwz-d5-update-{case.name}-{token[:8]}",
                    *(entry for key, value in labels.items() for entry in ("--label", f"{key}={value}")),
                    "--security-opt", "seccomp=unconfined", "--ulimit", "memlock=-1:-1", "--ulimit", "nofile=524288:524288",
                    "--stop-signal", "SIGTERM", "--env-file", str(APP_ENV), "--env", f"UWZ_SQL_WORKERS={WORKERS}",
                    "--env", "UWZ_SQL_AFFINITY=1", "--env", f"UWZ_HTTP_PORT={metadata['http_port']}",
                    "--mount", f"type=bind,source={binary},target=/server,readonly", "--entrypoint", "/server", fixture["image"]]
    require(lifecycle["run"]["argv"] == expected_run, "App did not mount the exact updates variant or workload options")
    state = read(case / "app_final_state.stdout")
    require(state["ExitCode"] == 0 and state["OOMKilled"] is False and state["Running"] is False, "Unhealthy updates app exit")
    pid = int((case / "app_pid.stdout").read_text())
    binding = read(case / "app_host_clock_namespace.json")
    clock = host.recorded_clock((case / "app_clock_namespace.stdout").read_text())
    host.require_same_clock(metadata["clock_namespace"], clock)
    require(binding["pid"] == pid and host.cgroup_container(binding["cgroup"], cid)
            and (binding.get("time_inode") == clock["inode"] or binding.get("unavailable_time_inode_errno") in (1, 13)),
            "App process does not match the immutable container or monotonic clock")
    ready = sorted(case.glob("ready_app_*.stdout"))[-1]
    require(query.command(case, ready.stem)["argv"][:3] == ["docker", "exec", cid], "Wrong listening app identity")
    raw = ready.read_text()
    inodes = set(re.findall(r"owned_listener_inode=(\d+)", raw))
    require(inodes and inodes <= set(re.findall(r"socket:\[(\d+)\]", raw)) and raw.count("anon_inode:[io_uring]") == WORKERS
            and affinity(raw) == metadata["expected_application_affinity"], "Listener ownership or app worker affinity differs")
    logs = "\n".join((case / f"app_logs.{stream}").read_text() for stream in ("stdout", "stderr"))
    workers = re.findall(r"SQL benchmark worker=(\d+) pool=(\d+) slab_bytes=(\d+)", logs)
    require(sorted(int(index) for index, _, _ in workers) == list(range(WORKERS))
            and all(int(pool) == POOL and int(slab) > 0 for _, pool, slab in workers), "App log worker/pool count differs")
    for monitor in case.glob("ready_sql_*.command.json"):
        ready_entry = query.command(case, monitor.name.removesuffix(".command.json"))
        host.check_socket_argv(ready_entry["argv"], fixture["pg_socket_port"], fixture["container"])
    return lifecycle, pid, cid


def verify_start(case, fixture, settings, proof, prior, previous_end):
    boundary, boundary_cmd = settled(case, "external_boundary", fixture, settings, proof)
    require(previous_end <= boundary_cmd["monotonic_before_spawn_ns"], "Updates case overlaps earlier work")
    if prior is not None:
        same_identity(prior, boundary)
        require(all(prior[key] == boundary[key] for key in COUNTERS), "World activity outside assigned cases")
    initial, initial_cmd = query.settled(case / "restore", "before", fixture, settings, proof)
    same_identity(boundary, initial)
    require(boundary_cmd["monotonic_after_reap_ns"] <= initial_cmd["monotonic_before_spawn_ns"]
            and all(boundary[key] == initial[key] for key in COUNTERS), "World activity between drain and restore")
    restored, restored_end, original = query.verify_restore(case, fixture, settings, proof)
    before, before_cmd = settled(case, "before", fixture, settings, proof)
    same_state(restored, before)
    check_inputs(before, prior)
    return before, before_cmd, restored, restored_end, original


def verified_cutoff(case, fixture, container, load_reaped, after_load_observed, before_stop_observed):
    pools = sorted(case.glob("pool_cutoff_*.stdout"))
    sockets = sorted(case.glob("http_cutoff_*.stdout"))
    require(len(pools) > 1 and len(pools) == len(sockets), "Incomplete post-client cutoff observations")
    last_end = after_load_observed
    first = None
    for index, (pool_path, socket_path) in enumerate(zip(pools, sockets)):
        require(pool_path.stem == f"pool_cutoff_{index:02}" and socket_path.stem == f"http_cutoff_{index:02}",
                "Cutoff observations are not consecutive")
        db = query.db_command(case, pool_path.stem, fixture, CUTOFF_SQL)
        http = query.command(case, socket_path.stem)
        require(http["argv"] == ["docker", "exec", container, "sh", "-ec", http_socket_script(fixture["http_port"])]
                and load_reaped <= last_end <= db["monotonic_before_spawn_ns"] < db["monotonic_after_reap_ns"]
                <= http["monotonic_before_spawn_ns"] < http["monotonic_after_reap_ns"] <= load_reaped + CUTOFF_DEADLINE_NS,
                "Owned cutoff snapshots do not fit the bounded post-client interval")
        last_end = http["monotonic_after_reap_ns"]
        signature = idle_signature(read(pool_path), socket_path.read_text().splitlines())
        if signature is None:
            first = None
        elif first is None or first[0] != signature:
            first = signature, index, last_end
        elif db["monotonic_before_spawn_ns"] - first[2] >= CUTOFF_IDLE_NS:
            require(index == len(pools) - 1 and last_end <= before_stop_observed, "Cutoff proof is not the final pre-stop observation")
            return {"first_sample": first[1], "last_sample": index, "quiet_ns": db["monotonic_before_spawn_ns"] - first[2]}
    raise ValueError("No stable transaction-free cutoff interval in the raw samples")


def verified_storage(root, label, fixture, proof):
    directory = proof["after"]["data_directory"]
    raw = query.command(root, f"{label}_storage")
    require(directory == "/var/lib/postgresql/18/docker" and raw["argv"] == [
        "docker", "exec", "--user", "postgres", fixture["container"], "df", "-P", "-T", "-k", "--", directory,
    ], "Storage observation did not target the owned fixture")
    query.db_command(root, f"{label}_wal_settings", fixture, WAL_SETTINGS_SQL)
    settings = read(root / f"{label}_wal_settings.stdout")
    require({"max_wal_size", "checkpoint_timeout", "checkpoint_completion_target", "min_wal_size"} <= settings.keys(),
            "Incomplete PostgreSQL WAL/checkpoint configuration proof")
    return {"capacity": parse_storage((root / f"{label}_storage.stdout").read_text()), "settings": settings}


def verify_case(case, phase, arm, count, metadata, fixture, settings, proof, prior, previous_end):
    summary = read(case / "summary.json")
    require(summary["valid"] is True and (summary["phase"], summary["arm"], summary["count"]) == (phase, arm, count),
            f"Invalid updates case {case.name}")
    before, before_cmd, restored, restored_end, original = verify_start(case, fixture, settings, proof, prior, previous_end)
    lifecycle, pid, cid = verify_app(case, metadata, fixture, arm)
    app, stop, removal = (lifecycle[key] for key in ("run", "stop", "remove"))
    ready, ready_cmd = observed(case, "ready_pair", fixture, settings, proof)
    end_load, end_cmd = observed(case, "after_load", fixture, settings, proof)
    after, after_cmd = settled(case, "after", fixture, settings, proof)
    same_state(before, ready)
    require(ready["tcp_clients"] == WORKERS * POOL
            and restored_end <= before_cmd["monotonic_before_spawn_ns"] < before_cmd["monotonic_after_reap_ns"]
            <= app["monotonic_before_spawn_ns"] < app["monotonic_after_reap_ns"] <= ready_cmd["monotonic_before_spawn_ns"]
            and end_cmd["monotonic_after_reap_ns"] <= stop["monotonic_before_spawn_ns"] < stop["monotonic_after_reap_ns"]
            <= removal["monotonic_before_spawn_ns"] < removal["monotonic_after_reap_ns"] <= after_cmd["monotonic_before_spawn_ns"],
            "Updates SQL boundaries do not bracket the application and restore")
    path = f"/updates?count={count}"
    result = {"phase": phase, "arm": arm, "count": count, "restored": restored, "pg_before": before, "pg_ready": ready,
              "pg_after_load": end_load, "pg_after": after}
    observations = [("before", before), ("ready", ready)]
    if phase == "fixed":
        responses = read(case / "fixed_responses.json")
        require(len(responses) == FIXED, "Wrong number of serial fixed responses")
        rows = [row for response in responses for row in fixed_result(response, "updates", path, count)]
        clock = read(case / "client_clock.json")
        require(ready_cmd["monotonic_after_reap_ns"] <= clock["started_ns"] < clock["finished_ns"] <= end_cmd["monotonic_before_spawn_ns"],
                "Fixed updates are outside their recorded app window")
        work = account(before, after, count, len(responses), 0)
        export = query.db_command(case, "world_after_updates", fixture, WORLD_SQL)
        probe, probe_cmd = settled(case, "probe", fixture, settings, proof)
        persisted = host.world_from((case / "world_after_updates.stdout").read_text())
        count_ids = host.matching_world(original, rows, persisted)
        require(count_ids == len(fixed_overlay(rows))
                and after_cmd["monotonic_after_reap_ns"] <= export["monotonic_before_spawn_ns"]
                and export["monotonic_after_reap_ns"] <= probe_cmd["monotonic_before_spawn_ns"]
                and probe["seq_scan"] == after["seq_scan"] + 1 and all(probe[key] == after[key] for key in COUNTERS if key != "seq_scan"),
                "Wrong off-window World freeze or last-per-ID serial update history")
        same_identity(after, probe)
        result["persisted_world"] = {"matched_rows": len(persisted), "distinct_updated_ids": count_ids, "off_window_export_scans": 1}
        require(result["persisted_world"] == summary["persisted_world"], "Persisted-World summary differs from rows")
        next_baseline, last_cmd = probe, probe_cmd
    else:
        warm = host.timed_sample(case, "warmup", WARMUP, path, metadata, pid, cid)
        warm_end, warm_cmd = observed(case, "after_warmup", fixture, settings, proof)
        timed = host.timed_sample(case, "timed", DURATION, path, metadata, pid, cid)
        require(ready_cmd["monotonic_after_reap_ns"] <= warm["client_clock_ns"][0] < warm["client_clock_ns"][1]
                <= warm_cmd["monotonic_before_spawn_ns"] < warm_cmd["monotonic_after_reap_ns"]
                <= timed["client_clock_ns"][0] < timed["client_clock_ns"][1] <= end_cmd["monotonic_before_spawn_ns"],
                "Updates warmup or sample has the wrong measured window")
        work = account(before, after, count, warm["requests"] + timed["requests"], 2 * CONNECTIONS)
        observations.append(("after_warmup", warm_end))
        quiet, quiet_cmd = observed(case, "before_stop", fixture, settings, proof)
        cutoff = verified_cutoff(case, fixture, cid, timed["client_clock_ns"][1], end_cmd["monotonic_after_reap_ns"],
                                 quiet_cmd["monotonic_before_spawn_ns"])
        require(cutoff == summary["cutoff_quiet"] and quiet["tcp_clients"] == WORKERS * POOL and quiet["active_tcp_clients"] == 0
                and quiet_cmd["monotonic_after_reap_ns"] <= stop["monotonic_before_spawn_ns"], "Quiet cutover does not precede owned shutdown")
        result.update({"warmup": warm, "pg_after_warmup": warm_end, "timed": timed, "cutoff_quiet": cutoff, "pg_before_stop": quiet})
        next_baseline, last_cmd = after, after_cmd
    observations.append(("after_load", end_load))
    if phase == "timed":
        observations.append(("before_stop", quiet))
    movement = phase_changes([*observations, ("drained", after)])
    require(work == summary["sql_work"] and movement == summary["maintenance_and_wal"],
            "Updates work or maintenance and WAL counts disagree with the raw record")
    result.update({"sql_work": work, "maintenance_and_wal": movement})
    return result, next_baseline, last_cmd["monotonic_after_reap_ns"], cid


def verify(root):
    md = read(root / "metadata.json")
    require(md["route"] == "updates" and md["count"] == COUNT and md["edges"] == list(EDGES) and md["keep_rule"] == KEEP_RULE
            and md["plan"] == [list(entry) for entry in plan()] and md["variants"] == sealed_variants()
            and md["cutoff_observation"]["timeout_ns"] == CUTOFF_DEADLINE_NS
            and md["cutoff_observation"]["minimum_quiet_ns"] == CUTOFF_IDLE_NS
            and tuple(md[key] for key in ("workers", "pool", "connections", "threads", "warmup_seconds", "timed_seconds",
                                         "fixed_count", "pipeline_depth")) == (WORKERS, POOL, CONNECTIONS, THREADS, WARMUP, DURATION, FIXED, 1),
            "Updates profile differs from its predeclared source, shape or keep rule")
    require(read(root / "completed.json") == [name for _, _, name, _ in plan()], "Not all updates comparison cases completed")
    fixture = read(FIXTURE)
    require(digest(FIXTURE) == "6e845754beeadbccb1e22b55d60d2eaeee4cd8a66a05a75cb968cec349ca57fa"
            and md["postgresql_loopback_auth"] == "scram-sha-256"
            and fixture["seed_sha256"] == digest(FIXTURE.with_name("world.sql")) == SEED_SHA
            and fixture["world_sha256"] == digest(Path(fixture["world_path"])) == SEED_WORLD_SHA, "Wrong SCRAM World fixture")
    settings_path, listener_path = (Path(fixture[key]) for key in ("settings_path", "listener_path"))
    settings, listener = read(settings_path), read(listener_path)
    require(digest(settings_path) == fixture["settings_sha256"] and digest(listener_path) == fixture["listener_sha256"]
            and settings["policy"] == {"setting": "auto", "source": "default", "reset_val": "auto"}
            and settings["settings"]["autovacuum"] == "on" and settings["settings"]["server_version_num"] == "180006"
            and settings["extensions"] == ["plpgsql"], "Database settings drifted")
    proof_path = FIXTURE.parent / "hba_repair/verified.json"
    proof = read(proof_path)
    require(digest(proof_path.with_name("after_hba.conf")) == proof["hba_sha256"], "Expected frozen SCRAM HBA bytes")
    initial_storage, final_storage = [verified_storage(root, label, fixture, proof) for label in ("initial", "final")]
    require(initial_storage == md["postgresql_initial_storage"] and final_storage == read(root / "postgresql_final_storage.json")
            and initial_storage["settings"] == final_storage["settings"], "PostgreSQL storage or WAL configuration records differ")
    required_inputs = {str(path) for path in (FIXTURE, WRK, SOURCE_SEAL, proof_path, WORK / "runner/status.lua", WORK / "runner/contract.py")}
    require(required_inputs <= set(md["sha256"]) and all(digest(Path(path)) == sha for path, sha in md["sha256"].items())
            and md["wrk"] == str(WRK) and digest(WRK) == WRK_SHA and md["lua"] == str(WORK / "runner/status.lua")
            and host.workload_fingerprints(md) == host.workload_fingerprints(read(WORK / "measurements/bridge_count20/metadata.json")),
            "Updates harness or workload bytes differ")
    frozen = WORK / "measurements/host_count20"
    masks = affinity(sorted((frozen / "fixed_updates").glob("ready_app_*.stdout"))[-1].read_text())
    require(md["client_affinity"] == read(frozen / "metadata.json")["client_affinity"] and md["expected_application_affinity"] == masks
            and host.recorded_clock((root / "host_clock_namespace.txt").read_text()) == md["clock_namespace"],
            "Updates benchmark CPU placement or clock differs")
    for label in ("db_identity", "db_image_id", "db_listener"):
        query.command(root, label)
    cid, image_id, image, pid, ports, labels, network, binds, pg_cmd = map(json.loads, (root / "db_identity.stdout").read_text().splitlines())
    port = host.check_host_topology(fixture, md, ports, network, binds, pg_cmd)
    bound = read(root / "db_host_binding.json")
    require(cid == md["db_container"] == fixture["container"] == proof["container"] == listener["container"]
            and pid == md["db_pid"] == proof["pid"] == listener["pid"] == bound["pid"]
            and labels == proof["labels"] and labels["uwz.run-token"] == fixture["owner_token"]
            and image == md["db_image"] == fixture["image"] and image_id == (root / "db_image_id.stdout").read_text().strip()
            and bound["cgroup"] == listener["cgroup"] and host.cgroup_container(bound["cgroup"], cid)
            and md["http_port"] == fixture["http_port"] and settings["endpoint"] == {"listen_addresses": "127.0.0.1", "port": str(port)},
            "Updates run did not use the exact owned PostgreSQL fixture")
    host.check_listener((root / "db_listener.stdout").read_text(), port, listener["inode"])
    cases, pairs, ids = {}, {}, set()
    baseline, last = None, 0
    for phase, arm, name, count in plan():
        result, baseline, last, app_id = verify_case(root / name, phase, arm, count, md, fixture, settings, proof, baseline, last)
        require(app_id not in ids, "Expected a fresh updates app for every case")
        ids.add(app_id)
        cases[name] = result
        if phase == "timed":
            timed = result["timed"]
            cpu = timed["cpu_usec_per_response"]
            pairs.setdefault(name.split("_")[0], {})[arm] = {"rps": timed["rps"], "p99_us": timed["p99_us"],
                 "application_cpu": cpu["application_cgroup"], "postgres_cpu": cpu["postgres_cgroup"]}
    query.verify_recorded_auth(root, "final", fixture, settings, proof)
    inventory = query.command(root, "app_final_inventory")
    require(inventory["argv"] == ["docker", "ps", "--all", "--quiet", "--no-trunc",
            *(part for key, value in LABELS.items() for part in ("--filter", f"label={key}={value}"))]
            and not (root / "app_final_inventory.stdout").read_bytes(), "Updates application cleanup did not complete")
    return {"valid": True, "scope": "Local /updates?count=20 comparison. Same logical data at each case start; physical history may differ.",
            "paired_summary": decision(list(pairs.values())), "cases": cases, "d5_all_three_assessed": False,
            "postgresql_storage": {"before": initial_storage, "after": final_storage}}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Independently check raw D-5 matched updates evidence")
    parser.add_argument("measurements", type=Path)
    print(json.dumps(verify(parser.parse_args().measurements), indent=2))
