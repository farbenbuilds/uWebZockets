#!/usr/bin/env python3
"""Verify the updates packet together with the pinned queries archive offline."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import tarfile
from tempfile import TemporaryDirectory
import unittest

from bundle_files import check_manifest, inventory, load, require, require_identity, sha


BUNDLE = Path(__file__).resolve().parent
WORK = BUNDLE / 'sql-d5-throughput-20261119'
RUN = WORK / 'measurements/updates_scram_pair_01'
BASE_SHA = '965f2d156fdadfad52252ff3bc34885015ee4340fee9a8fc5113096d3a00d351'
BASE_NAME = 'sql_world_queries_chunk_v1_2026_11_19'
SEAL = 'verification/updates_pair_candidate.json'


class RecordedPath(type(Path())):
    """Preserve original path strings while opening manifested archive inputs."""

    anchor = None
    files = {}

    def archive_name(self):
        path = Path(str(self))
        require(self.anchor is not None and path.is_absolute() and path.is_relative_to(self.anchor),
                f'Unrecognized recorded path: {path}')
        relative = path.relative_to(self.anchor)
        require('..' not in relative.parts and 'private' not in relative.parts, f'Unexpected archive input: {path}')
        return relative.as_posix()

    def archived(self):
        name = self.archive_name()
        require(name in self.files, f'Unmapped archived file: {name}')
        return self.files[name]

    def open(self, *args, **kwargs):
        return self.archived().open(*args, **kwargs)

    def stat(self, *, follow_symlinks=True):
        return self.archived().stat(follow_symlinks=follow_symlinks)

    def resolve(self, strict=False):
        self.archived().resolve(strict=strict)
        return self

    def glob(self, pattern, *args, **kwargs):
        require(not args and not kwargs, 'Unexpected archived glob options')
        root = self.archive_name()
        return (self / path.name for name in sorted(self.files)
                if (path := Path(name)).parent.as_posix() == root and path.match(pattern))


def validate_base(archive, root):
    dependency = load(BUNDLE / 'base_dependency.json')
    require(root.name == dependency['archive_name'] == BASE_NAME and dependency['archive_sha256'] == BASE_SHA == sha(archive),
            'Wrong queries prerequisite archive')
    manifest = root / 'payload_manifest.json'
    with tarfile.open(archive, 'r:gz') as sealed:
        item = sealed.getmember(f'{BASE_NAME}/payload_manifest.json')
        require(item.isfile() and sealed.extractfile(item).read() == manifest.read_bytes() and
                sha(manifest) == dependency['payload_manifest_sha256'], 'Extracted prerequisite manifest differs from the exact tar')
    check_manifest(root)
    subprocess.run([sys.executable, '-E', '-s', '-B', root / 'verify_bundle.py'], check=True, cwd=root)
    listed = {entry['path']: entry for entry in load(manifest)['files']}
    required = {}
    for entry in dependency['artifacts']:
        name = entry['path']
        require(name not in required and entry == listed[name], f'Base prerequisite does not match its sealed manifest: {name}')
        required[name] = require_identity(root, entry)
    return required


def validate_manifest_lines(work, filename, local_only=False):
    checked = set()
    for line in (work / filename).read_text().splitlines():
        digest, name = line.split(maxsplit=1)
        if local_only:
            actual = (work / name).resolve()
            require(actual.is_relative_to(BUNDLE), f'Unexpected local manifest path: {name}')
        else:
            record = Path(WORK.name) / name
            if record.as_posix().startswith(WORK.name + '/../'):
                record = Path(record.as_posix().split('/../', 1)[1])
            actual = (RecordedPath(str(RecordedPath.anchor)) / record).archived()
        require(actual not in checked and sha(actual) == digest, f'Producer prelaunch identity differs: {name}')
        checked.add(actual)
    require(checked, f'Empty producer receipt: {filename}')


def bind_modules(base):
    sys.path[:0] = [str(WORK), str(base / WORK.name), str(base / WORK.name / 'runner')]
    from runner import queries_pair_contract as queries
    from runner import updates_pair_contract as updates
    from verification import verify_queries_pair as q_check
    from verification import verify_updates_pair as u_check

    for module, root, relative in ((queries, base / WORK.name, 'runner/queries_pair_contract.py'),
                                   (updates, WORK, 'runner/updates_pair_contract.py'),
                                   (q_check, base / WORK.name, 'verification/verify_queries_pair.py'),
                                   (u_check, WORK, 'verification/verify_updates_pair.py'),
                                   (u_check.host, base / WORK.name, 'verification/verify_host.py')):
        require(Path(module.__file__).resolve() == root / relative, 'Unexpected checker import origin')

    raw_path = Path(load(RUN / 'metadata.json')['variants']['candidate']['build'])
    work = RecordedPath(str(raw_path.parents[2]))
    require(work.name == WORK.name, 'Unexpected raw workspace anchor')
    RecordedPath.anchor = Path(str(work.parent))
    for module in (queries, updates, q_check, u_check):
        module.Path = RecordedPath
        module.WORK = work
        module.WRK = work.parent / 'async-db-performance-20261118/tooling/root/usr/bin/wrk'
        module.FIXTURE = work / 'host_fixture/fixture/fixture.json'
        module.APP_ENV = work / 'host_fixture/private/app.env'
        module.SOURCE_SEAL = work / SEAL
    return updates, u_check


def verify_sources(variants):
    dependency = load(BUNDLE / 'base_dependency.json')
    require(variants['control']['binary_sha256'] == dependency['control_binary_sha256'] and
            variants['control']['source_sha256'] == dependency['control_source_identity_sha256'], 'Wrong updates control identity')
    source = WORK / 'updates_candidate'
    manifest = load(source / 'baseline_source_identity.json')
    require(inventory(source / 'source') == {entry['path'] for entry in manifest['files']} and
            len(manifest['files']) == 348, 'Candidate compiled-source inventory differs')
    require(sha(source / 'tracked.patch') == manifest['tracked_patch_sha256'] and
            sha(WORK / 'freeze_updates.py') == manifest['freeze_producer_sha256'] and
            load(WORK / 'freeze_updates_result.json')['exit_code'] == 0, 'Candidate source freeze provenance differs')
    ordinary = load(WORK / 'developer_updates/updates_full_units_01.json')
    require(ordinary['exit_code'] == 0 and '1198/1205 tests passed' in ordinary['test_counts'] and '7 skip' in ordinary['test_counts'],
            'Final ordinary-unit receipt differs')
    for name, digest in ordinary['sources'].items():
        directory = 'documentation' if name == 'docs/sql.md' else 'source'
        require(sha(source / directory / name) == digest, f'Tested and built source differ: {name}')
    focused = WORK / 'developer_updates/updates_lock_focus_02'
    require(load(focused.with_suffix('.json'))['exit_code'] == 0 and '13/13 tests passed' in focused.with_suffix('.stderr').read_text(),
            'Final focused test receipt differs')


def verify_lifecycle(variants):
    from updates_http_lifecycle import producer

    directory = WORK / 'updates_http_lifecycle'
    shared = RecordedPath.files[f'{WORK.name}/developer/check_queries_lifecycle.py']
    require(Path(producer.__file__).resolve() == directory / 'producer.py' and
            Path(producer.shared.__file__).resolve() == shared, 'Unexpected lifecycle import origin')
    final = load(directory / 'attempt_02_verified_summary.json')
    for path, digest in final['sha256'].items():
        require(sha(WORK / path) == digest, f'HTTP lifecycle raw artifact differs: {path}')
    raw = directory / 'attempt_02'
    result = load(raw / 'result.json')
    require(result['status'] == 'passed' and result['variant'] == final['variant'] == variants['candidate'] and
            not result['cleanup_errors'] and final['verified_same_original_after_cleanup'] is True and
            result['restore']['world_sha256'] == result['original_world_sha256'] == producer.world_digest(load(raw / 'world_before.json')),
            'HTTP lifecycle producer or restoration identity differs')
    rows = {}
    for command in load(raw / 'commands.json'):
        if (command['sql'] or '').endswith("SELECT json_agg(json_build_object('id',id,'randomNumber',randomnumber) ORDER BY id) FROM public.uwz_ul_values;"):
            require(command['exit_code'] == 0, 'Lifecycle World observation failed')
            world = json.loads(command['stdout'])
            rows[producer.world_digest(world)] = world
    responses = {entry['label']: entry for line in (raw / 'responses.jsonl').read_text().splitlines() if (entry := json.loads(line))}
    groups = [json.loads(line) for line in (raw / 'cases.jsonl').read_text().splitlines()]
    require(len(groups) == 36 and len(responses) == len(final['cases']) == 12, 'Wrong lifecycle case count')
    for start, observed, validated in zip(groups[::3], groups[1::3], groups[2::3], strict=True):
        label = start['label']
        path = start['path']
        route = path.split('?', 1)[0][1:]
        count = 1 if route == 'db' else int(path.rsplit('=', 1)[1])
        require(label == observed['label'] == validated['label'] and
                [start['event'], observed['event'], validated['event']] == ['started', 'observed', 'validated'],
                'Lifecycle journal event order differs')
        response = responses[label]
        current = producer.validate_case(response, observed['snapshot'], rows[start['before_sha256']], rows[observed['after_sha256']],
                                         count, route, start['fail'], start['missing'], start['delay'])
        require(current == {key: validated[key] for key in current} and response['status'] == final['cases'][label]['status'],
                f'Lifecycle outcome differs: {label}')
    failed = load(directory / 'attempt_01/result.json')
    require(failed['status'] == 'failed' and not failed['cleanup_errors'] and
            not (directory / 'attempt_01/responses.jsonl').exists() and
            failed['restore']['world_sha256'] == failed['original_world_sha256'], 'Historical lifecycle failure or cleanup differs')
    restore = load(WORK / 'developer_updates/preexisting_view_restore/restoration_receipt.json')
    require(restore['base_oid'] == restore['expected_base_oid'] and restore['before_rows_sha256'] ==
            restore['after_rows_sha256'] == restore['expected_rows_sha256'] and restore['all_subprocesses_reaped'],
            'Prior isolated World restoration differs')


def verify_pair(result):
    require(json.loads(json.dumps(result)) == load(RUN / 'verified.json'), 'Recomputed updates result differs from saved verification')
    require(result['paired_summary']['keep'] and not result['d5_all_three_assessed'], 'Wrong paired retention or D5 status')
    cases = result['cases'].values()
    fixed = [case for case in cases if case['phase'] == 'fixed']
    timed = [case for case in cases if case['phase'] == 'timed']
    require(len(fixed) == 12 and sum(case['sql_work']['completed'] for case in fixed) == 600 and
            len(timed) == 6 and sum(case['sql_work']['completed'] for case in timed) == 605074, 'Unexpected fixed or timed case totals')
    require(all(7400 <= case['sql_work']['updated_rows'] - 20 * case['sql_work']['completed'] <= 7680 and
                case['cutoff_quiet']['quiet_ns'] >= 1288000000 for case in timed), 'Unexpected sampled cutoff results')


class TestWork:
    """Keep original test source reads sealed and test writes in temporary storage."""

    def __init__(self, scratch):
        self.scratch = scratch

    def __truediv__(self, part):
        if part == 'verification':
            return self.scratch
        return RecordedPath(str(RecordedPath.anchor)) / WORK.name / part


def run_checker_tests():
    from updates_http_lifecycle import producer, test_producer
    from verification import test_updates_pair

    with TemporaryDirectory(dir=BUNDLE.parent) as directory:
        test_updates_pair.WORK = TestWork(Path(directory))
        producer.DIRECTORY = Path(directory)
        suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(module)
                                   for module in (test_updates_pair, test_producer))
        require(unittest.TextTestRunner(verbosity=1).run(suite).wasSuccessful(), 'Upstream offline checker tests failed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--queries-archive', type=Path, required=True)
    parser.add_argument('--queries-root', type=Path, required=True)
    parser.add_argument('--test-checkers', action='store_true', help='also run the archived offline checker tests')
    args = parser.parse_args()
    base = args.queries_root.resolve(strict=True)
    count = check_manifest(BUNDLE)
    archived = validate_base(args.queries_archive.resolve(strict=True), base)
    current = {name: BUNDLE / name for name in inventory(BUNDLE)}
    require(not archived.keys() & current.keys(), 'Ambiguous recorded input origin')
    RecordedPath.files = archived | current
    updates, checker = bind_modules(base)
    validate_manifest_lines(WORK, 'verification/updates_pair_prelaunch.sha256')
    validate_manifest_lines(WORK, 'updates_http_lifecycle/offline.sha256')
    variants = updates.sealed_variants()
    verify_sources(variants)
    verify_lifecycle(variants)
    result = checker.verify(RUN)
    verify_pair(result)
    if args.test_checkers:
        run_checker_tests()
    print(f'Verified {count} updates payload files and {len(archived)} exact prerequisite artifact identities.')
    print('Recomputed 12 HTTP lifecycle cases and 18 paired cases with 600 fixed responses and 605,074 warmup and timed successes.')
    rps = result['paired_summary']['metrics']['rps']
    print(f"/updates medians: {rps['control_median']:.3f} control requests/s, {rps['candidate_median']:.3f} candidate requests/s.")
    print('Candidate passes the keep rule. D5 remains open.')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, subprocess.CalledProcessError) as error:
        raise SystemExit(f'Verification failed: {error}') from error
