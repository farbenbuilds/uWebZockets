#!/usr/bin/env python3
"""Replay exact retained control and encrypted-peer witnesses without a compiler."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pki-tool', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    output = args.output.absolute()
    helper = args.pki_tool.resolve(strict=True)
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent replay output directory')
    if output.resolve().is_relative_to(base):
        raise ValueError('Keep replay output outside retained evidence')
    if digest(helper) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('The retained PKI helper checksum differs')
    identity = json.loads((base / 'prebuilt_identity.json').read_text())
    expected = {'baseline_controls/control_witness', 'candidate_controls/control_witness',
        'baseline_wire/wire_witness', 'candidate_wire/wire_witness',
        'candidate_unreserved_wire/wire_witness'}
    if set(identity['binaries']) != expected:
        raise ValueError('Unexpected retained binary inventory')
    for name, expected_digest in identity['binaries'].items():
        if digest(base / name) != expected_digest:
            raise ValueError('Retained executable checksum differs: ' + name)
    output.mkdir(parents=True, mode=0o700)
    pki = output / 'private_pki'
    commands = []
    complete = False

    def run(command, name):
        with (output / (name + '.stdout')).open('wb') as stdout, \
             (output / (name + '.stderr')).open('wb') as stderr:
            result = subprocess.run(command, cwd=output, stdout=stdout, stderr=stderr)
        commands.append({'command': command, 'exit_code': result.returncode})
        if result.returncode != 0:
            raise RuntimeError('Replay command failed: ' + name)

    try:
        run([str(helper), 'pki', str(pki)], 'pki_metadata')
        arguments = [str(pki / name) for name in ['server.pem', 'server.key', 'ca.pem']]
        for directory in ['baseline_controls', 'candidate_controls', 'baseline_wire',
                          'candidate_wire', 'candidate_unreserved_wire']:
            target = output / directory
            target.mkdir()
            control = directory.endswith('controls')
            name = 'control_witness' if control else 'wire_witness'
            run([str(base / directory / name), *arguments,
                 str(target / 'operations.csv'), str(target / 'summary.jsonl')], directory)
            verifier = base / ('verify_results.py' if control else 'verify_wire.py')
            command = [sys.executable, str(verifier), str(target)]
            if control:
                command.extend(['--operations', 'operations.csv', '--summary', 'summary.jsonl'])
            run(command, directory + '_verification')
            retained = base / directory / 'summary.jsonl'
            if (target / 'summary.jsonl').read_bytes() != retained.read_bytes():
                raise ValueError('Replay summary differs from retained rows: ' + directory)
            if (target / 'operations.csv').read_bytes() != (base / directory / 'operations.csv').read_bytes():
                raise ValueError('Replay operation counts differ from retained rows: ' + directory)
        run([sys.executable, str(base / 'compare_results.py'), str(output)], 'comparison')
        complete = True
    finally:
        if pki.exists():
            names = {path.name for path in pki.iterdir()}
            if names - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected fixture PKI output; refusing broad cleanup')
            for name in names:
                (pki / name).unlink()
            pki.rmdir()
        (output / 'results.json').write_text(json.dumps({
            'complete': complete, 'commands': commands,
            'private_pki_removed': not pki.exists(),
            'requires_compiler_native_archives_or_source': False,
            'strict_postgresql_gate_closed': False,
        }, indent=2) + '\n')
    print('PASS: 24 public control rows and 36 encrypted rows match exact retained semantics/counts; private PKI removed')


if __name__ == '__main__':
    main()
