#!/usr/bin/env python3
"""Reconcile encrypted peer inputs, results, observations and allocator totals."""
import argparse
import csv
import hashlib
import json
from pathlib import Path

SCENARIOS = ('header_split_1', 'header_split_2', 'header_split_3',
    'body_spanning_records', 'coalesced_header_1', 'coalesced_header_2',
    'coalesced_header_3', 'coalesced_partial_body', 'near_limit_record_slack',
    'excessive_announced_length', 'invalid_empty_ticket', 'repeated_tickets')


def verify(directory):
    rows = [json.loads(line) for line in (directory / 'summary.jsonl').read_text().splitlines()]
    operations = list(csv.DictReader((directory / 'operations.csv').open()))
    assert [row['scenario'] for row in rows] == list(SCENARIOS)
    fields = ('malloc', 'calloc', 'realloc', 'free', 'bytes')
    checked = 0
    for row in rows:
        name = row['scenario']
        assert row['tls13_verified'] and row['hostname_verified']
        assert row['effective_limit'] == 102400
        assert row['callback_bytes_exact'] is True
        assert row['callback_bytes_observed'] == (0 if name == 'excessive_announced_length' else row['plaintext_handshake_bytes'])
        assert sum(row['fragments']) == row['plaintext_handshake_bytes']
        assert all(0 < length <= 16384 for length in row['fragments'])
        selected = [op for op in operations if op['scenario'] == name]
        assert len(selected) == row['operations']
        assert [int(op['operation']) for op in selected] == list(range(len(selected)))
        assert {field: sum(int(op[field]) for op in selected) for field in fields} == row['client_read']
        assert sum(int(op['result']) <= 0 and int(op['error']) in (2, 3) for op in selected) == row['retries']
        assert all(op['phase'] in ('handshake', 'application') for op in selected)
        assert all(int(op['result']) <= 0 for op in selected if op['phase'] == 'handshake')
        assert all(int(op[field]) >= 0 for field in fields for op in selected)
        assert all(int(op['error']) in (0, 1, 2, 3) for op in selected)
        fatal = name in ('excessive_announced_length', 'invalid_empty_ticket')
        assert row['terminal_error'] == (1 if fatal else 0)
        assert (row['terminal_reason'] != 0) == fatal
        assert row['payload_valid'] == (not fatal)
        assert row['application_bytes'] == (0 if fatal else 4096)
        assert sum(max(int(op['result']), 0) for op in selected) == row['application_bytes']
        expected = 0 if name == 'excessive_announced_length' else 8 if name == 'repeated_tickets' else 2 if name.startswith('coalesced') or name == 'near_limit_record_slack' else 1
        assert len(row['callbacks']) == expected
        assert all(item[0] == 4 for item in row['callbacks'])
        if name == 'invalid_empty_ticket':
            assert row['callbacks'] == [[4, 17]]
        if name == 'body_spanning_records':
            assert row['callbacks'] == [[4, 32772]]
        if name == 'near_limit_record_slack':
            assert row['callbacks'] == [[4, 102404], [4, 16383]]
            assert row['peak_handshake_length'] == 118787
            assert row['fragments'][-1] == 16384
        if row['reserved']:
            assert row['retained_storage_stable'] is True
            assert row['peak_handshake_capacity'] in (0, 158384)
            partial = name not in ('excessive_announced_length', 'invalid_empty_ticket', 'repeated_tickets')
            assert row['pending_reservation_rejections'] == int(partial)
        else:
            assert row['retained_storage_stable'] is None
            assert row['pending_reservation_rejections'] == 0
        checked += len(selected)
    assert checked == len(operations)
    return {'rows_verified': len(rows), 'operations_verified': checked,
        'near_limit_logical_length_observed': 118787,
        'accepted_payload_rows': 10, 'fatal_protocol_rows': 2,
        'construction': 'native server tls_seal_record and real BIO delivery; no client parser field mutation',
        'accounting': 'complete client SSL_read plus immediate SSL_get_error; peer preparation and validation outside',
        'private_client_observations': 'read-only buffer length/capacity/pointer snapshots',
        'callbacks_are_pre_validation': True,
        'complete_callback_bytes_match_known_server_input': True,
        'valid_ticket_acceptance_requires_subsequent_payload': True,
        'strict_postgresql_gate_closed': False,
        'operations_sha256': hashlib.sha256((directory / 'operations.csv').read_bytes()).hexdigest(),
        'summary_sha256': hashlib.sha256((directory / 'summary.jsonl').read_bytes()).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.directory), indent=2))


if __name__ == '__main__':
    main()
