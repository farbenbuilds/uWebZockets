#include <openssl/err.h>
#include <openssl/ssl.h>
#include <openssl/ssl3.h>
#include <openssl/x509_vfy.h>
#include <openssl/sha.h>
#include "ssl/internal.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK(value) do { if (!(value)) fail(__LINE__, #value); } while (0)

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

struct allocation_counts {
    uint64_t malloc_calls;
    uint64_t calloc_calls;
    uint64_t realloc_calls;
    uint64_t free_calls;
    uint64_t requested_bytes;
};

struct measured_result {
    int result;
    int error;
    allocation_counts counts;
};

struct protocol_observations {
    unsigned int received_tickets;
    unsigned int received_key_updates;
    unsigned int sent_key_updates;
    uint8_t received_modes[8];
    uint8_t sent_modes[8];
    bool invalid;
    unsigned int callback_count;
    uint8_t callback_types[32];
    size_t callback_lengths[32];
    size_t peak_handshake_length;
    size_t peak_handshake_capacity;
    const char *reserved_data;
    size_t reserved_capacity;
    bool require_stable_storage;
    bool storage_stable;
    const uint8_t *expected_plaintext;
    size_t expected_plaintext_length;
    size_t observed_plaintext_length;
    bool callback_bytes_exact;
};

struct tls_pair {
    SSL_CTX *client_context;
    SSL_CTX *server_context;
    SSL *client;
    SSL *server;
    protocol_observations client_observations;
    protocol_observations server_observations;
};

struct phase_result {
    allocation_counts counts;
    unsigned int operations;
    unsigned int retries;
};

static void fail(int line, const char *expression)
{
    fprintf(stderr, "check failed at line %d: %s\n", line, expression);
    ERR_print_errors_fp(stderr);
    abort();
}

static allocation_counts snapshot_counts(void)
{
    return {uwz_alloc_malloc_calls(), uwz_alloc_calloc_calls(),
            uwz_alloc_realloc_calls(), uwz_alloc_free_calls(),
            uwz_alloc_requested_bytes()};
}

static void add_counts(allocation_counts *total, allocation_counts value)
{
    total->malloc_calls += value.malloc_calls;
    total->calloc_calls += value.calloc_calls;
    total->realloc_calls += value.realloc_calls;
    total->free_calls += value.free_calls;
    total->requested_bytes += value.requested_bytes;
}

static bool retry_error(int error)
{
    return error == SSL_ERROR_WANT_READ || error == SSL_ERROR_WANT_WRITE;
}

static void check_peer_result(SSL *ssl, int result)
{
    if (result > 0) return;
    CHECK(retry_error(SSL_get_error(ssl, result)));
}

static void observe_message(int is_write, int version, int content_type,
                            const void *buffer, size_t length, SSL *ssl,
                            void *argument)
{
    (void)ssl;
    if (content_type != SSL3_RT_HANDSHAKE || length == 0) return;
    const uint8_t *bytes = static_cast<const uint8_t *>(buffer);
    protocol_observations *observed =
        static_cast<protocol_observations *>(argument);
    if (!is_write) {
        if (observed->callback_count == 32) {
            observed->invalid = true;
            return;
        }
        const unsigned int index = observed->callback_count++;
        observed->callback_types[index] = bytes[0];
        observed->callback_lengths[index] = length;
        if (observed->expected_plaintext != nullptr) {
            const size_t remaining = observed->expected_plaintext_length - observed->observed_plaintext_length;
            if (length > remaining || memcmp(bytes, observed->expected_plaintext +
                    observed->observed_plaintext_length, length) != 0) {
                observed->callback_bytes_exact = false;
                observed->invalid = true;
            } else observed->observed_plaintext_length += length;
        }
        const bssl::SSLImpl *client = bssl::FromOpaque(ssl);
        if (client->s3->hs_buf) {
            const BUF_MEM *handshake = client->s3->hs_buf.get();
            if (handshake->length > observed->peak_handshake_length)
                observed->peak_handshake_length = handshake->length;
            if (handshake->max > observed->peak_handshake_capacity)
                observed->peak_handshake_capacity = handshake->max;
            if (observed->require_stable_storage &&
                (handshake->data != observed->reserved_data ||
                 handshake->max != observed->reserved_capacity))
                observed->storage_stable = false;
        }
    }
    if (bytes[0] == SSL3_MT_NEWSESSION_TICKET) {
        if (!is_write) observed->received_tickets++;
        if (version != TLS1_3_VERSION || length < 4) observed->invalid = true;
        return;
    }
    if (bytes[0] != SSL3_MT_KEY_UPDATE) return;
    if (version != TLS1_3_VERSION || length != 5 || bytes[4] > 1) {
        observed->invalid = true;
        return;
    }
    unsigned int *count = is_write ? &observed->sent_key_updates :
                                     &observed->received_key_updates;
    uint8_t *modes = is_write ? observed->sent_modes : observed->received_modes;
    if (*count == 8) {
        observed->invalid = true;
        return;
    }
    modes[*count] = bytes[4];
    (*count)++;
}

static void prepare_pair(tls_pair *pair, const char *certificate,
                         const char *private_key, const char *ca,
                         unsigned int tickets)
{
    pair->client_context = SSL_CTX_new(TLS_method());
    pair->server_context = SSL_CTX_new(TLS_method());
    CHECK(pair->client_context && pair->server_context);
    CHECK(SSL_CTX_set_min_proto_version(pair->client_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_max_proto_version(pair->client_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_min_proto_version(pair->server_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_max_proto_version(pair->server_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_num_tickets(pair->server_context, tickets));
    SSL_CTX_set_session_cache_mode(pair->client_context, SSL_SESS_CACHE_OFF);
    CHECK(SSL_CTX_get_session_cache_mode(pair->client_context) == SSL_SESS_CACHE_OFF);
    CHECK(SSL_CTX_sess_get_new_cb(pair->client_context) == nullptr);
    CHECK(SSL_CTX_use_certificate_chain_file(pair->server_context, certificate));
    CHECK(SSL_CTX_use_PrivateKey_file(pair->server_context, private_key,
                                     SSL_FILETYPE_PEM));
    CHECK(SSL_CTX_check_private_key(pair->server_context));
    CHECK(SSL_CTX_load_verify_locations(pair->client_context, ca, nullptr));
    SSL_CTX_set_verify(pair->client_context, SSL_VERIFY_PEER, nullptr);
    SSL_CTX_set_msg_callback(pair->client_context, observe_message);
    SSL_CTX_set_msg_callback_arg(pair->client_context, &pair->client_observations);
    SSL_CTX_set_msg_callback(pair->server_context, observe_message);
    SSL_CTX_set_msg_callback_arg(pair->server_context, &pair->server_observations);
    pair->client = SSL_new(pair->client_context);
    pair->server = SSL_new(pair->server_context);
    CHECK(pair->client && pair->server);
    CHECK(SSL_set_tlsext_host_name(pair->client, "localhost"));
    CHECK(SSL_set1_host(pair->client, "localhost"));
    SSL_set_connect_state(pair->client);
    SSL_set_accept_state(pair->server);
    BIO *client_bio = nullptr;
    BIO *server_bio = nullptr;
    CHECK(BIO_new_bio_pair(&client_bio, 1024, &server_bio, 1024));
    SSL_set_bio(pair->client, client_bio, client_bio);
    SSL_set_bio(pair->server, server_bio, server_bio);
    bool client_done = false;
    bool server_done = false;
    for (unsigned int i = 0; i < 10000 && (!client_done || !server_done); i++) {
        if (!client_done) {
            int result = SSL_do_handshake(pair->client);
            if (result == 1) client_done = true;
            else check_peer_result(pair->client, result);
        }
        if (!server_done) {
            int result = SSL_do_handshake(pair->server);
            if (result == 1) server_done = true;
            else check_peer_result(pair->server, result);
        }
    }
    CHECK(client_done && server_done);
    CHECK(SSL_version(pair->client) == TLS1_3_VERSION);
    CHECK(SSL_version(pair->server) == TLS1_3_VERSION);
    CHECK(SSL_get_verify_result(pair->client) == X509_V_OK);
    CHECK(SSL_get0_peer_certificates(pair->client) != nullptr);
    CHECK(pair->client_observations.received_tickets == 0);
    pair->client_observations = {};
    pair->server_observations = {};
}

static measured_result measured_read(SSL *client, void *output, int length)
{
    uwz_alloc_begin();
    const int result = SSL_read(client, output, length);
    const int error = result > 0 ? SSL_ERROR_NONE : SSL_get_error(client, result);
    uwz_alloc_end();
    return {result, error, snapshot_counts()};
}


struct wire_case {
    const char *name;
    uint8_t bytes[131072];
    size_t length;
    size_t fragments[32];
    size_t fragment_count;
    unsigned int expected_tickets;
    bool expected_error;
    bool reaches_logical_limit;
};

struct wire_result {
    phase_result reads;
    unsigned int terminal_error;
    uint32_t terminal_reason;
    unsigned int reservation_rejections;
    size_t application_bytes;
    bool payload_valid;
};

static size_t make_ticket(uint8_t *out, size_t capacity, size_t body_length)
{
    CHECK(body_length >= 14 && body_length + 4 <= capacity);
    const size_t ticket_length = body_length - 13 > 65535 ? 65535 : body_length - 13;
    const size_t extension_length = body_length - 13 - ticket_length;
    CHECK(extension_length == 0 || (extension_length >= 4 && extension_length <= 65535));
    out[0] = SSL3_MT_NEWSESSION_TICKET;
    out[1] = static_cast<uint8_t>(body_length >> 16);
    out[2] = static_cast<uint8_t>(body_length >> 8);
    out[3] = static_cast<uint8_t>(body_length);
    out[4] = 0;
    out[5] = 1;
    out[6] = 0x51;
    out[7] = 0x80;
    out[8] = 1;
    out[9] = 2;
    out[10] = 3;
    out[11] = 4;
    out[12] = 0;
    out[13] = static_cast<uint8_t>(ticket_length >> 8);
    out[14] = static_cast<uint8_t>(ticket_length);
    for (size_t i = 0; i < ticket_length; i++) out[15 + i] = static_cast<uint8_t>(i * 17 + 3);
    const size_t extension_offset = 15 + ticket_length;
    out[extension_offset] = static_cast<uint8_t>(extension_length >> 8);
    out[extension_offset + 1] = static_cast<uint8_t>(extension_length);
    if (extension_length != 0) {
        out[extension_offset + 2] = 0xff;
        out[extension_offset + 3] = 0xfe;
        out[extension_offset + 4] = static_cast<uint8_t>((extension_length - 4) >> 8);
        out[extension_offset + 5] = static_cast<uint8_t>(extension_length - 4);
        memset(out + extension_offset + 6, 0x5a, extension_length - 4);
    }
    return body_length + 4;
}

static void fragment_prefix(wire_case *test, size_t prefix)
{
    while (prefix != 0) {
        CHECK(test->fragment_count < 32);
        const size_t part = prefix > 16384 ? 16384 : prefix;
        test->fragments[test->fragment_count++] = part;
        prefix -= part;
    }
}

static void prepare_case(wire_case *test, unsigned int scenario)
{
    static const char *names[] = {"header_split_1", "header_split_2", "header_split_3",
        "body_spanning_records", "coalesced_header_1", "coalesced_header_2",
        "coalesced_header_3", "coalesced_partial_body", "near_limit_record_slack",
        "excessive_announced_length", "invalid_empty_ticket", "repeated_tickets"};
    CHECK(scenario < 12);
    test->name = names[scenario];
    test->expected_tickets = 1;
    test->length = make_ticket(test->bytes, sizeof(test->bytes), 32);
    if (scenario < 3) {
        test->fragments[0] = scenario + 1;
        test->fragments[1] = test->length - test->fragments[0];
        test->fragment_count = 2;
        return;
    }
    if (scenario == 3) {
        test->length = make_ticket(test->bytes, sizeof(test->bytes), 32768);
        fragment_prefix(test, test->length);
        return;
    }
    if (scenario >= 4 && scenario <= 7) {
        const size_t first = test->length;
        test->length += make_ticket(test->bytes + first, sizeof(test->bytes) - first, 32);
        const size_t partial = scenario == 7 ? 14 : scenario - 3;
        test->fragments[0] = first + partial;
        test->fragments[1] = test->length - test->fragments[0];
        test->fragment_count = 2;
        test->expected_tickets = 2;
        return;
    }
    if (scenario == 8) {
        const size_t ceiling = 102400;
        test->length = make_ticket(test->bytes, sizeof(test->bytes), ceiling);
        test->length += make_ticket(test->bytes + test->length,
                                    sizeof(test->bytes) - test->length, 16379);
        fragment_prefix(test, ceiling + 3);
        test->fragments[test->fragment_count++] = 16384;
        CHECK(test->length == ceiling + 3 + 16384);
        test->expected_tickets = 2;
        test->reaches_logical_limit = true;
        return;
    }
    if (scenario == 9) {
        const size_t announced = 102401;
        test->bytes[1] = static_cast<uint8_t>(announced >> 16);
        test->bytes[2] = static_cast<uint8_t>(announced >> 8);
        test->bytes[3] = static_cast<uint8_t>(announced);
        test->length = 5;
        test->fragments[test->fragment_count++] = test->length;
        test->expected_tickets = 0;
        test->expected_error = true;
        return;
    }
    if (scenario == 10) {
        test->bytes[1] = 0;
        test->bytes[2] = 0;
        test->bytes[3] = 13;
        test->bytes[13] = 0;
        test->bytes[14] = 0;
        test->bytes[15] = 0;
        test->bytes[16] = 0;
        test->length = 17;
        test->fragments[test->fragment_count++] = test->length;
        test->expected_error = true;
        return;
    }
    const size_t one = test->length;
    for (size_t i = 1; i < 8; i++) {
        memcpy(test->bytes + test->length, test->bytes, one);
        test->length += one;
    }
    for (size_t i = 0; i < 8; i++) test->fragments[test->fragment_count++] = one;
    test->expected_tickets = 8;
}

static void check_storage(tls_pair *pair)
{
    protocol_observations *observed = &pair->client_observations;
    if (!observed->require_stable_storage) return;
    const bssl::SSLImpl *client = bssl::FromOpaque(pair->client);
    CHECK(client->s3->hs_buf);
    CHECK(client->s3->hs_buf->data == observed->reserved_data);
    CHECK(client->s3->hs_buf->max == observed->reserved_capacity);
}

static void record_read(FILE *operations, const char *name, const char *phase,
                        measured_result operation, wire_result *result)
{
    const uint32_t error = ERR_peek_last_error();
    const uint32_t reason = (static_cast<uint32_t>(ERR_GET_LIB(error)) << 24) |
        static_cast<uint32_t>(ERR_GET_REASON(error));
    const allocation_counts counts = operation.counts;
    fprintf(operations, "%s,%s,%u,%d,%d,%u,%llu,%llu,%llu,%llu,%llu\n", name, phase,
            result->reads.operations, operation.result, operation.error, reason,
            static_cast<unsigned long long>(counts.malloc_calls),
            static_cast<unsigned long long>(counts.calloc_calls),
            static_cast<unsigned long long>(counts.realloc_calls),
            static_cast<unsigned long long>(counts.free_calls),
            static_cast<unsigned long long>(counts.requested_bytes));
    add_counts(&result->reads.counts, counts);
    result->reads.operations++;
    if (operation.result <= 0 && retry_error(operation.error)) result->reads.retries++;
    if (operation.result <= 0 && !retry_error(operation.error)) {
        result->terminal_error = operation.error;
        result->terminal_reason = reason;
    }
}

static void feed_fragment(tls_pair *pair, const wire_case *test,
                          const uint8_t *input, size_t length,
                          FILE *operations, wire_result *result)
{
    uint8_t encrypted[16640];
    size_t encrypted_length = 0;
    CHECK(length <= 16384);
    CHECK(bssl::tls_seal_record(bssl::FromOpaque(pair->server), encrypted,
        &encrypted_length, sizeof(encrypted), SSL3_RT_HANDSHAKE, input, length));
    size_t written = 0;
    for (unsigned int attempt = 0; attempt < 1000 && written < encrypted_length; attempt++) {
        const int accepted = BIO_write(SSL_get_wbio(pair->server), encrypted + written,
                                      static_cast<int>(encrypted_length - written));
        CHECK(accepted > 0 || BIO_should_retry(SSL_get_wbio(pair->server)));
        if (accepted > 0) written += static_cast<size_t>(accepted);
        uint8_t unused[257];
        const measured_result operation = measured_read(pair->client, unused, sizeof(unused));
        record_read(operations, test->name, "handshake", operation, result);
        CHECK(operation.result <= 0);
        check_storage(pair);
        if (result->terminal_error != 0) break;
    }
    CHECK(written == encrypted_length);
}

static unsigned int reject_pending_reservation(tls_pair *pair)
{
#if defined(UWZ_RESERVE_CLIENT_POST_HS)
    const bssl::SSLImpl *client = bssl::FromOpaque(pair->client);
    if (!client->s3->hs_buf || client->s3->hs_buf->length == 0) return 0;
    const BUF_MEM *before = client->s3->hs_buf.get();
    const char *data = before->data;
    const size_t length = before->length;
    const size_t capacity = before->max;
    const size_t configuration = SSL_get_max_cert_list(pair->client);
    uint8_t before_hash[32], after_hash[32];
    CHECK(SHA256(reinterpret_cast<const uint8_t *>(data), length, before_hash));
    CHECK(SSL_reserve_client_post_handshake_buffer(pair->client) == 0);
    CHECK(client->s3->hs_buf.get() == before && before->data == data);
    CHECK(before->length == length && before->max == capacity);
    CHECK(SSL_get_max_cert_list(pair->client) == configuration);
    CHECK(SHA256(reinterpret_cast<const uint8_t *>(data), length, after_hash));
    CHECK(memcmp(before_hash, after_hash, sizeof(before_hash)) == 0);
    ERR_clear_error();
    return 1;
#else
    (void)pair;
    return 0;
#endif
}

static void receive_payload(tls_pair *pair, const wire_case *test,
                            FILE *operations, wire_result *result)
{
    uint8_t payload[4096], received[4096];
    for (size_t i = 0; i < sizeof(payload); i++) payload[i] = static_cast<uint8_t>(i * 13 + 9);
    bool sent = false;
    size_t count = 0;
    for (unsigned int attempt = 0; attempt < 1000 && count < sizeof(received); attempt++) {
        if (!sent) {
            const int write = SSL_write(pair->server, payload, sizeof(payload));
            if (write > 0) {
                CHECK(write == sizeof(payload));
                sent = true;
            } else check_peer_result(pair->server, write);
        }
        const size_t available = sizeof(received) - count;
        const int maximum = static_cast<int>(available > 257 ? 257 : available);
        const measured_result operation = measured_read(pair->client, received + count, maximum);
        record_read(operations, test->name, "application", operation, result);
        if (operation.result > 0) count += static_cast<size_t>(operation.result);
        else CHECK(retry_error(operation.error));
        check_storage(pair);
    }
    CHECK(sent && count == sizeof(received));
    CHECK(memcmp(payload, received, sizeof(payload)) == 0);
    result->application_bytes = count;
    result->payload_valid = true;
}

static void print_counts(FILE *output, allocation_counts counts)
{
    fprintf(output, "{\"malloc\":%llu,\"calloc\":%llu,\"realloc\":%llu,\"free\":%llu,\"bytes\":%llu}",
        static_cast<unsigned long long>(counts.malloc_calls),
        static_cast<unsigned long long>(counts.calloc_calls),
        static_cast<unsigned long long>(counts.realloc_calls),
        static_cast<unsigned long long>(counts.free_calls),
        static_cast<unsigned long long>(counts.requested_bytes));
}

static void run_case(unsigned int scenario, const char *certificate,
                      const char *private_key, const char *ca,
                      FILE *operations, FILE *summary)
{
    wire_case test{};
    prepare_case(&test, scenario);
    tls_pair pair{};
    prepare_pair(&pair, certificate, private_key, ca, 0);
    CHECK(SSL_get_max_cert_list(pair.client) == 102400);
    CHECK(SSL_reserve_record_buffers(pair.client));
    CHECK(SSL_reserve_record_buffers(pair.server));
    pair.client_observations.storage_stable = true;
    pair.client_observations.expected_plaintext = test.bytes;
    pair.client_observations.expected_plaintext_length = test.length;
    pair.client_observations.callback_bytes_exact = true;
#if defined(UWZ_RESERVE_CLIENT_POST_HS)
    CHECK(SSL_reserve_client_post_handshake_buffer(pair.client));
    const BUF_MEM *reserved = bssl::FromOpaque(pair.client)->s3->hs_buf.get();
    CHECK(reserved && reserved->length == 0 && reserved->max == 158384);
    pair.client_observations.require_stable_storage = true;
    pair.client_observations.reserved_data = reserved->data;
    pair.client_observations.reserved_capacity = reserved->max;
    const bool opted_in = true;
#else
    const bool opted_in = false;
#endif
    wire_result result{};
    size_t offset = 0;
    for (size_t index = 0; index < test.fragment_count; index++) {
        feed_fragment(&pair, &test, test.bytes + offset, test.fragments[index], operations, &result);
        offset += test.fragments[index];
        if (result.terminal_error != 0) break;
        if (index == 0) result.reservation_rejections += reject_pending_reservation(&pair);
    }
    CHECK(offset == test.length);
    if (test.expected_error) CHECK(result.terminal_error == SSL_ERROR_SSL);
    else {
        CHECK(result.terminal_error == 0);
        receive_payload(&pair, &test, operations, &result);
    }
    const protocol_observations observed = pair.client_observations;
    CHECK(!observed.invalid && observed.received_tickets == test.expected_tickets);
    CHECK(observed.callback_count == test.expected_tickets);
    CHECK(observed.storage_stable && observed.callback_bytes_exact);
    CHECK(observed.observed_plaintext_length ==
        (scenario == 9 ? 0 : test.length));
    if (test.reaches_logical_limit) CHECK(observed.peak_handshake_length == 118787);
    fprintf(summary, "{\"scenario\":\"%s\",\"reserved\":%s,\"tls13_verified\":true,\"hostname_verified\":true,\"effective_limit\":102400,\"plaintext_handshake_bytes\":%zu,\"fragments\":[", test.name, opted_in ? "true" : "false", test.length);
    for (size_t i = 0; i < test.fragment_count; i++) fprintf(summary, "%s%zu", i ? "," : "", test.fragments[i]);
    fprintf(summary, "],\"callbacks\":[");
    for (unsigned int i = 0; i < observed.callback_count; i++) fprintf(summary, "%s[%u,%zu]", i ? "," : "", observed.callback_types[i], observed.callback_lengths[i]);
    fprintf(summary, "],\"callback_bytes_exact\":true,\"callback_bytes_observed\":%zu", observed.observed_plaintext_length);
    fprintf(summary, ",\"application_bytes\":%zu,\"payload_valid\":%s,\"terminal_error\":%u,\"terminal_reason\":%u,\"operations\":%u,\"retries\":%u,\"pending_reservation_rejections\":%u,\"peak_handshake_length\":%zu,\"peak_handshake_capacity\":%zu,\"retained_storage_stable\":%s,\"client_read\":", result.application_bytes, result.payload_valid ? "true" : "false", result.terminal_error, result.terminal_reason, result.reads.operations, result.reads.retries, result.reservation_rejections, observed.peak_handshake_length, observed.peak_handshake_capacity, opted_in ? "true" : "null");
    print_counts(summary, result.reads.counts);
    fprintf(summary, "}\n");
    SSL_free(pair.client);
    SSL_free(pair.server);
    SSL_CTX_free(pair.client_context);
    SSL_CTX_free(pair.server_context);
}

int main(int argc, char **argv)
{
    CHECK(argc == 6);
    CHECK(uwz_alloc_self_test());
    FILE *operations = fopen(argv[4], "wx");
    FILE *summary = fopen(argv[5], "wx");
    CHECK(operations && summary);
    fprintf(operations, "scenario,phase,operation,result,error,reason,malloc,calloc,realloc,free,bytes\n");
    for (unsigned int scenario = 0; scenario < 12; scenario++)
        run_case(scenario, argv[1], argv[2], argv[3], operations, summary);
    CHECK(fclose(operations) == 0 && fclose(summary) == 0);
    puts("PASS: 12 encrypted peer rows; native server record sealing, unmodified client parser, exact payloads and client-call accounting");
    return 0;
}
