#!/usr/bin/env python3
"""Compare baseline and candidate protocol semantics and measured allocation rows."""
import argparse
import csv
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True  # Keep evidence replays read-only.
from verify_wire import verify


def load_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def wire_comparison(base, candidate, require_same_counts=False):
    before_verified = verify(base)
    after_verified = verify(candidate)
    before = load_rows(base / 'summary.jsonl')
    after = load_rows(candidate / 'summary.jsonl')
    semantic_fields = ('scenario', 'tls13_verified', 'hostname_verified',
        'effective_limit', 'plaintext_handshake_bytes', 'fragments', 'callbacks',
        'callback_bytes_exact', 'callback_bytes_observed',
        'application_bytes', 'payload_valid', 'terminal_error', 'terminal_reason',
        'operations', 'retries', 'peak_handshake_length')
    comparisons = []
    for left, right in zip(before, after):
        assert {field: left[field] for field in semantic_fields} == {
            field: right[field] for field in semantic_fields}, left['scenario']
        if require_same_counts:
            assert left['client_read'] == right['client_read'], left['scenario']
        comparisons.append({'scenario': left['scenario'],
            'before': left['client_read'], 'after': right['client_read'],
            'semantic_fields_equal': True})
    left_ops = list(csv.DictReader((base / 'operations.csv').open()))
    right_ops = list(csv.DictReader((candidate / 'operations.csv').open()))
    operation_fields = ('scenario', 'phase', 'operation', 'result', 'error', 'reason')
    assert len(left_ops) == len(right_ops)
    assert [{key: row[key] for key in operation_fields} for row in left_ops] == [
        {key: row[key] for key in operation_fields} for row in right_ops]
    return {'rows': len(comparisons), 'operations': len(left_ops),
        'semantic_fields': list(semantic_fields), 'operation_fields': list(operation_fields),
        'semantic_equality': True, 'allocation_equality_required': require_same_counts, 'row_counts': comparisons,
        'baseline_verification': before_verified, 'candidate_verification': after_verified}


def control_comparison(base, candidate):
    before = load_rows(base / 'summary.jsonl')
    after = load_rows(candidate / 'summary.jsonl')
    assert len(before) == len(after) == 12
    excluded = {'client_read', 'client_response_write'}
    results = []
    for left, right in zip(before, after):
        assert {key: value for key, value in left.items() if key not in excluded} == {
            key: value for key, value in right.items() if key not in excluded}
        assert left['client_response_write'] == right['client_response_write']
        results.append({'round': left['round'], 'scenario': left['scenario'],
            'before': left['client_read'], 'after': right['client_read'],
            'response_write': right['client_response_write']})
    left_ops = list(csv.DictReader((base / 'operations.csv').open()))
    right_ops = list(csv.DictReader((candidate / 'operations.csv').open()))
    excluded_ops = {'malloc', 'calloc', 'realloc', 'free', 'bytes'}
    assert len(left_ops) == len(right_ops) == 255
    assert [{key: value for key, value in row.items() if key not in excluded_ops} for row in left_ops] == [
        {key: value for key, value in row.items() if key not in excluded_ops} for row in right_ops]
    return {'rows': len(results), 'operations': len(left_ops), 'semantic_equality': True,
            'row_counts': results}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path, nargs='?', default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    root = args.root
    result = {
        'baseline_vs_reserved_wire': wire_comparison(root / 'baseline_wire', root / 'candidate_wire'),
        'baseline_vs_unreserved_candidate_wire': wire_comparison(root / 'baseline_wire', root / 'candidate_unreserved_wire', require_same_counts=True),
        'public_controls': control_comparison(root / 'baseline_controls', root / 'candidate_controls'),
        'strict_postgresql_gate_closed': False,
        'source_scope': 'native server record sealing; no client parser mutation; public controls have startup reservation addition',
    }
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
