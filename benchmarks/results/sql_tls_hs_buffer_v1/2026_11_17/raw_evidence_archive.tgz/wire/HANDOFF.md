# Handshake-buffer encrypted wire verification

This directory is a separate verification experiment. Native implementation
ownership remains with `/tmp/uwz-pg-tls-hs-buffer-fixed-20261117`. Its baseline
is the earlier complete HKDF candidate. No protected vendor source, production
pin, native source, or repository file was changed by this verifier.

## Scope and results

The public control witness differs from its retained predecessor only by the
three-line conditional startup reservation in `control_startup_delta.patch`.
The baseline builds the same source with that option off; the candidate enables
`SSL_reserve_client_post_handshake_buffer` after record reservation. The new
startup reservation is outside the measured read/write intervals; its memory
and failure accounting belong to the separate helper/lifecycle experiment.

Each public variant passes twelve rows and 255 measured client operations.
All return values, retries, protocol observations and payload checks match.
The three repetitions have stable client-read vectors (malloc/free/bytes):

| Scenario | Prior HKDF candidate | Reserved handshake buffer |
| --- | --- | --- |
| Ticket-free payload | 0/0/0 | 0/0/0 |
| Two initially queued tickets, caching off | 14/14/2128 | 12/12/1600 |
| Peer KeyUpdate without response request | 3/3/656 | 1/1/608 |
| Peer KeyUpdate with response request | 9/7/1464 | 7/5/1416 |

The following client response/application write remains zero malloc and two
free calls. All calloc/realloc counts are zero. Tickets are initially queued
by the handshake, not arbitrary later ticket issuance. These are synthetic
TLS/BIO client-call counts, not PostgreSQL query measurements.

`wire_witness.cc` adds twelve encrypted cases in each of three variants:
original HKDF baseline, new native candidate without the reservation, and
new candidate with the reservation. The input covers header splits at bytes
1/2/3, bodies across records, coalesced complete messages with trailing partial
headers/body, the near-limit whole-record slack case, excessive announced
length, an invalid empty ticket, and eight successive tickets. Ten rows require
verified application payload completion; two require matching fatal protocol
errors. Each variant has 383 measured client reads.

The near-limit row first buffers M+3 bytes of an incomplete NewSessionTicket,
then delivers one full 16384-byte handshake record containing the last byte
and another complete ticket. The read-only message callback observes logical
length L=118787 exactly. Reserved data pointers and physical capacity 158384
remain stable. No received-message limit is tightened by the fixture.

The peer uses native `tls_seal_record` on the genuine server SSL and sends its
ciphertext through the real BIO. It does not implement cryptography or mutate
client parser state. This construction is internal native test machinery,
separate from the public-API-only control witness. Client private observations
are read-only length/capacity/pointer snapshots. Callback bytes are compared
allocation-free against the exact known server plaintext; complete callback
content/type/length, all application bytes and the complete read-result/error/
reason sequence match across variants. Callbacks precede semantic validation:
the malformed empty ticket still requires its fatal error despite matching
callback bytes.

Candidate-only reservation calls after actual partial handshake delivery must
fail without changing bytes, pointers, capacity or configuration; the encrypted
exchange then continues successfully. Those explicit API checks, hashing and
error-queue cleanup are outside SSL-read accounting. Their allocation behavior
is not a request-path claim. Public control counts above use only the startup
addition and do not include these extra pending-state checks.

The original all-C counter and its 63-byte self-test are byte-identical.
Complete client `SSL_read`/`SSL_write` calls include immediate `SSL_get_error`.
Peer work, preparation, callback setup and logging occur outside the intervals;
callback observations themselves use only fixed storage and byte comparisons.
No allocator suppression, replacement or weakened assertion was introduced.

## Replay and rebuild

The prebuilt replay requires five exact retained Linux x86-64 executables, a
checksum-pinned PKI helper and Python evidence tooling. It needs no native
archives, native source, compiler or network:

```sh
python3 replay_prebuilt.py --pki-tool /absolute/path/to/wt-tools --output /tmp/uwz-hs-wire-new-replay
```

Choose an absent directory outside this retained evidence. The wrapper verifies
all five helper identities, repeats both public-control and all three wire
variants, compares every retained operation/summary byte and recomputes the
semantic comparison. Owned private fixture PKI is removed in a finally block.
`replay_validation/` records a successful run; `replay_refusals.json` records
existing-output, inside-evidence and wrong-helper refusals before writes.

Source entry point:

```sh
python3 build_run.py NATIVE_ROOT PKI_HELPER NEW_OUTPUT
python3 build_run.py NATIVE_ROOT PKI_HELPER NEW_OUTPUT --reserved
python3 build_run.py NATIVE_ROOT PKI_HELPER NEW_OUTPUT --fixture wire
python3 build_run.py NATIVE_ROOT PKI_HELPER NEW_OUTPUT --fixture wire --reserved
```

Use exact Zig 0.16 and complete native Debug archives. The runner records
actual archive/source identities, fixture/counter hashes and all command
statuses, and refuses existing outputs. Debug archive identity is recorded
provenance, not a portable rebuild-byte requirement. `compare_results.py`
recomputes all variant comparisons offline using the standard directory layout.

`preliminary_observer/` preserves the earlier callback type/length observer and
its successful results. It is superseded by the final exact-byte observer.
Duplicate preliminary binaries and object files are omitted from the delivery
payload; raw historical command/status/hash metadata remains explicit.

Other TLS allocations remain: ticket/session construction, AEAD replacement,
response flights and error processing are not solved by this storage change.
The strict PostgreSQL request-path allocation gate remains open. Dedicated
smoke/security/sanitizer/fuzz/scan campaigns were not run; this is ordinary
functional/allocation verification and no FIPS or release claim is made.
