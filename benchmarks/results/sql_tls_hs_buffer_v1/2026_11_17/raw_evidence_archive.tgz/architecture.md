# Bounded client post-handshake storage

Add an explicit SSL_reserve_client_post_handshake_buffer opt-in for completed,
idle ordinary TLS 1.3 clients. Keep record reservation and unreserved behavior
unchanged. Temporary descriptor/data allocations commit only after success;
failure preserves existing ownership and configuration.

Capture M=max(16384,max_cert_list). Before an accepted TLS record, an incomplete
head occupies at most M+3 bytes; a whole decrypted record adds at most 16384.
Message consumption decreases length. Oversized incomplete heads fail before
another append. The logical bound L=M+3+16384 is 118787 by default; BUF_MEM
rounds data storage to 158384 bytes. Preserve these distinct quantities and
measure descriptor, allocator and state overhead separately.

The opt-in ceiling cannot increase: SSL_set_max_cert_list clamps to captured M
and its getter exposes the setting; lowering and re-raising within M work.
Context setters and unreserved SSL keep their existing behavior. SSL_clear
frees the profile and removes its clamp. Retained appends reject beyond L
without mutation or growth, empty buffers remain owned, and vacated tails are
cleansed. Parsing, callbacks, alerts and message ordering remain intact.

Verification owns genuine baseline RED before native changes, helper/lifecycle
and fault proofs, and separate real encrypted fragmentation/coalescing plus
control comparisons. Crypto owns four source files and complete native rebuild.
Independent review checks every append/reset/setter site and ownership. Root
checks final restoration, replay, artifact integrity and ordinary project gates.

AEAD, ticket/session, outgoing-flight and error/reconnect allocations remain
separate work. No production pin, native publication, PostgreSQL exception or
full allocation-gate closure is claimed. Dedicated campaigns remain deferred.
