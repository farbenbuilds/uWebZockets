from pathlib import Path
import hashlib,json,os,subprocess
base=Path(__file__).resolve().parents[1]
checks=Path(__file__).resolve().parent
helper=base/'native/restore_source.py'
inputs={'baseline':Path('/tmp/uwz-wt-child-callbacks-20261116/zig-pkg/N-V-__8AAA5Ieg5843crc8uXWdNhmmfStwJqA-9TknJSx3_n'), 'hkdf':Path('/tmp/uwz-pg-tls-hkdf-fixed-20261117/boringssl')}
expected=json.loads((base/'native/candidate_source_inventory.json').read_text())
records=[]
def run(command,name,status):
    with (checks/(name+'.stdout')).open('w') as out,(checks/(name+'.stderr')).open('w') as err:
        result=subprocess.run(command,stdout=out,stderr=err)
    records.append({'command':command,'exit_code':result.returncode,'expected_exit_code':status})
    assert result.returncode==status,name
for kind,source in inputs.items():
    target=Path('/tmp/uwz-hs-buffer-source-restore-'+kind+'-20261117')
    assert not target.exists() and not target.is_symlink()
    run(['python3',str(helper),'--source-kind',kind,str(source),str(target)],'restore-'+kind,0)
    names={p.relative_to(target).as_posix() for p in target.rglob('*') if p.is_file() or p.is_symlink()}
    assert names=={e['path'] for e in expected['entries']}
    for entry in expected['entries']:
        path=target/entry['path']
        if 'symlink' in entry:
            assert path.is_symlink() and os.readlink(path)==entry['symlink']
        else:
            assert not path.is_symlink() and hashlib.sha256(path.read_bytes()).hexdigest()==entry['sha256'],entry['path']
    run(['python3',str(helper),'--source-kind',kind,str(source),str(target)],'restore-'+kind+'-existing',1)
wrong=Path('/tmp/uwz-hs-buffer-wrong-source-mode-20261117')
assert not wrong.exists()
run(['python3',str(helper),str(inputs['hkdf']),str(wrong)],'restore-wrong-mode',1)
assert not wrong.exists()
(checks/'source_restore_results.json').write_text(json.dumps({'complete':True,'each_mode_verified_entries':expected['entry_count'],'baseline_and_hkdf_modes_exact':True,'existing_destination_refusals':2,'wrong_source_mode_refused_before_write':True,'commands':records},indent=2)+'\n')
print('PASS: both source modes restore all8709 entries; existing destinations and wrong source mode refused')
