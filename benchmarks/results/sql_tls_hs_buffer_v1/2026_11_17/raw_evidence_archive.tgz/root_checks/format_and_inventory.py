import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

root = Path('/home/foo/Desktop/Repos/uWebZockets')
evidence = Path('/tmp/uwz-sql-tls-hs-buffer-root-checks-20261117')
roots = ['src', 'builds', 'examples', 'tests', 'fuzz']
paths = set()
for arguments in [[], ['--others', '--exclude-standard']]:
    output = subprocess.check_output(
        ['git', 'ls-files', '-z', *arguments, '--', *roots, 'build.zig', 'build.zig.zon'], cwd=root
    )
    paths.update(os.fsdecode(item) for item in output.split(b'\0') if item)
paths = sorted(path for path in paths if (root / path).is_file())

def inventory():
    return {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in paths}

before = inventory()
moved = []
holder = Path(tempfile.mkdtemp(prefix='.uwz-fmt-', dir=root))
try:
    for directory in roots:
        for parent, directories, _ in os.walk(root / directory):
            for name in list(directories):
                if name not in {'.zig-cache', 'zig-cache', 'zig-out', 'zig-pkg', '.zig-pkg'}:
                    continue
                source = Path(parent) / name
                target = holder / str(len(moved))
                source.rename(target)
                moved.append((source, target))
                directories.remove(name)
    with (evidence / 'format.log').open('w') as output:
        subprocess.run(
            ['/tmp/zig-x86_64-linux-0.16.0/zig', 'fmt', *roots], cwd=root,
            stdout=output, stderr=subprocess.STDOUT, check=True
        )
finally:
    for source, target in reversed(moved):
        target.rename(source)
    holder.rmdir()
after = inventory()
changed = [path for path in paths if before[path] != after[path]]
(evidence / 'source.sha256').write_text(''.join(f'{after[path]}  {path}\n' for path in paths))
(evidence / 'format-result.json').write_text(json.dumps({
    'protected_directories': [str(source.relative_to(root)) for source, _ in moved],
    'input_count': len(paths), 'changed_files': changed
}, indent=2) + '\n')
print(f'{len(paths)} source/build inputs; {len(moved)} cache directories protected; changed={changed}')

