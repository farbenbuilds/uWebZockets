#!/usr/bin/env python3
"""Build a separate fault/cleansing observer and run the reservation lifecycle cases."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

CASES = ('failure_descriptor', 'failure_data', 'idempotent', 'pending_plaintext',
    'pending_record', 'pending_write', 'queued_key_update', 'pending_flight',
    'control_read', 'control_write', 'null', 'unfinished', 'dtls_configured',
    'quic_configured', 'server', 'tls12_complete', 'write_shutdown', 'read_shutdown',
    'clear_rehandshake', 'lowered_ceiling')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('pki_tool', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--zig', default='/tmp/zig-x86_64-linux-0.16.0/zig')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    native = args.native_root.resolve(strict=True)
    tool = args.pki_tool.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    if sha(tool) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('PKI helper differs')
    output.mkdir(mode=0o700)
    environment = dict(os.environ)
    environment['ZIG_GLOBAL_CACHE_DIR'] = '/tmp/uwz-zig-cache'
    commands = []
    rows = []
    complete = False

    def run(command, stem):
        with (output / (stem + '.stdout')).open('wb') as stdout, \
             (output / (stem + '.stderr')).open('wb') as stderr:
            result = subprocess.run(command, cwd=output, env=environment,
                                    stdout=stdout, stderr=stderr)
        commands.append({'command': command, 'exit_code': result.returncode, 'stem': stem})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode != 0:
            raise RuntimeError('Command failed: ' + str(output / stem))

    archives = [native / 'native_out/lib/libssl.a', native / 'native_out/lib/libcrypto.a']
    provenance = {'native_root': str(native), 'native_archives': {p.name: sha(p) for p in archives},
        'source_sha256': {name: sha(base / name) for name in
            ['hs_pair.h', 'hs_lifecycle.cc', 'hs_fault_alloc.c', 'hs_fault_alloc.h']},
        'native_source_sha256': {name: sha(native / 'boringssl' / name) for name in
            ['include/openssl/ssl.h', 'ssl/internal.h', 'ssl/ssl_lib.cc', 'ssl/s3_both.cc']},
        'optimization': 'Debug (-O0 -g)', 'fault_observer_is_ordinary_counter': False}
    (output / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    run([args.zig, 'cc', '-std=c11', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
         '-fno-builtin-malloc', '-fno-builtin-calloc', '-fno-builtin-realloc', '-fno-builtin-free',
         '-c', str(base / 'hs_fault_alloc.c'), '-o', str(output / 'hs_fault_alloc.o')], 'build-observer')
    run([args.zig, 'c++', '-std=c++17', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
         '-DBORINGSSL_IMPLEMENTATION', '-isystem', str(native / 'boringssl'),
         '-isystem', str(native / 'boringssl/include'), str(base / 'hs_lifecycle.cc'),
         str(output / 'hs_fault_alloc.o'), *[str(p) for p in archives],
         '-o', str(output / 'hs_lifecycle')], 'build-lifecycle')
    pki = output / 'private_pki'
    try:
        run([str(tool), 'pki', str(pki)], 'pki_metadata')
        arguments = [str(pki / name) for name in ['server.pem', 'server.key', 'ca.pem']]
        for name in CASES:
            run([str(output / 'hs_lifecycle'), *arguments, name], name)
            result = json.loads((output / (name + '.stdout')).read_text())
            if result['case'] != name or result['pass'] is not True:
                raise ValueError('Unexpected lifecycle output: ' + name)
            rows.append({'case': name, 'result': result,
                'stdout_sha256': sha(output / (name + '.stdout')),
                'stderr_sha256': sha(output / (name + '.stderr'))})
        complete = True
    finally:
        if pki.exists():
            names = {p.name for p in pki.iterdir()}
            if names - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected private fixture output')
            for name in names:
                (pki / name).unlink()
            pki.rmdir()
        (output / 'results.json').write_text(json.dumps({'complete': complete,
            'rows': rows, 'private_pki_removed': not pki.exists(),
            'binary_sha256': sha(output / 'hs_lifecycle')}, indent=2) + '\n')
    print('PASS: ' + str(len(rows)) + ' reservation lifecycle cases; private PKI removed')


if __name__ == '__main__':
    main()
