# Client post-handshake buffer verification

This payload is self-relative and ready for the outer delivery's `helper/`
directory. Native source and complete archives are owned by the separate
`/tmp/uwz-pg-tls-hs-buffer-fixed-20261117` experiment. Every final candidate
proof uses the same complete Debug native build:

- libssl.a `56a2bb22d7767cb72b626061f2c0ca22dff1305b140d471535bc2df0a00a6876`
- libcrypto.a `c1b0def642ff320a36360a16dbb0967fa020fc64ac7b92fc8203119adf1f9012`

`baseline_final/` and `candidate_initial/` contain the final direct-helper
fixture build and results. The candidate directory name records build order;
the native source and archives were confirmed final and unchanged afterward.
`baseline/` and `baseline_initial/` preserve the initial RED before additional
candidate-only contract assertions were added. No prior provenance was rewritten.

The direct helper starts with a real CA/hostname-verified TLS 1.3 pair, then
invokes native append/get/next-message helpers directly. It is not an encrypted
peer-protocol acceptance test. Sixty-four loops cover split 1/2/3-byte headers,
body fragmentation, a complete frame plus trailing partial header and subsequent
completion. A near-M incomplete frame followed by a full 16,384-byte append
reaches logical L=118787 exactly. Bytes and parsed frame contents are verified.

The unchanged-baseline strict zero-heap assertion fails as intended:
258 malloc, 258 free and 272600 requested bytes. With reservation, the identical
append/consume exercise plus candidate contract checks has zero malloc/calloc/
realloc/free/requested bytes. The original all-C interposer is byte-identical;
its malloc/calloc/realloc/free 1/1/1/2, 63-byte self-test remains intact.

Candidate contract checks include captured M=102400, logical L=118787, rounded
physical A=158384, exact-L usage, L+1/A+1 and partial-buffer overflow rejection
with byte/pointer/length/capacity preservation, vacant-tail zeroing, idempotence,
complete-message/has_message rejection and bounded setter/context behavior.
Physical slack is not extra logical capacity. The helper explicitly seeds
unused capacity bytes for deterministic guard checks, only in this direct-helper
scope. Default startup observes two C malloc calls /158424 bytes: descriptor
payload24+prefix8 and data158384+prefix8. sizeof(SSL3_STATE) is 600 baseline and
608 candidate. These measurements are distinct from the handshake's allocations.

`lifecycle_complete/` contains 21 passing cases, using separate test-only
`hs_fault_alloc.c` fixed bookkeeping. It injects first/second reservation malloc
failure, verifies atomic state/config/ownership preservation and real temporary
cleanup, then successfully reserves the same verified SSL. Successful descriptor
and data allocations start nonzero; the observer sees every byte zero immediately
before the actual __libc_free, including the allocation prefix, and forwards that
real free. Every tracked allocation is freed exactly once with zero live records.
This observer is not substituted for the ordinary allocation counter.

The cases cover idempotence, real unread plaintext/incomplete ciphertext/
backpressured application writes, continuation of those valid payloads followed
by reservation, role/version/configured DTLS/QUIC exclusions, null/unfinished
connections, close_notify, a public encrypted fatal-alert read with saved-error
preservation, minimum M=16384 and context independence. SSL_clear releases both
allocations, removes the captured bound, permits a larger setter, then supports
a fresh verified nonresumed handshake and another reservation/traffic epoch.
DTLS/QUIC negatives are configured-only, not handshake interoperability.

The queued-KeyUpdate and pending-flight lifecycle cases use public SSL_key_update.
For the partially flushed flight, a genuine SSL_write fills the BIO before
native tls_flush writes part of the resulting encrypted flight. This is an
internal canonical-flight-flush fixture, not a public-only peer acceptance test;
the server does not validate the queued flight in this case. No private flags or
buffer contents are staged to fabricate the pending state. The first preliminary
generator incorrectly used SSL_write, which moves the flight into write_buffer
and uncorks the KeyUpdate. `lifecycle_initial/` retains that failure, exact source
and diagnosis. The corrected generator retains the flight/key-update/state
assertions. `lifecycle_final/` is a complete 20-case intermediate source/run;
independent review then requested the additional fatal-alert saved-read-error
case now present in `lifecycle_complete/`.

`inherited_record/` rebuilds unchanged prior record-retention sources against
the new complete archives/state layout: all 16 lifecycle cases, 256 buffer loops
and the seven-record-size verified TLS pair through 16,384 bytes pass. Its old
record-reservation failure contract remains unchanged. `inherited_hkdf/` runs
the unchanged 1440-case fixture: 700 successful calls remain zero allocation,
and all 1440 return/error/full-buffer hashes match the retained pre-HKDF baseline.

The safe prebuilt replay requires no compiler, native source or native archives:

```sh
python3 helper/replay_prebuilt.py --pki-tool /absolute/path/to/wt-tools --output /tmp/uwz-hs-new-replay
```

Output must be absent and outside `helper/`. The PKI helper checksum and seven
retained binary checksums are verified before execution. All owned private PKI
is removed in a finally block. A complete successful replay is retained under
`replay_validation/`, with three refusal checks in `replay_negative_results.json`.
No certificate or private key is retained in this payload.

Source build commands and exact hashes/logs are retained in `run_helper.py`,
`run_lifecycle.py`, `run_record_regressions.py` and `inherited_hkdf/run_witness.py`
outputs. They require fresh output paths; the inherited record driver also
requires its listed generated paths to be absent in a fresh source copy.

Actual encrypted fragment/coalescing/differential and public control rows belong
to the separate wire verifier payload. This helper payload does not replace
that evidence. Strict PostgreSQL request-path allocation remains open because
other native post-handshake allocations persist. Production pins/APIs, fork
publication and release completion are unchanged. Deferred smoke/security/
sanitizer/fuzz campaigns were not run.
