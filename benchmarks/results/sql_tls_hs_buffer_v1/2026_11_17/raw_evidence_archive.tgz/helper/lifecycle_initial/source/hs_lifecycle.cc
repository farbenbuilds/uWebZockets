#include "hs_pair.h"
#include "hs_fault_alloc.h"

struct SliceSnapshot {
    uintptr_t pointer;
    size_t length;
    size_t capacity;
    uint64_t hash;
};

struct PendingSnapshot {
    SliceSnapshot slices[7];
    uintptr_t descriptor;
    size_t unreported_bytes;
    long max_cert_list;
    uint32_t ceiling;
    uint32_t flight_offset;
    uint32_t pending_write_type;
    uint8_t has_message;
    uint8_t key_update_pending;
    uint8_t alert_dispatch;
    uint8_t read_shutdown;
    uint8_t write_shutdown;
};

static uint64_t byte_hash(const uint8_t *bytes, size_t length)
{
    uint64_t hash = 1469598103934665603ULL;
    for (size_t index = 0; index < length; index++) {
        hash ^= bytes[index];
        hash *= 1099511628211ULL;
    }
    return hash;
}

static SliceSnapshot slice(const uint8_t *bytes, size_t length, size_t capacity)
{
    return {reinterpret_cast<uintptr_t>(bytes), length, capacity, byte_hash(bytes, length)};
}

static SliceSnapshot buffer(const BUF_MEM *value)
{
    if (!value) return {};
    return slice(reinterpret_cast<const uint8_t *>(value->data), value->length, value->max);
}

static PendingSnapshot capture(SSL *ssl)
{
    auto *state = bssl::FromOpaque(ssl)->s3;
    PendingSnapshot result;
    memset(&result, 0, sizeof(result));
    result.slices[0] = buffer(state->hs_buf.get());
    result.slices[1] = slice(state->read_buffer.cap() ? state->read_buffer.data() : nullptr,
        state->read_buffer.size(), state->read_buffer.cap());
    result.slices[2] = slice(state->write_buffer.cap() ? state->write_buffer.data() : nullptr,
        state->write_buffer.size(), state->write_buffer.cap());
    result.slices[3] = slice(state->pending_app_data.data(), state->pending_app_data.size(), 0);
    result.slices[4] = slice(state->pending_write.data(), state->pending_write.size(), 0);
    result.slices[5] = buffer(state->pending_hs_data.get());
    result.slices[6] = buffer(state->pending_flight.get());
    result.descriptor = reinterpret_cast<uintptr_t>(state->hs_buf.get());
    result.unreported_bytes = state->unreported_bytes_written;
    result.max_cert_list = SSL_get_max_cert_list(ssl);
    result.ceiling = state->client_post_handshake_max_message_len;
    result.flight_offset = state->pending_flight_offset;
    result.pending_write_type = state->pending_write_type;
    result.has_message = state->has_message;
    result.key_update_pending = state->key_update_pending;
    result.alert_dispatch = state->alert_dispatch;
    result.read_shutdown = state->read_shutdown;
    result.write_shutdown = state->write_shutdown;
    return result;
}

static void check_released(uint64_t allocations)
{
    const HsFaultStats stats = hs_fault_read();
    CHECK(stats.successful == allocations);
    CHECK(stats.live == 0 && stats.actual_frees == allocations);
    CHECK(stats.cleanse_failures == 0);
    CHECK(stats.calloc_calls == 0 && stats.realloc_calls == 0);
}

static void reject_unchanged(SSL *ssl)
{
    const PendingSnapshot before = capture(ssl);
    const HsFaultStats old = hs_fault_read();
    ERR_clear_error();
    hs_fault_arm(0);
    CHECK(!SSL_reserve_client_post_handshake_buffer(ssl));
    hs_fault_disarm();
    CHECK(ERR_peek_error() != 0);
    const PendingSnapshot after = capture(ssl);
    const HsFaultStats current = hs_fault_read();
    CHECK(memcmp(&before, &after, sizeof(before)) == 0);
    CHECK(memcmp(&old, &current, sizeof(old)) == 0);
    ERR_clear_error();
}

static void reserve(SSL *ssl, uint32_t maximum)
{
    const HsFaultStats before = hs_fault_read();
    hs_fault_arm(0);
    CHECK(SSL_reserve_client_post_handshake_buffer(ssl));
    hs_fault_disarm();
    const HsFaultStats after = hs_fault_read();
    CHECK(after.attempts == before.attempts + 2);
    CHECK(after.successful == before.successful + 2 && after.live == before.live + 2);
    const size_t logical = maximum + 3 + 16384;
    const size_t capacity = (logical + 3) / 3 * 4;
    CHECK(after.requested_bytes == before.requested_bytes + sizeof(BUF_MEM) + capacity + 16);
    auto *state = bssl::FromOpaque(ssl)->s3;
    CHECK(state->client_post_handshake_max_message_len == maximum);
    CHECK(state->hs_buf && state->hs_buf->length == 0 && state->hs_buf->max == capacity);
}

static void failure(char **arguments, size_t ordinal)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    hs_fault_reset();
    const PendingSnapshot before = capture(pair.client);
    hs_fault_arm(ordinal);
    CHECK(!SSL_reserve_client_post_handshake_buffer(pair.client));
    hs_fault_disarm();
    CHECK(ERR_peek_error() != 0);
    const PendingSnapshot after = capture(pair.client);
    CHECK(memcmp(&before, &after, sizeof(before)) == 0);
    const HsFaultStats stats = hs_fault_read();
    CHECK(stats.attempts == ordinal && stats.injected == 1);
    CHECK(stats.successful == ordinal - 1);
    CHECK(stats.live == 0 && stats.actual_frees == ordinal - 1);
    CHECK(stats.cleanse_failures == 0);
    ERR_clear_error();
    // Failure is atomic, so the same verified connection remains reservable.
    reserve(pair.client, 102400);
    destroy_pair(&pair);
    check_released(ordinal + 1);
}

static void idempotent(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    hs_fault_reset();
    reserve(pair.client, 102400);
    const PendingSnapshot before = capture(pair.client);
    const HsFaultStats old = hs_fault_read();
    hs_fault_arm(0);
    CHECK(SSL_reserve_client_post_handshake_buffer(pair.client));
    hs_fault_disarm();
    const PendingSnapshot after = capture(pair.client);
    const HsFaultStats current = hs_fault_read();
    CHECK(memcmp(&before, &after, sizeof(before)) == 0);
    CHECK(memcmp(&old, &current, sizeof(old)) == 0);
    destroy_pair(&pair);
    check_released(2);
}

static void fill_payload(uint8_t *bytes, size_t length)
{
    for (size_t index = 0; index < length; index++) bytes[index] = index * 13 + 7;
}

static void exchange(SSL *sender, SSL *receiver, size_t length, const uint8_t *existing = nullptr)
{
    uint8_t generated[4096];
    uint8_t output[sizeof(generated)];
    CHECK(length <= sizeof(generated));
    if (!existing) fill_payload(generated, length);
    const uint8_t *input = existing ? existing : generated;
    bool written = false;
    size_t received = 0;
    for (size_t iteration = 0; iteration < 100000 && (!written || received != length); iteration++) {
        if (!written) {
            const int result = SSL_write(sender, input, static_cast<int>(length));
            if (result > 0) {
                CHECK(static_cast<size_t>(result) == length);
                written = true;
            } else CHECK(retry(sender, result));
        }
        if (received < length) {
            const int result = SSL_read(receiver, output + received,
                static_cast<int>(length - received));
            if (result > 0) received += static_cast<size_t>(result);
            else CHECK(retry(receiver, result));
        }
    }
    CHECK(written && received == length && memcmp(input, output, length) == 0);
}

static void pending_plaintext(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    uint8_t input[128];
    uint8_t first = 0;
    fill_payload(input, sizeof(input));
    CHECK(SSL_write(pair.server, input, sizeof(input)) == static_cast<int>(sizeof(input)));
    CHECK(SSL_read(pair.client, &first, 1) == 1 && first == input[0]);
    CHECK(SSL_pending(pair.client) == static_cast<int>(sizeof(input) - 1));
    hs_fault_reset();
    reject_unchanged(pair.client);
    uint8_t rest[127];
    CHECK(SSL_read(pair.client, rest, sizeof(rest)) == static_cast<int>(sizeof(rest)));
    CHECK(memcmp(rest, input + 1, sizeof(rest)) == 0);
    reserve(pair.client, 102400);
    destroy_pair(&pair);
    check_released(2);
}

static void pending_record(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    uint8_t input[4096];
    uint8_t output[32];
    fill_payload(input, sizeof(input));
    int result = SSL_write(pair.server, input, sizeof(input));
    CHECK(result < 0 && SSL_get_error(pair.server, result) == SSL_ERROR_WANT_WRITE);
    result = SSL_read(pair.client, output, sizeof(output));
    CHECK(result < 0 && SSL_get_error(pair.client, result) == SSL_ERROR_WANT_READ);
    const auto *state = bssl::FromOpaque(pair.client)->s3;
    CHECK(state->read_buffer.size() > 0 && state->pending_app_data.empty());
    hs_fault_reset();
    reject_unchanged(pair.client);
    // Retry the same write and complete its verified plaintext after rejection.
    exchange(pair.server, pair.client, sizeof(input), input);
    reserve(pair.client, 102400);
    destroy_pair(&pair);
    check_released(2);
}

static void pending_write(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    uint8_t input[4096];
    fill_payload(input, sizeof(input));
    const int result = SSL_write(pair.client, input, sizeof(input));
    CHECK(result < 0 && SSL_get_error(pair.client, result) == SSL_ERROR_WANT_WRITE);
    const auto *state = bssl::FromOpaque(pair.client)->s3;
    CHECK(!state->pending_write.empty() && !state->write_buffer.empty());
    hs_fault_reset();
    reject_unchanged(pair.client);
    exchange(pair.client, pair.server, sizeof(input), input);
    reserve(pair.client, 102400);
    destroy_pair(&pair);
    check_released(2);
}

static void outgoing_key_update(char **arguments, bool backpressure)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    if (backpressure) {
        uint8_t bytes[1000];
        fill_payload(bytes, sizeof(bytes));
        CHECK(SSL_write(pair.client, bytes, sizeof(bytes)) == static_cast<int>(sizeof(bytes)));
    }
    CHECK(SSL_key_update(pair.client, SSL_KEY_UPDATE_NOT_REQUESTED));
    if (backpressure) {
        const int result = SSL_write(pair.client, nullptr, 0);
        CHECK(result < 0 && SSL_get_error(pair.client, result) == SSL_ERROR_WANT_WRITE);
    }
    const auto *state = bssl::FromOpaque(pair.client)->s3;
    CHECK(state->key_update_pending);
    CHECK((state->pending_hs_data && state->pending_hs_data->length != 0) ||
        (state->pending_flight && state->pending_flight->length != 0));
    if (backpressure) CHECK(state->pending_flight && state->pending_flight->length > state->pending_flight_offset);
    hs_fault_reset();
    reject_unchanged(pair.client);
    destroy_pair(&pair);
    check_released(0);
}

static void control_traffic(char **arguments, bool reverse)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    hs_fault_reset();
    if (reverse) exchange(pair.server, pair.client, 4096);
    else exchange(pair.client, pair.server, 4096);
    reserve(pair.client, 102400);
    destroy_pair(&pair);
    check_released(2);
}

static void excluded_configured(bool dtls, bool quic)
{
    SSL_CTX *context = SSL_CTX_new(dtls ? DTLS_method() : TLS_method());
    CHECK(context != nullptr);
    SSL *ssl = SSL_new(context);
    CHECK(ssl != nullptr);
    SSL_set_connect_state(ssl);
    if (quic) {
        static const SSL_QUIC_METHOD method = {};
        CHECK(SSL_set_quic_method(ssl, &method) && SSL_is_quic(ssl));
    }
    if (dtls) CHECK(SSL_is_dtls(ssl));
    hs_fault_reset();
    reject_unchanged(ssl);
    SSL_free(ssl);
    SSL_CTX_free(context);
    check_released(0);
}

static void excluded_pair(char **arguments, bool server)
{
    PeerPair pair = make_pair(arguments, server ? TLS1_3_VERSION : TLS1_2_VERSION, 1024);
    hs_fault_reset();
    reject_unchanged(server ? pair.server : pair.client);
    destroy_pair(&pair);
    check_released(0);
}

static void excluded_null(void)
{
    hs_fault_reset();
    hs_fault_arm(0);
    CHECK(!SSL_reserve_client_post_handshake_buffer(nullptr));
    hs_fault_disarm();
    CHECK(ERR_peek_error() != 0 && hs_fault_read().attempts == 0);
    check_released(0);
    ERR_clear_error();
}

static void shutdown_rejection(char **arguments, bool received)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    if (received) {
        CHECK(SSL_shutdown(pair.server) == 0);
        uint8_t byte;
        const int result = SSL_read(pair.client, &byte, 1);
        CHECK(result == 0 && SSL_get_error(pair.client, result) == SSL_ERROR_ZERO_RETURN);
    } else CHECK(SSL_shutdown(pair.client) == 0);
    hs_fault_reset();
    reject_unchanged(pair.client);
    destroy_pair(&pair);
    check_released(0);
}

static void clear_rehandshake(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    hs_fault_reset();
    reserve(pair.client, 102400);
    CHECK(SSL_clear(pair.client) && SSL_clear(pair.server));
    check_released(2);
    CHECK(bssl::FromOpaque(pair.client)->s3->client_post_handshake_max_message_len == 0);
    CHECK(!bssl::FromOpaque(pair.client)->s3->hs_buf);
    SSL_set_max_cert_list(pair.client, 200000);
    CHECK(SSL_get_max_cert_list(pair.client) == 200000);
    reject_unchanged(pair.client);
    SSL_set_max_cert_list(pair.client, 102400);
    CHECK(SSL_set_session(pair.client, nullptr));
    attach_bios(&pair, 1024);
    handshake(&pair, TLS1_3_VERSION);
    CHECK(!SSL_session_reused(pair.client));
    reserve(pair.client, 102400);
    exchange(pair.client, pair.server, 4096);
    exchange(pair.server, pair.client, 4096);
    destroy_pair(&pair);
    check_released(4);
}

static void lowered_ceiling(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    SSL_set_max_cert_list(pair.client, 1);
    hs_fault_reset();
    reserve(pair.client, 16384);
    CHECK(SSL_get_max_cert_list(pair.client) == 1);
    SSL_set_max_cert_list(pair.client, 200000);
    CHECK(SSL_get_max_cert_list(pair.client) == 16384);
    CHECK(SSL_CTX_get_max_cert_list(pair.client_context) == 102400);
    SSL_CTX_set_max_cert_list(pair.client_context, 200000);
    SSL *other = SSL_new(pair.client_context);
    CHECK(other && SSL_get_max_cert_list(other) == 200000);
    CHECK(SSL_get_max_cert_list(pair.client) == 16384);
    SSL_free(other);
    destroy_pair(&pair);
    check_released(2);
}

enum CaseId {
    failure_descriptor_case, failure_data_case, idempotent_case,
    pending_plaintext_case, pending_record_case, pending_write_case,
    queued_key_update_case, pending_flight_case, control_read_case, control_write_case,
    null_case, unfinished_case, dtls_case, quic_case, server_case, tls12_case,
    write_shutdown_case, read_shutdown_case, clear_rehandshake_case, lowered_ceiling_case,
    unknown_case,
};

struct CaseName {
    const char *name;
    CaseId id;
};

static CaseId parse_case(const char *name)
{
    static const CaseName names[] = {
        {"failure_descriptor", failure_descriptor_case}, {"failure_data", failure_data_case},
        {"idempotent", idempotent_case}, {"pending_plaintext", pending_plaintext_case},
        {"pending_record", pending_record_case}, {"pending_write", pending_write_case},
        {"queued_key_update", queued_key_update_case}, {"pending_flight", pending_flight_case},
        {"control_read", control_read_case}, {"control_write", control_write_case},
        {"null", null_case}, {"unfinished", unfinished_case}, {"dtls_configured", dtls_case},
        {"quic_configured", quic_case}, {"server", server_case}, {"tls12_complete", tls12_case},
        {"write_shutdown", write_shutdown_case}, {"read_shutdown", read_shutdown_case},
        {"clear_rehandshake", clear_rehandshake_case}, {"lowered_ceiling", lowered_ceiling_case},
    };
    for (const CaseName &entry : names) if (!strcmp(name, entry.name)) return entry.id;
    return unknown_case;
}

int main(int argc, char **argv)
{
    CHECK(argc == 5);
    CHECK(!SSL_reserve_client_post_handshake_buffer(nullptr));
    ERR_clear_error();
    switch (parse_case(argv[4])) {
        case failure_descriptor_case: failure(argv, 1); break;
        case failure_data_case: failure(argv, 2); break;
        case idempotent_case: idempotent(argv); break;
        case pending_plaintext_case: pending_plaintext(argv); break;
        case pending_record_case: pending_record(argv); break;
        case pending_write_case: pending_write(argv); break;
        case queued_key_update_case: outgoing_key_update(argv, false); break;
        case pending_flight_case: outgoing_key_update(argv, true); break;
        case control_read_case: control_traffic(argv, true); break;
        case control_write_case: control_traffic(argv, false); break;
        case null_case: excluded_null(); break;
        case unfinished_case: excluded_configured(false, false); break;
        case dtls_case: excluded_configured(true, false); break;
        case quic_case: excluded_configured(false, true); break;
        case server_case: excluded_pair(argv, true); break;
        case tls12_case: excluded_pair(argv, false); break;
        case write_shutdown_case: shutdown_rejection(argv, false); break;
        case read_shutdown_case: shutdown_rejection(argv, true); break;
        case clear_rehandshake_case: clear_rehandshake(argv); break;
        case lowered_ceiling_case: lowered_ceiling(argv); break;
        case unknown_case: CHECK(false); break;
    }
    const HsFaultStats stats = hs_fault_read();
    printf("{\"case\":\"%s\",\"pass\":true,\"attempts\":%llu,\"successful\":%llu,"
        "\"injected\":%llu,\"live\":%llu,\"actual_frees\":%llu,\"cleanse_failures\":%llu,"
        "\"calloc\":%llu,\"realloc\":%llu,\"requested_bytes\":%llu}\n", argv[4],
        static_cast<unsigned long long>(stats.attempts),
        static_cast<unsigned long long>(stats.successful),
        static_cast<unsigned long long>(stats.injected),
        static_cast<unsigned long long>(stats.live),
        static_cast<unsigned long long>(stats.actual_frees),
        static_cast<unsigned long long>(stats.cleanse_failures),
        static_cast<unsigned long long>(stats.calloc_calls),
        static_cast<unsigned long long>(stats.realloc_calls),
        static_cast<unsigned long long>(stats.requested_bytes));
}
