#include "hs_pair.h"

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

struct AllocationCounts {
    uint64_t malloc_calls;
    uint64_t calloc_calls;
    uint64_t realloc_calls;
    uint64_t free_calls;
    uint64_t bytes;
};

static AllocationCounts snapshot(void)
{
    return {uwz_alloc_malloc_calls(), uwz_alloc_calloc_calls(),
            uwz_alloc_realloc_calls(), uwz_alloc_free_calls(),
            uwz_alloc_requested_bytes()};
}

static bool zero_counts(const AllocationCounts *counts)
{
    return counts->malloc_calls == 0 && counts->calloc_calls == 0 &&
        counts->realloc_calls == 0 && counts->free_calls == 0 && counts->bytes == 0;
}

static void fill_frame(uint8_t *frame, size_t body_length)
{
    frame[0] = SSL3_MT_NEWSESSION_TICKET;
    frame[1] = (body_length >> 16) & 255;
    frame[2] = (body_length >> 8) & 255;
    frame[3] = body_length & 255;
    for (size_t index = 0; index < body_length; index++) frame[4 + index] = index * 13 + 7;
}

static void append(bssl::SSLImpl *ssl, const uint8_t *bytes, size_t length)
{
    CHECK(bssl::tls_append_handshake_data(ssl, bssl::Span<const uint8_t>(bytes, length)));
}

static void consume(bssl::SSLImpl *ssl, const uint8_t *frame, size_t length)
{
    bssl::SSLMessage message;
    CHECK(bssl::tls_get_message(ssl, &message));
    CHECK(CBS_len(&message.raw) == length);
    CHECK(memcmp(CBS_data(&message.raw), frame, length) == 0);
    const size_t old_length = ssl->s3->hs_buf->length;
    bssl::tls_next_message(ssl);
#if UWZ_HS_RESERVATION
    CHECK(ssl->s3->hs_buf);
    for (size_t index = ssl->s3->hs_buf->length; index < old_length; index++) {
        CHECK(ssl->s3->hs_buf->data[index] == 0);
    }
#else
    (void)old_length;
#endif
}

static void repeated_fragments(bssl::SSLImpl *ssl)
{
    uint8_t first[1028];
    uint8_t second[36];
    fill_frame(first, 1024);
    fill_frame(second, 32);
    for (size_t iteration = 0; iteration < 64; iteration++) {
        const size_t split = 1 + iteration % 3;
        append(ssl, first, split);
        bssl::SSLMessage message;
        CHECK(!bssl::tls_get_message(ssl, &message));
        append(ssl, first + split, 4 - split);
        CHECK(!bssl::tls_get_message(ssl, &message));
        append(ssl, first + 4, 513);
        CHECK(!bssl::tls_get_message(ssl, &message));
        append(ssl, first + 517, sizeof(first) - 517);
        append(ssl, second, 3);
        consume(ssl, first, sizeof(first));
        CHECK(ssl->s3->hs_buf && ssl->s3->hs_buf->length == 3);
        CHECK(memcmp(ssl->s3->hs_buf->data, second, 3) == 0);
        append(ssl, second + 3, sizeof(second) - 3);
        consume(ssl, second, sizeof(second));
    }
}

static void maximum_record_slack(bssl::SSLImpl *ssl, size_t maximum)
{
    uint8_t bytes[118787];
    CHECK(maximum == 102400);
    fill_frame(bytes, maximum);
    fill_frame(bytes + maximum + 4, 16379);
    append(ssl, bytes, maximum + 3);
    uint8_t alert = 0;
    CHECK(bssl::tls_can_accept_handshake_data(ssl, &alert));
    append(ssl, bytes + maximum + 3, 16384);
    CHECK(ssl->s3->hs_buf->length == sizeof(bytes));
    CHECK(memcmp(ssl->s3->hs_buf->data, bytes, sizeof(bytes)) == 0);
    consume(ssl, bytes, maximum + 4);
    consume(ssl, bytes + maximum + 4, 16383);
}

int main(int argc, char **argv)
{
    CHECK(argc == 5);
    const bool require_zero = strcmp(argv[4], "--require-zero") == 0;
    CHECK(require_zero || strcmp(argv[4], "--observe") == 0);
    CHECK(uwz_alloc_self_test());
    PeerPair pair = make_pair(argv, TLS1_3_VERSION, 1024);
    auto *ssl = bssl::FromOpaque(pair.client);
    CHECK(!ssl->s3->hs_buf);
    CHECK(SSL_get_max_cert_list(pair.client) == 102400);
#if UWZ_HS_RESERVATION
    CHECK(SSL_reserve_client_post_handshake_buffer(pair.client));
    CHECK(ssl->s3->hs_buf && ssl->s3->hs_buf->length == 0);
    const BUF_MEM *descriptor = ssl->s3->hs_buf.get();
    const char *data = descriptor->data;
    const size_t capacity = descriptor->max;
    CHECK(capacity == 158384);
#endif
    uwz_alloc_begin();
    repeated_fragments(ssl);
    maximum_record_slack(ssl, 102400);
#if UWZ_HS_RESERVATION
    CHECK(SSL_reserve_client_post_handshake_buffer(pair.client));
#endif
    uwz_alloc_end();
    const AllocationCounts counts = snapshot();
#if UWZ_HS_RESERVATION
    CHECK(ssl->s3->hs_buf.get() == descriptor);
    CHECK(ssl->s3->hs_buf->data == data && ssl->s3->hs_buf->max == capacity);
    CHECK(ssl->s3->hs_buf->length == 0);
#else
    CHECK(!ssl->s3->hs_buf);
#endif
    printf("{\"scope\":\"internal_handshake_buffer_helpers_after_verified_TLS13\","
           "\"reserved\":%s,\"sizeof_ssl3_state\":%zu,\"fragment_loops\":64,"
           "\"maximum_appended_bytes\":118787,\"malloc\":%llu,\"calloc\":%llu,"
           "\"realloc\":%llu,\"free\":%llu,\"bytes\":%llu,\"payloads_valid\":true}\n",
#if UWZ_HS_RESERVATION
           "true",
#else
           "false",
#endif
           sizeof(bssl::SSL3_STATE),
           static_cast<unsigned long long>(counts.malloc_calls),
           static_cast<unsigned long long>(counts.calloc_calls),
           static_cast<unsigned long long>(counts.realloc_calls),
           static_cast<unsigned long long>(counts.free_calls),
           static_cast<unsigned long long>(counts.bytes));
    destroy_pair(&pair);
    if (require_zero && !zero_counts(&counts)) return 1;
    return 0;
}
