#!/usr/bin/env python3
"""Replay fixed native handshake-buffer witnesses without a compiler or native libraries."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from run_lifecycle import CASES


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pki-tool', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    output = args.output.absolute()
    tool = args.pki_tool.resolve(strict=True)
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent replay output directory')
    if output.resolve().is_relative_to(base):
        raise ValueError('Keep replay output outside the retained evidence tree')
    if sha(tool) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('PKI helper checksum differs')
    identity = json.loads((base / 'prebuilt_identity.json').read_text())
    expected = {'baseline_final/hs_buffer_helper', 'candidate_initial/hs_buffer_helper',
        'lifecycle_complete/hs_lifecycle', 'inherited_record/lifecycle_test',
        'inherited_record/buffer_test', 'inherited_record/tls_pair_test',
        'inherited_hkdf/results/hkdf_witness'}
    if set(identity['binaries']) != expected:
        raise ValueError('Unexpected retained binary inventory')
    for name, checksum in identity['binaries'].items():
        if sha(base / name) != checksum:
            raise ValueError('Retained binary checksum differs: ' + name)
    output.mkdir(mode=0o700, parents=True)
    records = []
    complete = False

    def run(command, stem, expected_status=0):
        with (output / (stem + '.stdout')).open('wb') as stdout, \
             (output / (stem + '.stderr')).open('wb') as stderr:
            result = subprocess.run(command, cwd=output, stdout=stdout, stderr=stderr)
        records.append({'command': command, 'exit_code': result.returncode,
                        'expected_exit_code': expected_status, 'stem': stem})
        if result.returncode != expected_status:
            raise RuntimeError('Command failed: ' + stem)

    pki = output / 'private_pki'
    try:
        run([str(tool), 'pki', str(pki)], 'pki_metadata')
        arguments = [str(pki / name) for name in ['server.pem', 'server.key', 'ca.pem']]
        run([str(base / 'baseline_final/hs_buffer_helper'), *arguments, '--require-zero'], 'baseline', 1)
        run([str(base / 'candidate_initial/hs_buffer_helper'), *arguments, '--require-zero'], 'candidate')
        for name, retained in [('baseline', 'baseline_final'), ('candidate', 'candidate_initial')]:
            actual = json.loads((output / (name + '.stdout')).read_text())
            expected_row = json.loads((base / retained / 'observe.stdout').read_text())
            if actual != expected_row:
                raise ValueError('Direct helper outcome differs: ' + name)
        expected_rows = {row['case']: row['result'] for row in
            json.loads((base / 'lifecycle_complete/results.json').read_text())['rows']}
        for name in CASES:
            stem = 'lifecycle_' + name
            run([str(base / 'lifecycle_complete/hs_lifecycle'), *arguments, name], stem)
            actual = json.loads((output / (stem + '.stdout')).read_text())
            if actual != expected_rows[name]:
                raise ValueError('Lifecycle outcome differs: ' + name)
        run([sys.executable, str(base / 'inherited_record/run_cases.py'), '--pki', str(pki),
             '--output', str(output / 'inherited_record')], 'inherited_record')
        actual_record = json.loads((output / 'inherited_record/results.json').read_text())
        expected_record = json.loads((base / 'inherited_record/results/results.json').read_text())
        if [row['result'] for row in actual_record['rows']] != [
                row['result'] for row in expected_record['rows']]:
            raise ValueError('Inherited record lifecycle outcomes differ')
        run([str(base / 'inherited_record/buffer_test')], 'buffer_test')
        run([str(base / 'inherited_record/tls_pair_test'), *arguments], 'tls_pair_test')
        run([str(base / 'inherited_hkdf/results/hkdf_witness'), '--require-zero'], 'hkdf')
        run([sys.executable, str(base / 'inherited_hkdf/compare_results.py'),
             str(base / 'inherited_hkdf/prior_baseline.stdout'), str(output / 'hkdf.stdout')],
            'hkdf_differential')
        complete = True
    finally:
        if pki.exists():
            names = {p.name for p in pki.iterdir()}
            if names - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected private fixture output; refusing broad cleanup')
            for name in names:
                (pki / name).unlink()
            pki.rmdir()
        (output / 'results.json').write_text(json.dumps({'complete': complete,
            'commands': records, 'private_pki_removed': not pki.exists(),
            'native_source_archives_or_compiler_required': False,
            'strict_postgresql_gate_closed': False}, indent=2) + '\n')
    print('PASS: direct helper RED/GREEN, 21 reservation cases, 16 inherited record cases, 2 inherited helpers and 1440 HKDF differential cases; private PKI removed')


if __name__ == '__main__':
    main()
