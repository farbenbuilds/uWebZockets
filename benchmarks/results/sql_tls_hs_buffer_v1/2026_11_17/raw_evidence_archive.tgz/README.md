# Bounded incoming client handshake storage

This isolated native proposal adds explicit startup reservation for an idle,
completed ordinary TLS 1.3 client. Captured message ceiling M bounds logical
storage L=M+3+16384; default M=102400 gives L=118787 and rounded data A=158384.
Startup adds two C allocations requesting 158424 bytes; SSL3_STATE grows by 8 bytes.
The setter clamp, fixed append ceiling, consumed-tail cleansing and SSL_clear
reset keep the opt-in bounded. Production pins and the strict PostgreSQL
request-path allocation gate remain unchanged.

After extracting into a fresh directory, verify and replay from this directory:

```sh
sha256sum -c files.sha256
python3 restore_pki_tool.py /absolute/path/to/uWebZockets
python3 helper/replay_prebuilt.py --pki-tool tools/wt-tools --output /tmp/uwz-hs-helper-replay
python3 wire/replay_prebuilt.py --pki-tool tools/wt-tools --output /tmp/uwz-hs-wire-replay
```

Choose absent external replay directories. The checksum-pinned PKI executable
is restored from the existing repository artifact; no network, native archives
or compiler is required. Both replays verify exact binary inventories and
remove their owned private PKI. Root's successful copied-layout runs are under
root_checks/helper_delivery_replay and root_checks/wire_delivery_replay.

The helper replay requires baseline RED and candidate GREEN, 21 new reservation
cases, 16 inherited record cases, two old buffer/record helpers and 1440 HKDF
cases. The wire replay compares 24 public-control rows and 36 encrypted rows
with exact payload/callback bytes, retries, errors and allocator counters.
These are distinct helper and encrypted-peer scopes, not PostgreSQL queries.
Residual ticket/session, AEAD, flight and error/reconnect allocations persist.

Read native/HANDOFF.md for the four-file source delta, complete native build
and source restoration modes. Root verifies both original pinned package and
prior-HKDF inputs against all 8709 final entries; read
root_checks/source_restore_results.json. Earlier checker/fixture corrections
are explicitly classified as preliminary. external_inputs.json distinguishes
inherited historical identities from current native and final fixture hashes.

Actual full-allocation cleansing/free observations use the default OPENSSL/glibc
path, not custom allocator-hook verification or whole-process leak proof.
Root's ordinary SQL-enabled suite passed 1158 tests; 24 live PostgreSQL cases
skipped without required fixture settings. Dedicated smoke/security/sanitizer/
fuzz/scan campaigns remain user-deferred; no PostgreSQL exception, FIPS
certification or full allocation-gate closure is claimed.
