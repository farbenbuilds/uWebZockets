# Independent crypto review: retained client post-handshake buffer

Date: 2026-11-17. Read-only review of the isolated native proposal, helper/lifecycle proof and encrypted/public-control evidence. No source, test, documentation, package, pin or production policy was changed by this reviewer. No runtime proofs, builds, scans or deferred campaigns were repeated. Cross-model skipped: non-interactive context.

## Verdict

No confirmed native correctness, bounds, ownership, lifetime, compatibility or security defect remains in the reviewed candidate. The initial lifecycle proof omitted fatal-read-error eligibility; the verifier added a real encrypted fatal-alert case and reran all 21 final cases. That coverage gap is closed without changing native source.

This removes incoming handshake-assembly allocation for the explicit reserved client profile. It does not establish zero PostgreSQL request-path allocation, approve a PostgreSQL exception, change production TLS policy, or provide FIPS certification. The governing requirement remains no request-path allocation after startup, rather than an invented whole-TLS-lifetime zero-allocation rule.

## Exact implementation scope

Baseline: `/tmp/uwz-pg-tls-hkdf-fixed-20261117/boringssl`, exact pinned BoringSSL `d3bf4795ad5b79d646cddf2fec687da5b9b502db` plus the earlier record-retention and fixed-HKDF proposals. Candidate: `/tmp/uwz-pg-tls-hs-buffer-fixed-20261117/boringssl`.

Independently hashed both complete source trees: 8709 files each, identical file sets, exactly four changed files. The frozen patch SHA256 is `d928317a494c1577cdccb357dca2ad262860c95604e632eb0f7bf338d7aebc0d`.

| Candidate file | SHA256 |
| --- | --- |
| `include/openssl/ssl.h` | `506c697179b06466535a7d124894908d57a40307f9e97e7e62db65966ee6f935` |
| `ssl/internal.h` | `ec0daf18b92e68778546b008aedda0d1fb0da8b0b996b267a12ec38e963cc9e8` |
| `ssl/ssl_lib.cc` | `db7d44e596d92593443d5d947f2cd7b75f66de5efef88a41452cab6a90745484` |
| `ssl/s3_both.cc` | `be5891112e943ceca48a9c0ffda5ad5b004cb50cebb4e3408a3280f9f663f9a3` |

The old record-reservation API and its buffer implementation remain unchanged. Fixed HKDF SHA256 remains `abce47c85d1ee69e68e748b5e67159dd3514899e437fe60421a15f83264236a2`.

The complete native rebuild log records 6/6 successful steps with crypto and all 38 SSL translation units rebuilt together. All final fixture provenance uses `libssl.a` SHA256 `56a2bb22d7767cb72b626061f2c0ca22dff1305b140d471535bc2df0a00a6876` and `libcrypto.a` SHA256 `c1b0def642ff320a36360a16dbb0967fa020fc64ac7b92fc8203119adf1f9012`. The added field changes measured `sizeof(SSL3_STATE)` from 600 to 608 bytes; no mixed-layout object substitution is used.

## Bound, eligibility and lifetime review

References below are relative to the candidate native tree.

- `SSL_reserve_client_post_handshake_buffer` (`ssl/ssl_lib.cc:771`) accepts only completed ordinary TLS 1.3 clients in the documented idle state. It rejects null/missing state, servers, DTLS, QUIC, initialization, read/write shutdown or error, pending plaintext/record/write/unreported-write data, complete/incomplete handshake data, alerts, queued key update and outgoing handshake/flight data. Certificate and name verification remain caller prerequisites; the API does not claim to perform those checks itself.
- The captured `M=max(16384,max_cert_list)` is stored as a nonzero `uint32_t` profile marker (`ssl/internal.h:2964`). Public max-cert-list settings are already bounded to 24 bits. Thus `L=M+3+16384` and BUF_MEM's rounded capacity fit the supported arithmetic, including 32-bit `size_t`.
- The ordinary accepted-append bound is sound: before another record, an incomplete head has at most `M+3` buffered bytes, or at most three bytes before its header is known. Native TLS 1.3 record content contributes at most 16384 more bytes. Default `M=102400` therefore gives logical `L=118787`; BUF_MEM rounding gives physical `A=158384`. Coalesced complete heads/trailing fragments are included in this argument, rather than assuming only one message per record.
- `tls_append_handshake_data` (`ssl/s3_both.cc:455`) checks the logical limit with subtraction before calling the unchanged append helper. It also requires an existing descriptor and capacity at least L. Over-limit input cannot wrap an addition, change buffered bytes/length, allocate a replacement or use the larger rounded A as extra logical room. For an intact profile, `BUF_MEM_append` sees sufficient existing capacity and cannot grow.
- Reservation allocates a fresh temporary descriptor and data before committing either the buffer or captured ceiling. Failure leaves prior buffers/configuration unchanged; temporary ownership is released normally. This intentionally differs from the old record-reservation API's documented partial-reservation failure contract. The latter is not weakened.
- `SSL_set_max_cert_list` (`ssl/ssl_lib.cc:1795`) clamps reserved-mode increases to captured M, reports the effective value through the existing getter and permits lowering/re-raising within M. The context setter does not mutate an existing SSL value. `SSL_set_SSL_CTX` also does not assign `max_cert_list`. The captured ceiling cannot increase through those ordinary public configuration paths until a successful clear destroys the profile.
- `tls_next_message` (`ssl/s3_both.cc:544`) moves only the unconsumed suffix, then cleanses exactly the vacated tail. The cleanse ends at the prior logical length and does not erase retained trailing fragments. Empty opted-in buffers remain owned; unreserved release behavior is preserved.
- Audited all native `hs_buf` assignments/resets. The server V2ClientHello and handshake-hint paths are outside this established client profile. Initial-handshake cleanup runs before handshake finalization/initial-complete eligibility. `SSL_clear` destroys and recreates SSL3_STATE, releasing the buffer and resetting its default-zero marker together. Connect/accept state setters do not independently reset this buffer, and context replacement does not bypass the ceiling.
- Destruction uses upstream BUF_MEM/OPENSSL_free ownership. `crypto/mem.cc:236` cleanses the full default allocation before actual libc free; its documented custom-hook contract at `:85` assigns equivalent zeroing responsibility to custom `OPENSSL_memory_free` implementations. Actual cleansing/free observations here cover the default OPENSSL/glibc build, not independent custom-hook verification.

## Direct helper and lifecycle evidence

Proof root: `/tmp/uwz-pg-tls-hs-buffer-verify-20261117`.

The original all-C measurement interposer remains byte-identical, SHA256 `afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac`, including its 63-byte self-test. The separate fault observer is not substituted into ordinary measurements.

The final direct-helper source is `hs_buffer_helper.cc`, SHA256 `daea58b2b66d9e6b7aa2a24ca8529019d3d55029cec7b2a672c2a6b17f967a4c`. Both builds use the same final source with reservation disabled/enabled. The baseline strict assertion exits 1 with 258 malloc, 258 non-null free and 272600 requested bytes. Candidate strict assertion exits 0 with zero malloc/calloc/realloc/free/requested bytes in the append/consume interval; startup separately measures 2 malloc and 158424 requested bytes. This includes allocator prefixes, distinct from logical L and physical data A.

The helper starts from an actual CA/name-verified TLS 1.3 pair, then directly invokes canonical buffer/framing helpers. Its framing contents are not a peer-protocol acceptance claim. It covers 64 fragmented/coalesced loops, exact L, L+1/A+1/partial-buffer overflow rejection with full-byte/pointer/length/capacity preservation, tail cleansing, idempotence and setter/context behavior. Deliberate unused-capacity seeding occurs only in this direct-helper scope. Error state is primed before the measured guard checks; no first-use error-allocation guarantee follows.

`lifecycle_complete/` is authoritative: independently checked all 21 command statuses, parsed results and stdout/stderr hashes, plus final source provenance. Cases cover both allocation failures, successful same-SSL retry after atomic failure, idempotence, real unread plaintext/incomplete ciphertext/backpressured writes, queued key update/partially flushed flight, protocol/role/initialization exclusions, close_notify, fatal read error, minimum M/context independence and clear/re-handshake/re-reservation.

The added fatal case uses public `SSL_send_fatal_alert`, then genuine client `SSL_read` to enter saved `ssl_shutdown_error`. Rejected reservation makes zero allocations and preserves the saved-error pointer and state; a subsequent read still fails closed. No private flags are written to manufacture that state.

The fault observer fills tracked raw allocations nonzero, observes every byte zero before forwarding actual `__libc_free`, and tracks allocation epochs with fixed thread-local storage. The final results have no outstanding tracked ownership or cleanse failures. This proves tracked descriptor/data ownership, not leak freedom for every process allocation.

The preliminary pending-flight generator failure is correctly preserved as a fixture-generation correction, not a native fix. Its corrected case uses public key update and real BIO saturation plus canonical internal `tls_flush`, retaining the flight/state assertions. It does not claim public-only peer acceptance. The 20-case intermediate run is separately classified; native code never changed in response.

Unchanged inherited proofs were rebuilt against the same complete new archives: sixteen record-retention lifecycle cases, 256 buffer iterations and seven record sizes through 16384 pass. Independently checked inherited case statuses/result hashes. The unchanged HKDF fixture still matches all 1440 prior baseline semantic fields/full-buffer hashes, with all 700 successful calls counting zero heap operations. Configured DTLS/QUIC negatives remain distinct from completed protocol interoperability.

## Encrypted and public-control evidence

Wire root: `/tmp/uwz-pg-tls-hs-wire-20261117`. Final exact-byte wire fixture SHA256 is `72a2cf70a37090d5b4910acc0ffba83dc7fc6bd49cbe4cfa79ef6315d7d047c5`.

The wire fixture seals real records using the genuine server SSL's native `tls_seal_record`, delivers ciphertext through BIOs and runs the unmodified client parser. It is explicitly internal peer-construction machinery, separate from the public-API-only control fixture. Client private observations are read-only. Fixed callbacks compare complete received control bytes against known server plaintext; callback observation alone is not semantic acceptance, so successful cases also require exact following application payloads and malformed cases require the expected fatal error.

All three variants have twelve rows/383 client reads: prior HKDF baseline, new candidate unreserved, and new candidate reserved. Independently reconciled operation totals and compared the complete result/error/reason sequences, callback/type/length/byte observations, payload outcomes and logical peaks. The reserved profile preserves protocol outcomes; the unreserved candidate also preserves baseline allocation rows. The near-limit encrypted case reaches L=118787 exactly, retains A=158384 and stable storage, accepts both complete tickets and delivers all 4096 following application bytes. Actual partial encrypted-handshake delivery also proves rejected reservation preserves state before valid continuation.

The public control fixture changes only by the conditional startup opt-in outside accounting. Both variants have twelve rows/255 operations. The candidate's stable client-read vectors are:

| Client interval | malloc | non-null free | Requested bytes |
| --- | ---: | ---: | ---: |
| Ticket-free payload | 0 | 0 | 0 |
| Two initially queued tickets, cache OFF | 12 | 12 | 1600 |
| Peer KeyUpdate NOT_REQUESTED | 1 | 1 | 608 |
| Peer KeyUpdate REQUESTED | 7 | 5 | 1416 |
| Following response/application writes | 0 | 2 | 0 |

All calloc/realloc counts remain zero. These are synthetic client-call measurements, not PostgreSQL query counts. They retain real verification, control processing, peer response and payload checks. Residual ticket/session, AEAD replacement, response-flight and error allocations remain; no full gate closure follows.

## Replay and remaining delivery scope

The helper and wire prebuilt wrappers were read for exact binary/PKI identities, absent external output paths, expected subprocess statuses, retained-result comparison and bounded named-file PKI cleanup in finally blocks. No confirmed defect was found in those reviewed flows. Helper replay covers its seven executables and all 21/16/helper/HKDF assertions; wire replay covers five executables and both public/all three encrypted variants. Their producers retain successful replay/refusal records; this reviewer did not rerun them.

The native restoration helper verifies the full expected input set/hashes and cumulative snapshots before copying into an absent destination and modifies only the copied snapshot files. Root's final source-restoration/copy-layout verification and final combined archive/outer checksum manifests were still being assembled at report time. Bind final packaging to these exact native/fixture hashes, preserve the classified preliminary records, omit private PKI, and verify final manifests after incorporating this report. Any later edited wrapper or prose bytes need their normal final artifact check.

Production integration, maintained native adoption, remaining request-path allocation sites and error/reconnect attribution remain incomplete. No PostgreSQL allocation exception is approved. Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain user-deferred.
