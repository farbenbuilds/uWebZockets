# Bounded client post-handshake buffer proposal

This isolated native proposal adds SSL_reserve_client_post_handshake_buffer.
It does not change the existing record reservation API or adopt a native pin,
fork or production integration. The input is exact BoringSSL revision
d3bf4795ad5b79d646cddf2fec687da5b9b502db with the prior record-buffer and fixed
HKDF proposals. The original package identity is retained in input_provenance.json.

## Implementation and bounds

The new API accepts only an idle completed ordinary TLS 1.3 client. It rejects
null, unfinished, server, TLS 1.2, DTLS and QUIC states; shutdown/error, pending
application or handshake plaintext, input/output records, writes, messages,
alerts, updates and outgoing flights are rejected before reservation. Peer CA
and hostname verification remain caller prerequisites.

The first successful call captures M=max(16384, max_cert_list). A fresh temporary
BUF_MEM descriptor and data allocation are committed only after both succeed;
allocation failure preserves the old connection buffers and configuration.
Repeated idle calls are allocation-free and retain the first ceiling. The
single nonzero client_post_handshake_max_message_len member marks this opt-in.
SSL_set_max_cert_list clamps increases to M, exposes the effective value via
its existing getter and allows lowering/re-raising within M. The context setter
is unchanged. SSL_clear destroys the state and removes the clamp.

The logical append limit L=M+3+16384 includes an incomplete head and a whole
record's plaintext. Default M=102400 gives L=118787. BUF_MEM_reserve rounds the
data allocation to A=158384. The reserved append path checks L, safe subtraction
and installed capacity before calling BUF_MEM_append, so it cannot grow into
the allocator's extra slack. It does not impose a new handshake header parser
limit or claim separate complete oversized-head validation. Consuming a message
cleanses the vacated tail and retains an empty reserved buffer. Generic buffers
keep their previous allocation and release behavior. Under the observed default
OPENSSL/glibc allocator path, existing OPENSSL_free cleanses owned allocations
when SSL_free or SSL_clear destroys the buffer. Custom allocator-hook behavior
is outside that cleansing evidence.

Exactly four files differ from the preceding HKDF proposal among 8709 source
entries: ssl.h, internal.h, ssl_lib.cc and s3_both.cc. The cumulative proposal
differs in six unique files from the original package. The fixed HKDF hash stays
abce47c85d1ee69e68e748b5e67159dd3514899e437fe60421a15f83264236a2.
source_difference.json and both complete source inventories record the current
delta; provenance.json records the cumulative delta and all six snapshots.

## Evidence ownership

Root authorized source edits only after the independent verifier's real verified
TLS 1.3 baseline reproduced 258 malloc/free pairs and 272600 requested bytes
across 64 fragment/coalescing loops and near-M/final-record slack. Its unchanged
require-zero assertion exited one; observe mode exited zero and the unchanged
63-byte interposer self-test passed. Baseline SSL3_STATE measured 600 bytes.

The entire native crypto library and all 38 SSL translation units were rebuilt
together through the unchanged Zig 0.16.0 source-list builder. The process exited
zero, with all six build steps succeeding. build_commands.json records the exact
command, compiler and input hashes; build-native.log and native_archives.json
record its output and actual archive identities. Debug archive hashes are
path-dependent provenance, not portable rebuild requirements.

Functional reservation/lifecycle and real encrypted wire tests are owned by the
companion verification agents. Their retained commands, raw outputs, counters and
terminal results are authoritative; this implementation payload does not replace
them. The independent reviewer owns source and evidence review.

The independent helper component test reports default startup cost of two C
malloc calls and 158424 requested bytes: a 24-byte descriptor plus its 8-byte
allocator prefix, and 158384 data bytes plus an 8-byte prefix. Other allocation
counter fields were zero. SSL3_STATE grows from 600 to 608 bytes, including for
connections that do not enable the profile. After reservation, its 64 fragment/
coalescing loops, near-M/final-full-record slack, append-limit overflow controls,
setter/idempotence/tail-cleansing and complete-message rejection checks report
zero heap calls. Lifecycle and encrypted-wire terminal statuses remain with
their companion evidence owners.

## Source restoration

The delivery allowlist retains source snapshots, the four-file patch, full
inventories, provenance, build inputs and logs. It excludes the full native copy,
native archives, caches, generated private PKI and test secrets.

From a copied payload directory, restore the exact original package into an
absent destination and build with Zig 0.16.0:

    python3 restore_source.py /path/to/exact-original-package ./boringssl
    /path/to/zig build -Doptimize=Debug --cache-dir /tmp/new-hs-buffer-cache \
      -p native_out -j2 --summary all

The exact preceding HKDF proposal is accepted only with explicit
--source-kind hkdf. Both modes check the full expected old file set and hashes
and all six candidate snapshots before writing the new directory. Existing
destinations are refused, cached input is never modified and no patch executable
is required. Python prepares external evidence; it is not a library build
dependency. The source-list build compiles all native SSL units together.

restore_validation.json records one successful HKDF-input restoration with exact
8709-entry candidate equality, an existing-destination rejection and rejection
of HKDF input presented as the original package. The owned generated source copy
was removed. A successful original-package mode in the final delivery layout
remains Root's validation responsibility.

## Remaining scope

This proposal addresses the incoming handshake-buffer allocation component.
Other allocations in AEAD replacement, session tickets, outgoing flights, errors
and reconnects remain separate work. SQL-ALLOC-002 and the PostgreSQL zero-
allocation gate stay open. No PostgreSQL allocation exception, whole-lifetime
allocation guarantee, FIPS certification or production integration is claimed.
Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain user-deferred.
