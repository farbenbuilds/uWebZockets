const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const dependency = b.dependency("uwebzockets", .{
        .target = target,
        .optimize = optimize,
        .sql = true,
    });
    const module = dependency.module("uWebZockets");
    const root = b.createModule(.{
        .root_source_file = b.path("probe.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
        .unwind_tables = .sync,
        .omit_frame_pointer = false,
    });
    root.addImport("uWebZockets", module);
    root.addImport("xev", module.import_table.get("xev").?);
    const translated = b.addTranslateC(.{
        .root_source_file = b.path("allocation_trace.h"),
        .target = target,
        .optimize = optimize,
    });
    root.addImport("allocation_trace", translated.createModule());
    root.addCSourceFile(.{
        .file = b.path("allocation_trace.c"),
        .flags = &.{ "-std=c11", "-Wall", "-Wextra", "-Werror", "-fno-builtin-malloc", "-fno-builtin-calloc", "-fno-builtin-realloc", "-fno-builtin-free", "-funwind-tables", "-fno-omit-frame-pointer", "-fno-optimize-sibling-calls" },
    });
    const executable = b.addExecutable(.{ .name = "sql_tls_lifecycle_inventory", .root_module = root });
    b.installArtifact(executable);
}
