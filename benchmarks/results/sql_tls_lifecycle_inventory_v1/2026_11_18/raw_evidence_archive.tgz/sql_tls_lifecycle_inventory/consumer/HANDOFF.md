# Allocation lifetime inventory consumer

Frozen build-only author handoff. ReleaseSafe build passed19/19 steps;
`final_build.log` is the canonical serialized final build. No fixture was
launched, no credentials were read, and the author did not run the consumer or
either self-test. Root owns runtime and independent source/evidence review.

Executable: `zig-out/bin/sql_tls_lifecycle_inventory`, SHA256
`7a136325ed43576ea63bf8ae1ffcf3ef4165a9ee57123398da34f4e6ada181ee`.
`identity.json` binds all source, build, ABI documentation and binary hashes.
`inventory.patch` is relative to the frozen lifecycle consumer, SHA256
`d680defece96a66b484841a8f0594f2349666a107997cdfd8888bc302c2e8120`.

The original C source remains byte-exact afd763bd..., including allocator
bodies/counters/self-test. The original lifecycle core from App/constants
through the six scenario/interval functions and Report remains byte-identical,
SHA256 `ce1d2928c4203aff2a1fca8dc6f60311bd8097f0cf2a10ecbf3d879b891c687e`.
Only private observer C/header, normal build-time header translation and probe
observer setup/teardown/output/validation are added. No SDK, native source,
original producer, tracked source, pins or root artifact was changed.

Build command from this directory:

```sh
/tmp/zig-x86_64-linux-0.16.0/zig build -Doptimize=ReleaseSafe --cache-dir /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-preparation-integration-20261117/consumer-cache --global-cache-dir /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-preparation-integration-20261117/global-cache --summary all
```

Root runs with the existing trusted fixture PG environment, unchanged
`UWZ_SQL_LIFECYCLE_OUTPUT`, plus explicit `UWZ_SQL_TRACE_HEADER` and
`UWZ_SQL_TRACE_EVENTS` output paths under its owned SSD workspace. Also set
`UWZ_SQL_TRACE_CONTROL` to the independently run original control lifecycle
JSON from this exact fixture. The named schema validates all six completed
scenarios, original interval, functional success and strict RED before either
self-test/observer installation. Owned startup bytes/parsed storage stay live
through final exact per-round five-field comparison, with a SHA256/path binding
in trace_header.json. Do not print
the environment or credentials. `ABI.md` defines every binary field, scope,
statistic, size semantic and limitation. The caller supplies18MiB of startup
event storage:32768records of576bytes,64raw frames each. Header ABI size168,
version1, little endian, pointer size8. Header JSON and binary contain addresses
and sizes only; no allocation contents are read or written.

Original self-test precedes installation. The public-wrapper self-test remains
visible as scope1 with five allocation events/63bytes plus begin/end. Scopes2..7
are the six original worker intervals. Recursion may suppress recursive
unwinding only; the original counts/route and operation event remain. Any
overflow/recursive/truncated/missing stack or boundary rejects required trace
completeness. App/SQL teardown occurs before observer stop; dumping follows stop
and inactive counters. Uninstalled threads and post-main thread destructors are
outside the declared worker observation boundary.

Root runtime acceptance requires both self-tests, six functional rounds,
complete trace, seven total scopes and exact equality against all five fields
of every paired original control round, including requested bytes. Observer-induced native allocations are never filtered from
original counters; a vector change fails explicitly. Only after these checks
does the original strict NonZeroLifecycleAllocations result describe a genuine
RED. No successful runtime/counter-neutrality or allocation-gate completion is
claimed from the build alone. Broad campaigns remain deferred.

The first live attempt is retained unchanged in Root-owned run_control/ and
run_trace/. Root reported6/6 functional rounds,15357events and zero missing,
truncated, overflow or recursive-unwind statistics. Both original control and
trace actually matched exactly: failure268malloc/2calloc/0realloc/270free/412766B;
cancel536/4/0/540/825532B. The new fixture CA common name changed native requested
bytes from the prior fixture totals412698/825396, so the first hardcoded byte
comparison incorrectly returned TraceObserverChangedAllocationVector. This was
a fixture/setup comparison defect; the guard is corrected to require a
read-once paired original control and still checks every operation/byte field.
No raw first-attempt evidence or original control binary/counter was changed.
The old generation source/identity/docs are retained as .first_attempt copies;
Root froze binary801eb508... for symbolizing those original trace addresses.
