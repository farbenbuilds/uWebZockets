/* Test-only observer. All allocation decisions remain in the unchanged counter. */
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <errno.h>
#include <unwind.h>
#include "allocation_trace.h"

#if !defined(__linux__) || !defined(__GLIBC__) || UINTPTR_MAX != UINT64_MAX
#error This inventory requires 64-bit Linux glibc.
#endif
#if __BYTE_ORDER__ != __ORDER_LITTLE_ENDIAN__
#error This inventory ABI requires little endian.
#endif

_Static_assert(sizeof(UwzTraceEvent) == 576, "event ABI size");
_Static_assert(offsetof(UwzTraceEvent, operation) == 560, "event ABI offsets");
_Static_assert(sizeof(UwzTraceHeader) == 168, "header ABI size");
_Static_assert(offsetof(UwzTraceHeader, event_count) == 40, "header ABI offsets");

#define malloc uwz_counted_malloc
#define calloc uwz_counted_calloc
#define realloc uwz_counted_realloc
#define free uwz_counted_free
#define uwz_alloc_begin uwz_counted_alloc_begin
#define uwz_alloc_end uwz_counted_alloc_end
#include "allocation_scope.c"
#undef malloc
#undef calloc
#undef realloc
#undef free
#undef uwz_alloc_begin
#undef uwz_alloc_end

typedef struct TraceBinding {
    UwzTraceHeader *header;
    UwzTraceEvent *events;
    uint64_t scope;
    int unwinding;
} TraceBinding;

/* The existing counter and this explicit caller-buffer binding are thread-local. */
static _Thread_local TraceBinding binding;

static _Unwind_Reason_Code warm_frame(struct _Unwind_Context *context, void *argument)
{
    volatile uintptr_t *last = argument;
    *last = _Unwind_GetIP(context);
    return _URC_NO_REASON;
}

void uwz_trace_prewarm(void)
{
    volatile uintptr_t last = 0;
    (void)_Unwind_Backtrace(warm_frame, (void *)&last);
}

static _Unwind_Reason_Code capture_frame(struct _Unwind_Context *context, void *argument)
{
    UwzTraceEvent *event = argument;
    const uintptr_t ip = _Unwind_GetIP(context);
    if (ip == 0) return _URC_NO_REASON;
    if (event->frame_count == UWZ_TRACE_FRAME_CAPACITY) {
        event->flags |= UWZ_TRACE_TRUNCATED;
        return _URC_NORMAL_STOP;
    }
    event->frames[event->frame_count++] = (uint64_t)ip;
    return _URC_NO_REASON;
}

static __attribute__((noinline)) void capture_stack(UwzTraceEvent *event)
{
    if (binding.unwinding) {
        binding.header->recursive_events++;
        event->flags |= UWZ_TRACE_RECURSIVE;
        return;
    }
    binding.unwinding = 1;
    const _Unwind_Reason_Code result = _Unwind_Backtrace(capture_frame, event);
    binding.unwinding = 0;
    if (event->flags & UWZ_TRACE_TRUNCATED) binding.header->truncated_stacks++;
    else if (result != _URC_END_OF_STACK && result != _URC_NO_REASON) {
        binding.header->unwind_failures++;
        event->flags |= UWZ_TRACE_UNWIND_FAILED;
    }
    if (event->frame_count != 0) return;
    binding.header->empty_stacks++;
    event->flags |= UWZ_TRACE_EMPTY_STACK;
}

static __attribute__((noinline)) void record_event(uint32_t operation, uint64_t pointer,
    uint64_t old_pointer, uint64_t size, uint64_t count, uint64_t scope)
{
    UwzTraceHeader *header = binding.header;
    if (header == NULL) return;
    if (header->event_count == header->event_capacity) {
        header->overflow_events++;
        return;
    }
    const uint64_t index = header->event_count++;
    UwzTraceEvent *event = &binding.events[index];
    memset(event, 0, sizeof(*event));
    event->sequence = index;
    event->scope = scope;
    event->pointer = pointer;
    event->old_pointer = old_pointer;
    event->size = size;
    event->count = count;
    event->operation = operation;
    event->active = active != 0;
    if (operation <= UWZ_TRACE_FREE) capture_stack(event);
}

__attribute__((noinline)) void *malloc(size_t size)
{
    void *pointer = uwz_counted_malloc(size);
    const int saved_errno = errno;
    if (binding.header != NULL && pointer == NULL) binding.header->null_allocations++;
    record_event(UWZ_TRACE_MALLOC, (uintptr_t)pointer, 0, size, 1, active ? binding.scope : 0);
    errno = saved_errno;
    return pointer;
}

__attribute__((noinline)) void *calloc(size_t count, size_t size)
{
    void *pointer = uwz_counted_calloc(count, size);
    const int saved_errno = errno;
    if (binding.header != NULL && pointer == NULL) binding.header->null_allocations++;
    if (binding.header != NULL && size != 0 && count > SIZE_MAX / size) binding.header->calloc_overflows++;
    record_event(UWZ_TRACE_CALLOC, (uintptr_t)pointer, 0, size, count, active ? binding.scope : 0);
    errno = saved_errno;
    return pointer;
}

__attribute__((noinline)) void *realloc(void *pointer, size_t size)
{
    const uintptr_t old_pointer = (uintptr_t)pointer;
    void *replacement = uwz_counted_realloc(pointer, size);
    const int saved_errno = errno;
    if (binding.header != NULL && replacement == NULL && size != 0) binding.header->null_allocations++;
    record_event(UWZ_TRACE_REALLOC, (uintptr_t)replacement, old_pointer, size, 1, active ? binding.scope : 0);
    errno = saved_errno;
    return replacement;
}

__attribute__((noinline)) void free(void *pointer)
{
    const uintptr_t old_pointer = (uintptr_t)pointer;
    uwz_counted_free(pointer);
    const int saved_errno = errno;
    if (binding.header != NULL && old_pointer == 0) binding.header->free_nulls++;
    record_event(UWZ_TRACE_FREE, old_pointer, 0, 0, 0, active ? binding.scope : 0);
    errno = saved_errno;
}

void uwz_alloc_begin(void)
{
    const int already_active = active;
    uwz_counted_alloc_begin();
    if (binding.header == NULL) return;
    if (already_active) binding.header->invalid_boundaries++;
    binding.scope = ++binding.header->scope_count;
    binding.header->active_scope = binding.scope;
    record_event(UWZ_TRACE_SCOPE_BEGIN, 0, 0, 0, 0, binding.scope);
}

void uwz_alloc_end(void)
{
    const int was_active = active;
    uwz_counted_alloc_end();
    if (binding.header == NULL) return;
    if (!was_active) binding.header->invalid_boundaries++;
    record_event(UWZ_TRACE_SCOPE_END, 0, 0, 0, 0, binding.scope);
    binding.header->active_scope = 0;
}

int uwz_trace_install(UwzTraceHeader *header, UwzTraceEvent *events, size_t capacity)
{
    if (header == NULL || events == NULL || capacity == 0 || binding.header != NULL || active) return 0;
    if (capacity > SIZE_MAX / sizeof(*events)) return 0;
    memset(header, 0, sizeof(*header));
    memset(events, 0, capacity * sizeof(*events));
    memcpy(header->magic, "UWZATRC1", 8);
    header->abi_version = UWZ_TRACE_ABI_VERSION;
    header->endian_word = UINT32_C(0x01020304);
    header->pointer_size = sizeof(void *);
    header->event_size = sizeof(*events);
    header->header_size = sizeof(*header);
    header->frame_capacity = UWZ_TRACE_FRAME_CAPACITY;
    header->event_capacity = capacity;
    header->selftest_scope = 1;
    header->request_first_scope = 2;
    binding = (TraceBinding){ .header = header, .events = events };
    record_event(UWZ_TRACE_START, 0, 0, 0, 0, 0);
    return 1;
}

int uwz_trace_self_test(void)
{
    if (binding.header == NULL || active) return 0;
    UwzTraceHeader *header = binding.header;
    const uint64_t first_event = header->event_count;
    uwz_alloc_begin();
    void *first = malloc(17);
    void *second = calloc(3, 5);
    if (first == NULL || second == NULL) abort();
    ((volatile unsigned char *)first)[0] = 1;
    ((volatile unsigned char *)second)[0] = 2;
    first = realloc(first, 31);
    if (first == NULL) abort();
    free(first);
    free(second);
    uwz_alloc_end();
    if (uwz_alloc_malloc_calls() != 1 || uwz_alloc_calloc_calls() != 1 ||
        uwz_alloc_realloc_calls() != 1 || uwz_alloc_free_calls() != 2 || uwz_alloc_requested_bytes() != 63) return 0;
    if (header->event_count != first_event + 7 || header->scope_count != 1) return 0;
    const UwzTraceEvent *events = binding.events + first_event;
    const uint32_t operations[7] = { UWZ_TRACE_SCOPE_BEGIN, UWZ_TRACE_MALLOC, UWZ_TRACE_CALLOC,
        UWZ_TRACE_REALLOC, UWZ_TRACE_FREE, UWZ_TRACE_FREE, UWZ_TRACE_SCOPE_END };
    for (size_t i = 0; i < 7; i++) {
        if (events[i].operation != operations[i] || events[i].scope != 1 || events[i].flags != 0) return 0;
        if (events[i].active != (i != 6)) return 0;
        if (i > 0 && i < 6 && events[i].frame_count == 0) return 0;
    }
    if (events[1].size != 17 || events[2].count != 3 || events[2].size != 5 || events[3].size != 31) return 0;
    if (events[3].old_pointer != events[1].pointer || events[4].pointer != events[3].pointer || events[5].pointer != events[2].pointer) return 0;
    header->selftest_passed = 1;
    return 1;
}

void uwz_trace_stop(void)
{
    if (binding.header == NULL) return;
    if (active || binding.header->active_scope != 0) binding.header->invalid_boundaries++;
    record_event(UWZ_TRACE_STOP, 0, 0, 0, 0, 0);
    binding.header->stopped = 1;
    binding = (TraceBinding){0};
}
