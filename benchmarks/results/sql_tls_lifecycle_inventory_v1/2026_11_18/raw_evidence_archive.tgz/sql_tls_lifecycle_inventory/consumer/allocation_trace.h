#ifndef UWZ_ALLOCATION_TRACE_H
#define UWZ_ALLOCATION_TRACE_H

#include <stdint.h>
#include <stddef.h>

#define UWZ_TRACE_ABI_VERSION 1
#define UWZ_TRACE_FRAME_CAPACITY 64
#define UWZ_TRACE_EVENT_CAPACITY 32768

enum UwzTraceOperation {
    UWZ_TRACE_MALLOC = 1,
    UWZ_TRACE_CALLOC = 2,
    UWZ_TRACE_REALLOC = 3,
    UWZ_TRACE_FREE = 4,
    UWZ_TRACE_SCOPE_BEGIN = 5,
    UWZ_TRACE_SCOPE_END = 6,
    UWZ_TRACE_START = 7,
    UWZ_TRACE_STOP = 8
};

enum UwzTraceFlags {
    UWZ_TRACE_RECURSIVE = 1,
    UWZ_TRACE_TRUNCATED = 2,
    UWZ_TRACE_UNWIND_FAILED = 4,
    UWZ_TRACE_EMPTY_STACK = 8
};

/* All integer words are little endian. Unused frames and padding stay zero. */
typedef struct UwzTraceEvent {
    uint64_t sequence;
    uint64_t scope;
    uint64_t pointer;
    uint64_t old_pointer;
    uint64_t size;
    uint64_t count;
    uint64_t frames[UWZ_TRACE_FRAME_CAPACITY];
    uint32_t operation;
    uint32_t active;
    uint32_t frame_count;
    uint32_t flags;
} UwzTraceEvent;

typedef struct UwzTraceHeader {
    uint8_t magic[8];
    uint32_t abi_version;
    uint32_t endian_word;
    uint32_t pointer_size;
    uint32_t event_size;
    uint32_t header_size;
    uint32_t frame_capacity;
    uint64_t event_capacity;
    uint64_t event_count;
    uint64_t scope_count;
    uint64_t active_scope;
    uint64_t selftest_scope;
    uint64_t request_first_scope;
    uint64_t overflow_events;
    uint64_t recursive_events;
    uint64_t truncated_stacks;
    uint64_t unwind_failures;
    uint64_t empty_stacks;
    uint64_t null_allocations;
    uint64_t free_nulls;
    uint64_t calloc_overflows;
    uint64_t invalid_boundaries;
    uint64_t selftest_passed;
    uint64_t stopped;
} UwzTraceHeader;

void uwz_trace_prewarm(void);
int uwz_trace_install(UwzTraceHeader *header, UwzTraceEvent *events, size_t capacity);
int uwz_trace_self_test(void);
void uwz_trace_stop(void);

#endif
