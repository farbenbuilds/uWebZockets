//! Worker-wide lifecycle attribution; the established-query probe stays separate.
const std = @import("std");
const uz = @import("uWebZockets");
const xev = @import("xev");
const trace = @import("allocation_trace");

extern fn uwz_alloc_begin() callconv(.c) void;
extern fn uwz_alloc_end() callconv(.c) void;
extern fn uwz_alloc_malloc_calls() callconv(.c) u64;
extern fn uwz_alloc_calloc_calls() callconv(.c) u64;
extern fn uwz_alloc_realloc_calls() callconv(.c) u64;
extern fn uwz_alloc_free_calls() callconv(.c) u64;
extern fn uwz_alloc_requested_bytes() callconv(.c) u64;
extern fn uwz_alloc_malloc_site(index: c_uint) callconv(.c) u64;
extern fn uwz_alloc_self_test() callconv(.c) c_int;

const App = uz.ConfiguredAppWithTimeout(1, 1024, 4096, 0);
const round_count = 6;
const watchdog_ms = 30_000;
const Scenario = enum { failure_reconnect, deadline_cancel };
const Stage = enum { startup, running, settling, done };
const Role = enum { long, target, queued };

const Allocation = struct {
    mallocs: u64 = 0,
    callocs: u64 = 0,
    reallocs: u64 = 0,
    frees: u64 = 0,
    bytes: u64 = 0,
    site_0: u64 = 0,
    site_1: u64 = 0,

    fn snapshot() Allocation {
        return .{
            .mallocs = uwz_alloc_malloc_calls(),
            .callocs = uwz_alloc_calloc_calls(),
            .reallocs = uwz_alloc_realloc_calls(),
            .frees = uwz_alloc_free_calls(),
            .bytes = uwz_alloc_requested_bytes(),
            .site_0 = uwz_alloc_malloc_site(0),
            .site_1 = uwz_alloc_malloc_site(1),
        };
    }

    fn zero(self: Allocation) bool {
        return self.mallocs == 0 and self.callocs == 0 and self.reallocs == 0 and self.frees == 0 and self.bytes == 0;
    }
};

/// Captured at callback entry before inspecting borrowed rows; no owned strings.
const CallbackSnapshot = struct {
    observed: bool = false,
    role: Role = .long,
    order: usize = 0,
    at_ms: u64 = 0,
    failure: ?[]const u8 = null,
    long_running: bool = false,
    request_idle: bool = false,
    slot_index: usize = 0,
    lease_generation: u64 = 0,
    connection_phase: []const u8 = "unobserved",
    connection_ssl_null: bool = false,
    connection_network_bio_null: bool = false,
    tls_prepared: bool = false,
    backend_pid: u32 = 0,
    pool: uz.sql.pool.Stats = .{},
    allocations: Allocation = .{},
};

const Round = struct {
    scenario: Scenario = .failure_reconnect,
    started_ms: u64 = 0,
    ended_ms: u64 = 0,
    scope_complete: bool = false,
    initial_waiting: bool = false,
    target_index: usize = 0,
    old_pid: u32 = 0,
    new_pid: u32 = 0,
    old_generation: u64 = 0,
    new_generation: u64 = 0,
    target_prepared_before: bool = false,
    reconnect_prepared: bool = false,
    queued_assignment_while_long_running: bool = false,
    aux_prepared_observed: bool = false,
    aux_cancel_sent: bool = false,
    cancel_requests_before: u64 = 0,
    cancel_requests_after: u64 = 0,
    cancel_failures_before: u64 = 0,
    cancel_failures_after: u64 = 0,
    reconnects_before: u64 = 0,
    reconnects_after: u64 = 0,
    allocations: Allocation = .{},
    callbacks: [3]CallbackSnapshot = [_]CallbackSnapshot{.{}} ** 3,
};

const Slot = struct {
    owner: *Probe = undefined,
    role: Role,
    query: uz.sql.Query = undefined,
    index: usize = 0,
    generation: u64 = 0,
};

const Probe = struct {
    app: *App,
    sql: uz.sql.Sql,
    slots: [3]Slot = .{ .{ .role = .long }, .{ .role = .target }, .{ .role = .queued } },
    rounds: [round_count]Round = [_]Round{.{}} ** round_count,
    held: [6]uz.sql.Lease = undefined,
    timer: ?xev.Timer = null,
    completion: xev.Completion = .{},
    cancel_completion: xev.Completion = .{},
    stage: Stage = .startup,
    round_index: usize = 0,
    rounds_started: usize = 0,
    callbacks: usize = 0,
    holds: usize = 0,
    watchdog_deadline: u64 = 0,
    failure: ?anyerror = null,
    scope_active: bool = false,
    timer_active: bool = false,

    fn hooks(self: *Probe) uz.modules.ServiceHooks {
        return .{ .name = "sql_lifecycle_probe", .context = self, .start = start, .stop = stop, .deinit = deinit };
    }

    fn start(context: *anyopaque, _: *const uz.modules.WorkerContext) uz.modules.ServiceError!void {
        const self: *Probe = @ptrCast(@alignCast(context));
        self.timer = xev.Timer.init() catch return error.Unexpected;
        self.sql.db.diagnostics = .{ .trace_context = self, .trace = on_trace };
        for (&self.slots) |*slot| slot.owner = self;
        self.watchdog_deadline = self.now_ms() + watchdog_ms;
        self.arm();
    }

    fn arm(self: *Probe) void {
        std.debug.assert(!self.timer_active);
        self.timer_active = true;
        self.timer.?.run(self.app.loop.get_xev_loop(), &self.completion, 1, Probe, self, on_tick);
    }

    fn on_tick(user_data: ?*Probe, _: *xev.Loop, _: *xev.Completion, result: xev.Timer.RunError!void) xev.CallbackAction {
        const self = user_data.?;
        self.timer_active = false;
        result catch |err| {
            self.fail(err);
            return .disarm;
        };
        if (self.stage == .done) return .disarm;
        if (self.now_ms() >= self.watchdog_deadline) {
            self.fail(error.LifecycleWatchdogExpired);
            return .disarm;
        }
        if (self.stage == .running) self.observe_cancel();
        if (self.stage == .startup and self.sql.db.ready()) self.launch() catch |err| self.fail(err);
        if (self.stage == .settling and self.sql.db.ready() and self.aux_drained()) self.next() catch |err| self.fail(err);
        if (self.stage != .done) self.arm();
        return .disarm;
    }

    fn launch(self: *Probe) !void {
        for (&self.held) |*lease| {
            lease.* = try self.sql.db.acquire();
            self.holds += 1;
        }
        try self.begin_round();
    }

    fn begin_round(self: *Probe) !void {
        const scenario: Scenario = if (self.round_index < 3) .failure_reconnect else .deadline_cancel;
        self.rounds[self.round_index] = .{
            .scenario = scenario,
            .started_ms = self.now_ms(),
            .cancel_requests_before = self.sql.db.cancel_requests,
            .cancel_failures_before = self.sql.db.cancel_failures,
            .reconnects_before = self.sql.db.pool.reconnects,
        };
        self.callbacks = 0;
        self.rounds_started += 1;
        self.stage = .running;
        self.watchdog_deadline = self.now_ms() + watchdog_ms;
        self.slots[0].query = .{
            .statement = .{ .name = "lifecycle_long", .sql = "SELECT 42::int4 FROM pg_sleep(0.5)" },
            .context = &self.slots[0],
            .callback = on_query,
        };
        self.slots[1].query = .{
            .statement = .{
                .name = if (scenario == .failure_reconnect) "lifecycle_terminate" else "lifecycle_cancel",
                .sql = if (scenario == .failure_reconnect) "SELECT pg_terminate_backend(pg_backend_pid())" else "SELECT 42::int4 FROM pg_sleep(30)",
            },
            .deadline_ms = if (scenario == .deadline_cancel) self.now_ms() + 50 else 0,
            .context = &self.slots[1],
            .callback = on_query,
        };
        self.slots[2].query = .{
            .statement = .{ .name = "lifecycle_queued", .sql = "SELECT 42::int4" },
            .context = &self.slots[2],
            .callback = on_query,
        };
        self.scope_active = true;
        uwz_alloc_begin();
        // Includes synchronous submission writes and all overlapping lifecycle work.
        for (&self.slots) |*slot| self.sql.db.query(&slot.query) catch |err| on_query(slot, .{ .failure = err });
        self.rounds[self.round_index].initial_waiting = self.slots[2].query.state == .waiting and self.sql.db.pool.stats().waiting == 1;
    }

    fn on_trace(context: *anyopaque, event: uz.sql.TraceEvent) void {
        if (event.phase != .begin) return;
        const self: *Probe = @ptrCast(@alignCast(context));
        if (self.stage != .running) return;
        for (&self.slots) |*slot| {
            if (!std.mem.eql(u8, slot.query.statement.name, event.statement_name)) continue;
            const lease = slot.query.lease orelse return;
            slot.index = lease.index;
            slot.generation = lease.generation;
            const connection = &self.sql.db.connections[lease.index];
            const round = &self.rounds[self.round_index];
            if (slot.role == .target) {
                round.target_index = lease.index;
                round.old_pid = connection.backend_pid;
                round.old_generation = lease.generation;
                round.target_prepared_before = connection.tls_prepared;
            }
            if (slot.role == .queued) {
                round.new_pid = connection.backend_pid;
                round.new_generation = lease.generation;
                round.reconnect_prepared = connection.tls_prepared;
                round.queued_assignment_while_long_running = self.slots[0].query.state == .running;
            }
            return;
        }
    }

    fn on_query(context: *anyopaque, outcome: uz.sql.QueryOutcome) void {
        const slot: *Slot = @ptrCast(@alignCast(context));
        const self = slot.owner;
        // Final callback entry is the fixed end of this worker-wide interval.
        if (self.scope_active and self.callbacks == 2) {
            uwz_alloc_end();
            self.scope_active = false;
        }
        self.complete(slot, outcome);
    }

    fn complete(self: *Probe, slot: *Slot, outcome: uz.sql.QueryOutcome) void {
        if (self.stage != .running) return;
        const round = &self.rounds[self.round_index];
        const connection = &self.sql.db.connections[slot.index];
        const index = @intFromEnum(slot.role);
        if (round.callbacks[index].observed) {
            self.fail(error.DuplicateCallback);
            return;
        }
        round.callbacks[index] = .{
            .observed = true,
            .role = slot.role,
            .order = self.callbacks,
            .at_ms = self.now_ms(),
            .failure = if (outcome == .failure) @errorName(outcome.failure) else null,
            .long_running = self.slots[0].query.state == .running,
            .request_idle = slot.query.state == .idle,
            .slot_index = slot.index,
            .lease_generation = slot.generation,
            .connection_phase = @tagName(connection.phase),
            .connection_ssl_null = connection.session.ssl == null,
            .connection_network_bio_null = connection.session.network_bio == null,
            .tls_prepared = connection.tls_prepared,
            .backend_pid = connection.backend_pid,
            .pool = self.sql.db.pool.stats(),
            .allocations = Allocation.snapshot(),
        };
        self.callbacks += 1;
        self.validate_callback(slot.role, outcome) catch |err| {
            if (self.failure == null) self.failure = err;
        };
        self.observe_cancel();
        if (self.callbacks != 3) return;
        round.ended_ms = self.now_ms();
        round.scope_complete = !self.scope_active;
        round.allocations = Allocation.snapshot();
        round.cancel_requests_after = self.sql.db.cancel_requests;
        round.cancel_failures_after = self.sql.db.cancel_failures;
        round.reconnects_after = self.sql.db.pool.reconnects;
        self.validate_round() catch |err| {
            if (self.failure == null) self.failure = err;
        };
        self.stage = .settling;
    }

    fn validate_callback(self: *Probe, role: Role, outcome: uz.sql.QueryOutcome) !void {
        const round = &self.rounds[self.round_index];
        const snapshot = round.callbacks[@intFromEnum(role)];
        if (!snapshot.request_idle) return error.CallbackRequestNotRetired;
        if (role == .target) {
            const expected: uz.sql.RuntimeError = if (round.scenario == .failure_reconnect) error.ConnectionClosed else error.QueryTimeout;
            if (outcome != .failure or outcome.failure != expected) return error.UnexpectedTargetOutcome;
            if (!snapshot.connection_ssl_null or !snapshot.connection_network_bio_null or snapshot.tls_prepared) return error.FailedSessionNotDestroyed;
            if (!std.mem.eql(u8, snapshot.connection_phase, "dormant")) return error.FailedSocketNotRetired;
            if (!snapshot.long_running or snapshot.pool.waiting != 1 or snapshot.pool.failed != 1) return error.FailureOverlapMissing;
            return;
        }
        if (outcome != .success) return outcome.failure;
        var rows = outcome.success.rows;
        const row = (try rows.next()) orelse return error.MissingResult;
        if (try row.get(i32, 0) != 42 or try rows.next() != null) return error.InvalidResult;
        if (!snapshot.tls_prepared) return error.UnpreparedResult;
        if (role == .queued and !snapshot.long_running) return error.ReconnectOverlapMissing;
    }

    fn validate_round(self: *Probe) !void {
        const round = &self.rounds[self.round_index];
        if (!round.initial_waiting or !round.scope_complete) return error.WorkerScopeIncomplete;
        if (!round.target_prepared_before or !round.reconnect_prepared) return error.PreparationMissing;
        if (round.old_pid == 0 or round.new_pid == 0 or round.old_pid == round.new_pid) return error.BackendNotReplaced;
        if (round.new_generation <= round.old_generation) return error.LeaseGenerationNotReplaced;
        if (self.slots[2].index != round.target_index) return error.WaiterUsedWrongSlot;
        if (!round.queued_assignment_while_long_running) return error.WaiterAssignmentOverlapMissing;
        if (round.reconnects_after != round.reconnects_before + 1) return error.UnexpectedReconnectCount;
        if (round.cancel_failures_after != round.cancel_failures_before) return error.AuxiliaryCancellationFailed;
        const expected_cancels: u64 = if (round.scenario == .deadline_cancel) 1 else 0;
        if (round.cancel_requests_after != round.cancel_requests_before + expected_cancels) return error.UnexpectedCancelCount;
        if (round.scenario == .deadline_cancel and !round.aux_cancel_sent) return error.CancelRequestNotSent;
    }

    fn observe_cancel(self: *Probe) void {
        const round = &self.rounds[self.round_index];
        const cancel = &self.sql.db.cancel_connections[round.target_index];
        round.aux_prepared_observed = round.aux_prepared_observed or cancel.tls_prepared;
        round.aux_cancel_sent = round.aux_cancel_sent or cancel.cancel_sent;
    }

    fn aux_drained(self: *const Probe) bool {
        for (self.sql.db.cancel_connections) |*connection| {
            if (connection.phase != .dormant) return false;
        }
        return true;
    }

    fn next(self: *Probe) !void {
        self.round_index += 1;
        if (self.failure != null or self.round_index == round_count) {
            for (self.held[0..self.holds]) |lease| try self.sql.db.release(lease);
            self.holds = 0;
            self.stage = .done;
            self.app.request_shutdown();
            return;
        }
        try self.begin_round();
    }

    fn fail(self: *Probe, failure: anyerror) void {
        if (self.scope_active) {
            uwz_alloc_end();
            self.scope_active = false;
            self.rounds[self.round_index].allocations = Allocation.snapshot();
        }
        if (self.failure == null) self.failure = failure;
        self.stage = .done;
        self.app.request_shutdown();
    }

    fn now_ms(self: *const Probe) u64 {
        return @intCast(@divTrunc(std.Io.Clock.awake.now(self.app.io).nanoseconds, std.time.ns_per_ms));
    }

    fn stop(context: *anyopaque, _: *const uz.modules.WorkerContext) void {
        const self: *Probe = @ptrCast(@alignCast(context));
        if (self.scope_active) self.fail(error.InterruptedWorkerScope);
        if (!self.timer_active) return;
        self.timer.?.cancel(self.app.loop.get_xev_loop(), &self.completion, &self.cancel_completion, Probe, self, on_cancel);
    }

    fn on_cancel(user_data: ?*Probe, _: *xev.Loop, _: *xev.Completion, result: xev.CancelError!void) xev.CallbackAction {
        const self = user_data.?;
        result catch |err| {
            if (err != error.NotFound and self.failure == null) self.failure = err;
        };
        self.timer_active = false;
        return .disarm;
    }

    fn deinit(context: *anyopaque) void {
        const self: *Probe = @ptrCast(@alignCast(context));
        if (self.timer) |*timer| timer.deinit();
        self.timer = null;
    }
};

fn config(init: std.process.Init) !uz.sql.Config {
    const env = init.environ_map;
    const ca = env.get("PGSSLROOTCERT") orelse return error.SqlCaRequired;
    return .{
        .host = env.get("PGHOST") orelse "127.0.0.1",
        .port = try std.fmt.parseInt(u16, env.get("PGPORT") orelse "5432", 10),
        .user = env.get("PGUSER") orelse "postgres",
        .database = env.get("PGDATABASE") orelse "postgres",
        .password = env.get("PGPASSWORD") orelse "",
        .tls = .{
            .ca_path = try init.arena.allocator().dupeZ(u8, ca),
            .server_name = env.get("PGSSLSERVERNAME") orelse "127.0.0.1",
        },
        .statement_cache_entries = 32,
        .limits = .{ .max_message_bytes = 64 * 1024, .max_response_bytes = 64 * 1024 },
    };
}

const Report = struct {
    interval: []const u8 = "worker first Db.query submission through final callback entry; includes overlapping close/reconnect/cancel",
    expected_rounds: usize = round_count,
    completed_rounds: usize,
    functional_failure: ?[]const u8,
    strict_zero: bool,
    rounds: []const Round,
};

const TraceReport = struct {
    format: []const u8 = "UWZ allocation lifetime trace v1; little-endian fixed 576-byte events",
    unwind: []const u8 = "pinned Zig unwind.h _Unwind_Backtrace; raw return addresses include observer frames",
    scope_mapping: []const u8 = "scope0 startup/teardown; scope1 five-event63-byte selftest; scopes2..7 six unchanged lifecycle intervals",
    thread_coverage: []const u8 = "explicit buffer on main App.run worker thread; uninstalled threads are outside this worker inventory",
    control_path: []const u8,
    control_sha256: []const u8,
    header: trace.UwzTraceHeader,
};

/// Exact counter fields from the independently run original lifecycle consumer.
const ControlAllocation = struct {
    mallocs: u64,
    callocs: u64,
    reallocs: u64,
    frees: u64,
    bytes: u64,
};

const ControlRound = struct {
    scenario: Scenario,
    scope_complete: bool,
    allocations: ControlAllocation,
};

const ControlReport = struct {
    interval: []const u8,
    expected_rounds: usize,
    completed_rounds: usize,
    functional_failure: ?[]const u8,
    strict_zero: bool,
    rounds: [round_count]ControlRound,
};

/// Parsed control strings borrow the explicitly retained startup input bytes.
const ControlInput = struct {
    bytes: []u8,
    parsed: std.json.Parsed(ControlReport),
    digest: [32]u8,
    path: []const u8,

    fn load(allocator: std.mem.Allocator, io: std.Io, path: []const u8) !ControlInput {
        const bytes = try std.Io.Dir.cwd().readFileAlloc(io, path, allocator, .limited(1024 * 1024));
        errdefer allocator.free(bytes);
        const parsed = try std.json.parseFromSlice(ControlReport, allocator, bytes, .{ .ignore_unknown_fields = true });
        errdefer parsed.deinit();
        try validate_control(parsed.value);
        var digest: [32]u8 = undefined;
        std.crypto.hash.sha2.Sha256.hash(bytes, &digest, .{});
        return .{ .bytes = bytes, .parsed = parsed, .digest = digest, .path = path };
    }

    fn deinit(self: *ControlInput, allocator: std.mem.Allocator) void {
        self.parsed.deinit();
        allocator.free(self.bytes);
    }
};

fn validate_control(control: ControlReport) !void {
    if (control.expected_rounds != round_count or control.completed_rounds != round_count or
        control.functional_failure != null or control.strict_zero) return error.InvalidTraceControlCompletion;
    const original: Report = .{ .completed_rounds = round_count, .functional_failure = null, .strict_zero = false, .rounds = &.{} };
    if (!std.mem.eql(u8, control.interval, original.interval)) return error.InvalidTraceControlInterval;
    var nonzero = false;
    for (control.rounds, 0..) |round, index| {
        const expected: Scenario = if (index < 3) .failure_reconnect else .deadline_cancel;
        if (round.scenario != expected or !round.scope_complete) return error.InvalidTraceControlScenario;
        const allocation = round.allocations;
        nonzero = nonzero or allocation.mallocs != 0 or allocation.callocs != 0 or allocation.reallocs != 0 or allocation.frees != 0 or allocation.bytes != 0;
    }
    if (!nonzero) return error.InvalidTraceControlAllocationResult;
}

fn validate_trace(header: trace.UwzTraceHeader) !void {
    if (header.selftest_passed != 1 or header.stopped != 1 or header.active_scope != 0 or header.scope_count != 7) return error.TraceScopeIncomplete;
    if (header.overflow_events != 0 or header.recursive_events != 0 or header.truncated_stacks != 0 or
        header.unwind_failures != 0 or header.empty_stacks != 0 or header.invalid_boundaries != 0) return error.TraceFramesIncomplete;
}

fn validate_control_vectors(control: ControlReport, rounds: []const Round) !void {
    if (rounds.len != control.rounds.len) return error.TraceControlRoundMismatch;
    for (rounds, control.rounds) |round, reference| {
        if (round.scenario != reference.scenario) return error.TraceControlScenarioMismatch;
        const allocation = round.allocations;
        const expected = reference.allocations;
        if (allocation.mallocs != expected.mallocs or allocation.callocs != expected.callocs or allocation.reallocs != expected.reallocs or
            allocation.frees != expected.frees or allocation.bytes != expected.bytes) return error.TraceObserverChangedAllocationVector;
    }
}

fn dump_trace(init: std.process.Init, header_path: []const u8, events_path: []const u8, header: trace.UwzTraceHeader, events: []const trace.UwzTraceEvent, control: *const ControlInput) !void {
    var storage: [8192]u8 = undefined;
    var writer = std.Io.Writer.fixed(&storage);
    var json: std.json.Stringify = .{ .writer = &writer, .options = .{ .whitespace = .indent_2 } };
    const control_digest = std.fmt.bytesToHex(control.digest, .lower);
    try json.write(TraceReport{ .header = header, .control_path = control.path, .control_sha256 = &control_digest });
    const header_file = try std.Io.Dir.cwd().createFile(init.io, header_path, .{});
    defer header_file.close(init.io);
    try header_file.writeStreamingAll(init.io, writer.buffered());
    const events_file = try std.Io.Dir.cwd().createFile(init.io, events_path, .{});
    defer events_file.close(init.io);
    try events_file.writeStreamingAll(init.io, std.mem.sliceAsBytes(events));
}

pub fn main(init: std.process.Init) !void {
    const control_path = init.environ_map.get("UWZ_SQL_TRACE_CONTROL") orelse return error.TraceControlPathRequired;
    var control = try ControlInput.load(init.gpa, init.io, control_path);
    defer control.deinit(init.gpa);
    if (uwz_alloc_self_test() != 1) return error.AllocationInterposerSelfTestFailed;
    const output = init.environ_map.get("UWZ_SQL_LIFECYCLE_OUTPUT") orelse return error.OutputPathRequired;
    const trace_header_path = init.environ_map.get("UWZ_SQL_TRACE_HEADER") orelse return error.TraceHeaderPathRequired;
    const trace_events_path = init.environ_map.get("UWZ_SQL_TRACE_EVENTS") orelse return error.TraceEventsPathRequired;
    trace.uwz_trace_prewarm();
    const events = try init.gpa.alloc(trace.UwzTraceEvent, trace.UWZ_TRACE_EVENT_CAPACITY);
    defer init.gpa.free(events);
    var trace_header: trace.UwzTraceHeader = undefined;
    if (trace.uwz_trace_install(&trace_header, events.ptr, events.len) != 1) return error.TraceInstallationFailed;
    defer trace.uwz_trace_stop();
    if (trace.uwz_trace_self_test() != 1) {
        trace.uwz_trace_stop();
        try dump_trace(init, trace_header_path, trace_events_path, trace_header, events[0..trace_header.event_count], &control);
        return error.TraceSelfTestFailed;
    }
    const probe = try init.gpa.create(Probe);
    defer init.gpa.destroy(probe);
    var app = try App.init(init.io);
    var app_deinitialized = false;
    defer if (!app_deinitialized) app.deinit();
    probe.* = .{ .app = &app, .sql = try uz.sql.Sql.init(init.gpa, try config(init)) };
    app.provide(probe.sql.hooks()) catch |err| {
        probe.sql.db.deinit();
        return err;
    };
    try app.provide(probe.hooks());
    try app.listen("127.0.0.1", 0);
    app.run() catch |err| {
        probe.fail(err);
    };
    if (probe.scope_active) probe.fail(error.InterruptedWorkerScope);
    app.deinit();
    app_deinitialized = true;
    trace.uwz_trace_stop();
    try dump_trace(init, trace_header_path, trace_events_path, trace_header, events[0..trace_header.event_count], &control);
    var zero = probe.round_index == round_count;
    for (probe.rounds[0..probe.rounds_started]) |round| zero = zero and round.scope_complete and round.allocations.zero();
    var storage: [64 * 1024]u8 = undefined;
    var writer = std.Io.Writer.fixed(&storage);
    var json: std.json.Stringify = .{ .writer = &writer, .options = .{ .whitespace = .indent_2 } };
    try json.write(Report{
        .completed_rounds = probe.round_index,
        .functional_failure = if (probe.failure) |failure| @errorName(failure) else null,
        .strict_zero = zero,
        .rounds = probe.rounds[0..probe.rounds_started],
    });
    const file = try std.Io.Dir.cwd().createFile(init.io, output, .{});
    defer file.close(init.io);
    try file.writeStreamingAll(init.io, writer.buffered());
    if (probe.failure) |failure| return failure;
    if (probe.round_index != round_count) return error.IncompleteLifecycleRounds;
    try validate_trace(trace_header);
    try validate_control_vectors(control.parsed.value, probe.rounds[0..probe.rounds_started]);
    if (!zero) return error.NonZeroLifecycleAllocations;
}
