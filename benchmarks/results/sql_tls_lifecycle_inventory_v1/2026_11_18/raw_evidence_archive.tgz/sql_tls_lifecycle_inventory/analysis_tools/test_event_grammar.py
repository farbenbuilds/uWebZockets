#!/usr/bin/env python3
"""Reject copied malformed traces and accept the unchanged real trace."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys

if not __debug__:
    raise SystemExit("optimized Python is unsupported: proof assertions must remain enabled")

parser = argparse.ArgumentParser()
for name in ("analyzer", "header", "events", "control", "binary", "output"):
    parser.add_argument("--" + name, type=Path, required=True)
args = parser.parse_args()
out = args.output.resolve()
for parent in (out, *out.parents):
    if (parent / "files.sha256").exists():
        raise SystemExit("output must be outside an evidence artifact")
out.mkdir(parents=True, exist_ok=False)
inputs = out / "inputs"
outputs = out / "outputs"
inputs.mkdir()
outputs.mkdir()
original = args.events.read_bytes()
event_size = 576
assert len(original) % event_size == 0
operations = [struct.unpack_from("<I", original, offset + 560)[0]
              for offset in range(0, len(original), event_size)]
begin = operations.index(5)
end = operations.index(6)
inactive = next(index for index, operation in enumerate(operations)
                if operation <= 4 and struct.unpack_from("<I", original, index * event_size + 564)[0] == 0)
cases = [
    ("missing_stop", len(operations) - 1, 560, "<I", 7),
    ("duplicate_start", inactive, 560, "<I", 7),
    ("begin_not_active", begin, 564, "<I", 0),
    ("wrong_end_scope", end, 8, "<Q", 7),
    ("inactive_operation_wrong_scope", inactive, 8, "<Q", 99),
    ("stop_with_payload", len(operations) - 1, 16, "<Q", 1),
]

def command(events, destination):
    return [sys.executable, str(args.analyzer.resolve()),
            "--header", str(args.header.resolve()), "--events", str(events),
            "--control", str(args.control.resolve()), "--binary", str(args.binary.resolve()),
            "--output", str(destination)]

records = []
for name, index, offset, encoding, value in cases:
    mutated = bytearray(original)
    struct.pack_into(encoding, mutated, index * event_size + offset, value)
    source = inputs / (name + ".bin")
    source.write_bytes(mutated)
    destination = outputs / name
    with (out / (name + ".log")).open("wb") as stream:
        result = subprocess.run(command(source, destination), stdout=stream,
                                stderr=subprocess.STDOUT, timeout=120)
    assert result.returncode != 0 and not destination.exists(), name
    records.append({"name": name, "event_index": index, "byte_offset_in_event": offset,
                    "encoding": encoding, "value": value,
                    "mutant_sha256": hashlib.sha256(mutated).hexdigest(),
                    "exit_code": result.returncode, "output_created": False})
with (out / "valid_original.log").open("wb") as stream:
    result = subprocess.run(command(args.events.resolve(), out / "accepted_original"),
                            stdout=stream, stderr=subprocess.STDOUT, timeout=120)
assert result.returncode == 0
assert args.events.read_bytes() == original
(out / "results.json").write_text(json.dumps({
    "negative_cases": records, "valid_original_exit_code": result.returncode,
    "analyzer_sha256": hashlib.sha256(args.analyzer.read_bytes()).hexdigest(),
    "regression_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "original_inputs_changed": False,
}, indent=2) + "\n")
print(json.dumps({"rejected_mutants": len(records), "valid_original_exit_code": result.returncode}))
