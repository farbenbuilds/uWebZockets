# SQL TLS lifecycle inventory independent initial review

This preserves the initial review conducted on 2026-11-18 before the analyzer's
marker-grammar fix. One actionable finding was identified in the analyzer.
There were no additional correctness, ownership, counter-bypass, ABI,
secret-capture, or structural findings in the reviewed consumer. The accepted
raw trace passed the independent checks below; the analyzer finding does not
invalidate that trace's observed allocation vectors.

Reviewed analyzer SHA256:
`62e0af1c1b45a98ce1c1a4c5dd9f007336fd594d19a0aef2eceb864ebdfd842d`.
The original script is retained as `analysis/analyze_trace.pre_marker_fix.py`.
Any subsequent fix requires a targeted re-review.

## P2: Validate the ordered trace marker and active-scope grammar

Original file: `analysis/analyze_trace.py:69` (also lines 89-95 and 219),
relative to `.zig-cache/sql-tls-lifecycle-inventory-20261117/`.

The initial analyzer checks that each numbered scope has a begin followed by
an end, but does not require exactly one trace-start at the first record and
one trace-stop at the last record. It also does not reconcile every record's
scope and active bit with the ordered begin/end transitions. Its output
nevertheless unconditionally claims `trace_complete_for_recorded_worker: true`.

Reproduction: copy the accepted raw event file into a separate temporary input
directory, then change only its last record's operation word at offset
`len(raw) - 576 + 560` from 8 (`trace_stop`) to 7 (`trace_start`). Run the
unchanged analyzer with the original header, control, and binary, writing to a
new output directory outside the input directory. It exits 0 and emits the
completeness claim despite two starts and no stop. This can hide a malformed
or incorrectly emitted boundary record while approving an inventory as
complete. The original evidence file was never modified.

Use one ordered marker state machine: require the sole start first, the sole
stop last, scopes 1 through 7 in order without overlap, begin active=1, end
active=0, and every allocator record's active/scope fields equal the current
state. Reject nonzero boundary payload fields. Retain deterministic malformed
marker cases alongside the valid raw replay.

The root agent independently reproduced the failure and preserved its copied
input under `analysis/marker_red/` and the incorrect successful analysis under
`analysis/marker_red_incorrect_accept/`. The reviewer's original reproduction
and replay directories under `/tmp` were lost with the execution environment;
the checks below were performed before that loss.

## Verification performed during the initial review

- Read AGENTS.md, CODING_CONVENTION.md, reviewer/crypto_tls/verification agent
  instructions, relevant SQL/TLS docs, and the code-review-and-quality and
  thermo-nuclear-code-quality-review skills. Used graphify before source review.
- Verified every source/binary identity listed by consumer/identity.json and
  the inventory patch hash. Original allocation_scope.c is byte-identical to
  the frozen counter (SHA256
  `afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac`).
- Independently compared the complete lifecycle core with the original probe;
  it is byte-identical with SHA256
  `ce1d2928c4203aff2a1fca8dc6f60311bd8097f0cf2a10ecbf3d879b891c687e`.
- Verified the consumer binary identity:
  `7a136325ed43576ea63bf8ae1ffcf3ef4165a9ee57123398da34f4e6ada181ee`.
- Replayed the initial analyzer against the actual paired header, events,
  original control, and binary. The output summary exactly matched
  `analysis/paired_inventory_final/summary.json`.
- The accepted raw event SHA256 was
  `0311b0d4e59c750f40760f52c1755eacd9f0efb6bea8cdcaadd46381970ca3a3`;
  its header SHA256 was
  `54d2dd675db3b5bc154cb9f4e57980be095036291c0f830018a683d4499c31e0`.
  The paired control SHA256 was
  `ccd446bfbe66f522364a32133984958d9fc403f80d98e6f8cf2fc261d954598c`.
- Independently decoded all 15,340 records and checked the accepted trace's
  ordered markers, active/scope consistency, zero boundary payloads, and
  operation-specific scalar fields: one start, seven begins, seven ends,
  one stop; 4,898 malloc, 37 calloc, one realloc, and 10,388 free records.
- Both functional lifecycle reports completed six rounds without functional
  failure. The accepted tracer exits with `NonZeroLifecycleAllocations`;
  strict allocation remains RED. Exact per-round vectors are
  `(268,2,0,270,412766)` for the three failure/reconnect rounds and
  `(536,4,0,540,825532)` for the three cancellation rounds, ordered as
  malloc/calloc/realloc/free/requested bytes.
- Lifetime replay agreed on 9,428,258 peak known returned bytes, four live
  blocks totaling 14,664 bytes at observer stop, 5,457 free(NULL) events, and
  no untracked free/realloc releases. These are observed libc returned chunks,
  not a TLS capacity bound. The 13,360-byte Probe remains deliberately live
  through output and is destroyed after observer stop.
- All main-executable function symbols resolve; `_start` has no source line.
  Every allocation-operation stack includes `_start`.
- No private fixture credentials or allocation contents were read. Initial
  review and mutation replay changed no repository source or retained evidence.

## Attribution limits and verification gaps

- External shared-library frames remain unknown to symbolization against only
  the main executable. There are 13 distinct external raw IPs: 15,320 allocator
  events have two external frames, two have three, one has five, and one has
  eight. Describing every stack as having only two unresolved libc frames
  would overstate attribution completeness. The external IPs were not resolved
  to shared-library functions by this review.
- No fresh PostgreSQL execution or rebuild was performed during this review.
  Runtime conclusions use the retained paired evidence and identity checks.
- One installed main worker and the executed paths are covered. Preinstall
  work, observer-buffer/control startup allocation, post-stop/thread-exit
  work, other threads, allocator metadata, and internal realloc peaks are
  excluded. No universal capacity, failure-pressure, algorithm, or all-thread
  closure proof follows.
- Project-wide build/test/convention gates were not rerun by this read-only
  reviewer. Security, smoke, sanitizer, and fuzz campaigns remain deferred as
  requested. The separate native CBB/domain implementation is outside scope.

This file is the requested persistent copy of the initial review. It records
the pre-fix conclusion and does not claim the current analyzer still has the
finding if the root agent has since changed it.
