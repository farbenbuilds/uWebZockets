# SQL TLS lifecycle inventory targeted final review

No actionable findings in the targeted fix. The initial P2 finding about
missing global trace-marker and active-scope validation is resolved.

This verdict covers the analyzer grammar fix, its deterministic regression
driver, and the retained raw evidence. It does not approve production TLS
adoption or close the full PostgreSQL allocation requirement, which remains RED.

## Reviewed change and identities

All paths below are relative to
`.zig-cache/sql-tls-lifecycle-inventory-20261117/` unless noted otherwise.

- `analysis/analyze_trace.py:63`: the new pure `validate_event_grammar` checks
  exactly one first start and one last stop, no events outside that lifetime,
  sequential nonoverlapping scopes 1 through 7, matching active/scope fields,
  zero boundary memory payloads, and operation-specific scalar shapes. It runs
  before counter reconciliation, lifetime analysis, symbolization, or output.
  Reviewed SHA256:
  `3eee7ce88f1c8ac484d1d7049103cdb3932c8dee56426e6cfe2bb803cc33aa33`.
- `analysis/test_event_grammar.py`: copies the original events, mutates only
  the copies, requires each malformed case to fail before creating analysis
  output, and requires the original trace to succeed unchanged. Its results
  bind the analyzer and regression-script hashes. Reviewed script SHA256:
  `da6fa02220f566cd771ec641188e4e747aa3e3fe143742d2a2d8ae2d7f6eff53`.
- Compared the analyzer against `analysis/analyze_trace.pre_marker_fix.py`.
  The diff adds the validator/invocation and the successful-validation summary
  flag. Existing counter reconciliation, source symbolization, and lifetime
  semantics are retained.
- Checked the root's preserved historical RED reproduction at
  `analysis/marker_red/reproduction.json`: the old analyzer accepted a final
  stop changed into a second start. The original evidence was unchanged.

## Independent verification

Executed successfully from the repository root:

```sh
python3 .zig-cache/sql-tls-lifecycle-inventory-20261117/analysis/test_event_grammar.py \
  --analyzer .zig-cache/sql-tls-lifecycle-inventory-20261117/analysis/analyze_trace.py \
  --header .zig-cache/sql-tls-lifecycle-inventory-20261117/run_trace_paired/trace_header.json \
  --events .zig-cache/sql-tls-lifecycle-inventory-20261117/run_trace_paired/trace_events.bin \
  --control .zig-cache/sql-tls-lifecycle-inventory-20261117/run_control/lifecycle.json \
  --binary .zig-cache/sql-tls-lifecycle-inventory-20261117/consumer/zig-out/bin/sql_tls_lifecycle_inventory \
  --output .zig-cache/sql-tls-lifecycle-inventory-20261117/review/marker_regressions_reviewer
```

Result: `{"rejected_mutants": 6, "valid_original_exit_code": 0}`.

All six copied malformed inputs were rejected without creating accepted
analysis output: missing stop, duplicate start, inactive begin, wrong end
scope, wrong scope on an inactive allocator event, and a stop carrying a
pointer payload. In particular, the original missing-stop reproduction now
fails in `validate_event_grammar` with `invalid trace start`.

The reviewer's result manifest at
`review/marker_regressions_reviewer/results.json` exactly matches the root's
`analysis/marker_regressions_final/results.json`. Both bind the current source
hashes above. The accepted original summary is identical to
`analysis/paired_inventory_final/summary.json` apart from the added
`global_trace_scope_grammar_validated: true` field.

Recomputed original input identities after the regression run:

| Input | SHA256 |
| --- | --- |
| Paired raw events | `0311b0d4e59c750f40760f52c1755eacd9f0efb6bea8cdcaadd46381970ca3a3` |
| Paired trace header | `54d2dd675db3b5bc154cb9f4e57980be095036291c0f830018a683d4499c31e0` |
| Original control | `ccd446bfbe66f522364a32133984958d9fc403f80d98e6f8cf2fc261d954598c` |
| Consumer binary | `7a136325ed43576ea63bf8ae1ffcf3ef4165a9ee57123398da34f4e6ada181ee` |

These identities are unchanged from the initial review. The valid 15,340-event
trace retains exact original per-round allocation vectors and lifetime totals.
The initial independent source/counter/core and raw-event review is preserved
in `review/initial_review.md`.

## Verification gaps and attribution limits

- No fresh PostgreSQL run, rebuild, production-source review, or project-wide
  gate rerun was performed for this targeted recheck. Security, smoke,
  sanitizer, and fuzz campaigns remain deferred. The separate native CBB/domain
  implementation is outside this review.
- All main-executable function addresses resolve, with no source line for
  `_start`. Main-executable symbolization leaves 13 distinct external raw IPs
  unresolved. External frame counts vary: 15,320 allocator events have two,
  two events have three, one has five, and one has eight. This is an explicit
  shared-library attribution limit, not a universal two-frame claim.
- The inventory covers the installed main worker and executed paths through
  observer stop. Preinstall work, observer-storage/control startup allocation,
  other threads, thread-exit/post-stop work, allocator metadata, and internal
  realloc peaks remain outside the observation boundary. The 9,428,258-byte
  peak includes application startup slabs and native returned chunks; it is
  not a TLS capacity bound or an all-thread ownership proof.
- Analyzer/regression execution used ordinary `python3`, with assertions
  enabled, as in the retained commands.

Only review reports and isolated copied-trace regression outputs were written
by this reviewer. The C tracer, analyzer source, original raw inputs, native
source, and project gates were not edited.
