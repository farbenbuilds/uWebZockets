# Allocation inventory ABI version 1

This test-only consumer observes the main thread that owns the synchronous
`App.run` loop. The caller installs one explicitly allocated startup event slab
and header. Other uninstalled threads are outside this worker inventory, as
they are outside the original thread-local allocation counter. This is not a
process-wide ownership proof.

`allocation_scope.c` remains byte-identical to the frozen lifecycle producer:
SHA256 `afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac`.
The shim macro-includes it, renaming only its four allocator entries and
begin/end functions. Its actual bodies, original self-test and original counter
accessors remain intact. Every public allocator wrapper calls that renamed
counted entry, which calls the same `__libc_*` function as before. There is no
allocator selection, storage redirection, arena, allocation filter or alternate
counter. `errno` is restored to the value produced by the underlying operation.

The added wrapper changes `__builtin_return_address(0)` in the original malloc
counter: the existing two malloc-site fields now point into the observer
wrapper. They are retained, not forged to match old addresses. Lifetime/source
attribution uses the new raw full physical unwind frames, which include the
observer helpers and public wrapper. Optimized-away tail calls and inline
functions are not invented; the independent symbolizer may expand DWARF inline
information. `_Unwind_GetIP` returns native instruction/return addresses;
symbolization normally adjusts caller return addresses by one byte.

The pinned `/tmp/zig-x86_64-linux-0.16.0/lib/include/unwind.h` declares
`_Unwind_Backtrace` and `_Unwind_GetIP`. The existing Zig C++ link supplies its
unwinder. Only the observer C TU adds unwind/frame-pointer/no-sibling-call flags;
the probe root adds synchronous unwind tables and a frame pointer. Native SDK
source, compiler options and source lists remain unchanged.

Unwinding is prewarmed before buffer installation and before any active scope.
The unchanged original 63-byte self-test runs before installation. A separate
test calls the actual public wrappers after installation: malloc17, calloc3x5,
realloc31, free and free. It verifies the original 1/1/1/2 operation counters and
63 requested bytes plus five traced allocation events, pointer links, nonempty
frames, flags and active markers. Begin/end add two boundary events. Its scope
and events remain visible in the output.

The observer records all intercepted allocator calls from installation through
App/SQL teardown and observer stop. Buffer allocation/prewarming precede
installation; output and observer-storage release follow stop. Thread-exit
destructors after main returns are beyond the declared observation boundary.
The six functional lifecycle/query bodies and the original first-Db.query to
final-callback-entry intervals are unchanged. App.deinit now occurs before
observer stop/output, outside the already-ended request intervals, so native
context teardown is visible too.

## Files and header

`UWZ_SQL_TRACE_HEADER` names the JSON metadata file; `UWZ_SQL_TRACE_EVENTS`
names the raw fixed-record binary file. `UWZ_SQL_LIFECYCLE_OUTPUT` remains the
unchanged functional JSON report. The header JSON contains a named
`UwzTraceHeader`, ABI version1, magic bytes `UWZATRC1`, endian marker
0x01020304, pointer size8, header size168, record size576, frame capacity64,
event capacity/count, scope mapping, completeness statistics and stopped flag.
The binary file contains exactly event_count consecutive records, without a
prefix or trailer. C static assertions bind record/header sizes and offsets;
the header is imported by normal build-time translate-c.

All binary words are little endian. The consumer rejects a non-64-bit,
non-glibc, non-Linux or non-little-endian build. Every event and the header are
zeroed before use. No struct padding or unused frame can disclose data. No
object, SQL parameter, certificate, credential or other allocation contents are
read or stored; only addresses, sizes, operation metadata and raw frames appear.

| Offset | Field | Representation |
| --- | --- | --- |
| 0 | sequence | u64; zero-based reservation order |
| 8 | scope | u64; zero outside counted scope |
| 16 | pointer | u64 returned pointer; free's retired pointer |
| 24 | old_pointer | u64 realloc input pointer; zero otherwise |
| 32 | size | u64 size argument; calloc element size; free zero |
| 40 | count | u64 calloc element count; malloc/realloc1; free zero |
| 48 | frames | 64 u64 raw IPs; unused entries zero |
| 560 | operation | u32 opcode |
| 564 | active | u32 original-counter active bit at observation |
| 568 | frame_count | u32 valid frame entries |
| 572 | flags | u32 completeness flags |

Opcodes: malloc1, calloc2, realloc3, free4, scope_begin5, scope_end6,
trace_start7, trace_stop8. Boundaries carry zero frame counts; they do not invoke
the unwinder. Scope0 is startup/outside/teardown, scope1 is the public-wrapper
self-test, and scopes2..7 are the six unchanged lifecycle intervals in report
order. Begin is emitted after the original begin body, with active1. End is
emitted after the original end body, with active0 and the just-ended scope ID.
Begin/end do not move the original counted boundary or perform heap work.

For calloc, requested size is count times size; multiplication overflow is
explicitly counted in header.calloc_overflows. Failed malloc/calloc/realloc
are still recorded with pointer0; realloc's old pointer remains available.
`free(NULL)` is traced and counted in free_nulls, while the original unchanged
free counter continues to ignore null pointers. Zero-size realloc is recorded
without inventing a success/failure interpretation; pairing follows the actual
glibc contract and result.

## Limits and rejection

The fixed slab holds 32768 records, 18874368 bytes (18 MiB), with up to64 raw
frames per allocation operation. This is a bounded inventory for these exact
scenarios, not a universal maximum. A 65th nonzero frame sets truncated flag2
and increments truncated_stacks; it never silently pretends the stack was full.
Unexpected unwind status sets flag4; empty stack sets flag8. Recursive unwind
allocation still calls the original counter/libc path and records the operation,
pointer and size with recursive flag1; only its recursive stack traversal is
suppressed. Reentrancy is never an exemption from original counters.

Overflow, recursion, truncation, unwind failure, empty allocation stacks or
invalid/missing scope boundaries reject completeness. Null/failure/free-null
and calloc-overflow totals are separately visible and do not hide operations.
Scope count must be7, all six original functional rounds must complete, and the
trace must be stopped with no active scope. The public self-test must pass.
Observer allocations inside an active interval remain in the unchanged C
counters; every original vector is also checked: failure/reconnect
268/2/0/270/412698 and cancellation536/4/0/540/825396 for
malloc/calloc/realloc/free/requested-bytes. Any change fails explicitly with
TraceObserverChangedAllocationVector after reports are dumped. Strict allocation
RED is considered only after functional and trace/vector checks pass.

The observer performs no IO, formatting, heap operation, dlsym or clock read.
Only the underlying counted libc call may allocate/free. The unwind library's
actual behavior is tested by unchanged counters/self-test rather than assumed
allocation-free. Root owns runtime validation and independent review.
