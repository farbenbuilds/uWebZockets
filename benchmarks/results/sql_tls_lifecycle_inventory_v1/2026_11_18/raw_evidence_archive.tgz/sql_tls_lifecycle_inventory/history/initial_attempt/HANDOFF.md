# Allocation lifetime inventory consumer

Frozen build-only author handoff. ReleaseSafe build passed19/19 steps;
`final_build.log` is the canonical serialized final build. No fixture was
launched, no credentials were read, and the author did not run the consumer or
either self-test. Root owns runtime and independent source/evidence review.

Executable: `zig-out/bin/sql_tls_lifecycle_inventory`, SHA256
`801eb5081a5a6c1fea0d82141103056e80c119bbbe1441d31fbd368b163423e1`.
`identity.json` binds all source, build, ABI documentation and binary hashes.
`inventory.patch` is relative to the frozen lifecycle consumer, SHA256
`c5aae68fec9d4b20089e37ecbcb7ff0163d5958ea767682d8026a47fd7290563`.

The original C source remains byte-exact afd763bd..., including allocator
bodies/counters/self-test. The original lifecycle core from App/constants
through the six scenario/interval functions and Report remains byte-identical,
SHA256 `ce1d2928c4203aff2a1fca8dc6f60311bd8097f0cf2a10ecbf3d879b891c687e`.
Only private observer C/header, normal build-time header translation and probe
observer setup/teardown/output/validation are added. No SDK, native source,
original producer, tracked source, pins or root artifact was changed.

Build command from this directory:

```sh
/tmp/zig-x86_64-linux-0.16.0/zig build -Doptimize=ReleaseSafe --cache-dir /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-preparation-integration-20261117/consumer-cache --global-cache-dir /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-preparation-integration-20261117/global-cache --summary all
```

Root runs with the existing trusted fixture PG environment, unchanged
`UWZ_SQL_LIFECYCLE_OUTPUT`, plus explicit `UWZ_SQL_TRACE_HEADER` and
`UWZ_SQL_TRACE_EVENTS` output paths under its owned SSD workspace. Do not print
the environment or credentials. `ABI.md` defines every binary field, scope,
statistic, size semantic and limitation. The caller supplies18MiB of startup
event storage:32768records of576bytes,64raw frames each. Header ABI size168,
version1, little endian, pointer size8. Header JSON and binary contain addresses
and sizes only; no allocation contents are read or written.

Original self-test precedes installation. The public-wrapper self-test remains
visible as scope1 with five allocation events/63bytes plus begin/end. Scopes2..7
are the six original worker intervals. Recursion may suppress recursive
unwinding only; the original counts/route and operation event remain. Any
overflow/recursive/truncated/missing stack or boundary rejects required trace
completeness. App/SQL teardown occurs before observer stop; dumping follows stop
and inactive counters. Uninstalled threads and post-main thread destructors are
outside the declared worker observation boundary.

Root runtime acceptance requires both self-tests, six functional rounds,
complete trace, seven total scopes and unchanged vectors268/2/0/270/412698 and
536/4/0/540/825396. Observer-induced native allocations are never filtered from
original counters; a vector change fails explicitly. Only after these checks
does the original strict NonZeroLifecycleAllocations result describe a genuine
RED. No successful runtime/counter-neutrality or allocation-gate completion is
claimed from the build alone. Broad campaigns remain deferred.
