#!/usr/bin/env python3
"""Reconcile bounded allocation events with the unchanged lifecycle counter."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess

EVENT = struct.Struct("<70Q4I")
FIELDS = ("mallocs", "callocs", "reallocs", "frees", "bytes")
OPERATIONS = {1: "malloc", 2: "calloc", 3: "realloc", 4: "free"}
parser = argparse.ArgumentParser()
parser.add_argument("--header", type=Path, required=True)
parser.add_argument("--events", type=Path, required=True)
parser.add_argument("--control", type=Path, required=True)
parser.add_argument("--binary", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
out = args.output.resolve()
for parent in (out, *out.parents):
    if (parent / "files.sha256").exists():
        raise SystemExit("output must be outside an evidence artifact")
for source in (args.header, args.events, args.control, args.binary):
    if source.resolve().parent in (out, *out.parents):
        raise SystemExit("output must be outside input directories")
if out.exists():
    raise SystemExit("output must not exist")
header_document = json.loads(args.header.read_text())
header = header_document["header"]
assert header["magic"] == "UWZATRC1" and header["abi_version"] == 1
assert header["endian_word"] == 0x01020304 and header["pointer_size"] == 8
assert header["event_size"] == EVENT.size == 576 and header["frame_capacity"] == 64
assert header["header_size"] == 168 and header["event_count"] <= header["event_capacity"]
assert header["scope_count"] == 7 and header["selftest_scope"] == 1
assert header["request_first_scope"] == 2 and header["active_scope"] == 0
assert header["selftest_passed"] == header["stopped"] == 1
for key in ("overflow_events", "recursive_events", "truncated_stacks",
            "unwind_failures", "empty_stacks", "calloc_overflows", "invalid_boundaries"):
    assert header[key] == 0, key
raw = args.events.read_bytes()
assert len(raw) == header["event_count"] * EVENT.size
events = []
addresses = set()
for index, row in enumerate(EVENT.iter_unpack(raw)):
    sequence, scope, pointer, old_pointer, size, count = row[:6]
    operation, active, frame_count, flags = row[70:]
    assert sequence == index and flags == 0 and 0 <= frame_count <= 64
    frames = row[6:6 + frame_count]
    assert not any(row[6 + frame_count:70])
    assert operation in range(1, 9) and active in (0, 1)
    if operation <= 4:
        assert frames and all(frames)
        addresses.update(ip - 1 for ip in frames)
    else:
        assert frame_count == 0
    events.append({"sequence": sequence, "scope": scope, "pointer": pointer,
                   "old_pointer": old_pointer, "size": size, "count": count,
                   "operation": operation, "active": active, "frames": frames})

def validate_event_grammar(rows, scope_count):
    started = False
    stopped = False
    active_scope = 0
    next_scope = 1
    for index, event in enumerate(rows):
        operation = event["operation"]
        if operation == 7:
            assert index == 0 and not started and not stopped, "invalid trace start"
            assert event["scope"] == event["active"] == 0
            started = True
        elif operation == 8:
            assert started and not stopped and index == len(rows) - 1, "invalid trace stop"
            assert active_scope == event["scope"] == event["active"] == 0
            stopped = True
        else:
            assert started and not stopped, "event outside trace lifetime"
        if operation >= 5:
            assert event["pointer"] == event["old_pointer"] == event["size"] == event["count"] == 0
        if operation == 5:
            assert active_scope == 0 and event["scope"] == next_scope, "invalid scope begin"
            assert event["active"] == 1
            active_scope = next_scope
            next_scope += 1
        elif operation == 6:
            assert active_scope != 0 and event["scope"] == active_scope, "invalid scope end"
            assert event["active"] == 0
            active_scope = 0
        elif operation <= 4:
            assert event["active"] == int(active_scope != 0), "active flag disagrees with scope"
            assert event["scope"] == active_scope, "operation outside its scope"
            if operation in (1, 3):
                assert event["count"] == 1
            if operation in (1, 2):
                assert event["old_pointer"] == 0
            if operation == 4:
                assert event["old_pointer"] == event["size"] == event["count"] == 0
    assert started and stopped and active_scope == 0, "incomplete trace lifetime"
    assert next_scope == scope_count + 1, "incomplete scope sequence"

validate_event_grammar(events, header["scope_count"])

control = json.loads(args.control.read_text())
assert header_document["control_sha256"] == hashlib.sha256(args.control.read_bytes()).hexdigest()
assert control["expected_rounds"] == control["completed_rounds"] == len(control["rounds"]) == 6
assert control["functional_failure"] is None and not control["strict_zero"]
counts = {scope: dict.fromkeys(FIELDS, 0) for scope in range(1, 8)}
boundaries = defaultdict(list)
for event in events:
    operation = event["operation"]
    scope = event["scope"]
    if operation in (5, 6):
        boundaries[scope].append((operation, event["sequence"]))
    if not event["active"] or operation > 4:
        continue
    assert scope in counts
    count = counts[scope]
    if operation == 1:
        count["mallocs"] += 1
        count["bytes"] += event["size"]
    elif operation == 2:
        count["callocs"] += 1
        count["bytes"] += event["size"] * event["count"]
    elif operation == 3:
        count["reallocs"] += 1
        count["bytes"] += event["size"]
    elif event["pointer"]:
        count["frees"] += 1
for scope in range(1, 8):
    assert [op for op, _ in boundaries[scope]] == [5, 6]
assert counts[1] == dict(zip(FIELDS, (1, 1, 1, 2, 63)))
for scope, round_record in enumerate(control["rounds"], 2):
    assert round_record["scope_complete"]
    assert round_record["scenario"] == ("failure_reconnect" if scope < 5 else "deadline_cancel")
    assert counts[scope] == {key: round_record["allocations"][key] for key in FIELDS}

image = args.binary.read_bytes()
assert image[:6] == b"\x7fELF\x02\x01" and struct.unpack_from("<H", image, 16)[0] == 2
phoff = struct.unpack_from("<Q", image, 32)[0]
phsize, phnum = struct.unpack_from("<HH", image, 54)
executable_ranges = []
for index in range(phnum):
    kind, flags, _, vaddr, _, _, memsize, _ = struct.unpack_from("<II6Q", image, phoff + index * phsize)
    if kind == 1 and flags & 1:
        executable_ranges.append((vaddr, vaddr + memsize))

command = ["addr2line", "-a", "-f", "-C", "-i", "-e", str(args.binary.resolve())]
resolved = subprocess.run(command, input="".join(hex(ip) + "\n" for ip in sorted(addresses)),
                          text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
assert resolved.returncode == 0, resolved.stderr
symbols = {}
current = None
for line in resolved.stdout.splitlines():
    if re.fullmatch(r"0x[0-9a-fA-F]+", line):
        current = int(line, 16)
        symbols[current] = []
    else:
        assert current is not None
        symbols[current].append(line)
assert set(symbols) == addresses
for lines in symbols.values():
    assert len(lines) % 2 == 0

def stack_details(frames):
    result = []
    for raw_ip in frames:
        ip = raw_ip - 1
        lines = symbols[ip]
        result.append({"raw_ip": raw_ip, "lookup_ip": ip,
                       "in_main_executable": any(low <= ip < high for low, high in executable_ranges),
                       "inline_chain": [{"function": lines[i], "location": lines[i + 1]}
                                        for i in range(0, len(lines), 2)]})
    return result

live = {}
live_bytes = 0
peak_bytes = 0
unknown_frees = []
unknown_reallocs = []
lifetime_rows = []
scope_lifetimes = {}
stack_groups = {}
null_frees = 0
for event in events:
    operation, pointer, scope = event["operation"], event["pointer"], event["scope"]
    sequence = event["sequence"]
    if operation == 5:
        scope_lifetimes[scope] = {"start_known_live_bytes": live_bytes,
                                  "peak_known_live_bytes": live_bytes,
                                  "start_known_blocks": len(live)}
    if operation <= 4:
        key = (operation, event["frames"])
        if key not in stack_groups:
            stack_groups[key] = {"operation": OPERATIONS[operation], "events": 0,
                                 "active_events": 0, "requested_bytes": 0,
                                 "active_requested_bytes": 0,
                                 "sizes": Counter(), "scopes": Counter(),
                                 "stack": stack_details(event["frames"])}
            names = [entry["function"] for frame in stack_groups[key]["stack"]
                     for entry in frame["inline_chain"]]
            assert "_start" in names, "unwind ended before the executable entry"
        group = stack_groups[key]
        group["events"] += 1
        group["active_events"] += event["active"]
        group["scopes"][scope] += 1
        size = event["size"] * event["count"] if operation == 2 else event["size"]
        group["sizes"][size] += 1
        if operation != 4:
            group["requested_bytes"] += size
            if event["active"]:
                group["active_requested_bytes"] += size
    if operation == 4 and not pointer:
        null_frees += 1
    if operation in (3, 4):
        old_pointer = event["old_pointer"] if operation == 3 else pointer
        releases = operation == 4 or pointer != 0 or event["size"] == 0
        if releases and old_pointer:
            old = live.pop(old_pointer, None)
            if old is None:
                (unknown_reallocs if operation == 3 else unknown_frees).append(event)
            else:
                live_bytes -= old["requested_bytes"]
                lifetime_rows.append({**old, "release_sequence": sequence,
                                      "release_scope": scope,
                                      "release_operation": OPERATIONS[operation]})
    if operation in (1, 2, 3) and pointer:
        size = event["size"] * event["count"] if operation == 2 else event["size"]
        assert pointer not in live, "reused live allocation address"
        live[pointer] = {"pointer": pointer, "requested_bytes": size,
                         "allocation_sequence": sequence, "allocation_scope": scope,
                         "allocation_operation": OPERATIONS[operation]}
        live_bytes += size
    peak_bytes = max(peak_bytes, live_bytes)
    if event["active"]:
        scope_lifetimes[scope]["peak_known_live_bytes"] = max(scope_lifetimes[scope]["peak_known_live_bytes"], live_bytes)
    if operation == 6:
        scope_lifetimes[scope]["end_known_live_bytes"] = live_bytes
        scope_lifetimes[scope]["end_known_blocks"] = len(live)
assert null_frees == header["free_nulls"]
assert scope_lifetimes[1]["end_known_blocks"] == 0
assert not [event for event in unknown_frees + unknown_reallocs if event["active"]]

out.mkdir(parents=True)
(out / "addr2line.txt").write_text(resolved.stdout)
(out / "symbol_command.json").write_text(json.dumps({"command": command, "exit_code": 0,
    "lookup": "raw return address minus one", "unique_addresses": len(addresses)}, indent=2) + "\n")
groups = sorted(stack_groups.values(), key=lambda row: (-row["active_events"], -row["requested_bytes"]))
(out / "callsite_inventory.json").write_text(json.dumps(groups, indent=2) + "\n")
(out / "lifetimes.json").write_text(json.dumps({"closed": lifetime_rows, "still_live_at_stop": list(live.values())}, indent=2) + "\n")
summary = {"event_count": len(events), "unique_stacks_by_operation": len(groups),
           "unique_return_addresses": len(addresses), "scope_vectors": counts,
           "scope_lifetimes": scope_lifetimes, "peak_known_live_bytes": peak_bytes,
           "end_known_live_bytes": live_bytes, "end_known_blocks": len(live),
           "untracked_free_events": len(unknown_frees),
           "untracked_realloc_events": len(unknown_reallocs),
           "active_untracked_release_events": 0,
           "null_free_events": null_frees,
           "closed_lifetimes": len(lifetime_rows),
           "trace_complete_for_recorded_worker": True,
           "global_trace_scope_grammar_validated": True,
           "every_allocation_stack_reaches_executable_entry": True,
           "capacity_bound_proved": False,
           "limits": "Observed returned libc chunks include application startup slabs and native allocations on one installed worker; excludes preinstallation allocations, allocator metadata/internal realloc peaks, other threads and unexecuted native paths. Not a TLS domain size bound."}
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
(out / "inputs.json").write_text(json.dumps({str(path.resolve()): hashlib.sha256(path.read_bytes()).hexdigest()
    for path in (args.header, args.events, args.control, args.binary, Path(__file__))}, indent=2) + "\n")
print(json.dumps(summary))
