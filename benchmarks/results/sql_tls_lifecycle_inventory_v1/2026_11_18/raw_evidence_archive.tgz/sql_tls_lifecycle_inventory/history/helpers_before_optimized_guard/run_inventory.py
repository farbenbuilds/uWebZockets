#!/usr/bin/env python3
"""Pair the unchanged lifecycle control with the observing trace executable."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
for name in ("fixture", "control-binary", "trace-binary", "analyzer", "output"):
    parser.add_argument("--" + name, type=Path, required=True)
args = parser.parse_args()
out = args.output.resolve()
for parent in (out, *out.parents):
    if (parent / "files.sha256").exists():
        raise SystemExit("output must be outside an evidence artifact")
out.mkdir(parents=True, exist_ok=False)
fixture = args.fixture.resolve()
private = fixture / "private_fixture"
values = dict(line.split("=", 1) for line in (private / "postgres.env").read_text().splitlines())
env = dict(os.environ)
env.update(PGHOST="127.0.0.1", PGPORT=str(json.loads((fixture / "fixture.json").read_text())["port"]),
           PGUSER="uwz_test", PGDATABASE="uwz_test", PGPASSWORD=values["POSTGRES_PASSWORD"],
           PGSSLROOTCERT=str(private / "ca.pem"), PGSSLSERVERNAME="localhost")
records = []
for name, binary in (("control", args.control_binary), ("trace", args.trace_binary)):
    destination = out / name
    destination.mkdir()
    run_env = dict(env, UWZ_SQL_LIFECYCLE_OUTPUT=str(destination / "lifecycle.json"))
    if name == "trace":
        run_env.update(UWZ_SQL_TRACE_CONTROL=str(out / "control/lifecycle.json"),
                       UWZ_SQL_TRACE_HEADER=str(destination / "trace_header.json"),
                       UWZ_SQL_TRACE_EVENTS=str(destination / "trace_events.bin"))
    start = time.monotonic()
    with (destination / "stdout.log").open("wb") as stdout, (destination / "stderr.log").open("wb") as stderr:
        result = subprocess.run([str(binary.resolve())], env=run_env,
                                stdout=stdout, stderr=stderr, timeout=45)
    report = json.loads((destination / "lifecycle.json").read_text())
    assert result.returncode == 1 and report["completed_rounds"] == 6
    assert report["functional_failure"] is None and not report["strict_zero"]
    assert "error: NonZeroLifecycleAllocations" in (destination / "stderr.log").read_text()
    records.append({"name": name, "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
                    "exit_code": result.returncode, "expected_exit_code": 1,
                    "elapsed_s": time.monotonic() - start,
                    "completed_rounds": report["completed_rounds"], "functional_failure": None})
command = [sys.executable, str(args.analyzer.resolve()),
           "--header", str(out / "trace/trace_header.json"),
           "--events", str(out / "trace/trace_events.bin"),
           "--control", str(out / "control/lifecycle.json"),
           "--binary", str(args.trace_binary.resolve()), "--output", str(out / "analysis")]
with (out / "analysis.log").open("wb") as stream:
    result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=120)
assert result.returncode == 0
(out / "run_status.json").write_text(json.dumps({
    "runs": records, "analysis_exit_code": result.returncode,
    "analyzer_sha256": hashlib.sha256(args.analyzer.read_bytes()).hexdigest(),
    "private_credentials_recorded": False,
}, indent=2) + "\n")
print("paired control/trace functional rounds passed; strict lifecycle allocation RED retained")
