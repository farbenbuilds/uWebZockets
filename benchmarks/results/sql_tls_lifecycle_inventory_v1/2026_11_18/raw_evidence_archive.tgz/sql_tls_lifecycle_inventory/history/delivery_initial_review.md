# SQL TLS lifecycle inventory delivery review

One actionable P2 finding in the reviewed archive: optimized Python removes
the helpers' assertion-based acceptance gates. No other actionable delivery
findings. Ordinary-Python replay is valid and reproduces the packaged evidence.
The root agent is addressing the finding; a replacement archive needs a
targeted final recheck before this report can approve delivery.

## Reviewed immutable generation

- Artifact: `benchmarks/results/sql_tls_lifecycle_inventory_v1/2026_11_18/raw_evidence_archive.tgz`.
- SHA256: `c06841470a65fb3ebb7a253b11c0cfccee998bd8256ff11bb621df69f1c6feb1`.
- Compressed bytes: 30,634,996. Expanded regular-file bytes: 150,477,558.
- README SHA256: `90cce987c2c264c046c6d7705c4ea1f0ca66a150098d065e83247e87dc4feb39`.
- Outer manifest SHA256: `330612505b30a4e21ad27fe37e28fbc5d784e4bd9187261ce3612411cfaf3b75`.
- Reviewed `docs/sql.md:164` inventory paragraph; file SHA256 at review was
  `aed427e80c719e7db58a8c2353dfdf0129836155bffc464481b78325bd68230e`.

The extraction is preserved outside the immutable packet at
`.zig-cache/sql-tls-lifecycle-inventory-20261117/review/delivery_packet_extract/sql_tls_lifecycle_inventory/`.
Member references below are relative to that packet root.

## P2: Reject optimized Python before assertion-based validation runs

Locations: `analysis_tools/analyze_trace.py:33`,
`analysis_tools/test_event_grammar.py:58`, and `run_inventory.py:42`.

These tools enforce identities, marker grammar, exact counter vectors, expected
strict-RED exits, and regression outcomes with Python assertions. `python3 -O`
or `PYTHONOPTIMIZE` removes those checks. The analyzer can then label malformed
traces complete, and the regression driver can report rejected mutants even
when analyzer subprocesses succeed. The paired-run helper likewise loses its
functional/result gates.

Reproduced against the extracted immutable generation: invoke the analyzer
with `python3 -O`, the copied fresh missing-stop mutant produced by the included
regression driver, and otherwise unchanged header/control/binary inputs. It
exits 0 and writes `global_trace_scope_grammar_validated: true`.

Durable reproduction metadata and output:

- `review/delivery_optimized_red.json` outside the packet, relative to the
  experiment scratch root.
- `review/delivery_optimized_invalid_accept.log`.
- `review/delivery_optimized_invalid_accept/summary.json`.

Add an explicit early `if not __debug__: raise SystemExit(...)` rejection to
all three entry points, or replace the mandatory acceptance assertions with
checks that remain active under optimization. Keep the existing ordinary-mode
semantics and verify optimized invocations fail before creating outputs. The
root agent has selected the early rejection approach.

## Archive and identity verification

- Graphify query preceded new delivery exploration. Prior independent code
  review was reused; no broad source or native implementation review was
  repeated.
- Verified the archive's exact SHA256/size and its outer manifest. All 112
  members are regular files under the sole
  `sql_tls_lifecycle_inventory/` prefix, with canonical relative paths,
  no duplicate names, no traversal/absolute/backslash paths, no links or
  special files, and no privileged mode bits. Safely extracted into a new SSD
  scratch directory, preserving recorded modes.
- Internal `files.sha256` covers exactly all 111 other payload files.
  Independently recomputed every hash, then ran the documented
  `sha256sum -c files.sha256` from the extraction: 111 OK.
- Verified all 110 recorded hashes and modes in `payload_identity.json`.
- Consumer producer identity: all nine referenced included files verified,
  including final binary
  `7a136325ed43576ea63bf8ae1ffcf3ef4165a9ee57123398da34f4e6ada181ee`.
- Historical first-generation identity: all nine referenced included files
  verified, including distinct binary
  `801eb5081a5a6c1fea0d82141103056e80c119bbbe1441d31fbd368b163423e1`.
  Its retained error is `TraceObserverChangedAllocationVector`; the README
  correctly excludes this generation from accepted results.
- Original control identity: five included referenced files verified, including
  binary `3769693be9465ef778390fea52e9a0bae8e94bcbeaac8d01c2b1f0ec7e44cf55`.
- Original C counter bytes match across control, initial observer, and final
  observer. The archived final lifecycle core matches the archived original
  control core exactly.
- No dependency/build caches, `.git` state, private-fixture directory, or
  certificate/private-key files are packaged. A targeted scan of 97 text
  payload files detected no literal generated-password assignment or private
  key body. Source helpers generate private material separately and do not
  record it into the returned lifecycle/trace evidence.

## Independent replay and documented claims

Ran the extracted `analysis_tools/test_event_grammar.py` with the extracted
fresh replay header/events/control and extracted `bin/trace`, writing to the
new SSD directory `review/delivery_packet_replay` outside the packet.

Ordinary-Python result:
`{"rejected_mutants": 6, "valid_original_exit_code": 0}`.

All six copied malformed traces failed without analysis output. The accepted
original summary exactly matches the packet's fresh analysis summary. The
extracted analyzer/test hashes match the previously reviewed fixed generation:

- Analyzer: `3eee7ce88f1c8ac484d1d7049103cdb3932c8dee56426e6cfe2bb803cc33aa33`.
- Regression driver: `da6fa02220f566cd771ec641188e4e747aa3e3fe143742d2a2d8ae2d7f6eff53`.

Independently checked all four original/fresh control/trace lifecycle reports:
six complete functional rounds, no functional failure, strict_zero false, and
exact vectors `(268,2,0,270,412766)` three times followed by
`(536,4,0,540,825532)` three times. Fresh run metadata binds both executed
binaries and records their expected exit 1. Fixture metadata records the same
pinned PostgreSQL image and version 17.11 for original and fresh fixtures.

The fresh trace has 15,306 events, 1,098 operation/stack groups, 4,932 closed
lifetimes, no untracked non-null free/realloc, four live blocks totaling 14,664
bytes at stop, and a 9,428,258-byte peak of known returned chunks. The original
15,340-event trace differs by exactly 34 free(NULL) events. Allocation vectors
and closed lifetimes agree. These match README claims.

Every recorded stack includes `_start`, and all main-executable function names
resolve. Both original and fresh traces contain 13 distinct unresolved external
raw IPs. Original external-frame depths are two for 15,320 events, three for
two events, five for one, and eight for one. Fresh depths are two for 15,286
events, with the same counts at the other depths. The README correctly states
variable external depth and avoids a universal two-frame claim.

The README and `docs/sql.md` retain strict allocation RED, separate startup
application slabs from a TLS domain capacity bound, and leave production
adoption and the full PostgreSQL requirement open.

## Verification gaps and limits

- No fresh live PostgreSQL execution, SDK rebuild, project-wide gates,
  smoke/security/sanitizer/fuzz campaigns, or native-domain implementation
  review was performed. Replay executes only offline evidence analysis and
  deterministic malformed-copy checks.
- The original control's producer identity also references `build.log` and
  `initial_build_failure.log`, which are not included in this packet. Their
  contents were not audited in this delivery review; all included material
  source/binary identities verify.
- Fixture cleanup and exact generated-secret scanning are recorded by
  `fixture_cleanup.json`; deleted private values and removed containers were
  not independently reconstructed or inspected. The reviewer performed only
  the targeted packet path/content checks described above.
- Main-worker executed paths are covered. Preinstall work, observer-storage
  allocation, other threads, post-stop/thread-exit work, allocator metadata,
  internal realloc peaks, and unexecuted paths are outside the observation.
  External shared-library addresses remain unresolved. No universal capacity,
  all-thread closure, pressure/OOM, or complete TLS ownership proof follows.

Only new SSD extraction, copied-trace replay outputs, and review reports were
written. Tracked files, the immutable archive, original raw evidence, native
source, and protected vendors were not edited.
