// Test servers should echo whatever body they get, under ANY method:
// App.any() -> res.end(body)

const encoder = new TextEncoder();
const decoder = new TextDecoder();

// Define test cases
interface TestCase {
    request: string;
    description: string;
    expectedStatus: [number, number][];
}

const testCases: TestCase[] = [
    {
        request: "G",
        description: "Fragmented method",
        expectedStatus: [[-1, -1]],
        expectedTimeout: true
    },
    {
        request: "GET ",
        description: "Fragmented URL 1",
        expectedStatus: [[-1, -1]],
        expectedTimeout: true
    },
    {
        request: "GET /hello",
        description: "Fragmented URL 2",
        expectedStatus: [[-1, -1]],
        expectedTimeout: true
    },
    {
        request: "GET /hello ",
        description: "Fragmented URL 3",
        expectedStatus: [[-1, -1]],
        expectedTimeout: true
    },
    {
        request: "GET /hello HTTP",
        description: "Fragmented HTTP version",
        expectedStatus: [[-1, -1]],
        expectedTimeout: true
    },
    {
        request: "GET /hello HTTP/1.1",
        description: "Fragmented request line",
        expectedStatus: [[-1, -1]],
        expectedTimeout: true
    },
    {
        request: "GET /hello HTTP/1.1\r",
        description: "Fragmented request line newline 1",
        expectedStatus: [[-1, -1]],
        expectedTimeout: true
    },
    {
        request: "GET /hello HTTP/1.1\r\n",
        description: "Fragmented request line newline 2",
        expectedStatus: [[-1, -1]],
        expectedTimeout: true
    },
    {
        request: "GET /hello HTTP/1.1\r\nHos",
        description: "Fragmented field name",
        expectedStatus: [[-1, -1]],
        expectedTimeout: true
    },
    {
        request: "GET /hello HTTP/1.1\r\nHost:",
        description: "Fragmented field value 1",
        expectedStatus: [[-1, -1]],
        expectedTimeout: true
    },
    {
        request: "GET /hello HTTP/1.1\r\nHost: ",
        description: "Fragmented field value 2",
        expectedStatus: [[-1, -1]],
        expectedTimeout: true
    },
    {
        request: "GET /hello HTTP/1.1\r\nHost: localhost",
        description: "Fragmented field value 3",
        expectedStatus: [[-1, -1]],
        expectedTimeout: true
    },
    {
        request: "GET /hello HTTP/1.1\r\nHost: localhost\r",
        description: "Fragmented field value 4",
        expectedStatus: [[-1, -1]],
        expectedTimeout: true
    },
    {
        request: "GET /hello HTTP/1.1\r\nHost: localhost\r\n",
        description: "Fragmented request",
        expectedStatus: [[-1, -1]],
        expectedTimeout: true
    },
    {
        request: "GET /hello HTTP/1.1\r\nHost: localhost\r\n\r",
        description: "Fragmented request termination",
        expectedStatus: [[-1, -1]],
        expectedTimeout: true
    },
    {
        request: "GET / \r\n\r\n",
        description: "Request without HTTP version",
        expectedStatus: [[400, 599]],
    },
    {
        request: "GET / HTTP/1.1\r\nHost: example.com\r\nExpect: 100-continue\r\n\r\n",
        description: "Request with Expect header",
        expectedStatus: [[100, 100], [200, 299]],
    },
    {
        request: "GET / HTTP/1.1\r\nHost: example.com\r\n\r\n",
        description: "Valid GET request",
        expectedStatus: [[200, 299]],
    },
    {
        request: "GET / HTTP/1.1\r\nhoSt:\texample.com\r\nempty:\r\n\r\n",
        description: "Valid GET request with edge cases",
        expectedStatus: [[200, 299]],
    },
    {
        request: "GET / HTTP/1.1\r\nHost: example.com\r\nX-Invalid[]: test\r\n\r\n",
        description: "Invalid header characters",
        expectedStatus: [[400, 499]],
    },
    {
        request: "GET / HTTP/1.1\r\nContent-Length: 5\r\n\r\n",
        description: "Missing Host header",
        expectedStatus: [[400, 499]],
    },
    {
        request: "GET / HTTP/1.1\r\nHost: example.com\r\nHost: example.org\r\n\r\n",
        description: "Multiple Host headers",
        expectedStatus: [[400, 499]],
    },
    {
        request: "GET / HTTP/1.1\r\nHost: example.com\r\nContent-Length: -123456789123456789123456789\r\n\r\n",
        description: "Overflowing negative Content-Length header",
        expectedStatus: [[400, 499]],
    },
    {
        request: "GET / HTTP/1.1\r\nHost: example.com\r\nContent-Length: -1234\r\n\r\n",
        description: "Negative Content-Length header",
        expectedStatus: [[400, 499]],
    },
    {
        request: "GET / HTTP/1.1\r\nHost: example.com\r\nContent-Length: abc\r\n\r\n",
        description: "Non-numeric Content-Length header",
        expectedStatus: [[400, 499]],
    },
    {
        request: "GET / HTTP/1.1\r\nHost: example.com\r\nX-Empty-Header: \r\n\r\n",
        description: "Empty header value",
        expectedStatus: [[200, 299]],
    },
    {
        request: "GET / HTTP/1.1\r\nHost: example.com\r\nX-Bad-Control-Char: test\x07\r\n\r\n",
        description: "Header containing invalid control character",
        expectedStatus: [[400, 499]],
    },
    {
        request: "GET / HTTP/9.9\r\nHost: example.com\r\n\r\n",
        description: "Invalid HTTP version",
        expectedStatus: [[400, 499], [500, 599]],
    },
    {
        request: "Extra lineGET / HTTP/1.1\r\nHost: example.com\r\n\r\n",
        description: "Invalid prefix of request",
        expectedStatus: [[400, 499], [500, 599]],
    },
    {
        request: "GET / HTTP/1.1\r\nHost: example.com\r\n\rSome-Header: Test\r\n\r\n",
        description: "Invalid line ending",
        expectedStatus: [[400, 499]],
    },
    {
        request: "POST / HTTP/1.1\r\nHost: example.com\r\nContent-Length: 5\r\n\r\nhello",
        description: "Valid POST request with body",
        expectedStatus: [[200, 299], [404, 404]],
        expectedBody: "hello"
    },
    {
        request: "POST / HTTP/1.1\r\nHost: example.com\r\nTransfer-Encoding: chunked\r\n\r\nc\r\nHellO world1\r\n0\r\n\r\n",
        description: "Chunked Transfer-Encoding",
        expectedStatus: [[200, 299]],
        expectedBody: "HellO world1"
    },    
    {
        request: "POST / HTTP/1.1\r\nHost: example.com\r\ncontent-LengtH: 5\r\nTransFer-Encoding: chunked\r\n\r\nc\r\nHellO world1\r\n0\r\n\r\n",
        description: "Conflicting Transfer-Encoding and Content-Length in varying case",
        expectedStatus: [[400, 499], [200, 299]],
        expectedBody: "HellO world1"
    },
];

// Get host and port from command-line arguments
const [host, port] = Deno.args;
if (!host || !port) {
    console.error("Usage: deno run --allow-net tcp_http_test.ts <host> <port>");
    Deno.exit(1);
}

// Run all test cases in parallel
async function runTests() {
    const results = await Promise.all(
        testCases.map((testCase) => runTestCase(testCase, host, parseInt(port, 10)))
    );

    const passedCount = results.filter((result) => result).length;
    console.log(`\n${passedCount} out of ${testCases.length} tests passed.`);
    if (passedCount != testCases.length) {
        Deno.exit(1);
    }
}

// Run a single test case with a 3-second timeout on reading
async function runTestCase(testCase: TestCase, host: string, port: number): Promise<boolean> {
    try {
        const conn = await Deno.connect({ hostname: host, port });
        conn.unref();

        // Send the request
        await conn.write(encoder.encode(testCase.request));

        // Set up a read timeout promise
        const readTimeout = new Promise<boolean>((resolve) => {
            const timeoutId = setTimeout(() => {
                if (testCase.expectedTimeout) {
                    console.error(`✅ ${testCase.description}: Server waited successfully`);
                    conn.close(); // Ensure the connection is closed on timeout
                    resolve(true);
                } else {
                    console.error(`❌ ${testCase.description}: Read operation timed out`);
                    conn.close(); // Ensure the connection is closed on timeout
                    resolve(false);
                }
            }, 500);

            const readPromise = (async () => {
                const buffer = new Uint8Array(1024);
                try {
                    // This should ideally wait 100ms to make sure it got the response in full
                    const bytesRead = await conn.read(buffer);

                    // Clear the timeout if read completes
                    clearTimeout(timeoutId);
                    const response = decoder.decode(buffer.subarray(0, bytesRead || 0));
                    const statusCode = parseStatusCode(response);
                    const body = parseBody(response);

                    const isSuccess = testCase.expectedStatus.some(
                        ([min, max]) => statusCode >= min && statusCode <= max
                    ) && (statusCode == 200 && testCase.expectedBody ? (body == testCase.expectedBody) : true);

                    console.log(
                        `${isSuccess ? "✅" : "❌"} ${testCase.description}: Response Status Code ${statusCode}, Expected ranges: ${JSON.stringify(testCase.expectedStatus)}`
                    );
                    conn.close();
                    return resolve(isSuccess);
                } catch {

                }
            })();
        });

        // Wait for the read operation or timeout
        return await readTimeout;

    } catch (error) {
        console.error(`Error in test "${testCase.description}":`, error);
        return false;
    }
}


// Parse the HTTP status code from the response
function parseStatusCode(response: string): number {
    const statusLine = response.split("\r\n")[0];
    const match = statusLine.match(/HTTP\/1\.\d (\d{3})/);
    return match ? parseInt(match[1], 10) : 0;
}

function parseBody(response: string): string {
    const bodyIndex = response.indexOf("\r\n\r\n");
    return bodyIndex !== -1 ? response.slice(bodyIndex + 4) : undefined;
}

// Run all tests
runTests();
