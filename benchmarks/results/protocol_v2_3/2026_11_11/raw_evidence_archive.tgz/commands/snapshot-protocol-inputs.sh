#!/usr/bin/env bash
set -eu
snapshot_dir=$1
mkdir -p "$snapshot_dir"
input_paths=(AGENTS.md CODING_CONVENTION.md CONTRIBUTE.md build.zig build.zig.zon builds src include examples tests scripts vendor .gitmodules .gitignore)
git rev-parse HEAD >"$snapshot_dir/base_commit.txt"
git status --short --untracked-files=all >"$snapshot_dir/working_tree_status.txt"
git ls-files --stage -- "${input_paths[@]}" >"$snapshot_dir/tracked_input_modes.txt"
git ls-files --others --exclude-standard -- "${input_paths[@]}" >"$snapshot_dir/untracked_inputs.txt"
git diff --binary HEAD -- "${input_paths[@]}" >"$snapshot_dir/tracked_inputs.patch"
git ls-files --cached --others --exclude-standard -z -- "${input_paths[@]}" |
    sort -zu >"$snapshot_dir/candidate_paths.list0"
: >"$snapshot_dir/build_inputs.list0"
: >"$snapshot_dir/build_inputs.sha256"
while IFS= read -r -d '' input_path; do
    if [[ -f "$input_path" || -L "$input_path" ]]; then
        printf '%s\0' "$input_path" >>"$snapshot_dir/build_inputs.list0"
        sha256sum "$input_path" >>"$snapshot_dir/build_inputs.sha256"
    fi
done <"$snapshot_dir/candidate_paths.list0"
tar --null --verbatim-files-from --no-recursion --mtime=@0 --owner=0 --group=0 --numeric-owner \
    -czf "$snapshot_dir/build_inputs.tgz" -T "$snapshot_dir/build_inputs.list0"
sha256sum "$snapshot_dir/build_inputs.tgz" >"$snapshot_dir/build_inputs_archive.sha256"

