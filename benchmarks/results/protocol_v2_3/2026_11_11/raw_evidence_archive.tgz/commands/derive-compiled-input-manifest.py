#!/usr/bin/env python3
import argparse
from pathlib import Path


def compiled_input(path):
    if path in ("build.zig", "build.zig.zon"):
        return True
    if path.startswith("src/tests/"):
        return False
    if path.startswith("tests/"):
        return path in ("tests/autobahn/main.zig", "tests/h1spec/main.zig")
    return path.startswith(("builds/", "src/", "include/", "examples/", "vendor/", "scripts/"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("snapshot_dir", type=Path)
    args = parser.parse_args()
    lines = (args.snapshot_dir / "build_inputs.sha256").read_text().splitlines(keepends=True)
    selected = []
    for line in lines:
        digest, path = line.rstrip("\n").split("  ", 1)
        if len(digest) != 64:
            raise RuntimeError("Unexpected checksum manifest format")
        if compiled_input(path):
            selected.append(line)
    (args.snapshot_dir / "compiled_build_inputs.sha256").write_text("".join(selected))
    print(f"{len(selected)} compiled/build metadata input hashes retained")


if __name__ == "__main__":
    main()

