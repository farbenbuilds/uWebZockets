#!/usr/bin/env bash
set -eu
nix --extra-experimental-features 'nix-command flakes' build \
    --impure \
    --no-link \
    --max-jobs 0 \
    --expr 'let
        flake = builtins.getFlake "path:/workspace/scripts/http3_compliance";
        pkgs = import flake.inputs.nixpkgs { system = "x86_64-linux"; };
    in [
        pkgs.coreutils
        pkgs.curl
        pkgs.gnugrep
        pkgs.jq
        pkgs.openssl
        pkgs.procps
        pkgs.python3
        pkgs.python3Packages.aioquic
        pkgs.glibc
    ]'

