#!/usr/bin/env bash
set -eu
protocol_dir='/tmp/uwz-v230-protocol.TUONFJEp'
repo='/home/foo/Desktop/Repos/uWebZockets'
if (exec 3<>/dev/tcp/127.0.0.1/8000) 2>/dev/null; then
    printf '%s\n' 'Port 8000 already has a listener; refusing to start a second server.'
    exit 1
fi
"$repo/zig-out/bin/h1spec" >"$protocol_dir/h1spec-server.log" 2>&1 &
server_pid=$!
printf '%s\n' "$server_pid" >"$protocol_dir/h1spec-server.pid"
stop_server() {
    if kill -0 "$server_pid" 2>/dev/null; then
        kill -TERM "$server_pid"
        set +e
        wait "$server_pid"
        stop_status=$?
        set -e
        printf 'h1spec server stop status: %s\n' "$stop_status"
    fi
}
trap stop_server EXIT
ready=false
for ((attempt=0; attempt<100; attempt++)); do
    if ! kill -0 "$server_pid" 2>/dev/null; then
        cat "$protocol_dir/h1spec-server.log"
        exit 1
    fi
    if (exec 3<>/dev/tcp/127.0.0.1/8000) 2>/dev/null; then
        ready=true
        break
    fi
    sleep 0.1
done
test "$ready" = true
cd "$protocol_dir/h1spec"
"$protocol_dir/deno" run --allow-net=127.0.0.1:8000 http_test.ts 127.0.0.1 8000 >"$protocol_dir/h1spec.log" 2>&1
cat "$protocol_dir/h1spec.log"

