#!/usr/bin/env bash
set -eu
nix --version
curl --version
python3 -c 'import aioquic; print("aioquic " + aioquic.__version__)'
printf 'runtime glibc: '
nix --extra-experimental-features 'nix-command flakes' eval \
    --raw \
    --impure \
    --expr 'let
        flake = builtins.getFlake "path:/workspace/scripts/http3_compliance";
        pkgs = import flake.inputs.nixpkgs { system = "x86_64-linux"; };
    in pkgs.glibc.outPath'
printf '\n'

