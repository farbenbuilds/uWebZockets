#!/usr/bin/env bash
set -eu
cd '/home/foo/Desktop/Repos/uWebZockets'
if (exec 3<>/dev/tcp/127.0.0.1/9001) 2>/dev/null; then
    printf '%s\n' 'Port 9001 already has a listener; refusing to start a second server.'
    exit 1
fi
set +e
'/tmp/uwz-v230-protocol.TUONFJEp/deno' run \
    --no-prompt \
    --allow-net=127.0.0.1:9001 \
    --allow-read=tests/autobahn,zig-out/bin \
    --allow-run=docker,zig-out/bin/autobahn_server \
    --allow-write=tests/autobahn/reports \
    tests/autobahn/server_test.js >'/tmp/uwz-v230-protocol.TUONFJEp/autobahn.log' 2>&1
gate_status=$?
set -e
tail -n 12 '/tmp/uwz-v230-protocol.TUONFJEp/autobahn.log'
printf 'Autobahn exit status: %s\n' "$gate_status"
exit "$gate_status"

