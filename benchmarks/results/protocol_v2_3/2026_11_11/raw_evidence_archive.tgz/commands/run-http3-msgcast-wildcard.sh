#!/usr/bin/env bash
set -euo pipefail
artifact_dir=/protocol/http3-msgcast-final/wildcard
server_binary=/workspace/zig-out/bin/http3_server
server_loader=/nix/store/m07h00fl6538s4gavrp66a20ka4hg7fy-glibc-2.42-67/lib/ld-linux-x86-64.so.2
server_libraries=/nix/store/m07h00fl6538s4gavrp66a20ka4hg7fy-glibc-2.42-67/lib
expectations=/workspace/scripts/http3_compliance/expectations.json
runtime_dir=$(mktemp -d /tmp/uwz-v230-protocol-wildcard.XXXXXXXX)
server_pid=""
mkdir -p "$artifact_dir/qlog" "$runtime_dir/certs"
cleanup() {
    exit_status=$?
    trap - EXIT
    if [[ -n "$server_pid" ]]; then
        if kill -0 "$server_pid" 2>/dev/null; then
            kill -TERM "$server_pid"
            for ((attempt=0; attempt<50; attempt++)); do
                if ! kill -0 "$server_pid" 2>/dev/null; then
                    break
                fi
                sleep 0.1
            done
            if kill -0 "$server_pid" 2>/dev/null; then
                printf '%s\n' 'Wildcard server did not stop after SIGTERM.' >&2
                kill -KILL "$server_pid"
                exit_status=1
            fi
        fi
        server_exit=0
        wait "$server_pid" || server_exit=$?
        printf '%s\n' "$server_exit" >"$artifact_dir/server_exit.status"
        if [[ "$server_exit" -ne 0 && "$exit_status" -eq 0 ]]; then
            exit_status=$server_exit
        fi
    fi
    rm -rf -- "$runtime_dir"
    exit "$exit_status"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM HUP
openssl req -x509 -newkey rsa:2048 -nodes -days 1 \
    -subj '/CN=localhost' \
    -addext 'subjectAltName=DNS:localhost,IP:127.0.0.1,IP:127.0.0.2' \
    -keyout "$runtime_dir/certs/key.pem" \
    -out "$runtime_dir/certs/cert.pem" >"$artifact_dir/certificate_generation.log" 2>&1
(
    cd "$runtime_dir"
    exec "$server_loader" --library-path "$server_libraries" "$server_binary"
) >"$artifact_dir/server.log" 2>&1 &
server_pid=$!
printf '%s\n' "$server_pid" >"$artifact_dir/server.pid"
ready=false
for ((attempt=0; attempt<80; attempt++)); do
    if ! kill -0 "$server_pid" 2>/dev/null; then
        printf '%s\n' 'Wildcard server exited before readiness.' >&2
        exit 1
    fi
    if curl --http3-only --insecure --silent --show-error \
        --connect-timeout 1 --max-time 2 --output "$artifact_dir/readiness.body" \
        https://127.0.0.2:8443/ 2>>"$artifact_dir/readiness.log"; then
        ready=true
        break
    fi
    sleep 0.25
done
test "$ready" = true
curl --http3-only --insecure --fail-with-body --silent --show-error \
    --connect-timeout 5 --max-time 10 \
    --trace-time --trace-ascii "$artifact_dir/curl.trace" \
    --dump-header "$artifact_dir/curl.headers" \
    --output "$artifact_dir/curl.body" \
    --write-out '%{http_version}\n%{response_code}\n' \
    https://127.0.0.2:8443/ >"$artifact_dir/curl.metadata"
test "$(sed -n '1p' "$artifact_dir/curl.metadata")" = "$(jq -r '.response.http_version' "$expectations")"
test "$(sed -n '2p' "$artifact_dir/curl.metadata")" = "$(jq -r '.response.status' "$expectations")"
test "$(sha256sum "$artifact_dir/curl.body" | cut -d ' ' -f 1)" = "$(jq -r '.response.body_sha256' "$expectations")"
python3 /workspace/scripts/http3_compliance/aioquic_probe.py \
    --expectations "$expectations" \
    --host 127.0.0.2 \
    --output "$artifact_dir/aioquic_results.json" \
    --qlog-dir "$artifact_dir/qlog" >"$artifact_dir/aioquic.log" 2>&1
kill -0 "$server_pid"
printf '%s\n' 'HTTP/3 wildcard 127.0.0.2 compliance probe passed'

