#!/usr/bin/env bash
set -eu
export HTTP3_ARTIFACT_DIR=/protocol/http3-artifacts
export HTTP3_SERVER_BIN=/workspace/zig-out/bin/http3_server
export HTTP3_SERVER_DYNAMIC_LINKER=/nix/store/m07h00fl6538s4gavrp66a20ka4hg7fy-glibc-2.42-67/lib/ld-linux-x86-64.so.2
export HTTP3_SERVER_LIBRARY_PATH=/nix/store/m07h00fl6538s4gavrp66a20ka4hg7fy-glibc-2.42-67/lib
printf '%s\n' "$HTTP3_SERVER_DYNAMIC_LINKER" "$HTTP3_SERVER_LIBRARY_PATH" >"$HTTP3_ARTIFACT_DIR/runtime_loader.log"
exec bash /workspace/scripts/http3_compliance/run.sh

