#!/usr/bin/env python3
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--artifact-dir", type=Path, required=True)
    args = parser.parse_args()
    root = args.artifact_dir
    contract_bytes = (root / "contract.json").read_bytes()
    contract = json.loads(contract_bytes)
    contract_hash = hashlib.sha256(contract_bytes).hexdigest()
    expected_hash = "26fdca33b503f0f90b3540fb80889cbe9435305ae30891ebe416831b96be599f"
    if contract_hash != expected_hash:
        raise RuntimeError("Collected contract does not match the approved pre-data hash")
    if (root / "cohort_exit.status").read_text().strip() != "0":
        raise RuntimeError("Cohort exited nonzero")
    samples = []
    count = contract["measured_requests"]
    for index, label in enumerate(contract["sample_order"], 1):
        sample_dir = root / f"sample-{index:02d}-{label}"
        result = json.loads((sample_dir / "result.json").read_text())
        if result["status"] != "passed" or result["contract_sha256"] != contract_hash:
            raise RuntimeError(f"Sample {index} was invalid")
        if result["sample_index"] != index or result["label"] != label:
            raise RuntimeError(f"Sample {index} label/order mismatch")
        if result["warmup"]["completed"] != contract["warmup_requests"] or result["warmup"]["errors"]:
            raise RuntimeError(f"Sample {index} warmup mismatch")
        measured = result["measured"]
        if measured["completed"] != count or measured["errors"] or measured["incomplete"]:
            raise RuntimeError(f"Sample {index} incomplete or failed")
        with (sample_dir / "latencies.csv").open(newline="") as source:
            rows = list(csv.DictReader(source))
        indices = [int(row["request_index"]) for row in rows]
        if len(rows) != count or sorted(indices) != list(range(count)):
            raise RuntimeError(f"Sample {index} raw request coverage mismatch")
        ordered = sorted(int(row["latency_ns"]) for row in rows)
        percentiles = {
            "p50": ordered[(count - 1) // 2],
            "p99": ordered[(99 * count + 99) // 100 - 1],
            "p999": ordered[(999 * count + 999) // 1000 - 1],
            "maximum": ordered[-1],
        }
        if percentiles != result["latency_ns"]:
            raise RuntimeError(f"Sample {index} raw percentile mismatch")
        actual_rate = count * 1_000_000_000 / measured["duration_ns"]
        if not math.isclose(actual_rate, result["requests_per_second"], rel_tol=1e-12):
            raise RuntimeError(f"Sample {index} raw duration/rate mismatch")
        if (sample_dir / "server_exit.status").read_text().strip() != "0":
            raise RuntimeError(f"Sample {index} server did not exit cleanly")
        server_ticks = result["server_cpu_after_ticks"] - result["server_cpu_before_ticks"]
        client_ticks = result["client_cpu_after_ticks"] - result["client_cpu_before_ticks"]
        if server_ticks != result["server_cpu_delta_ticks"] or client_ticks != result["client_cpu_delta_ticks"]:
            raise RuntimeError(f"Sample {index} raw CPU counter mismatch")
        samples.append({
            "sample_index": index,
            "label": label,
            "completed": count,
            "errors": 0,
            "duration_ns": measured["duration_ns"],
            "requests_per_second": actual_rate,
            "latency_ns": percentiles,
            "server_cpu_delta_ticks": server_ticks,
            "client_cpu_delta_ticks": client_ticks,
            "ticks_per_second": result["ticks_per_second"],
            "server_rss_before_kib": result["server_rss_before_kib"],
            "server_rss_after_kib": result["server_rss_after_kib"],
        })
    medians = {}
    for label in ("old", "new"):
        selected = [sample for sample in samples if sample["label"] == label]
        medians[label] = {
            "requests_per_second": statistics.median(sample["requests_per_second"] for sample in selected),
            "minimum_requests_per_second": min(sample["requests_per_second"] for sample in selected),
            "maximum_requests_per_second": max(sample["requests_per_second"] for sample in selected),
            "sample_p50_ns": statistics.median(sample["latency_ns"]["p50"] for sample in selected),
            "sample_p99_ns": statistics.median(sample["latency_ns"]["p99"] for sample in selected),
        }
    summary = {
        "status": "collection_validated",
        "interpretation": "Shared-host diagnostic only; no GRO-only attribution, improvement claim, or official acceptance.",
        "contract_sha256": contract_hash,
        "measured_requests_total": len(samples) * count,
        "samples": samples,
        "medians": medians,
    }
    (root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()

