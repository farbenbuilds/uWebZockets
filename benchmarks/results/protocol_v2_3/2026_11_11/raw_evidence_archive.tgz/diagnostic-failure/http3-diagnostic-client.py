#!/usr/bin/env python3
import argparse
import asyncio
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import ssl
import sys
import time
import traceback

import aioquic
from aioquic.asyncio.client import connect
from aioquic.h3.connection import H3_ALPN
from aioquic.quic.configuration import QuicConfiguration

sys.path.insert(0, "/workspace/scripts/http3_compliance")
import aioquic_probe as probe


def cpu_ticks(pid):
    fields = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
    return int(fields[11]) + int(fields[12])


def rss_kib(pid):
    for line in Path(f"/proc/{pid}/status").read_text().splitlines():
        if line.startswith("VmRSS:"):
            return int(line.split()[1])
    raise RuntimeError(f"VmRSS unavailable for PID {pid}")


def percentile(values, fraction):
    return values[max(0, math.ceil(len(values) * fraction) - 1)]


async def run_phase(protocol, headers, count, concurrency, timeout, expected):
    state = {"next_index": 0}
    latencies = [None] * count
    errors = []

    async def worker():
        while not errors:
            index = state["next_index"]
            state["next_index"] += 1
            if index >= count:
                return
            started = time.perf_counter_ns()
            try:
                outcome = await protocol.request(headers, timeout)
                elapsed = time.perf_counter_ns() - started
                probe.assert_response(f"request {index}", outcome, expected)
                latencies[index] = elapsed
            except Exception as error:
                errors.append({
                    "request_index": index,
                    "latency_ns": time.perf_counter_ns() - started,
                    "error_type": type(error).__name__,
                    "error": str(error),
                })
                return

    started = time.perf_counter_ns()
    await asyncio.gather(*(worker() for _ in range(concurrency)))
    duration = time.perf_counter_ns() - started
    completed = sum(value is not None for value in latencies)
    return {
        "duration_ns": duration,
        "completed": completed,
        "incomplete": count - completed,
        "errors": errors,
        "latencies": latencies,
    }


async def collect(args, contract, result):
    if aioquic.__version__ != contract["clients"]["aioquic"]:
        raise RuntimeError("aioquic version does not match the declared contract")
    if contract["endpoint"]["path"] != "/":
        raise RuntimeError("Probe request_headers requires the declared root path")
    endpoint = contract["endpoint"]
    configuration = QuicConfiguration(is_client=True, alpn_protocols=H3_ALPN)
    configuration.verify_mode = ssl.CERT_NONE
    headers = probe.request_headers(f'{endpoint["host"]}:{endpoint["port"]}'.encode())
    async with connect(
        endpoint["host"],
        endpoint["port"],
        configuration=configuration,
        create_protocol=probe.ProbeProtocol,
        wait_connected=True,
    ) as protocol:
        warmup = await run_phase(
            protocol, headers, contract["warmup_requests"], contract["concurrency"],
            contract["request_timeout_seconds"], contract["expected_response"],
        )
        result["warmup"] = {key: value for key, value in warmup.items() if key != "latencies"}
        if warmup["errors"] or warmup["incomplete"]:
            raise RuntimeError("Warmup failed; measured requests were not started")
        result["server_cpu_before_ticks"] = cpu_ticks(args.server_pid)
        result["client_cpu_before_ticks"] = cpu_ticks(os.getpid())
        result["server_rss_before_kib"] = rss_kib(args.server_pid)
        measured = await run_phase(
            protocol, headers, contract["measured_requests"], contract["concurrency"],
            contract["request_timeout_seconds"], contract["expected_response"],
        )
        result["measured"] = {key: value for key, value in measured.items() if key != "latencies"}
        try:
            result["server_cpu_after_ticks"] = cpu_ticks(args.server_pid)
            result["client_cpu_after_ticks"] = cpu_ticks(os.getpid())
            result["server_rss_after_kib"] = rss_kib(args.server_pid)
        finally:
            with (args.output_dir / "latencies.csv").open("w", newline="") as output:
                writer = csv.writer(output)
                writer.writerow(["request_index", "latency_ns"])
                for index, latency in enumerate(measured["latencies"]):
                    if latency is not None:
                        writer.writerow([index, latency])
        if measured["errors"] or measured["incomplete"]:
            raise RuntimeError("Measured requests failed; the sample and cohort are invalid")
        ordered = sorted(measured["latencies"])
        result["requests_per_second"] = measured["completed"] * 1_000_000_000 / measured["duration_ns"]
        result["latency_ns"] = {
            "p50": percentile(ordered, 0.5),
            "p99": percentile(ordered, 0.99),
            "p999": percentile(ordered, 0.999),
            "maximum": ordered[-1],
        }
        result["server_cpu_delta_ticks"] = result["server_cpu_after_ticks"] - result["server_cpu_before_ticks"]
        result["client_cpu_delta_ticks"] = result["client_cpu_after_ticks"] - result["client_cpu_before_ticks"]
        result["status"] = "passed"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--contract-sha256", required=True)
    parser.add_argument("--sample-index", type=int, required=True)
    parser.add_argument("--label", choices=("old", "new"), required=True)
    parser.add_argument("--server-pid", type=int, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    contract_bytes = args.contract.read_bytes()
    actual_hash = hashlib.sha256(contract_bytes).hexdigest()
    if actual_hash != args.contract_sha256:
        raise RuntimeError("Diagnostic contract changed before collection")
    contract = json.loads(contract_bytes)
    if contract["sample_order"][args.sample_index - 1] != args.label:
        raise RuntimeError("Sample order differs from the declared contract")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    result = {
        "status": "failed",
        "sample_index": args.sample_index,
        "label": args.label,
        "contract_sha256": actual_hash,
        "aioquic_version": aioquic.__version__,
        "ticks_per_second": os.sysconf("SC_CLK_TCK"),
        "server_pid": args.server_pid,
        "client_pid": os.getpid(),
        "requested_measured_requests": contract["measured_requests"],
    }
    exit_status = 0
    try:
        asyncio.run(collect(args, contract, result))
    except Exception as error:
        result["exception"] = {"type": type(error).__name__, "message": str(error)}
        traceback.print_exc()
        exit_status = 1
    (args.output_dir / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))
    return exit_status


if __name__ == "__main__":
    raise SystemExit(main())

