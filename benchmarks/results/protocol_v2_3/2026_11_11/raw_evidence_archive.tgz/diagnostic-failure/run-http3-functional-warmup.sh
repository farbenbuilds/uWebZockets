#!/usr/bin/env bash
set -euo pipefail
artifact_dir=/protocol/http3-functional-warmup-candidate
server_binary=/workspace/zig-out/bin/http3_server
server_loader=/nix/store/m07h00fl6538s4gavrp66a20ka4hg7fy-glibc-2.42-67/lib/ld-linux-x86-64.so.2
server_libraries=/nix/store/m07h00fl6538s4gavrp66a20ka4hg7fy-glibc-2.42-67/lib
expectations=/workspace/scripts/http3_compliance/expectations.json
runtime_dir=$(mktemp -d /tmp/uwz-v230-protocol-wildcard.XXXXXXXX)
server_pid=""
mkdir -p "$artifact_dir/qlog" "$runtime_dir/certs"
cleanup() {
    exit_status=$?
    trap - EXIT
    if [[ -n "$server_pid" ]]; then
        if kill -0 "$server_pid" 2>/dev/null; then
            kill -TERM "$server_pid"
            for ((attempt=0; attempt<50; attempt++)); do
                if ! kill -0 "$server_pid" 2>/dev/null; then
                    break
                fi
                sleep 0.1
            done
            if kill -0 "$server_pid" 2>/dev/null; then
                printf '%s\n' 'Functional warmup server did not stop after SIGTERM.' >&2
                kill -KILL "$server_pid"
                exit_status=1
            fi
        fi
        server_exit=0
        wait "$server_pid" || server_exit=$?
        printf '%s\n' "$server_exit" >"$artifact_dir/server_exit.status"
        if [[ "$server_exit" -ne 0 && "$exit_status" -eq 0 ]]; then
            exit_status=$server_exit
        fi
    fi
    rm -rf -- "$runtime_dir"
    exit "$exit_status"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM HUP
openssl req -x509 -newkey rsa:2048 -nodes -days 1 \
    -subj '/CN=localhost' \
    -addext 'subjectAltName=DNS:localhost,IP:127.0.0.1,IP:127.0.0.1' \
    -keyout "$runtime_dir/certs/key.pem" \
    -out "$runtime_dir/certs/cert.pem" >"$artifact_dir/certificate_generation.log" 2>&1
(
    cd "$runtime_dir"
    exec "$server_loader" --library-path "$server_libraries" "$server_binary"
) >"$artifact_dir/server.log" 2>&1 &
server_pid=$!
printf '%s\n' "$server_pid" >"$artifact_dir/server.pid"
ready=false
for ((attempt=0; attempt<80; attempt++)); do
    if ! kill -0 "$server_pid" 2>/dev/null; then
        printf '%s\n' 'Functional warmup server exited before readiness.' >&2
        exit 1
    fi
    if curl --http3-only --insecure --silent --show-error \
        --connect-timeout 1 --max-time 2 --output "$artifact_dir/readiness.body" \
        https://127.0.0.1:8443/ 2>>"$artifact_dir/readiness.log"; then
        ready=true
        break
    fi
    sleep 0.25
done
test "$ready" = true
python3 /protocol/http3-functional-warmup.py --output "$artifact_dir/result.json" >"$artifact_dir/client.log" 2>&1
cat "$artifact_dir/result.json"
