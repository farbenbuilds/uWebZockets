#!/usr/bin/env bash
set -euo pipefail
cd /workspace
contract=/protocol/http3-diagnostic-contract.json
contract_hash=26fdca33b503f0f90b3540fb80889cbe9435305ae30891ebe416831b96be599f
artifact_dir=/protocol/http3-diagnostic
server_loader=/nix/store/m07h00fl6538s4gavrp66a20ka4hg7fy-glibc-2.42-67/lib/ld-linux-x86-64.so.2
server_libraries=/nix/store/m07h00fl6538s4gavrp66a20ka4hg7fy-glibc-2.42-67/lib
test "$(sha256sum "$contract" | cut -d ' ' -f 1)" = "$contract_hash"
test "$(sha256sum /protocol/http3-before-gro-server | cut -d ' ' -f 1)" = "$(jq -r '.old.sha256' "$contract")"
sha256sum --check /protocol/http3-diagnostic-binaries-declared.sha256
sha256sum --check /protocol/http3-input-sha256.txt
if [[ -e "$artifact_dir/collection_started.txt" ]]; then
    printf '%s\n' 'Refusing to overwrite or rerun an existing diagnostic cohort.' >&2
    exit 1
fi
mkdir -p "$artifact_dir"
runtime_dir=$(mktemp -d /tmp/uwz-v230-protocol-diagnostic.XXXXXXXX)
server_pid=""
sample_dir=""
stop_server() {
    if [[ -z "$server_pid" ]]; then
        return
    fi
    if kill -0 "$server_pid" 2>/dev/null; then
        kill -TERM "$server_pid"
        for ((attempt=0; attempt<50; attempt++)); do
            if ! kill -0 "$server_pid" 2>/dev/null; then
                break
            fi
            sleep 0.1
        done
        if kill -0 "$server_pid" 2>/dev/null; then
            printf '%s\n' 'Diagnostic server did not stop after SIGTERM.' >&2
            kill -KILL "$server_pid"
        fi
    fi
    server_exit=0
    wait "$server_pid" || server_exit=$?
    printf '%s\n' "$server_exit" >"$sample_dir/server_exit.status"
    server_pid=""
    test "$server_exit" -eq 0
}
cleanup() {
    exit_status=$?
    trap - EXIT
    if [[ -n "$server_pid" ]]; then
        set +e
        stop_server
        stop_status=$?
        set -e
        if [[ "$exit_status" -eq 0 && "$stop_status" -ne 0 ]]; then
            exit_status=$stop_status
        fi
    fi
    rm -rf -- "$runtime_dir"
    printf '%s\n' "$exit_status" >"$artifact_dir/cohort_exit.status"
    exit "$exit_status"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM HUP
date -u '+%Y-%m-%dT%H:%M:%SZ' >"$artifact_dir/collection_started.txt"
cp "$contract" "$artifact_dir/contract.json"
cp /protocol/http3-diagnostic-binaries-declared.sha256 "$artifact_dir/binaries.sha256"
sha256sum /protocol/http3-diagnostic-client.py /protocol/run-http3-diagnostic.sh /workspace/scripts/http3_compliance/aioquic_probe.py >"$artifact_dir/driver_and_helper.sha256"
nix --version >"$artifact_dir/tools.txt"
curl --version >>"$artifact_dir/tools.txt"
python3 -c 'import aioquic; print("aioquic " + aioquic.__version__)' >>"$artifact_dir/tools.txt"
mkdir -p "$runtime_dir/certs"
openssl req -x509 -newkey rsa:2048 -nodes -days 1 \
    -subj '/CN=localhost' \
    -addext 'subjectAltName=DNS:localhost,IP:127.0.0.1' \
    -keyout "$runtime_dir/certs/key.pem" \
    -out "$runtime_dir/certs/cert.pem" >"$artifact_dir/certificate_generation.log" 2>&1
openssl x509 -in "$runtime_dir/certs/cert.pem" -noout -sha256 -fingerprint -dates >"$artifact_dir/test_certificate.log"
mapfile -t sample_order < <(jq -r '.sample_order[]' "$contract")
sample_index=0
for label in "${sample_order[@]}"; do
    sample_index=$((sample_index + 1))
    sample_dir=$(printf '%s/sample-%02d-%s' "$artifact_dir" "$sample_index" "$label")
    mkdir -p "$sample_dir"
    binary=$(jq -r --arg label "$label" '.[$label].binary' "$contract")
    sha256sum --check "$artifact_dir/binaries.sha256" >"$sample_dir/binary_check.log"
    sha256sum "$binary" >"$sample_dir/binary.sha256"
    (
        cd "$runtime_dir"
        exec "$server_loader" --library-path "$server_libraries" "$binary"
    ) >"$sample_dir/server.log" 2>&1 &
    server_pid=$!
    printf '%s\n' "$server_pid" >"$sample_dir/server.pid"
    ready=false
    for ((attempt=0; attempt<80; attempt++)); do
        if ! kill -0 "$server_pid" 2>/dev/null; then
            printf '%s\n' 'Diagnostic server exited before readiness.' >&2
            exit 1
        fi
        if curl --http3-only --insecure --silent --show-error \
            --connect-timeout 1 --max-time 2 --output "$sample_dir/readiness.body" \
            https://127.0.0.1:8443/ 2>>"$sample_dir/readiness.log"; then
            ready=true
            break
        fi
        sleep 0.25
    done
    test "$ready" = true
    python3 /protocol/http3-diagnostic-client.py \
        --contract "$contract" \
        --contract-sha256 "$contract_hash" \
        --sample-index "$sample_index" \
        --label "$label" \
        --server-pid "$server_pid" \
        --output-dir "$sample_dir" >"$sample_dir/client.log" 2>&1
    stop_server
    cat "$sample_dir/result.json"
done
date -u '+%Y-%m-%dT%H:%M:%SZ' >"$artifact_dir/collection_finished.txt"
printf '%s\n' 'Fixed HTTP/3 diagnostic collection completed'

