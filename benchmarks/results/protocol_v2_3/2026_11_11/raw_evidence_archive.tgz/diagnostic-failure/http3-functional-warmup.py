#!/usr/bin/env python3
import argparse
import asyncio
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import traceback

spec = importlib.util.spec_from_file_location("diagnostic_client", "/protocol/http3-diagnostic-client.py")
driver = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = driver
spec.loader.exec_module(driver)


async def reproduce(contract):
    endpoint = contract["endpoint"]
    configuration = driver.QuicConfiguration(is_client=True, alpn_protocols=driver.H3_ALPN)
    configuration.verify_mode = driver.ssl.CERT_NONE
    headers = driver.probe.request_headers(f'{endpoint["host"]}:{endpoint["port"]}'.encode())
    async with driver.connect(
        endpoint["host"], endpoint["port"], configuration=configuration,
        create_protocol=driver.probe.ProbeProtocol, wait_connected=True,
    ) as protocol:
        return await driver.run_phase(
            protocol, headers, contract["warmup_requests"], contract["concurrency"],
            contract["request_timeout_seconds"], contract["expected_response"],
        )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    contract_bytes = Path("/protocol/http3-diagnostic-contract.json").read_bytes()
    actual_hash = hashlib.sha256(contract_bytes).hexdigest()
    if actual_hash != "26fdca33b503f0f90b3540fb80889cbe9435305ae30891ebe416831b96be599f":
        raise RuntimeError("Approved contract changed")
    contract = json.loads(contract_bytes)
    result = {
        "purpose": "Candidate-only unchanged warmup functional reproduction; no measured phase or throughput sample.",
        "contract_sha256": actual_hash,
        "requests": contract["warmup_requests"],
        "concurrency": contract["concurrency"],
        "timeout_seconds": contract["request_timeout_seconds"],
        "aioquic_version": driver.aioquic.__version__,
        "status": "failed",
    }
    try:
        phase = asyncio.run(reproduce(contract))
        result["phase"] = {key: value for key, value in phase.items() if key != "latencies"}
        if phase["completed"] == contract["warmup_requests"] and not phase["errors"] and phase["incomplete"] == 0:
            result["status"] = "passed"
    except Exception as error:
        result["exception"] = {"type": type(error).__name__, "message": str(error)}
        traceback.print_exc()
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())

