# Successful HTTP/3 request EOF lifecycle

Pinned dependency: farbenbuilds/lsquic 85bd081c9103c077a7cc98271d09334d0f1043d4.

The read API reports EOF using STREAM_FIN_REACHED but does not mark
STREAM_U_READ_DONE. The native close callback requires both user halves done.
The adapter had stopped read interest without acknowledging user-read shutdown
on successful buffered and streaming-body completion. Response completion
closed only the write half, retaining native streams and initial stream credit.

Primary source: https://github.com/farbenbuilds/lsquic/blob/85bd081c9103c077a7cc98271d09334d0f1043d4/src/liblsquic/lsquic_stream.c#L744
Read EOF: https://github.com/farbenbuilds/lsquic/blob/85bd081c9103c077a7cc98271d09334d0f1043d4/src/liblsquic/lsquic_stream.c#L1681
Shutdown: https://github.com/farbenbuilds/lsquic/blob/85bd081c9103c077a7cc98271d09334d0f1043d4/src/liblsquic/lsquic_stream.c#L1938

Both preserved pre-ownership/pre-GRO server and the combined pre-fix server
completed exactly 128 of 1024 valid requests on one connection with 32 active
streams, then timed out at five seconds. The diagnostic GET helper sets
end_stream=True; response futures finish only after received response FIN.
Protocol agent retains those independent live reproductions and the expanded
gate's red run. They are failed functional cohorts, not throughput results.

The narrow application fix acknowledges read shutdown after successful EOF and
body validation, before invoking buffered handlers or the streaming sink end.
A failed shutdown closes; streaming failure cancels its binding once after
clearing the reservation. Error/early-response and response write paths remain
unchanged. Native shutdown schedules on_close for later service dispatch;
it does not inline-release callback-owned storage.

Four focused fake-backend tests failed before the fix and all four pass after
it. They cover empty, ordinary and exact-capacity buffered EOF; cancellation
and close ordering on shutdown failure; successful streaming EOF; exactly-once
header/stream release and sink cancellation. Raw logs and isolated diff are
listed in /tmp/uwz-h3-lifecycle.sha256.

Formatting, conventions, and diff checks passed. Graphify update could not run
because the executable is absent (127). Full central suites, sanitizers,
cross-target and expanded real HTTP/3 gates are owned by root/protocol agents;
no unrun gate is claimed here. No dependency pin, cache, API, capacity, or
upstream repository was changed for this fix.
