# WebTransport positive-flow ordinary native evidence

Frozen runtime v2 passes the 17-case flow baseline, unchanged 77-case combined
stream/debt driver, and unchanged 33-case datagram driver in Debug, ReleaseSafe,
and ReleaseFast. The later DATA-zero FIN/RESET/STOP case passes separately in
each mode. All twelve invocations exited 0. Driver counts overlap through
helpers; these are not 384 independent protocol scenarios.

Final Root implementation commit:
`cc5013eb937bbf4066b153fe18c29bb999f68b85`. Its pure session-control predecessor
is `32a4830acafa6f0a40a0cce4ee32a858b18c207d`. Root source is byte-identical to
the retained v2 snapshot; no resnapshot or matrix rerun was needed for commits.

| Optimization mode | Flow baseline | Combined stream/debt | Datagrams | Added DATA-zero control case |
| --- | --- | --- | --- | --- |
| Debug | 17/17 | 77/77 | 33/33 | 1/1 |
| ReleaseSafe | 17/17 | 77/77 | 33/33 | 1/1 |
| ReleaseFast | 17/17 | 77/77 | 33/33 | 1/1 |

The exact raw summaries for each invocation are recorded in
[final_matrix.json](final_matrix.json), with unmodified log files and raw-log
SHA256 values in [raw_logs_sha256.txt](raw_logs_sha256.txt). Every successful
log contains `Build Summary: 16/16 steps succeeded` and its corresponding exact
`N/N tests passed` count. No performance result is inferred from test duration.

## Input binding and replay

The final fixture directory is the sibling
`uwz-wt-positive-flow-native-20261117`. Its `project_red`, `project_v1`, and
`project_v2` snapshots retain the exact source used for the corresponding trial.
Each snapshot has a source SHA256 manifest and successful independent copy
check. The complete v2 source/build/include manifest, including build metadata,
also matches Root after its documentation and formatting work: 266 files.

The 17-case baseline uses `trial_sources/flow17/tests/flow_main.zig` and its
neighboring exact test and helper source. All three SHA256 values match the
pre-extension [fixture_inputs_sha256.txt](fixture_inputs_sha256.txt). The test
file SHA256 is
`144a909ddffe7a714fba3ecafa2077523b4a4f7de476c8c4d6992e3b7eda8438`.
`tests/flow_main.zig` now imports the final 18-case test file; only the added
case was run after the extension. Final fixture hashes are kept separately in
[final_fixture_inputs_sha256.txt](final_fixture_inputs_sha256.txt).

The actual baseline commands were:

```sh
env UWZ_PROJECT_SOURCE=/tmp/uwz-wt-positive-flow-native-20261117/project_v2 \
  sh /tmp/uwz-wt-positive-flow-native-20261117/replay.sh Debug flow
sh /tmp/uwz-wt-positive-flow-native-20261117/run_ordinary_matrix.sh Debug debt datagrams
sh /tmp/uwz-wt-positive-flow-native-20261117/run_ordinary_matrix.sh ReleaseSafe flow debt datagrams
sh /tmp/uwz-wt-positive-flow-native-20261117/run_ordinary_matrix.sh ReleaseFast flow debt datagrams
```

The baseline flow source had 17 cases at that time. To replay those exact test
bytes after extraction, use `sh replay.sh MODE flow17`. To run only the added
control case, the actual command for each of the three modes was:

```sh
env UWZ_PROJECT_SOURCE=/tmp/uwz-wt-positive-flow-native-20261117/project_v2 \
  UWZ_TEST_FILTER='positive flow: DATA zero permits FIN RESET and STOP' \
  sh /tmp/uwz-wt-positive-flow-native-20261117/replay.sh MODE flow
```

All loopback invocations used host permission, `login=false`, `--system`,
`-j2`, and `--summary all`. The resolved compiler, external source revisions,
package directory, and cache paths at execution are in the matrix JSON.
Relocated replay defaults to its local `project_v2` and `.zig-cache`; external
compiler/package/dependency paths remain explicit environment overrides.

Native and libxev are external inputs. Their exact revisions, committed raw
artifact paths, archive SHA256 values, and extraction notes are in
[external_inputs.json](external_inputs.json). Neither their source trees nor
dependency binaries are copied into this archive. No maintained fork, pin,
workflow, or upstream repository was modified by this harness.

## Regression proof and failures

The actual RED command was the Debug flow replay with
`UWZ_PROJECT_SOURCE=.../project_red` and
`UWZ_TEST_FILTER='positive flow: over-limit early bytes'`. It exited 1 after
the test and all native libraries compiled successfully. The retained raw
[diagnostic log](red-early-bytes-diagnostic-debug.log) states:

```text
flow reset timeout expected=45d4487 auth=1 session=true opens=1 headers=1 status=200 resets={ 0, 0 } codes={ 0, 0 }
Build Summary: 14/16 steps succeeded (1 failed); 0/1 tests passed (1 failed)
```

Thus excess early body debt reached authorization and opened a session and
child before the fix. v1 already passed both early byte and early stream-count
rejections, but the full native suite exposed a distinct lazy-instantiation
compile defect: `engine.zig:400` passed `stream_api.Direction` to a budget
expecting `child_runtime.Direction`. Root corrected the explicit conversion
before v2. [v1-flow-debug.log](v1-flow-debug.log) retains this failure.

[setup-global-cache-readonly-debug.log](setup-global-cache-readonly-debug.log)
is a setup failure, not RED evidence: an explicit compile command initially
used the read-only default Zig cache. The writable global-cache override then
compiled every new harness test successfully against RED source. No test,
assertion, threshold, or expectation was weakened to obtain passing results.

Some passing logs retain `unowned child receive cancellation failed: invalid`
warnings and a literal `failed command` diagnostic despite terminal status 0
and passing build summaries. Raw output is preserved verbatim.

## Boundaries covered and retained limits

The flow cases exercise startup bilateral settings and one-sided/default-zero
ignore policy; pre-authorization early byte and stream limits; prefix-free
receipt, once-only debt transfer and RESET final-gap debit; local BIDI receive
counting; successful-only native creation and actual partial-write debit;
DATA-zero writable suppression and wire MAX_DATA recovery; serialized CONNECT
credits; blocked native credit acceptance and bounded wire recovery;
semantic WT_FLOW_CONTROL_ERROR versus malformed H3_MESSAGE_ERROR; and healthy
ordinary HTTP after session failures. The separate control case observes real
FIN, RESET code 101, and STOP code 102 at DATA zero while data debit and writable
notifications remain zero.

Every inherited test file remains byte-identical to the prior fixture. Two
inherited datagram reset-credit cases retain their private native receive-window
increment and are explicitly labeled in the fixture README. The inherited
callback-order injection keeps its original label and scope. New flow cases do
not mutate private native settings or receive windows.

Single-session-per-connection policy remains. These functional cases use the
shared Native client fixture and do not establish independent-client acceptance.
Dedicated smoke, security, sanitizer, and fuzz campaigns were user-deferred and
were not run. Caches, binaries, certificate/key files, private keys, and
credentials are excluded from the archive.
