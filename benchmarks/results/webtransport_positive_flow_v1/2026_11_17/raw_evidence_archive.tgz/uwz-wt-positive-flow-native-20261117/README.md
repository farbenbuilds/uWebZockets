# WebTransport positive session-flow functional fixture

This fixture runs ordinary native functional tests through the actual configured
App, TLS, and loopback UDP. It changes no dependency pin or maintained fork.
Dedicated smoke, security, sanitizer, and fuzz campaigns remain user-deferred.

The default frozen source is `project_v2`; `project_red` retains the pre-enforcement
interface and `project_v1` retains the first native API instantiation failure.
Source SHA256 manifests and independent copy-check output are retained in
`/tmp/uwz-wt-positive-flow-evidence-20261117`.

Native source: `d1104a9fab040af659295a95fb448c971a7bc6de`.
Libxev source: `5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`.
Compiler: Zig 0.16.0 at `/tmp/zig-x86_64-linux-0.16.0/zig`.
Packages: `/tmp/uwz-wt-child-callbacks-20261116/zig-pkg`.

Run `sh replay.sh MODE flow`, `sh replay.sh MODE debt`, or
`sh replay.sh MODE datagrams`; MODE is Debug, ReleaseSafe, or ReleaseFast.
The flow driver has 18 focused cases. The retained `flow17` driver is the exact
17-case source used for the completed baseline matrix; its SHA256 matches the
pre-extension input manifest. The additional DATA-zero control case is proven
separately in all three modes. The unchanged combined debt driver has
77 cases, including the retained stream assertions. The separate datagram driver
has 33 cases and shares helpers with the combined driver; counts across drivers
are not disjoint feature scenarios.

Two inherited datagram reset-credit cases stage a private native receive-window
increment before real wire updates: "actual App retries blocked message reset
after real peer response credit" and "actual App retries reset after blocked
Close capsule delays local FIN". Their assertions and inputs remain unchanged.
The inherited callback-order injection keeps its original label and scope.
The new flow cases use public pre-engine SETTINGS, public stream read
interest, actual CONNECT capsule bytes, and encrypted packet loss. They do not
mutate private native settings or receive windows.

The flow cases cover bilateral intent, one-sided/default-zero ignore policy,
early byte and stream debt before authorization, exact-once prefix-free receipt
and RESET final-gap accounting, local BIDI receive counting, native creation and
partial-write debit, DATA-zero writable suppression and MAX_DATA recovery,
serialized CONNECT grants, blocked grant acceptance and wire recovery, and
semantic WT_FLOW_CONTROL_ERROR versus malformed H3_MESSAGE_ERROR. A separate
DATA-zero case proves FIN, RESET, and STOP progress without spending data or
issuing writable notifications. Healthy
ordinary HTTP is checked after all relevant session failures.

`run_ordinary_matrix.sh MODE SUITE...` records terminal status and a separate raw
log for each invocation. Replay accepts `UWZ_ZIG`, `UWZ_PACKAGE_DIR`,
`UWZ_LIBXEV_SOURCE`, `UWZ_LSQUIC_SOURCE`, `UWZ_PROJECT_SOURCE`, `UWZ_CACHE_DIR`,
`UWZ_TEST_FILTER`, and `ZIG_GLOBAL_CACHE_DIR`. Keep the retained compiler,
packages, and source trees available or set explicit local overrides. Loopback
runs require the host permission used for the retained commands.

Multiple sessions per connection, independent-client acceptance, and dependency
fork publication remain open.
