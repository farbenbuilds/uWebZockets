#!/usr/bin/env python3
"""Reconcile the selected five-case fatal baseline and immutable zero assertion."""
import argparse
import csv
import json
from pathlib import Path

FIELDS=('malloc','calloc','realloc','free','bytes')
CASES=('empty_ticket','duplicate_flags','bad_mac','oversized_record','peer_fatal_alert')
FIRST=((2,0,0,0,40),(4,0,0,2,80),(4,0,0,2,128),(4,0,0,2,80),(4,0,0,0,124))
REASONS=((137,),(257,),(101,139),(146,),(1049,))
ALERTS=(50,47,20,22,49)


def verify(directory):
    for name in ('operations.csv','events.jsonl','summary.jsonl','lifetime.json'):
        assert (directory/('observe_'+name)).read_bytes()==(directory/('strict_'+name)).read_bytes(),name
    operations=list(csv.DictReader((directory/'observe_operations.csv').open()))
    events=[json.loads(line) for line in (directory/'observe_events.jsonl').read_text().splitlines()]
    rows=[json.loads(line) for line in (directory/'observe_summary.jsonl').read_text().splitlines()]
    assert len(operations)==len(events)==163 and [r['case'] for r in rows]==list(CASES)
    for index,(op,event) in enumerate(zip(operations,events)):
        assert event['index']==index
        assert (op['scenario'],op['phase'],int(op['step']),int(op['result']),int(op['error']))==(event['case'],event['phase'],event['step'],event['result'],event['error'])
        for entry in event['queue']:
            assert entry['library']==entry['packed']>>24 and entry['reason']==entry['packed']&0xffffff
            assert entry['line']>0 and entry['file'] and entry['flags'] in (0,3)
            assert entry['data']==('SSL alert number 49' if entry['flags']==3 else '')
    measured=[]
    for index,row in enumerate(rows):
        name=row['case'];selected=[(op,event) for op,event in zip(operations,events) if op['scenario']==name]
        warm=[op for op,_ in selected if op['phase'] in ('read','response_write')]
        fatal=[op for op,_ in selected if op['phase'] not in ('read','response_write')]
        assert len(warm)==25 and row['suite']==0x1301 and row['tls13_verified'] and row['hostname_verified'] and row['warm_payload_exact']
        assert row['warm_payload_each_direction']==4096 and row['post_fatal_read_cycles']==row['post_fatal_write_cycles']==3
        assert all(int(op[field])==0 for op in warm for field in FIELDS)
        assert sum(max(int(op['result']),0) for op in warm if op['phase']=='read')==4096
        assert sum(max(int(op['result']),0) for op in warm if op['phase']=='response_write')==4096
        assert len(fatal)==row['fatal_operations']
        assert {field:sum(int(op[field]) for op in fatal) for field in FIELDS}==row['fatal_calls']
        first=[op for op in fatal if op['phase']=='first_fatal_read'];assert len(first)==1
        assert all(int(op[field])==0 for op,_ in selected for field in FIELDS)
        assert tuple(entry['reason'] for entry in row['first_read_queue'])==REASONS[index]
        assert [entry['library'] for entry in row['first_read_queue']]==([30,16] if index==2 else [16])
        assert row['client_alerts']==[[0 if index==4 else 1,2,ALERTS[index]]]
        assert row['peer_alerts']==[[1 if index==4 else 0,2,ALERTS[index]]]
        assert row['positive_post_fatal_writes']==(index==4)
        for op,event in selected:
            if op['phase'] in ('read','response_write'):assert event['queue']==[];continue
            if op['phase']=='post_fatal_write':
                if index==4:assert (event['result'],event['error'],event['queue'])==(1,0,[])
                else:assert event['result']==-1 and event['error']==1 and [entry['reason'] for entry in event['queue']]==[194]
                continue
            assert event['result']==-1 and event['error']==1 and event['queue']==row['first_read_queue']
        measured.append({'case':name,'first_failure_vector':{field:int(first[0][field]) for field in FIELDS},
            'all_fatal_cross_lifetime_calls':row['fatal_calls'],'fatal_client_calls':len(fatal),
            'read_queue_libraries_reasons':[[entry['library'],entry['reason']] for entry in row['first_read_queue']]})
    lifetime=json.loads((directory/'observe_lifetime.json').read_text())
    assert all(lifetime[key] for key in ('cross_ssl_a_nondata_b_data_a_restore','cross_ssl_b_data_restore','popped_string_valid_after_ssl_free'))
    assert lifetime['popped_flags']==3 and lifetime['popped_reason']==1049
    assert lifetime['lifetime_read_result']==-1 and lifetime['lifetime_read_error']==1
    commands=json.loads((directory/'commands.json').read_text())
    statuses={entry['command'][-1]:entry['exit_code'] for entry in commands if entry['command'][-1] in ('--observe','--require-zero')}
    assert statuses=={'--observe':0,'--require-zero':0}
    result=json.loads((directory/'result.json').read_text());assert result['complete'] and result['private_pki_removed']
    return {'rows':5,'client_calls_per_run':163,'warm_calls':125,'fatal_cross_lifetime_calls':38,
        'functional_observe_exit':0,'strict_zero_exit':0,'raw_observe_strict_outputs_identical':True,
        'all_full_client_error_queues_and_flags_checked':True,'alert_order_and_peer_receipt_checked':True,
        'peer_fatal_successful_writes_preserved':True,'peer_received_exact_positive_post_fatal_bytes':3,
        'cross_ssl_restore_and_popped_string_lifetime_checked':True,'callsite_attribution':'source inference only',
        'measurements':measured,'complete_postgresql_allocation_gate_closed':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('directory',type=Path)
    print(json.dumps(verify(parser.parse_args().directory),indent=2))


if __name__=='__main__':main()
