#!/usr/bin/env python3
"""Build and run the unchanged bounded peer-alert allocation assertion twice."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root',type=Path)
    parser.add_argument('pki_helper',type=Path)
    parser.add_argument('output',type=Path)
    parser.add_argument('--expect-zero',action='store_true')
    args=parser.parse_args()
    base=Path(__file__).resolve().parent
    native=args.native_root.resolve(strict=True);helper=args.pki_helper.resolve(strict=True)
    output=args.output.absolute()
    if output.exists() or output.is_symlink():raise ValueError('Choose absent output')
    if digest(helper)!='531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':raise ValueError('PKI helper differs')
    if digest(base/'allocation_scope.c')!='afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac':raise ValueError('Original counter differs')
    output.mkdir(mode=0o700)
    zig='/tmp/zig-x86_64-linux-0.16.0/zig'
    env=dict(os.environ);env['ZIG_GLOBAL_CACHE_DIR']='/tmp/uwz-zig-cache'
    archives=[native/'native_out/lib/libssl.a',native/'native_out/lib/libcrypto.a']
    paths=['crypto/err/err.cc','crypto/err/internal.h','ssl/ssl_lib.cc','ssl/s3_pkt.cc','ssl/tls_record.cc','include/openssl/err.h','include/openssl/ssl.h']
    provenance={'optimization':'Debug (-O0 -g)','compiler':zig,'native_root':str(native),
        'archive_sha256':{p.name:digest(p) for p in archives},
        'source_subset_sha256':{name:digest(native/'boringssl'/name) for name in paths},
        'counter_sha256':digest(base/'allocation_scope.c'),'fixture_sha256':digest(base/'alert_witness.cc'),
        'pki_helper_sha256':digest(helper),'dedicated_smoke_security_sanitizer_fuzz_campaigns_run':False}
    (output/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
    commands=[]
    def run(command,name,status=0):
        with (output/(name+'.stdout')).open('wb') as out,(output/(name+'.stderr')).open('wb') as err:
            result=subprocess.run(command,cwd=output,env=env,stdout=out,stderr=err)
        commands.append({'command':command,'exit_code':result.returncode,'expected_exit_code':status})
        (output/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        if result.returncode!=status:raise RuntimeError('Unexpected status: '+name)
    pki=output/'private_pki';binary=output/'alert_witness';complete=False
    try:
        run([zig,'cc','-std=c11','-O0','-g','-c',str(base/'allocation_scope.c'),'-o',str(output/'allocation_scope.o')],'build-counter')
        run([zig,'c++','-std=c++17','-O0','-g','-fno-omit-frame-pointer','-Wall','-Wextra','-Werror','-DBORINGSSL_IMPLEMENTATION',
            '-isystem',str(native/'boringssl'),'-isystem',str(native/'boringssl/include'),str(base/'alert_witness.cc'),
            str(output/'allocation_scope.o'),*[str(path) for path in archives],'-o',str(binary)],'build-witness')
        run([str(helper),'pki',str(pki)],'pki-metadata')
        arguments=[str(pki/name) for name in ('server.pem','server.key','ca.pem')]
        for mode in ('observe','strict'):
            run([str(binary),*arguments,*[str(output/(mode+'_'+name)) for name in ('operations.csv','events.jsonl','summary.jsonl','lifetime.json')],
                '--observe' if mode=='observe' else '--require-zero'],mode,0 if mode=='observe' or args.expect_zero else 1)
        for name in ('operations.csv','events.jsonl','summary.jsonl','lifetime.json'):
            assert (output/('observe_'+name)).read_bytes()==(output/('strict_'+name)).read_bytes(),name
        complete=True
    finally:
        if pki.exists():
            names={p.name for p in pki.iterdir()}
            if names-{'ca.pem','server.pem','server.key'}:raise ValueError('Unexpected PKI files')
            for name in names:(pki/name).unlink()
            pki.rmdir()
        (output/'result.json').write_text(json.dumps({'complete':complete,'private_pki_removed':not pki.exists(),
            'binary_sha256':digest(binary) if binary.exists() else None,'strict_exit_code':0 if args.expect_zero else 1},indent=2)+'\n')
    print('PASS peer-alert functional observe0; unchanged strict allocation '+('GREEN0' if args.expect_zero else 'RED1')+'; owned PKI removed')


if __name__=='__main__':main()
