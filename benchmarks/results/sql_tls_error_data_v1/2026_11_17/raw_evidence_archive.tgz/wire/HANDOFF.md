# Phase B short error-data wire evidence

The unchanged reserved peer-alert allocation assertion is GREEN for all supported TLS1.3 cipher suites. Current unreserved controls remain functional and allocating. Prior metadata, ticket and KeyUpdate coverage also remains zero. The complete PostgreSQL/v2.3 gate is still open; this component adds no PostgreSQL allocation exception.

## Exact measured scope

| Group | Variant | Rows / client calls per selector | Gate |
|---|---|---|---|
| Fresh alert boundary baseline, actual0x1301 | Immutable Phase A native build, all reservations | 5 /164 | Observe0, strict RED1 |
| Same frozen alert input, actual0x1301 | Phase B reserved / unreserved | 5 /164 each | Reserved strict GREEN0; unreserved RED1 |
| Same five cases, actual0x1302 and0x1303 | Phase B reserved / unreserved | 5 /164 each suite/profile | Reserved strict GREEN0; unreserved RED1 |
| Inherited five-fault witness, actual0x1301 | Phase B reserved | 5 /163 | Full strict GREEN0, including old peer-fatal49 |
| Inherited ticket protocol | Phase B reserved | 27 /1320 | Every client count field zero, including18 fatal rows across all three suites |
| Inherited original public controls | Phase B reserved, original0x1301 scope | 12 /255 | Every client count field zero |

The three-suite alert totals are15 rows/492 client calls per selector/profile. The final source-free replay executes eight selected programs in18 runs and measures4197 complete client calls, counted from actual replay CSVs in `replay_call_totals.json`. It reproduces all retained raw operation/event/summary/lifetime files byte-for-byte. No old extra-suite baseline was rerun.

The original all-C counter remains SHA256 `afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac`; every executable requires malloc1/calloc1/realloc1/free2/requested63B selftest. Complete client `SSL_read`/`SSL_write` calls and immediate error classification are metered. Peer work, setup, queue observations, logging and teardown are outside those intervals. All new measurements use Zig0.16 Debug `-O0 -g`; no diagnostic counter substitutes for the zero assertion.

Fresh baseline first reads allocate2malloc/0free/83B for native fatal0,84B for public99 and85B for public255. Its public warning close0 and malformed one-byte input are already zero. Reserved Phase B makes all164 call vectors zero, including every repeat/cross/lifetime call. The current unreserved control first fatal0/99/255 reads each allocate2malloc/0free/72B; malformed one-byte processing allocates4malloc/2free/144B, while close0 remains zero. Generic private entries grow and short-copy behavior changes, so old allocation-array byte equality is deliberately not asserted. Actual changed vectors are retained in `comparison.json`; allocation call-site explanations are source inference, not measured return-address attribution.

## Protocol and ownership observations

Each new alert pair verifies a real CA/localhost TLS1.3 connection and asserts both actual negotiated cipher IDs after public singleton configuration with null flags. Existing record, incoming-handshake, AEAD-context, outgoing-KeyUpdate, validated ticket-discard and error-state reservations are enabled before exact4096B bidirectional warm traffic. The unreserved control removes only `SSL_reserve_error_state`; all other policies/input remain the same.

The five cases are: clearly labeled native-sealed fatal-level description0; genuine public `SSL_send_fatal_alert`99; genuine public fatal255; public warning-level close0 via `SSL_shutdown`; and a native-sealed one-byte malformed alert body. The pinned parser handles close_notify only in its warning branch. Fatal0 reaches the formatter and produces reason1000/text0, although the public fatal sender forbids0. No text is asserted for the warning close control. The malformed body fails length validation before an incoming alert callback, then its generated decode_error50 is actually received by the peer. No client parser/cipher fields are staged or sender callbacks manufactured for native-sealed negative inputs.

Each case requires three subsequent read/write cycles. Fatal0/99/255 and warning close0 preserve successful client writes and exact peer bytes0x71/0x72/0x73; malformed length preserves failed writes with SSL reason194. Warning close reads return0/SSL_ERROR_ZERO_RETURN6 with an empty queue. Fatal reads preserve full library/reason/text/flags, including STRING|MALLOCED3 for library-owned non-static strings. Immediate B255→A0→B255 calls restore distinct queue data on one thread. The popped255 string remains valid after client `SSL_free`, before a queue-modifying call. Full actual filename/line observations and callback alert order remain in raw logs.

`comparison.json` compares the frozen0x1301 source and current control, with explicit error-source statement/block/hash mappings. `extended_comparison.json` compares additional suites and the inherited fixtures. Its model adjusts only the declared suite field, retaining every other return/retry/diagnostic/callback field; raw logs are never rewritten. The source-backed and frozen-site offline reports are byte-identical. Inherited protocol/control diagnostics retain all fields available in their original witnesses (packed queues/alerts); filename/line mapping applies to the alert and five-fault witnesses that record those fields.

`alert_witness.cc` and the29-file `baseline_frozen.json` are unchanged pre-edit evidence. `cipher_input_delta.patch` documents the runtime cipher-selection copy; `unreserved_startup_delta.patch` and `unreserved_cipher_startup_delta.patch` remove just the one startup reservation. Inherited sources are byte-identical copies of Phase A inputs with their existing reservation compile option enabled: `inherited_source_inputs.json`, `inherited_reference_hashes.json` and `source_binding_verification.json` bind source/raw inputs and compiled hashes. Inherited late opaque tickets remain syntax/protocol inputs, not server-resumption claims; initial-ticket rows use actual server-issued tickets. Earlier producers, native source, protected vendor and repository files were not edited by this verifier.

Known wire text fits asserted fixed caller-owned witness storage; generic absent/empty,30/31/32-byte boundaries, aliases, long spill, marks/overflow and other ownership/lifecycle paths belong to the direct verifier. This wire witness does not truncate or claim coverage for arbitrary generic error strings. No ticket, key, session or context bytes/hashes are persisted. Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain deferred by user instruction.

## Native and delivery identities

Pre-edit native baseline: `.zig-cache/sql-tls-error-snapshot-fixed-20261117`.

- libssl.a `48e2928a79013579ddec9dea7bd1d750771e30a35d5091182db26af5555e960d`
- libcrypto.a `2143f831f9f57907f47a51dfc0fae9942f33b8c3ca6d378cca6cc90b387ea4dd`

Matching Phase B native build: `.zig-cache/sql-tls-error-data-fixed-20261117`.

- libssl.a `b0b35e16a11c00529cbae09abab58d18cf5ec84c7596aff600d59267db0aba30`
- libcrypto.a `e9cb29281bbc2b4dabb17863c1f7fbc51fdb93cb6ad2bdd016b481be443a1d9a`

Per-run provenance binds actual source/archives and the exact compiler/link/runtime commands and raw statuses. Source hash lists are subsets; complete archive hashes bind linked implementations. The frozen baseline runner inherited the previous shared `/tmp/uwz-zig-cache` setting, explicitly retained in its historical source/report; its outputs/PKI were on SSD. New variant, cipher and inherited builds use this owned scratch's SSD `zig_global_cache`. No old shared cache was deleted. Cache directories are excluded from the payload.

`original_measured_identity.json`, historical `baseline_frozen.json` and raw result/provenance IDs remain byte-identical original Debug measurement records. Current executable validation uses `prebuilt_identity.json` and `payload_manifest.json`. Delivery may transform only staged selected ELFs, refreshing eight current binary hashes and `delivery_stripping` false→true plus corresponding current manifest fields under separate ELF proof. Historical inventories/raw results must not be refreshed or rewritten. `verify_frozen.py` validates current delivery hashes without comparing historical Debug binary IDs against stripped copies.

## Replay and reproduction

From any directory, use an absent external output outside the evidence tree:

```sh
python3 /ABS/wire/replay_prebuilt.py --pki-tool /ABS/wt-tools --output /ABS/ABSENT_EXTERNAL_OUTPUT
```

The exact offline PKI helper SHA256 is `531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9`; original path `/tmp/uwz-wt-upstream-backport-client-20261117/client/wt-tools`. Owned ephemeral PKI is removed in finally blocks. Prebuilt replay needs no compiler/native source/native archives; it validates eight current executable IDs, expected functional/gate statuses, exact raw replay bytes, and offline semantic/site-map comparisons.

A self-relative replay passed from unselected `replay_stage/` into `replay_evidence/`, both inside owned SSD scratch. `replay_evidence/results.json` retains exact commands/statuses and cleanup. `replay_guards.json` records six rejections before output creation: existing output, own evidence tree, native/helper siblings inside a recognized combined root, dangling output symlink and wrong helper checksum. Combined-root detection preserves the hardened prior workflow and standalone own-tree fallback.

Rebuild with absent outputs using the recorded per-directory command arrays. Drivers are `run_alerts.py` (frozen baseline), `run_variant.py [--expect-zero|--unreserved]`, `run_suites.py [--unreserved]`, `run_inherited_fatal.py --reserve`, and `run_inherited.py --fixture protocol|control --reserve`. The native root and exact helper are explicit arguments. `--expect-zero` changes runner expected status only; the fixture's full zero assertion is unchanged.

The allowlist excludes caches, object/native archives, private PKI and unselected stage copies. Root owns final review, staged replay after delivery-only stripping, source integration, archive and commit/push. No further unrelated matrices were run.
