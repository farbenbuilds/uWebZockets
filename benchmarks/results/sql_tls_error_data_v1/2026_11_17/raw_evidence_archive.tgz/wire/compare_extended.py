#!/usr/bin/env python3
"""Reconcile accepted cipher coverage and inherited functional/zero regressions."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import compare_alerts
import verify_suites
import verify_inherited_fatal
import verify_protocol
import verify_controls

FIELDS=('malloc','calloc','realloc','free','bytes')


def json_rows(path):return [json.loads(line) for line in path.read_text().splitlines()]


def operations(path):return list(csv.DictReader(path.open()))


def tuples(rows):return [{k:v for k,v in row.items() if k not in FIELDS} for row in rows]


def compare(base,frozen):
    source=Path(__file__).resolve().parent;sites={};report=[]
    for reserved in (True,False):
        parent='candidate_suites' if reserved else 'candidate_unreserved_suites'
        reference=base/('candidate' if reserved else 'candidate_unreserved')
        ref_native=Path(json.loads((reference/'provenance.json').read_text())['native_root'])
        expected_source=source/('suite_witness.cc' if reserved else 'unreserved_suite_witness.cc')
        for suite in (0x1302,0x1303):
            current=base/parent/hex(suite)
            validation=verify_suites.verify(current,reserved,suite)
            provenance=json.loads((current/'provenance.json').read_text())
            assert provenance['suite']==suite and provenance['error_state_reserved']==reserved
            assert provenance['fixture_sha256']==hashlib.sha256(expected_source.read_bytes()).hexdigest()
            native=Path(provenance['native_root'])
            a=operations(reference/'observe_operations.csv');b=operations(current/'observe_operations.csv')
            assert tuples(a)==tuples(b)
            before=json_rows(reference/'observe_events.jsonl');after=json_rows(current/'observe_events.jsonl')
            compare_alerts.compare_value(before,after,ref_native,native,frozen,sites,reserved)
            before=[dict(row,suite=suite) for row in json_rows(reference/'observe_summary.jsonl')]
            after=json_rows(current/'observe_summary.jsonl')
            compare_alerts.compare_value(before,after,ref_native,native,frozen,sites,reserved)
            compare_alerts.compare_value(json.loads((reference/'observe_lifetime.json').read_text()),json.loads((current/'observe_lifetime.json').read_text()),ref_native,native,frozen,sites,reserved)
            report.append({'group':'alert_cipher_input','suite':suite,'reserved':reserved,
                'only_declared_suite_field_adjusted_in_comparison_model':True,'raw_logs_rewritten':False,
                'validation':validation,'all_call_count_fields_zero':all(int(row[field])==0 for row in b for field in FIELDS)})
    for kind,name in [('fatal','inherited_fatal'),('protocol','inherited_protocol'),('controls','inherited_controls')]:
        reference=base/('inherited_reference_'+kind);current=base/name
        prefix='observe_' if kind=='fatal' else ''
        a=operations(reference/(prefix+'operations.csv'));b=operations(current/(prefix+'operations.csv'))
        assert tuples(a)==tuples(b) and all(int(row[field])==0 for row in b for field in FIELDS)
        ref_native=Path(json.loads((reference/'provenance.json').read_text())['native_root'])
        native=Path(json.loads((current/'provenance.json').read_text())['native_root'])
        before=json_rows(reference/(prefix+'summary.jsonl'));after=json_rows(current/(prefix+'summary.jsonl'))
        if kind=='controls':
            for x,y in zip(before,after):assert x['reservation']==y['reservation']
        compare_alerts.compare_value(before,after,ref_native,native,frozen,sites,kind=='fatal')
        if kind=='fatal':
            compare_alerts.compare_value(json_rows(reference/'observe_events.jsonl'),json_rows(current/'observe_events.jsonl'),ref_native,native,frozen,sites,True)
            compare_alerts.compare_value(json.loads((reference/'observe_lifetime.json').read_text()),json.loads((current/'observe_lifetime.json').read_text()),ref_native,native,frozen,sites,True)
            validation=verify_inherited_fatal.verify(current)
        elif kind=='protocol':validation=verify_protocol.verify(current)
        else:validation=verify_controls.verify(current,'operations.csv','summary.jsonl',True,True,True)
        report.append({'group':'inherited_'+kind,'client_calls':len(b),'reserved':True,
            'all_call_count_fields_zero':True,'full_available_diagnostics_returns_callbacks_preserved':True,'validation':validation})
    return {'comparisons':report,'error_source_sites':list(sites.values()),
        'old_baselines_not_rerun':True,'unreserved_old_array_byte_parity_asserted':False,
        'raw_file_line_logs_rewritten':False,'complete_postgresql_gate_closed':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('directory',type=Path)
    parser.add_argument('--frozen-sites',type=Path);args=parser.parse_args();frozen=None
    if args.frozen_sites:
        rows=json.loads(args.frozen_sites.read_text())['error_source_sites']
        frozen={(r['relative_file'],r['baseline_line'],r['candidate_line']):r for r in rows};assert len(frozen)==len(rows)
    print(json.dumps(compare(args.directory.resolve(),frozen),indent=2))


if __name__=='__main__':main()
