#!/usr/bin/env python3
"""Replay peer-alert and accepted inherited evidence without native source/archives."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pki-tool',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();base=Path(__file__).resolve().parent;evidence_root=base
    if ((base.parent/'restore_pki_tool.py').is_file() and (base.parent/'native/HANDOFF.md').is_file()):evidence_root=base.parent
    output=args.output.absolute();helper=args.pki_tool.resolve(strict=True)
    if output.exists() or output.is_symlink():raise ValueError('Choose an absent output directory')
    if output.resolve().is_relative_to(evidence_root):raise ValueError('Keep output outside retained evidence')
    if digest(helper)!='531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':raise ValueError('PKI helper checksum differs')
    identity=json.loads((base/'prebuilt_identity.json').read_text())
    expected={'baseline/alert_witness','candidate/alert_witness','candidate_unreserved/alert_witness',
        'candidate_suites/suite_witness','candidate_unreserved_suites/suite_witness','inherited_fatal/fatal_witness',
        'inherited_protocol/protocol_witness','inherited_controls/control_witness'}
    if set(identity['binaries'])!=expected:raise ValueError('Unexpected executable inventory')
    for name,checksum in identity['binaries'].items():
        if digest(base/name)!=checksum:raise ValueError('Executable checksum differs: '+name)
    output.mkdir(parents=True,mode=0o700)
    commands=[];profile_commands={};profile_binaries={};complete=False;pki=output/'private_pki'

    def run(command,name,status=0,profile=None):
        with (output/(name+'.stdout')).open('wb') as out,(output/(name+'.stderr')).open('wb') as err:
            result=subprocess.run(command,cwd=output,stdout=out,stderr=err)
        item={'command':command,'exit_code':result.returncode,'expected_exit_code':status};commands.append(item)
        if profile is not None:profile_commands.setdefault(profile,[]).append(item)
        if result.returncode!=status:raise RuntimeError('Unexpected command status: '+name)

    def compare_files(directory,names):
        for name in names:
            if (output/directory/name).read_bytes()!=(base/directory/name).read_bytes():raise ValueError('Replay differs: '+directory+'/'+name)

    def cleanup_pki():
        if not pki.exists():return
        names={path.name for path in pki.iterdir()}
        if names-{'ca.pem','server.pem','server.key'}:raise ValueError('Unexpected PKI output')
        for name in names:(pki/name).unlink()
        pki.rmdir()

    def alert_profile(name,binary,strict_status,suite=None):
        target=output/name;target.mkdir(parents=True)
        shutil.copy2(base/name/'provenance.json',target/'provenance.json');profile_binaries[name]=binary
        for mode,option in [('observe','--observe'),('strict','--require-zero')]:
            paths=[str(target/(mode+'_'+part)) for part in ('operations.csv','events.jsonl','summary.jsonl','lifetime.json')]
            selection=[] if suite is None else [suite]
            run([str(base/binary),*arguments,*paths,*selection,option],name.replace('/','_')+'_'+mode,0 if mode=='observe' else strict_status,name)
            compare_files(name,[mode+'_'+part for part in ('operations.csv','events.jsonl','summary.jsonl','lifetime.json')])

    def plain_profile(name,binary):
        target=output/name;target.mkdir();profile_binaries[name]=binary
        shutil.copy2(base/name/'provenance.json',target/'provenance.json')
        run([str(base/binary),*arguments,str(target/'operations.csv'),str(target/'summary.jsonl')],name,0,name)
        compare_files(name,['operations.csv','summary.jsonl'])

    def reference(kind):
        name='inherited_reference_'+kind;target=output/name;target.mkdir()
        parts=['provenance.json','observe_operations.csv','observe_events.jsonl','observe_summary.jsonl','observe_lifetime.json'] if kind=='fatal' else ['provenance.json','operations.csv','summary.jsonl']
        for part in parts:shutil.copy2(base/name/part,target/part)

    try:
        try:
            run([str(helper),'pki',str(pki)],'pki_metadata')
            arguments=[str(pki/name) for name in ('server.pem','server.key','ca.pem')]
            for name in ('baseline','candidate_unreserved','candidate'):alert_profile(name,name+'/alert_witness',0 if name=='candidate' else 1)
            for suite in ('0x1302','0x1303'):
                alert_profile('candidate_suites/'+suite,'candidate_suites/suite_witness',0,suite)
                alert_profile('candidate_unreserved_suites/'+suite,'candidate_unreserved_suites/suite_witness',1,suite)
            alert_profile('inherited_fatal','inherited_fatal/fatal_witness',0)
            plain_profile('inherited_protocol','inherited_protocol/protocol_witness')
            plain_profile('inherited_controls','inherited_controls/control_witness')
            for kind in ('fatal','protocol','controls'):reference(kind)
        finally:cleanup_pki()
        for name,items in profile_commands.items():
            target=output/name
            (target/'commands.json').write_text(json.dumps(items,indent=2)+'\n')
            (target/'result.json').write_text(json.dumps({'complete':True,'private_pki_removed':not pki.exists(),
                'binary_sha256':digest(base/profile_binaries[name])},indent=2)+'\n')
        run([sys.executable,str(base/'verify_alerts.py'),str(output/'baseline')],'baseline_verification')
        run([sys.executable,str(base/'compare_alerts.py'),str(output),'--frozen-sites',str(base/'comparison.json')],'comparison')
        run([sys.executable,str(base/'compare_extended.py'),str(output),'--frozen-sites',str(base/'extended_comparison.json')],'extended_comparison')
        complete=True
    finally:
        cleanup_pki()
        (output/'results.json').write_text(json.dumps({'complete':complete,'commands':commands,'private_pki_removed':not pki.exists(),
            'requires_compiler_native_source_or_archives':False,'reserved_full_peer_alert_gate_zero':True,
            'unreserved_functional_control_remains_red':True,'complete_postgresql_gate_closed':False},indent=2)+'\n')
    print('PASS: three-suite peer-alert RED/GREEN, inherited zero, exact raw/semantic replay; PKI removed')


if __name__=='__main__':main()
