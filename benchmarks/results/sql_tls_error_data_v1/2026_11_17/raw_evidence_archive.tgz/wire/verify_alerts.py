#!/usr/bin/env python3
"""Reconcile peer-alert boundary semantics and complete-call allocation counts."""
import argparse
import csv
import json
from pathlib import Path

FIELDS=('malloc','calloc','realloc','free','bytes')
CASES=('native_fatal_zero','public_fatal_99','public_fatal_255','public_warning_close_zero','native_malformed_one_byte')
DESCRIPTIONS=(0,99,255,0,0)
FIRST=((2,0,0,0,83),(2,0,0,0,84),(2,0,0,0,85),(0,0,0,0,0),(0,0,0,0,0))


def verify(directory,zero):
    for name in ('operations.csv','events.jsonl','summary.jsonl','lifetime.json'):
        assert (directory/('observe_'+name)).read_bytes()==(directory/('strict_'+name)).read_bytes(),name
    operations=list(csv.DictReader((directory/'observe_operations.csv').open()))
    events=[json.loads(line) for line in (directory/'observe_events.jsonl').read_text().splitlines()]
    rows=[json.loads(line) for line in (directory/'observe_summary.jsonl').read_text().splitlines()]
    assert len(operations)==len(events)==164 and [row['case'] for row in rows]==list(CASES)
    for index,(op,event) in enumerate(zip(operations,events)):
        assert event['index']==index
        assert (op['scenario'],op['phase'],int(op['step']),int(op['result']),int(op['error']))==(event['case'],event['phase'],event['step'],event['result'],event['error'])
        assert all(int(op[field])>=0 for field in FIELDS)
        if zero:assert all(int(op[field])==0 for field in FIELDS)
        for entry in event['queue']:
            assert entry['library']==entry['packed']>>24 and entry['reason']==entry['packed']&0xffffff
            assert entry['line']>0 and entry['file'] and entry['flags'] in (0,3)
    measured=[]
    for kind,row in enumerate(rows):
        selected=[(op,event) for op,event in zip(operations,events) if op['scenario']==row['case']]
        warm=[op for op,_ in selected if op['phase'] in ('read','response_write')]
        alert=[op for op,_ in selected if op['phase'] not in ('read','response_write')]
        assert len(warm)==25 and row['suite']==0x1301 and row['tls13_verified'] and row['hostname_verified'] and row['warm_payload_exact']
        assert row['description']==DESCRIPTIONS[kind] and row['warm_payload_each_direction']==4096
        assert row['repeat_read_cycles']==row['repeat_write_cycles']==3
        assert row['public_sender']==(kind in (1,2,3)) and row['native_sealed_negative_input']==(kind in (0,4))
        assert row['formats_peer_alert_text']==(kind<3) and row['positive_post_alert_writes']==(kind<4)
        assert all(int(op[field])==0 for op in warm for field in FIELDS)
        assert sum(max(int(op['result']),0) for op in warm if op['phase']=='read')==4096
        assert sum(max(int(op['result']),0) for op in warm if op['phase']=='response_write')==4096
        assert len(alert)==row['alert_operations']
        assert {field:sum(int(op[field]) for op in alert) for field in FIELDS}==row['alert_calls']
        first=[op for op in alert if op['phase']=='first_alert_read'];assert len(first)==1
        if not zero:assert tuple(int(first[0][field]) for field in FIELDS)==FIRST[kind]
        if kind==3:assert row['first_read_queue']==[]
        else:
            assert len(row['first_read_queue'])==1
            entry=row['first_read_queue'][0]
            assert entry['library']==16 and entry['reason']==(102 if kind==4 else 1000+DESCRIPTIONS[kind])
            assert entry['flags']==(3 if kind<3 else 0)
            assert entry['data']==('SSL alert number '+str(DESCRIPTIONS[kind]) if kind<3 else '')
        expected_client=[[0,2,DESCRIPTIONS[kind]]] if kind<3 else [[0,1,0]] if kind==3 else [[1,2,50]]
        expected_peer=[] if kind==0 else [[1,2,DESCRIPTIONS[kind]]] if kind<3 else [[1,1,0]] if kind==3 else [[0,2,50]]
        assert row['client_alerts']==expected_client and row['peer_alerts']==expected_peer
        for op,event in selected:
            if op['phase'] in ('read','response_write'):assert event['queue']==[];continue
            if op['phase']=='post_alert_write':
                if kind<4:assert (event['result'],event['error'],event['queue'])==(1,0,[])
                else:assert event['result']==-1 and event['error']==1 and [entry['reason'] for entry in event['queue']]==[194]
                continue
            assert event['queue']==row['first_read_queue']
            assert (event['result'],event['error'])==((0,6) if kind==3 else (-1,1))
        measured.append({'case':row['case'],'first_read':{field:int(first[0][field]) for field in FIELDS},
            'alert_cross_lifetime_calls':len(alert),'aggregate':row['alert_calls']})
    lifetime=json.loads((directory/'observe_lifetime.json').read_text())
    assert lifetime['immediate_b255_a0_b255_restore'] and lifetime['popped_255_string_valid_after_ssl_free']
    assert lifetime['popped_flags']==3 and lifetime['popped_reason']==1255 and lifetime['read_result']==-1 and lifetime['read_error']==1
    commands=json.loads((directory/'commands.json').read_text())
    statuses={item['command'][-1]:item['exit_code'] for item in commands if item['command'][-1] in ('--observe','--require-zero')}
    assert statuses=={'--observe':0,'--require-zero':0 if zero else 1}
    result=json.loads((directory/'result.json').read_text());assert result['complete'] and result['private_pki_removed']
    return {'rows':5,'client_calls_per_selector':164,'warm_calls':125,'alert_cross_lifetime_calls':39,
        'observed_zero':zero,'functional_observe_exit':0,'strict_zero_exit':0 if zero else 1,
        'full_error_flags_text_file_line_and_order_checked':True,'warning_close_distinguished_from_fatal_zero':True,
        'malformed_length_rejects_before_received_alert_callback':True,'peer_fatal_and_close_successful_writes_preserved':True,
        'immediate_cross_ssl_restore_and_popped_lifetime_checked':True,'measurements':measured,
        'complete_postgresql_gate_closed':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('directory',type=Path);parser.add_argument('--zero',action='store_true')
    args=parser.parse_args();print(json.dumps(verify(args.directory,args.zero),indent=2))


if __name__=='__main__':main()
