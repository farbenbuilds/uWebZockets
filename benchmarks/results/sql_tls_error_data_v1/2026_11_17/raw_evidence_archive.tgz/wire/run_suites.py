#!/usr/bin/env python3
"""Build one cipher-input program and run both additional TLS1.3 suites."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root',type=Path);parser.add_argument('pki_helper',type=Path);parser.add_argument('output',type=Path)
    parser.add_argument('--unreserved',action='store_true');args=parser.parse_args()
    base=Path(__file__).resolve().parent;native=args.native_root.resolve(strict=True);helper=args.pki_helper.resolve(strict=True)
    output=args.output.absolute()
    if output.exists() or output.is_symlink():raise ValueError('Choose absent output')
    if digest(helper)!='531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':raise ValueError('PKI helper differs')
    if digest(base/'allocation_scope.c')!='afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac':raise ValueError('Counter differs')
    output.mkdir(mode=0o700);zig='/tmp/zig-x86_64-linux-0.16.0/zig'
    env=dict(os.environ);env['ZIG_GLOBAL_CACHE_DIR']=str(base/'zig_global_cache')
    source=base/('unreserved_suite_witness.cc' if args.unreserved else 'suite_witness.cc')
    archives=[native/'native_out/lib/libssl.a',native/'native_out/lib/libcrypto.a'];binary=output/'suite_witness'
    provenance={'native_root':str(native),'optimization':'Debug (-O0 -g)','compiler':zig,'compiler_cache':env['ZIG_GLOBAL_CACHE_DIR'],
        'fixture_sha256':digest(source),'counter_sha256':digest(base/'allocation_scope.c'),'error_state_reserved':not args.unreserved,
        'archive_sha256':{p.name:digest(p) for p in archives},'pki_helper_sha256':digest(helper),
        'cipher_selection':'public singleton IDs0x1302/0x1303, null flags, both actual IDs asserted'}
    (output/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
    commands=[];children={};pki=output/'private_pki';complete=False
    def run(command,name,status=0,child=None):
        with (output/(name+'.stdout')).open('wb') as out,(output/(name+'.stderr')).open('wb') as err:
            result=subprocess.run(command,cwd=output,env=env,stdout=out,stderr=err)
        item={'command':command,'exit_code':result.returncode,'expected_exit_code':status};commands.append(item)
        if child is not None:children.setdefault(child,[]).append(item)
        (output/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        if result.returncode!=status:raise RuntimeError('Unexpected status: '+name)
    try:
        run([zig,'cc','-std=c11','-O0','-g','-c',str(base/'allocation_scope.c'),'-o',str(output/'allocation_scope.o')],'build-counter')
        run([zig,'c++','-std=c++17','-O0','-g','-fno-omit-frame-pointer','-Wall','-Wextra','-Werror','-DBORINGSSL_IMPLEMENTATION',
            '-isystem',str(native/'boringssl'),'-isystem',str(native/'boringssl/include'),str(source),str(output/'allocation_scope.o'),
            *[str(p) for p in archives],'-o',str(binary)],'build-witness')
        run([str(helper),'pki',str(pki)],'pki-metadata')
        arguments=[str(pki/name) for name in ('server.pem','server.key','ca.pem')]
        for suite in ('0x1302','0x1303'):
            target=output/suite;target.mkdir()
            (target/'provenance.json').write_text(json.dumps(dict(provenance,suite=int(suite,16)),indent=2)+'\n')
            for mode,option in [('observe','--observe'),('strict','--require-zero')]:
                run([str(binary),*arguments,*[str(target/(mode+'_'+part)) for part in ('operations.csv','events.jsonl','summary.jsonl','lifetime.json')],suite,option],
                    suite+'_'+mode,1 if mode=='strict' and args.unreserved else 0,suite)
            for part in ('operations.csv','events.jsonl','summary.jsonl','lifetime.json'):
                assert (target/('observe_'+part)).read_bytes()==(target/('strict_'+part)).read_bytes()
        complete=True
    finally:
        if pki.exists():
            names={p.name for p in pki.iterdir()}
            if names-{'ca.pem','server.pem','server.key'}:raise ValueError('Unexpected PKI files')
            for name in names:(pki/name).unlink()
            pki.rmdir()
        result={'complete':complete,'private_pki_removed':not pki.exists(),'binary_sha256':digest(binary) if binary.exists() else None}
        (output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        for suite,items in children.items():
            (output/suite/'commands.json').write_text(json.dumps(items,indent=2)+'\n')
            (output/suite/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    for suite in ('0x1302','0x1303'):
        command=[sys.executable,str(base/'verify_suites.py'),str(output/suite),'--suite',suite]
        if not args.unreserved:command.append('--zero')
        run(command,suite+'_verification')
    print('PASS actual0x1302/0x1303 cases; '+('unreserved RED' if args.unreserved else 'reserved GREEN')+'; PKI removed')


if __name__=='__main__':main()
