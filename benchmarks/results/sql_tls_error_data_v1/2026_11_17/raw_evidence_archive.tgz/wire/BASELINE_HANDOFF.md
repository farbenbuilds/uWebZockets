# Phase B peer-alert baseline

The new bounded wire witness passes all functional checks and then fails the unchanged complete-call zero-allocation assertion. Observe exits0, strict exits1; operation/event/summary/lifetime files are byte-identical between selectors. The immutable Phase A native baseline is unchanged, and every selected prior Phase A payload hash was verified before new work.

| First client read | Result/error | malloc/free/bytes | Full SSL reason/data |
|---|---|---|---|
| Native-sealed fatal description0 | -1/1 | 2/0/83 | 1000 / `SSL alert number 0` |
| Public fatal99 | -1/1 | 2/0/84 | 1099 / `SSL alert number 99` |
| Public fatal255 | -1/1 | 2/0/85 | 1255 / `SSL alert number 255` |
| Public warning close0 | 0/6 | 0/0/0 | empty queue, no formatted text |
| Native-sealed one-byte alert | -1/1 | 0/0/0 | 102 / empty text, outgoing decode_error50 |

Every vector has calloc0/realloc0. Five fresh CA/localhost verified TLS1.3 pairs negotiate actual0x1301 through public singleton configuration with null flags on both contexts and assert both resulting cipher IDs. All six established policies/reservations are enabled on clients before exact4096B bidirectional warm traffic. Each pair then executes first alert read and three read/write cycles. Immediate B255→A0→B255 calls restore distinct data snapshots, and a final255 read checks that the popped queue-owned string remains valid after client `SSL_free` with flags STRING|MALLOCED, before another queue-modifying call.

Each selector measures164 complete client calls:125 warm calls, all zero, and39 alert/cross/lifetime calls. The data rows aggregate19malloc/16free/514B across25 alert/cross/lifetime calls; close and malformed rows remain zero. Per-case data totals are fatal0:6malloc/5free/159B over8calls; fatal99:5malloc/4free/144B over7calls; fatal255:8malloc/7free/211B over10calls. The final popped255 restore measures1malloc/1free/21B. Exact per-operation free placement remains in CSV; no per-restore averaging is used.

The pinned parser's warning-level close_notify branch precedes the fatal branch only inside `alert_level == WARNING`. Public `SSL_send_fatal_alert` disallows description0; the native-sealed fatal0 case is explicitly a negative peer input and does format text. Fatal99/255 use the genuine public sender. Warning close0 uses public `SSL_shutdown`, whose return0 here records successful one-way close emission. No text is asserted for that close branch. The one-byte negative input is native-sealed and rejects before the incoming alert callback. Its generated fatal decode_error is received by the peer. No client parser/cipher fields are staged.

After fatal0/99/255 and warning close0, client writes return1/error0 and the peer receives exact bytes0x71/0x72/0x73; after malformed length they fail with SSL reason194. Repeated close reads return0/SSL_ERROR_ZERO_RETURN6 with empty queues; repeated fatal reads restore full original queues. Actual packed error/library/reason, flags, exact nonsensitive text, filename, line and callback alert order are recorded for every client call. Native-sealed negative inputs do not manufacture sender plaintext callbacks; the fatal0 peer callback array is correctly empty, while its actual receiver callback is retained.

The all-C allocation counter is byte-identical SHA256 `afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac`, with mandatory selftest malloc1/calloc1/realloc1/free2/requested63B. Client calls and immediate `SSL_get_error` classification are inside measurement; peer preparation, queue observations, logging and cleanup are outside. No diagnostic counter or allocation fallback substitutes for this gate. No ticket, key, session or context bytes/hashes are logged. Known wire error strings fit asserted fixed witness storage; arbitrary generic error strings are a separate direct-owner contract.

Exact command (use a different absent output for a new run):

```sh
python3 .zig-cache/sql-tls-error-data-wire-20261117/run_alerts.py /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-error-snapshot-fixed-20261117 /tmp/uwz-wt-upstream-backport-client-20261117/client/wt-tools /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-error-data-wire-20261117/baseline
python3 .zig-cache/sql-tls-error-data-wire-20261117/verify_alerts.py .zig-cache/sql-tls-error-data-wire-20261117/baseline
```

`run_alerts.py --expect-zero` changes only the expected process status for later candidate evidence, not the fixture source/input or its zero assertion. All exact compiler/link/run arguments, statuses and raw output are retained in `baseline/`. Compilation uses Zig0.16 Debug `-O0 -g` and `/tmp/uwz-zig-cache`; all new bulk/PKI/output is on the workspace SSD. Owned ephemeral PKI is removed in a finally block.

Native libssl SHA256 `48e2928a79013579ddec9dea7bd1d750771e30a35d5091182db26af5555e960d`, libcrypto `2143f831f9f57907f47a51dfc0fae9942f33b8c3ca6d378cca6cc90b387ea4dd`. PKI helper SHA256 `531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9`. `phase_a_validation.json` binds prior selected validation; `baseline_verification.json` reconciles all164 actual operations. `baseline_frozen.json` preserves this pre-edit source/raw/hash baseline, excluding object files. The old producers, native files, protected vendor and repository are untouched.

Pure ERR lengths30/31/32, generic long spill/alias/marks/overflow/lifecycle remain with the direct verifier. Generic private error-array byte counts may change when entries grow; future comparisons must report actual values and semantic equivalence instead of claiming old byte parity. Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain deferred. Root decides native-author release and final integration; the full PostgreSQL/v2.3 gate remains open.
