#include <openssl/err.h>
#include <openssl/ssl.h>
#include <openssl/ssl3.h>
#include <openssl/x509_vfy.h>
#include "ssl/internal.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK(value) do { if (!(value)) fail(__LINE__, #value); } while (0)

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

struct allocation_counts {
    uint64_t malloc_calls;
    uint64_t calloc_calls;
    uint64_t realloc_calls;
    uint64_t free_calls;
    uint64_t requested_bytes;
};

struct measured_result {
    int result;
    int error;
    allocation_counts counts;
};

struct protocol_observations {
    unsigned int received_tickets;
    unsigned int received_key_updates;
    unsigned int sent_key_updates;
    uint8_t received_modes[96];
    uint8_t sent_modes[96];
    bool invalid;
    const uint8_t *expected_tickets;
    size_t expected_ticket_bytes;
    size_t observed_ticket_bytes;
    bool ticket_bytes_exact;
    unsigned int alert_count;
    uint8_t alerts[8][3];
};

struct tls_pair {
    SSL_CTX *client_context;
    SSL_CTX *server_context;
    SSL *client;
    SSL *server;
    protocol_observations client_observations;
    protocol_observations server_observations;
};

struct phase_result {
    allocation_counts counts;
    unsigned int operations;
    unsigned int retries;
};

static void fail(int line, const char *expression)
{
    fprintf(stderr, "check failed at line %d: %s\n", line, expression);
    ERR_print_errors_fp(stderr);
    abort();
}

static allocation_counts snapshot_counts(void)
{
    return {uwz_alloc_malloc_calls(), uwz_alloc_calloc_calls(),
            uwz_alloc_realloc_calls(), uwz_alloc_free_calls(),
            uwz_alloc_requested_bytes()};
}

static void add_counts(allocation_counts *total, allocation_counts value)
{
    total->malloc_calls += value.malloc_calls;
    total->calloc_calls += value.calloc_calls;
    total->realloc_calls += value.realloc_calls;
    total->free_calls += value.free_calls;
    total->requested_bytes += value.requested_bytes;
}

static bool retry_error(int error)
{
    return error == SSL_ERROR_WANT_READ || error == SSL_ERROR_WANT_WRITE;
}

static void check_peer_result(SSL *ssl, int result)
{
    if (result > 0) return;
    CHECK(retry_error(SSL_get_error(ssl, result)));
}

static void observe_message(int is_write, int version, int content_type,
                            const void *buffer, size_t length, SSL *ssl,
                            void *argument)
{
    (void)ssl;
    protocol_observations *observed = static_cast<protocol_observations *>(argument);
    const uint8_t *bytes = static_cast<const uint8_t *>(buffer);
    if (content_type == SSL3_RT_ALERT && length == 2) {
        if (observed->alert_count == 8) { observed->invalid = true; return; }
        const unsigned int index = observed->alert_count++;
        observed->alerts[index][0] = static_cast<uint8_t>(is_write);
        observed->alerts[index][1] = bytes[0];
        observed->alerts[index][2] = bytes[1];
        return;
    }
    if (content_type != SSL3_RT_HANDSHAKE || length == 0) return;
    if (bytes[0] == SSL3_MT_NEWSESSION_TICKET) {
        if (is_write) return;
        observed->received_tickets++;
        if (version != TLS1_3_VERSION || length < 4) { observed->invalid = true; return; }
        if (observed->expected_tickets != nullptr) {
            const size_t remaining = observed->expected_ticket_bytes - observed->observed_ticket_bytes;
            if (length > remaining || memcmp(bytes, observed->expected_tickets + observed->observed_ticket_bytes, length) != 0)
                observed->invalid = true;
            else observed->observed_ticket_bytes += length;
        }
        return;
    }
    if (bytes[0] != SSL3_MT_KEY_UPDATE) return;
    if (version != TLS1_3_VERSION || length != 5 || bytes[1] || bytes[2] || bytes[3] != 1 || bytes[4] > 1) {
        observed->invalid = true;
        return;
    }
    unsigned int *count = is_write ? &observed->sent_key_updates : &observed->received_key_updates;
    uint8_t *modes = is_write ? observed->sent_modes : observed->received_modes;
    if (*count == 96) { observed->invalid = true; return; }
    modes[(*count)++] = bytes[4];
}

static void prepare_pair(tls_pair *pair, const char *certificate,
                         const char *private_key, const char *ca,
                         unsigned int tickets, uint16_t suite, int cache_mode)
{
    pair->client_context = SSL_CTX_new(TLS_method());
    pair->server_context = SSL_CTX_new(TLS_method());
    CHECK(pair->client_context && pair->server_context);
    CHECK(SSL_CTX_set1_tls13_ciphers(pair->client_context, &suite, nullptr, 1));
    CHECK(SSL_CTX_set1_tls13_ciphers(pair->server_context, &suite, nullptr, 1));
    CHECK(SSL_CTX_set_min_proto_version(pair->client_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_max_proto_version(pair->client_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_min_proto_version(pair->server_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_max_proto_version(pair->server_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_num_tickets(pair->server_context, tickets));
    SSL_CTX_set_session_cache_mode(pair->client_context, cache_mode);
    CHECK(SSL_CTX_get_session_cache_mode(pair->client_context) == cache_mode);
    CHECK(SSL_CTX_sess_get_new_cb(pair->client_context) == nullptr);
    CHECK(SSL_CTX_use_certificate_chain_file(pair->server_context, certificate));
    CHECK(SSL_CTX_use_PrivateKey_file(pair->server_context, private_key,
                                     SSL_FILETYPE_PEM));
    CHECK(SSL_CTX_check_private_key(pair->server_context));
    CHECK(SSL_CTX_load_verify_locations(pair->client_context, ca, nullptr));
    SSL_CTX_set_verify(pair->client_context, SSL_VERIFY_PEER, nullptr);
    SSL_CTX_set_msg_callback(pair->client_context, observe_message);
    SSL_CTX_set_msg_callback_arg(pair->client_context, &pair->client_observations);
    SSL_CTX_set_msg_callback(pair->server_context, observe_message);
    SSL_CTX_set_msg_callback_arg(pair->server_context, &pair->server_observations);
    pair->client = SSL_new(pair->client_context);
    pair->server = SSL_new(pair->server_context);
    CHECK(pair->client && pair->server);
    CHECK(SSL_set_tlsext_host_name(pair->client, "localhost"));
    CHECK(SSL_set1_host(pair->client, "localhost"));
    SSL_set_connect_state(pair->client);
    SSL_set_accept_state(pair->server);
    BIO *client_bio = nullptr;
    BIO *server_bio = nullptr;
    CHECK(BIO_new_bio_pair(&client_bio, 1024, &server_bio, 1024));
    SSL_set_bio(pair->client, client_bio, client_bio);
    SSL_set_bio(pair->server, server_bio, server_bio);
    bool client_done = false;
    bool server_done = false;
    for (unsigned int i = 0; i < 10000 && (!client_done || !server_done); i++) {
        if (!client_done) {
            int result = SSL_do_handshake(pair->client);
            if (result == 1) client_done = true;
            else check_peer_result(pair->client, result);
        }
        if (!server_done) {
            int result = SSL_do_handshake(pair->server);
            if (result == 1) server_done = true;
            else check_peer_result(pair->server, result);
        }
    }
    CHECK(client_done && server_done);
    CHECK(SSL_version(pair->client) == TLS1_3_VERSION);
    CHECK(SSL_version(pair->server) == TLS1_3_VERSION);
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->client)) == suite);
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->server)) == suite);
    CHECK(SSL_get_verify_result(pair->client) == X509_V_OK);
    CHECK(SSL_get0_peer_certificates(pair->client) != nullptr);
    CHECK(pair->client_observations.received_tickets == 0);
}

static measured_result measured_read(SSL *client, void *output, int length)
{
    uwz_alloc_begin();
    const int result = SSL_read(client, output, length);
    const int error = result > 0 ? SSL_ERROR_NONE : SSL_get_error(client, result);
    uwz_alloc_end();
    return {result, error, snapshot_counts()};
}

static measured_result measured_write(SSL *client, const void *input, int length)
{
    uwz_alloc_begin();
    const int result = SSL_write(client, input, length);
    const int error = result > 0 ? SSL_ERROR_NONE : SSL_get_error(client, result);
    uwz_alloc_end();
    return {result, error, snapshot_counts()};
}

struct error_entry {
    uint32_t packed;
    int line;
    int flags;
    bool has_data;
    char file[512];
    char data[256];
};

struct error_queue {
    error_entry entries[15];
    size_t count;
};

struct output_files {
    FILE *operations;
    FILE *events;
    unsigned int event_index;
};

static void copy_text(char *output, size_t capacity, const char *input)
{
    CHECK(input != nullptr && strlen(input) < capacity);
    memcpy(output, input, strlen(input) + 1);
}

static error_queue capture_queue(void)
{
    error_queue queue{};
    for (;;) {
        const char *file = nullptr, *data = nullptr;
        int line = 0, flags = 0;
        const uint32_t packed = ERR_get_error_line_data(&file, &line, &data, &flags);
        if (packed == 0) return queue;
        CHECK(queue.count < 15);
        error_entry *entry = &queue.entries[queue.count++];
        entry->packed = packed; entry->line = line; entry->flags = flags;
        copy_text(entry->file, sizeof(entry->file), file ? file : "");
        entry->has_data = (flags & ERR_FLAG_STRING) != 0;
        CHECK(data != nullptr);
        if (entry->has_data) CHECK(strncmp(data, "SSL alert number ", 17) == 0);
        else CHECK(flags == 0 && data[0] == 0);
        copy_text(entry->data, sizeof(entry->data), data);
    }
}

static bool same_queue(const error_queue *a, const error_queue *b)
{
    if (a->count != b->count) return false;
    for (size_t i = 0; i < a->count; i++) {
        const error_entry *x = &a->entries[i], *y = &b->entries[i];
        if (x->packed != y->packed || x->line != y->line || x->flags != y->flags ||
            x->has_data != y->has_data || strcmp(x->file, y->file) || strcmp(x->data, y->data)) return false;
    }
    return true;
}

static void print_string(FILE *output, const char *value)
{
    fputc('"', output);
    for (const unsigned char *p = reinterpret_cast<const unsigned char *>(value); *p; p++) {
        if (*p == '"' || *p == 92) fputc(92, output);
        CHECK(*p >= 32 && *p < 127);
        fputc(*p, output);
    }
    fputc('"', output);
}

static void print_queue(FILE *output, const error_queue *queue)
{
    fputc('[', output);
    for (size_t i = 0; i < queue->count; i++) {
        const error_entry *entry = &queue->entries[i];
        fprintf(output, "%s{\"packed\":%u,\"library\":%d,\"reason\":%d,\"line\":%d,\"flags\":%d,\"file\":", i ? "," : "", entry->packed, ERR_GET_LIB(entry->packed), ERR_GET_REASON(entry->packed), entry->line, entry->flags);
        print_string(output, entry->file);
        fprintf(output, ",\"data\":");
        print_string(output, entry->data);
        fputc('}', output);
    }
    fputc(']', output);
}

static void record_captured_operation(output_files *files, unsigned int round, const char *row,
                              const char *phase, measured_result operation,
                              const protocol_observations *observed,
                              phase_result *result, const error_queue *queue)
{
    const allocation_counts count = operation.counts;
    fprintf(files->operations, "%u,%s,%s,%u,%d,%d,%llu,%llu,%llu,%llu,%llu,%u,%u,%u\n",
            round, row, phase, result->operations, operation.result, operation.error,
            (unsigned long long)count.malloc_calls, (unsigned long long)count.calloc_calls,
            (unsigned long long)count.realloc_calls, (unsigned long long)count.free_calls,
            (unsigned long long)count.requested_bytes, observed->received_tickets,
            observed->received_key_updates, observed->sent_key_updates);
    fprintf(files->events, "{\"index\":%u,\"case\":\"%s\",\"phase\":\"%s\",\"step\":%u,\"result\":%d,\"error\":%d,\"queue\":", files->event_index++, row, phase, round, operation.result, operation.error);
    print_queue(files->events, queue);
    fprintf(files->events, ",\"observed_alerts\":[");
    for (unsigned int i = 0; i < observed->alert_count; i++) fprintf(files->events, "%s[%u,%u,%u]", i ? "," : "", observed->alerts[i][0], observed->alerts[i][1], observed->alerts[i][2]);
    fprintf(files->events, "],\"received_tickets\":%u}\n", observed->received_tickets);
    CHECK(fflush(files->operations) == 0 && fflush(files->events) == 0);
    add_counts(&result->counts, count); result->operations++;
    if (operation.result <= 0) result->retries++;
}

static error_queue record_full_operation(output_files *files, unsigned int round, const char *row,
                              const char *phase, measured_result operation,
                              const protocol_observations *observed, phase_result *result)
{
    const error_queue queue = capture_queue();
    record_captured_operation(files, round, row, phase, operation, observed, result, &queue);
    return queue;
}

static void record_operation(output_files *files, unsigned int round, const char *row,
                              const char *phase, measured_result operation,
                              const protocol_observations *observed, phase_result *result)
{
    const error_queue queue = record_full_operation(files, round, row, phase, operation, observed, result);
    CHECK(queue.count == 0);
}

static phase_result read_payload(tls_pair *pair, const uint8_t *payload,
                                  int length, output_files *operations,
                                  unsigned int round, const char *row)
{
    uint8_t received[4096];
    CHECK(length == sizeof(received));
    bool written = false;
    int offset = 0;
    phase_result result{};
    for (unsigned int i = 0; i < 10000 && (!written || offset != length); i++) {
        if (!written) {
            const int sent = SSL_write(pair->server, payload, length);
            if (sent > 0) {
                CHECK(sent == length);
                written = true;
            } else check_peer_result(pair->server, sent);
        }
        if (offset == length) continue;
        const int remaining = length - offset;
        measured_result operation = measured_read(pair->client, received + offset,
                                                   remaining < 257 ? remaining : 257);
        record_operation(operations, round, row, "read", operation,
                          &pair->client_observations, &result);
        if (operation.result > 0) offset += operation.result;
        else CHECK(retry_error(operation.error));
    }
    CHECK(written && offset == length);
    CHECK(memcmp(received, payload, length) == 0);
    return result;
}

static phase_result write_reply(tls_pair *pair, const uint8_t *payload,
                                 int length, output_files *operations,
                                 unsigned int round, const char *row)
{
    uint8_t received[4096];
    CHECK(length == sizeof(received));
    bool written = false;
    int offset = 0;
    phase_result result{};
    for (unsigned int i = 0; i < 10000 && (!written || offset != length); i++) {
        if (!written) {
            measured_result operation = measured_write(pair->client, payload, length);
            record_operation(operations, round, row, "response_write", operation,
                              &pair->client_observations, &result);
            if (operation.result > 0) {
                CHECK(operation.result == length);
                written = true;
            } else CHECK(retry_error(operation.error));
        }
        if (offset == length) continue;
        const int remaining = length - offset;
        const int count = SSL_read(pair->server, received + offset,
                                   remaining < 257 ? remaining : 257);
        if (count > 0) offset += count;
        else check_peer_result(pair->server, count);
    }
    CHECK(written && offset == length);
    CHECK(memcmp(received, payload, length) == 0);
    return result;
}

static void print_counts(FILE *output, allocation_counts counts)
{
    fprintf(output, "{\"malloc\":%llu,\"calloc\":%llu,\"realloc\":%llu,\"free\":%llu,\"bytes\":%llu}",
            (unsigned long long)counts.malloc_calls,
            (unsigned long long)counts.calloc_calls,
            (unsigned long long)counts.realloc_calls,
            (unsigned long long)counts.free_calls,
            (unsigned long long)counts.requested_bytes);
}

struct alert_case {
    const char *name;
    unsigned int kind;
    uint8_t description;
    tls_pair pair;
    error_queue first_queue;
    error_queue write_queue;
    phase_result warm_reads;
    phase_result warm_writes;
    phase_result alert_calls;
    bool positive_writes;
};

static bool counts_zero(allocation_counts counts)
{
    return counts.malloc_calls == 0 && counts.calloc_calls == 0 && counts.realloc_calls == 0 &&
        counts.free_calls == 0 && counts.requested_bytes == 0;
}

static void prepare_alert(alert_case *test, const char *certificate,
                           const char *private_key, const char *ca, output_files *output)
{
    tls_pair *pair = &test->pair;
    prepare_pair(pair, certificate, private_key, ca, 0, 0x1301, SSL_SESS_CACHE_OFF);
    CHECK(SSL_reserve_record_buffers(pair->client));
    CHECK(SSL_reserve_client_post_handshake_buffer(pair->client));
    CHECK(SSL_reserve_key_update_context(pair->client));
    CHECK(SSL_reserve_key_update_output_buffers(pair->client));
    CHECK(SSL_discard_client_session_tickets(pair->client));
    uint8_t payload[4096];
    for (size_t i = 0; i < sizeof(payload); i++) payload[i] = static_cast<uint8_t>(i * 23 + test->kind);
    test->warm_reads = read_payload(pair, payload, sizeof(payload), output, 0, test->name);
    test->warm_writes = write_reply(pair, payload, sizeof(payload), output, 0, test->name);
    CHECK(counts_zero(test->warm_reads.counts) && counts_zero(test->warm_writes.counts));
    CHECK(pair->client_observations.received_tickets == 0);
}

static void deliver_alert(alert_case *test)
{
    tls_pair *pair = &test->pair;
    if (test->kind == 1 || test->kind == 2) {
        CHECK(SSL_send_fatal_alert(pair->server, test->description) == 1);
        CHECK(pair->server_observations.alert_count == 1);
        return;
    }
    if (test->kind == 3) {
        const int result = SSL_shutdown(pair->server);
        CHECK(result == 0);
        CHECK(pair->server_observations.alert_count == 1);
        return;
    }
    const uint8_t plaintext[] = {SSL3_AL_FATAL, 0};
    const size_t input_length = test->kind == 4 ? 1 : 2;
    CHECK(test->kind == 0 || test->kind == 4);
    uint8_t encrypted[128];
    size_t length = 0;
    CHECK(bssl::tls_seal_record(bssl::FromOpaque(pair->server), encrypted, &length,
        sizeof(encrypted), SSL3_RT_ALERT, plaintext, input_length));
    CHECK(BIO_write(SSL_get_wbio(pair->server), encrypted, static_cast<int>(length)) == static_cast<int>(length));
}

static error_queue read_alert(alert_case *test, output_files *output,
                                unsigned int step, const char *phase)
{
    uint8_t unused[257];
    const measured_result result = measured_read(test->pair.client, unused, sizeof(unused));
    if (test->kind == 3) CHECK(result.result == 0 && result.error == SSL_ERROR_ZERO_RETURN);
    else CHECK(result.result < 0 && result.error == SSL_ERROR_SSL);
    return record_full_operation(output, step, test->name, phase, result,
        &test->pair.client_observations, &test->alert_calls);
}

static void validate_alerts(alert_case *test)
{
    protocol_observations *client = &test->pair.client_observations;
    protocol_observations *peer = &test->pair.server_observations;
    CHECK(!client->invalid && !peer->invalid && client->alert_count == 1);
    if (test->kind < 3) {
        CHECK(client->alerts[0][0] == 0 && client->alerts[0][1] == SSL3_AL_FATAL && client->alerts[0][2] == test->description);
        CHECK(peer->alert_count == (test->kind == 0 ? 0u : 1u));
        if (test->kind != 0) CHECK(peer->alerts[0][0] == 1 && peer->alerts[0][1] == SSL3_AL_FATAL && peer->alerts[0][2] == test->description);
        return;
    }
    if (test->kind == 3) {
        CHECK(client->alerts[0][0] == 0 && client->alerts[0][1] == SSL3_AL_WARNING && client->alerts[0][2] == 0);
        CHECK(peer->alert_count == 1 && peer->alerts[0][0] == 1 && peer->alerts[0][1] == SSL3_AL_WARNING && peer->alerts[0][2] == 0);
        return;
    }
    CHECK(client->alerts[0][0] == 1 && client->alerts[0][1] == SSL3_AL_FATAL && client->alerts[0][2] == SSL_AD_DECODE_ERROR);
    uint8_t unused[16];
    const int result = SSL_read(test->pair.server, unused, sizeof(unused));
    CHECK(result < 0 && SSL_get_error(test->pair.server, result) == SSL_ERROR_SSL);
    const error_queue peer_queue = capture_queue();
    CHECK(peer_queue.count == 1 && ERR_GET_REASON(peer_queue.entries[0].packed) == SSL_AD_REASON_OFFSET + SSL_AD_DECODE_ERROR);
    CHECK(peer->alert_count == 1 && peer->alerts[0][0] == 0 && peer->alerts[0][1] == SSL3_AL_FATAL && peer->alerts[0][2] == SSL_AD_DECODE_ERROR);
}

static void run_alert(alert_case *test, output_files *output)
{
    deliver_alert(test);
    test->first_queue = read_alert(test, output, 0, "first_alert_read");
    if (test->kind == 3) CHECK(test->first_queue.count == 0);
    else {
        CHECK(test->first_queue.count == 1);
        const error_entry *entry = &test->first_queue.entries[0];
        CHECK(ERR_GET_LIB(entry->packed) == ERR_LIB_SSL);
        CHECK(ERR_GET_REASON(entry->packed) == (test->kind == 4 ? SSL_R_BAD_ALERT : SSL_AD_REASON_OFFSET + test->description));
        if (test->kind < 3) {
            char expected[32];
            CHECK(snprintf(expected, sizeof(expected), "SSL alert number %u", test->description) > 0);
            CHECK(entry->flags == (ERR_FLAG_STRING | ERR_FLAG_MALLOCED) && strcmp(entry->data, expected) == 0);
        } else CHECK(entry->flags == 0 && entry->data[0] == 0);
    }
    for (unsigned int step = 1; step <= 3; step++) {
        const error_queue queue = read_alert(test, output, step, "repeat_alert_read");
        CHECK(same_queue(&queue, &test->first_queue));
        const uint8_t payload = static_cast<uint8_t>(0x70 + step);
        const measured_result operation = measured_write(test->pair.client, &payload, 1);
        const error_queue write = record_full_operation(output, step, test->name, "post_alert_write", operation,
            &test->pair.client_observations, &test->alert_calls);
        if (test->kind < 4) {
            CHECK(operation.result == 1 && operation.error == SSL_ERROR_NONE && write.count == 0);
            uint8_t received = 0;
            CHECK(SSL_read(test->pair.server, &received, 1) == 1 && received == payload);
            test->positive_writes = true;
        } else {
            CHECK(operation.result < 0 && operation.error == SSL_ERROR_SSL && write.count == 1);
            CHECK(ERR_GET_REASON(write.entries[0].packed) == SSL_R_PROTOCOL_IS_SHUTDOWN);
        }
        if (step == 1) test->write_queue = write;
        else CHECK(same_queue(&test->write_queue, &write));
    }
    CHECK(test->pair.client_observations.received_tickets == 0);
    validate_alerts(test);
}

static void print_summary(FILE *summary, const alert_case *test)
{
    fprintf(summary, "{\"case\":\"%s\",\"suite\":4865,\"tls13_verified\":true,\"hostname_verified\":true,\"description\":%u,\"public_sender\":%s,\"native_sealed_negative_input\":%s,\"formats_peer_alert_text\":%s,\"warm_payload_each_direction\":4096,\"warm_payload_exact\":true,\"repeat_read_cycles\":3,\"repeat_write_cycles\":3,\"positive_post_alert_writes\":%s,\"warm_reads\":", test->name, test->description, test->kind == 1 || test->kind == 2 || test->kind == 3 ? "true" : "false", test->kind == 0 || test->kind == 4 ? "true" : "false", test->kind < 3 ? "true" : "false", test->positive_writes ? "true" : "false");
    print_counts(summary, test->warm_reads.counts);
    fprintf(summary, ",\"warm_writes\":"); print_counts(summary, test->warm_writes.counts);
    fprintf(summary, ",\"alert_calls\":"); print_counts(summary, test->alert_calls.counts);
    fprintf(summary, ",\"alert_operations\":%u,\"first_read_queue\":", test->alert_calls.operations); print_queue(summary, &test->first_queue);
    fprintf(summary, ",\"post_alert_write_queue\":"); print_queue(summary, &test->write_queue);
    fprintf(summary, ",\"client_alerts\":[");
    const protocol_observations *observed = &test->pair.client_observations;
    for (unsigned int i = 0; i < observed->alert_count; i++) fprintf(summary, "%s[%u,%u,%u]", i ? "," : "", observed->alerts[i][0], observed->alerts[i][1], observed->alerts[i][2]);
    fprintf(summary, "],\"peer_alerts\":["); observed = &test->pair.server_observations;
    for (unsigned int i = 0; i < observed->alert_count; i++) fprintf(summary, "%s[%u,%u,%u]", i ? "," : "", observed->alerts[i][0], observed->alerts[i][1], observed->alerts[i][2]);
    fprintf(summary, "]}\n");
}

static void free_pair(tls_pair *pair)
{
    SSL_free(pair->client); pair->client = nullptr;
    SSL_free(pair->server); pair->server = nullptr;
    SSL_CTX_free(pair->client_context); pair->client_context = nullptr;
    SSL_CTX_free(pair->server_context); pair->server_context = nullptr;
}

int main(int argc, char **argv)
{
    CHECK(argc == 9 && uwz_alloc_self_test());
    const bool require_zero = strcmp(argv[8], "--require-zero") == 0;
    CHECK(require_zero || strcmp(argv[8], "--observe") == 0);
    output_files output{fopen(argv[4], "wx"), fopen(argv[5], "wx"), 0};
    FILE *summary = fopen(argv[6], "wx"), *lifetime = fopen(argv[7], "wx");
    CHECK(output.operations && output.events && summary && lifetime);
    fprintf(output.operations, "step,scenario,phase,operation,result,error,malloc,calloc,realloc,free,bytes,received_tickets,received_key_updates,sent_key_updates\n");
    alert_case tests[5]{};
    const char *names[] = {"native_fatal_zero", "public_fatal_99", "public_fatal_255", "public_warning_close_zero", "native_malformed_one_byte"};
    const uint8_t descriptions[] = {0,99,255,0,0};
    for (unsigned int i = 0; i < 5; i++) {
        tests[i].name = names[i]; tests[i].kind = i; tests[i].description = descriptions[i];
        prepare_alert(&tests[i], argv[1], argv[2], argv[3], &output);
        run_alert(&tests[i], &output);
    }
    const error_queue before = read_alert(&tests[2], &output, 4, "cross_b255_before_a0");
    CHECK(same_queue(&before, &tests[2].first_queue));
    const error_queue a = read_alert(&tests[0], &output, 4, "cross_a0_after_b255");
    CHECK(same_queue(&a, &tests[0].first_queue));
    const error_queue b = read_alert(&tests[2], &output, 5, "cross_b255_after_a0");
    CHECK(same_queue(&b, &tests[2].first_queue));
    uint8_t unused[16];
    const measured_result operation = measured_read(tests[2].pair.client, unused, sizeof(unused));
    CHECK(operation.result < 0 && operation.error == SSL_ERROR_SSL);
    const char *file = nullptr, *data = nullptr; int line = 0, flags = 0;
    const uint32_t packed = ERR_get_error_line_data(&file, &line, &data, &flags);
    CHECK(packed == tests[2].first_queue.entries[0].packed && flags == (ERR_FLAG_STRING | ERR_FLAG_MALLOCED));
    CHECK(data != nullptr && strcmp(data, "SSL alert number 255") == 0);
    CHECK(strcmp(file, tests[2].first_queue.entries[0].file) == 0 && line == tests[2].first_queue.entries[0].line);
    SSL_free(tests[2].pair.client); tests[2].pair.client = nullptr;
    CHECK(strcmp(data, "SSL alert number 255") == 0);
    record_captured_operation(&output, 6, tests[2].name, "popped_255_lifetime_read", operation,
        &tests[2].pair.client_observations, &tests[2].alert_calls, &tests[2].first_queue);
    ERR_clear_error();
    fprintf(lifetime, "{\"immediate_b255_a0_b255_restore\":true,\"popped_255_string_valid_after_ssl_free\":true,\"popped_flags\":%d,\"popped_reason\":%d,\"read_result\":%d,\"read_error\":%d,\"read_counts\":", flags, ERR_GET_REASON(packed), operation.result, operation.error);
    print_counts(lifetime, operation.counts); fprintf(lifetime, "}\n");
    bool zero = counts_zero(operation.counts);
    for (alert_case &test : tests) {
        print_summary(summary, &test); zero = zero && counts_zero(test.alert_calls.counts); free_pair(&test.pair);
    }
    CHECK(fclose(output.operations) == 0 && fclose(output.events) == 0 && fclose(summary) == 0 && fclose(lifetime) == 0);
    puts("PASS: five peer-alert boundary/control rows, repeated public I/O, immediate cross-SSL restore and popped-string lifetime");
    if (require_zero && !zero) { fputs("FAIL: strict complete-call peer-alert allocation gate\n", stderr); return 1; }
    return 0;
}
