#!/usr/bin/env python3
"""Compare unchanged wire inputs, including explicit native error source sites."""
import argparse
import csv
import difflib
import hashlib
import json
from pathlib import Path
import verify_alerts
import verify_variants

FIELDS=('malloc','calloc','realloc','free','bytes')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def site_mapping(before,after,old_native,new_native,frozen):
    old=Path(before['file']);new=Path(after['file'])
    relative=old.relative_to(old_native/'boringssl')
    assert relative==new.relative_to(new_native/'boringssl')
    key=(str(relative),before['line'],after['line'])
    if frozen is not None:
        assert key in frozen,key
        return frozen[key]
    a=old.read_text().splitlines();b=new.read_text().splitlines()
    x=before['line']-1;y=after['line']-1
    assert a[x]==b[y]
    blocks=[block for block in difflib.SequenceMatcher(None,a,b,autojunk=False).get_matching_blocks()
        if block.a<=x<block.a+block.size and block.b+x-block.a==y]
    assert len(blocks)==1,key
    return {'relative_file':str(relative),'baseline_line':x+1,'candidate_line':y+1,
        'unchanged_statement':a[x],'matching_source_block_lines':blocks[0].size,
        'baseline_source_sha256':digest(old),'candidate_source_sha256':digest(new),
        'baseline_context':a[max(0,x-2):x+3],'candidate_context':b[max(0,y-2):y+3]}


def compare_value(before,after,old_native,new_native,frozen,sites,require_zero):
    if isinstance(before,dict):
        assert isinstance(after,dict) and set(before)==set(after)
        if set(before)==set(FIELDS):
            assert all(value>=0 for value in after.values())
            if require_zero:assert all(value==0 for value in after.values())
            return
        if {'packed','file','line'}.issubset(before):
            assert {k:v for k,v in before.items() if k not in ('file','line')}=={k:v for k,v in after.items() if k not in ('file','line')}
            site=site_mapping(before,after,old_native,new_native,frozen)
            key=(site['relative_file'],site['baseline_line'],site['candidate_line'])
            if key in sites:assert sites[key]==site
            sites[key]=site
            return
        for key in before:compare_value(before[key],after[key],old_native,new_native,frozen,sites,require_zero)
        return
    if isinstance(before,list):
        assert isinstance(after,list) and len(before)==len(after)
        for a,b in zip(before,after):compare_value(a,b,old_native,new_native,frozen,sites,require_zero)
        return
    assert before==after,(before,after)


def compare(base,frozen):
    old=base/'baseline'
    old_native=Path(json.loads((old/'provenance.json').read_text())['native_root'])
    old_validation=verify_alerts.verify(old,False)
    a=list(csv.DictReader((old/'observe_operations.csv').open()))
    source_base=Path(__file__).resolve().parent
    original=(source_base/'alert_witness.cc').read_bytes()
    expected_unreserved=original.replace(b'    CHECK(SSL_reserve_error_state(pair->client));\n',b'')
    assert expected_unreserved!=original
    sites={};variants=[]
    for name in ('candidate','candidate_unreserved'):
        new=base/name;reserved=name=='candidate'
        provenance=json.loads((new/'provenance.json').read_text())
        new_native=Path(provenance['native_root'])
        assert provenance['error_state_reserved']==reserved
        validation=verify_variants.verify(new,reserved)
        expected_source=original if reserved else expected_unreserved
        assert provenance['fixture_sha256']==hashlib.sha256(expected_source).hexdigest()
        assert json.loads((old/'provenance.json').read_text())['fixture_sha256']==hashlib.sha256(original).hexdigest()
        b=list(csv.DictReader((new/'observe_operations.csv').open()))
        assert len(a)==len(b)==164
        changes=[]
        for index,(before,after) in enumerate(zip(a,b)):
            assert {k:v for k,v in before.items() if k not in FIELDS}=={k:v for k,v in after.items() if k not in FIELDS}
            if reserved:assert all(int(after[field])==0 for field in FIELDS)
            previous={field:int(before[field]) for field in FIELDS};current={field:int(after[field]) for field in FIELDS}
            if previous!=current:changes.append({'index':index,'case':before['scenario'],'phase':before['phase'],
                'step':int(before['step']),'baseline_reserved':previous,'candidate':current})
        for filename in ('events.jsonl','summary.jsonl'):
            left=[json.loads(line) for line in (old/('observe_'+filename)).read_text().splitlines()]
            right=[json.loads(line) for line in (new/('observe_'+filename)).read_text().splitlines()]
            compare_value(left,right,old_native,new_native,frozen,sites,reserved)
        compare_value(json.loads((old/'observe_lifetime.json').read_text()),json.loads((new/'observe_lifetime.json').read_text()),old_native,new_native,frozen,sites,reserved)
        variants.append({'variant':name,'reservation_enabled':reserved,'validation':validation,
            'same_frozen_fixture_source':reserved,'only_startup_error_reservation_removed':not reserved,
            'actual_count_changes':changes,'unreserved_old_array_byte_parity_asserted':False})
    return {'client_calls_per_selector':164,'baseline':old_validation,'variants':variants,
        'error_source_sites':list(sites.values()),'raw_file_line_logs_rewritten':False,
        'source_site_mapping_requires_independent_review':True,'generic_entry_bytes_assumed_unchanged':False,
        'complete_postgresql_gate_closed':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('directory',type=Path)
    parser.add_argument('--frozen-sites',type=Path);args=parser.parse_args();frozen=None
    if args.frozen_sites:
        rows=json.loads(args.frozen_sites.read_text())['error_source_sites']
        frozen={(r['relative_file'],r['baseline_line'],r['candidate_line']):r for r in rows}
        assert len(frozen)==len(rows)
    print(json.dumps(compare(args.directory.resolve(),frozen),indent=2))


if __name__=='__main__':main()
