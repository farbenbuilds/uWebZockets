# Independent source/evidence review: owned short TLS error data

Date: 2026-11-17. Reviewer: /root/tls_error_review.

No unresolved actionable findings remain in the reviewed Phase B source and
functional evidence. This covers the isolated candidate. Production adoption,
PostgreSQL's complete allocation gate and transformed delivery remain separate.

## Source and strict maintainability review

Incremental patch SHA256:
16abd85274983350043a8ebcd8bbf32c343fbd8f177b4403ef2bd3440c700efd.
Cumulative fifteen-path patch SHA256:
962ff38672b6b8fa5bbff49197f7cd1bebd017120f6bed0e8e59019f2f7345aa.
Matching libssl.a:
b0b35e16a11c00529cbae09abab58d18cf5ec84c7596aff600d59267db0aba30.
Matching libcrypto.a:
e9cb29281bbc2b4dabb17863c1f7fbc51fdb93cb6ad2bdd016b481be443a1d9a.

Only crypto/err/err.cc and ssl/tls_record.cc change behavior; both header edits
are comments only. I independently checked all 8709 actual candidate entries,
types, modes and hashes, all twenty-one retained function-body hashes, and both
comment-only header comparisons. Generic formatter/concatenation generation,
raw-buffer adoption, snapshot APIs, marks and prior SSL policy/lifecycle bodies
remain consistent with the accepted contract.

Root explicitly requested the pinned thermo-nuclear maintainability lens in
addition to code-review-and-quality. ERR grows from 889 to 939 lines and remains
cohesive. Five central helpers encode inline identity, release, data-only clear,
empty-destination copy and independent popped ownership. Flat pointer/array fields
keep ownership in ERR while SSL retains opaque snapshots. No new state layer,
forwarding abstraction, scattered storage policy or justified file split is
needed. The bounded TLS formatter remains independently removable from the
usable general ERR optimization.

Short public replacements stage aliases before clearing. Long replacements copy
before commit, preserving old data on spill OOM. Data-only setters preserve marks
and metadata; snapshot copies preserve the original mark-reset/best-effort data
semantics. Inline pop copies into independent thread storage and reassigns the
returned pointer afterward. Raw formatter buffers retain their original adoption
and transfer lifetime. No shallow ownership copies or inline-free path was found.
Present empty data remains distinct from absence. Output flags3 remain library
owned; input MALLOCED requires valid OPENSSL_malloc provenance.

## Independently executed and reconciled proof

I independently executed the twelve-row immutable Phase A baseline in observe
mode and the identical-source candidate in strict short-storage mode. Baseline
observe passes, its recorded strict gate remains RED, and candidate strict
exits0. The exact original
allocation counter/self-test is unchanged. Short/empty/31-byte copies and aliases
become zero; 32/6000-byte spill, required input free, generic printf/concatenation
and generic snapshot header/array remain honest positive controls.

I source-reviewed and independently executed the selected twenty-one-row
ownership/fault/destructor program. It covers persistent-failure short zero,
nonuniform long aliases and 32-to-31 suffixes, old-heap frees, metadata/marks,
peek/pop lifetime, valid OpenSSL input consumption/erasure on success and OOM,
generic header/array and each/persistent long-copy failure, mixed15-to1-to0
cleanup, and actual pthread destruction of inline, long and raw-formatted data.
The documented fault observer is separate from the original allocation counter.

Compiler dumps confirm host layouts entry56/thread944/reserved848/header16/S3
656, all alignment8. Two startup owners request1696 bytes; a cold worker needs
984 bytes including its unchanged forty-byte thread table. The failed combined
layout probe is retained as fixture history; separate probes pass without native
code or macro weakening.

I recomputed the small and extended wire comparisons and independently bound
all source-site hashes/statements/contexts. The same164-call alert witness is
zero under reservation for actual0x1301/0x1302/0x1303, retaining full error fields,
callback order, fatal0 versus warning-close0, malformed-length rejection,
peer-fatal successful writes and popped-string lifetime. Unreserved controls
remain functional/RED with actual new72/144-byte shapes. Raw paths and lines
are retained; old record-byte equality is not asserted. Inherited163-call full
fatal,27-row/1320-call protocol and12-row/255-call controls are zero with all
available original observations preserved. Additional suites change only the
explicit suite input/model field; original public controls retain0x1301 scope.

All fourteen Phase A input snapshots bind to immutable originals. Exactly four
layout-arithmetic replacements occur across three C++ files; no other source or
assertion changes occur. All51 older inputs plus their driver remain byte
identical. Both eight-command aggregate groups and the HKDF comparison pass.
These larger matrices were reconciled from producer records rather than rerun
by this reviewer. I independently hashed both Root-restored8709-entry source
trees, confirmed exact types/modes/hashes and the four before-write refusals,
including a genuinely chmod-only changed input.

## Frozen evidence and limits

Native producer: .zig-cache/sql-tls-error-data-fixed-20261117.
All836 regular payloads/835 manifest hashes and24 selected executable hashes
were checked. Its91 recorded replay commands have expected statuses, including
one deliberate baseline short-gate exit1; private PKI is removed.

- HANDOFF: 7a4cbd6e9c7285f53a023e79f4762a03ecb3d8cc4149217d2b9501ec3d280ef0.
- files.sha256: ae171a185e70990e89699ff24251a84f1508e4fa0b92a7cd4eb0151c4f21845e.
- Current24-program identity: 48bfb9a80e416bef26b74b8712a3001ac819fe6f3db8330e487ecf7a65610fcf.

Wire producer: .zig-cache/sql-tls-error-data-wire-20261117.
All410 regular payloads/409 hashes and eight selected executable hashes were
checked. Its22 replay commands include eighteen executable runs/4197 actual
client calls, with expected GREEN/RED statuses and removed PKI. The original
29-file baseline remains exact; source-backed/offline comparisons agree.

- HANDOFF: 1ad1ccb819c953bd0a194cb3a50cd641bfa1641e335567aadf2f49ac2aa685f9.
- Payload manifest: 3e4e8835d7c5d65c686974198736f8bcf9b57fc399191b4e6d855800cc8562b5.
- Current eight-program identity: 45a754c074bb68de50822d0d1786f78fbee997e5bd5438f167b68764a7dd96fc.

No dedicated smoke/security/sanitizer/fuzz/scan campaign was run. Long diagnostic
spill, generic formatting, previously heap-backed history and cold initialization
remain allocating controls, without an automatic PostgreSQL exception. SQL
teardown/cancellation/reconnect attribution, native publication, production
adoption and the complete request-path allocation proof remain open. Delivery
transformation, final archive/member checks and Root's final project gates still
require their separate review/verification.
