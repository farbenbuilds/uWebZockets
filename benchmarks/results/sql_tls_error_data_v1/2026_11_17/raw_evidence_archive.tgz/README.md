# Owned short TLS error data evidence

This isolated native candidate stores copied strings through 31 payload bytes
plus NUL inline and preserves complete heap spill for longer text. Native peer
alerts use a bounded stack formatter followed by the copying setter. Generic
formatters retain their original raw-buffer adoption. Production adoption and
the complete PostgreSQL allocation gate remain open.

`native/` contains the four-file increment, fifteen-file cumulative proposal,
8709-entry inventories/restoration, Zig build and layout proofs, ownership/OOM
fixtures, input deltas and inherited controls. `wire/` contains the five alert
cases across three negotiated suites and inherited fault/protocol/control
records. Their handoffs distinguish original measured IDs from delivered copies.
`delivery_transform/` records debug-section removal on selected staged ELFs,
original identities/manifests and unchanged-runtime/input proofs. Raw results,
source, historical IDs and producer files are unchanged by delivery.

`root_checks/` records production unit/project checks, independent source
restoration, final delivered-program replays and remaining integration duties.
`reviews/` holds independent source/delivery reviews and architecture analysis.

Verify every retained payload from this extracted directory:

```sh
sha256sum -c files.sha256
```

The external PKI helper is deliberately omitted. `external_inputs.json` binds
its exact hash and earlier retained archive member. Restore it offline with:

```sh
python3 restore_pki_tool.py /absolute/path/repository
```

Then run the selected host programs into absent directories outside this tree:

```sh
python3 native/replay_prebuilt.py --pki-tool /absolute/path/wt-tools --output /absolute/path/new-native-results
python3 wire/replay_prebuilt.py --pki-tool /absolute/path/wt-tools --output /absolute/path/new-wire-results
```

Replay requires no compiler, native source or static archives. It verifies
expected statuses, including deliberately allocating controls, and removes its
ephemeral PKI. Source restoration separately accepts the exact original
BoringSSL d3bf4795ad5b79d646cddf2fec687da5b9b502db tree or the preceding candidate
with `--source-kind error-snapshot`. Inventories bind every file's type, mode
and bytes. Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain
user-deferred; this component is neither production integration nor a release.
