#!/usr/bin/env python3
"""Copy frozen error-data evidence and strip delivery DWARF only."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import runpy
import shutil
import stat
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def payload_path(root, name):
    rel = PurePosixPath(name)
    path = root / name
    if not name or rel.is_absolute() or '..' in rel.parts or path.is_symlink():
        raise ValueError('Unsafe payload path: ' + name)
    if not path.resolve().is_relative_to(root.resolve()) or not path.is_file():
        raise ValueError('Payload is not a contained regular file: ' + name)
    return path


def manifest_hashes(root, config):
    path = root / config['manifest']
    if config['manifest_kind'] == 'json':
        return json.loads(path.read_text())[config['hash_map_key']]
    if config['manifest_kind'] != 'sha256':
        raise ValueError('Unknown manifest format')
    pairs = [line.split('  ', 1) for line in path.read_text().splitlines()]
    result = {name: checksum for checksum, name in pairs}
    if len(result) != len(pairs):
        raise ValueError('Duplicate hash-manifest entry')
    return result


def inventory(root, config):
    names = (root / config['allowlist']).read_text().splitlines()
    if len(set(names)) != len(names) or not names:
        raise ValueError('Payload allowlist must be nonempty and unique')
    if not set(config['unhashed_inventory_files']).issubset(
            {config['manifest'], config['allowlist'], config['identity']}):
        raise ValueError('Every unmanifested file needs an explicit freeze identity')
    hashes = manifest_hashes(root, config)
    if set(names) != set(hashes) | set(config['unhashed_inventory_files']):
        raise ValueError('Allowlist and explicit manifest inventory differ')
    for name in names:
        path = payload_path(root, name)
        if path.suffix in {'.a', '.o', '.pem', '.key'}:
            raise ValueError('Archive-policy conflict in selected payload: ' + name)
        if name in hashes and sha(path) != hashes[name]:
            raise ValueError('Payload checksum differs: ' + name)
    return names, hashes


def write_manifest(root, config, hashes):
    path = root / config['manifest']
    if config['manifest_kind'] == 'json':
        data = json.loads(path.read_text())
        data[config['hash_map_key']] = hashes
        path.write_text(json.dumps(data, indent=2) + '\n')
        return
    path.write_text(''.join(checksum + '  ' + name + '\n'
                            for name, checksum in hashes.items()))


def verify_original(root, config):
    for key in ['manifest', 'allowlist', 'identity']:
        if sha(root / config[key]) != config[key + '_sha256']:
            raise ValueError('Frozen producer identity differs: ' + key)
    names, hashes = inventory(root, config)
    identity = json.loads((root / config['identity']).read_text())
    binaries = identity['binaries']
    if len(names) != config['payload_file_count']:
        raise ValueError('Frozen producer file count differs')
    if len(binaries) != config['binary_count'] or not 1 <= len(binaries) <= 32:
        raise ValueError('Unexpected bounded executable inventory')
    if not set(binaries).issubset(hashes):
        raise ValueError('Executable identity lies outside manifest')
    for name, checksum in binaries.items():
        if hashes[name] != checksum:
            raise ValueError('Executable hash maps disagree: ' + name)
    for name in config['historical_identity_files']:
        if name not in hashes or name in binaries or name == config['identity']:
            raise ValueError('Historical identity needs a distinct frozen manifest entry')
    return names, hashes, identity


def main():
    if len(sys.argv) != 2:
        raise ValueError('Usage: stage_delivery.py FREEZE_CONFIG.json')
    config_path = Path(sys.argv[1]).resolve()
    config = json.loads(config_path.read_text())
    if config['root_authorized_scope'] != 'frozen producer copy and delivery-only strip-debug':
        raise ValueError('Unexpected Root-authorized scope')
    stage = Path(config['stage_root'])
    scratch = Path(__file__).resolve().parent
    outputs = scratch / 'stripped'
    if stage.exists() or outputs.exists():
        raise ValueError('Choose absent staging and transformation outputs')
    if set(config['producers']) != {'native', 'wire'}:
        raise ValueError('Expected exactly the two accepted producers')
    original = {}
    for subtree, producer in config['producers'].items():
        root = Path(producer['root'])
        original[subtree] = verify_original(root, producer)
        print('verified frozen ' + subtree, flush=True)
    tool = Path('/usr/bin/objcopy')
    if sha(tool) != '05f4473d24f7330a9b13f43d007d619a2e792e33de453cd7533a2d97c30da770':
        raise ValueError('Strip tool identity differs')
    elf = runpy.run_path(str(scratch / 'elf_delivery.py'))
    stage.mkdir()
    transform = stage / 'delivery_transform'
    transform.mkdir()
    outputs.mkdir()
    shutil.copy2(config_path, transform / 'freeze_config.json')
    rows = []
    for subtree, producer in config['producers'].items():
        root = Path(producer['root'])
        target_root = stage / subtree
        names, hashes, identity = original[subtree]
        for name in names:
            source = payload_path(root, name)
            target = target_root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            if sha(source) != sha(target):
                raise ValueError('Copy differs: ' + name)
        for key in ['manifest', 'identity']:
            shutil.copy2(root / producer[key], transform / ('original_' + subtree + '_' + Path(producer[key]).name))
        for name, checksum in identity['binaries'].items():
            source = payload_path(root, name)
            target = target_root / name
            stripped = outputs / subtree / name
            stripped.parent.mkdir(parents=True, exist_ok=True)
            if sha(source) != checksum or sha(target) != checksum:
                raise ValueError('Executable changed before transformation')
            command = [str(tool), '--strip-debug', str(target), str(stripped)]
            result = subprocess.run(command, capture_output=True, text=True)
            if result.returncode:
                raise RuntimeError('objcopy failed: ' + result.stderr)
            before, after = source.read_bytes(), stripped.read_bytes()
            proof = elf['compare_elf'](before, after)
            mode = stat.S_IMODE(source.stat().st_mode)
            if len(after) >= len(before) or not mode & 0o111:
                raise ValueError('Expected a smaller executable delivery copy')
            temporary = target.with_name(target.name + '.delivery-temp')
            if temporary.exists():
                raise ValueError('Temporary transformation file already exists')
            shutil.copyfile(stripped, temporary)
            temporary.chmod(mode)
            os.replace(temporary, target)
            rows.append({'subtree': subtree, 'path': name, 'command': command,
                         'exit_code': result.returncode,
                         'original_measured_sha256': checksum,
                         'original_measured_bytes': len(before),
                         'delivered_sha256': sha(target), 'delivered_bytes': len(after),
                         'executable_mode': mode, 'elf_comparison': proof})
            identity['binaries'][name] = sha(target)
        if 'delivery_stripping' in identity:
            if identity['delivery_stripping'] is not False:
                raise ValueError('Original delivery-strip metadata must be false')
            identity['delivery_stripping'] = True
        (target_root / producer['identity']).write_text(json.dumps(identity, indent=2) + '\n')
        current = {name: sha(target_root / name) for name in hashes}
        write_manifest(target_root, producer, current)
        inventory(target_root, producer)
        print('staged and stripped ' + subtree, flush=True)
    manifest = {'complete': True, 'scope': 'delivery-only debug-section removal',
                'freeze_config': config,
                'tool': {'path': str(tool), 'sha256': sha(tool),
                         'version_output': subprocess.check_output([str(tool), '--version'], text=True),
                         'operation': '--strip-debug'},
                'binaries': rows,
                'totals': {'binaries': len(rows),
                           'original_bytes': sum(row['original_measured_bytes'] for row in rows),
                           'delivered_bytes': sum(row['delivered_bytes'] for row in rows)},
                'historical_identity_files': {
                    name: producer['historical_identity_files']
                    for name, producer in config['producers'].items()},
                'native_compilation_or_relinking': False,
                'source_producer_mutation': False,
                'zig_objcopy_limitation': 'Prior evidence: Zig 0.16.0 ELF-to-ELF strip is unimplemented; no new probe'}
    (transform / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    for name in ['stage_delivery.py', 'elf_delivery.py', 'verify_delivery.py']:
        shutil.copy2(scratch / name, transform / name)
    print(json.dumps(manifest['totals'], indent=2))


if __name__ == '__main__':
    main()
