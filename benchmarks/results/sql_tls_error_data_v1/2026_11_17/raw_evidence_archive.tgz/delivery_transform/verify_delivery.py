#!/usr/bin/env python3
"""Verify frozen producer stability and authorized delivery transformations."""
import json
from pathlib import Path
import runpy
import stat


def main():
    here = Path(__file__).resolve().parent
    stage = here.parent
    manifest = json.loads((here / 'manifest.json').read_text())
    config = manifest['freeze_config']
    common = runpy.run_path(str(here / 'stage_delivery.py'), run_name='delivery_functions')
    elf = runpy.run_path(str(here / 'elf_delivery.py'), run_name='elf_functions')
    sha = common['sha']
    rows = manifest['binaries']
    if len({(row['subtree'], row['path']) for row in rows}) != len(rows):
        raise ValueError('Duplicate executable transform row')
    original_entries = 0
    unchanged_entries = 0
    for subtree, producer in config['producers'].items():
        root = Path(producer['root'])
        target = stage / subtree
        names, hashes, original_identity = common['verify_original'](root, producer)
        identity = json.loads((target / producer['identity']).read_text())
        archived_identity = here / ('original_' + subtree + '_' + Path(producer['identity']).name)
        archived_manifest = here / ('original_' + subtree + '_' + Path(producer['manifest']).name)
        if sha(archived_identity) != producer['identity_sha256']:
            raise ValueError('Archived original identity differs')
        if sha(archived_manifest) != producer['manifest_sha256']:
            raise ValueError('Archived original manifest differs')
        selected = [row for row in rows if row['subtree'] == subtree]
        if {row['path'] for row in selected} != set(original_identity['binaries']):
            raise ValueError('Transform rows differ from executable inventory')
        expected_identity = json.loads(archived_identity.read_text())
        for row in selected:
            expected_identity['binaries'][row['path']] = row['delivered_sha256']
        if 'delivery_stripping' in expected_identity:
            if expected_identity['delivery_stripping'] is not False:
                raise ValueError('Original strip metadata differs')
            expected_identity['delivery_stripping'] = True
        if identity != expected_identity:
            raise ValueError('Unauthorized executable identity metadata change')
        actual_names, current_hashes = common['inventory'](target, producer)
        if actual_names != names:
            raise ValueError('Delivery allowlist changed')
        actual_files = []
        for path in target.rglob('*'):
            if path.is_symlink():
                raise ValueError('Delivery symlink is not allowed')
            if path.is_file():
                actual_files.append(path.relative_to(target).as_posix())
        if set(actual_files) != set(names):
            raise ValueError('Delivery contains files outside frozen allowlist')
        changed = set(original_identity['binaries']) | {producer['identity']}
        if set(current_hashes) != set(hashes):
            raise ValueError('Current manifest key set changed')
        for name in names:
            original_entries += 1
            if name in changed or name == producer['manifest']:
                continue
            if sha(root / name) != sha(target / name):
                raise ValueError('Non-delivery bytes changed: ' + name)
            unchanged_entries += 1
        if producer['manifest_kind'] == 'json':
            original_metadata = json.loads(archived_manifest.read_text())
            current_metadata = json.loads((target / producer['manifest']).read_text())
            del original_metadata[producer['hash_map_key']]
            del current_metadata[producer['hash_map_key']]
            if current_metadata != original_metadata:
                raise ValueError('Unauthorized JSON manifest metadata change')
    for row in rows:
        root = Path(config['producers'][row['subtree']]['root'])
        source = root / row['path']
        target = stage / row['subtree'] / row['path']
        before, after = source.read_bytes(), target.read_bytes()
        if sha(source) != row['original_measured_sha256'] or sha(target) != row['delivered_sha256']:
            raise ValueError('Executable transformation identity differs')
        if len(before) != row['original_measured_bytes'] or len(after) != row['delivered_bytes']:
            raise ValueError('Executable transformation size differs')
        if stat.S_IMODE(source.stat().st_mode) != row['executable_mode']:
            raise ValueError('Original executable mode changed')
        if stat.S_IMODE(target.stat().st_mode) != row['executable_mode']:
            raise ValueError('Delivered executable mode changed')
        if elf['compare_elf'](before, after) != row['elf_comparison']:
            raise ValueError('Recomputed runtime ELF proof differs')
    result = {'complete': True,
              'source_producers_unchanged': len(config['producers']),
              'original_payload_entries_verified': original_entries,
              'non_delivery_staged_entries_unchanged': unchanged_entries,
              'selected_executable_elf_and_permission_proofs_recomputed': len(rows),
              'regular_symbol_tables_retained': len(rows),
              'raw_results_sources_runners_or_native_inputs_changed': False,
              'historical_identity_files_preserved': {
                  name: producer['historical_identity_files']
                  for name, producer in config['producers'].items()},
              'other_identity_and_manifest_metadata_unchanged': True,
              'functional_replay': 'Root-owned, required after this static verification'}
    (here / 'post_transform_verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
