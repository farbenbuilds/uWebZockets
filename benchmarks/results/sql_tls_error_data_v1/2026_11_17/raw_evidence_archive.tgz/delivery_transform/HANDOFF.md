# Error-data delivery transformation

The frozen native/direct/control and wire producers were copied from their
explicit allowlists, then only staged selected executables had nonallocated
debug sections removed. No compiler, optimizer, relinker or native source
modification was used. The operation covered 32 Debug ELF64 x86-64 programs,
reducing executable bytes from 478,370,120 to 130,837,304.

| Subtree | Programs | Original executable bytes | Delivered executable bytes |
|---|---:|---:|---:|
| native | 24 | 327,589,064 | 88,546,672 |
| wire | 8 | 150,781,056 | 42,290,632 |

`manifest.json` records every original measured identity, actual delivered
identity, byte count, command, exit status, mode and bounded ELF comparison.
`freeze_config.json` binds both exact original inventories and current identity
maps. Original producer manifests and identity maps are archived unchanged as
`original_native_files.sha256`, `original_native_prebuilt_identity.json`,
`original_wire_payload_manifest.json` and
`original_wire_prebuilt_identity.json`.

Current native identity metadata changes only its 24 selected binary hashes.
Its optimization and both native archive maps remain identical. Current wire
identity changes only its eight selected binary hashes and its explicit
`delivery_stripping` flag from false to true. Its optimization field describes
the original measured Debug build. No delivery-size or indirection fields were
added to either current identity map. Only hash values were refreshed in each
current subtree manifest; all other JSON manifest metadata remains unchanged.

The wire files `original_measured_identity.json`, `baseline_frozen.json` and raw
result identities are historical original Debug measurements and remain
byte-identical. Current prebuilt replay validates `prebuilt_identity.json` and
`payload_manifest.json`; it does not compare a historical Debug binary hash to
the stripped delivery copy. Native per-run measured binary/source/arithmetic
identities likewise remain unchanged and are not current replay selectors.

The existing tool was `/usr/bin/objcopy --strip-debug`, SHA-256
`05f4473d24f7330a9b13f43d007d619a2e792e33de453cd7533a2d97c30da770`.
The complete version output is recorded in the transformation manifest. No tool
was installed, and this evidence-packaging operation adds no native build or
prebuilt-replay dependency. Prior retained evidence established that pinned
Zig 0.16.0 ELF-to-ELF objcopy is unimplemented; no additional probe was run.

The bounded ELF comparison was reused unchanged from the prior reviewed
error-snapshot delivery. Preparation verified that prior transformation's
fourteen file checks before copying its tools. This phase adds explicit
historical-identity inventory reporting without changing the ELF comparison.

For every executable, the entrypoint/ABI identity, program-header tuples,
allocated-section metadata and payloads are unchanged. Every PT_LOAD byte is
unchanged after normalizing only `e_shoff` at offset 40 for 8 bytes, `e_shnum`
at offset 60 for 2 bytes and `e_shstrndx` at offset 62 for 2 bytes. Regular symbol
tables and executable permissions remain present and unchanged. Original debug
sections are absent from delivery copies; complete-file hashes differ.

Independent static rechecking passed for both complete original payloads,
1,246 selected files, 1,210 untouched staged entries and all 32 runtime ELF,
regular-symbol-table and permission proofs. This includes all selected native
sources, fixture assertions, raw results, replay wrappers, historical identities
and archive provenance. Original producer files remain unchanged under:

- `.zig-cache/sql-tls-error-data-fixed-20261117`: 836 selected files and
  835 hash entries, 24 programs.
- `.zig-cache/sql-tls-error-data-wire-20261117`: 410 selected files and
  409 hash entries, eight programs.

`verify_delivery.py` can recheck these original producers against this staged
layout. It intentionally needs the immutable original producer roots for the
before/after comparison. The prebuilt native and wire replays need neither
original producer sources nor native archives. Run the static verification with:

```sh
env PYTHONDONTWRITEBYTECODE=1 python3 delivery_transform/verify_delivery.py
```

Root still owns both complete final copied-layout functional replays, using
`native/replay_prebuilt.py` and `wire/replay_prebuilt.py` with the exact offline
PKI tool and absent output directories outside the combined evidence root.
Root also adds the combined-root bootstrap marker and its checks/reviews, then
verifies the final archive. The temporary `tools/wt-tools` helper must be omitted
from that archive. This packaging step ran no dedicated smoke, security,
sanitizer, fuzz or scan campaign and makes no PostgreSQL allocation-gate claim.
