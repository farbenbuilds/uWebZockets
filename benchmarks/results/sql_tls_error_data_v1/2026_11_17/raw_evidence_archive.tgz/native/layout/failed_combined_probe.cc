#include <crypto/err/err.cc>
#include <ssl/internal.h>

static_assert(sizeof(err_error_st) == 56, "measured x86_64 inline error entry");
static_assert(sizeof(ERR_STATE) == 944, "measured x86_64 worker queue");
static_assert(sizeof(bssl::ERR_RESERVED_STATE) == 848, "measured x86_64 reserved snapshot");
static_assert(sizeof(bssl::ERR_SAVE_STATE) == 16, "unchanged x86_64 generic header");
static_assert(sizeof(bssl::SSL3_STATE) == 656, "unchanged x86_64 SSL connection state");
