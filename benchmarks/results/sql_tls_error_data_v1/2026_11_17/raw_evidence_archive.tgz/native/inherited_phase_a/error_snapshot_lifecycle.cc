#include "ticket_pair.h"
#include "ticket_fault.h"

static PeerPair ready_pair(char **arguments) {
  PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 4096);
  CHECK(SSL_reserve_record_buffers(pair.client));
  CHECK(SSL_reserve_client_post_handshake_buffer(pair.client));
  CHECK(SSL_reserve_key_update_context(pair.client));
  CHECK(SSL_reserve_key_update_output_buffers(pair.client));
  CHECK(SSL_discard_client_session_tickets(pair.client));
  return pair;
}

static void require_pair(SSL *ssl, bool present) {
  const auto *state = bssl::FromOpaque(ssl)->s3;
  CHECK((state->reserved_read_error != nullptr) == present);
  CHECK((state->reserved_alert_error != nullptr) == present);
  if (present) CHECK(state->reserved_read_error.get() != state->reserved_alert_error.get());
}

static void exchange(SSL *sender, SSL *receiver) {
  const uint8_t input[] = {2, 5, 8, 11, 14, 17, 20, 23};
  uint8_t output[sizeof(input)];
  CHECK(SSL_write(sender, input, sizeof(input)) == static_cast<int>(sizeof(input)));
  CHECK(SSL_read(receiver, output, sizeof(output)) == static_cast<int>(sizeof(output)));
  CHECK(memcmp(input, output, sizeof(input)) == 0);
}

static void expect_released(size_t owners) {
  const TicketFaultStats stats = ticket_fault_read();
  CHECK(stats.live == 0 && stats.actual_frees == owners);
  CHECK(stats.cleanse_failures == 0 && stats.calloc_calls == 0 && stats.realloc_calls == 0);
}

static void seed_queue() {
  ERR_put_error(ERR_LIB_SSL, 0, SSL_R_DECODE_ERROR, "synthetic_snapshot_lifecycle.cc", 71);
  ERR_set_error_data(const_cast<char *>("synthetic diagnostic"), ERR_FLAG_STRING);
}

static void check_queue() {
  const char *file = nullptr;
  const char *data = nullptr;
  int line = 0;
  int flags = 0;
  CHECK(ERR_peek_error_line_data(&file, &line, &data, &flags) == ERR_PACK(ERR_LIB_SSL, SSL_R_DECODE_ERROR));
  CHECK(strcmp(file, "synthetic_snapshot_lifecycle.cc") == 0 && line == 71);
  CHECK(strcmp(data, "synthetic diagnostic") == 0);
  CHECK(flags == (ERR_FLAG_STRING | ERR_FLAG_MALLOCED));
}

static void rollback_and_repeat(char **arguments, size_t fail_ordinal) {
  PeerPair pair = ready_pair(arguments);
  auto *state = bssl::FromOpaque(pair.client)->s3;
  uint8_t before[sizeof(*state)];
  memcpy(before, state, sizeof(before));
  const uint32_t options = SSL_get_options(pair.client);
  const uint32_t mode = SSL_get_mode(pair.client);
  SSL_SESSION *session = SSL_get_session(pair.client);
  ERR_clear_error();
  seed_queue();
  ticket_fault_reset();
  ticket_fault_arm_ordinal(fail_ordinal);
  const int result = SSL_reserve_error_state(pair.client);
  ticket_fault_disarm();
  const TicketFaultStats first = ticket_fault_read();
  CHECK(result == (fail_ordinal == 0));
  CHECK(SSL_get_options(pair.client) == options && SSL_get_mode(pair.client) == mode);
  CHECK(SSL_get_session(pair.client) == session);
  check_queue();
  if (fail_ordinal != 0) {
    CHECK(memcmp(before, state, sizeof(before)) == 0);
    CHECK(first.attempts == fail_ordinal && first.injected == 1);
    CHECK(first.successful == fail_ordinal - 1 && first.actual_frees == fail_ordinal - 1 && first.live == 0);
    require_pair(pair.client, false);
    ticket_fault_arm_ordinal(0);
    CHECK(SSL_reserve_error_state(pair.client));
    ticket_fault_disarm();
  } else {
    CHECK(first.attempts == 2 && first.successful == 2 && first.live == 2);
    CHECK(first.requested_bytes == 1696);
  }
  require_pair(pair.client, true);
  require_pair(pair.server, false);
  const auto *read = state->reserved_read_error.get();
  const auto *alert = state->reserved_alert_error.get();
  const TicketFaultStats before_repeat = ticket_fault_read();
  ticket_fault_arm_ordinal(1);
  CHECK(SSL_reserve_error_state(pair.client));
  ticket_fault_disarm();
  const TicketFaultStats after_repeat = ticket_fault_read();
  CHECK(memcmp(&before_repeat, &after_repeat, sizeof(before_repeat)) == 0);
  CHECK(state->reserved_read_error.get() == read && state->reserved_alert_error.get() == alert);
  check_queue();
  ERR_clear_error();
  exchange(pair.client, pair.server);
  exchange(pair.server, pair.client);
  OPENSSL_cleanse(before, sizeof(before));
  destroy_pair(&pair);
  expect_released(fail_ordinal == 0 ? 2 : fail_ordinal + 1);
  printf("PASS rollback_and_repeat: fail_ordinal=%zu\n", fail_ordinal);
}

static void reject_unchanged(SSL *ssl) {
  auto *state = bssl::FromOpaque(ssl)->s3;
  uint8_t before[sizeof(*state)];
  memcpy(before, state, sizeof(before));
  const TicketFaultStats initial = ticket_fault_read();
  ERR_clear_error();
  ticket_fault_arm_ordinal(1);
  CHECK(SSL_reserve_error_state(ssl) == 0);
  ticket_fault_disarm();
  const TicketFaultStats final = ticket_fault_read();
  CHECK(memcmp(&initial, &final, sizeof(initial)) == 0);
  CHECK(memcmp(before, state, sizeof(before)) == 0);
  CHECK(ERR_GET_REASON(ERR_peek_error()) == ERR_R_SHOULD_NOT_HAVE_BEEN_CALLED);
  OPENSSL_cleanse(before, sizeof(before));
  ERR_clear_error();
}

static void eligibility(char **arguments) {
  PeerPair pair = ready_pair(arguments);
  auto *state = bssl::FromOpaque(pair.client)->s3;
  ticket_fault_reset();
  reject_unchanged(pair.server);
  state->initial_handshake_complete = false;
  reject_unchanged(pair.client);
  state->initial_handshake_complete = true;
  state->version = TLS1_2_VERSION;
  reject_unchanged(pair.client);
  state->version = TLS1_3_VERSION;
  state->read_shutdown = bssl::ssl_shutdown_error;
  reject_unchanged(pair.client);
  state->read_shutdown = bssl::ssl_shutdown_none;
  state->write_shutdown = bssl::ssl_shutdown_close_notify;
  reject_unchanged(pair.client);
  state->write_shutdown = bssl::ssl_shutdown_none;
  uint8_t byte = 7;
  state->pending_app_data = bssl::Span<uint8_t>(&byte, 1);
  reject_unchanged(pair.client);
  state->pending_app_data = {};
  state->pending_write = bssl::Span<const uint8_t>(&byte, 1);
  reject_unchanged(pair.client);
  state->pending_write = {};
  state->unreported_bytes_written = 1;
  reject_unchanged(pair.client);
  state->unreported_bytes_written = 0;
  state->has_message = true;
  reject_unchanged(pair.client);
  state->has_message = false;
  state->alert_dispatch = true;
  reject_unchanged(pair.client);
  state->alert_dispatch = false;
  state->key_update_pending = true;
  reject_unchanged(pair.client);
  state->key_update_pending = false;
  state->key_update_candidate = state->aead_read_ctx.get();
  reject_unchanged(pair.client);
  state->key_update_candidate = nullptr;
  state->hs_buf->length = 1;
  reject_unchanged(pair.client);
  state->hs_buf->length = 0;
  state->pending_hs_data->length = 1;
  reject_unchanged(pair.client);
  state->pending_hs_data->length = 0;
  state->pending_flight->length = 1;
  reject_unchanged(pair.client);
  state->pending_flight->length = 0;
  state->pending_flight_offset = 1;
  reject_unchanged(pair.client);
  state->pending_flight_offset = 0;
  ticket_fault_arm_ordinal(0);
  CHECK(SSL_reserve_error_state(pair.client));
  ticket_fault_disarm();
  state->has_message = true;
  reject_unchanged(pair.client);
  state->has_message = false;
  CHECK(SSL_reserve_error_state(pair.client));
  destroy_pair(&pair);
  expect_released(2);
  printf("PASS eligibility: 17 isolated state guards, including active opt-in\n");
}

static void clear_case(char **arguments, unsigned mode) {
  PeerPair pair = ready_pair(arguments);
  auto *ssl = bssl::FromOpaque(pair.client);
  auto *old = ssl->s3;
  ticket_fault_reset();
  ticket_fault_arm_ordinal(0);
  CHECK(SSL_reserve_error_state(pair.client));
  ticket_fault_disarm();
  ticket_fault_watch(old, sizeof(*old));
  const auto *read = old->reserved_read_error.get();
  const auto *alert = old->reserved_alert_error.get();
  if (mode == 1) {
    SSL_set_shed_handshake_config(pair.client, 1);
    SSL_set_renegotiate_mode(pair.client, ssl_renegotiate_never);
    CHECK(ssl->config == nullptr);
  }
  if (mode != 0) ticket_fault_arm_ordinal(1);
  const int result = SSL_clear(pair.client);
  if (mode != 0) ticket_fault_disarm();
  CHECK(result == (mode == 0));
  if (mode == 1) {
    CHECK(ssl->s3 == old && old->reserved_read_error.get() == read &&
          old->reserved_alert_error.get() == alert);
    const TicketFaultStats current = ticket_fault_read();
    CHECK(current.live == 3 && current.actual_frees == 0 && current.attempts == 2);
    exchange(pair.client, pair.server);
    exchange(pair.server, pair.client);
  } else {
    expect_released(3);
    if (mode == 0) {
      CHECK(ssl->s3 != nullptr);
      require_pair(pair.client, false);
    } else CHECK(ssl->s3 == nullptr);
  }
  destroy_pair(&pair);
  expect_released(3);
  printf("PASS clear_case: mode=%u sizeof_s3=%zu tracked_raw_owners=2 watched_erased_s3=1\n",
         mode, sizeof(bssl::SSL3_STATE));
  ERR_clear_error();
}

int main(int argc, char **argv) {
  CHECK(argc == 4);
  ERR_clear_error();
  CHECK(SSL_reserve_error_state(nullptr) == 0);
  CHECK(ERR_GET_REASON(ERR_get_error()) == ERR_R_PASSED_NULL_PARAMETER);
  rollback_and_repeat(argv, 0);
  rollback_and_repeat(argv, 1);
  rollback_and_repeat(argv, 2);
  eligibility(argv);
  for (unsigned mode = 0; mode < 3; mode++) clear_case(argv, mode);
  puts("PASS public error reservation controls; raw error owners have no cleanse contract");
}
