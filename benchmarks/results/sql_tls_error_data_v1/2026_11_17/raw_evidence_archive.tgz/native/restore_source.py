#!/usr/bin/env python3
"""Restore the short-error-data candidate from exact original or error-snapshot source."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat


def main():
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-kind', choices=['baseline', 'error-snapshot'], default='baseline')
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    destination = args.destination.absolute()
    if destination.exists() or destination.is_symlink():
        raise ValueError('Choose an absent source destination')
    if destination.resolve().is_relative_to(source):
        raise ValueError('Source destination must not be inside its input')
    name = 'original_source_inventory.json' if args.source_kind == 'baseline' else 'baseline_inventory.json'
    inventory = json.loads((base / name).read_text())
    names = {e['path'] for e in inventory['entries']}
    actual = {p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file() or p.is_symlink()}
    if names != actual:
        raise ValueError('Input source file set differs')
    for entry in inventory['entries']:
        relative = PurePosixPath(entry['path'])
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('Unsafe source inventory path')
        path = source / entry['path']
        info = path.lstat()
        if entry['kind'] == 'symlink':
            if not path.is_symlink() or os.readlink(path) != entry['target']:
                raise ValueError('Input source symlink differs: ' + entry['path'])
        else:
            if not stat.S_ISREG(info.st_mode):
                raise ValueError('Input source type differs: ' + entry['path'])
            if stat.S_IMODE(info.st_mode) != entry['mode']:
                raise ValueError('Input source mode differs: ' + entry['path'])
            if hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
                raise ValueError('Input source checksum differs: ' + entry['path'])
    provenance = json.loads((base / 'provenance.json').read_text())
    candidate = json.loads((base / 'candidate_source_inventory.json').read_text())
    candidate_modes = {entry['path']: entry['mode'] for entry in candidate['entries']
                       if entry['kind'] == 'file'}
    payloads = []
    for relative, checksum in provenance['snapshot_sha256'].items():
        name = PurePosixPath(relative)
        if relative not in names or name.is_absolute() or '..' in name.parts:
            raise ValueError('Unsafe candidate source path')
        payload = (base / 'candidate_source' / relative).read_bytes()
        if hashlib.sha256(payload).hexdigest() != checksum:
            raise ValueError('Candidate source snapshot checksum differs: ' + relative)
        payloads.append((relative, payload))
    shutil.copytree(source, destination, symlinks=True)
    for relative, payload in payloads:
        target = destination / relative
        target.chmod(stat.S_IMODE(target.stat().st_mode) | stat.S_IWUSR)
        target.write_bytes(payload)
        target.chmod(candidate_modes[relative])
    print('Restored exact short-error-data candidate; ' + str(len(names)) + ' source entries verified.')


if __name__ == '__main__':
    main()
