// Test-only error data ownership witness; never linked into the library.
#include <openssl/err.h>
#include <openssl/mem.h>
#include <openssl/ssl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "crypto/err/internal.h"

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

#define REQUIRE(value) do { if (!(value)) { fprintf(stderr, "FAIL line%d: %s\n", __LINE__, #value); abort(); } } while (0)

struct Counts {
  uint64_t mallocs;
  uint64_t callocs;
  uint64_t reallocs;
  uint64_t frees;
  uint64_t bytes;
};

static bool all_short_zero = true;

static Counts end_count() {
  uwz_alloc_end();
  return {uwz_alloc_malloc_calls(), uwz_alloc_calloc_calls(),
          uwz_alloc_realloc_calls(), uwz_alloc_free_calls(), uwz_alloc_requested_bytes()};
}

static bool zero(const Counts &counts) {
  return counts.mallocs == 0 && counts.callocs == 0 && counts.reallocs == 0 &&
         counts.frees == 0 && counts.bytes == 0;
}

static void emit(const char *name, size_t length, const Counts &counts, bool gated) {
  printf("{\"case\":\"%s\",\"payload_chars\":%zu,\"malloc\":%llu,\"calloc\":%llu,\"realloc\":%llu,\"free\":%llu,\"bytes\":%llu,\"short_zero_gate\":%s}\n",
         name, length, static_cast<unsigned long long>(counts.mallocs),
         static_cast<unsigned long long>(counts.callocs),
         static_cast<unsigned long long>(counts.reallocs),
         static_cast<unsigned long long>(counts.frees),
         static_cast<unsigned long long>(counts.bytes), gated ? "true" : "false");
  if (gated && !zero(counts)) all_short_zero = false;
}

static void push() {
  ERR_put_error(ERR_LIB_SSL, 0, SSL_R_DECODE_ERROR, "synthetic_error_data.cc", 71);
}

static const char *check_data(const char *expected, bool pop) {
  const char *file = nullptr;
  const char *data = nullptr;
  int line = 0;
  int flags = -1;
  const uint32_t packed = pop ? ERR_get_error_line_data(&file, &line, &data, &flags)
                              : ERR_peek_error_line_data(&file, &line, &data, &flags);
  REQUIRE(packed == ERR_PACK(ERR_LIB_SSL, SSL_R_DECODE_ERROR));
  REQUIRE(strcmp(file, "synthetic_error_data.cc") == 0 && line == 71);
  REQUIRE(strcmp(data, expected ? expected : "") == 0);
  REQUIRE(flags == (expected ? ERR_FLAG_STRING | ERR_FLAG_MALLOCED : 0));
  return data;
}

static void reserved_data_case(const char *name, size_t length, bool absent) {
  char input[6001];
  REQUIRE(length < sizeof(input));
  memset(input, 'd', length);
  input[length] = 0;
  ERR_clear_error();
  bssl::UniquePtr<bssl::ERR_RESERVED_STATE> saved(bssl::ERR_RESERVED_STATE_new());
  REQUIRE(saved != nullptr);
  uwz_alloc_begin();
  push();
  if (!absent) ERR_set_error_data(input, ERR_FLAG_STRING);
  check_data(absent ? nullptr : input, false);
  bssl::ERR_save_reserved_state(saved.get());
  ERR_clear_error();
  bssl::ERR_restore_reserved_state(saved.get());
  check_data(absent ? nullptr : input, false);
  const char *popped = check_data(absent ? nullptr : input, true);
  const Counts counts = end_count();
  saved.reset();
  // No intervening queue operation: popped data must outlive its saved owner.
  REQUIRE(strcmp(popped, absent ? "" : input) == 0);
  REQUIRE(ERR_get_error() == 0);
  ERR_clear_error();
  emit(name, length, counts, absent || length <= 31);
  if (!absent && length >= 32) REQUIRE(counts.mallocs > 0 && counts.bytes > 0);
}

static void short_aliases() {
  ERR_clear_error();
  char input[32];
  memset(input, 'a', 31);
  input[31] = 0;
  push();
  ERR_set_error_data(input, ERR_FLAG_STRING);
  const char *data = check_data(input, false);
  uwz_alloc_begin();
  ERR_set_error_data(const_cast<char *>(data), ERR_FLAG_STRING);
  data = check_data(input, false);
  ERR_set_error_data(const_cast<char *>(data + 1), ERR_FLAG_STRING);
  check_data(input + 1, false);
  const Counts counts = end_count();
  ERR_clear_error();
  emit("short_whole_and_subspan_alias", 31, counts, true);
}

static void owned_input() {
  ERR_clear_error();
  push();
  char *owned = static_cast<char *>(OPENSSL_malloc(20));
  REQUIRE(owned != nullptr);
  memcpy(owned, "owned caller input", sizeof("owned caller input"));
  uwz_alloc_begin();
  ERR_set_error_data(owned, ERR_FLAG_STRING | ERR_FLAG_MALLOCED);
  check_data("owned caller input", false);
  const Counts counts = end_count();
  REQUIRE(counts.frees == 1 && counts.callocs == 0 && counts.reallocs == 0);
  ERR_clear_error();
  emit("input_openssl_malloced_consumed", 18, counts, false);
}

static void formatter_controls() {
  ERR_clear_error();
  push();
  uwz_alloc_begin();
  ERR_add_error_dataf("form %d", 7);
  check_data("form 7", false);
  const Counts formatted = end_count();
  REQUIRE(formatted.mallocs > 0);
  ERR_clear_error();
  emit("generic_printf_remains_allocating", 6, formatted, false);
  push();
  uwz_alloc_begin();
  ERR_add_error_data(3, "left", nullptr, "right");
  check_data("leftright", false);
  const Counts concatenated = end_count();
  REQUIRE(concatenated.mallocs > 0);
  ERR_clear_error();
  emit("generic_concat_remains_allocating", 9, concatenated, false);
}

static void generic_saved_copy() {
  ERR_clear_error();
  char input[32];
  memset(input, 'g', 31);
  input[31] = 0;
  push();
  ERR_set_error_data(input, ERR_FLAG_STRING);
  uwz_alloc_begin();
  bssl::UniquePtr<bssl::ERR_SAVE_STATE> saved(bssl::ERR_save_state());
  const Counts counts = end_count();
  REQUIRE(saved != nullptr && counts.mallocs >= 2);
  ERR_clear_error();
  bssl::ERR_restore_state(saved.get());
  const char *popped = check_data(input, true);
  saved.reset();
  REQUIRE(strcmp(popped, input) == 0);
  ERR_clear_error();
  emit("generic_snapshot_header_array_control", 31, counts, false);
}

static void full_queue_data() {
  ERR_clear_error();
  bssl::UniquePtr<bssl::ERR_RESERVED_STATE> saved(bssl::ERR_RESERVED_STATE_new());
  REQUIRE(saved != nullptr);
  uwz_alloc_begin();
  for (unsigned i = 1; i <= 20; i++) {
    ERR_put_error(ERR_LIB_SSL, 0, static_cast<int>(2000 + i), "synthetic_queue_wrap.cc", 100 + i);
    ERR_set_error_data(const_cast<char *>("short owned text"), ERR_FLAG_STRING);
  }
  REQUIRE(ERR_set_mark() == 1);
  bssl::ERR_save_reserved_state(saved.get());
  ERR_clear_error();
  bssl::ERR_restore_reserved_state(saved.get());
  for (unsigned i = 6; i <= 20; i++) {
    const char *file = nullptr;
    const char *data = nullptr;
    int line = 0;
    int flags = 0;
    REQUIRE(ERR_get_error_line_data(&file, &line, &data, &flags) == ERR_PACK(ERR_LIB_SSL, 2000 + i));
    REQUIRE(strcmp(file, "synthetic_queue_wrap.cc") == 0 && line == static_cast<int>(100 + i));
    REQUIRE(strcmp(data, "short owned text") == 0 && flags == (ERR_FLAG_STRING | ERR_FLAG_MALLOCED));
  }
  REQUIRE(ERR_get_error() == 0);
  bssl::ERR_restore_reserved_state(saved.get());
  REQUIRE(ERR_pop_to_mark() == 0 && ERR_get_error() == 0);
  bssl::ERR_save_reserved_state(saved.get());
  ERR_clear_error();
  const Counts counts = end_count();
  saved.reset();
  emit("full15_wrap_marks_shrink_empty", 16, counts, true);
}

int main(int argc, char **argv) {
  REQUIRE(argc == 2);
  const bool strict = strcmp(argv[1], "--require-short-zero") == 0;
  REQUIRE(strict || strcmp(argv[1], "--observe") == 0);
  REQUIRE(uwz_alloc_self_test() == 1);
  ERR_clear_error();
  reserved_data_case("absent_data", 0, true);
  reserved_data_case("empty_data", 0, false);
  reserved_data_case("inline_below", 30, false);
  reserved_data_case("inline_exact", 31, false);
  reserved_data_case("inline_spill", 32, false);
  reserved_data_case("long_spill", 6000, false);
  short_aliases();
  owned_input();
  formatter_controls();
  generic_saved_copy();
  full_queue_data();
  puts("PASS twelve bounded data ownership rows; absence/empty, alias, flags, popped lifetime, FIFO and generic allocating controls verified");
  return strict && !all_short_zero ? 1 : 0;
}
