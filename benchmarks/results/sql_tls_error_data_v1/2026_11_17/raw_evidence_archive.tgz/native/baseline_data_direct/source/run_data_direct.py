#!/usr/bin/env python3
"""Build and measure bounded ERR data ownership against supplied native libraries."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--candidate', action='store_true')
    parser.add_argument('--zig', default='/tmp/zig-x86_64-linux-0.16.0/zig')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    native = args.native_root.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    output.mkdir(mode=0o700)
    source = output / 'source'
    source.mkdir()
    for name in ['allocation_scope.c', 'error_data_direct.cc', 'run_data_direct.py']:
        shutil.copy2(base / name, source / name)
    if sha(source / 'allocation_scope.c') != 'afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac':
        raise ValueError('Original all-C counter differs')
    environment = dict(os.environ, ZIG_GLOBAL_CACHE_DIR=str(base / 'global-cache'))
    commands = []

    def run(command, stem, expected=0):
        with (output / (stem + '.stdout')).open('wb') as stdout, \
             (output / (stem + '.stderr')).open('wb') as stderr:
            result = subprocess.run(command, cwd=output, env=environment,
                                    stdout=stdout, stderr=stderr)
        commands.append({'command': command, 'exit_code': result.returncode,
                         'expected_exit_code': expected, 'stem': stem})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode != expected:
            raise RuntimeError('Command failed: ' + str(output / stem))

    crypto = native / 'native_out/lib/libcrypto.a'
    run([args.zig, 'cc', '-std=c11', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
         '-c', str(source / 'allocation_scope.c'), '-o', str(output / 'allocation_scope.o')], 'build-counter')
    run([args.zig, 'c++', '-std=c++17', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
         '-DBORINGSSL_IMPLEMENTATION', '-isystem', str(native / 'boringssl'),
         '-isystem', str(native / 'boringssl/include'), str(source / 'error_data_direct.cc'),
         str(output / 'allocation_scope.o'), str(crypto), '-o', str(output / 'error_data_direct')], 'build-direct')
    run([str(output / 'error_data_direct'), '--observe'], 'observe')
    run([str(output / 'error_data_direct'), '--require-short-zero'], 'require-short-zero', 0 if args.candidate else 1)
    if (output / 'observe.stdout').read_bytes() != (output / 'require-short-zero.stdout').read_bytes():
        raise ValueError('Observe and strict functional/count results differ')
    (output / 'results.json').write_text(json.dumps({'complete': True,
        'candidate': args.candidate, 'observe_exit': 0, 'strict_exit': 0 if args.candidate else 1,
        'functional_and_count_outputs_identical': True,
        'native_crypto_sha256': sha(crypto), 'binary_sha256': sha(output / 'error_data_direct'),
        'source_sha256': {p.name: sha(p) for p in source.iterdir()},
        'scope': 'twelve direct data ownership rows; short ERR_set/reserved copy storage gate only; generic formatting, generic saved header/array and owned-input free remain honest allocating controls'}, indent=2) + '\n')
    print((output / 'observe.stdout').read_text(), end='')


if __name__ == '__main__':
    main()
