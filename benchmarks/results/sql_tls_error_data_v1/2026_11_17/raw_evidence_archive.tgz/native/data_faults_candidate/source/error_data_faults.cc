#include <openssl/err.h>
#include <openssl/mem.h>
#include <openssl/ssl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "crypto/err/internal.h"
#include "data_fault.h"

#define REQUIRE(value) do { if (!(value)) { fprintf(stderr, "FAIL line%d: %s\n", __LINE__, #value); abort(); } } while (0)

static char long_text[6001];

static void push(unsigned reason, const char *data = nullptr) {
  ERR_put_error(ERR_LIB_SSL, 0, static_cast<int>(reason), "synthetic_data_fault.cc", 71);
  if (data) ERR_set_error_data(const_cast<char *>(data), ERR_FLAG_STRING);
}

static const char *check(unsigned reason, const char *expected, bool pop = false) {
  const char *file = nullptr;
  const char *data = nullptr;
  int line = 0;
  int flags = -1;
  const uint32_t value = pop ? ERR_get_error_line_data(&file, &line, &data, &flags)
                            : ERR_peek_error_line_data(&file, &line, &data, &flags);
  REQUIRE(value == ERR_PACK(ERR_LIB_SSL, reason));
  REQUIRE(strcmp(file, "synthetic_data_fault.cc") == 0 && line == 71);
  REQUIRE(strcmp(data, expected ? expected : "") == 0);
  REQUIRE(flags == (expected ? ERR_FLAG_STRING | ERR_FLAG_MALLOCED : 0));
  return data;
}

static DataFaultStats balanced() {
  const DataFaultStats stats = data_fault_read();
  REQUIRE(stats.live == 0 && stats.actual_frees == stats.successful + stats.watched);
  REQUIRE(stats.cleanse_failures == 0 && stats.calloc_calls == 0 && stats.realloc_calls == 0);
  return stats;
}

static void short_noalloc_under_persistent_fault() {
  ERR_clear_error();
  bssl::UniquePtr<bssl::ERR_RESERVED_STATE> saved(bssl::ERR_RESERVED_STATE_new());
  REQUIRE(saved != nullptr);
  data_fault_reset();
  data_fault_arm_persistent();
  push(2101, "1234567890123456789012345678901");
  bssl::ERR_save_reserved_state(saved.get());
  ERR_clear_error();
  bssl::ERR_restore_reserved_state(saved.get());
  check(2101, "1234567890123456789012345678901", true);
  ERR_clear_error();
  data_fault_disarm();
  const DataFaultStats stats = balanced();
  REQUIRE(stats.attempts == 0 && stats.injected == 0);
  puts("PASS short setter/capture/restore/pop under persistent raw-malloc failure: no attempt");
}

static void alias_and_old_heap_history() {
  ERR_clear_error();
  push(2201, long_text);
  REQUIRE(ERR_set_mark() == 1);
  const char *old = check(2201, long_text);
  data_fault_reset();
  data_fault_watch_raw(const_cast<char *>(old), sizeof(long_text));
  data_fault_arm_persistent();
  ERR_set_error_data(const_cast<char *>(old), ERR_FLAG_STRING);
  data_fault_disarm();
  REQUIRE(data_fault_read().injected == 1 && data_fault_read().live == 1);
  REQUIRE(check(2201, long_text) == old);
  data_fault_arm_ordinal(0);
  ERR_set_error_data(const_cast<char *>(old), ERR_FLAG_STRING);
  data_fault_disarm();
  const char *replacement = check(2201, long_text);
  REQUIRE(replacement != old);
  char suffix32[33];
  memcpy(suffix32, replacement + strlen(replacement) - 32, sizeof(suffix32));
  data_fault_arm_ordinal(0);
  ERR_set_error_data(const_cast<char *>(replacement + strlen(replacement) - 32), ERR_FLAG_STRING);
  data_fault_disarm();
  replacement = check(2201, suffix32);
  const char *short_suffix = replacement + 1;
  char expected[32];
  memcpy(expected, short_suffix, sizeof(expected));
  data_fault_arm_persistent();
  ERR_set_error_data(const_cast<char *>(short_suffix), ERR_FLAG_STRING);
  data_fault_disarm();
  check(2201, expected);
  REQUIRE(data_fault_read().attempts == 3 && data_fault_read().injected == 1);
  push(2202, "newer inline entry");
  REQUIRE(ERR_pop_to_mark() == 1);
  check(2201, expected);
  ERR_clear_error();
  const DataFaultStats stats = balanced();
  REQUIRE(stats.successful == 2 && stats.watched == 1 && stats.actual_frees == 3);
  puts("PASS nonuniform whole long alias/OOM then32/31-byte suffixes; old heap freed legitimately, metadata/mark preserved");
}

static void peeks_and_pop_without_data() {
  ERR_clear_error();
  data_fault_reset();
  data_fault_arm_persistent();
  push(2251, "popped inline");
  push(2252, "x");
  push(2253, "last inline");
  const char *popped = check(2251, "popped inline", true);
  check(2252, "x");
  const char *file = nullptr;
  const char *data = nullptr;
  int line = 0;
  int flags = 0;
  REQUIRE(ERR_peek_last_error_line_data(&file, &line, &data, &flags) == ERR_PACK(ERR_LIB_SSL, 2253));
  REQUIRE(strcmp(file, "synthetic_data_fault.cc") == 0 && line == 71);
  REQUIRE(strcmp(data, "last inline") == 0 && flags == (ERR_FLAG_STRING | ERR_FLAG_MALLOCED));
  REQUIRE(strcmp(popped, "popped inline") == 0);
  REQUIRE(ERR_get_error_line(&file, &line) == ERR_PACK(ERR_LIB_SSL, 2252));
  REQUIRE(strcmp(file, "synthetic_data_fault.cc") == 0 && line == 71);
  REQUIRE(ERR_get_error() == ERR_PACK(ERR_LIB_SSL, 2253));
  REQUIRE(ERR_get_error() == 0);
  ERR_remove_thread_state(nullptr);
  data_fault_disarm();
  REQUIRE(balanced().attempts == 0);
  puts("PASS length1, first/last peeks preserve popped pointer, pop-without-data and remove-thread-state avoid inline free");
}

static void marked_setter() {
  ERR_clear_error();
  push(2301, "marked data");
  REQUIRE(ERR_set_mark() == 1);
  const char *old = check(2301, "marked data");
  ERR_set_error_data(const_cast<char *>(old + 1), ERR_FLAG_STRING);
  push(2302, "newer");
  REQUIRE(ERR_pop_to_mark() == 1);
  check(2301, "arked data");
  REQUIRE(ERR_pop_to_mark() == 0 && ERR_get_error() == 0);
  puts("PASS data-only alias setter preserves metadata and mark; pop clears mark exactly once");
}

static void openssl_input(bool long_input, bool fail_copy) {
  ERR_clear_error();
  push(2401, "old text survives");
  const size_t size = long_input ? sizeof(long_text) : sizeof("owned short");
  char *input = static_cast<char *>(OPENSSL_malloc(size));
  REQUIRE(input != nullptr);
  memcpy(input, long_input ? long_text : "owned short", size);
  data_fault_reset();
  data_fault_watch(input, size);
  if (fail_copy) data_fault_arm_persistent(); else data_fault_arm_ordinal(0);
  ERR_set_error_data(input, ERR_FLAG_STRING | ERR_FLAG_MALLOCED);
  data_fault_disarm();
  check(2401, fail_copy ? "old text survives" : long_input ? long_text : "owned short");
  ERR_clear_error();
  const DataFaultStats stats = balanced();
  REQUIRE(stats.watched == 1 && stats.actual_frees == (long_input && !fail_copy ? 2 : 1));
  REQUIRE(stats.injected == (fail_copy ? 1 : 0));
  printf("PASS OpenSSL input consumption: long=%u copy_fail=%u watched_freed_once=1 prefix_and_payload_erased=1\n",
         static_cast<unsigned>(long_input), static_cast<unsigned>(fail_copy));
}

static void mixed_source() {
  push(2501, "inline source");
  push(2502, long_text);
  push(2503, long_text);
}

static void mixed_queue(unsigned omitted) {
  check(2501, "inline source", true);
  check(2502, omitted == 1 || omitted == 3 ? nullptr : long_text, true);
  check(2503, omitted == 2 || omitted == 3 ? nullptr : long_text, true);
  REQUIRE(ERR_get_error() == 0);
}

static void persistent_reserved_oom(bool restoration) {
  ERR_clear_error();
  bssl::UniquePtr<bssl::ERR_RESERVED_STATE> saved(bssl::ERR_RESERVED_STATE_new());
  REQUIRE(saved != nullptr);
  mixed_source();
  if (restoration) {
    bssl::ERR_save_reserved_state(saved.get());
    ERR_clear_error();
  }
  data_fault_reset();
  data_fault_arm_persistent();
  if (restoration) bssl::ERR_restore_reserved_state(saved.get());
  else bssl::ERR_save_reserved_state(saved.get());
  data_fault_disarm();
  REQUIRE(data_fault_read().attempts == 2 && data_fault_read().injected == 2);
  if (!restoration) {
    mixed_queue(0);
    ERR_clear_error();
    bssl::ERR_restore_reserved_state(saved.get());
  }
  mixed_queue(3);
  ERR_clear_error();
  saved.reset();
  REQUIRE(balanced().successful == 0);
  printf("PASS persistent reserved%s spill OOM: both long texts omitted, short data and all metadata intact\n",
         restoration ? " restore" : " capture");
}

static void reserved_copy_oom(bool restoration, unsigned omitted) {
  ERR_clear_error();
  bssl::UniquePtr<bssl::ERR_RESERVED_STATE> saved(bssl::ERR_RESERVED_STATE_new());
  REQUIRE(saved != nullptr);
  mixed_source();
  if (restoration) {
    bssl::ERR_save_reserved_state(saved.get());
    ERR_clear_error();
  }
  data_fault_reset();
  data_fault_arm_ordinal(omitted);
  if (restoration) bssl::ERR_restore_reserved_state(saved.get());
  else bssl::ERR_save_reserved_state(saved.get());
  data_fault_disarm();
  REQUIRE(data_fault_read().attempts == 2 && data_fault_read().injected == 1);
  if (!restoration) {
    // Capture never changes the source queue, including its complete long text.
    mixed_queue(0);
    ERR_clear_error();
    bssl::ERR_restore_reserved_state(saved.get());
  }
  mixed_queue(omitted);
  ERR_clear_error();
  saved.reset();
  REQUIRE(balanced().successful == 1);
  printf("PASS reserved%s spill OOM: failed_long_entry=%u, all metadata intact, optional text omitted only there\n",
         restoration ? " restore" : " capture", omitted);
}

static void generic_copy_oom(unsigned ordinal) {
  ERR_clear_error();
  mixed_source();
  data_fault_reset();
  data_fault_arm_ordinal(ordinal);
  bssl::UniquePtr<bssl::ERR_SAVE_STATE> saved(bssl::ERR_save_state());
  data_fault_disarm();
  REQUIRE(data_fault_read().injected == 1);
  if (ordinal <= 2) {
    REQUIRE(saved == nullptr);
    mixed_queue(0);
  } else {
    REQUIRE(saved != nullptr);
    mixed_queue(0);
    ERR_clear_error();
    bssl::ERR_restore_state(saved.get());
    mixed_queue(ordinal - 2);
  }
  ERR_clear_error();
  saved.reset();
  balanced();
  printf("PASS generic snapshot OOM: ordinal=%u; header/array failure null, spill failure retains full metadata\n", ordinal);
}

static void shrink_mixed_snapshot() {
  ERR_clear_error();
  bssl::UniquePtr<bssl::ERR_RESERVED_STATE> saved(bssl::ERR_RESERVED_STATE_new());
  REQUIRE(saved != nullptr);
  for (unsigned i = 0; i < 15; i++) push(2600 + i, i < 2 ? long_text : "inline source");
  data_fault_reset();
  data_fault_arm_ordinal(0);
  bssl::ERR_save_reserved_state(saved.get());
  data_fault_disarm();
  REQUIRE(data_fault_read().successful == 2 && data_fault_read().live == 2);
  ERR_clear_error();
  push(2650, "one short");
  bssl::ERR_save_reserved_state(saved.get());
  REQUIRE(data_fault_read().live == 0 && data_fault_read().actual_frees == 2);
  ERR_clear_error();
  bssl::ERR_save_reserved_state(saved.get());
  saved.reset();
  balanced();
  puts("PASS mixed15->1->0 capture releases both trailing long owners exactly once");
}

struct ThreadCase {
  unsigned kind;
  DataFaultStats final;
};

static void *thread_data(void *opaque) {
  auto *test = static_cast<ThreadCase *>(opaque);
  ERR_clear_error();
  data_fault_reset();
  data_fault_arm_ordinal(0);
  if (test->kind == 0) {
    push(2701, "thread short");
    check(2701, "thread short", true);
  } else if (test->kind == 1) {
    push(2701, long_text);
    push(2702, long_text);
    check(2701, long_text, true);
  } else {
    push(2701);
    ERR_add_error_dataf("form %d", 7);
    const char *before = check(2701, "form 7");
    REQUIRE(check(2701, "form 7", true) == before);
  }
  data_fault_disarm();
  const DataFaultStats before = data_fault_read();
  REQUIRE(before.live == (test->kind == 0 ? 0 : test->kind == 1 ? 2 : 1));
  data_fault_publish_to(&test->final);
  // Native thread-local destruction must clear queued and popped ownership.
  return nullptr;
}

static void thread_destruction() {
  for (unsigned kind = 0; kind < 3; kind++) {
    ThreadCase test = {kind, {}};
    pthread_t thread;
    REQUIRE(pthread_create(&thread, nullptr, thread_data, &test) == 0);
    REQUIRE(pthread_join(thread, nullptr) == 0);
    REQUIRE(test.final.live == 0 && test.final.actual_frees == test.final.successful);
    REQUIRE(test.final.cleanse_failures == 0 && test.final.calloc_calls == 0 && test.final.realloc_calls == 0);
    printf("PASS native thread destructor: kind=%u successful=%llu freed=%llu live=0\n", kind,
           static_cast<unsigned long long>(test.final.successful),
           static_cast<unsigned long long>(test.final.actual_frees));
  }
}

int main() {
  for (size_t i = 0; i < sizeof(long_text) - 1; i++) long_text[i] = 'a' + (i * 7 + 3) % 26;
  long_text[sizeof(long_text) - 1] = 0;
  ERR_clear_error();
  short_noalloc_under_persistent_fault();
  alias_and_old_heap_history();
  peeks_and_pop_without_data();
  marked_setter();
  openssl_input(false, false);
  openssl_input(true, false);
  openssl_input(true, true);
  for (unsigned omitted = 1; omitted <= 2; omitted++) {
    reserved_copy_oom(false, omitted);
    reserved_copy_oom(true, omitted);
  }
  for (unsigned ordinal = 1; ordinal <= 4; ordinal++) generic_copy_oom(ordinal);
  persistent_reserved_oom(false);
  persistent_reserved_oom(true);
  shrink_mixed_snapshot();
  thread_destruction();
  ERR_clear_error();
  puts("PASS twenty-one ownership/alias/OOM/destructor rows; short inline and full raw spill paths remain distinct");
}
