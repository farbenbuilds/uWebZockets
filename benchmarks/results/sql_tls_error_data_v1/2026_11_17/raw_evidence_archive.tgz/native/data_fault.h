#ifndef UWZ_DATA_FAULT_H
#define UWZ_DATA_FAULT_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

struct DataFaultStats {
    uint64_t attempts;
    uint64_t matches;
    uint64_t successful;
    uint64_t injected;
    uint64_t watched;
    uint64_t live;
    uint64_t actual_frees;
    uint64_t cleanse_failures;
    uint64_t unwatched_nonzero_frees;
    uint64_t calloc_calls;
    uint64_t realloc_calls;
    uint64_t requested_bytes;
    size_t first_uncleansed_size;
    uintptr_t first_uncleansed_site;
};

void data_fault_reset(void);
void data_fault_arm_ordinal(size_t ordinal);
void data_fault_arm_size(size_t size);
void data_fault_disarm(void);
void data_fault_arm_persistent(void);
void data_fault_watch_raw(void *pointer, size_t size);
void data_fault_publish_to(struct DataFaultStats *destination);
void data_fault_watch(void *openssl_pointer, size_t payload_size);
struct DataFaultStats data_fault_read(void);

#ifdef __cplusplus
}
#endif
#endif
