#!/usr/bin/env python3
"""Check retained replay input refusals without changing producer files."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pki-tool', type=Path, required=True)
    parser.add_argument('--existing-output', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    output = args.output.absolute()
    if output.exists() or output.is_symlink() or output.resolve().is_relative_to(base):
        raise ValueError('Choose an absent external guard directory')
    output.mkdir(mode=0o700)
    tool = args.pki_tool.resolve(strict=True)
    rows = []

    def refusal(name, script, supplied_tool, destination, message, existing=False):
        command = [sys.executable, str(script), '--pki-tool', str(supplied_tool),
                   '--output', str(destination)]
        with (output / (name + '.stdout')).open('wb') as stdout, \
             (output / (name + '.stderr')).open('wb') as stderr:
            result = subprocess.run(command, stdout=stdout, stderr=stderr)
        if result.returncode != 1 or message not in (output / (name + '.stderr')).read_text():
            raise RuntimeError('Guard failed: ' + name)
        if not existing and destination.exists():
            raise RuntimeError('Guard created refused output: ' + name)
        rows.append({'case': name, 'command': command, 'exit_code': result.returncode,
                     'expected_message': message, 'no_new_output_created': True})

    script = base / 'replay_prebuilt.py'
    refusal('existing_output', script, tool, args.existing_output.resolve(strict=True),
            'Choose an absent replay output directory', True)
    refusal('inside_producer', script, tool, base / 'refused_replay_inside_producer',
            'Keep replay output outside the retained evidence tree')
    refusal('wrong_tool', script, base / 'error_data_direct.cc', output / 'wrong_tool_output',
            'PKI helper checksum differs')
    identity = json.loads((base / 'prebuilt_identity.json').read_text())
    invalid = output / 'invalid_inventory'
    invalid.mkdir()
    shutil.copy2(script, invalid / script.name)
    changed = json.loads(json.dumps(identity))
    changed['binaries'].pop(next(iter(changed['binaries'])))
    (invalid / 'prebuilt_identity.json').write_text(json.dumps(changed))
    refusal('binary_inventory', invalid / script.name, tool, output / 'inventory_output',
            'Unexpected retained binary inventory')
    corrupt = output / 'corrupt_binary'
    corrupt.mkdir()
    shutil.copy2(script, corrupt / script.name)
    (corrupt / 'prebuilt_identity.json').write_text(json.dumps(identity))
    first = next(iter(identity['binaries']))
    target = corrupt / first
    target.parent.mkdir(parents=True)
    shutil.copy2(base / first, target)
    with target.open('r+b') as stream:
        stream.seek(-1, 2)
        byte = stream.read(1)
        stream.seek(-1, 2)
        stream.write(bytes([byte[0] ^ 1]))
    refusal('binary_checksum', corrupt / script.name, tool, output / 'checksum_output',
            'Retained binary checksum differs: ' + first)
    (output / 'results.json').write_text(json.dumps({'complete': True, 'cases': rows,
        'producer_files_modified': False}, indent=2) + '\n')
    print('PASS five replay input guards; producer unchanged')


if __name__ == '__main__':
    main()
