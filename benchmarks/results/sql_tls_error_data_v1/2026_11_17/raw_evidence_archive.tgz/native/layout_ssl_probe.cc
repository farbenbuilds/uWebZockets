#include <ssl/internal.h>
static_assert(sizeof(bssl::SSL3_STATE) == 656, "unchanged x86_64 SSL connection state");
