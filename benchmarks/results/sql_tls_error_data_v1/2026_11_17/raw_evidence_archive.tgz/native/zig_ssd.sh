#!/bin/sh
export ZIG_GLOBAL_CACHE_DIR="/home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-error-data-fixed-20261117/global-cache"
exec /tmp/zig-x86_64-linux-0.16.0/zig "$@"
