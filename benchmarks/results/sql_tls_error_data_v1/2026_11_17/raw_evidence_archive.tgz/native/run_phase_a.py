#!/usr/bin/env python3
"""Rebuild the prior Phase A programs with documented private-layout arithmetic updates."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('pki_tool', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    native = args.native_root.resolve(strict=True)
    tool = args.pki_tool.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    source = base / 'inherited_phase_a'
    lineage = json.loads((source / 'input_lineage.json').read_text())
    for entry in lineage['entries']:
        if sha(source / entry['path']) != entry['current_sha256']:
            raise ValueError('Adapted input differs: ' + entry['path'])
        if sha(source / 'original_inputs' / entry['path']) != entry['original_sha256']:
            raise ValueError('Original input differs: ' + entry['path'])
    output.mkdir(mode=0o700)
    todo = [
        ('run_direct.py', [str(native), str(source / 'direct_generic')]),
        ('run_direct.py', [str(native), str(source / 'direct_reserved'), '--candidate']),
        ('run_oom.py', [str(native), str(source / 'oom_generic')]),
        ('run_oom.py', [str(native), str(source / 'oom_reserved'), '--candidate']),
        ('run_lifecycle.py', [str(native), str(tool), str(source / 'lifecycle')]),
        ('run_nested.py', [str(native), str(tool), str(source / 'nested_generic')]),
        ('run_nested.py', [str(native), str(tool), str(source / 'nested_reserved'), '--candidate']),
        ('run_factory_oom.py', [str(native), str(source / 'factory'), '--candidate']),
    ]
    commands = []
    for index, (name, arguments) in enumerate(todo):
        command = [sys.executable, str(source / name), *arguments]
        with (output / (str(index) + '.stdout')).open('wb') as stdout, \
             (output / (str(index) + '.stderr')).open('wb') as stderr:
            result = subprocess.run(command, stdout=stdout, stderr=stderr)
        commands.append({'command': command, 'exit_code': result.returncode})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode:
            raise RuntimeError('Phase A inherited command failed: ' + name)
    (output / 'results.json').write_text(json.dumps({'complete': True,
        'profile_scope': 'generic and reserved profiles against current matching candidate libraries; prior immutable library is independently measured by baseline_data_direct',
        'commands': commands, 'changed_source_files': 3,
        'changes_only_verified_private_layout_arithmetic': True,
        'native_archives_sha256': {p.name: sha(p) for p in (native / 'native_out/lib').glob('*.a')}
    }, indent=2) + '\n')
    print('PASS eight prior Phase A profiles/programs; exact documented layout updates only')


if __name__ == '__main__':
    main()
