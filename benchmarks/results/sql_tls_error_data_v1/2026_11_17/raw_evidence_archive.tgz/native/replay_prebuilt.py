#!/usr/bin/env python3
"""Replay retained short error data ownership and inherited helpers without a compiler."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pki-tool', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    evidence_root = base
    if ((base.parent / 'restore_pki_tool.py').is_file() and
            (base.parent / 'native/HANDOFF.md').is_file()):
        evidence_root = base.parent
    tool = args.pki_tool.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent replay output directory')
    if output.resolve().is_relative_to(evidence_root):
        raise ValueError('Keep replay output outside the retained evidence tree')
    if sha(tool) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('PKI helper checksum differs')
    identity = json.loads((base / 'prebuilt_identity.json').read_text())
    expected_binaries = {'inherited_phase_a/lifecycle/error_snapshot_lifecycle', 'regressions/output/direct/output_failures', 'inherited_phase_a/factory/error_factory_oom', 'regressions/aead/lifecycle/aead_transitions', 'inherited_phase_a/nested_generic/error_snapshot_nested', 'regressions/inherited_record/lifecycle_test', 'regressions/hs/helper/hs_buffer_helper', 'regressions/inherited_record/buffer_test', 'regressions/aead/lifecycle/aead_lifecycle', 'baseline_data_direct/error_data_direct', 'inherited_phase_a/oom_reserved/error_snapshot_oom', 'regressions/output/direct/output_direct', 'candidate_data_direct/error_data_direct', 'regressions/aead/direct/aead_init_failures', 'inherited_phase_a/nested_reserved/error_snapshot_nested', 'regressions/inherited_record/tls_pair_test', 'data_faults_candidate/error_data_faults', 'inherited_phase_a/oom_generic/error_snapshot_oom', 'regressions/aead/direct/aead_direct', 'regressions/output/lifecycle/output_lifecycle', 'inherited_phase_a/direct_generic/error_snapshot_direct', 'regressions/hs/lifecycle/hs_lifecycle', 'regressions/inherited_hkdf/results/hkdf_witness', 'inherited_phase_a/direct_reserved/error_snapshot_direct'}
    if set(identity['binaries']) != expected_binaries:
        raise ValueError('Unexpected retained binary inventory')
    for name, checksum in identity['binaries'].items():
        if sha(base / name) != checksum:
            raise ValueError('Retained binary checksum differs: ' + name)
    output.mkdir(mode=0o700, parents=True)
    commands = []
    complete = False

    def run(command, stem, expected=0):
        with (output / (stem + '.stdout')).open('wb') as stdout, \
             (output / (stem + '.stderr')).open('wb') as stderr:
            result = subprocess.run(command, cwd=output, stdout=stdout, stderr=stderr)
        commands.append({'command': command, 'exit_code': result.returncode, 'expected_exit_code': expected, 'stem': stem})
        if result.returncode != expected:
            raise RuntimeError('Command failed: ' + stem)

    def same_stdout(stem, retained):
        if (output / (stem + '.stdout')).read_bytes() != (base / retained).read_bytes():
            raise ValueError('Replay output differs: ' + stem)

    def cases(binary, retained, prefix, count, fixture):
        data = json.loads((base / retained).read_text())
        if not data['complete'] or len(data['rows']) != count:
            raise ValueError('Retained case inventory differs: ' + prefix)
        for row in data['rows']:
            name = row['case']
            stem = prefix + '_' + name
            run([str(base / binary), *fixture, name], stem)
            if json.loads((output / (stem + '.stdout')).read_text()) != row['result']:
                raise ValueError('Lifecycle outcome differs: ' + stem)

    pki = output / 'private_pki'
    try:
        run([str(tool), 'pki', str(pki)], 'pki_metadata')
        fixture = [str(pki / name) for name in ['server.pem', 'server.key', 'ca.pem']]
        for variant in ['baseline', 'candidate']:
            direct = variant + '_data_direct'
            binary = str(base / direct / 'error_data_direct')
            run([binary, '--observe'], variant + '_data_observe')
            same_stdout(variant + '_data_observe', direct + '/observe.stdout')
            run([binary, '--require-short-zero'], variant + '_data_strict', 1 if variant == 'baseline' else 0)
            same_stdout(variant + '_data_strict', direct + '/require-short-zero.stdout')
        run([str(base / 'data_faults_candidate/error_data_faults')], 'data_ownership_faults')
        same_stdout('data_ownership_faults', 'data_faults_candidate/faults.stdout')
        for profile in ['generic', 'reserved']:
            direct = 'inherited_phase_a/direct_' + profile
            run([str(base / direct / 'error_snapshot_direct')], profile + '_direct')
            same_stdout(profile + '_direct', direct + '/direct.stdout')
            oom = 'inherited_phase_a/oom_' + profile
            run([str(base / oom / 'error_snapshot_oom')], profile + '_oom')
            same_stdout(profile + '_oom', oom + '/oom.stdout')
            nested = 'inherited_phase_a/nested_' + profile
            run([str(base / nested / 'error_snapshot_nested'), *fixture], profile + '_nested')
            same_stdout(profile + '_nested', nested + '/clear.stdout')
        run([str(base / 'inherited_phase_a/factory/error_factory_oom')], 'factory_cold_oom')
        same_stdout('factory_cold_oom', 'inherited_phase_a/factory/oom.stdout')
        run([str(base / 'inherited_phase_a/lifecycle/error_snapshot_lifecycle'), *fixture], 'error_lifecycle')
        same_stdout('error_lifecycle', 'inherited_phase_a/lifecycle/clear.stdout')
        run([str(base / 'regressions/output/direct/output_direct'), *fixture], 'output_direct')
        same_stdout('output_direct', 'regressions/output/direct/direct.stdout')
        run([str(base / 'regressions/output/direct/output_failures'), *fixture], 'output_failures')
        same_stdout('output_failures', 'regressions/output/direct/failures.stdout')
        cases('regressions/output/lifecycle/output_lifecycle', 'regressions/output/lifecycle/results.json', 'output', 23, fixture)
        run([str(base / 'regressions/aead/direct/aead_direct')], 'aead_direct')
        same_stdout('aead_direct', 'regressions/aead/direct/direct.stdout')
        run([str(base / 'regressions/aead/direct/aead_init_failures')], 'aead_init_failures')
        same_stdout('aead_init_failures', 'regressions/aead/direct/init-failures.stdout')
        run([str(base / 'regressions/aead/lifecycle/aead_transitions'), *fixture], 'aead_transitions')
        same_stdout('aead_transitions', 'regressions/aead/lifecycle/transitions.stdout')
        cases('regressions/aead/lifecycle/aead_lifecycle', 'regressions/aead/lifecycle/results.json',
            'aead', 22, fixture)
        run([str(base / 'regressions/hs/helper/hs_buffer_helper'), *fixture, '--require-zero'],
            'hs_helper')
        same_stdout('hs_helper', 'regressions/hs/helper/require-zero.stdout')
        cases('regressions/hs/lifecycle/hs_lifecycle', 'regressions/hs/lifecycle/results.json',
            'hs', 21, fixture)
        run([sys.executable, str(base / 'regressions/inherited_record/run_cases.py'),
            '--pki', str(pki), '--output', str(output / 'record_cases')], 'record_lifecycle')
        actual = json.loads((output / 'record_cases/results.json').read_text())
        expected = json.loads((base / 'regressions/inherited_record/results/results.json').read_text())
        if [row['result'] for row in actual['rows']] != [row['result'] for row in expected['rows']]:
            raise ValueError('Inherited record lifecycle outcomes differ')
        run([str(base / 'regressions/inherited_record/buffer_test')], 'buffer_test')
        run([str(base / 'regressions/inherited_record/tls_pair_test'), *fixture], 'tls_pair_test')
        run([str(base / 'regressions/inherited_hkdf/results/hkdf_witness'), '--require-zero'], 'hkdf')
        run([sys.executable, str(base / 'regressions/inherited_hkdf/compare_results.py'),
             str(base / 'regressions/inherited_hkdf/prior_baseline.stdout'),
             str(output / 'hkdf.stdout')], 'hkdf_differential')
        complete = True
    finally:
        if pki.exists():
            names = {p.name for p in pki.iterdir()}
            if names - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected private fixture output; refusing broad cleanup')
            for name in names:
                (pki / name).unlink()
            pki.rmdir()
        (output / 'results.json').write_text(json.dumps({'complete': complete,
            'commands': commands, 'private_pki_removed': not pki.exists(),
            'native_source_archives_or_compiler_required': False,
            'retained_evidence_directory_modified': False,
            'strict_postgresql_gate_closed': False}, indent=2) + '\n')
    print('PASS: short data ownership/alias/OOM/destructors and inherited error/output/AEAD/HS/record/HKDF; private PKI removed')


if __name__ == '__main__':
    main()
