const std = @import("std");
const boringssl = @import("builds/vendor/boringssl.zig");
const lsquic = @import("builds/vendor/lsquic.zig");
const sanitizers = @import("builds/sanitizers.zig");
const zlib = @import("builds/vendor/zlib.zig");

const ordinary_tests = [_][]const u8{
    "ack",
    "ackgen_gquic_be",
    "ackparse_gquic_be",
    "ackparse_ietf",
    "alarmset",
    "alt_svc_ver",
    "arr",
    "attq",
    "blocked_gquic_be",
    "bw_sampler",
    "cert_chain",
    "conn_close_gquic_be",
    "conn_close_ietf",
    "crypto_gen",
    "cubic",
    "dec",
    "di_nocopy",
    "elision",
    "engine_ctor",
    "export_key",
    "frame_chop",
    "frame_reader",
    "frame_writer",
    "goaway_gquic_be",
    "hkdf",
    "hpi",
    "http_prio_header",
    "http1x_if",
    "lsquic_hash",
    "mini_conn_delay",
    "packet_out",
    "packet_resize",
    "packno_len",
    "parse_packet_in",
    "purga",
    "push_disabled",
    "qenc_hdl",
    "qlog",
    "quic_be_floats",
    "reg_pkt_headergen",
    "rst_stream_gquic_be",
    "rtt",
    "send_headers",
    "send_ctl_accounting",
    "send_ctl_bw_lifecycle",
    "senhist",
    "sess_resume",
    "set",
    "sfcw",
    "shi",
    "spi",
    "stop_waiting_gquic_be",
    "stk",
    "streamgen",
    "streamparse",
    "tokgen",
    "trapa",
    "varint",
    "ver_nego",
    "wuf_gquic_be",
    "frame_rw",
    "bounds_helpers",
    "ack_merge",
    "hcsi_reader",
};

const Special = struct {
    name: []const u8,
    source: []const u8,
    extra: []const u8,
    flags: []const []const u8 = &.{},
};

const special_tests = [_]Special{
    .{ .name = "min_heap", .source = "min_heap", .extra = "lsquic_min_heap.c" },
    .{ .name = "malo_pooled", .source = "malo", .extra = "lsquic_malo.c", .flags = &.{"-DLSQUIC_USE_POOLS=1"} },
    .{ .name = "malo_nopool", .source = "malo", .extra = "lsquic_malo.c", .flags = &.{"-DLSQUIC_USE_POOLS=0"} },
    .{ .name = "minmax", .source = "minmax", .extra = "lsquic_minmax.c" },
    .{ .name = "rechist", .source = "rechist", .extra = "lsquic_rechist.c" },
    .{ .name = "trechist", .source = "trechist", .extra = "lsquic_trechist.c" },
};

pub fn configure(
    b: *std.Build,
    target: std.Build.ResolvedTarget,
    optimize: std.builtin.OptimizeMode,
    sanitizer: sanitizers.Config,
    ls: lsquic.Artifacts,
    bssl: boringssl.Artifacts,
    z: zlib.Artifacts,
) void {
    if (target.result.os.tag != .linux or optimize != .Debug)
        @panic("this native upstream test manifest records Linux Debug cases");
    const all = b.step("test", "Run every existing upstream Linux Debug assertion case");
    var prior: ?*std.Build.Step = null;
    for (ordinary_tests) |name| {
        const exe = compile_case(b, target, optimize, sanitizer, ls, bssl, z, name, name, null, &.{});
        append_case(b, all, &prior, exe, sanitizer, ls, name, &.{});
    }
    const stream = compile_case(b, target, optimize, sanitizer, ls, bssl, z, "stream", "stream", null, &.{});
    append_case(b, all, &prior, stream, sanitizer, ls, "stream", &.{});
    append_case(b, all, &prior, stream, sanitizer, ls, "stream_hash", &.{"-h"});
    append_case(b, all, &prior, stream, sanitizer, ls, "stream_A", &.{"-A"});
    append_case(b, all, &prior, stream, sanitizer, ls, "stream_hash_A", &.{ "-A", "-h" });
    const h3 = compile_case(b, target, optimize, sanitizer, ls, bssl, z, "h3_framing", "h3_framing", null, &.{});
    for (0..6) |index| {
        append_case(b, all, &prior, h3, sanitizer, ls, b.fmt("h3_framing_pwritev_combo{d}", .{index}), &.{ "-s", b.fmt("{d}", .{index}) });
    }
    append_case(b, all, &prior, h3, sanitizer, ls, "h3_framing_hq", &.{ "-s", "10" });
    append_case(b, all, &prior, h3, sanitizer, ls, "h3_framing_header_split", &.{ "-s", "11" });
    append_case(b, all, &prior, h3, sanitizer, ls, "h3_framing_zero_size", &.{ "-s", "12" });
    for (special_tests) |special| {
        const exe = compile_case(b, target, optimize, sanitizer, ls, bssl, z, special.name, special.source, special.extra, special.flags);
        append_case(b, all, &prior, exe, sanitizer, ls, special.name, &.{});
    }
}

fn compile_case(
    b: *std.Build,
    target: std.Build.ResolvedTarget,
    optimize: std.builtin.OptimizeMode,
    sanitizer: sanitizers.Config,
    ls: lsquic.Artifacts,
    bssl: boringssl.Artifacts,
    z: zlib.Artifacts,
    name: []const u8,
    source: []const u8,
    extra: ?[]const u8,
    extra_flags: []const []const u8,
) *std.Build.Step.Compile {
    var flags: std.ArrayList([]const u8) = .empty;
    flags.appendSlice(b.allocator, sanitizers.instrumented_flags(b, &.{
        "-std=gnu11",                            "-UNDEBUG",         "-DLSQUIC_TEST=1",   "-DLSQUIC_CONN_STATS=1",
        "-DLSQUIC_DEBUG_NEXT_ADV_TICK=1",        "-DHAVE_BORINGSSL", "-Wno-unused-value", "-Wno-initializer-overrides",
        "-DXXH_HEADER_NAME=\"lsquic_xxhash.h\"",
    }, sanitizer)) catch @panic("out of memory");
    flags.appendSlice(b.allocator, extra_flags) catch @panic("out of memory");
    const module = b.createModule(.{ .target = target, .optimize = optimize, .link_libc = true });
    module.addIncludePath(ls.include_root);
    module.addIncludePath(ls.assembled_root.path(b, "src/liblsquic"));
    module.addIncludePath(ls.assembled_root.path(b, "src/liblsquic/ls-qpack"));
    module.addIncludePath(ls.assembled_root.path(b, "src/lshpack"));
    module.addIncludePath(bssl.include_root);
    module.addIncludePath(z.include_root);
    module.addCSourceFile(.{
        .file = ls.raw_source_root.path(b, b.fmt("tests/test_{s}.c", .{source})),
        .flags = flags.items,
    });
    if (extra) |file| module.addCSourceFile(.{
        .file = ls.assembled_root.path(b, b.fmt("src/liblsquic/{s}", .{file})),
        .flags = flags.items,
    });
    module.linkLibrary(ls.library);
    module.linkLibrary(bssl.ssl);
    module.linkLibrary(bssl.crypto);
    module.linkLibrary(z.library);
    sanitizer.attach(module);
    return b.addExecutable(.{ .name = b.fmt("test_{s}", .{name}), .root_module = module });
}

fn append_case(
    b: *std.Build,
    all: *std.Build.Step,
    prior: *?*std.Build.Step,
    exe: *std.Build.Step.Compile,
    sanitizer: sanitizers.Config,
    ls: lsquic.Artifacts,
    name: []const u8,
    args: []const []const u8,
) void {
    const run = sanitizers.add_run_artifact(b, exe, sanitizer.run);
    run.step.name = b.fmt("run upstream {s}", .{name});
    run.setCwd(ls.raw_source_root.path(b, "tests"));
    run.addArgs(args);
    if (prior.*) |previous| run.step.dependOn(previous);
    prior.* = &run.step;
    all.dependOn(&run.step);
}
