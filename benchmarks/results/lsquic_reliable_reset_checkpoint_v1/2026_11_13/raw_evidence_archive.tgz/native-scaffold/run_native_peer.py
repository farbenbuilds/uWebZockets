from pathlib import Path
import json
import select
import subprocess


def main():
    pki = json.loads(Path('/tmp/uwz-reset-native-pki.json').read_text())
    output = Path('/tmp/uwz-lsquic-reset-harness/evidence/native-interop')
    output.mkdir(parents=True, exist_ok=True)
    server_args = [
        '/tmp/uwz-lsquic-reset-harness/zig-out/bin/uwz_reset_oracle_peer',
        '--listen', '127.0.0.1:0', '--cert', pki['cert'], '--key', pki['key'],
        '--timeout', '10',
    ]
    client_args = None
    server_exit = client_exit = None
    first = rest = ''
    with (output / 'server.stderr').open('w') as errors:
        server = subprocess.Popen(server_args, stdout=subprocess.PIPE,
                                  stderr=errors, text=True, bufsize=1)
        try:
            readable, _, _ = select.select([server.stdout], [], [], 4)
            assert readable, 'native peer did not become ready'
            first = server.stdout.readline()
            ready = json.loads(first)
            assert ready['event'] == 'ready'
            client_args = [
                '/tmp/uwz-quic-reset-oracle-20261111/reset-oracle', 'client',
                '--addr', ready['address'], '--ca', pki['ca'], '--timeout', '10s',
            ]
            with (output / 'client.json').open('w') as out, \
                    (output / 'client.stderr').open('w') as err:
                client = subprocess.run(client_args, stdout=out, stderr=err,
                                        timeout=12)
            client_exit = client.returncode
            rest, _ = server.communicate(timeout=12)
            server_exit = server.returncode
        finally:
            if server.poll() is None:
                server.terminate()
                try:
                    rest, _ = server.communicate(timeout=3)
                except subprocess.TimeoutExpired:
                    server.kill()
                    rest, _ = server.communicate()
                server_exit = server.returncode
            (output / 'server.jsonl').write_text(first + rest)
            (output / 'commands.json').write_text(json.dumps({
                'server_argv': server_args, 'server_exit': server_exit,
                'client_argv': client_args, 'client_exit': client_exit,
            }, indent=2) + '\n')
    assert client_exit == 0, (output / 'client.json').read_text()
    assert server_exit == 0, (output / 'server.jsonl').read_text()
    client_result = json.loads((output / 'client.json').read_text())
    server_result = json.loads((output / 'server.jsonl').read_text().splitlines()[-1])
    assert client_result['pass'] and server_result['pass']
    print(json.dumps({'server_exit': server_exit, 'client_exit': client_exit,
                      'client': client_result, 'server': server_result}))


if __name__ == '__main__':
    main()
