#define _POSIX_C_SOURCE 200809L

#include <arpa/inet.h>
#include <errno.h>
#include <inttypes.h>
#include <limits.h>
#include <poll.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

#include <lsquic.h>
#include <openssl/ssl.h>

#define TEST_ALPN "uwz-reset-test/1"
#define TEST_PREFIX "uwz-reset-test/1 reliable prefix\n"
#define TEST_HEALTHY "uwz-reset-test/1 healthy sibling\n"
#define PREFIX_SIZE (sizeof(TEST_PREFIX) - 1)
#define HEALTHY_SIZE (sizeof(TEST_HEALTHY) - 1)
#define OPTIONAL_SIZE 4096
#define RESET_SIZE (PREFIX_SIZE + OPTIONAL_SIZE)
#define RESET_ERROR UINT64_C(373)

_Static_assert(PREFIX_SIZE == 33, "reliable prefix wire size");
_Static_assert(HEALTHY_SIZE == 33, "healthy sibling wire size");

struct peer;

struct stream_state {
    struct peer *peer;
    lsquic_stream_t *stream;
    uint64_t id;
    size_t bytes;
    unsigned opened;
    unsigned closed;
    unsigned done;
    unsigned reset_events;
};

struct peer {
    int socket;
    struct sockaddr_in local;
    SSL_CTX *ssl_ctx;
    lsquic_engine_t *engine;
    lsquic_conn_t *conn;
    struct stream_state streams[4];
    unsigned char reset_payload[RESET_SIZE];
    struct lsquic_stream_recv_state recv_reset;
    unsigned metadata_saved;
    unsigned tls_configured;
    unsigned receive_enabled;
    unsigned conn_opened;
    unsigned conn_closed;
    unsigned close_frames;
    unsigned alpn_selected;
    unsigned outgoing_created;
    unsigned closed_before_destroy;
    unsigned packets_in;
    unsigned packets_out;
    unsigned reset_calls;
    int reset_status;
    int close_app_error;
    uint64_t close_error;
    const char *failure;
    int failure_errno;
};

struct options {
    const char *listen;
    const char *cert;
    const char *key;
    unsigned timeout_seconds;
};

static void
fail(struct peer *peer, const char *message, int error)
{
    if (peer->failure)
        return;
    peer->failure = message;
    peer->failure_errno = error;
}

static int64_t
monotonic_ms(void)
{
    struct timespec now;

    if (clock_gettime(CLOCK_MONOTONIC, &now) < 0)
        return -1;
    return (int64_t) now.tv_sec * 1000 + now.tv_nsec / 1000000;
}

static int
parse_options(int argc, char **argv, struct options *options,
              struct sockaddr_in *local)
{
    char host[INET_ADDRSTRLEN];
    const char *colon;
    char *end;
    unsigned long number;
    size_t host_len;
    int i;

    options->listen = "127.0.0.1:0";
    options->timeout_seconds = 10;
    for (i = 1; i < argc; i += 2) {
        if (i + 1 == argc)
            return -1;
        if (strcmp(argv[i], "--listen") == 0)
            options->listen = argv[i + 1];
        else if (strcmp(argv[i], "--cert") == 0)
            options->cert = argv[i + 1];
        else if (strcmp(argv[i], "--key") == 0)
            options->key = argv[i + 1];
        else if (strcmp(argv[i], "--timeout") == 0) {
            errno = 0;
            number = strtoul(argv[i + 1], &end, 10);
            if (errno || !argv[i + 1][0] || *end || number < 1 || number > 60)
                return -1;
            options->timeout_seconds = (unsigned) number;
        } else
            return -1;
    }
    if (!options->cert || !options->key)
        return -1;
    colon = strrchr(options->listen, ':');
    if (!colon)
        return -1;
    host_len = (size_t) (colon - options->listen);
    if (!host_len || host_len >= sizeof(host))
        return -1;
    memcpy(host, options->listen, host_len);
    host[host_len] = '\0';
    memset(local, 0, sizeof(*local));
    local->sin_family = AF_INET;
    if (inet_pton(AF_INET, host, &local->sin_addr) != 1 ||
        (ntohl(local->sin_addr.s_addr) >> 24) != 127)
        return -1;
    errno = 0;
    number = strtoul(colon + 1, &end, 10);
    if (errno || !colon[1] || *end || number > UINT16_MAX)
        return -1;
    local->sin_port = htons((uint16_t) number);
    return 0;
}

static int
select_alpn(SSL *ssl, const unsigned char **out, unsigned char *out_len,
            const unsigned char *in, unsigned in_len, void *context)
{
    struct peer *peer = context;
    unsigned offset = 0, len;

    (void) ssl;
    while (offset < in_len) {
        len = in[offset++];
        if (!len || len > in_len - offset)
            return SSL_TLSEXT_ERR_ALERT_FATAL;
        if (len == sizeof(TEST_ALPN) - 1 &&
            memcmp(in + offset, TEST_ALPN, len) == 0) {
            *out = (const unsigned char *) TEST_ALPN;
            *out_len = (unsigned char) len;
            ++peer->alpn_selected;
            return SSL_TLSEXT_ERR_OK;
        }
        offset += len;
    }
    return SSL_TLSEXT_ERR_ALERT_FATAL;
}

static SSL_CTX *
get_ssl_ctx(void *context, const struct sockaddr *local)
{
    struct peer *peer = context;

    (void) local;
    return peer->ssl_ctx;
}

static SSL_CTX *
lookup_cert(void *context, const struct sockaddr *local, const char *sni)
{
    (void) sni;
    return get_ssl_ctx(context, local);
}

static lsquic_conn_ctx_t *
on_new_conn(void *context, lsquic_conn_t *conn)
{
    struct peer *peer = context;

    ++peer->conn_opened;
    if (peer->conn_opened != 1 || peer->conn)
        fail(peer, "unexpected additional connection", 0);
    else
        peer->conn = conn;
    if (lsquic_conn_quic_version(conn) != LSQVER_I001)
        fail(peer, "connection is not QUIC v1", 0);
    return (lsquic_conn_ctx_t *) peer;
}

static void
on_conn_closed(lsquic_conn_t *conn)
{
    struct peer *peer = (struct peer *) lsquic_conn_get_ctx(conn);

    if (!peer)
        return;
    lsquic_conn_set_ctx(conn, NULL);
    ++peer->conn_closed;
    if (peer->conn != conn || peer->conn_closed != 1)
        fail(peer, "connection closed more than once or wrong connection", 0);
    peer->conn = NULL;
}

static void
on_conncloseframe(lsquic_conn_t *conn, int app_error, uint64_t code,
                  const char *reason, int reason_len)
{
    struct peer *peer = (struct peer *) lsquic_conn_get_ctx(conn);

    (void) reason;
    (void) reason_len;
    if (!peer)
        return;
    ++peer->close_frames;
    peer->close_app_error = app_error;
    peer->close_error = code;
    if (peer->close_frames != 1 || app_error != 1 || code != 0)
        fail(peer, "expected remote application connection close zero", 0);
}

static lsquic_stream_ctx_t *
on_new_stream(void *context, lsquic_stream_t *stream)
{
    struct peer *peer = context;
    struct stream_state *state;
    uint64_t id;
    unsigned slot;

    if (!stream) {
        fail(peer, "stream creation returned null", 0);
        return NULL;
    }
    id = lsquic_stream_id(stream);
    switch (id) {
    case 2: slot = 0; break;
    case 6: slot = 1; break;
    case 3: slot = 2; break;
    case 7: slot = 3; break;
    default:
        fail(peer, "unexpected application stream ID", 0);
        return NULL;
    }
    state = &peer->streams[slot];
    if (state->opened || state->closed || state->stream) {
        fail(peer, "application stream opened more than once", 0);
        return NULL;
    }
    state->stream = stream;
    ++state->opened;
    if (slot < 2) {
        lsquic_stream_wantread(stream, 1);
        return (lsquic_stream_ctx_t *) state;
    }
    if (!peer->streams[0].done || !peer->streams[1].done ||
        slot != 2 + peer->outgoing_created)
        fail(peer, "response stream opened before verified request pair", 0);
    ++peer->outgoing_created;
    if (lsquic_stream_wantwrite(stream, 1) < 0)
        fail(peer, "cannot enable response write interest", errno);
    return (lsquic_stream_ctx_t *) state;
}

static int
check_input(struct stream_state *state, const unsigned char *bytes, size_t len)
{
    size_t offset, i;
    unsigned char expected;
    size_t limit = state->id == 2 ? RESET_SIZE : HEALTHY_SIZE;

    if (len > limit - state->bytes)
        return -1;
    for (i = 0; i < len; ++i) {
        offset = state->bytes + i;
        if (state->id == 6)
            expected = (unsigned char) TEST_HEALTHY[offset];
        else if (offset < PREFIX_SIZE)
            expected = (unsigned char) TEST_PREFIX[offset];
        else
            expected = 'x';
        if (bytes[i] != expected)
            return -1;
    }
    state->bytes += len;
    return 0;
}

static void
on_read(lsquic_stream_t *stream, lsquic_stream_ctx_t *context)
{
    struct stream_state *state = (struct stream_state *) context;
    struct peer *peer;
    unsigned char bytes[512];
    uint64_t code = 0;
    ssize_t count;
    int error;
    unsigned required_flags = LSQUIC_SRS_FINAL_SIZE_KNOWN |
        LSQUIC_SRS_RESET_KNOWN | LSQUIC_SRS_RELIABLE_RESET_SEEN |
        LSQUIC_SRS_RESET_VISIBLE;

    if (!state)
        return;
    peer = state->peer;
    if (state->stream != stream || state->closed || state->done ||
        (state->id != 2 && state->id != 6)) {
        fail(peer, "read callback for invalid stream lifecycle", 0);
        return;
    }
    for (;;) {
        count = lsquic_stream_read(stream, bytes, sizeof(bytes));
        if (count > 0) {
            if (check_input(state, bytes, (size_t) count) < 0) {
                fail(peer, "inbound stream payload mismatch or excess bytes", 0);
                return;
            }
            continue;
        }
        error = count < 0 ? errno : 0;
        if (count < 0 && (error == EAGAIN || error == EWOULDBLOCK))
            return;
        if (count < 0 && error == EINTR)
            continue;
        if (state->id == 6) {
            if (count != 0 || state->bytes != HEALTHY_SIZE) {
                fail(peer, "healthy inbound stream requires exact payload and EOF", error);
                return;
            }
        } else {
            if (count != -1 || error != ECONNRESET || state->bytes < PREFIX_SIZE ||
                lsquic_stream_get_reset_error(stream, 0, &code) != LSQUIC_SERR_AVAILABLE ||
                code != RESET_ERROR) {
                fail(peer, "reset inbound stream requires prefix and remote reset 373", error);
                return;
            }
            if (lsquic_stream_get_recv_state(stream, &peer->recv_reset) != LSQUIC_SRG_OK) {
                fail(peer, "received reset metadata unavailable", 0);
                return;
            }
            peer->metadata_saved = 1;
            if ((peer->recv_reset.flags & required_flags) != required_flags ||
                peer->recv_reset.reliable_size != PREFIX_SIZE ||
                peer->recv_reset.final_size < state->bytes ||
                peer->recv_reset.final_size > RESET_SIZE ||
                peer->recv_reset.reset_error_code != RESET_ERROR) {
                fail(peer, "received reliable reset metadata mismatch", 0);
                return;
            }
        }
        state->done = 1;
        lsquic_stream_wantread(stream, 0);
        /* Stream callbacks may retire the pointer during shutdown. */
        if (lsquic_stream_shutdown(stream, 0) < 0)
            fail(peer, "cannot finish inbound read direction", errno);
        return;
    }
}

static void
on_write(lsquic_stream_t *stream, lsquic_stream_ctx_t *context)
{
    struct stream_state *state = (struct stream_state *) context;
    struct peer *peer;
    const unsigned char *payload;
    size_t length;
    ssize_t count;
    int status;

    if (!state)
        return;
    peer = state->peer;
    if (state->stream != stream || state->closed || state->done ||
        (state->id != 3 && state->id != 7)) {
        fail(peer, "write callback for invalid stream lifecycle", 0);
        return;
    }
    payload = state->id == 3 ? peer->reset_payload :
        (const unsigned char *) TEST_HEALTHY;
    length = state->id == 3 ? RESET_SIZE : HEALTHY_SIZE;
    while (state->bytes < length) {
        count = lsquic_stream_write(stream, payload + state->bytes,
                                   length - state->bytes);
        if (count > 0) {
            state->bytes += (size_t) count;
            continue;
        }
        if (count == 0 || errno == EAGAIN || errno == EWOULDBLOCK)
            return;
        if (errno == EINTR)
            continue;
        fail(peer, "response stream write failed", errno);
        return;
    }
    lsquic_stream_wantwrite(stream, 0);
    state->done = 1;
    if (state->id == 7) {
        if (lsquic_stream_shutdown(stream, 1) < 0)
            fail(peer, "cannot finish healthy response stream", errno);
        return;
    }
    ++peer->reset_calls;
    /* The completed handshake and Go peer's TP make BLOCKED/UNSUPPORTED failures. */
    status = lsquic_stream_reset_at(stream, RESET_ERROR, PREFIX_SIZE);
    peer->reset_status = status;
    if (status != LSQUIC_SRA_OK)
        fail(peer, "nonzero-boundary reset_at did not return OK", 0);
}

static void
on_reset(lsquic_stream_t *stream, lsquic_stream_ctx_t *context, int how)
{
    struct stream_state *state = (struct stream_state *) context;

    if (!state)
        return;
    ++state->reset_events;
    if (state->stream != stream || state->closed || state->id != 2 ||
        how != 0 || state->reset_events != 1 || state->bytes < PREFIX_SIZE)
        fail(state->peer, "unexpected or repeated peer stream reset callback", 0);
    /* Notification never cancels reading the guaranteed prefix. */
}

static void
on_close(lsquic_stream_t *stream, lsquic_stream_ctx_t *context)
{
    struct stream_state *state = (struct stream_state *) context;

    if (!state)
        return;
    ++state->closed;
    if (state->stream != stream || state->opened != 1 || state->closed != 1)
        fail(state->peer, "application stream closed more than once or wrong stream", 0);
    state->stream = NULL;
}

static int
packets_out(void *context, const struct lsquic_out_spec *specs, unsigned count)
{
    struct peer *peer = context;
    struct msghdr message;
    struct cmsghdr *control_header;
    union {
        struct cmsghdr align;
        unsigned char bytes[CMSG_SPACE(sizeof(int))];
    } control;
    ssize_t sent;
    size_t expected, j;
    unsigned i;
    int tos;

    for (i = 0; i < count; ++i) {
        memset(&message, 0, sizeof(message));
        memset(&control, 0, sizeof(control));
        message.msg_name = (void *) specs[i].dest_sa;
        message.msg_namelen = sizeof(struct sockaddr_in);
        message.msg_iov = specs[i].iov;
        message.msg_iovlen = specs[i].iovlen;
        message.msg_control = control.bytes;
        message.msg_controllen = sizeof(control.bytes);
        control_header = CMSG_FIRSTHDR(&message);
        control_header->cmsg_level = IPPROTO_IP;
        control_header->cmsg_type = IP_TOS;
        control_header->cmsg_len = CMSG_LEN(sizeof(tos));
        tos = specs[i].ecn & 3;
        memcpy(CMSG_DATA(control_header), &tos, sizeof(tos));
        expected = 0;
        for (j = 0; j < specs[i].iovlen; ++j)
            expected += specs[i].iov[j].iov_len;
        do {
            sent = sendmsg(peer->socket, &message, 0);
        } while (sent < 0 && errno == EINTR);
        if (sent == (ssize_t) expected) {
            ++peer->packets_out;
            continue;
        }
        if (sent >= 0)
            errno = EIO;
        if (errno != EAGAIN && errno != EWOULDBLOCK)
            fail(peer, "UDP sendmsg failed or returned partial datagram", errno);
        return i ? (int) i : -1;
    }
    return (int) count;
}

static const struct lsquic_stream_if stream_callbacks = {
    .on_new_conn = on_new_conn,
    .on_conn_closed = on_conn_closed,
    .on_new_stream = on_new_stream,
    .on_read = on_read,
    .on_write = on_write,
    .on_close = on_close,
    .on_reset = on_reset,
    .on_conncloseframe_received = on_conncloseframe,
};

static void
receive_packets(struct peer *peer)
{
    unsigned char packet[65536];
    struct sockaddr_in remote;
    struct iovec iov = { .iov_base = packet, .iov_len = sizeof(packet) };
    struct msghdr message;
    struct cmsghdr *header;
    union {
        struct cmsghdr align;
        unsigned char bytes[CMSG_SPACE(sizeof(int))];
    } control;
    unsigned received;
    ssize_t size;
    int ecn;

    for (received = 0; received < 64; ++received) {
        memset(&message, 0, sizeof(message));
        memset(&remote, 0, sizeof(remote));
        message.msg_name = &remote;
        message.msg_namelen = sizeof(remote);
        message.msg_iov = &iov;
        message.msg_iovlen = 1;
        message.msg_control = control.bytes;
        message.msg_controllen = sizeof(control.bytes);
        size = recvmsg(peer->socket, &message, 0);
        if (size < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK)
                return;
            if (errno == EINTR)
                continue;
            fail(peer, "UDP recvmsg failed", errno);
            return;
        }
        if (message.msg_flags & (MSG_TRUNC | MSG_CTRUNC)) {
            fail(peer, "truncated UDP packet or ancillary data", 0);
            return;
        }
        if (remote.sin_family != AF_INET ||
            (ntohl(remote.sin_addr.s_addr) >> 24) != 127) {
            fail(peer, "received datagram from non-loopback address", 0);
            return;
        }
        ecn = 0;
        for (header = CMSG_FIRSTHDR(&message); header;
             header = CMSG_NXTHDR(&message, header)) {
            if (header->cmsg_level == IPPROTO_IP && header->cmsg_type == IP_TOS &&
                header->cmsg_len >= CMSG_LEN(sizeof(unsigned char)))
                ecn = *(const unsigned char *) CMSG_DATA(header) & 3;
        }
        ++peer->packets_in;
        if (lsquic_engine_packet_in(peer->engine, packet, (size_t) size,
            (const struct sockaddr *) &peer->local,
            (const struct sockaddr *) &remote, peer, ecn) < 0) {
            fail(peer, "lsquic_engine_packet_in failed", 0);
            return;
        }
        if (peer->failure || peer->conn_closed)
            return;
    }
}

static void
run_loop(struct peer *peer, unsigned timeout_seconds)
{
    struct pollfd descriptor = { .fd = peer->socket };
    int64_t now = monotonic_ms(), deadline, wait_ms;
    int diff, polled, status;
    unsigned before, opened_before;

    if (now < 0) {
        fail(peer, "monotonic clock failed", errno);
        return;
    }
    deadline = now + (int64_t) timeout_seconds * 1000;
    while (!peer->failure && !peer->conn_closed) {
        now = monotonic_ms();
        if (now < 0 || now >= deadline) {
            fail(peer, now < 0 ? "monotonic clock failed" : "exchange deadline expired",
                 now < 0 ? errno : 0);
            return;
        }
        lsquic_engine_process_conns(peer->engine);
        if (peer->failure || peer->conn_closed)
            return;
        opened_before = peer->outgoing_created;
        while (peer->conn && peer->streams[0].done && peer->streams[1].done &&
               peer->outgoing_created < 2) {
            before = peer->outgoing_created;
            status = lsquic_conn_make_uni_stream(peer->conn);
            if (status == LSQUIC_MUS_BLOCKED)
                break;
            if (status != LSQUIC_MUS_OK || peer->outgoing_created != before + 1) {
                fail(peer, "make_uni_stream failed or callback count mismatch", 0);
                return;
            }
            if (peer->failure || peer->conn_closed)
                return;
        }
        /* Newly enabled writers need an engine turn before waiting for UDP. */
        if (peer->outgoing_created != opened_before)
            continue;
        now = monotonic_ms();
        if (now < 0 || now >= deadline) {
            fail(peer, now < 0 ? "monotonic clock failed" : "exchange deadline expired",
                 now < 0 ? errno : 0);
            return;
        }
        wait_ms = deadline - now;
        if (lsquic_engine_earliest_adv_tick(peer->engine, &diff)) {
            int64_t tick_ms = diff <= 0 ? 0 : ((int64_t) diff + 999) / 1000;
            if (tick_ms < wait_ms)
                wait_ms = tick_ms;
        }
        descriptor.events = POLLIN;
        if (lsquic_engine_has_unsent_packets(peer->engine))
            descriptor.events |= POLLOUT;
        descriptor.revents = 0;
        polled = poll(&descriptor, 1, (int) wait_ms);
        if (polled < 0 && errno == EINTR)
            continue;
        if (polled < 0 || (descriptor.revents & (POLLERR | POLLHUP | POLLNVAL))) {
            fail(peer, "UDP poll failed", polled < 0 ? errno : 0);
            return;
        }
        if (descriptor.revents & POLLIN)
            receive_packets(peer);
        if (peer->failure || peer->conn_closed)
            return;
        if (descriptor.revents & POLLOUT)
            lsquic_engine_send_unsent_packets(peer->engine);
    }
}

static int
initialize(struct peer *peer, const struct options *options)
{
    struct lsquic_engine_settings settings;
    struct lsquic_engine_api api;
    socklen_t address_len = sizeof(peer->local);
    int enabled = 1;

    peer->ssl_ctx = SSL_CTX_new(TLS_method());
    if (!peer->ssl_ctx ||
        !SSL_CTX_set_min_proto_version(peer->ssl_ctx, TLS1_3_VERSION) ||
        !SSL_CTX_set_max_proto_version(peer->ssl_ctx, TLS1_3_VERSION) ||
        !SSL_CTX_use_certificate_chain_file(peer->ssl_ctx, options->cert) ||
        !SSL_CTX_use_PrivateKey_file(peer->ssl_ctx, options->key, SSL_FILETYPE_PEM) ||
        !SSL_CTX_check_private_key(peer->ssl_ctx)) {
        fail(peer, "TLS context or provided PEM certificate/key setup failed", 0);
        return -1;
    }
    SSL_CTX_set_alpn_select_cb(peer->ssl_ctx, select_alpn, peer);
    peer->tls_configured = 1;
    peer->socket = socket(AF_INET, SOCK_DGRAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
    if (peer->socket < 0 ||
        setsockopt(peer->socket, IPPROTO_IP, IP_RECVTOS, &enabled, sizeof(enabled)) < 0 ||
        bind(peer->socket, (const struct sockaddr *) &peer->local, sizeof(peer->local)) < 0 ||
        getsockname(peer->socket, (struct sockaddr *) &peer->local, &address_len) < 0) {
        fail(peer, "loopback UDP socket setup failed", errno);
        return -1;
    }
    lsquic_engine_init_settings(&settings, LSENG_SERVER);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_init_max_streams_uni = 4;
    settings.es_init_max_data = 65536;
    settings.es_init_max_stream_data_uni = 65536;
    settings.es_handshake_to = 3000000;
    settings.es_idle_timeout = options->timeout_seconds;
    settings.es_reset_stream_at = 1;
    if (lsquic_engine_check_settings(&settings, LSENG_SERVER, NULL, 0) < 0) {
        fail(peer, "lsquic settings validation failed", 0);
        return -1;
    }
    memset(&api, 0, sizeof(api));
    api.ea_settings = &settings;
    api.ea_stream_if = &stream_callbacks;
    api.ea_stream_if_ctx = peer;
    api.ea_packets_out = packets_out;
    api.ea_packets_out_ctx = peer;
    api.ea_lookup_cert = lookup_cert;
    api.ea_cert_lu_ctx = peer;
    api.ea_get_ssl_ctx = get_ssl_ctx;
    api.ea_alpn = TEST_ALPN;
    peer->engine = lsquic_engine_new(LSENG_SERVER, &api);
    if (!peer->engine) {
        fail(peer, "lsquic engine creation failed", 0);
        return -1;
    }
    peer->receive_enabled = 1;
    return 0;
}

static void
check_complete(struct peer *peer)
{
    unsigned i;

    if (peer->conn_opened != 1 || peer->conn_closed != 1 || peer->conn ||
        peer->close_frames != 1 || peer->close_app_error != 1 || peer->close_error ||
        peer->alpn_selected != 1 || peer->outgoing_created != 2 ||
        peer->reset_calls != 1 || peer->reset_status != LSQUIC_SRA_OK ||
        !peer->metadata_saved)
        fail(peer, "connection negotiation or teardown counts mismatch", 0);
    for (i = 0; i < 4; ++i) {
        if (peer->streams[i].closed == 1)
            ++peer->closed_before_destroy;
        if (peer->streams[i].opened != 1 || peer->streams[i].closed != 1 ||
            !peer->streams[i].done || peer->streams[i].stream ||
            peer->streams[i].reset_events != (i == 0 ? 1U : 0U))
            fail(peer, "application stream lifecycle counts mismatch", 0);
    }
    if (peer->streams[2].bytes != RESET_SIZE || peer->streams[3].bytes != HEALTHY_SIZE)
        fail(peer, "response byte counts mismatch", 0);
}

static int
report(const struct peer *peer)
{
    unsigned i;
    size_t optional = peer->streams[0].bytes >= PREFIX_SIZE ?
        peer->streams[0].bytes - PREFIX_SIZE : 0;

    if (printf("{\"role\":\"lsquic-server\",\"alpn_expected\":\"%s\","
               "\"tls13_only_configured\":%s,\"receive_reset_enabled\":%s,"
               "\"alpn_selected\":%u,\"connections_opened\":%u,\"connections_closed\":%u,"
               "\"remote_close_frames\":%u,\"remote_close_app_error\":%d,"
               "\"remote_close_code\":%" PRIu64 ",\"optional_bytes_observed\":%zu,"
               "\"received_metadata_saved\":%u,\"received_final_size\":%" PRIu64 ","
               "\"received_reliable_size\":%" PRIu64 ",\"received_reset_error\":%" PRIu64 ","
               "\"received_metadata_flags\":%u,\"sent_reset_status\":%d,"
               "\"reset_calls\":%u,\"closed_before_destroy\":%u,"
               "\"packets_in\":%u,\"packets_out\":%u,\"streams\":[",
               TEST_ALPN, peer->tls_configured ? "true" : "false",
               peer->receive_enabled ? "true" : "false", peer->alpn_selected,
               peer->conn_opened, peer->conn_closed,
               peer->close_frames, peer->close_app_error, peer->close_error, optional,
               peer->metadata_saved, peer->recv_reset.final_size,
               peer->recv_reset.reliable_size, peer->recv_reset.reset_error_code,
               peer->recv_reset.flags, peer->reset_status, peer->reset_calls,
               peer->closed_before_destroy, peer->packets_in, peer->packets_out) < 0)
        return -1;
    for (i = 0; i < 4; ++i) {
        const struct stream_state *state = &peer->streams[i];
        if (printf("%s{\"id\":%" PRIu64 ",\"bytes\":%zu,\"opened\":%u,"
                   "\"closed\":%u,\"done\":%u,\"reset_events\":%u}",
                   i ? "," : "", state->id, state->bytes, state->opened,
                   state->closed, state->done, state->reset_events) < 0)
            return -1;
    }
    if (printf("],\"pass\":%s,\"error\":\"%s\",\"errno\":%d}\n",
               peer->failure ? "false" : "true", peer->failure ? peer->failure : "",
               peer->failure_errno) < 0 || fflush(stdout) != 0)
        return -1;
    return 0;
}

int
main(int argc, char **argv)
{
    static const uint64_t stream_ids[4] = { 2, 6, 3, 7 };
    struct peer peer = { .socket = -1, .reset_status = LSQUIC_SRA_BLOCKED };
    struct options options = { 0 };
    char address[INET_ADDRSTRLEN];
    unsigned i;
    int global_initialized = 0;

    for (i = 0; i < 4; ++i) {
        peer.streams[i].peer = &peer;
        peer.streams[i].id = stream_ids[i];
    }
    memcpy(peer.reset_payload, TEST_PREFIX, PREFIX_SIZE);
    memset(peer.reset_payload + PREFIX_SIZE, 'x', OPTIONAL_SIZE);
    if (parse_options(argc, argv, &options, &peer.local) < 0) {
        fail(&peer, "usage requires --listen IPv4-loopback:port --cert PEM --key PEM --timeout seconds", 0);
        goto cleanup;
    }
    if (lsquic_global_init(LSQUIC_GLOBAL_SERVER) < 0) {
        fail(&peer, "lsquic global initialization failed", 0);
        goto cleanup;
    }
    global_initialized = 1;
    if (initialize(&peer, &options) < 0)
        goto cleanup;
    if (!inet_ntop(AF_INET, &peer.local.sin_addr, address, sizeof(address)) ||
        printf("{\"event\":\"ready\",\"address\":\"%s:%u\"}\n", address,
               (unsigned) ntohs(peer.local.sin_port)) < 0 || fflush(stdout) != 0) {
        fail(&peer, "cannot report bound loopback address", errno);
        goto cleanup;
    }
    run_loop(&peer, options.timeout_seconds);
    check_complete(&peer);

cleanup:
    if (peer.engine)
        lsquic_engine_destroy(peer.engine);
    if (peer.socket >= 0 && close(peer.socket) < 0)
        fail(&peer, "UDP socket cleanup failed", errno);
    if (peer.ssl_ctx)
        SSL_CTX_free(peer.ssl_ctx);
    if (global_initialized)
        lsquic_global_cleanup();
    if (report(&peer) < 0)
        return 1;
    return peer.failure ? 1 : 0;
}
