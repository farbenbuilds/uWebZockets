# Reliable reset checkpoint, 2026-11-13

The user requested a commit checkpoint. The proposal is local, unpublished,
and not a production dependency, patch overlay, or completed release.

## Recover

Restore the prerequisite history from the earlier dependency/uni-stream
archives. Then verify and fetch reliable-reset.bundle. It requires
0f7382b17b38d7fb0496a0b75b3c66ace79e49e8 and contains tip
c434c4ae3a2ad9f584d2c17536f800623ef36df6 on the proposal branch.
The proposal working tree was clean when archived. proposal-inputs.sha256
identifies all tracked files at that tip.

The native-scaffold directory is review and functional-test material only.
It preserves the Zig-native build and standalone peer, without dependency
caches, binaries, fixture private keys, or new production build dependencies.
Original scratch paths in logs and scripts require relocation before reuse.
The earlier checkpoint retains the independent Go client sources and pinned
provenance. No fetched dependency source was edited to manufacture results.

## Observed functional results

Focused Debug runs passed for receive regressions, encryption-level legality,
both-role lost-prefix delivery, four real-ticket resumption cases, partial
headers, both STOP_SENDING receive-state cases, both-role public API and
frozen flow-credit cases, and both-role obsolete-ACK/shrink recovery.
The final shrink case passed before the commit freeze; the multi-stream ACK
batch case has not been implemented.

The native lsquic peer and pinned independent quic-go client both exited zero.
The client verified its explicit fixture CA and TLS 1.3. Both directions
verified the 33-byte reliable prefix and reset error 373, plus healthy sibling
streams and clean connection shutdown. This proves reliable reset, not a
complete WebTransport implementation. The generated fixture private key is
excluded.

The full upstream Debug run failed: six standalone test-link failures and
send_headers test_flushes_and_closes asserted SMQF_FREE_STREAM. The scaffold
has since copied the previously verified standalone-link selection fix, but
the full run has not been repeated and the assertion remains unresolved.
No failing test or assertion was removed or weakened for this checkpoint.
The initial failing logs and corrected focused logs are retained separately.

The early-data-disabled resumption case waits for the actual TLS handshake;
pre-handshake STREAM queueing with early data disabled still closes the old
backend and remains unresolved outside this parameter matrix.

## Remaining work

Resolve upstream send_headers, rerun the functional upstream suite with the
corrected manifest, implement real multi-stream ACK batching coverage, review
private layout changes and platform builds, and finish the live draft-16
WebTransport path. Maintained-fork review/publication and a reviewed exact
production pin are still required. No root dependency pin changed.

Remaining smoke/security runs are deferred to the user. Earlier evidence is
historical; this archive claims no new sanitizer, security, fuzz, or smoke run.
PostgreSQL TLS allocation, throughput, external publication, and other v2.3.0
release gates remain open. SQLite SQL-ALLOC-001 does not waive PostgreSQL TLS
allocation. No release, push, tag, or force update was performed.
