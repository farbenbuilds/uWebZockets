# Paused reliable-reset checkpoint

The user paused implementation and requested this commit on 2026-11-12.
Remaining smoke and security runs are deferred to the user. No capability or
production dependency pin is activated by this archive.

Local proposal commit: 3e6c31890cb7c48d933b5114136324c5113fb0a8.
Prerequisite: 0f7382b17b38d7fb0496a0b75b3c66ace79e49e8, retained in the earlier
lsquic_uni_prerequisite_v1 artifact. Import fork.bundle into a checkout with
that prerequisite to recover the source-control checkpoint. This bundle is
review material, never a production build input or dependency overlay.

Verified before pause: four wire/transport-parameter Debug units; eight
original encrypted engine groups after the corrected core (12/12 build
steps); two targeted regression failures against the immutable RX-first
version. P1/P2 corrections are present in the proposal, but their targeted
GREEN checks were not run before the pause. Receive advertisement remains
held. New reliable-reset delivery and external native interoperability are
not verified. The Go reset and exact draft-16 tools have Go-to-Go control
results only; their sources and evidence are retained without binaries,
module caches, or private keys.

Resume functional work with the targeted correction checks, then coordinate
the held receive advertisement and run the new delivery fixtures. Preserve
the partial-QPACK and STOP independent-direction findings in the historical
core handoff. More runtime, ACK, close and flow-credit cases remain. The
historical handoff predates the P1/P2 edits; this file records their current
status. Active release gates also remain in tasks/todo.md in the parent
repository. The goal is paused, and v2.3.0 is not complete.

The native harness compiles dependencies using Zig. Absolute temporary paths
in historical commands describe the original environment; its source and
fixture options allow a restored checkout. External Go tools are separate
verification clients, not library build requirements. Historical manifests
may refer to excluded binaries or dependency sources; files.sha256 covers
exactly this archive's retained files.
