package main

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"net"
	"os"
	"time"

	quic "github.com/quic-go/quic-go"
)

const (
	sourceRevision = "8d34dbcccc219375fa9fbaa9b7b22caeebd7d49d"
	archiveSHA256  = "cf7ac1c2b5e224a58891d17c4add0c7a0f7ca981f8c6693f9243985851703093"
)

type PeerEvidence struct {
	Role               string           `json:"role"`
	ALPN               string           `json:"alpn"`
	TLSVersion         uint16           `json:"tls_version"`
	ExplicitCAVerified bool             `json:"explicit_ca_verified,omitempty"`
	LocalSupport       bool             `json:"local_partial_delivery"`
	RemoteSupport      bool             `json:"remote_partial_delivery"`
	SentResetID        uint64           `json:"sent_reset_stream_id"`
	SentHealthyID      uint64           `json:"sent_healthy_stream_id"`
	ResetBytesWritten  int              `json:"reset_bytes_written"`
	ReliableSize       int              `json:"reliable_size"`
	ReceivedResetID    uint64           `json:"received_reset_stream_id"`
	ReceivedHealthyID  uint64           `json:"received_healthy_stream_id"`
	PrefixHex          string           `json:"verified_prefix_hex"`
	Reset              ResetObservation `json:"reset"`
	HealthyHex         string           `json:"verified_healthy_hex"`
	HealthyEOF         bool             `json:"healthy_eof"`
	CleanClose         bool             `json:"clean_close"`
	DurationMS         int64            `json:"duration_ms"`
	Pass               bool             `json:"pass"`
	Error              string           `json:"error,omitempty"`
}

type Result struct {
	Mode          string         `json:"mode"`
	Revision      string         `json:"quic_go_revision"`
	ArchiveSHA256 string         `json:"quic_go_archive_sha256"`
	Address       string         `json:"address,omitempty"`
	PKIDir        string         `json:"pki_directory,omitempty"`
	Peers         []PeerEvidence `json:"peers,omitempty"`
	Pass          bool           `json:"pass"`
	Error         string         `json:"error,omitempty"`
}

type serverEndpoint struct {
	socket    *net.UDPConn
	transport *quic.Transport
	listener  *quic.Listener
}

func main() {
	result, err := run(os.Args[1:])
	result.Pass = err == nil
	if err != nil {
		result.Error = err.Error()
	}
	if encodeErr := json.NewEncoder(os.Stdout).Encode(result); encodeErr != nil {
		fmt.Fprintln(os.Stderr, encodeErr)
		os.Exit(1)
	}
	if err != nil {
		os.Exit(1)
	}
}

func run(args []string) (result Result, err error) {
	result.Revision, result.ArchiveSHA256 = sourceRevision, archiveSHA256
	if len(args) == 0 {
		return result, errors.New("usage: reset-oracle selftest | client --addr IP:PORT --ca FILE | server --listen IP:PORT --cert FILE --key FILE")
	}
	result.Mode = args[0]
	flags := flag.NewFlagSet(result.Mode, flag.ContinueOnError)
	addr := flags.String("addr", "127.0.0.1:4433", "loopback server address")
	listen := flags.String("listen", "127.0.0.1:4433", "loopback listen address")
	ca := flags.String("ca", "", "explicit PEM CA file")
	cert := flags.String("cert", "", "PEM server certificate file")
	key := flags.String("key", "", "PEM server private key file")
	timeout := flags.Duration("timeout", 10*time.Second, "whole exchange timeout, at most 1 minute")
	if err := flags.Parse(args[1:]); err != nil {
		return result, err
	}
	if flags.NArg() != 0 || *timeout <= 0 || *timeout > time.Minute {
		return result, errors.New("unexpected arguments or timeout outside (0, 1m]")
	}
	ctx, cancel := context.WithTimeout(context.Background(), *timeout)
	defer cancel()
	switch result.Mode {
	case "selftest":
		return runSelftest(ctx, result)
	case "client":
		result.Address = *addr
		conf, err := clientTLS(*ca)
		if err != nil {
			return result, err
		}
		peer, err := runClient(ctx, *addr, conf)
		result.Peers = []PeerEvidence{peer}
		return result, err
	case "server":
		conf, err := serverTLS(*cert, *key)
		if err != nil {
			return result, err
		}
		endpoint, err := listenLocal(*listen, conf)
		if err != nil {
			return result, err
		}
		defer func() { err = errors.Join(err, closeServer(endpoint)) }()
		result.Address = endpoint.listener.Addr().String()
		if err := json.NewEncoder(os.Stdout).Encode(map[string]string{"event": "ready", "address": result.Address}); err != nil {
			return result, err
		}
		peer, err := servePeer(ctx, endpoint.listener)
		result.Peers = []PeerEvidence{peer}
		return result, err
	default:
		return result, fmt.Errorf("unknown mode %q", result.Mode)
	}
}

func config() *quic.Config {
	// Exact revision's API describes draft-ietf-quic-reliable-stream-reset-09.
	// https://github.com/quic-go/quic-go/blob/8d34dbcccc219375fa9fbaa9b7b22caeebd7d49d/interface.go#L193-L195
	return &quic.Config{
		Versions:                         []quic.Version{quic.Version1},
		EnableStreamResetPartialDelivery: true,
		HandshakeIdleTimeout:             3 * time.Second,
		MaxIdleTimeout:                   10 * time.Second,
		MaxIncomingUniStreams:            4,
	}
}

func loopbackAddress(addr string) (*net.UDPAddr, error) {
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		return nil, err
	}
	ip := net.ParseIP(host)
	if ip == nil || !ip.IsLoopback() || ip.To4() == nil {
		return nil, errors.New("address must be a literal IPv4 loopback address")
	}
	return net.ResolveUDPAddr("udp4", addr)
}

func listenLocal(addr string, conf *tls.Config) (*serverEndpoint, error) {
	local, err := loopbackAddress(addr)
	if err != nil {
		return nil, err
	}
	socket, err := net.ListenUDP("udp4", local)
	if err != nil {
		return nil, err
	}
	transport := &quic.Transport{Conn: socket}
	listener, err := transport.Listen(conf, config())
	if err != nil {
		return nil, errors.Join(err, transport.Close(), socket.Close())
	}
	return &serverEndpoint{socket, transport, listener}, nil
}

func closeServer(endpoint *serverEndpoint) error {
	return errors.Join(endpoint.listener.Close(), endpoint.transport.Close(), endpoint.socket.Close())
}

func runSelftest(ctx context.Context, result Result) (_ Result, err error) {
	pki, err := generatePKI()
	if err != nil {
		return result, err
	}
	result.PKIDir = pki
	serverConf, err := serverTLS(pki+"/server.pem", pki+"/server.key")
	if err != nil {
		return result, err
	}
	clientConf, err := clientTLS(pki + "/ca.pem")
	if err != nil {
		return result, err
	}
	endpoint, err := listenLocal("127.0.0.1:0", serverConf)
	if err != nil {
		return result, err
	}
	defer func() { err = errors.Join(err, closeServer(endpoint)) }()
	result.Address = endpoint.listener.Addr().String()
	type outcome struct {
		peer PeerEvidence
		err  error
	}
	serverDone := make(chan outcome, 1)
	go func() {
		peer, err := servePeer(ctx, endpoint.listener)
		serverDone <- outcome{peer, err}
	}()
	client, clientErr := runClient(ctx, result.Address, clientConf)
	server := <-serverDone
	result.Peers = []PeerEvidence{client, server.peer}
	return result, errors.Join(clientErr, server.err)
}

func runClient(ctx context.Context, addr string, tlsConf *tls.Config) (e PeerEvidence, err error) {
	e.Role = "client"
	started := time.Now()
	defer func() { finishPeer(&e, started, err) }()
	remote, err := loopbackAddress(addr)
	if err != nil {
		return e, err
	}
	socket, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: 0})
	if err != nil {
		return e, err
	}
	transport := &quic.Transport{Conn: socket}
	defer func() { err = errors.Join(err, transport.Close(), socket.Close()) }()
	conn, err := transport.Dial(ctx, remote, tlsConf, config())
	if err != nil {
		return e, err
	}
	// On failure, close promptly so the single-shot server can also terminate.
	defer conn.CloseWithError(1, "oracle client ended")
	if err := checkNegotiation(conn, &e); err != nil {
		return e, err
	}
	if err := sendPair(ctx, conn, &e, 2); err != nil {
		return e, err
	}
	if err := receivePair(ctx, conn, &e, 3); err != nil {
		return e, err
	}
	if err := conn.CloseWithError(0, "oracle complete"); err != nil {
		return e, err
	}
	e.CleanClose = true
	return e, nil
}

func servePeer(ctx context.Context, listener *quic.Listener) (e PeerEvidence, err error) {
	e.Role = "server"
	started := time.Now()
	defer func() { finishPeer(&e, started, err) }()
	conn, err := listener.Accept(ctx)
	if err != nil {
		return e, err
	}
	defer conn.CloseWithError(1, "oracle server ended")
	if err := checkNegotiation(conn, &e); err != nil {
		return e, err
	}
	if err := receivePair(ctx, conn, &e, 2); err != nil {
		return e, err
	}
	if err := sendPair(ctx, conn, &e, 3); err != nil {
		return e, err
	}
	select {
	case <-ctx.Done():
		return e, ctx.Err()
	case <-conn.Context().Done():
		var app *quic.ApplicationError
		cause := context.Cause(conn.Context())
		if !errors.As(cause, &app) || !app.Remote || app.ErrorCode != 0 {
			return e, fmt.Errorf("expected client application close 0: %v", cause)
		}
	}
	e.CleanClose = true
	return e, nil
}

func finishPeer(e *PeerEvidence, started time.Time, err error) {
	e.DurationMS = time.Since(started).Milliseconds()
	e.Pass = err == nil
	if err != nil {
		e.Error = err.Error()
	}
}

func checkNegotiation(conn *quic.Conn, e *PeerEvidence) error {
	state := conn.ConnectionState()
	e.ALPN = state.TLS.NegotiatedProtocol
	e.TLSVersion = state.TLS.Version
	e.LocalSupport = state.SupportsStreamResetPartialDelivery.Local
	e.RemoteSupport = state.SupportsStreamResetPartialDelivery.Remote
	e.ExplicitCAVerified = len(state.TLS.VerifiedChains) > 0
	if e.ALPN != alpn || e.TLSVersion != tls.VersionTLS13 || !e.LocalSupport || !e.RemoteSupport {
		return errors.New("ALPN, TLS 1.3, or partial-delivery negotiation failed")
	}
	if e.Role == "client" && !e.ExplicitCAVerified {
		return errors.New("server certificate was not CA-verified")
	}
	return nil
}

func sendPair(ctx context.Context, conn *quic.Conn, e *PeerEvidence, first quic.StreamID) error {
	deadline, _ := ctx.Deadline()
	reset, err := conn.OpenUniStreamSync(ctx)
	if err != nil {
		return err
	}
	e.SentResetID = uint64(reset.StreamID())
	if reset.StreamID() != first {
		return errors.New("unexpected outgoing reset stream ID")
	}
	if err := reset.SetWriteDeadline(deadline); err != nil {
		return err
	}
	if n, err := io.WriteString(reset, prefix); err != nil || n != len(prefix) {
		return fmt.Errorf("write reliable prefix: count %d, error %v", n, err)
	}
	// The boundary applies only to the prefix; the suffix may race cancellation.
	// https://github.com/quic-go/quic-go/blob/8d34dbcccc219375fa9fbaa9b7b22caeebd7d49d/send_stream.go#L621-L625
	reset.SetReliableBoundary()
	if n, err := reset.Write(bytes.Repeat([]byte{'x'}, optionalSize)); err != nil || n != optionalSize {
		return fmt.Errorf("write optional suffix: count %d, error %v", n, err)
	}
	e.ResetBytesWritten, e.ReliableSize = len(prefix)+optionalSize, len(prefix)
	reset.CancelWrite(resetCode)
	sibling, err := conn.OpenUniStreamSync(ctx)
	if err != nil {
		return err
	}
	e.SentHealthyID = uint64(sibling.StreamID())
	if sibling.StreamID() != first+4 {
		return errors.New("unexpected outgoing sibling stream ID")
	}
	if err := sibling.SetWriteDeadline(deadline); err != nil {
		return err
	}
	if n, err := io.WriteString(sibling, healthy); err != nil || n != len(healthy) {
		return fmt.Errorf("write sibling: count %d, error %v", n, err)
	}
	return sibling.Close()
}

func receivePair(ctx context.Context, conn *quic.Conn, e *PeerEvidence, first quic.StreamID) error {
	deadline, _ := ctx.Deadline()
	reset, err := conn.AcceptUniStream(ctx)
	if err != nil {
		return err
	}
	e.ReceivedResetID = uint64(reset.StreamID())
	if reset.StreamID() != first {
		return errors.New("unexpected incoming reset stream ID")
	}
	if err := reset.SetReadDeadline(deadline); err != nil {
		return err
	}
	e.Reset, err = readReset(reset, reset.StreamID())
	if err != nil {
		return err
	}
	e.PrefixHex = hex.EncodeToString([]byte(prefix))
	sibling, err := conn.AcceptUniStream(ctx)
	if err != nil {
		return err
	}
	e.ReceivedHealthyID = uint64(sibling.StreamID())
	if sibling.StreamID() != first+4 {
		return errors.New("unexpected incoming sibling stream ID")
	}
	if err := sibling.SetReadDeadline(deadline); err != nil {
		return err
	}
	if err := readHealthy(sibling); err != nil {
		return err
	}
	e.HealthyHex, e.HealthyEOF = hex.EncodeToString([]byte(healthy)), true
	return nil
}
