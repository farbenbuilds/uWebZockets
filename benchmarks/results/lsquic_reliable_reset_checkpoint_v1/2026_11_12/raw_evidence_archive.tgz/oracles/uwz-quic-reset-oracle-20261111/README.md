# Local QUIC reliable-reset oracle

External verification tool only. Nothing here is a µWebZockets library or build dependency.

The local replace in `go.mod` selects the exact official quic-go source revision
`8d34dbcccc219375fa9fbaa9b7b22caeebd7d49d`. Its separately verified archive SHA256 is
`cf7ac1c2b5e224a58891d17c4add0c7a0f7ca981f8c6693f9243985851703093`.
`evidence/archive-provenance.json` retains the supplied provenance;
`evidence/pinned-source-files.sha256` hashes every extracted source file.
`evidence/artifacts.sha256` hashes that manifest, the oracle sources, module files,
and executable. No quic-go source was modified.

`go-local.sh` uses Go 1.26.8 with GOTOOLCHAIN=local, GOENV=off, GOSUMDB=sum.golang.org,
and GOPATH/GOMODCACHE/GOCACHE/TMPDIR entirely under this directory. `go.sum` is retained.
The `v0.0.0` requirement is a local replacement placeholder, never a remote version selection.

## Commands

Run from `/tmp/uwz-quic-reset-oracle-20261111`:

```sh
./go-local.sh test -v ./...
./go-local.sh vet ./...
./go-local.sh mod verify
./go-local.sh build -buildvcs=false -trimpath -o reset-oracle .
./reset-oracle selftest
./reset-oracle server --listen 127.0.0.1:4433 --cert pki-708540879/server.pem --key pki-708540879/server.key
./reset-oracle client --addr 127.0.0.1:4433 --ca pki-708540879/ca.pem
```

All listed checks and the actual control runs exited 0; exact commands and logs are
listed in `evidence/commands.json`. An initial build failed because VCS stamping
could not obtain git status from the temporary source context. The archive-based
build explicitly omits VCS stamping and retains source hashes instead.

Selftest generates a new private test CA and localhost server certificate, writes
them in a private temporary directory here, and records the path in JSON. The
retained passing run's files are `pki-708540879/ca.pem`, `server.pem`, `server.key`.
The certificate is valid 24 hours from generation on 2026-11-11. Client verification
uses only the supplied CA, ServerName `localhost`, and TLS 1.3; no insecure bypass.
Both roles bind literal IPv4 loopback addresses only. Whole-exchange context and
stream deadlines default to 10 seconds, with a maximum configurable timeout of 1 minute.

## Native peer contract

QUIC v1, TLS 1.3, ALPN `uwz-reset-test/1`. Both peers must advertise draft-09 reliable
reset support (TP 0x1d, RESET_STREAM_AT 0x24). The oracle requires local and remote
`SupportsStreamResetPartialDelivery` to be true.

Client starts, sending two unidirectional streams:

1. ID 2 writes exactly 33 ASCII bytes `uwz-reset-test/1 reliable prefix\n`, calls
   `SetReliableBoundary()`, writes 4096 ASCII `x` bytes, then `CancelWrite(0x175)`.
2. ID 6 writes exactly 33 ASCII bytes `uwz-reset-test/1 healthy sibling\n`, then FIN.

The server validates both, then mirrors the pair on ID 3 and ID 7. The receiver must
observe the entire exact reliable prefix, then zero to 4096 optional `x` bytes,
then a remote stream error with code 373 (`0x175`) and the correct stream ID.
EOF, any other bytes, local reset, or wrong code fail. The healthy stream must
contain exactly its 33 bytes and EOF. After validating the server pair, the client
closes the connection with application code 0; the server waits for that remote
close before success. Logical reset bytes written are 4129; quic-go may discard
its last unreserved buffered STREAM frame, so exact wire final_size is not claimed.

JSON includes negotiated support, TLS/ALPN, CA verification, stream IDs, verified
payload hex, optional bytes observed, exact reset error, healthy EOF, and teardown.
Server emits one readiness JSON line before the final result. Failure exits 1.

## Scope and evidence limits

`evidence/selftest.json` is a passing pinned-quic-go vs pinned-quic-go control run:
client observed 0 optional bytes; server observed 2507. Independent CLI processes
also passed (`cli-client.json`, `cli-server.jsonl`). These runs establish oracle
operation; they do not establish lsquic interoperability, loss recovery, or
reordering behavior. Native interoperability remains a separate pending run.
No fault injection, benchmark, production changes, root build changes, or remote
git writes were performed.

Pinned official API sources:

- https://github.com/quic-go/quic-go/blob/8d34dbcccc219375fa9fbaa9b7b22caeebd7d49d/interface.go#L193-L195
- https://github.com/quic-go/quic-go/blob/8d34dbcccc219375fa9fbaa9b7b22caeebd7d49d/interface.go#L222-L227
- https://github.com/quic-go/quic-go/blob/8d34dbcccc219375fa9fbaa9b7b22caeebd7d49d/send_stream.go#L621-L625
- https://github.com/quic-go/quic-go/blob/8d34dbcccc219375fa9fbaa9b7b22caeebd7d49d/send_stream.go#L654-L660

The stream checker tests first failed against unimplemented checker stubs
(`test-red.log` exit 1), then passed after implementation (`test-green.log`,
`test.log`, exit 0). They reject corrupt/truncated/excess payloads, EOF instead of
reset, local resets, wrong error codes, and wrong stream IDs. Review found no
remaining blocker for the documented localhost oracle scope.
