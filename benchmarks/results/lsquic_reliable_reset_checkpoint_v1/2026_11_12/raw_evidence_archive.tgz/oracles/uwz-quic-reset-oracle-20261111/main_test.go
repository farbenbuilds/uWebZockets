package main

import (
	"bytes"
	"io"
	"strings"
	"testing"

	quic "github.com/quic-go/quic-go"
)

type terminalReader struct{ err error }

func (r terminalReader) Read([]byte) (int, error) { return 0, r.err }

// A checker that accepts EOF, a truncated prefix, corrupt optional bytes, or a
// local/wrong reset would turn a transport failure into false passing evidence.
func TestResetCheckerRequiresPrefixAndExactRemoteError(t *testing.T) {
	for _, n := range []int{0, 1, 4096} {
		r := io.MultiReader(strings.NewReader("uwz-reset-test/1 reliable prefix\n"+strings.Repeat("x", n)), terminalReader{&quic.StreamError{StreamID: 3, ErrorCode: 373, Remote: true}})
		got, err := readReset(r, 3)
		if err != nil || got.OptionalBytes != n || !got.Remote || got.Code != 373 {
			t.Fatalf("optional %d: got %+v, err %v", n, got, err)
		}
	}
	cases := []struct {
		name string
		body string
		err  error
	}{
		{"EOF", "uwz-reset-test/1 reliable prefix\n", io.EOF},
		{"truncated", "uwz-reset-test/1 reliable prefix", &quic.StreamError{StreamID: 3, ErrorCode: 373, Remote: true}},
		{"wrong prefix", "uwz-reset-test/1 reliable PrefiX\n", &quic.StreamError{StreamID: 3, ErrorCode: 373, Remote: true}},
		{"corrupt optional", "uwz-reset-test/1 reliable prefix\nxy", &quic.StreamError{StreamID: 3, ErrorCode: 373, Remote: true}},
		{"excess optional", "uwz-reset-test/1 reliable prefix\n" + strings.Repeat("x", 4097), &quic.StreamError{StreamID: 3, ErrorCode: 373, Remote: true}},
		{"local reset", "uwz-reset-test/1 reliable prefix\n", &quic.StreamError{StreamID: 3, ErrorCode: 373}},
		{"wrong code", "uwz-reset-test/1 reliable prefix\n", &quic.StreamError{StreamID: 3, ErrorCode: 374, Remote: true}},
		{"wrong stream", "uwz-reset-test/1 reliable prefix\n", &quic.StreamError{StreamID: 7, ErrorCode: 373, Remote: true}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if _, err := readReset(io.MultiReader(strings.NewReader(tc.body), terminalReader{tc.err}), 3); err == nil {
				t.Fatal("accepted invalid reset stream")
			}
		})
	}
}

func TestHealthyCheckerRequiresExactBytesAndEOF(t *testing.T) {
	if err := readHealthy(strings.NewReader("uwz-reset-test/1 healthy sibling\n")); err != nil {
		t.Fatal(err)
	}
	for _, body := range []string{"", "uwz-reset-test/1 healthy sibling", "uwz-reset-test/1 healthy sibling\nextra"} {
		if err := readHealthy(strings.NewReader(body)); err == nil {
			t.Fatalf("accepted %q", body)
		}
	}
	r := io.MultiReader(bytes.NewBufferString("uwz-reset-test/1 healthy sibling\n"), terminalReader{&quic.StreamError{StreamID: 7, ErrorCode: 373, Remote: true}})
	if err := readHealthy(r); err == nil {
		t.Fatal("accepted reset instead of sibling EOF")
	}
}
