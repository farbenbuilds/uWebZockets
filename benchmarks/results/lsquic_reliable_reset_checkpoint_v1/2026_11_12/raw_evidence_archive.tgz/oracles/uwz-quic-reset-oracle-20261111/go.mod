module uwz.local/reset-oracle

go 1.26.0

require github.com/quic-go/quic-go v0.0.0

require (
	golang.org/x/crypto v0.54.0 // indirect
	golang.org/x/net v0.56.0 // indirect
	golang.org/x/sys v0.47.0 // indirect
)

replace github.com/quic-go/quic-go => /tmp/uwz-quic-go-8d34dbcccc219375fa9fbaa9b7b22caeebd7d49d
