#!/bin/sh
set -eu
oracle_dir=/tmp/uwz-quic-reset-oracle-20261111
exec env GOENV=off GOTOOLCHAIN=local GOPATH="$oracle_dir/gopath" \
  GOMODCACHE="$oracle_dir/gopath/pkg/mod" GOCACHE="$oracle_dir/cache" \
  TMPDIR="$oracle_dir/tmp" GOPROXY=https://proxy.golang.org \
  GOSUMDB=sum.golang.org /usr/local/go/bin/go "$@"
