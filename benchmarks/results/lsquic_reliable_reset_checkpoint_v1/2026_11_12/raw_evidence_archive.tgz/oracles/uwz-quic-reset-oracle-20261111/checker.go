package main

import (
	"bytes"
	"errors"
	"fmt"
	"io"

	quic "github.com/quic-go/quic-go"
)

const (
	alpn                              = "uwz-reset-test/1"
	prefix                            = "uwz-reset-test/1 reliable prefix\n"
	healthy                           = "uwz-reset-test/1 healthy sibling\n"
	optionalSize                      = 4096
	resetCode    quic.StreamErrorCode = 0x175
)

type ResetObservation struct {
	OptionalBytes int    `json:"optional_bytes_observed"`
	Remote        bool   `json:"remote_reset"`
	Code          uint64 `json:"reset_code"`
}

func readReset(r io.Reader, id quic.StreamID) (ResetObservation, error) {
	data, err := io.ReadAll(io.LimitReader(r, int64(len(prefix)+optionalSize+1)))
	got := ResetObservation{}
	if len(data) < len(prefix) || !bytes.Equal(data[:len(prefix)], []byte(prefix)) {
		return got, fmt.Errorf("reset prefix mismatch: received %d bytes (%x)", len(data), data)
	}
	got.OptionalBytes = len(data) - len(prefix)
	if got.OptionalBytes > optionalSize || !bytes.Equal(data[len(prefix):], bytes.Repeat([]byte{'x'}, got.OptionalBytes)) {
		return got, errors.New("optional suffix exceeds 4096 bytes or contains non-x bytes")
	}
	var reset *quic.StreamError
	if !errors.As(err, &reset) || !reset.Remote || reset.ErrorCode != resetCode || reset.StreamID != id {
		return got, fmt.Errorf("expected remote stream %d reset code 373; received %v", id, err)
	}
	got.Remote = reset.Remote
	got.Code = uint64(reset.ErrorCode)
	return got, nil
}

func readHealthy(r io.Reader) error {
	data, err := io.ReadAll(io.LimitReader(r, int64(len(healthy)+1)))
	if err != nil {
		return fmt.Errorf("sibling ended without EOF: %w", err)
	}
	if !bytes.Equal(data, []byte(healthy)) {
		return fmt.Errorf("sibling mismatch: %x", data)
	}
	return nil
}
