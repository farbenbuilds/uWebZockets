package main

import (
	"bytes"
	"encoding/binary"
	"errors"
)

const payloadMagic = "UWZWT16\x00"

func makeDatagram(source, session uint16, sequence uint32) (payload [16]byte) {
	copy(payload[:8], payloadMagic)
	binary.BigEndian.PutUint16(payload[8:10], source)
	binary.BigEndian.PutUint16(payload[10:12], session)
	binary.BigEndian.PutUint32(payload[12:16], sequence)
	return payload
}

func parseDatagram(payload []byte) (uint16, uint16, uint32, error) {
	if len(payload) != 16 || !bytes.Equal(payload[:8], []byte(payloadMagic)) {
		return 0, 0, 0, errors.New("invalid 16-byte datagram size or magic")
	}
	return binary.BigEndian.Uint16(payload[8:10]), binary.BigEndian.Uint16(payload[10:12]), binary.BigEndian.Uint32(payload[12:16]), nil
}
