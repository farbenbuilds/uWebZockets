package main

import (
	"bytes"
	"testing"
)

func TestDatagramCarriesIndependentSourceSessionAndSequence(t *testing.T) {
	want := []byte{'U', 'W', 'Z', 'W', 'T', '1', '6', 0, 0x12, 0x34, 0, 2, 0, 0, 0, 3}
	got := makeDatagram(0x1234, 2, 3)
	if !bytes.Equal(got[:], want) {
		t.Fatalf("wire payload %x, want %x", got, want)
	}
	source, session, seq, err := parseDatagram(want)
	if err != nil || source != 0x1234 || session != 2 || seq != 3 {
		t.Fatalf("decoded %d/%d/%d: %v", source, session, seq, err)
	}
}

func TestDatagramRejectsCorruptionAndWrongSize(t *testing.T) {
	for _, bad := range [][]byte{
		{}, []byte("UWZWT16\x00\x00\x01\x00\x01\x00\x00\x00"),
		[]byte("UWZWT15\x00\x00\x01\x00\x01\x00\x00\x00\x00"),
		[]byte("UWZWT16\x00\x00\x01\x00\x01\x00\x00\x00\x00X"),
	} {
		if _, _, _, err := parseDatagram(bad); err == nil {
			t.Fatalf("accepted %x", bad)
		}
	}
}
