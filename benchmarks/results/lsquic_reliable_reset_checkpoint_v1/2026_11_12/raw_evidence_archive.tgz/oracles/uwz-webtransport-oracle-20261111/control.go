package main

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/http"
	"strconv"
	"sync"

	quic "github.com/quic-go/quic-go"
	"github.com/quic-go/quic-go/http3"
	wt "github.com/quic-go/webtransport-go"
)

type ControlAdmission struct {
	Ordinal           int               `json:"session_ordinal"`
	Protocol          string            `json:"received_connect_protocol"`
	Origin            string            `json:"received_origin"`
	ConnectionOrdinal int               `json:"connection_ordinal"`
	PeerSettings      map[uint64]uint64 `json:"received_peer_settings"`
	DatagramsReceived int               `json:"datagrams_received"`
}

type ControlEvidence struct {
	AcceptedConnections    int                `json:"accepted_connections"`
	Admissions             []ControlAdmission `json:"admissions"`
	SameConnectionHealth   int                `json:"same_connection_health_requests"`
	ServerDeliveryVerified bool               `json:"server_delivery_verified"`
	ServeJoined            bool               `json:"serve_joined"`
	Error                  string             `json:"error,omitempty"`
}

type controlState struct {
	mutex    sync.Mutex
	evidence ControlEvidence
	err      error
}

type connectionKey struct{}

func runControlCase(ctx context.Context, o Options) (result CaseEvidence, err error) {
	tlsConf, err := serverTLS(o.Cert, o.Key)
	if err != nil {
		return result, err
	}
	socket, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1)})
	if err != nil {
		return result, err
	}
	transport := &quic.Transport{Conn: socket}
	defer func() { err = errors.Join(err, transport.Close(), socket.Close()) }()
	listener, err := transport.Listen(tlsConf, quicConfig())
	if err != nil {
		return result, err
	}
	defer func() { err = errors.Join(err, listener.Close()) }()
	o.URL = "https://" + listener.Addr().String() + "/wt"
	o.Origin = "https://" + listener.Addr().String()
	state := &controlState{}
	h3 := &http3.Server{TLSConfig: tlsConf, EnableDatagrams: true, ConnContext: func(c context.Context, _ *quic.Conn) context.Context { return context.WithValue(c, connectionKey{}, 1) }}
	server := &wt.Server{H3: h3, Config: flowConfig(o.Flow), CheckOrigin: func(r *http.Request) bool {
		return r.Header.Get("Origin") == o.Origin && r.Host == listener.Addr().String()
	}}
	h3.Handler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { serveControl(ctx, server, state, o, w, r) })
	defer func() { err = errors.Join(err, server.Close()) }()
	serveDone := make(chan error, 1)
	go func() {
		conn, acceptErr := listener.Accept(ctx)
		if acceptErr != nil {
			serveDone <- acceptErr
			return
		}
		state.mutex.Lock()
		state.evidence.AcceptedConnections++
		state.mutex.Unlock()
		stop := context.AfterFunc(ctx, func() { conn.CloseWithError(quic.ApplicationErrorCode(http3.ErrCodeNoError), "control deadline") })
		defer stop()
		serveDone <- server.ServeQUICConn(conn)
	}()
	result.Client, err = runClient(ctx, o, true)
	serveErr := <-serveDone
	state.mutex.Lock()
	state.evidence.ServeJoined = true
	if state.evidence.AcceptedConnections != 1 || len(state.evidence.Admissions) != o.Sessions || state.evidence.SameConnectionHealth != 1 {
		state.err = errors.Join(state.err, errors.New("control connection/admission/health counts mismatch"))
	}
	for _, admission := range state.evidence.Admissions {
		if admission.DatagramsReceived != 4 {
			state.err = errors.Join(state.err, errors.New("control received datagram count mismatch"))
		}
	}
	state.evidence.ServerDeliveryVerified = state.err == nil && err == nil
	if state.err != nil {
		state.evidence.Error = state.err.Error()
	}
	copy := state.evidence
	result.Control = &copy
	err = errors.Join(err, state.err)
	state.mutex.Unlock()
	// A normal H3_NO_ERROR peer close is the expected ServeQUICConn termination.
	var app *quic.ApplicationError
	if serveErr != nil && !(errors.As(serveErr, &app) && app.Remote && app.ErrorCode == quic.ApplicationErrorCode(http3.ErrCodeNoError)) && !errors.Is(serveErr, http.ErrServerClosed) {
		err = errors.Join(err, serveErr)
	}
	return result, err
}

func serveControl(ctx context.Context, server *wt.Server, state *controlState, o Options, w http.ResponseWriter, r *http.Request) {
	connection, _ := r.Context().Value(connectionKey{}).(int)
	if r.Method == http.MethodGet && r.URL.Path == o.HealthPath {
		state.mutex.Lock()
		if connection != 1 {
			state.err = errors.Join(state.err, errors.New("health request connection mismatch"))
		}
		state.evidence.SameConnectionHealth++
		state.mutex.Unlock()
		w.WriteHeader(http.StatusOK)
		if _, err := w.Write([]byte("uwz-wt-healthy\n")); err != nil {
			controlError(state, err)
		}
		return
	}
	if r.Method != http.MethodConnect || r.URL.Path != "/wt" || r.Header.Get("Origin") != o.Origin {
		http.Error(w, "request rejected", http.StatusForbidden)
		controlError(state, errors.New("control request or Origin rejected"))
		return
	}
	ordinal, err := strconv.Atoi(r.Header.Get("X-Uwz-Oracle-Session"))
	if err != nil || ordinal < 1 || ordinal > o.Sessions {
		http.Error(w, "bad ordinal", http.StatusBadRequest)
		controlError(state, errors.New("invalid control session ordinal"))
		return
	}
	session, err := server.Upgrade(w, r)
	if err != nil {
		controlError(state, err)
		return
	}
	settings := w.(http3.Settingser).Settings()
	other := make(map[uint64]uint64, len(settings.Other))
	for k, v := range settings.Other {
		other[k] = v
	}
	if connection != 1 || r.Proto != "webtransport-h3" || other[settingsWTEnabled] != 1 || !settings.EnableDatagrams {
		controlError(state, errors.New("actual received protocol or SETTINGS_WT_ENABLED mismatch"))
		return
	}
	positiveFC := other[0x2b64] > 0 || other[0x2b65] > 0 || other[0x2b61] > 0
	if positiveFC != (o.Flow == "on") {
		controlError(state, errors.New("actual received flow-control settings mismatch"))
		return
	}
	state.mutex.Lock()
	index := len(state.evidence.Admissions)
	state.evidence.Admissions = append(state.evidence.Admissions, ControlAdmission{Ordinal: ordinal, Protocol: r.Proto, Origin: r.Header.Get("Origin"), ConnectionOrdinal: connection, PeerSettings: other})
	state.mutex.Unlock()
	seen := uint32(0)
	for n := 0; n < 4; n++ {
		payload, err := session.ReceiveDatagram(ctx)
		if err != nil {
			controlError(state, err)
			return
		}
		source, id, sequence, err := parseDatagram(payload)
		if err != nil || source != uint16(o.Source) || id != uint16(ordinal) || sequence >= 4 || seen&(1<<sequence) != 0 {
			controlError(state, fmt.Errorf("control payload mismatch in session ordinal %d", ordinal))
			return
		}
		seen |= 1 << sequence
		state.mutex.Lock()
		state.evidence.Admissions[index].DatagramsReceived++
		state.mutex.Unlock()
		if err := session.SendDatagram(payload); err != nil {
			controlError(state, err)
			return
		}
	}
}

func controlError(state *controlState, err error) {
	state.mutex.Lock()
	state.err = errors.Join(state.err, err)
	state.mutex.Unlock()
}
