# WebTransport draft-16 external oracle

This isolated test tool uses official webtransport-go commit
`2a2b547d91a8a70e313e7ce61538b066554021b5` through a local replacement of the
unchanged extracted source. Its supplied archive SHA256 is
`5ad87c03fed6cfeed41eed04124c7b8aed510b8267792bca688865fbf8a78eba`.
The README at that revision explicitly implements draft-16.

quic-go is the checksum-verified module `v0.62.0`. Retained download metadata
proves `Origin.Hash` is commit `793f74d8e03368c5aded128af6f48d21dbb47f73`;
the annotated tag object is not used as a commit pin. Module checksum:
`h1:ZHDjCk5OacATwGvs8PWE97CTvX7AqZiVoW7++ZOXTf8=`.
The metadata was parsed and its version, immutable origin hash, and checksum
compared against exact expected values; see `evidence/origin-verification.json`.
`go.sum` and full downloaded-source hash manifests are retained.

This tool adds no dependency or requirement to the root library/build. No root
repository, fork, scaffold, or frozen dependency source was edited. Go 1.26.8
runs via `go-local.sh` with GOENV=off, GOTOOLCHAIN=local, GOSUMDB=sum.golang.org,
and GOPATH/GOMODCACHE/GOCACHE/TMPDIR confined to this directory.

## CLI for native integration

```sh
./wt-oracle client --url https://127.0.0.1:PORT/wt \
  --ca /tmp/uwz-quic-reset-oracle-20261111/pki-708540879/ca.pem \
  --origin https://127.0.0.1:PORT --source 1 \
  --sessions 1 --flow-control off --health-path /health
```

Use `--sessions 2 --flow-control on` for the second scenario. All sessions and
the final GET `/health` use the same explicitly owned QUIC connection through
`Transport.NewClientConn` and `ClientConn.RoundTrip`. There is no second HTTP
transport, connection pool, or reconnect fallback. Flow-control-on configures
MaxIncomingStreams=1, MaxIncomingUniStreams=1, MaxIncomingData=4096; the native
server must also advertise positive WebTransport flow-control settings for
bilateral negotiation. Native harness evidence must establish its actual
settings and per-session behavior; client JSON calls this local configuration.

The client requires status 200 admission, TLS 1.3, h3 ALPN, an explicitly trusted
server CA, QUIC DATAGRAM, and stream reset partial-delivery support. Its Origin
must exactly match the URL's HTTPS authority. Only literal `127.0.0.1`, an
explicit nonzero port, and same-connection health paths are accepted. The TLS
ServerName is `localhost`, matching the supplied test certificate SAN. No global
trust store or insecure verification bypass is used.

Each session sends four exact 16-byte datagrams. Byte layout:

| Offset | Field |
| --- | --- |
| 0..7 | ASCII `UWZWT16` followed by byte zero |
| 8..9 | source identifier, unsigned 16-bit big endian |
| 10..11 | session ordinal 1 or 2, unsigned 16-bit big endian |
| 12..15 | sequence 0, 1, 2, or 3, unsigned 32-bit big endian |

Session ordinals are application labels, not invented wire session IDs. The
CONNECT request also carries `X-Uwz-Oracle-Session`. Native mode requires no
echo and opens no application child streams. Root's datagram-only App can
verify delivery through its inbound datagram/context/metrics seam.

Client-mode JSON always says `server_delivery_verified:false`, with scope
`admission_and_enqueue_only`. Successful SendDatagram means enqueue, not receipt.
Native acceptance therefore requires independent server source/session/sequence
observations. HTTP health requires status 200 and a response body of at most
4096 bytes; response contents are not logged. All sessions close with code 0,
then the QUIC connection closes with H3_NO_ERROR. A context deadline also forces
connection closure so session-close waits are bounded. The default case timeout
is 10 seconds, configurable only within (0, 1 minute].

## Passing control test

```sh
./go-local.sh test -v ./...
./go-local.sh vet ./...
./go-local.sh mod verify
./go-local.sh build -buildvcs=false -trimpath -o wt-oracle .
./wt-oracle selftest
```

Every command above exited 0. Exact invocations, logs, and prior intentional RED
failure are recorded in `evidence/commands.json`. No broad check was rerun after
passing. VCS stamping is explicitly disabled for the temporary archive-based
tool; immutable source and executable hashes provide provenance instead.

The selftest creates fresh localhost listeners and runs two cases: one session
with session flow control off, then two concurrent sessions with it on. Each
case accepts exactly one connection, uses exact same-origin admission policy,
observes four correct datagrams per session, echoes them only as a control, and
serves one same-connection health request. The client checks the exact echo set
without assuming datagram order. Both cases passed and joined the server serve
loop; owned listeners, transports, sockets, sessions, and connections close.

The control HTTP handler records actual received peer settings via the public
http3.Settingser interface and actual received CONNECT `r.Proto`. It requires
SETTINGS_WT_ENABLED `0x2c7cf000` = 1 and `webtransport-h3`. The enabled case also
observed setting `0x2b61` = 4096, `0x2b64` = 1, and `0x2b65` = 1. No legacy
WebTransport constant is copied into the client. The official control server
may advertise its compatibility setting; that is not the negotiated proof.

`evidence/selftest.json` records CONNECT 200, four verified echoes per session,
HTTP 200 health, CA/TLS/QUIC negotiation, closed sessions/connections, and server
join. It explicitly retains `product_interop_verified:false`: this is pinned
Go-vs-Go oracle validation. Native/product interoperability remains pending.
Loss recovery, child-stream behavior, and production performance are not tested.

Selftest reads the prior oracle PKI without copying or archiving private keys.
The certificate validity check passed with at least one hour remaining:
notBefore Nov 11 15:23:15 2026 GMT; notAfter Nov 12 15:24:15 2026 GMT. Provide
`selftest --ca FILE --cert FILE --key FILE` for later runs with renewed test PKI.
The tiny TLS helper in `tls.go` is adapted with attribution from the prior
isolated reset oracle; no certificate generation is included here.

## Source and evidence map

- `main.go`: CLI, explicit connection ownership, session/datagram client, health.
- `control.go`: optional Go server control, actual settings/protocol observations.
- `payload.go`, `payload_test.go`: bounded wire payload and independent fixtures.
- `tls.go`: explicit CA trust and provided control certificate loading.
- `evidence/quic-go-download.json`, `origin-verification.json`: immutable origin.
- `evidence/webtransport-archive-provenance.json`: supplied archive provenance.
- `evidence/*source-files.sha256`: complete frozen dependency source manifests.
- `evidence/artifacts.sha256`: oracle, executable, manifests, and module hashes.

Verified pinned official APIs:

- https://github.com/quic-go/webtransport-go/blob/2a2b547d91a8a70e313e7ce61538b066554021b5/client_conn.go
- https://github.com/quic-go/webtransport-go/blob/2a2b547d91a8a70e313e7ce61538b066554021b5/config.go
- https://github.com/quic-go/webtransport-go/blob/2a2b547d91a8a70e313e7ce61538b066554021b5/protocol.go
- https://github.com/quic-go/webtransport-go/blob/2a2b547d91a8a70e313e7ce61538b066554021b5/server.go
- https://github.com/quic-go/webtransport-go/blob/2a2b547d91a8a70e313e7ce61538b066554021b5/session.go
- https://github.com/quic-go/quic-go/blob/793f74d8e03368c5aded128af6f48d21dbb47f73/http3/body.go
