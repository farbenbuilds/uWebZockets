package main

import (
	"crypto/tls"
	"crypto/x509"
	"errors"
	"os"
)

// Adapted from the isolated reset oracle's tls.go; only ALPN and TLS bounds differ.
// No certificate/key generation or key archival occurs in this tool.
func clientTLS(path string) (*tls.Config, error) {
	if path == "" {
		return nil, errors.New("--ca is required")
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	roots := x509.NewCertPool()
	if !roots.AppendCertsFromPEM(data) {
		return nil, errors.New("CA file contains no PEM certificate")
	}
	return &tls.Config{RootCAs: roots, ServerName: "localhost", NextProtos: []string{"h3"}, MinVersion: tls.VersionTLS13, MaxVersion: tls.VersionTLS13}, nil
}

func serverTLS(certPath, keyPath string) (*tls.Config, error) {
	cert, err := tls.LoadX509KeyPair(certPath, keyPath)
	if err != nil {
		return nil, err
	}
	return &tls.Config{Certificates: []tls.Certificate{cert}, NextProtos: []string{"h3"}, MinVersion: tls.VersionTLS13, MaxVersion: tls.VersionTLS13}, nil
}
