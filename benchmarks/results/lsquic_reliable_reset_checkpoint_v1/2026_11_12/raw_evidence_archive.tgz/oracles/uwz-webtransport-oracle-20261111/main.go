package main

import (
	"context"
	"crypto/tls"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"

	quic "github.com/quic-go/quic-go"
	"github.com/quic-go/quic-go/http3"
	wt "github.com/quic-go/webtransport-go"
)

const (
	wtRevision               = "2a2b547d91a8a70e313e7ce61538b066554021b5"
	quicRevision             = "793f74d8e03368c5aded128af6f48d21dbb47f73"
	settingsWTEnabled uint64 = 0x2c7cf000
	pkiDefault               = "/tmp/uwz-quic-reset-oracle-20261111/pki-708540879"
)

type Options struct {
	URL, Origin, CA, Cert, Key, HealthPath, Flow string
	Source, Sessions                             int
	Timeout                                      time.Duration
}

type SessionEvidence struct {
	Ordinal           int      `json:"session_ordinal"`
	Status            int      `json:"connect_status"`
	AdmissionVerified bool     `json:"admission_verified"`
	DatagramsEnqueued int      `json:"datagrams_enqueued"`
	DatagramHex       []string `json:"datagram_hex"`
	EchoesVerified    int      `json:"control_echoes_verified"`
	Closed            bool     `json:"closed"`
}

type ClientEvidence struct {
	URL                    string            `json:"url"`
	Origin                 string            `json:"origin"`
	FlowControl            string            `json:"flow_control_config"`
	TLSVersion             uint16            `json:"tls_version"`
	ALPN                   string            `json:"alpn"`
	ExplicitCAVerified     bool              `json:"explicit_ca_verified"`
	LocalDatagrams         bool              `json:"local_datagrams"`
	RemoteDatagrams        bool              `json:"remote_datagrams"`
	LocalPartialReset      bool              `json:"local_partial_reset"`
	RemotePartialReset     bool              `json:"remote_partial_reset"`
	ConnectionCount        int               `json:"owned_quic_connections"`
	ProtocolExpected       string            `json:"connect_protocol_expected"`
	Sessions               []SessionEvidence `json:"sessions"`
	HealthStatus           int               `json:"same_connection_health_status"`
	HealthBytes            int               `json:"health_response_bytes"`
	ServerDeliveryVerified bool              `json:"server_delivery_verified"`
	Scope                  string            `json:"verification_scope"`
	ConnectionClosed       bool              `json:"connection_closed"`
	DurationMS             int64             `json:"duration_ms"`
	Pass                   bool              `json:"pass"`
	Error                  string            `json:"error,omitempty"`
}

type CaseEvidence struct {
	Client  ClientEvidence   `json:"client"`
	Control *ControlEvidence `json:"control_server,omitempty"`
	Pass    bool             `json:"pass"`
	Error   string           `json:"error,omitempty"`
}

type Result struct {
	Mode                   string         `json:"mode"`
	WTRevision             string         `json:"webtransport_go_revision"`
	QuicRevision           string         `json:"quic_go_revision"`
	ProductInteropVerified bool           `json:"product_interop_verified"`
	Cases                  []CaseEvidence `json:"cases,omitempty"`
	Pass                   bool           `json:"pass"`
	Error                  string         `json:"error,omitempty"`
}

func main() {
	r, err := run(os.Args[1:])
	r.Pass = err == nil
	if err != nil {
		r.Error = err.Error()
	}
	if encodeErr := json.NewEncoder(os.Stdout).Encode(r); encodeErr != nil {
		fmt.Fprintln(os.Stderr, encodeErr)
		os.Exit(1)
	}
	if err != nil {
		os.Exit(1)
	}
}

func run(args []string) (Result, error) {
	r := Result{WTRevision: wtRevision, QuicRevision: quicRevision}
	if len(args) == 0 {
		return r, errors.New("usage: wt-oracle client|selftest [flags]")
	}
	r.Mode = args[0]
	o := Options{}
	f := flag.NewFlagSet(r.Mode, flag.ContinueOnError)
	f.StringVar(&o.URL, "url", "", "HTTPS URL with literal 127.0.0.1 host and explicit port")
	f.StringVar(&o.Origin, "origin", "", "explicit exact same-origin HTTPS origin")
	f.StringVar(&o.CA, "ca", "", "explicit CA PEM file")
	f.StringVar(&o.Cert, "cert", pkiDefault+"/server.pem", "selftest server certificate PEM")
	f.StringVar(&o.Key, "key", pkiDefault+"/server.key", "selftest server private key PEM")
	f.StringVar(&o.HealthPath, "health-path", "/health", "same-connection HTTP health path")
	f.StringVar(&o.Flow, "flow-control", "off", "off for one session; on for up to two")
	f.IntVar(&o.Source, "source", 1, "datagram source identifier, 1..65535")
	f.IntVar(&o.Sessions, "sessions", 1, "session count, 1..2")
	f.DurationVar(&o.Timeout, "timeout", 10*time.Second, "whole-case timeout, at most one minute")
	if err := f.Parse(args[1:]); err != nil {
		return r, err
	}
	if f.NArg() != 0 || o.Timeout <= 0 || o.Timeout > time.Minute || o.Source < 1 || o.Source > 65535 {
		return r, errors.New("invalid arguments, source, or finite timeout")
	}
	switch r.Mode {
	case "client":
		if _, err := validateClient(o); err != nil {
			return r, err
		}
		ctx, cancel := context.WithTimeout(context.Background(), o.Timeout)
		defer cancel()
		client, err := runClient(ctx, o, false)
		c := CaseEvidence{Client: client, Pass: err == nil}
		if err != nil {
			c.Error = err.Error()
		}
		r.Cases = []CaseEvidence{c}
		return r, err
	case "selftest":
		if o.CA == "" {
			o.CA = pkiDefault + "/ca.pem"
		}
		for _, flow := range []string{"off", "on"} {
			o.Flow, o.Sessions = flow, 1
			if flow == "on" {
				o.Sessions = 2
			}
			ctx, cancel := context.WithTimeout(context.Background(), o.Timeout)
			c, err := runControlCase(ctx, o)
			cancel()
			c.Pass = err == nil
			if err != nil {
				c.Error = err.Error()
			}
			r.Cases = append(r.Cases, c)
			if err != nil {
				return r, err
			}
		}
		return r, nil
	default:
		return r, errors.New("unknown mode")
	}
}

func validateClient(o Options) (*url.URL, error) {
	u, err := url.Parse(o.URL)
	if err != nil {
		return nil, err
	}
	if u.Scheme != "https" || u.Hostname() != "127.0.0.1" || u.Port() == "" || u.User != nil || u.Fragment != "" {
		return nil, errors.New("URL requires HTTPS, literal 127.0.0.1, explicit port, no credentials or fragment")
	}
	port, err := strconv.ParseUint(u.Port(), 10, 16)
	if err != nil || port == 0 {
		return nil, errors.New("invalid nonzero UDP port")
	}
	if o.Origin != "https://"+u.Host {
		return nil, errors.New("--origin must exactly equal the URL HTTPS origin")
	}
	if !strings.HasPrefix(o.HealthPath, "/") || strings.HasPrefix(o.HealthPath, "//") || strings.ContainsAny(o.HealthPath, "?#") {
		return nil, errors.New("health path must be a bounded local path without query or fragment")
	}
	if o.CA == "" || o.Sessions < 1 || o.Sessions > 2 || (o.Flow != "off" && o.Flow != "on") || (o.Flow == "off" && o.Sessions != 1) {
		return nil, errors.New("explicit CA required; flow-control off requires one session, on permits one or two")
	}
	return u, nil
}

func quicConfig() *quic.Config {
	return &quic.Config{Versions: []quic.Version{quic.Version1}, EnableDatagrams: true, EnableStreamResetPartialDelivery: true, HandshakeIdleTimeout: 3 * time.Second, MaxIdleTimeout: 10 * time.Second}
}

func flowConfig(flow string) *wt.Config {
	if flow == "off" {
		return &wt.Config{}
	}
	return &wt.Config{MaxIncomingStreams: 1, MaxIncomingUniStreams: 1, MaxIncomingData: 4096}
}

func runClient(ctx context.Context, o Options, echo bool) (e ClientEvidence, err error) {
	started := time.Now()
	e = ClientEvidence{URL: o.URL, Origin: o.Origin, FlowControl: o.Flow, ProtocolExpected: "webtransport-h3", Scope: "admission_and_enqueue_only"}
	defer func() {
		e.DurationMS = time.Since(started).Milliseconds()
		e.Pass = err == nil
		if err != nil {
			e.Error = err.Error()
		}
	}()
	u, err := validateClient(o)
	if err != nil {
		return e, err
	}
	tlsConf, err := clientTLS(o.CA)
	if err != nil {
		return e, err
	}
	remote, err := net.ResolveUDPAddr("udp4", u.Host)
	if err != nil {
		return e, err
	}
	socket, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1)})
	if err != nil {
		return e, err
	}
	transport := &quic.Transport{Conn: socket}
	defer func() { err = errors.Join(err, transport.Close(), socket.Close()) }()
	conn, err := transport.Dial(ctx, remote, tlsConf, quicConfig())
	if err != nil {
		return e, err
	}
	e.ConnectionCount = 1
	stopDeadline := context.AfterFunc(ctx, func() { conn.CloseWithError(quic.ApplicationErrorCode(http3.ErrCodeNoError), "oracle deadline") })
	defer stopDeadline()
	defer conn.CloseWithError(quic.ApplicationErrorCode(http3.ErrCodeNoError), "oracle ended")
	state := conn.ConnectionState()
	e.TLSVersion, e.ALPN = state.TLS.Version, state.TLS.NegotiatedProtocol
	e.ExplicitCAVerified = len(state.TLS.VerifiedChains) > 0
	e.LocalDatagrams, e.RemoteDatagrams = state.SupportsDatagrams.Local, state.SupportsDatagrams.Remote
	e.LocalPartialReset, e.RemotePartialReset = state.SupportsStreamResetPartialDelivery.Local, state.SupportsStreamResetPartialDelivery.Remote
	if e.TLSVersion != tls.VersionTLS13 || e.ALPN != "h3" || !e.ExplicitCAVerified || !e.LocalDatagrams || !e.RemoteDatagrams || !e.LocalPartialReset || !e.RemotePartialReset {
		return e, errors.New("TLS, h3, CA verification, DATAGRAM or partial-reset negotiation failed")
	}
	wtTransport := &wt.Transport{Config: flowConfig(o.Flow)}
	client, err := wtTransport.NewClientConn(conn)
	if err != nil {
		return e, err
	}
	defer wtTransport.Close()
	sessions := make([]*wt.Session, 0, o.Sessions)
	defer func() {
		for _, s := range sessions {
			s.CloseWithError(0, "")
		}
	}()
	for i := 1; i <= o.Sessions; i++ {
		entry := SessionEvidence{Ordinal: i}
		headers := http.Header{"Origin": []string{o.Origin}, "X-Uwz-Oracle-Session": []string{strconv.Itoa(i)}}
		response, session, dialErr := client.Dial(ctx, o.URL, headers)
		if response != nil {
			entry.Status = response.StatusCode
		}
		e.Sessions = append(e.Sessions, entry)
		if dialErr != nil {
			return e, dialErr
		}
		if response.StatusCode != http.StatusOK {
			return e, fmt.Errorf("CONNECT requires status 200, received %d", response.StatusCode)
		}
		sessions = append(sessions, session)
		e.Sessions[i-1].AdmissionVerified = true
	}
	for i, session := range sessions {
		for seq := uint32(0); seq < 4; seq++ {
			payload := makeDatagram(uint16(o.Source), uint16(i+1), seq)
			if err := session.SendDatagram(payload[:]); err != nil {
				return e, err
			}
			e.Sessions[i].DatagramsEnqueued++
			e.Sessions[i].DatagramHex = append(e.Sessions[i].DatagramHex, hex.EncodeToString(payload[:]))
		}
		if !echo {
			continue
		}
		seen := uint32(0)
		for n := 0; n < 4; n++ {
			payload, err := session.ReceiveDatagram(ctx)
			if err != nil {
				return e, err
			}
			source, ordinal, seq, err := parseDatagram(payload)
			if err != nil || source != uint16(o.Source) || ordinal != uint16(i+1) || seq >= 4 || seen&(1<<seq) != 0 {
				return e, errors.New("control echo payload mismatch or duplicate")
			}
			seen |= 1 << seq
			e.Sessions[i].EchoesVerified++
		}
	}
	health := &url.URL{Scheme: "https", Host: u.Host, Path: o.HealthPath}
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, health.String(), nil)
	if err != nil {
		return e, err
	}
	response, err := client.RoundTrip(request)
	if err != nil {
		return e, err
	}
	body, readErr := io.ReadAll(io.LimitReader(response.Body, 4097))
	closeErr := response.Body.Close()
	e.HealthStatus, e.HealthBytes = response.StatusCode, len(body)
	if readErr != nil || closeErr != nil {
		return e, errors.Join(readErr, closeErr)
	}
	if response.StatusCode != http.StatusOK || len(body) > 4096 {
		return e, errors.New("same-connection health response status or body bound failed")
	}
	for i, session := range sessions {
		if err := session.CloseWithError(0, ""); err != nil {
			return e, err
		}
		select {
		case <-session.Context().Done():
			e.Sessions[i].Closed = true
		case <-ctx.Done():
			return e, ctx.Err()
		}
	}
	if err := conn.CloseWithError(quic.ApplicationErrorCode(http3.ErrCodeNoError), "oracle complete"); err != nil {
		return e, err
	}
	e.ConnectionClosed = true
	if ctx.Err() != nil {
		return e, ctx.Err()
	}
	if echo {
		e.Scope = "pinned_go_control_echo"
		e.ServerDeliveryVerified = true
	}
	return e, nil
}
