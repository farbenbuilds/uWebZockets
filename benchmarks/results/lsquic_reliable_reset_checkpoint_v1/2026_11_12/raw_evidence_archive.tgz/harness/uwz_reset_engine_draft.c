/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/queue.h>

#include <openssl/ssl.h>

#include "lsquic.h"
#include "uwz_quic_fixture.h"
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_packet_in.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"

#ifdef NDEBUG
#error "uwz_reliable_reset requires active assertions"
#endif

extern int lsquic_stream_reset_at (lsquic_stream_t *, uint64_t, uint64_t)
    __attribute__((weak));
extern int lsquic_stream_get_reset_error (const lsquic_stream_t *, int,
    uint64_t *) __attribute__((weak));

enum {
    RESET_MAX_STREAMS = 16,
    RESET_MAX_STEPS = 20000,
    RESET_SUFFIX_SIZE = 4096,
};

struct reset_endpoint;

struct reset_stream {
    struct reset_endpoint *rs_endpoint;
    lsquic_stream_t *rs_stream;
    lsquic_stream_id_t rs_id;
    const char *rs_send;
    size_t rs_send_size;
    size_t rs_sent;
    size_t rs_received;
    unsigned rs_fin;
    unsigned rs_closed;
    unsigned rs_auto_fin;
    unsigned rs_expect_reset;
    unsigned rs_reset_events[2];
    int rs_read_error;
    uint64_t rs_reset_codes[2];
    struct lsquic_stream_recv_state rs_close_metadata;
    unsigned char rs_bytes[8192];
};

struct reset_endpoint {
    struct lsquic_test_endpoint *re_transport;
    lsquic_conn_t *re_conn;
    unsigned re_server;
    unsigned re_receive_enabled;
    unsigned re_hold_primary;
    unsigned re_expect_primary_reset;
    unsigned re_handshake_ok;
    unsigned re_new_connections;
    unsigned re_closed_connections;
    unsigned re_stream_count;
    struct reset_stream re_streams[RESET_MAX_STREAMS];
};

struct reset_fixture {
    struct lsquic_test_pair rf_transport;
    struct reset_endpoint rf_client;
    struct reset_endpoint rf_server;
};

static const char reset_alpn[] = "uwz-reset-test/1";
static const char reset_prefix[] = "uwz-reset-test/1 reliable prefix\n";
static const char healthy_payload[] = "uwz-reset-test/1 healthy sibling\n";


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct reset_endpoint *endpoint = ctx;

    endpoint->re_conn = conn;
    ++endpoint->re_new_connections;
    if (endpoint->re_server)
        endpoint->re_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct reset_endpoint *endpoint = (struct reset_endpoint *) lsquic_conn_get_ctx(conn);

    assert(status == LSQ_HSK_OK);
    endpoint->re_handshake_ok = 1;
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct reset_endpoint *endpoint = (struct reset_endpoint *) lsquic_conn_get_ctx(conn);

    lsquic_conn_set_ctx(conn, NULL);
    endpoint->re_conn = NULL;
    ++endpoint->re_closed_connections;
    assert(endpoint->re_closed_connections == 1);
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct reset_endpoint *endpoint = ctx;
    struct reset_stream *state;

    assert(stream);
    assert(endpoint->re_stream_count < RESET_MAX_STREAMS);
    state = &endpoint->re_streams[endpoint->re_stream_count++];
    memset(state, 0, sizeof(*state));
    state->rs_endpoint = endpoint;
    state->rs_stream = stream;
    state->rs_id = lsquic_stream_id(stream);
    state->rs_expect_reset = state->rs_id < 4 && endpoint->re_expect_primary_reset;
    if ((state->rs_id & 1) != endpoint->re_server
        && !(state->rs_id < 4 && endpoint->re_hold_primary))
        assert(lsquic_stream_wantread(stream, 1) >= 0);
    return (lsquic_stream_ctx_t *) state;
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct reset_stream *state = (struct reset_stream *) ctx;
    unsigned char bytes[256];
    ssize_t size;

    while (1)
    {
        size = lsquic_stream_read(stream, bytes, sizeof(bytes));
        if (size > 0)
        {
            assert((size_t) size <= sizeof(state->rs_bytes) - state->rs_received);
            memcpy(state->rs_bytes + state->rs_received, bytes, size);
            state->rs_received += size;
        }
        else if (size == 0)
        {
            ++state->rs_fin;
            assert(state->rs_fin == 1);
            assert(lsquic_stream_wantread(stream, 0) >= 0);
            assert(0 == lsquic_stream_shutdown(stream, 0));
            return;
        }
        else if (errno == ECONNRESET)
        {
            assert(state->rs_expect_reset);
            state->rs_read_error = errno;
            assert(lsquic_stream_wantread(stream, 0) >= 0);
            assert(0 == lsquic_stream_shutdown(stream, 0));
            return;
        }
        else
        {
            assert(errno == EAGAIN || errno == EWOULDBLOCK);
            return;
        }
    }
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct reset_stream *state = (struct reset_stream *) ctx;
    ssize_t size;

    assert(state->rs_send);
    size = lsquic_stream_write(stream, state->rs_send + state->rs_sent,
                              state->rs_send_size - state->rs_sent);
    if (size < 0)
    {
        assert(errno == EAGAIN || errno == EWOULDBLOCK);
        return;
    }
    state->rs_sent += size;
    if (state->rs_sent == state->rs_send_size)
    {
        assert(lsquic_stream_wantwrite(stream, 0) >= 0);
        if (state->rs_auto_fin)
            assert(0 == lsquic_stream_shutdown(stream, 1));
        else
            assert(0 == lsquic_stream_flush(stream));
    }
}


static void
close_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct reset_stream *state = (struct reset_stream *) ctx;

    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream,
                                                    &state->rs_close_metadata));
    ++state->rs_closed;
    assert(state->rs_closed == 1);
    state->rs_stream = NULL;
}


static void
reset_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx, int how)
{
    struct reset_stream *state = (struct reset_stream *) ctx;
    uint64_t error = UINT64_C(0xA5A5A5A5);

    assert(how == 0 || how == 1);
    assert(LSQUIC_SERR_AVAILABLE == lsquic_stream_get_reset_error(stream, how,
                                                                 &error));
    ++state->rs_reset_events[how];
    assert(state->rs_reset_events[how] == 1);
    state->rs_reset_codes[how] = error;
    if (how == 0)
        assert(state->rs_expect_reset);
}


static const struct lsquic_stream_if reset_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_new_stream = new_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_reset = reset_stream,
};


static void
pump_step (struct reset_fixture *fixture)
{
    lsquic_test_pair_process(&fixture->rf_transport, 1000);
    lsquic_test_deliver_all(&fixture->rf_transport.ltp_client);
    lsquic_test_deliver_all(&fixture->rf_transport.ltp_server);
}


static void
init_endpoint (struct reset_fixture *fixture, struct reset_endpoint *endpoint,
               unsigned server)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct lsquic_test_endpoint *peer;
    unsigned flags = server ? LSENG_SERVER : 0;

    endpoint->re_server = server;
    if (server)
    {
        endpoint->re_transport = &fixture->rf_transport.ltp_server;
        peer = &fixture->rf_transport.ltp_client;
    }
    else
    {
        endpoint->re_transport = &fixture->rf_transport.ltp_client;
        peer = &fixture->rf_transport.ltp_server;
    }
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = 4;
    settings.es_max_streams_in = 4;
    settings.es_reset_stream_at = endpoint->re_receive_enabled;
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &reset_callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_alpn = reset_alpn;
    config.ltec_tls = lsquic_test_tls_context_new(server, reset_alpn);
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(endpoint->re_transport, peer, &config,
                                        server ? 12101 : 12102));
    SSL_CTX_free(config.ltec_tls);
}


static void
send_bytes (struct reset_stream *state, const char *bytes, size_t size)
{
    state->rs_send = bytes;
    state->rs_send_size = size;
    state->rs_auto_fin = 1;
    assert(lsquic_stream_wantwrite(state->rs_stream, 1) >= 0);
}


static struct reset_stream *
find_stream (struct reset_endpoint *endpoint, lsquic_stream_id_t id)
{
    unsigned index;

    for (index = 0; index < endpoint->re_stream_count; ++index)
        if (endpoint->re_streams[index].rs_id == id)
            return &endpoint->re_streams[index];
    return NULL;
}

static void
init_fixture (struct reset_fixture *fixture, unsigned client_receive,
              unsigned server_receive)
{
    unsigned step;

    memset(fixture, 0, sizeof(*fixture));
    fixture->rf_client.re_receive_enabled = client_receive;
    fixture->rf_server.re_receive_enabled = server_receive;
    init_endpoint(fixture, &fixture->rf_client, 0);
    init_endpoint(fixture, &fixture->rf_server, 1);
    assert(lsquic_engine_connect(fixture->rf_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture->rf_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture->rf_transport.ltp_server.lte_address,
                &fixture->rf_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
    for (step = 0; step < RESET_MAX_STEPS; ++step)
    {
        if (fixture->rf_client.re_handshake_ok && fixture->rf_server.re_handshake_ok)
            break;
        pump_step(fixture);
    }
    assert(fixture->rf_client.re_handshake_ok == 1);
    assert(fixture->rf_server.re_handshake_ok == 1);
    assert(fixture->rf_client.re_new_connections == 1);
    assert(fixture->rf_server.re_new_connections == 1);
}


static void
cleanup_fixture (struct reset_fixture *fixture)
{
    lsquic_test_endpoint_destroy(&fixture->rf_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture->rf_transport.ltp_server);
}


static void
assert_pending_reset (struct reset_stream *stream, uint64_t final_size,
                      uint64_t reliable_size)
{
    struct lsquic_stream_recv_state metadata;
    uint64_t error = UINT64_C(0xA5A5A5A5);
    unsigned known = LSQUIC_SRS_FINAL_SIZE_KNOWN | LSQUIC_SRS_RESET_KNOWN
                                            | LSQUIC_SRS_RELIABLE_RESET_SEEN;

    assert(stream && stream->rs_stream);
    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream->rs_stream,
                                                       &metadata));
    assert((metadata.flags & known) == known);
    assert(!(metadata.flags & LSQUIC_SRS_RESET_VISIBLE));
    assert(metadata.final_size == final_size);
    assert(metadata.reliable_size == reliable_size);
    assert(metadata.reset_error_code == 0x175);
    assert(LSQUIC_SERR_UNAVAILABLE == lsquic_stream_get_reset_error(
                                                    stream->rs_stream, 0, &error));
    assert(error == UINT64_C(0xA5A5A5A5));
    assert(stream->rs_reset_events[0] == 0);
    assert(stream->rs_read_error == 0);
}


static void
consume_prefix (struct reset_fixture *fixture, struct reset_stream *stream,
                size_t target)
{
    unsigned step;
    ssize_t size;

    assert(target <= sizeof(reset_prefix) - 1);
    for (step = 0; step < RESET_MAX_STEPS && stream->rs_received < target; ++step)
    {
        assert(stream->rs_stream);
        size = lsquic_stream_read(stream->rs_stream,
                    stream->rs_bytes + stream->rs_received,
                    target - stream->rs_received);
        if (size > 0)
        {
            stream->rs_received += size;
            assert(stream->rs_received <= target);
        }
        else
        {
            assert(size < 0 && (errno == EAGAIN || errno == EWOULDBLOCK));
            pump_step(fixture);
        }
    }
    assert(stream->rs_received == target);
    assert(0 == memcmp(stream->rs_bytes, reset_prefix, target));
}


static void
consume_reset (struct reset_fixture *fixture, struct reset_stream *stream)
{
    unsigned step, index;
    ssize_t size;

    for (step = 0; step < RESET_MAX_STEPS; ++step)
    {
        assert(stream->rs_stream);
        size = lsquic_stream_read(stream->rs_stream,
                    stream->rs_bytes + stream->rs_received,
                    sizeof(stream->rs_bytes) - stream->rs_received);
        if (size > 0)
        {
            for (index = 0; index < (unsigned) size; ++index)
                assert(stream->rs_bytes[stream->rs_received + index] == 'x');
            stream->rs_received += size;
            assert(stream->rs_received <= sizeof(reset_prefix) - 1 + RESET_SUFFIX_SIZE);
        }
        else if (size < 0 && errno == ECONNRESET)
        {
            stream->rs_read_error = ECONNRESET;
            assert(0 == lsquic_stream_shutdown(stream->rs_stream, 0));
            return;
        }
        else
        {
            assert(size < 0 && (errno == EAGAIN || errno == EWOULDBLOCK));
            pump_step(fixture);
        }
    }
    assert(0 && "reset notification did not follow the consumed reliable prefix");
}


static void
assert_healthy (struct reset_stream *stream)
{
    assert(stream);
    assert(stream->rs_received == sizeof(healthy_payload) - 1);
    assert(0 == memcmp(stream->rs_bytes, healthy_payload, sizeof(healthy_payload) - 1));
    assert(stream->rs_fin == 1 && stream->rs_closed == 1);
    assert(stream->rs_reset_events[0] == 0 && stream->rs_reset_events[1] == 0);
    assert(stream->rs_close_metadata.flags & LSQUIC_SRS_FINAL_SIZE_KNOWN);
    assert(stream->rs_close_metadata.flags & LSQUIC_SRS_FIN_RECEIVED);
    assert(!(stream->rs_close_metadata.flags & LSQUIC_SRS_RESET_KNOWN));
    assert(stream->rs_close_metadata.final_size == sizeof(healthy_payload) - 1);
    assert(stream->rs_close_metadata.reliable_size == sizeof(healthy_payload) - 1);
}


static void
test_lost_prefix_reset_first (unsigned server_sender)
{
    struct reset_fixture fixture;
    struct reset_endpoint *sender, *receiver;
    struct reset_stream *outgoing, *incoming, *sibling;
    struct lsquic_test_packet lost_prefix;
    struct lsquic_stream_recv_state metadata;
    char suffix[RESET_SUFFIX_SIZE];
    unsigned step, sent_before;
    uint64_t id = server_sender ? 3 : 2;
    uint64_t error = UINT64_C(0xA5A5A5A5);
    unsigned char byte;

    init_fixture(&fixture, server_sender, !server_sender);
    sender = server_sender ? &fixture.rf_server : &fixture.rf_client;
    receiver = server_sender ? &fixture.rf_client : &fixture.rf_server;
    receiver->re_hold_primary = 1;
    receiver->re_expect_primary_reset = 1;
    for (step = 0; step < 200; ++step)
        pump_step(&fixture);
    assert(fixture.rf_transport.ltp_client.lte_incoming.ltq_count == 0);
    assert(fixture.rf_transport.ltp_server.lte_incoming.ltq_count == 0);
    assert(!lsquic_engine_has_unsent_packets(sender->re_transport->lte_engine));
    assert(!lsquic_engine_has_unsent_packets(receiver->re_transport->lte_engine));
    assert(LSQUIC_MUS_OK == lsquic_conn_make_uni_stream(sender->re_conn));
    outgoing = find_stream(sender, id);
    assert(outgoing && outgoing->rs_stream);
    sent_before = sender->re_transport->lte_packets_sent;
    assert(sizeof(reset_prefix) - 1 == (size_t) lsquic_stream_write(
                outgoing->rs_stream, reset_prefix, sizeof(reset_prefix) - 1));
    outgoing->rs_sent = sizeof(reset_prefix) - 1;
    assert(0 == lsquic_stream_flush(outgoing->rs_stream));
    lsquic_engine_process_conns(sender->re_transport->lte_engine);
    /* This is the sole new output and all 33 bytes are in transport frames. */
    assert(sender->re_transport->lte_packets_sent == sent_before + 1);
    assert(receiver->re_transport->lte_incoming.ltq_count == 1);
    assert(outgoing->rs_stream->tosend_off >= sizeof(reset_prefix) - 1);
    assert(0 == lsquic_test_packet_take(receiver->re_transport, 0, &lost_prefix));
    assert(lost_prefix.ltp_size > 0);
    assert(receiver->re_transport->lte_incoming.ltq_count == 0);
    memset(suffix, 'x', sizeof(suffix));
    assert(sizeof(suffix) == (size_t) lsquic_stream_write(outgoing->rs_stream,
                                                        suffix, sizeof(suffix)));
    outgoing->rs_sent += sizeof(suffix);
    assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(outgoing->rs_stream, 0x175,
                                                 sizeof(reset_prefix) - 1));
    assert(LSQUIC_MUS_OK == lsquic_conn_make_uni_stream(sender->re_conn));
    sibling = find_stream(sender, id + 4);
    assert(sibling);
    send_bytes(sibling, healthy_payload, sizeof(healthy_payload) - 1);
    /* Keep the virtual clock fixed until RESET metadata is received. */
    lsquic_engine_process_conns(sender->re_transport->lte_engine);
    lsquic_test_deliver_all(receiver->re_transport);
    lsquic_engine_process_conns(receiver->re_transport->lte_engine);
    incoming = find_stream(receiver, id);
    assert_pending_reset(incoming, sizeof(reset_prefix) - 1 + sizeof(suffix),
                         sizeof(reset_prefix) - 1);
    assert(-1 == lsquic_stream_read(incoming->rs_stream, &byte, 1));
    assert(errno == EAGAIN || errno == EWOULDBLOCK);
    assert(incoming->rs_received == 0);
    consume_prefix(&fixture, incoming, sizeof(reset_prefix) - 2);
    assert_pending_reset(incoming, sizeof(reset_prefix) - 1 + sizeof(suffix),
                         sizeof(reset_prefix) - 1);
    consume_prefix(&fixture, incoming, sizeof(reset_prefix) - 1);
    assert(LSQUIC_SERR_AVAILABLE == lsquic_stream_get_reset_error(
                                                    incoming->rs_stream, 0, &error));
    assert(error == 0x175);
    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(incoming->rs_stream,
                                                       &metadata));
    assert(metadata.flags & LSQUIC_SRS_RESET_VISIBLE);
    consume_reset(&fixture, incoming);
    for (step = 0; step < RESET_MAX_STEPS; ++step)
    {
        if (incoming->rs_closed && outgoing->rs_closed
            && sibling->rs_closed && find_stream(receiver, id + 4)
            && find_stream(receiver, id + 4)->rs_closed)
            break;
        pump_step(&fixture);
    }
    assert(incoming->rs_closed == 1 && outgoing->rs_closed == 1);
    assert(incoming->rs_reset_events[0] == 1);
    assert(incoming->rs_reset_codes[0] == 0x175);
    assert(incoming->rs_read_error == ECONNRESET && incoming->rs_fin == 0);
    assert(incoming->rs_close_metadata.flags & LSQUIC_SRS_RESET_VISIBLE);
    assert_healthy(find_stream(receiver, id + 4));
    cleanup_fixture(&fixture);
    printf("PASS lost-prefix/reset-first/recovery/32-of-33 withholding/exact error373/healthy FIN: %s sender, receiver-only advertisement\n",
           server_sender ? "server" : "client");
}


int
main (void)
{
    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(lsquic_stream_reset_at && lsquic_stream_get_reset_error);
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    test_lost_prefix_reset_first(0);
    test_lost_prefix_reset_first(1);
    lsquic_global_cleanup();
    return 0;
}
