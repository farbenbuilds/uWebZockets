#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>

#include "lsquic.h"

int
main(void)
{
    printf("{\"settings_size\":%zu,\"settings_alignment\":%zu,"
           "\"versions_offset\":%zu,\"header_sets_offset\":%zu",
           sizeof(struct lsquic_engine_settings),
           _Alignof(struct lsquic_engine_settings),
           offsetof(struct lsquic_engine_settings, es_versions),
           offsetof(struct lsquic_engine_settings, es_max_header_sets));
#ifdef RESET_LAYOUT_NEW
    _Static_assert(offsetof(struct lsquic_engine_settings, es_reset_stream_at)
                   == offsetof(struct lsquic_engine_settings, es_max_header_sets)
                    + sizeof(((struct lsquic_engine_settings *) 0)->es_max_header_sets),
                   "reset receive setting must follow existing fields");
    printf(",\"reset_setting_offset\":%zu,\"receive_snapshot_size\":%zu",
           offsetof(struct lsquic_engine_settings, es_reset_stream_at),
           sizeof(struct lsquic_stream_recv_state));
#endif
    return puts("}") < 0;
}
