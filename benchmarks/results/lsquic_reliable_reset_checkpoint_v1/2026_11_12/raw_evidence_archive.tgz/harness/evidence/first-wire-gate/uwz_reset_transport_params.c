/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "lsquic.h"
#include "lsquic_types.h"
#include "lsquic_sizes.h"
#include "lsquic_trans_params.h"

#ifdef NDEBUG
#error "uwz_reset_transport_params requires active assertions"
#endif

struct parameter_vector {
    unsigned pv_size;
    unsigned char pv_bytes[12];
};


static void
test_valid_parameter (unsigned server)
{
    static const struct parameter_vector vectors[] = {
        { 2, { 0x1D, 0 } },
        { 3, { 0x40, 0x1D, 0 } },
        { 3, { 0x1D, 0x40, 0 } },
        { 9, { 0xC0, 0, 0, 0, 0, 0, 0, 0x1D, 0 } },
        { 9, { 0x1D, 0xC0, 0, 0, 0, 0, 0, 0, 0 } },
    };
    struct transport_params params = TP_INITIALIZER();
    struct transport_params decoded;
    unsigned char output[8];
    unsigned reset_bit = 1U << TPI_RESET_STREAM_AT;
    unsigned index, cut, capacity, guard;

    assert(!(params.tp_set & reset_bit));
    assert(0 == lsquic_tp_encode(&params, server, output, sizeof(output)));
    assert(0 == lsquic_tp_decode(output, 0, server, &decoded));
    assert(!(decoded.tp_set & reset_bit));
    assert(!(decoded.tp_decoded & reset_bit));
    params.tp_set |= reset_bit;
    for (capacity = 0; capacity < 2; ++capacity)
    {
        memset(output, 0xA5, sizeof(output));
        assert(lsquic_tp_encode(&params, server, output + 1, capacity) < 0);
        assert(output[0] == 0xA5);
        for (guard = capacity + 1; guard < sizeof(output); ++guard)
            assert(output[guard] == 0xA5);
    }
    assert(2 == lsquic_tp_encode(&params, server, output, sizeof(output)));
    assert(output[0] == 0x1D && output[1] == 0);
    for (index = 0; index < sizeof(vectors) / sizeof(vectors[0]); ++index)
    {
        assert((int) vectors[index].pv_size == lsquic_tp_decode(
                    vectors[index].pv_bytes, vectors[index].pv_size,
                    server, &decoded));
        assert(decoded.tp_set & reset_bit);
        assert(decoded.tp_decoded & reset_bit);
        for (cut = 1; cut < vectors[index].pv_size; ++cut)
            assert(lsquic_tp_decode(vectors[index].pv_bytes, cut,
                                   server, &decoded) < 0);
    }
}


static void
test_invalid_parameter (unsigned server)
{
    static const struct parameter_vector vectors[] = {
        { 3, { 0x1D, 1, 0 } },
        { 4, { 0x1D, 2, 0, 0 } },
        { 4, { 0x1D, 0x40, 1, 0 } },
        { 4, { 0x1D, 0, 0x1D, 0 } },
        { 5, { 0x1D, 0, 0x40, 0x1D, 0 } },
        { 6, { 0x1D, 0, 0x3F, 0, 0x1D, 0 } },
        { 9, { 0x1D, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF } },
    };
    static const unsigned char maximum_unknown_id[] = {
        0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0,
    };
    struct transport_params decoded;
    unsigned index;

    for (index = 0; index < sizeof(vectors) / sizeof(vectors[0]); ++index)
        assert(lsquic_tp_decode(vectors[index].pv_bytes, vectors[index].pv_size,
                               server, &decoded) < 0);
    assert(sizeof(maximum_unknown_id) == (size_t) lsquic_tp_decode(
                maximum_unknown_id, sizeof(maximum_unknown_id), server, &decoded));
    assert(!(decoded.tp_set & (1U << TPI_RESET_STREAM_AT)));
    assert(!(decoded.tp_decoded & (1U << TPI_RESET_STREAM_AT)));
}


static void
test_receive_setting (unsigned server)
{
    struct lsquic_engine_settings settings;
    char error[256];
    unsigned flags = server ? LSENG_SERVER : 0;

    lsquic_engine_init_settings(&settings, flags);
    assert(settings.es_reset_stream_at == 0);
    settings.es_reset_stream_at = 1;
    assert(0 == lsquic_engine_check_settings(&settings, flags, error, sizeof(error)));
    settings.es_reset_stream_at = -1;
    assert(lsquic_engine_check_settings(&settings, flags, error, sizeof(error)) < 0);
    settings.es_reset_stream_at = 2;
    assert(lsquic_engine_check_settings(&settings, flags, error, sizeof(error)) < 0);
}


int
main (void)
{
    unsigned server;

    for (server = 0; server < 2; ++server)
    {
        test_valid_parameter(server);
        test_invalid_parameter(server);
        test_receive_setting(server);
    }
    puts("PASS reset_stream_at receive TP: both roles, empty-only, duplicates, widths/truncations, maximum varints/capacity, default-off and boolean setting validation");
    return 0;
}
