/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "lsquic.h"
#include "lsquic_types.h"
#include "lsquic_parse.h"

#ifdef NDEBUG
#error "uwz_reset_codec requires active assertions"
#endif

static const uint64_t reset_varint_max = UINT64_C(0x3FFFFFFFFFFFFFFF);


static void
assert_frame (const struct lsquic_reset_stream_at *actual,
              const struct lsquic_reset_stream_at *expected)
{
    assert(actual->stream_id == expected->stream_id);
    assert(actual->error_code == expected->error_code);
    assert(actual->final_size == expected->final_size);
    assert(actual->reliable_size == expected->reliable_size);
}


static unsigned
write_varint (unsigned char *bytes, uint64_t value, unsigned width)
{
    unsigned index, prefix;

    assert(width == 1 || width == 2 || width == 4 || width == 8);
    assert(value < (UINT64_C(1) << (width * 8 - 2)));
    prefix = width == 1 ? 0 : width == 2 ? 1 : width == 4 ? 2 : 3;
    for (index = 0; index < width; ++index)
        bytes[width - index - 1] = value >> (index * 8);
    bytes[0] |= prefix << 6;
    return width;
}


static void
assert_atomic_failure (const struct parse_funcs *pf,
                       const unsigned char *bytes, size_t size)
{
    struct lsquic_reset_stream_at output, before;

    memset(&output, 0xA5, sizeof(output));
    before = output;
    assert(-1 == pf->pf_parse_reset_stream_at_frame(bytes, size, &output));
    assert(0 == memcmp(&output, &before, sizeof(output)));
}


static void
test_frame (const struct parse_funcs *pf,
            const struct lsquic_reset_stream_at *expected)
{
    unsigned char storage[35], before[35];
    struct lsquic_reset_stream_at output;
    unsigned size, capacity;
    int encoded;

    size = pf->pf_reset_stream_at_frame_size(expected);
    assert(size >= 5 && size <= 33);
    for (capacity = 0; capacity < size; ++capacity)
    {
        memset(storage, 0xA5, sizeof(storage));
        memcpy(before, storage, sizeof(storage));
        assert(-1 == pf->pf_gen_reset_stream_at_frame(storage + 1, capacity,
                                                     expected));
        assert(0 == memcmp(storage, before, sizeof(storage)));
    }
    memset(storage, 0xA5, sizeof(storage));
    encoded = pf->pf_gen_reset_stream_at_frame(storage + 1, size, expected);
    assert(encoded == (int) size);
    assert(storage[0] == 0xA5 && storage[size + 1] == 0xA5);
    assert(storage[1] == 0x24);
    assert(encoded == pf->pf_parse_reset_stream_at_frame(storage + 1, size,
                                                        &output));
    assert_frame(&output, expected);
    for (capacity = 0; capacity < size; ++capacity)
        assert_atomic_failure(pf, storage + 1, capacity);
    storage[size + 1] = 0;
    assert(encoded == pf->pf_parse_reset_stream_at_frame(storage + 1, size + 1,
                                                        &output));
    assert_frame(&output, expected);
}


static void
test_boundaries (const struct parse_funcs *pf)
{
    static const uint64_t values[] = {
        0, 63, 64, 16383, 16384, 1073741823, 1073741824,
        UINT64_C(0x3FFFFFFFFFFFFFFF),
    };
    struct lsquic_reset_stream_at frame;
    unsigned index, field;

    for (index = 0; index < sizeof(values) / sizeof(values[0]); ++index)
        for (field = 0; field < 4; ++field)
        {
            memset(&frame, 0, sizeof(frame));
            if (field == 0)
                frame.stream_id = values[index];
            else if (field == 1)
                frame.error_code = values[index];
            else if (field == 2)
                frame.final_size = values[index];
            else
                frame.reliable_size = values[index];
            test_frame(pf, &frame);
        }
    frame.stream_id = reset_varint_max;
    frame.error_code = reset_varint_max;
    frame.final_size = reset_varint_max;
    frame.reliable_size = reset_varint_max;
    assert(pf->pf_reset_stream_at_frame_size(&frame) == 33);
    test_frame(pf, &frame);
}


static void
test_nonminimal_fields (const struct parse_funcs *pf)
{
    static const unsigned widths[] = { 1, 2, 4, 8 };
    const struct lsquic_reset_stream_at expected = { 3, 7, 9, 5 };
    struct lsquic_reset_stream_at output;
    unsigned char bytes[33];
    unsigned field, index, current, offset, truncated;

    for (field = 0; field < 4; ++field)
        for (index = 0; index < 4; ++index)
        {
            bytes[0] = 0x24;
            offset = 1;
            for (current = 0; current < 4; ++current)
                offset += write_varint(bytes + offset,
                            current == 0 ? 3 : current == 1 ? 7 : current == 2 ? 9 : 5,
                            current == field ? widths[index] : 1);
            assert((int) offset == pf->pf_parse_reset_stream_at_frame(bytes,
                                                          offset, &output));
            assert_frame(&output, &expected);
            for (truncated = 0; truncated < offset; ++truncated)
                assert_atomic_failure(pf, bytes, truncated);
        }
}


static void
test_invalid_fields (const struct parse_funcs *pf)
{
    struct lsquic_reset_stream_at frame;
    unsigned char bytes[35], before[35];
    unsigned field;

    assert(pf->pf_reset_stream_at_frame_size(NULL) == 0);
    assert(-1 == pf->pf_gen_reset_stream_at_frame(bytes, sizeof(bytes), NULL));
    for (field = 0; field < 4; ++field)
    {
        memset(&frame, 0, sizeof(frame));
        if (field == 0)
            frame.stream_id = reset_varint_max + 1;
        else if (field == 1)
            frame.error_code = UINT64_MAX;
        else if (field == 2)
            frame.final_size = reset_varint_max + 1;
        else
            frame.reliable_size = UINT64_MAX;
        assert(pf->pf_reset_stream_at_frame_size(&frame) == 0);
        memset(bytes, 0xA5, sizeof(bytes));
        memcpy(before, bytes, sizeof(bytes));
        assert(-1 == pf->pf_gen_reset_stream_at_frame(bytes, sizeof(bytes), &frame));
        assert(0 == memcmp(bytes, before, sizeof(bytes)));
    }
    memset(&frame, 0, sizeof(frame));
    assert(-1 == pf->pf_gen_reset_stream_at_frame(NULL, sizeof(bytes), &frame));
    memset(bytes, 0, sizeof(bytes));
    assert_atomic_failure(pf, bytes, sizeof(bytes));
    bytes[0] = 0x25;
    assert_atomic_failure(pf, bytes, sizeof(bytes));
    bytes[0] = 0x40;
    bytes[1] = 0x24;
    assert_atomic_failure(pf, bytes, sizeof(bytes));
}


int
main (void)
{
    const struct parse_funcs *pf = select_pf_by_ver(LSQVER_I001);

    assert(pf && pf->pf_gen_reset_stream_at_frame);
    assert(pf->pf_parse_reset_stream_at_frame && pf->pf_reset_stream_at_frame_size);
    test_boundaries(pf);
    test_nonminimal_fields(pf);
    test_invalid_fields(pf);
    puts("PASS RESET_STREAM_AT canonical boundaries, all field widths/truncations, atomic parse/generation and bounded capacity");
    return 0;
}
