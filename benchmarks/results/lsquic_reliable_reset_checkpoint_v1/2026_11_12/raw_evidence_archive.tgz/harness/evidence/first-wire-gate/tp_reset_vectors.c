/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "lsquic.h"
#include "lsquic_types.h"
#include "lsquic_sizes.h"
#include "lsquic_trans_params.h"


struct reset_tp_vector
{
    const char          *name;
    const unsigned char *encoded;
    size_t               size;
    int                  reject;
};


static const unsigned char empty_value[] = { 0x1D, 0x00 };
static const unsigned char nonempty_value[] = { 0x1D, 0x01, 0x00 };
static const unsigned char duplicate_empty[] = { 0x1D, 0x00, 0x1D, 0x00 };
static const unsigned char duplicate_wide_id[] =
                                      { 0x1D, 0x00, 0x40, 0x1D, 0x00 };
static const unsigned char wide_zero_length[] = { 0x1D, 0x40, 0x00 };
static const unsigned char missing_length[] = { 0x1D };
static const unsigned char missing_value[] = { 0x1D, 0x01 };
static const unsigned char oversized_length[] = { 0x1D, 0x40, 0x40 };

static const struct reset_tp_vector vectors[] =
{
    { "empty", empty_value, sizeof(empty_value), 0 },
    { "nonempty", nonempty_value, sizeof(nonempty_value), 1 },
    { "duplicate", duplicate_empty, sizeof(duplicate_empty), 1 },
    { "duplicate-wide-id", duplicate_wide_id, sizeof(duplicate_wide_id), 1 },
    { "wide-zero-length", wide_zero_length, sizeof(wide_zero_length), 0 },
    { "missing-length", missing_length, sizeof(missing_length), 1 },
    { "missing-value", missing_value, sizeof(missing_value), 1 },
    { "oversized-length", oversized_length, sizeof(oversized_length), 1 },
};


static unsigned
test_decode (int is_server, int use_legacy)
{
    struct transport_params params;
    const unsigned bit = 1u << TPI_RESET_STREAM_AT;
    unsigned failures = 0;
    unsigned i;
    int result;

    for (i = 0; i < sizeof(vectors) / sizeof(vectors[0]); ++i)
    {
        if (use_legacy)
            result = lsquic_tp_decode_27(vectors[i].encoded, vectors[i].size,
                                                        is_server, &params);
        else
            result = lsquic_tp_decode(vectors[i].encoded, vectors[i].size,
                                                        is_server, &params);
        if ((result < 0) != vectors[i].reject)
        {
            fprintf(stderr, "%s TP from %s (legacy=%d): expected %s, got %d\n",
                vectors[i].name, is_server ? "server" : "client", use_legacy,
                vectors[i].reject ? "rejection" : "acceptance", result);
            ++failures;
        }
        if (!vectors[i].reject && (result != (int) vectors[i].size
                || !(params.tp_set & bit) || !(params.tp_decoded & bit)))
        {
            fprintf(stderr, "%s TP (legacy=%d): decoded state missing\n",
                                                vectors[i].name, use_legacy);
            ++failures;
        }
    }

    if (use_legacy)
        result = lsquic_tp_decode_27(empty_value, 0, is_server, &params);
    else
        result = lsquic_tp_decode(empty_value, 0, is_server, &params);
    if (result != 0 || (params.tp_set & bit) || (params.tp_decoded & bit))
    {
        fprintf(stderr, "absent TP (legacy=%d): support was enabled\n",
                                                                use_legacy);
        ++failures;
    }

    return failures;
}


static unsigned
test_encode (int is_server, int use_legacy)
{
    struct transport_params params = TP_INITIALIZER();
    unsigned char buf[3];
    unsigned failures = 0;
    size_t size;
    int result;

    params.tp_set |= 1u << TPI_RESET_STREAM_AT;
    memset(buf, 0xA5, sizeof(buf));
    if (use_legacy)
        result = lsquic_tp_encode_27(&params, is_server, buf, 2);
    else
        result = lsquic_tp_encode(&params, is_server, buf, 2);
    if (result != 2 || memcmp(buf, empty_value, 2) != 0 || buf[2] != 0xA5)
    {
        fprintf(stderr, "empty TP (legacy=%d): invalid encoded bytes\n",
                                                                use_legacy);
        ++failures;
    }

    for (size = 0; size < 2; ++size)
    {
        memset(buf, 0xA5, sizeof(buf));
        if (use_legacy)
            result = lsquic_tp_encode_27(&params, is_server, buf, size);
        else
            result = lsquic_tp_encode(&params, is_server, buf, size);
        if (result >= 0 || buf[0] != 0xA5 || buf[1] != 0xA5 || buf[2] != 0xA5)
        {
            fprintf(stderr, "empty TP (legacy=%d): exceeded capacity %zu\n",
                                                            use_legacy, size);
            ++failures;
        }
    }

    params.tp_set &= ~(1u << TPI_RESET_STREAM_AT);
    memset(buf, 0xA5, sizeof(buf));
    if (use_legacy)
        result = lsquic_tp_encode_27(&params, is_server, buf, 0);
    else
        result = lsquic_tp_encode(&params, is_server, buf, 0);
    if (result != 0 || buf[0] != 0xA5 || buf[1] != 0xA5 || buf[2] != 0xA5)
    {
        fprintf(stderr, "absent TP (legacy=%d): output was written\n",
                                                                use_legacy);
        ++failures;
    }

    return failures;
}


int
main (void)
{
    unsigned failures = 0;
    int is_server, use_legacy;

    for (is_server = 0; is_server <= 1; ++is_server)
        for (use_legacy = 0; use_legacy <= 1; ++use_legacy)
        {
            failures += test_decode(is_server, use_legacy);
            failures += test_encode(is_server, use_legacy);
        }

    return failures != 0;
}
