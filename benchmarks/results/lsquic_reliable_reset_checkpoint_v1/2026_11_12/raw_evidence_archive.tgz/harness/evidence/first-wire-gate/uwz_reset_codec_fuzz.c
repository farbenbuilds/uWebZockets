/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "lsquic.h"
#include "lsquic_types.h"
#include "lsquic_parse.h"

#ifdef NDEBUG
#error "uwz_reset_codec_fuzz requires active assertions"
#endif


int
LLVMFuzzerTestOneInput (const uint8_t *data, size_t size)
{
    const struct parse_funcs *pf = select_pf_by_ver(LSQVER_I001);
    struct lsquic_reset_stream_at parsed, before, roundtrip;
    unsigned char encoded[35];
    unsigned needed;
    int consumed, written;

    if (size > 64)
        size = 64;
    memset(&parsed, 0xA5, sizeof(parsed));
    before = parsed;
    consumed = pf->pf_parse_reset_stream_at_frame(data, size, &parsed);
    if (consumed < 0)
    {
        assert(consumed == -1);
        assert(0 == memcmp(&parsed, &before, sizeof(parsed)));
        return 0;
    }
    assert(consumed >= 5 && (size_t) consumed <= size);
    needed = pf->pf_reset_stream_at_frame_size(&parsed);
    assert(needed >= 5 && needed <= 33);
    memset(encoded, 0xA5, sizeof(encoded));
    written = pf->pf_gen_reset_stream_at_frame(encoded + 1, needed, &parsed);
    assert(written == (int) needed);
    assert(encoded[0] == 0xA5 && encoded[needed + 1] == 0xA5);
    assert(written == pf->pf_parse_reset_stream_at_frame(encoded + 1, needed,
                                                        &roundtrip));
    assert(roundtrip.stream_id == parsed.stream_id);
    assert(roundtrip.error_code == parsed.error_code);
    assert(roundtrip.final_size == parsed.final_size);
    assert(roundtrip.reliable_size == parsed.reliable_size);
    return 0;
}


#ifndef FUZZING_BUILD_MODE_UNSAFE_FOR_PRODUCTION
int
main (void)
{
    static const unsigned char seeds[][33] = {
        { 0 },
        { 0x24 },
        { 0x24, 3, 7, 9, 5 },
        { 0x24, 3, 7, 0, 5 },
        { 0x24, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF },
    };
    static const size_t seed_sizes[] = { 0, 1, 5, 5, 33 };
    unsigned char bytes[64];
    uint64_t state = UINT64_C(0x09D16A24);
    unsigned seed, size, iteration, index;

    for (seed = 0; seed < sizeof(seeds) / sizeof(seeds[0]); ++seed)
        for (size = 0; size <= seed_sizes[seed]; ++size)
            assert(0 == LLVMFuzzerTestOneInput(seeds[seed], size));
    for (iteration = 0; iteration < 4096; ++iteration)
    {
        state = state * UINT64_C(6364136223846793005) + 1;
        size = state % (sizeof(bytes) + 1);
        for (index = 0; index < size; ++index)
        {
            state = state * UINT64_C(6364136223846793005) + 1;
            bytes[index] = state >> 32;
        }
        if (size && iteration % 2 == 0)
            bytes[0] = 0x24;
        assert(0 == LLVMFuzzerTestOneInput(bytes, size));
    }
    puts("PASS RESET_STREAM_AT deterministic parser fuzz smoke: bounded seeds, every seed truncation, 4096 generated inputs");
    return 0;
}
#endif
