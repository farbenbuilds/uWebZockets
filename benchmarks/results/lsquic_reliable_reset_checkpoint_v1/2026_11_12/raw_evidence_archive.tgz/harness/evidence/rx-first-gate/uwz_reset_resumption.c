/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <openssl/crypto.h>
#include <openssl/ssl.h>

#include "lsquic.h"
#include "lsquic_types.h"
#include "lsquic_sizes.h"
#include "lsquic_trans_params.h"
#include "uwz_quic_fixture.h"

#ifdef NDEBUG
#error "uwz_reset_resumption requires active assertions"
#endif

enum { RESUME_MAX_STEPS = 20000 };

struct resume_tls_state
{
    unsigned char *rts_blob;
    size_t rts_blob_size;
    unsigned rts_server;
    unsigned rts_handshakes;
    unsigned rts_reused;
    unsigned rts_early_accepted;
    unsigned rts_peer_reset_support;
    unsigned rts_ticket_early_capable;
};

struct resume_endpoint
{
    lsquic_conn_t *re_conn;
    lsquic_stream_t *re_stream;
    unsigned re_server;
    unsigned re_handshake_ok;
    unsigned re_closed;
    unsigned re_streams;
    unsigned re_fin;
    size_t re_sent;
    size_t re_received;
    size_t re_queued_before_handshake;
    unsigned char re_bytes[128];
};

struct resume_fixture
{
    struct lsquic_test_pair rf_transport;
    struct resume_endpoint rf_client;
    struct resume_endpoint rf_server;
};

struct resume_case
{
    const char *rc_name;
    int rc_initial_support;
    int rc_resumed_support;
    int rc_client_early_enabled;
    unsigned rc_expected_early_acceptance;
};

static const char resume_alpn[] = "uwz-reset-resume/1";
static const char resume_payload[] = "ordinary stream data across resumption";


static void
observe_tls (const SSL *ssl, int event, int UNUSED_value)
{
    struct resume_tls_state *state;
    struct transport_params params;
    const unsigned char *bytes;
    size_t size;

    if (event != SSL_CB_HANDSHAKE_DONE)
        return;
    state = SSL_CTX_get_app_data(SSL_get_SSL_CTX(ssl));
    assert(state);
    ++state->rts_handshakes;
    assert(state->rts_handshakes == 1);
    state->rts_reused = SSL_session_reused(ssl);
    state->rts_early_accepted = SSL_early_data_accepted(ssl);
    SSL_get_peer_quic_transport_params(ssl, &bytes, &size);
    assert(bytes && size);
    assert(lsquic_tp_decode(bytes, size, !state->rts_server, &params) >= 0);
    state->rts_peer_reset_support =
                                !!(params.tp_set & (1u << TPI_RESET_STREAM_AT));
}


static int
save_ticket (SSL *ssl, SSL_SESSION *session)
{
    struct resume_tls_state *state;

    state = SSL_CTX_get_app_data(SSL_get_SSL_CTX(ssl));
    assert(state && !state->rts_server);
    if (state->rts_blob)
        return 0;
    assert(0 == lsquic_ssl_sess_to_resume_info(ssl, session, &state->rts_blob,
                                                        &state->rts_blob_size));
    assert(state->rts_blob && state->rts_blob_size);
    state->rts_ticket_early_capable = SSL_SESSION_early_data_capable(session);
    return 0;
}


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct resume_endpoint *endpoint = ctx;

    assert(!endpoint->re_conn);
    endpoint->re_conn = conn;
    if (endpoint->re_server)
        endpoint->re_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct resume_endpoint *endpoint =
                            (struct resume_endpoint *) lsquic_conn_get_ctx(conn);

    assert(status == LSQ_HSK_OK || status == LSQ_HSK_RESUMED_OK);
    endpoint->re_handshake_ok = 1;
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct resume_endpoint *endpoint =
                            (struct resume_endpoint *) lsquic_conn_get_ctx(conn);

    lsquic_conn_set_ctx(conn, NULL);
    endpoint->re_conn = NULL;
    ++endpoint->re_closed;
    assert(endpoint->re_closed == 1);
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct resume_endpoint *endpoint = ctx;

    assert(stream && !endpoint->re_stream);
    endpoint->re_stream = stream;
    ++endpoint->re_streams;
    assert(endpoint->re_streams == 1);
    assert(lsquic_stream_wantread(stream, 1) >= 0);
    if (!endpoint->re_server)
        assert(lsquic_stream_wantwrite(stream, 1) >= 0);
    return (lsquic_stream_ctx_t *) endpoint;
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct resume_endpoint *endpoint = (struct resume_endpoint *) ctx;
    unsigned char bytes[64];
    ssize_t size;

    while (1)
    {
        size = lsquic_stream_read(stream, bytes, sizeof(bytes));
        if (size > 0)
        {
            assert(endpoint->re_server);
            assert((size_t) size <= sizeof(endpoint->re_bytes)
                                                    - endpoint->re_received);
            memcpy(endpoint->re_bytes + endpoint->re_received, bytes, size);
            endpoint->re_received += size;
            continue;
        }
        if (size < 0)
        {
            assert(errno == EAGAIN || errno == EWOULDBLOCK);
            return;
        }
        assert(!endpoint->re_fin);
        endpoint->re_fin = 1;
        assert(lsquic_stream_wantread(stream, 0) >= 0);
        assert(0 == lsquic_stream_shutdown(stream, 0));
        if (endpoint->re_server)
            assert(0 == lsquic_stream_shutdown(stream, 1));
        return;
    }
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct resume_endpoint *endpoint = (struct resume_endpoint *) ctx;
    ssize_t size;

    assert(!endpoint->re_server);
    size = lsquic_stream_write(stream, resume_payload + endpoint->re_sent,
                              sizeof(resume_payload) - 1 - endpoint->re_sent);
    if (size < 0)
    {
        assert(errno == EAGAIN || errno == EWOULDBLOCK);
        return;
    }
    endpoint->re_sent += size;
    if (!endpoint->re_handshake_ok)
        endpoint->re_queued_before_handshake += size;
    if (endpoint->re_sent != sizeof(resume_payload) - 1)
        return;
    assert(lsquic_stream_wantwrite(stream, 0) >= 0);
    assert(0 == lsquic_stream_shutdown(stream, 1));
}


static void
close_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct resume_endpoint *endpoint = (struct resume_endpoint *) ctx;

    assert(endpoint->re_stream == stream);
    endpoint->re_stream = NULL;
}


static const struct lsquic_stream_if resume_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_new_stream = new_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
};


static void
init_endpoint (struct resume_fixture *fixture, unsigned server, SSL_CTX *tls,
               const struct lsquic_engine_settings *settings)
{
    struct lsquic_test_endpoint_config config;
    struct resume_endpoint *endpoint;
    struct lsquic_test_endpoint *transport, *peer;

    if (server)
    {
        endpoint = &fixture->rf_server;
        transport = &fixture->rf_transport.ltp_server;
        peer = &fixture->rf_transport.ltp_client;
    }
    else
    {
        endpoint = &fixture->rf_client;
        transport = &fixture->rf_transport.ltp_client;
        peer = &fixture->rf_transport.ltp_server;
    }
    endpoint->re_server = server;
    memset(&config, 0, sizeof(config));
    config.ltec_flags = server ? LSENG_SERVER : 0;
    config.ltec_settings = settings;
    config.ltec_stream_if = &resume_callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_alpn = resume_alpn;
    config.ltec_tls = tls;
    assert(0 == lsquic_test_endpoint_init(transport, peer, &config,
                                                    server ? 12201 : 12202));
}


static void
pump_connection (struct resume_fixture *fixture,
                 const struct resume_tls_state *client_tls)
{
    unsigned step;

    for (step = 0; step < RESUME_MAX_STEPS; ++step)
    {
        lsquic_test_pair_process(&fixture->rf_transport, 1000);
        lsquic_test_deliver_all(&fixture->rf_transport.ltp_client);
        lsquic_test_deliver_all(&fixture->rf_transport.ltp_server);
        assert(!fixture->rf_client.re_closed && !fixture->rf_server.re_closed);
        if (client_tls->rts_blob && fixture->rf_client.re_handshake_ok
                && fixture->rf_server.re_handshake_ok
                && fixture->rf_client.re_fin && fixture->rf_server.re_fin)
            return;
    }
    assert(!"resumption fixture did not finish");
}


static void
run_connection (struct resume_fixture *fixture, SSL_CTX *client_ctx,
                SSL_CTX *server_ctx,
                const struct lsquic_engine_settings *client_settings,
                const struct lsquic_engine_settings *server_settings,
                struct resume_tls_state *client_tls, int resumed)
{
    struct lsquic_test_pair *pair = &fixture->rf_transport;
    lsquic_conn_t *conn;

    memset(fixture, 0, sizeof(*fixture));
    init_endpoint(fixture, 0, client_ctx, client_settings);
    init_endpoint(fixture, 1, server_ctx, server_settings);
    conn = lsquic_engine_connect(pair->ltp_client.lte_engine, LSQVER_I001,
        (const struct sockaddr *) &pair->ltp_client.lte_address,
        (const struct sockaddr *) &pair->ltp_server.lte_address,
        &pair->ltp_client, NULL, "localhost", 0,
        resumed ? client_tls->rts_blob : NULL,
        resumed ? client_tls->rts_blob_size : 0, NULL, 0);
    assert(conn && fixture->rf_client.re_conn == conn);
    lsquic_conn_make_stream(conn);
    pump_connection(fixture, client_tls);
    assert(fixture->rf_client.re_sent == sizeof(resume_payload) - 1);
    assert(fixture->rf_server.re_received == sizeof(resume_payload) - 1);
    assert(0 == memcmp(fixture->rf_server.re_bytes, resume_payload,
                                                    sizeof(resume_payload) - 1));
    lsquic_test_endpoint_destroy(&pair->ltp_client);
    lsquic_test_endpoint_destroy(&pair->ltp_server);
    assert(fixture->rf_client.re_closed == 1);
    assert(fixture->rf_server.re_closed == 1);
}


static void
run_case (const struct resume_case *test)
{
    struct resume_fixture fixture;
    struct resume_tls_state client_tls = { 0 }, server_tls = { .rts_server = 1 };
    struct lsquic_engine_settings client_settings, initial_settings;
    struct lsquic_engine_settings resumed_settings;
    SSL_CTX *client_ctx, *server_ctx;

    lsquic_engine_init_settings(&client_settings, 0);
    lsquic_engine_init_settings(&initial_settings, LSENG_SERVER);
    client_settings.es_versions = initial_settings.es_versions =
                                                        1u << LSQVER_I001;
    client_settings.es_pace_packets = initial_settings.es_pace_packets = 0;
    initial_settings.es_reset_stream_at = test->rc_initial_support;
    resumed_settings = initial_settings;
    resumed_settings.es_reset_stream_at = test->rc_resumed_support;

    client_ctx = lsquic_test_tls_context_new(0, resume_alpn);
    server_ctx = lsquic_test_tls_context_new(1, resume_alpn);
    assert(client_ctx && server_ctx);
    assert(1 == SSL_CTX_set_app_data(client_ctx, &client_tls));
    assert(1 == SSL_CTX_set_app_data(server_ctx, &server_tls));
    SSL_CTX_set_info_callback(client_ctx, observe_tls);
    SSL_CTX_set_info_callback(server_ctx, observe_tls);
    SSL_CTX_set_session_cache_mode(client_ctx, SSL_SESS_CACHE_CLIENT);
    SSL_CTX_sess_set_new_cb(client_ctx, save_ticket);
    SSL_CTX_set_early_data_enabled(client_ctx, 1);
    SSL_CTX_set_early_data_enabled(server_ctx, 1);

    run_connection(&fixture, client_ctx, server_ctx, &client_settings,
                                            &initial_settings, &client_tls, 0);
    assert(client_tls.rts_handshakes == 1 && server_tls.rts_handshakes == 1);
    assert(!client_tls.rts_reused && !server_tls.rts_reused);
    assert(!client_tls.rts_early_accepted && !server_tls.rts_early_accepted);
    assert(client_tls.rts_ticket_early_capable);
    assert(client_tls.rts_peer_reset_support ==
                                        (unsigned) test->rc_initial_support);

    client_tls.rts_handshakes = server_tls.rts_handshakes = 0;
    SSL_CTX_set_early_data_enabled(client_ctx, test->rc_client_early_enabled);
    run_connection(&fixture, client_ctx, server_ctx, &client_settings,
                                            &resumed_settings, &client_tls, 1);
    assert(client_tls.rts_handshakes == 1 && server_tls.rts_handshakes == 1);
    assert(client_tls.rts_reused && server_tls.rts_reused);
    assert(client_tls.rts_early_accepted == test->rc_expected_early_acceptance);
    assert(server_tls.rts_early_accepted == test->rc_expected_early_acceptance);
    assert(client_tls.rts_peer_reset_support ==
                                        (unsigned) test->rc_resumed_support);
    if (test->rc_client_early_enabled)
        assert(fixture.rf_client.re_queued_before_handshake);
    printf("%s: resumed=%u early_accepted=%u early_queued=%zu\n", test->rc_name,
        client_tls.rts_reused, client_tls.rts_early_accepted,
        fixture.rf_client.re_queued_before_handshake);

    SSL_CTX_free(client_ctx);
    SSL_CTX_free(server_ctx);
    OPENSSL_cleanse(client_tls.rts_blob, client_tls.rts_blob_size);
    free(client_tls.rts_blob);
}


int
main (void)
{
    static const struct resume_case cases[] = {
        { "support-kept", 1, 1, 1, 1 },
        { "support-removed", 1, 0, 1, 0 },
        { "support-removed-without-early-data", 1, 0, 0, 0 },
        { "support-enabled", 0, 1, 1, 0 },
    };
    unsigned i;

    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    for (i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i)
        run_case(&cases[i]);
    lsquic_global_cleanup();
    return 0;
}
