/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <openssl/ssl.h>

#include "lsquic.h"
#include "uwz_quic_fixture.h"

#ifdef NDEBUG
#error "uwz_reliable_reset requires active assertions"
#endif

extern int lsquic_stream_reset_at (lsquic_stream_t *, uint64_t, uint64_t)
    __attribute__((weak));
extern int lsquic_stream_get_reset_error (const lsquic_stream_t *, int,
    uint64_t *) __attribute__((weak));

enum {
    RESET_MAX_STREAMS = 4,
    RESET_MAX_STEPS = 20000,
    RESET_SUFFIX_SIZE = 4096,
};

struct reset_stream {
    lsquic_stream_t *rs_stream;
    lsquic_stream_id_t rs_id;
    const char *rs_send;
    size_t rs_send_size;
    size_t rs_sent;
    size_t rs_received;
    unsigned rs_fin;
    unsigned rs_closed;
    unsigned char rs_bytes[8192];
};

struct reset_endpoint {
    struct lsquic_test_endpoint *re_transport;
    lsquic_conn_t *re_conn;
    unsigned re_server;
    unsigned re_handshake_ok;
    unsigned re_new_connections;
    unsigned re_closed_connections;
    unsigned re_stream_count;
    struct reset_stream re_streams[RESET_MAX_STREAMS];
};

struct reset_fixture {
    struct lsquic_test_pair rf_transport;
    struct reset_endpoint rf_client;
    struct reset_endpoint rf_server;
};

static const char reset_alpn[] = "uwz-reset-test/1";
static const char reset_prefix[] = "uwz-reset-test/1 reliable prefix\n";
static const char healthy_payload[] = "uwz-reset-test/1 healthy sibling\n";


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct reset_endpoint *endpoint = ctx;

    endpoint->re_conn = conn;
    ++endpoint->re_new_connections;
    if (endpoint->re_server)
        endpoint->re_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct reset_endpoint *endpoint = (struct reset_endpoint *) lsquic_conn_get_ctx(conn);

    assert(status == LSQ_HSK_OK);
    endpoint->re_handshake_ok = 1;
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct reset_endpoint *endpoint = (struct reset_endpoint *) lsquic_conn_get_ctx(conn);

    lsquic_conn_set_ctx(conn, NULL);
    endpoint->re_conn = NULL;
    ++endpoint->re_closed_connections;
    assert(endpoint->re_closed_connections == 1);
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct reset_endpoint *endpoint = ctx;
    struct reset_stream *state;

    assert(stream);
    assert(endpoint->re_stream_count < RESET_MAX_STREAMS);
    state = &endpoint->re_streams[endpoint->re_stream_count++];
    memset(state, 0, sizeof(*state));
    state->rs_stream = stream;
    state->rs_id = lsquic_stream_id(stream);
    if ((state->rs_id & 1) != endpoint->re_server)
        assert(lsquic_stream_wantread(stream, 1) >= 0);
    return (lsquic_stream_ctx_t *) state;
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct reset_stream *state = (struct reset_stream *) ctx;
    unsigned char bytes[256];
    ssize_t size;

    while (1)
    {
        size = lsquic_stream_read(stream, bytes, sizeof(bytes));
        if (size > 0)
        {
            assert((size_t) size <= sizeof(state->rs_bytes) - state->rs_received);
            memcpy(state->rs_bytes + state->rs_received, bytes, size);
            state->rs_received += size;
        }
        else if (size == 0)
        {
            ++state->rs_fin;
            assert(state->rs_fin == 1);
            assert(lsquic_stream_wantread(stream, 0) >= 0);
            assert(0 == lsquic_stream_shutdown(stream, 0));
            return;
        }
        else
        {
            assert(errno == EAGAIN || errno == EWOULDBLOCK);
            return;
        }
    }
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct reset_stream *state = (struct reset_stream *) ctx;
    ssize_t size;

    assert(state->rs_send);
    size = lsquic_stream_write(stream, state->rs_send + state->rs_sent,
                              state->rs_send_size - state->rs_sent);
    if (size < 0)
    {
        assert(errno == EAGAIN || errno == EWOULDBLOCK);
        return;
    }
    state->rs_sent += size;
    if (state->rs_sent == state->rs_send_size)
    {
        assert(lsquic_stream_wantwrite(stream, 0) >= 0);
        assert(0 == lsquic_stream_shutdown(stream, 1));
    }
}


static void
close_stream (lsquic_stream_t *UNUSED_stream, lsquic_stream_ctx_t *ctx)
{
    struct reset_stream *state = (struct reset_stream *) ctx;

    ++state->rs_closed;
    assert(state->rs_closed == 1);
    state->rs_stream = NULL;
}


static const struct lsquic_stream_if reset_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_new_stream = new_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
};


static void
pump_step (struct reset_fixture *fixture)
{
    lsquic_test_pair_process(&fixture->rf_transport, 1000);
    lsquic_test_deliver_all(&fixture->rf_transport.ltp_client);
    lsquic_test_deliver_all(&fixture->rf_transport.ltp_server);
}


static void
init_endpoint (struct reset_fixture *fixture, struct reset_endpoint *endpoint,
               unsigned server)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct lsquic_test_endpoint *peer;
    unsigned flags = server ? LSENG_SERVER : 0;

    endpoint->re_server = server;
    if (server)
    {
        endpoint->re_transport = &fixture->rf_transport.ltp_server;
        peer = &fixture->rf_transport.ltp_client;
    }
    else
    {
        endpoint->re_transport = &fixture->rf_transport.ltp_client;
        peer = &fixture->rf_transport.ltp_server;
    }
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = 4;
    settings.es_max_streams_in = 4;
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &reset_callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_alpn = reset_alpn;
    config.ltec_tls = lsquic_test_tls_context_new(server, reset_alpn);
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(endpoint->re_transport, peer, &config,
                                        server ? 12101 : 12102));
    SSL_CTX_free(config.ltec_tls);
}


static void
send_bytes (struct reset_stream *state, const char *bytes, size_t size)
{
    state->rs_send = bytes;
    state->rs_send_size = size;
    assert(lsquic_stream_wantwrite(state->rs_stream, 1) >= 0);
}


static struct reset_stream *
find_stream (struct reset_endpoint *endpoint, lsquic_stream_id_t id)
{
    unsigned index;

    for (index = 0; index < endpoint->re_stream_count; ++index)
        if (endpoint->re_streams[index].rs_id == id)
            return &endpoint->re_streams[index];
    return NULL;
}


int
main (void)
{
    struct reset_fixture fixture;
    struct reset_stream *primary, *sibling;
    char payload[sizeof(reset_prefix) - 1 + RESET_SUFFIX_SIZE];
    unsigned step, index;
    int missing_api;

    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    memset(&fixture, 0, sizeof(fixture));
    init_endpoint(&fixture, &fixture.rf_client, 0);
    init_endpoint(&fixture, &fixture.rf_server, 1);
    assert(lsquic_engine_connect(fixture.rf_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture.rf_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture.rf_transport.ltp_server.lte_address,
                &fixture.rf_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
    for (step = 0; step < RESET_MAX_STEPS; ++step)
    {
        if (fixture.rf_client.re_handshake_ok && fixture.rf_server.re_handshake_ok)
            break;
        pump_step(&fixture);
    }
    assert(fixture.rf_client.re_handshake_ok == 1);
    assert(fixture.rf_server.re_handshake_ok == 1);
    assert(fixture.rf_client.re_new_connections == 1);
    assert(fixture.rf_server.re_new_connections == 1);
    memcpy(payload, reset_prefix, sizeof(reset_prefix) - 1);
    memset(payload + sizeof(reset_prefix) - 1, 'x', RESET_SUFFIX_SIZE);
    assert(sizeof(reset_prefix) - 1 == 33);
    assert(sizeof(healthy_payload) - 1 == 33);
    assert(LSQUIC_MUS_OK == lsquic_conn_make_uni_stream(fixture.rf_server.re_conn));
    assert(LSQUIC_MUS_OK == lsquic_conn_make_uni_stream(fixture.rf_server.re_conn));
    assert(fixture.rf_server.re_stream_count == 2);
    assert(fixture.rf_server.re_streams[0].rs_id == 3);
    assert(fixture.rf_server.re_streams[1].rs_id == 7);
    send_bytes(&fixture.rf_server.re_streams[0], payload, sizeof(payload));
    send_bytes(&fixture.rf_server.re_streams[1], healthy_payload,
               sizeof(healthy_payload) - 1);
    for (step = 0; step < RESET_MAX_STEPS; ++step)
    {
        if (fixture.rf_client.re_stream_count == 2
            && fixture.rf_client.re_streams[0].rs_closed
            && fixture.rf_client.re_streams[1].rs_closed
            && fixture.rf_server.re_streams[0].rs_closed
            && fixture.rf_server.re_streams[1].rs_closed)
            break;
        pump_step(&fixture);
    }
    assert(fixture.rf_client.re_stream_count == 2);
    for (index = 0; index < 2; ++index)
    {
        assert(fixture.rf_client.re_streams[index].rs_fin == 1);
        assert(fixture.rf_client.re_streams[index].rs_closed == 1);
        assert(fixture.rf_server.re_streams[index].rs_closed == 1);
    }
    assert(fixture.rf_server.re_streams[0].rs_sent == sizeof(payload));
    primary = find_stream(&fixture.rf_client, 3);
    sibling = find_stream(&fixture.rf_client, 7);
    assert(primary && sibling);
    assert(primary->rs_received == sizeof(payload));
    assert(0 == memcmp(primary->rs_bytes, payload, sizeof(payload)));
    assert(sibling->rs_received == sizeof(healthy_payload) - 1);
    assert(0 == memcmp(sibling->rs_bytes, healthy_payload,
                      sizeof(healthy_payload) - 1));
    puts("Real encrypted TLS handshake and existing uni lifecycle complete: IDs3/7, prefix33+suffix4096, healthy sibling33, exact bytes+FIN");
    missing_api = !lsquic_stream_reset_at || !lsquic_stream_get_reset_error;
    lsquic_test_endpoint_destroy(&fixture.rf_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture.rf_transport.ltp_server);
    lsquic_global_cleanup();
    if (missing_api)
    {
        fputs("RED: reliable-reset API absent after real encrypted TLS and uni lifecycle; loss/reorder behavior is not yet measurable\n", stderr);
        return 1;
    }
    fputs("Reliable-reset API exists; the negotiated loss/reorder matrix must replace this initial absence gate before GREEN\n", stderr);
    return 2;
}
