/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <sys/queue.h>

#include <openssl/ssl.h>

#include "lsquic.h"
#include "lsxpack_header.h"
#include "uwz_quic_fixture.h"

#ifdef NDEBUG
#error "uwz_reset_metadata requires active assertions"
#endif

enum {
    MAX_STEPS = 20000,
    MAX_STREAMS = 8,
};

struct endpoint;

struct stream_state {
    struct endpoint *ss_endpoint;
    lsquic_stream_t *ss_stream;
    lsquic_stream_id_t ss_id;
    unsigned ss_closed;
    unsigned ss_sampled;
    int ss_error_result;
    uint64_t ss_error_output;
    struct lsquic_stream_recv_state ss_receive;
};

struct endpoint {
    lsquic_conn_t *ep_conn;
    unsigned ep_server;
    unsigned ep_handshake_ok;
    unsigned ep_closed;
    unsigned ep_goaway_received;
    unsigned ep_stream_count;
    struct stream_state ep_streams[MAX_STREAMS];
};

struct fixture {
    struct lsquic_test_pair f_transport;
    struct endpoint f_client;
    struct endpoint f_server;
};

static const uint64_t error_canary = UINT64_C(0xA1B2C3D4E5F60718);


static void
sample_metadata (lsquic_stream_t *stream, struct stream_state *state)
{
    state->ss_error_output = error_canary;
    state->ss_error_result = lsquic_stream_get_reset_error(stream, 0,
                                                    &state->ss_error_output);
    memset(&state->ss_receive, 0xA5, sizeof(state->ss_receive));
    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream,
                                                    &state->ss_receive));
    ++state->ss_sampled;
}


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct endpoint *endpoint = ctx;

    endpoint->ep_conn = conn;
    if (endpoint->ep_server)
        endpoint->ep_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct endpoint *endpoint = (struct endpoint *) lsquic_conn_get_ctx(conn);

    assert(status == LSQ_HSK_OK);
    endpoint->ep_handshake_ok = 1;
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct endpoint *endpoint = (struct endpoint *) lsquic_conn_get_ctx(conn);

    ++endpoint->ep_closed;
    endpoint->ep_conn = NULL;
    lsquic_conn_set_ctx(conn, NULL);
}


static void
goaway_received (lsquic_conn_t *conn)
{
    struct endpoint *endpoint = (struct endpoint *) lsquic_conn_get_ctx(conn);

    ++endpoint->ep_goaway_received;
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct endpoint *endpoint = ctx;
    struct stream_state *state;

    assert(stream);
    assert(endpoint->ep_stream_count < MAX_STREAMS);
    state = &endpoint->ep_streams[endpoint->ep_stream_count++];
    state->ss_endpoint = endpoint;
    state->ss_stream = stream;
    state->ss_id = lsquic_stream_id(stream);
    return (lsquic_stream_ctx_t *) state;
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct stream_state *state = (struct stream_state *) ctx;

    if (state->ss_endpoint->ep_goaway_received)
        sample_metadata(stream, state);
    assert(lsquic_stream_wantread(stream, 0) >= 0);
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct stream_state *state = (struct stream_state *) ctx;

    if (state->ss_endpoint->ep_goaway_received)
        sample_metadata(stream, state);
    assert(lsquic_stream_wantwrite(stream, 0) >= 0);
}


static void
close_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct stream_state *state = (struct stream_state *) ctx;

    assert(state->ss_closed == 0);
    if (state->ss_endpoint->ep_goaway_received)
        sample_metadata(stream, state);
    ++state->ss_closed;
    state->ss_stream = NULL;
}


static const struct lsquic_stream_if callbacks = {
    .on_new_conn = new_connection,
    .on_goaway_received = goaway_received,
    .on_conn_closed = connection_closed,
    .on_new_stream = new_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_hsk_done = handshake_done,
};


static void
pump (struct fixture *fixture)
{
    lsquic_test_pair_process(&fixture->f_transport, 1000);
    lsquic_test_deliver_all(&fixture->f_transport.ltp_client);
    lsquic_test_deliver_all(&fixture->f_transport.ltp_server);
}


static void
init_endpoint (struct fixture *fixture, unsigned server)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct endpoint *endpoint;
    struct lsquic_test_endpoint *transport, *peer;
    unsigned flags = LSENG_HTTP | (server ? LSENG_SERVER : 0);

    endpoint = server ? &fixture->f_server : &fixture->f_client;
    endpoint->ep_server = server;
    transport = server ? &fixture->f_transport.ltp_server
                       : &fixture->f_transport.ltp_client;
    peer = server ? &fixture->f_transport.ltp_client
                  : &fixture->f_transport.ltp_server;
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = 8;
    settings.es_max_streams_in = 8;
    settings.es_qpack_dec_max_size = 0;
    settings.es_qpack_dec_max_blocked = 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_alpn = "h3";
    config.ltec_tls = lsquic_test_tls_context_new(server, "h3");
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(transport, peer, &config,
                                        server ? 13101 : 13102));
    SSL_CTX_free(config.ltec_tls);
}


static void
start_fixture (struct fixture *fixture)
{
    unsigned step;

    memset(fixture, 0, sizeof(*fixture));
    init_endpoint(fixture, 0);
    init_endpoint(fixture, 1);
    assert(lsquic_engine_connect(fixture->f_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture->f_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture->f_transport.ltp_server.lte_address,
                &fixture->f_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
    for (step = 0; step < MAX_STEPS; ++step)
    {
        if (fixture->f_client.ep_handshake_ok && fixture->f_server.ep_handshake_ok)
            break;
        pump(fixture);
    }
    assert(step < MAX_STEPS);
    assert(fixture->f_transport.ltp_client.lte_packets_received);
    assert(fixture->f_transport.ltp_server.lte_packets_received);
    for (step = 0; step < 100; ++step)
        pump(fixture);
    assert(fixture->f_client.ep_conn && fixture->f_server.ep_conn);
}


static struct stream_state *
find_stream (struct endpoint *endpoint, lsquic_stream_id_t id)
{
    unsigned index;

    for (index = 0; index < endpoint->ep_stream_count; ++index)
        if (endpoint->ep_streams[index].ss_id == id)
            return &endpoint->ep_streams[index];
    return NULL;
}


static void
send_request_headers (lsquic_stream_t *stream)
{
    static const char *const fields[] = {
        ":methodGET", ":schemehttps", ":authoritylocalhost", ":path/",
    };
    static const unsigned name_sizes[] = { 7, 7, 10, 5 };
    static const unsigned value_sizes[] = { 3, 5, 9, 1 };
    struct lsxpack_header fields_out[4];
    struct lsquic_http_headers headers = { 4, fields_out };
    unsigned index;

    for (index = 0; index < 4; ++index)
        lsxpack_header_set_offset2(&fields_out[index], fields[index], 0,
                    name_sizes[index], name_sizes[index], value_sizes[index]);
    assert(0 == lsquic_stream_send_headers(stream, &headers, 0));
    assert(0 == lsquic_stream_flush(stream));
}


static void
test_goaway_is_not_peer_reset (void)
{
    struct fixture fixture;
    struct stream_state *state;
    unsigned step;

    start_fixture(&fixture);
    lsquic_conn_make_stream(fixture.f_client.ep_conn);
    state = find_stream(&fixture.f_client, 0);
    assert(state && state->ss_stream);
    send_request_headers(state->ss_stream);
    for (step = 0; step < MAX_STEPS; ++step)
    {
        if (find_stream(&fixture.f_server, 0))
            break;
        pump(&fixture);
    }
    assert(step < MAX_STEPS);
    lsquic_conn_make_stream(fixture.f_client.ep_conn);
    state = find_stream(&fixture.f_client, 4);
    assert(state && state->ss_stream);
    sample_metadata(state->ss_stream, state);
    assert(state->ss_error_result == LSQUIC_SERR_UNAVAILABLE);
    assert(state->ss_error_output == error_canary);
    assert(state->ss_receive.flags == 0);
    state->ss_sampled = 0;

    /* RFC 9114 section 5.2: GOAWAY rejects unused requests locally. */
    lsquic_conn_going_away(fixture.f_server.ep_conn);
    for (step = 0; step < MAX_STEPS; ++step)
    {
        pump(&fixture);
        if (!fixture.f_client.ep_goaway_received)
            continue;
        if (state->ss_stream)
            sample_metadata(state->ss_stream, state);
        if (state->ss_sampled)
            break;
    }
    assert(step < MAX_STEPS);
    assert(fixture.f_client.ep_goaway_received == 1);
    assert(state->ss_sampled);
    if (state->ss_error_result != LSQUIC_SERR_UNAVAILABLE)
        fprintf(stderr, "GOAWAY fabricated peer RESET error: result=%d value=%llu flags=%u\n",
                state->ss_error_result, (unsigned long long) state->ss_error_output,
                state->ss_receive.flags);
    assert(state->ss_error_result == LSQUIC_SERR_UNAVAILABLE);
    assert(state->ss_error_output == error_canary);
    assert(!(state->ss_receive.flags & LSQUIC_SRS_RESET_KNOWN));
    assert(!(state->ss_receive.flags & LSQUIC_SRS_RESET_VISIBLE));
    assert(state->ss_receive.reset_error_code == 0);
    lsquic_test_endpoint_destroy(&fixture.f_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture.f_transport.ltp_server);
    puts("PASS encrypted H3 GOAWAY local rejection exposes no peer RESET metadata");
}


int
main (void)
{
    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    test_goaway_is_not_peer_reset();
    lsquic_global_cleanup();
    return 0;
}
