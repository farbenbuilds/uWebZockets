/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <sys/queue.h>

#include <openssl/ssl.h>

#include "lsquic.h"
#include "uwz_quic_fixture.h"

#ifdef NDEBUG
#error "uwz_reset_http requires active assertions"
#endif

/* Existing sender seam: frames still traverse encryption and packet ingress. */
extern void lsquic_stream_maybe_reset (lsquic_stream_t *, uint64_t, int);

enum {
    MAX_STEPS = 20000,
    MAX_STREAMS = 16,
};

struct endpoint;

struct stream_state {
    lsquic_stream_t *ss_stream;
    lsquic_stream_id_t ss_id;
    unsigned ss_closed;
};

struct endpoint {
    lsquic_conn_t *ep_conn;
    unsigned ep_server;
    unsigned ep_handshake_ok;
    unsigned ep_closed;
    unsigned ep_stream_count;
    enum LSQUIC_CONN_STATUS ep_close_status;
    char ep_close_reason[160];
    struct stream_state ep_streams[MAX_STREAMS];
};

struct fixture {
    struct lsquic_test_pair f_transport;
    struct endpoint f_client;
    struct endpoint f_server;
};


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct endpoint *endpoint = ctx;

    endpoint->ep_conn = conn;
    if (endpoint->ep_server)
        endpoint->ep_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct endpoint *endpoint = (struct endpoint *) lsquic_conn_get_ctx(conn);

    assert(status == LSQ_HSK_OK);
    endpoint->ep_handshake_ok = 1;
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct endpoint *endpoint = (struct endpoint *) lsquic_conn_get_ctx(conn);

    endpoint->ep_close_status = lsquic_conn_status(conn,
                        endpoint->ep_close_reason, sizeof(endpoint->ep_close_reason));
    ++endpoint->ep_closed;
    endpoint->ep_conn = NULL;
    lsquic_conn_set_ctx(conn, NULL);
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct endpoint *endpoint = ctx;
    struct stream_state *state;

    assert(stream);
    assert(endpoint->ep_stream_count < MAX_STREAMS);
    state = &endpoint->ep_streams[endpoint->ep_stream_count++];
    state->ss_stream = stream;
    state->ss_id = lsquic_stream_id(stream);
    return (lsquic_stream_ctx_t *) state;
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *UNUSED_ctx)
{
    assert(lsquic_stream_wantread(stream, 0) >= 0);
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *UNUSED_ctx)
{
    assert(lsquic_stream_wantwrite(stream, 0) >= 0);
}


static void
close_stream (lsquic_stream_t *UNUSED_stream, lsquic_stream_ctx_t *ctx)
{
    struct stream_state *state = (struct stream_state *) ctx;

    assert(state->ss_closed == 0);
    ++state->ss_closed;
    state->ss_stream = NULL;
}


static const struct lsquic_stream_if callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_new_stream = new_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_hsk_done = handshake_done,
};


static void
pump (struct fixture *fixture, unsigned steps)
{
    unsigned step;

    for (step = 0; step < steps; ++step)
    {
        lsquic_test_pair_process(&fixture->f_transport, 1000);
        lsquic_test_deliver_all(&fixture->f_transport.ltp_client);
        lsquic_test_deliver_all(&fixture->f_transport.ltp_server);
    }
}


static void
init_endpoint (struct fixture *fixture, unsigned server)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct endpoint *endpoint;
    struct lsquic_test_endpoint *transport, *peer;
    unsigned flags = server ? LSENG_SERVER | LSENG_HTTP : 0;

    endpoint = server ? &fixture->f_server : &fixture->f_client;
    endpoint->ep_server = server;
    transport = server ? &fixture->f_transport.ltp_server
                       : &fixture->f_transport.ltp_client;
    peer = server ? &fixture->f_transport.ltp_client
                  : &fixture->f_transport.ltp_server;
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = 8;
    settings.es_max_streams_in = 8;
    settings.es_qpack_dec_max_size = 0;
    settings.es_qpack_dec_max_blocked = 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_alpn = "h3";
    config.ltec_tls = lsquic_test_tls_context_new(server, "h3");
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(transport, peer, &config,
                                        server ? 13001 : 13002));
    SSL_CTX_free(config.ltec_tls);
}


static void
start_fixture (struct fixture *fixture)
{
    unsigned step;

    memset(fixture, 0, sizeof(*fixture));
    init_endpoint(fixture, 0);
    init_endpoint(fixture, 1);
    assert(lsquic_engine_connect(fixture->f_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture->f_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture->f_transport.ltp_server.lte_address,
                &fixture->f_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
    for (step = 0; step < MAX_STEPS; ++step)
    {
        if (fixture->f_client.ep_handshake_ok && fixture->f_server.ep_handshake_ok)
            break;
        pump(fixture, 1);
    }
    assert(step < MAX_STEPS);
    assert(fixture->f_client.ep_conn && fixture->f_server.ep_conn);
    assert(fixture->f_transport.ltp_client.lte_packets_received);
    assert(fixture->f_transport.ltp_server.lte_packets_received);
    pump(fixture, 50);
}


static struct stream_state *
make_client_uni (struct fixture *fixture)
{
    struct endpoint *endpoint = &fixture->f_client;
    unsigned index;

    assert(0 == lsquic_conn_make_uni_stream(endpoint->ep_conn));
    for (index = 0; index < endpoint->ep_stream_count; ++index)
        if (endpoint->ep_streams[index].ss_id == 2)
            return &endpoint->ep_streams[index];
    assert(!"client stream 2 was not created");
    return NULL;
}


static void
cleanup_fixture (struct fixture *fixture)
{
    lsquic_test_endpoint_destroy(&fixture->f_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture->f_transport.ltp_server);
}


static void
assert_connected (const struct fixture *fixture)
{
    if (fixture->f_server.ep_closed)
        fprintf(stderr, "unexpected H3 close: %d %s\n",
                fixture->f_server.ep_close_status, fixture->f_server.ep_close_reason);
    assert(fixture->f_server.ep_closed == 0);
    assert(fixture->f_client.ep_closed == 0);
    assert(fixture->f_server.ep_conn);
    assert(LSCONN_ST_CONNECTED == lsquic_conn_status(
                                fixture->f_server.ep_conn, NULL, 0));
}


static void
test_reset_before_stream_type (void)
{
    struct fixture fixture;
    struct stream_state *state;
    unsigned packets_before;

    start_fixture(&fixture);
    state = make_client_uni(&fixture);
    packets_before = fixture.f_transport.ltp_server.lte_packets_received;
    lsquic_stream_maybe_reset(state->ss_stream, 0x10C, 1);
    pump(&fixture, 1000);
    assert(fixture.f_transport.ltp_server.lte_packets_received > packets_before);
    /* RFC 9114 section 6.2 permits reset before the type is received. */
    assert_connected(&fixture);
    cleanup_fixture(&fixture);
    puts("PASS encrypted ordinary RESET before H3 uni type keeps connection live");
}


static void
test_reset_reserved_stream_type (void)
{
    static const unsigned char reserved_type = 0x21;
    struct fixture fixture;
    struct stream_state *state;

    start_fixture(&fixture);
    state = make_client_uni(&fixture);
    assert(1 == lsquic_stream_write(state->ss_stream, &reserved_type, 1));
    assert(0 == lsquic_stream_flush(state->ss_stream));
    pump(&fixture, 100);
    assert_connected(&fixture);
    if (state->ss_stream)
        lsquic_stream_maybe_reset(state->ss_stream, 0x10C, 1);
    pump(&fixture, 1000);
    /* RFC 9114 section 6.2.3 permits ignoring reserved stream types. */
    assert_connected(&fixture);
    cleanup_fixture(&fixture);
    puts("PASS encrypted ordinary RESET on reserved H3 uni type keeps connection live");
}


int
main (void)
{
    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    test_reset_before_stream_type();
    test_reset_reserved_stream_type();
    lsquic_global_cleanup();
    return 0;
}
