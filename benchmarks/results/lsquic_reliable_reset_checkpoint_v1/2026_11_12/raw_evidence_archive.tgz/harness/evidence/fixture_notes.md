# Reliable reset: initial test contract

All source changes are confined to the new scratch fork
`/tmp/uwz-lsquic-reliable-reset-20261111`, based on
`0f7382b17b38d7fb0496a0b75b3c66ace79e49e8`. The finalized prior uni proposal,
its harness/evidence, root production sources, dependency pins, and caches are
not edited by this fixture work. Build graph ownership remains with root.

`uwz_quic_fixture.{h,c}` shares only bounded encrypted datagram transport,
TLS setup, engine processing/teardown, and the existing three clock/fault seams.
The stream/connection callbacks remain in their case files. Seven original
uni callback bodies are byte-identical and all eight original PASS group strings
are retained. Queue storage is caller-owned: 256 packets of at most 4096 bytes
per endpoint. Engine processing and packet extraction/delivery are separate;
`packet_in` is never recursively invoked inside `packets_out`.

The existing test TLS constructor preserves TLS 1.3, fixed certificate dates,
and its in-memory self-signed test policy. It does not prove server identity.
Endpoint initialization retains the caller-supplied `SSL_CTX` and never changes
its verification policy. Later external tests supply their explicit CA/certificate
context separately. No private key is exported by this helper.

The first RED is deliberately narrow: two production engines complete a real
encrypted handshake; existing server uni streams 3 and 7 deliver exact bytes and
FIN and close once. The primary contains the exact 33-byte reliable-prefix
candidate followed by 4096 `x` bytes; the healthy sibling has its exact 33-byte
payload. After teardown, missing weak reset/getter symbols produce expected
exit 1. Their presence produces exit 2 until this initial absence gate is
replaced by the negotiated behavioral matrix. This initial RED does not claim
prefix/reset loss, reset-first delivery, or draft transport-parameter support.
No reset advertisement or WebTransport capability is enabled here.

The target is specifically
[reliable-stream-reset draft-09](https://datatracker.ietf.org/doc/html/draft-ietf-quic-reliable-stream-reset-09),
as referenced by [WebTransport draft-16](https://www.ietf.org/archive/id/draft-ietf-webtrans-http3-16.html#section-4.4).
The accepted design uses empty receive-willingness transport parameter `0x1d`
and RESET_STREAM_AT frame `0x24`, default off. The reset API and accessor follow
the root-approved prototypes; later behavior must wait for required bytes to be
application-consumed before callback/getter/read-error reset visibility.

The separately pinned Go oracle contract uses QUIC v1, TLS 1.3 and ALPN
`uwz-reset-test/1`. Client streams 2 and 6 are mirrored by server streams 3 and 7.
The first stream writes `uwz-reset-test/1 reliable prefix\n` (33 bytes), marks
its reliable boundary, writes 4096 `x` bytes, and resets with application code
`0x175` (373). The healthy stream writes
`uwz-reset-test/1 healthy sibling\n` (33 bytes) and FIN. The receiver must receive
the full prefix before remote reset 373; zero through 4096 suffix bytes are
permitted. The Go peer may report 4129 logical bytes written without that being
its exact wire final size. The native sender may use final size 4129. The oracle
uses CA-validated localhost TLS and finite 10-second contexts/deadlines. Native
UDP interop is a subsequent test, not a library build dependency.

Planned required follow-ups retain all eight uni groups and add both roles and
directions, loss/reordering/delayed reads, shrinking reset boundaries, obsolete
ACK references, FIN/ordinary RESET/STOP_SENDING interactions, final-size credit
ownership, and HTTP HEADERS/blocked-QPACK/partial-consumption/callback-close
visibility. Required HTTP headers must remain publicly retrievable even when
internal read offsets have advanced. Frozen final-size credit must not be
refunded through STOP/zero-boundary/destroy paths or reused by a sibling.
