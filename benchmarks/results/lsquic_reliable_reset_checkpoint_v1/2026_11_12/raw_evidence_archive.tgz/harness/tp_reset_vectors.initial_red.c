/* Copyright (c) 2026 LiteSpeed Technologies Inc.  See LICENSE. */
#include <stdint.h>
#include <stdio.h>

#include "lsquic.h"
#include "lsquic_types.h"
#include "lsquic_sizes.h"
#include "lsquic_trans_params.h"


struct reset_tp_vector
{
    const char          *name;
    const unsigned char *encoded;
    size_t               size;
    int                  reject;
};


static const unsigned char empty_value[] = { 0x1D, 0x00 };
static const unsigned char nonempty_value[] = { 0x1D, 0x01, 0x00 };
static const unsigned char duplicate_empty[] = { 0x1D, 0x00, 0x1D, 0x00 };
static const unsigned char duplicate_wide_id[] =
                                      { 0x1D, 0x00, 0x40, 0x1D, 0x00 };

static const struct reset_tp_vector vectors[] =
{
    { "empty", empty_value, sizeof(empty_value), 0 },
    { "nonempty", nonempty_value, sizeof(nonempty_value), 1 },
    { "duplicate", duplicate_empty, sizeof(duplicate_empty), 1 },
    { "duplicate-wide-id", duplicate_wide_id, sizeof(duplicate_wide_id), 1 },
};


int
main (void)
{
    struct transport_params params;
    unsigned failures = 0;
    unsigned i;
    int is_server, result;

    for (is_server = 0; is_server <= 1; ++is_server)
        for (i = 0; i < sizeof(vectors) / sizeof(vectors[0]); ++i)
        {
            result = lsquic_tp_decode(vectors[i].encoded, vectors[i].size,
                                                        is_server, &params);
            if ((result < 0) != vectors[i].reject)
            {
                fprintf(stderr, "%s TP from %s: expected %s, got %d\n",
                    vectors[i].name, is_server ? "server" : "client",
                    vectors[i].reject ? "rejection" : "acceptance", result);
                ++failures;
            }
        }

    return failures != 0;
}
