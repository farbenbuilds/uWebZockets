const std = @import("std");
const boringssl = @import("builds/vendor/boringssl.zig");
const lsquic = @import("builds/vendor/lsquic.zig");
const sanitizers = @import("builds/sanitizers.zig");
const zlib = @import("builds/vendor/zlib.zig");
const upstream = @import("upstream_tests.zig");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const sanitizer = sanitizers.configure(b, target, true);
    const upstream_mode = b.option(bool, "upstream-tests", "Run the native upstream assertion suite") orelse false;
    const fixture_hooks = b.option(bool, "fixture-hooks", "Enable fixture-only clock and failure symbols") orelse !upstream_mode;
    const bssl = boringssl.build(b, target, optimize, sanitizer);
    const z = zlib.build(b, target, optimize, sanitizer);
    const ls = lsquic.build(b, target, optimize, sanitizer, bssl, z, fixture_hooks);

    const libraries = b.step("libraries", "Compile real native dependency objects");
    libraries.dependOn(&ls.library.step);

    if (upstream_mode) {
        upstream.configure(b, target, optimize, sanitizer, ls, bssl, z);
        return;
    }

    const fixture_path = b.option([]const u8, "fixture", "Public-engine C fixture") orelse
        "/tmp/uwz-lsquic-reliable-reset-20261111/tests/uwz_reliable_reset.c";
    const source_path = b.option([]const u8, "fixture-includes", "Private type include directory") orelse
        "/tmp/uwz-lsquic-reliable-reset-20261111/src/liblsquic";
    const support_path = b.option([]const u8, "fixture-support", "Shared fixture C source");
    const fixture_name = b.option([]const u8, "fixture-name", "Fixture executable name") orelse
        "uwz_reliable_reset";
    const module = b.createModule(.{
        .target = target,
        .optimize = optimize,
        .link_libc = true,
    });
    module.addIncludePath(ls.include_root);
    module.addIncludePath(bssl.include_root);
    module.addIncludePath(ls.assembled_root.path(b, "src/lshpack"));
    module.addIncludePath(ls.assembled_root.path(b, "src/liblsquic/ls-qpack"));
    module.addIncludePath(.{ .cwd_relative = source_path });
    const fixture_flags = sanitizers.instrumented_flags(b, &.{
        "-std=gnu11",
        "-UNDEBUG",
        "-D__wrap_lsquic_time_now=lsquic_time_now",
        "-Wall",
        "-Wextra",
        "-fno-omit-frame-pointer",
    }, sanitizer);
    module.addCSourceFile(.{
        .file = .{ .cwd_relative = fixture_path },
        .flags = fixture_flags,
    });
    if (support_path) |path| module.addCSourceFile(.{
        .file = .{ .cwd_relative = path },
        .flags = fixture_flags,
    });
    module.linkLibrary(ls.library);
    module.linkLibrary(bssl.ssl);
    module.linkLibrary(bssl.crypto);
    module.linkLibrary(z.library);
    sanitizer.attach(module);
    const fixture = b.addExecutable(.{
        .name = fixture_name,
        .root_module = module,
    });
    b.installArtifact(fixture);
    const run = sanitizers.add_run_artifact(b, fixture, sanitizer.run);
    if (b.args) |args| run.addArgs(args);
    const test_step = b.step("test", "Run real-engine protocol checks");
    test_step.dependOn(&run.step);
}
