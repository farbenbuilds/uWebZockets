# Reliable reset core handoff

The parent orchestration agent is reported errored by collaboration.list_agents
(content-risk flag).  No child compiler or test session is active from this
implementation agent.  Parent-owned handles may require inspection on resume;
do not infer they are terminal from the agent error alone.

## Frozen implementation

- Repository: /tmp/uwz-lsquic-reliable-reset-20261111
- Base: 0f7382b17b38d7fb0496a0b75b3c66ace79e49e8
- Exact 17 owned C/header hashes:
  /tmp/uwz-lsquic-reset-core-pre-rx-fixes.sha256
- Immutable owned production diff:
  /tmp/uwz-lsquic-reset-core-pre-rx-fixes.diff
- All 17 hashes were rechecked successfully at handoff.
- docs/apiref.rst and docs/internals.rst also contain the public API and
  ownership/ACK contract.  They are outside the 17-file C manifest.
- The crypto owner's trans_params.h/.c and enc_sess_ietf.c changes are separate
  ownership and are not included in this diff/manifest.
- No commits, remote writes, pins, root source, vendor source, or caches changed
  by this agent.  The previous uni proposal remains untouched.

The API, codecs, defaults, RX metadata/state, TX state, native packet retention,
resize and true-ACK hooks are implemented.  **The TX/ACK checkpoint has not been
compiled or run.**  It deliberately retains the two independently reviewed RX
defects below because root required targeted snapshot RED before their edits.
Receive advertisement remains held, and default receive setting remains zero.

## Verified evidence already reported by root

1. Baseline eight real-engine groups: Debug exit 0, 12/12 steps.
2. Initial API-absent RED: actual encrypted TLS, stream IDs 3/7, prefix 33 plus
   suffix 4096, healthy sibling 33 with FIN/close, then exit 1 for missing API.
   This is not yet a lost-prefix proof.
3. First wire gate: four standalone Debug units, all terminal 0 / 12-of-12:
   codec, independent TP/settings vectors, crypto TP vectors including legacy,
   and 4096-input bounded codec smoke.
4. RX-first old-eight regression: Debug exit 0, 12/12.  Frozen snapshot:
   /tmp/uwz-lsquic-reset-rx-first-20261111
5. Initial resumption RED: missing advertised peer parameter while advertisement
   is intentionally held.  It is not accepted/rejected 0-RTT coverage.

Evidence roots:
/tmp/uwz-lsquic-reset-harness/evidence/first-wire-gate
/tmp/uwz-lsquic-reset-harness/evidence/rx-first-gate
/tmp/uwz-lsquic-reset-baseline-debug.log
/tmp/uwz-lsquic-reset-initial-red.log

## Immediate pending RX corrections (do not skip root's RED gate)

P1: new_stream() marks incoming HTTP uni IDs below 12 critical before learning
their type.  process_stream_reset() then rejects a valid unclassified or
reserved-type reset as connection-wide H3_CLOSED_CRITICAL_STREAM.  The proposed
correction is to remove this numeric ctor heuristic and set SMBF_CRITICAL in
the actual CONTROL/QPACK_ENC/QPACK_DEC classifier branches, before interface
callbacks.  A pending reliable reset must also reject actual critical ownership
if classification establishes it later.  A validated delivered/canceled incoming
uni reset needs its absent send half U_WRITE_DONE|FORCE_FINISH so an incomplete
HTTP classifier can close without an impossible outgoing FIN.  Root accepted
the latter invariant conditional on correct critical classification.

P2: get_reset_error(how=0) and snapshot RESET_VISIBLE currently check only
STREAM_RST_RECVD.  fake_reset_unused_stream() sets that flag locally for GOAWAY.
Require SMDF_RESET_KNOWN as well, preserving the error-output canary on failure.

The root-assigned test owner prepared and froze two real-engine regressions,
but no terminal targeted RED has been sent to this agent:

- tests/uwz_reset_http.c
  ef3010563c4a5f108facedd634a65fc70747ce3b961330fb908b43a1b4f7f476
- tests/uwz_reset_metadata.c
  eeb3a85e4c9d66bbc6a1c87327b37b57bf7e6997ed926e29d480864b56dd07c5

Both target the immutable RX-first snapshot and do not call reset_at.

## Additional source-audit findings sent to root, awaiting correction release

1. A partial HEADERS block can be QPACK-blocked immediately after Required
   Insert Count while read_offset < R and its known end
   read_offset+hqfi_left > R.  The current completion gate can then wait for
   an unpromised block tail/insert.  Proposed refinement: after earlier UH is
   consumed and data_in has contiguous bytes through R, consume/discard that
   incomplete block's remaining wire prefix to R through the existing raw
   reader, cancel its QPACK context normally, then publish reset.  No extra
   state or persistent skip mode is required if done only once all remaining
   prefix bytes are contiguous.  Fully promised blocks must still decode and
   their resulting UH must be publicly consumed.  Add a partial blocked-block
   regression, not only an unblocked partial-block case.
2. Native stream_reset(..., do_close=0), used by STOP_SENDING's ordinary
   fallback, still cancels receive QPACK ownership and clears all sending flags
   including receive MAX_STREAM_DATA/STOP_SENDING.  Proposed narrow fix:
   cancel read QPACK only for do_close; preserve receive signals for IETF write
   resets, while keeping gQUIC all-flags behavior.  The new reset_at TX path
   already preserves both.  Add STOP while opposite receive headers are pending.

These are source findings, not claims of observed runtime failures.  No edits
for them were made after the core freeze.

Already included source refinements: zero-R or block-end-beyond-R skips the
zero-byte QPACK completion attempt; late valid FIN after visible reset records
FIN_RECEIVED; reducing a completed but not yet on_closed TX reset cancels queued
on_close/free before creating the new minimum; final-size debit is retained
through suffix dropping, including optional debug accounting.  Ordinary FIN's
inherited duplicate handling and first-FIN-below-seen-max checks need test
coverage before any broader legacy FIN change; those behaviors were not edited.

## True ACK implementation contract

Five uint64_t stream fields add an expected 40 bytes; no packet/frame metadata
fields were added.  Packet flag bit 18 marks in-place obsolete-frame padding.
Old suffix/obsolete reset frames are zeroed to PADDING rather than copied.
Required boundary STREAM frames are retained whole, allowing optional bytes
beyond R.  Buffered data is flushed through the first native frame reaching R,
with FIN suppressed, then unsent suffix is dropped without refunding final size.

lsquic_packet_out_ack_reset_frames() is called only at actual regular ACK and
the acknowledged-loss-chain path, never generic chain destruction.  It parses
retained reset wire identity and acknowledges only current error/final/minimum.
lsquic_stream_acked() remains reference release and cannot set new TX reset ACK.
Smaller resets are generated on native fresh chains; old frames are not rewritten
to a smaller boundary.  Obsolete empty chain members are detached individually.

lsquic_send_ctl_reset_ack_scan() runs once at the start of a service batch for
all queued candidates, traversing retained packet queues once.  Candidate proof
is initialized from materialized offset then cleared for outstanding STREAM
records intersecting the required prefix.  Existing service flag bit 12 owns
the transient work; no new queue/registry is introduced.

Test-only observer under LSQUIC_RESET_ACK_TEST_OBSERVER in send_ctl.h:

    struct lsquic_reset_ack_scan_stats {
        size_t candidates;
        size_t packets;
        size_t frames;
    };
    void lsquic_reset_ack_scan_observer(const struct lsquic_conn *,
                            const struct lsquic_reset_ack_scan_stats *);

One callback per nonempty pass, real connection handle, stack summary valid
only during callback.  Observer is read-only.  Production has no counts,
summary storage, or callback.  Root explicitly approved this macro seam.

## Fixtures and remaining acceptance

The current tests/uwz_reliable_reset.c matches
/tmp/uwz-lsquic-reset-harness/uwz_reset_engine_draft.c at
d79688ea6b373b2bb49cf9bc18b81aa65f50ccfdc5be3c39957ebee7367a0ec9.
It implements, but has not run, both-role real prefix loss/reset-first recovery,
32-of-33-byte withholding, exact error 373, snapshot and healthy sibling FIN.
Prefix identity proof drains handshake ACKs and both queues, flushes only 33
bytes, asserts exactly one new encrypted packet and actual stream.tosend_off
>=33, then removes that packet before suffix/reset.  No production observer
was added for packet identity.

The protocol test owner reported these still missing: zero/ordinary comparison,
unsupported/invalid/CLOSED statuses, smaller/repeated resets, obsolete ACK and
reference-elision proof, batch observer assertions, reset-packet loss, STOP/FIN,
cancellation, frozen final credit/sibling reuse, callback close, HTTP header and
blocked/partial QPACK cases, native oracle interoperability, final sanitizers.
Resumption fixtures are owned separately by the crypto specialist.

The native public-API-only oracle source is
/tmp/uwz-lsquic-reset-harness/oracle_peer.c.  Root owns compilation/execution.

Root's header-only native layout probe measured EngineSettings size unchanged
352/alignment8, old es_max_header_sets offset344, new setting offset348 in old
padding, recv snapshot size40.  Private stream/packet/frame sizes and cross-ABI
verification remain unrun; expected deltas are +40/0/0, not verified results.

Resume in this order: recover parent-owned live handles, run snapshot targeted
REDs, release/apply RX corrections, review/refreeze, explicitly release crypto
receive advertisement plus SERVER_0RTT_TPS bit, jointly freeze/hash, then root
serializes compile/real-engine tests.  All affected native units, strict
ASan/UBSan/LSan, external oracle, cross checks and independent code review remain
required before acceptance.  Do not activate root capabilities or 0-RTT.
