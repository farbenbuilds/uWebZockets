#!/usr/bin/env python3
"""Replay with exact archived ELFs and a fresh, separately bound SCRAM fixture."""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys

from bundle_files import check_manifest, load, require, sha
from verify_bundle import BUNDLE, WORK, WRK, RecordedPath, bind_paired_checker


HISTORICAL_FIXTURE = '6e845754beeadbccb1e22b55d60d2eaeee4cd8a66a05a75cb968cec349ca57fa'
HOST_LABEL = 'sql-d5-throughput-20261119-host'
IMAGE = 'postgres@sha256:e3d24f6906d0760bf4da0dae872415391ededefad23fd471c47dc53b0ddf3c42'
TMPFS = {'/var/lib/postgresql': ''}
IDENTITY_SQL = """SELECT json_build_object('data_directory', current_setting('data_directory'),
 'postmaster_started',pg_postmaster_start_time(),'owner',current_user,'database',current_database(),
 'port',current_setting('port'),'listen',current_setting('listen_addresses'),'local',inet_client_addr() IS NULL,
 'tcp_clients',(SELECT count(*) FROM pg_stat_activity WHERE client_addr IS NOT NULL));"""


def run(work, *args):
    env = dict(os.environ, PYTHONPATH=os.pathsep.join((str(work), str(work / 'runner'))))
    subprocess.run([sys.executable, '-B', *args], cwd=work, env=env, check=True)


def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def derive(original, target, replacements):
    text = original.read_text()
    for old, new in replacements:
        require(text.count(old) == 1, 'Unexpected frozen replay derivation input')
        text = text.replace(old, new, 1)
    compile(text, str(target), 'exec')
    target.write_text(text)


def stage(work):
    for pattern in ('runner/*.py', 'runner/*.lua', 'verification/verify_host.py', 'host_fixture/*.py',
                    'fixture/world.sql', 'fixture/world_initial.jsonl', 'fixture/settings.json', 'measurements/bridge_count20/metadata.json',
                    'measurements/host_count20/metadata.json', 'measurements/host_count20/fixed_queries/ready_app_*.stdout'):
        for source in WORK.glob(pattern):
            copy(source, work / source.relative_to(WORK))


def owned_marker(private, name):
    path = private / name
    details = path.lstat()
    require(stat.S_ISREG(details.st_mode) and details.st_uid == os.geteuid() and stat.S_IMODE(details.st_mode) == 0o600,
            f'Fixture identity file has unexpected ownership or mode: {name}')
    return path.read_text().strip()


def capture_runtime_identity(host):
    public, private = host / 'fixture', host / 'private'
    details = private.lstat()
    require(stat.S_ISDIR(details.st_mode) and details.st_uid == os.geteuid() and stat.S_IMODE(details.st_mode) == 0o700,
            'Replay fixture private directory is not owned and private')
    fixture = load(public / 'fixture.json')
    container, owner, port = (fixture[key] for key in ('container', 'owner_token', 'pg_socket_port'))
    require(re.fullmatch(r'[0-9a-f]{64}', container) and re.fullmatch(r'[0-9a-f]{32}', owner) and
            type(port) is int and 0 < port <= 65535 and port == fixture['pg_host_port'] and port != fixture['http_port'] and
            fixture['label'] == HOST_LABEL and fixture['image'] == IMAGE and fixture['postgresql_network'] == 'host_loopback' and
            (fixture['pg_user'], fixture['pg_database']) == ('bench', 'benchmark') and
            [owned_marker(private, name) for name in ('container.id', 'owner_token', 'pg_port')] == [container, owner, str(port)],
            'Fresh fixture ownership, database or assigned port differs')
    listener_path = public / 'listener.json'
    settings_path = public / 'settings.json'
    require(sha(listener_path) == fixture['listener_sha256'] and sha(settings_path) == fixture['settings_sha256'],
            'Fresh fixture listener or settings receipt differs')
    listener = load(listener_path)
    settings = load(settings_path)
    labels = {'uwz.sql-experiment': HOST_LABEL, 'uwz.role': 'database', 'uwz.run-token': owner}
    fields = ('Id', 'State.Pid', 'State.Running', 'Config.Labels', 'Config.Image', 'HostConfig.NetworkMode',
              'HostConfig.Tmpfs', 'HostConfig.PortBindings', 'Config.Cmd')
    inspect = ['docker', 'inspect', '--format', '\n'.join('{{json .' + field + '}}' for field in fields), container]
    cid, pid, running, live_labels, image, network, tmpfs, binds, command = map(
        json.loads, subprocess.check_output(inspect, text=True, timeout=10).splitlines())
    expected_command = ['-c', 'max_connections=100', '-c', 'listen_addresses=127.0.0.1', '-c', f'port={port}']
    require(cid == listener['container'] == container and type(pid) is int and pid > 0 and pid == listener['pid'] and
            running is True and live_labels == labels and image == IMAGE and network == listener['network_mode'] == 'host' and
            tmpfs == TMPFS and binds in (None, {}) and port == listener['pg_port'] and command == listener['pg_command'] == expected_command,
            'Replay container or listener topology differs')
    cgroup = Path(f'/proc/{pid}/cgroup').read_text()
    paths = [line[3:] for line in cgroup.splitlines() if line.startswith('0::')]
    require(cgroup == listener['cgroup'] and len(paths) == 1 and Path(paths[0]).name in (container, f'docker-{container}.scope'),
            'Replay PostgreSQL PID belongs to a different cgroup')
    argv = ['docker', 'exec', '-i', container, 'psql', '-qXAt', '-w', '-h', '/var/run/postgresql', '-p', str(port),
            '-U', 'bench', '-d', 'benchmark', '-vON_ERROR_STOP=1', '-c', IDENTITY_SQL]
    row = json.loads(subprocess.check_output(argv, text=True, timeout=10))
    require(row == {'data_directory': '/var/lib/postgresql/18/docker', 'postmaster_started': settings['postmaster'],
                    'owner': 'bench', 'database': 'benchmark', 'port': str(port), 'listen': '127.0.0.1',
                    'local': True, 'tcp_clients': 0}, 'Replay PostgreSQL identity changed or has TCP clients')
    identity = {'container': container, 'pid': pid, 'cgroup': cgroup, 'labels': labels, 'tmpfs': tmpfs,
                'postgresql': {key: row[key] for key in ('data_directory', 'postmaster_started', 'owner', 'port')},
                'inspect_argv': inspect, 'argv': argv, 'listener_sha256': sha(listener_path), 'private_inputs_recorded': False}
    with (public / 'unit_runtime_identity.json').open('x') as output:
        output.write(json.dumps(identity, indent=2) + '\n')
    return port


def bind_host_helpers(host):
    port = capture_runtime_identity(host)
    for name in ('setup_unit_fixture', 'repair_hba'):
        derive(host / f'{name}.py', host / f'{name}_replay.py', [
            ('port == fixture["pg_host_port"] == 59761', f'port == fixture["pg_host_port"] == {port}'),
        ])


def bind(work, archived_receipts):
    fixture = work / 'host_fixture/fixture/fixture.json'
    proof = fixture.parent / 'hba_repair/verified.json'
    fixtures = (fixture, fixture.parent / 'world_initial.jsonl', proof)
    lua = work / 'runner/status.lua'
    identity = {path.relative_to(work).as_posix(): sha(path) for path in (*fixtures, lua)}
    require(identity['host_fixture/fixture/world_initial.jsonl'] == sha(WORK / 'host_fixture/fixture/world_initial.jsonl'),
            'Fresh fixture does not have identical World bytes')
    fixture_sha = identity['host_fixture/fixture/fixture.json']
    require(fixture_sha != HISTORICAL_FIXTURE, 'Expected an independently owned replay fixture')
    receipts = {arm: {key: str(RecordedPath(value).archived()) if key in ('source', 'build', 'binary') else value
                      for key, value in receipt.items()} for arm, receipt in archived_receipts.items()}
    binding = {'scope': 'fresh local SCRAM replay', 'wrk': str(WRK), 'wrk_sha256': sha(WRK),
               'identities': identity, 'variants': receipts}
    record = work / 'replay_binding.json'
    record.write_text(json.dumps(binding, indent=2) + '\n')
    loader = work / 'replay_binding.py'
    loader.write_text('import json\nfrom pathlib import Path\n'
                      'binding = json.loads(Path(__file__).with_name("replay_binding.json").read_text())\n'
                      'def replay_receipts():\n    return binding["variants"]\n')
    common = [('import argparse\n', 'import argparse\nfrom replay_binding import replay_receipts\n'),
              (HISTORICAL_FIXTURE, fixture_sha), ('source_receipts()', 'replay_receipts()')]
    derive(WORK / 'runner/measure_queries_pair.py', work / 'runner/measure_queries_replay.py', common + [
        ('args.wrk, args.lua, args.fixture, args.app_env = WRK,',
         f'args.wrk, args.lua, args.fixture, args.app_env = Path({str(WRK)!r}),'),
        ('digest(args.lua) == frozen["sha256"][str(args.lua)]', f'digest(args.lua) == {sha(lua)!r}'),
    ])
    derive(WORK / 'verification/verify_queries_pair.py', work / 'verification/verify_queries_replay.py', common + [
        ('from runner.measure_queries_pair import PAIR_LABELS, STATS_SQL',
         'from runner.measure_queries_replay import PAIR_LABELS, STATS_SQL'),
        ('metadata["wrk"] == str(WRK) and digest(WRK) == WRK_SHA',
         f'metadata["wrk"] == {str(WRK)!r} and digest(Path(metadata["wrk"])) == WRK_SHA'),
    ])
    binding['derived_harness'] = {name: sha(work / name) for name in ('runner/measure_queries_replay.py',
                                                                         'verification/verify_queries_replay.py',
                                                                         'host_fixture/setup_unit_fixture_replay.py',
                                                                         'host_fixture/repair_hba_replay.py')}
    binding['runtime_identity_sha256'] = sha(work / 'host_fixture/fixture/unit_runtime_identity.json')
    record.write_text(json.dumps(binding, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('fresh_work_directory', type=Path)
    args = parser.parse_args()
    work = args.fresh_work_directory.resolve()
    require(not work.is_relative_to(BUNDLE), 'Replay must use a fresh directory outside the archive')
    check_manifest(BUNDLE)
    contract, _ = bind_paired_checker()
    archived_receipts = contract.source_receipts()
    work.mkdir()
    stage(work)
    host = work / 'host_fixture'
    try:
        run(work, host / 'setup_fixture_pre_scram.py')
        bind_host_helpers(host)
        run(work, host / 'setup_unit_fixture_replay.py')
        run(work, host / 'repair_hba_replay.py')
        bind(work, archived_receipts)
        run(work, '-m', 'runner.measure_queries_replay', '--output', work / 'measurements/queries_scram_pair_replay')
        run(work, '-m', 'verification.verify_queries_replay', work / 'measurements/queries_scram_pair_replay')
    finally:
        if (host / 'private/owner_token').is_file():
            run(work, host / 'cleanup_fixture.py')


if __name__ == '__main__':
    main()
