import hashlib
import json
from pathlib import Path
import subprocess
import time

work=Path(__file__).resolve().parent
repo=work.parent.parent
source=work/'source'
build=work/'baseline_build'
build.mkdir(exist_ok=False)
identity=work/'baseline_source_identity.json'
manifest=json.loads(identity.read_text())

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def check_source():
    for entry in manifest['files']:
        path=source/entry['path']
        assert digest(path)==entry['sha256'],entry['path']
        assert (path.stat().st_mode&0o777)==entry['mode'],entry['path']

check_source()
zig=repo/'.zig-cache/toolchains/zig-x86_64-linux-0.16.0/zig'
assert digest(zig)=='2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c'
argv=[str(zig),'build','sql-bench','-Dsql=true','-Doptimize=ReleaseFast','-Dtarget=x86_64-linux-musl','-Dcpu=native','-j2','--cache-dir',str(repo/'.zig-cache/async-db-performance-20261118/build-cache'),'--global-cache-dir',str(repo/'.zig-cache/tls-domain-leaf-fixed-20261118/sdk-global-cache'),'--prefix',str(work/'install'),'--summary','all']
record={'argv':argv,'cwd':str(source),'started_unix_ns':time.time_ns(),'source_identity_sha256':digest(identity),'zig_sha256':digest(zig),'source_commit':manifest['commit']}
(build/'command.json').write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic()
with (build/'build.log').open('wb') as output:
    result=subprocess.run(argv,cwd=source,stdout=output,stderr=subprocess.STDOUT)
check_source()
record.update({'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'finished_unix_ns':time.time_ns()})
if result.returncode==0:
    record['binaries']={}
    for name in ('sql_cluster_server','sql_query_probe'):
        path=work/'install/bin'/name
        record['binaries'][name]={'path':str(path),'sha256':digest(path),'bytes':path.stat().st_size,'mode':path.stat().st_mode&0o777}
        elf=subprocess.run(['readelf','-h','-l','-d',str(path)],check=True,capture_output=True,text=True)
        (build/(name+'_elf.txt')).write_text(elf.stdout)
        assert 'INTERP' not in elf.stdout
(build/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
raise SystemExit(result.returncode)
