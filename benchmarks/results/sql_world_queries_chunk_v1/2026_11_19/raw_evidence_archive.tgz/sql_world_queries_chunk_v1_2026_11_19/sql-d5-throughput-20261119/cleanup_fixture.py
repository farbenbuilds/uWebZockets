#!/usr/bin/env python3
"""Remove only the exact owned database fixture and its private inputs."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess


WORK = Path(__file__).resolve().parent
PRIVATE = WORK / "private"
LABEL = "sql-d5-throughput-20261119"


def require(condition, message):
    if not condition:
        raise SystemExit(message)


def main():
    require(PRIVATE.is_dir() and not PRIVATE.is_symlink(), "private fixture path differs")
    token = (PRIVATE / "owner_token").read_text().strip()
    require(re.fullmatch(r"[0-9a-f]{32}", token), "ownership token differs")
    command = ["docker", "ps", "--all", "--quiet", "--no-trunc", "--filter",
               "label=uwz.sql-experiment=" + LABEL, "--filter",
               "label=uwz.role=database", "--filter", "label=uwz.run-token=" + token]
    matches = subprocess.check_output(command, text=True).split()
    require(len(matches) <= 1, "more than one owned database matched")
    recorded = PRIVATE / "container.id"
    if recorded.exists():
        container = recorded.read_text().strip()
        require(re.fullmatch(r"[0-9a-f]{64}", container), "container identity differs")
        require(matches == [container] or not matches, "owned container identity differs")
        if not matches:
            existing = subprocess.check_output(
                ["docker", "ps", "--all", "--quiet", "--no-trunc", "--filter",
                 "id=" + container], text=True).split()
            require(not existing, "recorded container exists with different ownership")
    else:
        container = matches[0] if matches else None
    if matches:
        labels = json.loads(subprocess.check_output(
            ["docker", "inspect", "--format", "{{json .Config.Labels}}", container], text=True))
        require(labels.get("uwz.sql-experiment") == LABEL and
                labels.get("uwz.role") == "database" and
                labels.get("uwz.run-token") == token, "container ownership differs")
        clients = subprocess.check_output(
            ["docker", "exec", container, "psql", "-X", "-U", "bench", "-d",
             "benchmark", "-A", "-t", "-vON_ERROR_STOP=1", "-c",
             "SELECT count(*) FROM pg_stat_activity WHERE client_addr IS NOT NULL "
             ";"], text=True).strip()
        require(clients == "0", "application database consumers remain")
        subprocess.run(["docker", "rm", "--force", container], check=True, capture_output=True)
    shutil.rmtree(PRIVATE)
    record = {"cleanup_utc": datetime.now(timezone.utc).isoformat(),
              "label": LABEL, "ownership_token_sha256": hashlib.sha256(token.encode()).hexdigest(),
              "matched_database_containers": len(matches), "container_removed_or_absent": True,
              "private_inputs_removed": not PRIVATE.exists(),
              "private_inputs_recorded": False}
    (WORK / "cleanup.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record))


if __name__ == "__main__":
    main()
