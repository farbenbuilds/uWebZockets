import hashlib
import importlib.util
import json
from pathlib import Path
import re


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()


def main():
    work = Path('.zig-cache/sql-d5-throughput-20261119/developer')
    module_path = work / 'check_queries_lifecycle.py'
    spec = importlib.util.spec_from_file_location('owned_lifecycle', module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    fixture_path = Path('.zig-cache/sql-d5-throughput-20261119/host_fixture/fixture/fixture.json')
    context = {
        'fixture': json.loads(fixture_path.read_text()),
        'identity': json.loads(fixture_path.with_name('unit_runtime_identity.json').read_text()),
        'private': module.load_private(Path('.zig-cache/sql-d5-throughput-20261119/host_fixture/private/world_integration.env')),
        'commands': [],
    }
    report = {'schema': 'uwz_owned_world_view_restore_v1', 'preserve_original_base_table': True, 'mutation_attempted': False}
    try:
        report['guard'] = module.fixture_guard(context)
        zero = json.loads(module.sql(context, "SELECT json_build_object('controller_pid',pg_backend_pid(),'other_test_clients',(SELECT count(*) FROM pg_stat_activity WHERE usename IN ('uwz_test','uwz_world_test') AND backend_type='client backend' AND pid<>pg_backend_pid()));"))
        report['zero_clients_before'] = zero
        assert zero['other_test_clients'] == 0
        objects = json.loads(module.sql(context, "SELECT json_build_object('relations',(SELECT json_agg(json_build_object('oid',c.oid::bigint,'name',c.relname,'kind',c.relkind,'owner',pg_get_userbyid(c.relowner)) ORDER BY c.relname) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relname IN ('world','world_values','query_control','query_call_log','query_calls')),'function',(SELECT json_build_object('oid',p.oid::bigint,'owner',pg_get_userbyid(p.proowner),'argtypes',p.proargtypes::text,'source',p.prosrc) FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.proname='world_visible' AND p.proargtypes='23 23'::oidvector),'view',pg_get_viewdef('public.world'::regclass));"))
        report['objects_before'] = objects
        expected = {'world': 'v', 'world_values': 'r', 'query_control': 'r', 'query_call_log': 'r', 'query_calls': 'S'}
        assert {item['name']: item['kind'] for item in objects['relations']} == expected
        assert all(item['owner'] == 'uwz_world_test' for item in objects['relations'])
        assert all(type(item['oid']) is int and item['oid'] > 0 for item in objects['relations'])
        function = objects['function']
        assert function['owner'] == 'uwz_world_test' and function['argtypes'] == '23 23'
        assert function['source'] == module.DDL.split('AS $$', 1)[1].split('$$;', 1)[0]
        normalized = re.sub(r'\s+', '', objects['view'])
        assert normalized == 'SELECTid,randomnumberFROMworld_valuesWHEREworld_visible(id,randomnumber);'
        world = next(item for item in objects['relations'] if item['name'] == 'world')
        base = next(item for item in objects['relations'] if item['name'] == 'world_values')
        dependencies = json.loads(module.sql(context, "SELECT json_agg(json_build_object('class',d.refclassid::regclass::text,'oid',d.refobjid::bigint,'subid',d.refobjsubid,'kind',d.deptype)) FROM pg_depend d JOIN pg_rewrite r ON r.oid=d.objid WHERE d.classid='pg_rewrite'::regclass AND r.ev_class='public.world'::regclass;"))
        report['view_dependencies'] = dependencies
        assert {item['oid'] for item in dependencies if item['class'] == 'pg_class'} == {world['oid'], base['oid']}
        assert {item['oid'] for item in dependencies if item['class'] == 'pg_proc'} == {function['oid']}
        report['retained_failed_probe_state'] = json.loads(module.sql(context, "SELECT json_build_object('control',(SELECT row_to_json(s) FROM query_control s),'calls',(SELECT CASE WHEN is_called THEN last_value ELSE 0 END FROM query_calls),'log',(SELECT coalesce(json_agg(s ORDER BY call),'[]'::json) FROM query_call_log s));"))
        before = json.loads(module.sql(context, "SELECT json_agg(s ORDER BY id) FROM (SELECT id,randomnumber FROM public.world_values) s;"))
        assert len(before) == 10000 and [row['id'] for row in before] == list(range(1, 10001))
        assert all(1 <= row['randomnumber'] <= 10000 for row in before)
        before_bytes = canonical(before)
        (work / 'lifecycle_restore_before_world.json').write_bytes(before_bytes + b'\n')
        checks = []
        for item in objects['relations']:
            checks.append(f"IF NOT EXISTS(SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE c.oid={item['oid']} AND c.relname='{item['name']}' AND c.relkind='{item['kind']}' AND n.nspname='public' AND pg_get_userbyid(c.relowner)=current_user) THEN RAISE EXCEPTION 'owned relation identity changed'; END IF;")
        body = function['source'].replace("'", "''")
        checks.append(f"IF NOT EXISTS(SELECT 1 FROM pg_proc WHERE oid={function['oid']} AND proname='world_visible' AND proargtypes='23 23'::oidvector AND pg_get_userbyid(proowner)=current_user AND prosrc='{body}') THEN RAISE EXCEPTION 'owned function identity changed'; END IF;")
        statement = "BEGIN; LOCK TABLE public.world_values IN ACCESS EXCLUSIVE MODE; LOCK TABLE public.world IN ACCESS EXCLUSIVE MODE; DO $$ BEGIN IF current_user <> 'uwz_world_test' OR current_database() <> 'uwz_world_test' THEN RAISE EXCEPTION 'wrong owned test target'; END IF; " + ' '.join(checks) + " END $$; DROP VIEW public.world; DROP FUNCTION public.world_visible(integer,integer); DROP TABLE public.query_call_log; DROP TABLE public.query_control; DROP SEQUENCE public.query_calls; ALTER TABLE public.world_values RENAME TO world; COMMIT;"
        report['mutation_attempted'] = True
        module.sql(context, statement)
        after = json.loads(module.sql(context, "SELECT json_agg(s ORDER BY id) FROM (SELECT id,randomnumber FROM public.world) s;"))
        after_bytes = canonical(after)
        (work / 'lifecycle_restore_after_world.json').write_bytes(after_bytes + b'\n')
        assert before_bytes == after_bytes
        relation = json.loads(module.sql(context, "SELECT json_build_object('oid',c.oid::bigint,'kind',c.relkind,'owner',pg_get_userbyid(c.relowner)) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relname='world';"))
        assert relation == {'oid': base['oid'], 'kind': 'r', 'owner': 'uwz_world_test'}
        report.update({'base_rows': len(after), 'before_contents_sha256': hashlib.sha256(before_bytes).hexdigest(), 'after_contents_sha256': hashlib.sha256(after_bytes).hexdigest(), 'base_relation_after': relation, 'status': 'restored'})
    except BaseException as error:
        report['status'] = 'failed'
        report['error'] = repr(error)
        raise
    finally:
        report['commands'] = context['commands']
        (work / 'lifecycle_restore_result_02.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'rows': report['base_rows'], 'base_oid': report['base_relation_after']['oid'], 'contents_sha256': report['after_contents_sha256']}))


if __name__ == '__main__':
    main()
