import argparse
import hashlib
import http.client
import json
import os
from pathlib import Path
import re
import shlex
import signal
import socket
import struct
import subprocess
import time


DDL = """
BEGIN;
ALTER TABLE public.world RENAME TO world_values;
CREATE SEQUENCE query_calls CACHE 1;
CREATE TABLE query_control (
    singleton BOOLEAN PRIMARY KEY CHECK (singleton),
    fail_at BIGINT,
    missing_at BIGINT,
    sleep_seconds DOUBLE PRECISION NOT NULL
);
INSERT INTO query_control VALUES (true, NULL, NULL, 0);
CREATE TABLE query_call_log (
    call BIGINT PRIMARY KEY,
    id INTEGER NOT NULL,
    randomnumber INTEGER NOT NULL,
    transaction_id BIGINT NOT NULL
);
CREATE FUNCTION world_visible(row_id INTEGER, row_number INTEGER)
RETURNS BOOLEAN LANGUAGE plpgsql VOLATILE AS $$
DECLARE
    ordinal BIGINT;
    control query_control%ROWTYPE;
BEGIN
    ordinal := nextval('query_calls');
    SELECT * INTO STRICT control FROM query_control WHERE singleton;
    INSERT INTO query_call_log VALUES (ordinal, row_id, row_number, txid_current());
    IF ordinal = control.fail_at THEN
        RAISE EXCEPTION 'controlled query failure';
    END IF;
    IF control.sleep_seconds > 0 THEN
        PERFORM pg_sleep(control.sleep_seconds);
    END IF;
    RETURN control.missing_at IS NULL OR ordinal <> control.missing_at;
END;
$$;
CREATE VIEW public.world AS
SELECT id, randomnumber FROM public.world_values
WHERE world_visible(id, randomnumber);
COMMIT;
"""

SNAPSHOT_SQL = """
SELECT json_build_object(
    'calls', (SELECT CASE WHEN is_called THEN last_value ELSE 0 END FROM query_calls),
    'log', (SELECT coalesce(json_agg(row_to_json(s) ORDER BY call), '[]'::json)
            FROM query_call_log s),
    'tcp_clients', (SELECT count(*) FROM pg_stat_activity
                    WHERE usename='uwz_world_test' AND datname='uwz_world_test'
                      AND client_addr IS NOT NULL),
    'active_clients', (SELECT count(*) FROM pg_stat_activity
                       WHERE usename='uwz_world_test' AND datname='uwz_world_test'
                         AND client_addr IS NOT NULL AND state IS DISTINCT FROM 'idle'),
    'tls_clients', (SELECT count(*) FROM pg_stat_ssl s
                    JOIN pg_stat_activity a USING(pid)
                    WHERE a.usename='uwz_world_test' AND a.datname='uwz_world_test'
                      AND a.client_addr IS NOT NULL AND s.ssl)
);
"""


def load_private(path):
    assert path.stat().st_mode & 0o777 == 0o600
    values = {}
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        key, raw = line.split('=', 1)
        tokens = shlex.split(raw)
        assert len(tokens) == 1
        values[key] = tokens[0]
    assert values['PGHOST'] == '127.0.0.1'
    assert values['PGUSER'] == values['PGDATABASE'] == 'uwz_world_test'
    assert values['UWZ_SQL_ALLOW_PLAINTEXT'] == '1'
    return values


def command(context, argv, sql=None):
    started = time.monotonic_ns()
    result = subprocess.run(argv, input=sql, capture_output=True, text=True, timeout=20)
    assert context['private']['PGPASSWORD'] not in result.stdout + result.stderr
    context['commands'].append({
        'argv': argv, 'sql': sql, 'exit_code': result.returncode,
        'stdout': result.stdout, 'stderr': result.stderr,
        'started_monotonic_ns': started, 'finished_monotonic_ns': time.monotonic_ns(),
    })
    assert result.returncode == 0, result.stderr
    return result.stdout.strip()


def sql(context, text, identity=False):
    role = 'bench' if identity else 'uwz_world_test'
    database = 'benchmark' if identity else 'uwz_world_test'
    argv = ['docker', 'exec', '-i', context['fixture']['container'], 'psql', '-qXAt', '-w',
            '-h', '/var/run/postgresql', '-p', str(context['fixture']['pg_socket_port']),
            '-U', role, '-d', database, '-vON_ERROR_STOP=1']
    return command(context, argv, 'SET statement_timeout=5000;\n' + text)


def fixture_guard(context):
    fixture = context['fixture']
    assert re.fullmatch(r'[0-9a-f]{64}', fixture['container'])
    assert re.fullmatch(r'[0-9a-f]{32}', fixture['owner_token'])
    output = command(context, ['docker', 'inspect', '--format',
        '{{json .Id}}\n{{json .State.Pid}}\n{{json .State.Running}}\n{{json .Config.Labels}}\n{{json .HostConfig.NetworkMode}}', fixture['container']])
    identifier, pid, running, labels, network = [json.loads(line) for line in output.splitlines()]
    expected = context['identity']
    assert identifier == fixture['container'] == expected['container']
    assert pid == expected['pid'] and running and network == 'host'
    assert all(labels[key] == value for key, value in expected['labels'].items())
    actual = json.loads(sql(context, "SELECT json_build_object('data_directory',current_setting('data_directory'),'postmaster_started',pg_postmaster_start_time(),'owner',current_user,'port',current_setting('port'));", identity=True))
    assert actual == expected['postgresql']
    assert str(fixture['pg_host_port']) == context['private']['PGPORT']
    target = json.loads(sql(context, "SELECT json_build_object('role',current_user,'database',current_database(),'port',current_setting('port'),'postmaster_started',pg_postmaster_start_time());"))
    assert target['role'] == target['database'] == 'uwz_world_test'
    assert target['postmaster_started'] == actual['postmaster_started']
    assert target['port'] == actual['port']
    return {'container': identifier, 'pid': pid, 'labels': labels, 'postgresql': actual, 'test_target': target}


def process_identity(pid):
    stat = Path(f'/proc/{pid}/stat').read_text()
    tail = stat[stat.rfind(')') + 2:].split()
    return {'pid': pid, 'start_ticks': int(tail[19]), 'executable': os.readlink(f'/proc/{pid}/exe')}


def socket_fds(pid):
    found = {}
    for entry in Path(f'/proc/{pid}/fd').iterdir():
        try:
            target = os.readlink(entry)
        except FileNotFoundError:
            continue
        match = re.fullmatch(r'socket:\[(\d+)\]', target)
        if match:
            found[match.group(1)] = int(entry.name)
    return found


def endpoint_inode(pid, local_port, remote_port=None):
    fds = socket_fds(pid)
    matches = []
    for line in Path(f'/proc/{pid}/net/tcp').read_text().splitlines()[1:]:
        fields = line.split()
        local, remote, state, inode = fields[1], fields[2], fields[3], fields[9]
        if int(local.split(':')[1], 16) != local_port or inode not in fds:
            continue
        if remote_port is None and state != '0A':
            continue
        if remote_port is not None and (state != '01' or int(remote.split(':')[1], 16) != remote_port):
            continue
        matches.append({'inode': inode, 'fd': fds[inode], 'local': local, 'remote': remote, 'state': state})
    assert len(matches) == 1, matches
    return matches[0]


def fresh_port():
    with socket.socket() as owned:
        owned.bind(('127.0.0.1', 0))
        return owned.getsockname()[1]


def sessions(context):
    return json.loads(sql(context, "SELECT json_build_object('tcp_clients',count(*),'active_clients',count(*) FILTER(WHERE state IS DISTINCT FROM 'idle')) FROM pg_stat_activity WHERE usename='uwz_world_test' AND datname='uwz_world_test' AND client_addr IS NOT NULL;"))


def start_app(context, name):
    port = fresh_port()
    env = {key: value for key, value in os.environ.items()
           if not key.startswith('PG') and not key.startswith('UWZ_SQL_TEST_')}
    env.update(context['private'])
    env.update(context['app_options'])
    env['UWZ_HTTP_PORT'] = str(port)
    log_path = context['output'] / f'{name}.log'
    log = log_path.open('wb')
    child = subprocess.Popen([str(context['binary'])], env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    app = {'child': child, 'log': log, 'port': port, 'name': name, 'identity': None}
    context['apps'].append(app)
    app['identity'] = process_identity(child.pid)
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        assert child.poll() is None, f'{name} exited during startup'
        try:
            listener = endpoint_inode(child.pid, port)
        except AssertionError:
            time.sleep(0.02)
            continue
        state = sessions(context)
        if state['tcp_clients'] == context['expected_sessions'] and state['active_clients'] == 0:
            app['listener'] = listener
            return app
        time.sleep(0.02)
    raise AssertionError('Owned example failed listener/database readiness')


def stop_app(context, app):
    child = app['child']
    signals = []
    if child.poll() is None:
        if app['identity'] is not None:
            assert process_identity(child.pid) == app['identity']
        for requested, timeout in ((signal.SIGTERM, 10), (signal.SIGKILL, 3)):
            child.send_signal(requested)
            signals.append(requested.name)
            try:
                child.wait(timeout=timeout)
                break
            except subprocess.TimeoutExpired:
                continue
    child.wait(timeout=1)
    app['log'].close()
    assert context['private']['PGPASSWORD'] not in (context['output'] / f"{app['name']}.log").read_text(errors='replace')
    deadline = time.monotonic() + 5
    state = sessions(context)
    while state['tcp_clients'] and time.monotonic() < deadline:
        time.sleep(0.02)
        state = sessions(context)
    result = {'name': app['name'], 'identity': app['identity'], 'signals': signals, 'exit_code': child.returncode, 'post_stop': state}
    context['stops'].append(result)
    app['stopped'] = True
    assert child.returncode == 0 and state['tcp_clients'] == 0, result


def request(app, path):
    started = time.monotonic_ns()
    connection = http.client.HTTPConnection('127.0.0.1', app['port'], timeout=15)
    try:
        connection.request('GET', path, headers={'Connection': 'close'})
        response = connection.getresponse()
        body = response.read()
        headers = response.getheaders()
        assert int(response.getheader('Content-Length')) == len(body)
        return {'path': path, 'status': response.status, 'headers': headers,
                'body': body.decode(), 'started_monotonic_ns': started,
                'finished_monotonic_ns': time.monotonic_ns(), 'elapsed_seconds': (time.monotonic_ns() - started) / 1e9}
    finally:
        connection.close()


def worlds(response, count, single=False):
    assert response['status'] == 200, response
    value = json.loads(response['body'], object_pairs_hook=unique_object)
    items = [value] if single else value
    assert type(items) is list and len(items) == count
    for item in items:
        assert set(item) == {'id', 'randomNumber'}
        assert type(item['id']) is int and 1 <= item['id'] <= 10000
        assert type(item['randomNumber']) is int and 1 <= item['randomNumber'] <= 10000
    return items


def unique_object(pairs):
    value = dict(pairs)
    assert len(value) == len(pairs), 'Duplicate JSON object name'
    return value


def snapshot(context):
    return json.loads(sql(context, SNAPSHOT_SQL))


def settled(context):
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        state = snapshot(context)
        if state['active_clients'] == 0:
            assert state['tcp_clients'] == context['expected_sessions'] and state['tls_clients'] == 0
            return state
        time.sleep(0.05)
    raise AssertionError('Test queries did not settle')


def reset_control(context, fail_at=None, missing_at=None, sleep_seconds=0):
    settled(context)
    fail = 'NULL' if fail_at is None else str(int(fail_at))
    missing = 'NULL' if missing_at is None else str(int(missing_at))
    sql(context, f"BEGIN; UPDATE query_control SET fail_at={fail},missing_at={missing},sleep_seconds={float(sleep_seconds)}; TRUNCATE query_call_log; ALTER SEQUENCE query_calls RESTART WITH 1; COMMIT;")
    state = snapshot(context)
    assert state['calls'] == 0 and not state['log']
    return state


def failure(response):
    assert response['status'] == 503, response
    assert json.loads(response['body']) == {'error': 'SQL operation failed'}


def original_cases(context, app):
    cases = []
    first = request(app, '/db')
    worlds(first, 1, single=True)
    cases.append(first)
    for count in (1, 20):
        response = request(app, f'/updates?count={count}')
        items = worlds(response, count)
        final = {item['id']: item['randomNumber'] for item in items}
        ids = ','.join(str(identifier) for identifier in sorted(final))
        actual = json.loads(sql(context, f"SELECT json_object_agg(id,randomnumber) FROM World WHERE id IN ({ids});"))
        assert actual == {str(identifier): number for identifier, number in final.items()}
        cases.append(response)
    return cases


def controlled_cases(context, app):
    expected = {row['id']: row['randomnumber'] for row in json.loads(sql(context, "SELECT json_agg(s ORDER BY id) FROM (SELECT id,randomnumber FROM world_values) s;"))}
    assert len(expected) == 10000
    cases = []
    for count in (1, 15, 16, 17, 20, 500):
        before = reset_control(context)
        response = request(app, f'/queries?count={count}')
        items = worlds(response, count)
        after = settled(context)
        assert after['calls'] == len(after['log']) == count
        assert [(row['id'], row['randomnumber']) for row in after['log']] == [(row['id'], row['randomNumber']) for row in items]
        assert all(row['randomNumber'] == expected[row['id']] for row in items)
        groups = []
        previous = None
        for row in after['log']:
            if row['transaction_id'] != previous:
                groups.append(0)
                previous = row['transaction_id']
            groups[-1] += 1
        assert groups == [min(16, count - start) for start in range(0, count, 16)], groups
        cases.append({'name': f'healthy_{count}', 'before': before, 'response': response, 'after': after,
                      'transaction_group_sizes': groups, 'duplicate_ids': count - len({row['id'] for row in items})})

    before = reset_control(context, fail_at=18)
    response = request(app, '/queries?count=500')
    failure(response)
    after = settled(context)
    assert after['calls'] == 18 and len(after['log']) == 16
    cases.append({'name': 'middle_server_error', 'before': before, 'response': response, 'after': after})

    before = reset_control(context, missing_at=18)
    response = request(app, '/queries?count=500')
    failure(response)
    after = settled(context)
    assert after['calls'] == len(after['log']) == 32
    cases.append({'name': 'short_second_chunk', 'before': before, 'response': response, 'after': after})

    before = reset_control(context, sleep_seconds=0.55)
    response = request(app, '/queries?count=20')
    failure(response)
    after = settled(context)
    assert 9 <= response['elapsed_seconds'] <= 12
    assert 16 < after['calls'] <= 20 and len(after['log']) == 16
    cases.append({'name': 'original_deadline_across_chunks', 'before': before, 'response': response, 'after': after})

    before = reset_control(context, sleep_seconds=0.1)
    client = socket.create_connection(('127.0.0.1', app['port']), timeout=2)
    try:
        client_port = client.getsockname()[1]
        client.sendall(b'GET /queries?count=500 HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n')
        deadline = time.monotonic() + 3
        current = snapshot(context)
        while current['calls'] == 0 and time.monotonic() < deadline:
            time.sleep(0.01)
            current = snapshot(context)
        assert 0 < current['calls'] < 16
        descriptor = endpoint_inode(app['child'].pid, app['port'], client_port)
        client.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii', 1, 0))
        reset_sent_ns = time.monotonic_ns()
    finally:
        client.close()
    while descriptor['inode'] in socket_fds(app['child'].pid) and time.monotonic() < deadline:
        time.sleep(0.005)
    assert descriptor['inode'] not in socket_fds(app['child'].pid)
    close_observed_ns = time.monotonic_ns()
    at_close = snapshot(context)
    assert at_close['calls'] < 16, at_close
    after = settled(context)
    assert 0 < after['calls'] <= 16
    time.sleep(0.25)
    stable = settled(context)
    assert stable['calls'] == after['calls']
    cases.append({'name': 'disconnect_after_observed_transport_close', 'before': before,
                  'request_path': '/queries?count=500', 'socket': descriptor,
                  'rst_sent_monotonic_ns': reset_sent_ns, 'fd_closed_monotonic_ns': close_observed_ns,
                  'at_close': at_close, 'after': after, 'stable': stable,
                  'cancellation_proof': 'tcp.close_connection cancels async_response_state before closing this fd; source identity retained separately.'})
    reset_control(context)
    recovery = request(app, '/db')
    worlds(recovery, 1, single=True)
    cases.append({'name': 'healthy_after_lifecycle_cases', 'response': recovery, 'after': settled(context)})
    return cases


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--binary-sha256', required=True)
    parser.add_argument('--fixture', type=Path, required=True)
    parser.add_argument('--identity', type=Path, required=True)
    parser.add_argument('--app-env', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--expected-sessions', type=int, default=8)
    parser.add_argument('--app-option', action='append', default=[])
    args = parser.parse_args()
    args.output.mkdir(parents=True)
    assert hashlib.sha256(args.binary.read_bytes()).hexdigest() == args.binary_sha256
    context = {'binary': args.binary.resolve(), 'fixture': json.loads(args.fixture.read_text()),
               'identity': json.loads(args.identity.read_text()), 'private': load_private(args.app_env),
               'output': args.output, 'expected_sessions': args.expected_sessions,
               'app_options': dict(item.split('=', 1) for item in args.app_option),
               'commands': [], 'apps': [], 'stops': []}
    report = {'schema': 'uwz_queries_lifecycle_v1', 'binary_sha256': args.binary_sha256,
              'argv': os.sys.argv, 'performance_measurement': False}
    try:
        report['guard_before'] = fixture_guard(context)
        assert sessions(context)['tcp_clients'] == 0
        original = start_app(context, 'original_world')
        report['original_world'] = original_cases(context, original)
        stop_app(context, original)
        sql(context, DDL)
        controlled = start_app(context, 'controlled_world')
        report['controlled_world'] = controlled_cases(context, controlled)
        stop_app(context, controlled)
        report['guard_after'] = fixture_guard(context)
        report['final_sessions'] = sessions(context)
        assert report['final_sessions'] == {'tcp_clients': 0, 'active_clients': 0}
        report['final_all_test_sessions'] = json.loads(sql(context, "SELECT json_build_object('controller_pid',pg_backend_pid(),'other_test_clients',(SELECT count(*) FROM pg_stat_activity WHERE usename IN ('uwz_test','uwz_world_test') AND backend_type='client backend' AND pid<>pg_backend_pid()));"))
        assert report['final_all_test_sessions']['other_test_clients'] == 0
        report['status'] = 'passed'
    except BaseException as error:
        report['status'] = 'failed'
        report['error'] = repr(error)
        raise
    finally:
        cleanup_errors = []
        for app in context['apps']:
            if not app.get('stopped'):
                try:
                    stop_app(context, app)
                except BaseException as error:
                    cleanup_errors.append(repr(error))
        report['commands'] = context['commands']
        report['stops'] = context['stops']
        report['cleanup_errors'] = cleanup_errors
        if cleanup_errors:
            report['status'] = 'failed'
        (args.output / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
        if cleanup_errors and 'error' not in report:
            raise AssertionError(cleanup_errors)
    print(json.dumps({'status': report['status'], 'controlled_cases': len(report['controlled_world']),
                      'app_exit_codes': [item['exit_code'] for item in report['stops']],
                      'final_sessions': report['final_sessions']}))


if __name__ == '__main__':
    main()
