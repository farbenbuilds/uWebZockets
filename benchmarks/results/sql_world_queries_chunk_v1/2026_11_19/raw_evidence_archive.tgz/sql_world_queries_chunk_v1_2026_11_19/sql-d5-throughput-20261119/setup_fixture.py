#!/usr/bin/env python3
"""Prepare the labeled World database with the original local benchmark seed."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import socket
import subprocess
import time


WORK = Path(__file__).resolve().parent
PRIVATE = WORK / "private"
PUBLIC = WORK / "fixture"
IMAGE = "postgres@sha256:e3d24f6906d0760bf4da0dae872415391ededefad23fd471c47dc53b0ddf3c42"
LABEL = "sql-d5-throughput-20261119"
SEED_SHA = "1edf81f613f4c7878fb05e763e556d3e8f44b33f9ca87915870b7b5cdcf9c2e5"
HTTP_PORT = 31631


def require(condition, message):
    if not condition:
        raise SystemExit(message)


def private_file(name, text):
    fd = os.open(PRIVATE / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as output:
        output.write(text)


def psql(container, command, stdin=None):
    argv = ["docker", "exec", "-i", container, "psql", "-X", "-w", "-U", "bench", "-d", "benchmark", "-At", "-v", "ON_ERROR_STOP=1"]
    if command is not None:
        argv.extend(("-c", command))
    return subprocess.run(argv, input=stdin, capture_output=True, text=True, timeout=45, check=True).stdout


def owned_labels(container, expected):
    actual = json.loads(subprocess.check_output(["docker", "inspect", "--format", "{{json .Config.Labels}}", container], text=True))
    require(all(actual.get(key) == value for key, value in expected.items()), "PostgreSQL fixture ownership differs")


def main():
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", HTTP_PORT))
    seed = (WORK.parents[1] / "examples" / "sql" / "world.sql").read_bytes()
    require(hashlib.sha256(seed).hexdigest() == SEED_SHA, "The original World SQL seed does not match its pinned bytes")
    subprocess.run(["docker", "image", "inspect", IMAGE], check=True, stdout=subprocess.DEVNULL)
    PRIVATE.mkdir(mode=0o700)
    PUBLIC.mkdir()
    (PUBLIC / "world.sql").write_bytes(seed)
    password = secrets.token_hex(24)
    owner = secrets.token_hex(16)
    private_file("owner_token", owner + "\n")
    private_file("postgres.env", "POSTGRES_USER=bench\nPOSTGRES_DB=benchmark\nPOSTGRES_PASSWORD=" + password + "\n")
    labels = {"uwz.sql-experiment": LABEL, "uwz.role": "database", "uwz.run-token": owner}
    command = ["docker", "run", "--detach", "--pull=never", "--network", "bridge",
               *(part for key, value in labels.items() for part in ("--label", f"{key}={value}")),
               "--env-file", str(PRIVATE / "postgres.env"), "--publish", "127.0.0.1::5432", "--tmpfs", "/var/lib/postgresql",
               IMAGE, "-c", "max_connections=100"]
    container = subprocess.check_output(command, text=True, timeout=60).strip()
    require(re.fullmatch(r"[0-9a-f]{64}", container), "PostgreSQL did not provide an immutable container ID")
    private_file("container.id", container + "\n")
    owned_labels(container, labels)
    for _ in range(60):
        command_ready = ["docker", "exec", container, "pg_isready", "-h127.0.0.1", "-Ubench", "-dbenchmark"]
        if subprocess.run(command_ready, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10).returncode == 0:
            break
        time.sleep(.5)
    else:
        raise SystemExit("PostgreSQL readiness failed; the owned fixture is identifiable for cleanup")
    (PUBLIC / "seed.log").write_text(psql(container, None, seed.decode("utf-8")))
    mapping = subprocess.check_output(["docker", "port", container, "5432/tcp"], text=True).strip()
    require(re.fullmatch(r"127\.0\.0\.1:[0-9]+", mapping), "Unexpected PostgreSQL port publication")
    pg_port = int(mapping.rsplit(":", 1)[-1])
    private_file("app.env", "PGHOST=127.0.0.1\nPGPORT=" + str(pg_port) + "\nPGUSER=bench\nPGDATABASE=benchmark\nPGPASSWORD=" + password
                 + "\nUWZ_SQL_ALLOW_PLAINTEXT=1\n")
    expected = PUBLIC / "world_initial.jsonl"
    expected.write_text(psql(container, "SELECT json_build_object('id',id,'randomNumber',randomnumber) FROM public.world ORDER BY id;"))
    rows = [json.loads(line) for line in expected.read_text().splitlines()]
    require(rows == [{"id": ident, "randomNumber": 1 + (ident * 7919) % 10000} for ident in range(1, 10001)], "Unexpected World seed values")
    (PUBLIC / "version.txt").write_text(psql(container, "SELECT version();"))
    (PUBLIC / "schema.txt").write_text(psql(container, "SELECT conname,pg_get_constraintdef(oid) FROM pg_constraint WHERE conrelid='public.world'::regclass ORDER BY conname;"))
    settings = json.loads(psql(container, """
SELECT json_build_object('role',current_user,'database',current_database(),'postmaster',pg_postmaster_start_time(),
  'settings',(SELECT json_object_agg(name,setting ORDER BY name) FROM pg_settings WHERE name IN
    ('autovacuum','compute_query_id','fsync','full_page_writes','max_connections','plan_cache_mode','server_version_num',
     'shared_buffers','shared_preload_libraries','synchronous_commit','track_counts','wal_level')),
  'policy',(SELECT row_to_json(s) FROM (SELECT setting,source,reset_val FROM pg_settings WHERE name='plan_cache_mode') s),
  'extensions',(SELECT json_agg(extname ORDER BY extname) FROM pg_extension));
"""))
    effective = settings["settings"]
    require(settings["role"] == "bench" and settings["database"] == "benchmark" and effective["server_version_num"] == "180006"
            and effective["max_connections"] == "100" and effective["fsync"] == effective["synchronous_commit"] == effective["autovacuum"] == "on"
            and effective["shared_preload_libraries"] == "" and settings["extensions"] == ["plpgsql"]
            and settings["policy"] == {"setting": "auto", "source": "default", "reset_val": "auto"}, "Unexpected PostgreSQL fixture settings")
    (PUBLIC / "settings.json").write_text(json.dumps(settings, indent=2) + "\n")
    (PUBLIC / "plan.json").write_text(psql(container, "EXPLAIN (FORMAT JSON) SELECT id,randomnumber FROM public.world WHERE id=1;"))
    record = {"created_utc": datetime.now(timezone.utc).isoformat(), "image": IMAGE, "container": container, "label": LABEL,
              "owner_token": owner, "pg_user": "bench", "pg_database": "benchmark", "pg_host_port": pg_port, "http_port": HTTP_PORT,
              "seed_sha256": SEED_SHA, "seed_rows": len(rows), "world_path": str(expected), "world_sha256": hashlib.sha256(expected.read_bytes()).hexdigest(),
              "settings_path": str(PUBLIC / "settings.json"), "settings_sha256": hashlib.sha256((PUBLIC / "settings.json").read_bytes()).hexdigest(),
              "postgresql_network": "bridge through published loopback", "data_mount": "tmpfs", "docker_command": command,
              "private_inputs_recorded": False}
    (PUBLIC / "fixture.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({key: record[key] for key in ("image", "pg_host_port", "http_port", "seed_rows")}))


if __name__ == "__main__":
    main()
