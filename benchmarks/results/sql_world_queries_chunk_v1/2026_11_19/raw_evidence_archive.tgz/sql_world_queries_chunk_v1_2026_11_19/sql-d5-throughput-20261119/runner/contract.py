import json


WORKERS = 12
POOL = 8
CONNECTIONS = 192
THREADS = 4
WARMUP = 2
SAMPLES = 3
DURATION = 10
FIXED = 50
ROUTES = ("db", "queries", "updates")
PROFILES = {"default": 1, "5": 5, "20": 20, "500": 500}
COUNTERS = ("idx_scan", "pkey_scans", "seq_scan", "n_tup_upd", "n_tup_ins", "n_tup_del", "xact_rollback")
STAT_ERRORS = ("connect_errors", "read_errors", "write_errors", "timeout_errors", "status_errors", "non_200")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def route_contract(route, profile):
    count = 1 if route == "db" else PROFILES[profile]
    path = f"/{route}" if route == "db" or profile == "default" else f"/{route}?count={count}"
    return path, count


def unique_fields(entries):
    output = dict(entries)
    require(len(output) == len(entries), "Duplicate JSON field")
    return output


def typed_world(rows):
    require(isinstance(rows, list), "Expected a list of World rows")
    for row in rows:
        require(type(row) is dict and set(row) == {"id", "randomNumber"}
                and all(type(value) is int and 1 <= value <= 10000 for value in row.values()), "Invalid World row")
    return rows


def fixed_result(response, route, path, count):
    require(response["method"] == "GET" and response["path"] == path and response["version"] == 11 and response["status"] == 200,
            "Unexpected fixed request or HTTP response")
    headers = {name.lower(): value for name, value in response["headers"]}
    raw = response["body_utf8"]
    require(len(headers) == len(response["headers"]) and headers.get("content-type") == "application/json"
            and headers.get("content-length") == str(len(raw.encode("utf-8"))), "Invalid fixed HTTP response framing")
    payload = json.loads(raw, object_pairs_hook=unique_fields)
    rows = typed_world([payload] if route == "db" else payload)
    require(len(rows) == count, "Unexpected World response cardinality")
    return rows


def check_client(sample, seconds):
    require(sample["requests"] > 0 and sample["duration_us"] >= seconds * 1_000_000 and sample["status_200"] == sample["requests"]
            and all(sample[name] == 0 for name in STAT_ERRORS), "Client did not finish with exact HTTP 200 and zero errors")


def sql_work(before, after, route, count, complete, cutoff):
    require(all(before[key] == after[key] for key in ("postmaster", "stats_reset", "world_oid", "world_pkey_oid")), "PostgreSQL epoch or table identity changed")
    delta = {key: after[key] - before[key] for key in COUNTERS}
    require(min(delta.values()) >= 0, "PostgreSQL count decreased")
    require(delta["idx_scan"] == delta["pkey_scans"] and all(delta[key] == 0 for key in ("seq_scan", "n_tup_ins", "n_tup_del")),
            "SQL used a different scan or changed table shape")
    writes = delta["n_tup_upd"]
    reads = delta["idx_scan"] - writes
    lower, upper = count * complete, count * (complete + cutoff)
    require(lower <= reads <= upper, "Point reads outside completed and cutoff bounds")
    if route == "updates":
        require(lower <= writes <= upper and writes <= reads, "Updates outside completed and cutoff bounds")
    else:
        require(writes == 0, "Read route changed World rows")
    require(delta["xact_rollback"] == 0 if cutoff == 0 else delta["xact_rollback"] <= cutoff,
            "Rollback count exceeds request deadline allowance")
    return {"completed": complete, "cutoff_requests": cutoff, "read_scans": reads, "updated_rows": writes, "deltas": delta,
            "reads_per_complete_request": count, "updates_per_complete_request": count if route == "updates" else 0}
