import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import secrets
import signal
import stat
import time

from runner import measure_host as host
from runner.contract import CONNECTIONS, DURATION, FIXED, POOL, THREADS, WARMUP, WORKERS, require, sql_work
from runner.queries_pair_contract import (APP_ENV, AUTH_SQL, COUNT, EDGES, FIXTURE, HOST, KEEP_RULE, RESTORE_SQL, SEED_SHA,
                                          SEED_WORLD_SHA, WORK, WRK, WRK_SHA, WORLD_EXPORT, affinity, check_auth, digest,
                                          epoch, fixed_read_work, plan, read, same_state, source_receipts)


PAIR_LABELS = host.RUN_LABELS | {"uwz.cohort": "queries-scram-pair"}
EXTRA_STATS = """
  'vacuum_count',t.vacuum_count,'analyze_count',t.analyze_count,
  'last_vacuum',t.last_vacuum,'last_autovacuum',t.last_autovacuum,
  'last_analyze',t.last_analyze,'last_autoanalyze',t.last_autoanalyze,
  'n_mod_since_analyze',t.n_mod_since_analyze,'n_ins_since_vacuum',t.n_ins_since_vacuum,
  'world_bytes',pg_relation_size(t.relid),'pkey_bytes',pg_relation_size(i.indexrelid),
  'conf_loaded',pg_conf_load_time(),
  'maintenance_running',(EXISTS (SELECT 1 FROM pg_stat_progress_vacuum WHERE datname=current_database() AND relid=t.relid)
                         OR EXISTS (SELECT 1 FROM pg_stat_progress_analyze WHERE datname=current_database() AND relid=t.relid)),
  'foreign_clients',(SELECT count(*) FROM pg_stat_activity WHERE backend_type='client backend'
      AND pid<>pg_backend_pid() AND NOT (datname='benchmark' AND usename='bench' AND client_addr IS NOT NULL)),
"""
STATS_SQL = host.STATS_SQL.replace("  'postmaster'", EXTRA_STATS + "  'postmaster'")


def db_sql(args, directory, label, statement):
    return host.run(directory, label, [
        "docker", "exec", "--user", "postgres", args.db_container, "psql", "-X", "-w", "-At",
        "-h", "/var/run/postgresql", "-p", str(args.db_port), "-U", "bench", "-d", "benchmark",
        "-v", "ON_ERROR_STOP=1", "-c", statement,
    ], timeout=45)


def check_environment(args):
    require(not args.app_env.parent.is_symlink() and not args.app_env.is_symlink() and args.app_env.is_file()
            and args.app_env.stat().st_uid == os.getuid() and stat.S_IMODE(args.app_env.stat().st_mode) == 0o600,
            "Application environment file is not private")
    rows = args.app_env.read_text().splitlines()
    env = dict(row.split("=", 1) for row in rows)
    require(len(env) == len(rows) and set(env) == {"PGHOST", "PGPORT", "PGUSER", "PGDATABASE", "PGPASSWORD", "UWZ_SQL_ALLOW_PLAINTEXT"}
            and tuple(env[key] for key in ("PGHOST", "PGPORT", "PGUSER", "PGDATABASE", "UWZ_SQL_ALLOW_PLAINTEXT"))
            == ("127.0.0.1", str(args.db_port), "bench", "benchmark", "1")
            and bool(re.fullmatch(r"[0-9a-f]{48}", env["PGPASSWORD"])), "Wrong private benchmark role, connection or options")


def verify_db(args, directory, label, fixture, proof):
    raw = db_sql(args, directory, f"{label}_hba_rules", AUTH_SQL)
    check_auth(fixture, args.settings, proof, json.loads(raw))
    argv = ["docker", "exec", "--user", "postgres", args.db_container, "sha256sum", "--", proof["after"]["hba_file"]]
    hba = host.run(directory, f"{label}_hba_digest", argv)
    require(hba.split() == [proof["hba_sha256"], proof["after"]["hba_file"]], "Corrected HBA bytes changed")


def snapshot(args, directory, label):
    row = json.loads(db_sql(args, directory, label, STATS_SQL))
    host.check_postgres(args, row)
    require(row["conf_loaded"] == args.auth_proof["after"]["loaded"] and row["foreign_clients"] == 0,
            "PostgreSQL was reloaded or still has foreign client sessions")
    return row


def settled(args, directory, phase):
    prior = None
    for index in range(20):
        row = snapshot(args, directory, f"pg_{phase}_{index:02}")
        require(directory.name == "restore" or not row["maintenance_running"], "World maintenance crossed a paired arm")
        if (row == prior and row["tcp_clients"] == row["bench_tcp_clients"] == 0
                and row["ssl_clients"] == row["active_tcp_clients"] == 0):
            return row
        prior = row
        time.sleep(1)
    raise RuntimeError(f"World statistics or database sockets did not settle at {phase}")


def restore_world(args, fixture):
    directory = args.output / "restore"
    directory.mkdir()
    seed = FIXTURE.with_name("world.sql")
    require(digest(seed) == fixture["seed_sha256"] == SEED_SHA
            and digest(Path(fixture["world_path"])) == fixture["world_sha256"] == SEED_WORLD_SHA, "Canonical World seed or export changed")
    verify_db(args, directory, "before", fixture, args.auth_proof)
    before = settled(args, directory, "before")
    require(not before["maintenance_running"], "Benchmark World maintenance is active before restore")
    raw = db_sql(args, directory, "world_restore", RESTORE_SQL)
    updated, = re.findall(r"^UPDATE ([0-9]+)$", raw, re.M)
    require(0 <= int(updated) <= 10000, "Canonical World restore count out of bounds")
    world = db_sql(args, directory, "world_export", WORLD_EXPORT)
    require(hashlib.sha256(world.encode()).hexdigest() == SEED_WORLD_SHA, "Restored World's full sorted export differs from the frozen seed")
    settled(args, directory, "pre_vacuum")
    require(db_sql(args, directory, "world_vacuum", "VACUUM (ANALYZE) public.world;").strip() == "VACUUM",
            "Off-window World VACUUM (ANALYZE) did not complete")
    anchor = settled(args, directory, "anchor")
    require(all(anchor[key] == before[key] for key in ("postmaster", "stats_reset", "world_oid", "world_pkey_oid"))
            and anchor["n_tup_upd"] - before["n_tup_upd"] == int(updated)
            and all(anchor[key] == before[key] for key in ("n_tup_ins", "n_tup_del", "xact_rollback"))
            and anchor["vacuum_count"] == before["vacuum_count"] + 1 and anchor["analyze_count"] == before["analyze_count"] + 1
            and anchor["n_mod_since_analyze"] == 0 and not anchor["maintenance_running"], "Unexpected World restore or maintenance counters")
    host.save_json(directory / "anchor.json", anchor)
    return anchor


def run_client(args, case, label, seconds, path, app_pid):
    result = host.wrk_load(args, case, label, seconds, path, app_pid)
    first, last = (read(case / f"{label}_{phase}.resources.json") for phase in ("before", "after"))
    cpu = host.cpu_delta(first, last)
    require(0 < result["p50_us"] <= result["p95_us"] <= result["p99_us"]
            and all(cpu[role].get("usage_usec", 0) > 0 for role in ("application", "postgres")),
            f"Missing or invalid latency and CPU evidence for {label}")
    return result


def measure_case(args, directory, phase, arm, count, expected):
    directory.mkdir()
    print(f"Starting {directory.name}", flush=True)
    ownership = secrets.token_hex(16)
    labels = PAIR_LABELS | {"uwz.run-owner": ownership}
    host.save_json(directory / "app_ownership.json", {"labels": labels})
    path = f"/queries?count={count}"
    record = {"arm": arm, "phase": phase, "count": count, "valid": False}
    container = None
    starting = False
    try:
        before = settled(args, directory, "before")
        same_state(expected, before)
        require(args.binary_hash == digest(args.binary), "Selected application binary drifted")
        starting = True
        owned = host.run(directory, "app_run", ["docker", "run", "--detach", "--pull=never", "--network", "host",
                         "--name", f"uwz-d5-queries-{directory.name}-{ownership[:8]}",
                         *(part for key, value in labels.items() for part in ("--label", f"{key}={value}")),
                         "--security-opt", "seccomp=unconfined", "--ulimit", "memlock=-1:-1", "--ulimit", "nofile=524288:524288",
                         "--stop-signal", "SIGTERM", "--env-file", args.app_env, "--env", f"UWZ_SQL_WORKERS={WORKERS}",
                         "--env", "UWZ_SQL_AFFINITY=1", "--env", f"UWZ_HTTP_PORT={args.port}",
                         "--mount", f"type=bind,source={args.binary},target=/server,readonly", "--entrypoint", "/server", args.image]).strip()
        require(re.fullmatch(r"[0-9a-f]{64}", owned), "Unexpected application container ID")
        container = owned
        host.app_ready(args, directory, container)
        ready = snapshot(args, directory, "ready_pair")
        same_state(before, ready)
        require(ready["tcp_clients"] == ready["bench_tcp_clients"] == WORKERS * POOL and ready["ssl_clients"] == 0,
                "Paired application readiness did not show the 96 plaintext bench sessions")
        app_pid = host.read_pid(directory, "app_pid", container)
        host.save_json(directory / "app_host_clock_namespace.json", host.host_clock_binding(app_pid, container))
        raw = host.run(directory, "app_clock_namespace", ["docker", "exec", container, "sh", "-ec", "readlink /proc/1/ns/time\n"
                       "readlink /proc/1/ns/time_for_children\ncat /proc/1/timens_offsets\nsha256sum /proc/sys/kernel/random/boot_id | cut -d ' ' -f 1"])
        require(host.same_clock(host.clock_namespace(raw), args.clock_namespace), "Application clock differs")
        masks = affinity(sorted(directory.glob("ready_app_*.stdout"))[-1].read_text())
        require(args.app_affinity == masks, "Application affinity differs from the predeclared profile")
        if phase == "fixed":
            started = time.monotonic_ns()
            host.fixed_load(args, directory, "queries", path, count)
            host.save_json(directory / "client_clock.json", {"started_ns": started, "finished_ns": time.monotonic_ns()})
        else:
            record["warmup"] = run_client(args, directory, "warmup", WARMUP, path, app_pid)
            record["timed"] = run_client(args, directory, "timed", DURATION, path, app_pid)
    except (OSError, ValueError, KeyError, RuntimeError) as error:
        record["failure"] = str(error)
    finally:
        if starting:
            container = container or host.find_owned_container(directory, labels)
        if container is not None:
            state = host.collect_stop(directory, container, labels)
            record["app_state"] = state
    after = None
    try:
        after = settled(args, directory, "after")
        if "failure" not in record:
            require(state["ExitCode"] == 0 and state["OOMKilled"] is False and not state["evidence_errors"],
                    "Owned application or cleanup is unhealthy")
            require(epoch(before) == epoch(after), "World maintenance changed during this arm")
            if phase == "fixed":
                record["sql_work"] = fixed_read_work(before, after, count)
            else:
                complete = record["warmup"]["requests"] + record["timed"]["requests"]
                record["sql_work"] = sql_work(before, after, "queries", COUNT, complete, 2 * CONNECTIONS)
            record["valid"] = True
    except (OSError, ValueError, KeyError, RuntimeError) as error:
        record["failure"] = str(error)
    host.save_json(directory / "summary.json", record)
    print(f"Finished {directory.name} valid={record['valid']} {record.get('sql_work', record.get('failure', ''))}", flush=True)
    return record, after


def main():
    parser = argparse.ArgumentParser(description="D-5 queries-only paired comparison on the corrected SCRAM fixture")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output = args.output.resolve()
    require(args.output.parent == (HOST.parent / "measurements") and args.output.name.startswith("queries_scram_pair"),
            "Record the comparison in the dedicated measurements directory")
    variants = source_receipts()
    args.wrk, args.lua, args.fixture, args.app_env = WRK, Path(host.__file__).with_name("status.lua"), FIXTURE, APP_ENV
    require(digest(args.wrk) == WRK_SHA and digest(args.fixture) == "6e845754beeadbccb1e22b55d60d2eaeee4cd8a66a05a75cb968cec349ca57fa",
            "wrk or exact prepared host fixture identity changed")
    args.output.mkdir()
    fixture = host.bind_fixture(args)
    require(fixture["seed_sha256"] == SEED_SHA and (args.db_user, args.db_name) == ("bench", "benchmark"),
            "Wrong World data or connection role")
    check_environment(args)
    hba_path = FIXTURE.parent / "hba_repair/verified.json"
    args.auth_proof = read(hba_path)
    frozen_run = WORK / "measurements/host_count20"
    frozen = read(frozen_run / "metadata.json")
    client_affinity = sorted(os.sched_getaffinity(0))
    require(client_affinity == frozen["client_affinity"] and digest(args.lua) == frozen["sha256"][str(args.lua)],
            "wrk status script or client affinity differs from the frozen workload")
    args.app_affinity = affinity(sorted((frozen_run / "fixed_queries").glob("ready_app_*.stdout"))[-1].read_text())
    clock = time.get_clock_info("monotonic")
    require(clock.implementation == "clock_gettime(CLOCK_MONOTONIC)" and clock.monotonic and not clock.adjustable, "Wrong host clock")
    raw = (os.readlink("/proc/self/ns/time") + "\n" + os.readlink("/proc/self/ns/time_for_children") + "\n"
           + Path("/proc/self/timens_offsets").read_text() + digest(Path("/proc/sys/kernel/random/boot_id")) + "\n")
    args.clock_namespace = host.clock_namespace(raw)
    (args.output / "host_clock_namespace.txt").write_text(raw)
    inputs = (args.wrk, args.lua, args.fixture, hba_path, Path(__file__), Path(host.__file__),
              Path(__file__).with_name("contract.py"), Path(__file__).with_name("queries_pair_contract.py"))
    host.save_json(args.output / "metadata.json", {
        "recorded_at": host.now(), "route": "queries", "count": COUNT, "edges": EDGES, "plan": plan(), "variants": variants,
        "keep_rule": KEEP_RULE,
        "workers": WORKERS, "pool": POOL, "connections": CONNECTIONS, "threads": THREADS,
        "warmup_seconds": WARMUP, "timed_seconds": DURATION, "fixed_count": FIXED, "pipeline_depth": 1,
        "postgresql_network": "host_loopback", "postgresql_loopback_auth": "scram-sha-256", "pg_host_port": args.db_port,
        "db_container": args.db_container, "db_pid": args.db_pid, "db_image": args.image, "http_port": args.port,
        "wrk": str(args.wrk), "lua": str(args.lua), "kernel": platform.release(), "client_affinity": client_affinity,
        "expected_application_affinity": args.app_affinity,
        "clock_namespace": args.clock_namespace, "proc_clock_ticks_per_second": os.sysconf("SC_CLK_TCK"),
        "status_scope": "exact HTTP 200 from the Lua response hook; timed HTTP bodies not decoded",
        "sha256": {str(path): digest(path) for path in inputs},
    })
    prior = restore_world(args, fixture)
    completed = []
    try:
        for phase, arm, name, count in plan():
            args.binary = Path(variants[arm]["binary"])
            args.binary_hash = variants[arm]["binary_sha256"]
            result, prior = measure_case(args, args.output / name, phase, arm, count, prior)
            completed.append(name)
            host.save_json(args.output / "completed.json", completed)
            if not result["valid"]:
                return 2
        verify_db(args, args.output, "final", fixture, args.auth_proof)
        return 0
    finally:
        inventory = host.run(args.output, "app_final_inventory", ["docker", "ps", "--all", "--quiet", "--no-trunc",
                             *(part for key, value in PAIR_LABELS.items() for part in ("--filter", f"label={key}={value}"))])
        require(not inventory, "A paired application container remains")


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, host.interrupted)
    raise SystemExit(main())
