import hashlib
import json
from pathlib import Path
import re
import stat
import statistics

from .contract import COUNTERS, FIXED, require, sql_work


WORK = Path(__file__).resolve().parents[1]
HOST = WORK / "host_fixture"
FIXTURE = HOST / "fixture/fixture.json"
APP_ENV = HOST / "private/app.env"
CONTROL, CANDIDATE = "control", "candidate"
ARMS = (CONTROL, CANDIDATE)
COUNT = 20
EDGES = (1, 15, 16, 17, 20, 500)
PAIRS = (ARMS, ARMS[::-1], ARMS)
KEEP_RULE = {
    "eligible_metrics": ["rps", "application_cpu", "postgres_cpu"],
    "required_favorable_pairs": len(PAIRS),
    "required_median_gain": "strictly above 100 × (max control − min control) / median control",
    "rps_worse_pairs_veto": 2,
    "p99_worse_pairs_veto": 2,
}
BINARIES = {
    CONTROL: "e40fe20894ae59c33dd507b6b0ef78bebca9d8c27644e9ea0b5f55c718f7832a",
    CANDIDATE: "384795c818740c3d8bc96cc490ef1c8910c91455d506bba452dac577660be1b7",
}
SOURCE_CHANGES = {"examples/sql_postgres.zig", "builds/testing.zig", "src/test_support.zig",
                  "src/tests/main.zig", "src/tests/sql_migration_service_tests.zig", "src/tests/sql_postgres_tests.zig"}
COMMIT = "a296a93d55ec7fecb1b99efc3f07e873bdb0f5e9"
MANIFESTS = {
    CONTROL: "39b91b9a44fe8d01880d4422fc2526341c97a4de09f474880ea3a9183a2485ad",
    CANDIDATE: "ed80223d93ce26a5c0b1a0affc589ad60a849214a2c76401e67f7c36e09732b5",
}
WRK = WORK.parent / "async-db-performance-20261118/tooling/root/usr/bin/wrk"
WRK_SHA = "f6536e3f9479584fa2b4a97d12c56671487be9f1011f309dc7a3b1bb0f6ea06c"
SEED_SHA = "1edf81f613f4c7878fb05e763e556d3e8f44b33f9ca87915870b7b5cdcf9c2e5"
SEED_WORLD_SHA = "3a2660e0ddfae2c4ed092d1cb6b166f14cc746c2464657a2bac3263b78e58c8a"
MAINTENANCE = ("vacuum_count", "autovacuum_count", "analyze_count", "autoanalyze_count",
               "last_vacuum", "last_autovacuum", "last_analyze", "last_autoanalyze",
               "n_mod_since_analyze", "n_ins_since_vacuum", "stats_reset", "postmaster", "world_oid", "world_pkey_oid",
               "world_bytes", "pkey_bytes", "conf_loaded", "maintenance_running")
WORLD_EXPORT = ("SELECT json_build_object('id',id,'randomNumber',randomnumber) "
                "FROM public.world ORDER BY id;")
AUTH_SQL = """
SELECT COALESCE(json_agg(to_jsonb(r) - 'options' ORDER BY rule_number NULLS FIRST, line_number),'[]')
FROM pg_hba_file_rules r;
"""
RESTORE_SQL = """
SET statement_timeout = '10s';
BEGIN;
DO $guard$
BEGIN
 IF current_database() <> 'benchmark' OR current_user <> 'bench' OR inet_client_addr() IS NOT NULL
    OR EXISTS (SELECT 1 FROM pg_stat_activity WHERE backend_type='client backend' AND pid<>pg_backend_pid()) THEN
  RAISE EXCEPTION 'Expected the drained benchmark database on the fixture Unix socket';
 END IF;
END;
$guard$;
UPDATE public.world
SET randomnumber = 1 + ((id * 7919) % 10000)
WHERE randomnumber <> 1 + ((id * 7919) % 10000);
COMMIT;
"""


def read(path):
    return json.loads(path.read_text())


def digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def plan():
    blocks = (("primary", COUNT), *((f"edge_{count}", count) for count in EDGES))
    return ([("fixed", arm, f"fixed_{arm}_{label}", count) for arm in ARMS for label, count in blocks]
            + [("timed", arm, f"pair{number}_{arm}", COUNT) for number, arms in enumerate(PAIRS, 1) for arm in arms])


def epoch(row):
    return {key: row[key] for key in MAINTENANCE}


def same_state(left, right):
    require(epoch(left) == epoch(right) and all(left[key] == right[key] for key in COUNTERS),
            "Benchmark statistics, table identity or maintenance changed outside measured scopes")


def fixed_read_work(before, after, count):
    for row in (before, after):
        require(all(row[key] == 0 for key in ("tcp_clients", "bench_tcp_clients", "active_tcp_clients",
                    "ssl_clients", "foreign_clients")), "Exact fixed read accounting requires a drained pool")
    require(epoch(before) == epoch(after), "Maintenance crossed a fixed validation block")
    return sql_work(before, after, "queries", count, FIXED, 0)


def source_receipts():
    receipts, closures, argv_prefixes = {}, {}, {}
    for arm, root in ((CONTROL, WORK), (CANDIDATE, WORK / "queries_candidate")):
        manifest = root / "baseline_source_identity.json"
        build_path = root / "baseline_build/result.json"
        source, build = read(manifest), read(build_path)
        source_dir = root / "source"
        selected = build["binaries"]["sql_cluster_server"]
        binary = root / "install/bin/sql_cluster_server"
        require(source["commit"] == build["source_commit"] == COMMIT and build["exit_code"] == 0
                and MANIFESTS[arm] == build["source_identity_sha256"] == digest(manifest) and build["cwd"] == str(source_dir)
                and selected["path"] == str(binary) and not binary.is_symlink()
                and BINARIES[arm] == digest(binary) == selected["sha256"]
                and binary.stat().st_size == selected["bytes"]
                and stat.S_IMODE(binary.stat().st_mode) == selected["mode"], f"Invalid {arm} binary or source receipt")
        argv = build["argv"]
        prefix = argv.index("--prefix")
        require(argv[1:8] == ["build", "sql-bench", "-Dsql=true", "-Doptimize=ReleaseFast",
                              "-Dtarget=x86_64-linux-musl", "-Dcpu=native", "-j2"]
                and argv[prefix + 1:] == [str(root / "install"), "--summary", "all"]
                and digest(Path(argv[0])) == build["zig_sha256"], f"Wrong {arm} build flags or compiler")
        argv_prefixes[arm] = argv[:prefix]
        closure = {}
        for entry in source["files"]:
            name = entry["path"]
            path = source_dir / name
            require(name not in closure and path.resolve().is_relative_to(source_dir) and not path.is_symlink()
                    and digest(path) == entry["sha256"] and stat.S_IMODE(path.stat().st_mode) == entry["mode"],
                    f"{arm} sealed source differs: {name}")
            closure[name] = (entry["sha256"], entry["mode"])
        closures[arm] = closure
        receipts[arm] = {"source": str(manifest), "source_sha256": digest(manifest), "build": str(build_path), "build_sha256": digest(build_path),
                         "binary": str(binary), "binary_sha256": BINARIES[arm]}
        if arm == CANDIDATE:
            require(source["uncommitted_candidate"] is True and source["baseline_source_identity_sha256"] == receipts[CONTROL]["source_sha256"]
                    and source["runtime_changes"] == ["examples/sql_postgres.zig"]
                    and set(source["test_changes"]) == SOURCE_CHANGES - {"examples/sql_postgres.zig"}, "Unapproved candidate changes")
    baseline, candidate = (closures[arm] for arm in ARMS)
    changed = {name for name in baseline.keys() | candidate.keys() if baseline.get(name) != candidate.get(name)}
    require(argv_prefixes[CONTROL] == argv_prefixes[CANDIDATE] and len(baseline) == 347 and len(candidate) == 348
            and candidate.keys() - baseline.keys() == {"src/tests/sql_postgres_tests.zig"} and baseline.keys() <= candidate.keys()
            and changed == SOURCE_CHANGES, "Production or test closure differs from the approved candidate")
    return receipts


def check_auth(fixture, settings, proof, rules):
    require(proof["container"] == fixture["container"] and proof["labels"]["uwz.run-token"] == fixture["owner_token"]
            and proof["after"]["postmaster"] == settings["postmaster"] and proof["after"]["tcp_clients"] == 0
            and proof["verified_roles"] == ["bench", "uwz_test", "uwz_world_test"] and proof["successful_probes"] == 6,
            "Missing corrected SCRAM fixture proof")
    require(rules and all(rule["error"] is None and rule["file_name"] == proof["after"]["hba_file"] for rule in rules)
            and [rule["rule_number"] for rule in rules] == list(range(1, len(rules) + 1)), "Invalid HBA rules")
    first = next((rule for rule in rules if rule["type"] != "local"), {})
    require(first.get("type") == "host" and first.get("auth_method") == "scram-sha-256"
            and first.get("address") == "127.0.0.1" and first.get("netmask") == "255.255.255.255"
            and first.get("database") == first.get("user_name") == ["all"], "Active fixture HBA changed")


def affinity(raw):
    masks = sorted(re.findall(r"^Cpus_allowed_list:\s*(\S+)", raw, re.M))
    require(bool(masks), "Application affinity evidence missing")
    return masks


def decision(pairs):
    metrics = {}
    for key in ("rps", "application_cpu", "postgres_cpu", "p99_us"):
        lhs, rhs = zip(*[(pair[CONTROL][key], pair[CANDIDATE][key]) for pair in pairs])
        require(len(lhs) == KEEP_RULE["required_favorable_pairs"] and all(value > 0 for value in (*lhs, *rhs)),
                f"Invalid paired metric {key}")
        direction = 1 if key == "rps" else -1
        gains = [100 * direction * (right - left) / left for left, right in zip(lhs, rhs)]
        span = 100 * (max(lhs) - min(lhs)) / statistics.median(lhs)
        metrics[key] = {"control_median": statistics.median(lhs), "candidate_median": statistics.median(rhs),
                        "paired_gains_percent": gains, "median_gain_percent": statistics.median(gains),
                        "control_span_percent": span, "all_favorable": all(gain > 0 for gain in gains),
                        "worse_pairs": sum(gain < 0 for gain in gains)}
    benefits = [key for key in KEEP_RULE["eligible_metrics"]
                if metrics[key]["all_favorable"] and metrics[key]["median_gain_percent"] > metrics[key]["control_span_percent"]]
    reject_rps = metrics["rps"]["worse_pairs"] >= KEEP_RULE["rps_worse_pairs_veto"]
    reject_p99 = metrics["p99_us"]["worse_pairs"] >= KEEP_RULE["p99_worse_pairs_veto"]
    return {"keep": bool(benefits) and not reject_rps and not reject_p99, "benefits": benefits,
            "repeatable_rps_regression": reject_rps, "repeatable_p99_regression": reject_p99, "metrics": metrics}
