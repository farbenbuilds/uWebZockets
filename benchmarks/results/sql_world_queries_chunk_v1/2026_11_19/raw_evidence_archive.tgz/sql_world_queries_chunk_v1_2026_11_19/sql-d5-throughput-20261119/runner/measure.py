import argparse
from datetime import datetime, timezone
import hashlib
import http.client
import json
import os
from pathlib import Path
import platform
import re
import resource
import secrets
import shutil
import signal
import socket
import statistics
import subprocess
import time

from contract import (CONNECTIONS, DURATION, FIXED, POOL, PROFILES, ROUTES, SAMPLES, THREADS, WARMUP, WORKERS,
                      check_client, fixed_result, require, route_contract, sql_work, typed_world)


LABEL = "sql-d5-throughput-20261119"
RUN_LABELS = {"uwz.sql-experiment": LABEL, "uwz.role": "application"}
WORLD_SQL = "SELECT json_build_object('id',id,'randomNumber',randomnumber) FROM public.world;"
STATS_SQL = """
SELECT json_build_object(
  'idx_scan',t.idx_scan,'pkey_scans',i.idx_scan,'seq_scan',t.seq_scan,'n_tup_upd',t.n_tup_upd,'n_tup_ins',t.n_tup_ins,'n_tup_del',t.n_tup_del,
  'n_tup_hot_upd',t.n_tup_hot_upd,'autovacuum_count',t.autovacuum_count,'autoanalyze_count',t.autoanalyze_count,
  'xact_rollback',(SELECT xact_rollback FROM pg_stat_database WHERE datname=current_database()),
  'stats_reset',(SELECT stats_reset FROM pg_stat_database WHERE datname=current_database()),
  'postmaster',pg_postmaster_start_time(),'world_oid',t.relid::text,'world_pkey_oid',i.indexrelid::text,
  'tcp_clients',(SELECT count(*) FROM pg_stat_activity WHERE backend_type='client backend' AND client_addr IS NOT NULL),
  'bench_tcp_clients',(SELECT count(*) FROM pg_stat_activity WHERE backend_type='client backend' AND client_addr IS NOT NULL
                         AND datname='benchmark' AND usename='bench'),
  'active_tcp_clients',(SELECT count(*) FROM pg_stat_activity WHERE backend_type='client backend' AND client_addr IS NOT NULL AND state='active'),
  'ssl_clients',(SELECT count(*) FROM pg_stat_activity a JOIN pg_stat_ssl s USING(pid) WHERE a.client_addr IS NOT NULL AND s.ssl),
  'plan_cache_mode',current_setting('plan_cache_mode'),'policy_source',(SELECT source FROM pg_settings WHERE name='plan_cache_mode'),
  'shared_preload_libraries',current_setting('shared_preload_libraries'),'fsync',current_setting('fsync'),
  'synchronous_commit',current_setting('synchronous_commit'))
FROM pg_stat_user_tables t JOIN pg_stat_user_indexes i ON i.relid=t.relid
WHERE t.schemaname='public' AND t.relname='world' AND i.indexrelname='world_pkey';
"""


def now():
    return datetime.now(timezone.utc).isoformat()



def save_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")



def terminate_group(command):
    try:
        os.killpg(command.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass  # The whole subprocess group has already exited.
    return command.communicate()



def run(directory, label, argv, timeout=60, check=True):
    started = now()
    interrupted = False
    before_ns = time.monotonic_ns()
    with subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True) as command:
        try:
            stdout, stderr = command.communicate(timeout=timeout)
            code = command.returncode
        except subprocess.TimeoutExpired:
            stdout, stderr = terminate_group(command)
            code = "timeout"
        except KeyboardInterrupt:
            stdout, stderr = terminate_group(command)
            code, interrupted = "interrupted", True
    after_ns = time.monotonic_ns()
    (directory / f"{label}.stdout").write_bytes(stdout)
    (directory / f"{label}.stderr").write_bytes(stderr)
    save_json(directory / f"{label}.command.json", {
        "argv": [str(arg) for arg in argv], "started_at": started,
        "finished_at": now(), "exit_code": code,
        "monotonic_before_spawn_ns": before_ns, "monotonic_after_reap_ns": after_ns,
    })
    if interrupted:
        raise KeyboardInterrupt
    if check and code != 0:
        raise RuntimeError(f"{label} exit={code}. See {directory}.")
    return stdout.decode(errors="replace")



def snapshot_stats(args, directory, label):
    result = run(directory, label, [
        "docker", "exec", "--user", "postgres", args.db_container, "psql", "-X", "-w", "-At",
        "-h", "/var/run/postgresql", "-U", args.db_user, "-d", args.db_name,
        "-v", "ON_ERROR_STOP=1", "-c", STATS_SQL,
    ])
    return json.loads(result)



def process_state(pid):
    proc = Path(f"/proc/{pid}")
    data = {"pid": pid}
    try:
        data["proc_stat"] = (proc / "stat").read_text().strip()
        data["rss"] = {key: val.strip() for key, val in (
            line.split(":", 1) for line in (proc / "status").read_text().splitlines()
        ) if key in ("VmRSS", "VmHWM", "RssAnon", "RssFile", "RssShmem", "Threads")}
        data["cgroup"] = (proc / "cgroup").read_text()
        cgroup_path = next(line[3:] for line in data["cgroup"].splitlines() if line.startswith("0::"))
        cgroup = Path("/sys/fs/cgroup") / cgroup_path.lstrip("/")
        for filename in ("cpu.stat", "cpu.max", "memory.current", "memory.peak", "memory.stat", "memory.max"):
            path = cgroup / filename
            if path.exists():
                data[filename] = path.read_text().strip()
    except (OSError, StopIteration) as error:
        data["unavailable"] = str(error)
    return data



def resource_snapshot(args, directory, label, app_pid):
    resource_data = {
        "at": now(), "monotonic_start_ns": time.monotonic_ns(),
        "application": process_state(app_pid), "postgres": process_state(args.db_pid),
        "monotonic_end_ns": time.monotonic_ns(),
    }
    save_json(directory / f"{label}.resources.json", resource_data)
    return resource_data



def cpu_delta(before, after):
    result = {}
    for role in ("application", "postgres"):
        if "cpu.stat" not in before[role] or "cpu.stat" not in after[role]:
            result[role] = {"unavailable": "Missing cgroup cpu.stat. See raw resource snapshots."}
            continue
        first, second = (dict(line.split() for line in snapshot[role]["cpu.stat"].splitlines())
                         for snapshot in (before, after))
        result[role] = {key: int(second[key]) - int(first[key]) for key in ("usage_usec", "user_usec", "system_usec")}
    return result



def read_pid(directory, label, container):
    return int(run(directory, label, ["docker", "inspect", "--format", "{{.State.Pid}}", container]))



def clock_namespace(raw):
    inode, child_inode, monotonic, boottime, boot_hash = raw.splitlines()
    if not re.fullmatch(r"time:\[\d+\]", inode) or inode != child_inode or not re.fullmatch(r"[0-9a-f]{64}", boot_hash):
        raise ValueError("Malformed kernel or Linux time namespace identity")
    offsets = {}
    for expected, line in (("monotonic", monotonic), ("boottime", boottime)):
        clock, seconds, nanos = line.split()
        if clock != expected or not 0 <= int(nanos) < 1_000_000_000:
            raise ValueError("Malformed Linux time namespace offset")
        offsets[clock] = int(seconds) * 1_000_000_000 + int(nanos)
    return {"inode": inode, "child_inode": child_inode, "offsets_ns": offsets, "kernel_boot_sha256": boot_hash}



def same_clock(left, right):
    # The offset is relative to the initial time namespace of this kernel.
    return (left["kernel_boot_sha256"] == right["kernel_boot_sha256"]
            and left["offsets_ns"] == right["offsets_ns"] == {"monotonic": 0, "boottime": 0})



def host_clock_binding(pid, container):
    proc = Path(f"/proc/{pid}")
    cgroup = (proc / "cgroup").read_text()
    matching_paths = [line[3:] for line in cgroup.splitlines() if line.startswith("0::")]
    if len(matching_paths) != 1 or Path(matching_paths[0]).name not in (container, f"docker-{container}.scope"):
        raise ValueError("Docker immutable application ID does not match the host PID cgroup")
    binding = {"pid": pid, "cgroup": cgroup}
    try:
        binding["time_inode"] = os.readlink(proc / "ns/time")
    except PermissionError as error:
        binding["unavailable_time_inode_errno"] = error.errno
    return binding



def find_owned_container(directory, labels):
    filters = [arg for key, value in labels.items() for arg in ("--filter", f"label={key}={value}")]
    for index in range(3):
        matches = run(directory, f"app_lookup_{index:02}", [
            "docker", "ps", "--all", "--quiet", "--no-trunc", *filters,
        ]).splitlines()
        if not matches:
            time.sleep(1)
            continue
        if len(matches) != 1 or not re.fullmatch(r"[0-9a-f]{64}", matches[0]):
            raise RuntimeError("Unexpected owned Docker container lookup result")
        return matches[0]
    return None



def hash_file(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()



def interrupted(_signum, _frame):
    raise KeyboardInterrupt


def check_postgres(args, snapshot):
    require(snapshot["postmaster"] == args.settings["postmaster"] and snapshot["plan_cache_mode"] == "auto"
            and snapshot["policy_source"] == "default" and snapshot["shared_preload_libraries"] == ""
            and snapshot["fsync"] == snapshot["synchronous_commit"] == "on", "PostgreSQL postmaster or effective settings differ")


def settled_stats(args, case, phase):
    previous = None
    for index in range(20):
        snapshot = snapshot_stats(args, case, f"pg_{phase}_{index:02}")
        check_postgres(args, snapshot)
        if snapshot == previous and snapshot["tcp_clients"] == snapshot["bench_tcp_clients"] == snapshot["ssl_clients"] == 0:
            return snapshot
        previous = snapshot
        time.sleep(1)
    raise RuntimeError(f"World counters or DB sockets did not settle at {phase}")


def app_ready(args, case, container):
    for index in range(45):
        snapshot = snapshot_stats(args, case, f"ready_sql_{index:02}")
        check_postgres(args, snapshot)
        if snapshot["tcp_clients"] == snapshot["bench_tcp_clients"] == WORKERS * POOL and snapshot["ssl_clients"] == 0:
            endpoint = f"0100007F:{args.port:04X}"
            script = ("ls -l /proc/1/fd\n"
                      f"awk '$2 == \"{endpoint}\" && $4 == \"0A\" {{ print \"owned_listener_inode=\" $10 }}' /proc/1/net/tcp\n"
                      "for task in /proc/1/task/*; do awk '/^Name:|^Cpus_allowed_list:/ {print}' \"$task/status\"; done\n")
            exposed = run(case, f"ready_app_{index:02}", ["docker", "exec", container, "sh", "-ec", script])
            listeners = set(re.findall(r"owned_listener_inode=(\d+)", exposed))
            fds = set(re.findall(r"socket:\[(\d+)\]", exposed))
            if listeners:
                require(listeners <= fds and exposed.count("anon_inode:[io_uring]") == WORKERS,
                        "HTTP listener or io_uring descriptors do not belong to the owned application")
                return snapshot
        state = run(case, f"ready_state_{index:02}", ["docker", "inspect", "--format", "{{.State.Status}}", container])
        require(state.strip() == "running", "Owned app exited before pool and listener readiness")
        time.sleep(.5)
    raise RuntimeError("App did not reach the 96-connection plaintext bench pool and owned loopback listener")


def fixed_load(args, case, route, path, count):
    records, returned = [], []
    connection = http.client.HTTPConnection("127.0.0.1", args.port, timeout=12)
    try:
        for _ in range(FIXED):
            request = {"method": "GET", "path": path}
            try:
                connection.request("GET", path, headers={"Connection": "keep-alive", "User-Agent": "uwz-sql-local-v1"})
                response = connection.getresponse()
                request.update({"status": response.status, "version": response.version, "headers": response.getheaders(),
                                "body_utf8": response.read().decode("utf-8")})
            except (OSError, http.client.HTTPException, UnicodeDecodeError) as error:
                request["error"] = str(error)
            records.append(request)
            rows = fixed_result(request, route, path, count)
            if route != "updates":
                require(all(args.world[row["id"]] == row["randomNumber"] for row in rows), "Fixed point read disagreed with the seeded World")
            returned.extend(rows)
    finally:
        connection.close()
        save_json(case / "fixed_responses.json", records)
    return returned


def wrk_load(args, case, label, seconds, path, app_pid):
    resource_snapshot(args, case, f"{label}_before", app_pid)
    request = case / f"{label}.request.http"
    raw = run(case, label, [
        "env", "LC_ALL=C", "/usr/bin/time", "-v", "-o", case / f"{label}.client_time.txt", args.wrk,
        "-t", str(THREADS), "-c", str(CONNECTIONS), "-d", f"{seconds}s", "--timeout", "2s", "--latency",
        "-s", args.lua, f"http://127.0.0.1:{args.port}{path}", "--", request,
    ], check=False)
    resource_snapshot(args, case, f"{label}_after", app_pid)
    command = json.loads((case / f"{label}.command.json").read_text())
    lines = [line.removeprefix("SQL_SAMPLE ") for line in raw.splitlines() if line.startswith("SQL_SAMPLE ")]
    require(command["exit_code"] == 0 and len(lines) == 1 and request.is_file(), f"wrk command or evidence failed at {label}")
    sample = json.loads(lines[0])
    check_client(sample, seconds)
    return sample | {"rps": sample["requests"] * 1_000_000 / sample["duration_us"]}


def collect_stop(case, container, labels):
    actual = json.loads(run(case, "app_verify_ownership", ["docker", "inspect", "--format", "{{json .Config.Labels}}", container]))
    require(all(actual.get(key) == value for key, value in labels.items()), "Application ownership changed before cleanup")
    run(case, "app_stop", ["docker", "stop", "--time", "30", container], check=False)
    run(case, "app_logs", ["docker", "logs", "--timestamps", container], check=False)
    state = run(case, "app_final_state", ["docker", "inspect", "--format", "{{json .State}}", container], check=False)
    run(case, "app_remove", ["docker", "rm", "--force", container], check=False)
    errors = [label for label in ("app_stop", "app_logs", "app_final_state", "app_remove")
              if json.loads((case / f"{label}.command.json").read_text())["exit_code"] != 0]
    final = json.loads(state) if "app_final_state" not in errors else {"ExitCode": None, "OOMKilled": None}
    return final | {"evidence_errors": errors}


def persisted_world(args, case, returned, accounting_after):
    query = run(case, "world_after_updates", ["docker", "exec", args.db_container, "psql", "-X", "-w", "-U", "bench", "-d",
                                               "benchmark", "-At", "-v", "ON_ERROR_STOP=1", "-c", WORLD_SQL])
    rows = typed_world([json.loads(line) for line in query.splitlines()])
    actual = {row["id"]: row["randomNumber"] for row in rows}
    overlay = {row["id"]: row["randomNumber"] for row in returned}
    require(len(rows) == len(actual) == 10000 and actual == (args.world | overlay), "Persisted World differs from last returned updates")
    probe_after = settled_stats(args, case, "probe_after")
    require(probe_after["seq_scan"] - accounting_after["seq_scan"] == 1 and all(probe_after[key] == accounting_after[key]
            for key in ("idx_scan", "pkey_scans", "n_tup_upd", "n_tup_ins", "n_tup_del", "xact_rollback", "stats_reset", "postmaster")),
            "Unexpected World persistence probe counters")
    return {"matched_rows": len(actual), "distinct_updated_ids": len(overlay),
            "probe_seq_scan_delta": probe_after["seq_scan"] - accounting_after["seq_scan"],
            "probe_idx_scan_delta": probe_after["idx_scan"] - accounting_after["idx_scan"]}


def measure(args, case, route, fixed):
    case.mkdir()
    name = case.name
    print(f"Starting {name}", flush=True)
    path, count = route_contract(route, args.count)
    owner = secrets.token_hex(16)
    labels = RUN_LABELS | {"uwz.run-owner": owner}
    save_json(case / "app_ownership.json", {"labels": labels})
    work = {"route": route, "path": path, "count": count, "fixed": fixed, "valid": False}
    container = None
    try:
        before = settled_stats(args, case, "before")
        work["pg_before"] = before
        if args.last_pg is not None:
            require(all(before[key] == args.last_pg[key] for key in ("idx_scan", "pkey_scans", "seq_scan", "n_tup_upd", "n_tup_ins", "n_tup_del",
                       "xact_rollback", "stats_reset", "postmaster", "world_oid", "world_pkey_oid")), "World counters changed between cases")
        owned = run(case, "app_run", ["docker", "run", "--detach", "--pull=never", "--network", "host", "--name", f"uwz-d5-{name}-{owner[:8]}",
                     *(part for key, value in labels.items() for part in ("--label", f"{key}={value}")),
                     "--security-opt", "seccomp=unconfined", "--ulimit", "memlock=-1:-1", "--ulimit", "nofile=524288:524288",
                     "--stop-signal", "SIGTERM", "--env-file", args.app_env, "--env", f"UWZ_SQL_WORKERS={WORKERS}",
                     "--env", "UWZ_SQL_AFFINITY=1", "--env", f"UWZ_HTTP_PORT={args.port}",
                     "--mount", f"type=bind,source={args.binary},target=/server,readonly", "--entrypoint", "/server", args.image]).strip()
        require(re.fullmatch(r"[0-9a-f]{64}", owned), "Unexpected application container ID")
        container = owned
        work["ready"] = app_ready(args, case, container)
        app_pid = read_pid(case, "app_pid", container)
        save_json(case / "app_host_clock_namespace.json", host_clock_binding(app_pid, container))
        info = run(case, "app_clock_namespace", ["docker", "exec", container, "sh", "-ec", "readlink /proc/1/ns/time\n"
                  "readlink /proc/1/ns/time_for_children\ncat /proc/1/timens_offsets\nsha256sum /proc/sys/kernel/random/boot_id | cut -d ' ' -f 1"])
        require(same_clock(clock_namespace(info), args.clock_namespace), "Host and application clock coordinates differ")
        if fixed:
            returned = fixed_load(args, case, route, path, count)
            complete, cutoff = FIXED, 0
        else:
            work["warmup"] = wrk_load(args, case, "warmup", WARMUP, path, app_pid)
            work["samples"] = [wrk_load(args, case, f"timed_{index}", DURATION, path, app_pid) for index in range(1, SAMPLES + 1)]
            complete = work["warmup"]["requests"] + sum(sample["requests"] for sample in work["samples"])
            cutoff = CONNECTIONS * (1 + SAMPLES)
    except (OSError, ValueError, KeyError, RuntimeError) as error:
        work["failure"] = str(error)
    finally:
        container = container or find_owned_container(case, labels)
        if container is not None:
            work["app_state"] = collect_stop(case, container, labels)
    try:
        after = settled_stats(args, case, "after")
        work["pg_after"] = after
        if "failure" not in work:
            require(work["app_state"]["ExitCode"] == 0 and work["app_state"]["OOMKilled"] is False
                    and not work["app_state"]["evidence_errors"], "Application did not drain cleanly or evidence collection failed")
            logs = "\n".join((case / f"app_logs.{stream}").read_text() for stream in ("stdout", "stderr"))
            workers = re.findall(r"SQL benchmark worker=(\d+) pool=(\d+) slab_bytes=(\d+)", logs)
            require(sorted(int(index) for index, _, _ in workers) == list(range(WORKERS))
                    and all(int(pool) == POOL and int(slab) > 0 for _, pool, slab in workers), "App worker/pool log differs from the profile")
            work["sql_work"] = sql_work(before, after, route, count, complete, cutoff)
            if fixed and route == "updates":
                work["persisted_world"] = persisted_world(args, case, returned, after)
                after = json.loads(sorted(case.glob("pg_probe_after_*.stdout"))[-1].read_text())
            args.last_pg = after
            work["valid"] = True
    except (OSError, ValueError, KeyError, RuntimeError) as error:
        work["failure"] = str(error)
    save_json(case / "summary.json", work)
    print(f"Finished {name} valid={work['valid']} {work.get('sql_work', work.get('failure', ''))}", flush=True)
    return work


def bind_fixture(args):
    fixture = json.loads(args.fixture.read_text())
    args.db_container, args.image = fixture["container"], fixture["image"]
    args.db_user, args.db_name, args.port = fixture["pg_user"], fixture["pg_database"], fixture["http_port"]
    fields = "\n".join(("{{json .Id}}", "{{json .Image}}", "{{json .Config.Image}}", "{{json .State.Pid}}",
                        '{{json (index .NetworkSettings.Ports "5432/tcp")}}', "{{json .Config.Labels}}", "{{json .HostConfig.NetworkMode}}"))
    raw = run(args.output, "db_identity", ["docker", "inspect", "--format", fields, args.db_container])
    container, image_id, image, args.db_pid, ports, labels, network = map(json.loads, raw.splitlines())
    expected_id = run(args.output, "db_image_id", ["docker", "image", "inspect", "--format", "{{.Id}}", args.image]).strip()
    require(container == args.db_container and image == args.image and image_id == expected_id and args.db_pid > 0 and network == "bridge"
            and ports == [{"HostIp": "127.0.0.1", "HostPort": str(fixture["pg_host_port"])}]
            and labels.get("uwz.sql-experiment") == LABEL and labels.get("uwz.role") == "database"
            and labels.get("uwz.run-token") == fixture["owner_token"], "Incorrect PostgreSQL fixture or topology")
    args.settings = json.loads(Path(fixture["settings_path"]).read_text())
    raw = Path(fixture["world_path"])
    require(hash_file(raw) == fixture["world_sha256"] and hash_file(Path(fixture["settings_path"])) == fixture["settings_sha256"],
            "World seed or PostgreSQL settings export changed")
    rows = typed_world([json.loads(line) for line in raw.read_text().splitlines()])
    args.world = {row["id"]: row["randomNumber"] for row in rows}
    require(len(rows) == len(args.world) == fixture["seed_rows"] == 10000, "Wrong World fixture cardinality")
    return fixture


def main():
    parser = argparse.ArgumentParser(description="D-5 real PostgreSQL World route characterization")
    file_options = ("binary", "wrk", "app_env", "fixture", "build_receipt", "source_identity")
    for name in file_options:
        parser.add_argument("--" + name.replace("_", "-"), type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--count", choices=tuple(PROFILES), default="20")
    args = parser.parse_args()
    for name in file_options:
        setattr(args, name, getattr(args, name).resolve(strict=True))
    args.output = args.output.resolve()
    args.output.mkdir(parents=True)
    args.lua = Path(__file__).with_name("status.lua").resolve()
    fixture = bind_fixture(args)
    build = json.loads(args.build_receipt.read_text())
    sealed = build["binaries"]["sql_cluster_server"]
    binary_hash = hash_file(args.binary)
    require(build["exit_code"] == 0 and sealed["sha256"] == binary_hash and sealed["bytes"] == args.binary.stat().st_size
            and build["source_identity_sha256"] == hash_file(args.source_identity), "Selected D-5 binary differs from sealed source/build")
    clock = time.get_clock_info("monotonic")
    require(clock.implementation == "clock_gettime(CLOCK_MONOTONIC)" and clock.monotonic and not clock.adjustable, "Wrong monotonic clock")
    clock_raw = (os.readlink("/proc/self/ns/time") + "\n" + os.readlink("/proc/self/ns/time_for_children") + "\n"
                 + Path("/proc/self/timens_offsets").read_text() + hash_file(Path("/proc/sys/kernel/random/boot_id")) + "\n")
    args.clock_namespace = clock_namespace(clock_raw)
    (args.output / "host_clock_namespace.txt").write_text(clock_raw)
    paths = [*(getattr(args, key) for key in file_options if key != "app_env"), args.lua, Path(__file__).resolve(), Path(__file__).with_name("contract.py"),
             Path(fixture["world_path"]), Path(fixture["settings_path"])]
    save_json(args.output / "metadata.json", {
        "recorded_at": now(), "selected_profile": args.count, "predeclared_count_profiles": PROFILES, "routes": ROUTES,
        "workers": WORKERS, "pool": POOL, "connections": CONNECTIONS, "threads": THREADS, "warmup_seconds": WARMUP,
        "timed_seconds": DURATION, "sample_count": SAMPLES, "fixed_count": FIXED, "pipeline_depth": 1, "required_rps_above": 300000,
        "binary": str(args.binary), "binary_sha256": binary_hash, "wrk": str(args.wrk), "lua": str(args.lua),
        "db_container": args.db_container, "db_pid": args.db_pid, "db_image": args.image, "http_port": args.port,
        "host_policy": "shared development host; PostgreSQL bridge through loopback, application host and default cluster core pinning",
        "kernel": platform.release(), "client_affinity": sorted(os.sched_getaffinity(0)), "proc_clock_ticks_per_second": os.sysconf("SC_CLK_TCK"),
        "clock_namespace": args.clock_namespace, "python_monotonic_clock": vars(clock),
        "status_scope": "Lua checks every completed response for HTTP 200 with wrk body capture; timed JSON is not decoded",
        "latency_scope": "HTTP client percentiles; no SQL execution latency inferred from HTTP",
        "sha256": {str(path): hash_file(path) for path in paths},
    })
    run(args.output, "elf", [shutil.which("readelf") or "readelf", "-h", "-l", args.binary, args.wrk])
    args.last_pg = None
    report = {}
    for phase in ("fixed", "timed"):
        report[phase] = {}
        for route in ROUTES:
            outcome = measure(args, args.output / f"{phase}_{route}", route, fixed=phase == "fixed")
            report[phase][route] = outcome
            if not outcome["valid"]:
                break
        if not all(case["valid"] for case in report[phase].values()):
            break
    save_json(args.output / "summary.json", report)
    inventory = run(args.output, "app_final_inventory", ["docker", "ps", "--all", "--quiet", "--no-trunc",
                    *(part for key, value in RUN_LABELS.items() for part in ("--filter", f"label={key}={value}"))])
    return 0 if not inventory and len(report) == 2 and all(len(cases) == 3 and all(case["valid"] for case in cases.values())
                                                          for cases in report.values()) else 2


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, interrupted)
    raise SystemExit(main())

