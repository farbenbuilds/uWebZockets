wrk.headers["Connection"] = "keep-alive"
wrk.headers["User-Agent"] = "uwz-sql-local-v1"

local threads = {}
status_200 = 0
non_200 = 0

function setup(thread)
    threads[#threads + 1] = thread
end

function init(args)
    local file = assert(io.open(args[1], "wb"))
    file:write(wrk.format())
    file:close()
end

function response(status)
    if status == 200 then
        status_200 = status_200 + 1
    else
        non_200 = non_200 + 1
    end
end

function done(summary, latency, _)
    local good, wrong = 0, 0
    for _, thread in ipairs(threads) do
        good = good + thread:get("status_200")
        wrong = wrong + thread:get("non_200")
    end
    io.write(string.format(
        'SQL_SAMPLE {"requests":%d,"duration_us":%d,"bytes":%d,"status_200":%d,"non_200":%d,"connect_errors":%d,"read_errors":%d,"write_errors":%d,"status_errors":%d,"timeout_errors":%d,"p50_us":%.3f,"p95_us":%.3f,"p99_us":%.3f}\n',
        summary.requests, summary.duration, summary.bytes, good, wrong,
        summary.errors.connect, summary.errors.read, summary.errors.write, summary.errors.status,
        summary.errors.timeout, latency:percentile(50), latency:percentile(95), latency:percentile(99)))
end
