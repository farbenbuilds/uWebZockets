#!/usr/bin/env python3
"""Prepare the owned host-loopback World database from the frozen bridge seed."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import socket
import subprocess
import time


WORK = Path(__file__).resolve().parent
PRIVATE = WORK / "private"
PUBLIC = WORK / "fixture"
IMAGE = "postgres@sha256:e3d24f6906d0760bf4da0dae872415391ededefad23fd471c47dc53b0ddf3c42"
LABEL = "sql-d5-throughput-20261119-host"
SEED_SHA = "1edf81f613f4c7878fb05e763e556d3e8f44b33f9ca87915870b7b5cdcf9c2e5"
HTTP_PORT = 31631


def require(condition, message):
    if not condition:
        raise SystemExit(message)


def private_file(name, text):
    fd = os.open(PRIVATE / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as output:
        output.write(text)


def psql(container, pg_port, command, stdin=None):
    argv = ["docker", "exec", "-i", container, "psql", "-X", "-w", "-h", "/var/run/postgresql", "-p", str(pg_port),
            "-U", "bench", "-d", "benchmark", "-At", "-v", "ON_ERROR_STOP=1"]
    if command is not None:
        argv.extend(("-c", command))
    return subprocess.run(argv, input=stdin, capture_output=True, text=True, timeout=45, check=True).stdout


def owned_labels(container, expected):
    actual = json.loads(subprocess.check_output(["docker", "inspect", "--format", "{{json .Config.Labels}}", container], text=True))
    require(all(actual.get(key) == value for key, value in expected.items()), "PostgreSQL fixture ownership differs")


def prove_listener(container, pg_port, expected_cmd):
    fields = "\n".join(("{{json .Id}}", "{{json .State.Pid}}", "{{json .HostConfig.NetworkMode}}",
                        "{{json .HostConfig.PortBindings}}", "{{json .NetworkSettings.Ports}}", "{{json .Config.Cmd}}"))
    inspect = ["docker", "inspect", "--format", fields, container]
    identity, pid, network, binds, ports, command = map(json.loads, subprocess.check_output(inspect, text=True).splitlines())
    unpublished = ports is None or isinstance(ports, dict) and all(value in (None, []) for value in ports.values())
    require(identity == container and pid > 0 and network == "host" and binds in (None, {}) and unpublished and command == expected_cmd,
            "Unexpected owned PostgreSQL host topology or command")
    cgroup = Path(f"/proc/{pid}/cgroup").read_text()
    paths = [line[3:] for line in cgroup.splitlines() if line.startswith("0::")]
    require(len(paths) == 1 and Path(paths[0]).name in (container, f"docker-{container}.scope"), "PostgreSQL PID cgroup ownership differs")
    port_hex = f"{pg_port:04X}"
    script = ("ls -l /proc/1/fd\n"
              f"awk -v port={port_hex} '$4 == \"0A\" && substr($2,length($2)-3) == port "
              "{ print \"listener=\" $2 \" inode=\" $10 }' /proc/1/net/tcp /proc/1/net/tcp6\n")
    scan = ["docker", "exec", "--user", "postgres", container, "sh", "-ec", script]
    raw = subprocess.check_output(scan, text=True, timeout=10)
    endpoints = re.findall(r"listener=(\S+) inode=(\d+)", raw)
    socket_fds = set(re.findall(r"socket:\[(\d+)\]", raw))
    require(len(endpoints) == 1 and endpoints[0][0] == f"0100007F:{port_hex}" and endpoints[0][1] in socket_fds,
            "PostgreSQL must own the sole IPv4 loopback listener on its assigned port")
    return {"container": container, "pid": pid, "cgroup": cgroup, "network_mode": network, "port_bindings": binds,
            "published_ports": ports, "pg_command": command, "pg_port": pg_port, "inode": endpoints[0][1],
            "inspect_argv": inspect, "listener_argv": scan, "listener_stdout": raw}


def main():
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", HTTP_PORT))
        with socket.socket() as database_listener:
            database_listener.bind(("127.0.0.1", 0))
            pg_port = database_listener.getsockname()[1]
    bridge_fixture = WORK.parent / "fixture"
    seed = (bridge_fixture / "world.sql").read_bytes()
    require(hashlib.sha256(seed).hexdigest() == SEED_SHA, "The original World SQL seed does not match its pinned bytes")
    subprocess.run(["docker", "image", "inspect", IMAGE], check=True, stdout=subprocess.DEVNULL)
    PRIVATE.mkdir(mode=0o700)
    PUBLIC.mkdir()
    (PUBLIC / "world.sql").write_bytes(seed)
    password = secrets.token_hex(24)
    owner = secrets.token_hex(16)
    private_file("owner_token", owner + "\n")
    private_file("pg_port", str(pg_port) + "\n")
    private_file("postgres.env", "POSTGRES_USER=bench\nPOSTGRES_DB=benchmark\nPOSTGRES_PASSWORD=" + password + "\n")
    labels = {"uwz.sql-experiment": LABEL, "uwz.role": "database", "uwz.run-token": owner}
    pg_command = ["-c", "max_connections=100", "-c", "listen_addresses=127.0.0.1", "-c", f"port={pg_port}"]
    command = ["docker", "run", "--detach", "--pull=never", "--network", "host",
               *(part for key, value in labels.items() for part in ("--label", f"{key}={value}")),
               "--env-file", str(PRIVATE / "postgres.env"), "--tmpfs", "/var/lib/postgresql", IMAGE, *pg_command]
    container = subprocess.check_output(command, text=True, timeout=60).strip()
    require(re.fullmatch(r"[0-9a-f]{64}", container), "PostgreSQL did not provide an immutable container ID")
    private_file("container.id", container + "\n")
    owned_labels(container, labels)
    for _ in range(60):
        command_ready = ["docker", "exec", container, "pg_isready", "-h127.0.0.1", f"-p{pg_port}", "-Ubench", "-dbenchmark"]
        if subprocess.run(command_ready, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10).returncode == 0:
            break
        time.sleep(.5)
    else:
        raise SystemExit("PostgreSQL readiness failed; the owned fixture is identifiable for cleanup")
    evidence = prove_listener(container, pg_port, pg_command)
    listener_proof = PUBLIC / "listener.json"
    listener_proof.write_text(json.dumps(evidence, indent=2) + "\n")
    (PUBLIC / "seed.log").write_text(psql(container, pg_port, None, seed.decode("utf-8")))
    private_file("app.env", "PGHOST=127.0.0.1\nPGPORT=" + str(pg_port) + "\nPGUSER=bench\nPGDATABASE=benchmark\nPGPASSWORD=" + password
                 + "\nUWZ_SQL_ALLOW_PLAINTEXT=1\n")
    expected = PUBLIC / "world_initial.jsonl"
    expected.write_text(psql(container, pg_port, "SELECT json_build_object('id',id,'randomNumber',randomnumber) FROM public.world ORDER BY id;"))
    rows = [json.loads(line) for line in expected.read_text().splitlines()]
    require(rows == [{"id": ident, "randomNumber": 1 + (ident * 7919) % 10000} for ident in range(1, 10001)], "Unexpected World seed values")
    require(expected.read_bytes() == (bridge_fixture / "world_initial.jsonl").read_bytes(), "Seeded World differs from bridge baseline")
    (PUBLIC / "version.txt").write_text(psql(container, pg_port, "SELECT version();"))
    (PUBLIC / "schema.txt").write_text(psql(container, pg_port, "SELECT conname,pg_get_constraintdef(oid) FROM pg_constraint WHERE conrelid='public.world'::regclass ORDER BY conname;"))
    settings = json.loads(psql(container, pg_port, """
SELECT json_build_object('role',current_user,'database',current_database(),'postmaster',pg_postmaster_start_time(),
  'endpoint',json_build_object('listen_addresses',current_setting('listen_addresses'),'port',current_setting('port')),
  'settings',(SELECT json_object_agg(name,setting ORDER BY name) FROM pg_settings WHERE name IN
    ('autovacuum','compute_query_id','fsync','full_page_writes','max_connections','plan_cache_mode','server_version_num',
     'shared_buffers','shared_preload_libraries','synchronous_commit','track_counts','wal_level')),
  'policy',(SELECT row_to_json(s) FROM (SELECT setting,source,reset_val FROM pg_settings WHERE name='plan_cache_mode') s),
  'extensions',(SELECT json_agg(extname ORDER BY extname) FROM pg_extension));
"""))
    effective = settings["settings"]
    require(settings["role"] == "bench" and settings["database"] == "benchmark" and effective["server_version_num"] == "180006"
            and effective["max_connections"] == "100" and effective["fsync"] == effective["synchronous_commit"] == effective["autovacuum"] == "on"
            and effective["shared_preload_libraries"] == "" and settings["extensions"] == ["plpgsql"]
            and settings["policy"] == {"setting": "auto", "source": "default", "reset_val": "auto"}, "Unexpected PostgreSQL fixture settings")
    bridge = json.loads((bridge_fixture / "settings.json").read_text())
    require(settings["endpoint"] == {"listen_addresses": "127.0.0.1", "port": str(pg_port)}
            and effective == bridge["settings"] and settings["policy"] == bridge["policy"], "Nontransport settings drifted from bridge baseline")
    (PUBLIC / "settings.json").write_text(json.dumps(settings, indent=2) + "\n")
    (PUBLIC / "plan.json").write_text(psql(container, pg_port, "EXPLAIN (FORMAT JSON) SELECT id,randomnumber FROM public.world WHERE id=1;"))
    record = {"created_utc": datetime.now(timezone.utc).isoformat(), "image": IMAGE, "container": container, "label": LABEL,
              "owner_token": owner, "pg_user": "bench", "pg_database": "benchmark", "pg_host_port": pg_port, "pg_socket_port": pg_port,
              "http_port": HTTP_PORT, "listener_path": str(listener_proof), "listener_sha256": hashlib.sha256(listener_proof.read_bytes()).hexdigest(),
              "seed_sha256": SEED_SHA, "seed_rows": len(rows), "world_path": str(expected), "world_sha256": hashlib.sha256(expected.read_bytes()).hexdigest(),
              "settings_path": str(PUBLIC / "settings.json"), "settings_sha256": hashlib.sha256((PUBLIC / "settings.json").read_bytes()).hexdigest(),
              "postgresql_network": "host_loopback", "data_mount": "tmpfs", "docker_command": command,
              "private_inputs_recorded": False}
    (PUBLIC / "fixture.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({key: record[key] for key in ("image", "pg_host_port", "http_port", "seed_rows")}))


if __name__ == "__main__":
    main()
