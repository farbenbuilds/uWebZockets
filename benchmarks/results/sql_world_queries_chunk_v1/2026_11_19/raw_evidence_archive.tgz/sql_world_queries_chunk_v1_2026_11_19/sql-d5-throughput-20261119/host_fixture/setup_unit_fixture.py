#!/usr/bin/env python3
"""Provision ordinary test databases without touching the benchmark World."""
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import secrets
import stat
import subprocess

from setup_fixture import IMAGE, LABEL, PRIVATE, PUBLIC, SEED_SHA, owned_labels, private_file, prove_listener, require


ROLES = ("uwz_test", "uwz_world_test")
PRIVATE_NAMES = ("unit.env", "world_integration.env")
GUARD_SQL = """
SELECT json_build_object(
 'tcp_clients',(SELECT count(*) FROM pg_stat_activity WHERE client_addr IS NOT NULL),
 'role',current_user,'database',current_database(),'postmaster',pg_postmaster_start_time(),
 'port',current_setting('port'),'plan_cache_mode',current_setting('plan_cache_mode'),
 'test_roles',COALESCE((SELECT json_agg(rolname ORDER BY rolname) FROM pg_roles
   WHERE rolname IN ('uwz_test','uwz_world_test')),'[]'::json),
 'test_databases',COALESCE((SELECT json_agg(datname ORDER BY datname) FROM pg_database
   WHERE datname IN ('uwz_test','uwz_world_test')),'[]'::json),
 'benchmark_world',(SELECT row_to_json(t) FROM (SELECT relid::text,seq_scan,idx_scan,n_tup_ins,n_tup_upd,n_tup_del
   FROM pg_stat_user_tables WHERE schemaname='public' AND relname='world') t));
"""


def execute(container, port, label, user, database, *, sql=None, meta=None, prompt=None):
    argv = ["docker", "exec", "-i", container, "psql", "-qXAt", "-w", "-h", "/var/run/postgresql", "-p", str(port),
            "-U", user, "-d", database, "-vON_ERROR_STOP=1"]
    if meta is not None:
        argv.extend(("-c", meta))
    result = subprocess.run(argv, input=prompt if meta is not None else sql, text=True, capture_output=True, timeout=45)
    require(result.returncode == 0, f"{label} failed with exit {result.returncode}; test SQL output suppressed")
    return result.stdout


def check_guard(snapshot, port, expected_postmaster):
    require(snapshot["tcp_clients"] == 0 and snapshot["role"] == "bench" and snapshot["database"] == "benchmark"
            and snapshot["postmaster"] == expected_postmaster and snapshot["port"] == str(port)
            and snapshot["plan_cache_mode"] == "auto" and snapshot["benchmark_world"] is not None,
            "The owned benchmark cluster is busy or its identity changed")


def main():
    receipt = PUBLIC / "unit_fixture.json"
    require(PRIVATE.is_dir() and not PRIVATE.is_symlink() and PRIVATE.stat().st_uid == os.geteuid()
            and stat.S_IMODE(PRIVATE.stat().st_mode) == 0o700, "Owned private directory differs")
    require(not receipt.exists() and all(not (PRIVATE / name).exists() and not (PRIVATE / name).is_symlink() for name in PRIVATE_NAMES),
            "Test fixture inputs already exist")
    fixture = json.loads((PUBLIC / "fixture.json").read_text())
    container, port, owner = fixture["container"], fixture["pg_socket_port"], fixture["owner_token"]
    require(re.fullmatch(r"[0-9a-f]{64}", container) and re.fullmatch(r"[0-9a-f]{32}", owner)
            and fixture["label"] == LABEL and fixture["image"] == IMAGE and fixture["postgresql_network"] == "host_loopback"
            and port == fixture["pg_host_port"] == 59761 and port != fixture["http_port"]
            and (PRIVATE / "container.id").read_text().strip() == container and (PRIVATE / "owner_token").read_text().strip() == owner
            and (PRIVATE / "pg_port").read_text().strip() == str(port), "Host fixture ownership or assigned port differs")
    labels = {"uwz.sql-experiment": LABEL, "uwz.role": "database", "uwz.run-token": owner}
    owned_labels(container, labels)
    listener = json.loads((PUBLIC / "listener.json").read_text())
    current = prove_listener(container, port, ["-c", "max_connections=100", "-c", "listen_addresses=127.0.0.1", "-c", f"port={port}"])
    require(all(current[key] == listener[key] for key in ("container", "pid", "cgroup", "pg_port", "inode")), "Owned postmaster changed")
    expected_postmaster = json.loads((PUBLIC / "settings.json").read_text())["postmaster"]
    before = json.loads(execute(container, port, "initial test fixture guard", "bench", "benchmark", sql=GUARD_SQL))
    check_guard(before, port, expected_postmaster)
    require(before["test_roles"] == before["test_databases"] == [], "Expected both test roles and databases to be absent")
    seed = (PUBLIC / "world.sql").read_bytes()
    require(hashlib.sha256(seed).hexdigest() == SEED_SHA, "Original World seed bytes differ")
    passwords = {role: secrets.token_hex(24) for role in ROLES}
    require(len(set(passwords.values())) == len(ROLES), "Test passwords were not distinct")
    for role in ROLES:
        execute(container, port, f"create isolated {role} objects", "bench", "benchmark",
                sql=f"CREATE ROLE {role} LOGIN;\nCREATE DATABASE {role} OWNER {role};\n")
        password = passwords[role]
        execute(container, port, f"set {role} password", "bench", "benchmark", meta=f"\\password {role}",
                prompt=f"{password}\n{password}\n")
    world_role = "uwz_world_test"
    execute(container, port, "seed World in lifecycle database", world_role, world_role, sql=seed.decode("utf-8"))
    world = json.loads(execute(container, port, "verify lifecycle World", world_role, world_role, sql="""
SELECT json_build_object('user',current_user,'database',current_database(),
 'rows',(SELECT count(*) FROM public.world),
 'incorrect_rows',(SELECT count(*) FROM public.world WHERE id NOT BETWEEN 1 AND 10000 OR randomnumber != 1 + ((id * 7919) % 10000)),
 'owned_tables',(SELECT json_agg(relname ORDER BY relname) FROM pg_class WHERE oid IN ('public.world'::regclass,'public.example_jobs'::regclass)
                 AND pg_get_userbyid(relowner)=current_user));
"""))
    require(world == {"user": world_role, "database": world_role, "rows": 10000, "incorrect_rows": 0,
                      "owned_tables": ["example_jobs", "world"]}, "Lifecycle fixture World or table ownership differs")
    after = json.loads(execute(container, port, "final test fixture guard", "bench", "benchmark", sql=GUARD_SQL))
    check_guard(after, port, expected_postmaster)
    require(after["test_roles"] == after["test_databases"] == list(ROLES) and after["benchmark_world"] == before["benchmark_world"],
            "Test fixture inventory or benchmark World counters differ")
    private_file("unit.env", f"UWZ_SQL_TEST_PASSWORD={passwords['uwz_test']}\nUWZ_SQL_TEST_PORT={port}\n")
    private_file("world_integration.env", f"PGHOST=127.0.0.1\nPGPORT={port}\nPGUSER={world_role}\nPGDATABASE={world_role}\n"
                 f"PGPASSWORD={passwords[world_role]}\nUWZ_SQL_ALLOW_PLAINTEXT=1\n")
    require(all(stat.S_IMODE((PRIVATE / name).stat().st_mode) == 0o600 for name in PRIVATE_NAMES), "Test input permissions differ")
    receipt.write_text(json.dumps({"created_utc": datetime.now(timezone.utc).isoformat(), "container": container,
                                   "expected_labels": labels, "pg_port": port, "socket_directory": "/var/run/postgresql",
                                   "host": "127.0.0.1", "before": before, "after": after, "world_integration": world,
                                   "world_seed_sha256": SEED_SHA, "private_file_modes": dict.fromkeys(PRIVATE_NAMES, "0600"),
                                   "private_inputs_recorded": False}, indent=2) + "\n")
    print("Isolated SQL unit and World lifecycle fixtures ready")


if __name__ == "__main__":
    main()
