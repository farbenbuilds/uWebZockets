#!/usr/bin/env python3
"""Enforce SCRAM on the identified, drained host fixture's loopback listener."""
from datetime import datetime
import hashlib
import json
import os
from pathlib import PurePosixPath
import re
import secrets
import stat
import subprocess
import time

from setup_fixture import HBA_RULES_SQL, IMAGE, LABEL, PRIVATE, PUBLIC, check_hba_rules
from setup_fixture import owned_labels, prove_listener, psql, require


PREFIX = b"host all all 127.0.0.1/32 scram-sha-256\n"
LISTENER_KEYS = ("container", "pid", "cgroup", "network_mode", "port_bindings", "published_ports",
                 "pg_command", "pg_port", "inode")
GUARD_SQL = """
SELECT json_build_object(
  'user', current_user, 'database', current_database(),
  'postmaster', pg_postmaster_start_time(), 'loaded', pg_conf_load_time(),
  'data_directory', current_setting('data_directory'), 'hba_file', current_setting('hba_file'),
  'port', current_setting('port'), 'listen', current_setting('listen_addresses'),
  'tcp_clients', (SELECT count(*) FROM pg_stat_activity WHERE client_addr IS NOT NULL));
"""
PROBE_SQL = """
SELECT json_build_object(
 'user', current_user, 'database', current_database(), 'postmaster', pg_postmaster_start_time(),
 'client', host(inet_client_addr()), 'server', host(inet_server_addr()), 'port', inet_server_port());
"""
REPLACE_HBA = """
path=$1
old_sha=$2
[ "$(readlink -f -- "$path")" = "$path" ]
[ "$(sha256sum -- "$path" | cut -d ' ' -f 1)" = "$old_sha" ]
replacement=$(mktemp -- "${path}.uwz-scram.XXXXXX")
trap 'rm -f -- "$replacement"' EXIT
cat > "$replacement"
chmod --reference="$path" -- "$replacement"
mv -T -- "$replacement" "$path"
"""
AUTH_PSQL = """
IFS= read -r PGPASSWORD
export PGPASSWORD
exec psql "$@"
"""


def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def private_env(name):
    path = PRIVATE / name
    flags = path.lstat()
    require(stat.S_ISREG(flags.st_mode) and flags.st_uid == os.geteuid()
            and stat.S_IMODE(flags.st_mode) == 0o600, "Fixture env file is not owned and private")
    result = dict(line.split("=", 1) for line in path.read_text().splitlines())
    return result


def credentials(port):
    bench = private_env("app.env")
    unit = private_env("unit.env")
    world = private_env("world_integration.env")
    require(unit.get("UWZ_SQL_TEST_PORT") == str(port), "SQL unit endpoint differs")
    for env, role, database in ((bench, "bench", "benchmark"), (world, "uwz_world_test", "uwz_world_test")):
        require((env.get("PGHOST"), env.get("PGPORT"), env.get("PGUSER"), env.get("PGDATABASE"))
                == ("127.0.0.1", str(port), role, database), "The selected private fixture endpoint differs")
    passwords = (bench.get("PGPASSWORD"), unit.get("UWZ_SQL_TEST_PASSWORD"), world.get("PGPASSWORD"))
    require(all(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{48}", value) for value in passwords)
            and len(set(passwords)) == 3, "Fixture credentials do not match the generated format")
    return list(zip(("bench", "uwz_test", "uwz_world_test"), ("benchmark", "uwz_test", "uwz_world_test"), passwords))


def guard(container, port, identity):
    row = json.loads(psql(container, port, GUARD_SQL))
    require(row["tcp_clients"] == 0 and row["user"] == "bench" and row["database"] == "benchmark"
            and row["postmaster"] == identity["postmaster_started"] and row["port"] == identity["port"] == str(port)
            and identity["owner"] == "bench" and row["data_directory"] == identity["data_directory"]
            and row["hba_file"] == str(PurePosixPath(row["data_directory"]) / "pg_hba.conf")
            and row["listen"] == "127.0.0.1", "The owned PostgreSQL identity differs or TCP clients remain")
    return row


def probe(container, port, postmaster, role, database, password, expect_success, evidence):
    argv = ["docker", "exec", "-i", "--user", "postgres", container, "sh", "-ec", AUTH_PSQL, "sh",
            "-qXAt", "-w", "-h", "127.0.0.1", "-p", str(port), "-U", role, "-d", database,
            "-vON_ERROR_STOP=1", "-c", PROBE_SQL]
    result = subprocess.run(argv, input=password + "\n", text=True, capture_output=True, timeout=15)
    rejected = (result.returncode == 2 and not result.stdout and "password authentication failed" in result.stderr)
    valid = False
    peer = None
    if result.returncode == 0 and not result.stderr:
        peer = json.loads(result.stdout)
        valid = peer == {"user": role, "database": database, "postmaster": postmaster,
                         "client": "127.0.0.1", "server": "127.0.0.1", "port": port}
    outcome = "accepted" if valid else "password_rejected" if rejected else "other_failure"
    dump(evidence / f"{role}_{'correct' if expect_success else 'incorrect'}.json",
         {"argv": argv, "role": role, "database": database, "exit_code": result.returncode,
          "outcome": outcome, "connection": peer if valid else None, "private_inputs_recorded": False})
    require((expect_success and valid) or (not expect_success and rejected), "A fixture credential probe did not match its expected outcome")


def main():
    require(not PRIVATE.is_symlink() and PRIVATE.is_dir() and PRIVATE.stat().st_uid == os.geteuid()
            and stat.S_IMODE(PRIVATE.stat().st_mode) == 0o700, "Fixture private directory differs")
    fixture = json.loads((PUBLIC / "fixture.json").read_text())
    identity = json.loads((PUBLIC / "unit_runtime_identity.json").read_text())
    container, port, owner = fixture["container"], fixture["pg_socket_port"], fixture["owner_token"]
    labels = {"uwz.sql-experiment": LABEL, "uwz.role": "database", "uwz.run-token": owner}
    require(re.fullmatch(r"[0-9a-f]{64}", container) and re.fullmatch(r"[0-9a-f]{32}", owner)
            and fixture["label"] == LABEL and fixture["image"] == IMAGE and fixture["postgresql_network"] == "host_loopback"
            and port == fixture["pg_host_port"] == 59761 and port != fixture["http_port"]
            and identity["container"] == container and identity["labels"] == labels and identity["tmpfs"] == {"/var/lib/postgresql": ""}
            and (PRIVATE / "container.id").read_text().strip() == container and (PRIVATE / "owner_token").read_text().strip() == owner
            and (PRIVATE / "pg_port").read_text().strip() == str(port), "Host fixture ownership or assigned port differs")
    owned_labels(container, labels)
    expected = json.loads((PUBLIC / "listener.json").read_text())
    live = prove_listener(container, port, expected["pg_command"])
    require(all(live[key] == expected[key] for key in LISTENER_KEYS)
            and live["pid"] == identity["pid"] and live["cgroup"] == identity["cgroup"],
            "Owned PostgreSQL process or listener differs")
    users = credentials(port)
    before = guard(container, port, identity["postgresql"])
    data = before["data_directory"]
    path = before["hba_file"]
    require(data == "/var/lib/postgresql/18/docker", "Owned PostgreSQL data directory differs")
    exec_postgres = ["docker", "exec", "--user", "postgres", container]
    resolved = subprocess.check_output([*exec_postgres, "readlink", "-f", "--", data, path], text=True, timeout=10).splitlines()
    require(resolved == [data, path], "PostgreSQL HBA or data directory is not canonical")
    read_hba = [*exec_postgres, "cat", "--", path]
    original = subprocess.check_output(read_hba, timeout=10)
    require(all(password.encode() not in original for _, _, password in users), "Unexpected private material in HBA")
    old_rules = json.loads(psql(container, port, HBA_RULES_SQL))
    check_hba_rules(old_rules, "trust")
    require(all(rule["file_name"] == path for rule in old_rules), "Unexpected alternate HBA source")
    evidence = PUBLIC / "hba_repair"
    evidence.mkdir()
    (evidence / "before_hba.conf").write_bytes(original)
    dump(evidence / "before.json", {"container": container, "labels": labels, "pid": live["pid"], "identity": before,
                                   "canonical_paths": resolved, "ordered_rules": old_rules})
    require(guard(container, port, identity["postgresql"]) == before, "PostgreSQL changed before HBA modification")
    updated = PREFIX + original
    original_sha = hashlib.sha256(original).hexdigest()
    new_sha = hashlib.sha256(updated).hexdigest()
    replace = ["docker", "exec", "-i", "--user", "postgres", container, "sh", "-ec", REPLACE_HBA, "sh", path, original_sha]
    write_result = subprocess.run(replace, input=updated, capture_output=True, timeout=15)
    dump(evidence / "replace.json", {"argv": replace, "exit_code": write_result.returncode,
                                    "before_sha256": original_sha, "after_sha256": new_sha})
    require(write_result.returncode == 0, "Guarded HBA replacement failed")
    current = subprocess.check_output(read_hba, timeout=10)
    require(current == updated, "HBA replacement bytes differ")
    (evidence / "after_hba.conf").write_bytes(current)
    new_rules = json.loads(psql(container, port, HBA_RULES_SQL))
    dump(evidence / "after_rules.json", new_rules)
    check_hba_rules(new_rules, "scram-sha-256")
    require(all(rule["file_name"] == path for rule in new_rules), "Unexpected alternate HBA source")
    rel = psql(container, port, "SELECT pg_reload_conf();").strip()
    dump(evidence / "reload.json", {"command": "SELECT pg_reload_conf();", "result": rel, "before_conf_loaded": before["loaded"]})
    require(rel == "t", "PostgreSQL did not accept its reload signal")
    for _ in range(40):
        after = guard(container, port, identity["postgresql"])
        if datetime.fromisoformat(after["loaded"]) > datetime.fromisoformat(before["loaded"]):
            break
        time.sleep(.25)
    else:
        raise SystemExit("PostgreSQL configuration load time did not advance")
    require(after == {**before, "loaded": after["loaded"]}, "PostgreSQL changed during the HBA reload")
    dump(evidence / "reloaded.json", after)
    for role, database, password in users:
        incorrect = secrets.token_hex(24)
        require(incorrect not in {value for _, _, value in users}, "Fixture probe input collides with a generated password")
        probe(container, port, after["postmaster"], role, database, password, True, evidence)
        probe(container, port, after["postmaster"], role, database, incorrect, False, evidence)
    final = guard(container, port, identity["postgresql"])
    require(final == after and json.loads(psql(container, port, HBA_RULES_SQL)) == new_rules, "PostgreSQL changed during the credential checks")
    owned_labels(container, labels)
    final_listener = prove_listener(container, port, expected["pg_command"])
    require(all(final_listener[key] == expected[key] for key in LISTENER_KEYS), "Owned PostgreSQL listener changed")
    dump(evidence / "verified.json", {"container": container, "labels": labels, "pid": live["pid"],
                                    "before": before, "after": final, "hba_sha256": new_sha,
                                    "verified_roles": [role for role, _, _ in users], "successful_probes": 6,
                                    "private_inputs_recorded": False})
    print("Owned loopback fixture enforces SCRAM. All six credential checks passed and TCP clients drained.")


if __name__ == "__main__":
    main()
