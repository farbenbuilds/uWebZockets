const std = @import("std");
const example = @import("sql_postgres");
const sql = @import("test_support").sql;
const batch_capacity = sql.runtime_types.max_batch_statements;

/// Each result retains independent wire bytes while sharing iteration scratch.
const Chunk = struct {
    columns: [2]sql.types.Column = .{
        .{ .name = "id", .oid = 23, .format = .binary },
        .{ .name = "randomnumber", .oid = 23, .format = .binary },
    },
    fields: [2]sql.types.Field = undefined,
    data: [batch_capacity][46]u8 = undefined,
    params: [batch_capacity]sql.Param = undefined,
    results: [batch_capacity]sql.ResultSet = undefined,

    fn set(self: *Chunk, index: usize, id: i32, number: i32) void {
        const bytes = &self.data[index];
        bytes[0] = 'D';
        std.mem.writeInt(u32, bytes[1..5], 22, .big);
        std.mem.writeInt(u16, bytes[5..7], 2, .big);
        std.mem.writeInt(i32, bytes[7..11], 4, .big);
        std.mem.writeInt(i32, bytes[11..15], id, .big);
        std.mem.writeInt(i32, bytes[15..19], 4, .big);
        std.mem.writeInt(i32, bytes[19..23], number, .big);
        self.params[index] = .{ .value = .{ .int4 = id } };
        self.results[index] = .{
            .rows = .{ .data = bytes[0..23], .columns = &self.columns, .fields = &self.fields },
            .command_tag = "SELECT 1",
        };
    }
};

test "sql postgres: bounded query chunks preserve counts duplicates and scalar order" {
    const counts = [_]usize{ 1, 15, 16, 17, 20, 500 };
    for (counts) |count| {
        var chunk: Chunk = .{};
        var output: [500 * 48 + 2]u8 = undefined;
        output[0] = '[';
        var length: usize = 1;
        var completed: usize = 0;
        while (completed < count) {
            const take = @min(count - completed, batch_capacity);
            for (0..take) |index| {
                const ordinal = completed + index;
                chunk.set(index, @intCast(ordinal % 3 + 1), @intCast(ordinal + 1000));
            }
            length = try example.append_query_chunk(&output, length, chunk.params[0..take], chunk.results[0..take]);
            @memset(std.mem.asBytes(&chunk.data), 0xa5);
            completed += take;
        }
        output[length] = ']';
        length += 1;
        const parsed = try std.json.parseFromSlice(std.json.Value, std.testing.allocator, output[0..length], .{});
        defer parsed.deinit();
        const items = parsed.value.array.items;
        try std.testing.expectEqual(count, items.len);
        for (items, 0..) |item, index| {
            try std.testing.expectEqual(@as(usize, 2), item.object.count());
            try std.testing.expectEqual(@as(i64, @intCast(index % 3 + 1)), item.object.get("id").?.integer);
            try std.testing.expectEqual(@as(i64, @intCast(index + 1000)), item.object.get("randomNumber").?.integer);
        }
    }
}

test "sql postgres: query chunks reject missing extra and oversized result sets" {
    var chunk: Chunk = .{};
    chunk.set(0, 7, 19);
    chunk.set(1, 9, 21);
    var output: [256]u8 = undefined;
    output[0] = '[';
    try std.testing.expectError(error.InvalidResult, example.append_query_chunk(&output, 1, chunk.params[0..1], &.{}));
    try std.testing.expectError(error.InvalidResult, example.append_query_chunk(&output, 1, chunk.params[0..1], chunk.results[0..2]));
    try std.testing.expectError(error.InvalidResult, example.append_query_chunk(&output, 1, &.{}, &.{}));
    const too_many_params = [_]sql.Param{.{ .value = .{ .int4 = 1 } }} ** (batch_capacity + 1);
    var too_many_results: [batch_capacity + 1]sql.ResultSet = undefined;
    @memset(&too_many_results, chunk.results[0]);
    try std.testing.expectError(error.InvalidResult, example.append_query_chunk(&output, 1, &too_many_params, &too_many_results));
}

test "sql postgres: every bound query requires exactly one matching row" {
    var chunk: Chunk = .{};
    chunk.set(0, 7, 19);
    chunk.set(1, 9, 21);
    var output: [256]u8 = undefined;
    output[0] = '[';
    chunk.results[1].rows.data = &.{};
    try std.testing.expectError(error.InvalidResult, example.append_query_chunk(&output, 1, chunk.params[0..2], chunk.results[0..2]));
    chunk.set(1, 9, 21);
    @memcpy(chunk.data[1][23..46], chunk.data[1][0..23]);
    chunk.results[1].rows.data = &chunk.data[1];
    try std.testing.expectError(error.InvalidResult, example.append_query_chunk(&output, 1, chunk.params[0..2], chunk.results[0..2]));
    chunk.set(1, 9, 21);
    chunk.params[1].value = .{ .int4 = 8 };
    try std.testing.expectError(error.InvalidResult, example.append_query_chunk(&output, 1, chunk.params[0..2], chunk.results[0..2]));
}

test "sql postgres: query chunk values retain exact SQL scalar types and widths" {
    var chunk: Chunk = .{};
    chunk.set(0, 7, 19);
    var output: [256]u8 = undefined;
    output[0] = '[';
    chunk.columns[1].oid = 25;
    try std.testing.expectError(error.TypeMismatch, example.append_query_chunk(&output, 1, chunk.params[0..1], chunk.results[0..1]));
    chunk.columns[1].oid = 23;
    std.mem.writeInt(i32, chunk.data[0][15..19], -1, .big);
    std.mem.writeInt(u32, chunk.data[0][1..5], 18, .big);
    chunk.results[0].rows.data = chunk.data[0][0..19];
    try std.testing.expectError(error.NullValue, example.append_query_chunk(&output, 1, chunk.params[0..1], chunk.results[0..1]));
    chunk.set(0, 7, 19);
    std.mem.writeInt(i32, chunk.data[0][15..19], 3, .big);
    std.mem.writeInt(u32, chunk.data[0][1..5], 21, .big);
    chunk.results[0].rows.data = chunk.data[0][0..22];
    try std.testing.expectError(error.InvalidValue, example.append_query_chunk(&output, 1, chunk.params[0..1], chunk.results[0..1]));
    chunk.set(0, 7, 19);
    chunk.params[0].value = .{ .bool = true };
    try std.testing.expectError(error.TypeMismatch, example.append_query_chunk(&output, 1, chunk.params[0..1], chunk.results[0..1]));
}

test "sql postgres: query chunks reject malformed wire data and reserve array closure" {
    var chunk: Chunk = .{};
    chunk.set(0, 7, 19);
    var output: [256]u8 = undefined;
    output[0] = '[';
    chunk.results[0].rows.data = chunk.data[0][0..22];
    try std.testing.expectError(error.TruncatedMessage, example.append_query_chunk(&output, 1, chunk.params[0..1], chunk.results[0..1]));
    chunk.set(0, 7, 19);
    var short = [_]u8{'['};
    try std.testing.expectError(error.BufferTooSmall, example.append_query_chunk(&short, 1, chunk.params[0..1], chunk.results[0..1]));
    const expected = "[{\"id\":7,\"randomNumber\":19}]";
    var exact: [expected.len]u8 = undefined;
    exact[0] = '[';
    const length = try example.append_query_chunk(&exact, 1, chunk.params[0..1], chunk.results[0..1]);
    try std.testing.expectEqual(exact.len - 1, length);
    exact[length] = ']';
    try std.testing.expectEqualStrings(expected, &exact);
    try std.testing.expectError(error.BufferTooSmall, example.append_query_chunk(exact[0 .. exact.len - 1], 1, chunk.params[0..1], chunk.results[0..1]));
}
