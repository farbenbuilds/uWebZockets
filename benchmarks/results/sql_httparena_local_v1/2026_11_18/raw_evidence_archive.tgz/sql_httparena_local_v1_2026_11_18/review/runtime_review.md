# Independent measurement review

The reviewer reported no actionable findings after source and retained-raw-evidence review. No benchmark rerun or deferred campaign was performed by the reviewer.

The raw artifact audit recomputed all six RPS and p99 values from Lua output and cross-checked stock wrk counters. It checked 100 exact fixed HTTP 200 bodies against the PostgreSQL export, including field types, content lengths, duplicate JSON keys and unique item IDs per response. Each fixed cohort has exactly 50 completions, renders and sequential scans. All timed windows include warmup and remain within their connection cutoff bounds; every render count equals the PostgreSQL scan delta. All eight application containers exited zero and were removed, leaving an empty application inventory.

The reviewer checked role-specific cgroup deltas and timestamps, source/input hashes and the executed binary identity. The standard median is 48963.10739266891 RPS and median HTTP p99 is 38284 microseconds. The diagnostic median is 14225.631914786394 RPS. The 300000 RPS gate remains unmet.

Stock wrk status errors cover HTTP 400 and above. Exact HTTP 200 and full typed values are established by the fixed cohorts. SQL execution timing under load and official/quiet-host acceptance remain unverified.
