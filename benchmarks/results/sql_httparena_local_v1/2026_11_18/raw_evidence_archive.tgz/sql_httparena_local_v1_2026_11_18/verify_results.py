#!/usr/bin/env python3
"""Verify the extracted local evidence using only Python's standard library."""
import hashlib
import json
from pathlib import Path
import re
import stat
import statistics


LIMITS = (5, 10, 20, 35, 50)
COHORTS = ((1, 32, 1), (32, 1024, 8))
ERROR_FIELDS = ('status', 'connect', 'read', 'write', 'timeout')
LATENCY_FIELDS = ('p50_us', 'p90_us', 'p95_us', 'p99_us')
COUNTERS = re.compile(r'benchmark database rendered_queries=(\d+) empty_fallbacks=(\d+) rejected_responses=(\d+)')
SERVER = 'install/bin/sql_httparena'
WRK = 'tooling/root/usr/bin/wrk'
DEB = 'tooling/wrk_4.1.0-4build3_amd64.deb'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def unique_keys(pairs):
    obj = dict(pairs)
    require(len(obj) == len(pairs), 'Duplicate JSON object key')
    return obj


def parse_json(data):
    return json.loads(data, object_pairs_hook=unique_keys)


def load(path):
    return parse_json(path.read_text())


def sha256(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def check_file_set(root, entries, manifest=None):
    files = {}
    for entry in entries:
        path = Path(entry['path'])
        require(not path.is_absolute() and '..' not in path.parts and path not in files,
                f'Invalid or duplicate manifest path {path}')
        member = root / path
        require(member.is_file() and not member.is_symlink(), f'Missing regular file {path}')
        require(stat.S_IMODE(member.stat().st_mode) == entry['mode'], f'Mode differs for {path}')
        require(sha256(member) == entry['sha256'], f'Contents differ for {path}')
        files[path] = entry
    observed = {path.relative_to(root) for path in root.rglob('*') if not path.is_dir() or path.is_symlink()}
    if manifest is not None:
        observed.remove(Path(manifest))
    require(observed == set(files), f'Manifest file inventory differs under {root.name}')
    return files


def verify_source(root):
    packaged = load(root / 'packaged_source_identity.json')
    original = load(root / 'source_identity.json')
    build = load(root / 'build/result.json')
    files = check_file_set(root / 'source', packaged['files'])
    paths = packaged['paths']
    zon = (root / 'source/build.zig.zon').read_text().split('.paths = .{', 1)[1].split('},', 1)[0]
    require(paths == re.findall(r'^ +"([^"\n]+)",$', zon, re.M), 'Zig package paths differ')
    require(all(any(posix == str(path) or posix in [str(parent) for parent in path.parents]
                    for path in files) for posix in paths), 'A declared source path is missing')
    for path, entry in files.items():
        require(any(Path(posix) == path or Path(posix) in path.parents for posix in paths),
                f'Source outside declared package paths: {path}')
        data = (root / 'source' / path).read_bytes()
        oid = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
        git_mode = '100755' if entry['mode'] & stat.S_IXUSR else '100644'
        require(entry['git_blob'] == oid and entry['git_mode'] == git_mode, f'Git identity differs for {path}')
    require(len(files) == 346 and len(original['files']) == 288, 'Unexpected source identity scope')
    for entry in original['files']:
        packaged_entry = files[Path(entry['path'])]
        require(all(entry[key] == packaged_entry[key] for key in ('sha256', 'mode')),
                f'Build input identity differs for {entry["path"]}')
    require(packaged['commit'] == original['commit'] == build['source_commit'], 'Source commit identities differ')
    require(build['exit_code'] == 0 and sha256(root / SERVER) == build['binary_sha256'] and
            (root / SERVER).stat().st_size == build['binary_bytes'], 'Built server identity differs')
    return len(files)


def verify_inputs(root, run):
    for entry in load(root / 'archived_inputs.json')['files']:
        member = root / 'archived_fixture' / Path(entry['member']).name
        require(sha256(member) == entry['sha256'] and stat.S_IMODE(member.stat().st_mode) == entry['mode'],
                f'Original fixture identity differs for {member.name}')
    tooling = load(root / 'tooling/identity.json')
    require(sha256(root / WRK) == tooling['wrk_sha256'] and sha256(root / DEB) == tooling['package_sha256'],
            'wrk package or ELF identity differs')
    metadata = load(run / 'metadata.json')
    paths = (SERVER, WRK, 'fixture.json', 'fixture/expected_items.jsonl', 'runner/measure.py', 'runner/async_db.lua')
    expected_hashes = {path: sha256(root / path) for path in paths}
    actual_hashes = {}
    for original, digest in metadata['sha256'].items():
        matches = [path for path in paths if original.endswith('/' + path)]
        require(len(matches) == 1 and matches[0] not in actual_hashes, 'Unexpected metadata hash path')
        actual_hashes[matches[0]] = digest
    require(expected_hashes == actual_hashes, 'Runner input identities differ')
    fixture = load(root / 'fixture.json')
    require(metadata['parameters'] == {'min': 10, 'max': 50, 'rotating_limits': list(LIMITS), 'pipeline_depth': 1},
            'Unexpected workload shape')
    require(metadata['db_image'] == fixture['image'] == (root / 'archived_fixture/image.txt').read_text().strip() and
            metadata['db_seed_sha256'] == fixture['seed_sha256'] == sha256(root / 'archived_fixture/pgdb-seed.sql') and
            metadata['db_seed_rows'] == fixture['seed_rows'] == 100000, 'PostgreSQL fixture identity differs')
    cleanup = load(root / 'cleanup.json')
    require(cleanup['container_removed_or_absent'] is True and cleanup['matched_database_containers'] == 1 and
            cleanup['private_inputs_removed'] is True and cleanup['label'] == fixture['label'] and
            cleanup['ownership_token_sha256'] == hashlib.sha256(fixture['owner_token'].encode()).hexdigest(),
            'PostgreSQL cleanup evidence differs')
    return metadata


def fixed_rows(path, count):
    rows = {}
    for line in path.read_text().splitlines():
        item = parse_json(line)
        item_id = item['id']
        require(type(item_id) is int and item_id not in rows and 10 <= item['price'] <= 50,
                'Fixture item has duplicate ID, invalid ID type, or price outside the workload')
        rows[item_id] = item
    require(len(rows) == count == 8237, 'Unexpected comparison fixture size')
    return rows


def canonical(value):
    return json.dumps(value, sort_keys=True, allow_nan=False)


def verify_response(response, rows, limit, port):
    request = response['request']
    require(request == {'method': 'GET', 'version': 'HTTP/1.1', 'path': f'/async-db?min=10&max=50&limit={limit}',
                        'limit': limit, 'headers': {'Host': f'127.0.0.1:{port}', 'Accept-Encoding': 'identity',
                                                    'Connection': 'close'}}, 'Fixed request differs')
    require(response['status'] == 200 and response['version'] == 11, 'Fixed response must be HTTP/1.1 200')
    headers = unique_keys([(key.lower(), value) for key, value in response['headers']])
    body = response['body_utf8']
    require(headers.get('content-type') == 'application/json' and
            int(headers['content-length']) == len(body.encode()), 'Response content type or byte size differs')
    payload = parse_json(body)
    require(payload.keys() == {'items', 'count'} and type(payload['count']) is int and payload['count'] == limit,
            'Invalid response shape or count')
    items = payload['items']
    require(type(items) is list and len(items) == limit, 'Unexpected item count')
    ids = set()
    for item in items:
        item_id = item['id']
        require(type(item_id) is int and item_id not in ids and item_id in rows,
                f'Duplicate, invalid or unknown response ID {item_id}')
        require(canonical(item) == canonical(rows[item_id]), f'Typed PostgreSQL field mismatch for response ID {item_id}')
        ids.add(item_id)


def verify_fixed(case, rows, port):
    responses = load(case / 'fixed_responses.json')
    planned = LIMITS * 10
    require(len(responses) == len(planned), f'Unexpected number of fixed responses in {case.name}')
    for response, limit in zip(responses, planned, strict=True):
        verify_response(response, rows, limit, port)
    size = len(responses)
    return {'issued': size, 'completed': size, 'validated': size, 'errors': []}


def command_ok(case, label):
    command = load(case / f'{label}.command.json')
    require(command['exit_code'] == 0, f'{case.name}/{label} failed')
    return command['argv']


def verify_cpu_delta(case, phase):
    before = load(case / f'{phase}_before.resources.json')
    after = load(case / f'{phase}_after.resources.json')
    stats = {}
    for role in ('application', 'postgres'):
        first = dict(line.split() for line in before[role]['cpu.stat'].splitlines())
        last = dict(line.split() for line in after[role]['cpu.stat'].splitlines())
        stats[role] = {key: int(last[key]) - int(first[key]) for key in ('usage_usec', 'user_usec', 'system_usec')}
        require(all(delta >= 0 for delta in stats[role].values()), f'Regressed CPU counters in {case.name}/{phase}')
    return stats


def numeric_fields(line):
    return unique_keys([(key, int(value)) for key, value in re.findall(r'(\w+)=(\d+)', line)])


def verify_wrk(case, phase, seconds, connections, threads, port):
    argv = command_ok(case, phase)
    options = ['-t', str(threads), '-c', str(connections), '-d', f'{seconds}s', '--timeout', '2s', '--latency', '-s']
    require(argv[4].endswith('/' + WRK) and argv[5:-2] == options and argv[-2].endswith('/runner/async_db.lua') and
            argv[-1] == f'http://127.0.0.1:{port}', f'Unexpected wrk command in {case.name}/{phase}')
    output = (case / f'{phase}.stdout').read_text()
    line, = re.findall(r'^UWZ_WRK (.+)$', output, re.M)
    metrics = numeric_fields(line)
    require(metrics.keys() == {'completed', 'duration_us', *ERROR_FIELDS, *LATENCY_FIELDS}, 'Missing wrk counters')
    require(metrics['completed'] > 0 and metrics['duration_us'] >= seconds * 1_000_000 and
            all(metrics[key] == 0 for key in ERROR_FIELDS), f'Bad raw wrk metrics in {case.name}/{phase}')
    latencies = [metrics[key] for key in LATENCY_FIELDS]
    require(latencies == sorted(latencies) and latencies[0] > 0, 'Invalid raw wrk percentiles')
    completed, = re.findall(r'^\s+(\d+) requests in ', output, re.M)
    require(int(completed) == metrics['completed'], 'wrk printed request count disagrees with Lua summary')
    require((case / f'{phase}.stderr').stat().st_size == 0 and
            re.search(r'^\s*Exit status: 0$', (case / f'{phase}.client_time.txt').read_text(), re.M),
            f'Unexpected stderr or exit status in {case.name}/{phase}')
    generated = [numeric_fields(line) for line in re.findall(r'^UWZ_WRK_GENERATED (.+)$', output, re.M)]
    require([entry['thread'] for entry in generated] == list(range(1, threads + 1)), 'Unexpected wrk thread count')
    for entry in generated:
        cycles, extra = divmod(entry['calls'], len(LIMITS))
        expected = {f'limit_{limit}': cycles + int(index < extra) for index, limit in enumerate(LIMITS)}
        require(entry == expected | {'thread': entry['thread'], 'calls': entry['calls']}, 'Unexpected wrk request rotation')
    return metrics | {'rps': metrics['completed'] * 1e6 / metrics['duration_us'], 'exit_code': 0,
                      'client_generated_per_thread': generated, 'cpu_delta': verify_cpu_delta(case, phase)}


def pg_samples(case, label):
    logs = sorted(case.glob(f'{label}_[0-9][0-9].stdout'))
    for sample in logs:
        command_ok(case, sample.stem)
    return [load(sample) for sample in logs]


def verify_case_lifecycle(case, workers):
    start = command_ok(case, 'app_run')
    container = (case / 'app_run.stdout').read_text().strip()
    require(re.fullmatch(r'[0-9a-f]{64}', container) is not None and '--pull=never' in start and
            ('UWZ_SQL_WORKERS=1' in start) == (workers == 1), f'Unexpected startup in {case.name}')
    for action in ('app_verify_ownership', 'app_stop', 'app_logs', 'app_final_state', 'app_remove'):
        require(command_ok(case, action)[-1] == container, f'{action} used a different container ID')
    labels = load(case / 'app_verify_ownership.stdout')
    require(labels == load(case / 'app_ownership.json')['labels'] and
            (case / 'app_remove.stdout').read_text().strip() == container, f'Unexpected container removal in {case.name}')
    state = load(case / 'app_final_state.stdout')
    require(state['Status'] == 'exited' and state['ExitCode'] == 0 and state['OOMKilled'] is False,
            f'Application shutdown failed in {case.name}')
    command_ok(case, 'application_limits_and_fds')
    rings = (case / 'application_limits_and_fds.stdout').read_text().count('anon_inode:[io_uring]')
    require(rings == workers, f'Unexpected io_uring descriptor count in {case.name}')
    return state, rings


def verify_case(case, workers, connections, threads, rows, port):
    state, rings = verify_case_lifecycle(case, workers)
    before, after = (pg_samples(case, label) for label in ('pg_before', 'pg_after'))
    for samples in (before, after):
        require(len(samples) >= 2 and samples[-1] == samples[-2] and samples[-1]['tcp_clients'] == 0,
                f'PostgreSQL statistics did not settle in {case.name}')
    begin, end = before[-1], after[-1]
    ready = pg_samples(case, 'ready_sql')[-1]
    require(ready['tcp_clients'] == 8 * workers and ready['ssl_clients'] == begin['ssl_clients'] == end['ssl_clients'] == 0
            and ready['reset_at'] == begin['reset_at'] == end['reset_at'], f'Unexpected PostgreSQL sessions in {case.name}')
    app = (case / 'app_logs.stdout').read_text() + (case / 'app_logs.stderr').read_text()
    workers_counters = [list(map(int, counts)) for counts in COUNTERS.findall(app)]
    require(len(workers_counters) == workers, f'Unexpected worker count in {case.name}')
    rendered, fallbacks, rejected = map(sum, zip(*workers_counters, strict=True))
    scans = end['seq_scan'] - begin['seq_scan']
    idx_scans = end['idx_scan'] - begin['idx_scan']
    tuples = end['seq_tup_read'] - begin['seq_tup_read']
    require(scans == rendered and idx_scans == fallbacks == rejected == 0 and tuples >= scans,
            f'DB and application counters disagree in {case.name}')
    if case.name.endswith('_fixed'):
        phases = {'fixed': verify_fixed(case, rows, port)}
        completed = phases['fixed']['completed']
        bound = 0
    else:
        phases = {'warmup': verify_wrk(case, 'warmup', 5, connections, threads, port),
                  'timed': verify_wrk(case, 'timed', 10, connections, threads, port)}
        completed = sum(phase['completed'] for phase in phases.values())
        bound = 2 * connections
        phases['deadline_allowance'] = bound
    require(completed <= rendered <= completed + bound, f'Exceeded client cutoff bound in {case.name}')
    return phases | {'workers': workers, 'connections': connections, 'threads': threads, 'pg_before': begin,
                     'ready': ready, 'io_uring_fds': rings, 'app_counters': workers_counters, 'app_state': state,
                     'pg_after': end, 'rendered_queries': rendered, 'empty_fallbacks': fallbacks,
                     'rejected_responses': rejected, 'seq_scan_delta': scans, 'idx_scan_delta': idx_scans,
                     'seq_tup_read_delta': tuples, 'valid': True, 'completed': completed,
                     'rendered_minus_completed': rendered - completed, 'scan_minus_rendered': scans - rendered}


def verify_cohort(run, workers, connections, threads, rows, port):
    prefix = f'workers_{workers}'
    names = [f'{prefix}_fixed', *(f'{prefix}_sample_{number}' for number in range(1, 4))]
    require({path.name for path in run.glob(prefix + '_*') if path.is_dir()} == set(names), 'Unexpected case inventory')
    cases = []
    for name in names:
        case = run / name
        derived = verify_case(case, workers, connections, threads, rows, port)
        require(derived == load(case / 'summary.json'), f'Per-case summary does not match raw data for {name}')
        cases.append(derived)
    fixed, *samples = cases
    metrics = {key: statistics.median(sample['timed'][key] for sample in samples) for key in ('rps', *LATENCY_FIELDS)}
    return {'workers': workers, 'connections': connections, 'threads': threads, 'fixed': fixed, 'samples': samples,
            'sample_medians': metrics, 'valid': True, 'threshold_rps': 300000,
            'throughput_gate_met': workers == 32 and metrics['rps'] > 300000}


def main():
    root = Path(__file__).resolve().parent
    manifest = 'payload_manifest.json'
    artifacts = check_file_set(root, load(root / manifest)['files'], manifest)
    source_files = verify_source(root)
    run = root / 'measurements/run_01'
    metadata = verify_inputs(root, run)
    require((run / 'application_final_inventory.txt').stat().st_size == 0, 'Application containers remain in inventory')
    rows = fixed_rows(root / 'fixture/expected_items.jsonl', metadata['fixture_rows_exported'])
    cohorts = [verify_cohort(run, *cohort, rows, metadata['http_port']) for cohort in COHORTS]
    require(cohorts == load(run / 'summary.json'), 'Aggregate producer report does not match raw data')
    for cohort in cohorts:
        med = cohort['sample_medians']
        print(f"{cohort['workers']} worker(s), {cohort['connections']} connections, three timed samples: "
              f"{med['rps']:.3f} RPS, p50/p90/p95/p99 = " + '/'.join(f'{med[key] / 1000:.3f}' for key in LATENCY_FIELDS) + ' ms')
    print(f'Verified {len(artifacts)} payload files including {source_files} source files, eight cases and 100 fixed responses.')
    print('300,000 RPS gate:', 'met' if cohorts[-1]['throughput_gate_met'] else 'unmet')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, IndexError, TypeError) as error:
        raise SystemExit(f'Verification failed: {error}') from error
