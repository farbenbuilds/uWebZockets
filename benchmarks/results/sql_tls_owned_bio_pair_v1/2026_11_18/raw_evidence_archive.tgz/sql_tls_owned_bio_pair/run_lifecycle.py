#!/usr/bin/env python3
"""Run the unchanged lifecycle probe without recording fixture credentials."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
for name in ('fixture', 'binary', 'output'):
    parser.add_argument('--' + name, type=Path, required=True)
args = parser.parse_args()

def require(condition, message):
    if not condition:
        raise SystemExit(message)

out = args.output.resolve()
for ancestor in (out, *out.parents):
    require(not (ancestor / 'files.sha256').exists(), 'output must be outside an evidence artifact')
out.mkdir(parents=True, exist_ok=False)
fixture = args.fixture.resolve()
private = fixture / 'private_fixture'
values = dict(line.split('=', 1) for line in (private / 'postgres.env').read_text().splitlines())
env = dict(os.environ)
env.update(PGHOST='127.0.0.1',
           PGPORT=str(json.loads((fixture / 'fixture.json').read_text())['port']),
           PGUSER='uwz_test', PGDATABASE='uwz_test',
           PGPASSWORD=values['POSTGRES_PASSWORD'],
           PGSSLROOTCERT=str(private / 'ca.pem'), PGSSLSERVERNAME='localhost',
           UWZ_SQL_LIFECYCLE_OUTPUT=str(out / 'lifecycle.json'))
binary = args.binary.resolve()
start = time.monotonic()
with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
    result = subprocess.run([str(binary)], env=env, stdout=stdout, stderr=stderr, timeout=45)
elapsed = time.monotonic() - start
report = json.loads((out / 'lifecycle.json').read_text())
require(result.returncode == 1, 'expected unchanged strict allocation RED exit')
require('error: NonZeroLifecycleAllocations' in (out / 'stderr.log').read_text(), 'unexpected strict failure')
require(report['expected_rounds'] == report['completed_rounds'] == 6, 'incomplete lifecycle rounds')
require(report['functional_failure'] is None and report['strict_zero'] is False, 'functional failure or unexpected zero result')
require(report['interval'] == 'worker first Db.query submission through final callback entry; includes overlapping close/reconnect/cancel', 'allocation interval changed')
rounds = report['rounds']
require(len(rounds) == 6, 'round count mismatch')
require([row['scenario'] for row in rounds] == ['failure_reconnect'] * 3 + ['deadline_cancel'] * 3, 'scenario matrix changed')
vectors = []
for row in rounds:
    require(row['scope_complete'] and row['initial_waiting'], 'incomplete scope or missing waiter')
    require(row['target_prepared_before'] and row['reconnect_prepared'], 'TLS preparation was not retained')
    require(row['queued_assignment_while_long_running'], 'concurrent query/waiter behavior changed')
    require(len(row['callbacks']) == 3 and all(value['observed'] for value in row['callbacks']), 'callback matrix incomplete')
    counts = {key: row['allocations'][key] for key in ('mallocs', 'callocs', 'reallocs', 'frees', 'bytes')}
    require(all(type(value) is int and value >= 0 for value in counts.values()), 'invalid counter vector')
    vectors.append({'scenario': row['scenario'], **counts})
(out / 'run_status.json').write_text(json.dumps({
    'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
    'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'exit_code': result.returncode, 'expected_exit_code': 1, 'elapsed_s': elapsed,
    'completed_rounds': 6, 'functional_failure': None, 'strict_zero': False,
    'vectors': vectors, 'private_credentials_recorded': False,
}, indent=2) + '\n')
print(json.dumps({'completed_rounds': 6, 'functional_failure': None,
                  'strict_zero': False, 'vectors': vectors}))
