# Owned BIO-pair implementation decision

Root accepts the complete four-file native factory/query contract in contract.md
after independent review e8a540dc20e104659ee63e4b46a50e678b4d74b4844c6332c58876399d3d143b.
The existing v2.3.0 plan and user continuation authorize this implementation.
Verification captures parent compile/ordinary-allocation RED before native edits.
Native, prepared-SDK runtime and proof ownership are disjoint; Root owns shared
builder path binding, fixtures, combined evidence and integration. No parent,
protected vendor, production pin, new remote, gate or measurement interval changes.
No total TLS ownership/capacity or release-completion claim is approved.
