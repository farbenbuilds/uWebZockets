#!/usr/bin/env python3
"""Run an ordinary prepared-SDK check with private fixture environment inputs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--mode', choices=('units', 'safe', 'fast'), required=True)
parser.add_argument('--expected-tests', type=int)
for name in ('fixture', 'sdk', 'zig', 'cache', 'global-cache', 'output'):
    parser.add_argument('--' + name, type=Path, required=True)
args = parser.parse_args()

def require(condition, message):
    if not condition:
        raise SystemExit(message)

require(args.mode != 'units' or (args.expected_tests is not None and args.expected_tests > 0),
        'live units require the exact expected test count')
out = args.output.resolve()
for ancestor in (out, *out.parents):
    require(not (ancestor / 'files.sha256').exists(), 'output must be outside an evidence artifact')
out.mkdir(parents=True, exist_ok=False)
fixture = args.fixture.resolve()
private = fixture / 'private_fixture'
env = dict(os.environ)
if args.mode == 'units':
    values = dict(line.split('=', 1) for line in (private / 'postgres.env').read_text().splitlines())
    env.update(UWZ_SQL_TEST_PASSWORD=values['POSTGRES_PASSWORD'],
               UWZ_SQL_TEST_PORT=str(json.loads((fixture / 'fixture.json').read_text())['port']),
               UWZ_SQL_TEST_CA_PATH=str(private / 'ca.pem'),
               UWZ_SQL_TEST_UNTRUSTED_CA_PATH=str(private / 'untrusted.pem'))
    env.update(json.loads((private / 'unicode_passwords.json').read_text()))
step = {'units': 'test-unit', 'safe': 'test-compile', 'fast': 'lib'}[args.mode]
command = [str(args.zig.resolve()), 'build', step, '-Dsql=true', '-Dsqlite=true', '-j4',
           '--cache-dir', str(args.cache.resolve()),
           '--global-cache-dir', str(args.global_cache.resolve()), '--summary', 'all']
if args.mode != 'units':
    command.append('-Doptimize=' + ('ReleaseSafe' if args.mode == 'safe' else 'ReleaseFast'))
start = time.monotonic()
with (out / 'build.log').open('wb') as stream:
    result = subprocess.run(command, cwd=args.sdk.resolve(), env=env,
                            stdout=stream, stderr=subprocess.STDOUT)
record = {'command': command, 'exit_code': result.returncode,
          'elapsed_s': time.monotonic() - start, 'mode': args.mode,
          'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'expected_tests': args.expected_tests,
          'private_credentials_recorded': False}
if args.mode == 'units' and result.returncode == 0:
    summaries = [line for line in (out / 'build.log').read_text().splitlines()
                 if line.startswith('Build Summary:')]
    summary = summaries[-1] if summaries else ''
    record['summary'] = summary
    match = re.search(r'(\d+)/(\d+) tests passed', summary)
    record['live_coverage_complete'] = bool(match and int(match.group(1)) == int(match.group(2)) == args.expected_tests
                                            and 'skipped' not in summary)
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
require(result.returncode == 0, 'SDK check failed; inspect retained raw log')
require(args.mode != 'units' or record['live_coverage_complete'], 'live unit coverage incomplete')
print(json.dumps(record))
