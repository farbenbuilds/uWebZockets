# Owned BIO-pair native functional/evidence review

No actionable findings in the native proof or its stated coverage claims.
This verdict covers native functional evidence only. It does not approve the
SQL adapter, prepared SDK, integrated lifecycle evidence or full v2.3.0 goal.

Reviewed final proof identity SHA256:
`e303050e1d36c54613c13b683f7e6ef88658f8221128eb7f1c5da977ddf1fa62`.
Reviewed handoff SHA256:
`83997c18802be33430b3c108995347a189de0be1142cf49684ea4f9f0b260163`.
The native source verdict remains in `native_source_review.md`.

Independent checks and replay:

- All 30 checked identities matched: 11 proof/build sources, ten executed ELF
  files, three compiled-library provenance hashes, the pinned compiler,
  original counter in both candidate and parent, native builder, final build
  log, and preserved parent ordinary-control executable. Recorded in
  `native_functional_identity_check.json`.
- Replayed all ten final installed ELFs; each exited 0. The BIO proof reproduced
  nine rows with all five counter fields zero and the explicit whole-SSL row
  with malloc59/calloc0/realloc0/free58/requested14802. The inherited proof
  retained 14 passing rows, including 13 measured zero-C-heap rows.
- Replayed the preserved parent ordinary pair: exit 0 for the functional control
  and exit 1 for `--strict`, both with malloc6/calloc0/realloc0/free6/65856 bytes
  and the unchanged 63-byte positive counter self-test. This is a real allocating
  control, not a behavioral RED attributed to a missing interface.
- Independently repeated the public C probe against the immutable parent. It
  exited 1 for the absent public type, requirements query and factory. The
  probe hash matches the recorded pre-implementation compile RED.
- Byte-compared allocation_scope.c, domain_proof.cc, public_api_proof.c and
  sdallocx_proof.cc with the immutable parent; all remain unchanged. The counter
  SHA256 is afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac.
- Inspected the recorded final build command/log: ReleaseSafe, 38/38 steps,
  normal complete native builders, separate complete sized-free crypto image,
  original counter with -fno-builtin, and no object overlay or system crypto.
  I replayed the executables rather than rebuilding the complete libraries.

Replay records: `native_functional_replay.json` and
`parent_api_red_replay.json` beside this report.

The coverage assertions match the contract:

- `proof/bio_pair_proof.cc:25` uses explicit return-on-failure checks, independent
  of NDEBUG. `run_case` at line 386 ends the measured interval before printing
  and checks malloc, calloc, realloc, free and requested bytes together.
- Lines 125 and 137 test cold requirements, default normalization, failed output
  zeroing, preserved ERR sentinel and payload/alignment/sum overflow. Source
  purity from the separate source review supplies the no-hook/no-thread/once
  conclusion; the cold measured row establishes C-heap zero only.
- Line 160 checks six owned allocations, exact rounded raw request sum versus
  query bytes, high-water within the bound and asymmetric/default/32 KiB
  capacities. Native sizes are explicitly Linux64 proof expectations.
- Line 186 exercises wrap, partial/full/empty behavior, retry flags, pending,
  read requests/reset, write guarantees, bidirectional data, flush, half-close,
  drain-to-EOF and broken-pipe refusal.
- Line 226 injects each of six allocation failure indices, checks null outputs,
  all releases and cursor reset, then constructs/frees successfully using the
  same storage. Line 247 rejects bad outputs, descriptors and overflow before
  any domain callback.
- Lines 51, 85, 105 and 277 verify callback pointer/extent/alignment ownership,
  full raw cleansing, checked adapter setup before bad backing reaches C++,
  overlap rejection and preservation of an existing live pair. This is the
  native test adapter; it does not substitute for the separate SQL adapter.
- Lines 301 and 326 interleave two domains for 128 cycles each and exercise
  extra references and both final-release orders without early storage reset.
- Line 347 transfers one endpoint to both SSL roles and tests external extra
  references and both release orders with complete SSL teardown. The row is
  deliberately required to allocate. Its 59/58 asymmetry is disclosed rather
  than represented as a zero-allocation or fully diagnosed SSL lifetime.
- `proof/hook_proof.cc:119` and `proof/partial_hook_proof.cc:48` exercise the
  new query/factory in full and all three partial weak-hook configurations.
  Valid/overflow queries preserve the single sentinel and exact queue depth;
  all five C-counter fields remain zero. Factory rejection checks null outputs,
  zero domain/hook calls and zero C-counter fields. Ordinary full-hook pair
  byte transfer retains its exact six-allocation/release behavior.

Verification gaps and boundaries:

- Native execution is Linux x86-64/glibc. Cross-target execution and numerical
  capacity proofs for other ABIs remain unclaimed.
- No independent pthread/once interposer was installed. The no-thread/once
  requirement is supported by effect-free source inspection, not an expanded
  dynamic instrumentation claim.
- Runtime startup slabs, production adapter backing/OOM behavior, SDK build
  gates and live PostgreSQL lifecycle comparisons remain outside this pass.
  No combined or runtime verdict is given here.
- Full SSL ownership, ERR/thread lifetimes and PostgreSQL total allocation
  compliance remain open; the native BIO component proof does not close them.
- No dedicated smoke, security, sanitizer or fuzz campaign was run, consistent
  with the user deferral. Configured gates were not changed.
- Cross-model review was skipped in this non-interactive reviewer context.

Only scratch review records were written. No source, test, gate, protected
vendor, parent, tracked result archive, pin or publication state was edited.
