# Owned BIO-pair native source review

No actionable findings in the four-file implementation.

Scope: actual candidate `.zig-cache/tls-owned-bio-pair-20261118/boringssl`
against immutable parent `.zig-cache/tls-domain-leaf-fixed-20261118/boringssl`,
using the accepted contract, inherited memory-domain ABI and existing Bio
construction/destruction/refcount implementation. This is a source verdict;
functional acceptance and combined runtime/evidence review are pending.

Frozen patch SHA256: `482dd921181067ba48d575c4576f1a1d2164a149196839a618d56cf69fb1008f`.
Frozen native identity manifest SHA256: `698bc252dcd3b629fb4f779e18ec3889aa96ccf5ab2b6eb2f174e0789647ed7b`.
Contract SHA256: `987d105fd00cb865a653ec60fa6706a69c33916c329431880229010294d43217`.

I independently rehashed both complete native trees and checked file modes.
Both contain 8709 files; exactly `crypto/bio/pair.cc`, `crypto/mem.cc`,
`crypto/mem_internal.h`, and `include/openssl/bio.h` differ. No added/deleted
files, mode changes or symlinks were found. The live candidate exactly matches
its frozen manifest. See `native_source_scope_check.json` beside this report.

Source checks completed:

- `crypto/mem.cc:242` computes raw extent with a guarded header addition and
  returns the existing alignment. It clears accessible failed output and has
  no allocation, hook, ERR, once, thread or I/O operation.
- `crypto/bio/pair.cc:407` normalizes each zero ring capacity to the unchanged
  17 KiB default, obtains all six raw extents from that helper, and separately
  guards alignment rounding and accumulated addition. Short-circuit evaluation
  makes both subtractions in the accumulated check safe. Failed results remain
  zeroed, and successful outputs are committed only after every check.
- `crypto/bio/pair.cc:459` clears both accessible output slots, rejects missing
  or aliased slots and malformed descriptors, and preflights the complete bound
  before allocation. The first inherited owned-allocation guard at
  `crypto/mem.cc:259` rejects any complete or partial memory-hook configuration
  before invoking a domain callback. There is no ordinary allocator fallback.
- `crypto/bio/pair.cc:440` obtains Bio and state storage before constructing
  either object. Failed state allocation releases the unconstructed Bio payload
  directly through generic owned free. Successful placement construction uses
  the existing Bio constructor and the ordinary state defaults; state attaches
  before either Bio reaches a UniquePtr/refcount destruction path.
- `crypto/bio/pair.cc:477` owns both endpoints during ring construction, so
  failure at any of the six raw allocation positions has an initialized-state
  cleanup path. Ring pairing happens only after both rings exist. Destruction
  uses the existing state/ring release and generic owned provenance, including
  either endpoint's last-reference order.
- The ordinary factory at `crypto/bio/pair.cc:491` passes a null domain, which
  selects its original `OPENSSL_malloc` ring branches. The shared default
  constant has the same value. Ordinary public layouts, Bio fields, methods,
  flags, reference counts, I/O routines, error behavior and memory prefix are
  unchanged; the owned allocator's existing validation/error ordering and raw
  layout remain unchanged apart from using the extracted size helper.
- `include/openssl/bio.h:649` adds named C-compatible output data and additive
  exported declarations inside the existing public linkage boundary. It
  documents the borrowed lifetime and failure behavior. No existing signature
  or public structure changed.

The structural-quality lens found no actionable regression: the authoritative
size helper eliminates layout duplication, construction stays in the existing
pair owner, and the explicit optional domain is confined to ring construction.
No generic allocator or Bio owner field was added. Candidate line counts are
`crypto/bio/pair.cc` 519, `crypto/mem.cc` 683, `crypto/mem_internal.h` 754, `include/openssl/bio.h` 1092. Existing large-file
boundaries did not require a new split for this small, cohesive change.

Verification evidence inspected: `native_evidence/syntax_compile.json` records
GNU++17 Zig c++ compilation of `crypto/mem.cc` and `crypto/bio/pair.cc`, both
exit 0 with empty raw logs. This reviewer did not rerun those compilations.
The root's captured pre-implementation RED and ordinary six-allocation control
were supplied as context, not independently replayed in this source pass.

Verification gaps:

- The native functional/OOM/counter/alignment/cleansing/hook matrices and
  SSL-held-reference proof are not yet reviewed. Compilation alone cannot
  certify them.
- Cross-target ABI bounds, ReleaseSafe/NDEBUG behavior, whole SDK builds,
  live PostgreSQL scope comparisons, and startup adapter lifetime/backing
  checks remain for the requested later combined runtime/evidence review.
- No dedicated smoke, security, sanitizer or fuzz campaign was run; those
  remain user-deferred without a gate change.
- Graph-first queries were run before implementation inspection. Their broad
  outputs were truncated; conclusions use the specifically located native
  files and the complete four-file diff.
- Cross-model review was skipped in this non-interactive independent reviewer
  context; no recursive reviewer was invoked.

No source, immutable parent, protected vendor, pin, test, gate or publication
state was edited. Only requested scratch review artifacts were written.
