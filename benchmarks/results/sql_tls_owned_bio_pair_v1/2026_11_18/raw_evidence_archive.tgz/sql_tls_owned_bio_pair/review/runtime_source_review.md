# Prepared SQL owned-BIO runtime source review

No actionable findings in the frozen six-file runtime diff or the two additive
test-support aliases. This is an independent source and recorded-evidence review,
not an acceptance claim for the pending integrated lifecycle comparison.

Reviewed against immutable parent
`.zig-cache/tls-domain-leaf-fixed-20261118/sdk`, accepted `contract.md` and
`ROOT_DECISION.md`. Every candidate and parent file hash/mode in
`runtime_evidence/runtime_source_identity.json` was independently recomputed and
matched; `runtime.diff` matches its recorded SHA256
`da5dc0b3bda9701c8bb1ef9cf2b274b36da9adca624f4ba62b171afa2bde139e`.

Ownership and failure paths inspected:

- `sdk/src/sql/db.zig:68` queries native bytes/alignment, checks the 2N count
  and total byte multiplication, and requests one aligned startup allocation.
  The loop at line 80 initializes exactly N normal and N cancellation Storage
  records only after their arrays have stable addresses. Each aligned queried
  extent is disjoint. Startup errors unwind context, BIO backing and prior
  allocations in reverse acquisition order.
- `sdk/src/sql/bio_storage.zig:23` rejects zero/non-power-of-two alignment and
  malformed extents before pointer arithmetic. Lines 56-68 perform checked
  alignment/end arithmetic, bound allocations to six exact extents and fail
  without growth or fallback. Lines 71-87 validate native releases and reset
  metadata only after the final raw block release. The native header contract
  supplies trusted matching callback context, extent and alignment, and cleanses
  raw storage before release; the adapter does not call back into BoringSSL.
- `sdk/src/crypto/tls_client.zig:136` preserves ordinary initializers and all
  TLS/name/ALPN policy, selecting the additive domain factory only when passed
  explicitly. Error cleanup releases both endpoints and SSL in valid ownership
  order. Storage is outside Session, so Session reset at line 194 leaves the
  borrowed descriptor/context intact.
- `sdk/src/sql/db.zig:266` keeps the existing normal/cancellation preparation
  and reconnect timing. A surviving extra endpoint reference fails the next
  storage acquisition before any replacement pair construction. Connection
  startup, admission, deadlines, quarantine and completion ordering are otherwise
  unchanged. `sdk/src/sql/connection.zig:258` releases Sessions only after
  socket completions have drained.
- `sdk/src/sql/db.zig:220` destroys both Session arrays, including dormant
  preconstructed cancellation Sessions, before freeing context or BIO slabs.
  Explicit live-count panics survive optimized builds and prevent freeing
  backing/descriptors while an external BIO reference survives.

The structural-quality lens found no actionable regression: the six-extent
adapter is isolated in an 88-line SQL-owned module, connection integration adds
one field, and the shared TLS implementation retains one initialization flow.
Resulting line counts are tls_client 229, connection 877, db 521 and new tests
224. No threshold crossing, weakened gate, new global state, version change or
unrelated source change occurs in this diff.

Evidence inspected: all eight final focused tests; the missing-module compile
RED and matching source hash; the actual zero-alignment assertion crash and
its isolated source guard fix; final ordinary SDK exit 0 and raw summary of
23/23 steps, 1173/1197 tests with 24 live skips; recorded formatting, convention
and release-version checks. Precisely two guard/query tests are present in the
pre-implementation missing-module RED snapshot; eight are present in the final
suite. The later alignment crash is genuine behavioral RED for an unchanged
guard test. Native ABI/header contracts and prior native-review handoff were
consulted without repeating the separate four-file native audit.

Verification gaps:

- Root's full live PostgreSQL run and unchanged original six-scenario lifecycle
  comparison were in progress when this review closed. Their functional and
  allocation vectors are not certified by the skipped ordinary suite.
- ReleaseSafe compilation, ReleaseFast library build and final combined project
  gates remain Root-owned acceptance work. This reviewer inspected recorded
  ordinary results and did not independently rerun builds or tests.
- There is no dedicated Db-level death test for teardown with an externally
  retained BIO reference; the fail-closed panic was verified in source and the
  retained-reference adapter/Session behavior is covered by focused tests.
- Linux x86-64 evidence does not establish cross-target execution or complete
  TLS storage bounds. Whole SSL allocation and the strict PostgreSQL allocation
  gate remain open.
- Broad smoke, security, sanitizer and fuzz campaigns remain user-deferred;
  their configured gates are unchanged.

Read AGENTS.md, CODING_CONVENTION.md, reviewer/crypto specialist instructions,
relevant SQL/TLS/security/build documentation and applicable review/Zig skills.
Graph-first queries preceded code exploration. No source, parent, archive,
protected vendor, pin or publication state was edited; only this requested
scratch review report was written.
