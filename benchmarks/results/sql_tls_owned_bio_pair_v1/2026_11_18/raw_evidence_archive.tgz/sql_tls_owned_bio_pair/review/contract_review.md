# Owned BIO-pair contract review

No actionable findings.

The exact four-file native factory/query plus a queried startup slab for each
of the N normal and N cancellation Connection objects is implementable under
the stated construction, OOM, reference, alignment and teardown rules.

Reviewed contract: `.zig-cache/tls-owned-bio-pair-20261118/contract.md`, SHA256
`987d105fd00cb865a653ec60fa6706a69c33916c329431880229010294d43217`.

The review covered contract lines 24-76 (additive C interface, output
nulling/alias rejection, one pure authoritative size helper, checked aligned
bound, two-phase construction and ordinary compatibility), lines 80-101
(stable per-Connection ownership, last-block reset and 2N structural bound),
and lines 105-147 (RED order, all six OOM points, SSL reference/free order,
unchanged allocation scope and required ordinary checks).

The immutable native parent inspected was
`.zig-cache/tls-domain-leaf-fixed-20261118/boringssl`. In particular:

- `crypto/bio/pair.cc:31` defines the complete pair state;
  `crypto/bio/pair.cc:51` creates that state;
  `crypto/bio/pair.cc:94` requires non-null state during destruction;
  `crypto/bio/pair.cc:249` owns both rings and pairing;
  `crypto/bio/pair.cc:398` is the ordinary factory.
- `crypto/bio/bio.cc:39` and `crypto/bio/internal.h:56` establish the Bio
  construction and refcount destruction path. The contract's allocation-before-
  construction rule prevents the existing null-state destroy hazard in the
  additive factory.
- `crypto/ex_data.cc:109` initializes empty ex-data without allocation, and
  its empty-data free path returns directly.
- `crypto/mem.cc:47`, `crypto/mem.cc:242`, `crypto/mem.cc:304`, and
  `include/openssl/mem.h:36` establish the inherited private header,
  raw callback extent/alignment, generic owned release, cleansing, immutable
  borrowed descriptor, synchronization and same-image constraints.
- `ssl/ssl_lib.cc:615` retains a second reference when one endpoint is supplied
  for both SSL read and write; the proposed last-endpoint-reference lifetime
  and both release-order checks cover that ownership.

The prepared SDK inspected was the unchanged fresh copy at
`.zig-cache/tls-owned-bio-pair-20261118/sdk`, with parent identified as
`.zig-cache/tls-domain-leaf-fixed-20261118/sdk`:

- `src/sql/db.zig:48` creates N normal and N cancellation Connection objects in
  separate stable allocator-owned arrays. A Db value may move during init, so
  keeping descriptor/context addresses in the stable Connection objects fits
  the contract; pointers must be installed after element initialization.
- `src/sql/connection.zig:256` waits for close and cancellation completions,
  destroys Session, and only then marks the object dormant and calls closed.
- `src/crypto/tls_client.zig:164` releases SSL and its external endpoint and
  clears Session, supporting storage outside Session.
- `src/sql/db.zig:199` drains/destroys every normal and cancellation Session
  before freeing connection storage. The new slab cleanup must retain this
  ordering, including partial init rollback.

The Linux64 arithmetic stated by the contract is internally consistent:
2*(80+32) + 2*(56+32) + 2*(32768+32) = 66000 raw bytes;
rounding each raw allocation to 16 bytes yields 66016 slab bytes. These are
conditional expectations rather than verified cross-target production bounds.
The design correctly requires the native query to be authoritative.

The structural-quality lens found no actionable contract-level regression:
the shared private size helper prevents duplicate native layout arithmetic,
and the SQL storage seam owns a bound and lifetime rule rather than forwarding
an unrelated operation. There is no whole-codebase refactor in this review.

Verification gaps:

- No factory, query, size-helper extraction or SQL adapter implementation was
  present; this is a contract verdict, not implementation approval.
- No new compilation, native/SDK tests, live PostgreSQL test, OOM campaign,
  ABI-size measurement or allocation comparison was run for this contract
  review. All source-level and evidence acceptance items remain required for
  the separate implementation review.
- Parent identity manifests were inspected for their 8709-file native and
  497-file SDK populations; the full trees were not independently rehashed.
- Graph queries were used before code inspection; their broad results were
  truncated, so conclusions rely on the specifically located source paths.
- Cross-model review was skipped in this non-interactive reviewer context.
  This agent is the independent reviewer in the root's doubt cycle and did
  not recursively invoke another reviewer.

No protected vendor, immutable parent, production source, pin, gate or test was
edited. Only this requested scratch report was written.
