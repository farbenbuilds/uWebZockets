const std = @import("std");
const bio_storage = @import("test_support").sql_bio_storage;

test "sql BIO storage: native requirements bound one complete pair" {
    const requirements = try bio_storage.requirements(32 * 1024);
    try std.testing.expect(requirements.bytes > 64 * 1024);
    try std.testing.expect(std.math.isPowerOfTwo(requirements.alignment));
    try std.testing.expectEqual(@as(usize, 0), requirements.bytes % requirements.alignment);
    try std.testing.expectError(error.InvalidRequirements, bio_storage.requirements(std.math.maxInt(usize)));
}

test "sql BIO storage: backing and availability fail before callbacks" {
    var backing: [256]u8 align(64) = undefined;
    var storage: bio_storage.Storage = .{};
    try std.testing.expectError(error.StorageUnavailable, storage.domain_for_pair());
    try std.testing.expectError(error.InvalidRequirements, storage.init(&backing, .{ .bytes = 128, .alignment = 0 }));
    try std.testing.expectError(error.InvalidRequirements, storage.init(&backing, .{ .bytes = 128, .alignment = 3 }));
    try std.testing.expectError(error.StorageTooSmall, storage.init(backing[0..127], .{ .bytes = 128, .alignment = 16 }));
    try std.testing.expectError(error.StorageMisaligned, storage.init(backing[1..], .{ .bytes = 128, .alignment = 16 }));
    try storage.init(&backing, .{ .bytes = 128, .alignment = 16 });
    const domain = try storage.domain_for_pair();
    try std.testing.expectEqual(@as(?*anyopaque, &storage), domain.context);
    try std.testing.expectEqual(@as(usize, 0), storage.live_count);
}
