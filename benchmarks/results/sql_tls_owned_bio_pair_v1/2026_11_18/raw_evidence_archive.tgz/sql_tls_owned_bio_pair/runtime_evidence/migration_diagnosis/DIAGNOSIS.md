# Migration-deadline diagnosis

No source, test, deadline, gate, native image or fixture setting was changed.
The frozen six-file runtime identity remains unchanged. All diagnostic processes
are terminal; the owned PostgreSQL fixture remains running for Root.

The original unfiltered candidate suite passed 1196/1197 tests and failed only
`sql migration service: applying SQL obeys the overall deadline and drains`.
The expected migration name was `migration_deadline`; the retained name was empty.
The failure occurred at the name assertion, after the unchanged assertions for
DeadlineExceeded and QueryTimeout had passed. The original seed is 0x23c82387.
Original raw build output, result and binary identity are preserved here.

Source localization:

- The exact test and its credential helper, migration service, migration runner,
  auth/wire codecs and runtime configuration are byte-identical to the immutable
  parent. `unchanged_sources.json` records all hashes.
- This test's Db configuration selects plaintext with TLS null. The new BIO
  factory, storage query and TLS slab allocation are not selected on this path.
- The service's 500 ms overall deadline includes waiting for SQL readiness and
  migration transaction/lock/schema/history setup. The named migration becomes
  current only after those phases. An empty name proves a pre-apply deadline
  outcome; it does not distinguish startup from a later setup phase.

Targeted comparison:

- Existing `-Dtest-filter` selected exactly the original single test, preserving
  the same source and 500 ms deadline. Candidate and immutable parent each passed
  their targeted build/run with the original seed.
- Five alternating direct binary replays per profile then ran against the same
  fixture without any other Root compile/test workload. Candidate passed 5/5.
  Parent passed 4/5 and failed once with the exact same empty-name assertion.
  `parent_replay_0/stderr.log` records that reproduction without any
  AuthenticationFailed warning. Each replay confirms the single selected target.
- Both targeted binary hashes, commands, exits, seed and raw outputs are retained.
  This demonstrates the failure exists independently of the new runtime source.
  It does not prove that every future timing schedule passes or quantify a
  regression-rate bound.

Backend evidence:

- Redacted snapshots verify the owned fixture's label, 512 MiB/2-CPU limits,
  max_connections 100 and one diagnostic client after each capture. No client
  limit, reserved-slot, fork, startup-packet or backend capacity error was seen.
- The original full-run window contains eight password-failure events clustered
  early in the run, consistent with the existing bad-password cohort. The raw
  records do not tie those events to the failing deadline test. Treat the
  AuthenticationFailed warning as non-causal until separately demonstrated.
- Between the before/after captures, all targeted runs produced exactly eleven
  new query-cancellation events and no new authentication or capacity errors.
  Twelve targeted invocations included eleven passes and the parent pre-apply
  failure. Raw server-log SQL statements and generated credentials were never saved.

Conclusion and next step:

The confirmed condition is inherited pre-apply sensitivity to an overall
500 ms deadline. The original run's exact delayed phase and underlying load or
scheduling cause remain unproven. No runtime fix or threshold/test change is
justified. Root can run one full unfiltered live suite alone, preserving the
original failure and these targeted results alongside its result. The complete
PostgreSQL allocation gate remains a separate strict RED obligation.
