# Prepared SQL owned-BIO runtime handoff

The six-file runtime scope is frozen in runtime_source_identity.json and runtime.diff.
Parent mapping and each final file hash/mode are explicit; Root owns the separate
test_support aliases and BoringSSL builder path rebind.

Native sizing drives one aligned startup allocation containing exactly 2N pair
slabs. Connection arrays are stable before each descriptor/context is initialized.
The adapter bounds six raw allocations, tracks exact extents, validates releases,
and resets only after the final native block is released. Normal and cancellation
Sessions are destroyed before backing release; dormant preconstructed cancellation
Sessions are included. Extra surviving BIO refs prevent reuse and fail closed
before Db deinit frees backing. SSL allocation remains ordinary.

Eight focused cases cover query/backing guards, bounded extents and arbitrary
release order, all six native OOM sites/cleansing/reuse, two owners/extra refs, 100
byte-transfer cycles, Session reset with retained network BIO, ordinary initializer
compatibility and startup allocation failure cleanup.

Actual missing-module compile RED is retained in storage_missing_module_actual_red.*
with its test source snapshot. Earlier sandbox cache failure and incorrect relative
test import are classified separately. runtime_first_build records a typed array
initializer error; runtime_second_build records the zero-alignment regression
crash and the pre-fix source is retained. The explicit zero guard fixes the
std.math.isPowerOfTwo positive-input precondition without changing the test.

Final ordinary enabled SDK command/result is runtime_alignment_fixed.*:
exit 0, 23/23 build steps,1173/1197 tests passed with 24 live PostgreSQL skips.
Formatting, conventions and release version checks pass (runtime_checks.json).
Root still owns full live tests, release builds, original lifecycle comparison,
final review, graph refresh, packaging and commit/push. No broad deferred campaign,
production pin or full PostgreSQL allocation completion is claimed.
