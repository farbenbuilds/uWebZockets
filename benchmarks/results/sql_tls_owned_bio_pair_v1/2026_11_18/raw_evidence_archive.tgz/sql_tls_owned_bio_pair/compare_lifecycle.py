#!/usr/bin/env python3
"""Compare the original complete worker intervals on one owned fixture."""
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser()
for name in ('control', 'candidate', 'output'):
    parser.add_argument('--' + name, type=Path, required=True)
args = parser.parse_args()

def require(condition, message):
    if not condition:
        raise SystemExit(message)

control = json.loads(args.control.read_text())
candidate = json.loads(args.candidate.read_text())
for report in (control, candidate):
    require(report['expected_rounds'] == report['completed_rounds'] == 6, 'incomplete rounds')
    require(report['functional_failure'] is None and report['strict_zero'] is False,
            'unexpected functional or strict outcome')
    require(len(report['rounds']) == 6, 'missing round records')
    require([row['scenario'] for row in report['rounds']] ==
            ['failure_reconnect'] * 3 + ['deadline_cancel'] * 3, 'scenario matrix changed')
    for row in report['rounds']:
        require(all(row[key] is True for key in ('scope_complete', 'initial_waiting',
                    'target_prepared_before', 'reconnect_prepared',
                    'queued_assignment_while_long_running')), 'incomplete functional scope')
        require(len(row['callbacks']) == 3 and all(value['observed'] is True
                    for value in row['callbacks']), 'incomplete callback records')
require(control['interval'] == candidate['interval'], 'allocation interval changed')
keys = ('mallocs', 'callocs', 'reallocs', 'frees', 'bytes')
invariants = ('scenario', 'scope_complete', 'initial_waiting', 'target_index',
              'old_generation', 'new_generation', 'target_prepared_before',
              'reconnect_prepared', 'queued_assignment_while_long_running',
              'aux_prepared_observed', 'aux_cancel_sent', 'cancel_requests_before',
              'cancel_requests_after', 'cancel_failures_before', 'cancel_failures_after',
              'reconnects_before', 'reconnects_after')
callback_invariants = ('observed', 'role', 'order', 'failure', 'long_running',
                       'request_idle', 'slot_index', 'lease_generation',
                       'connection_phase', 'connection_ssl_null',
                       'connection_network_bio_null', 'tls_prepared', 'pool')
rows = []
for original, owned in zip(control['rounds'], candidate['rounds'], strict=True):
    require(all(original[key] == owned[key] for key in invariants), 'lifecycle semantics differ')
    for before, after in zip(original['callbacks'], owned['callbacks'], strict=True):
        require(all(before[key] == after[key] for key in callback_invariants), 'callback semantics differ')
    old = {key: original['allocations'][key] for key in keys}
    new = {key: owned['allocations'][key] for key in keys}
    delta = {key: old[key] - new[key] for key in keys}
    pairs = 1 if original['scenario'] == 'failure_reconnect' else 2
    expected = dict(mallocs=6 * pairs, callocs=0, reallocs=0,
                    frees=6 * pairs, bytes=65856 * pairs)
    require(delta == expected, 'observed allocation reduction differs from measured pair closure')
    rows.append({'scenario': original['scenario'], 'control': old, 'owned': new,
                 'removed': delta, 'pair_constructions': pairs})
out = args.output.resolve()
for ancestor in (out, *out.parents):
    require(not (ancestor / 'files.sha256').exists(), 'output must be outside an evidence artifact')
out.mkdir(parents=True, exist_ok=False)
record = {'control_sha256': hashlib.sha256(args.control.read_bytes()).hexdigest(),
          'candidate_sha256': hashlib.sha256(args.candidate.read_bytes()).hexdigest(),
          'comparison_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'functional_rounds': 6, 'semantic_invariants_equal': True,
          'strict_allocation_gate_passed': False, 'rows': rows,
          'total_removed': {key: sum(row['removed'][key] for row in rows) for key in keys},
          'limits': 'Same-fixture Linux x86-64 ordinary prepared-SDK comparison; does not prove whole TLS ownership or total capacity.'}
(out / 'comparison.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record['total_removed']))
