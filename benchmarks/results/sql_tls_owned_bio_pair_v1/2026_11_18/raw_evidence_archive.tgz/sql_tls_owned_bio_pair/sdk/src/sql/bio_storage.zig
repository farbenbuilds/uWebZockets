//! Worker-confined backing for one native BIO pair and its final references.
const std = @import("std");
const c = @import("c");

/// One pair owns two BIOs, two endpoint states and two fixed rings.
pub const max_allocations = 6;
/// Native-derived raw storage bound; private header sizes stay in BoringSSL.
pub const Requirements = struct { bytes: usize = 0, alignment: usize = 0 };
/// Caller storage cannot grow or be reused while native references survive.
pub const Error = error{ InvalidRequirements, StorageTooSmall, StorageMisaligned, StorageUnavailable, StorageBusy };
/// Exact raw extents make release validation independent of destructor order.
const Block = struct { offset: usize = 0, bytes: usize = 0, live: bool = false };

/// Obtains the checked bound for the two equal-capacity SQL ciphertext rings.
pub fn requirements(capacity: usize) Error!Requirements {
    var native: c.BIO_PAIR_STORAGE_REQUIREMENTS = .{ .bytes = 0, .alignment = 0 };
    if (c.BIO_pair_storage_requirements(capacity, capacity, &native) != 1) return error.InvalidRequirements;
    const result: Requirements = .{ .bytes = native.bytes, .alignment = native.alignment };
    try validate_requirements(result);
    return result;
}

fn validate_requirements(value: Requirements) Error!void {
    if (value.bytes == 0 or value.alignment == 0) return error.InvalidRequirements;
    if (!std.math.isPowerOfTwo(value.alignment)) return error.InvalidRequirements;
    if (value.bytes % value.alignment != 0) return error.InvalidRequirements;
}

/// Its address, descriptor and backing remain stable until the last raw release.
pub const Storage = struct {
    backing: []u8 = &.{},
    domain: c.OPENSSL_ALLOCATION_DOMAIN = .{ .context = null, .allocate = null, .release = null },
    blocks: [max_allocations]Block = [_]Block{.{}} ** max_allocations,
    required: Requirements = .{},
    cursor: usize = 0,
    allocation_count: usize = 0,
    live_count: usize = 0,

    pub fn init(self: *Storage, backing: []u8, required: Requirements) Error!void {
        if (self.live_count != 0) return error.StorageBusy;
        try validate_requirements(required);
        if (backing.len < required.bytes) return error.StorageTooSmall;
        if (@intFromPtr(backing.ptr) % required.alignment != 0) return error.StorageMisaligned;
        self.* = .{ .backing = backing[0..required.bytes], .required = required };
        self.domain = .{ .context = self, .allocate = allocate_raw, .release = release_raw };
    }

    /// Creating another pair requires every prior endpoint reference to be gone.
    pub fn domain_for_pair(self: *Storage) Error!*const c.OPENSSL_ALLOCATION_DOMAIN {
        if (self.backing.len == 0 or self.domain.context != @as(?*anyopaque, self)) return error.StorageUnavailable;
        if (self.live_count != 0) return error.StorageBusy;
        return &self.domain;
    }
};

fn allocate_raw(context: ?*anyopaque, bytes: usize, alignment: usize) callconv(.c) ?*anyopaque {
    const self: *Storage = @ptrCast(@alignCast(context orelse return null));
    if (bytes == 0 or alignment != self.required.alignment) return null;
    if (self.allocation_count == max_allocations) return null;
    const rounded = std.math.add(usize, self.cursor, alignment - 1) catch return null;
    const offset = rounded & ~(alignment - 1);
    const end = std.math.add(usize, offset, bytes) catch return null;
    if (end > self.backing.len) return null;
    self.blocks[self.allocation_count] = .{ .offset = offset, .bytes = bytes, .live = true };
    self.allocation_count += 1;
    self.live_count += 1;
    self.cursor = end;
    return @ptrCast(self.backing.ptr + offset);
}

fn release_raw(context: ?*anyopaque, pointer: ?*anyopaque, bytes: usize, alignment: usize) callconv(.c) void {
    const self: *Storage = @ptrCast(@alignCast(context orelse @panic("SQL BIO release has no owner")));
    const address = @intFromPtr(pointer orelse @panic("SQL BIO release has no block"));
    if (alignment != self.required.alignment) @panic("SQL BIO release alignment differs");
    for (self.blocks[0..self.allocation_count]) |*block| {
        if (!block.live or @intFromPtr(self.backing.ptr) + block.offset != address) continue;
        if (block.bytes != bytes) @panic("SQL BIO release extent differs");
        block.live = false;
        self.live_count -= 1;
        if (self.live_count == 0) {
            self.cursor = 0;
            self.allocation_count = 0;
            self.blocks = [_]Block{.{}} ** max_allocations;
        }
        return;
    }
    @panic("SQL BIO release does not match a live block");
}
