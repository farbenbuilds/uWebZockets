const std = @import("std");
const bio_storage = @import("test_support").sql_bio_storage;
const tls = @import("test_support").tls_client;
const sql = @import("test_support").sql;
const c = @import("c");

test "sql BIO storage: native requirements bound one complete pair" {
    const requirements = try bio_storage.requirements(32 * 1024);
    try std.testing.expect(requirements.bytes > 64 * 1024);
    try std.testing.expect(std.math.isPowerOfTwo(requirements.alignment));
    try std.testing.expectEqual(@as(usize, 0), requirements.bytes % requirements.alignment);
    try std.testing.expectError(error.InvalidRequirements, bio_storage.requirements(std.math.maxInt(usize)));
}

test "sql BIO storage: backing and availability fail before callbacks" {
    var backing: [256]u8 align(64) = undefined;
    var storage: bio_storage.Storage = .{};
    try std.testing.expectError(error.StorageUnavailable, storage.domain_for_pair());
    try std.testing.expectError(error.InvalidRequirements, storage.init(&backing, .{ .bytes = 128, .alignment = 0 }));
    try std.testing.expectError(error.InvalidRequirements, storage.init(&backing, .{ .bytes = 128, .alignment = 3 }));
    try std.testing.expectError(error.StorageTooSmall, storage.init(backing[0..127], .{ .bytes = 128, .alignment = 16 }));
    try std.testing.expectError(error.StorageMisaligned, storage.init(backing[1..], .{ .bytes = 128, .alignment = 16 }));
    try storage.init(&backing, .{ .bytes = 128, .alignment = 16 });
    const domain = try storage.domain_for_pair();
    try std.testing.expectEqual(@as(?*anyopaque, &storage), domain.context);
    try std.testing.expectEqual(@as(usize, 0), storage.live_count);
}

test "sql BIO storage: six bounded extents survive arbitrary release order" {
    var backing: [128]u8 align(64) = undefined;
    var storage: bio_storage.Storage = .{};
    try storage.init(&backing, .{ .bytes = 96, .alignment = 16 });
    const domain = try storage.domain_for_pair();
    var blocks: [6]?*anyopaque = undefined;
    for (&blocks) |*block| block.* = domain.allocate.?(domain.context, 1, 16) orelse return error.TestUnexpectedResult;
    try std.testing.expectEqual(@as(usize, 6), storage.live_count);
    try std.testing.expectError(error.StorageBusy, storage.domain_for_pair());
    try std.testing.expectError(error.StorageBusy, storage.init(&backing, .{ .bytes = 96, .alignment = 16 }));
    try std.testing.expectEqual(@as(?*anyopaque, null), domain.allocate.?(domain.context, 1, 16));
    const order = [_]usize{ 3, 0, 5, 1, 4, 2 };
    for (order, 0..) |index, released| {
        domain.release.?(domain.context, blocks[index], 1, 16);
        try std.testing.expectEqual(@as(usize, 5) - released, storage.live_count);
        if (released != 5) try std.testing.expectError(error.StorageBusy, storage.domain_for_pair());
    }
    try std.testing.expectEqual(@as(usize, 0), storage.cursor);
    try std.testing.expectEqual(@as(usize, 0), storage.allocation_count);
    _ = try storage.domain_for_pair();
    try std.testing.expectEqual(@as(?*anyopaque, null), domain.allocate.?(domain.context, std.math.maxInt(usize), 16));
    try std.testing.expectEqual(@as(?*anyopaque, null), domain.allocate.?(domain.context, 1, 8));
    try std.testing.expectEqual(@as(usize, 0), storage.live_count);
}

/// Fault injection belongs to the test descriptor, never the runtime adapter.
const FaultDomain = struct {
    storage: *bio_storage.Storage = undefined,
    domain: c.OPENSSL_ALLOCATION_DOMAIN = .{ .context = null, .allocate = null, .release = null },
    fail_index: usize = std.math.maxInt(usize),
    calls: usize = 0,
    cleansed: bool = true,

    fn init(self: *FaultDomain, storage: *bio_storage.Storage, fail_index: usize) void {
        self.* = .{ .storage = storage, .fail_index = fail_index };
        self.domain = .{ .context = self, .allocate = allocate, .release = release };
    }

    fn allocate(context: ?*anyopaque, bytes: usize, alignment: usize) callconv(.c) ?*anyopaque {
        const self: *FaultDomain = @ptrCast(@alignCast(context.?));
        const index = self.calls;
        self.calls += 1;
        if (index == self.fail_index) return null;
        return self.storage.domain.allocate.?(self.storage.domain.context, bytes, alignment);
    }

    fn release(context: ?*anyopaque, pointer: ?*anyopaque, bytes: usize, alignment: usize) callconv(.c) void {
        const self: *FaultDomain = @ptrCast(@alignCast(context.?));
        const raw: [*]const u8 = @ptrCast(pointer.?);
        for (raw[0..bytes]) |byte| {
            if (byte != 0) self.cleansed = false;
        }
        self.storage.domain.release.?(self.storage.domain.context, pointer, bytes, alignment);
    }
};

/// Both returned endpoint references are owned by the caller until released.
const Pair = struct { left: ?*c.BIO = null, right: ?*c.BIO = null };

fn pair(domain: *const c.OPENSSL_ALLOCATION_DOMAIN) !Pair {
    var result: Pair = .{};
    if (c.BIO_new_bio_pair_with_domain(&result.left, 32 * 1024, &result.right, 32 * 1024, domain) != 1) return error.PairConstructionFailed;
    return result;
}

fn release_pair(value: *Pair) void {
    if (value.left) |endpoint| _ = c.BIO_free(endpoint);
    if (value.right) |endpoint| _ = c.BIO_free(endpoint);
    value.* = .{};
}

test "sql BIO storage: each native allocation failure cleans up and permits reuse" {
    const required = try bio_storage.requirements(32 * 1024);
    var backing: [128 * 1024]u8 align(64) = undefined;
    var storage: bio_storage.Storage = .{};
    try storage.init(&backing, required);
    for (0..6) |index| {
        c.ERR_clear_error();
        var fault: FaultDomain = .{};
        fault.init(&storage, index);
        var failed: Pair = .{};
        try std.testing.expectEqual(@as(c_int, 0), c.BIO_new_bio_pair_with_domain(&failed.left, 32 * 1024, &failed.right, 32 * 1024, &fault.domain));
        try std.testing.expectEqual(@as(?*c.BIO, null), failed.left);
        try std.testing.expectEqual(@as(?*c.BIO, null), failed.right);
        try std.testing.expectEqual(index + 1, fault.calls);
        try std.testing.expect(fault.cleansed);
        try std.testing.expectEqual(@as(usize, 0), storage.live_count);
        try std.testing.expectEqual(@as(usize, 0), storage.cursor);
        var recovered = try pair(try storage.domain_for_pair());
        release_pair(&recovered);
        try std.testing.expectEqual(@as(usize, 0), storage.live_count);
    }
    c.ERR_clear_error();
}

test "sql BIO storage: independent owners wait for final endpoint references" {
    const required = try bio_storage.requirements(32 * 1024);
    var first_backing: [128 * 1024]u8 align(64) = undefined;
    var second_backing: [128 * 1024]u8 align(64) = undefined;
    var first: bio_storage.Storage = .{};
    var second: bio_storage.Storage = .{};
    try first.init(&first_backing, required);
    try second.init(&second_backing, required);
    var a = try pair(try first.domain_for_pair());
    defer release_pair(&a);
    var b = try pair(try second.domain_for_pair());
    defer release_pair(&b);
    try std.testing.expectEqual(@as(usize, 6), first.live_count);
    try std.testing.expectEqual(@as(usize, 6), second.live_count);
    const retained = a.left.?;
    try std.testing.expectEqual(@as(c_int, 1), c.BIO_up_ref(retained));
    _ = c.BIO_free(a.left);
    a.left = null;
    _ = c.BIO_free(a.right);
    a.right = null;
    try std.testing.expect(first.live_count > 0);
    try std.testing.expectError(error.StorageBusy, first.domain_for_pair());
    try std.testing.expectEqual(@as(usize, 6), second.live_count);
    _ = c.BIO_free(retained);
    try std.testing.expectEqual(@as(usize, 0), first.live_count);
    _ = c.BIO_free(b.right);
    b.right = null;
    try std.testing.expect(second.live_count > 0);
    _ = c.BIO_free(b.left);
    b.left = null;
    try std.testing.expectEqual(@as(usize, 0), second.live_count);
    _ = try first.domain_for_pair();
    _ = try second.domain_for_pair();
}

test "sql BIO storage: repeated byte transfer reuses one queried slab" {
    const required = try bio_storage.requirements(32 * 1024);
    var backing: [128 * 1024]u8 align(64) = undefined;
    var storage: bio_storage.Storage = .{};
    try storage.init(&backing, required);
    for (0..100) |index| {
        var current = try pair(try storage.domain_for_pair());
        const message = "owned BIO bytes";
        try std.testing.expectEqual(@as(c_int, message.len), c.BIO_write(current.left, message.ptr, message.len));
        var received: [message.len]u8 = undefined;
        try std.testing.expectEqual(@as(c_int, received.len), c.BIO_read(current.right, &received, received.len));
        try std.testing.expectEqualSlices(u8, message, &received);
        if (index % 2 == 0) {
            _ = c.BIO_free(current.right);
            current.right = null;
        }
        release_pair(&current);
        try std.testing.expectEqual(@as(usize, 0), storage.live_count);
        try std.testing.expectEqual(@as(usize, 0), storage.cursor);
    }
}

test "sql BIO storage: Session reset cannot release a retained network reference" {
    const required = try bio_storage.requirements(tls.bio_capacity);
    var backing: [128 * 1024]u8 align(64) = undefined;
    var storage: bio_storage.Storage = .{};
    try storage.init(&backing, required);
    var context = try tls.ClientContext.init(.{ .verify = false });
    defer context.deinit();
    var session: tls.Session = .{};
    try session.init_for_protocol_with_bio_domain(context.ctx, "localhost", false, .postgres, try storage.domain_for_pair());
    try std.testing.expectEqual(@as(usize, 6), storage.live_count);
    const retained = session.network_bio.?;
    try std.testing.expectEqual(@as(c_int, 1), c.BIO_up_ref(retained));
    session.deinit();
    try std.testing.expectEqual(@as(?*c.SSL, null), session.ssl);
    try std.testing.expect(storage.live_count > 0);
    try std.testing.expectError(error.StorageBusy, storage.domain_for_pair());
    _ = c.BIO_free(retained);
    try std.testing.expectEqual(@as(usize, 0), storage.live_count);
    try session.init_for_protocol_with_bio_domain(context.ctx, "localhost", false, .postgres, try storage.domain_for_pair());
    session.deinit();
    try session.init_for_protocol(context.ctx, "localhost", false, .postgres);
    try std.testing.expectEqual(@as(usize, 0), storage.live_count);
    session.deinit();
}

fn startup_tls_failure(allocator: std.mem.Allocator) !void {
    var db = sql.Db.init(allocator, .{
        .user = "uwz_test",
        .database = "uwz_test",
        .tls = .{ .ca_path = ".", .server_name = "localhost" },
        .limits = .{ .max_message_bytes = 1024, .max_response_bytes = 1024 },
        .write_bytes = 1024,
    }) catch |err| return switch (err) {
        error.OutOfMemory => err,
        error.TlsFailed => {},
        else => err,
    };
    defer db.deinit();
    return error.ExpectedTlsFailure;
}

test "sql BIO storage: every startup allocation failure releases TLS backing" {
    try std.testing.checkAllAllocationFailures(std.testing.allocator, startup_tls_failure, .{});
}
