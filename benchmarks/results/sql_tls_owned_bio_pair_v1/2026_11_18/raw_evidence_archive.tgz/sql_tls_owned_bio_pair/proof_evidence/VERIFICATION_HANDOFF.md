# Owned BIO-pair native verification

The final native ReleaseSafe proof passes 38/38 build steps. Ten executed
programs are installed in zig-out/bin. No native or prepared-SDK implementation
source was edited by verification. The original allocation_scope.c remains
afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac.

## Parent RED

Before Root authorized native edits, bio_public_api_proof.c failed compilation
against the complete immutable parent because the new type/query/factory were
absent. This is public API compile RED, not a claimed behavioral test.
parent_api_red.json records the exact command and probe SHA
ba126ca7c33d4aaf0e86c470011f512cc4310af1fe35a0d42de742285360fa4b.

The ordinary pair control compiled and completed correct byte transfer. With
two 32768-byte rings, it measured malloc6/calloc0/realloc0/free6/requested65856.
The identical binary exits zero for that positive control and exits one when
invoked with --strict. Its unchanged all-C counter self-test verifies five
operations and 63 requested bytes. The exact parent binary is preserved as
bin/ordinary_parent_control, SHA
c41873b6467cd0d2d7404bbae6f8dcecdab8fe3d406189b1b5f9236a85a1f379.
Raw parent compile/build/strict records remain separate from final records.

## Final command and result

The exact command and elapsed time are in owned_bio_final_build.json. It runs
the pinned workspace Zig 0.16.0 binary, `build proof -Doptimize=ReleaseSafe -j4`,
the isolated work/native-cache and the previously provisioned native-global-cache.
The complete normal generated BoringSSL source lists build crypto and SSL;
the sized-free control builds its own complete second crypto image. No object
overlay, alternate compiler, system crypto library or build-time patch is used.

owned_bio_final_build.log reports all 38 steps succeeded. The inherited memory/
CBB proof has 14 passing rows, including its 13 measured zero-C-heap cases.
The ordinary pair remains an allocating control with the same six-allocation
vector. Full/partial weak-hook, guard-page and ordinary/owned sized-free controls
also pass.

## New public-interface matrix

bio_pair_proof.cc reports ten passing rows. Nine have malloc/calloc/realloc/free
and requested bytes all exactly zero:

- A first native requirements call before ERR warm-up: valid 32 KiB capacities,
  null output and invalid size, with no C heap operation.
- Requirements preserve an existing ERR sentinel, normalize zero to the same
  17 KiB default, reject payload/alignment/sum overflow and zero failure output.
- Zero/default, tiny asymmetric, ordinary asymmetric and 32 KiB capacities:
  exactly six owned allocations; actual rounded raw requests equal query bytes;
  high-water fits the bound. Current Linux64 32 KiB result is 66016 bytes,
  alignment16. These are measured proof expectations, not runtime constants.
- Ring wrap, short/partial writes, full and empty retries, read request/reset,
  pending/write-pending/write guarantee, bidirectional bytes, flush, independent
  half-close, draining to EOF and broken-pipe refusal.
- Every one of six allocation failure indices: null outputs, full partial
  cleanup, no C fallback and successful construction/reuse afterwards.
- Null and aliased output slots, null/missing descriptor callbacks and size
  overflow are rejected before any domain allocation callback.
- Test-adapter backing rejects undersize/misalignment before exposing a bad
  pointer to native C++; overlapping construction fails without disturbing the
  original live pair or resetting its storage.
- Two independent domains interleave 128 complete construction/destruction
  cycles each, preserve byte identity and release every raw block through the
  correct owner. Release verifies exact pointer/extent/alignment and complete
  cleansing of header, padding and payload.
- Extra endpoint references and both final-release orders retain backing until
  the last reference, then release all six blocks and reset only when live zero.

The tenth row deliberately counts the complete SSL_CTX/SSL construction and
destruction around SSL_set_bio. The same endpoint supplies both SSL read/write
roles; external extra references and both final-release orders preserve exact
owned-pair lifetimes. This whole-SSL control measured 59 mallocs, 58 frees and
14802 requested bytes. Its remaining native process/thread allocation lifetime
is not diagnosed by this test. It is a positive allocating control and does not
claim a zero-allocation SSL lifetime. All pair raw blocks are released/cleansed.

The full weak-hook program and each separate partial alloc/free/get_size program
call the new BIO requirements query for valid and overflow inputs with a single
ERR sentinel. Query output, exact queue depth and original error are preserved;
all five all-C counter fields are zero. The NEW owned-pair factory is also
called in all four configurations and rejects with null outputs before domain
or hook callback use, under a zero all-C counted scope. The full-hook ordinary
tiny pair still uses exactly six hook allocations/releases and transfers the
expected bytes. These checks extend the public pair interface; they are not
inferred from the earlier memory/CBB hook proof.

## Owned files and identities

Verification changed only top build.zig and proof/ plus proof_evidence/:

- New bio_public_api_proof.c, ordinary_bio_control.cc and bio_pair_proof.cc.
- New allocation_scope.h declares original counter entry points and combines
  every operation/byte into one test zero invariant; it changes no counter body.
- Existing hook_proof.cc and partial_hook_proof.cc gain new query/factory checks.
- Existing allocation_scope.c, domain_proof.cc, public_api_proof.c and
  sdallocx_proof.cc retain parent bytes.
- build.zig adds the new programs, original counter linkage for hook checks,
  SSL linkage for the explicit whole-SSL control and a shared ordinary baseline
  step. Native build ownership remains in the prepared SDK's normal builder.

final_proof_identity.json records the exact compiler, proof/build sources,
ten installed executed binaries, three compiled native library hashes and
builder/log identities. The libraries are provenance metadata, not delivery
payloads. proof_native_identity.json records all 8709 native files as used;
only the four contracted native paths differ from the parent. Root should
reconcile these identities with the native owner's final record before freezing.

## Limits

The proof is native Linux x86-64/glibc and uses the existing interposer. It is
not cross-target execution, a numerical total TLS-domain bound, integrated SQL
pressure/OOM proof, or complete PostgreSQL allocation compliance. The cold
requirements row observes all-C heap behavior; lack of ERR/hook/thread/once
effects also requires the source-level purity review. It does not install an
independent pthread/once interposer. Root owns actual SDK/runtime integration,
live PostgreSQL, unchanged six-scenario lifecycle comparison, project gates,
graph refresh, review and delivery. Smoke/security/sanitizer/fuzz campaigns
remain user-deferred and are not claimed by these functional checks.
