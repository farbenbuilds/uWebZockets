# Complete owned BIO-pair construction

Status: architecture accepted by Root; independent contract review precedes source
implementation. The active objective remains all v2.3.0 requirements in TODO.md.

## Parent and ownership

Use the complete immutable 8709-file native memory/CBB source from
../tls-domain-leaf-fixed-20261118/boringssl. Its final identity SHA256 is
d3f644b25ac53ff800610dff16f980296f68ffb39fa5e319f5f8a32d8c6f43fa.
Root checkpoint cb11c009a07247ec6781438aeff59edb9f48e3a1 retains that source
and the unchanged lifecycle inventory. All implementation uses fresh complete
SSD copies. No protected vendor, parent source, production pin, publication
destination or new remote changes are authorized.

The observed pair closure comprises two Bio objects, two pair-state objects
and two rings: six malloc calls and 65856 requested bytes per 32 KiB pair in
the original Linux64 image. Nine pairs occur across the six original intervals.
Remove this whole closure with explicit destination ownership. Broader SSL,
transcript, certificates, crypto and ERR/thread allocation remains separate work.

## Additive C interface

In include/openssl/bio.h include the existing openssl/mem.h domain declaration:

```c
typedef struct bio_pair_storage_requirements_st {
  size_t bytes;
  size_t alignment;
} BIO_PAIR_STORAGE_REQUIREMENTS;

OPENSSL_EXPORT int BIO_pair_storage_requirements(
    size_t writebuf1, size_t writebuf2,
    BIO_PAIR_STORAGE_REQUIREMENTS *out);

OPENSSL_EXPORT int BIO_new_bio_pair_with_domain(
    BIO **out1, size_t writebuf1,
    BIO **out2, size_t writebuf2,
    const OPENSSL_ALLOCATION_DOMAIN *domain);
```

Requirements are pure: no allocation, ERR changes, hook lookup, once/thread
initialization or I/O. Normalize each zero capacity to the existing 17 KiB
default. Null output returns zero; other invalid/overflow inputs return zero
with the accessible output record zeroed. Success returns one and a checked
aligned bound for all six raw allocations.

The factory clears accessible outputs and requires non-null distinct output
slots, a valid borrowed immutable descriptor and no incompatible memory hooks.
Reject output aliasing, descriptor/hook errors and size/bound overflow before
any domain callback. Every failure leaves both accessible outputs null and
fully releases constructed state. There is no ordinary-heap fallback. Ordinary
BIO_new_bio_pair behavior, public layouts, refcounts and I/O semantics remain
unchanged. Descriptor/callback/context/storage survive the last endpoint ref.

## One authoritative memory layout

Add private AllocationDomainRequirements {raw_size,alignment} and pure bool
GetAllocationDomainRequirements(size_t payload_size, ... *out) in the existing
mem_internal.h/mem.cc seam. Use it both in OPENSSL_malloc_with_domain and the
BIO query. Keep the existing owned header representation, placement construction,
cleansing and ordinary eight-byte prefix unchanged. No public layout constants,
generic owned BIO_new, allocator template or extra Bio owner field is needed.

The pair bound sums checked align_up(raw_size, alignment) for Bio, pair-state,
Bio, pair-state, ring1 and ring2. Checked arithmetic includes alignment rounding
and the total sum. Current Linux64 expectations are H32, A16, Bio80, state56,
66000 raw bytes and 66016 aligned slab bytes for two 32768-byte rings. These
are proof expectations, never production constants or a total TLS bound.

Crypto owns four paths in the fresh full native tree: include/openssl/bio.h,
crypto/bio/pair.cc, crypto/mem_internal.h and crypto/mem.cc. A two-phase endpoint
constructor obtains raw Bio/state blocks before constructing/attaching them.
Bio destruction must never reach pair bio_free with null state. If state
allocation fails, release the unconstructed Bio raw block directly. Generic
BIO_free/owned-memory provenance releases valid constructed objects normally.

## Prepared SQL SDK integration

Runtime owns a focused private SQL BIO-storage module and its call sites in
the complete prepared SDK copy at ./sdk, copied from the immutable
../tls-domain-leaf-fixed-20261118/sdk. Each physical normal and cancellation Connection
gets its own queried startup slab and explicit immutable descriptor/context.
Initialize self/context pointers only after connection arrays have stable
addresses. Keep storage outside Session because Session.deinit clears Session.
Pass the domain explicitly through an additive storage-aware Session initializer;
ordinary initializers retain their existing behavior.

Use checked aligned bump allocation and a live-block count. Reset the cursor
only when the last raw block is released. Reject unavailable/misaligned backing,
overlapping pair construction and capacity exhaustion; do not wait, grow, reuse
live bytes, allocate another slab or retain a spare native-object stock. Native
callbacks always receive appropriately aligned raw storage. Tests of bad backing
must reject it before returning a misaligned pointer to native C++ placement new.
Preserve cleanup after partial OOM and both BIO release orders. Drain all
sessions before freeing backing slabs or descriptors.

The structural storage bound is 2N queried pair slabs plus bounded metadata for
N configured pool connections, independent of reconnect count. Verify actual
normal/cancel object counts against the existing runtime. No trace peak is a
capacity proof. Preserve TLS verification, pool/admission counts, deadlines,
quarantine, callback order and close draining without changing measurement scope.

## RED, implementation and verification order

1. Verification writes and captures missing-API C compile RED against immutable
   parent and the ordinary pair's six-allocation control before implementation.
   Reuse the original unchanged allocation_scope.c and 63-byte positive self-test.
2. Native owner implements only the four native paths after those RED records.
   Native proof covers the complete six-allocation closure and inherited domain
   cases, using explicit checked test failures that survive ReleaseSafe/NDEBUG.
3. Runtime owner integrates actual prepared SQL normal and cancel connections
   using the query and reusable startup storage. Root serializes shared build,
   imports and fixture work. Every owner reports changed files and real results.
4. Compare unchanged prepared SDK lifecycle control and new integration against
   one fresh owned PostgreSQL fixture. All six functional rounds pass; all-C
   intervals, allocator bodies, other active queries and queued waiters remain
   identical. Strict full allocation RED stays RED until every native path is
   owned. Review source, requirements bound, lifetimes and raw evidence independently.

Native proof covers all six OOM indices and reuse; two interleaved domains and
many construction/destruction cycles; exact owner/extent/alignment and complete
raw cleansing on release; distinct/alias/null outputs; invalid descriptors and
full/partial hooks; zero/default/tiny asymmetric/32 KiB capacities; payload,
alignment and sum overflow; undersized/misaligned adapter backing; ring wrap,
partial/full/empty retry, pending/read requests/write guarantees, flush,
half-close and drain-to-EOF; either free order and extra refs. Query outputs fit
actual requests and never mutate ERR or initialize a thread facility.

Exercise SSL_set_bio with one endpoint for both read/write and release in both
orders. A leaf-only zero count may preconstruct SSL outside that leaf scope and
detach/free its BIO inside it; full SSL_free retains its honest ordinary counts.
The integrated worker-wide test always includes its original complete SSL
teardown. Never infer whole SSL lifetime zero from the BIO leaf scope.

Predicted reductions, to be tested rather than accepted arithmetically, are:
failure rounds 268/2/0/270/412766 -> 262/2/0/264/346910;
cancel rounds 536/4/0/540/825532 -> 524/4/0/528/693820
(malloc/calloc/realloc/free/requested bytes). Same-fixture controls determine
the authoritative vectors if fixture-specific certificate bytes differ.

Run ordinary native and prepared-SDK functional tests, live PostgreSQL tests,
ReleaseSafe compile and ReleaseFast library builds; required root fmt,
convention, version and ordinary unit checks. Keep smoke/security/sanitizer/fuzz
campaigns user-deferred without altering their configured gates. Evidence helper
acceptance checks must remain active under optimized Python or explicitly reject
it before work. Keep each result directory to README, manifest and one archive
below 100 MiB. Root commits and pushes only impl/implement-2.3.0 after review.

Deleting this ownership seam would spread six allocation decisions, overflow,
alignment, partial rollback and reference-lifetime rules into TLS callers. That
justifies the small factory/query interface. Complete TLS capacity, SSL/cert/
crypto/thread ownership, maintained publication/pins, D-5 performance and every
other open roadmap requirement remain part of the original goal.
