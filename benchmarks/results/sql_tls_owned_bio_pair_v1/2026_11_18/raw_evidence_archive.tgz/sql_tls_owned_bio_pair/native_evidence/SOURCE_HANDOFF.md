# Complete owned BIO-pair native source handoff

The accepted additive factory and pure requirements query are implemented in
exactly four native paths: include/openssl/bio.h, crypto/bio/pair.cc,
crypto/mem_internal.h and crypto/mem.cc. The full candidate retains 8709 files,
with no added/deleted files, links or mode changes against the copied parent.
Parent bytes are unchanged. All source edits stopped at this freeze pending
independent source/functional review.

The memory module alone computes owned raw extent/alignment. Both the existing
owned allocator and new BIO storage query use that helper. The private header,
placement construction, ordinary eight-byte prefix, cleansing and generic
free/realloc representation are unchanged.

The query normalizes zero capacities to 17 KiB and checks per-allocation padding
and total overflow. It performs no allocator, ERR, hook, initialization or thread
operation. The factory nulls accessible outputs, rejects null/aliased outputs
and malformed descriptors, and preflights the complete storage bound before its
first allocation. Existing owned allocation guards reject incompatible hooks
before any callback. There is no ordinary fallback.

Each endpoint obtains raw Bio and state memory before constructing either.
State attaches before a Bio becomes destructible through its pair method.
Generic BIO_free/refcounts release complete constructed endpoints and their
rings. Partial state-allocation failure frees the unconstructed Bio raw block.
The private pairing routine receives an explicit optional domain for ring
allocation; the existing ordinary factory passes nullptr and retains its path.

Root explicitly authorized edits after checking real missing-API compile RED,
the ordinary six-malloc/six-free/65856-byte pair control and unchanged 63-byte
self-test. Targeted GNU++17 Zig c++ compilation of mem.cc and pair.cc both exits
zero; exact commands, elapsed time and raw logs are in syntax_compile.json and
mem_compile.log/pair_compile.log. This is compilation evidence only. Native
functional, OOM, counter, SSL lifetime and prepared-SDK/lifecycle matrices belong
to the independent verification/runtime owners and are not claimed here.

No production pin, new remote, protected vendor, parent, SDK, proof source or
root tracked source was edited by this owner. Dedicated smoke/security/sanitizer/
fuzz campaigns remain user-deferred. New .o files are syntax-check outputs only,
not library overlays or delivery inputs.
