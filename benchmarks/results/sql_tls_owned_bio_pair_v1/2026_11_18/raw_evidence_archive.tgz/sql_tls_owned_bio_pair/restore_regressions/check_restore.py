#!/usr/bin/env python3
"""Exercise fail-closed restoration gates with Python optimization enabled."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

repo = Path('/home/foo/Desktop/Repos/uWebZockets')
delivery = repo / '.zig-cache/tls-owned-bio-pair-20261118/delivery'
packet = delivery / 'packet/sql_tls_owned_bio_pair'
parent = repo / '.zig-cache/tls-domain-leaf-fixed-20261118/boringssl'
out = delivery / 'restore_regressions'
out.mkdir(exist_ok=False)
empty = out / 'empty_parent'
empty.mkdir()
existing = out / 'already_exists'
existing.mkdir()
immutable = out / 'immutable'
immutable.mkdir()
(immutable / 'files.sha256').write_text('')
env = dict(os.environ, PYTHONOPTIMIZE='1')
records = []

def require(condition, message):
    if not condition:
        raise SystemExit(message)

def run_case(name, input_packet, input_parent, destination, expected, extra=(), exists_before=False):
    command = ['python3', '-O', str(input_packet / 'restore.py'), '--parent', str(input_parent),
               '--output', str(destination), *extra]
    result = subprocess.run(command, env=env, capture_output=True)
    (out / (name + '.log')).write_bytes(result.stdout + result.stderr)
    require(result.returncode != 0 and expected.encode() in result.stdout + result.stderr,
            'negative restoration case did not reject: ' + name)
    require(destination.exists() == exists_before, 'negative restoration wrote output: ' + name)
    records.append({'name': name, 'command': command, 'optimized_python': True,
                    'exit_code': result.returncode, 'output_created': False,
                    'output_existed_before': exists_before, 'expected_diagnostic': expected})

run_case('wrong_file_set', packet, empty, out / 'bad_set_output', 'source file set differs')
run_case('wrong_native_hash', packet, repo / '.zig-cache/tls-owned-bio-pair-20261118/boringssl',
         out / 'bad_hash_output', 'source hash:')
run_case('wrong_compiler', packet, parent, out / 'bad_compiler_output',
         'compiler hash differs', ('--zig', '/bin/true'))
for name, suffix in [('quote', '"output'), ('backslash', '\\output'), ('control', '\noutput')]:
    run_case('unsupported_' + name, packet, parent, out / suffix, 'must not contain')
run_case('existing_output', packet, parent, existing, 'output already exists', exists_before=True)
run_case('inside_evidence', packet, parent, immutable / 'output', 'outside an evidence artifact')

bad_packet = out / 'bad_sdk_packet'
bad_packet.mkdir()
shutil.copy2(packet / 'restore.py', bad_packet / 'restore.py')
shutil.copytree(packet / 'source_identity', bad_packet / 'source_identity')
shutil.copytree(packet / 'sdk', bad_packet / 'sdk')
first = json.loads((packet / 'source_identity/sdk_final_source_identity.json').read_text())['files'][0]
bad_file = bad_packet / 'sdk' / first['path']
original = bad_file.read_bytes()
bad_file.write_bytes(original + b'changed input\n')
run_case('wrong_sdk_hash', bad_packet, parent, out / 'bad_sdk_hash_output', 'source hash:')
bad_file.write_bytes(original)
bad_file.chmod(first['mode'] ^ 0o100)
run_case('wrong_sdk_mode', bad_packet, parent, out / 'bad_sdk_mode_output', 'source mode:')
shutil.rmtree(bad_packet)
record = {'helper_sha256': hashlib.sha256((packet / 'restore.py').read_bytes()).hexdigest(),
          'negative_cases': records, 'all_rejected': True, 'case_count': len(records)}
(out / 'results.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'negative_cases': len(records), 'all_rejected': True}))
