#!/usr/bin/env python3
"""Reconcile every measured client operation with the reported control rows."""
import argparse
import csv
import hashlib
import json
from pathlib import Path


def verify(directory, operations_name, summary_name):
    operations = list(csv.DictReader((directory / operations_name).open()))
    rows = [json.loads(line) for line in (directory / summary_name).read_text().splitlines()]
    scenarios = ('baseline', 'initial_tickets_cache_off',
                 'key_update_not_requested', 'key_update_requested')
    keys = {(row['round'], row['scenario']) for row in rows}
    assert len(rows) == 12 and keys == {(round, name) for round in range(3) for name in scenarios}
    checked_operations = 0
    fields = ('malloc', 'calloc', 'realloc', 'free', 'bytes')
    vectors = {}
    for row in rows:
        name = row['scenario']
        assert row['tls13_verified'] and row['hostname_verified'] and row['payload_valid']
        assert row['payload_bytes'] == 4096 and row['alpn_bytes'] == 0
        assert row['cipher_suite'] in (0x1301, 0x1302, 0x1303)
        assert row['bio_capacity'] == 1024 and row['read_chunk'] == 257
        assert row['received_tickets'] == (2 if name == 'initial_tickets_cache_off' else 0)
        expected_updates = int(name.startswith('key_update_'))
        assert row['received_key_updates'] == expected_updates
        assert row['received_key_mode'] == ({'key_update_requested': 1, 'key_update_not_requested': 0}.get(name, -1))
        requested = name == 'key_update_requested'
        assert row['sent_key_updates'] == row['peer_received_response'] == int(requested)
        assert row['peer_response_mode'] == (0 if requested else -1)
        assert row['reply_valid'] == (True if requested else None)
        assert row['reservation']['malloc'] == 2
        assert row['reservation']['calloc'] == row['reservation']['realloc'] == 0
        assert row['reservation']['bytes'] == 131070
        selected = [op for op in operations if int(op['round']) == row['round'] and op['scenario'] == name]
        for phase, prefix, totals_name in (('read', 'read', 'client_read'),
                                            ('response_write', 'write', 'client_response_write')):
            subset = [op for op in selected if op['phase'] == phase]
            assert len(subset) == row[prefix + '_operations']
            assert [int(op['operation']) for op in subset] == list(range(len(subset)))
            totals = {field: sum(int(op[field]) for op in subset) for field in fields}
            assert totals == row[totals_name]
            retries = sum(int(op['result']) <= 0 for op in subset)
            assert retries == row[prefix + '_retries']
            accepted = sum(max(int(op['result']), 0) for op in subset)
            assert accepted == (4096 if phase == 'read' or requested else 0)
            for op in subset:
                result, error = int(op['result']), int(op['error'])
                assert (result > 0 and error == 0) or (result <= 0 and error in (2, 3))
                assert all(int(op[field]) >= 0 for field in fields)
                if phase == 'read' and result > 0:
                    assert result <= 257
            vectors.setdefault(name + '/' + phase, set()).add(tuple(totals[field] for field in fields))
            checked_operations += len(subset)
        assert all(op['phase'] in ('read', 'response_write') for op in selected)
        if name == 'baseline':
            assert all(row['client_read'][field] == 0 for field in fields)
        else:
            assert row['client_read']['malloc'] > 0
    assert checked_operations == len(operations)
    return {
        'rows_verified': len(rows), 'operations_verified': checked_operations,
        'all_payloads_and_protocol_observations_valid': True,
        'source_scope': 'client SSL_read/SSL_write and immediate SSL_get_error only',
        'ticket_scope': 'initial queued NewSessionTicket processing after handshake',
        'warmed_postgresql_query_measurement': False,
        'strict_postgresql_gate_closed': False,
        'count_vector_fields': list(fields),
        'observed_vectors': {name: [list(value) for value in sorted(values)]
                             for name, values in sorted(vectors.items())},
        'operations_sha256': hashlib.sha256((directory / operations_name).read_bytes()).hexdigest(),
        'summary_sha256': hashlib.sha256((directory / summary_name).read_bytes()).hexdigest(),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    parser.add_argument('--operations', default='operations_v2.csv')
    parser.add_argument('--summary', default='summary_v2.jsonl')
    arguments = parser.parse_args()
    print(json.dumps(verify(arguments.directory, arguments.operations, arguments.summary), indent=2))


if __name__ == '__main__':
    main()
