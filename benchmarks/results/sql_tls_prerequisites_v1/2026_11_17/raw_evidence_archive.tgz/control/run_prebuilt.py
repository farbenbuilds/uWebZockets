#!/usr/bin/env python3
"""Run the exact retained Linux witness without native archives or a compiler."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def run(command, directory, output, environment, records):
    with output.open('w') as stream:
        result = subprocess.run(command, cwd=directory, env=environment,
                                stdout=stream, stderr=subprocess.STDOUT)
    records.append({'command': command, 'exit_code': result.returncode,
                    'log': output.name})
    if result.returncode != 0:
        raise RuntimeError('Command failed; see ' + str(output))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pki_helper', type=Path)
    parser.add_argument('output_directory', type=Path)
    arguments = parser.parse_args()
    source = Path(__file__).resolve().parent
    output = arguments.output_directory.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    binary = source / 'control_witness'
    binary_hash = hashlib.sha256(binary.read_bytes()).hexdigest()
    if binary_hash != '63096685fcef49bcb2b4b6c537ee232cac13297448aaa0f7aeeaf98bf2107766':
        raise ValueError('The retained witness executable differs')
    helper = arguments.pki_helper.resolve(strict=True)
    helper_hash = hashlib.sha256(helper.read_bytes()).hexdigest()
    if helper_hash != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('The PKI helper differs from the retained version')
    output.mkdir()
    environment = dict(os.environ)
    records = []
    pki = output / 'pki'
    try:
        run([str(helper), 'pki', str(pki)], output, output / 'pki_metadata.json', environment, records)
        run([str(binary), str(pki / 'server.pem'), str(pki / 'server.key'),
             str(pki / 'ca.pem'), str(output / 'operations.csv'), str(output / 'summary.jsonl')],
            output, output / 'run.log', environment, records)
        run(['python3', str(source / 'verify_results.py'), str(output), '--operations',
             'operations.csv', '--summary', 'summary.jsonl'], output,
            output / 'verification.json', environment, records)
    finally:
        if pki.exists():
            names = {p.name for p in pki.iterdir()}
            if names - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected PKI contents; refusing cleanup')
            for name in names:
                (pki / name).unlink()
            pki.rmdir()
        (output / 'commands.json').write_text(json.dumps({'commands': records,
            'witness_binary_sha256': binary_hash, 'pki_helper_sha256': helper_hash,
            'native_archives_or_compiler_required': False}, indent=2) + '\n')
    print('PASS: exact retained witness, 12 verified rows and removed private PKI')


if __name__ == '__main__':
    main()
