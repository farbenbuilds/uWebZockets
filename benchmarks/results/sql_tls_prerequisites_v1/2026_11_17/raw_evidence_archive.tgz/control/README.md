# TLS 1.3 control-traffic allocation witness

This isolated public-API witness measures client-side C allocator calls with
the unchanged record-buffer reservation prototype. It does not measure warmed
PostgreSQL queries, change production source or close SQL-ALLOC-002.

The native baseline is exact BoringSSL
`d3bf4795ad5b79d646cddf2fec687da5b9b502db` plus the original four-file reservation
prototype. `native_source.sha256`, `native_input_provenance.json` and
`native_build.log` identify its complete Debug rebuild: all 38 SSL translation
units were built together. `input_provenance.json` records both linked archive
hashes. The protected vendor checkout was not used or changed.

Every row creates fresh TLS 1.3 peers with explicit CA and localhost name
verification, no ALPN, a 1024-byte BIO pair and 257-byte client reads. The client
reserves two record buffers before the trigger: two startup mallocs request
131070 bytes outside the control-traffic intervals. All twelve final rows
negotiate TLS_AES_128_GCM_SHA256 (cipher ID 4865).

| Scenario, three independent pairs each | Client read malloc/free | Requested bytes | Next client write malloc/free |
| --- | --- | --- | --- |
| No tickets or KeyUpdate | 0 / 0 | 0 | Not performed |
| Two initial queued tickets; client cache off, no session callback | 16 / 16 | 2186 | Not performed |
| KeyUpdate NOT_REQUESTED | 6 / 6 | 726 | Not performed |
| KeyUpdate REQUESTED | 15 / 13 | 1604 | 0 / 2 |

All measured calloc/realloc counts are zero. Counts are identical in the three
rounds; raw variation is retained rather than collapsed. The requested-update
write requests zero additional bytes and records two non-null frees.
The source map describes reachable allocation paths; this witness does not
attribute individual numeric counts to specific allocation sites.

Public message callbacks record fixed-size metadata only. Two incoming ticket
messages are observed after the handshake and reservation. For KeyUpdate,
the client receives the required request byte and then successfully decrypts
the exact 4096-byte next-key payload. For REQUESTED, the next client write
reaches the peer with an actual NOT_REQUESTED response and exact reply payload.
Incoming callbacks precede semantic processing, so accepted payloads supply
the acceptance check. Server outgoing queue-time callbacks alone are not used
as delivery proof.

The ticket row flushes tickets initially queued by the server handshake when
the server first writes application data. It is not arbitrary later ticket
minting or a warmed PostgreSQL query. Cache-off is exercised; SSL_OP_NO_TICKET
is not separately measured here. No KeyUpdate is ignored or rejected to avoid
allocation, and no session-callback policy is changed during measurement.

## Accounting and results

`allocation_scope.c` is byte-identical to the original audit interposer. Its
malloc/calloc/realloc/free forwarding and 63-byte self-test are unchanged.
Accounting surrounds each client SSL_read/SSL_write and its immediate
SSL_get_error, including retries. All peer TLS operations and peer callbacks
are outside those intervals. Result validation, logging and teardown also run
outside accounting. The client's
fixed observation callback executes inside the measured client operation and
performs no allocation or I/O.

`operations_v2.csv` retains every call. `summary_v2.jsonl` retains twelve final
rows. `verify_results.py` independently reconciles all 255 operations, phase
totals/retries, accepted bytes and protocol observations. The v1 source and
results remain preliminary records; v2 adds cipher/no-ALPN/profile metadata
outside accounting and matches every v1 measurement field. Only the final v2
executable is retained.

The first counter compile failed because its default global cache path was
read-only. `build-counter.log` preserves that infrastructure failure; the
corrected cache build succeeded. Both witness builds and both runtime versions
exit zero. This is an allocation witness, not a failing production test waived
to pass a gate. Dedicated campaigns were not run.

## Reproduction

For the retained compatible Linux/glibc executable, no native archive or
compiler is required:

```sh
python3 run_prebuilt.py /absolute/path/to/wt-tools \
  /tmp/uwz-control-witness-new-prebuilt-output
```

Choose an absent output directory. The script verifies exact witness executable
SHA-256 `63096685fcef49bcb2b4b6c537ee232cac13297448aaa0f7aeeaf98bf2107766`
and the PKI helper hash before creating outputs. It generates fresh private PKI,
runs twelve rows and reconciles all operations, then removes that PKI. Existing
output directories are refused before any write; recorded result files are
never overwritten.

For source rebuilding,
use the complete lifecycle experiment's unchanged native build, Zig 0.16.0 and
the exact prebuilt PKI helper from the preceding independent-client artifact.
The helper hash is pinned by `replay.py`; Go is not needed. From this directory:

```sh
python3 replay.py /absolute/path/to/lifecycle-experiment \
  /absolute/path/to/wt-tools /tmp/uwz-control-witness-new-output \
  --zig /absolute/path/to/zig
```

Choose an absent output directory. The script verifies native source hashes,
records actual linked native archive hashes, rebuilds the C/C++ witness with
Zig, generates private fixture PKI, runs twelve rows and reconciles all results.
It removes its generated PKI on exit. Rebuilt archives may have different
binary hashes when debug paths change; their actual hashes remain recorded.
Build the entire native library together using the lifecycle experiment's
recorded source-list build rather than swapping individual SSL objects.

The retained source replay in `replay_validation/` and prebuilt replay in
`prebuilt_validation/` each pass another twelve rows and 255-operation
reconciliation. Their private PKI is absent. Native archives,
build caches and generated PKI are not payloads. `payload_files.txt` lists the
retained evidence; `files.sha256` covers it. Git/Python and the prebuilt PKI
helper are external verification tools, not library build requirements.

Tickets, KeyUpdate and other post-handshake allocations still require a native
design before any strict allocation claim. This witness establishes reachable
client-control allocations despite record reservation; it proves neither
PostgreSQL per-query counts nor production interoperability. No PostgreSQL
allocation exception is approved by this evidence.
