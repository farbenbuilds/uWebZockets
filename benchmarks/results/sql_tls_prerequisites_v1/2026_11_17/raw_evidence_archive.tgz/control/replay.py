#!/usr/bin/env python3
"""Build and rerun the public-API witness with an existing complete native build."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def run(command, directory, output, environment, records):
    with output.open('w') as stream:
        result = subprocess.run(command, cwd=directory, env=environment,
                                stdout=stream, stderr=subprocess.STDOUT)
    records.append({'command': command, 'exit_code': result.returncode,
                    'log': output.name})
    if result.returncode != 0:
        raise RuntimeError('Command failed; see ' + str(output))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('pki_helper', type=Path)
    parser.add_argument('output_directory', type=Path)
    parser.add_argument('--zig', default='/tmp/zig-x86_64-linux-0.16.0/zig')
    arguments = parser.parse_args()
    source = Path(__file__).resolve().parent
    native = arguments.native_root.resolve(strict=True)
    output = arguments.output_directory.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    for row in (source / 'native_source.sha256').read_text().splitlines():
        digest, name = row.split('  ', 1)
        if hashlib.sha256((native / name).read_bytes()).hexdigest() != digest:
            raise ValueError('Native source differs: ' + name)
    helper = arguments.pki_helper.resolve(strict=True)
    if hashlib.sha256(helper.read_bytes()).hexdigest() != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('PKI helper differs from the retained version')
    output.mkdir()
    environment = dict(os.environ)
    environment['ZIG_GLOBAL_CACHE_DIR'] = str(output / 'zig-global-cache')
    records = []
    archives = [native / 'native_out/lib/libssl.a', native / 'native_out/lib/libcrypto.a']
    provenance = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in archives}
    pki = output / 'pki'
    try:
        run([str(helper), 'pki', str(pki)], output, output / 'pki_metadata.json', environment, records)
        run([arguments.zig, 'cc', '-c', str(source / 'allocation_scope.c'), '-O0', '-g',
             '-fno-omit-frame-pointer', '-o', str(output / 'allocation_scope.o')],
            output, output / 'build-counter.log', environment, records)
        run([arguments.zig, 'c++', '-std=c++17', '-O0', '-g', '-fno-omit-frame-pointer',
             '-Wall', '-Wextra', '-Werror', '-I', str(native / 'boringssl/include'),
             str(source / 'control_witness.cc'), str(output / 'allocation_scope.o'),
             *[str(p) for p in archives], '-o', str(output / 'control_witness')],
            output, output / 'build-witness.log', environment, records)
        run([str(output / 'control_witness'), str(pki / 'server.pem'), str(pki / 'server.key'),
             str(pki / 'ca.pem'), str(output / 'operations.csv'), str(output / 'summary.jsonl')],
            output, output / 'run.log', environment, records)
        run(['python3', str(source / 'verify_results.py'), str(output), '--operations',
             'operations.csv', '--summary', 'summary.jsonl'], output,
            output / 'verification.json', environment, records)
    finally:
        if pki.exists():
            names = {p.name for p in pki.iterdir()}
            if names - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected PKI contents; refusing cleanup')
            for name in names:
                (pki / name).unlink()
            pki.rmdir()
        (output / 'commands.json').write_text(json.dumps({'commands': records,
            'native_archive_sha256': provenance, 'native_source_changed': False}, indent=2) + '\n')
    print('PASS: rebuilt witness, 12 control rows, verified operation totals and removed private PKI')


if __name__ == '__main__':
    main()
