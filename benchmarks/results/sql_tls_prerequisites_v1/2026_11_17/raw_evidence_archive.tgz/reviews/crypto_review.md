# Independent crypto review: PostgreSQL TLS reservation prerequisites

Date: 2026-11-17. Read-only review of temporary artifacts. No production source, dependency pin, native prototype, test fixture, or benchmark interposer was changed by this reviewer. No build, runtime TLS test, database measurement, smoke, sanitizer, fuzz, security scan, or external cross-model campaign was run by this reviewer. Cross-model skipped: non-interactive context.

## Verdict

No confirmed correctness or security defect was found in the documented opt-in reservation path, its final 16-case lifecycle proof, or the separate four-row public-API control witness. This verdict covers the exact artifacts and hashes below. It does not approve production integration or close SQL-ALLOC-002.

The control witness is affirmative evidence that retaining the two record buffers alone does not satisfy a strict all-client-TLS-I/O allocation gate. Valid tickets and KeyUpdate cause measured client allocator activity after reservation. No PostgreSQL allocation exception has been approved; SQL-ALLOC-001 applies only to SQLite.

## Artifacts and provenance verified

- Original candidate: `/tmp/uwz-pg-tls-retention-20261117/boringssl`, pinned baseline `d3bf4795ad5b79d646cddf2fec687da5b9b502db` plus the original four-file reservation patch.
- Lifecycle copy: `/tmp/uwz-pg-tls-lifecycle-20261117/boringssl`. Independently compared SHA256 inventories of both complete trees, excluding any `.git` directory: 8709 files each, zero missing, extra, or differing files. The generated `gen/sources.json` contains all 38 SSL translation units. The 6/6 native build output was inspected; runtime builds were not repeated.
- The candidate four-file SHA256 values match original provenance and the lifecycle copy:
  - `include/openssl/ssl.h`: `d456d6ec611a3dd9f45fd2b701527875c66e589326cb158f8270d1146a959e2e`
  - `ssl/internal.h`: `bdc63544965dfd787176a592a600ef0f86ad99aaacf5e204a4c59528bd691c37`
  - `ssl/ssl_buffer.cc`: `21f4621ef3fbed496a750d4723b450d8c6c83d47a74337801ab31b99c488bb38`
  - `ssl/ssl_lib.cc`: `6b4629af106bb53182465d8a6b8baf1dc56591594872333791296f008bd84827`
- Both witnesses link the lifecycle archives. Independently hashed archives match their recorded provenance:
  - `libssl.a`: `8757a7289d30a7e5a0d22fccb403e5088afafb41b588384be85118af9015ec24`
  - `libcrypto.a`: `2964fce97d81bbf85d4430bb862cd01440c6b298feb6e715b5a52b1d52223210`
- Lifecycle final source `lifecycle_test.cc`: `3241b0a8089e5115c76329595cdebb668ce7ac4bb3baada24fa02fd2ab2bcdbf`.
- Lifecycle observer `lifecycle_alloc.c`: `6a0b407c0609d8a902e7e4de1232374e7db9cc9b92d2e709875138c0ea9e6f6d`.
- Lifecycle header `lifecycle_alloc.h`: `0eb27d7cafdb239ad72b6c73dc67edf78315c813759051d2ec89af5b3a52fa7a`.
- Lifecycle binary: `349bab12067d5f2a50f86a6ee25c643e1c6d83e5a54a31977002f9115478ede0`.
- Public witness `control_witness.cc`: `dea11adc1556d17da8cef385b3a078e0fd674ad80cde879cf75f071113ae584b`.
- Public witness `allocation_scope.c`: `afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac`, matching the original all-C measurement interposer. The separate lifecycle fault observer does not replace it.

## Lifecycle conclusions

References in this section are under `/tmp/uwz-pg-tls-lifecycle-20261117/`.

1. The API contract explicitly requires destruction after every failed reservation and documents possible partial reservation (`boringssl/include/openssl/ssl.h:245`). The implementation rejects unsupported/pending states before either reserve call; RX and TX reserve use short-circuit evaluation (`boringssl/ssl/ssl_lib.cc:751`). The second-allocation failure can therefore retain RX until `SSL_free`, as documented. The failure fixtures do not continue application I/O after this failure (`lifecycle_test.cc:233`).
2. Positive pairs pin both minimum and maximum to TLS 1.3, load an explicit CA, enable peer verification, set SNI and the expected `localhost` name, and require the verified handshake result and a peer chain (`lifecycle_test.cc:60`, `:83`). This does not silently count an unverified handshake as a positive case.
3. The first and second 65535-byte malloc failures are armed only after the verified idle handshake. The observer uses fixed thread-local records and forwards all malloc/calloc/realloc/free calls to libc; it reads the full tracked allocation before the actual libc free (`lifecycle_alloc.c:39`, `:87`). Fresh tracked bytes are initialized nonzero to make the full cleanup check meaningful. The observer proves cleanup of the specifically tracked reservation allocations, not absence of leaks throughout SSL, BoringSSL, libc, or the process heap.
4. Real public TLS operations establish pending decrypted plaintext, incomplete encrypted record input, and BIO-blocked output (`lifecycle_test.cc:272`, `:287`, `:307`). No private state is assigned to fabricate these cases. Read-only private snapshots observe pointer identities, sizes, capacities, pending-write metadata and data hashes (`:137`). Rejected calls do not mutate the observed data state or perform reservation allocations (`:163`). Error-queue changes are intentionally allowed and checked.
5. Each rejected pending-state connection is destroyed. Separate fresh valid-traffic controls demonstrate payload delivery; there is no attempted continuation after rejection (`lifecycle_test.cc:322`).
6. The completed TLS 1.2 fixture is a negative eligibility case only (`lifecycle_test.cc:332`). The DTLS and QUIC fixtures are configured-only rejection checks (`:342`), not completed DTLS/QUIC handshake or protocol integration coverage. Their labels must retain that distinction.
7. `SSL_clear` release and premature reservation rejection are isolated from the successful clear/re-handshake path. The reuse case clears the session, attaches fresh BIOs, performs another verified nonresumed TLS 1.3 handshake, reserves again, exchanges seven payload lengths through 1024-byte BIO backpressure and 257-byte plaintext reads, and checks all eight allocation epochs are eventually cleansed and forwarded to actual libc free (`lifecycle_test.cc:375`, `:388`).
8. Independently read `final_runs/results.json` and checked all 16 recorded exit codes are zero; every stdout/stderr hash, source hash, native archive hash and binary hash matches the current final artifact. All final parsed results have `pass=true`, zero live tracked reservations and zero cleanse failures. Initial top-level logs predate the final snapshot refinement and are not the definitive records.

Inherited buffer/record proof source and logs were also inspected. The buffer destructor observer checks bytes then calls actual libc free (`inherited/buffer_allocation_scope.c:52`); no empty deallocator is used. Those proofs remain limited to their stated buffer capacity/alignment/compaction and verified TLS record cases.

## Public control witness conclusions

References in this section are under `/tmp/uwz-pg-tls-control-witness-20261117/`.

The source uses public BoringSSL APIs only. Fixed message callbacks record actually delivered ticket and KeyUpdate messages without allocations (`control_witness.cc:95`). Both endpoints are pinned to TLS 1.3; explicit CA trust, peer verification, SNI, hostname checking, negotiated version and successful verification are required (`:125`). The client uses `SSL_SESS_CACHE_OFF` with a null new-session callback.

Each active interval wraps one client `SSL_read` or `SSL_write` and its immediate `SSL_get_error` where applicable (`control_witness.cc:184`). Peer TLS operations, payload verification, aggregation and logging occur outside that interval (`:222`, `:253`). Callback bookkeeping inside the TLS call is fixed-size and allocation-free. No server allocator activity is attributed to the client counter.

Independently reconciled every row in `operations_v1.csv` against `summary_v1.jsonl`: 255 client operations, 12 scenario rows, phase allocator totals, operation indices, phase operation counts and retry counts all agree. The same results occur in three independent fresh-pair rounds:

| Synthetic client control interval | malloc | free | Requested bytes |
| --- | ---: | ---: | ---: |
| Ticket-free application-data control, client reads | 0 | 0 | 0 |
| Two initially queued tickets, client cache OFF, client reads | 16 | 16 | 2186 |
| Peer KeyUpdate NOT_REQUESTED, client reads | 6 | 6 | 726 |
| Peer KeyUpdate REQUESTED, client reads | 15 | 13 | 1604 |
| Requested-update response, next client writes | 0 | 2 | 0 |

All calloc and realloc counts are zero. Every row separately records two startup reservation malloc calls requesting 131070 bytes; startup reservation is outside these read/write totals. Every row validates all 4096 payload bytes. Requested-update rows additionally validate the response payload and the peer's receipt of a NOT_REQUESTED update. This supports accepted control processing and key continuity rather than merely observing a message header.

The ticket row flushes tickets initially queued by the server handshake after client reservation. It is not an arbitrary later ticket-minting API. The witness does not assert counts for PostgreSQL cached queries, repeated control messages on one connection, every cipher, every error, or production interoperability.

The core source-level explanation was independently spot-checked in the original pinned candidate: `ssl/tls13_client.cc:1226` creates a ticket session before the cache callback decision; `ssl/tls13_both.cc:728` always rotates read keys for valid KeyUpdate and `:733` queues a required response; `crypto/fipsmodule/tls/kdf.cc.inc:157` allocates the HKDF label through CBB; `ssl/s3_both.cc:455` creates handshake-assembly storage, which is released after consumed post-handshake messages at `:550`. None of these files differs between the original and lifecycle native trees.

## Remaining work and limits

- The production strict total-allocation gate remains unsatisfied. Ordinary successful-query zero counts are insufficient to claim all post-handshake TLS I/O is allocation-free.
- Native maintenance, supported integration and production SQL readiness/accounting boundaries remain unresolved. This report does not authorize a pin change, protected vendor edit, maintained-dependency patch, or PostgreSQL policy exception.
- Repeated/fragmented controls, fatal and clean-close controls, failed-query teardown/reconnect/readiness boundaries, alternative cipher/target behavior and production PostgreSQL interoperability remain outside these proofs.
- Dedicated smoke, security, sanitizer, fuzz and scan campaigns remain user-deferred and were not run. Ordinary test evidence here cannot replace them.
- Final archive packaging, omission of private fixture material, replay documentation and any later edited summary text need their own final artifact checks. This report binds to the exact source/data hashes above, not to future packaging edits.
- No repository-wide suite or production formatting/conventions/version checks were run by this read-only reviewer; production source was not changed by this reviewer.

Review policy and narrow skills read: `AGENTS.md`, `CODING_CONVENTION.md`, `CONTRIBUTE.md`, `CODEBASE.md` TLS section, `SECURITY.md`, `CI_CD_PIPELINE.md`; code-review-and-quality, doubt-driven-development, source-driven-development, security-and-hardening and the applicable Zig/C skills. The graph query preceded source exploration. No nested reviewers or external CLI were invoked.
