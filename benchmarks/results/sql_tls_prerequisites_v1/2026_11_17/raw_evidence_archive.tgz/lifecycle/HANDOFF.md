# Record-buffer prototype lifecycle prerequisites

This experiment preserves the exact four-file BoringSSL prototype from
sql_tls_retention_v1/2026_11_17. No production source, dependency pin, TLS
policy, native fork or library build requirement changed.

The baseline pin is d3bf4795ad5b79d646cddf2fec687da5b9b502db, package hash
N-V-__8AAA5Ieg5843crc8uXWdNhmmfStwJqA-9TknJSx3_n. The new candidate tree
matches all 8709 entries of the original prototype. native_source_inventory.json
records every input; source_identity.json records four candidate-source
hashes, complete native archives, helper executables, unchanged inherited
inputs and harness sources. All 38 SSL translation units and crypto were
rebuilt together with the project's Zig 0.16.0 native source-list builder.
The final helper rebuild produces byte-identical archives.

## Results and ownership

final_runs/results.json contains 16 exact commands, terminal exit codes,
stdout/stderr hashes and results. All 16 pass:

- First reservation malloc failure: one attempted allocation, none owned.
- Second failure: two attempts and one retained RX allocation; mandatory
  SSL_free cleanses and actually frees it once.
- Repeated successful reservation: four existing pair reservations persist,
  with no measured malloc/calloc/realloc/non-null-free calls or requested bytes.
- Unread plaintext, incomplete encrypted record and BIO-blocked write: actual
  TLS/BIO operations create each condition. Reservation rejects before any
  reserved-buffer allocation, preserving observed pointers, cursors, bytes and
  write ownership. Separate valid-traffic controls complete exact payloads.
- Null, unfinished TLS, completed TLS 1.2 and publicly configured DTLS/QUIC
  objects reject. TLS 1.2 is an isolated negative fixture, not production
  support. Configured DTLS/QUIC exercise combined eligibility rejection, not
  completed handshakes or isolated proof that each individual guard is required.
- SSL_clear frees and cleanses all old reservations. One control checks
  premature reservation rejection and then frees the objects. A separate
  control attaches fresh BIOs and performs another verified, non-resumed TLS 1.3
  handshake without an intervening failed reservation. Fresh reservations
  exchange seven record lengths in both directions under 1024-byte BIO and
  257-byte read bounds, with zero measured allocator calls in all 14 windows.
  Eight allocation epochs are actually freed and cleansed across clear/reuse.

lifecycle_alloc.c is a separate test-only glibc interposer. Its fault arm
targets the first or second 65535-byte reservation only after a verified idle
handshake. Successfully tracked allocations start nonzero, and every tracked
destructor free is inspected before forwarding to real __libc_free. Fixed
per-thread records support reused addresses across allocation epochs without
allocating bookkeeping. This establishes tracked reservation cleanup, not a
process-wide leak oracle. Injection results are not ordinary zero-allocation
measurements. The original query probe and interposer are retained unchanged.

Both inherited ordinary proofs also pass against the newly rebuilt archives:
the 256 maximum-capacity/alignment/compaction loops and full-allocation
destructor cleansing, plus seven record sizes through 16384 bytes over verified
TLS 1.3 under short reads/backpressure with zero measured C allocator calls.
See inherited_results.json and the two raw logs.

Initial fixture runs remain separate from final results. A compile setup
failure involved unmodified upstream private-header parameter warnings and a
const accessor mismatch. Own-source -Wall -Wextra -Werror remained enabled;
external headers use -isystem. The final snapshot avoids accessing an absent
empty buffer. No native defect was found or native source changed. The later
recorder refinement only makes source/archive provenance optional for prebuilt
replay; case execution and validation are unchanged. trial_classification.json
distinguishes these setup steps from actual API results.

## Offline prebuilt replay

Retain lifecycle_test, buffer_test, tls_pair_test, replay.py,
run_cases.py and source_identity.json. No compiler, native archive or source
tree is needed to run these existing executables. They require the recorded
compatible Linux/glibc host and CPU/ABI; they are not portable binaries.

Supply the separately retained wt-tools PKI helper, exact SHA-256
531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9.
It is an external verification input, not a library build dependency.
From a copied/extracted evidence directory, run:

    python3 replay.py --pki-tool /absolute/path/to/wt-tools \
      --output /tmp/uwz-tls-lifecycle-new-replay

Choose an absent output directory outside the retained evidence tree. The
wrapper verifies executable hashes, generates fresh private PKI, runs all 16
cases and both inherited helpers, and removes only its three private PKI files
and directory in finally. Existing output paths are refused before creation;
archived final_runs and other recorded outputs are never overwritten. All
new commands, statuses and hashes are written beneath the new output. Root
owns validation of this exact delivery command from its final copied layout.

## Source rebuild

Use the exact unmodified baseline package above. prepare_source.py verifies
the entire baseline file set/hashes before copying it to an absent destination,
then copies the four retained prototype files into that new experiment only.
It never edits a cached input or invokes patch. A candidate-source input is
also accepted with explicit --source-kind candidate. The actual baseline
recovery passed all 8709 entries; existing-destination and wrong-source-kind
refusals occur before destination writes.

    python3 prepare_source.py /path/to/exact-boringssl-package ./boringssl
    /path/to/zig build -Doptimize=Debug --cache-dir /tmp/uwz-new-native-cache \
      -p native_out -j2 --summary all

Always rebuild all SSL translation units together. Do not replace one object
against another internal layout. build_lifecycle_command.json and
build_inherited_commands.json retain exact direct zig cc/zig c++ fixture
compile/link commands; substitute your Zig 0.16.0 path when necessary. Own C/C++
warnings remain strict. The original native build log and final cached helper
build log retain complete terminal summaries. Original archive hashes are
provenance rather than a required prebuilt runtime input: Debug archive bytes
may depend on source paths.

## Limits

Reservation failure permits partial ownership and requires SSL_free; these
tests do not impose rollback or continue I/O after failure. Positive pairs
verify the CA chain and localhost name. Private state is read for snapshots,
never written to manufacture pending TLS conditions. Tickets are disabled in
these record fixtures.

Tickets/session creation, KeyUpdate, pending flights, alert/error/reconnect
paths, broader PostgreSQL query allocation, production startup integration and
native maintenance/adoption remain separate. The earlier 256-query result is
not rerun or expanded by this lifecycle proof. SQL-ALLOC-002 remains open;
SQLite's approved exception does not authorize PostgreSQL allocations.
No dedicated smoke/security/sanitizer/fuzz/scan campaign ran.
