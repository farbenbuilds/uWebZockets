#!/usr/bin/env python3
"""Copy an exact native input, then apply the retained prototype source snapshot."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil


def main():
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-kind', choices=['baseline', 'candidate'], default='baseline')
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    arguments = parser.parse_args()
    source = arguments.source.resolve(strict=True)
    destination = arguments.destination.absolute()
    if destination.exists() or destination.is_symlink():
        raise ValueError('Choose an absent native destination')
    if destination.resolve().is_relative_to(source):
        raise ValueError('Native destination must not be inside its source')
    provenance = json.loads((base / 'input_provenance.json').read_text())
    inventory = json.loads((base / 'native_source_inventory.json').read_text())
    expected_names = {entry['path'] for entry in inventory['entries']}
    actual_names = {
        path.relative_to(source).as_posix()
        for path in source.rglob('*') if path.is_file() or path.is_symlink()
    }
    if actual_names != expected_names:
        raise ValueError('Native input file set differs from the pinned experiment')
    for entry in inventory['entries']:
        relative = PurePosixPath(entry['path'])
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('Unsafe retained native path')
        path = source / entry['path']
        if 'symlink' in entry:
            if not path.is_symlink() or os.readlink(path) != entry['symlink']:
                raise ValueError('Native symlink differs: ' + entry['path'])
            continue
        expected = entry['sha256']
        if arguments.source_kind == 'baseline':
            expected = provenance['source_baseline_sha256'].get(entry['path'], expected)
        if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('Native source checksum differs: ' + entry['path'])
    snapshots = []
    for name, digest in provenance['source_candidate_sha256'].items():
        payload = (base / 'candidate_source' / name).read_bytes()
        if hashlib.sha256(payload).hexdigest() != digest:
            raise ValueError('Retained prototype source differs: ' + name)
        snapshots.append((name, payload))
    shutil.copytree(source, destination, symlinks=True)
    for name, payload in snapshots:
        (destination / name).write_bytes(payload)
    print('Prepared exact candidate source from ' + arguments.source_kind +
          ' input; ' + str(len(expected_names)) + ' entries verified.')


if __name__ == '__main__':
    main()
