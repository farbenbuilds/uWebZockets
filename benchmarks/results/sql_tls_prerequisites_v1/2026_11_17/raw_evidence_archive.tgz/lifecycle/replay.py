#!/usr/bin/env python3
"""Replay the retained helpers into a new directory and remove private fixture PKI."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pki-tool', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    arguments = parser.parse_args()
    output = arguments.output.absolute()
    tool = arguments.pki_tool.resolve(strict=True)
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent replay output directory')
    if output.resolve().is_relative_to(base):
        raise ValueError('Keep replay output outside the retained evidence tree')
    if digest(tool) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('The verified PKI helper checksum differs')
    identity = json.loads((base / 'source_identity.json').read_text())
    for name, entry in identity['binaries'].items():
        if digest(base / name) != entry['sha256']:
            raise ValueError('The retained helper checksum differs: ' + name)
    output.mkdir(parents=True, mode=0o700)
    pki = output / 'private_pki'
    rows = []
    try:
        with (output / 'pki_metadata.json').open('w') as stdout, \
             (output / 'pki.stderr').open('w') as stderr:
            subprocess.run([str(tool), 'pki', str(pki)],
                           stdout=stdout, stderr=stderr, check=True)
        with (output / 'lifecycle_driver.log').open('w') as stdout:
            subprocess.run([
                sys.executable, str(base / 'run_cases.py'),
                '--pki', str(pki), '--output', str(output / 'cases'),
            ], stdout=stdout, stderr=subprocess.STDOUT, check=True)
        commands = [
            [str(base / 'buffer_test')],
            [str(base / 'tls_pair_test'), str(pki / 'server.pem'),
             str(pki / 'server.key'), str(pki / 'ca.pem')],
        ]
        for command in commands:
            name = Path(command[0]).name
            stdout = output / (name + '.stdout')
            stderr = output / (name + '.stderr')
            with stdout.open('wb') as out, stderr.open('wb') as err:
                result = subprocess.run(command, stdout=out, stderr=err)
            rows.append({
                'name': name, 'command': command, 'exit_code': result.returncode,
                'stdout_sha256': digest(stdout), 'stderr_sha256': digest(stderr),
            })
            if result.returncode != 0:
                raise RuntimeError('Inherited helper failed: ' + name)
    finally:
        if pki.exists():
            names = {'ca.pem', 'server.pem', 'server.key'}
            if any(path.name not in names for path in pki.iterdir()):
                raise ValueError('Unexpected private fixture output; refusing broad cleanup')
            for name in names:
                path = pki / name
                if path.exists() or path.is_symlink():
                    path.unlink()
            pki.rmdir()
    (output / 'results.json').write_text(json.dumps({
        'complete': True, 'lifecycle_cases': 16, 'inherited_helpers': rows,
        'private_pki_removed': not pki.exists(),
        'archived_evidence_directory_modified': False,
    }, indent=2) + '\n')
    print('PASS: 16 lifecycle cases and both inherited helpers; private PKI removed.')


if __name__ == '__main__':
    main()
