# Outgoing native handoff

Final source commit: a775b461e8e279d1a5d2058c0a2ea06a0c3f2fa7.
Final cohort: 67/67 in Debug, ReleaseSafe and ReleaseFast, 16/16 steps each.
The previous51 cases and assertions are unchanged; sixteen new cases cover
outgoing creation, direction semantics, callback reentry, real MAX_STREAMS
blocking/recovery, reservation rollback, half controls, refusal and retirement.

Project_v2 retains257 inputs matching the implementation commit. Project_v1
retains the actual receive-credit product RED; the only changed Root input
is engine.zig's bounded WT local-BIDI receive window. Exact39 fixture inputs
for focused RED/GREEN are retained separately under evidence/regression_inputs.
Final39 fixture inputs are hashed separately in fixture/provenance.

The original client's zero remote-BIDI byte credit correctly caused native
WouldBlock. New pre-engine profiles enable byte credit or bounded count credit;
all earlier variants retain their settings. Initial mismatch logs are historical
observations. A new premature pool-empty-after-I/O-drain assertion was corrected
to test through actual native destruction, preserving production drain asserts.
No blanket replay claim is made for every intermediate historical driver.

New cases manually service the engine. Native OOM/INVALID/UNSUPPORTED/contract
violations and actual OS submission failures are unforced. Root wake return and
generation-counter exhaustion are explicit test seams. Independent clients,
positive/multi-session flow, publication and production activation stay open.
Dedicated smoke/security/sanitizer/fuzz campaigns remain user-deferred.

No live native build remains. Root owns final relocated replay, archive,
outer documentation, checksums and publication.
