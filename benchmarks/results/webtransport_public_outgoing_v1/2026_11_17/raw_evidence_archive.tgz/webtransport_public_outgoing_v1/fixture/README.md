# Isolated outgoing WebTransport functional proof

The fixture exercises the actual App, UDP transport, TLS and lsquic proposal.
Its final cohort contains 51 unchanged receive/transmit/half-control cases and
16 outgoing creation cases. Existing limits and assertions remain unchanged.
This scratch build's test target runs these functional cases and does not run
the repository's dedicated C smoke target.

Final project_v2 is equivalent to implementation commit
`a775b461e8e279d1a5d2058c0a2ea06a0c3f2fa7` for all 257 retained source/build
inputs. Separate manifests hash those inputs and 39 fixture/build/test files.
The replay script checks both inventories before building.

## Replay

Use Zig 0.16.0, the offline packages selected by build.zig.zon, native005
`005ab244169f269689e511d6b77dd2187e318df1`, and XEV proposal
`5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`. Native source/history is retained at
`benchmarks/results/webtransport_child_lifecycle_v1/2026_11_16/raw_evidence_archive.tgz`
(SHA-256 `3e27ce7137f3791cf977d0b4c83bee4ea72c873b1af125c3a13616695b2a8418`).
This archive does not duplicate those trees or offline packages. The native
ls-hpack gitlink is `cf0f70dd10b352194c97448eb5d00b4aa484f531`; the compiled
ls-hpack package is `fda48e02491d865cce00612be8cc10c2622b8e55`. Actual ls-qpack
and its gitlink both use `91567706c41c0d97ab8dc576873ecd472d7869fa`.

```sh
UWZ_ZIG=/path/to/zig-0.16.0 \
UWZ_LSQUIC_SOURCE=/path/to/native005 \
UWZ_LIBXEV_SOURCE=/path/to/xev5b2c \
UWZ_PACKAGE_DIR=/path/to/offline-zig-packages \
UWZ_CACHE_DIR=/path/to/disposable-cache \
ZIG_GLOBAL_CACHE_DIR=/path/to/disposable-global-cache \
sh replay.sh Debug
```

Select Debug, ReleaseSafe or ReleaseFast. Loopback socket permission is required.
Native C/C++ is compiled with Zig. No production pin or fork is published.

## Cases and profiles

Outgoing UNI sends binary bytes/FIN without RX callbacks; BIDI receives payload
and EOF with zero receive-prefix subtraction. Creation from session/open/data/
writable callbacks never invokes local admission inline. Pool, generation,
wake and handle failures preserve Root reservations; default zero remote-BIDI
byte credit produces a genuine native WouldBlock without queuing work.

New pre-engine profiles enable 65536 remote-BIDI bytes, or combine that window
with two BIDI streams or four total UNI streams. The latter leaves one WT UNI
after three HTTP critical streams. Tests exhaust count credit, observe actual
WouldBlock, close streams, and recover through real peer MAX_STREAMS before an
explicit new creation succeeds. No private credit grants or native fields are
mutated. Existing client variants retain their previous settings.

Additional cases verify local UNI reliable reset-prefix publication and exact
mapped code, independent BIDI half controls, declined admission without owned
close, shutdown before typed publication, and parent-session retirement. The
new shutdown case performs actual native destruction before checking for late
App notifications; production pool/lease drain assertions remain active.

## Regression and limits

The first BIDI attempts used the client's default zero remote-BIDI byte window;
those initial failures are profile mismatches, not Root product failures.
After enabling peer byte credit, actual peer replies exposed Root advertising
zero local-BIDI receive credit. Exact focused RED/GREEN fixture inputs are in
`evidence/regression_inputs`: use Root project_v1 for RED and project_v2 for
GREEN with the BIDI filter documented there. Root v2 adds only the bounded
WT-bound local-BIDI receive window relative to v1. Original snapshots and logs
are retained. Other intermediate logs are historical observations, not a claim
that every earlier driver is retained unchanged.

An intermediate new shutdown assertion expected empty native pools after only
I/O drain. That premise was corrected: native destruction owns final close and
lease release. The final test checks no admission/owned-close notification
through actual destruction and leaves production drain assertions unchanged.

New cases manually service the engine; only the inherited TX wake case proves
loop-only progress. Native allocation/INVALID/UNSUPPORTED/contract-violation
returns, actual OS submission failures and non-Linux runtime were not forced.
Root generation exhaustion and Binding.wake return faults are explicit test
seams. Independent draft16 clients, positive/multi-session flow and production
activation remain outside this proof. Smoke/security/sanitizer/fuzz campaigns
remain user-deferred. No native allocation-free claim is made.
