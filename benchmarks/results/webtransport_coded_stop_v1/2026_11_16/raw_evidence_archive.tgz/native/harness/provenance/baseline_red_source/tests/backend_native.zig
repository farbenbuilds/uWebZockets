const std = @import("std");
const backend = @import("backend");
const c = @import("c");
const testing = std.testing;

const ordinary_limits: backend.LocalLimits = .{
    .initial_max_data = 4096,
    .initial_max_streams_bidi = 2,
    .initial_max_streams_uni = 3,
};

/// Fixed driver input for checking both child directions and endpoint roles.
const ChildCase = struct {
    sender: c.enum_uwz_wt_role,
    receiver: c.enum_uwz_wt_role,
    direction: backend.Direction,
};

/// Stack-owned evidence consumed only during the synchronous fixture constructor.
const ConfigurationObservation = struct {
    limits: backend.LocalLimits,
    calls: u32 = 0,
    default_fields_checked: u32 = 0,
    preserved_settings_checked: u32 = 0,
    preserved_callbacks_checked: u32 = 0,
};

fn configure_native(context: ?*anyopaque, settings: [*c]c.lsquic_engine_settings, callbacks: [*c]c.lsquic_stream_if) callconv(.c) c_int {
    if (context == null or settings == null or callbacks == null) return -1;
    const observation: *ConfigurationObservation = @ptrCast(@alignCast(context.?));
    const native_settings: *c.lsquic_engine_settings = settings;
    const native_callbacks: *c.lsquic_stream_if = callbacks;
    observation.calls += 1;
    if (native_settings.es_webtransport.enabled != 0 or
        native_settings.es_webtransport.initial_max_data != 0 or
        native_settings.es_webtransport.initial_max_streams_bidi != 0 or
        native_settings.es_webtransport.initial_max_streams_uni != 0 or
        native_settings.es_datagrams != 0 or native_settings.es_reset_stream_at != 0)
    {
        return -1;
    }
    observation.default_fields_checked += 1;
    var expected_settings = native_settings.*;
    expected_settings.es_datagrams = 1;
    expected_settings.es_reset_stream_at = 1;
    expected_settings.es_webtransport = .{
        .enabled = 1,
        .initial_max_data = observation.limits.initial_max_data,
        .initial_max_streams_bidi = observation.limits.initial_max_streams_bidi,
        .initial_max_streams_uni = observation.limits.initial_max_streams_uni,
    };
    const callbacks_before = native_callbacks.*;
    const settings_callback = native_callbacks.on_h3_settings orelse return -1;
    const child_callback = native_callbacks.on_webtransport_stream orelse return -1;
    if (backend.configure(native_settings, observation.limits) != .ok) return -1;
    if (!std.meta.eql(expected_settings, native_settings.*)) return -1;
    observation.preserved_settings_checked += 1;
    if (!backend.install_callbacks(native_callbacks, .{
        .settings = settings_callback,
        .child = child_callback,
    })) return -1;
    if (!std.meta.eql(callbacks_before, native_callbacks.*)) return -1;
    observation.preserved_callbacks_checked += 1;
    return 0;
}

fn create_fixture(limits: backend.LocalLimits) !*c.struct_uwz_wt_fixture {
    var configured: ConfigurationObservation = .{ .limits = limits };
    const fixture = c.uwz_wt_fixture_create(configure_native, &configured) orelse return error.FixtureInitialization;
    errdefer c.uwz_wt_fixture_destroy(fixture);
    try testing.expectEqual(@as(u32, 2), configured.calls);
    try testing.expectEqual(@as(u32, 2), configured.default_fields_checked);
    try testing.expectEqual(@as(u32, 2), configured.preserved_settings_checked);
    try testing.expectEqual(@as(u32, 2), configured.preserved_callbacks_checked);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_connect(fixture));
    return fixture;
}

fn endpoint_snapshot(fixture: *c.struct_uwz_wt_fixture, role: c.enum_uwz_wt_role) !c.struct_uwz_wt_endpoint_snapshot {
    var snapshot: c.struct_uwz_wt_endpoint_snapshot = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_endpoint_snapshot(fixture, role, &snapshot));
    return snapshot;
}

fn stream_snapshot(fixture: *c.struct_uwz_wt_fixture, role: c.enum_uwz_wt_role, id: u64) !c.struct_uwz_wt_stream_snapshot {
    var snapshot: c.struct_uwz_wt_stream_snapshot = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_stream_snapshot(fixture, role, id, &snapshot));
    return snapshot;
}

fn expect_unclassified(stream: ?*c.lsquic_stream) !void {
    var info: backend.StreamInfo = .{
        .session_id = 0x123456789,
        .send_prefix_size = 17,
        .receive_prefix_size = 19,
        .association = .child,
        .direction = .uni,
        .initiator = .local,
    };
    const before = info;
    try testing.expectEqual(backend.QueryResult.pending, backend.read_stream(stream, &info));
    try testing.expectEqualDeep(before, info);
}

fn expect_no_child(fixture: *c.struct_uwz_wt_fixture, role: c.enum_uwz_wt_role, session_id: u64, expected: backend.CreateResult) !void {
    const before = try endpoint_snapshot(fixture, role);
    const conn = c.uwz_wt_fixture_connection(fixture, role);
    try testing.expectEqual(expected, backend.create_child(conn, session_id, .bidi));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_pump(fixture, 4));
    const after = try endpoint_snapshot(fixture, role);
    try testing.expectEqual(before.stream_callbacks, after.stream_callbacks);
    try testing.expectEqual(before.typed_callbacks, after.typed_callbacks);
}

fn accept_parent(fixture: *c.struct_uwz_wt_fixture) !void {
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_open_connect(fixture));
    const client = c.uwz_wt_fixture_stream(fixture, c.UWZ_WT_CLIENT, 0);
    try testing.expect(client != null);
    try expect_unclassified(client);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_await_headers(fixture, c.UWZ_WT_SERVER));
    const server = c.uwz_wt_fixture_stream(fixture, c.UWZ_WT_SERVER, 0);
    try testing.expect(server != null);
    try expect_unclassified(server);
    try expect_no_child(fixture, c.UWZ_WT_SERVER, 0, .no_session);
    try testing.expectEqual(backend.CreateResult.ok, backend.accept_connect(server));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_send_success(fixture));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_await_headers(fixture, c.UWZ_WT_CLIENT));
    try expect_unclassified(client);
    try testing.expectEqual(backend.CreateResult.ok, backend.accept_connect(client));
    try testing.expectEqual(backend.CreateResult.ok, backend.accept_connect(server));
    try testing.expectEqual(backend.CreateResult.ok, backend.accept_connect(client));

    for ([_]c.enum_uwz_wt_role{ c.UWZ_WT_CLIENT, c.UWZ_WT_SERVER }) |role| {
        var info: backend.StreamInfo = .{};
        const stream = c.uwz_wt_fixture_stream(fixture, role, 0);
        try testing.expectEqual(backend.QueryResult.ok, backend.read_stream(stream, &info));
        try testing.expectEqualDeep(backend.StreamInfo{
            .initiator = if (role == c.UWZ_WT_CLIENT) .local else .peer,
        }, info);
        const snapshot = try stream_snapshot(fixture, role, 0);
        try testing.expectEqual(@as(c_uint, 1), snapshot.header_callbacks);
        try testing.expectEqual(@as(c_uint, 1), snapshot.headers_valid);
        try testing.expectEqual(@as(c_uint, 0), snapshot.typed_callbacks);
        try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_enable_reads(stream));
    }
}

fn expect_child(info: backend.StreamInfo, direction: backend.Direction, initiator: backend.Initiator) !void {
    try testing.expectEqualDeep(backend.StreamInfo{
        .session_id = 0,
        .association = .child,
        .direction = direction,
        .initiator = initiator,
        .send_prefix_size = if (initiator == .local) 3 else 0,
        .receive_prefix_size = if (initiator == .peer) 3 else 0,
    }, info);
}

fn create_and_observe_child(fixture: *c.struct_uwz_wt_fixture, child_case: ChildCase) !void {
    const before = try endpoint_snapshot(fixture, child_case.sender);
    const conn = c.uwz_wt_fixture_connection(fixture, child_case.sender);
    try testing.expectEqual(backend.CreateResult.ok, backend.create_child(conn, 0, child_case.direction));
    const after = try endpoint_snapshot(fixture, child_case.sender);
    try testing.expectEqual(before.stream_callbacks + 1, after.stream_callbacks);
    const outgoing = c.uwz_wt_fixture_last_child(fixture, child_case.sender) orelse return error.MissingNativeChild;
    const id = c.lsquic_stream_id(outgoing);
    var local_info: backend.StreamInfo = .{};
    try testing.expectEqual(backend.QueryResult.ok, backend.read_stream(outgoing, &local_info));
    try expect_child(local_info, child_case.direction, .local);

    const payload = [_]u8{ 0x41, 0, 0xff, 'r', 'a', 'w' };
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_write(outgoing, &payload, payload.len, 0));
    var step: u32 = 0;
    while (step < c.UWZ_WT_MAX_STEPS) : (step += 1) {
        try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_pump(fixture, 1));
        const incoming = c.uwz_wt_fixture_stream(fixture, child_case.receiver, id);
        if (incoming == null) continue;
        const received = try stream_snapshot(fixture, child_case.receiver, id);
        if (received.received != payload.len) continue;
        var peer_info: backend.StreamInfo = .{};
        try testing.expectEqual(backend.QueryResult.ok, backend.read_stream(incoming, &peer_info));
        try expect_child(peer_info, child_case.direction, .peer);
        try testing.expectEqual(@as(c_uint, 1), received.new_callbacks);
        try testing.expectEqual(@as(c_uint, 1), received.typed_callbacks);
        try testing.expectEqual(@as(c_int, c.LSQUIC_WTS_OK), received.typed_info_result);
        try testing.expectEqual(@as(c_uint, 0), received.header_callbacks);
        try testing.expectEqual(@as(c_uint, 0), received.reset_callbacks);
        try testing.expectEqualSlices(u8, &payload, received.bytes[0..payload.len]);
        const sent = try stream_snapshot(fixture, child_case.sender, id);
        try testing.expectEqual(@as(c_uint, 1), sent.typed_callbacks);
        try testing.expectEqual(@as(c_int, c.LSQUIC_WTS_OK), sent.typed_info_result);
        try testing.expectEqual(@as(c_uint, 0), sent.reset_callbacks);
        try testing.expectEqual(@as(c_uint, if (child_case.direction == .uni) 14 else 6), sent.typed_info.flags);
        try testing.expectEqual(@as(c_uint, if (child_case.direction == .uni) 10 else 2), received.typed_info.flags);
        return;
    }
    return error.NativeChildDeliveryTimeout;
}

test "candidate backend resolves real native contracts and preserves invalid outputs" {
    try testing.expect(backend.available);
    var peer: backend.Peer = .{ .initial_max_data = 123, .wt_enabled = true };
    const peer_before = peer;
    try testing.expectEqual(backend.QueryResult.invalid, backend.read_peer(null, &peer));
    try testing.expectEqualDeep(peer_before, peer);
    var info: backend.StreamInfo = .{ .session_id = 44, .association = .child };
    const info_before = info;
    try testing.expectEqual(backend.QueryResult.invalid, backend.read_stream(null, &info));
    try testing.expectEqualDeep(info_before, info);
}

test "candidate backend observes pending then real TLS peer settings" {
    const fixture = try create_fixture(ordinary_limits);
    defer c.uwz_wt_fixture_destroy(fixture);
    const client = c.uwz_wt_fixture_connection(fixture, c.UWZ_WT_CLIENT);
    try testing.expect(client != null);
    var pending: backend.Peer = .{
        .initial_max_data = 91,
        .initial_max_streams_bidi = 92,
        .initial_max_streams_uni = 93,
        .reliable_reset = true,
    };
    const before = pending;
    try testing.expectEqual(backend.QueryResult.pending, backend.read_peer(client, &pending));
    try testing.expectEqualDeep(before, pending);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_handshake(fixture));

    for ([_]c.enum_uwz_wt_role{ c.UWZ_WT_CLIENT, c.UWZ_WT_SERVER }) |role| {
        const conn = c.uwz_wt_fixture_connection(fixture, role);
        var peer: backend.Peer = .{};
        var native: c.struct_lsquic_webtransport_peer = undefined;
        try testing.expectEqual(backend.QueryResult.ok, backend.read_peer(conn, &peer));
        try testing.expectEqual(@as(c_int, c.LSQUIC_WTP_OK), c.lsquic_conn_get_webtransport_peer(conn, &native));
        try testing.expectEqual(@as(c_uint, if (role == c.UWZ_WT_CLIENT) 31 else 29), native.flags);
        try testing.expectEqualDeep(backend.Peer{
            .initial_max_data = 4096,
            .initial_max_streams_bidi = 2,
            .initial_max_streams_uni = 3,
            .wt_enabled = true,
            .extended_connect = role == c.UWZ_WT_CLIENT,
            .http_datagram = true,
            .quic_datagram = true,
            .reliable_reset = true,
        }, peer);
        try testing.expectEqual(@as(u64, 4096), native.initial_max_data);
        try testing.expectEqual(@as(u64, 2), native.initial_max_streams_bidi);
        try testing.expectEqual(@as(u64, 3), native.initial_max_streams_uni);
        try testing.expect(backend.peer_requirements_met(peer, if (role == c.UWZ_WT_CLIENT) .client else .server));
        const snapshot = try endpoint_snapshot(fixture, role);
        try testing.expectEqual(@as(c_uint, 1), snapshot.settings_callbacks);
        try testing.expectEqual(@as(c_uint, 0), snapshot.connection_closed);
        try testing.expectEqual(@as(c_uint, 0), snapshot.stream_callbacks);
    }
}

test "candidate backend preserves 64 bit peer limits from actual TLS SETTINGS" {
    const wide_limits: backend.LocalLimits = .{
        .initial_max_data = (@as(u64, 1) << 40) + 4096,
        .initial_max_streams_bidi = (@as(u64, 1) << 35) + 2,
        .initial_max_streams_uni = (@as(u64, 1) << 34) + 3,
    };
    const fixture = try create_fixture(wide_limits);
    defer c.uwz_wt_fixture_destroy(fixture);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_handshake(fixture));

    for ([_]c.enum_uwz_wt_role{ c.UWZ_WT_CLIENT, c.UWZ_WT_SERVER }) |role| {
        const conn = c.uwz_wt_fixture_connection(fixture, role);
        var peer: backend.Peer = .{};
        var native: c.struct_lsquic_webtransport_peer = undefined;
        try testing.expectEqual(backend.QueryResult.ok, backend.read_peer(conn, &peer));
        try testing.expectEqual(@as(c_int, c.LSQUIC_WTP_OK), c.lsquic_conn_get_webtransport_peer(conn, &native));
        try testing.expectEqual(@as(c_uint, if (role == c.UWZ_WT_CLIENT) 31 else 29), native.flags);
        try testing.expectEqual(wide_limits.initial_max_data, native.initial_max_data);
        try testing.expectEqual(wide_limits.initial_max_streams_bidi, native.initial_max_streams_bidi);
        try testing.expectEqual(wide_limits.initial_max_streams_uni, native.initial_max_streams_uni);
        try testing.expectEqualDeep(backend.Peer{
            .initial_max_data = wide_limits.initial_max_data,
            .initial_max_streams_bidi = wide_limits.initial_max_streams_bidi,
            .initial_max_streams_uni = wide_limits.initial_max_streams_uni,
            .wt_enabled = true,
            .extended_connect = role == c.UWZ_WT_CLIENT,
            .http_datagram = true,
            .quic_datagram = true,
            .reliable_reset = true,
        }, peer);
        try testing.expect(backend.peer_requirements_met(peer, if (role == c.UWZ_WT_CLIENT) .client else .server));
        const snapshot = try endpoint_snapshot(fixture, role);
        try testing.expectEqual(@as(c_uint, 1), snapshot.settings_callbacks);
        try testing.expectEqual(@as(c_uint, 0), snapshot.connection_closed);
        try testing.expectEqual(@as(c_uint, 0), snapshot.stream_callbacks);
        try testing.expectEqual(@as(c_uint, 0), snapshot.typed_callbacks);
    }
}

test "candidate backend marks real CONNECT and creates bidirectional and unidirectional children" {
    const fixture = try create_fixture(ordinary_limits);
    defer c.uwz_wt_fixture_destroy(fixture);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_handshake(fixture));
    try expect_no_child(fixture, c.UWZ_WT_CLIENT, 0, .no_session);
    try expect_no_child(fixture, c.UWZ_WT_SERVER, 1, .invalid);
    try accept_parent(fixture);
    try expect_no_child(fixture, c.UWZ_WT_CLIENT, 4, .no_session);
    try expect_no_child(fixture, c.UWZ_WT_SERVER, 1, .invalid);

    const child_cases = [_]ChildCase{
        .{ .sender = c.UWZ_WT_CLIENT, .receiver = c.UWZ_WT_SERVER, .direction = .bidi },
        .{ .sender = c.UWZ_WT_SERVER, .receiver = c.UWZ_WT_CLIENT, .direction = .bidi },
        .{ .sender = c.UWZ_WT_CLIENT, .receiver = c.UWZ_WT_SERVER, .direction = .uni },
        .{ .sender = c.UWZ_WT_SERVER, .receiver = c.UWZ_WT_CLIENT, .direction = .uni },
    };
    for (child_cases) |child_case| try create_and_observe_child(fixture, child_case);
    for ([_]c.enum_uwz_wt_role{ c.UWZ_WT_CLIENT, c.UWZ_WT_SERVER }) |role| {
        const snapshot = try endpoint_snapshot(fixture, role);
        try testing.expectEqual(@as(c_uint, 5), snapshot.stream_callbacks);
        try testing.expectEqual(@as(c_uint, 4), snapshot.typed_callbacks);
        try testing.expectEqual(snapshot.headers_created, snapshot.headers_discarded);
        try testing.expectEqual(@as(c_uint, 0), snapshot.connection_closed);
    }
}
