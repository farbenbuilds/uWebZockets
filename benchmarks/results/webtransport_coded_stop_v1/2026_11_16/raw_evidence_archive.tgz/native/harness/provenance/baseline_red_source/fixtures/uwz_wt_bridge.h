/* Copyright (c) 2026 uWebZockets contributors. See LICENSE. */
#ifndef UWZ_WT_BRIDGE_H
#define UWZ_WT_BRIDGE_H

#include <stddef.h>
#include <stdint.h>
#include "lsquic.h"

struct uwz_wt_fixture;

/* Runs before engine creation; callbacks point into fixture-owned storage. */
typedef int (*uwz_wt_configure_callback)(void *, struct lsquic_engine_settings *,
                                        struct lsquic_stream_if *);

enum uwz_wt_role {
    UWZ_WT_CLIENT = 0,
    UWZ_WT_SERVER = 1,
};

enum uwz_wt_event {
    UWZ_WT_EVENT_TYPED,
    UWZ_WT_EVENT_DATA,
    UWZ_WT_EVENT_EOF,
    UWZ_WT_EVENT_RESET,
    UWZ_WT_EVENT_STOP,
    UWZ_WT_EVENT_CLOSE,
};

/* The stream and bytes are borrowed only for this actual native callback. */
typedef void (*uwz_wt_observer_callback)(void *, enum uwz_wt_role, uint64_t,
    enum uwz_wt_event, lsquic_stream_t *, const unsigned char *, size_t);

enum {
    UWZ_WT_MAX_STEPS = 20000,
    UWZ_WT_MAX_STREAMS = 8,
    UWZ_WT_MAX_PAYLOAD = 128,
};

struct uwz_wt_endpoint_snapshot {
    unsigned handshake_complete;
    unsigned settings_callbacks;
    unsigned connection_closed;
    unsigned stream_callbacks;
    unsigned typed_callbacks;
    unsigned headers_created;
    unsigned headers_discarded;
};

struct uwz_wt_stream_snapshot {
    uint64_t stream_id;
    struct lsquic_webtransport_stream_info new_info;
    struct lsquic_webtransport_stream_info typed_info;
    struct lsquic_webtransport_stream_info close_info;
    size_t received;
    unsigned new_callbacks;
    unsigned header_callbacks;
    unsigned headers_valid;
    unsigned typed_callbacks;
    unsigned read_callbacks;
    unsigned close_callbacks;
    unsigned reset_callbacks;
    unsigned fin_received;
    int new_info_result;
    int typed_info_result;
    int close_info_result;
    struct lsquic_stream_recv_state close_receive;
    int close_receive_result;
    unsigned char bytes[UWZ_WT_MAX_PAYLOAD];
};

/* Fixtures run sequentially because lsquic owns process-wide initialization. */
struct uwz_wt_fixture *uwz_wt_fixture_create(uwz_wt_configure_callback, void *configure_ctx);
void uwz_wt_fixture_destroy(struct uwz_wt_fixture *);
int uwz_wt_fixture_connect(struct uwz_wt_fixture *);
int uwz_wt_fixture_pump(struct uwz_wt_fixture *, unsigned steps);
int uwz_wt_fixture_handshake(struct uwz_wt_fixture *);

lsquic_conn_t *uwz_wt_fixture_connection(struct uwz_wt_fixture *, enum uwz_wt_role);
lsquic_stream_t *uwz_wt_fixture_stream(struct uwz_wt_fixture *, enum uwz_wt_role,
                                     uint64_t stream_id);
lsquic_stream_t *uwz_wt_fixture_last_child(struct uwz_wt_fixture *, enum uwz_wt_role);
int uwz_wt_fixture_endpoint_snapshot(const struct uwz_wt_fixture *, enum uwz_wt_role,
                                    struct uwz_wt_endpoint_snapshot *);
int uwz_wt_fixture_stream_snapshot(const struct uwz_wt_fixture *, enum uwz_wt_role,
                                  uint64_t stream_id, struct uwz_wt_stream_snapshot *);

/* Sends real headers; admission is performed exclusively by the Zig caller. */
int uwz_wt_fixture_open_connect(struct uwz_wt_fixture *);
int uwz_wt_fixture_await_headers(struct uwz_wt_fixture *, enum uwz_wt_role);
int uwz_wt_fixture_send_success(struct uwz_wt_fixture *);
int uwz_wt_fixture_write(lsquic_stream_t *, const unsigned char *, size_t, int fin);
int uwz_wt_fixture_enable_reads(lsquic_stream_t *);
int uwz_wt_fixture_observe(struct uwz_wt_fixture *, uwz_wt_observer_callback, void *);
int uwz_wt_fixture_pause_reads(struct uwz_wt_fixture *, enum uwz_wt_role, int);
int uwz_wt_fixture_process_role(struct uwz_wt_fixture *, enum uwz_wt_role, unsigned);

#endif
