# STOP cohort terminal history

| Row | Result | Source identity and scope |
| --- | --- | --- |
| baseline-red-debug.log | exit 1, two compile errors | Frozen native 2e229 and pre-helper backend c09ae489 lack both the native entry and Zig helper. Actual native compilation/translation succeeded. |
| native-worker-wire-red.log | Failed external native-worker assertion | The worker's real encrypted raw-UNI baseline requested a caller-selected full-width code using the old generic-only path. Original source/log are copied; that source uses a weak-symbol fallback only to compile the old baseline. No active GREEN wrapper fallback exists. |
| first-green-debug.log | session 29307 exit 0, 15/15 | Native freeze d5be33a0..., before the logging-width correction. Wire behavior passed; this row does not claim the later logger fix. |
| final-Debug.log | session 24973 exit 0, 15/15 | Final native freeze 105bc1b1..., full compile-source manifest 04f69758.... |
| final-ReleaseSafe.log | session 43411 exit 0, 15/15 | Identical final scratch/native source. |
| final-ReleaseFast.log | session 19336 exit 0, 15/15 | Identical final scratch/native source. |

Legacy generic STOP uses HTTP HEC_NO_ERROR 0x100. The worker's first RED log
did not print an actual numeric-zero result; an earlier conversational zero
description was corrected before final evidence. GREEN separately proves that
explicit numeric zero remains distinct from the legacy default.

First GREEN already preserved full-width wire codes. Review then found the
internal event-log helper still accepted uint16_t. The native worker widened
its declaration/body to uint64_t/PRIu64 and added real maximum-code and legacy
256 runtime-capture evidence. The final fifteen-case modes include that source
revision. First/final native source manifests and diffs remain separate.

All final modes used scratch manifest
ccf94d0ef432d716563abe72c9aca829ee3c18094a1f3fe4680a33e2e1750909,
native freeze
105bc1b1fd01ceec3943e6be2fd4db7649d47d36a4aaf00e293f29db4024cf76,
and full native compile-source manifest
04f69758970c18b2a10471cebc43b4b333796e0166776f7947ca16c35b3a3b91.
Every mode has unchanged-source checks after authoritative termination. No
scratch/native source was edited during a live build. Review cleared the
strong-wrapper proof and the logging delta before final mode advancement.

README/provenance packaging edits occurred after all final modes terminated.
The final archive manifest includes current documentation; historical run
manifests are preserved. No code changed and no passing test was rerun for
those documentation edits.
