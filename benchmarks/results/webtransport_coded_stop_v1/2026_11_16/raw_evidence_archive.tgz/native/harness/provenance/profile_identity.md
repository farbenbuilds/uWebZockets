# Actual compiled profile

- Zig 0.16.0; native Linux x86_64; Zig compiles all C/C++ dependencies.
- Two actual HTTP/TLS native engines with BoringSSL and encrypted bounded
  in-memory packet delivery; synthetic inherited native clock.
- Native fixture clock enabled; reset-ACK and SETTINGS observers disabled.
- No UDP, libxev, Root Engine/App consumer or real-awake-clock expiry is used.
- Both peers' bidi-local, bidi-remote and UNI receive credit is 65536 bytes.
  WT advertised limits are data 65536, BIDI 16 and UNI 16. Caller admission uses
  actual extended CONNECT headers, server mark, actual non-FIN 200, client mark.
- Only the explicit FIN-received/unread case sets public client
  es_delay_onclose=1 via the actual pre-engine constructor callback. Other
  cases retain ordinary callback-close timing.
- Native source was tested as base 2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c
  plus feature diff SHA828f4c3b6f386981c56e4985bb1b19a86deadf9372f88f4e0dae1eafe5d0e2ad.
  Physical source identities are native-final-freeze.sha256 and
  native-final-source-inputs.sha256. A later metadata-only local proposal
  commit, if recorded by the combined handoff, must match those tested files.

The dependency package URLs and Zig hashes in build.zig.zon are unchanged from
the inherited scaffold. BoringSSL is d3bf4795ad5b79d646cddf2fec687da5b9b502db,
ls-qpack is 91567706c41c0d97ab8dc576873ecd472d7869fa, ls-hpack is
fda48e02491d865cce00612be8cc10c2622b8e55, and zlib is 1.3.2.

The native base's qpack gitlink matches the qpack package. Its hpack gitlink is
cf0f70dd10b352194c97448eb5d00b4aa484f531. The inherited Zig build copies and
compiles the explicit fda48e... hpack package instead, as did the previous
cohorts. native-submodule-identities.txt records the actual base gitlinks.
These identities are deliberately distinct; no equality/synchronization claim
is made and no dependency or submodule was modified in this prerequisite.

The separately linked native_source/ proposal contains the complete native
source/bundle and its own baseline/event-capture history. This Zig cohort
contains only its strong-wrapper scaffold, copied project sources, manifests,
logs and the historical wire-RED source/log. No full native repository is
included again.
