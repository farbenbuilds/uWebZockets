const c = @import("c");
const project = @import("project");

test "explicit native STOP API exists" {
    _ = c.lsquic_stream_stop_sending;
}

test "backend receive cancellation API exists" {
    _ = project.backend.stop_receiving;
}
