# Explicit native STOP prerequisite

Fifteen functional tests pass in Debug, ReleaseSafe and ReleaseFast: nine new
STOP cases and six byte-identical child-ledger regressions. There is no anchor
test. This scratch harness imports exact project source copies and calls the
new strong `backend.stop_receiving` adapter/native entry without a fallback.
No production source, dependency pin or older frozen harness is changed.

The profile uses two actual HTTP/TLS lsquic engines, BoringSSL and bounded
in-memory queues containing real encrypted packets. The inherited native
fixture clock is synthetic. There is no UDP, xev, Engine/App child consumer,
public child-I/O API or independent-client proof here. The production pending
queue's real OS awake clock is outside this cohort.

The nine STOP cases prove:

- Exact WT_BUFFERED_STREAM_REJECTED 0x3994bd84, the largest 62-bit code, and
  explicit numeric zero, independently of legacy HTTP HEC_NO_ERROR 0x100.
- Incoming UNI cancellation, unsupported local-UNI cancellation, invalid
  bounds, same-code idempotence/conflict rejection before and after peer
  receipt, no inline callbacks, and final-size retention through on-close.
- BIDI receive cancellation followed by real local transmit bytes; the peer
  observes the requested STOP independently from local TX RESET error 373.
- Explicit STOP after FIN is received but unread, preserving the exact code
  and avoiding a wait for an already known final size.
- Unchanged legacy read-shutdown code 0x100 and FIN-based STOP suppression;
  explicit cancellation after read EOF or known hidden RESET is closed and
  preserves native receive state.

All ordinary pairs explicitly advertise 65536 bytes for each of the three QUIC
stream receive windows on both peers. The FIN-unread case alone configures the
client's supported es_delay_onclose=1 before engine construction, keeping its
native context alive through actual peer STOP. The typed constructor callback
uses explicit userdata and the same WT/DG/reset settings as the ordinary
fixture. Read-only flag observations use actual candidate headers. Every
post-pump access reacquires a live native pointer; on-close evidence is copied
inside the real callback before pointer invalidation. No native layout, peer
cache, callback or packet is fabricated.

`project/backend.zig` matches SHA-256
8a2755b4290b173961c886c24b1a4914a4e85fe9c8d76bcc4d450f07a25d5b7c;
`project/child_ledger.zig` matches
95c45beb37df0a5468d08b079ae52618939508c6a7a5dfc4079fdec8ed87b496.
The namespace only shares real translated C types between both files.
The original ledger driver remains
f149e8015acd521186703c3afc70b923eef9df09fe9c18cad24328037cb51510.

Final modes share scratch manifest ccf94d0e..., nine-file native freeze
105bc1b1..., and full native compile-source manifest 04f69758.... The native
candidate was base 2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c plus the tested
frozen feature diff 828f4c3b.... Its separate complete source/proposal archive
is supplied as `native_source/` by the combined handoff. This scaffold does not
duplicate the native repository or Git bundle.

The exact compiled dependency identities remain in `build.zig.zon`.
ls-qpack package/gitlink both use 91567706.... The inherited build actually
compiles ls-hpack package fda48e02491d865cce00612be8cc10c2622b8e55, while the
native base gitlink is cf0f70dd10b352194c97448eb5d00b4aa484f531. Both identities
are recorded explicitly; this is not a claim that they match. No submodule or
package was changed for STOP. See `provenance/profile_identity.md`.

Recorded final command, replacing Debug with the other modes as appropriate:

```sh
ulimit -c 0
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-uni-global-cache \
  /tmp/zig-x86_64-linux-0.16.0/zig build test \
  -Doptimize=Debug \
  -Dlsquic-source=/tmp/uwz-lsquic-wt-stop-20261116 -j2 --summary all
```

The sealed checkpoint's replay.sh supports explicit source, package, Zig and
cache paths and disables fetching when supplied exact package inputs.
`provenance/history.md` distinguishes declaration/wire RED, pre-logging-fix
GREEN and final GREEN. Only documentation/provenance changed after the final
modes; historical run manifests remain unchanged. Dedicated smoke, security,
sanitizer and fuzz campaigns remain deferred.
