#include <stddef.h>
#include <stdint.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <openssl/base.h>
#undef OPENSSL_GNUC_CLANG_PRAGMA
#define OPENSSL_GNUC_CLANG_PRAGMA(arg)

#include <openssl/ssl.h>
#include "lsquic.h"
#include "uwz_wt_bridge.h"
