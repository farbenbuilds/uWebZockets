/* Copyright (c) 2026 uWebZockets contributors. See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <sys/queue.h>
#include <openssl/ssl.h>
#include "lsquic.h"
#include "lsxpack_header.h"
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_packet_in.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"
#include "uwz_quic_fixture.h"
#include "uwz_webtransport_fixture.h"
#include "uwz_wt_bridge.h"

#ifdef NDEBUG
#error "uwz_wt_bridge requires active assertions"
#endif

struct uwz_wt_endpoint;

struct uwz_wt_stream {
    struct uwz_wt_endpoint *endpoint;
    lsquic_stream_t *native;
    struct uwz_wt_stream_snapshot observation;
};

struct uwz_wt_endpoint {
    lsquic_conn_t *native;
    enum uwz_wt_role role;
    struct uwz_wt_endpoint_snapshot observation;
    struct lsquic_stream_if callbacks;
    struct uwz_wt_stream streams[UWZ_WT_MAX_STREAMS];
    struct streams_header_pool headers;
    uwz_wt_observer_callback observer;
    void *observer_context;
    int reads_paused;
};

struct uwz_wt_fixture {
    struct lsquic_test_pair transport;
    struct uwz_wt_endpoint endpoints[2];
    unsigned initialized;
    unsigned connected;
};

static int
valid_role(enum uwz_wt_role role)
{
    return role == UWZ_WT_CLIENT || role == UWZ_WT_SERVER;
}

static struct uwz_wt_stream *
find_stream(struct uwz_wt_endpoint *endpoint, uint64_t id)
{
    unsigned index;

    for (index = 0; index < endpoint->observation.stream_callbacks; ++index)
        if (endpoint->streams[index].observation.stream_id == id)
            return &endpoint->streams[index];
    return NULL;
}

static void
observe_stream(struct uwz_wt_stream *state, enum uwz_wt_event event,
               const unsigned char *bytes, size_t size)
{
    if (state->endpoint->observer)
        state->endpoint->observer(state->endpoint->observer_context,
            state->endpoint->role, state->observation.stream_id, event,
            state->native, bytes, size);
}

static lsquic_conn_ctx_t *
new_connection(void *ctx, lsquic_conn_t *conn)
{
    struct uwz_wt_endpoint *endpoint = ctx;

    assert(!endpoint->native);
    endpoint->native = conn;
    if (endpoint->role == UWZ_WT_SERVER)
        endpoint->observation.handshake_complete = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}

static void
handshake_done(lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct uwz_wt_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint && status == LSQ_HSK_OK);
    endpoint->observation.handshake_complete = 1;
}

static void
settings_received(lsquic_conn_t *conn)
{
    struct uwz_wt_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint && endpoint->native == conn);
    ++endpoint->observation.settings_callbacks;
}

static void
connection_closed(lsquic_conn_t *conn)
{
    struct uwz_wt_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint && endpoint->native == conn);
    ++endpoint->observation.connection_closed;
    endpoint->native = NULL;
    lsquic_conn_set_ctx(conn, NULL);
}

static lsquic_stream_ctx_t *
new_stream(void *ctx, lsquic_stream_t *stream)
{
    struct uwz_wt_endpoint *endpoint = ctx;
    struct uwz_wt_stream *state;

    assert(stream && endpoint->observation.stream_callbacks < UWZ_WT_MAX_STREAMS);
    state = &endpoint->streams[endpoint->observation.stream_callbacks++];
    state->endpoint = endpoint;
    state->native = stream;
    state->observation.stream_id = lsquic_stream_id(stream);
    state->observation.new_callbacks = 1;
    state->observation.new_info_result =
        lsquic_stream_get_webtransport_info(stream, &state->observation.new_info);
    return (lsquic_stream_ctx_t *) state;
}

static int
header_matches(const struct streams_header_set *set, const char *name,
               const char *value)
{
    const struct lsxpack_header *header;
    size_t name_size = strlen(name), value_size = strlen(value);
    unsigned index, matches = 0;

    for (index = 0; index < set->shs_count; ++index)
    {
        header = &set->shs_fields[index].shf_header;
        if (header->name_len != name_size
            || memcmp(lsxpack_header_get_name(header), name, name_size))
            continue;
        if (header->val_len != value_size
            || memcmp(lsxpack_header_get_value(header), value, value_size))
            return 0;
        ++matches;
    }
    return matches == 1;
}

static int
valid_headers(const struct streams_header_set *set, enum uwz_wt_role role)
{
    if (role == UWZ_WT_CLIENT)
        return set->shs_count == 1 && header_matches(set, ":status", "200");
    return set->shs_count == 6
        && header_matches(set, ":method", "CONNECT")
        && header_matches(set, ":protocol", "webtransport-h3")
        && header_matches(set, ":scheme", "https")
        && header_matches(set, ":authority", "localhost")
        && header_matches(set, ":path", "/wt")
        && header_matches(set, "origin", "https://localhost");
}

static void
header_set_received(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct uwz_wt_stream *state = (void *) ctx;
    struct streams_header_set *set;

    assert(state && state->native == stream && state->observation.stream_id == 0);
    ++state->observation.header_callbacks;
    set = lsquic_stream_get_hset(stream);
    assert(set && set->shs_active && set->shs_complete);
    state->observation.headers_valid = valid_headers(set, state->endpoint->role);
    discard_header_set(set);
}

static void
webtransport_stream(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct uwz_wt_stream *state = (void *) ctx;
    struct lsquic_webtransport_stream_info *info;

    assert(state && state->native == stream && state->observation.new_callbacks);
    ++state->observation.typed_callbacks;
    ++state->endpoint->observation.typed_callbacks;
    info = &state->observation.typed_info;
    state->observation.typed_info_result = lsquic_stream_get_webtransport_info(stream, info);
    observe_stream(state, UWZ_WT_EVENT_TYPED, NULL, 0);
    if (state->observation.typed_info_result != LSQUIC_WTS_OK)
        return;
    if ((info->flags & LSQUIC_WTSF_UNI) && (info->flags & LSQUIC_WTSF_LOCAL))
        return;
    assert(lsquic_stream_wantread(stream, !state->endpoint->reads_paused) >= 0);
}

static void
read_stream(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct uwz_wt_stream *state = (void *) ctx;
    struct uwz_wt_stream_snapshot *observation = &state->observation;
    ssize_t size;

    assert(state->native == stream);
    ++observation->read_callbacks;
    while (observation->received < sizeof(observation->bytes))
    {
        size = lsquic_stream_read(stream, observation->bytes + observation->received,
                                sizeof(observation->bytes) - observation->received);
        if (size > 0)
        {
            observe_stream(state, UWZ_WT_EVENT_DATA,
                observation->bytes + observation->received, (size_t) size);
            observation->received += (size_t) size;
            continue;
        }
        if (size == 0)
        {
            observation->fin_received = 1;
            observe_stream(state, UWZ_WT_EVENT_EOF, NULL, 0);
        }
        if (size < 0 && (errno == EAGAIN || errno == EWOULDBLOCK))
            return;
        assert(lsquic_stream_wantread(stream, 0) >= 0);
        return;
    }
    assert(lsquic_stream_wantread(stream, 0) >= 0);
}

static void
write_stream(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) ctx;
    /* The Zig driver supplies every payload through synchronous write calls. */
    assert(lsquic_stream_wantwrite(stream, 0) >= 0);
}

static void
close_stream(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct uwz_wt_stream *state = (void *) ctx;

    assert(state && state->native == stream && !state->observation.close_callbacks);
    state->observation.close_info_result =
        lsquic_stream_get_webtransport_info(stream, &state->observation.close_info);
    state->observation.close_receive_result =
        lsquic_stream_get_recv_state(stream, &state->observation.close_receive);
    observe_stream(state, UWZ_WT_EVENT_CLOSE, NULL, 0);
    ++state->observation.close_callbacks;
    state->native = NULL;
}

static void
stream_reset(lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx, int how)
{
    struct uwz_wt_stream *state = (void *) ctx;

    assert(state && state->native == stream && (how == 0 || how == 1));
    ++state->observation.reset_callbacks;
    observe_stream(state, how == 0 ? UWZ_WT_EVENT_RESET : UWZ_WT_EVENT_STOP, NULL, 0);
}

static const struct lsquic_stream_if bridge_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_h3_settings = settings_received,
    .on_new_stream = new_stream,
    .on_hset_in = header_set_received,
    .on_webtransport_stream = webtransport_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_reset = stream_reset,
};

static int
init_endpoint(struct uwz_wt_fixture *fixture, enum uwz_wt_role role,
              uwz_wt_configure_callback configure, void *configure_ctx)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct uwz_wt_endpoint *endpoint = &fixture->endpoints[role];
    struct lsquic_test_endpoint *transport, *peer;
    unsigned flags = LSENG_HTTP | (role == UWZ_WT_SERVER ? LSENG_SERVER : 0);
    int result;

    endpoint->role = role;
    transport = role == UWZ_WT_SERVER ? &fixture->transport.ltp_server
                                    : &fixture->transport.ltp_client;
    peer = role == UWZ_WT_SERVER ? &fixture->transport.ltp_client
                               : &fixture->transport.ltp_server;
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = 8;
    settings.es_init_max_streams_bidi = 8;
    settings.es_max_streams_in = 0;
    settings.es_init_max_stream_data_bidi_local = 65536;
    settings.es_init_max_stream_data_bidi_remote = 65536;
    settings.es_init_max_stream_data_uni = 65536;
    settings.es_qpack_dec_max_size = 0;
    settings.es_qpack_dec_max_blocked = 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    endpoint->callbacks = bridge_callbacks;
    if (configure)
    {
        if (configure(configure_ctx, &settings, &endpoint->callbacks))
            return -1;
    }
    else
    {
        settings.es_datagrams = 1;
        settings.es_reset_stream_at = 1;
        settings.es_webtransport.enabled = 1;
        settings.es_webtransport.initial_max_data = 65536;
        settings.es_webtransport.initial_max_streams_bidi = 16;
        settings.es_webtransport.initial_max_streams_uni = 16;
    }
    if (lsquic_engine_check_settings(&settings, flags, NULL, 0))
        return -1;
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &endpoint->callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_hsi_if = &streams_hsi;
    config.ltec_hsi_ctx = &endpoint->headers;
    config.ltec_alpn = "h3";
    config.ltec_tls = lsquic_test_tls_context_new(role == UWZ_WT_SERVER, "h3");
    if (!config.ltec_tls)
        return -1;
    result = lsquic_test_endpoint_init(transport, peer, &config,
                                     role == UWZ_WT_SERVER ? 12901 : 12902);
    SSL_CTX_free(config.ltec_tls);
    return result;
}

struct uwz_wt_fixture *
uwz_wt_fixture_create(uwz_wt_configure_callback configure, void *configure_ctx)
{
    struct uwz_wt_fixture *fixture = calloc(1, sizeof(*fixture));

    if (!fixture)
        return NULL;
    if (lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER))
    {
        free(fixture);
        return NULL;
    }
    fixture->initialized = 1;
    if (init_endpoint(fixture, UWZ_WT_CLIENT, configure, configure_ctx)
        || init_endpoint(fixture, UWZ_WT_SERVER, configure, configure_ctx))
    {
        uwz_wt_fixture_destroy(fixture);
        return NULL;
    }
    return fixture;
}

void
uwz_wt_fixture_destroy(struct uwz_wt_fixture *fixture)
{
    unsigned index;

    if (!fixture)
        return;
    lsquic_test_endpoint_destroy(&fixture->transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture->transport.ltp_server);
    for (index = 0; index < 2; ++index)
        assert(fixture->endpoints[index].headers.shp_created
               == fixture->endpoints[index].headers.shp_discarded);
    if (fixture->initialized)
        lsquic_global_cleanup();
    free(fixture);
}

int
uwz_wt_fixture_connect(struct uwz_wt_fixture *fixture)
{
    lsquic_conn_t *conn;

    if (!fixture || fixture->connected)
        return -1;
    conn = lsquic_engine_connect(fixture->transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture->transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture->transport.ltp_server.lte_address,
                &fixture->transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0);
    if (!conn)
        return -1;
    fixture->connected = 1;
    return 0;
}

int
uwz_wt_fixture_pump(struct uwz_wt_fixture *fixture, unsigned steps)
{
    unsigned step;

    if (!fixture || steps > UWZ_WT_MAX_STEPS)
        return -1;
    for (step = 0; step < steps; ++step)
    {
        lsquic_test_pair_process(&fixture->transport, 1000);
        lsquic_test_deliver_all(&fixture->transport.ltp_client);
        lsquic_test_deliver_all(&fixture->transport.ltp_server);
    }
    return 0;
}

int
uwz_wt_fixture_handshake(struct uwz_wt_fixture *fixture)
{
    unsigned step;

    if (!fixture || !fixture->connected)
        return -1;
    for (step = 0; step < UWZ_WT_MAX_STEPS; ++step)
    {
        if (fixture->endpoints[0].observation.handshake_complete
            && fixture->endpoints[1].observation.handshake_complete
            && fixture->endpoints[0].observation.settings_callbacks
            && fixture->endpoints[1].observation.settings_callbacks)
            return uwz_wt_fixture_pump(fixture, 20);
        if (uwz_wt_fixture_pump(fixture, 1))
            return -1;
    }
    return -1;
}

lsquic_conn_t *
uwz_wt_fixture_connection(struct uwz_wt_fixture *fixture, enum uwz_wt_role role)
{
    if (!fixture || !valid_role(role))
        return NULL;
    return fixture->endpoints[role].native;
}

lsquic_stream_t *
uwz_wt_fixture_stream(struct uwz_wt_fixture *fixture, enum uwz_wt_role role,
                      uint64_t stream_id)
{
    struct uwz_wt_stream *state;

    if (!fixture || !valid_role(role))
        return NULL;
    state = find_stream(&fixture->endpoints[role], stream_id);
    return state ? state->native : NULL;
}

lsquic_stream_t *
uwz_wt_fixture_last_child(struct uwz_wt_fixture *fixture, enum uwz_wt_role role)
{
    struct uwz_wt_endpoint *endpoint;
    struct uwz_wt_stream *state;
    struct lsquic_webtransport_stream_info info;
    unsigned index;

    if (!fixture || !valid_role(role))
        return NULL;
    endpoint = &fixture->endpoints[role];
    for (index = endpoint->observation.stream_callbacks; index > 0; --index)
    {
        state = &endpoint->streams[index - 1];
        if (state->native
            && lsquic_stream_get_webtransport_info(state->native, &info) == LSQUIC_WTS_OK
            && (info.flags & LSQUIC_WTSF_CHILD))
            return state->native;
    }
    return NULL;
}

int
uwz_wt_fixture_endpoint_snapshot(const struct uwz_wt_fixture *fixture,
    enum uwz_wt_role role, struct uwz_wt_endpoint_snapshot *out)
{
    const struct uwz_wt_endpoint *endpoint;

    if (!fixture || !valid_role(role) || !out)
        return -1;
    endpoint = &fixture->endpoints[role];
    *out = endpoint->observation;
    out->headers_created = endpoint->headers.shp_created;
    out->headers_discarded = endpoint->headers.shp_discarded;
    return 0;
}

int
uwz_wt_fixture_stream_snapshot(const struct uwz_wt_fixture *fixture,
    enum uwz_wt_role role, uint64_t stream_id, struct uwz_wt_stream_snapshot *out)
{
    const struct uwz_wt_endpoint *endpoint;
    unsigned index;

    if (!fixture || !valid_role(role) || !out)
        return -1;
    endpoint = &fixture->endpoints[role];
    for (index = 0; index < endpoint->observation.stream_callbacks; ++index)
    {
        if (endpoint->streams[index].observation.stream_id != stream_id)
            continue;
        *out = endpoint->streams[index].observation;
        return 0;
    }
    return -1;
}

int
uwz_wt_fixture_open_connect(struct uwz_wt_fixture *fixture)
{
    /* Draft-16 requires webtransport-h3 and a separately validated Origin. */
    static const char *const fields[] = {
        ":methodCONNECT", ":protocolwebtransport-h3", ":schemehttps",
        ":authoritylocalhost", ":path/wt", "originhttps://localhost",
    };
    static const unsigned name_sizes[] = { 7, 9, 7, 10, 5, 6 };
    struct lsxpack_header encoded[6];
    struct lsquic_http_headers headers = { 6, encoded };
    lsquic_stream_t *stream;
    unsigned index;

    if (!fixture || !fixture->endpoints[UWZ_WT_CLIENT].native
        || fixture->endpoints[UWZ_WT_CLIENT].observation.stream_callbacks)
        return -1;
    lsquic_conn_make_stream(fixture->endpoints[UWZ_WT_CLIENT].native);
    stream = uwz_wt_fixture_stream(fixture, UWZ_WT_CLIENT, 0);
    if (!stream)
        return -1;
    for (index = 0; index < 6; ++index)
        lsxpack_header_set_offset2(&encoded[index], fields[index], 0,
                    name_sizes[index], name_sizes[index], strlen(fields[index]) - name_sizes[index]);
    if (lsquic_stream_send_headers(stream, &headers, 0))
        return -1;
    return lsquic_stream_flush(stream);
}

int
uwz_wt_fixture_await_headers(struct uwz_wt_fixture *fixture, enum uwz_wt_role role)
{
    struct uwz_wt_stream *state;
    unsigned step;

    if (!fixture || !valid_role(role))
        return -1;
    for (step = 0; step < UWZ_WT_MAX_STEPS; ++step)
    {
        state = find_stream(&fixture->endpoints[role], 0);
        if (state && state->observation.header_callbacks)
            return state->observation.headers_valid ? 0 : -1;
        if (uwz_wt_fixture_pump(fixture, 1))
            return -1;
    }
    return -1;
}

int
uwz_wt_fixture_send_success(struct uwz_wt_fixture *fixture)
{
    static const char status[] = ":status200";
    struct lsxpack_header encoded;
    struct lsquic_http_headers headers = { 1, &encoded };
    lsquic_stream_t *stream = uwz_wt_fixture_stream(fixture, UWZ_WT_SERVER, 0);

    if (!stream)
        return -1;
    lsxpack_header_set_offset2(&encoded, status, 0, 7, 7, 3);
    if (lsquic_stream_send_headers(stream, &headers, 0))
        return -1;
    return lsquic_stream_flush(stream);
}

int
uwz_wt_fixture_write(lsquic_stream_t *stream, const unsigned char *bytes,
                     size_t size, int fin)
{
    ssize_t written;

    if (!stream || !bytes || size > UWZ_WT_MAX_PAYLOAD || (fin != 0 && fin != 1))
        return -1;
    written = lsquic_stream_write(stream, bytes, size);
    if (written < 0 || (size_t) written != size)
        return -1;
    if (fin)
        return lsquic_stream_shutdown(stream, 1);
    return lsquic_stream_flush(stream);
}

int
uwz_wt_fixture_enable_reads(lsquic_stream_t *stream)
{
    if (!stream)
        return -1;
    return lsquic_stream_wantread(stream, 1) < 0 ? -1 : 0;
}

int
uwz_wt_fixture_observe(struct uwz_wt_fixture *fixture,
                     uwz_wt_observer_callback observer, void *context)
{
    unsigned index;

    if (!fixture || fixture->connected)
        return -1;
    for (index = 0; index < 2; ++index)
    {
        fixture->endpoints[index].observer = observer;
        fixture->endpoints[index].observer_context = context;
    }
    return 0;
}

int
uwz_wt_fixture_pause_reads(struct uwz_wt_fixture *fixture,
                         enum uwz_wt_role role, int paused)
{
    if (!fixture || !valid_role(role) || (paused != 0 && paused != 1))
        return -1;
    fixture->endpoints[role].reads_paused = paused;
    return 0;
}

int
uwz_wt_fixture_process_role(struct uwz_wt_fixture *fixture,
                          enum uwz_wt_role role, unsigned steps)
{
    struct lsquic_test_endpoint *endpoint;
    unsigned step;

    if (!fixture || !valid_role(role) || steps > UWZ_WT_MAX_STEPS)
        return -1;
    endpoint = role == UWZ_WT_SERVER ? &fixture->transport.ltp_server
                                   : &fixture->transport.ltp_client;
    for (step = 0; step < steps; ++step)
        lsquic_engine_process_conns(endpoint->lte_engine);
    return 0;
}

int
uwz_wt_stream_flags(const lsquic_stream_t *stream, struct uwz_wt_native_flags *out)
{
    if (!stream || !out)
        return -1;
    out->stream_flags = stream->stream_flags;
    out->queue_flags = stream->sm_qflags;
    out->waiting_final = !!(stream->sm_qflags & SMQF_WAIT_FIN_OFF);
    out->application_closed = (stream->stream_flags & (STREAM_U_READ_DONE | STREAM_U_WRITE_DONE))
                            == (STREAM_U_READ_DONE | STREAM_U_WRITE_DONE);
    return 0;
}
