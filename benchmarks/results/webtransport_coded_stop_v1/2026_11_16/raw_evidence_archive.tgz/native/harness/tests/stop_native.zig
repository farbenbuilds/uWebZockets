const std = @import("std");
const c = @import("c");
const project = @import("project");
const backend = project.backend;
const testing = std.testing;

comptime {
    _ = @import("ledger_native.zig");
}

const rejected: u64 = 0x3994bd84;
const largest_code: u64 = (1 << 62) - 1;
const inbound = [_]u8{ 0x41, 0, 0xff, 's', 't', 'o', 'p', 0x54, 0x40, 0xfe };
const reverse = [_]u8{ 0x41, 0x41, 0, 'r', 'e', 'p', 'l', 'y', 0xff };
const max_steps = 20000;

/// All evidence is copied during actual native callbacks, never from dead handles.
const StreamRecord = struct {
    id: u64 = 0,
    role: c.enum_uwz_wt_role = c.UWZ_WT_CLIENT,
    info: backend.StreamInfo = .{},
    receive: backend.ReceiveSnapshot = .{},
    close_receive: backend.ReceiveSnapshot = .{},
    bytes: [128]u8 = @splat(0),
    received: usize = 0,
    typed: usize = 0,
    reads: usize = 0,
    eof: usize = 0,
    resets: [2]usize = @splat(0),
    error_status: [2]c_int = @splat(c.LSQUIC_SERR_UNAVAILABLE),
    errors: [2]u64 = @splat(0),
    closes: usize = 0,
};

/// Two endpoints each have at most eight fixture stream contexts.
const Observation = struct {
    records: [16]StreamRecord = @splat(.{}),
    count: usize = 0,
    callbacks: usize = 0,
    failure: ?anyerror = null,
};

const Event = enum { typed, data, eof, reset, stop, close };
const Await = struct {
    role: c.enum_uwz_wt_role,
    id: u64,
    event: Event,
    size: usize = 0,
};

const CallbackSnapshot = struct {
    client: c.struct_uwz_wt_stream_snapshot,
    server: c.struct_uwz_wt_stream_snapshot,
};

const DelayConfiguration = struct {
    calls: usize = 0,
    delayed_clients: usize = 0,
};

fn find(observation: *Observation, role: c.enum_uwz_wt_role, id: u64) ?*StreamRecord {
    for (observation.records[0..observation.count]) |*record| {
        if (record.id == id and record.role == role) return record;
    }
    return null;
}

fn observe_event(observation: *Observation, role: c.enum_uwz_wt_role, id: u64, event: c.enum_uwz_wt_event, native: ?*c.lsquic_stream, bytes: [*c]const u8, size: usize) !void {
    observation.callbacks += 1;
    if (event == c.UWZ_WT_EVENT_TYPED) {
        try testing.expect(find(observation, role, id) == null);
        try testing.expect(observation.count < observation.records.len);
        const record = &observation.records[observation.count];
        try testing.expectEqual(backend.QueryResult.ok, backend.read_stream(native, &record.info));
        try testing.expectEqual(backend.Association.child, record.info.association);
        record.role = role;
        record.id = id;
        record.typed = 1;
        observation.count += 1;
    }
    const record = find(observation, role, id) orelse return;
    try testing.expectEqual(backend.QueryResult.ok, backend.read_receive(native, &record.receive));
    if (event == c.UWZ_WT_EVENT_DATA) {
        try testing.expect(bytes != null and size > 0 and size <= record.bytes.len - record.received);
        @memcpy(record.bytes[record.received..][0..size], bytes[0..size]);
        record.received += size;
        record.reads += 1;
    }
    if (event == c.UWZ_WT_EVENT_EOF) record.eof += 1;
    if (event == c.UWZ_WT_EVENT_RESET or event == c.UWZ_WT_EVENT_STOP) {
        const how: usize = if (event == c.UWZ_WT_EVENT_RESET) 0 else 1;
        record.error_status[how] = c.lsquic_stream_get_reset_error(native, @intCast(how), &record.errors[how]);
        try testing.expectEqual(@as(c_int, c.LSQUIC_SERR_AVAILABLE), record.error_status[how]);
        record.resets[how] += 1;
    }
    if (event == c.UWZ_WT_EVENT_CLOSE) {
        record.close_receive = record.receive;
        record.closes += 1;
    }
}

fn observe(context: ?*anyopaque, role: c.enum_uwz_wt_role, id: u64, event: c.enum_uwz_wt_event, native: ?*c.lsquic_stream, bytes: [*c]const u8, size: usize) callconv(.c) void {
    const observation: *Observation = @ptrCast(@alignCast(context orelse return));
    if (observation.failure != null) return;
    observe_event(observation, role, id, event, native, bytes, size) catch |err| {
        observation.failure = err;
    };
}

fn checked(observation: *const Observation) !void {
    if (observation.failure) |err| return err;
}

fn pump(fixture: *c.struct_uwz_wt_fixture, observation: *const Observation) !void {
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_pump(fixture, 1));
    try checked(observation);
}

fn await_event(fixture: *c.struct_uwz_wt_fixture, observation: *Observation, expected: Await) !*StreamRecord {
    for (0..max_steps) |_| {
        if (find(observation, expected.role, expected.id)) |record| {
            const ready = switch (expected.event) {
                .typed => record.typed == 1,
                .data => record.received == expected.size,
                .eof => record.eof == 1,
                .reset => record.resets[0] == 1,
                .stop => record.resets[1] == 1,
                .close => record.closes == 1,
            };
            if (ready) return record;
        }
        try pump(fixture, observation);
    }
    return error.NativeEventTimeout;
}

fn native_stream(fixture: *c.struct_uwz_wt_fixture, role: c.enum_uwz_wt_role, id: u64) !*c.lsquic_stream {
    return c.uwz_wt_fixture_stream(fixture, role, id) orelse error.NativeStreamClosed;
}

fn snapshot(fixture: *c.struct_uwz_wt_fixture, role: c.enum_uwz_wt_role, id: u64) !backend.ReceiveSnapshot {
    var result: backend.ReceiveSnapshot = .{};
    try testing.expectEqual(backend.QueryResult.ok, backend.read_receive(try native_stream(fixture, role, id), &result));
    return result;
}

fn flags(fixture: *c.struct_uwz_wt_fixture, role: c.enum_uwz_wt_role, id: u64) !c.struct_uwz_wt_native_flags {
    var result: c.struct_uwz_wt_native_flags = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_stream_flags(try native_stream(fixture, role, id), &result));
    return result;
}

fn configure_delayed_client(context: ?*anyopaque, settings: [*c]c.lsquic_engine_settings, callbacks: [*c]c.lsquic_stream_if) callconv(.c) c_int {
    _ = callbacks;
    if (context == null or settings == null) return -1;
    const configured: *DelayConfiguration = @ptrCast(@alignCast(context.?));
    // The fixture initializes the client before the server, without retaining this context.
    if (configured.calls == 0) {
        settings.*.es_delay_onclose = 1;
        configured.delayed_clients += 1;
    }
    configured.calls += 1;
    settings.*.es_datagrams = 1;
    settings.*.es_reset_stream_at = 1;
    settings.*.es_webtransport.enabled = 1;
    settings.*.es_webtransport.initial_max_data = 65536;
    settings.*.es_webtransport.initial_max_streams_bidi = 16;
    settings.*.es_webtransport.initial_max_streams_uni = 16;
    return 0;
}

fn create_pair(observation: *Observation, delay_client_close: bool) !*c.struct_uwz_wt_fixture {
    try testing.expect(backend.available);
    var configured: DelayConfiguration = .{};
    const fixture = if (delay_client_close)
        c.uwz_wt_fixture_create(configure_delayed_client, &configured) orelse return error.FixtureInitialization
    else
        c.uwz_wt_fixture_create(null, null) orelse return error.FixtureInitialization;
    errdefer c.uwz_wt_fixture_destroy(fixture);
    if (delay_client_close) {
        try testing.expectEqual(@as(usize, 2), configured.calls);
        try testing.expectEqual(@as(usize, 1), configured.delayed_clients);
    }
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_observe(fixture, observe, observation));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_connect(fixture));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_handshake(fixture));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_open_connect(fixture));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_await_headers(fixture, c.UWZ_WT_SERVER));
    try testing.expectEqual(backend.CreateResult.ok, backend.accept_connect(c.uwz_wt_fixture_stream(fixture, c.UWZ_WT_SERVER, 0)));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_send_success(fixture));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_await_headers(fixture, c.UWZ_WT_CLIENT));
    try testing.expectEqual(backend.CreateResult.ok, backend.accept_connect(c.uwz_wt_fixture_stream(fixture, c.UWZ_WT_CLIENT, 0)));
    try checked(observation);
    return fixture;
}

fn open_child(fixture: *c.struct_uwz_wt_fixture, observation: *Observation, direction: backend.Direction) !u64 {
    try testing.expectEqual(backend.CreateResult.ok, backend.create_child(c.uwz_wt_fixture_connection(fixture, c.UWZ_WT_CLIENT), 0, direction));
    const child = c.uwz_wt_fixture_last_child(fixture, c.UWZ_WT_CLIENT) orelse return error.NoChild;
    const id = c.lsquic_stream_id(child);
    _ = try await_event(fixture, observation, .{ .role = c.UWZ_WT_CLIENT, .id = id, .event = .typed });
    const incoming = try await_event(fixture, observation, .{ .role = c.UWZ_WT_SERVER, .id = id, .event = .typed });
    try testing.expectEqual(@as(u8, 3), incoming.info.receive_prefix_size);
    try testing.expectEqual(direction, incoming.info.direction);
    return id;
}

fn send_payload(fixture: *c.struct_uwz_wt_fixture, role: c.enum_uwz_wt_role, id: u64, bytes: []const u8, fin: bool) !void {
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_write(try native_stream(fixture, role, id), bytes.ptr, bytes.len, @intFromBool(fin)));
}

fn stop(fixture: *c.struct_uwz_wt_fixture, role: c.enum_uwz_wt_role, id: u64, code: u64) !backend.StopResult {
    return backend.stop_receiving(try native_stream(fixture, role, id), code);
}

fn callback_snapshot(fixture: *c.struct_uwz_wt_fixture, id: u64) !CallbackSnapshot {
    var result: CallbackSnapshot = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_stream_snapshot(fixture, c.UWZ_WT_CLIENT, id, &result.client));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_stream_snapshot(fixture, c.UWZ_WT_SERVER, id, &result.server));
    return result;
}

fn assert_parent(fixture: *c.struct_uwz_wt_fixture) !void {
    for ([_]c.enum_uwz_wt_role{ c.UWZ_WT_CLIENT, c.UWZ_WT_SERVER }) |role| {
        var info: backend.StreamInfo = .{};
        try testing.expectEqual(backend.QueryResult.ok, backend.read_stream(try native_stream(fixture, role, 0), &info));
        try testing.expectEqual(backend.Association.connect, info.association);
        try testing.expect(c.uwz_wt_fixture_connection(fixture, role) != null);
    }
}

fn close_application(fixture: *c.struct_uwz_wt_fixture, role: c.enum_uwz_wt_role, id: u64) !void {
    const native = c.uwz_wt_fixture_stream(fixture, role, id) orelse return;
    var state: c.struct_uwz_wt_native_flags = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_stream_flags(native, &state));
    if (state.application_closed != 0) return;
    try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_close(native));
}

fn coded_uni(code: u64) !void {
    var observation: Observation = .{};
    const fixture = try create_pair(&observation, false);
    defer c.uwz_wt_fixture_destroy(fixture);
    const id = try open_child(fixture, &observation, .uni);
    try testing.expectEqual(backend.StopResult.unsupported, try stop(fixture, c.UWZ_WT_CLIENT, id, code));
    try send_payload(fixture, c.UWZ_WT_CLIENT, id, &inbound, false);
    const receiver = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_SERVER, .id = id, .event = .data, .size = inbound.len });
    try testing.expectEqualSlices(u8, &inbound, receiver.bytes[0..receiver.received]);
    const before = try snapshot(fixture, c.UWZ_WT_SERVER, id);
    const before_flags = try flags(fixture, c.UWZ_WT_SERVER, id);
    const callbacks = observation.callbacks;
    const native_callbacks = try callback_snapshot(fixture, id);
    try testing.expectEqual(backend.StopResult.invalid, try stop(fixture, c.UWZ_WT_SERVER, id, largest_code + 1));
    try testing.expectEqualDeep(before, try snapshot(fixture, c.UWZ_WT_SERVER, id));
    try testing.expectEqualDeep(before_flags, try flags(fixture, c.UWZ_WT_SERVER, id));
    try testing.expectEqual(backend.StopResult.ok, try stop(fixture, c.UWZ_WT_SERVER, id, code));
    try testing.expectEqual(callbacks, observation.callbacks);
    try testing.expectEqualDeep(native_callbacks, try callback_snapshot(fixture, id));
    const stopped = try snapshot(fixture, c.UWZ_WT_SERVER, id);
    try testing.expect(stopped.read_cancelled);
    try testing.expectEqual(@as(?u64, null), stopped.final_size);
    try testing.expectEqual(@as(c_uint, 1), (try flags(fixture, c.UWZ_WT_SERVER, id)).waiting_final);
    const stopped_flags = try flags(fixture, c.UWZ_WT_SERVER, id);
    try testing.expectEqual(backend.StopResult.ok, try stop(fixture, c.UWZ_WT_SERVER, id, code));
    try testing.expectEqualDeep(stopped_flags, try flags(fixture, c.UWZ_WT_SERVER, id));
    try testing.expectEqual(backend.StopResult.invalid, try stop(fixture, c.UWZ_WT_SERVER, id, code ^ 1));
    try testing.expectEqualDeep(stopped_flags, try flags(fixture, c.UWZ_WT_SERVER, id));
    try testing.expectEqual(callbacks, observation.callbacks);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_process_role(fixture, c.UWZ_WT_SERVER, 20));
    try checked(&observation);
    try testing.expectEqual(@as(usize, 0), receiver.closes);
    _ = try native_stream(fixture, c.UWZ_WT_SERVER, id);
    try testing.expectEqual(@as(?u64, null), (try snapshot(fixture, c.UWZ_WT_SERVER, id)).final_size);
    const peer = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_CLIENT, .id = id, .event = .stop });
    try testing.expectEqual(code, peer.errors[1]);
    try testing.expectEqual(@as(?u64, code), peer.receive.stop_error);
    try testing.expectEqual(backend.StopResult.ok, try stop(fixture, c.UWZ_WT_SERVER, id, code));
    try testing.expectEqual(backend.StopResult.invalid, try stop(fixture, c.UWZ_WT_SERVER, id, code ^ 1));
    const closed = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_SERVER, .id = id, .event = .close });
    try testing.expectEqual(@as(?u64, inbound.len + 3), closed.close_receive.final_size);
    try testing.expect(closed.close_receive.read_cancelled);
    try testing.expectEqual(@as(usize, 1), peer.resets[1]);
    try assert_parent(fixture);
}

test "coded STOP rejects incoming UNI with WebTransport error and retains final accounting" {
    try coded_uni(rejected);
}

test "coded STOP preserves the largest 62 bit peer application error" {
    try coded_uni(largest_code);
}

test "explicit numeric zero STOP is distinct from legacy HTTP no error" {
    try coded_uni(0);
}

test "BIDI receive STOP preserves local transmit and independent RESET error" {
    var observation: Observation = .{};
    const fixture = try create_pair(&observation, false);
    defer c.uwz_wt_fixture_destroy(fixture);
    const id = try open_child(fixture, &observation, .bidi);
    try send_payload(fixture, c.UWZ_WT_CLIENT, id, &inbound, false);
    _ = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_SERVER, .id = id, .event = .data, .size = inbound.len });
    const callbacks = observation.callbacks;
    const native_callbacks = try callback_snapshot(fixture, id);
    try testing.expectEqual(backend.StopResult.ok, try stop(fixture, c.UWZ_WT_SERVER, id, rejected));
    try testing.expectEqual(callbacks, observation.callbacks);
    try testing.expectEqualDeep(native_callbacks, try callback_snapshot(fixture, id));
    try send_payload(fixture, c.UWZ_WT_SERVER, id, &reverse, false);
    const peer = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_CLIENT, .id = id, .event = .data, .size = reverse.len });
    try testing.expectEqualSlices(u8, &reverse, peer.bytes[0..peer.received]);
    _ = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_CLIENT, .id = id, .event = .stop });
    try testing.expectEqual(rejected, peer.errors[1]);
    try testing.expectEqual(@as(c_int, c.LSQUIC_SRA_OK), c.lsquic_stream_reset_at(try native_stream(fixture, c.UWZ_WT_SERVER, id), 373, reverse.len));
    _ = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_CLIENT, .id = id, .event = .reset });
    try testing.expectEqual(@as(u64, 373), peer.errors[0]);
    try testing.expectEqual(rejected, peer.errors[1]);
    try testing.expectEqual(@as(?u64, reverse.len), peer.receive.final_size);
    try testing.expectEqual(@as(?u64, 373), peer.receive.reset_error);
    try testing.expectEqual(@as(?u64, rejected), peer.receive.stop_error);
    try close_application(fixture, c.UWZ_WT_CLIENT, id);
    _ = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_SERVER, .id = id, .event = .close });
    _ = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_CLIENT, .id = id, .event = .close });
    try assert_parent(fixture);
}

test "explicit STOP after FIN received but unread keeps exact code and has no final wait" {
    var observation: Observation = .{};
    const fixture = try create_pair(&observation, true);
    defer c.uwz_wt_fixture_destroy(fixture);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_pause_reads(fixture, c.UWZ_WT_SERVER, 1));
    const id = try open_child(fixture, &observation, .uni);
    try send_payload(fixture, c.UWZ_WT_CLIENT, id, &inbound, true);
    for (0..max_steps) |_| {
        if ((try snapshot(fixture, c.UWZ_WT_SERVER, id)).fin_received) break;
        try pump(fixture, &observation);
    }
    const before = try snapshot(fixture, c.UWZ_WT_SERVER, id);
    try testing.expect(before.fin_received);
    const receiver = find(&observation, c.UWZ_WT_SERVER, id).?;
    try testing.expectEqual(@as(usize, 0), receiver.received);
    try testing.expectEqual(@as(usize, 0), receiver.eof);
    try testing.expectEqual(backend.StopResult.ok, try stop(fixture, c.UWZ_WT_SERVER, id, rejected));
    try testing.expectEqual(@as(c_uint, 0), (try flags(fixture, c.UWZ_WT_SERVER, id)).waiting_final);
    const peer = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_CLIENT, .id = id, .event = .stop });
    try testing.expectEqual(rejected, peer.errors[1]);
    const closed = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_SERVER, .id = id, .event = .close });
    try testing.expectEqual(@as(?u64, inbound.len + 3), closed.close_receive.final_size);
    try testing.expectEqual(@as(usize, 0), receiver.received);
    try assert_parent(fixture);
}

test "legacy read shutdown retains HTTP no error STOP code" {
    var observation: Observation = .{};
    const fixture = try create_pair(&observation, false);
    defer c.uwz_wt_fixture_destroy(fixture);
    const id = try open_child(fixture, &observation, .uni);
    try send_payload(fixture, c.UWZ_WT_CLIENT, id, &inbound, false);
    _ = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_SERVER, .id = id, .event = .data, .size = inbound.len });
    try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_shutdown(try native_stream(fixture, c.UWZ_WT_SERVER, id), 0));
    const peer = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_CLIENT, .id = id, .event = .stop });
    try testing.expectEqual(@as(u64, 0x100), peer.errors[1]);
    _ = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_SERVER, .id = id, .event = .close });
    try assert_parent(fixture);
}

test "legacy read shutdown still suppresses STOP when FIN is already received" {
    var observation: Observation = .{};
    const fixture = try create_pair(&observation, false);
    defer c.uwz_wt_fixture_destroy(fixture);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_pause_reads(fixture, c.UWZ_WT_SERVER, 1));
    const id = try open_child(fixture, &observation, .bidi);
    try send_payload(fixture, c.UWZ_WT_CLIENT, id, &inbound, true);
    for (0..max_steps) |_| {
        if ((try snapshot(fixture, c.UWZ_WT_SERVER, id)).fin_received) break;
        try pump(fixture, &observation);
    }
    try testing.expect((try snapshot(fixture, c.UWZ_WT_SERVER, id)).fin_received);
    try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_shutdown(try native_stream(fixture, c.UWZ_WT_SERVER, id), 0));
    try testing.expectEqual(@as(c_uint, 0), (try flags(fixture, c.UWZ_WT_SERVER, id)).waiting_final);
    try send_payload(fixture, c.UWZ_WT_SERVER, id, &reverse, true);
    const peer = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_CLIENT, .id = id, .event = .eof });
    try testing.expectEqualSlices(u8, &reverse, peer.bytes[0..peer.received]);
    try testing.expectEqual(@as(usize, 0), peer.resets[1]);
    try testing.expectEqual(@as(?u64, null), peer.receive.stop_error);
    _ = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_SERVER, .id = id, .event = .close });
    try assert_parent(fixture);
}

test "explicit STOP is closed after actual read EOF" {
    var observation: Observation = .{};
    const fixture = try create_pair(&observation, false);
    defer c.uwz_wt_fixture_destroy(fixture);
    const id = try open_child(fixture, &observation, .bidi);
    try send_payload(fixture, c.UWZ_WT_CLIENT, id, &inbound, true);
    _ = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_SERVER, .id = id, .event = .eof });
    const before = try flags(fixture, c.UWZ_WT_SERVER, id);
    try testing.expectEqual(backend.StopResult.closed, try stop(fixture, c.UWZ_WT_SERVER, id, rejected));
    try testing.expectEqualDeep(before, try flags(fixture, c.UWZ_WT_SERVER, id));
    try send_payload(fixture, c.UWZ_WT_SERVER, id, &reverse, true);
    const peer = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_CLIENT, .id = id, .event = .eof });
    try testing.expectEqualSlices(u8, &reverse, peer.bytes[0..peer.received]);
    try testing.expectEqual(@as(usize, 0), peer.resets[1]);
    if (c.uwz_wt_fixture_stream(fixture, c.UWZ_WT_SERVER, id)) |native| {
        try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_close(native));
    }
    _ = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_SERVER, .id = id, .event = .close });
    try assert_parent(fixture);
}

test "explicit STOP is closed for known hidden RESET without changing receive state" {
    var observation: Observation = .{};
    const fixture = try create_pair(&observation, false);
    defer c.uwz_wt_fixture_destroy(fixture);
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_pause_reads(fixture, c.UWZ_WT_SERVER, 1));
    const id = try open_child(fixture, &observation, .bidi);
    try send_payload(fixture, c.UWZ_WT_CLIENT, id, &inbound, false);
    try testing.expectEqual(@as(c_int, c.LSQUIC_SRA_OK), c.lsquic_stream_reset_at(try native_stream(fixture, c.UWZ_WT_CLIENT, id), 373, 7));
    for (0..max_steps) |_| {
        if ((try snapshot(fixture, c.UWZ_WT_SERVER, id)).reset_error != null) break;
        try pump(fixture, &observation);
    }
    const before = try snapshot(fixture, c.UWZ_WT_SERVER, id);
    try testing.expectEqual(@as(?u64, 373), before.reset_error);
    try testing.expect(!before.reset_visible);
    const before_flags = try flags(fixture, c.UWZ_WT_SERVER, id);
    try testing.expectEqual(backend.StopResult.closed, try stop(fixture, c.UWZ_WT_SERVER, id, rejected));
    try testing.expectEqualDeep(before, try snapshot(fixture, c.UWZ_WT_SERVER, id));
    try testing.expectEqualDeep(before_flags, try flags(fixture, c.UWZ_WT_SERVER, id));
    try testing.expectEqual(@as(c_int, 0), c.uwz_wt_fixture_enable_reads(try native_stream(fixture, c.UWZ_WT_SERVER, id)));
    const receiver = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_SERVER, .id = id, .event = .reset });
    try testing.expectEqual(@as(u64, 373), receiver.errors[0]);
    try testing.expectEqual(@as(usize, 0), find(&observation, c.UWZ_WT_CLIENT, id).?.resets[1]);
    try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_close(try native_stream(fixture, c.UWZ_WT_SERVER, id)));
    try close_application(fixture, c.UWZ_WT_CLIENT, id);
    _ = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_SERVER, .id = id, .event = .close });
    _ = try await_event(fixture, &observation, .{ .role = c.UWZ_WT_CLIENT, .id = id, .event = .close });
    try assert_parent(fixture);
}
