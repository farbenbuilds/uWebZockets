const std = @import("std");
const runtime = @import("builds/runtime.zig");

pub fn build(b: *std.Build) void {
    runtime.configure(b);
}
