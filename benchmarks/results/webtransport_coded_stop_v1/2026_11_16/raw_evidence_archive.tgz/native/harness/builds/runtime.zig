const std = @import("std");
const boringssl = @import("vendor/boringssl.zig");
const lsquic = @import("vendor/lsquic.zig");
const sanitizers = @import("sanitizers.zig");
const zlib = @import("vendor/zlib.zig");

pub fn configure(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const native_tests = b.option([]const u8, "native-tests-source", "Scratch native test driver") orelse "tests/stop_native.zig";
    const sanitizer = sanitizers.configure(b, target, true);
    const bssl = boringssl.build(b, target, optimize, sanitizer);
    const z = zlib.build(b, target, optimize, sanitizer);
    const ls = lsquic.build(b, target, optimize, sanitizer, bssl, z, true, false, false);
    const translate = b.addTranslateC(.{
        .root_source_file = b.path("fixtures/c.h"),
        .target = target,
        .optimize = optimize,
    });
    translate.addIncludePath(ls.include_root);
    translate.addIncludePath(bssl.include_root);
    translate.addIncludePath(b.path("fixtures"));
    const c_module = translate.createModule();
    const project = b.createModule(.{
        .root_source_file = b.path("project/module.zig"),
        .target = target,
        .optimize = optimize,
        .imports = &.{.{ .name = "c", .module = c_module }},
    });
    const module = b.createModule(.{
        .root_source_file = b.path(native_tests),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
        .imports = &.{
            .{ .name = "c", .module = c_module },
            .{ .name = "project", .module = project },
        },
    });
    module.addIncludePath(ls.include_root);
    module.addIncludePath(bssl.include_root);
    module.addIncludePath(ls.assembled_root.path(b, "src/liblsquic"));
    module.addIncludePath(ls.assembled_root.path(b, "src/lshpack"));
    module.addIncludePath(ls.assembled_root.path(b, "src/liblsquic/ls-qpack"));
    module.addIncludePath(b.path("fixtures"));
    module.addCSourceFiles(.{
        .files = &.{ "fixtures/uwz_quic_fixture.c", "fixtures/uwz_wt_bridge.c" },
        .flags = sanitizers.instrumented_flags(b, &.{
            "-std=gnu11",
            "-UNDEBUG",
            "-D__wrap_lsquic_time_now=lsquic_time_now",
            "-Wall",
            "-Wextra",
            "-fno-omit-frame-pointer",
        }, sanitizer),
    });
    module.linkLibrary(ls.library);
    module.linkLibrary(bssl.ssl);
    module.linkLibrary(bssl.crypto);
    module.linkLibrary(z.library);
    sanitizer.attach(module);
    const tests = b.addTest(.{ .name = "uwz_wt_stop_native", .root_module = module });
    const run = sanitizers.add_run_artifact(b, tests, sanitizer.run);
    const test_step = b.step("test", "Run nine coded STOP and six ledger native cases");
    test_step.dependOn(&run.step);
    const native_step = b.step("test-native", "Run nine coded STOP and six ledger native cases");
    native_step.dependOn(&run.step);
    const compile_step = b.step("test-compile", "Compile the native receive-ledger cases");
    compile_step.dependOn(&tests.step);
    const libraries_step = b.step("libraries", "Compile the exact native dependency graph");
    libraries_step.dependOn(&ls.library.step);
    b.default_step = test_step;
}
