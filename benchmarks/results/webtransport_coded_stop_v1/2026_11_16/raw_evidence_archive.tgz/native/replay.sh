#!/bin/sh
set -eu
ulimit -c 0
uwz_stop_checkpoint=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
uwz_stop_zig=${UWZ_STOP_ZIG:-/tmp/zig-x86_64-linux-0.16.0/zig}
uwz_stop_source=${UWZ_STOP_LSQUIC_SOURCE:-/tmp/uwz-lsquic-wt-stop-20261116}
uwz_stop_packages=${UWZ_STOP_PACKAGE_DIR:-/tmp/uwz-lsquic-uni-harness/zig-pkg}
uwz_stop_cache=${UWZ_STOP_GLOBAL_CACHE:-/tmp/uwz-uni-global-cache}
(
    cd "$uwz_stop_source"
    sha256sum -c "$uwz_stop_checkpoint/harness/provenance/native-final-freeze.sha256"
    sha256sum -c "$uwz_stop_checkpoint/harness/provenance/native-final-source-inputs.sha256"
)
cd "$uwz_stop_checkpoint/harness"
if test "$#" -eq 0; then
    set -- Debug ReleaseSafe ReleaseFast
fi
for uwz_stop_mode in "$@"; do
    case "$uwz_stop_mode" in
        Debug|ReleaseSafe|ReleaseFast) ;;
        *) printf '%s\n' "unsupported mode: $uwz_stop_mode" >&2; exit 2 ;;
    esac
    ZIG_GLOBAL_CACHE_DIR="$uwz_stop_cache" "$uwz_stop_zig" build test \
        --system "$uwz_stop_packages" \
        -Doptimize="$uwz_stop_mode" -Dlsquic-source="$uwz_stop_source" \
        -j2 --summary all
done
