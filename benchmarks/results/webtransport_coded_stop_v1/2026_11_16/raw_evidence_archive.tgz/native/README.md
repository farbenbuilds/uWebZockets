# Explicit STOP Zig/native checkpoint

All fifteen functional tests pass in Debug, ReleaseSafe and ReleaseFast:
nine strong-wrapper STOP cases and six unchanged child-ledger regressions.
There is no anchor test. The actual HTTP/TLS engines exchange real encrypted
packets through bounded in-memory queues with a synthetic native clock. This
cohort does not use UDP, xev, Engine/App child delivery or an independent client.

The exact tested project copies are backend8a2755... and child_ledger95c45beb....
The unchanged ledger driver is f149e801...; the STOP driver is f37d7fe1....
Full hashes, source copies and all original logs are included. The ordinary
profile advertises 65536 bytes of genuine peer stream credit in all three
receive directions; only the FIN-unread case uses supported client
es_delay_onclose=1. Native flags/snapshots are observed through actual headers
and callbacks. No peer cache, packet, callback or native layout is fabricated.

The tested native source is base
2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c plus frozen feature diff
828f4c3b6f386981c56e4985bb1b19a86deadf9372f88f4e0dae1eafe5d0e2ad.
A separately supplied native_source/ proposal in the combined handoff contains
the complete source, history and bundle. This package does not duplicate that
repository. Any later local proposal commit must match the tested native
manifests. Production dependency pins remain unchanged.

Final modes share these immutable manifests:

- Scratch compiled source: ccf94d0ef432d716563abe72c9aca829ee3c18094a1f3fe4680a33e2e1750909.
- Nine-file native freeze: 105bc1b1fd01ceec3943e6be2fd4db7649d47d36a4aaf00e293f29db4024cf76.
- Full tracked native compile source: 04f69758970c18b2a10471cebc43b4b333796e0166776f7947ca16c35b3a3b91.

harness/README.md and provenance/profile_identity.md record the actual compiled
dependencies, including the inherited ls-hpack package fda48e... versus native
base gitlink cf0f70dd.... They are not claimed to match. qpack package/gitlink
both use 91567706.... No package or gitlink was changed in this STOP prerequisite.

harness/provenance/history.md preserves the dual-declaration RED, the native
worker's real-wire RED, the pre-logging-fix fifteen-case GREEN and final GREEN.
No actual-zero claim is made for the legacy wire RED: legacy HEC_NO_ERROR is
0x100, while explicit zero is independently proved by GREEN. Internal logging
width was corrected before the final three modes. Documentation was updated
only after authoritative mode termination; historical run manifests remain
unchanged. Results belong to this standalone profile, not positive App support.

Run `sh replay.sh Debug` (or ReleaseSafe/ReleaseFast); omit the mode for all
three. Supply the complete frozen native source and exact populated immutable
package inputs. Environment options select Zig, source, package and writable
cache paths. Replay verifies native hashes and disables package fetching.
The archive contains source, manifests, logs and licenses, without caches,
binaries, runtime TLS-key files or external symlinks. Dedicated smoke, security,
sanitizer and fuzz campaigns remain deferred.
