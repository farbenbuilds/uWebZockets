# Coded receive cancellation prerequisite, 2026-11-16

Base project commit: `b6f8455dad748745d2b9a714026a769b3d3b5125`.
Zig: `/tmp/zig-x86_64-linux-0.16.0/zig` (0.16.0).

The base native proposal cannot express the required receive rejection
for a unidirectional child: `reset_at` rejects incoming UNI, while ordinary
read shutdown emits STOP_SENDING with `HEC_NO_ERROR` (`0x100`). The native wire helper also takes
an HTTP error enum instead of a full QUIC error value. This is a prerequisite
for bounded early-child admission, not a replacement for that integration.

[Draft-16 section 4.6](https://www.ietf.org/archive/id/draft-ietf-webtrans-http3-16.html#section-4.6)
requires a specific rejection error when buffered streams exceed their bound.
[RFC 9000 section 3.3](https://www.rfc-editor.org/rfc/rfc9000.html#section-3.3)
permits STOP after FIN has arrived while its data remains unread; received-reset
states are excluded. Explicit cancellation must therefore differ from ordinary
shutdown, which suppresses STOP after FIN receipt.

Root adds `backend.StopResult` and `stop_receiving`, with full optional-contract
gating for the new native entry point and all SST result constants. A blocked
result leaves retry policy to the caller. Cancellation preserves the local
write half and keeps its error separate from local RESET and received STOP.
Successful cancellation does not grant permission to release native ownership
before `on_close`. The unchanged production pin lacks the complete contract.

The Root missing-API RED is retained. The final Root checks pass 1023/1023
functional tests in 20/20 build steps (26 seconds executing), ReleaseSafe test
compilation 21/21 steps and ReleaseFast library 21/21 steps. The full unit suite
runs with loopback available from the start. Rejection-path TLS/authentication
and io_uring diagnostics are retained in the successful original log.

Conventions and release-version checks passed. Exact `zig fmt src builds
examples tests fuzz` protected two nested cache directories with same-filesystem
rename and restored them afterward. Formatting changed none of 297 tracked/new
source/build inputs, which remain hash-identical after all Root builds. Graphify
was updated in AST-only mode. No lint, assertion, threshold, default or test was
weakened. Smoke, security, sanitizer and fuzz campaigns remain deferred.

Restore the base repository and copy `root/` over it. This contains the complete
297-input overlay indexed by `provenance/source.sha256`. User-owned vendor
changes are excluded. Root commands were:

```sh
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache zig build test-unit --global-cache-dir /tmp/uwz-zig-cache --summary all
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache zig build test-compile -Doptimize=ReleaseSafe --global-cache-dir /tmp/uwz-zig-cache --summary all
ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache zig build lib -Doptimize=ReleaseFast --global-cache-dir /tmp/uwz-zig-cache --summary all
sh scripts/check_conventions.sh
sh scripts/check_release_version.sh
```

Engine/App child handling, production pins and activation remain unchanged.
The next integration must attach generation-checked ledgers, associate and
expire bounded early children, route real bytes to an explicit consumer, and
propagate terminal events while retaining delayed final-size ownership.
Supported public child I/O, application TX, multi-session flow accounting,
independent-client acceptance, dependency publication/pins and the other
v2.3.0 release gates remain open.

The read-only publication check is retained in
`provenance/lsquic-publication-permission.json`: the current GitHub CLI viewer
has `READ` permission on `farbenbuilds/lsquic`, whose mirror default branch is
`master`. No fork publication or pin update was attempted. The tested proposal
is preserved for maintained-fork owner review; Root commits are pushed separately
to the authorized project repository.

The complete new native proposal is local commit
`530e9e505eb04a0a4095b290f7eb052504ace94e`, parent
`2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c`. It changes exactly nine files:
six native files and three tests. Core receive cancellation, queue/final-size
retention and reset suppression passed six native C Debug cases. The same
pre-logging revision passed 65 existing WebTransport cases (8 normal, 12
resets, 33 classification, 12 placement) and 83 upstream Debug cases.

Independent review found a remaining private event logger using uint16_t.
Both a signature compile RED and an actual formatted-output RED are retained.
The final correction widens its declaration/definition to uint64_t/PRIu64
and adds a capture test for decimal `4611686018427387903` and legacy `256`.
Its Debug GREEN passes 12/12 build steps. The four core files and existing
fixture tests are unchanged from the earlier 65/83-test revision. No claim is
made that the earlier legacy cohort ran after this logging-only correction.

The final strong Root-wrapper cohort passes 15/15 tests and 13/13 steps in
Debug, ReleaseSafe and ReleaseFast. It contains nine STOP cases and the six
unchanged receive-ledger regressions. Native source manifest
`105bc1b1fd01ceec3943e6be2fd4db7649d47d36a4aaf00e293f29db4024cf76`,
scratch compiled-input manifest
`ccf94d0ef432d716563abe72c9aca829ee3c18094a1f3fe4680a33e2e1750909`,
and the full tracked native compile-input manifest remained unchanged through
all final runs. The subsequent Git commit changes metadata/tracked membership,
not these tested source bytes; the earlier manifest excludes the three then
untracked new tests, which are independently present in the nine-file manifest.

This cohort uses actual paired LSQUIC HTTP/TLS engines and encrypted packets
delivered by bounded in-memory queues. It uses the inherited synthetic native
scheduling clock and no UDP, xev or App/Engine integration. FIN-unread tests use
the public delayed-close setting so sender context remains observable. Peers
advertise actual positive QUIC receive credits for reverse BIDI data. Native
callbacks, peer bytes, held reads and server-only processing provide the proof;
no native protocol state or production callback is fabricated. Post-pump
operations reacquire live stream pointers, and close snapshots are copied
inside the native callback before invalidation.

The native repository's hpack gitlink remains
`cf0f70dd10b352194c97448eb5d00b4aa484f531`, while the inherited, actually compiled
hpack package is `fda48e02491d865cce00612be8cc10c2622b8e55`. They are not claimed
equivalent. The qpack package and native gitlink both use
`91567706c41c0d97ab8dc576873ecd472d7869fa`. Package URLs, Zig hashes, source inventories and licenses identify
the compiled inputs. No dependency pin was changed by this work.

`native/` contains the strong Zig/native cohort, and `native_source/` contains
the complete C proposal snapshot/history, its native Zig scaffold and C evidence.
Both packages retain their own manifests. The source snapshot leaves submodule
directories unpopulated; the unchanged Zig build graph copies the exact pinned
qpack/hpack packages into its generated build tree without modifying source.

From an extracted combined payload, set the explicit source/package paths:

```sh
UWZ_STOP_ZIG=/path/to/zig UWZ_STOP_LSQUIC_SOURCE="$PWD/native_source/source" UWZ_STOP_PACKAGE_DIR=/path/to/exact/zig-pkg sh native/replay.sh Debug
sh native_source/replay.sh /path/to/zig Debug quick /path/to/exact/zig-pkg
```

Repeat the first command with ReleaseSafe and ReleaseFast. The C replay also
offers logger, baseline-red, logger-red and pre-log-regressions profiles.
Its baseline profiles recover the included Git history; the regular package
is kept read-only and compilation uses a new temporary work directory.
