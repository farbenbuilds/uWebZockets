#include <assert.h>
#include <stdint.h>
#include <string.h>
#include "lsquic.h"
#include "lsquic_hq.h"
struct lsquic_packet_in;
#include "lsquic_ev_log.h"

struct capture {
    unsigned calls;
    char text[1024];
};

static int
capture_log(void *context, const char *bytes, size_t size)
{
    struct capture *capture = context;
    assert(size < sizeof(capture->text));
    memcpy(capture->text, bytes, size);
    capture->text[size] = 0;
    ++capture->calls;
    return (int) size;
}

int
main(void)
{
    static const struct lsquic_logger_if logger = { .log_buf = capture_log };
    struct capture capture = { 0 };
    lsquic_cid_t cid = { 0 };
    uint64_t full_width = (UINT64_C(1) << 62) - 1;
    lsquic_logger_init(&logger, &capture, LLTS_NONE);
    assert(0 == lsquic_logger_lopt("event=debug"));
    lsquic_ev_log_generated_stop_sending_frame(&cid, 4, full_width);
    assert(capture.calls == 1);
    assert(strstr(capture.text, "error code: 4611686018427387903"));
    lsquic_ev_log_generated_stop_sending_frame(&cid, 4, HEC_NO_ERROR);
    assert(capture.calls == 2);
    assert(strstr(capture.text, "error code: 256"));
    return 0;
}
