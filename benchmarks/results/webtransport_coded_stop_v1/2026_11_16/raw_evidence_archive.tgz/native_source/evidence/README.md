# Coded STOP_SENDING proposal evidence

Base: 2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c.
Candidate: /tmp/uwz-lsquic-wt-stop-20261116.
The earlier native candidate and Root checkout are unchanged by this work.

`declaration-red.log` records absent public declarations before implementation.
`wire-red.log` records actual encrypted raw non-HTTP UNI delivery followed by
the legacy read-shutdown STOP error differing from 0x123456789abcdef.
The baseline error is HEC_NO_ERROR (0x100), not numeric zero. The original
fixture comment used zero before that distinction was checked; its archived
source and log remain unchanged under red-source and red.sha256.

`reset-before-send-red.log` records an explicit queued STOP remaining after
a later valid encrypted peer RESET was received before packetization. The
matching GREEN suppresses only that unsent coded STOP. RFC 9000 sections
3.3 and 3.5 describe STOP_SENDING after peer reset:
https://www.rfc-editor.org/rfc/rfc9000.html#section-3.5

The six final Debug case logs cover full-width coded UNI STOP, FIN received
but unread without WAIT_FIN_OFF, BIDI write-half independence, preserved
legacy HEC_NO_ERROR, preserved legacy FIN suppression, and reset-before-send.
The wire variants also exercise failure atomicity, unsupported halves/types,
handshake/live-TP blocking, immutable duplicates, and closed connection status.

source-freeze.sha256 identifies the immutable candidate files for independent
review and additional native tests. That pre-logger revision passed all 65
existing WebTransport cases and all 83 upstream executables in Debug.

The later event logger signature/format change preserves those four API/core
hashes. event-log-capture-red.log demonstrates actual 62-bit output truncation;
event-log-capture-green-debug.log passes maximum-value and legacy HEC_NO_ERROR
formatted output. event-log-width-red.log and event-log-width-green.log retain
the separate private-signature check. source-final-freeze.sha256 identifies
the final revision, including the logger pair and native capture test.

No sanitizer, fuzz, security, or smoke campaign was run.
