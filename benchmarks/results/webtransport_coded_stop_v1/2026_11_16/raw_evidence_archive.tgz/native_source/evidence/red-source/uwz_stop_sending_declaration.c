#include "lsquic.h"

int main(void)
{
    enum lsquic_stream_stop_sending_result result = LSQUIC_SST_INVALID;
    int (*operation)(lsquic_stream_t *, uint64_t) = lsquic_stream_stop_sending;
    return operation(NULL, UINT64_MAX) != result;
}
