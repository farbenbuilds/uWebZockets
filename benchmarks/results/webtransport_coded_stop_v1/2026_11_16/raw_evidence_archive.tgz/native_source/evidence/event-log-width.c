#include <stdint.h>
#include "lsquic.h"
#include "lsquic_ev_log.h"

_Static_assert(__builtin_types_compatible_p(
    __typeof__(&lsquic_ev_log_generated_stop_sending_frame),
    void (*)(const lsquic_cid_t *, lsquic_stream_id_t, uint64_t)),
    "STOP event logger must retain a full QUIC application error");
