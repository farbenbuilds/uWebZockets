# Native coded STOP_SENDING checkpoint

Local proposal commit: `530e9e505eb04a0a4095b290f7eb052504ace94e`.
Parent: `2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c`.
Branch: `uwz/stop-sending-proposal-20261116`.

The proposal adds receive-only `lsquic_stream_stop_sending` with named
LSQUIC_SST results, a full QUIC-varint application error, independent transmit
state, immutable explicit errors and failure-atomic preflight. An unread FIN
still allows an explicit STOP; known finals do not acquire WAIT_FIN_OFF.
Unknown finals retain native context until the final arrives or the connection
is destroyed. A later valid peer RESET suppresses a still-unsent coded STOP.
Legacy generic shutdown retains HEC_NO_ERROR (0x100) and its FIN suppression.
Both the wire generator and event logger preserve full-width errors.

This is an unpublished proposal. No fork push, dependency pin update, listener
activation, Engine child integration or public App stream API is included.

## Contents

- `source/`: complete tracked candidate snapshot, including all nine changed
  files and published upstream test assets. The submodule directories are
  unpopulated; dependency assembly uses the separate pinned packages below.
- `git/`: full-history Git bundle for the proposal and its complete base chain.
- `harness/`: unchanged native Zig build graph and pinned package declarations.
- `licenses/`: lsquic, BoringSSL, ls-qpack, ls-hpack and zlib license texts.
- `evidence/`: original failures, targeted passes, source freezes, logger
  capture/type probes, 65-case WebTransport and 83-executable upstream logs.
- `metadata/`: commit, diff, source/dependency identities and toolchain hashes.

## Dependency qualification

The actual compiled dependencies are listed in `metadata/dependencies.tsv`
and `harness/build.zig.zon`. The ls-qpack revision matches the candidate
gitlink. The compiled ls-hpack revision
`fda48e02491d865cce00612be8cc10c2622b8e55` **does not match** the candidate
gitlink `cf0f70dd10b352194c97448eb5d00b4aa484f531`. The harness deliberately
assembles the pinned compiled package over that unpopulated directory. This
checkpoint makes no source/gitlink match claim for ls-hpack.

Dependency sources and the Zig executable are not duplicated here. Replay
uses Zig 0.16.0 and either exact cached package directories named by their Zig
hashes or Zig's normal fetch of the immutable URLs/hashes. No CMake, Ninja,
system zlib, patch program, external code generator, or runtime key file is
required. Static upstream tracked test assets remain in the source snapshot.

## Evidence and revisions

The pre-logger freeze is `evidence/source-freeze.sha256`, whose manifest SHA256
is `d5be33a0609b0ea4928e1f5fbda796d7fb70e2e172a3f52d64755bced489e72b`.
It passed six focused native Debug cases, all 65 existing WebTransport cases
(8 normal, 12 reset, 33 classification, 12 placement) and all 83 upstream
executables (165/165 build steps). Those logs describe that pre-logger revision.

The final nine-file freeze is `evidence/source-final-freeze.sha256`, whose
manifest SHA256 is
`105bc1b1fd01ceec3943e6be2fd4db7649d47d36a4aaf00e293f29db4024cf76`.
Its four API/core file hashes equal the pre-logger freeze. The later change
widens only the private event logger and adds an actual formatted-output
capture test. Capture/type RED and GREEN are retained. The final independent
TLS Zig wrapper/ledger cohort passed 15/15 in Debug, ReleaseSafe and
ReleaseFast; its complete replay package is maintained separately by Root.

The historical tracked build-input identity covers include/src/wincompat
and excludes the then-untracked new test files. Its original SHA256 is
`04f69758970c18b2a10471cebc43b4b333796e0166776f7947ca16c35b3a3b91`.
`metadata/post-commit-tracked-files.sha256` covers the complete tracked
snapshot, including the new tests after the metadata-only commit. Neither
identity was silently rewritten.
No tests were rerun merely because Git metadata changed. No smoke, security,
sanitizer or fuzz campaign was run.

## Replay

Run `sh replay.sh /path/to/zig Debug quick /path/to/exact/zig-pkg` for the
final declaration, six focused wire/status cases and event-log capture.
The last argument is optional; supplying it disables dependency fetching and
uses the exact cached packages by Zig hash. Omitting it permits normal pinned
Zig package fetching. Mode also accepts ReleaseSafe or ReleaseFast.

`pre-log-regressions` reconstructs the historical pre-logger source by
replacing only the two logger files from the retained originals, then runs
the 65-case WebTransport cohort and all 83 upstream executables. `logger`
runs only the final output capture. Every build uses a new temporary work
directory; the package remains read-only and no old absolute scratch path
is required. The script prints that work directory and retains its logs.

`baseline-red` recovers the base commit from the included bundle and applies
only the preserved test inputs; declaration and encrypted-wire checks must
fail. `logger-red` reconstructs the pre-logger helper and requires the actual
formatted-output capture to fail. These profiles report success only when
the expected failing commands return nonzero.

To recover Git history:

```sh
git clone -b uwz/stop-sending-proposal-20261116 git/lsquic-stop-proposal.bundle proposal
git -C proposal rev-parse HEAD
```

Verify `metadata/package-files.sha256` from this directory before replay.
To verify the final changed-file freeze, run its checksum check from `source/`.
