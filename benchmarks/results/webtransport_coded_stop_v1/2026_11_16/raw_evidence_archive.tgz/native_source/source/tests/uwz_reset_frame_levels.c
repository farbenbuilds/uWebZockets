/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>

#include "lsquic.h"
#include "lsquic_types.h"
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_enc_sess.h"

#ifdef NDEBUG
#error "uwz_reset_frame_levels requires active assertions"
#endif


static int
reset_version_supported (enum lsquic_version version)
{
    switch (version)
    {
    case LSQVER_I002:
    case LSQVER_I001:
    case LSQVER_ID29:
    case LSQVER_ID27:
        return 1;
    default:
        return 0;
    }
}


int
main (void)
{
    unsigned version, level, allowed, expected;

    for (version = 0; version < N_LSQVER; ++version)
        for (level = 0; level < N_ENC_LEVS; ++level)
        {
            allowed = !!(lsquic_legal_frames_by_level[version][level]
                                                & QUIC_FTBIT_RESET_STREAM_AT);
            expected = reset_version_supported((enum lsquic_version) version)
                            && (level == ENC_LEV_APP || level == ENC_LEV_0RTT);
            assert(allowed == expected);
        }
    puts("PASS RESET_STREAM_AT: four IETF App/0RTT rows; Initial/Handshake/gQUIC forbidden");
    return 0;
}
