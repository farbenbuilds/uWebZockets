/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/queue.h>
#include <sys/types.h>

#include <openssl/ssl.h>

#include "lsquic.h"
#include "uwz_quic_fixture.h"
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_packet_in.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"
#include "lsquic_conn.h"
#include "lsquic_conn_public.h"
#include "lsquic_mm.h"
#include "lsquic_engine_public.h"

#ifdef NDEBUG
#error "uwz_webtransport_settings_delivery requires active assertions"
#endif
#ifndef LSQUIC_WT_SETTINGS_TEST_OBSERVER
#error "uwz_webtransport_settings_delivery requires the constructor observer"
#endif

enum {
    DELIVERY_MAX_STEPS = 20000,
    DELIVERY_SETTLE_STEPS = 32,
    DELIVERY_MAX_SETTINGS = 8,
    DELIVERY_WIRE_CAPACITY = 4 + DELIVERY_MAX_SETTINGS * 16,
    DELIVERY_CANARY = 0xA5,
};

struct delivery_setting {
    uint64_t ds_id;
    uint64_t ds_value;
};

struct delivery_wire {
    size_t dw_size;
    size_t dw_first_pair_end;
    unsigned char dw_bytes[DELIVERY_WIRE_CAPACITY];
};

struct delivery_probe {
    unsigned char dp_before[8];
    struct lsquic_webtransport_peer dp_value;
    unsigned char dp_after[8];
};

struct delivery_endpoint {
    lsquic_conn_t *de_conn;
    struct lsquic_conn_public *de_conn_pub;
    lsquic_stream_t *de_control;
    uint64_t de_expected_offset;
    unsigned de_server;
    unsigned de_hold_initial;
    unsigned de_manual;
    unsigned de_constructed;
    unsigned de_new;
    unsigned de_handshake_ok;
    unsigned de_closed;
    unsigned de_notifications;
    unsigned de_pending_probes;
    unsigned de_remote_closes;
    int de_remote_app_error;
    uint64_t de_remote_error;
    int de_close_result;
    struct lsquic_webtransport_peer de_notified_peer;
    struct lsquic_webtransport_peer de_close_peer;
};

struct delivery_fixture {
    struct lsquic_test_pair df_transport;
    struct delivery_endpoint df_client;
    struct delivery_endpoint df_server;
};

struct delivery_invalid_case {
    const char *dic_name;
    size_t dic_count;
    struct delivery_setting dic_settings[2];
};

static const struct delivery_invalid_case invalid_cases[] = {
    { "WT_ENABLED=2", 1, { { HQSID_WT_ENABLED, 2 } } },
    { "H3_DATAGRAM=2", 1, { { HQSID_H3_DATAGRAM, 2 } } },
    { "CONNECT=2", 1, { { HQSID_ENABLE_CONNECT_PROTOCOL, 2 } } },
    { "duplicate WT_ENABLED=0", 2,
      { { HQSID_WT_ENABLED, 0 }, { HQSID_WT_ENABLED, 0 } } },
    { "bidi limit exceeds 2^60", 1,
      { { HQSID_WT_INITIAL_MAX_STREAMS_BIDI, (UINT64_C(1) << 60) + 1 } } },
    { "uni limit exceeds 2^60", 1,
      { { HQSID_WT_INITIAL_MAX_STREAMS_UNI, (UINT64_C(1) << 60) + 1 } } },
};


static void
assert_canary (const void *bytes, size_t size)
{
    const unsigned char *cursor = bytes;
    size_t index;

    for (index = 0; index < size; ++index)
        assert(cursor[index] == DELIVERY_CANARY);
}


static int
query_peer (lsquic_conn_t *conn, struct lsquic_webtransport_peer *out)
{
    struct delivery_probe probe;
    unsigned char original[sizeof(probe)];
    int result;

    assert(conn && out);
    memset(&probe, DELIVERY_CANARY, sizeof(probe));
    memcpy(original, &probe, sizeof(probe));
    result = lsquic_conn_get_webtransport_peer(conn, &probe.dp_value);
    assert_canary(probe.dp_before, sizeof(probe.dp_before));
    assert_canary(probe.dp_after, sizeof(probe.dp_after));
    assert(result == LSQUIC_WTP_OK || result == LSQUIC_WTP_PENDING);
    if (result == LSQUIC_WTP_OK)
        memcpy(out, &probe.dp_value, sizeof(*out));
    else
        assert(0 == memcmp(original, &probe, sizeof(probe)));
    return result;
}


void
lsquic_wt_settings_test_conn (struct lsquic_conn *conn,
                             struct lsquic_conn_public *conn_pub)
{
    struct delivery_endpoint *endpoint;
    struct lsquic_hash_elem *element;
    lsquic_stream_id_t id;

    assert(conn_pub && conn_pub->lconn == conn && conn_pub->enpub);
    endpoint = conn_pub->enpub->enp_stream_if_ctx;
    assert(endpoint && !endpoint->de_constructed);
    assert(endpoint->de_server == !!(conn->cn_flags & LSCONN_SERVER));
    assert(!endpoint->de_conn || endpoint->de_conn == conn);
    id = endpoint->de_server ? 3 : 2;
    element = lsquic_hash_find(conn_pub->all_streams, &id, sizeof(id));
    assert(element);
    endpoint->de_control = lsquic_hashelem_getdata(element);
    assert(endpoint->de_control->id == id);
    assert(endpoint->de_control->conn_pub == conn_pub);
    assert(lsquic_stream_is_critical(endpoint->de_control));
    endpoint->de_conn_pub = conn_pub;
    endpoint->de_constructed = 1;
    if (!endpoint->de_hold_initial)
        return;
    assert(endpoint->de_control->tosend_off == 0);
    assert(endpoint->de_control->sm_n_buffered == 0);
    assert(lsquic_stream_wantwrite(endpoint->de_control, 0) >= 0);
    assert(!(endpoint->de_control->sm_qflags & SMQF_WANT_WRITE));
    endpoint->de_manual = 1;
}


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct delivery_endpoint *endpoint = ctx;

    assert(!endpoint->de_conn && !endpoint->de_new);
    if (endpoint->de_conn_pub)
        assert(endpoint->de_conn_pub->lconn == conn);
    endpoint->de_conn = conn;
    endpoint->de_new = 1;
    if (endpoint->de_server)
        endpoint->de_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct delivery_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint && status == LSQ_HSK_OK);
    endpoint->de_handshake_ok = 1;
}


static void
settings_received (lsquic_conn_t *conn)
{
    struct delivery_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint && endpoint->de_new && endpoint->de_conn == conn);
    assert(endpoint->de_notifications == 0);
    assert(LSQUIC_WTP_OK == query_peer(conn, &endpoint->de_notified_peer));
    ++endpoint->de_notifications;
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct delivery_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint && endpoint->de_conn == conn && !endpoint->de_closed);
    endpoint->de_close_result = query_peer(conn, &endpoint->de_close_peer);
    endpoint->de_closed = 1;
    endpoint->de_conn = NULL;
    endpoint->de_conn_pub = NULL;
    endpoint->de_control = NULL;
    lsquic_conn_set_ctx(conn, NULL);
}


static void
remote_close (lsquic_conn_t *conn, int app_error, uint64_t error,
              const char *reason, int reason_len)
{
    struct delivery_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    (void) reason;
    (void) reason_len;
    assert(endpoint);
    if (endpoint->de_remote_closes)
    {
        assert(endpoint->de_remote_app_error == app_error);
        assert(endpoint->de_remote_error == error);
    }
    endpoint->de_remote_app_error = app_error;
    endpoint->de_remote_error = error;
    ++endpoint->de_remote_closes;
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    (void) ctx;
    (void) stream;
    assert(0 && "SETTINGS delivery creates no application streams");
    return NULL;
}


static void
stream_event (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) stream;
    (void) ctx;
    assert(0 && "SETTINGS delivery uses native critical-stream callbacks");
}


static const struct lsquic_stream_if delivery_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_conncloseframe_received = remote_close,
    .on_new_stream = new_stream,
    .on_read = stream_event,
    .on_write = stream_event,
    .on_close = stream_event,
    .on_h3_settings = settings_received,
};


static void
hold_auto_writer (struct delivery_endpoint *endpoint)
{
    if (!endpoint->de_manual || !endpoint->de_control)
        return;
    assert(lsquic_stream_wantwrite(endpoint->de_control, 0) >= 0);
    assert(endpoint->de_control->tosend_off == endpoint->de_expected_offset);
    assert(endpoint->de_control->sm_n_buffered == 0);
    assert(!(endpoint->de_control->sm_qflags & SMQF_WANT_WRITE));
}


static void
pump_step (struct delivery_fixture *fixture)
{
    hold_auto_writer(&fixture->df_client);
    hold_auto_writer(&fixture->df_server);
    lsquic_test_pair_process(&fixture->df_transport, 1000);
    lsquic_test_deliver_all(&fixture->df_transport.ltp_client);
    lsquic_test_deliver_all(&fixture->df_transport.ltp_server);
    hold_auto_writer(&fixture->df_client);
    hold_auto_writer(&fixture->df_server);
}


static void
init_endpoint (struct delivery_fixture *fixture, unsigned server,
               unsigned hold)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct delivery_endpoint *endpoint;
    struct lsquic_test_endpoint *transport, *other;
    unsigned flags = LSENG_HTTP | (server ? LSENG_SERVER : 0);

    endpoint = server ? &fixture->df_server : &fixture->df_client;
    endpoint->de_server = server;
    endpoint->de_hold_initial = hold;
    transport = server ? &fixture->df_transport.ltp_server
                       : &fixture->df_transport.ltp_client;
    other = server ? &fixture->df_transport.ltp_client
                   : &fixture->df_transport.ltp_server;
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_support_push = 0;
    settings.es_init_max_streams_uni = 8;
    settings.es_max_streams_in = 8;
    settings.es_qpack_dec_max_size = 0;
    settings.es_qpack_dec_max_blocked = 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    settings.es_datagrams = 1;
    settings.es_reset_stream_at = 1;
    settings.es_webtransport.enabled = 1;
    settings.es_webtransport.initial_max_data = server ? 900001 : 65537;
    settings.es_webtransport.initial_max_streams_bidi = server ? 31 : 17;
    settings.es_webtransport.initial_max_streams_uni = server ? 23 : 19;
    assert(0 == lsquic_engine_check_settings(&settings, flags, NULL, 0));
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &delivery_callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_alpn = "h3";
    config.ltec_tls = lsquic_test_tls_context_new(server, "h3");
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(transport, other, &config,
                                        server ? 12901 : 12902));
    SSL_CTX_free(config.ltec_tls);
}


static void
start_fixture (struct delivery_fixture *fixture, unsigned server_sender,
               unsigned hold)
{
    unsigned step;

    memset(fixture, 0, sizeof(*fixture));
    init_endpoint(fixture, 0, hold && !server_sender);
    init_endpoint(fixture, 1, hold && server_sender);
    assert(lsquic_engine_connect(fixture->df_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture->df_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture->df_transport.ltp_server.lte_address,
                &fixture->df_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
    for (step = 0; step < DELIVERY_MAX_STEPS; ++step)
    {
        pump_step(fixture);
        assert(!fixture->df_client.de_closed && !fixture->df_server.de_closed);
        if (fixture->df_client.de_handshake_ok && fixture->df_server.de_handshake_ok
                && fixture->df_client.de_constructed
                && fixture->df_server.de_constructed
                && (hold || (fixture->df_client.de_notifications == 1
                             && fixture->df_server.de_notifications == 1)))
            break;
    }
    assert(step < DELIVERY_MAX_STEPS);
    for (step = 0; step < DELIVERY_SETTLE_STEPS; ++step)
        pump_step(fixture);
    assert(fixture->df_client.de_conn && fixture->df_server.de_conn);
    assert(fixture->df_transport.ltp_client.lte_packets_received);
    assert(fixture->df_transport.ltp_server.lte_packets_received);
}


static void
cleanup_fixture (struct delivery_fixture *fixture)
{
    lsquic_test_endpoint_destroy(&fixture->df_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture->df_transport.ltp_server);
    assert(fixture->df_client.de_closed == 1 && fixture->df_server.de_closed == 1);
    assert(fixture->df_client.de_new == 1 && fixture->df_server.de_new == 1);
}


static void
assert_pending (struct delivery_endpoint *receiver)
{
    struct lsquic_webtransport_peer peer;
    int result;

    result = receiver->de_conn ? query_peer(receiver->de_conn, &peer)
                              : receiver->de_close_result;
    assert(result == LSQUIC_WTP_PENDING);
    assert(receiver->de_notifications == 0);
    ++receiver->de_pending_probes;
}


static void
assert_unchanged (struct delivery_endpoint *receiver,
                  const struct lsquic_webtransport_peer *expected)
{
    struct lsquic_webtransport_peer peer;
    int result;

    if (receiver->de_conn)
        result = query_peer(receiver->de_conn, &peer);
    else
    {
        result = receiver->de_close_result;
        memcpy(&peer, &receiver->de_close_peer, sizeof(peer));
    }
    assert(result == LSQUIC_WTP_OK);
    assert(0 == memcmp(expected, &peer, sizeof(peer)));
    assert(receiver->de_notifications == 1);
}


static size_t
append_varint (unsigned char *bytes, size_t capacity, size_t offset,
               uint64_t value)
{
    unsigned width, index, prefix;

    assert(value <= VINT_MAX_VALUE);
    width = value < (UINT64_C(1) << 6) ? 1
          : value < (UINT64_C(1) << 14) ? 2
          : value < (UINT64_C(1) << 30) ? 4 : 8;
    assert(offset <= capacity && width <= capacity - offset);
    for (index = 0; index < width; ++index)
        bytes[offset + index] = (unsigned char) (value >> (8 * (width - 1 - index)));
    prefix = width == 1 ? 0 : width == 2 ? 0x40 : width == 4 ? 0x80 : 0xC0;
    bytes[offset] |= prefix;
    return offset + width;
}


static void
make_wire (struct delivery_wire *wire, const struct delivery_setting *settings,
           size_t count, unsigned first_frame)
{
    unsigned char payload[DELIVERY_MAX_SETTINGS * 16];
    size_t size = 0, offset = 0, first_pair = 0, index;

    assert(count > 0 && count <= DELIVERY_MAX_SETTINGS);
    memset(wire, 0, sizeof(*wire));
    for (index = 0; index < count; ++index)
    {
        size = append_varint(payload, sizeof(payload), size, settings[index].ds_id);
        size = append_varint(payload, sizeof(payload), size, settings[index].ds_value);
        if (index == 0)
            first_pair = size;
    }
    if (first_frame)
        offset = append_varint(wire->dw_bytes, sizeof(wire->dw_bytes), offset, 0);
    offset = append_varint(wire->dw_bytes, sizeof(wire->dw_bytes), offset, HQFT_SETTINGS);
    offset = append_varint(wire->dw_bytes, sizeof(wire->dw_bytes), offset, size);
    assert(size <= sizeof(wire->dw_bytes) - offset);
    memcpy(wire->dw_bytes + offset, payload, size);
    wire->dw_first_pair_end = offset + first_pair;
    wire->dw_size = offset + size;
}


static void
make_valid_wire (struct delivery_wire *wire, unsigned server_sender)
{
    struct delivery_setting settings[] = {
        { HQSID_WT_ENABLED, 1 },
        { HQSID_H3_DATAGRAM, 1 },
        { HQSID_WT_INITIAL_MAX_DATA, (UINT64_C(1) << 40) + 9 },
        { HQSID_WT_INITIAL_MAX_STREAMS_BIDI, 17 },
        { HQSID_WT_INITIAL_MAX_STREAMS_UNI, 19 },
        { HQSID_ENABLE_CONNECT_PROTOCOL, 1 },
    };

    make_wire(wire, settings, server_sender ? 6 : 5, 1);
}


static void
send_fragment (struct delivery_fixture *fixture, struct delivery_endpoint *sender,
               const unsigned char *bytes, size_t size)
{
    struct lsquic_test_endpoint *transport = sender->de_server
                    ? &fixture->df_transport.ltp_client
                    : &fixture->df_transport.ltp_server;
    unsigned received = transport->lte_packets_received;
    unsigned step;

    assert(sender->de_conn && sender->de_control && sender->de_manual && size > 0);
    hold_auto_writer(sender);
    assert((ssize_t) size == lsquic_stream_write(sender->de_control, bytes, size));
    sender->de_expected_offset += size;
    assert(0 == lsquic_stream_flush(sender->de_control));
    hold_auto_writer(sender);
    for (step = 0; step < DELIVERY_SETTLE_STEPS; ++step)
        pump_step(fixture);
    assert(transport->lte_packets_received > received);
}


static void
wait_for_error (struct delivery_fixture *fixture, struct delivery_endpoint *sender,
                uint64_t expected)
{
    unsigned step;

    for (step = 0; step < DELIVERY_MAX_STEPS && !sender->de_remote_closes; ++step)
        pump_step(fixture);
    assert(sender->de_remote_closes);
    assert(sender->de_remote_app_error == 1);
    assert(sender->de_remote_error == expected);
}


static void
test_fragmented_first (unsigned server_sender)
{
    struct delivery_fixture fixture;
    struct delivery_wire wire;
    struct delivery_endpoint *sender, *receiver;
    struct lsquic_webtransport_peer peer;
    size_t index;
    unsigned flags = LSQUIC_WTP_WT_ENABLED | LSQUIC_WTP_H3_DATAGRAM
                   | LSQUIC_WTP_QUIC_DATAGRAM | LSQUIC_WTP_RELIABLE_RESET;

    start_fixture(&fixture, server_sender, 1);
    sender = server_sender ? &fixture.df_server : &fixture.df_client;
    receiver = server_sender ? &fixture.df_client : &fixture.df_server;
    assert_pending(receiver);
    make_valid_wire(&wire, server_sender);
    for (index = 0; index + 1 < wire.dw_size; ++index)
    {
        send_fragment(&fixture, sender, wire.dw_bytes + index, 1);
        assert_pending(receiver);
        assert(receiver->de_conn && !receiver->de_closed);
    }
    send_fragment(&fixture, sender, wire.dw_bytes + index, 1);
    assert(receiver->de_conn && !receiver->de_closed);
    assert(receiver->de_notifications == 1);
    assert(LSQUIC_WTP_OK == query_peer(receiver->de_conn, &peer));
    if (server_sender)
        flags |= LSQUIC_WTP_CONNECT;
    assert(peer.flags == flags);
    assert(peer.initial_max_data == (UINT64_C(1) << 40) + 9);
    assert(peer.initial_max_streams_bidi == 17 && peer.initial_max_streams_uni == 19);
    assert(receiver->de_pending_probes == wire.dw_size);
    cleanup_fixture(&fixture);
    assert_unchanged(receiver, &peer);
    printf("PASS bytewise first SETTINGS/%zu real fragments/PENDING canaries through last byte/one READY: %s sender\n",
            wire.dw_size, server_sender ? "server" : "client");
}


static void
test_invalid_first (unsigned server_sender,
                    const struct delivery_invalid_case *test)
{
    struct delivery_fixture fixture;
    struct delivery_wire wire;
    struct delivery_endpoint *sender, *receiver;

    start_fixture(&fixture, server_sender, 1);
    sender = server_sender ? &fixture.df_server : &fixture.df_client;
    receiver = server_sender ? &fixture.df_client : &fixture.df_server;
    make_wire(&wire, test->dic_settings, test->dic_count, 1);
    assert(wire.dw_size > 1);
    assert_pending(receiver);
    send_fragment(&fixture, sender, wire.dw_bytes, wire.dw_size - 1);
    assert_pending(receiver);
    send_fragment(&fixture, sender, wire.dw_bytes + wire.dw_size - 1, 1);
    assert_pending(receiver);
    wait_for_error(&fixture, sender, HEC_SETTINGS_ERROR);
    assert_pending(receiver);
    cleanup_fixture(&fixture);
    assert_pending(receiver);
    printf("PASS invalid first SETTINGS/%s/real H3_SETTINGS_ERROR/no publication: %s sender\n",
            test->dic_name, server_sender ? "server" : "client");
}


static void
test_truncated_first (unsigned server_sender)
{
    struct delivery_fixture fixture;
    struct delivery_wire wire;
    struct delivery_endpoint *sender, *receiver;

    start_fixture(&fixture, server_sender, 1);
    sender = server_sender ? &fixture.df_server : &fixture.df_client;
    receiver = server_sender ? &fixture.df_client : &fixture.df_server;
    make_valid_wire(&wire, server_sender);
    send_fragment(&fixture, sender, wire.dw_bytes, wire.dw_size - 1);
    assert_pending(receiver);
    assert(sender->de_control);
    assert(!(sender->de_control->sm_qflags & SMQF_SEND_STOP_SENDING));
    /* Only the send half exists on this outgoing uni stream. */
    assert(0 == lsquic_stream_shutdown(sender->de_control, 1));
    assert(sender->de_control->stream_flags & STREAM_U_WRITE_DONE);
    assert(!(sender->de_control->sm_qflags & SMQF_SEND_STOP_SENDING));
    sender->de_control = NULL;
    wait_for_error(&fixture, sender, HEC_CLOSED_CRITICAL_STREAM);
    assert_pending(receiver);
    cleanup_fixture(&fixture);
    assert_pending(receiver);
    printf("PASS truncated first SETTINGS/public write-half FIN/no publication: %s sender\n",
            server_sender ? "server" : "client");
}


static void
test_fragmented_second (unsigned server_sender)
{
    static const struct delivery_setting flow_off[] = {
        { HQSID_WT_ENABLED, 1 },
        { HQSID_H3_DATAGRAM, 1 },
        { HQSID_ENABLE_CONNECT_PROTOCOL, 1 },
    };
    static const struct delivery_setting replacement[] = {
        { HQSID_WT_INITIAL_MAX_DATA, 123456789 },
        { HQSID_WT_INITIAL_MAX_STREAMS_UNI, 99 },
    };
    struct delivery_fixture fixture;
    struct delivery_wire wire;
    struct delivery_endpoint *sender, *receiver;
    struct lsquic_webtransport_peer original;
    size_t index, first_count = server_sender ? 3 : 2;
    unsigned flags = LSQUIC_WTP_WT_ENABLED | LSQUIC_WTP_H3_DATAGRAM
                   | LSQUIC_WTP_QUIC_DATAGRAM | LSQUIC_WTP_RELIABLE_RESET;

    start_fixture(&fixture, server_sender, 1);
    sender = server_sender ? &fixture.df_server : &fixture.df_client;
    receiver = server_sender ? &fixture.df_client : &fixture.df_server;
    assert_pending(receiver);
    /* DATA and both stream-limit IDs must be unseen by the second frame. */
    for (index = 0; index < first_count; ++index)
    {
        assert(flow_off[index].ds_id != HQSID_WT_INITIAL_MAX_DATA);
        assert(flow_off[index].ds_id != HQSID_WT_INITIAL_MAX_STREAMS_BIDI);
        assert(flow_off[index].ds_id != HQSID_WT_INITIAL_MAX_STREAMS_UNI);
    }
    make_wire(&wire, flow_off, first_count, 1);
    send_fragment(&fixture, sender, wire.dw_bytes, wire.dw_size);
    assert(receiver->de_conn && receiver->de_notifications == 1);
    assert(LSQUIC_WTP_OK == query_peer(receiver->de_conn, &original));
    if (server_sender)
        flags |= LSQUIC_WTP_CONNECT;
    assert(original.flags == flags);
    assert(original.initial_max_data == 0);
    assert(original.initial_max_streams_bidi == 0);
    assert(original.initial_max_streams_uni == 0);
    assert(sender->de_control && sender->de_control->sm_n_buffered == 0);
    assert(!(sender->de_control->sm_qflags & SMQF_WANT_WRITE));
    assert(sender->de_expected_offset > 0);
    assert(sender->de_manual && sender->de_expected_offset == wire.dw_size);
    assert(sender->de_control->tosend_off == wire.dw_size);
    make_wire(&wire, replacement, sizeof(replacement) / sizeof(replacement[0]), 0);
    assert(wire.dw_first_pair_end < wire.dw_size);
    send_fragment(&fixture, sender, wire.dw_bytes, wire.dw_first_pair_end);
    assert_unchanged(receiver, &original);
    if (sender->de_conn && sender->de_control && receiver->de_conn
            && !sender->de_remote_closes
            && lsquic_conn_status(sender->de_conn, NULL, 0) == LSCONN_ST_CONNECTED)
    {
        send_fragment(&fixture, sender, wire.dw_bytes + wire.dw_first_pair_end,
                                    wire.dw_size - wire.dw_first_pair_end);
        assert_unchanged(receiver, &original);
    }
    wait_for_error(&fixture, sender, HEC_FRAME_UNEXPECTED);
    assert_unchanged(receiver, &original);
    cleanup_fixture(&fixture);
    assert_unchanged(receiver, &original);
    printf("PASS fragmented second SETTINGS/unseen DATA pair before missing tail/READY bytes unchanged/one callback: %s sender\n",
            server_sender ? "server" : "client");
}


int
main (int argc, char **argv)
{
    unsigned fragmented, invalid, truncated, second, role;
    size_t index;

    assert(argc <= 2);
    fragmented = argc == 1 || 0 == strcmp(argv[1], "all")
                          || 0 == strcmp(argv[1], "fragment");
    invalid = argc == 1 || 0 == strcmp(argv[1], "all")
                       || 0 == strcmp(argv[1], "invalid");
    truncated = argc == 1 || 0 == strcmp(argv[1], "all")
                         || 0 == strcmp(argv[1], "truncated");
    second = argc == 1 || 0 == strcmp(argv[1], "all")
                      || 0 == strcmp(argv[1], "second");
    assert(fragmented || invalid || truncated || second);
    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    for (role = 0; role < 2; ++role)
    {
        if (fragmented)
            test_fragmented_first(role);
        if (invalid)
            for (index = 0; index < sizeof(invalid_cases) / sizeof(invalid_cases[0]); ++index)
                test_invalid_first(role, &invalid_cases[index]);
        if (truncated)
            test_truncated_first(role);
        if (second)
            test_fragmented_second(role);
    }
    lsquic_global_cleanup();
    return 0;
}
