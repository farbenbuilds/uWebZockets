/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <sys/queue.h>

#include <openssl/ssl.h>

#include "lsquic.h"
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_packet_in.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"
#include "lsquic_headers.h"
#include "lsquic_http1x_if.h"
#include "uwz_quic_fixture.h"

#ifdef NDEBUG
#error "uwz_reset_headers requires active assertions"
#endif

enum {
    MAX_STEPS = 20000,
    MAX_STREAMS = 16,
    RECEIVE_WINDOW = 4096,
    HEADER_VALUE_SIZE = 2048,
};

struct endpoint;

struct stream_state {
    struct endpoint *ss_endpoint;
    lsquic_stream_t *ss_stream;
    lsquic_stream_id_t ss_id;
    unsigned ss_closed;
    unsigned ss_hsets;
    unsigned ss_reset_events[2];
    uint64_t ss_reset_errors[2];
};

struct endpoint {
    lsquic_conn_t *ep_conn;
    unsigned ep_server;
    unsigned ep_handshake_ok;
    unsigned ep_closed;
    unsigned ep_stream_count;
    char ep_close_reason[160];
    struct stream_state ep_streams[MAX_STREAMS];
};

struct fixture {
    struct lsquic_test_pair f_transport;
    struct endpoint f_client;
    struct endpoint f_server;
};

/* RFC 9204 sections 4.5.2/4.5.4: GET, https, localhost, and path /. */
static const unsigned char request_headers[] = {
    1, 16, 0, 0, 0xD1, 0xD7, 0x50, 9,
    'l', 'o', 'c', 'a', 'l', 'h', 'o', 's', 't', 0xC1,
};


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct endpoint *endpoint = ctx;

    endpoint->ep_conn = conn;
    if (endpoint->ep_server)
        endpoint->ep_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct endpoint *endpoint = (struct endpoint *) lsquic_conn_get_ctx(conn);
    char reason[160] = { 0 };
    enum LSQUIC_CONN_STATUS connection_status;

    if (status != LSQ_HSK_OK)
    {
        connection_status = lsquic_conn_status(conn, reason, sizeof(reason));
        fprintf(stderr, "handshake status=%d connection status=%d server=%u reason=%s\n",
                status, connection_status, endpoint->ep_server, reason);
    }
    assert(status == LSQ_HSK_OK);
    endpoint->ep_handshake_ok = 1;
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct endpoint *endpoint = (struct endpoint *) lsquic_conn_get_ctx(conn);

    (void) lsquic_conn_status(conn, endpoint->ep_close_reason,
                             sizeof(endpoint->ep_close_reason));
    ++endpoint->ep_closed;
    endpoint->ep_conn = NULL;
    lsquic_conn_set_ctx(conn, NULL);
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct endpoint *endpoint = ctx;
    struct stream_state *state;

    assert(stream);
    assert(endpoint->ep_stream_count < MAX_STREAMS);
    state = &endpoint->ep_streams[endpoint->ep_stream_count++];
    state->ss_endpoint = endpoint;
    state->ss_stream = stream;
    state->ss_id = lsquic_stream_id(stream);
    if (endpoint->ep_server && !(state->ss_id & 2))
        assert(lsquic_stream_wantread(stream, 1) >= 0);
    return (lsquic_stream_ctx_t *) state;
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *UNUSED_ctx)
{
    /* The application deliberately retains completed header sets. */
    assert(lsquic_stream_wantread(stream, 0) >= 0);
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *UNUSED_ctx)
{
    assert(lsquic_stream_wantwrite(stream, 0) >= 0);
}


static void
hset_in (lsquic_stream_t *UNUSED_stream, lsquic_stream_ctx_t *ctx)
{
    struct stream_state *state = (struct stream_state *) ctx;

    ++state->ss_hsets;
}


static void
reset_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx, int how)
{
    struct stream_state *state = (struct stream_state *) ctx;
    uint64_t error = UINT64_MAX;

    assert(how == 0 || how == 1);
    assert(LSQUIC_SERR_AVAILABLE == lsquic_stream_get_reset_error(stream, how,
                                                                &error));
    ++state->ss_reset_events[how];
    assert(state->ss_reset_events[how] == 1);
    state->ss_reset_errors[how] = error;
}


static void
close_stream (lsquic_stream_t *UNUSED_stream, lsquic_stream_ctx_t *ctx)
{
    struct stream_state *state = (struct stream_state *) ctx;

    assert(state->ss_closed == 0);
    ++state->ss_closed;
    state->ss_stream = NULL;
}


static const struct lsquic_stream_if callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_new_stream = new_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_hsk_done = handshake_done,
    .on_hset_in = hset_in,
    .on_reset = reset_stream,
};


static void
pump (struct fixture *fixture, unsigned count)
{
    unsigned step;

    for (step = 0; step < count; ++step)
    {
        lsquic_test_pair_process(&fixture->f_transport, 1000);
        lsquic_test_deliver_all(&fixture->f_transport.ltp_client);
        lsquic_test_deliver_all(&fixture->f_transport.ltp_server);
    }
}


static void
init_endpoint (struct fixture *fixture, unsigned server)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct endpoint *endpoint;
    struct lsquic_test_endpoint *transport, *peer;
    unsigned flags = server ? LSENG_SERVER | LSENG_HTTP : 0;

    endpoint = server ? &fixture->f_server : &fixture->f_client;
    endpoint->ep_server = server;
    transport = server ? &fixture->f_transport.ltp_server
                       : &fixture->f_transport.ltp_client;
    peer = server ? &fixture->f_transport.ltp_client
                  : &fixture->f_transport.ltp_server;
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = 8;
    settings.es_max_streams_in = 8;
    /* H3 transport-parameter sanity requires at least 4096 receive bytes. */
    settings.es_init_max_stream_data_bidi_remote = RECEIVE_WINDOW;
    settings.es_qpack_dec_max_size = server ? 256 : 0;
    settings.es_qpack_dec_max_blocked = server ? 4 : 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    settings.es_max_header_sets = 4;
    settings.es_reset_stream_at = 1;
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_alpn = "h3";
    config.ltec_tls = lsquic_test_tls_context_new(server, "h3");
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(transport, peer, &config,
                                        server ? 13201 : 13202));
    SSL_CTX_free(config.ltec_tls);
}


static struct stream_state *
find_stream (struct endpoint *endpoint, lsquic_stream_id_t id)
{
    unsigned index;

    for (index = 0; index < endpoint->ep_stream_count; ++index)
        if (endpoint->ep_streams[index].ss_id == id)
            return &endpoint->ep_streams[index];
    return NULL;
}


static void
send_bytes (struct stream_state *state, const void *bytes, size_t size)
{
    assert(state && state->ss_stream);
    assert(size == (size_t) lsquic_stream_write(state->ss_stream, bytes, size));
    assert(0 == lsquic_stream_flush(state->ss_stream));
}


static void
assert_connected (const struct fixture *fixture)
{
    if (fixture->f_server.ep_closed)
        fprintf(stderr, "unexpected HTTP close: %s\n",
                fixture->f_server.ep_close_reason);
    assert(!fixture->f_server.ep_closed && !fixture->f_client.ep_closed);
    assert(fixture->f_server.ep_conn && fixture->f_client.ep_conn);
    assert(LSCONN_ST_CONNECTED == lsquic_conn_status(
                                    fixture->f_server.ep_conn, NULL, 0));
}


static void
start_fixture (struct fixture *fixture)
{
    static const unsigned char control[] = { 0, 4, 0 };
    static const unsigned char encoder[] = { 2, 0x3F, 0xE1, 1 };
    static const unsigned char decoder[] = { 3 };
    unsigned step;

    memset(fixture, 0, sizeof(*fixture));
    init_endpoint(fixture, 0);
    init_endpoint(fixture, 1);
    assert(lsquic_engine_connect(fixture->f_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture->f_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture->f_transport.ltp_server.lte_address,
                &fixture->f_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
    for (step = 0; step < MAX_STEPS; ++step)
    {
        if (fixture->f_client.ep_handshake_ok && fixture->f_server.ep_handshake_ok)
            break;
        pump(fixture, 1);
    }
    assert(step < MAX_STEPS);
    pump(fixture, 50);
    for (step = 0; step < 3; ++step)
        assert(LSQUIC_MUS_OK == lsquic_conn_make_uni_stream(fixture->f_client.ep_conn));
    send_bytes(find_stream(&fixture->f_client, 2), control, sizeof(control));
    send_bytes(find_stream(&fixture->f_client, 6), encoder, sizeof(encoder));
    send_bytes(find_stream(&fixture->f_client, 10), decoder, sizeof(decoder));
    pump(fixture, 100);
    assert_connected(fixture);
    assert(fixture->f_transport.ltp_client.lte_packets_received);
    assert(fixture->f_transport.ltp_server.lte_packets_received);
}


static void
cleanup_fixture (struct fixture *fixture)
{
    lsquic_test_endpoint_destroy(&fixture->f_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture->f_transport.ltp_server);
}


static struct stream_state *
send_request_prefix (struct fixture *fixture, const void *bytes, size_t size)
{
    struct stream_state *state;
    unsigned step;

    lsquic_conn_make_stream(fixture->f_client.ep_conn);
    state = find_stream(&fixture->f_client, 0);
    assert(state && state->ss_stream);
    send_bytes(state, bytes, size);
    for (step = 0; step < MAX_STEPS; ++step)
    {
        state = find_stream(&fixture->f_server, 0);
        if (state && state->ss_stream && state->ss_stream->sm_hblock_ctx
            && lsquic_sfcw_get_max_recv_off(&state->ss_stream->fc) == size)
            return state;
        assert_connected(fixture);
        pump(fixture, 1);
    }
    assert(!"HTTP prefix did not create an incomplete QPACK section");
    return NULL;
}


static void
claim_header_set (struct stream_state *state, const char *expected)
{
    struct http1x_headers *headers;

    assert(state && state->ss_stream);
    headers = lsquic_stream_get_hset(state->ss_stream);
    assert(headers);
    assert(headers->h1h_size && headers->h1h_buf);
    assert(strstr(headers->h1h_buf, expected));
    lsquic_http1x_if->hsi_discard_header_set(headers);
}


static void
test_partial_block_reset (void)
{
    static const unsigned char tail[] = { 0, 0, 1, 3, 2, 0 };
    unsigned char prefix[sizeof(request_headers) + sizeof(tail)];
    struct lsquic_stream_recv_state metadata;
    struct fixture fixture;
    struct stream_state *incoming, *outgoing;
    uint64_t error = UINT64_MAX;
    unsigned step;
    unsigned char byte;

    memcpy(prefix, request_headers, sizeof(request_headers));
    memcpy(prefix + sizeof(request_headers), tail, sizeof(tail));
    start_fixture(&fixture);
    incoming = send_request_prefix(&fixture, prefix, sizeof(prefix));
    outgoing = find_stream(&fixture.f_client, 0);
    assert(incoming->ss_hsets == 1);
    assert(!STAILQ_EMPTY(&incoming->ss_stream->uh));
    assert(incoming->ss_stream->sm_qflags & SMQF_QPACK_DEC);
    assert(incoming->ss_stream->sm_hq_filter.hqfi_flags & HQFI_FLAG_BLOCKED);
    assert(incoming->ss_stream->read_offset == sizeof(prefix) - 1);
    assert(incoming->ss_stream->sm_hq_filter.hqfi_left == 2);
    assert(lsquic_sfcw_get_max_recv_off(&incoming->ss_stream->fc) == sizeof(prefix));
    assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(outgoing->ss_stream,
                                                    0x175, sizeof(prefix)));
    pump(&fixture, 100);
    assert(incoming->ss_stream);
    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(incoming->ss_stream,
                                                                &metadata));
    assert(metadata.flags & LSQUIC_SRS_RESET_KNOWN);
    assert(!(metadata.flags & LSQUIC_SRS_RESET_VISIBLE));
    assert(metadata.reliable_size == sizeof(prefix));
    assert(metadata.final_size == sizeof(prefix));
    assert(incoming->ss_reset_events[0] == 0);
    claim_header_set(incoming, "GET / HTTP/1.1");
    /* The later section ends beyond R; neither its tail nor insert is promised. */
    for (step = 0; step < 1000; ++step)
    {
        if (incoming->ss_reset_events[0])
            break;
        pump(&fixture, 1);
    }
    if (!incoming->ss_reset_events[0])
        fprintf(stderr, "partial HEADERS still awaits bytes outside reliable prefix\n");
    assert(incoming->ss_reset_events[0] == 1);
    assert(incoming->ss_reset_errors[0] == 0x175);
    assert(incoming->ss_stream);
    assert(LSQUIC_SERR_AVAILABLE == lsquic_stream_get_reset_error(
                                            incoming->ss_stream, 0, &error));
    assert(error == 0x175);
    assert(-1 == lsquic_stream_read(incoming->ss_stream, &byte, 1));
    assert(errno == ECONNRESET);
    assert(incoming->ss_stream->sm_hblock_ctx == NULL);
    assert(!(incoming->ss_stream->sm_qflags & SMQF_QPACK_DEC));
    assert_connected(&fixture);
    cleanup_fixture(&fixture);
    puts("PASS partial QPACK section beyond R retires after earlier completed headers are claimed");
}


static void
queue_peer_stop (struct fixture *fixture, struct stream_state *outgoing)
{
    unsigned packets_before = fixture->f_transport.ltp_client.lte_packets_sent;

    assert(outgoing && outgoing->ss_stream);
    assert(0 == lsquic_stream_shutdown(outgoing->ss_stream, 0));
    assert(outgoing->ss_stream->sm_qflags & SMQF_SEND_STOP_SENDING);
    /* Read-only shutdown queues control work; write interest schedules its tick. */
    assert(lsquic_stream_wantwrite(outgoing->ss_stream, 1) >= 0);
    lsquic_engine_process_conns(fixture->f_transport.ltp_client.lte_engine);
    if (!fixture->f_transport.ltp_server.lte_incoming.ltq_count)
        fprintf(stderr, "STOP queued without packet: qflags=%x stream_flags=%x sent=%u->%u unsent=%d\n",
                (unsigned) outgoing->ss_stream->sm_qflags,
                (unsigned) outgoing->ss_stream->stream_flags, packets_before,
                fixture->f_transport.ltp_client.lte_packets_sent,
                lsquic_engine_has_unsent_packets(fixture->f_transport.ltp_client.lte_engine));
    assert(fixture->f_transport.ltp_server.lte_incoming.ltq_count);
    assert(outgoing->ss_stream->stream_flags & STREAM_SS_SENT);
}


static void
test_stop_preserves_receive_headers (void)
{
    static const unsigned char padded_name[] = { 0x25, 'x', '-', 'p', 'a', 'd' };
    static const unsigned char padded_size[] = { 0x7F, 0x81, 0x0F };
    static const unsigned char field_tail[] = { 'x', 1, 'y' };
    unsigned char prefix[3 + sizeof(request_headers) - 2
                    + sizeof(padded_name) + sizeof(padded_size) + HEADER_VALUE_SIZE + 1];
    struct fixture fixture;
    struct stream_state *incoming, *outgoing;
    const void *header_context;
    size_t offset = 3;
    size_t section_size = sizeof(prefix) - 3 + sizeof(field_tail);
    unsigned step;

    assert(section_size >= 64 && section_size < 16384);
    prefix[0] = 1;
    prefix[1] = 0x40 | (section_size >> 8);
    prefix[2] = section_size & 0xFF;
    memcpy(prefix + offset, request_headers + 2, sizeof(request_headers) - 2);
    offset += sizeof(request_headers) - 2;
    memcpy(prefix + offset, padded_name, sizeof(padded_name));
    offset += sizeof(padded_name);
    memcpy(prefix + offset, padded_size, sizeof(padded_size));
    offset += sizeof(padded_size);
    memset(prefix + offset, 'b', HEADER_VALUE_SIZE);
    offset += HEADER_VALUE_SIZE;
    prefix[offset++] = 0x21;
    assert(offset == sizeof(prefix));
    start_fixture(&fixture);
    incoming = send_request_prefix(&fixture, prefix, sizeof(prefix));
    outgoing = find_stream(&fixture.f_client, 0);
    assert(incoming->ss_hsets == 0);
    assert(incoming->ss_stream->read_offset == sizeof(prefix));
    assert(incoming->ss_stream->sm_qflags & SMQF_QPACK_DEC);
    assert(incoming->ss_stream->sm_qflags & SMQF_SEND_MAX_STREAM_DATA);
    header_context = incoming->ss_stream->sm_hblock_ctx;
    assert(header_context);
    /* Deliver STOP without ticking the server's queued MAX_STREAM_DATA output. */
    queue_peer_stop(&fixture, outgoing);
    lsquic_test_deliver_all(&fixture.f_transport.ltp_server);
    assert(incoming->ss_reset_events[1] == 1);
    assert(incoming->ss_stream->sm_hblock_ctx == header_context);
    assert(incoming->ss_stream->sm_qflags & SMQF_QPACK_DEC);
    assert(incoming->ss_stream->sm_qflags & SMQF_SEND_MAX_STREAM_DATA);
    send_bytes(outgoing, field_tail, sizeof(field_tail));
    assert(lsquic_stream_wantread(incoming->ss_stream, 1) >= 0);
    for (step = 0; step < MAX_STEPS; ++step)
    {
        if (incoming->ss_hsets == 1)
            break;
        assert_connected(&fixture);
        pump(&fixture, 1);
    }
    assert(step < MAX_STEPS);
    claim_header_set(incoming, "x: y");
    assert(incoming->ss_reset_events[0] == 0);
    assert_connected(&fixture);
    cleanup_fixture(&fixture);
    puts("PASS peer STOP preserves receive MAX_STREAM_DATA and incomplete HEADERS decoding");
}


static void
test_crossed_stop_flags (void)
{
    static const unsigned char partial_request[] = { 1, 16, 0, 0 };
    struct fixture fixture;
    struct stream_state *incoming, *outgoing;

    start_fixture(&fixture);
    incoming = send_request_prefix(&fixture, partial_request, sizeof(partial_request));
    outgoing = find_stream(&fixture.f_client, 0);
    queue_peer_stop(&fixture, outgoing);
    assert(0 == lsquic_stream_shutdown(incoming->ss_stream, 0));
    assert(incoming->ss_stream->sm_qflags & SMQF_SEND_STOP_SENDING);
    lsquic_test_deliver_all(&fixture.f_transport.ltp_server);
    assert(incoming->ss_reset_events[1] == 1);
    assert(incoming->ss_stream->sm_qflags & SMQF_SEND_STOP_SENDING);
    pump(&fixture, 100);
    assert(outgoing->ss_reset_events[1] == 1);
    assert_connected(&fixture);
    cleanup_fixture(&fixture);
    puts("PASS crossed STOP_SENDING preserves the independently queued receive cancellation");
}


int
main (int argc, char **argv)
{
    unsigned selected = argc == 1;

    assert(argc <= 2);
    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    if (argc == 1 || 0 == strcmp(argv[1], "partial-reset"))
    {
        test_partial_block_reset();
        selected = 1;
    }
    if (argc == 1 || 0 == strcmp(argv[1], "stop-half"))
    {
        test_stop_preserves_receive_headers();
        selected = 1;
    }
    if (argc == 1 || 0 == strcmp(argv[1], "stop-flags"))
    {
        test_crossed_stop_flags();
        selected = 1;
    }
    assert(selected);
    lsquic_global_cleanup();
    return 0;
}
