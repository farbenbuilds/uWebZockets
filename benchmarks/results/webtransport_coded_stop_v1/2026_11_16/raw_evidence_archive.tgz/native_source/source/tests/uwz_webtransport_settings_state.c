/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "lsquic.h"
#include "lsquic_webtransport.h"

#ifdef NDEBUG
#error "uwz_webtransport_settings_state requires active assertions"
#endif

enum {
    STATE_CANARY = 0xA5,
    STATE_OTHER_FLAG = 1 << 17,
};

enum state_field {
    STATE_BOOLEAN,
    STATE_DATA,
    STATE_BIDI,
    STATE_UNI,
};

struct state_setting {
    uint64_t ss_id;
    uint64_t ss_maximum;
    enum state_field ss_field;
    unsigned ss_flag;
};

struct state_step {
    unsigned ss_setting;
    uint64_t ss_value;
};

struct state_probe {
    unsigned char sp_before[8];
    struct lsquic_webtransport_peer sp_peer;
    unsigned sp_seen;
    unsigned char sp_after[8];
};

/* Independent draft-16 literals, not aliases from the implementation header. */
static const struct state_setting state_settings[] = {
    { UINT64_C(0x2c7cf000), 1, STATE_BOOLEAN, LSQUIC_WTP_WT_ENABLED },
    { UINT64_C(0x08), 1, STATE_BOOLEAN, LSQUIC_WTP_CONNECT },
    { UINT64_C(0x33), 1, STATE_BOOLEAN, LSQUIC_WTP_H3_DATAGRAM },
    { UINT64_C(0x2b61), (UINT64_C(1) << 62) - 1, STATE_DATA, 0 },
    { UINT64_C(0x2b65), UINT64_C(1) << 60, STATE_BIDI, 0 },
    { UINT64_C(0x2b64), UINT64_C(1) << 60, STATE_UNI, 0 },
};

static const struct state_step first_order[] = {
    { 0, 1 }, { 1, 0 }, { 2, 1 }, { 3, 65537 }, { 4, 17 }, { 5, 19 },
};

static const struct state_step second_order[] = {
    { 3, 7 }, { 5, 23 }, { 2, 0 }, { 0, 0 }, { 4, 31 }, { 1, 1 },
};

static const uint64_t unknown_ids[] = {
    0, UINT64_C(0x2b62), UINT64_C(0x2b603742), UINT64_C(0x2b603743),
    (UINT64_C(1) << 62) - 1,
};


static void
init_probe (struct state_probe *probe)
{
    memset(probe, STATE_CANARY, sizeof(*probe));
    probe->sp_peer.initial_max_data = 101;
    probe->sp_peer.initial_max_streams_bidi = 103;
    probe->sp_peer.initial_max_streams_uni = 107;
    probe->sp_peer.flags = STATE_OTHER_FLAG | LSQUIC_WTP_QUIC_DATAGRAM
                                          | LSQUIC_WTP_RELIABLE_RESET;
    probe->sp_seen = 0;
}


static void
assert_canaries (const struct state_probe *probe)
{
    size_t index;

    for (index = 0; index < sizeof(probe->sp_before); ++index)
        assert(probe->sp_before[index] == STATE_CANARY);
    for (index = 0; index < sizeof(probe->sp_after); ++index)
        assert(probe->sp_after[index] == STATE_CANARY);
}


static void
assert_applied (struct state_probe *probe, const struct state_setting *setting,
                uint64_t value)
{
    struct lsquic_webtransport_peer before = probe->sp_peer;
    unsigned seen_before = probe->sp_seen;

    assert(LSQUIC_WT_SETTING_APPLIED == lsquic_wt_setting_apply(
                      &probe->sp_peer, &probe->sp_seen, setting->ss_id, value));
    assert(probe->sp_seen != seen_before);
    assert_canaries(probe);
    assert(probe->sp_peer.initial_max_data ==
                        (setting->ss_field == STATE_DATA ? value : before.initial_max_data));
    assert(probe->sp_peer.initial_max_streams_bidi ==
                        (setting->ss_field == STATE_BIDI ? value : before.initial_max_streams_bidi));
    assert(probe->sp_peer.initial_max_streams_uni ==
                        (setting->ss_field == STATE_UNI ? value : before.initial_max_streams_uni));
    assert((probe->sp_peer.flags & ~setting->ss_flag) == (before.flags & ~setting->ss_flag));
    if (setting->ss_field == STATE_BOOLEAN)
        assert(!!(probe->sp_peer.flags & setting->ss_flag) == !!value);
}


static void
assert_unchanged (struct state_probe *probe, uint64_t id, uint64_t value,
                  enum lsquic_wt_setting_status expected)
{
    unsigned char before[sizeof(*probe)];

    memcpy(before, probe, sizeof(*probe));
    assert(expected == lsquic_wt_setting_apply(&probe->sp_peer, &probe->sp_seen,
                                              id, value));
    assert(0 == memcmp(before, probe, sizeof(*probe)));
    assert_canaries(probe);
}


static void
test_order (const struct state_step *steps, size_t count)
{
    struct state_probe probe;
    size_t index;

    init_probe(&probe);
    for (index = 0; index < count; ++index)
        assert_applied(&probe, &state_settings[steps[index].ss_setting],
                       steps[index].ss_value);
    for (index = 0; index < count; ++index)
        assert_unchanged(&probe, state_settings[steps[index].ss_setting].ss_id,
                         steps[index].ss_value, LSQUIC_WT_SETTING_INVALID);
}


static void
test_inclusive_bounds (void)
{
    struct state_probe probe;
    const struct state_setting *setting;
    size_t index;

    for (index = 0; index < sizeof(state_settings) / sizeof(state_settings[0]); ++index)
    {
        setting = &state_settings[index];
        init_probe(&probe);
        assert_applied(&probe, setting, 0);
        init_probe(&probe);
        assert_applied(&probe, setting, setting->ss_maximum);
    }
}


static void
test_invalid_first_values (void)
{
    struct state_probe probe;
    const struct state_setting *setting;
    size_t index;

    for (index = 0; index < sizeof(state_settings) / sizeof(state_settings[0]); ++index)
    {
        setting = &state_settings[index];
        init_probe(&probe);
        assert_unchanged(&probe, setting->ss_id, setting->ss_maximum + 1,
                         LSQUIC_WT_SETTING_INVALID);
        assert_unchanged(&probe, setting->ss_id, UINT64_MAX,
                         LSQUIC_WT_SETTING_INVALID);
        /* A rejected first occurrence must not mark this identifier seen. */
        assert_applied(&probe, setting, setting->ss_maximum);
    }
}


static void
test_duplicates (void)
{
    struct state_probe probe;
    const struct state_setting *setting;
    uint64_t values[3];
    size_t index, first, second;

    for (index = 0; index < sizeof(state_settings) / sizeof(state_settings[0]); ++index)
    {
        setting = &state_settings[index];
        values[0] = 0;
        values[1] = 1;
        values[2] = setting->ss_maximum;
        for (first = 0; first < sizeof(values) / sizeof(values[0]); ++first)
        {
            init_probe(&probe);
            assert_applied(&probe, setting, values[first]);
            for (second = 0; second < sizeof(values) / sizeof(values[0]); ++second)
                assert_unchanged(&probe, setting->ss_id, values[second],
                                 LSQUIC_WT_SETTING_INVALID);
        }
    }
}


static void
test_unknown_ids (void)
{
    struct state_probe probe;
    size_t index, setting;

    init_probe(&probe);
    for (index = 0; index < sizeof(unknown_ids) / sizeof(unknown_ids[0]); ++index)
    {
        assert_unchanged(&probe, unknown_ids[index], 0, LSQUIC_WT_SETTING_UNKNOWN);
        assert_unchanged(&probe, unknown_ids[index], (UINT64_C(1) << 62) - 1,
                         LSQUIC_WT_SETTING_UNKNOWN);
    }
    for (setting = 0; setting < sizeof(state_settings) / sizeof(state_settings[0]); ++setting)
        assert_applied(&probe, &state_settings[setting], state_settings[setting].ss_maximum);
    for (index = 0; index < sizeof(unknown_ids) / sizeof(unknown_ids[0]); ++index)
        assert_unchanged(&probe, unknown_ids[index], 1, LSQUIC_WT_SETTING_UNKNOWN);
}


static void
assert_transport (struct state_probe *probe, unsigned datagrams,
                  unsigned reliable_reset, unsigned expected)
{
    uint64_t data = probe->sp_peer.initial_max_data;
    uint64_t bidi = probe->sp_peer.initial_max_streams_bidi;
    uint64_t uni = probe->sp_peer.initial_max_streams_uni;
    unsigned seen = probe->sp_seen;

    lsquic_wt_peer_set_transport(&probe->sp_peer, datagrams, reliable_reset);
    assert(probe->sp_peer.flags == expected);
    assert(probe->sp_peer.initial_max_data == data);
    assert(probe->sp_peer.initial_max_streams_bidi == bidi);
    assert(probe->sp_peer.initial_max_streams_uni == uni);
    assert(probe->sp_seen == seen);
    assert_canaries(probe);
}


static void
test_transport_replacement (void)
{
    struct state_probe probe;
    const unsigned settings_flags = STATE_OTHER_FLAG | LSQUIC_WTP_WT_ENABLED
                                 | LSQUIC_WTP_CONNECT | LSQUIC_WTP_H3_DATAGRAM;

    init_probe(&probe);
    probe.sp_peer.flags |= LSQUIC_WTP_WT_ENABLED | LSQUIC_WTP_CONNECT
                                               | LSQUIC_WTP_H3_DATAGRAM;
    /* Live absence replaces both cached support bits, preserving settings. */
    assert_transport(&probe, 0, 0, settings_flags);
    assert_transport(&probe, 0, 0, settings_flags);
    assert_transport(&probe, 3, 0, settings_flags | LSQUIC_WTP_QUIC_DATAGRAM);
    assert_transport(&probe, 3, 0, settings_flags | LSQUIC_WTP_QUIC_DATAGRAM);
    assert_transport(&probe, 0, 9, settings_flags | LSQUIC_WTP_RELIABLE_RESET);
    assert_transport(&probe, 0, 9, settings_flags | LSQUIC_WTP_RELIABLE_RESET);
    assert_transport(&probe, 4, 5, settings_flags | LSQUIC_WTP_QUIC_DATAGRAM
                                                | LSQUIC_WTP_RELIABLE_RESET);
    assert_transport(&probe, 4, 5, settings_flags | LSQUIC_WTP_QUIC_DATAGRAM
                                                | LSQUIC_WTP_RELIABLE_RESET);
    assert_transport(&probe, 0, 0, settings_flags);
}


int
main (void)
{
    assert(LSQUIC_WT_SETTING_UNKNOWN == 0);
    assert(LSQUIC_WT_SETTING_APPLIED == 1);
    assert(LSQUIC_WT_SETTING_INVALID == -1);
    test_order(first_order, sizeof(first_order) / sizeof(first_order[0]));
    test_order(second_order, sizeof(second_order) / sizeof(second_order[0]));
    test_inclusive_bounds();
    test_invalid_first_values();
    test_duplicates();
    test_unknown_ids();
    test_transport_replacement();
    puts("PASS pure WebTransport SETTINGS transitions: six IDs/order/bounds/duplicate zero/unknown and legacy IDs/unchanged failures/canaries/live transport replacement");
    return 0;
}
