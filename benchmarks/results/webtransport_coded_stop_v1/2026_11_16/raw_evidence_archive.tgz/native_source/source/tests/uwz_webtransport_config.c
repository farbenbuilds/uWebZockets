/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "lsquic.h"

#ifdef NDEBUG
#error "uwz_webtransport_config requires active assertions"
#endif

enum {
    CONFIG_ERROR_CAPACITY = 32,
    CONFIG_CANARY_SIZE = 8,
    CONFIG_CANARY = 0xA5,
};

struct config_case {
    const char *cc_name;
    unsigned cc_http;
    int cc_datagrams;
    int cc_reset;
    struct lsquic_webtransport_settings cc_webtransport;
    unsigned cc_valid;
};

struct config_error_buffer {
    unsigned char ceb_before[CONFIG_CANARY_SIZE];
    char ceb_text[CONFIG_ERROR_CAPACITY];
    unsigned char ceb_after[CONFIG_CANARY_SIZE];
};

static const struct config_case config_cases[] = {
    {
        .cc_name = "enabled flow off",
        .cc_http = 1, .cc_datagrams = 1, .cc_reset = 1,
        .cc_webtransport = { .enabled = 1 },
        .cc_valid = 1,
    },
    {
        .cc_name = "enabled flow on",
        .cc_http = 1, .cc_datagrams = 1, .cc_reset = 1,
        .cc_webtransport = { .enabled = 1, .initial_max_data = 65537,
            .initial_max_streams_bidi = 17, .initial_max_streams_uni = 19 },
        .cc_valid = 1,
    },
    {
        .cc_name = "nonzero datagrams option",
        .cc_http = 1, .cc_datagrams = 2, .cc_reset = 1,
        .cc_webtransport = { .enabled = 1 },
        .cc_valid = 1,
    },
    {
        .cc_name = "inclusive enabled maxima",
        .cc_http = 1, .cc_datagrams = 1, .cc_reset = 1,
        .cc_webtransport = { .enabled = 1,
            .initial_max_data = (UINT64_C(1) << 62) - 1,
            .initial_max_streams_bidi = UINT64_C(1) << 60,
            .initial_max_streams_uni = UINT64_C(1) << 60 },
        .cc_valid = 1,
    },
    {
        .cc_name = "disabled maximum preset without prerequisites",
        .cc_webtransport = {
            .initial_max_data = (UINT64_C(1) << 62) - 1,
            .initial_max_streams_bidi = UINT64_C(1) << 60,
            .initial_max_streams_uni = UINT64_C(1) << 60 },
        .cc_valid = 1,
    },
    {
        .cc_name = "enabled requires HTTP mode",
        .cc_datagrams = 1, .cc_reset = 1,
        .cc_webtransport = { .enabled = 1 },
    },
    {
        .cc_name = "enabled requires datagrams",
        .cc_http = 1, .cc_reset = 1,
        .cc_webtransport = { .enabled = 1 },
    },
    {
        .cc_name = "enabled requires reliable reset receive support",
        .cc_http = 1, .cc_datagrams = 1,
        .cc_webtransport = { .enabled = 1 },
    },
    {
        .cc_name = "enabled value two",
        .cc_http = 1, .cc_datagrams = 1, .cc_reset = 1,
        .cc_webtransport = { .enabled = 2 },
    },
    {
        .cc_name = "enabled unsigned maximum",
        .cc_http = 1, .cc_datagrams = 1, .cc_reset = 1,
        .cc_webtransport = { .enabled = UINT_MAX },
    },
    {
        .cc_name = "enabled data maximum plus one",
        .cc_http = 1, .cc_datagrams = 1, .cc_reset = 1,
        .cc_webtransport = { .enabled = 1,
            .initial_max_data = UINT64_C(1) << 62 },
    },
    {
        .cc_name = "enabled bidi maximum plus one",
        .cc_http = 1, .cc_datagrams = 1, .cc_reset = 1,
        .cc_webtransport = { .enabled = 1,
            .initial_max_streams_bidi = (UINT64_C(1) << 60) + 1 },
    },
    {
        .cc_name = "enabled uni maximum plus one",
        .cc_http = 1, .cc_datagrams = 1, .cc_reset = 1,
        .cc_webtransport = { .enabled = 1,
            .initial_max_streams_uni = (UINT64_C(1) << 60) + 1 },
    },
    {
        .cc_name = "disabled data maximum plus one",
        .cc_webtransport = { .initial_max_data = UINT64_C(1) << 62 },
    },
    {
        .cc_name = "disabled bidi maximum plus one",
        .cc_webtransport = { .initial_max_streams_bidi = (UINT64_C(1) << 60) + 1 },
    },
    {
        .cc_name = "disabled uni maximum plus one",
        .cc_webtransport = { .initial_max_streams_uni = (UINT64_C(1) << 60) + 1 },
    },
};


static void
assert_canary (const void *bytes, size_t size)
{
    const unsigned char *cursor = bytes;
    size_t index;

    for (index = 0; index < size; ++index)
        assert(cursor[index] == CONFIG_CANARY);
}


static void
assert_result (int result, unsigned valid, const char *name)
{
    if ((valid && result != 0) || (!valid && result >= 0))
        printf("configuration case failed: %s, expected %s, returned %d\n",
               name, valid ? "valid" : "invalid", result);
    if (valid)
        assert(result == 0);
    else
        assert(result < 0);
}


static void
check_configuration (const struct lsquic_engine_settings *settings,
                     unsigned flags, unsigned valid, const char *name)
{
    struct lsquic_engine_settings before;
    struct config_error_buffer error;
    const size_t sizes[] = { 1, CONFIG_ERROR_CAPACITY };
    size_t index, size;
    int result;

    memcpy(&before, settings, sizeof(before));
    result = lsquic_engine_check_settings(settings, flags, NULL, 0);
    assert_result(result, valid, name);
    assert(0 == memcmp(&before, settings, sizeof(before)));
    for (index = 0; index < sizeof(sizes) / sizeof(sizes[0]); ++index)
    {
        size = sizes[index];
        memset(&error, CONFIG_CANARY, sizeof(error));
        result = lsquic_engine_check_settings(settings, flags,
                                             error.ceb_text, size);
        assert_result(result, valid, name);
        assert(0 == memcmp(&before, settings, sizeof(before)));
        assert_canary(error.ceb_before, sizeof(error.ceb_before));
        assert_canary(error.ceb_after, sizeof(error.ceb_after));
        assert_canary(error.ceb_text + size, sizeof(error.ceb_text) - size);
        if (!valid)
            assert(memchr(error.ceb_text, '\0', size));
    }
}


static void
test_defaults (unsigned server)
{
    struct lsquic_engine_settings settings;
    unsigned http, flags;

    for (http = 0; http < 2; ++http)
    {
        flags = (server ? LSENG_SERVER : 0) | (http ? LSENG_HTTP : 0);
        memset(&settings, 0, sizeof(settings));
        lsquic_engine_init_settings(&settings, flags);
        assert(settings.es_webtransport.enabled == 0);
        assert(settings.es_webtransport.initial_max_data == 0);
        assert(settings.es_webtransport.initial_max_streams_bidi == 0);
        assert(settings.es_webtransport.initial_max_streams_uni == 0);
        assert(settings.es_reset_stream_at == 0);
        assert(settings.es_datagrams == LSQUIC_DF_DATAGRAMS);
        assert(settings.es_qpack_dec_max_size == LSQUIC_DF_QPACK_DEC_MAX_SIZE);
        assert(settings.es_qpack_dec_max_blocked == LSQUIC_DF_QPACK_DEC_MAX_BLOCKED);
        check_configuration(&settings, flags, 1, "unchanged defaults");
    }
}


static void
test_cases (unsigned server)
{
    struct lsquic_engine_settings settings;
    const struct config_case *test;
    size_t index;
    unsigned flags;

    for (index = 0; index < sizeof(config_cases) / sizeof(config_cases[0]); ++index)
    {
        test = &config_cases[index];
        flags = (server ? LSENG_SERVER : 0) | (test->cc_http ? LSENG_HTTP : 0);
        memset(&settings, 0, sizeof(settings));
        lsquic_engine_init_settings(&settings, flags);
        settings.es_webtransport = test->cc_webtransport;
        settings.es_datagrams = test->cc_datagrams;
        settings.es_reset_stream_at = test->cc_reset;
        settings.es_pace_packets = 0;
        settings.es_init_max_streams_uni = 8;
        settings.es_max_header_sets = 3;
        check_configuration(&settings, flags, test->cc_valid, test->cc_name);
    }
}


int
main (void)
{
    unsigned server;

    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    for (server = 0; server < 2; ++server)
    {
        test_defaults(server);
        test_cases(server);
    }
    puts("PASS WebTransport config: both roles/defaults/prerequisites/boolean/inclusive limits/disabled presets/unchanged input/bounded error buffers");
    return 0;
}
