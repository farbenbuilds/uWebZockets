/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/queue.h>

#include <openssl/ssl.h>

#include "lsquic.h"
#include "uwz_quic_fixture.h"
#include "lsquic_types.h"
#include "lsquic_int_types.h"
#include "lsquic_sizes.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"
#include "lsquic_conn.h"
#include "lsquic_enc_sess.h"
#include "lsquic_trans_params.h"

#ifdef NDEBUG
#error "uwz_webtransport_credit requires active assertions"
#endif

enum {
    CREDIT_MAX_STEPS = 20000,
    CREDIT_MAX_STREAMS = 8,
    CREDIT_BIDI_LOCAL = 32768,
    CREDIT_BIDI_REMOTE = 49152,
    CREDIT_UNI_WINDOW = 65536,
    CREDIT_RAW_SERVER_LOCAL = 65536,
    CREDIT_RAW_SERVER_REMOTE = 81920,
};

enum credit_mode {
    CREDIT_HTTP,
    CREDIT_RAW,
};

struct credit_endpoint;

struct credit_stream {
    struct credit_endpoint *cs_endpoint;
    lsquic_stream_t *cs_stream;
    lsquic_stream_id_t cs_id;
    unsigned cs_closed;
    unsigned cs_fin;
    size_t cs_received;
    unsigned char cs_bytes[32];
};

struct credit_endpoint {
    lsquic_conn_t *ce_conn;
    unsigned ce_server;
    enum credit_mode ce_mode;
    unsigned ce_handshake_ok;
    unsigned ce_settings_count;
    unsigned ce_stream_count;
    unsigned ce_closed;
    int ce_settings_result;
    struct credit_stream ce_streams[CREDIT_MAX_STREAMS];
};

struct credit_fixture {
    struct lsquic_test_pair cf_transport;
    struct credit_endpoint cf_client;
    struct credit_endpoint cf_server;
};


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct credit_endpoint *endpoint = ctx;

    assert(!endpoint->ce_conn);
    endpoint->ce_conn = conn;
    if (endpoint->ce_server)
        endpoint->ce_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct credit_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(status == LSQ_HSK_OK);
    endpoint->ce_handshake_ok = 1;
}


static void
settings_received (lsquic_conn_t *conn)
{
    struct credit_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);
    struct lsquic_webtransport_peer peer;

    assert(endpoint && endpoint->ce_conn == conn);
    ++endpoint->ce_settings_count;
    endpoint->ce_settings_result = lsquic_conn_get_webtransport_peer(conn, &peer);
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct credit_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint && endpoint->ce_conn == conn && !endpoint->ce_closed);
    endpoint->ce_closed = 1;
    endpoint->ce_conn = NULL;
    lsquic_conn_set_ctx(conn, NULL);
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct credit_endpoint *endpoint = ctx;
    struct credit_stream *state;

    assert(stream && endpoint->ce_stream_count < CREDIT_MAX_STREAMS);
    state = &endpoint->ce_streams[endpoint->ce_stream_count++];
    state->cs_endpoint = endpoint;
    state->cs_stream = stream;
    state->cs_id = lsquic_stream_id(stream);
    return (lsquic_stream_ctx_t *) state;
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct credit_stream *state = (void *) ctx;
    unsigned char bytes[16];
    ssize_t size;

    assert(state->cs_endpoint->ce_mode == CREDIT_RAW);
    while (1)
    {
        size = lsquic_stream_read(stream, bytes, sizeof(bytes));
        if (size > 0)
        {
            assert((size_t) size <= sizeof(state->cs_bytes) - state->cs_received);
            memcpy(state->cs_bytes + state->cs_received, bytes, size);
            state->cs_received += size;
            continue;
        }
        if (size < 0)
        {
            assert(errno == EAGAIN || errno == EWOULDBLOCK);
            return;
        }
        assert(!state->cs_fin);
        state->cs_fin = 1;
        assert(lsquic_stream_wantread(stream, 0) >= 0);
        assert(0 == lsquic_stream_shutdown(stream, 0));
        return;
    }
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) stream;
    (void) ctx;
    assert(0 && "credit cases use no application write callbacks");
}


static void
close_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct credit_stream *state = (void *) ctx;

    assert(state->cs_stream == stream && !state->cs_closed);
    state->cs_closed = 1;
    state->cs_stream = NULL;
}


static const struct lsquic_stream_if credit_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_new_stream = new_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_h3_settings = settings_received,
};


static void
pump_step (struct credit_fixture *fixture)
{
    lsquic_test_pair_process(&fixture->cf_transport, 1000);
    lsquic_test_deliver_all(&fixture->cf_transport.ltp_client);
    lsquic_test_deliver_all(&fixture->cf_transport.ltp_server);
}


static void
init_endpoint (struct credit_fixture *fixture, unsigned server,
               unsigned enabled, unsigned client_uni_limit, enum credit_mode mode)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct credit_endpoint *endpoint;
    struct lsquic_test_endpoint *transport, *peer;
    unsigned flags = (mode == CREDIT_HTTP ? LSENG_HTTP : 0)
                   | (server ? LSENG_SERVER : 0);
    const char *alpn = mode == CREDIT_HTTP ? "h3" : "uwz-credit-raw/1";

    endpoint = server ? &fixture->cf_server : &fixture->cf_client;
    endpoint->ce_server = server;
    endpoint->ce_mode = mode;
    transport = server ? &fixture->cf_transport.ltp_server
                       : &fixture->cf_transport.ltp_client;
    peer = server ? &fixture->cf_transport.ltp_client
                  : &fixture->cf_transport.ltp_server;
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = server ? 8 : client_uni_limit;
    settings.es_init_max_streams_bidi = mode == CREDIT_HTTP ? 5 : 8;
    settings.es_max_streams_in = mode == CREDIT_HTTP ? 2 : 8;
    settings.es_init_max_stream_data_bidi_local = mode == CREDIT_RAW && server
                            ? CREDIT_RAW_SERVER_LOCAL : CREDIT_BIDI_LOCAL;
    settings.es_init_max_stream_data_bidi_remote = mode == CREDIT_RAW && server
                            ? CREDIT_RAW_SERVER_REMOTE : CREDIT_BIDI_REMOTE;
    settings.es_init_max_stream_data_uni = CREDIT_UNI_WINDOW;
    settings.es_qpack_dec_max_size = 0;
    settings.es_qpack_dec_max_blocked = 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    settings.es_webtransport.enabled = enabled;
    if (enabled)
    {
        settings.es_datagrams = 1;
        settings.es_reset_stream_at = 1;
    }
    assert(settings.es_check_tp_sanity);
    assert(0 == lsquic_engine_check_settings(&settings, flags, NULL, 0));
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &credit_callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_alpn = alpn;
    config.ltec_tls = lsquic_test_tls_context_new(server, alpn);
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(transport, peer, &config,
                                        server ? 12801 : 12802));
    SSL_CTX_free(config.ltec_tls);
}


static void
start_fixture (struct credit_fixture *fixture, unsigned enabled,
               unsigned client_uni_limit, enum credit_mode mode)
{
    unsigned step;

    memset(fixture, 0, sizeof(*fixture));
    init_endpoint(fixture, 0, enabled, client_uni_limit, mode);
    init_endpoint(fixture, 1, enabled, client_uni_limit, mode);
    assert(lsquic_engine_connect(fixture->cf_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture->cf_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture->cf_transport.ltp_server.lte_address,
                &fixture->cf_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
    for (step = 0; step < CREDIT_MAX_STEPS; ++step)
    {
        if (fixture->cf_client.ce_handshake_ok && fixture->cf_server.ce_handshake_ok
            && (mode == CREDIT_RAW || (fixture->cf_client.ce_settings_count
                                    && fixture->cf_server.ce_settings_count)))
            break;
        pump_step(fixture);
    }
    assert(step < CREDIT_MAX_STEPS);
    assert(fixture->cf_client.ce_conn && fixture->cf_server.ce_conn);
    if (mode == CREDIT_HTTP)
    {
        assert(fixture->cf_client.ce_settings_count == 1);
        assert(fixture->cf_server.ce_settings_count == 1);
        assert(fixture->cf_client.ce_settings_result == LSQUIC_WTP_OK);
        assert(fixture->cf_server.ce_settings_result == LSQUIC_WTP_OK);
    }
    else
        assert(!fixture->cf_client.ce_settings_count && !fixture->cf_server.ce_settings_count);
    for (step = 0; step < 20; ++step)
        pump_step(fixture);
    assert(fixture->cf_client.ce_stream_count == 0);
    assert(fixture->cf_server.ce_stream_count == 0);
}


static const struct transport_params *
actual_peer_parameters (const lsquic_conn_t *conn)
{
    const struct transport_params *params;

    assert(conn && (conn->cn_flags & LSCONN_IETF));
    assert(conn->cn_esf.i && conn->cn_esf.i->esfi_get_peer_transport_params);
    params = conn->cn_esf.i->esfi_get_peer_transport_params(conn->cn_enc_session);
    assert(params);
    return params;
}


static void
assert_connected_ready (const struct credit_endpoint *endpoint)
{
    struct lsquic_webtransport_peer peer;

    assert(endpoint->ce_conn && !endpoint->ce_closed);
    assert(LSCONN_ST_CONNECTED == lsquic_conn_status(endpoint->ce_conn, NULL, 0));
    assert(LSQUIC_WTP_OK == lsquic_conn_get_webtransport_peer(endpoint->ce_conn, &peer));
    assert(endpoint->ce_settings_count == 1);
}


static void
prove_client_receive_admission (struct credit_fixture *fixture)
{
    static const unsigned char unknown_stream[] = { 0x21, 'u', 'w', 'z' };
    struct credit_endpoint *server = &fixture->cf_server;
    unsigned index, received_before, sent_before;

    received_before = fixture->cf_transport.ltp_client.lte_packets_received;
    sent_before = fixture->cf_transport.ltp_server.lte_packets_sent;
    for (index = 0; index < server->ce_stream_count; ++index)
    {
        assert(server->ce_streams[index].cs_stream);
        assert(sizeof(unknown_stream) == (size_t) lsquic_stream_write(
                    server->ce_streams[index].cs_stream,
                    unknown_stream, sizeof(unknown_stream)));
        assert(0 == lsquic_stream_flush(server->ce_streams[index].cs_stream));
        assert(lsquic_stream_has_unacked_data(server->ce_streams[index].cs_stream));
    }
    lsquic_engine_process_conns(fixture->cf_transport.ltp_server.lte_engine);
    assert(fixture->cf_transport.ltp_server.lte_packets_sent > sent_before);
    assert(fixture->cf_transport.ltp_client.lte_incoming.ltq_count > 0);
    for (index = 0; index < 200; ++index)
        pump_step(fixture);
    assert(fixture->cf_transport.ltp_client.lte_packets_received > received_before);
    /* Unknown HTTP/3 streams may be stopped; they must not exceed admission. */
    assert_connected_ready(&fixture->cf_client);
    assert_connected_ready(&fixture->cf_server);
}


static void
test_uni_credit (unsigned enabled, unsigned configured, unsigned advertised)
{
    struct credit_fixture fixture;
    struct credit_endpoint *server;
    const struct transport_params *params;
    unsigned index, available = advertised - 3;

    start_fixture(&fixture, enabled, configured, CREDIT_HTTP);
    server = &fixture.cf_server;
    params = actual_peer_parameters(server->ce_conn);
    assert(params->tp_decoded & (1U << TPI_INIT_MAX_STREAMS_UNI));
    /* The transport parameters came through the real encrypted handshake. */
    assert(params->tp_init_max_streams_uni == advertised);
    assert(params->tp_init_max_stream_data_uni == CREDIT_UNI_WINDOW);
    assert(params->tp_init_max_stream_data_bidi_local == CREDIT_BIDI_LOCAL);
    assert(params->tp_init_max_stream_data_bidi_remote == CREDIT_BIDI_REMOTE);
    for (index = 0; index < available; ++index)
    {
        assert(LSQUIC_MUS_OK == lsquic_conn_make_uni_stream(server->ce_conn));
        assert(server->ce_stream_count == index + 1);
        assert(server->ce_streams[index].cs_stream);
        assert(server->ce_streams[index].cs_id == 15 + 4 * index);
        assert(!server->ce_streams[index].cs_closed);
    }
    assert(LSQUIC_MUS_BLOCKED == lsquic_conn_make_uni_stream(server->ce_conn));
    assert(server->ce_stream_count == available);
    assert(fixture.cf_client.ce_stream_count == 0);
    for (index = 0; index < available; ++index)
        assert(server->ce_streams[index].cs_stream && !server->ce_streams[index].cs_closed);
    assert_connected_ready(&fixture.cf_client);
    assert_connected_ready(&fixture.cf_server);
    if (available)
        prove_client_receive_admission(&fixture);
    assert(server->ce_stream_count == available);
    assert(fixture.cf_client.ce_stream_count == 0);
    lsquic_test_endpoint_destroy(&fixture.cf_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture.cf_transport.ltp_server);
    printf("PASS actual client uni credit: WT%s/configured%u/peer TP%u/%u initially held-open application streams/next BLOCKED without callback/actual receive admission\n",
           enabled ? "enabled" : "disabled", configured, advertised, available);
}


static struct credit_stream *
find_stream (struct credit_endpoint *endpoint, lsquic_stream_id_t id)
{
    unsigned index;

    for (index = 0; index < endpoint->ce_stream_count; ++index)
        if (endpoint->ce_streams[index].cs_id == id)
            return &endpoint->ce_streams[index];
    return NULL;
}


static void
assert_send_cap (const struct credit_stream *stream, uint64_t expected)
{
    assert(stream && stream->cs_stream && !stream->cs_received && !stream->cs_closed);
    if (stream->cs_stream->max_send_off != expected)
        printf("raw bidi cap mismatch: endpoint=%s stream=%llu actual=%llu expected=%llu\n",
               stream->cs_endpoint->ce_server ? "server" : "client",
               (unsigned long long) stream->cs_id,
               (unsigned long long) stream->cs_stream->max_send_off,
               (unsigned long long) expected);
    assert(stream->cs_stream->max_send_off == expected);
}


static void
send_raw_half (struct credit_stream *stream, const char *payload, size_t already_sent)
{
    assert(stream && stream->cs_stream && already_sent <= 4);
    assert(4 - already_sent == (size_t) lsquic_stream_write(stream->cs_stream,
                                            payload + already_sent, 4 - already_sent));
    assert(0 == lsquic_stream_shutdown(stream->cs_stream, 1));
    assert(lsquic_stream_wantread(stream->cs_stream, 1) >= 0);
}


static void
assert_raw_received (const struct credit_stream *stream, const char *expected)
{
    assert(stream && stream->cs_closed && stream->cs_fin);
    assert(stream->cs_received == 4 && 0 == memcmp(stream->cs_bytes, expected, 4));
}


static void
test_raw_directional_credit (void)
{
    struct credit_fixture fixture;
    struct credit_stream *client_local, *client_remote, *server_local, *server_remote;
    const struct transport_params *client_peer, *server_peer;
    unsigned step;

    start_fixture(&fixture, 0, 8, CREDIT_RAW);
    client_peer = actual_peer_parameters(fixture.cf_client.ce_conn);
    server_peer = actual_peer_parameters(fixture.cf_server.ce_conn);
    assert(client_peer->tp_init_max_stream_data_bidi_local == CREDIT_RAW_SERVER_LOCAL);
    assert(client_peer->tp_init_max_stream_data_bidi_remote == CREDIT_RAW_SERVER_REMOTE);
    assert(server_peer->tp_init_max_stream_data_bidi_local == CREDIT_BIDI_LOCAL);
    assert(server_peer->tp_init_max_stream_data_bidi_remote == CREDIT_BIDI_REMOTE);
    lsquic_conn_make_stream(fixture.cf_client.ce_conn);
    lsquic_conn_make_stream(fixture.cf_server.ce_conn);
    assert(fixture.cf_client.ce_stream_count == 1 && fixture.cf_server.ce_stream_count == 1);
    client_local = find_stream(&fixture.cf_client, 0);
    server_local = find_stream(&fixture.cf_server, 1);
    assert(client_local && server_local);
    assert(1 == lsquic_stream_write(client_local->cs_stream, "cli0", 1));
    assert(0 == lsquic_stream_flush(client_local->cs_stream));
    assert(1 == lsquic_stream_write(server_local->cs_stream, "srv1", 1));
    assert(0 == lsquic_stream_flush(server_local->cs_stream));
    for (step = 0; step < CREDIT_MAX_STEPS; ++step)
    {
        if (fixture.cf_client.ce_stream_count == 2 && fixture.cf_server.ce_stream_count == 2)
            break;
        pump_step(&fixture);
    }
    assert(step < CREDIT_MAX_STEPS);
    client_remote = find_stream(&fixture.cf_client, 1);
    server_remote = find_stream(&fixture.cf_server, 0);
    assert(client_remote && server_remote);
    /* No application has read a byte, so no receive-window update is earned. */
    assert_send_cap(client_local, CREDIT_RAW_SERVER_REMOTE);
    assert_send_cap(server_remote, CREDIT_BIDI_LOCAL);
    assert_send_cap(server_local, CREDIT_BIDI_REMOTE);
    assert_send_cap(client_remote, CREDIT_RAW_SERVER_LOCAL);
    send_raw_half(client_local, "cli0", 1);
    send_raw_half(server_local, "srv1", 1);
    send_raw_half(server_remote, "srv0", 0);
    send_raw_half(client_remote, "cli1", 0);
    for (step = 0; step < CREDIT_MAX_STEPS; ++step)
    {
        if (client_local->cs_closed && client_remote->cs_closed
            && server_local->cs_closed && server_remote->cs_closed)
            break;
        pump_step(&fixture);
    }
    assert(step < CREDIT_MAX_STEPS);
    assert_raw_received(client_local, "srv0");
    assert_raw_received(server_remote, "cli0");
    assert_raw_received(server_local, "cli1");
    assert_raw_received(client_remote, "srv1");
    assert(fixture.cf_client.ce_conn && fixture.cf_server.ce_conn);
    assert(!fixture.cf_client.ce_settings_count && !fixture.cf_server.ce_settings_count);
    lsquic_test_endpoint_destroy(&fixture.cf_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture.cf_transport.ltp_server);
    puts("PASS raw QUIC directional bidi credit: client-created0/server-created1/all four actual peer-window send caps/exact bidirectional bytes+FIN");
}


int
main (int argc, char **argv)
{
    unsigned eight, three, disabled, raw;

    assert(argc <= 2);
    eight = argc == 1 || 0 == strcmp(argv[1], "all") || 0 == strcmp(argv[1], "enabled8");
    three = argc == 1 || 0 == strcmp(argv[1], "all") || 0 == strcmp(argv[1], "enabled3");
    disabled = argc == 1 || 0 == strcmp(argv[1], "all") || 0 == strcmp(argv[1], "disabled8");
    raw = argc == 1 || 0 == strcmp(argv[1], "all") || 0 == strcmp(argv[1], "raw");
    assert(eight || three || disabled || raw);
    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    if (eight)
        test_uni_credit(1, 8, 8);
    if (three)
        test_uni_credit(1, 3, 3);
    if (disabled)
        test_uni_credit(0, 8, 3);
    if (raw)
        test_raw_directional_credit();
    lsquic_global_cleanup();
    return 0;
}
