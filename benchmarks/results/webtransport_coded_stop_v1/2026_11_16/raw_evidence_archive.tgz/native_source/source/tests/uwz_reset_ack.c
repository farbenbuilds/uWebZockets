/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/queue.h>

#include <openssl/ssl.h>

#include "lsquic.h"
#include "uwz_quic_fixture.h"
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_packet_in.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"
#include "lsquic_conn_public.h"
#include "lsquic_parse.h"
#include "lsquic_conn.h"
#include "lsquic_cubic.h"
#include "lsquic_pacer.h"
#include "lsquic_senhist.h"
#include "lsquic_bw_sampler.h"
#include "lsquic_minmax.h"
#include "lsquic_bbr.h"
#include "lsquic_adaptive_cc.h"
#include "lsquic_send_ctl.h"

#ifdef NDEBUG
#error "uwz_reset_ack requires active assertions"
#endif
#ifndef LSQUIC_RESET_ACK_TEST_OBSERVER
#error "uwz_reset_ack requires the test-only reset ACK observer"
#endif

enum {
    ACK_MAX_STREAMS = 8,
    ACK_MAX_STEPS = 20000,
    ACK_PREFIX_SIZE = 64,
};

struct ack_stream {
    lsquic_stream_t *as_stream;
    lsquic_stream_id_t as_id;
    size_t as_received;
    unsigned as_outgoing;
    unsigned as_closed;
    unsigned as_reset_events;
    int as_read_error;
    uint64_t as_error;
    struct lsquic_stream_recv_state as_close_metadata;
    unsigned char as_bytes[ACK_PREFIX_SIZE];
};

struct ack_endpoint {
    struct lsquic_test_endpoint *ae_transport;
    lsquic_conn_t *ae_conn;
    unsigned ae_server;
    unsigned ae_handshake_ok;
    unsigned ae_hold_read;
    unsigned ae_stream_count;
    unsigned ae_observe;
    unsigned ae_scan_calls;
    size_t ae_scan_candidates;
    size_t ae_scan_packets;
    size_t ae_scan_frames;
    struct ack_stream ae_streams[ACK_MAX_STREAMS];
};

struct ack_fixture {
    struct lsquic_test_pair af_transport;
    struct ack_endpoint af_client;
    struct ack_endpoint af_server;
};

/* Counts come from real retained packets and parsed serialized frame records. */
struct ack_retained {
    unsigned ar_packets;
    unsigned ar_frames;
    unsigned ar_prefixes;
    unsigned ar_resets;
    unsigned ar_acks;
    unsigned ar_stream_mask;
    lsquic_packno_t ar_last_packet;
};

static const char ack_alpn[] = "uwz-reset-ack/1";


void
lsquic_reset_ack_scan_observer (const struct lsquic_conn *conn,
                              const struct lsquic_reset_ack_scan_stats *stats)
{
    struct ack_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint);
    if (!endpoint->ae_observe)
        return;
    ++endpoint->ae_scan_calls;
    endpoint->ae_scan_candidates += stats->candidates;
    endpoint->ae_scan_packets += stats->packets;
    endpoint->ae_scan_frames += stats->frames;
}


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct ack_endpoint *endpoint = ctx;

    assert(!endpoint->ae_conn);
    endpoint->ae_conn = conn;
    if (endpoint->ae_server)
        endpoint->ae_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct ack_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(status == LSQ_HSK_OK);
    endpoint->ae_handshake_ok = 1;
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct ack_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint->ae_conn == conn);
    endpoint->ae_conn = NULL;
    lsquic_conn_set_ctx(conn, NULL);
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct ack_endpoint *endpoint = ctx;
    struct ack_stream *state;

    assert(stream && endpoint->ae_stream_count < ACK_MAX_STREAMS);
    state = &endpoint->ae_streams[endpoint->ae_stream_count++];
    memset(state, 0, sizeof(*state));
    state->as_stream = stream;
    state->as_id = lsquic_stream_id(stream);
    state->as_outgoing = (state->as_id & 1) == endpoint->ae_server;
    if (!state->as_outgoing && !endpoint->ae_hold_read)
        assert(lsquic_stream_wantread(stream, 1) >= 0);
    return (lsquic_stream_ctx_t *) state;
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct ack_stream *state = (void *) ctx;
    unsigned char bytes[ACK_PREFIX_SIZE];
    ssize_t size;

    while (1)
    {
        size = lsquic_stream_read(stream, bytes, sizeof(bytes));
        if (size > 0)
        {
            assert((size_t) size <= sizeof(state->as_bytes) - state->as_received);
            memcpy(state->as_bytes + state->as_received, bytes, size);
            state->as_received += size;
            continue;
        }
        assert(size < 0);
        if (errno != ECONNRESET)
        {
            assert(errno == EAGAIN || errno == EWOULDBLOCK);
            return;
        }
        state->as_read_error = ECONNRESET;
        assert(lsquic_stream_wantread(stream, 0) >= 0);
        assert(0 == lsquic_stream_shutdown(stream, 0));
        return;
    }
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) stream;
    (void) ctx;
    assert(0 && "ACK cases write through the public synchronous API");
}


static void
close_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct ack_stream *state = (void *) ctx;

    assert(state->as_stream == stream && !state->as_closed);
    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream,
                                                   &state->as_close_metadata));
    state->as_closed = 1;
    state->as_stream = NULL;
}


static void
reset_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx, int how)
{
    struct ack_stream *state = (void *) ctx;

    assert(how == 0 && !state->as_outgoing && !state->as_reset_events);
    assert(LSQUIC_SERR_AVAILABLE == lsquic_stream_get_reset_error(stream, how,
                                                            &state->as_error));
    assert(state->as_error == 373);
    state->as_reset_events = 1;
}


static const struct lsquic_stream_if ack_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_new_stream = new_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_reset = reset_stream,
};


static void
pump_step (struct ack_fixture *fixture)
{
    lsquic_test_pair_process(&fixture->af_transport, 1000);
    lsquic_test_deliver_all(&fixture->af_transport.ltp_client);
    lsquic_test_deliver_all(&fixture->af_transport.ltp_server);
}


static void
init_endpoint (struct ack_fixture *fixture, struct ack_endpoint *endpoint,
               unsigned server)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct lsquic_test_endpoint *peer;
    unsigned flags = server ? LSENG_SERVER : 0;

    endpoint->ae_server = server;
    endpoint->ae_hold_read = 1;
    endpoint->ae_transport = server ? &fixture->af_transport.ltp_server
                                   : &fixture->af_transport.ltp_client;
    peer = server ? &fixture->af_transport.ltp_client
                  : &fixture->af_transport.ltp_server;
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = ACK_MAX_STREAMS;
    settings.es_max_streams_in = ACK_MAX_STREAMS;
    settings.es_reset_stream_at = 1;
    assert(settings.es_check_tp_sanity);
    assert(0 == lsquic_engine_check_settings(&settings, flags, NULL, 0));
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &ack_callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_alpn = ack_alpn;
    config.ltec_tls = lsquic_test_tls_context_new(server, ack_alpn);
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(endpoint->ae_transport, peer, &config,
                                        server ? 12301 : 12302));
    SSL_CTX_free(config.ltec_tls);
}


static void
init_fixture (struct ack_fixture *fixture)
{
    unsigned step;

    memset(fixture, 0, sizeof(*fixture));
    init_endpoint(fixture, &fixture->af_client, 0);
    init_endpoint(fixture, &fixture->af_server, 1);
    assert(lsquic_engine_connect(fixture->af_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture->af_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture->af_transport.ltp_server.lte_address,
                &fixture->af_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
    for (step = 0; step < ACK_MAX_STEPS; ++step)
    {
        if (fixture->af_client.ae_handshake_ok && fixture->af_server.ae_handshake_ok)
            break;
        pump_step(fixture);
    }
    assert(fixture->af_client.ae_handshake_ok && fixture->af_server.ae_handshake_ok);
    for (step = 0; step < 200; ++step)
        pump_step(fixture);
    assert(!fixture->af_transport.ltp_client.lte_incoming.ltq_count);
    assert(!fixture->af_transport.ltp_server.lte_incoming.ltq_count);
}


static struct ack_stream *
find_stream (struct ack_endpoint *endpoint, lsquic_stream_id_t id)
{
    unsigned index;

    for (index = 0; index < endpoint->ae_stream_count; ++index)
        if (endpoint->ae_streams[index].as_id == id)
            return &endpoint->ae_streams[index];
    return NULL;
}


static struct ack_stream *
make_prefix (struct ack_endpoint *sender, lsquic_stream_id_t id)
{
    struct ack_stream *stream;
    unsigned char bytes[ACK_PREFIX_SIZE];

    assert(LSQUIC_MUS_OK == lsquic_conn_make_uni_stream(sender->ae_conn));
    stream = find_stream(sender, id);
    assert(stream && stream->as_stream && stream->as_outgoing);
    memset(bytes, (int) ('a' + id / 4), sizeof(bytes));
    assert(sizeof(bytes) == (size_t) lsquic_stream_write(stream->as_stream,
                                                         bytes, sizeof(bytes)));
    assert(0 == lsquic_stream_flush(stream->as_stream));
    assert(stream->as_stream->tosend_off == ACK_PREFIX_SIZE);
    assert(stream->as_stream->sm_n_buffered == 0);
    return stream;
}


static struct lsquic_send_ctl *
stream_send_ctl (struct ack_stream *stream)
{
    assert(stream && stream->as_stream);
    return stream->as_stream->conn_pub->send_ctl;
}


static void
assert_other_queues_empty (const struct lsquic_send_ctl *ctl)
{
    assert(TAILQ_EMPTY(&ctl->sc_scheduled_packets));
    assert(TAILQ_EMPTY(&ctl->sc_unacked_packets[PNS_INIT]));
    assert(TAILQ_EMPTY(&ctl->sc_unacked_packets[PNS_HSK]));
    assert(TAILQ_EMPTY(&ctl->sc_lost_packets));
    assert(TAILQ_EMPTY(&ctl->sc_buffered_packets[0].bpq_packets));
    assert(TAILQ_EMPTY(&ctl->sc_buffered_packets[1].bpq_packets));
    assert(TAILQ_EMPTY(&ctl->sc_0rtt_stash));
}


static void
count_frame (const struct parse_funcs *pf, const struct frame_rec *record,
             const struct lsquic_packet_out *packet, uint64_t reliable,
             struct ack_retained *summary)
{
    struct stream_frame prefix;
    struct lsquic_reset_stream_at reset;
    struct ack_info ack;
    unsigned index;

    assert((size_t) record->fe_off + record->fe_len <= packet->po_data_sz);
    ++summary->ar_frames;
    if (record->fe_frame_type == QUIC_FRAME_STREAM)
    {
        assert(record->fe_len == pf->pf_parse_stream_frame(
                packet->po_data + record->fe_off, record->fe_len, &prefix));
        assert(prefix.stream_id == record->fe_stream->id);
        assert((prefix.stream_id & 2) && prefix.stream_id / 4 < ACK_MAX_STREAMS);
        assert(prefix.data_frame.df_offset == 0);
        assert(prefix.data_frame.df_size == ACK_PREFIX_SIZE);
        for (index = 0; index < ACK_PREFIX_SIZE; ++index)
            assert(prefix.data_frame.df_data[index] == 'a' + prefix.stream_id / 4);
        ++summary->ar_prefixes;
        summary->ar_stream_mask |= 1U << (prefix.stream_id / 4);
        return;
    }
    if (record->fe_frame_type == QUIC_FRAME_RESET_STREAM_AT)
    {
        assert(record->fe_len == pf->pf_parse_reset_stream_at_frame(
                packet->po_data + record->fe_off, record->fe_len, &reset));
        assert(reset.stream_id == record->fe_stream->id);
        assert((reset.stream_id & 2) && reset.stream_id / 4 < ACK_MAX_STREAMS);
        assert(reset.final_size == ACK_PREFIX_SIZE && reset.reliable_size == reliable);
        assert(reset.error_code == 373);
        ++summary->ar_resets;
        summary->ar_stream_mask |= 1U << (reset.stream_id / 4);
        return;
    }
    assert(record->fe_frame_type == QUIC_FRAME_ACK && record->fe_len > 0);
    assert(packet->po_data[record->fe_off] == 0x02
        || packet->po_data[record->fe_off] == 0x03);
    /* Delay scaling does not affect the ACK frame's structural validity. */
    assert(record->fe_len == pf->pf_parse_ack_frame(
                    packet->po_data + record->fe_off, record->fe_len, &ack, 0));
    assert(ack.n_ranges > 0);
    ++summary->ar_acks;
}


static struct ack_retained
retained_records (struct ack_stream *stream, uint64_t reliable)
{
    struct lsquic_send_ctl *ctl = stream_send_ctl(stream);
    const struct parse_funcs *pf = stream->as_stream->conn_pub->lconn->cn_pf;
    struct lsquic_packet_out *packet;
    struct packet_out_frec_iter iterator;
    const struct frame_rec *record;
    struct ack_retained summary = { 0 };

    assert_other_queues_empty(ctl);
    TAILQ_FOREACH(packet, &ctl->sc_unacked_packets[PNS_APP], po_next)
    {
        assert(!(packet->po_flags & (PO_LOSS_REC | PO_POISON)));
        ++summary.ar_packets;
        summary.ar_last_packet = packet->po_packno;
        for (record = lsquic_pofi_first(&iterator, packet); record;
                                record = lsquic_pofi_next(&iterator))
            count_frame(pf, record, packet, reliable, &summary);
    }
    assert(summary.ar_frames == summary.ar_prefixes + summary.ar_resets
                                                    + summary.ar_acks);
    return summary;
}


static void
assert_latest_reset (struct ack_stream *stream, uint64_t reliable,
                     lsquic_packno_t previous)
{
    struct lsquic_send_ctl *ctl = stream_send_ctl(stream);
    struct lsquic_packet_out *packet;
    struct packet_out_frec_iter iterator;
    const struct frame_rec *record;
    const struct parse_funcs *pf = stream->as_stream->conn_pub->lconn->cn_pf;
    struct ack_retained summary = { 0 };

    assert_other_queues_empty(ctl);
    packet = TAILQ_LAST(&ctl->sc_unacked_packets[PNS_APP], lsquic_packets_tailq);
    assert(packet && packet->po_packno > previous);
    for (record = lsquic_pofi_first(&iterator, packet); record;
                                    record = lsquic_pofi_next(&iterator))
        count_frame(pf, record, packet, reliable, &summary);
    assert(summary.ar_resets == 1 && !summary.ar_prefixes);
}


static void
collect_only_ack (struct ack_fixture *fixture, struct ack_endpoint *sender,
                  struct ack_endpoint *receiver, struct ack_stream *incoming,
                  lsquic_packno_t acknowledged, struct lsquic_test_packet *ack)
{
    unsigned step, sent_before = sender->ae_transport->lte_packets_sent;

    assert(sender->ae_transport->lte_incoming.ltq_count <= 1);
    for (step = 0; step < 100
                && !sender->ae_transport->lte_incoming.ltq_count; ++step)
    {
        lsquic_test_pair_process(&fixture->af_transport, 1000);
        assert(!receiver->ae_transport->lte_incoming.ltq_count);
        assert(sender->ae_transport->lte_packets_sent == sent_before);
        if (sender->ae_transport->lte_incoming.ltq_count)
            break;
    }
    assert(sender->ae_transport->lte_incoming.ltq_count == 1);
    assert(incoming && incoming->as_stream);
    assert(stream_send_ctl(incoming)->sc_largest_acked == acknowledged);
    assert(0 == lsquic_test_packet_take(sender->ae_transport, 0, ack));
    assert(ack->ltp_size > 0);
}


static void
assert_metadata (struct ack_stream *incoming, uint64_t reliable)
{
    struct lsquic_stream_recv_state metadata;
    unsigned known = LSQUIC_SRS_FINAL_SIZE_KNOWN | LSQUIC_SRS_RESET_KNOWN
                                              | LSQUIC_SRS_RELIABLE_RESET_SEEN;

    assert(incoming && incoming->as_stream && !incoming->as_received);
    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(incoming->as_stream,
                                                                    &metadata));
    assert((metadata.flags & known) == known);
    assert(!(metadata.flags & LSQUIC_SRS_RESET_VISIBLE));
    assert(metadata.final_size == ACK_PREFIX_SIZE);
    assert(metadata.reliable_size == reliable && metadata.reset_error_code == 373);
}


static void
finish_stream (struct ack_fixture *fixture, struct ack_endpoint *receiver,
               struct ack_stream *outgoing, uint64_t reliable)
{
    struct ack_stream *incoming = find_stream(receiver, outgoing->as_id);
    unsigned step, index;

    assert_metadata(incoming, reliable);
    assert(lsquic_stream_wantread(incoming->as_stream, 1) >= 0);
    for (step = 0; step < ACK_MAX_STEPS; ++step)
    {
        if (outgoing->as_closed && incoming->as_closed)
            break;
        pump_step(fixture);
    }
    assert(outgoing->as_closed && incoming->as_closed);
    assert(incoming->as_read_error == ECONNRESET && incoming->as_reset_events == 1);
    assert(incoming->as_error == 373);
    assert(incoming->as_received >= reliable && incoming->as_received <= ACK_PREFIX_SIZE);
    for (index = 0; index < incoming->as_received; ++index)
        assert(incoming->as_bytes[index] == 'a' + incoming->as_id / 4);
    assert(incoming->as_close_metadata.final_size == ACK_PREFIX_SIZE);
    assert(incoming->as_close_metadata.reliable_size == reliable);
    assert(incoming->as_close_metadata.reset_error_code == 373);
    assert(incoming->as_close_metadata.flags & LSQUIC_SRS_RESET_VISIBLE);
}


static void
cleanup_fixture (struct ack_fixture *fixture)
{
    lsquic_test_endpoint_destroy(&fixture->af_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture->af_transport.ltp_server);
}


static void
test_obsolete_reset_ack (unsigned server_sender)
{
    struct ack_fixture fixture;
    struct ack_endpoint *sender, *receiver;
    struct ack_stream *outgoing, *incoming;
    struct ack_retained records;
    struct lsquic_test_packet old_ack, lost_reset;
    lsquic_stream_id_t id = server_sender ? 3 : 2;
    unsigned step, sent_before;

    init_fixture(&fixture);
    sender = server_sender ? &fixture.af_server : &fixture.af_client;
    receiver = server_sender ? &fixture.af_client : &fixture.af_server;
    outgoing = make_prefix(sender, id);
    for (step = 0; step < ACK_MAX_STEPS; ++step)
    {
        if (!lsquic_stream_has_unacked_data(outgoing->as_stream))
            break;
        pump_step(&fixture);
    }
    assert(!lsquic_stream_has_unacked_data(outgoing->as_stream));
    assert(outgoing->as_stream->n_unacked == 0);
    incoming = find_stream(receiver, id);
    assert(incoming && incoming->as_stream && !incoming->as_received);
    for (step = 0; step < 100; ++step)
        pump_step(&fixture);
    assert(!sender->ae_transport->lte_incoming.ltq_count);
    assert(!receiver->ae_transport->lte_incoming.ltq_count);
    sent_before = sender->ae_transport->lte_packets_sent;
    assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(outgoing->as_stream, 373, 64));
    lsquic_engine_process_conns(sender->ae_transport->lte_engine);
    records = retained_records(outgoing, 64);
    assert(records.ar_packets == 1 && records.ar_resets == 1 && !records.ar_prefixes);
    assert(sender->ae_transport->lte_packets_sent == sent_before + 1);
    assert(receiver->ae_transport->lte_incoming.ltq_count == 1);
    lsquic_test_deliver_all(receiver->ae_transport);
    lsquic_engine_process_conns(receiver->ae_transport->lte_engine);
    assert_metadata(incoming, 64);
    collect_only_ack(&fixture, sender, receiver, incoming,
                    records.ar_last_packet, &old_ack);
    sent_before = sender->ae_transport->lte_packets_sent;
    assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(outgoing->as_stream, 373, 33));
    lsquic_engine_process_conns(sender->ae_transport->lte_engine);
    assert(sender->ae_transport->lte_packets_sent == sent_before + 1);
    assert(receiver->ae_transport->lte_incoming.ltq_count == 1);
    assert_latest_reset(outgoing, 33, records.ar_last_packet);
    /* These are the sole fresh bytes; no packet is replayed for recovery. */
    assert(0 == lsquic_test_packet_take(receiver->ae_transport, 0, &lost_reset));
    assert(lost_reset.ltp_size > 0);
    assert(!receiver->ae_transport->lte_incoming.ltq_count);
    assert(!outgoing->as_closed && outgoing->as_stream);
    assert(!(outgoing->as_stream->stream_flags & STREAM_RST_ACKED));
    /* No clock advance can turn the lost current reset into a timeout here. */
    assert(lsquic_test_packet_deliver(sender->ae_transport, &old_ack) >= 0);
    lsquic_engine_process_conns(sender->ae_transport->lte_engine);
    assert(!outgoing->as_closed && outgoing->as_stream);
    assert(!(outgoing->as_stream->stream_flags & STREAM_RST_ACKED));
    assert(outgoing->as_stream->sm_reset_tx_reliable == 33);
    assert(outgoing->as_stream->sm_reset_tx_final == ACK_PREFIX_SIZE);
    assert(outgoing->as_stream->error_code == 373);
    for (step = 0; step < ACK_MAX_STEPS; ++step)
    {
        struct lsquic_stream_recv_state metadata;

        pump_step(&fixture);
        assert(incoming->as_stream);
        assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(incoming->as_stream,
                                                                    &metadata));
        if (metadata.reliable_size == 33)
            break;
    }
    assert(step < ACK_MAX_STEPS);
    finish_stream(&fixture, receiver, outgoing, 33);
    cleanup_fixture(&fixture);
    printf("PASS ACKed prefix64/held RESET64 ACK/shrink33/drop fresh reset/obsolete ACK cannot close/native recovery/error373: %s sender\n",
           server_sender ? "server" : "client");
}


static int
send_queues_empty (const struct lsquic_send_ctl *ctl)
{
    return TAILQ_EMPTY(&ctl->sc_scheduled_packets)
        && TAILQ_EMPTY(&ctl->sc_unacked_packets[PNS_INIT])
        && TAILQ_EMPTY(&ctl->sc_unacked_packets[PNS_HSK])
        && TAILQ_EMPTY(&ctl->sc_unacked_packets[PNS_APP])
        && TAILQ_EMPTY(&ctl->sc_lost_packets)
        && TAILQ_EMPTY(&ctl->sc_buffered_packets[0].bpq_packets)
        && TAILQ_EMPTY(&ctl->sc_buffered_packets[1].bpq_packets)
        && TAILQ_EMPTY(&ctl->sc_0rtt_stash);
}


static void
settle_before_prefix (struct ack_fixture *fixture, struct ack_endpoint *sender,
                      struct ack_endpoint *receiver, struct ack_stream *stream)
{
    struct lsquic_send_ctl *ctl = stream_send_ctl(stream);
    unsigned step;

    for (step = 0; step < ACK_MAX_STEPS; ++step)
    {
        /* A genuine peer ACK drains control traffic without hiding records. */
        pump_step(fixture);
        if (send_queues_empty(ctl)
            && !sender->ae_transport->lte_incoming.ltq_count
            && !receiver->ae_transport->lte_incoming.ltq_count
            && !lsquic_engine_has_unsent_packets(sender->ae_transport->lte_engine)
            && !lsquic_engine_has_unsent_packets(receiver->ae_transport->lte_engine))
            break;
    }
    assert(step < ACK_MAX_STEPS);
    assert(send_queues_empty(ctl));
}


static void
test_coalesced_ack_batch (unsigned server_sender)
{
    struct ack_fixture fixture;
    struct ack_endpoint *sender, *receiver;
    struct ack_stream *outgoing[ACK_MAX_STREAMS];
    struct ack_stream *incoming;
    struct ack_retained prefixes, retained;
    struct lsquic_test_packet prefix_packet, prefix_ack;
    struct lsquic_test_packet reset_packets[ACK_MAX_STREAMS];
    lsquic_stream_id_t first_id = server_sender ? 3 : 2;
    unsigned index, reset_count, sent_before;
    unsigned char bytes[ACK_PREFIX_SIZE];
    unsigned all_streams = (1U << ACK_MAX_STREAMS) - 1;

    init_fixture(&fixture);
    sender = server_sender ? &fixture.af_server : &fixture.af_client;
    receiver = server_sender ? &fixture.af_client : &fixture.af_server;
    for (index = 0; index < ACK_MAX_STREAMS; ++index)
    {
        assert(LSQUIC_MUS_OK == lsquic_conn_make_uni_stream(sender->ae_conn));
        outgoing[index] = find_stream(sender, first_id + 4 * index);
        assert(outgoing[index] && outgoing[index]->as_stream);
        assert(outgoing[index]->as_outgoing);
    }
    assert(sender->ae_stream_count == ACK_MAX_STREAMS);
    settle_before_prefix(&fixture, sender, receiver, outgoing[0]);
    sent_before = sender->ae_transport->lte_packets_sent;
    for (index = 0; index < ACK_MAX_STREAMS; ++index)
    {
        assert(outgoing[index]->as_id == first_id + 4 * index);
        memset(bytes, (int) ('a' + outgoing[index]->as_id / 4), sizeof(bytes));
        assert(sizeof(bytes) == (size_t) lsquic_stream_write(
                            outgoing[index]->as_stream, bytes, sizeof(bytes)));
        assert(0 == lsquic_stream_flush(outgoing[index]->as_stream));
        assert(outgoing[index]->as_stream->tosend_off == ACK_PREFIX_SIZE);
        assert(!outgoing[index]->as_stream->sm_n_buffered);
    }
    lsquic_engine_process_conns(sender->ae_transport->lte_engine);
    prefixes = retained_records(outgoing[0], ACK_PREFIX_SIZE);
    if (prefixes.ar_packets != 1 || prefixes.ar_prefixes != ACK_MAX_STREAMS)
        printf("batch prefix setup: role=%s streams=%u packets=%u prefixes=%u frames=%u ACKs=%u mask=0x%X sent=%u queued=%u\n",
               server_sender ? "server" : "client", sender->ae_stream_count,
               prefixes.ar_packets, prefixes.ar_prefixes, prefixes.ar_frames,
               prefixes.ar_acks, prefixes.ar_stream_mask,
               sender->ae_transport->lte_packets_sent - sent_before,
               receiver->ae_transport->lte_incoming.ltq_count);
    assert(prefixes.ar_packets == 1 && prefixes.ar_prefixes == ACK_MAX_STREAMS);
    assert(prefixes.ar_frames == ACK_MAX_STREAMS + prefixes.ar_acks);
    assert(!prefixes.ar_resets);
    assert(prefixes.ar_stream_mask == all_streams);
    assert(sender->ae_transport->lte_packets_sent == sent_before + 1);
    assert(receiver->ae_transport->lte_incoming.ltq_count == 1);
    assert(!sender->ae_transport->lte_incoming.ltq_count);
    assert(0 == lsquic_test_packet_take(receiver->ae_transport, 0, &prefix_packet));
    assert(prefix_packet.ltp_size > 0);
    assert(receiver->ae_stream_count == 0);
    sent_before = sender->ae_transport->lte_packets_sent;
    for (index = 0; index < ACK_MAX_STREAMS; ++index)
    {
        assert(outgoing[index]->as_stream->n_unacked == 1);
        assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(
                            outgoing[index]->as_stream, 373, ACK_PREFIX_SIZE));
    }
    lsquic_engine_process_conns(sender->ae_transport->lte_engine);
    reset_count = receiver->ae_transport->lte_incoming.ltq_count;
    assert(reset_count > 0 && reset_count <= ACK_MAX_STREAMS);
    assert(sender->ae_transport->lte_packets_sent == sent_before + reset_count);
    retained = retained_records(outgoing[0], ACK_PREFIX_SIZE);
    assert(retained.ar_packets == reset_count + 1);
    assert(retained.ar_prefixes == ACK_MAX_STREAMS);
    assert(retained.ar_resets == ACK_MAX_STREAMS);
    assert(retained.ar_frames == 2 * ACK_MAX_STREAMS + retained.ar_acks);
    assert(retained.ar_stream_mask == all_streams);
    for (index = 0; index < ACK_MAX_STREAMS; ++index)
    {
        assert(!outgoing[index]->as_closed && outgoing[index]->as_stream);
        assert(outgoing[index]->as_stream->n_unacked == 2);
        assert(!(outgoing[index]->as_stream->stream_flags & STREAM_PREFIX_ACKED));
        assert(!(outgoing[index]->as_stream->stream_flags & STREAM_RST_ACKED));
    }
    for (index = 0; index < reset_count; ++index)
    {
        assert(0 == lsquic_test_packet_take(receiver->ae_transport, 0,
                                                        &reset_packets[index]));
        assert(reset_packets[index].ltp_size > 0);
    }
    assert(!receiver->ae_transport->lte_incoming.ltq_count);
    /* All eight prefix ranges share this one genuine encrypted datagram. */
    assert(lsquic_test_packet_deliver(receiver->ae_transport, &prefix_packet) >= 0);
    lsquic_engine_process_conns(receiver->ae_transport->lte_engine);
    assert(receiver->ae_stream_count == ACK_MAX_STREAMS);
    incoming = find_stream(receiver, first_id);
    collect_only_ack(&fixture, sender, receiver, incoming,
                    prefixes.ar_last_packet, &prefix_ack);
    assert(!sender->ae_transport->lte_incoming.ltq_count);
    assert(!receiver->ae_transport->lte_incoming.ltq_count);
    assert(sender->ae_scan_calls == 0);
    sender->ae_observe = 1;
    assert(lsquic_test_packet_deliver(sender->ae_transport, &prefix_ack) >= 0);
    lsquic_engine_process_conns(sender->ae_transport->lte_engine);
    sender->ae_observe = 0;
    /* The remaining records are the exact RESET cohort, not prefix data. */
    retained = retained_records(outgoing[0], ACK_PREFIX_SIZE);
    assert(retained.ar_packets == reset_count && retained.ar_prefixes == 0);
    assert(retained.ar_resets == ACK_MAX_STREAMS);
    assert(retained.ar_frames == ACK_MAX_STREAMS + retained.ar_acks);
    assert(retained.ar_stream_mask == all_streams);
    assert(sender->ae_scan_calls == 1);
    assert(sender->ae_scan_candidates == ACK_MAX_STREAMS);
    assert(sender->ae_scan_packets == retained.ar_packets);
    assert(sender->ae_scan_frames == retained.ar_frames);
    for (index = 0; index < ACK_MAX_STREAMS; ++index)
    {
        assert(!outgoing[index]->as_closed && outgoing[index]->as_stream);
        assert(outgoing[index]->as_stream->n_unacked == 1);
        assert(outgoing[index]->as_stream->stream_flags & STREAM_PREFIX_ACKED);
        assert(!(outgoing[index]->as_stream->stream_flags & STREAM_RST_ACKED));
    }
    assert(!receiver->ae_transport->lte_incoming.ltq_count);
    for (index = 0; index < reset_count; ++index)
        assert(lsquic_test_packet_deliver(receiver->ae_transport,
                                                    &reset_packets[index]) >= 0);
    lsquic_engine_process_conns(receiver->ae_transport->lte_engine);
    for (index = 0; index < ACK_MAX_STREAMS; ++index)
        finish_stream(&fixture, receiver, outgoing[index], ACK_PREFIX_SIZE);
    cleanup_fixture(&fixture);
    printf("PASS eight prefix64 ranges/sole encrypted prefix packet/one coalesced ACK pass/candidates8/retained RESET visits once/no early close/error373: %s sender\n",
           server_sender ? "server" : "client");
}


int
main (int argc, char **argv)
{
    unsigned shrink, batch;

    assert(argc <= 2);
    shrink = argc == 1 || 0 == strcmp(argv[1], "all")
                      || 0 == strcmp(argv[1], "shrink");
    batch = argc == 1 || 0 == strcmp(argv[1], "all")
                     || 0 == strcmp(argv[1], "batch");
    assert(shrink || batch);
    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    if (shrink)
    {
        test_obsolete_reset_ack(0);
        test_obsolete_reset_ack(1);
    }
    if (batch)
    {
        test_coalesced_ack_batch(0);
        test_coalesced_ack_batch(1);
    }
    lsquic_global_cleanup();
    return 0;
}
