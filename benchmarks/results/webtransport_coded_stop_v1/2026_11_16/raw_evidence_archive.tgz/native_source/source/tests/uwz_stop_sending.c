/* Copyright (c) 2026 uWebZockets contributors. See LICENSE. */
#include <assert.h>
#include <stdint.h>
#include <string.h>
#include <sys/queue.h>
#include <openssl/ssl.h>
#include "lsquic.h"
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_packet_in.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"
#include "lsquic_conn_public.h"
#include "lsquic_conn.h"
#include "uwz_quic_fixture.h"

#ifdef NDEBUG
#error "uwz_stop_sending requires active assertions"
#endif

/* The baseline sends its HEC_NO_ERROR default, producing the wire RED. */
extern int lsquic_stream_stop_sending(lsquic_stream_t *, uint64_t)
    __attribute__((weak));

enum { MAX_STEPS = 20000, MAX_STREAMS = 8 };
enum { EXPECT_OK = 0, EXPECT_BLOCKED = 1, EXPECT_UNSUPPORTED = -1,
       EXPECT_INVALID = -2, EXPECT_CLOSED = -3 };
struct endpoint;
struct stream_state {
    lsquic_stream_t *stream;
    uint64_t id;
    uint64_t errors[2];
    unsigned resets[2];
    unsigned closed;
};
struct endpoint {
    lsquic_conn_t *connection;
    unsigned server;
    unsigned handshake;
    unsigned stream_count;
    struct stream_state streams[MAX_STREAMS];
};
struct fixture {
    struct lsquic_test_pair transport;
    struct endpoint client;
    struct endpoint server;
};

static lsquic_conn_ctx_t *
on_connection(void *context, lsquic_conn_t *connection)
{
    struct endpoint *endpoint = context;
    endpoint->connection = connection;
    endpoint->handshake = endpoint->server;
    return (void *) endpoint;
}

static void
on_connection_closed(lsquic_conn_t *connection)
{
    struct endpoint *endpoint = (void *) lsquic_conn_get_ctx(connection);
    assert(endpoint->connection == connection);
    endpoint->connection = NULL;
    lsquic_conn_set_ctx(connection, NULL);
}

static void
on_handshake(lsquic_conn_t *connection, enum lsquic_hsk_status status)
{
    struct endpoint *endpoint = (void *) lsquic_conn_get_ctx(connection);
    assert(status == LSQ_HSK_OK);
    endpoint->handshake = 1;
}

static lsquic_stream_ctx_t *
on_stream(void *context, lsquic_stream_t *stream)
{
    struct endpoint *endpoint = context;
    struct stream_state *state;
    assert(endpoint->stream_count < MAX_STREAMS);
    state = &endpoint->streams[endpoint->stream_count++];
    state->stream = stream;
    state->id = lsquic_stream_id(stream);
    return (void *) state;
}

static void
on_reset(lsquic_stream_t *stream, lsquic_stream_ctx_t *context, int how)
{
    struct stream_state *state = (void *) context;
    assert(state->stream == stream && (how == 0 || how == 1));
    assert(!state->resets[how]);
    assert(LSQUIC_SERR_AVAILABLE == lsquic_stream_get_reset_error(stream, how,
                                                         &state->errors[how]));
    ++state->resets[how];
}

static void
on_close(lsquic_stream_t *stream, lsquic_stream_ctx_t *context)
{
    struct stream_state *state = (void *) context;
    assert(state->stream == stream && !state->closed);
    if (lsquic_stream_stop_sending
            && (!(state->id & 2)
                || (state->id & 1) != !!(stream->sm_bflags & SMBF_SERVER)))
        assert(EXPECT_CLOSED == lsquic_stream_stop_sending(stream, 7));
    state->closed = 1;
    state->stream = NULL;
}

static const struct lsquic_stream_if callbacks = {
    .on_new_conn = on_connection,
    .on_conn_closed = on_connection_closed,
    .on_hsk_done = on_handshake,
    .on_new_stream = on_stream,
    .on_reset = on_reset,
    .on_close = on_close,
};

static void
pump(struct fixture *fixture)
{
    lsquic_test_pair_process(&fixture->transport, 1000);
    lsquic_test_deliver_all(&fixture->transport.ltp_client);
    lsquic_test_deliver_all(&fixture->transport.ltp_server);
}

static void
init_endpoint(struct fixture *fixture, unsigned server)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct endpoint *endpoint = server ? &fixture->server : &fixture->client;
    struct lsquic_test_endpoint *transport = server ? &fixture->transport.ltp_server
                                                   : &fixture->transport.ltp_client;
    struct lsquic_test_endpoint *peer = server ? &fixture->transport.ltp_client
                                              : &fixture->transport.ltp_server;
    const unsigned flags = server ? LSENG_SERVER : 0;
    endpoint->server = server;
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_bidi = 8;
    settings.es_init_max_streams_uni = 8;
    settings.es_init_max_stream_data_bidi_local = 65536;
    settings.es_init_max_stream_data_bidi_remote = 65536;
    settings.es_init_max_stream_data_uni = 65536;
    settings.es_delay_onclose = 1;
    settings.es_reset_stream_at = 1;
    assert(0 == lsquic_engine_check_settings(&settings, flags, NULL, 0));
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_alpn = "uwz-stop-test";
    config.ltec_tls = lsquic_test_tls_context_new(server, config.ltec_alpn);
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(transport, peer, &config,
                                         server ? 13001 : 13002));
    SSL_CTX_free(config.ltec_tls);
}

static void
start(struct fixture *fixture)
{
    unsigned step;
    memset(fixture, 0, sizeof(*fixture));
    init_endpoint(fixture, 0);
    init_endpoint(fixture, 1);
    assert(lsquic_engine_connect(fixture->transport.ltp_client.lte_engine,
        LSQVER_I001, (void *) &fixture->transport.ltp_client.lte_address,
        (void *) &fixture->transport.ltp_server.lte_address,
        &fixture->transport.ltp_client, NULL, "localhost", 0, NULL, 0, NULL, 0));
    for (step = 0; step < MAX_STEPS; ++step) {
        pump(fixture);
        if (fixture->client.handshake && fixture->server.handshake) break;
    }
    assert(step < MAX_STEPS);
    for (step = 0; step < 20; ++step) pump(fixture);
}

static void
finish(struct fixture *fixture)
{
    lsquic_test_endpoint_destroy(&fixture->transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture->transport.ltp_server);
}

static struct stream_state *
find(struct endpoint *endpoint, uint64_t id)
{
    unsigned index;
    for (index = 0; index < endpoint->stream_count; ++index)
        if (endpoint->streams[index].id == id) return &endpoint->streams[index];
    return NULL;
}

static void
assert_failure(struct lsquic_stream *stream, uint64_t code, int expected)
{
    struct lsquic_stream before = *stream;
    assert(expected == lsquic_stream_stop_sending(stream, code));
    assert(0 == memcmp(&before, stream, sizeof(before)));
}

static void
test_contract(struct lsquic_stream *stream, struct lsquic_stream *local,
              unsigned uni)
{
    struct lsquic_stream copy;
    unsigned flags;
    assert(EXPECT_INVALID == lsquic_stream_stop_sending(NULL, 0));
    assert_failure(stream, UINT64_C(1) << 62, EXPECT_INVALID);
    copy = *stream;
    copy.sm_bflags &= ~SMBF_IETF;
    assert_failure(&copy, 0, EXPECT_UNSUPPORTED);
    copy = *stream;
    copy.sm_bflags |= SMBF_CRYPTO;
    assert_failure(&copy, 0, EXPECT_UNSUPPORTED);
    copy = *stream;
    copy.sm_bflags |= SMBF_CRITICAL;
    assert_failure(&copy, 0, EXPECT_UNSUPPORTED);
    copy = *stream;
    copy.sm_dflags |= SMDF_RESET_KNOWN;
    assert_failure(&copy, 0, EXPECT_CLOSED);
    copy = *stream;
    copy.stream_flags |= STREAM_ONCLOSE_DONE;
    assert_failure(&copy, 0, EXPECT_CLOSED);
    flags = stream->conn_pub->cp_flags;
    stream->conn_pub->cp_flags &= ~CP_LIVE_PEER_TP;
    assert_failure(stream, 0, EXPECT_BLOCKED);
    stream->conn_pub->cp_flags = flags;
    flags = stream->conn_pub->lconn->cn_flags;
    stream->conn_pub->lconn->cn_flags &= ~LSCONN_HANDSHAKE_DONE;
    assert_failure(stream, 0, EXPECT_BLOCKED);
    stream->conn_pub->lconn->cn_flags = flags;
    if (uni) assert_failure(local, 0, EXPECT_UNSUPPORTED);
}

static void
test_wire(unsigned server_sender, unsigned uni, unsigned fin, unsigned generic)
{
    struct fixture fixture;
    struct endpoint *sender, *receiver;
    struct stream_state *local, *remote = NULL;
    uint64_t code = generic ? HEC_NO_ERROR : UINT64_C(0x123456789ABCDEF);
    uint64_t id;
    unsigned step;
    enum stream_flags write_flags;
    const unsigned write_mask = STREAM_U_WRITE_DONE | STREAM_RST_SENT
                             | STREAM_RESET_TX | STREAM_FIN_SENT;

    start(&fixture);
    sender = server_sender ? &fixture.server : &fixture.client;
    receiver = server_sender ? &fixture.client : &fixture.server;
    if (uni) assert(LSQUIC_MUS_OK == lsquic_conn_make_uni_stream(sender->connection));
    else lsquic_conn_make_stream(sender->connection);
    assert(sender->stream_count == 1);
    local = &sender->streams[0];
    id = local->id;
    assert(7 == lsquic_stream_write(local->stream, "payload", 7));
    if (fin) assert(0 == lsquic_stream_shutdown(local->stream, 1));
    else assert(0 == lsquic_stream_flush(local->stream));
    for (step = 0; step < MAX_STEPS; ++step) {
        pump(&fixture);
        remote = find(receiver, id);
        if (remote && (!fin || (remote->stream->stream_flags & STREAM_FIN_RECVD))) break;
    }
    assert(step < MAX_STEPS && remote->stream->read_offset == 0);
    write_flags = remote->stream->stream_flags & write_mask;
    if (lsquic_stream_stop_sending) test_contract(remote->stream, local->stream, uni);
    if (generic || !lsquic_stream_stop_sending) {
        assert(0 == lsquic_stream_shutdown(remote->stream, 0));
        if (lsquic_stream_stop_sending)
            assert_failure(remote->stream, code, EXPECT_CLOSED);
    } else {
        assert(EXPECT_OK == lsquic_stream_stop_sending(remote->stream, code));
        assert(EXPECT_OK == lsquic_stream_stop_sending(remote->stream, code));
        assert(EXPECT_INVALID == lsquic_stream_stop_sending(remote->stream, code + 1));
        assert((remote->stream->stream_flags & write_mask) == write_flags);
        assert(!!(remote->stream->sm_qflags & SMQF_WAIT_FIN_OFF) == !fin);
        if (!uni) {
            assert(5 == lsquic_stream_write(remote->stream, "reply", 5));
            assert(0 == lsquic_stream_flush(remote->stream));
        }
    }
    if (generic && fin) {
        for (step = 0; step < 30; ++step) pump(&fixture);
        assert(!local->resets[1]);
        finish(&fixture);
        return;
    }
    for (step = 0; step < MAX_STEPS && !local->resets[1]; ++step) pump(&fixture);
    assert(step < MAX_STEPS);
    assert(local->errors[1] == code);
    assert(local->resets[1] == 1);
    if (lsquic_stream_stop_sending && remote->stream) {
        lsquic_conn_abort(receiver->connection);
        assert_failure(remote->stream, code, EXPECT_CLOSED);
    }
    finish(&fixture);
}

static void
test_reset_before_send(void)
{
    struct fixture fixture;
    struct stream_state *local, *remote = NULL;
    unsigned step;
    start(&fixture);
    lsquic_conn_make_stream(fixture.client.connection);
    local = &fixture.client.streams[0];
    assert(7 == lsquic_stream_write(local->stream, "payload", 7));
    assert(0 == lsquic_stream_flush(local->stream));
    for (step = 0; step < MAX_STEPS; ++step) {
        pump(&fixture);
        remote = find(&fixture.server, local->id);
        if (remote) break;
    }
    assert(step < MAX_STEPS && lsquic_stream_stop_sending);
    assert(EXPECT_OK == lsquic_stream_stop_sending(remote->stream, 7));
    assert(remote->stream->sm_qflags & SMQF_SEND_STOP_SENDING);
    assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(local->stream, 373, 0));
    /* Receive the actual peer RESET before this endpoint can packetize STOP. */
    lsquic_engine_process_conns(fixture.transport.ltp_client.lte_engine);
    lsquic_test_deliver_all(&fixture.transport.ltp_server);
    assert(remote->stream->sm_dflags & SMDF_RESET_KNOWN);
    assert(EXPECT_CLOSED == lsquic_stream_stop_sending(remote->stream, 7));
    assert(!(remote->stream->sm_qflags & SMQF_SEND_STOP_SENDING));
    for (step = 0; step < 30; ++step) pump(&fixture);
    assert(!local->resets[1]);
    finish(&fixture);
}

int
main(int argc, char **argv)
{
    unsigned server, uni, fin, generic;
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    if (argc == 2 && 0 == strcmp(argv[1], "reset-before-send")) {
        test_reset_before_send();
        lsquic_global_cleanup();
        return 0;
    }
    assert(argc == 5);
    server = (unsigned) (argv[1][0] - '0');
    uni = (unsigned) (argv[2][0] - '0');
    fin = (unsigned) (argv[3][0] - '0');
    generic = (unsigned) (argv[4][0] - '0');
    assert(server <= 1 && uni <= 1 && fin <= 1 && generic <= 1);
    test_wire(server, uni, fin, generic);
    lsquic_global_cleanup();
    return 0;
}
