/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/queue.h>

#include <openssl/ssl.h>

#include "lsquic.h"
#include "uwz_quic_fixture.h"
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_packet_in.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"
#include "lsquic_conn_public.h"
#include "lsquic_parse.h"
#include "lsquic_conn.h"
#include "lsquic_mm.h"
#include "lsquic_engine_public.h"
#include "lsquic_cubic.h"
#include "lsquic_pacer.h"
#include "lsquic_senhist.h"
#include "lsquic_bw_sampler.h"
#include "lsquic_minmax.h"
#include "lsquic_bbr.h"
#include "lsquic_adaptive_cc.h"
#include "lsquic_send_ctl.h"

#ifdef NDEBUG
#error "uwz_webtransport_settings requires active assertions"
#endif
#ifndef LSQUIC_WT_SETTINGS_TEST_OBSERVER
#error "uwz_webtransport_settings requires the test-only HTTP initialization observer"
#endif

enum {
    WT_MAX_STEPS = 20000,
    WT_MAX_STREAMS = 8,
    WT_MAX_WIRE_BYTES = 1024,
    WT_MAX_SETTINGS = 32,
};

enum wt_flow_mode {
    WT_FLOW_OFF,
    WT_FLOW_ON,
    WT_FLOW_MAX,
};

/* draft-ietf-webtrans-http3-16, Sections 3.1, 5.1, and 9.2. */
static const uint64_t wt_enabled_id = UINT64_C(0x2c7cf000);
static const uint64_t wt_data_id = UINT64_C(0x2b61);
static const uint64_t wt_bidi_id = UINT64_C(0x2b65);
static const uint64_t wt_uni_id = UINT64_C(0x2b64);

struct wt_app_stream {
    lsquic_stream_t *was_stream;
    lsquic_stream_id_t was_id;
    unsigned was_closed;
};

/* Every byte is copied from a native retained STREAM record at its real offset. */
struct wt_wire_stream {
    lsquic_stream_id_t wws_id;
    unsigned wws_active;
    size_t wws_high;
    unsigned char wws_bytes[WT_MAX_WIRE_BYTES];
    unsigned char wws_present[WT_MAX_WIRE_BYTES];
};

struct wt_setting {
    uint64_t ws_id;
    uint64_t ws_value;
    unsigned ws_value_width;
};

struct wt_control_view {
    const struct wt_wire_stream *wcv_stream;
    size_t wcv_payload_offset;
    size_t wcv_payload_size;
    unsigned wcv_length_width;
};

struct wt_settings_snapshot {
    size_t wss_count;
    struct wt_setting wss_settings[WT_MAX_SETTINGS];
};

struct wt_endpoint {
    lsquic_conn_t *we_conn;
    struct lsquic_conn_public *we_conn_pub;
    unsigned we_server;
    unsigned we_handshake_ok;
    unsigned we_closed;
    unsigned we_settings_callbacks;
    unsigned we_stream_count;
    struct wt_app_stream we_streams[WT_MAX_STREAMS];
    struct wt_wire_stream we_wire[WT_MAX_STREAMS];
};

struct wt_fixture {
    struct lsquic_test_pair wf_transport;
    struct wt_endpoint wf_client;
    struct wt_endpoint wf_server;
};


void
lsquic_wt_settings_test_conn (struct lsquic_conn *conn,
                             struct lsquic_conn_public *conn_pub)
{
    struct wt_endpoint *endpoint;

    assert(conn_pub && conn_pub->lconn == conn && conn_pub->enpub);
    endpoint = conn_pub->enpub->enp_stream_if_ctx;
    assert(endpoint);
    assert(endpoint->we_server == !!(conn->cn_flags & LSCONN_SERVER));
    if (endpoint->we_conn)
        assert(endpoint->we_conn == conn);
    assert(!endpoint->we_conn_pub || endpoint->we_conn_pub == conn_pub);
    endpoint->we_conn_pub = conn_pub;
}


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct wt_endpoint *endpoint = ctx;

    assert(!endpoint->we_conn);
    if (endpoint->we_conn_pub)
        assert(endpoint->we_conn_pub->lconn == conn);
    endpoint->we_conn = conn;
    if (endpoint->we_server)
        endpoint->we_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct wt_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(status == LSQ_HSK_OK);
    endpoint->we_handshake_ok = 1;
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct wt_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint->we_conn == conn && !endpoint->we_closed);
    endpoint->we_conn = NULL;
    endpoint->we_conn_pub = NULL;
    endpoint->we_closed = 1;
    lsquic_conn_set_ctx(conn, NULL);
}


static void
peer_settings_received (lsquic_conn_t *conn)
{
    struct wt_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint && endpoint->we_conn == conn);
    ++endpoint->we_settings_callbacks;
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct wt_endpoint *endpoint = ctx;
    struct wt_app_stream *state;

    assert(stream && endpoint->we_stream_count < WT_MAX_STREAMS);
    state = &endpoint->we_streams[endpoint->we_stream_count++];
    state->was_stream = stream;
    state->was_id = lsquic_stream_id(stream);
    return (lsquic_stream_ctx_t *) state;
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) ctx;
    assert(lsquic_stream_wantread(stream, 0) >= 0);
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) ctx;
    assert(lsquic_stream_wantwrite(stream, 0) >= 0);
}


static void
close_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct wt_app_stream *state = (void *) ctx;

    assert(state->was_stream == stream && !state->was_closed);
    state->was_stream = NULL;
    state->was_closed = 1;
}


static const struct lsquic_stream_if wt_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_new_stream = new_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_h3_settings = peer_settings_received,
};


static void
init_endpoint (struct wt_fixture *fixture, unsigned server,
               const struct lsquic_webtransport_settings *webtransport)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct wt_endpoint *endpoint;
    struct lsquic_test_endpoint *transport, *peer;
    unsigned flags = LSENG_HTTP | (server ? LSENG_SERVER : 0);

    endpoint = server ? &fixture->wf_server : &fixture->wf_client;
    endpoint->we_server = server;
    transport = server ? &fixture->wf_transport.ltp_server
                       : &fixture->wf_transport.ltp_client;
    peer = server ? &fixture->wf_transport.ltp_client
                  : &fixture->wf_transport.ltp_server;
    lsquic_engine_init_settings(&settings, flags);
    assert(!settings.es_webtransport.enabled);
    assert(!settings.es_webtransport.initial_max_data);
    assert(!settings.es_webtransport.initial_max_streams_bidi);
    assert(!settings.es_webtransport.initial_max_streams_uni);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = WT_MAX_STREAMS;
    settings.es_max_streams_in = WT_MAX_STREAMS;
    settings.es_qpack_dec_max_size = 0;
    settings.es_qpack_dec_max_blocked = 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    settings.es_webtransport = *webtransport;
    if (webtransport->enabled)
    {
        settings.es_datagrams = 1;
        settings.es_reset_stream_at = 1;
    }
    assert(settings.es_check_tp_sanity);
    assert(0 == lsquic_engine_check_settings(&settings, flags, NULL, 0));
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &wt_callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_alpn = "h3";
    config.ltec_tls = lsquic_test_tls_context_new(server, "h3");
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(transport, peer, &config,
                                        server ? 12601 : 12602));
    SSL_CTX_free(config.ltec_tls);
}


static struct wt_wire_stream *
wire_slot (struct wt_endpoint *endpoint, lsquic_stream_id_t id)
{
    struct wt_wire_stream *slot;
    unsigned index;

    for (index = 0; index < WT_MAX_STREAMS; ++index)
    {
        slot = &endpoint->we_wire[index];
        if (slot->wws_active && slot->wws_id == id)
            return slot;
    }
    for (index = 0; index < WT_MAX_STREAMS; ++index)
    {
        slot = &endpoint->we_wire[index];
        if (slot->wws_active)
            continue;
        slot->wws_active = 1;
        slot->wws_id = id;
        return slot;
    }
    assert(0 && "bounded endpoint unidirectional capture exhausted");
    return NULL;
}


static void
capture_frame (struct wt_endpoint *endpoint, const struct parse_funcs *pf,
               const struct lsquic_packet_out *packet,
               const struct frame_rec *record)
{
    struct stream_frame frame;
    struct wt_wire_stream *slot;
    size_t offset, index;

    if (record->fe_frame_type != QUIC_FRAME_STREAM)
        return;
    assert((size_t) record->fe_off + record->fe_len <= packet->po_data_sz);
    assert(record->fe_len == pf->pf_parse_stream_frame(
                packet->po_data + record->fe_off, record->fe_len, &frame));
    if ((frame.stream_id & 3) != 2 + endpoint->we_server)
        return;
    assert(frame.stream_id == record->fe_stream->id);
    assert(frame.data_frame.df_offset <= WT_MAX_WIRE_BYTES);
    offset = (size_t) frame.data_frame.df_offset;
    assert(frame.data_frame.df_size <= WT_MAX_WIRE_BYTES - offset);
    slot = wire_slot(endpoint, frame.stream_id);
    for (index = 0; index < frame.data_frame.df_size; ++index)
    {
        if (slot->wws_present[offset + index])
            assert(slot->wws_bytes[offset + index] == frame.data_frame.df_data[index]);
        slot->wws_bytes[offset + index] = frame.data_frame.df_data[index];
        slot->wws_present[offset + index] = 1;
    }
    if (offset + frame.data_frame.df_size > slot->wws_high)
        slot->wws_high = offset + frame.data_frame.df_size;
}


static void
capture_endpoint_wire (struct wt_endpoint *endpoint)
{
    struct lsquic_conn_public *conn_pub = endpoint->we_conn_pub;
    struct lsquic_send_ctl *ctl;
    struct lsquic_packet_out *packet;
    struct packet_out_frec_iter iterator;
    const struct frame_rec *record;
    unsigned index;

    if (!conn_pub)
        return;
    ctl = conn_pub->send_ctl;
    const struct lsquic_packets_tailq queues[] = {
        ctl->sc_scheduled_packets,
        ctl->sc_unacked_packets[PNS_INIT],
        ctl->sc_unacked_packets[PNS_HSK],
        ctl->sc_unacked_packets[PNS_APP],
        ctl->sc_lost_packets,
        ctl->sc_buffered_packets[0].bpq_packets,
        ctl->sc_buffered_packets[1].bpq_packets,
        ctl->sc_0rtt_stash,
    };

    for (index = 0; index < sizeof(queues) / sizeof(queues[0]); ++index)
    {
        TAILQ_FOREACH(packet, &queues[index], po_next)
        {
            if (packet->po_flags & (PO_LOSS_REC | PO_POISON))
                continue;
            for (record = lsquic_pofi_first(&iterator, packet); record;
                                    record = lsquic_pofi_next(&iterator))
                capture_frame(endpoint, conn_pub->lconn->cn_pf, packet, record);
        }
    }
}


static void
pump_step (struct wt_fixture *fixture)
{
    lsquic_test_pair_process(&fixture->wf_transport, 1000);
    /* Observe each output before delivering a packet that can ACK it. */
    capture_endpoint_wire(&fixture->wf_client);
    capture_endpoint_wire(&fixture->wf_server);
    lsquic_test_deliver_all(&fixture->wf_transport.ltp_server);
    capture_endpoint_wire(&fixture->wf_server);
    lsquic_test_deliver_all(&fixture->wf_transport.ltp_client);
    capture_endpoint_wire(&fixture->wf_client);
}


static int
control_settings_bounds (const struct wt_wire_stream *stream,
                         struct wt_control_view *view)
{
    const unsigned char *cursor, *end;
    uint64_t type, length;
    size_t contiguous;
    int consumed;

    contiguous = 0;
    while (contiguous < stream->wws_high && stream->wws_present[contiguous])
        ++contiguous;
    cursor = stream->wws_bytes;
    end = cursor + contiguous;
    consumed = lsquic_varint_read(cursor, end, &type);
    if (consumed <= 0)
        return 0;
    if (type != 0)
        return 0;
    cursor += consumed;
    consumed = lsquic_varint_read(cursor, end, &type);
    if (consumed <= 0)
        return 0;
    assert(type == 4);
    cursor += consumed;
    consumed = lsquic_varint_read(cursor, end, &length);
    if (consumed <= 0)
        return 0;
    cursor += consumed;
    assert(length <= WT_MAX_WIRE_BYTES);
    if (length > (uint64_t) (end - cursor))
        return 0;
    view->wcv_stream = stream;
    view->wcv_payload_offset = (size_t) (cursor - stream->wws_bytes);
    view->wcv_payload_size = (size_t) length;
    view->wcv_length_width = (unsigned) consumed;
    return 1;
}


static unsigned
find_complete_settings (const struct wt_endpoint *endpoint,
                        struct wt_control_view *view)
{
    struct wt_control_view candidate;
    unsigned found = 0, index;

    for (index = 0; index < WT_MAX_STREAMS; ++index)
    {
        if (!endpoint->we_wire[index].wws_active)
            continue;
        if (!control_settings_bounds(&endpoint->we_wire[index], &candidate))
            continue;
        assert(!found && "endpoint emitted more than one HTTP control stream");
        *view = candidate;
        found = 1;
    }
    return found;
}


static void
parse_settings (const struct wt_wire_stream *control, size_t payload_offset,
                size_t payload_size, struct wt_settings_snapshot *snapshot)
{
    const unsigned char *cursor = control->wws_bytes + payload_offset;
    const unsigned char *end = cursor + payload_size;
    struct wt_setting *setting;
    size_t index;
    int consumed;

    memset(snapshot, 0, sizeof(*snapshot));
    while (cursor < end)
    {
        assert(snapshot->wss_count < WT_MAX_SETTINGS);
        setting = &snapshot->wss_settings[snapshot->wss_count];
        consumed = lsquic_varint_read(cursor, end, &setting->ws_id);
        assert(consumed > 0);
        cursor += consumed;
        consumed = lsquic_varint_read(cursor, end, &setting->ws_value);
        assert(consumed > 0);
        setting->ws_value_width = (unsigned) consumed;
        cursor += consumed;
        for (index = 0; index < snapshot->wss_count; ++index)
            assert(snapshot->wss_settings[index].ws_id != setting->ws_id);
        ++snapshot->wss_count;
    }
    assert(cursor == end);
}


static unsigned
setting_count (const struct wt_settings_snapshot *snapshot, uint64_t id,
               uint64_t *value)
{
    size_t index;
    unsigned count = 0;

    for (index = 0; index < snapshot->wss_count; ++index)
    {
        if (snapshot->wss_settings[index].ws_id != id)
            continue;
        *value = snapshot->wss_settings[index].ws_value;
        ++count;
    }
    return count;
}


static void
assert_setting (const struct wt_settings_snapshot *snapshot, uint64_t id,
                uint64_t expected)
{
    uint64_t value = UINT64_MAX;

    assert(setting_count(snapshot, id, &value) == 1);
    assert(value == expected);
}


static void
assert_no_setting (const struct wt_settings_snapshot *snapshot, uint64_t id)
{
    uint64_t value = UINT64_MAX;

    assert(setting_count(snapshot, id, &value) == 0);
    assert(value == UINT64_MAX);
}


static void
assert_flow_setting (const struct wt_settings_snapshot *snapshot, uint64_t id,
                     uint64_t expected)
{
    uint64_t value = UINT64_MAX;
    unsigned count = setting_count(snapshot, id, &value);

    if (expected)
    {
        assert(count == 1 && value == expected);
        return;
    }
    assert(count == 0 || (count == 1 && value == 0));
}


static void
assert_setting_width (const struct wt_settings_snapshot *snapshot, uint64_t id,
                      unsigned width)
{
    size_t index;

    for (index = 0; index < snapshot->wss_count; ++index)
    {
        if (snapshot->wss_settings[index].ws_id != id)
            continue;
        assert(snapshot->wss_settings[index].ws_value_width == width);
        return;
    }
    assert(0 && "required setting missing from encoding-width check");
}


static const char *
flow_name (enum wt_flow_mode flow)
{
    switch (flow)
    {
    case WT_FLOW_OFF:
        return "off";
    case WT_FLOW_ON:
        return "on";
    case WT_FLOW_MAX:
        return "maximum";
    }
    assert(0 && "unknown flow mode");
    return NULL;
}


static void
assert_peer_settings (const struct wt_endpoint *endpoint,
                      const struct wt_control_view *view,
                      const struct lsquic_webtransport_settings *webtransport,
                      enum wt_flow_mode flow)
{
    struct wt_settings_snapshot snapshot;

    parse_settings(view->wcv_stream, view->wcv_payload_offset,
                   view->wcv_payload_size, &snapshot);
    assert_no_setting(&snapshot, UINT64_C(0x2b603742));
    assert_no_setting(&snapshot, UINT64_C(0x2b603743));
    if (webtransport->enabled)
    {
        assert_setting(&snapshot, wt_enabled_id, 1);
        assert_setting(&snapshot, UINT64_C(0x33), 1);
        if (endpoint->we_server)
            assert_setting(&snapshot, UINT64_C(0x08), 1);
        else
            assert_no_setting(&snapshot, UINT64_C(0x08));
        assert_flow_setting(&snapshot, wt_data_id, webtransport->initial_max_data);
        assert_flow_setting(&snapshot, wt_bidi_id, webtransport->initial_max_streams_bidi);
        assert_flow_setting(&snapshot, wt_uni_id, webtransport->initial_max_streams_uni);
        assert(view->wcv_length_width == 2);
    }
    else
    {
        assert_no_setting(&snapshot, wt_enabled_id);
        assert_no_setting(&snapshot, wt_data_id);
        assert_no_setting(&snapshot, wt_bidi_id);
        assert_no_setting(&snapshot, wt_uni_id);
        assert(view->wcv_length_width == 1 || view->wcv_length_width == 2);
    }
    if (flow == WT_FLOW_MAX)
    {
        assert_setting_width(&snapshot, wt_data_id, 8);
        assert_setting_width(&snapshot, wt_bidi_id, 8);
        assert_setting_width(&snapshot, wt_uni_id, 8);
    }
    printf("PASS real TLS/HTTP %s control SETTINGS: %s, flow %s, length-varint width %u, payload %zu bytes, %zu unique settings\n",
           endpoint->we_server ? "server" : "client",
           webtransport->enabled ? "draft16 enabled" : "default disabled",
           flow_name(flow), view->wcv_length_width, view->wcv_payload_size,
           snapshot.wss_count);
}


static void
test_settings (unsigned enabled, enum wt_flow_mode flow)
{
    struct wt_fixture fixture;
    struct lsquic_webtransport_settings webtransport = { 0 };
    struct wt_control_view client_view = { 0 }, server_view = { 0 };
    unsigned step, client_complete, server_complete;

    memset(&fixture, 0, sizeof(fixture));
    webtransport.enabled = enabled;
    switch (flow)
    {
    case WT_FLOW_OFF:
        break;
    case WT_FLOW_ON:
        assert(enabled);
        webtransport.initial_max_data = 65537;
        webtransport.initial_max_streams_bidi = 17;
        webtransport.initial_max_streams_uni = 19;
        break;
    case WT_FLOW_MAX:
        assert(enabled);
        webtransport.initial_max_data = (UINT64_C(1) << 62) - 1;
        webtransport.initial_max_streams_bidi = UINT64_C(1) << 60;
        webtransport.initial_max_streams_uni = UINT64_C(1) << 60;
        break;
    }
    init_endpoint(&fixture, 0, &webtransport);
    init_endpoint(&fixture, 1, &webtransport);
    assert(lsquic_engine_connect(fixture.wf_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture.wf_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture.wf_transport.ltp_server.lte_address,
                &fixture.wf_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
    for (step = 0; step < WT_MAX_STEPS; ++step)
    {
        pump_step(&fixture);
        client_complete = find_complete_settings(&fixture.wf_client, &client_view);
        server_complete = find_complete_settings(&fixture.wf_server, &server_view);
        if (client_complete && server_complete
                    && fixture.wf_client.we_handshake_ok
                    && fixture.wf_server.we_handshake_ok)
            break;
    }
    assert(step < WT_MAX_STEPS && client_view.wcv_stream && server_view.wcv_stream);
    assert(fixture.wf_client.we_conn && fixture.wf_server.we_conn);
    assert(fixture.wf_transport.ltp_client.lte_packets_received);
    assert(fixture.wf_transport.ltp_server.lte_packets_received);
    assert_peer_settings(&fixture.wf_client, &client_view, &webtransport, flow);
    assert_peer_settings(&fixture.wf_server, &server_view, &webtransport, flow);
    lsquic_test_endpoint_destroy(&fixture.wf_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture.wf_transport.ltp_server);
}


int
main (int argc, char **argv)
{
    unsigned disabled, flow_off, flow_on, flow_max;

    assert(argc <= 2);
    disabled = argc == 1 || 0 == strcmp(argv[1], "all")
                        || 0 == strcmp(argv[1], "disabled");
    flow_off = argc == 1 || 0 == strcmp(argv[1], "all")
                        || 0 == strcmp(argv[1], "flow-off");
    flow_on = argc == 1 || 0 == strcmp(argv[1], "all")
                       || 0 == strcmp(argv[1], "flow-on");
    flow_max = argc == 1 || 0 == strcmp(argv[1], "all")
                        || 0 == strcmp(argv[1], "flow-max");
    assert(disabled || flow_off || flow_on || flow_max);
    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    if (disabled)
        test_settings(0, WT_FLOW_OFF);
    if (flow_off)
        test_settings(1, WT_FLOW_OFF);
    if (flow_on)
        test_settings(1, WT_FLOW_ON);
    if (flow_max)
        test_settings(1, WT_FLOW_MAX);
    lsquic_global_cleanup();
    return 0;
}
