/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <openssl/ssl.h>

#include "lsquic.h"
#include "uwz_quic_fixture.h"

#ifdef NDEBUG
#error "uwz_webtransport_peer requires active assertions"
#endif

enum {
    PEER_MAX_STEPS = 20000,
    PEER_CANARY = 0xA5,
};

enum peer_mode {
    PEER_HTTP,
    PEER_RAW,
};

struct peer_probe {
    unsigned char pp_before[8];
    struct lsquic_webtransport_peer pp_value;
    unsigned char pp_after[8];
};

struct peer_case {
    const char *pc_name;
    struct lsquic_webtransport_settings pc_client;
    struct lsquic_webtransport_settings pc_server;
    unsigned pc_notify;
};

struct peer_endpoint {
    lsquic_conn_t *pe_conn;
    unsigned pe_server;
    enum peer_mode pe_mode;
    unsigned pe_close_on_notification;
    unsigned pe_close_requested;
    unsigned pe_observed_ready;
    unsigned pe_early_unsupported;
    unsigned pe_new_connections;
    unsigned pe_handshake_ok;
    unsigned pe_early_pending;
    unsigned pe_notifications;
    unsigned pe_notification_context_ok;
    unsigned pe_closed;
    int pe_notification_result;
    int pe_close_result;
    struct lsquic_webtransport_peer pe_notification_peer;
    struct lsquic_webtransport_peer pe_close_peer;
    struct lsquic_webtransport_peer pe_observed_peer;
};

struct peer_fixture {
    struct lsquic_test_pair pf_transport;
    struct peer_endpoint pf_client;
    struct peer_endpoint pf_server;
};

static const struct peer_case peer_cases[] = {
    {
        .pc_name = "disabled", .pc_notify = 1,
    },
    {
        .pc_name = "flow-off", .pc_notify = 1,
        .pc_client = { .enabled = 1 },
        .pc_server = { .enabled = 1 },
    },
    {
        .pc_name = "flow-on", .pc_notify = 1,
        .pc_client = { .enabled = 1, .initial_max_data = 65537,
            .initial_max_streams_bidi = 17, .initial_max_streams_uni = 19 },
        .pc_server = { .enabled = 1, .initial_max_data = 65537,
            .initial_max_streams_bidi = 17, .initial_max_streams_uni = 19 },
    },
    {
        .pc_name = "flow-max", .pc_notify = 1,
        .pc_client = { .enabled = 1,
            .initial_max_data = (UINT64_C(1) << 62) - 1,
            .initial_max_streams_bidi = UINT64_C(1) << 60,
            .initial_max_streams_uni = UINT64_C(1) << 60 },
        .pc_server = { .enabled = 1,
            .initial_max_data = (UINT64_C(1) << 62) - 1,
            .initial_max_streams_bidi = UINT64_C(1) << 60,
            .initial_max_streams_uni = UINT64_C(1) << 60 },
    },
    {
        .pc_name = "client-only", .pc_notify = 1,
        .pc_client = { .enabled = 1, .initial_max_data = 65537,
            .initial_max_streams_bidi = 17, .initial_max_streams_uni = 19 },
    },
    {
        .pc_name = "server-only", .pc_notify = 1,
        .pc_server = { .enabled = 1, .initial_max_data = 900001,
            .initial_max_streams_bidi = 31, .initial_max_streams_uni = 23 },
    },
    {
        .pc_name = "asymmetric", .pc_notify = 1,
        .pc_client = { .enabled = 1, .initial_max_data = 65537,
            .initial_max_streams_bidi = 17, .initial_max_streams_uni = 19 },
        .pc_server = { .enabled = 1, .initial_max_data = 900001,
            .initial_max_streams_bidi = 31, .initial_max_streams_uni = 23 },
    },
    {
        .pc_name = "no-callback",
        .pc_client = { .enabled = 1, .initial_max_data = 65537,
            .initial_max_streams_bidi = 17, .initial_max_streams_uni = 19 },
        .pc_server = { .enabled = 1, .initial_max_data = 900001,
            .initial_max_streams_bidi = 31, .initial_max_streams_uni = 23 },
    },
};


static void
assert_canary (const void *bytes, size_t size)
{
    const unsigned char *cursor = bytes;
    size_t index;

    for (index = 0; index < size; ++index)
        assert(cursor[index] == PEER_CANARY);
}


static int
query_peer (const lsquic_conn_t *conn, struct lsquic_webtransport_peer *out)
{
    struct peer_probe probe;
    unsigned char original[sizeof(probe)];
    int result;

    memset(&probe, PEER_CANARY, sizeof(probe));
    memcpy(original, &probe, sizeof(probe));
    result = lsquic_conn_get_webtransport_peer(conn, &probe.pp_value);
    assert_canary(probe.pp_before, sizeof(probe.pp_before));
    assert_canary(probe.pp_after, sizeof(probe.pp_after));
    if (result == LSQUIC_WTP_OK)
        *out = probe.pp_value;
    else
        assert(0 == memcmp(original, &probe, sizeof(probe)));
    return result;
}


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct peer_endpoint *endpoint = ctx;
    struct lsquic_webtransport_peer peer;

    assert(!endpoint->pe_conn && !endpoint->pe_new_connections);
    endpoint->pe_conn = conn;
    endpoint->pe_new_connections = 1;
    assert(LSQUIC_WTP_INVALID == lsquic_conn_get_webtransport_peer(conn, NULL));
    if (endpoint->pe_server)
        endpoint->pe_handshake_ok = 1;
    if (endpoint->pe_mode == PEER_RAW)
    {
        assert(LSQUIC_WTP_UNSUPPORTED == query_peer(conn, &peer));
        endpoint->pe_early_unsupported = 1;
        return (lsquic_conn_ctx_t *) endpoint;
    }
    if (!endpoint->pe_server)
    {
        assert(LSQUIC_WTP_PENDING == query_peer(conn, &peer));
        endpoint->pe_early_pending = 1;
        assert(endpoint->pe_notifications == 0);
    }
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct peer_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(status == LSQ_HSK_OK);
    endpoint->pe_handshake_ok = 1;
}


static void
settings_received (lsquic_conn_t *conn)
{
    struct peer_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint);
    ++endpoint->pe_notifications;
    endpoint->pe_notification_context_ok = endpoint->pe_new_connections == 1
                                        && endpoint->pe_conn == conn;
    endpoint->pe_notification_result = query_peer(conn,
                                                &endpoint->pe_notification_peer);
    if (endpoint->pe_notification_result == LSQUIC_WTP_OK)
    {
        endpoint->pe_observed_ready = 1;
        endpoint->pe_observed_peer = endpoint->pe_notification_peer;
    }
    if (!endpoint->pe_close_on_notification || endpoint->pe_close_requested)
        return;
    endpoint->pe_close_requested = 1;
    lsquic_conn_close(conn);
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct peer_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint && endpoint->pe_conn == conn && !endpoint->pe_closed);
    endpoint->pe_close_result = query_peer(conn, &endpoint->pe_close_peer);
    endpoint->pe_closed = 1;
    endpoint->pe_conn = NULL;
    lsquic_conn_set_ctx(conn, NULL);
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    (void) ctx;
    (void) stream;
    assert(0 && "peer SETTINGS cases create no application streams");
    return NULL;
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) stream;
    (void) ctx;
    assert(0 && "peer SETTINGS cases have no application reads");
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) stream;
    (void) ctx;
    assert(0 && "peer SETTINGS cases have no application writes");
}


static void
close_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) stream;
    (void) ctx;
    assert(0 && "peer SETTINGS cases have no application stream lifetime");
}


static const struct lsquic_stream_if peer_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_new_stream = new_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_h3_settings = settings_received,
};

static const struct lsquic_stream_if peer_no_notification_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_new_stream = new_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
};


static void
pump_step (struct peer_fixture *fixture)
{
    lsquic_test_pair_process(&fixture->pf_transport, 1000);
    lsquic_test_deliver_all(&fixture->pf_transport.ltp_client);
    lsquic_test_deliver_all(&fixture->pf_transport.ltp_server);
}


static void
init_endpoint (struct peer_fixture *fixture, unsigned server,
               const struct lsquic_webtransport_settings *webtransport,
               unsigned notify, enum peer_mode mode)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct peer_endpoint *endpoint;
    struct lsquic_test_endpoint *transport, *other;
    unsigned flags = (mode == PEER_HTTP ? LSENG_HTTP : 0)
                   | (server ? LSENG_SERVER : 0);
    const char *alpn = mode == PEER_HTTP ? "h3" : "uwz-peer-raw/1";

    endpoint = server ? &fixture->pf_server : &fixture->pf_client;
    endpoint->pe_server = server;
    endpoint->pe_mode = mode;
    transport = server ? &fixture->pf_transport.ltp_server
                       : &fixture->pf_transport.ltp_client;
    other = server ? &fixture->pf_transport.ltp_client
                   : &fixture->pf_transport.ltp_server;
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = 8;
    settings.es_max_streams_in = 8;
    settings.es_qpack_dec_max_size = 0;
    settings.es_qpack_dec_max_blocked = 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    settings.es_webtransport = *webtransport;
    if (webtransport->enabled)
    {
        settings.es_datagrams = 1;
        settings.es_reset_stream_at = 1;
    }
    assert(0 == lsquic_engine_check_settings(&settings, flags, NULL, 0));
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = notify ? &peer_callbacks : &peer_no_notification_callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_alpn = alpn;
    config.ltec_tls = lsquic_test_tls_context_new(server, alpn);
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(transport, other, &config,
                                        server ? 12701 : 12702));
    SSL_CTX_free(config.ltec_tls);
}


static void
assert_peer_matches (const struct lsquic_webtransport_peer *peer,
                     const struct lsquic_webtransport_settings *expected,
                     unsigned peer_server)
{
    unsigned flags = LSQUIC_WTP_WT_ENABLED | LSQUIC_WTP_H3_DATAGRAM
                  | LSQUIC_WTP_QUIC_DATAGRAM | LSQUIC_WTP_RELIABLE_RESET;

    if (peer_server)
        flags |= LSQUIC_WTP_CONNECT;
    assert(peer->flags == (expected->enabled ? flags : 0));
    assert(peer->initial_max_data == expected->initial_max_data);
    assert(peer->initial_max_streams_bidi == expected->initial_max_streams_bidi);
    assert(peer->initial_max_streams_uni == expected->initial_max_streams_uni);
}


static void
assert_completed (struct peer_endpoint *endpoint,
                  const struct lsquic_webtransport_settings *expected,
                  unsigned notify)
{
    struct lsquic_webtransport_peer peer;

    assert(endpoint->pe_conn && endpoint->pe_new_connections == 1);
    /* First parser/runtime RED follows independently completed TLS setup. */
    assert(LSQUIC_WTP_OK == query_peer(endpoint->pe_conn, &peer));
    assert_peer_matches(&peer, expected, !endpoint->pe_server);
    assert(endpoint->pe_notifications == notify);
    if (notify)
    {
        assert(endpoint->pe_notification_context_ok);
        assert(endpoint->pe_notification_result == LSQUIC_WTP_OK);
        assert_peer_matches(&endpoint->pe_notification_peer, expected,
                            !endpoint->pe_server);
    }
}


static void
test_peer_case (const struct peer_case *test)
{
    struct peer_fixture fixture;
    unsigned step;

    memset(&fixture, 0, sizeof(fixture));
    init_endpoint(&fixture, 0, &test->pc_client, test->pc_notify, PEER_HTTP);
    init_endpoint(&fixture, 1, &test->pc_server, test->pc_notify, PEER_HTTP);
    assert(lsquic_engine_connect(fixture.pf_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture.pf_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture.pf_transport.ltp_server.lte_address,
                &fixture.pf_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
    for (step = 0; step < PEER_MAX_STEPS; ++step)
    {
        if (fixture.pf_client.pe_handshake_ok && fixture.pf_server.pe_handshake_ok)
            break;
        pump_step(&fixture);
    }
    assert(step < PEER_MAX_STEPS);
    assert(fixture.pf_client.pe_early_pending == 1);
    assert(fixture.pf_transport.ltp_client.lte_packets_received);
    assert(fixture.pf_transport.ltp_server.lte_packets_received);
    for (step = 0; step < 200; ++step)
        pump_step(&fixture);
    assert_completed(&fixture.pf_client, &test->pc_server, test->pc_notify);
    assert_completed(&fixture.pf_server, &test->pc_client, test->pc_notify);
    lsquic_conn_close(fixture.pf_client.pe_conn);
    for (step = 0; step < PEER_MAX_STEPS; ++step)
    {
        if (fixture.pf_client.pe_closed && fixture.pf_server.pe_closed)
            break;
        pump_step(&fixture);
    }
    assert(step < PEER_MAX_STEPS);
    assert(fixture.pf_client.pe_close_result == LSQUIC_WTP_OK);
    assert(fixture.pf_server.pe_close_result == LSQUIC_WTP_OK);
    assert_peer_matches(&fixture.pf_client.pe_close_peer, &test->pc_server, 1);
    assert_peer_matches(&fixture.pf_server.pe_close_peer, &test->pc_client, 0);
    assert(fixture.pf_client.pe_notifications == test->pc_notify);
    assert(fixture.pf_server.pe_notifications == test->pc_notify);
    lsquic_test_endpoint_destroy(&fixture.pf_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture.pf_transport.ltp_server);
    printf("PASS public WebTransport peer state: %s, both roles/early PENDING/exact peer flags and limits/notification count%u/close snapshot\n",
           test->pc_name, test->pc_notify);
}


static void
start_connection (struct peer_fixture *fixture)
{
    assert(lsquic_engine_connect(fixture->pf_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture->pf_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture->pf_transport.ltp_server.lte_address,
                &fixture->pf_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
}


static void
observe_ready (struct peer_endpoint *endpoint)
{
    struct lsquic_webtransport_peer peer;
    int result;

    if (!endpoint->pe_conn)
        return;
    result = query_peer(endpoint->pe_conn, &peer);
    assert(result == LSQUIC_WTP_OK || result == LSQUIC_WTP_PENDING);
    if (result == LSQUIC_WTP_PENDING)
    {
        assert(!endpoint->pe_observed_ready);
        return;
    }
    endpoint->pe_observed_ready = 1;
    endpoint->pe_observed_peer = peer;
}


static void
assert_close_snapshot (const struct peer_endpoint *endpoint,
                       const struct lsquic_webtransport_settings *expected)
{
    assert(endpoint->pe_closed && endpoint->pe_notifications <= 1);
    if (endpoint->pe_close_result == LSQUIC_WTP_PENDING)
    {
        assert(!endpoint->pe_observed_ready && !endpoint->pe_notifications);
        return;
    }
    assert(endpoint->pe_close_result == LSQUIC_WTP_OK);
    assert_peer_matches(&endpoint->pe_close_peer, expected, !endpoint->pe_server);
    if (endpoint->pe_observed_ready)
        assert_peer_matches(&endpoint->pe_observed_peer, expected, !endpoint->pe_server);
    if (!endpoint->pe_notifications)
        return;
    assert(endpoint->pe_notification_context_ok);
    assert(endpoint->pe_notification_result == LSQUIC_WTP_OK);
    assert_peer_matches(&endpoint->pe_notification_peer, expected, !endpoint->pe_server);
}


static void
test_raw_peer (void)
{
    struct peer_fixture fixture;
    struct lsquic_webtransport_settings disabled = { 0 };
    struct lsquic_webtransport_peer peer;
    unsigned step;

    memset(&fixture, 0, sizeof(fixture));
    init_endpoint(&fixture, 0, &disabled, 1, PEER_RAW);
    init_endpoint(&fixture, 1, &disabled, 1, PEER_RAW);
    start_connection(&fixture);
    for (step = 0; step < PEER_MAX_STEPS; ++step)
    {
        if (fixture.pf_client.pe_handshake_ok && fixture.pf_server.pe_handshake_ok)
            break;
        pump_step(&fixture);
    }
    assert(step < PEER_MAX_STEPS);
    for (step = 0; step < 200; ++step)
        pump_step(&fixture);
    assert(fixture.pf_client.pe_early_unsupported && fixture.pf_server.pe_early_unsupported);
    assert(fixture.pf_client.pe_conn && fixture.pf_server.pe_conn);
    assert(LSQUIC_WTP_UNSUPPORTED == query_peer(fixture.pf_client.pe_conn, &peer));
    assert(LSQUIC_WTP_UNSUPPORTED == query_peer(fixture.pf_server.pe_conn, &peer));
    assert(!fixture.pf_client.pe_notifications && !fixture.pf_server.pe_notifications);
    lsquic_conn_close(fixture.pf_client.pe_conn);
    for (step = 0; step < PEER_MAX_STEPS; ++step)
    {
        if (fixture.pf_client.pe_closed && fixture.pf_server.pe_closed)
            break;
        pump_step(&fixture);
    }
    assert(step < PEER_MAX_STEPS);
    assert(fixture.pf_client.pe_close_result == LSQUIC_WTP_UNSUPPORTED);
    assert(fixture.pf_server.pe_close_result == LSQUIC_WTP_UNSUPPORTED);
    assert(!fixture.pf_client.pe_notifications && !fixture.pf_server.pe_notifications);
    lsquic_test_endpoint_destroy(&fixture.pf_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture.pf_transport.ltp_server);
    puts("PASS public WebTransport peer state: raw IETF QUIC/both roles/early+final+close UNSUPPORTED/unchanged canaries/no SETTINGS notification");
}


static void
test_close_on_notify (unsigned server_closer)
{
    struct peer_fixture fixture;
    struct lsquic_webtransport_settings client = {
        .enabled = 1, .initial_max_data = 65537,
        .initial_max_streams_bidi = 17, .initial_max_streams_uni = 19,
    };
    struct lsquic_webtransport_settings server = {
        .enabled = 1, .initial_max_data = 900001,
        .initial_max_streams_bidi = 31, .initial_max_streams_uni = 23,
    };
    struct peer_endpoint *closer;
    unsigned step;

    memset(&fixture, 0, sizeof(fixture));
    init_endpoint(&fixture, 0, &client, 1, PEER_HTTP);
    init_endpoint(&fixture, 1, &server, 1, PEER_HTTP);
    closer = server_closer ? &fixture.pf_server : &fixture.pf_client;
    closer->pe_close_on_notification = 1;
    start_connection(&fixture);
    for (step = 0; step < PEER_MAX_STEPS; ++step)
    {
        if (fixture.pf_client.pe_closed && fixture.pf_server.pe_closed)
            break;
        observe_ready(&fixture.pf_client);
        observe_ready(&fixture.pf_server);
        pump_step(&fixture);
    }
    if (step == PEER_MAX_STEPS)
        printf("close-on-notify timeout: closer=%s client closed=%u notifications=%u ready=%u close-status=%d; server closed=%u notifications=%u ready=%u close-status=%d\n",
               server_closer ? "server" : "client",
               fixture.pf_client.pe_closed, fixture.pf_client.pe_notifications,
               fixture.pf_client.pe_observed_ready, fixture.pf_client.pe_close_result,
               fixture.pf_server.pe_closed, fixture.pf_server.pe_notifications,
               fixture.pf_server.pe_observed_ready, fixture.pf_server.pe_close_result);
    assert(step < PEER_MAX_STEPS);
    assert(fixture.pf_client.pe_new_connections == 1);
    assert(fixture.pf_server.pe_new_connections == 1);
    assert(fixture.pf_client.pe_early_pending);
    assert(closer->pe_close_requested && closer->pe_notifications == 1);
    assert(closer->pe_notification_result == LSQUIC_WTP_OK);
    assert(closer->pe_observed_ready && closer->pe_close_result == LSQUIC_WTP_OK);
    assert_close_snapshot(&fixture.pf_client, &server);
    assert_close_snapshot(&fixture.pf_server, &client);
    lsquic_test_endpoint_destroy(&fixture.pf_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture.pf_transport.ltp_server);
    printf("PASS public WebTransport peer state: %s closes inside READY SETTINGS notification/one callback/per-peer READY or PENDING close state/client=%d server=%d\n",
           server_closer ? "server" : "client",
           fixture.pf_client.pe_close_result, fixture.pf_server.pe_close_result);
}


int
main (int argc, char **argv)
{
    struct lsquic_webtransport_peer ignored;
    size_t index;
    unsigned selected = 0;

    assert(argc <= 2);
    assert(LSQUIC_WTP_OK == 0 && LSQUIC_WTP_PENDING == 1);
    assert(LSQUIC_WTP_INVALID == -1 && LSQUIC_WTP_UNSUPPORTED == -2);
    assert(LSQUIC_WTP_WT_ENABLED == 1 && LSQUIC_WTP_CONNECT == 2);
    assert(LSQUIC_WTP_H3_DATAGRAM == 4 && LSQUIC_WTP_QUIC_DATAGRAM == 8);
    assert(LSQUIC_WTP_RELIABLE_RESET == 16);
    assert(LSQUIC_WTP_INVALID == query_peer(NULL, &ignored));
    assert(LSQUIC_WTP_INVALID == lsquic_conn_get_webtransport_peer(NULL, NULL));
    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    for (index = 0; index < sizeof(peer_cases) / sizeof(peer_cases[0]); ++index)
    {
        if (argc == 2 && 0 != strcmp(argv[1], "all")
                      && 0 != strcmp(argv[1], peer_cases[index].pc_name))
            continue;
        ++selected;
        test_peer_case(&peer_cases[index]);
    }
    if (argc == 1 || 0 == strcmp(argv[1], "all") || 0 == strcmp(argv[1], "raw"))
    {
        ++selected;
        test_raw_peer();
    }
    if (argc == 1 || 0 == strcmp(argv[1], "all")
                  || 0 == strcmp(argv[1], "close-on-notify"))
    {
        ++selected;
        test_close_on_notify(0);
        test_close_on_notify(1);
    }
    assert(selected > 0);
    lsquic_global_cleanup();
    return 0;
}
