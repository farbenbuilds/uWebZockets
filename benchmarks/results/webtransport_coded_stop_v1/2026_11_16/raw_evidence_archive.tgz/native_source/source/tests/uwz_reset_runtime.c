/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/queue.h>

#include <openssl/ssl.h>

#include "lsquic.h"
#include "uwz_quic_fixture.h"
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_packet_in.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"

#ifdef NDEBUG
#error "uwz_reset_runtime requires active assertions"
#endif

enum {
    RUNTIME_MAX_STREAMS = 8,
    RUNTIME_MAX_STEPS = 20000,
    RUNTIME_CREDIT = 4096,
    RUNTIME_MAX_BYTES = 8192,
};

struct runtime_stream {
    lsquic_stream_t *rs_stream;
    lsquic_stream_id_t rs_id;
    size_t rs_received;
    unsigned rs_outgoing;
    unsigned rs_expect_reset;
    unsigned rs_fin;
    unsigned rs_closed;
    unsigned rs_closed_api_checked;
    unsigned rs_reset_events[2];
    int rs_read_error;
    uint64_t rs_errors[2];
    struct lsquic_stream_recv_state rs_close_metadata;
    unsigned char rs_bytes[RUNTIME_MAX_BYTES];
};

struct runtime_endpoint {
    struct lsquic_test_endpoint *re_transport;
    lsquic_conn_t *re_conn;
    lsquic_stream_id_t re_reset_id;
    unsigned re_server;
    unsigned re_receive_enabled;
    unsigned re_handshake_ok;
    unsigned re_stream_count;
    struct runtime_stream re_streams[RUNTIME_MAX_STREAMS];
};

struct runtime_fixture {
    struct lsquic_test_pair rf_transport;
    struct runtime_endpoint rf_client;
    struct runtime_endpoint rf_server;
};

/* Read-only evidence that rejected calls preserve the sender state. */
struct runtime_send_snapshot {
    uint64_t rss_flags;
    uint64_t rss_final;
    uint64_t rss_reliable;
    uint64_t rss_error;
    uint64_t rss_offset;
    unsigned rss_queue_flags;
    unsigned rss_buffered;
};

static const char runtime_alpn[] = "uwz-reset-runtime/1";


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct runtime_endpoint *endpoint = ctx;

    assert(!endpoint->re_conn);
    endpoint->re_conn = conn;
    if (endpoint->re_server)
        endpoint->re_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct runtime_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(status == LSQ_HSK_OK);
    endpoint->re_handshake_ok = 1;
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct runtime_endpoint *endpoint = (void *) lsquic_conn_get_ctx(conn);

    assert(endpoint->re_conn == conn);
    endpoint->re_conn = NULL;
    lsquic_conn_set_ctx(conn, NULL);
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct runtime_endpoint *endpoint = ctx;
    struct runtime_stream *state;

    assert(stream);
    assert(endpoint->re_stream_count < RUNTIME_MAX_STREAMS);
    state = &endpoint->re_streams[endpoint->re_stream_count++];
    memset(state, 0, sizeof(*state));
    state->rs_stream = stream;
    state->rs_id = lsquic_stream_id(stream);
    state->rs_outgoing = (state->rs_id & 1) == endpoint->re_server;
    state->rs_expect_reset = state->rs_id == endpoint->re_reset_id;
    if (!state->rs_outgoing)
        assert(lsquic_stream_wantread(stream, 1) >= 0);
    return (lsquic_stream_ctx_t *) state;
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct runtime_stream *state = (void *) ctx;
    unsigned char bytes[256];
    ssize_t size;

    while (1)
    {
        size = lsquic_stream_read(stream, bytes, sizeof(bytes));
        if (size > 0)
        {
            assert((size_t) size <= sizeof(state->rs_bytes) - state->rs_received);
            memcpy(state->rs_bytes + state->rs_received, bytes, size);
            state->rs_received += size;
            continue;
        }
        if (size == 0)
        {
            assert(!state->rs_fin);
            state->rs_fin = 1;
        }
        else if (errno == ECONNRESET)
        {
            assert(state->rs_expect_reset);
            state->rs_read_error = ECONNRESET;
        }
        else
        {
            assert(errno == EAGAIN || errno == EWOULDBLOCK);
            return;
        }
        assert(lsquic_stream_wantread(stream, 0) >= 0);
        assert(0 == lsquic_stream_shutdown(stream, 0));
        return;
    }
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    (void) stream;
    (void) ctx;
    assert(0 && "runtime cases write through the public synchronous API");
}


static void
close_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct runtime_stream *state = (void *) ctx;

    assert(state->rs_stream == stream);
    assert(!state->rs_closed);
    assert(LSQUIC_SRG_OK == lsquic_stream_get_recv_state(stream,
                                                   &state->rs_close_metadata));
    if (state->rs_outgoing)
    {
        /* on_close is the final valid lifetime of this stream pointer. */
        assert(LSQUIC_SRA_CLOSED == lsquic_stream_reset_at(stream, 373, 0));
        state->rs_closed_api_checked = 1;
    }
    state->rs_closed = 1;
    state->rs_stream = NULL;
}


static void
reset_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx, int how)
{
    struct runtime_stream *state = (void *) ctx;
    uint64_t error = UINT64_MAX;

    assert(how == 0 || how == 1);
    assert(LSQUIC_SERR_AVAILABLE == lsquic_stream_get_reset_error(stream, how,
                                                                     &error));
    assert(!state->rs_reset_events[how]);
    state->rs_reset_events[how] = 1;
    state->rs_errors[how] = error;
    if (how == 0)
        assert(state->rs_expect_reset);
}


static const struct lsquic_stream_if runtime_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_hsk_done = handshake_done,
    .on_new_stream = new_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_reset = reset_stream,
};


static void
pump_step (struct runtime_fixture *fixture)
{
    lsquic_test_pair_process(&fixture->rf_transport, 1000);
    lsquic_test_deliver_all(&fixture->rf_transport.ltp_client);
    lsquic_test_deliver_all(&fixture->rf_transport.ltp_server);
}


static void
init_endpoint (struct runtime_fixture *fixture,
               struct runtime_endpoint *endpoint, unsigned server,
               unsigned initial_credit)
{
    struct lsquic_engine_settings settings;
    struct lsquic_test_endpoint_config config;
    struct lsquic_test_endpoint *peer;
    unsigned flags = server ? LSENG_SERVER : 0;

    endpoint->re_server = server;
    endpoint->re_reset_id = UINT64_MAX;
    endpoint->re_transport = server ? &fixture->rf_transport.ltp_server
                                   : &fixture->rf_transport.ltp_client;
    peer = server ? &fixture->rf_transport.ltp_client
                  : &fixture->rf_transport.ltp_server;
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = 4;
    settings.es_max_streams_in = 4;
    settings.es_reset_stream_at = endpoint->re_receive_enabled;
    if (initial_credit)
    {
        settings.es_init_max_data = initial_credit;
        settings.es_init_max_stream_data_uni = RUNTIME_MAX_BYTES;
    }
    assert(settings.es_check_tp_sanity);
    assert(0 == lsquic_engine_check_settings(&settings, flags, NULL, 0));
    memset(&config, 0, sizeof(config));
    config.ltec_flags = flags;
    config.ltec_settings = &settings;
    config.ltec_stream_if = &runtime_callbacks;
    config.ltec_stream_if_ctx = endpoint;
    config.ltec_alpn = runtime_alpn;
    config.ltec_tls = lsquic_test_tls_context_new(server, runtime_alpn);
    assert(config.ltec_tls);
    assert(0 == lsquic_test_endpoint_init(endpoint->re_transport, peer, &config,
                                        server ? 12201 : 12202));
    SSL_CTX_free(config.ltec_tls);
}


static void
init_fixture (struct runtime_fixture *fixture, unsigned client_receive,
              unsigned server_receive, unsigned initial_credit)
{
    unsigned step;

    memset(fixture, 0, sizeof(*fixture));
    fixture->rf_client.re_receive_enabled = client_receive;
    fixture->rf_server.re_receive_enabled = server_receive;
    init_endpoint(fixture, &fixture->rf_client, 0, initial_credit);
    init_endpoint(fixture, &fixture->rf_server, 1, initial_credit);
    assert(lsquic_engine_connect(fixture->rf_transport.ltp_client.lte_engine,
                LSQVER_I001,
                (struct sockaddr *) &fixture->rf_transport.ltp_client.lte_address,
                (struct sockaddr *) &fixture->rf_transport.ltp_server.lte_address,
                &fixture->rf_transport.ltp_client, NULL, "localhost", 0,
                NULL, 0, NULL, 0));
    for (step = 0; step < RUNTIME_MAX_STEPS; ++step)
    {
        if (fixture->rf_client.re_handshake_ok && fixture->rf_server.re_handshake_ok)
            break;
        pump_step(fixture);
    }
    assert(fixture->rf_client.re_handshake_ok);
    assert(fixture->rf_server.re_handshake_ok);
    for (step = 0; step < 200; ++step)
        pump_step(fixture);
    assert(!fixture->rf_transport.ltp_client.lte_incoming.ltq_count);
    assert(!fixture->rf_transport.ltp_server.lte_incoming.ltq_count);
}


static struct runtime_stream *
find_stream (struct runtime_endpoint *endpoint, lsquic_stream_id_t id)
{
    unsigned index;

    for (index = 0; index < endpoint->re_stream_count; ++index)
        if (endpoint->re_streams[index].rs_id == id)
            return &endpoint->re_streams[index];
    return NULL;
}


static struct runtime_stream *
make_stream (struct runtime_endpoint *sender, lsquic_stream_id_t id)
{
    struct runtime_stream *stream;

    assert(LSQUIC_MUS_OK == lsquic_conn_make_uni_stream(sender->re_conn));
    stream = find_stream(sender, id);
    assert(stream && stream->rs_stream && stream->rs_outgoing);
    return stream;
}


static void
wait_closed (struct runtime_fixture *fixture, struct runtime_stream *outgoing,
             struct runtime_endpoint *receiver)
{
    struct runtime_stream *incoming;
    unsigned step;

    for (step = 0; step < RUNTIME_MAX_STEPS; ++step)
    {
        incoming = find_stream(receiver, outgoing->rs_id);
        if (outgoing->rs_closed && incoming && incoming->rs_closed)
            break;
        pump_step(fixture);
    }
    incoming = find_stream(receiver, outgoing->rs_id);
    assert(outgoing->rs_closed && outgoing->rs_closed_api_checked);
    assert(incoming && incoming->rs_closed);
}


static void
cleanup_fixture (struct runtime_fixture *fixture)
{
    lsquic_test_endpoint_destroy(&fixture->rf_transport.ltp_client);
    lsquic_test_endpoint_destroy(&fixture->rf_transport.ltp_server);
}


static struct runtime_send_snapshot
snapshot_send (const lsquic_stream_t *stream)
{
    struct runtime_send_snapshot snapshot = {
        .rss_flags = stream->stream_flags,
        .rss_final = stream->sm_reset_tx_final,
        .rss_reliable = stream->sm_reset_tx_reliable,
        .rss_error = stream->error_code,
        .rss_offset = stream->tosend_off,
        .rss_queue_flags = stream->sm_qflags,
        .rss_buffered = stream->sm_n_buffered,
    };

    return snapshot;
}


static void
assert_rejected (lsquic_stream_t *stream, uint64_t error, uint64_t reliable,
                 int expected)
{
    struct runtime_send_snapshot before = snapshot_send(stream);
    struct runtime_send_snapshot after;

    assert(expected == lsquic_stream_reset_at(stream, error, reliable));
    after = snapshot_send(stream);
    assert(before.rss_flags == after.rss_flags);
    assert(before.rss_final == after.rss_final);
    assert(before.rss_reliable == after.rss_reliable);
    assert(before.rss_error == after.rss_error);
    assert(before.rss_offset == after.rss_offset);
    assert(before.rss_queue_flags == after.rss_queue_flags);
    assert(before.rss_buffered == after.rss_buffered);
}


static void
assert_healthy (const struct runtime_stream *incoming,
                const unsigned char *bytes, size_t size)
{
    assert(incoming && incoming->rs_closed);
    assert(incoming->rs_fin && !incoming->rs_read_error);
    assert(!incoming->rs_reset_events[0] && !incoming->rs_reset_events[1]);
    assert(incoming->rs_received == size);
    assert(0 == memcmp(incoming->rs_bytes, bytes, size));
    assert(incoming->rs_close_metadata.flags & LSQUIC_SRS_FIN_RECEIVED);
    assert(!(incoming->rs_close_metadata.flags & LSQUIC_SRS_RESET_KNOWN));
    assert(incoming->rs_close_metadata.final_size == size);
    assert(incoming->rs_close_metadata.reliable_size == size);
}


static void
assert_reset (const struct runtime_stream *incoming, uint64_t final_size,
              uint64_t reliable_size, unsigned extended)
{
    unsigned known = LSQUIC_SRS_FINAL_SIZE_KNOWN | LSQUIC_SRS_RESET_KNOWN
                                              | LSQUIC_SRS_RESET_VISIBLE;

    assert(incoming && incoming->rs_closed && !incoming->rs_fin);
    assert(incoming->rs_read_error == ECONNRESET);
    assert(incoming->rs_reset_events[0] == 1);
    assert(incoming->rs_errors[0] == 373);
    assert((incoming->rs_close_metadata.flags & known) == known);
    assert(!!(incoming->rs_close_metadata.flags & LSQUIC_SRS_RELIABLE_RESET_SEEN)
                                                                    == extended);
    assert(incoming->rs_close_metadata.final_size == final_size);
    assert(incoming->rs_close_metadata.reliable_size == reliable_size);
    assert(incoming->rs_close_metadata.reset_error_code == 373);
}


static void
test_api_contract (unsigned server_sender)
{
    struct runtime_fixture fixture;
    struct runtime_endpoint *sender, *receiver;
    struct runtime_stream *healthy, *reset;
    unsigned char bytes[64];
    lsquic_stream_id_t id = server_sender ? 3 : 2;

    memset(bytes, 'a', sizeof(bytes));
    init_fixture(&fixture, 0, 0, 0);
    sender = server_sender ? &fixture.rf_server : &fixture.rf_client;
    receiver = server_sender ? &fixture.rf_client : &fixture.rf_server;
    healthy = make_stream(sender, id);
    assert(sizeof(bytes) == (size_t) lsquic_stream_write(healthy->rs_stream,
                                                        bytes, sizeof(bytes)));
    assert_rejected(healthy->rs_stream, 373, 33, LSQUIC_SRA_UNSUPPORTED);
    assert(0 == lsquic_stream_shutdown(healthy->rs_stream, 1));
    wait_closed(&fixture, healthy, receiver);
    assert_healthy(find_stream(receiver, id), bytes, sizeof(bytes));
    receiver->re_reset_id = id + 4;
    reset = make_stream(sender, id + 4);
    assert(sizeof(bytes) == (size_t) lsquic_stream_write(reset->rs_stream,
                                                        bytes, sizeof(bytes)));
    assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(reset->rs_stream, 373, 0));
    assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(reset->rs_stream, 373, 0));
    wait_closed(&fixture, reset, receiver);
    assert_reset(find_stream(receiver, id + 4), sizeof(bytes), 0, 0);
    cleanup_fixture(&fixture);

    init_fixture(&fixture, 1, 1, 0);
    sender = server_sender ? &fixture.rf_server : &fixture.rf_client;
    receiver = server_sender ? &fixture.rf_client : &fixture.rf_server;
    healthy = make_stream(sender, id);
    assert(sizeof(bytes) == (size_t) lsquic_stream_write(healthy->rs_stream,
                                                        bytes, sizeof(bytes)));
    assert_rejected(healthy->rs_stream, 373, sizeof(bytes) + 1,
                    LSQUIC_SRA_INVALID);
    assert_rejected(healthy->rs_stream, 373, UINT64_C(1) << 62,
                    LSQUIC_SRA_INVALID);
    assert_rejected(healthy->rs_stream, UINT64_C(1) << 62, 33,
                    LSQUIC_SRA_INVALID);
    assert(0 == lsquic_stream_shutdown(healthy->rs_stream, 1));
    wait_closed(&fixture, healthy, receiver);
    assert_healthy(find_stream(receiver, id), bytes, sizeof(bytes));
    receiver->re_reset_id = id + 4;
    reset = make_stream(sender, id + 4);
    assert(sizeof(bytes) == (size_t) lsquic_stream_write(reset->rs_stream,
                                                        bytes, sizeof(bytes)));
    assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(reset->rs_stream, 373, 64));
    assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(reset->rs_stream, 373, 64));
    assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(reset->rs_stream, 373, 33));
    assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(reset->rs_stream, 373, 33));
    assert_rejected(reset->rs_stream, 373, 34, LSQUIC_SRA_INVALID);
    assert_rejected(reset->rs_stream, 374, 33, LSQUIC_SRA_INVALID);
    wait_closed(&fixture, reset, receiver);
    assert_reset(find_stream(receiver, id + 4), sizeof(bytes), 33, 1);
    assert(find_stream(receiver, id + 4)->rs_received >= 33);
    assert(find_stream(receiver, id + 4)->rs_received <= sizeof(bytes));
    cleanup_fixture(&fixture);
    printf("PASS API/lifecycle/unsupported healthy FIN/zero reset/invalid unchanged/reduce/error373: %s sender\n",
           server_sender ? "server" : "client");
}


static void
test_frozen_connection_credit (unsigned server_sender)
{
    struct runtime_fixture fixture;
    struct runtime_endpoint *sender, *receiver;
    struct runtime_stream *primary, *sibling;
    unsigned char bytes[RUNTIME_CREDIT];
    unsigned char healthy[64];
    lsquic_stream_id_t id = server_sender ? 3 : 2;
    unsigned step, received_before;
    ssize_t size;

    memset(bytes, 'c', sizeof(bytes));
    memset(healthy, 'h', sizeof(healthy));
    init_fixture(&fixture, 1, 1, RUNTIME_CREDIT);
    sender = server_sender ? &fixture.rf_server : &fixture.rf_client;
    receiver = server_sender ? &fixture.rf_client : &fixture.rf_server;
    receiver->re_reset_id = id;
    primary = make_stream(sender, id);
    assert(RUNTIME_CREDIT - 1000 == lsquic_stream_write(primary->rs_stream,
                                               bytes, RUNTIME_CREDIT - 1000));
    assert(0 == lsquic_stream_flush(primary->rs_stream));
    /* Leave one credit available to avoid the implicit exhaustion flush. */
    assert(999 == lsquic_stream_write(primary->rs_stream,
                                      bytes + RUNTIME_CREDIT - 1000, 999));
    assert(primary->rs_stream->sm_n_buffered > 0);
    sibling = make_stream(sender, id + 4);
    received_before = sender->re_transport->lte_packets_received;
    assert(1 == lsquic_stream_write(sibling->rs_stream, healthy, 1));
    assert(primary->rs_stream->sm_n_buffered > 0);
    assert(0 == lsquic_stream_write(sibling->rs_stream, healthy + 1,
                                                    sizeof(healthy) - 1));
    assert(LSQUIC_SRA_OK == lsquic_stream_reset_at(primary->rs_stream, 373, 33));
    assert(primary->rs_stream->sm_n_buffered == 0);
    /* No peer packet, including MAX_DATA, can arrive between these probes. */
    assert(sender->re_transport->lte_packets_received == received_before);
    assert(0 == lsquic_stream_write(sibling->rs_stream, healthy + 1,
                                                    sizeof(healthy) - 1));
    assert(sender->re_transport->lte_packets_received == received_before);
    for (step = 0; step < RUNTIME_MAX_STEPS; ++step)
    {
        pump_step(&fixture);
        size = lsquic_stream_write(sibling->rs_stream, healthy + 1,
                                                       sizeof(healthy) - 1);
        assert(size >= 0);
        if (size > 0)
            break;
    }
    assert(size == sizeof(healthy) - 1);
    assert(sender->re_transport->lte_packets_received > received_before);
    assert(0 == lsquic_stream_shutdown(sibling->rs_stream, 1));
    wait_closed(&fixture, primary, receiver);
    wait_closed(&fixture, sibling, receiver);
    assert_reset(find_stream(receiver, id), RUNTIME_CREDIT - 1, 33, 1);
    assert(find_stream(receiver, id)->rs_received >= 33);
    assert(find_stream(receiver, id)->rs_received <= RUNTIME_CREDIT - 1);
    assert_healthy(find_stream(receiver, id + 4), healthy, sizeof(healthy));
    cleanup_fixture(&fixture);
    printf("PASS frozen final4095 debit/one-byte sibling exhausts4096 credit/buffered suffix discarded/B blocked before peer credit/normal drain/error373: %s sender\n",
           server_sender ? "server" : "client");
}


int
main (int argc, char **argv)
{
    unsigned api, credit;

    assert(argc <= 2);
    api = argc == 1 || 0 == strcmp(argv[1], "all") || 0 == strcmp(argv[1], "api");
    credit = argc == 1 || 0 == strcmp(argv[1], "all") || 0 == strcmp(argv[1], "credit");
    assert(api || credit);
    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    if (api)
    {
        test_api_contract(0);
        test_api_contract(1);
    }
    if (credit)
    {
        test_frozen_connection_credit(0);
        test_frozen_connection_credit(1);
    }
    lsquic_global_cleanup();
    return 0;
}
