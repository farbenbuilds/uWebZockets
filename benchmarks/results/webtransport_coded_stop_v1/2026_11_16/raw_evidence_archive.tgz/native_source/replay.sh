#!/bin/sh
set -eu

checkpoint=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
zig_exe=${1:-zig}
mode=${2:-Debug}
profile=${3:-quick}
package_cache=${4:-}
case "$mode" in Debug|ReleaseSafe|ReleaseFast) ;; *) exit 2 ;; esac
case "$profile" in quick|logger|baseline-red|logger-red|pre-log-regressions) ;; *) exit 2 ;; esac
run_dir=$(mktemp -d "${TMPDIR:-/tmp}/uwz-stop-replay.XXXXXXXX")
printf 'Replay work and logs: %s\n' "$run_dir"
source_dir="$checkpoint/source"
if [ "$profile" = pre-log-regressions ] || [ "$profile" = logger-red ]; then
    cp -R "$source_dir" "$run_dir/pre-log-source"
    source_dir="$run_dir/pre-log-source"
    cp "$checkpoint/evidence/pre-log-logger/lsquic_ev_log.c" "$source_dir/src/liblsquic/lsquic_ev_log.c"
    cp "$checkpoint/evidence/pre-log-logger/lsquic_ev_log.h" "$source_dir/src/liblsquic/lsquic_ev_log.h"
    if [ "$profile" = pre-log-regressions ]; then rm "$source_dir/tests/uwz_stop_sending_log.c"; fi
fi
if [ "$profile" = baseline-red ]; then
    git clone -q -b uwz/stop-sending-proposal-20261116 \
        "$checkpoint/git/lsquic-stop-proposal.bundle" "$run_dir/baseline-source"
    source_dir="$run_dir/baseline-source"
    git -C "$source_dir" checkout -q 2e229b3e0a9bb293c4d7f74f7532e09213b8cb5c
    cp "$checkpoint/evidence/red-source/uwz_stop_sending.c" "$source_dir/tests/uwz_stop_sending.c"
    cp "$checkpoint/evidence/red-source/uwz_stop_sending_declaration.c" "$source_dir/tests/uwz_stop_sending_declaration.c"
fi

native_case() {
    case_name=$1
    fixture=$2
    shift 2
    set -- -- "$@"
    if [ -n "$package_cache" ]; then set -- --system "$package_cache" "$@"; fi
    ZIG_GLOBAL_CACHE_DIR="$run_dir/global-cache" "$zig_exe" build test \
        --build-file "$checkpoint/harness/build.zig" \
        --cache-dir "$run_dir/cache" --global-cache-dir "$run_dir/global-cache" \
        "-Doptimize=$mode" "-Dlsquic-source=$source_dir" \
        "-Dfixture=$source_dir/tests/$fixture" \
        "-Dfixture-includes=$source_dir/src/liblsquic" \
        "-Dfixture-support=$source_dir/tests/uwz_quic_fixture.c" \
        "-Dfixture-name=$case_name" -j2 --summary all "$@" \
        > "$run_dir/$case_name.log" 2>&1 || return $?
    printf 'PASS %s\n' "$case_name"
}

cd "$run_dir"
if [ "$profile" = baseline-red ]; then
    if native_case declaration-red uwz_stop_sending_declaration.c; then exit 1; fi
    grep -F 'LSQUIC_SST_INVALID' "$run_dir/declaration-red.log" >/dev/null
    grep -F 'undeclared' "$run_dir/declaration-red.log" >/dev/null
    if native_case wire-red uwz_stop_sending.c 0 1 0 0; then exit 1; fi
    grep -F 'local->errors[1] == code' "$run_dir/wire-red.log" >/dev/null
    printf 'EXPECTED FAILURES: declaration and actual wire baseline\n'
    exit
fi
if [ "$profile" = logger-red ]; then
    if native_case event-log-red uwz_stop_sending_log.c; then exit 1; fi
    grep -F 'strstr(capture.text, "error code: 4611686018427387903")' "$run_dir/event-log-red.log" >/dev/null
    printf 'EXPECTED FAILURE: full-width event logger capture\n'
    exit
fi
if [ "$profile" = logger ]; then
    native_case event-log uwz_stop_sending_log.c
    exit
fi
if [ "$profile" = quick ]; then
    native_case declaration uwz_stop_sending_declaration.c
    native_case coded-uni uwz_stop_sending.c 0 1 0 0
    native_case coded-fin-unread uwz_stop_sending.c 0 1 1 0
    native_case coded-bidi-independent uwz_stop_sending.c 1 0 0 0
    native_case legacy-stop uwz_stop_sending.c 0 1 0 1
    native_case legacy-fin-suppression uwz_stop_sending.c 0 1 1 1
    native_case reset-before-send uwz_stop_sending.c reset-before-send
    native_case event-log uwz_stop_sending_log.c
    exit
fi
native_case old-normal uwz_webtransport_streams.c all
native_case old-resets uwz_webtransport_stream_resets.c all
native_case old-classification uwz_webtransport_classification.c all
native_case old-placement uwz_webtransport_frame_errors.c all
set --
if [ -n "$package_cache" ]; then set -- --system "$package_cache"; fi
ZIG_GLOBAL_CACHE_DIR="$run_dir/global-cache" "$zig_exe" build test \
    --build-file "$checkpoint/harness/build.zig" \
    --cache-dir "$run_dir/cache" --global-cache-dir "$run_dir/global-cache" \
    "-Doptimize=$mode" "-Dlsquic-source=$source_dir" \
    -Dupstream-tests=true -j2 --summary all "$@" \
    > "$run_dir/upstream83.log" 2>&1
printf 'PASS upstream83\n'
