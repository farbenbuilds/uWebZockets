#!/usr/bin/env python3
"""Change only the planner policy of an idle, uniquely owned fixture."""
import argparse
import json
from pathlib import Path
import re
import subprocess
import time


QUERY = "SELECT id,name,category,price,quantity,active,tags,rating_score,rating_count FROM items WHERE price BETWEEN $1 AND $2 LIMIT $3"
SNAPSHOT_SQL = """
SELECT json_build_object(
 'user',current_user,'database',current_database(),
 'postmaster_started',pg_postmaster_start_time(),
 'server_version_num',current_setting('server_version_num'),
 'tcp_clients',(SELECT count(*) FROM pg_stat_activity WHERE backend_type='client backend' AND client_addr IS NOT NULL),
 'target',json_build_object('dbid',(SELECT oid FROM pg_database WHERE datname='benchmark'),'userid',(SELECT oid FROM pg_roles WHERE rolname='bench')),
 'setting',(SELECT row_to_json(s) FROM (SELECT name,setting,source,reset_val,boot_val,pending_restart FROM pg_settings WHERE name='plan_cache_mode') s),
 'role_settings',COALESCE((SELECT json_agg(s) FROM (SELECT setdatabase,setrole,setconfig FROM pg_db_role_setting WHERE setdatabase IN (0,(SELECT oid FROM pg_database WHERE datname='benchmark')) AND setrole IN (0,(SELECT oid FROM pg_roles WHERE rolname='bench')) ORDER BY setdatabase,setrole) s),'[]'::json),
 'statistics',(SELECT row_to_json(s) FROM (SELECT n_live_tup,n_dead_tup,n_mod_since_analyze,n_ins_since_vacuum,last_analyze,last_autoanalyze,analyze_count,autoanalyze_count,last_vacuum,last_autovacuum,vacuum_count,autovacuum_count FROM pg_stat_user_tables WHERE schemaname='public' AND relname='items') s),
 'settings',(SELECT json_object_agg(name,setting ORDER BY name) FROM pg_settings WHERE name IN ('shared_preload_libraries','compute_query_id','default_transaction_isolation','max_connections','shared_buffers','fsync','synchronous_commit','jit','track_counts','track_io_timing','default_statistics_target','log_statement')));
"""


def command(container, sql):
    argv = ["docker", "exec", "-i", container, "psql", "-qXAt", "-U", "bench",
            "-d", "benchmark", "-vON_ERROR_STOP=1"]
    result = subprocess.run(argv, input=sql, text=True, capture_output=True)
    record = {"argv": argv, "stdin": sql, "exit_code": result.returncode,
              "stdout": result.stdout, "stderr": result.stderr}
    if result.returncode != 0:
        raise RuntimeError("Owned policy SQL failed: " + result.stderr)
    return record


def observe(container):
    record = command(container, SNAPSHOT_SQL)
    return record, json.loads(record["stdout"])


def validate(snapshot, mode):
    if snapshot["user"] != "bench" or snapshot["database"] != "benchmark":
        raise RuntimeError("The fresh login has the wrong database or role")
    setting = snapshot["setting"]
    expected_source = "default" if mode == "auto" else "database user"
    if (setting["setting"] != mode or setting["reset_val"] != mode
            or setting["boot_val"] != "auto" or setting["source"] != expected_source
            or setting["pending_restart"]):
        raise RuntimeError("Inherited planner policy differs")
    expected = [] if mode == "auto" else [{
        "setdatabase": snapshot["target"]["dbid"], "setrole": snapshot["target"]["userid"],
        "setconfig": ["plan_cache_mode=force_generic_plan"]}]
    if snapshot["role_settings"] != expected:
        raise RuntimeError("The role/database policy catalog differs")
    if snapshot["settings"]["shared_preload_libraries"] or snapshot["settings"]["compute_query_id"] != "auto":
        raise RuntimeError("The fixture has unexpected instrumentation")


def json_stream(text):
    decoder = json.JSONDecoder()
    values = []
    remaining = text.lstrip()
    while remaining:
        value, end = decoder.raw_decode(remaining)
        values.append(value)
        remaining = remaining[end:].lstrip()
    return values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["apply", "snapshot", "probe"])
    parser.add_argument("--mode", choices=["auto", "force_generic_plan"], required=True)
    parser.add_argument("--fixture", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    fixture = json.loads(args.fixture.read_text())
    container = fixture["container"]
    if (not re.fullmatch(r"[0-9a-f]{64}", container)
            or fixture["pg_user"] != "bench" or fixture["pg_database"] != "benchmark"):
        raise RuntimeError("Unexpected fixture identity")
    labels = json.loads(subprocess.check_output(
        ["docker", "inspect", "--format", "{{json .Config.Labels}}", container], text=True))
    expected_labels = {"uwz.sql-experiment": "sql-plan-policy-20261119",
                       "uwz.role": "database", "uwz.run-token": fixture["owner_token"]}
    if any(labels.get(key) != value for key, value in expected_labels.items()):
        raise RuntimeError("Policy fixture ownership differs")
    commands = []
    first, before = observe(container)
    commands.append(first)
    if args.action in ("apply", "probe") and before["tcp_clients"] != 0:
        raise RuntimeError("Policy mutation and probes require zero TCP clients")
    if args.action == "apply":
        sql = ("ALTER ROLE bench IN DATABASE benchmark RESET plan_cache_mode;" if args.mode == "auto"
               else "ALTER ROLE bench IN DATABASE benchmark SET plan_cache_mode TO force_generic_plan;")
        commands.append(command(container, sql))
    after_command, after = observe(container)
    commands.append(after_command)
    validate(after, args.mode)
    if before["postmaster_started"] != after["postmaster_started"] or before["target"] != after["target"]:
        raise RuntimeError("The fixture restarted or changed identity during policy verification")
    if args.action in ("apply", "probe") and after["tcp_clients"] != 0:
        raise RuntimeError("TCP clients appeared during policy setup or probing")
    record = {"schema": "uwz_pg_plan_policy_v1", "action": args.action, "mode": args.mode,
              "observed_unix_ns": time.time_ns(), "container": container,
              "expected_labels": expected_labels, "before": before, "snapshot": after,
              "commands": commands}
    if args.action == "probe":
        probe_sql = "PREPARE uwz_plan_policy_probe(int4,int4,int4) AS " + QUERY + ";\n"
        for limit in (5, 10, 20, 35, 50):
            probe_sql += "EXPLAIN (FORMAT JSON) EXECUTE uwz_plan_policy_probe(10,50," + str(limit) + ");\n"
        probe_sql += "SELECT row_to_json(s) FROM (SELECT name,statement,parameter_types::text,from_sql,generic_plans,custom_plans FROM pg_prepared_statements WHERE name='uwz_plan_policy_probe') s;\n"
        probe_sql += "DEALLOCATE uwz_plan_policy_probe;\n"
        probe = command(container, probe_sql)
        values = json_stream(probe["stdout"])
        if len(values) != 6:
            raise RuntimeError("Expected five plans and one session-local counter row")
        for plan in values[:5]:
            root = plan[0]["Plan"]
            children = root.get("Plans", [])
            if (root["Node Type"] != "Limit" or root.get("Parallel Aware")
                    or len(children) != 1 or children[0]["Node Type"] != "Seq Scan"
                    or children[0].get("Parallel Aware") or children[0].get("Relation Name") != "items"):
                raise RuntimeError("The policy changed the required nonparallel scan shape")
        counts = values[-1]
        expected_counts = (0, 5) if args.mode == "auto" else (5, 0)
        if (counts["generic_plans"], counts["custom_plans"]) != expected_counts:
            raise RuntimeError("Probe-session plan policy counts differ")
        record.update({"probe": probe, "plans": values[:5], "probe_session_counts": counts,
                       "probe_scope": "Off-window SQL PREPARE/EXPLAIN only, not application session counts; no ANALYZE"})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(record, indent=2) + "\n")
    print(args.action, args.mode, "verified on the owned fixture")


if __name__ == "__main__":
    main()
