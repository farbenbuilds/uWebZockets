#!/usr/bin/env python3
"""Verify extracted source, policy changes, restoration and paired results offline."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import sys


BINARY = 'install/bin/sql_httparena'
WRK = 'tooling/root/usr/bin/wrk'
LUA = 'runner/async_db.lua'
AUTO = 'auto'
GENERIC = 'force_generic_plan'
RESET = 'ALTER ROLE bench IN DATABASE benchmark RESET plan_cache_mode;'
SET = 'ALTER ROLE bench IN DATABASE benchmark SET plan_cache_mode TO force_generic_plan;'
AUTO_PROBE = 'preflight/auto_probe.json'
GENERIC_PROBE = 'preflight/force_generic_plan_probe.json'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def mode(path):
    return stat.S_IMODE(path.stat().st_mode)


def check_inventory(root, entries, manifest=None):
    expected = set()
    for entry in entries:
        name = entry['path']
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts and name not in expected, f'Invalid inventory path {name}')
        expected.add(name)
        member = root / path
        require(member.is_file() and not member.is_symlink() and mode(member) == entry['mode'] and
                sha(member) == entry['sha256'], f'File identity differs: {name}')
    observed = {path.relative_to(root).as_posix() for path in root.rglob('*') if not path.is_dir() or path.is_symlink()}
    if manifest is not None:
        expected.add(manifest)
    require(observed == expected, f'File inventory differs under {root.name}')
    return len(entries)


def verify_source(root):
    plan = load(root / 'decision_plan.json')
    build = load(root / 'build/result.json')
    package = load(root / 'packaged_source_identity.json')
    base = load(root / 'source_identity.json')
    provenance = load(root / 'source_provenance.json')
    require(check_inventory(root / 'source', package['files']) == provenance['verified_git_blob_identities'] == 346 and
            package['commit'] == base['commit'] == build['source_commit'] == provenance['build_source_commit'] and
            plan['base_commit'] == provenance['measurement_workspace_commit'] and plan['source_changes'] is False,
            'Source provenance differs')
    package_by_path = {entry['path']: entry for entry in package['files']}
    require(len(base['files']) == 288, 'Build input subset differs')
    for item in base['files']:
        expected = package_by_path[item['path']]
        require(all(item[key] == expected[key] for key in ('sha256', 'mode')), f"Build subset differs: {item['path']}")
    require(build['exit_code'] == 0 and sha(root / BINARY) == build['binary_sha256'] == plan['normal_binary_sha256'] and
            (root / BINARY).stat().st_size == build['binary_bytes'], 'Build binary differs')
    tools = load(root / 'tooling/identity.json')
    require(sha(root / WRK) == tools['wrk_sha256'] and
            sha(root / 'tooling/wrk_4.1.0-4build3_amd64.deb') == tools['package_sha256'], 'wrk identity differs')


def verify_fixture(root):
    fixture = load(root / 'fixture.json')
    for entry in load(root / 'archived_inputs.json')['files']:
        file = root / 'archived_fixture' / Path(entry['member']).name
        require(sha(file) == entry['sha256'] and mode(file) == entry['mode'], f'Archived fixture input differs: {file.name}')
    require(fixture['seed_sha256'] == sha(root / 'archived_fixture/pgdb-seed.sql') and
            fixture['image'] == (root / 'archived_fixture/image.txt').read_text().strip() and
            fixture['seed_rows'] == 100000 and fixture['expected_rows'] == 8237, 'Fixture identity differs')
    return fixture


def verify_snapshot(snapshot, mode):
    expected_source = 'default' if mode == AUTO else 'database user'
    require(snapshot['user'] == 'bench' and snapshot['database'] == 'benchmark' and snapshot['tcp_clients'] == 0 and
            snapshot['server_version_num'] == '180006' and snapshot['setting'] == {'name': 'plan_cache_mode', 'setting': mode,
                'source': expected_source, 'reset_val': mode, 'boot_val': AUTO, 'pending_restart': False},
            f'Wrong inherited planner setting: {mode}')
    target = snapshot['target']
    require(all(type(oid) is str and oid.isdigit() for oid in target.values()), 'Invalid role or database OID')
    expected_catalog = [] if mode == AUTO else [{'setdatabase': target['dbid'], 'setrole': target['userid'],
                                                'setconfig': ['plan_cache_mode=force_generic_plan']}]
    require(snapshot['role_settings'] == expected_catalog, f'Wrong role/database catalog: {mode}')
    require(snapshot['settings']['shared_preload_libraries'] == '' and snapshot['settings']['compute_query_id'] == AUTO,
            'Unexpected database instrumentation')
    return {key: snapshot[key] for key in ('target', 'settings', 'statistics', 'postmaster_started', 'server_version_num')}


def verify_policy_record(record, fixture, action, mode, previous):
    labels = {'uwz.sql-experiment': fixture['label'], 'uwz.role': 'database', 'uwz.run-token': fixture['owner_token']}
    container = fixture['container']
    require(record['schema'] == 'uwz_pg_plan_policy_v1' and record['action'] == action and record['mode'] == mode and
            record['container'] == container and record['expected_labels'] == labels, 'Wrong policy fixture binding')
    before = verify_snapshot(record['before'], previous)
    after = verify_snapshot(record['snapshot'], mode)
    require(before == after, 'Postmaster, maintenance or another setting changed during policy operation')
    commands = record['commands']
    require(len(commands) == (3 if action == 'apply' else 2) and all(command['exit_code'] == 0 and
            command['argv'][3] == container for command in commands), 'Invalid recorded policy command')
    require(json.loads(commands[0]['stdout']) == record['before'] and json.loads(commands[-1]['stdout']) == record['snapshot'],
            'Policy snapshot does not match command output')
    if action == 'apply':
        require(commands[1]['stdin'] == (RESET if mode == AUTO else SET), 'Policy change SQL differs')
    return after


def utc_ns(value):
    return int(datetime.fromisoformat(value).timestamp() * 1_000_000_000)


def verify_policy_history(root, run, fixture):
    profile_ops = ((AUTO_PROBE, 'probe', AUTO, AUTO), ('preflight/force_generic_plan_apply.json', 'apply', GENERIC, AUTO),
                   (GENERIC_PROBE, 'probe', GENERIC, GENERIC), ('preflight/auto_apply.json', 'apply', AUTO, GENERIC),
                   ('final_restore.json', 'apply', AUTO, GENERIC))
    epoch = None
    times = []
    for name, action, mode, previous in profile_ops:
        record = load(root / name)
        current = verify_policy_record(record, fixture, action, mode, previous)
        require(epoch is None or epoch == current, f'Expected unchanged database maintenance epoch: {name}')
        epoch = current
        times.append(record['observed_unix_ns'])
    start = utc_ns(load(run / 'metadata.json')['start'])
    end = max(utc_ns(load(path)['finished_at']) for path in run.glob('*/policy_after.command.json'))
    cleanup = load(root / 'cleanup.json')
    require(times[:4] == sorted(set(times[:4])) and times[3] < start < end < times[4] < utc_ns(cleanup['cleanup_utc']),
            'Probe, canonical reset, measurement, final reset and cleanup order differs')
    final_case = load(run / 'pair_03_force_generic_plan/policy_after.json')
    require(final_case['snapshot'] == load(root / 'final_restore.json')['before'], 'Final reset did not start from the last case policy')
    require(cleanup['container_removed_or_absent'] is True and cleanup['private_inputs_removed'] is True and
            cleanup['matched_database_containers'] == 1 and cleanup['label'] == fixture['label'] and
            cleanup['ownership_token_sha256'] == hashlib.sha256(fixture['owner_token'].encode()).hexdigest(),
            'Cleanup identity differs')


def verify_prelaunch(root):
    seen = set()
    expected = {BINARY, WRK, LUA, 'runner/measure.py', 'verification/verify.py', 'verification/test_verify.py', 'verification/test_run.log',
                'policy.py', 'fixture.json', 'fixture/expected_items.jsonl', AUTO_PROBE, GENERIC_PROBE,
                'preflight/auto_apply.json', 'preflight/force_generic_plan_apply.json'}
    for line in (root / 'verification/prelaunch.sha256').read_text().splitlines():
        digest, path = line.split()
        work, name = path.removeprefix('.zig-cache/').split('/', 1)
        require(work in {'sql-plan-policy-20261119', 'async-db-performance-20261118'} and name not in seen and
                name in expected and sha(root / name) == digest, f'Prelaunch identity differs: {name}')
        seen.add(name)
    require(seen == expected, 'Unexpected prelaunch input inventory')


def verify_perf_record(root):
    record = load(root / 'preflight/perf_availability.json')
    require(record['argv'] == ['perf', 'stat', '-e', 'task-clock', '--', 'true'] and record['exit_code'] == 1 and
            record['perf_event_paranoid'] == '4' and 'CapEff:\t0000000000000000' in record['effective_capabilities'],
            'Perf availability evidence differs')


def main():
    root = Path(__file__).resolve().parent
    run = root / 'measurements/run_01'
    count = check_inventory(root, load(root / 'payload_manifest.json')['files'], 'payload_manifest.json')
    verify_source(root)
    fixture = verify_fixture(root)
    verify_prelaunch(root)
    verify_policy_history(root, run, fixture)
    verify_perf_record(root)
    out = subprocess.check_output([sys.executable, '-B', root / 'verification/verify.py', run,
                                   '--items', root / 'fixture/expected_items.jsonl', '--fixture', root / 'fixture.json',
                                   '--binary', root / BINARY, '--wrk', root / WRK, '--lua', root / LUA,
                                   '--policy', root / 'policy.py', '--auto-probe', root / AUTO_PROBE, '--generic-probe', root / GENERIC_PROBE])
    result = json.loads(out)
    require(result == load(run / 'verified.json'), 'Recomputed benchmark differs from retained verification')
    ranges = result['timed_run_observed_ranges']
    print(f'Verified {count} payload files, 346 source files, role policy and the final reset.')
    print('Recomputed eight cases and 100 fixed responses.')
    print(f"HTTP medians: {ranges[AUTO]['rps']['median']:.3f} auto requests/s, {ranges[GENERIC]['rps']['median']:.3f} generic requests/s.")
    print('Both observed medians above 300,000 requests/s:', result['observed_median_above_threshold'])


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, subprocess.CalledProcessError) as error:
        raise SystemExit(f'Verification failed: {error}') from error
