package main

import (
	"bytes"
	"testing"
)

func TestExactReadRequiresAllBinaryBytesAndFIN(t *testing.T) {
	want := []byte{0, 255, 0, 1, 128}
	if _, err := exactRead(bytes.NewReader(want), want); err != nil {
		t.Fatal(err)
	}
	for _, got := range [][]byte{want[:4], append(append([]byte{}, want...), 0), []byte{0, 254, 0, 1, 128}} {
		if _, err := exactRead(bytes.NewReader(got), want); err == nil {
			t.Fatalf("accepted mismatched body %x", got)
		}
	}
}
