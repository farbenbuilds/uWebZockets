package main

import (
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
)

type ConnectionIdentity struct {
	Index      int
	Generation uint64
}

type RouteIdentity struct {
	Source  int `json:"source"`
	Ordinal int `json:"ordinal"`
}
type ServerSession struct {
	SessionIndex      int    `json:"session_index"`
	SessionGeneration uint64 `json:"session_generation"`
	OpenCount         int    `json:"open_count"`
	ClosedCount       int    `json:"closed_count"`
	Source            int    `json:"source"`
	Ordinal           int    `json:"ordinal"`
	ConnectionIndex   int    `json:"connection_index"`
	Generation        uint64 `json:"generation"`
	SessionID         uint64 `json:"session_id"`
	Open              bool   `json:"open"`
	Closed            bool   `json:"closed"`
}
type ServerDatagram struct {
	ConnectionGeneration uint64 `json:"connection_generation"`
	Source               int    `json:"source"`
	Ordinal              int    `json:"ordinal"`
	ConnectionIndex      int    `json:"connection_index"`
	SessionID            uint64 `json:"session_id"`
	Hex                  string `json:"hex"`
}
type ServerRing struct {
	ConnectionGeneration uint64 `json:"connection_generation"`
	Source               int    `json:"source"`
	Sequence             uint64 `json:"sequence"`
	ConnectionIndex      int    `json:"connection_index"`
	Ordinal              int    `json:"ordinal"`
	SessionID            uint64 `json:"session_id"`
	Hex                  string `json:"hex"`
}
type ServerChild struct {
	ConnectionGeneration uint64  `json:"connection_generation"`
	SessionIndex         int     `json:"session_index"`
	SessionGeneration    uint64  `json:"session_generation"`
	OpenCount            int     `json:"open_count"`
	EOFCount             int     `json:"eof_count"`
	ResetCount           int     `json:"reset_count"`
	StopCount            int     `json:"stop_count"`
	ClosedCount          int     `json:"closed_count"`
	WriteCalls           int     `json:"write_calls"`
	Source               int     `json:"source"`
	Ordinal              int     `json:"ordinal"`
	ConnectionIndex      int     `json:"connection_index"`
	SessionID            uint64  `json:"session_id"`
	StreamID             uint64  `json:"stream_id"`
	CommandID            uint64  `json:"command_id"`
	Direction            string  `json:"direction"`
	ReceivedHex          string  `json:"received_hex"`
	SentHex              string  `json:"sent_hex"`
	ReceivedLen          int     `json:"received_len"`
	SentLen              int     `json:"sent_len"`
	EOF                  bool    `json:"eof"`
	Finished             bool    `json:"finished"`
	ResetCode            *uint32 `json:"reset_code"`
	ResetFinalSize       *uint64 `json:"reset_final_size"`
	StopCode             *uint32 `json:"stop_code"`
	Closed               bool    `json:"closed"`
	WriteWouldBlock      int     `json:"write_would_block"`
	PartialWrites        int     `json:"partial_writes"`
	WritableCount        int     `json:"writable_count"`
}
type ControlReply struct {
	CommandID uint64 `json:"command_id"`
	OK        bool   `json:"ok"`
	Result    string `json:"result"`
}
type ServerReport struct {
	Overflow  bool             `json:"overflow"`
	Errors    []string         `json:"errors"`
	Sessions  []ServerSession  `json:"sessions"`
	Datagrams []ServerDatagram `json:"datagrams"`
	Ring      []ServerRing     `json:"ring"`
	Children  []ServerChild    `json:"children"`
	Commands  []ControlReply   `json:"commands"`
}

func streamPayload(source, ordinal, kind, size int) []byte {
	p := make([]byte, size)
	for i := range p {
		p[i] = byte(i*17 + source*7 + ordinal*3 + kind)
	}
	return p
}

func validateReport(r ServerReport) error {
	for _, s := range r.Sessions {
		if s.ConnectionIndex < 0 || s.Generation == 0 || s.SessionIndex < 0 || s.SessionGeneration == 0 {
			return errors.New("invalid or omitted positive sessiongeneration/index")
		}
	}
	for _, c := range r.Children {
		for _, count := range []int{c.OpenCount, c.EOFCount, c.ResetCount, c.StopCount, c.ClosedCount} {
			if count < 0 || count > 1 {
				return errors.New("duplicate or invalid child callback counter")
			}
		}
		if err := validateChildIdentity(c); err != nil {
			return err
		}
	}
	for _, d := range r.Datagrams {
		if d.ConnectionIndex < 0 || d.ConnectionGeneration == 0 {
			return errors.New("invalid callback connectiongeneration/index")
		}
	}
	for _, d := range r.Ring {
		if d.ConnectionIndex < 0 || d.ConnectionGeneration == 0 {
			return errors.New("invalid ring connectiongeneration/index")
		}
	}
	if r.Overflow || len(r.Errors) > 0 {
		return fmt.Errorf("server report overflow=%v errors=%v", r.Overflow, r.Errors)
	}
	if len(r.Sessions) > 8 || len(r.Children) > 32 || len(r.Datagrams) > 64 || len(r.Ring) > 64 || len(r.Commands) > 128 {
		return errors.New("report exceeds fixture bounds")
	}
	return nil
}

func validateDatagrams(r ServerReport, expected []RouteIdentity, separate bool) error {
	if err := validateReport(r); err != nil {
		return err
	}
	if err := validateClosedChildren(r.Children); err != nil {
		return err
	}
	if len(r.Sessions) != len(expected) || len(r.Datagrams) != 4*len(expected) || len(r.Ring) != 4*len(expected) {
		return errors.New("session/callback/ring counts differ from exact expected set")
	}
	sessions := make(map[RouteIdentity]ServerSession)
	connections := make(map[ConnectionIdentity]bool)
	sessionIDs := make(map[string]bool)
	for _, s := range r.Sessions {
		route := RouteIdentity{Source: s.Source, Ordinal: s.Ordinal}
		if _, exists := sessions[route]; exists {
			return errors.New("duplicate route session")
		}
		if !s.Open || !s.Closed || s.OpenCount != 1 || s.ClosedCount != 1 {
			return errors.New("session lifecycle must contain exactly one open and close")
		}
		key := fmt.Sprintf("%d/%d/%d", s.ConnectionIndex, s.Generation, s.SessionID)
		if sessionIDs[key] {
			return errors.New("duplicate connection/session identity")
		}
		sessionIDs[key] = true
		if s.Ordinal == 1 && s.SessionID != 0 {
			return errors.New("first CONNECT did not precede HTTP with SID0")
		}
		sessions[route] = s
		connections[ConnectionIdentity{s.ConnectionIndex, s.Generation}] = true
		if err := validateSessionSID(s, separate); err != nil {
			return err
		}
	}
	wantConnections := 1
	if separate {
		wantConnections = len(expected)
	}
	if len(connections) != wantConnections {
		return errors.New("connection namespace count mismatch")
	}
	for _, c := range r.Children {
		matched := false
		for _, s := range r.Sessions {
			if sameChildSession(c, s) {
				matched = true
				break
			}
		}
		if !matched {
			return errors.New("child fullsessionidentity mismatch")
		}
	}
	want := make(map[string]ServerSession)
	for _, route := range expected {
		s, ok := sessions[route]
		if !ok {
			return errors.New("expected route missing")
		}
		for seq := uint32(0); seq < 4; seq++ {
			p := makeDatagram(uint16(route.Source), uint16(route.Ordinal), seq)
			want[hex.EncodeToString(p[:])] = s
		}
	}
	seen := make(map[string]bool)
	for _, d := range r.Datagrams {
		s, ok := want[d.Hex]
		if !ok || seen[d.Hex] || d.Source != s.Source || d.Ordinal != s.Ordinal || d.ConnectionIndex != s.ConnectionIndex || d.ConnectionGeneration != s.Generation || d.SessionID != s.SessionID {
			return errors.New("callback payload missing, duplicated, or misrouted")
		}
		seen[d.Hex] = true
	}
	counts := make(map[ConnectionIdentity]uint64)
	for _, s := range r.Sessions {
		counts[ConnectionIdentity{s.ConnectionIndex, s.Generation}] += 4
	}
	seen = make(map[string]bool)
	ordinals := make(map[string]bool)
	for _, d := range r.Ring {
		s, ok := want[d.Hex]
		key := fmt.Sprintf("%d/%d/%d", d.ConnectionIndex, d.ConnectionGeneration, d.Sequence)
		if !ok || seen[d.Hex] || ordinals[key] || d.Sequence >= counts[ConnectionIdentity{d.ConnectionIndex, d.ConnectionGeneration}] || d.Source != s.Source || d.Ordinal != s.Ordinal || d.ConnectionIndex != s.ConnectionIndex || d.ConnectionGeneration != s.Generation || d.SessionID != s.SessionID {
			return errors.New("ring payload missing, duplicated, or misrouted")
		}
		seen[d.Hex] = true
		ordinals[key] = true
	}
	return nil
}

func decodeReport(data []byte) (ServerReport, error) {
	var report ServerReport
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(data, &fields); err != nil {
		return report, err
	}
	for _, name := range []string{"overflow", "errors", "sessions", "datagrams", "ring", "children", "commands"} {
		raw, ok := fields[name]
		if !ok || string(raw) == "null" {
			return report, fmt.Errorf("missing typed report field %s", name)
		}
	}
	if err := json.Unmarshal(data, &report); err != nil {
		return report, err
	}
	return report, validateReport(report)
}

func validateClosedChildren(children []ServerChild) error {
	identities := make(map[string]bool)
	for _, c := range children {
		if err := validateChildIdentity(c); err != nil {
			return err
		}
		key := fmt.Sprintf("%d/%d/%d", c.ConnectionIndex, c.SessionID, c.StreamID)
		if identities[key] {
			return errors.New("duplicate child connection/session/stream identity")
		}
		identities[key] = true
		if c.OpenCount != 1 || c.ClosedCount != 1 || !c.Closed {
			return errors.New("child requires exactly one open and close callback")
		}
		if c.EOFCount < 0 || c.EOFCount > 1 || c.EOF != (c.EOFCount == 1) {
			return errors.New("child EOF callback count mismatch")
		}
		if c.ResetCount < 0 || c.ResetCount > 1 || (c.ResetCode != nil) != (c.ResetCount == 1) {
			return errors.New("child reset callback count mismatch")
		}
		if c.StopCount < 0 || c.StopCount > 1 || (c.StopCode != nil) != (c.StopCount == 1) {
			return errors.New("child stop callback count mismatch")
		}
		received, err := hex.DecodeString(c.ReceivedHex)
		if err != nil {
			return err
		}
		sent, err := hex.DecodeString(c.SentHex)
		if err != nil {
			return err
		}
		if len(received) != c.ReceivedLen || len(sent) != c.SentLen || c.ReceivedLen > 8192 || c.SentLen > 8192 {
			return errors.New("child exact payload accounting mismatch")
		}
	}
	return nil
}

func sameChildSession(c ServerChild, s ServerSession) bool {
	return c.Source == s.Source && c.Ordinal == s.Ordinal && c.ConnectionIndex == s.ConnectionIndex && c.ConnectionGeneration == s.Generation && c.SessionID == s.SessionID && c.SessionIndex == s.SessionIndex && c.SessionGeneration == s.SessionGeneration
}
func flowBlockedChild(c ServerChild, s ServerSession, id uint64) bool {
	return sameChildSession(c, s) && c.CommandID == id && c.SentLen == 32 && !c.Finished && (c.WriteWouldBlock > 0 || c.PartialWrites > 0)
}
func validateSessionSID(s ServerSession, separate bool) error {
	if separate && s.SessionID != 0 {
		return errors.New("independentconnection CONNECT must useSID0")
	}
	if !separate && ((s.Ordinal == 1 && s.SessionID != 0) || (s.Ordinal == 2 && s.SessionID != 4)) {
		return errors.New("sameconnection CONNECT IDs must be0+4 beforeHTTP")
	}
	return nil
}

type ExpectedChild struct {
	Session        ServerSession `json:"session"`
	StreamID       uint64        `json:"stream_id"`
	CommandID      uint64        `json:"command_id"`
	Direction      string        `json:"direction"`
	ReceivedHex    string        `json:"received_hex"`
	SentHex        string        `json:"sent_hex"`
	EOF            bool          `json:"eof"`
	Finished       bool          `json:"finished"`
	ResetCode      *uint32       `json:"reset_code"`
	ResetFinalSize *uint64       `json:"reset_final_size"`
	ReceivedPrefix bool          `json:"received_prefix"`
}

func validateExpectedChildren(children []ServerChild, expected []ExpectedChild) error {
	if err := validateClosedChildren(children); err != nil {
		return err
	}
	if len(children) != len(expected) {
		return errors.New("actual child set differs from independently expected operations")
	}
	matched := make(map[int]bool)
	for _, want := range expected {
		index := -1
		for i, c := range children {
			if sameChildSession(c, want.Session) && c.StreamID == want.StreamID && c.CommandID == want.CommandID && c.Direction == want.Direction {
				if index != -1 {
					return errors.New("duplicate expected child identity")
				}
				index = i
			}
		}
		if index < 0 || matched[index] {
			return errors.New("missing child or wrong fullsession/stream/command/direction identity")
		}
		matched[index] = true
		c := children[index]
		receivedOK := c.ReceivedHex == want.ReceivedHex
		if want.ReceivedPrefix {
			receivedOK = len(c.ReceivedHex) <= len(want.ReceivedHex) && len(c.ReceivedHex)%2 == 0 && want.ReceivedHex[:len(c.ReceivedHex)] == c.ReceivedHex
		}
		if !receivedOK || c.SentHex != want.SentHex || c.EOF != want.EOF || c.Finished != want.Finished {
			return errors.New("expected child payload/EOF/FIN mismatch")
		}
		if (c.ResetCode == nil) != (want.ResetCode == nil) || (c.ResetFinalSize == nil) != (want.ResetFinalSize == nil) {
			return errors.New("expected child reset presence mismatch")
		}
		if want.ResetCode != nil && want.ResetFinalSize == nil {
			return errors.New("expected reset requires payloadfinalsize")
		}
		if want.ResetCode != nil && (*c.ResetCode != *want.ResetCode || *c.ResetFinalSize != *want.ResetFinalSize) {
			return errors.New("expected child resetcode/finalsize mismatch")
		}
		if c.StopCount != 0 || c.StopCode != nil {
			return errors.New("unexpected stop-sending callback")
		}
	}
	return nil
}

func validateChildIdentity(c ServerChild) error {
	if c.ConnectionIndex < 0 || c.ConnectionGeneration == 0 || c.SessionIndex < 0 || c.SessionGeneration == 0 {
		return errors.New("invalid or omitted positive childgeneration/index")
	}
	return nil
}

func finalReportReady(r ServerReport, expected []ExpectedChild, sessionCount int) bool {
	if len(r.Sessions) != sessionCount {
		return false
	}
	for _, s := range r.Sessions {
		if !s.Closed {
			return false
		}
	}
	for _, want := range expected {
		closed := false
		for _, c := range r.Children {
			if sameChildSession(c, want.Session) && c.StreamID == want.StreamID && c.CommandID == want.CommandID && c.Direction == want.Direction && c.Closed && c.ClosedCount == 1 {
				closed = true
				break
			}
		}
		if !closed {
			return false
		}
	}
	return true
}
