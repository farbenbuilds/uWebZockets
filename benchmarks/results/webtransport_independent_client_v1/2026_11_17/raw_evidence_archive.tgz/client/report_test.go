package main

import (
	"encoding/hex"
	"testing"
)

func TestPatternIncludesBinaryBytesAndRouteIdentity(t *testing.T) {
	got := streamPayload(1, 2, 41, 260)
	if len(got) != 260 || got[0] != 54 || got[12] != 2 || got[256] != 54 {
		t.Fatalf("wrong deterministic pattern: %x", got)
	}
	if string(got) == string(streamPayload(2, 2, 41, 260)) {
		t.Fatal("source missing from pattern")
	}
}

func TestDatagramReportRequiresExactCallbackAndRingIdentity(t *testing.T) {
	expected := []RouteIdentity{{Source: 1, Ordinal: 1}, {Source: 2, Ordinal: 1}}
	r := ServerReport{Sessions: []ServerSession{{Source: 1, Ordinal: 1, ConnectionIndex: 0, Generation: 1, SessionGeneration: 1, SessionID: 0, Open: true, Closed: true, OpenCount: 1, ClosedCount: 1}, {Source: 2, Ordinal: 1, ConnectionIndex: 1, Generation: 2, SessionGeneration: 2, SessionID: 0, Open: true, Closed: true, OpenCount: 1, ClosedCount: 1}}}
	for _, s := range r.Sessions {
		for seq := uint32(0); seq < 4; seq++ {
			p := makeDatagram(uint16(s.Source), uint16(s.Ordinal), seq)
			r.Datagrams = append(r.Datagrams, ServerDatagram{Source: s.Source, Ordinal: s.Ordinal, ConnectionIndex: s.ConnectionIndex, ConnectionGeneration: s.Generation, SessionID: 0, Hex: hex.EncodeToString(p[:])})
			r.Ring = append(r.Ring, ServerRing{Source: s.Source, Ordinal: s.Ordinal, ConnectionIndex: s.ConnectionIndex, ConnectionGeneration: s.Generation, Sequence: uint64(seq), SessionID: 0, Hex: hex.EncodeToString(p[:])})
		}
	}
	if err := validateDatagrams(r, expected, true); err != nil {
		t.Fatal(err)
	}
	for i := range r.Ring {
		r.Ring[i].Sequence += 100
	}
	if err := validateDatagrams(r, expected, true); err == nil {
		t.Fatal("accepted shifted ringordinals")
	}
	for i := range r.Ring {
		r.Ring[i].Sequence -= 100
	}
	r.Sessions[0].OpenCount = 2
	if err := validateDatagrams(r, expected, true); err == nil {
		t.Fatal("accepted duplicate session open callback")
	}
	r.Sessions[0].OpenCount = 1
	r.Ring[7].Hex = r.Ring[6].Hex
	if err := validateDatagrams(r, expected, true); err == nil {
		t.Fatal("accepted duplicate ring payload")
	}
}

func TestDatagramReportRejectsMisroutingAndOverflow(t *testing.T) {
	if err := validateDatagrams(ServerReport{Overflow: true}, nil, false); err == nil {
		t.Fatal("accepted overflow")
	}
	r := ServerReport{Sessions: []ServerSession{{Source: 1, Ordinal: 1, Open: true, Closed: true, OpenCount: 1, ClosedCount: 1}}, Datagrams: []ServerDatagram{{Source: 2, Ordinal: 1, Hex: "00"}}}
	if err := validateDatagrams(r, []RouteIdentity{{Source: 1, Ordinal: 1}}, false); err == nil {
		t.Fatal("accepted wrong callback identity")
	}
}

func TestReportDecoderRequiresTypedCompleteEnvelope(t *testing.T) {
	for _, bad := range []string{`{}`, `{"overflow":false,"errors":[],"sessions":[],"datagrams":[],"ring":[],"children":"","commands":[]}`} {
		if _, err := decodeReport([]byte(bad)); err == nil {
			t.Fatalf("accepted incomplete or untyped report %s", bad)
		}
	}
	if _, err := decodeReport([]byte(`{"overflow":false,"errors":[],"sessions":[],"datagrams":[],"ring":[],"children":[],"commands":[]}`)); err != nil {
		t.Fatal(err)
	}
}

func TestClosedChildrenRejectDuplicateLifecycleAndIdentity(t *testing.T) {
	child := ServerChild{Source: 1, Ordinal: 1, ConnectionGeneration: 1, SessionGeneration: 1, StreamID: 6, Direction: "peer_uni", EOF: true, Closed: true, OpenCount: 1, EOFCount: 1, ClosedCount: 1}
	if err := validateClosedChildren([]ServerChild{child}); err != nil {
		t.Fatal(err)
	}
	if err := validateClosedChildren([]ServerChild{child, child}); err == nil {
		t.Fatal("accepted duplicate child identity")
	}
	child.ClosedCount = 2
	if err := validateClosedChildren([]ServerChild{child}); err == nil {
		t.Fatal("accepted duplicate childclose")
	}
	child.ClosedCount = 1
	child.ResetCount = 1
	if err := validateClosedChildren([]ServerChild{child}); err == nil {
		t.Fatal("accepted reset callback without resetnotice")
	}
}

func TestFlowBarrierRequiresExactNegotiated32AndIdentity(t *testing.T) {
	s := ServerSession{Source: 1, Ordinal: 1, ConnectionIndex: 15, Generation: 2, SessionID: 0, SessionIndex: 7, SessionGeneration: 3}
	c := ServerChild{Source: 1, Ordinal: 1, ConnectionIndex: 15, ConnectionGeneration: 2, SessionID: 0, SessionIndex: 7, SessionGeneration: 3, CommandID: 1, SentLen: 32, WriteWouldBlock: 1}
	if !flowBlockedChild(c, s, 1) {
		t.Fatal("rejected exact32flowbarrier")
	}
	for _, n := range []int{0, 31} {
		c.SentLen = n
		if flowBlockedChild(c, s, 1) {
			t.Fatalf("accepted sentlen%d", n)
		}
	}
	c.SentLen = 32
	c.ConnectionGeneration++
	if flowBlockedChild(c, s, 1) {
		t.Fatal("accepted wrongconnectiongeneration")
	}
}

func TestSameConnectionSecondSIDMustBe4(t *testing.T) {
	if err := validateSessionSID(ServerSession{Ordinal: 1, SessionID: 0}, false); err != nil {
		t.Fatal(err)
	}
	if err := validateSessionSID(ServerSession{Ordinal: 2, SessionID: 4}, false); err != nil {
		t.Fatal(err)
	}
	if err := validateSessionSID(ServerSession{Ordinal: 2, SessionID: 8}, false); err == nil {
		t.Fatal("accepted wrong secondCONNECT SID")
	}
}

func TestExpectedChildrenRejectExtraAndWrongRetainedRoute(t *testing.T) {
	session := ServerSession{Source: 1, Ordinal: 1, ConnectionIndex: 15, Generation: 2, SessionID: 0, SessionIndex: 7, SessionGeneration: 3}
	child := ServerChild{Source: 1, Ordinal: 1, ConnectionIndex: 15, ConnectionGeneration: 2, SessionID: 0, SessionIndex: 7, SessionGeneration: 3, StreamID: 6, Direction: "peer_uni", OpenCount: 1, EOFCount: 1, EOF: true, ClosedCount: 1, Closed: true}
	expected := []ExpectedChild{{Session: session, StreamID: 6, Direction: "peer_uni", EOF: true}}
	if err := validateExpectedChildren([]ServerChild{child}, expected); err != nil {
		t.Fatal(err)
	}
	extra := child
	extra.StreamID = 10
	if err := validateExpectedChildren([]ServerChild{child, extra}, expected); err == nil {
		t.Fatal("accepted unsolicited closed child")
	}
	child.Ordinal = 2
	if err := validateExpectedChildren([]ServerChild{child}, expected); err == nil {
		t.Fatal("accepted wrong retained route")
	}
}

func TestReportRejectsOmittedAndZeroGenerations(t *testing.T) {
	for _, identity := range []string{
		`{"source":1,"ordinal":1,"connection_index":0,"session_index":0,"session_generation":1}`,
		`{"source":1,"ordinal":1,"connection_index":0,"generation":1,"session_index":0,"session_generation":0}`,
		`{"source":1,"ordinal":1,"connection_index":-1,"generation":1,"session_index":0,"session_generation":1}`,
	} {
		raw := []byte(`{"overflow":false,"errors":[],"sessions":[` + identity + `],"datagrams":[],"ring":[],"children":[],"commands":[]}`)
		if _, err := decodeReport(raw); err == nil {
			t.Fatalf("accepted missing or invalid generation/index %s", identity)
		}
	}
}

func TestFinalBarrierWaitsForExpectedNativeChildClose(t *testing.T) {
	identity := ServerSession{Source: 1, Ordinal: 1, ConnectionIndex: 0, Generation: 1, SessionIndex: 0, SessionGeneration: 1, SessionID: 0, Closed: true}
	expected := []ExpectedChild{{Session: identity, StreamID: 6, Direction: "peer_uni"}}
	child := ServerChild{Source: 1, Ordinal: 1, ConnectionIndex: 0, ConnectionGeneration: 1, SessionIndex: 0, SessionGeneration: 1, StreamID: 6, Direction: "peer_uni", OpenCount: 1}
	report := ServerReport{Sessions: []ServerSession{identity}, Children: []ServerChild{child}}
	if finalReportReady(report, expected, 1) {
		t.Fatal("logical sessionclose incorrectly bypassed pendingnativechild")
	}
	report.Children[0].Closed = true
	report.Children[0].ClosedCount = 1
	if !finalReportReady(report, expected, 1) {
		t.Fatal("exact expected nativeclose didnotreleasebarrier")
	}
	report.Children[0].ClosedCount = 2
	if err := validateReport(report); err == nil {
		t.Fatal("duplicate closecounter must fail immediately")
	}
}
