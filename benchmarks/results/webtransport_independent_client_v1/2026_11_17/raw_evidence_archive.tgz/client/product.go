package main

import (
	"context"
	"crypto/tls"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"time"

	quic "github.com/quic-go/quic-go"
	"github.com/quic-go/quic-go/http3"
	wt "github.com/quic-go/webtransport-go"
)

type ProductEvidence struct {
	ExpectedChildren []ExpectedChild  `json:"expected_children,omitempty"`
	SentResets       []WireReset      `json:"sent_reset_frames,omitempty"`
	RawReport        json.RawMessage  `json:"raw_report,omitempty"`
	Scenario         string           `json:"scenario"`
	Connections      []ClientEvidence `json:"connections"`
	Controls         []ControlReply   `json:"controls,omitempty"`
	Streams          []StreamEvidence `json:"streams,omitempty"`
	Barriers         []string         `json:"barriers"`
	Reports          []ServerReport   `json:"reports"`
	HealthStatuses   []int            `json:"same_connection_health_statuses"`
	Reconciled       bool             `json:"server_report_reconciled"`
}
type StreamEvidence struct {
	Kind       string `json:"kind"`
	Source     int    `json:"source"`
	Ordinal    int    `json:"ordinal"`
	StreamID   uint64 `json:"stream_id"`
	WrittenHex string `json:"written_hex,omitempty"`
	ReadHex    string `json:"read_hex,omitempty"`
	EOF        bool   `json:"eof"`
}
type DeadlineStop func() bool
type OwnedClient struct {
	ResetTrace    *ResetTrace
	LastRawReport json.RawMessage
	StopDeadline  DeadlineStop
	LastReport    *ServerReport
	Socket        *net.UDPConn
	Transport     *quic.Transport
	Conn          *quic.Conn
	WT            *wt.Transport
	HTTP          *wt.ClientConn
	Sessions      []*wt.Session
	Evidence      ClientEvidence
	URL           *url.URL
}
type ProductSession struct {
	Identity ServerSession
	Client   *OwnedClient
	Session  *wt.Session
	Route    RouteIdentity
}
type ReportPredicate func(ServerReport) bool

func connectProduct(ctx context.Context, o Options) (c *OwnedClient, err error) {
	u, err := validateClient(o)
	if err != nil {
		return nil, err
	}
	tlsConf, err := clientTLS(o.CA)
	if err != nil {
		return nil, err
	}
	remote, err := net.ResolveUDPAddr("udp4", u.Host)
	if err != nil {
		return nil, err
	}
	socket, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1)})
	if err != nil {
		return nil, err
	}
	c = &OwnedClient{Socket: socket, URL: u}
	c.Transport = &quic.Transport{Conn: socket}
	defer func() {
		if err != nil {
			err = errors.Join(err, closeProduct(c))
		}
	}()
	c.ResetTrace = newResetTrace()
	c.Conn, err = c.Transport.Dial(ctx, remote, tlsConf, traceQUICConfig(c.ResetTrace))
	if err != nil {
		return c, err
	}
	c.StopDeadline = context.AfterFunc(ctx, func() { c.Conn.CloseWithError(quic.ApplicationErrorCode(http3.ErrCodeNoError), "oracle deadline") })
	state := c.Conn.ConnectionState()
	c.Evidence = ClientEvidence{URL: o.URL, Origin: o.Origin, FlowControl: o.Flow, ProtocolExpected: "webtransport-h3", Scope: "public_app_report_reconciliation", ConnectionCount: 1, TLSVersion: state.TLS.Version, ALPN: state.TLS.NegotiatedProtocol, ExplicitCAVerified: len(state.TLS.VerifiedChains) > 0, LocalDatagrams: state.SupportsDatagrams.Local, RemoteDatagrams: state.SupportsDatagrams.Remote, LocalPartialReset: state.SupportsStreamResetPartialDelivery.Local, RemotePartialReset: state.SupportsStreamResetPartialDelivery.Remote}
	e := c.Evidence
	if e.TLSVersion != tls.VersionTLS13 || e.ALPN != "h3" || !e.ExplicitCAVerified || !e.LocalDatagrams || !e.RemoteDatagrams || !e.LocalPartialReset || !e.RemotePartialReset {
		return c, errors.New("TLS/ALPN/CA/DATAGRAM/partial-reset negotiation failed")
	}
	fc := flowConfig(o.Flow)
	if o.Flow == "on" {
		fc.MaxIncomingData = 32
	}
	c.WT = &wt.Transport{Config: fc}
	c.HTTP, err = c.WT.NewClientConn(c.Conn)
	return c, err
}

func closeProduct(c *OwnedClient) error {
	if c == nil {
		return nil
	}
	var err error
	if c.StopDeadline != nil {
		c.StopDeadline()
	}
	for _, s := range c.Sessions {
		err = errors.Join(err, s.CloseWithError(0, ""))
	}
	if c.Conn != nil {
		err = errors.Join(err, c.Conn.CloseWithError(quic.ApplicationErrorCode(http3.ErrCodeNoError), "oracle complete"))
	}
	if c.WT != nil {
		err = errors.Join(err, c.WT.Close())
	}
	if c.Transport != nil {
		err = errors.Join(err, c.Transport.Close())
	}
	if c.Socket != nil {
		err = errors.Join(err, c.Socket.Close())
	}
	return err
}

func dialProduct(ctx context.Context, c *OwnedClient, o Options, path string, route RouteIdentity) (ProductSession, error) {
	u := *c.URL
	u.Path = path
	u.RawQuery = ""
	response, s, err := c.HTTP.Dial(ctx, u.String(), http.Header{"Origin": []string{o.Origin}})
	if err != nil {
		return ProductSession{}, err
	}
	if response.StatusCode != http.StatusOK {
		return ProductSession{}, fmt.Errorf("CONNECT status %d", response.StatusCode)
	}
	c.Sessions = append(c.Sessions, s)
	c.Evidence.Sessions = append(c.Evidence.Sessions, SessionEvidence{Ordinal: route.Ordinal, Status: response.StatusCode, AdmissionVerified: true})
	return ProductSession{Client: c, Session: s, Route: route}, nil
}

func getProduct(ctx context.Context, c *OwnedClient, path string) ([]byte, int, error) {
	u := *c.URL
	parsed, err := url.ParseRequestURI(path)
	if err != nil {
		return nil, 0, err
	}
	u.Path, u.RawQuery = parsed.Path, parsed.RawQuery
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	if err != nil {
		return nil, 0, err
	}
	response, err := c.HTTP.RoundTrip(req)
	if err != nil {
		return nil, 0, err
	}
	body, readErr := io.ReadAll(io.LimitReader(response.Body, 1024*1024+1))
	closeErr := response.Body.Close()
	if readErr != nil || closeErr != nil {
		return nil, response.StatusCode, errors.Join(readErr, closeErr)
	}
	if response.StatusCode != 200 || len(body) > 1024*1024 {
		return nil, response.StatusCode, fmt.Errorf("bounded GET %s status=%d bytes=%d", path, response.StatusCode, len(body))
	}
	return body, response.StatusCode, nil
}

func getReport(ctx context.Context, c *OwnedClient) (ServerReport, error) {
	var report ServerReport
	data, _, err := getProduct(ctx, c, "/report")
	if err != nil {
		return report, err
	}
	c.LastRawReport = append(json.RawMessage(nil), data...)
	report, err = decodeReport(data)
	if err != nil {
		return report, err
	}
	c.LastReport = &report
	return report, nil
}

func awaitReport(ctx context.Context, c *OwnedClient, condition ReportPredicate) (ServerReport, error) {
	for ctx.Err() == nil {
		r, err := getReport(ctx, c)
		if err != nil {
			return r, err
		}
		if condition(r) {
			return r, nil
		}
	}
	return ServerReport{}, ctx.Err()
}

func command(ctx context.Context, s ProductSession, op string, size int, hold bool, id uint64) (ControlReply, error) {
	q := url.Values{"source": []string{strconv.Itoa(s.Route.Source)}, "ordinal": []string{strconv.Itoa(s.Route.Ordinal)}, "op": []string{op}}
	if size >= 0 {
		q.Set("size", strconv.Itoa(size))
	}
	if hold {
		q.Set("hold", "1")
	} else {
		q.Set("hold", "0")
	}
	if id != 0 {
		q.Set("command_id", strconv.FormatUint(id, 10))
	}
	data, _, err := getProduct(ctx, s.Client, "/control?"+q.Encode())
	if err != nil {
		return ControlReply{}, err
	}
	var reply ControlReply
	if err := json.Unmarshal(data, &reply); err != nil {
		return reply, err
	}
	if reply.CommandID == 0 || (reply.Result != "ok" && reply.Result != "would_block") {
		return reply, fmt.Errorf("control rejected: %s", data)
	}
	if reply.OK != (reply.Result == "ok") {
		return reply, errors.New("inconsistent control result")
	}
	return reply, nil
}

func runProduct(ctx context.Context, o Options) (e ProductEvidence, err error) {
	e.Scenario = o.Scenario
	first, err := connectProduct(ctx, o)
	if err != nil {
		return e, err
	}
	clients := []*OwnedClient{first}
	defer func() {
		for _, c := range clients {
			if err != nil && e.RawReport == nil && c.LastRawReport != nil {
				e.RawReport = c.LastRawReport
			}
			if err != nil && c.LastReport != nil {
				e.Reports = append(e.Reports, *c.LastReport)
			}
			err = errors.Join(err, closeProduct(c))
			c.Evidence.ConnectionClosed = true
			c.Evidence.Pass = err == nil
			e.Connections = append(e.Connections, c.Evidence)
		}
	}()
	sessions := make([]ProductSession, 0, 2)
	if o.Scenario == "connections" {
		second, connectErr := connectProduct(ctx, o)
		if connectErr != nil {
			return e, connectErr
		}
		clients = append(clients, second)
		a, dialErr := dialProduct(ctx, first, o, "/wt", RouteIdentity{1, 1})
		if dialErr != nil {
			return e, dialErr
		}
		b, dialErr := dialProduct(ctx, second, o, "/namespace", RouteIdentity{2, 1})
		if dialErr != nil {
			return e, dialErr
		}
		sessions = append(sessions, a, b)
	} else {
		path := first.URL.Path
		if path != "/wt" && path != "/namespace" {
			return e, errors.New("product first route must be /wt or /namespace")
		}
		source := 1
		if path == "/namespace" {
			source = 2
		}
		a, dialErr := dialProduct(ctx, first, o, path, RouteIdentity{source, 1})
		if dialErr != nil {
			return e, dialErr
		}
		sessions = append(sessions, a)
		if o.Sessions == 2 || o.Scenario == "isolation" {
			other := "/other"
			if source == 2 {
				other = "/namespace-other"
			}
			b, dialErr := dialProduct(ctx, first, o, other, RouteIdentity{source, 2})
			if dialErr != nil {
				return e, dialErr
			}
			sessions = append(sessions, b)
		}
	}
	routes := make([]RouteIdentity, 0, len(sessions))
	for _, s := range sessions {
		routes = append(routes, s.Route)
		for seq := uint32(0); seq < 4; seq++ {
			p := makeDatagram(uint16(s.Route.Source), uint16(s.Route.Ordinal), seq)
			if err := s.Session.SendDatagram(p[:]); err != nil {
				return e, err
			}
		}
	}
	dgReport, barrierErr := awaitReport(ctx, first, func(r ServerReport) bool {
		return len(r.Datagrams) == len(sessions)*4 && len(r.Ring) == len(sessions)*4
	})
	if barrierErr != nil {
		return e, barrierErr
	}
	for i := range sessions {
		found := false
		for _, identity := range dgReport.Sessions {
			if identity.Source == sessions[i].Route.Source && identity.Ordinal == sessions[i].Route.Ordinal {
				if found {
					return e, errors.New("ambiguous initialsession route")
				}
				sessions[i].Identity = identity
				found = true
			}
		}
		if !found {
			return e, errors.New("initialsession identitymissing")
		}
	}
	e.Barriers = append(e.Barriers, "all exact datagram callback and ring receipts observed")
	switch o.Scenario {
	case "datagrams", "connections":
	case "streams":
		err = productStreams(ctx, &e, sessions[0])
	case "reset":
		err = productReset(ctx, &e, sessions[0])
	case "flow":
		err = productFlow(ctx, &e, sessions[0])
	case "credit":
		err = productCredit(ctx, &e, sessions[0])
	case "isolation":
		err = productIsolation(ctx, &e, sessions[0], sessions[1])
	default:
		err = errors.New("unknown product scenario")
	}
	if err != nil {
		return e, err
	}
	for _, c := range clients {
		_, status, healthErr := getProduct(ctx, c, "/health")
		if healthErr != nil {
			return e, healthErr
		}
		e.HealthStatuses = append(e.HealthStatuses, status)
	}
	for _, s := range sessions {
		if err := s.Session.CloseWithError(0, ""); err != nil {
			return e, err
		}
	}
	report, err := awaitReport(ctx, first, func(r ServerReport) bool {
		return finalReportReady(r, e.ExpectedChildren, len(sessions))
	})
	if err != nil {
		return e, err
	}
	if err := validateExpectedChildren(report.Children, e.ExpectedChildren); err != nil {
		return e, err
	}
	if err := validateDatagrams(report, routes, o.Scenario == "connections"); err != nil {
		return e, err
	}
	e.Reports = append(e.Reports, report)
	e.RawReport = first.LastRawReport
	e.Reconciled = true
	return e, nil
}

func deadline(ctx context.Context) time.Time { d, _ := ctx.Deadline(); return d }
func exactRead(reader io.Reader, expected []byte) ([]byte, error) {
	data, err := io.ReadAll(io.LimitReader(reader, int64(len(expected)+1)))
	if err != nil {
		return data, err
	}
	if hex.EncodeToString(data) != hex.EncodeToString(expected) {
		return data, fmt.Errorf("payload mismatch got=%x want=%x", data, expected)
	}
	return data, nil
}

func runInspect(ctx context.Context, o Options) (e ProductEvidence, err error) {
	e.Scenario = "retained_report_via_separate_http_connection"
	c, err := connectProduct(ctx, o)
	if err != nil {
		return e, err
	}
	defer func() { err = errors.Join(err, closeProduct(c)) }()
	data, _, err := getProduct(ctx, c, "/report")
	if err != nil {
		return e, err
	}
	e.RawReport = data
	var report ServerReport
	if err := json.Unmarshal(data, &report); err != nil {
		return e, err
	}
	e.Reports = append(e.Reports, report)
	return e, nil
}
