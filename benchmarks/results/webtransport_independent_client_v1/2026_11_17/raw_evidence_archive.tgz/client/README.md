# Pinned official draft-16 client fixture

Owned temporary client for `/tmp/uwz-wt-independent-client-20261117/CONTRACT.md`.
No production source or frozen dependency source is modified. Original oracle
sources and historical artifacts under `/tmp/uwz-webtransport-oracle-20261111`
are preserved. Copied module and build caches are isolated from that fixture.

Inputs: official webtransport-go `2a2b547d91a8a70e313e7ce61538b066554021b5`,
quic-go v0.62.0 `793f74d8e03368c5aded128af6f48d21dbb47f73`, Go 1.26.8 at
`/usr/local/go/bin/go`. `go-local.sh` disables network module resolution and VCS
stamping; module verification is recorded in `logs/module-verify.log`.

Build and ordinary checks:

```sh
./go-local.sh test ./...
./go-local.sh vet ./...
./go-local.sh mod verify
./go-local.sh build -o wt-oracle .
./go-local.sh build -o wt-tools ./tools
```

Fresh PKI is generated into a new owned directory with mode 0700; PEM files are
mode 0600. The CA private key exists only in memory while signing. The server
certificate contains localhost and 127.0.0.1 SANs. Never archive the PKI directory,
private keys, certificates, caches, or credentials into product evidence.

```sh
./wt-tools pki /tmp/uwz-wt-independent-client-20261117/client/pki-fresh
./wt-tools port
./wt-tools port 52311
```

The port helper checks a loopback UDP bind and releases it; the server's later
explicit bind is authoritative. Loopback invocations require sandbox escalation.
Only start a client after the server owner reports ready. Each case timeout is
at most 60s. The server must start fresh for each case because reports retain
all observations and the client enforces exact sets.

```sh
./wt-oracle product --scenario streams \
  --url https://127.0.0.1:52311/wt --origin https://127.0.0.1:52311 \
  --ca pki/ca.pem --flow-control on --sessions 1 --timeout 45s
```

Positive scenarios are `datagrams` (sessions 2), `streams`, `reset`, `flow`,
`credit`, `isolation` (sessions 2), and `connections` (sessions 2). Run datagrams
with `/namespace` and sessions 2 to cover `/namespace` plus `/namespace-other`.
Run legacy datagrams with server legacy profile, flow-control off, sessions 1.
Connections opens `/wt` and `/namespace` on two independent owned connections;
both CONNECTs precede HTTP and must use SID 0. Shared connection sessions open
`/wt`+`/other` or `/namespace`+`/namespace-other` before HTTP and require SID 0+4.

Same owned `ClientConn.RoundTrip` serves `/report`, `/control`, and `/health`.
Actual callback and ring receipts, connection generations, route namespaces,
exact child identities and exact callback counts must reconcile before
`product_interop_verified` can be true. Ring sequence is the public connection
wide delivery ordinal and must form 0..N-1; payload delivery order may vary.
Flow barriers require exactly 32 sent bytes with partial/WouldBlock before reads.
Credit tests explicitly retry a rejected command after consuming the held child.

Reset evidence retains only reset metadata from the official public qlog
`PacketSent` callback. A reset case must observe a transmitted RESET_STREAM_AT
with reliable size equal to the WT header. The application final size excludes
the header. If the 24 byte case falls back after header ACK, an immediate public
CancelWrite case proves the header-only reliable boundary. No arbitrary body
reliability is claimed and no client private state or native windows are changed.

`selftest` preserves the old pinned Go admission/echo controls;
`public-selftest` exercises ordinary public UNI/BIDI APIs in both directions
with data 32/count 1, binary 260 byte bodies plus FIN and reverse BIDI 19 bytes.
Their product interop flag stays false. `client` is the historical
admission/enqueue mode, whose server-delivery flag stays false. `inspect`
collects a retained report through a separate HTTP connection for the unchanged
baseline; it does not claim same-connection report evidence or product interop.

First-attempt product logs predate later strict lifecycle and identity checks.
They remain provisional. Root owns the final serialized matrix, its exact
commands/statuses, archived source selection, project documentation and delivery.
Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain deferred.
