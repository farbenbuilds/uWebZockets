#!/bin/sh
set -eu
oracle_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec env GOFLAGS=-buildvcs=false GOENV=off GOTOOLCHAIN=local GOPATH="$oracle_dir/gopath" \
  GOMODCACHE="$oracle_dir/gopath/pkg/mod" GOCACHE="$oracle_dir/cache" \
  TMPDIR="$oracle_dir/tmp" GOPROXY=off GOSUMDB=off /usr/local/go/bin/go "$@"
