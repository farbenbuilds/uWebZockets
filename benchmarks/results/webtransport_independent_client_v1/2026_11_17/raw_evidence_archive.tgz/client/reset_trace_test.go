package main

import (
	"github.com/quic-go/quic-go/qlog"
	"testing"
)

func TestResetTracerRequiresSentPartialFrame(t *testing.T) {
	state := newResetTrace()
	recorder := state.AddProducer()
	recorder.RecordEvent(qlog.PacketReceived{Frames: []qlog.Frame{{Frame: &qlog.ResetStreamFrame{StreamID: 6, ErrorCode: 99, FinalSize: 27, ReliableSize: 3}}}})
	if len(snapshotResets(state)) != 0 {
		t.Fatal("counted received frame as transmitted")
	}
	recorder.RecordEvent(qlog.PacketSent{Frames: []qlog.Frame{{Frame: &qlog.ResetStreamFrame{StreamID: 6, ErrorCode: 99, FinalSize: 27}}}})
	got := snapshotResets(state)
	if len(got) != 1 || got[0].FrameType != "reset_stream" {
		t.Fatal("ordinary reset misclassified")
	}
	recorder.RecordEvent(qlog.PacketSent{Frames: []qlog.Frame{{Frame: &qlog.ResetStreamFrame{StreamID: 10, ErrorCode: 100, FinalSize: 3, ReliableSize: 3}}}})
	got = snapshotResets(state)
	if len(got) != 2 || got[1].FrameType != "reset_stream_at" || got[1].ReliableSize != 3 {
		t.Fatal("missing transmitted reliable reset")
	}
}

func TestResetWireValidatorRequiresMappedCodeAndExactHeaderBoundary(t *testing.T) {
	const code = uint32(0x1234)
	mapped := uint64(0x52e4a40fa8db) + uint64(code) + uint64(code)/30
	frame := WireReset{FrameType: "reset_stream_at", StreamID: 6, ErrorCode: mapped, FinalSize: 27, ReliableSize: 3}
	if err := validateResetWire(frame, 6, code, 24); err != nil {
		t.Fatal(err)
	}
	frame.ReliableSize = 4
	if err := validateResetWire(frame, 6, code, 24); err == nil {
		t.Fatal("accepted arbitrary body reliableboundary")
	}
	frame.ReliableSize = 3
	frame.ErrorCode++
	if err := validateResetWire(frame, 6, code, 24); err == nil {
		t.Fatal("accepted unmapped resetcode")
	}
	frame.ErrorCode = mapped
	frame.FinalSize = 24
	if err := validateResetWire(frame, 6, code, 24); err == nil {
		t.Fatal("accepted wirefinalsize without WTheader")
	}
}
