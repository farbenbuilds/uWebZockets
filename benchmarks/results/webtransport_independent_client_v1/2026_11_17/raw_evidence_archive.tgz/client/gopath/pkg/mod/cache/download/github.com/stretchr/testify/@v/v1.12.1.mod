module github.com/stretchr/testify

// This should match the minimum supported version that is tested in
// .github/workflows/main.yml
go 1.17

require (
	github.com/stretchr/objx v0.5.3
	go.yaml.in/yaml/v3 v3.0.5
)
