package main

import (
	"context"
	"errors"
	"sync"

	quic "github.com/quic-go/quic-go"
	"github.com/quic-go/quic-go/qlog"
	"github.com/quic-go/quic-go/qlogwriter"
)

type WireReset struct {
	FrameType    string `json:"frame_type"`
	StreamID     uint64 `json:"stream_id"`
	ErrorCode    uint64 `json:"error_code"`
	FinalSize    uint64 `json:"final_size"`
	ReliableSize uint64 `json:"reliable_size"`
}
type ResetTrace struct {
	Mutex    sync.Mutex
	Frames   []WireReset
	Overflow bool
	Changed  chan struct{}
}
type ResetRecorder struct{ State *ResetTrace }

func newResetTrace() *ResetTrace { return &ResetTrace{Changed: make(chan struct{}, 1)} }

// These methods implement the official qlog observer contract; only sent reset metadata is retained.
func (s *ResetTrace) AddProducer() qlogwriter.Recorder   { return &ResetRecorder{State: s} }
func (s *ResetTrace) SupportsSchemas(schema string) bool { return schema == qlog.EventSchema }
func (r *ResetRecorder) Close() error                    { return nil }
func (r *ResetRecorder) RecordEvent(event qlogwriter.Event) {
	sent, ok := event.(qlog.PacketSent)
	if !ok {
		return
	}
	for _, frame := range sent.Frames {
		reset, ok := frame.Frame.(*qlog.ResetStreamFrame)
		if !ok {
			continue
		}
		kind := "reset_stream"
		if reset.ReliableSize > 0 {
			kind = "reset_stream_at"
		}
		observed := WireReset{FrameType: kind, StreamID: uint64(reset.StreamID), ErrorCode: uint64(reset.ErrorCode), FinalSize: uint64(reset.FinalSize), ReliableSize: uint64(reset.ReliableSize)}
		r.State.Mutex.Lock()
		if len(r.State.Frames) >= 64 {
			r.State.Overflow = true
		} else {
			r.State.Frames = append(r.State.Frames, observed)
		}
		r.State.Mutex.Unlock()
		select {
		case r.State.Changed <- struct{}{}:
		default:
		}
	}
}

func snapshotResets(s *ResetTrace) []WireReset {
	s.Mutex.Lock()
	defer s.Mutex.Unlock()
	return append([]WireReset(nil), s.Frames...)
}
func awaitReset(ctx context.Context, s *ResetTrace, id uint64) (WireReset, error) {
	for {
		s.Mutex.Lock()
		overflow := s.Overflow
		s.Mutex.Unlock()
		if overflow {
			return WireReset{}, errors.New("reset trace overflow")
		}
		for _, frame := range snapshotResets(s) {
			if frame.StreamID == id {
				return frame, nil
			}
		}
		select {
		case <-s.Changed:
		case <-ctx.Done():
			return WireReset{}, ctx.Err()
		}
	}
}
func traceQUICConfig(state *ResetTrace) *quic.Config {
	config := quicConfig()
	config.Tracer = func(_ context.Context, _ bool, _ quic.ConnectionID) qlogwriter.Trace { return state }
	return config
}

func validateResetWire(frame WireReset, id uint64, code uint32, payloadSize int) error {
	mapped := uint64(0x52e4a40fa8db) + uint64(code) + uint64(code)/0x1e
	if frame.StreamID != id || frame.ErrorCode != mapped || frame.FinalSize < uint64(payloadSize) {
		return errors.New("sent reset stream/code/finalsize mismatch")
	}
	headerSize := frame.FinalSize - uint64(payloadSize)
	if headerSize == 0 || headerSize > 16 {
		return errors.New("reset wirefinalsize doesnot include bounded WT header")
	}
	if frame.FrameType == "reset_stream_at" && frame.ReliableSize != headerSize {
		return errors.New("reset reliableboundary isnot exact WT header")
	}
	return nil
}
