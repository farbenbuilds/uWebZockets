package main

import (
	"context"
	"encoding/hex"
	"errors"
	"fmt"
	"net"
	"net/http"

	quic "github.com/quic-go/quic-go"
	"github.com/quic-go/quic-go/http3"
	wt "github.com/quic-go/webtransport-go"
)

func runPublicControl(ctx context.Context, o Options) (e ProductEvidence, err error) {
	e.Scenario = "official_go_public_stream_controls"
	tlsConf, err := serverTLS(o.Cert, o.Key)
	if err != nil {
		return e, err
	}
	socket, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1)})
	if err != nil {
		return e, err
	}
	transport := &quic.Transport{Conn: socket}
	defer func() { err = errors.Join(err, transport.Close(), socket.Close()) }()
	listener, err := transport.Listen(tlsConf, quicConfig())
	if err != nil {
		return e, err
	}
	defer func() { err = errors.Join(err, listener.Close()) }()
	o.URL = "https://" + listener.Addr().String() + "/wt"
	o.Origin = "https://" + listener.Addr().String()
	o.Flow = "on"
	o.Sessions = 1
	h3 := &http3.Server{TLSConfig: tlsConf, EnableDatagrams: true}
	server := &wt.Server{H3: h3, Config: &wt.Config{MaxIncomingStreams: 1, MaxIncomingUniStreams: 1, MaxIncomingData: 32}, CheckOrigin: func(r *http.Request) bool { return r.Header.Get("Origin") == o.Origin }}
	defer func() { err = errors.Join(err, server.Close()) }()
	accepted := make(chan *wt.Session, 1)
	handlerErr := make(chan error, 1)
	h3.Handler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodConnect || r.URL.Path != "/wt" {
			http.Error(w, "rejected", http.StatusBadRequest)
			return
		}
		s, upgradeErr := server.Upgrade(w, r)
		if upgradeErr != nil {
			handlerErr <- upgradeErr
			return
		}
		accepted <- s
	})
	serveDone := make(chan error, 1)
	go func() {
		conn, acceptErr := listener.Accept(ctx)
		if acceptErr != nil {
			serveDone <- acceptErr
			return
		}
		stop := context.AfterFunc(ctx, func() { conn.CloseWithError(quic.ApplicationErrorCode(http3.ErrCodeNoError), "control deadline") })
		defer stop()
		serveDone <- server.ServeQUICConn(conn)
	}()
	client, err := connectProduct(ctx, o)
	if err != nil {
		return e, err
	}
	defer func() { err = errors.Join(err, closeProduct(client)) }()
	ps, err := dialProduct(ctx, client, o, "/wt", RouteIdentity{1, 1})
	if err != nil {
		return e, err
	}
	var peer *wt.Session
	select {
	case peer = <-accepted:
	case err := <-handlerErr:
		return e, err
	case <-ctx.Done():
		return e, ctx.Err()
	}
	results := make(chan error, 1)
	go func() { results <- publicControlPeer(ctx, peer) }()
	for _, kind := range []string{"uni", "bidi"} {
		payload := streamPayload(1, 1, 101, 260)
		if kind == "uni" {
			stream, openErr := ps.Session.OpenUniStreamSync(ctx)
			if openErr != nil {
				return e, openErr
			}
			if err := stream.SetWriteDeadline(deadline(ctx)); err != nil {
				return e, err
			}
			n, writeErr := stream.Write(payload)
			if writeErr != nil || n != len(payload) {
				return e, errors.Join(writeErr, errors.New("control uni write incomplete"))
			}
			if err := stream.Close(); err != nil {
				return e, err
			}
			e.Streams = append(e.Streams, StreamEvidence{Kind: "peer_uni", StreamID: uint64(stream.StreamID()), WrittenHex: hex.EncodeToString(payload), EOF: true})
		} else {
			stream, openErr := ps.Session.OpenStreamSync(ctx)
			if openErr != nil {
				return e, openErr
			}
			if err := stream.SetDeadline(deadline(ctx)); err != nil {
				return e, err
			}
			n, writeErr := stream.Write(payload)
			if writeErr != nil || n != len(payload) {
				return e, errors.Join(writeErr, errors.New("control bidi write incomplete"))
			}
			if err := stream.Close(); err != nil {
				return e, err
			}
			received, readErr := exactRead(stream, payload)
			if readErr != nil {
				return e, readErr
			}
			e.Streams = append(e.Streams, StreamEvidence{Kind: "peer_bidi", StreamID: uint64(stream.StreamID()), WrittenHex: hex.EncodeToString(payload), ReadHex: hex.EncodeToString(received), EOF: true})
		}
	}
	stream, err := ps.Session.AcceptUniStream(ctx)
	if err != nil {
		return e, err
	}
	if err := stream.SetReadDeadline(deadline(ctx)); err != nil {
		return e, err
	}
	payload := streamPayload(1, 1, 41, 260)
	received, err := exactRead(stream, payload)
	if err != nil {
		return e, err
	}
	e.Streams = append(e.Streams, StreamEvidence{Kind: "local_uni", StreamID: uint64(stream.StreamID()), ReadHex: hex.EncodeToString(received), EOF: true})
	bidi, err := ps.Session.AcceptStream(ctx)
	if err != nil {
		return e, err
	}
	if err := bidi.SetDeadline(deadline(ctx)); err != nil {
		return e, err
	}
	reverse := streamPayload(1, 1, 137, 19)
	n, err := bidi.Write(reverse)
	if err != nil || n != len(reverse) {
		return e, errors.Join(err, errors.New("control reverse incomplete"))
	}
	if err := bidi.Close(); err != nil {
		return e, err
	}
	received, err = exactRead(bidi, streamPayload(1, 1, 73, 260))
	if err != nil {
		return e, err
	}
	e.Streams = append(e.Streams, StreamEvidence{Kind: "local_bidi", StreamID: uint64(bidi.StreamID()), WrittenHex: hex.EncodeToString(reverse), ReadHex: hex.EncodeToString(received), EOF: true})
	select {
	case err := <-results:
		if err != nil {
			return e, err
		}
	case <-ctx.Done():
		return e, ctx.Err()
	}
	if err := client.Conn.CloseWithError(quic.ApplicationErrorCode(http3.ErrCodeNoError), "control complete"); err != nil {
		return e, err
	}
	serveErr := <-serveDone
	var app *quic.ApplicationError
	if serveErr != nil && !(errors.As(serveErr, &app) && app.Remote && app.ErrorCode == quic.ApplicationErrorCode(http3.ErrCodeNoError)) && !errors.Is(serveErr, http.ErrServerClosed) {
		return e, serveErr
	}
	e.Barriers = append(e.Barriers, "official public UNI/BIDI bothdirections exact260byte binaryFIN and reverseBIDI19bytes with data32 and count1")
	e.Connections = append(e.Connections, client.Evidence)
	return e, nil
}

func publicControlPeer(ctx context.Context, s *wt.Session) error {
	uni, err := s.AcceptUniStream(ctx)
	if err != nil {
		return err
	}
	if err := uni.SetReadDeadline(deadline(ctx)); err != nil {
		return err
	}
	if _, err := exactRead(uni, streamPayload(1, 1, 101, 260)); err != nil {
		return err
	}
	bidi, err := s.AcceptStream(ctx)
	if err != nil {
		return err
	}
	if err := bidi.SetDeadline(deadline(ctx)); err != nil {
		return err
	}
	payload, err := exactRead(bidi, streamPayload(1, 1, 101, 260))
	if err != nil {
		return err
	}
	n, err := bidi.Write(payload)
	if err != nil || n != len(payload) {
		return errors.Join(err, fmt.Errorf("control echo wrote%d", n))
	}
	if err := bidi.Close(); err != nil {
		return err
	}
	out, err := s.OpenUniStreamSync(ctx)
	if err != nil {
		return err
	}
	if err := out.SetWriteDeadline(deadline(ctx)); err != nil {
		return err
	}
	payload = streamPayload(1, 1, 41, 260)
	n, err = out.Write(payload)
	if err != nil || n != len(payload) {
		return errors.Join(err, errors.New("control local uni incomplete"))
	}
	if err := out.Close(); err != nil {
		return err
	}
	outBidi, err := s.OpenStreamSync(ctx)
	if err != nil {
		return err
	}
	if err := outBidi.SetDeadline(deadline(ctx)); err != nil {
		return err
	}
	// Read reverse direction concurrently so DATA32 cannot deadlock either writer.
	reverseDone := make(chan error, 1)
	go func() { _, readErr := exactRead(outBidi, streamPayload(1, 1, 137, 19)); reverseDone <- readErr }()
	payload = streamPayload(1, 1, 73, 260)
	n, err = outBidi.Write(payload)
	if err != nil || n != len(payload) {
		return errors.Join(err, errors.New("control local bidi incomplete"))
	}
	if err := outBidi.Close(); err != nil {
		return err
	}
	select {
	case err := <-reverseDone:
		return err
	case <-ctx.Done():
		return ctx.Err()
	}
}
