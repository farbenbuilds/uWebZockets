package main

import (
	"bytes"
	"context"
	"encoding/hex"
	"errors"
	"fmt"

	wt "github.com/quic-go/webtransport-go"
)

func peerUni(ctx context.Context, e *ProductEvidence, s ProductSession) error {
	stream, err := s.Session.OpenUniStreamSync(ctx)
	if err != nil {
		return err
	}
	if err := stream.SetWriteDeadline(deadline(ctx)); err != nil {
		return err
	}
	payload := streamPayload(s.Route.Source, s.Route.Ordinal, 101, 260)
	n, err := stream.Write(payload)
	if err != nil || n != len(payload) {
		return errors.Join(err, fmt.Errorf("peer uni write=%d", n))
	}
	if err := stream.Close(); err != nil {
		return err
	}
	_, err = awaitReport(ctx, s.Client, func(r ServerReport) bool {
		for _, c := range r.Children {
			if sameChildSession(c, s.Identity) && c.StreamID == uint64(stream.StreamID()) && c.Direction == "peer_uni" && c.Source == s.Route.Source && c.Ordinal == s.Route.Ordinal && c.ReceivedHex == hex.EncodeToString(payload) && c.EOF {
				return true
			}
		}
		return false
	})
	if err == nil {
		e.ExpectedChildren = append(e.ExpectedChildren, ExpectedChild{Session: s.Identity, StreamID: uint64(stream.StreamID()), Direction: "peer_uni", ReceivedHex: hex.EncodeToString(payload), EOF: true})
		e.Streams = append(e.Streams, StreamEvidence{Kind: "peer_uni", Source: s.Route.Source, Ordinal: s.Route.Ordinal, StreamID: uint64(stream.StreamID()), WrittenHex: hex.EncodeToString(payload), EOF: true})
	}
	return err
}

func peerBidi(ctx context.Context, e *ProductEvidence, s ProductSession) error {
	stream, err := s.Session.OpenStreamSync(ctx)
	if err != nil {
		return err
	}
	if err := stream.SetDeadline(deadline(ctx)); err != nil {
		return err
	}
	payload := streamPayload(s.Route.Source, s.Route.Ordinal, 113, 260)
	n, err := stream.Write(payload)
	if err != nil || n != len(payload) {
		return errors.Join(err, fmt.Errorf("peer bidi write=%d", n))
	}
	if err := stream.Close(); err != nil {
		return err
	}
	received, err := exactRead(stream, payload)
	if err != nil {
		return err
	}
	_, err = awaitReport(ctx, s.Client, func(r ServerReport) bool {
		for _, c := range r.Children {
			if sameChildSession(c, s.Identity) && c.StreamID == uint64(stream.StreamID()) && c.Direction == "peer_bidi" && c.Source == s.Route.Source && c.Ordinal == s.Route.Ordinal && c.ReceivedHex == hex.EncodeToString(payload) && c.SentHex == hex.EncodeToString(payload) && c.EOF && c.Finished {
				return true
			}
		}
		return false
	})
	if err == nil {
		e.ExpectedChildren = append(e.ExpectedChildren, ExpectedChild{Session: s.Identity, StreamID: uint64(stream.StreamID()), Direction: "peer_bidi", ReceivedHex: hex.EncodeToString(payload), SentHex: hex.EncodeToString(received), EOF: true, Finished: true})
		e.Streams = append(e.Streams, StreamEvidence{Kind: "peer_bidi", Source: s.Route.Source, Ordinal: s.Route.Ordinal, StreamID: uint64(stream.StreamID()), WrittenHex: hex.EncodeToString(payload), ReadHex: hex.EncodeToString(received), EOF: true})
	}
	return err
}

func productStreams(ctx context.Context, e *ProductEvidence, s ProductSession) error {
	if err := peerUni(ctx, e, s); err != nil {
		return err
	}
	if err := peerBidi(ctx, e, s); err != nil {
		return err
	}
	for _, kind := range []string{"uni", "bidi"} {
		reply, err := command(ctx, s, "create_"+kind, 260, false, 0)
		e.Controls = append(e.Controls, reply)
		if err != nil {
			return err
		}
		if !reply.OK {
			return errors.New("ordinary create unexpectedly blocked")
		}
		if err := readLocal(ctx, e, s, kind, 260, reply.CommandID); err != nil {
			return err
		}
	}
	e.Barriers = append(e.Barriers, "peer UNI/BIDI and server UNI/BIDI exact binary payload plus FIN, reverse server BIDI payload observed")
	return nil
}

func readLocal(ctx context.Context, e *ProductEvidence, s ProductSession, kind string, size int, id uint64) error {
	tag := 41
	if kind == "bidi" {
		tag = 73
	}
	payload := streamPayload(s.Route.Source, s.Route.Ordinal, tag, size)
	var streamID uint64
	var received, reverse []byte
	if kind == "uni" {
		stream, err := s.Session.AcceptUniStream(ctx)
		if err != nil {
			return err
		}
		if err := stream.SetReadDeadline(deadline(ctx)); err != nil {
			return err
		}
		streamID = uint64(stream.StreamID())
		received, err = exactRead(stream, payload)
		if err != nil {
			return err
		}
	} else {
		stream, err := s.Session.AcceptStream(ctx)
		if err != nil {
			return err
		}
		if err := stream.SetDeadline(deadline(ctx)); err != nil {
			return err
		}
		streamID = uint64(stream.StreamID())
		reverse = streamPayload(s.Route.Source, s.Route.Ordinal, 137, 19)
		n, err := stream.Write(reverse)
		if err != nil || n != len(reverse) {
			return errors.Join(err, errors.New("local bidi reverse write incomplete"))
		}
		if err := stream.Close(); err != nil {
			return err
		}
		received, err = exactRead(stream, payload)
		if err != nil {
			return err
		}
	}
	_, err := awaitReport(ctx, s.Client, func(r ServerReport) bool {
		for _, c := range r.Children {
			if sameChildSession(c, s.Identity) && c.StreamID == streamID && c.CommandID == id && c.SentHex == hex.EncodeToString(payload) && c.Finished && (kind == "uni" || (c.ReceivedHex == hex.EncodeToString(reverse) && c.EOF)) {
				return true
			}
		}
		return false
	})
	if err != nil {
		return err
	}
	e.ExpectedChildren = append(e.ExpectedChildren, ExpectedChild{Session: s.Identity, StreamID: streamID, CommandID: id, Direction: "local_" + kind, ReceivedHex: hex.EncodeToString(reverse), SentHex: hex.EncodeToString(received), EOF: kind == "bidi", Finished: true})
	e.Streams = append(e.Streams, StreamEvidence{Kind: "local_" + kind, Source: s.Route.Source, Ordinal: s.Route.Ordinal, StreamID: streamID, WrittenHex: hex.EncodeToString(reverse), ReadHex: hex.EncodeToString(received), EOF: true})
	return nil
}

func productReset(ctx context.Context, e *ProductEvidence, s ProductSession) error {
	frame, err := resetChild(ctx, e, s, streamPayload(s.Route.Source, s.Route.Ordinal, 151, 24), 0x1234)
	if err != nil {
		return err
	}
	if frame.FrameType != "reset_stream_at" {
		e.Barriers = append(e.Barriers, "body24 reset used ordinary fallback after reliable header ACK; trying immediate header-only cancellation")
		frame, err = resetChild(ctx, e, s, nil, 0x1235)
		if err != nil {
			return err
		}
	}
	if frame.FrameType != "reset_stream_at" || frame.ReliableSize == 0 {
		return errors.New("no transmitted RESET_STREAM_AT observed")
	}
	e.Barriers = append(e.Barriers, "public qlog PacketSent RESET_STREAM_AT matches app reset code and prefix-excluding final payload size; only header reliability claimed")
	return nil
}

func resetChild(ctx context.Context, e *ProductEvidence, s ProductSession, payload []byte, code uint32) (WireReset, error) {
	stream, err := s.Session.OpenUniStreamSync(ctx)
	if err != nil {
		return WireReset{}, err
	}
	if err := stream.SetWriteDeadline(deadline(ctx)); err != nil {
		return WireReset{}, err
	}
	if len(payload) > 0 {
		n, err := stream.Write(payload)
		if err != nil || n != len(payload) {
			return WireReset{}, errors.Join(err, errors.New("reset payload write incomplete"))
		}
	}
	stream.CancelWrite(wt.StreamErrorCode(code))
	frame, err := awaitReset(ctx, s.Client.ResetTrace, uint64(stream.StreamID()))
	if err != nil {
		return frame, err
	}
	e.SentResets = append(e.SentResets, frame)
	if err := validateResetWire(frame, uint64(stream.StreamID()), code, len(payload)); err != nil {
		return frame, err
	}
	report, err := awaitReport(ctx, s.Client, func(r ServerReport) bool {
		for _, c := range r.Children {
			if sameChildSession(c, s.Identity) && c.StreamID == uint64(stream.StreamID()) && c.ResetCode != nil && *c.ResetCode == code && c.ResetFinalSize != nil {
				return true
			}
		}
		return false
	})
	if err != nil {
		return frame, err
	}
	for _, c := range report.Children {
		if !sameChildSession(c, s.Identity) || c.StreamID != uint64(stream.StreamID()) {
			continue
		}
		got, err := hex.DecodeString(c.ReceivedHex)
		if err != nil {
			return frame, err
		}
		if c.ResetFinalSize == nil || *c.ResetFinalSize != uint64(len(payload)) || len(got) > len(payload) || !bytes.Equal(got, payload[:len(got)]) {
			return frame, errors.New("reset appcode, receivedprefix or payloadfinalsize mismatch")
		}
	}
	finalSize := uint64(len(payload))
	e.ExpectedChildren = append(e.ExpectedChildren, ExpectedChild{Session: s.Identity, StreamID: uint64(stream.StreamID()), Direction: "peer_uni", ReceivedHex: hex.EncodeToString(payload), ReceivedPrefix: true, ResetCode: new(code), ResetFinalSize: &finalSize})
	e.Reports = append(e.Reports, report)
	e.Streams = append(e.Streams, StreamEvidence{Kind: "peer_uni_reset_header_reliable_only", Source: s.Route.Source, Ordinal: s.Route.Ordinal, StreamID: uint64(stream.StreamID()), WrittenHex: hex.EncodeToString(payload)})
	return frame, nil
}

func productFlow(ctx context.Context, e *ProductEvidence, s ProductSession) error {
	reply, err := command(ctx, s, "create_uni", 4096, false, 0)
	e.Controls = append(e.Controls, reply)
	if err != nil {
		return err
	}
	if !reply.OK {
		return errors.New("initial flow create blocked")
	}
	report, err := awaitReport(ctx, s.Client, func(r ServerReport) bool {
		for _, c := range r.Children {
			if flowBlockedChild(c, s.Identity, reply.CommandID) {
				return true
			}
		}
		return false
	})
	if err != nil {
		return err
	}
	e.Reports = append(e.Reports, report)
	e.Barriers = append(e.Barriers, "server partial write or WouldBlock observed before client reads")
	if err := readLocal(ctx, e, s, "uni", 4096, reply.CommandID); err != nil {
		return err
	}
	e.Barriers = append(e.Barriers, "client read returned all4096 exact bytes and FIN after MAX_DATA recovery")
	return nil
}

func productCredit(ctx context.Context, e *ProductEvidence, s ProductSession) error {
	for _, kind := range []string{"uni", "bidi"} {
		first, err := command(ctx, s, "create_"+kind, 8, true, 0)
		e.Controls = append(e.Controls, first)
		if err != nil {
			return err
		}
		if !first.OK {
			return errors.New("first count1 stream create failed")
		}
		_, err = awaitReport(ctx, s.Client, func(r ServerReport) bool {
			for _, c := range r.Children {
				if sameChildSession(c, s.Identity) && c.CommandID == first.CommandID && c.SentLen == 8 && !c.Finished {
					return true
				}
			}
			return false
		})
		if err != nil {
			return err
		}
		second, err := command(ctx, s, "create_"+kind, 8, false, 0)
		e.Controls = append(e.Controls, second)
		if err != nil {
			return err
		}
		if second.Result != "would_block" {
			return errors.New("second count1 create did not WouldBlock")
		}
		finish, err := command(ctx, s, "finish", -1, false, first.CommandID)
		e.Controls = append(e.Controls, finish)
		if err != nil {
			return err
		}
		if err := readLocal(ctx, e, s, kind, 8, first.CommandID); err != nil {
			return err
		}
		var retry ControlReply
		for attempt := 0; attempt < 128; attempt++ {
			retry, err = command(ctx, s, "retry", -1, false, second.CommandID)
			e.Controls = append(e.Controls, retry)
			if err != nil {
				return err
			}
			if retry.OK {
				break
			}
			if _, err := getReport(ctx, s.Client); err != nil {
				return err
			}
		}
		if !retry.OK {
			return errors.New("explicit create retry remained blocked after consumption")
		}
		if err := readLocal(ctx, e, s, kind, 8, retry.CommandID); err != nil {
			return err
		}
	}
	e.Barriers = append(e.Barriers, "UNI and BIDI count1: held first child, second WouldBlock, consume/close, explicit retry succeeds")
	return nil
}

func productIsolation(ctx context.Context, e *ProductEvidence, a, b ProductSession) error {
	reply, err := command(ctx, a, "create_uni", 4096, false, 0)
	e.Controls = append(e.Controls, reply)
	if err != nil {
		return err
	}
	report, err := awaitReport(ctx, a.Client, func(r ServerReport) bool {
		for _, c := range r.Children {
			if flowBlockedChild(c, a.Identity, reply.CommandID) {
				return true
			}
		}
		return false
	})
	if err != nil {
		return err
	}
	e.Reports = append(e.Reports, report)
	blocked, acceptErr := a.Session.AcceptUniStream(ctx)
	if acceptErr != nil {
		return acceptErr
	}
	e.ExpectedChildren = append(e.ExpectedChildren, ExpectedChild{Session: a.Identity, StreamID: uint64(blocked.StreamID()), CommandID: reply.CommandID, Direction: "local_uni", SentHex: hex.EncodeToString(streamPayload(a.Route.Source, a.Route.Ordinal, 41, 4096)[:32])})
	if err := peerBidi(ctx, e, b); err != nil {
		return err
	}
	_, status, err := getProduct(ctx, a.Client, "/health")
	if err != nil {
		return err
	}
	e.HealthStatuses = append(e.HealthStatuses, status)
	if err := a.Session.CloseWithError(0, ""); err != nil {
		return err
	}
	_, err = awaitReport(ctx, a.Client, func(r ServerReport) bool {
		for _, s := range r.Sessions {
			if s.Source == a.Route.Source && s.Ordinal == a.Route.Ordinal && s.Closed {
				return true
			}
		}
		return false
	})
	if err != nil {
		return err
	}
	if err := peerUni(ctx, e, b); err != nil {
		return err
	}
	e.Barriers = append(e.Barriers, "session B exact BIDI while A blocked, healthy same-connection HTTP, B exact UNI after A closed")
	return nil
}
