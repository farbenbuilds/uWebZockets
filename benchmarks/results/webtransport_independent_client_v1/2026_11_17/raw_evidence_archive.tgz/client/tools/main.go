package main

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"math/big"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"time"
)

func main() {
	if len(os.Args) < 2 {
		fail(errors.New("usage: tools pki DIR | port [PORT]"))
	}
	switch os.Args[1] {
	case "pki":
		if len(os.Args) != 3 {
			fail(errors.New("pki requires an owned directory"))
		}
		if err := makePKI(os.Args[2]); err != nil {
			fail(err)
		}
	case "port":
		port := 0
		if len(os.Args) > 3 {
			fail(errors.New("port accepts at most one explicit port"))
		}
		if len(os.Args) == 3 {
			var err error
			port, err = strconv.Atoi(os.Args[2])
			if err != nil || port < 1 || port > 65535 {
				fail(errors.New("invalid explicit port"))
			}
		}
		c, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: port})
		if err != nil {
			fail(err)
		}
		chosen := c.LocalAddr().(*net.UDPAddr).Port
		if err := c.Close(); err != nil {
			fail(err)
		}
		if err := json.NewEncoder(os.Stdout).Encode(map[string]any{"host": "127.0.0.1", "port": chosen, "bind_checked": true}); err != nil {
			fail(err)
		}
	default:
		fail(errors.New("unknown helper mode"))
	}
}

func fail(err error) { fmt.Fprintln(os.Stderr, err); os.Exit(1) }

func makePKI(dir string) error {
	if _, err := os.Stat(dir); !os.IsNotExist(err) {
		return errors.New("PKI directory must not already exist")
	}
	if err := os.MkdirAll(dir, 0700); err != nil {
		return err
	}
	caKey, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return err
	}
	serial, err := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 128))
	if err != nil {
		return err
	}
	now := time.Now()
	ca := &x509.Certificate{SerialNumber: serial, Subject: pkix.Name{CommonName: "UWZ loopback oracle CA"}, NotBefore: now.Add(-time.Minute), NotAfter: now.Add(48 * time.Hour), KeyUsage: x509.KeyUsageCertSign | x509.KeyUsageDigitalSignature, BasicConstraintsValid: true, IsCA: true}
	caDER, err := x509.CreateCertificate(rand.Reader, ca, ca, &caKey.PublicKey, caKey)
	if err != nil {
		return err
	}
	serverKey, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return err
	}
	serial, err = rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 128))
	if err != nil {
		return err
	}
	cert := &x509.Certificate{SerialNumber: serial, Subject: pkix.Name{CommonName: "localhost"}, NotBefore: now.Add(-time.Minute), NotAfter: now.Add(24 * time.Hour), DNSNames: []string{"localhost"}, IPAddresses: []net.IP{net.IPv4(127, 0, 0, 1)}, KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}}
	certDER, err := x509.CreateCertificate(rand.Reader, cert, ca, &serverKey.PublicKey, caKey)
	if err != nil {
		return err
	}
	keyDER, err := x509.MarshalPKCS8PrivateKey(serverKey)
	if err != nil {
		return err
	}
	for name, data := range map[string][]byte{"ca.pem": pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: caDER}), "server.pem": pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: certDER}), "server.key": pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: keyDER})} {
		f, err := os.OpenFile(filepath.Join(dir, name), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
		if err != nil {
			return err
		}
		_, writeErr := f.Write(data)
		closeErr := f.Close()
		if err := errors.Join(writeErr, closeErr); err != nil {
			return err
		}
	}
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"ca": filepath.Join(dir, "ca.pem"), "cert": filepath.Join(dir, "server.pem"), "key": filepath.Join(dir, "server.key"), "not_after": cert.NotAfter.UTC().Format(time.RFC3339), "sans": []string{"localhost", "127.0.0.1"}, "private_mode": "0600"})
}
