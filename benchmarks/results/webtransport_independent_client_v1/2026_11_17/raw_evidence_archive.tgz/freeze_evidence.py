from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import zipfile

base = Path(__file__).resolve().parent
stage = Path('/tmp/uwz-wt-independent-client-evidence-20261117')
assert not stage.exists()
stage.mkdir()

def copy(source, relative):
    assert source.is_file() and not source.is_symlink(), source
    assert source.suffix not in {'.pem', '.key', '.crt', '.der'}, source
    target = stage / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)

for name in ['build.zig', 'build.zig.zon', 'CONTRACT.md', 'run_matrix.py', 'replay.sh', 'freeze_evidence.py']:
    copy(base/name, Path(name))
for p in (base/'builds').rglob('*.zig'):
    copy(p, p.relative_to(base))
for p in (base/'server').iterdir():
    if p.is_file() and p.suffix in {'.zig', '.log', '.txt', '.json', '.sha256'}:
        copy(p, p.relative_to(base))
for directory in ['root_logs', 'root_checks']:
    for p in (base/directory).iterdir():
        if p.is_file(): copy(p, p.relative_to(base))
for p in (base/'client').iterdir():
    if p.is_file() and (p.suffix in {'.go', '.mod', '.sum', '.md', '.sh'}):
        copy(p, p.relative_to(base))
for directory in ['tools', 'logs']:
    for p in (base/'client'/directory).rglob('*'):
        if p.is_file(): copy(p, p.relative_to(base))
for name in ['client/wt-oracle', 'client/wt-tools', 'server/out/bin/uwz_wt_independent_server', 'profiles/Debug/bin/uwz_wt_independent_server', 'profiles/ReleaseFast/bin/uwz_wt_independent_server']:
    copy(base/name, Path(name))
cache = base/'client/gopath/pkg/mod/cache/download'
for p in cache.rglob('*'):
    if not p.is_file() or p.suffix == '.lock': continue
    if p.suffix == '.zip':
        with zipfile.ZipFile(p) as archive:
            if any(name.endswith(('.pem','.key','.crt','.der')) for name in archive.namelist()): continue
    copy(p, p.relative_to(base))
upstream = Path('/tmp/uwz-webtransport-go-2a2b547d91a8a70e313e7ce61538b066554021b5')
for p in upstream.rglob('*'):
    if p.is_file(): copy(p, Path('inputs/webtransport-go')/p.relative_to(upstream))
root = Path('/home/foo/Desktop/Repos/uWebZockets')
commit = 'c377d38caeb32de773c03531be11d8bda3c2d829'
files = subprocess.check_output(['git','ls-tree','-r','--name-only',commit,'--','src','builds','include','build.zig','build.zig.zon'],cwd=root,text=True).splitlines()
for name in files:
    data = subprocess.check_output(['git','show',commit+':'+name],cwd=root)
    target = stage/'project'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(data)
metadata = {
    'root_source_commit': commit,
    'root_snapshot_files': len(files),
    'native': {'commit':'d1104a9fab040af659295a95fb448c971a7bc6de','archive':'benchmarks/results/lsquic_receive_publication_v1/2026_11_17/raw_evidence_archive.tgz','sha256':'753083ac2454662c5a1a55717811899cfd682dd3cf45c4fb47b0081ad2da360c'},
    'libxev': {'commit':'5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5','archive':'benchmarks/results/webtransport_child_callbacks_v1/2026_11_16/raw_evidence_archive.tgz','sha256':'4501a2f59807d89697428d0f627ed8918b0be43031972bd9132f2fab9e196e39'},
    'official_webtransport_go': {'commit':'2a2b547d91a8a70e313e7ce61538b066554021b5','source':'inputs/webtransport-go','original_archive_sha256':'5ad87c03fed6cfeed41eed04124c7b8aed510b8267792bca688865fbf8a78eba'},
    'quic_go': {'version':'v0.62.0','implementation_commit':'793f74d8e03368c5aded128af6f48d21dbb47f73','module_sum':'h1:ZHDjCk5OacATwGvs8PWE97CTvX7AqZiVoW7++ZOXTf8='},
    'go_toolchain':'go1.26.8 linux/amd64',
    'zig_toolchain':'0.16.0 x86_64-linux',
    'candidate_only':True,
    'library_build_requirements_unchanged':True,
    'pki_files_excluded':True,
    'module_cache_note':'Only frozen download inputs are retained, not build caches. The new offline wrapper uses the previously verified unchanged sources and go.sum; original online provenance is in the earlier oracle artifact.',
    'historical_binaries_not_copied':[]
}
for name in ['server/uwz_wt_first_milestone','server/uwz_wt_product_v1','client/wt-oracle-baseline']:
    p=base/name
    metadata['historical_binaries_not_copied'].append({'path_at_run':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scope':'provisional first runs only; final acceptance uses retained frozen binaries'})
(stage/'external_inputs.json').write_text(json.dumps(metadata,indent=2)+'\n')
payloads = sorted(p for p in stage.rglob('*') if p.is_file())
for p in payloads:
    assert not p.is_symlink()
    if p.suffix in {'.pem','.key','.crt','.der'}: raise RuntimeError('unexpected PKI payload')
(stage/'files.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(stage).as_posix()+'\n' for p in payloads))
print('Frozen payloads:',len(payloads),'root snapshot:',len(files),'bytes:',sum(p.stat().st_size for p in payloads))
