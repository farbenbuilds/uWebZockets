package webtransport_test

import (
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"io"
	"net"
	"testing"
	"time"

	"github.com/quic-go/webtransport-go"

	"github.com/quic-go/quic-go"
	"github.com/quic-go/quic-go/http3"
	"github.com/quic-go/quic-go/quicvarint"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const (
	// Extended CONNECT, RFC 9220
	settingExtendedConnect = 0x8
	// HTTP Datagrams, RFC 9297
	settingDatagram = 0x33
	// WebTransport
	settingsWebTransportEnabled = 0x2c7cf000
)

// appendSettingsFrame serializes an HTTP/3 SETTINGS frame
// It reimplements the function in the http3 package, in a slightly simplified way.
func appendSettingsFrame(b []byte, values map[uint64]uint64) []byte {
	b = quicvarint.Append(b, 0x4)
	var l uint64
	for k, val := range values {
		l += uint64(quicvarint.Len(k)) + uint64(quicvarint.Len(val))
	}
	b = quicvarint.Append(b, l)
	for id, val := range values {
		b = quicvarint.Append(b, id)
		b = quicvarint.Append(b, val)
	}
	return b
}

func TestClientInvalidResponseHandling(t *testing.T) {
	ln, err := quic.ListenAddr(
		"localhost:0",
		webtransport.TLSConf,
		&quic.Config{EnableDatagrams: true, EnableStreamResetPartialDelivery: true},
	)
	require.NoError(t, err)
	defer ln.Close()

	errChan := make(chan error, 1)
	go func() {
		conn, err := ln.Accept(context.Background())
		if err != nil {
			errChan <- err
			return
		}
		// send the SETTINGS frame
		settingsStr, err := conn.OpenUniStream()
		if err != nil {
			errChan <- err
			return
		}
		_, err = settingsStr.Write(appendSettingsFrame([]byte{0} /* stream type */, map[uint64]uint64{
			settingDatagram:             1,
			settingExtendedConnect:      1,
			settingsWebTransportEnabled: 1,
		}))
		if err != nil {
			errChan <- err
			return
		}

		str, err := conn.AcceptStream(context.Background())
		if err != nil {
			errChan <- err
			return
		}
		// write an HTTP/3 data frame. This will cause an error, since a HEADERS frame is expected
		var b []byte
		b = quicvarint.Append(b, 0x0)
		b = quicvarint.Append(b, 1337)
		_, err = str.Write(b)
		require.NoError(t, err)
		for {
			if _, err := str.Read(make([]byte, 64)); err != nil {
				errChan <- err
				return
			}
		}
	}()

	d := webtransport.Transport{TLSClientConfig: &tls.Config{RootCAs: webtransport.CertPool}}
	_, _, err = d.Dial(context.Background(), fmt.Sprintf("https://localhost:%d", ln.Addr().(*net.UDPAddr).Port), nil)
	require.Error(t, err)
	var sErr error
	select {
	case sErr = <-errChan:
	case <-time.After(5 * time.Second):
		t.Fatal("timeout")
	}
	require.Error(t, sErr)
	var appErr *quic.ApplicationError
	require.True(t, errors.As(sErr, &appErr))
	require.Equal(t, http3.ErrCodeFrameUnexpected, http3.ErrCode(appErr.ErrorCode))
}

func TestClientConnChecksServerQUICSupportOnDial(t *testing.T) {
	for _, tt := range []struct {
		name       string
		config     *quic.Config
		wantErrMsg string
	}{
		{
			name:       "datagrams",
			config:     &quic.Config{EnableStreamResetPartialDelivery: true},
			wantErrMsg: "server didn't enable QUIC datagram support",
		},
		{
			name:       "stream reset partial delivery",
			config:     &quic.Config{EnableDatagrams: true},
			wantErrMsg: "server didn't enable QUIC stream reset partial delivery",
		},
	} {
		t.Run(tt.name, func(t *testing.T) {
			ln, err := quic.ListenAddr("localhost:0", webtransport.TLSConf, tt.config)
			require.NoError(t, err)
			defer ln.Close()

			qconn, err := quic.DialAddr(
				t.Context(),
				ln.Addr().String(),
				&tls.Config{
					RootCAs:    webtransport.CertPool,
					ServerName: "localhost",
					NextProtos: []string{http3.NextProtoH3},
				},
				&quic.Config{EnableDatagrams: true, EnableStreamResetPartialDelivery: true},
			)
			require.NoError(t, err)
			defer qconn.CloseWithError(0, "")

			tr := &webtransport.Transport{}
			defer tr.Close()
			conn, err := tr.NewClientConn(qconn)
			require.NoError(t, err)
			_, _, err = conn.Dial(t.Context(), "https://localhost", nil)
			require.ErrorContains(t, err, tt.wantErrMsg)
			var reqErr *webtransport.RequirementsNotMetError
			require.ErrorAs(t, err, &reqErr)
		})
	}
}

func TestClientClosesConnectionForInvalidSessionID(t *testing.T) {
	ln, err := quic.ListenAddr("localhost:0", webtransport.TLSConf, &quic.Config{EnableDatagrams: true, EnableStreamResetPartialDelivery: true})
	require.NoError(t, err)
	defer ln.Close()
	addr := fmt.Sprintf("https://localhost:%d", ln.Addr().(*net.UDPAddr).Port)

	for _, tt := range []struct {
		name       string
		streamType uint64
	}{{"bidirectional", webTransportFrameType}, {"unidirectional", webTransportUniStreamType}} {
		t.Run(tt.name, func(t *testing.T) {
			go func() {
				d := webtransport.Transport{TLSClientConfig: &tls.Config{RootCAs: webtransport.CertPool}}
				_, _, _ = d.Dial(context.Background(), addr, nil)
			}()

			ctx, cancel := context.WithTimeout(context.Background(), time.Second)
			defer cancel()
			conn, err := ln.Accept(ctx)
			require.NoError(t, err)
			defer conn.CloseWithError(0, "")
			settingsStr, err := conn.OpenUniStream()
			require.NoError(t, err)
			_, err = settingsStr.Write(
				appendSettingsFrame(
					[]byte{0},
					map[uint64]uint64{settingDatagram: 1, settingExtendedConnect: 1, settingsWebTransportEnabled: 1},
				),
			)
			require.NoError(t, err)

			var str io.WriteCloser
			if tt.streamType == webTransportUniStreamType {
				str, err = conn.OpenUniStream()
			} else {
				str, err = conn.OpenStream()
			}
			require.NoError(t, err)
			_, err = str.Write(quicvarint.Append(quicvarint.Append(nil, tt.streamType), 1))
			require.NoError(t, err)
			require.NoError(t, str.Close())

			select {
			case <-conn.Context().Done():
				require.ErrorIs(t,
					context.Cause(conn.Context()),
					&quic.ApplicationError{ErrorCode: quic.ApplicationErrorCode(http3.ErrCodeIDError), Remote: true},
				)
			case <-time.After(time.Second):
				t.Fatal("timeout waiting for connection to close")
			}
		})
	}
}

func TestClientWaitForSettingsTimeout(t *testing.T) {
	ln, err := quic.ListenAddr("localhost:0", webtransport.TLSConf, &quic.Config{EnableDatagrams: true, EnableStreamResetPartialDelivery: true})
	require.NoError(t, err)
	defer ln.Close()

	connChan := make(chan *quic.Conn, 1)
	go func() {
		conn, err := ln.Accept(context.Background())
		if err != nil {
			return
		}
		connChan <- conn
	}()

	ctx, cancel := context.WithCancelCause(context.Background())
	errChan := make(chan error)
	go func() {
		d := webtransport.Transport{TLSClientConfig: &tls.Config{RootCAs: webtransport.CertPool}}
		_, _, err := d.Dial(ctx, fmt.Sprintf("https://localhost:%d", ln.Addr().(*net.UDPAddr).Port), nil)
		errChan <- err
	}()

	var serverConn *quic.Conn
	select {
	case serverConn = <-connChan:
	case <-time.After(time.Second):
		t.Fatal("timeout waiting for connection")
	}

	cancel(assert.AnError)

	select {
	case err := <-errChan:
		require.Error(t, err)
		require.ErrorContains(t, err, "error waiting for HTTP/3 settings")
		require.ErrorIs(t, err, assert.AnError)
	case <-time.After(time.Second):
		t.Fatal("timeout waiting for dial to complete")
	}

	// the client should close the underlying QUIC connection
	select {
	case <-serverConn.Context().Done():
		require.ErrorIs(t,
			context.Cause(serverConn.Context()),
			&quic.ApplicationError{ErrorCode: quic.ApplicationErrorCode(http3.ErrCodeNoError), Remote: true},
		)
	case <-time.After(time.Second):
		t.Fatal("timeout waiting for client to close connection")
	}
}

func TestClientInvalidSettingsHandling(t *testing.T) {
	for _, tc := range []struct {
		name     string
		settings map[uint64]uint64
		errorStr string
	}{
		{
			name: "Extended CONNECT disabled",
			settings: map[uint64]uint64{
				settingDatagram:             1,
				settingExtendedConnect:      0,
				settingsWebTransportEnabled: 1,
			},
			errorStr: "server didn't enable Extended CONNECT",
		},
		{
			name: "HTTP/3 DATAGRAMs disabled",
			settings: map[uint64]uint64{
				settingDatagram:             0,
				settingExtendedConnect:      1,
				settingsWebTransportEnabled: 1,
			},
			errorStr: "server didn't enable HTTP/3 datagram support",
		},
		{
			name: "WebTransport disabled",
			settings: map[uint64]uint64{
				settingDatagram:             1,
				settingExtendedConnect:      1,
				settingsWebTransportEnabled: 0,
			},
			errorStr: "server didn't enable WebTransport",
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			ln, err := quic.ListenAddr("localhost:0", webtransport.TLSConf, &quic.Config{EnableDatagrams: true, EnableStreamResetPartialDelivery: true})
			require.NoError(t, err)
			defer ln.Close()

			connChan := make(chan *quic.Conn, 1)
			go func() {
				conn, err := ln.Accept(context.Background())
				if err != nil {
					t.Errorf("failed to accept connection: %v", err)
					return
				}
				// send the SETTINGS frame
				settingsStr, err := conn.OpenUniStream()
				if err != nil {
					t.Errorf("failed to open uni stream: %v", err)
					return
				}
				if _, err := settingsStr.Write(appendSettingsFrame([]byte{0} /* stream type */, tc.settings)); err != nil {
					t.Errorf("failed to write settings frame: %v", err)
					return
				}
				connChan <- conn
			}()

			d := webtransport.Transport{TLSClientConfig: &tls.Config{RootCAs: webtransport.CertPool}}
			_, _, err = d.Dial(context.Background(), fmt.Sprintf("https://localhost:%d", ln.Addr().(*net.UDPAddr).Port), nil)
			require.Error(t, err)
			require.ErrorContains(t, err, tc.errorStr)
			var reqErr *webtransport.RequirementsNotMetError
			require.ErrorAs(t, err, &reqErr)

			var serverConn *quic.Conn
			select {
			case serverConn = <-connChan:
			case <-time.After(5 * time.Second):
				t.Fatal("timeout")
			}

			// the client should close the underlying QUIC connection
			select {
			case <-serverConn.Context().Done():
				require.ErrorIs(t,
					context.Cause(serverConn.Context()),
					&quic.ApplicationError{ErrorCode: webtransport.WTRequirementsNotMetErrorCode, Remote: true},
				)
			case <-time.After(time.Second):
				t.Fatal("timeout waiting for client to close connection")
			}
		})
	}
}
