# Independent public-App acceptance replay

The final nine-case matrix passed with Debug, ReleaseSafe and ReleaseFast
servers. The official client uses webtransport-go
2a2b547d91a8a70e313e7ce61538b066554021b5 and quic-go v0.62.0 implementation
793f74d8e03368c5aded128af6f48d21dbb47f73. The Root snapshot is
c377d38caeb32de773c03531be11d8bda3c2d829; Native and XEV remain external
inputs with exact existing artifact hashes in external_inputs.json.

Verify files.sha256 from this directory. On the recorded compatible Linux
x86_64 host, run:

    sh replay.sh Debug

ReleaseSafe and ReleaseFast are also supported. Replay uses the retained final
binaries, verifies their exact hashes, generates fresh private localhost PKI,
runs each case on a new loopback server, and requires positive readiness,
strict client report reconciliation, exit zero and normal App shutdown/deinit.
It removes only the PKI it generated. Python 3 orchestrates this verification;
Go and Python are not native-library build requirements. Set UWZ_RUN_ID to a
new lowercase identifier for another run without overwriting original results.
Run each replay with the loopback permissions required by the host environment.

root_logs/matrix_MODE_final_v1.json records the original commands, statuses,
binary hashes and raw log hashes. Each client JSON contains raw server report,
operation-derived expected children and public reset-frame evidence. All 27
original rows and all 81 raw log hashes were independently verified.
root_logs/matrix_Debug_relocated_v1.json and its logs record the additional
nine-case relocated replay; its private PKI has been removed.

Final server executable locations:

- Debug: profiles/Debug/bin/uwz_wt_independent_server
- ReleaseSafe: server/out/bin/uwz_wt_independent_server
- ReleaseFast: profiles/ReleaseFast/bin/uwz_wt_independent_server

The retained binaries are for the recorded host/CPU/ABI. Rebuilding elsewhere
requires Zig 0.16.0 plus exact Native/XEV source overrides and the pinned Zig
packages. builds/server.zig imports the frozen project/src/root.zig module and
builds all C dependencies with Zig source lists. No C client, test_support,
SETTINGS observer, artificial clock or private native-window changes are used.
server/BUILD_COMMAND.txt records the actual original build command; substitute
this directory's project snapshot and explicit dependency paths when rebuilding.

Client source and go.sum are retained under client/. Its offline wrapper uses
Go 1.26.8 and isolated caches. inputs/webtransport-go contains the unchanged
64-file official source snapshot; client/gopath/pkg/mod/cache/download contains
dependency metadata/checksums and certificate-free download inputs rather than
build caches. The upstream quic-go ZIP contains public test PKI and is excluded
in its entirety; its exact hash and go.sum remain recorded. Source rebuild must
fetch that unchanged pinned module into an isolated cache before using the
offline wrapper. Final-binary replay requires no module download. The original go.mod
records the original absolute local replacement path. A relocated source rebuild
must explicitly replace it with inputs/webtransport-go in a separate modfile;
retain original go.mod/go.sum and record new binary hashes. Original-run fixed
hash checks must not be represented as hashes of rebuilt executables.

The first runs under server/ and client/logs are explicitly provisional fixture
trials. Early report schemas, weaker validators, build include errors and old
oracle admission/enqueue-only flags remain historical data; they do not establish
final acceptance. Component manifests bind available trial sources/binaries;
only the final frozen inputs and their completed matrices are replayed here.
Historical binary hashes are retained in external_inputs.json; only final
acceptance executables are included. The original oracle/dependency provenance
is also preserved in the earlier reliable-reset checkpoint artifact.

The final client checks TLS 1.3, h3, explicit CA chains, DATAGRAM and partial-reset
negotiation; exact callback/ring receipt sets and per-connection ordinals; full
session/child route and generation identity; exact expected child sets and
terminal counts; binary data/FIN in all four directions; DATA32 and stream
credit recovery; scoped retirement and duplicate-SID-zero connection namespaces.
Public qlog records RESET_STREAM_AT reliable3/wirefinal27 matching appcode4660
and final payload24. It does not claim arbitrary reliable application-prefix or
optimistic early-traffic coverage; those remain separate raw/native evidence.

Production pins/capabilities and maintained forks are unchanged. Dedicated
smoke/security/sanitizer/fuzz/scan campaigns were deferred. This is compatible
independent-client evidence for the unpublished candidate, not published
activation or completion of v2.3.0. No certificates, private keys or credentials
are included.
