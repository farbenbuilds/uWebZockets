#!/usr/bin/env bash
set -euo pipefail
PORT=${1:-31642}
PASS=0
FAIL=0
TESTS='async async-db'
DOCS_BASE='https://http-arena.com/#doc=test-profiles'
EVIDENCE_DIRECTORY=$(CDPATH='' cd "$(dirname "$0")" && pwd)
mkdir -p "$EVIDENCE_DIRECTORY/responses"
curl() {
    local captured status=0
    captured=$(mktemp "$EVIDENCE_DIRECTORY/responses/curl.XXXXXXXX")
    printf '%q ' "$@" > "$captured.args"
    command curl "$@" > "$captured.out" || status=$?
    cat "$captured.out"
    return "$status"
}

has_test() {
    # Exact whole-token match. `grep -qw` treats "-" as a word boundary
    # and matches "baseline" against "baseline-h2c" / "baseline-h2", and
    # "json" against "json-h2c" / "json-tls" / "json-comp" — all false
    # positives. Bash pattern match on the space-padded string is exact.
    [[ " $TESTS " == *" $1 "* ]]
}


rand_between() {
    local lo="$1" hi="$2"
    echo $(( (RANDOM % (hi - lo + 1)) + lo ))
}


fail_with_link() {
    local msg="$1"
    local docs_url="$2"
    echo "  FAIL $msg"
    if [ -n "$docs_url" ]; then
        echo "        → $docs_url"
    fi
    FAIL=$((FAIL + 1))
}


dump_debug() {
    local trace="$1"
    local response="$2"
    if [ -n "$trace" ] && [ -s "$trace" ]; then
        echo "        ─── wire trace ───"
        sed 's/^/        /' "$trace"
    fi
    if [ -n "$response" ]; then
        echo "        ─── response ───"
        printf '%s\n' "$response" | sed 's/^/        /'
    fi
    [ -n "$trace" ] && rm -f "$trace"
}


check() {
    local label="$1"
    local expected_body="$2"
    local docs_url="$3"
    shift 3
    local response trace
    trace=$(mktemp)
    response=$(curl -s --max-time 30 -D- --trace-ascii "$trace" "$@" || true)
    local body
    body=$(echo "$response" | tail -1)

    if [ "$body" = "$expected_body" ]; then
        echo "  PASS [$label]"
        PASS=$((PASS + 1))
        rm -f "$trace"
    else
        fail_with_link "[$label]: expected body '$expected_body', got '$body'" "$docs_url"
        dump_debug "$trace" "$response"
    fi
}


check_header() {
    local label="$1"
    local header_name="$2"
    local expected_value="$3"
    local docs_url="$4"
    shift 4
    local headers trace
    trace=$(mktemp)
    headers=$(curl -s --max-time 30 -D- -o /dev/null --trace-ascii "$trace" "$@" || true)
    local value
    value=$(echo "$headers" | grep -i "^${header_name}:" | sed 's/^[^:]*: *//' | tr -d '\r' || true)

    # Normalize: text/javascript and application/javascript are equivalent (RFC 9239)
    local norm_value norm_expected
    norm_value=$(echo "$value" | sed 's|text/javascript|application/javascript|')
    norm_expected=$(echo "$expected_value" | sed 's|text/javascript|application/javascript|')
    if [ "$value" = "$expected_value" ] || [[ "$value" == "$expected_value;"* ]] || [ "$norm_value" = "$norm_expected" ] || [[ "$norm_value" == "$norm_expected;"* ]]; then
        echo "  PASS [$label] ($header_name: $value)"
        PASS=$((PASS + 1))
        rm -f "$trace"
    else
        fail_with_link "[$label]: expected $header_name '$expected_value', got '$value'" "$docs_url"
        dump_debug "$trace" "$headers"
    fi
}


check_delay() {
    local label="$1" ms="$2" min_secs="$3" docs="$4"
    local out code body
    out=$(LC_ALL=C curl -s --max-time 30 -w '\n%{http_code} %{time_total}' \
              "http://localhost:$PORT/delay/$ms" 2>/dev/null || true)
    code=$(printf '%s\n' "$out" | tail -1 | awk '{print $1}')
    ASYNC_SECS=$(printf '%s\n' "$out" | tail -1 | awk '{print $2}')
    body=$(printf '%s\n' "$out" | head -n -1 | tail -1)

    if [ "$code" != "200" ]; then
        fail_with_link "[$label]: expected HTTP 200, got HTTP ${code:-none}" "$docs"
        return
    fi
    if [ "$body" != "$ms" ]; then
        fail_with_link "[$label]: expected body '$ms', got '$body'" "$docs"
        return
    fi
    if ! awk -v t="${ASYNC_SECS:-0}" -v m="$min_secs" 'BEGIN{exit !(t+0 >= m+0)}'; then
        fail_with_link "[$label]: answered in ${ASYNC_SECS}s, short of the ${ms}ms it was asked to wait" "$docs"
        return
    fi
    echo "  PASS [$label] (${ASYNC_SECS}s)"
    PASS=$((PASS + 1))
}


async_concurrent_probe() {
    local label="$1" n="$2" docs="$3"
    local dir; dir=$(mktemp -d)
    local i ms
    local t0 t1
    # Waited on by pid, not with a bare `wait`: the run-level watchdog at the
    # top of this script is a background subshell sleeping out VALIDATE_TIMEOUT,
    # and a bare wait blocks on that too - which is the whole timeout, every
    # time, for a probe that finishes in half a second.
    local -a pids=()
    t0=$(date +%s.%N)
    for i in $(seq 1 "$n"); do
        # 13 is coprime with 400, so 32 indices give 32 distinct delays.
        ms=$(( 100 + (i * 13) % 400 ))
        printf '%s' "$ms" > "$dir/$i.want"
        # No leading newline in -w here: the body already goes to its own file,
        # so stdout is the metrics line and nothing else.
        LC_ALL=C curl -s --max-time 30 -w '%{http_code} %{time_total}' \
            -o "$dir/$i.body" "http://localhost:$PORT/delay/$ms" > "$dir/$i.meta" 2>/dev/null &
        pids+=($!)
    done
    wait "${pids[@]}" 2>/dev/null || true
    t1=$(date +%s.%N)

    local bad="" code secs body want
    for i in $(seq 1 "$n"); do
        want=$(cat "$dir/$i.want")
        code=$(awk '{print $1}' "$dir/$i.meta" 2>/dev/null)
        secs=$(awk '{print $2}' "$dir/$i.meta" 2>/dev/null)
        body=$(tail -1 "$dir/$i.body" 2>/dev/null)
        if [ "$code" != "200" ]; then
            bad="/delay/$want returned HTTP ${code:-none}"; break
        fi
        if [ "$body" != "$want" ]; then
            bad="/delay/$want echoed '$body'"; break
        fi
        if ! awk -v t="${secs:-0}" -v m="$want" 'BEGIN{exit !(t+0 >= (m/1000)*0.9)}'; then
            bad="/delay/$want answered in ${secs}s"; break
        fi
    done
    rm -rf "$dir"

    local wall
    wall=$(LC_ALL=C awk -v a="$t0" -v b="$t1" 'BEGIN{printf "%.2f", b-a}')
    if [ -n "$bad" ]; then
        fail_with_link "[$label]: $bad" "$docs"
    else
        echo "  PASS [$label] ($n concurrent, ${wall}s wall)"
        PASS=$((PASS + 1))
    fi
}


if has_test "async"; then
    ASYNC_DOCS="$DOCS_BASE/h1/async/validation"
    echo "[test] async delay endpoint"

    # The benchmark asks for a flat 15ms, so on-the-wire variation is not
    # doing any anti-cheat work there and all of it lands here: draw the
    # value fresh, after the container is already up, so nothing can have
    # been prepared for it.
    #
    # The bound scales with the value drawn. A fixed floor only ever tested the
    # bottom of the range -- an 8ms floor says nothing about an 84ms ask, which
    # is most of what this draw produces -- so the check read as "did it wait at
    # all" when the docs claim it asserts the requested delay. 0.9x leaves room
    # for a timer that rounds down without letting a real skip through.
    ASYNC_MS=$(rand_between 10 90)
    ASYNC_MIN=$(LC_ALL=C awk -v m="$ASYNC_MS" 'BEGIN{printf "%.3f", (m/1000)*0.9}')
    check_delay "GET /delay/$ASYNC_MS (random)" "$ASYNC_MS" "$ASYNC_MIN" "$ASYNC_DOCS"

    check_header "GET /delay/$ASYNC_MS Content-Type" "Content-Type" "text/plain" "$ASYNC_DOCS" \
        "http://localhost:$PORT/delay/$ASYNC_MS"

    # Zero is a valid delay, not a missing one. Anything that treats it as
    # absent and substitutes a default answers with the wrong number here.
    check "GET /delay/0" "0" "$ASYNC_DOCS" "http://localhost:$PORT/delay/0"

    # The parameter has to reach the sleep, not just the response body. Echoing
    # it back is easy; taking half a second longer for the request that asked
    # for half a second longer is not.
    echo "[test] async delay is driven by the parameter"
    check_delay "GET /delay/10" 10 0.008 "$ASYNC_DOCS"
    ASYNC_T_SHORT="${ASYNC_SECS:-0}"
    check_delay "GET /delay/500" 500 0.45 "$ASYNC_DOCS"
    ASYNC_T_LONG="${ASYNC_SECS:-0}"

    if awk -v s="$ASYNC_T_SHORT" -v l="$ASYNC_T_LONG" 'BEGIN{exit !((l+0) - (s+0) >= 0.3)}'; then
        echo "  PASS [/delay/500 waits ~490ms longer than /delay/10] (${ASYNC_T_SHORT}s vs ${ASYNC_T_LONG}s)"
        PASS=$((PASS + 1))
    else
        fail_with_link "[/delay/500 vs /delay/10]: ${ASYNC_T_SHORT}s vs ${ASYNC_T_LONG}s — the delay does not track the parameter" \
            "$ASYNC_DOCS"
    fi

    # A fixed multi-second sleep would satisfy every lower bound above. This is
    # the only upper bound in the section, and it is deliberately loose: it
    # exists to catch a constant, not to grade timer precision.
    if awk -v s="$ASYNC_T_SHORT" 'BEGIN{exit !(s+0 <= 2.0)}'; then
        echo "  PASS [/delay/10 is not a constant long sleep] (${ASYNC_T_SHORT}s)"
        PASS=$((PASS + 1))
    else
        fail_with_link "[/delay/10]: took ${ASYNC_T_SHORT}s for a 10ms delay" "$ASYNC_DOCS"
    fi

    echo "[test] async concurrent delays"
    async_concurrent_probe "32 overlapping requests, 32 different delays" 32 "$ASYNC_DOCS"
fi

if has_test "async-db"; then
    ASYNCDB_DOCS="$DOCS_BASE/h1/async-database/validation"
    echo "[test] async-db endpoint"
    asyncdb_fail=false
    # ranges and limits drawn per run
    db_params=""
    for _ in 1 2 3 4; do
        _dbmin=$(rand_between 1 120)
        _dbmax=$((_dbmin + $(rand_between 20 300)))
        db_params="$db_params min=${_dbmin}&max=${_dbmax}&limit=$(rand_between 1 50)"
    done
    for dbp in $db_params; do
        dblimit=$(echo "$dbp" | grep -oP 'limit=\K[0-9]+')
        response=$(curl -s --max-time 30 "http://localhost:$PORT/async-db?$dbp" || true)
        pgdb_result=$(echo "$response" | python3 -c "
import sys, json
d = json.load(sys.stdin)
count = d.get('count', 0)
items = d.get('items', [])
has_rating = all('rating' in item and 'score' in item['rating'] for item in items) if items else False
has_tags = all(isinstance(item.get('tags'), list) for item in items) if items else False
has_active_bool = all(isinstance(item.get('active'), bool) for item in items) if items else False
print(f'{count} {has_rating} {has_tags} {has_active_bool}')
" 2>/dev/null || echo "0 False False False")
        pgdb_count=$(echo "$pgdb_result" | cut -d' ' -f1)
        pgdb_rating=$(echo "$pgdb_result" | cut -d' ' -f2)
        pgdb_tags=$(echo "$pgdb_result" | cut -d' ' -f3)
        pgdb_active=$(echo "$pgdb_result" | cut -d' ' -f4)

        if [ "$pgdb_count" = "$dblimit" ] && [ "$pgdb_rating" = "True" ] && [ "$pgdb_tags" = "True" ] && [ "$pgdb_active" = "True" ]; then
            :
        else
            fail_with_link "[GET /async-db?limit=$dblimit]: count=$pgdb_count, rating=$pgdb_rating, tags=$pgdb_tags, active=$pgdb_active" "$ASYNCDB_DOCS"
            asyncdb_fail=true
        fi
    done
    if [ "$asyncdb_fail" = "false" ]; then
        echo "  PASS [GET /async-db?limit=N] (4 limits verified, correct structure)"
        PASS=$((PASS + 1))
    fi

    check_header "GET /async-db Content-Type" "Content-Type" "application/json" "$ASYNCDB_DOCS" \
        "http://localhost:$PORT/async-db?min=10&max=50&limit=50"

    # Anti-cheat: empty range should return 0 items
    response_empty=$(curl -s --max-time 30 "http://localhost:$PORT/async-db?min=9999&max=9999&limit=50" || true)
    pgdb_empty=$(echo "$response_empty" | python3 -c "import sys,json; print(json.load(sys.stdin).get('count','-1'))" 2>/dev/null || echo "-1")
    if [ "$pgdb_empty" = "0" ]; then
        echo "  PASS [GET /async-db empty range] (count=0)"
        PASS=$((PASS + 1))
    else
        fail_with_link "[GET /async-db empty range]: expected count=0, got $pgdb_empty" "$ASYNCDB_DOCS"
    fi
fi

printf "scoped official profile checks: PASS=%s FAIL=%s\n" "$PASS" "$FAIL"
[ "$FAIL" -eq 0 ]
