#!/usr/bin/env python3
import asyncio
import importlib.util
import json
import select
import signal
import subprocess
import time
from pathlib import Path

spec = importlib.util.spec_from_file_location('fixture', '/tmp/uwz-arena-verify.py')
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)


def lock_waiters():
    output = subprocess.check_output(['docker', 'exec', fixture.CONTAINER, 'psql', '-U', 'bench', '-d', 'benchmark', '-Atc', "SELECT count(*) FROM pg_stat_activity WHERE datname='benchmark' AND client_addr IS NOT NULL AND wait_event_type='Lock'"], text=True)
    return int(output.strip())


async def blocked_shutdown(child):
    pairs = await fixture.open_connections(31642, 1024)
    payload = b'GET /async-db?min=1&max=500&limit=50 HTTP/1.1\r\nHost: localhost\r\n\r\n'
    for _, writer in pairs:
        writer.write(payload)
    await asyncio.gather(*(writer.drain() for _, writer in pairs))
    for _ in range(50):
        waiting = lock_waiters()
        if waiting >= 128:
            break
        await asyncio.sleep(.02)
    else:
        raise AssertionError(f'no proven blocked work: {waiting}')
    child.send_signal(signal.SIGTERM)
    outcomes = await asyncio.wait_for(asyncio.gather(*(reader.read() for reader, _ in pairs), return_exceptions=True), 20)
    for _, writer in pairs:
        writer.close()
    await asyncio.gather(*(writer.wait_closed() for _, writer in pairs), return_exceptions=True)
    code = child.wait(timeout=20)
    assert code == 0, code
    return {'connections': len(pairs), 'requests_submitted': len(pairs), 'postgres_lock_waiters_before_shutdown': waiting, 'application_exit': code, 'received_bytes': sum(len(value) for value in outcomes if isinstance(value, bytes))}


def main():
    binary = Path('/home/foo/Desktop/Repos/uWebZockets/.zig-cache/o/56d1437a6940a89877c4542b0369c71b/sql_httparena')
    child = fixture.launch(binary, 'queued_blocked', 31642)
    lock = None
    try:
        lock = subprocess.Popen(['docker', 'exec', '-i', fixture.CONTAINER, 'psql', '-XqAt', '-U', 'bench', '-d', 'benchmark', '-v', 'ON_ERROR_STOP=1'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        lock.stdin.write("BEGIN;\nSET LOCAL application_name='uwz_arena_shutdown_lock';\nLOCK TABLE items IN ACCESS EXCLUSIVE MODE;\nSELECT 'uwz_arena_lock_ready';\n")
        lock.stdin.flush()
        assert select.select([lock.stdout], [], [], 10)[0], 'lock readiness timeout'
        assert lock.stdout.readline().strip() == 'uwz_arena_lock_ready'
        result = asyncio.run(blocked_shutdown(child))
    finally:
        if child.poll() is None:
            fixture.cleanup_container('queued_blocked')
            child.wait(timeout=10)
        if lock is not None:
            lock.stdin.write('ROLLBACK;\n\\q\n')
            lock.stdin.flush()
            lock.stdin.close()
            assert lock.wait(timeout=10) == 0
    fixture.wait_pg_connections(0)
    result['metrics'] = fixture.metrics('queued_blocked')
    assert result['metrics']['rendered_queries'] == 0
    result['database_sockets_after_release'] = fixture.pg_connections()
    (fixture.OUT / 'queued-blocked-summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
