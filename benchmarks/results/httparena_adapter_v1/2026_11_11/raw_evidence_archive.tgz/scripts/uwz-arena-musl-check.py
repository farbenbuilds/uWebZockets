#!/usr/bin/env python3
import asyncio
import hashlib
import importlib.util
import json
from pathlib import Path
spec=importlib.util.spec_from_file_location('fixture','/tmp/uwz-arena-verify.py')
fixture=importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
binary=Path('/tmp/uwz-arena-musl-build/bin/uwebzockets')
child=fixture.launch(binary,'adapter_musl',31643,static=True)
try:
    result={'official_blocks':fixture.official('adapter_musl',31643),'standard':asyncio.run(fixture.populated('adapter_musl',31643)),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
finally:
    result['exit']=fixture.stop(child,'adapter_musl',False)
result['backend_connections_after_tests']=fixture.pg_connections()
(fixture.OUT/'musl-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
