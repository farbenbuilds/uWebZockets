#!/usr/bin/env python3
"""Correctness checks only; does not measure or claim throughput."""
import asyncio
import hashlib
import json
import os
import re
import resource
import signal
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

BASE = Path(Path('/tmp/uwz_arena_validation_path').read_text().strip())
OUT = BASE / 'final'
SOURCE = Path('/tmp/uwz-httparena-source-5646c1d2')
CONTAINER = (BASE / 'container.id').read_text().strip()
SECRET = dict(line.split('=', 1) for line in (BASE / 'postgres.env').read_text().splitlines())['POSTGRES_PASSWORD']
PGPORT = (BASE / 'port.txt').read_text().strip().rsplit(':', 1)[1]
DATABASE_URL = f'postgres://bench:{SECRET}@127.0.0.1:{PGPORT}/benchmark'
RESULTS = {}


def cleanup_container(name):
    cidfile = BASE / f'{name}.cid'
    if not cidfile.exists(): return
    cid = cidfile.read_text().strip()
    subprocess.run(['docker', 'rm', '--force', cid], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def pg_connections():
    text = subprocess.check_output(['docker', 'exec', CONTAINER, 'psql', '-U', 'bench', '-d', 'benchmark', '-Atc', "SELECT count(*) FROM pg_stat_activity WHERE datname='benchmark' AND usename='bench' AND client_addr IS NOT NULL"], text=True)
    return int(text.strip())


def wait_pg_connections(expected):
    for _ in range(100):
        value = pg_connections()
        if value == expected:
            return value
        time.sleep(.05)
    raise AssertionError(f'expected {expected} PostgreSQL sockets, got {value}')


def launch(binary, name, port, database=True, database_url=None, expected_connections=256, expected_workers=32, budget=256, static=False):
    env = os.environ.copy()
    for key in ('DATABASE_URL', 'DATABASE_MAX_CONN', 'UWZ_SQL_WORKERS', 'PGSSLROOTCERT', 'PGSSLSERVERNAME'):
        env.pop(key, None)
    if database:
        env['DATABASE_URL'] = database_url or DATABASE_URL
        env['DATABASE_MAX_CONN'] = str(budget)
    env.update(UWZ_HTTP_PORT=str(port), UZ_CERT=str(OUT / 'missing-cert.pem'), UZ_KEY=str(OUT / 'missing-key.pem'), UZ_DATASET=str(SOURCE / 'data/dataset.json'))
    logpath = OUT / f'{name}.log'
    binary_directory = OUT / 'binaries'
    binary_directory.mkdir(exist_ok=True)
    filename = 'adapter' if binary.name == 'uwebzockets' else 'standalone'
    shutil.copy2(binary, binary_directory / filename)
    envfile = BASE / f'{name}.private.env'
    selected = {key: value for key, value in env.items() if key in ('DATABASE_URL', 'DATABASE_MAX_CONN', 'UWZ_HTTP_PORT')}
    selected.update(UZ_CERT='/arena/missing-cert.pem', UZ_KEY='/arena/missing-key.pem', UZ_DATASET='/arena/dataset.json')
    envfile.write_text(''.join(f'{key}={value}\n' for key, value in selected.items()))
    envfile.chmod(0o600)
    cidfile = BASE / f'{name}.cid'
    if cidfile.exists(): cidfile.unlink()
    image = (BASE / 'image.txt').read_text().strip()
    nofile = resource.getrlimit(resource.RLIMIT_NOFILE)[1]
    command = ['docker', 'run', '--rm', '--init', '--label', 'uwz.agent=arena_adapter', '--label', 'uwz.purpose=v230-httparena-correctness', '--network', 'host', '--security-opt', 'seccomp=unconfined', '--ulimit', 'memlock=-1:-1', '--ulimit', f'nofile={nofile}:{nofile}', '--cidfile', str(cidfile), '--env-file', str(envfile), '--mount', f'type=bind,source={OUT},target=/arena,readonly', '--entrypoint', '/arena/runtime/ld-linux-x86-64.so.2', image, '--library-path', '/arena/runtime', f'/arena/binaries/{filename}']
    if static:
        index = command.index('--entrypoint')
        command = command[:index] + ['--entrypoint', f'/arena/binaries/{filename}', image]
    log = logpath.open('wb')
    child = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
    log.close()
    ready = expected_workers if database else None
    for _ in range(300):
        if child.poll() is not None:
            raise AssertionError(f'{name} exited before readiness: {child.returncode}')
        logs = logpath.read_text()
        count = sum(f'server listening on 127.0.0.1:{port}' in line or f'server listening on 0.0.0.0:{port}' in line for line in logs.splitlines())
        if (ready is not None and count == ready) or (ready is None and count > 0):
            if database:
                try:
                    wait_pg_connections(expected_connections)
                except BaseException:
                    cleanup_container(name)
                    child.wait(timeout=10)
                    raise
            cid = cidfile.read_text().strip()
            details = subprocess.check_output(['docker', 'exec', cid, 'sh', '-c', 'cat /proc/1/limits; for directory in /proc/[0-9]*/fd; do for descriptor in "$directory"/*; do readlink "$descriptor" || true; done; done'], text=True)
            (OUT / f'{name}-runtime.txt').write_text(details)
            assert re.search(r'^Max locked memory\s+unlimited\s+unlimited', details, re.M)
            limit = re.search(r'^Max open files\s+(\d+)\s+(\d+)', details, re.M)
            assert limit and int(limit[1]) == nofile and int(limit[2]) == nofile
            return child
        time.sleep(.1)
    cleanup_container(name)
    child.wait(timeout=15)
    raise AssertionError(f'{name} did not become ready')


def stop(child, name, graceful):
    child.send_signal(signal.SIGTERM)
    try:
        code = child.wait(timeout=20)
    except subprocess.TimeoutExpired:
        cleanup_container(name)
        child.wait(timeout=10)
        raise
    if graceful:
        assert code == 0, (name, code)
    else:
        assert code == 128 + signal.SIGTERM, (name, code)
    wait_pg_connections(0)
    return code


def official(name, port, tests='async async-db'):
    target = OUT / f'{name}-official'
    target.mkdir()
    original = (BASE / 'official-profile-checks.sh').read_text()
    original = original.replace("TESTS='async async-db'", 'TESTS=${2:-async async-db}', 1)
    script = target / 'checks.sh'
    script.write_text(original)
    with (target / 'checks.log').open('wb') as log:
        subprocess.run(['bash', str(script), str(port), tests], stdout=log, stderr=subprocess.STDOUT, check=True)
    return (target / 'checks.log').read_text().splitlines()[-1]


def validate(body, minimum, maximum, limit):
    assert body['count'] == limit and len(body['items']) == limit, (body.get('count'), limit)
    for item in body['items']:
        assert minimum <= item['price'] <= maximum
        assert type(item['id']) is int and type(item['price']) is int and type(item['quantity']) is int
        assert type(item['active']) is bool
        assert isinstance(item['tags'], list) and all(isinstance(tag, str) for tag in item['tags'])
        assert type(item['rating']['score']) is int and type(item['rating']['count']) is int


async def open_connections(port, count):
    return await asyncio.gather(*(asyncio.open_connection('127.0.0.1', port) for _ in range(count)))


async def one_request(index, pair):
    reader, writer = pair
    minimum = 1 + index * 37 % 120
    maximum = minimum + 20 + index * 13 % 300
    limit = 1 + index * 7 % 50
    request = f'GET /async-db?min={minimum}&max={maximum}&limit={limit} HTTP/1.1\r\nHost: localhost\r\nConnection: keep-alive\r\n\r\n'.encode()
    writer.write(request)
    await writer.drain()
    header = await asyncio.wait_for(reader.readuntil(b'\r\n\r\n'), 20)
    lines = header.decode('ascii').split('\r\n')
    status = int(lines[0].split()[1])
    headers = dict(line.split(': ', 1) for line in lines[1:] if line)
    length = int(next(value for key, value in headers.items() if key.lower() == 'content-length'))
    content_type = next(value for key, value in headers.items() if key.lower() == 'content-type')
    assert content_type.startswith('application/json')
    raw = await asyncio.wait_for(reader.readexactly(length), 20)
    assert status == 200, (index, status, raw)
    body = json.loads(raw)
    validate(body, minimum, maximum, limit)
    return {'index': index, 'min': minimum, 'max': maximum, 'limit': limit, 'status': status, 'content_type': content_type, 'body': body}


async def populated(name, port):
    pairs = await open_connections(port, 1024)
    try:
        results = await asyncio.gather(*(one_request(index, pair) for index, pair in enumerate(pairs)))
    finally:
        for _, writer in pairs:
            writer.close()
        await asyncio.gather(*(writer.wait_closed() for _, writer in pairs), return_exceptions=True)
    with (OUT / f'{name}-1024.jsonl').open('w') as target:
        for result in results:
            target.write(json.dumps(result, ensure_ascii=False) + '\n')
    return {'connections': len(pairs), 'requests': len(results), 'exact_populated_results': len(results), 'empty_fallbacks': 0, 'non_200': 0}


async def queued_shutdown(child, port):
    pairs = await open_connections(port, 1024)
    payload = b'GET /async-db?min=1&max=500&limit=50 HTTP/1.1\r\nHost: localhost\r\n\r\n'
    for _, writer in pairs:
        writer.write(payload)
    await asyncio.gather(*(writer.drain() for _, writer in pairs))
    await asyncio.sleep(.001)
    child.send_signal(signal.SIGTERM)
    outcomes = await asyncio.wait_for(asyncio.gather(*(reader.read() for reader, _ in pairs), return_exceptions=True), 20)
    for _, writer in pairs:
        writer.close()
    await asyncio.gather(*(writer.wait_closed() for _, writer in pairs), return_exceptions=True)
    return {'connections': len(pairs), 'shutdown_after_submission_ms': 1, 'received_bytes': sum(len(value) for value in outcomes if isinstance(value, bytes))}


def metrics(name):
    logs = (OUT / f'{name}.log').read_text()
    entries = re.findall(r'rendered_queries=(\d+) empty_fallbacks=(\d+) rejected_responses=(\d+)', logs)
    assert len(entries) == 32, len(entries)
    result = dict(zip(('rendered_queries', 'empty_fallbacks', 'rejected_responses'), map(sum, zip(*(tuple(map(int, entry)) for entry in entries)))))
    assert result['empty_fallbacks'] == 0 and result['rejected_responses'] == 0, result
    return result


def main():
    standalone = Path(sys.argv[1]).resolve()
    adapter = Path(sys.argv[2]).resolve()
    assert not (OUT / 'missing-cert.pem').exists()
    child = launch(standalone, 'standalone', 31642)
    try:
        RESULTS['standalone_official'] = official('standalone', 31642)
        RESULTS['standalone_standard'] = asyncio.run(populated('standalone', 31642))
    finally:
        RESULTS['standalone_exit'] = stop(child, 'standalone', True)
    RESULTS['standalone_metrics'] = metrics('standalone')

    child = launch(standalone, 'queued_shutdown', 31642)
    try:
        RESULTS['queued_shutdown'] = asyncio.run(queued_shutdown(child, 31642))
        RESULTS['queued_shutdown_exit'] = child.wait(timeout=20)
        assert RESULTS['queued_shutdown_exit'] == 0
        wait_pg_connections(0)
    finally:
        if child.poll() is None:
            stop(child, 'queued_shutdown', True)
    RESULTS['queued_shutdown_metrics'] = metrics('queued_shutdown')

    child = launch(standalone, 'recovery', 31642)
    try:
        with urllib.request.urlopen('http://127.0.0.1:31642/async-db?min=10&max=50&limit=50', timeout=20) as response:
            body = json.load(response)
        validate(body, 10, 50, 50)
        RESULTS['restart_recovery'] = True
    finally:
        RESULTS['recovery_exit'] = stop(child, 'recovery', True)
    RESULTS['recovery_metrics'] = metrics('recovery')

    child = launch(adapter, 'adapter_no_url', 31643, False)
    try:
        with urllib.request.urlopen('http://127.0.0.1:31643/baseline11?a=2&b=3', timeout=20) as response:
            assert response.read() == b'5'
        RESULTS['adapter_no_url_baseline'] = True
        RESULTS['adapter_no_url_async'] = official('adapter_no_url', 31643, 'async')
        assert pg_connections() == 0
    finally:
        RESULTS['adapter_no_url_exit'] = stop(child, 'adapter_no_url', False)

    child = launch(adapter, 'adapter_database', 31643)
    try:
        RESULTS['adapter_official'] = official('adapter_database', 31643)
        RESULTS['adapter_standard'] = asyncio.run(populated('adapter', 31643))
    finally:
        RESULTS['adapter_exit'] = stop(child, 'adapter_database', False)
    RESULTS['database_sockets_after_tests'] = pg_connections()
    RESULTS['binary_sha256'] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in (standalone, adapter)}
    RESULTS['scope'] = 'correctness only; owned container has process-local unlimited memlock and cached host GNU runtime; TLS/H3 adapter listeners deliberately disabled; upstream full Docker and official benchmark not run'
    (OUT / 'summary.json').write_text(json.dumps(RESULTS, indent=2) + '\n')
    print(json.dumps(RESULTS, indent=2))

if __name__ == '__main__':
    try:
        main()
    except BaseException:
        (OUT / 'partial-summary.json').write_text(json.dumps(RESULTS, indent=2) + '\n')
        raise
