#!/usr/bin/env python3
import asyncio
import importlib.util
import json
from pathlib import Path

spec = importlib.util.spec_from_file_location('fixture', '/tmp/uwz-arena-verify.py')
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
binary = Path('/tmp/uwz-httparena-source-5646c1d2/frameworks/uwebzockets/zig-out/bin/uwebzockets')
results = {}

child = fixture.launch(binary, 'budget224_green', 31643, expected_connections=224, expected_workers=28, budget=224)
try:
    with fixture.urllib.request.urlopen('http://127.0.0.1:31643/async-db?min=10&max=50&limit=50', timeout=20) as response:
        body = json.load(response)
    fixture.validate(body, 10, 50, 50)
    results['budget224'] = {'workers': 28, 'pool_connections': fixture.pg_connections(), 'count': body['count'], 'acceptance_passed': True}
finally:
    results['budget224_exit'] = fixture.stop(child, 'budget224_green', False)

child = fixture.launch(binary, 'adapter_final', 31643)
try:
    results['current_official_blocks'] = fixture.official('adapter_final', 31643)
    results['standard'] = asyncio.run(fixture.populated('adapter_final', 31643))
finally:
    results['standard_exit'] = fixture.stop(child, 'adapter_final', False)

child = fixture.launch(binary, 'adapter_final_no_url', 31643, False)
try:
    with fixture.urllib.request.urlopen('http://127.0.0.1:31643/baseline11?a=2&b=3', timeout=20) as response:
        assert response.read() == b'5'
    results['no_url_baseline'] = True
    results['no_url_current_async_blocks'] = fixture.official('adapter_final_no_url', 31643, 'async')
    assert fixture.pg_connections() == 0
finally:
    results['no_url_exit'] = fixture.stop(child, 'adapter_final_no_url', False)

results['backend_connections_after_tests'] = fixture.pg_connections()
(fixture.OUT / 'final-external-summary.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
