#!/usr/bin/env sh
set -eu
adapter=/tmp/uwz-httparena-source-5646c1d2/frameworks/uwebzockets
cd "$adapter"
original=$(mktemp /tmp/uwz-arena-zon.XXXXXXXX)
cp build.zig.zon "$original"
cleanup()
{
    cp "$original" build.zig.zon
    rm -f "$original"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' HUP TERM
python3 - <<'PY'
import os
from pathlib import Path
p=Path('build.zig.zon')
s=p.read_text()
start=s.index('            .url = ')
end=s.index('\n        },',start)
s=s[:start]+'            .path = "'+os.path.relpath('/home/foo/Desktop/Repos/uWebZockets')+'",'+s[end:]
p.write_text(s)
PY
env PATH="/tmp/zig-x86_64-linux-0.16.0:$PATH" ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-zig-cache zig build -Dtarget=x86_64-linux-musl -Dcpu=x86_64_v3+aes+pclmul+adx -Doptimize=ReleaseFast -j2 --prefix /tmp/uwz-arena-musl-build --summary all
