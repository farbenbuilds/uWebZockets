#!/usr/bin/env python3
"""Check retained correctness evidence without sockets or database access."""
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent


def load(name):
    return json.loads((ROOT / name).read_text())


def digest(name):
    return hashlib.sha256((ROOT / name).read_bytes()).hexdigest()


def seed_rows():
    rows = {}
    copying = False
    for line in (ROOT / 'fixture/pgdb-seed.sql').read_text().splitlines():
        if line.startswith('COPY items '):
            copying = True
            continue
        if not copying:
            continue
        if line == r'\.':
            break
        fields = line.split('\t')
        assert len(fields) == 9
        assert '\\' not in ''.join(fields), 'Seed needs PostgreSQL COPY unescaping'
        identifier, name, category, price, quantity, active, tags, score, count = fields
        assert active in ('t', 'f')
        row = {
            'id': int(identifier), 'name': name, 'category': category,
            'price': int(price), 'quantity': int(quantity), 'active': active == 't',
            'tags': json.loads(tags), 'rating': {'score': int(score), 'count': int(count)},
        }
        assert row['id'] not in rows
        rows[row['id']] = row
    assert len(rows) == 100000
    return rows


def verify_responses(name, rows):
    seen = set()
    for line in (ROOT / 'evidence' / name).read_text().splitlines():
        response = json.loads(line)
        index = response['index']
        assert 0 <= index < 1024 and index not in seen
        seen.add(index)
        minimum = 1 + index * 37 % 120
        maximum = minimum + 20 + index * 13 % 300
        limit = 1 + index * 7 % 50
        assert (response['min'], response['max'], response['limit']) == (minimum, maximum, limit)
        assert response['status'] == 200
        assert response['content_type'].startswith('application/json')
        body = response['body']
        assert body['count'] == limit and len(body['items']) == limit
        assert len({item['id'] for item in body['items']}) == limit
        for item in body['items']:
            assert minimum <= item['price'] <= maximum
            assert all(type(item[key]) is int for key in ('id', 'price', 'quantity'))
            assert type(item['active']) is bool
            assert all(type(item['rating'][key]) is int for key in ('score', 'count'))
            assert item == rows[item['id']], (name, index, item['id'])
    assert len(seen) == 1024
    return len(seen)


def main():
    seed_hash = (ROOT / 'evidence/seed.sha256').read_text().split()[0]
    assert digest('fixture/pgdb-seed.sql') == seed_hash
    upstream_hash = (ROOT / 'scripts/official-validation-source.sha256').read_text().split()[0]
    assert digest('upstream/scripts/validate.sh') == upstream_hash
    proposal = load('proposal.json')
    assert digest('proposed/build.zig.zon') == digest('before/build.zig.zon')
    assert digest('proposed/build.zig.zon') == proposal['adapter_manifest_sha256']
    assert digest('library_candidate.tgz') == proposal['library_candidate_archive_sha256']
    assert proposal['native_binary_sha256'] == (ROOT / 'evidence/native_adapter.sha256').read_text().split()[0]
    assert proposal['musl_binary_sha256'] == (ROOT / 'evidence/musl_adapter.sha256').read_text().split()[0]
    red = load('evidence/budget224-red-summary.json')
    assert (red['observed_workers'], red['observed_pool_connections'], red['acceptance_passed']) == (16, 128, False)
    green = load('evidence/final-external-summary.json')['budget224']
    assert (green['workers'], green['pool_connections'], green['acceptance_passed']) == (28, 224, True)
    queued = load('evidence/queued-blocked-summary.json')
    assert queued['postgres_lock_waiters_before_shutdown'] == 256
    assert queued['requests_submitted'] == 1024 and queued['application_exit'] == 0
    assert queued['received_bytes'] == 0 and queued['database_sockets_after_release'] == 0
    assert queued['metrics'] == {'rendered_queries': 0, 'empty_fallbacks': 0, 'rejected_responses': 0}
    rows = seed_rows()
    responses = sum(verify_responses(name, rows) for name in (
        'standalone-1024.jsonl', 'adapter-1024.jsonl',
        'adapter_final-1024.jsonl', 'adapter_musl-1024.jsonl',
    ))
    assert not proposal['official_full_run'] and not proposal['throughput_acceptance']
    print(json.dumps({'seed_rows': len(rows), 'exact_seed_matched_responses': responses,
                      'source_and_checksums': 'passed', 'exact_worker_regression': 'passed',
                      'blocked_shutdown_evidence': 'passed'}))


if __name__ == '__main__':
    main()
