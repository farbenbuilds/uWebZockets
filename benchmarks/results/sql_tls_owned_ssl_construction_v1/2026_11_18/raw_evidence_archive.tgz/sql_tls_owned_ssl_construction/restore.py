#!/usr/bin/env python3
"""Restore the SSL construction checkpoint from its complete external parent.

Python validates and restores evidence. Zig alone builds the native source image.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess


def require(condition, message):
    if not condition:
        raise SystemExit(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def safe_name(name):
    require(isinstance(name, str) and name and '\\' not in name
            and not any(ord(ch) < 32 for ch in name), 'unsafe identity path')
    value = PurePosixPath(name)
    require(not value.is_absolute() and '..' not in value.parts
            and value.as_posix() == name and '.git' not in value.parts,
            'unsafe identity path: ' + name)
    return name


def entries_by_path(entries):
    require(isinstance(entries, list), 'identity entries must be a list')
    result = {}
    for entry in entries:
        name = safe_name(entry['path'])
        require(name not in result, 'duplicate identity path: ' + name)
        require(isinstance(entry['sha256'], str) and len(entry['sha256']) == 64
                and all(ch in '0123456789abcdef' for ch in entry['sha256']),
                'invalid source hash: ' + name)
        require(type(entry['mode']) is int and 0 <= entry['mode'] <= 0o777,
                'invalid source mode: ' + name)
        result[name] = entry
    return result


def file_names(directory, ignore_git=False):
    require(directory.is_dir() and not directory.is_symlink(), 'source directory missing or linked')
    names = set()
    for path in directory.rglob('*'):
        relative = path.relative_to(directory)
        if ignore_git and '.git' in relative.parts:
            continue
        require(not path.is_symlink(), 'source symlink: ' + relative.as_posix())
        mode = path.stat().st_mode
        require(stat.S_ISREG(mode) or stat.S_ISDIR(mode), 'source special file: ' + relative.as_posix())
        if stat.S_ISREG(mode):
            names.add(relative.as_posix())
    return names


def verify_files(directory, entries, exact=True, ignore_git=False):
    expected = entries_by_path(entries)
    if exact:
        require(file_names(directory, ignore_git) == set(expected), 'source file set differs: ' + str(directory))
    for name, entry in expected.items():
        path = directory / name
        require(path.is_file() and not path.is_symlink(), 'source is not a regular file: ' + name)
        for ancestor in path.parents:
            if ancestor == directory:
                break
            require(not ancestor.is_symlink(), 'source parent symlink: ' + name)
        require(digest(path) == entry['sha256'], 'source hash: ' + name)
        require(path.stat().st_mode & 0o777 == entry['mode'], 'source mode: ' + name)
    return expected


def verify_packet(packet):
    manifest = packet / 'files.sha256'
    require(manifest.is_file() and not manifest.is_symlink(), 'packet manifest missing or linked')
    expected = {}
    for line in manifest.read_text().splitlines():
        fields = line.split('  ', 1)
        require(len(fields) == 2, 'invalid packet manifest line')
        sha256, name = fields
        safe_name(name)
        require(name not in expected and name != 'files.sha256', 'duplicate packet manifest path')
        require(len(sha256) == 64 and all(ch in '0123456789abcdef' for ch in sha256),
                'invalid packet manifest hash')
        expected[name] = sha256
    require(file_names(packet) == set(expected) | {'files.sha256'}, 'packet file set differs')
    for name, sha256 in expected.items():
        require(digest(packet / name) == sha256, 'packet hash: ' + name)
    identity = json.loads((packet / 'payload_identity.json').read_text())
    indexed = verify_files(packet, identity, exact=False)
    require(set(indexed) == set(expected) - {'payload_identity.json'}, 'packet mode identity coverage differs')


parser = argparse.ArgumentParser()
parser.add_argument('--parent', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--zig', type=Path)
args = parser.parse_args()
packet = Path(__file__).resolve().parent
out = args.output.resolve()
for ancestor in (out, *out.parents):
    require(not (ancestor / 'files.sha256').exists(), 'output must be outside an evidence artifact')
require(not out.exists(), 'output already exists')
require(not any(ch in ('"', '\\') or ord(ch) < 32 for ch in str(out)),
        'Zig 0.16 source paths must not contain quotes, backslashes or control characters')
parent = args.parent.resolve()
require(not out.is_relative_to(parent) and not parent.is_relative_to(out), 'output overlaps native parent')
require(not out.is_relative_to(packet) and not packet.is_relative_to(out), 'output overlaps packet')
zig = args.zig.resolve() if args.zig else None
compiler_sha256 = '2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c'
if zig:
    require(zig.is_file() and digest(zig) == compiler_sha256, 'compiler hash differs')

identity_root = packet / 'source_identity'
parent_identity = identity_root / 'parent_native_identity.json'
expected = json.loads(parent_identity.read_text())['files']
candidate = json.loads((identity_root / 'native_source_identity.json').read_text())
sdk_parent_path = identity_root / 'parent_sdk_identity.json'
sdk_parent = json.loads(sdk_parent_path.read_text())
sdk = json.loads((identity_root / 'sdk_final_source_identity.json').read_text())
proof = json.loads((identity_root / 'final_proof_identity.json').read_text())
require(digest(parent_identity) == candidate['parent_identity_sha256'], 'parent identity binding differs')
require(proof['compiler_sha256'] == compiler_sha256, 'proof compiler binding differs')
require(digest(identity_root / 'native_source_identity.json') == proof['native_identity_sha256'],
        'proof native identity binding differs')
before = entries_by_path(expected)
after = entries_by_path(candidate['files'])
require(len(before) == len(after) == 8709 and set(before) == set(after), 'native source set differs')
require(all(before[name]['mode'] == after[name]['mode'] for name in before), 'native source mode delta')
changed = [safe_name(name) for name in candidate['changed_paths']]
require(len(changed) == len(set(changed)) == 16, 'native replacement set differs')
require(set(changed) == {name for name in before if before[name] != after[name]}, 'native delta differs')
before_sdk = entries_by_path(sdk_parent['files'])
after_sdk = entries_by_path(sdk['files'])
require(digest(sdk_parent_path) == sdk['parent_identity_sha256'], 'SDK parent identity binding differs')
require(len(before_sdk) == 499 and len(after_sdk) == 501 and set(before_sdk) <= set(after_sdk),
        'SDK source count or set differs')
require(set(after_sdk) - set(before_sdk) == {'src/sql/ssl_storage.zig', 'src/tests/sql_ssl_storage_tests.zig'},
        'SDK addition set differs')
require({name for name in before_sdk if before_sdk[name] != after_sdk[name]} == {
        'builds/vendor/boringssl.zig', 'src/crypto/tls_client.zig', 'src/sql/connection.zig',
        'src/sql/db.zig', 'src/test_support.zig', 'src/tests/main.zig'}, 'SDK modified set differs')
require(all(before_sdk[name]['mode'] == after_sdk[name]['mode'] for name in before_sdk), 'SDK source mode delta')
verify_files(parent, expected, ignore_git=True)
verify_files(packet / 'candidate_files', [after[name] for name in changed])
verify_files(packet / 'sdk', sdk['files'])
proof_entries = proof['proof_files']
proof_names = set(entries_by_path(proof_entries))
require('build.zig' in proof_names and all(name == 'build.zig' or name.startswith('proof/')
        for name in proof_names), 'proof input scope differs')
require(file_names(packet / 'proof') == {name[6:] for name in proof_names if name.startswith('proof/')},
        'proof file set differs')
verify_files(packet, proof_entries, exact=False)
replay_entries = json.loads((identity_root / 'replay_source_identity.json').read_text())['files']
replay_names = set(entries_by_path(replay_entries))
require(all(name.startswith('lifecycle_consumer/') or name in
        {'run_lifecycle.py', 'run_sdk_check.py', 'compare_lifecycle.py'} for name in replay_names),
        'replay source scope differs')
require(file_names(packet / 'lifecycle_consumer') == {name[19:] for name in replay_names
        if name.startswith('lifecycle_consumer/')}, 'lifecycle source file set differs')
verify_files(packet, replay_entries, exact=False)
builder_entry = 'builds/vendor/boringssl.zig'
builder_text = (packet / 'sdk' / builder_entry).read_text()
old_source = candidate['actual_candidate_source']
require(builder_text.count(old_source) == 1, 'expected exactly one native source path')
verify_packet(packet)

out.mkdir(parents=True, exist_ok=False)
source = out / 'boringssl'
for name in before:
    destination = source / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(parent / name, destination)
for name in changed:
    shutil.copy2(packet / 'candidate_files' / name, source / name)
verify_files(source, candidate['files'])
shutil.copytree(packet / 'sdk', out / 'sdk')
for entry in [*proof_entries, *replay_entries]:
    destination = out / entry['path']
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(packet / entry['path'], destination)
builder = out / 'sdk' / builder_entry
encoded = ''.join(chr(byte) if 0x20 <= byte < 0x7f and byte not in (34, 92)
                  else '\\x%02x' % byte for byte in str(source).encode())
builder.write_text(builder_text.replace(old_source, encoded))
builder.chmod(entries_by_path(sdk['files'])[builder_entry]['mode'])
record = {'parent_verified_files': len(before), 'candidate_verified_files': len(after),
          'sdk_verified_files': len(sdk['files']), 'proof_verified_files': len(proof_entries),
          'replay_verified_files': len(replay_entries), 'changed_paths': changed,
          'builder_path_rebound': True, 'packet_manifest_verified': True,
          'restored_builder_sha256': digest(builder), 'proof_executed': False}
if zig:
    command = [str(zig), 'build', 'proof', '-Doptimize=ReleaseSafe', '-j4',
               '--cache-dir', 'cache', '--global-cache-dir', 'global-cache', '--summary', 'all']
    with (out / 'proof.log').open('wb') as stream:
        result = subprocess.run(command, cwd=out, stdout=stream, stderr=subprocess.STDOUT)
    record.update(proof_executed=True, command=command, exit_code=result.returncode)
(out / 'restoration.json').write_text(json.dumps(record, indent=2) + '\n')
require(not zig or record['exit_code'] == 0, 'native proof failed')
print(json.dumps(record))
