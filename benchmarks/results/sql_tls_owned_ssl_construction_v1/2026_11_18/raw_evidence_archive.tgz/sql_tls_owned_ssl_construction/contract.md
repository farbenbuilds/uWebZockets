# Owned client SSL construction and identity setup

Status: Root freezes the profile/interface below after independent contract
review; implementation and measured acceptance remain outstanding.
The objective remains all v2.3.0 requirements in TODO.md. Previous turn made
verified progress and pushed b5f221b00c33e70027133428a1fdb79f4872c57e.

## Immutable inputs and permitted scope

Use the complete native parent ../tls-owned-bio-pair-20261118/boringssl, whose
8709-file identity is 698bc252dcd3b629fb4f779e18ec3889aa96ccf5ab2b6eb2f174e0789647ed7b.
The matching 499-file SDK is ../tls-owned-bio-pair-20261118/sdk, identity
994b9913aa379b7f91b02bacac5b04b88b96c1d773f0454a20ef5b7977f0057b.
Copy both to fresh complete workspace-SSD trees before implementation. No parent,
protected vendor, main branch, production dependency pin, new remote or
publication destination may change.

Close actual connection-owned construction and identity setup, not generic TLS
allocation. Current SQL supports verified TLS1.3 with an explicitly required
caller CA bundle, DNS/IPv4/IPv6 identity and PostgreSQL without HTTP ALPN. Preserve every
one of those capabilities. Existing ordinary TLS entry points and development
verify=false behavior remain intact. No PostgreSQL allocation exception exists.

The retained trace observes sixteen eager allocations per SSL_new: SSLImpl,
SSL_CONFIG, CERT, its initial credential and replacement clone, TLS1.3 cipher
stack/backing/flags, group IDs/flags, S3, two null AEADs, handshake, transcript
BUF_MEM descriptor and X509 verification parameters. Nine in-interval calls
account for 144 mallocs/52731 requested bytes. SNI and DNS verification add 36
mallocs/1116 bytes. Fresh same-fixture evidence is authoritative for the actual
delta; these counts only identify the implementation closure.

## Additive native interface

Declare in include/openssl/ssl.h:

```c
typedef struct ssl_client_construction_requirements_st {
  size_t bytes;
  size_t alignment;
  size_t block_bytes;
  size_t block_count;
} SSL_CLIENT_CONSTRUCTION_REQUIREMENTS;

OPENSSL_EXPORT int SSL_client_construction_storage_requirements(
    const SSL_CTX *ctx, size_t max_server_name_bytes,
    SSL_CLIENT_CONSTRUCTION_REQUIREMENTS *out);

OPENSSL_EXPORT SSL *SSL_new_client_with_construction_domain(
    SSL_CTX *ctx, const OPENSSL_ALLOCATION_DOMAIN *domain);
```

The factory owns all eager constructor allocations admitted by its profile and
arms client state. It is not SSL_new_with_domain and makes no subsequent TLS
ownership promise. One private shared constructor with an optional explicit
domain preserves ordinary SSL_new without duplicating its scalar/config/ref
copying. Cold process/thread/RNG/ERR work retains existing separate ownership.

Before any domain allocation, admit only understood clone shapes. All SQL client
contexts above must pass, including arbitrary trust bundles and verify=false
development contexts. A raw context with configured client credentials,
identity/policy lists, custom unsupported X509 method/callback/extension clone
shape may be rejected only by this new profile, explicitly and without fallback.
Do not reject scalar flags/depth or any actual SQL option merely to simplify a
bound. One shared pure profile predicate must require the ordinary TLS client
protocol method (no DTLS), no QUIC, the standard ssl_crypto_x509_method on both
context and CERT, and nonnull context/CERT/legacy credential/verification param.
Require empty cert.credentials and cert.available_trust_anchors. The legacy
credential must satisfy its ordinary Dup invariants: kX509, no delegated
credential, zero delegated algorithm, empty sid_ctx; its chain/sigalgs and
pubkey/privkey/key_method/signed_cert_timestamp_list/ocsp_response are empty.
Require empty context alpn_client_proto_list and verify_sigalgs, absent
requested_trust_anchors and psk_identity_hint; verification param policies,
hosts, email and ip are null and poison is zero. Size TLS1.3 cipher and group
copies from their actual capacities/counts. Non-clone callbacks are copied
without being invoked and need no blanket rejection. Context/trust-store
references keep their existing ownership; arbitrary trust contents, scalar
verification settings, flags and depth remain admitted.

Reject null context, null/malformed descriptor, unsupported profile, arithmetic
overflow and incompatible memory hooks before any domain callback. Factory
failure returns NULL with complete partial cleanup. Ordinary successful behavior
and representation stay intact. Source ssl_crypto_x509_ssl_new currently ignores
X509_VERIFY_PARAM_inherit failure: the owned path must check it and fail closed.
If correcting the ordinary erroneous OOM path too, retain a real parent failure
and prove that successful ordinary behavior is unchanged; never preserve dropped
verification constraints merely to retain a defective error path.

## Pure native bound and reusable slots

The query supports a max_server_name_bytes in 1..255 and covers constructor,
one SNI assignment, one DNS/IP verification assignment and repeat SSL_clear
under the same admitted configuration. Clear must inherit the actual SSL root's
owner when recreating S3, AEAD, handshake and transcript descriptors. It cannot
silently allocate those objects on the heap. Repeated setup beyond this stated
sequence may exhaust the bounded domain and fail; it never falls back or grows.
Preserve SSL_clear's existing destructive failure semantics: allocation failure
after old state destruction requires complete cleanup and an SSL that remains
freeable. It does not promise rollback to the old connection state.

Query behavior is pure: no allocation, ERR, RNG, hook lookup, thread/once,
callback, refcount mutation, clock or I/O. Null output fails; accessible output
is cleared on failure. Context inputs must remain alive and immutable across
sizing/construction; callers keep ordinary context lifetime/synchronization
responsibilities. Concurrent mutation is not admitted.

Use the existing authoritative private GetAllocationDomainRequirements helper.
For every admitted eager/setup allocation, derive checked raw extent and
alignment from actual sizes/capacities. Stack duplication copies num_alloc
capacity, not just num. Compute block_bytes by checked alignment of the largest
raw request, block_count as a conservative proven live-slot bound for the stated
sequence, and bytes as checked block_bytes*block_count. Count every new owned
implementation allocation, including zero-capacity backing or temporary clone
overlap; do not assume it has exactly the old sixteen allocation operations.
For the admitted parent shape, thirteen constructor operations exclude the
three possibly nonempty TLS1.3 flags/group arrays, then at most four allocations
cover SNI plus DNS setup. The standard shape gives twenty conservative slots
(nineteen final live after the transient default credential is freed). Re-derive
the count from the actual new helpers and their zero-length behavior. Destructive
clear releases and replaces five eager allocations without raising this bound.
The private native stack sizing helper owns descriptor size, capacity and the
minimum four-entry backing rule; no private stack formula goes into Zig.

The old profile suggests about 20 slots with largest payload 2288, stride about
2320 and total about 46400 bytes, but these are illustrative only. Native query
results and proof determine actual values; no private size/header/count formula
is copied into Zig. This is a construction/setup bound, never a total TLS budget.

Use bounded reusable fixed-stride slots for the new SSL storage. First-free
selection, checked pointer/extent/alignment release and immediate slot reuse
avoid fragmentation. A permanent SSL/config allocation means live count rarely
reaches zero during clear: a bump-reset-only allocator is insufficient. Do not
introduce a general allocator framework, hidden current owner, TLS router,
global registry, spare SSL stock, admission pause or delayed native destruction.

## Native propagation and lifetime

Expected paths are include/openssl/ssl.h; ssl/{ssl_lib.cc,internal.h,ssl_cert.cc,
ssl_credential.cc,ssl_cipher.cc,s3_lib.cc,handshake.cc,ssl_aead_ctx.cc,
ssl_transcript.cc,ssl_x509.cc}; crypto/x509/{x509_vpm.cc,internal.h};
crypto/stack/stack.cc and crypto/internal.h for its private declarations;
crypto/mem_internal.h. Any additional path requires Root ownership approval.

Use a documented private placement constructor and actual trivial-array copy
helper only at real call sites. Propagate the explicit destination owner through
CERT/credential/cipher/group copies, S3/null AEAD/handshake and BUF_MEM descriptor
construction. Do not optimize away CERT's transient default credential in this
same change: own and account for its existing allocation first.

Identity setters choose the actual destination owner's descriptor. SNI uses the
SSL/config root; DNS/IP parameter setters use the destination parameter, not a
borrowed source. An owned parameter copied into ordinary verification storage
must produce ordinary destination-owned data; no connection domain may escape
to shared context/store state. Test both copy directions and free the source
first. Any provenance lookup requires an exact allocation root with a written
call-site proof; embedded transcripts, arrays/interior spans, static defaults,
stack objects and arbitrary pointers are forbidden probes. Hook-owned pointers
retain the memory module's hook-first protection.

SSLImpl is unique-owned: no SSL_up_ref exists in this image. Context, BIO and
credential reference lifetimes still matter. The domain descriptor/callback/
backing survive the last construction-owned allocation, through clear and free.
Extra BIO references remain on the separate established BIO domain. Do not
allocate shared trust or peer/session caches into connection storage. Reject
unsupported raw configuration before partial construction instead of silently
mixing ownership for its eager descendants.

## Prepared SDK integration

Add src/sql/ssl_storage.zig with named flat requirements/storage/block records
and bounded reusable slots, separate from the existing six-block BIO storage.
Each stable normal and cancellation Connection receives its own descriptor and
queried startup backing/metadata. Bind context pointers only in place; do not
put them inside Session, which resets itself on deinit. Db creates the client
context before querying requirements, then performs checked 2N allocation and
complete startup-failure cleanup.

Add a named SessionDomains input for an additive storage-aware initializer with
separate BIO and construction domains. Preserve ordinary and BIO-only entry
points and all supported protocol/verification behavior. Use the new native
constructor only where its profile is admitted. Keep dormant preconstructed
cancellation sessions, close draining and callback timing intact. Destroy both
Session arrays before either slab/metadata/context is released; phase dormant
does not prove storage has no live owner. There is no root production adoption
in this isolated slice.

## Evidence and implementation order

1. Independent contract review, then Root freezes profile/interface/ownership.
2. Capture real parent ordinary constructor/setup allocation RED with the
   original all-C counter and 63-byte self-test, and missing-public-API compile
   RED. Capture any inherited-param OOM defect before fixing that path.
3. Native owner implements complete admitted closure; verification owns separate
   proof/build inputs. SDK runtime owner uses actual query values and stable
   per-connection slots. Shared headers/build/import edits stay serialized.
4. Independently review source and evidence, then compare unchanged original
   worker-wide lifecycle code and intervals against one fresh owned fixture.
   Functional/callback/pool/admission/preparation invariants stay equal; no
   error, cancel or reconnect activity is reclassified outside the interval.
5. Run full ordinary/live root and SDK suites, Safe compile/Fast library and
   required fmt/convention/version checks. Preserve inherited timing-sensitive
   failures and diagnose against parent without weakening deadlines or tests.
   Keep dedicated smoke/security/sanitizer/fuzz campaigns user-deferred.

Acceptance covers pure query cold-thread/process conditions and ERR/RNG/hook
non-effects; output/invalid/profile/overflow guards; admitted CA/context settings;
owned DNS/IPv4/IPv6 and verify=false setup; exact owner/size/alignment/cleansing;
every constructor/setup allocation failure index with full partial cleanup,
especially parameter inherit; clear failure cleanup and continued freeability;
many create/free and clear cycles; two independent interleaved domains; backing
exhaustion without corruption; context released before SSL and shared context;
borrowed/export/copy lifetimes; ordinary controls and full/partial hooks; verified
TLS1.3 across three suites with valid/wrong names and trust; and all original
six SQL failure/reconnect/cancel scenarios. Cold ERR/RNG setup is a separately
reported allocating control, never silently warmed inside a claimed pure call.

## Explicit remaining full-goal work

BUF_MEM descriptor ownership does not own transcript payload: reserve starts
OPENSSL_realloc(NULL,...) for that separately unowned buffer. ClientHello flights,
CBB payloads, key shares, peer cert/ASN1 parsing, verification chains/stores,
EVP/EC/RSA/BN workspaces, negotiated AEAD/session/ticket data and ERR/RNG/thread
facilities remain required. Do not route those unknown allocations into a
constructor-only slot budget or claim the complete PostgreSQL gate passed.
Publication/pins, production adoption, total TLS capacity, D-5 throughput and
all other open v2.3.0 requirements remain part of the original goal.
