# Focused SDK test correction

The initial focused run is preserved in `focused_initial/`: six tests passed and two failed. Both failures were in new test inputs or assertions; production code and gates did not change.

`checked_tls_startup` used two connections, while the unchanged `runtime_types.validate_config` requires eight through sixteen. The input now uses the admitted minimum of eight and reaches every startup Zig allocation before constructing dormant cancellation sessions.

The failure-index test assumed each failed allocation immediately stops subsequent allocations. Native `ssl/s3_lib.cc:65` and `:66` initialize the read and write null AEADs independently; `:67` checks both results afterward. Failing the read AEAD at index eleven therefore permits the write AEAD attempt, yielding thirteen total calls. The test now counts the selected injected failure explicitly and requires exactly one, requires operation failure, bounds total attempts by the dynamically measured successful baseline, requires every other attempted allocation to succeed in the caller storage, requires one validated release per successful allocation, checks cleansing and zero live slots, checks descriptor identity, and proves immediate successful reuse. Storage release still checks exact owner range, slot root, extent, alignment and liveness. Independent native all-C allocation evidence owns the separate no-hidden-heap-fallback proof.

The corrected focused command uses the same cache roots, `-j2`, trusted CA fixture and filter. `focused_fixed/build.log` records 23/23 steps and 8/8 tests passed, with no skipped test. Changed-file formatting and SDK conventions/version scripts passed. Full suites remain reserved for Root.
