# SDK SSL-construction source review

## Verdict and resolved finding

No remaining actionable findings. Source and recorded focused-test evidence are
accepted for the refreshed identity below; full integrated acceptance remains
pending.

The initial P2 finding is resolved at
`sdk/src/tests/sql_ssl_storage_tests.zig:267`: `checked_tls_startup` now uses the
admitted eight connections. Unchanged pool validation still requires 8..16.
The focused run executes all eight cases without skips, including startup
allocation failures and destruction of dormant cancellation Sessions.

The initial focused run also exposed an invalid immediate-stop assertion in
the new failure-index test. The replacement at test lines 176-183 preserves
its failure and cleanup guarantees: exactly one selected failure, operation
failure, attempts bounded by the measured successful baseline, successful
allocations equal to all other attempts, matching validated releases, full raw
cleansing, zero live slots, stable descriptor identity and successful reuse.
The old index+1 call-count assumption was false: native `ssl/s3_lib.cc:65-67`
attempts both null AEAD allocations before checking either result. The revised
assertions accommodate that existing sequence without relaxing a project gate
or changing production code. Separate native all-C evidence still owns the
no-hidden-heap-fallback proof.

The initial report is preserved as runtime_source_review.initial.md, SHA256
`562aaf5b522afd5c937224b2456789fbbd0a06d3f2bbe06fdc65eb2bdd71fdc9`.

## Reviewed identity and scope

Contract SHA256: `6bc18d4008437a6b00932d416c9c376151fb90b9cb63798b24d1112dd15c2199`.
Runtime identity SHA256: `37dfd29b9f1daf9ac354877f7b08988d85cef18a83c48a0cca697fba4cadfd6f`.
Runtime patch SHA256: `554484a853961f02161df6c380da9a76fdf4c74efd23c3075e1dd372a67a0c30`.
Full SDK identity SHA256: `e9b6135a8da083cbdac2bb51554f15e6602397ba9c05e555c330b61be92372bf`.

All 499 parent SDK file contents and modes match parent_sdk_identity.json.
All 501 final SDK file contents and modes match the refreshed full identity.
The six candidate runtime/test files match their refreshed frozen hashes. Only
the new sql_ssl_storage_tests.zig changed since the initial source review;
all five other files and production code are identical. Existing-file
changes are limited to four of those runtime files plus Root's single test-support
alias and native-builder path binding; the two remaining runtime files are new.
See runtime_source_rereview_check.json for the refreshed identities and
runtime_source_scope_check.initial.json for the initial scope check.

Reviewed checked query-derived slot size/count/alignment, bounded first-free
selection and immediate reuse, exact root/extent/alignment release validation,
moved-storage descriptor rejection, checked 2N slab/metadata allocation, stable
Connection-resident contexts outside resettable Session, startup error unwinding,
and normal plus dormant cancellation destruction before backing/context release.
Separate BIO and construction domains retain independent lifetimes. Ordinary and
BIO-only Session entry points preserve their native constructor/connect-state
path; the new path uses the constructor that already arms client state. SQL still
uses verified TLS1.3 and no ALPN; development verify=false remains available.
No preparation, admission, callback, deadline, quarantine or interval movement
appears in the diff.

The structural lens found no additional actionable regression: the 86-line slot
adapter owns its checks in SQL; the shared TLS initializer retains one flow;
Connection only adds one field. Resulting line counts are tls_client 252,
connection 879, db 555 and new tests 289. No gate or threshold was weakened.

Recorded targeted evidence was checked against raw logs and commands:
focused_initial retains exit 1, 6/8 tests with the invalid pool-size and call-count
failures; focused_fixed retains exit 0, 23/23 steps and 8/8 tests without skips.
Both commands retain the SQL/SQLite-enabled build, same exact filter, cache
roots and -j2. This reviewer did not rerun the focused suite.

## Verification gaps

- The unfiltered SDK 1205-test live suite, lifecycle comparison and native full
  functional proof remain pending. The focused 8/8 result is not a full-suite
  acceptance claim.
- The retained missing-module log is genuine compile RED. It does not establish
  runtime/OOM behavior by itself. The subsequent focused run provides targeted
  behavior evidence. Recorded formatting/convention/version success was supplied
  by the owner and was not rerun by this reviewer.
- The separate native reviewer owns the 17-path constructor/profile/provenance
  propagation, pure bound, clear behavior and complete native OOM matrix. This
  pass consulted the accepted API/header contract without repeating that audit.
- Fresh same-fixture original lifecycle comparison, full root/SDK live results,
  Safe/Fast builds and final combined evidence review remain Root-owned.
- Complete TLS/transcript/certificate/crypto/ERR/RNG/thread ownership and total
  capacity remain open. Dedicated smoke/security/sanitizer/fuzz campaigns remain
  user-deferred, and no such campaign is claimed here.

AGENTS.md, CODING_CONVENTION.md, specialist/reviewer instructions, the accepted
contract and narrow review/Zig skills governed this review. Graph-first queries
preceded source exploration. No nested agent, external review CLI, source,
build, proof or runtime modification was made; only requested review artifacts
were written under the workspace SSD cache.
