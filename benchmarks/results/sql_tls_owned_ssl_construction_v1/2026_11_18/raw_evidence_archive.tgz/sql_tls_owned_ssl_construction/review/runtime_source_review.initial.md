# SDK SSL-construction source review

## Finding

[P2] Use an admitted pool size in the startup-cleanup test.

`sdk/src/tests/sql_ssl_storage_tests.zig:250` sets `.connections = 2` in
`checked_tls_startup`. The unchanged validation at
`sdk/src/sql/runtime_types.zig:76` and `sdk/src/sql/pool.zig:44` requires 8..16.
When `UWZ_SQL_TEST_CA_PATH` is available, `Db.init` therefore returns
`InvalidPoolSize` before allocating anything, and `checkAllAllocationFailures`
propagates that error. The new live test fails and never exercises TLS slab/
metadata allocation failure cleanup or dormant cancellation Sessions. Use the
default eight connections, or another admitted count, without changing pool
validation.

No other actionable finding in the reviewed implementation.

## Reviewed identity and scope

Contract SHA256: `6bc18d4008437a6b00932d416c9c376151fb90b9cb63798b24d1112dd15c2199`.
Runtime identity SHA256: `eeef8658100c3fb7445aa14b04b30094cacf6959efb45088597ecee118e0359b`.
Runtime patch SHA256: `65901bc765d9d453460fbef177fbb2bf4d49460d18afc5f1b04ce23e98b8d670`.

All 499 parent SDK file contents and modes match parent_sdk_identity.json.
The six candidate runtime/test files match their frozen hashes. Existing-file
changes are limited to four of those runtime files plus Root's single test-support
alias and native-builder path binding; the two remaining runtime files are new.
See runtime_source_scope_check.json for independently recomputed identities.

Reviewed checked query-derived slot size/count/alignment, bounded first-free
selection and immediate reuse, exact root/extent/alignment release validation,
moved-storage descriptor rejection, checked 2N slab/metadata allocation, stable
Connection-resident contexts outside resettable Session, startup error unwinding,
and normal plus dormant cancellation destruction before backing/context release.
Separate BIO and construction domains retain independent lifetimes. Ordinary and
BIO-only Session entry points preserve their native constructor/connect-state
path; the new path uses the constructor that already arms client state. SQL still
uses verified TLS1.3 and no ALPN; development verify=false remains available.
No preparation, admission, callback, deadline, quarantine or interval movement
appears in the diff.

The structural lens found no additional actionable regression: the 86-line slot
adapter owns its checks in SQL; the shared TLS initializer retains one flow;
Connection only adds one field. Resulting line counts are tls_client 252,
connection 879, db 555 and new tests 272. No gate or threshold was weakened.

## Verification gaps

- The new SDK compile/runtime/live suite and native functional proof remain
  pending. This is a source review, not a claim of 1205 passing tests.
- The startup-cleanup test above must be corrected, then rerun with CA material
  so its allocation-failure and dormant-cancellation checks actually execute.
- The retained missing-module log is genuine compile RED. It does not establish
  runtime/OOM behavior; recorded formatting/convention/version success was supplied
  by the owner and was not rerun by this reviewer.
- The separate native reviewer owns the 17-path constructor/profile/provenance
  propagation, pure bound, clear behavior and complete native OOM matrix. This
  pass consulted the accepted API/header contract without repeating that audit.
- Fresh same-fixture original lifecycle comparison, full root/SDK live results,
  Safe/Fast builds and final combined evidence review remain Root-owned.
- Complete TLS/transcript/certificate/crypto/ERR/RNG/thread ownership and total
  capacity remain open. Dedicated smoke/security/sanitizer/fuzz campaigns remain
  user-deferred, and no such campaign is claimed here.

AGENTS.md, CODING_CONVENTION.md, specialist/reviewer instructions, the accepted
contract and narrow review/Zig skills governed this review. Graph-first queries
preceded source exploration. No nested agent, external review CLI, source,
build, proof or runtime modification was made; only requested review artifacts
were written under the workspace SSD cache.
