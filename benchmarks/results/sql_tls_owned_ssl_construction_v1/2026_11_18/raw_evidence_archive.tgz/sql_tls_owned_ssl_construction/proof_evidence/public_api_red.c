#include <openssl/ssl.h>
int main(void) {
  SSL_CLIENT_CONSTRUCTION_REQUIREMENTS out = {0};
  return SSL_client_construction_storage_requirements(0, 255, &out) +
      (SSL_new_client_with_construction_domain(0, 0) != 0);
}
