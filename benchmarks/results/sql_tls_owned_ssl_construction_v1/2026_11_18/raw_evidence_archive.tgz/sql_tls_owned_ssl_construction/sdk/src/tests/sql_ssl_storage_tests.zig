const std = @import("std");
const ssl_storage = @import("test_support").sql_ssl_storage;
const bio_storage = @import("test_support").sql_bio_storage;
const tls = @import("test_support").tls_client;
const sql = @import("test_support").sql;
const fixture = @import("sql_test_support.zig");
const c = @import("c");

test "sql SSL storage: native requirements describe checked fixed slots" {
    var context = try tls.ClientContext.init(.{ .verify = false });
    defer context.deinit();
    const required = try ssl_storage.requirements(context.ctx, tls.max_server_name_bytes);
    try std.testing.expect(required.block_count > 0);
    try std.testing.expect(required.block_bytes > 0);
    try std.testing.expect(std.math.isPowerOfTwo(required.alignment));
    try std.testing.expectEqual(@as(usize, 0), required.block_bytes % required.alignment);
    try std.testing.expectEqual(required.bytes, try std.math.mul(usize, required.block_bytes, required.block_count));
    try std.testing.expectError(error.InvalidRequirements, ssl_storage.requirements(context.ctx, 0));
    try std.testing.expectError(error.InvalidRequirements, ssl_storage.requirements(context.ctx, tls.max_server_name_bytes + 1));
}

test "sql SSL storage: malformed backing and metadata fail before binding" {
    var backing: [256]u8 align(64) = undefined;
    var blocks: [2]ssl_storage.Block = undefined;
    var storage: ssl_storage.Storage = .{};
    const required: ssl_storage.Requirements = .{ .bytes = 128, .alignment = 16, .block_bytes = 64, .block_count = 2 };
    try std.testing.expectError(error.StorageUnavailable, storage.domain_for_session());
    try std.testing.expectError(error.InvalidRequirements, storage.init(&backing, &blocks, .{}));
    var invalid = required;
    invalid.alignment = 3;
    try std.testing.expectError(error.InvalidRequirements, storage.init(&backing, &blocks, invalid));
    invalid = required;
    invalid.block_bytes = 63;
    try std.testing.expectError(error.InvalidRequirements, storage.init(&backing, &blocks, invalid));
    invalid = required;
    invalid.bytes = 127;
    try std.testing.expectError(error.InvalidRequirements, storage.init(&backing, &blocks, invalid));
    invalid = required;
    invalid.block_count = std.math.maxInt(usize);
    try std.testing.expectError(error.InvalidRequirements, storage.init(&backing, &blocks, invalid));
    try std.testing.expectError(error.StorageTooSmall, storage.init(backing[0..127], &blocks, required));
    try std.testing.expectError(error.MetadataTooSmall, storage.init(&backing, blocks[0..1], required));
    try std.testing.expectError(error.StorageMisaligned, storage.init(backing[1..], &blocks, required));
    try storage.init(&backing, &blocks, required);
    const domain = try storage.domain_for_session();
    try std.testing.expectEqual(@as(?*anyopaque, &storage), domain.context);
    var moved = storage;
    try std.testing.expectError(error.StorageUnavailable, moved.domain_for_session());
    try std.testing.expectEqual(@as(usize, 0), storage.live_count);
}

test "sql SSL storage: partial release immediately reuses its exact fixed slot" {
    var backing: [192]u8 align(64) = undefined;
    var blocks: [3]ssl_storage.Block = undefined;
    var storage: ssl_storage.Storage = .{};
    try storage.init(&backing, &blocks, .{ .bytes = 192, .alignment = 16, .block_bytes = 64, .block_count = 3 });
    const domain = try storage.domain_for_session();
    const first = domain.allocate.?(domain.context, 1, 16) orelse return error.TestUnexpectedResult;
    const second = domain.allocate.?(domain.context, 64, 16) orelse return error.TestUnexpectedResult;
    const third = domain.allocate.?(domain.context, 17, 16) orelse return error.TestUnexpectedResult;
    try std.testing.expectEqual(@as(usize, 3), storage.live_count);
    try std.testing.expectError(error.StorageBusy, storage.domain_for_session());
    try std.testing.expectError(error.StorageBusy, storage.init(&backing, &blocks, storage.required));
    try std.testing.expectEqual(@as(?*anyopaque, null), domain.allocate.?(domain.context, 1, 16));
    domain.release.?(domain.context, second, 64, 16);
    const reused = domain.allocate.?(domain.context, 31, 16) orelse return error.TestUnexpectedResult;
    try std.testing.expectEqual(second, reused);
    try std.testing.expectEqual(@as(usize, 3), storage.live_count);
    domain.release.?(domain.context, third, 17, 16);
    domain.release.?(domain.context, first, 1, 16);
    domain.release.?(domain.context, reused, 31, 16);
    _ = try storage.domain_for_session();
    try std.testing.expectEqual(@as(?*anyopaque, null), domain.allocate.?(domain.context, 65, 16));
    try std.testing.expectEqual(@as(?*anyopaque, null), domain.allocate.?(domain.context, 1, 8));
    try std.testing.expectEqual(@as(?*anyopaque, null), domain.allocate.?(domain.context, 0, 16));
    try std.testing.expectEqual(@as(usize, 0), storage.live_count);
}

/// Test allocations bind only after the fixture reaches its stable address.
const StorageFixture = struct {
    storage: ssl_storage.Storage = .{},
    backing: []u8 = &.{},
    blocks: []ssl_storage.Block = &.{},
    alignment: std.mem.Alignment = .@"1",

    fn init(self: *StorageFixture, context: *const c.SSL_CTX) !void {
        const required = try ssl_storage.requirements(context, tls.max_server_name_bytes);
        const alignment: std.mem.Alignment = .fromByteUnits(required.alignment);
        const pointer = std.testing.allocator.rawAlloc(required.bytes, alignment, @returnAddress()) orelse return error.OutOfMemory;
        const backing = pointer[0..required.bytes];
        errdefer std.testing.allocator.rawFree(backing, alignment, @returnAddress());
        const blocks = try std.testing.allocator.alloc(ssl_storage.Block, required.block_count);
        errdefer std.testing.allocator.free(blocks);
        try self.storage.init(backing, blocks, required);
        self.backing = backing;
        self.blocks = blocks;
        self.alignment = alignment;
    }

    fn deinit(self: *StorageFixture) void {
        std.debug.assert(self.storage.live_count == 0);
        std.testing.allocator.rawFree(self.backing, self.alignment, @returnAddress());
        std.testing.allocator.free(self.blocks);
        self.* = .{};
    }
};

/// Failure injection wraps the explicit descriptor and checks native cleansing.
const FaultDomain = struct {
    storage: *ssl_storage.Storage = undefined,
    domain: c.OPENSSL_ALLOCATION_DOMAIN = .{ .context = null, .allocate = null, .release = null },
    fail_index: usize = std.math.maxInt(usize),
    calls: usize = 0,
    injected_failures: usize = 0,
    allocations: usize = 0,
    releases: usize = 0,
    cleansed: bool = true,

    fn init(self: *FaultDomain, storage: *ssl_storage.Storage, fail_index: usize) void {
        self.* = .{ .storage = storage, .fail_index = fail_index };
        self.domain = .{ .context = self, .allocate = allocate, .release = release };
    }

    fn allocate(context: ?*anyopaque, bytes: usize, alignment: usize) callconv(.c) ?*anyopaque {
        const self: *FaultDomain = @ptrCast(@alignCast(context.?));
        const index = self.calls;
        self.calls += 1;
        if (index == self.fail_index) {
            self.injected_failures += 1;
            return null;
        }
        const pointer = self.storage.domain.allocate.?(self.storage.domain.context, bytes, alignment) orelse return null;
        self.allocations += 1;
        return pointer;
    }

    fn release(context: ?*anyopaque, pointer: ?*anyopaque, bytes: usize, alignment: usize) callconv(.c) void {
        const self: *FaultDomain = @ptrCast(@alignCast(context.?));
        const raw: [*]const u8 = @ptrCast(pointer.?);
        for (raw[0..bytes]) |byte| {
            if (byte != 0) self.cleansed = false;
        }
        self.storage.domain.release.?(self.storage.domain.context, pointer, bytes, alignment);
        self.releases += 1;
    }
};

test "sql SSL storage: constructor and identity failure indices release every slot" {
    var context = try tls.ClientContext.init(.{ .verify = false });
    defer context.deinit();
    var owner: StorageFixture = .{};
    try owner.init(context.ctx);
    defer owner.deinit();
    var fault: FaultDomain = .{};
    fault.init(&owner.storage, std.math.maxInt(usize));
    var session: tls.Session = .{};
    defer session.deinit();
    try session.init_for_protocol_with_domains(context.ctx, "localhost", true, .postgres, .{ .construction = &fault.domain });
    const allocation_count = fault.calls;
    try std.testing.expect(allocation_count > 0);
    session.deinit();
    try std.testing.expectEqual(@as(usize, 0), fault.injected_failures);
    try std.testing.expectEqual(allocation_count, fault.allocations);
    try std.testing.expectEqual(allocation_count, fault.releases);
    try std.testing.expect(fault.cleansed);
    for (0..allocation_count) |index| {
        c.ERR_clear_error();
        fault.init(&owner.storage, index);
        if (session.init_for_protocol_with_domains(context.ctx, "localhost", true, .postgres, .{ .construction = &fault.domain })) {
            session.deinit();
            return error.ExpectedAllocationFailure;
        } else |err| switch (err) {
            error.SslAllocationFailed, error.SniConfigurationFailed, error.HostnameVerificationFailed => {},
            else => return err,
        }
        // tls_new initializes both null AEADs before checking either result.
        try std.testing.expectEqual(@as(usize, 1), fault.injected_failures);
        try std.testing.expect(fault.calls >= index + 1 and fault.calls <= allocation_count);
        try std.testing.expectEqual(fault.calls - 1, fault.allocations);
        try std.testing.expectEqual(fault.allocations, fault.releases);
        try std.testing.expect(fault.cleansed);
        try std.testing.expectEqual(@as(usize, 0), owner.storage.live_count);
        try std.testing.expectEqual(@as(?*anyopaque, &owner.storage), owner.storage.domain.context);
        try session.init_for_protocol_with_domains(context.ctx, "localhost", true, .postgres, .{ .construction = try owner.storage.domain_for_session() });
        session.deinit();
        try std.testing.expectEqual(@as(usize, 0), owner.storage.live_count);
    }
    c.ERR_clear_error();
}

test "sql SSL storage: clear and new sessions reuse native-derived slots" {
    var context = try tls.ClientContext.init(.{ .verify = false });
    defer context.deinit();
    var owner: StorageFixture = .{};
    try owner.init(context.ctx);
    defer owner.deinit();
    for (0..40) |_| {
        for ([_][]const u8{ "localhost", "127.0.0.1", "::1" }) |name| {
            var session: tls.Session = .{};
            try session.init_for_protocol_with_domains(context.ctx, name, true, .postgres, .{ .construction = try owner.storage.domain_for_session() });
            errdefer session.deinit();
            const live = owner.storage.live_count;
            for (0..40) |_| {
                try std.testing.expectEqual(@as(c_int, 1), c.SSL_clear(session.ssl.?));
                try std.testing.expectEqual(live, owner.storage.live_count);
            }
            session.deinit();
            try std.testing.expectEqual(@as(usize, 0), owner.storage.live_count);
        }
    }
}

test "sql SSL storage: interleaved SSL and BIO owners retain independent references" {
    var context = try tls.ClientContext.init(.{ .verify = false });
    defer context.deinit();
    var first: StorageFixture = .{};
    try first.init(context.ctx);
    defer first.deinit();
    var second: StorageFixture = .{};
    try second.init(context.ctx);
    defer second.deinit();
    var bio_backing: [128 * 1024]u8 align(64) = undefined;
    var pair_storage: bio_storage.Storage = .{};
    try pair_storage.init(&bio_backing, try bio_storage.requirements(tls.bio_capacity));
    var a: tls.Session = .{};
    defer a.deinit();
    try a.init_for_protocol_with_domains(context.ctx, "localhost", true, .postgres, .{ .construction = try first.storage.domain_for_session(), .bio = try pair_storage.domain_for_pair() });
    var b: tls.Session = .{};
    defer b.deinit();
    try b.init_for_protocol_with_domains(context.ctx, "127.0.0.1", true, .postgres, .{ .construction = try second.storage.domain_for_session() });
    const second_live = second.storage.live_count;
    const retained = a.network_bio.?;
    try std.testing.expectEqual(@as(c_int, 1), c.BIO_up_ref(retained));
    a.deinit();
    try std.testing.expectEqual(@as(usize, 0), first.storage.live_count);
    try std.testing.expect(pair_storage.live_count > 0);
    try std.testing.expectEqual(second_live, second.storage.live_count);
    _ = c.BIO_free(retained);
    try std.testing.expectEqual(@as(usize, 0), pair_storage.live_count);
    b.deinit();
    try std.testing.expectEqual(@as(usize, 0), second.storage.live_count);
}

test "sql SSL storage: ordinary entrypoints and development verification remain available" {
    var context = try tls.ClientContext.init(.{ .verify = false });
    defer context.deinit();
    var owner: StorageFixture = .{};
    try owner.init(context.ctx);
    defer owner.deinit();
    var session: tls.Session = .{};
    defer session.deinit();
    try session.init(context.ctx, "localhost", false);
    session.deinit();
    try session.init_for_protocol(context.ctx, "localhost", false, .postgres);
    session.deinit();
    try session.init_for_protocol_with_domains(context.ctx, "localhost", false, .postgres, .{ .construction = try owner.storage.domain_for_session() });
    try std.testing.expect(owner.storage.live_count > 0);
    session.deinit();
    try std.testing.expectError(error.ServerNameEmpty, session.init_for_protocol_with_domains(context.ctx, "", false, .postgres, .{ .construction = try owner.storage.domain_for_session() }));
    try std.testing.expectEqual(@as(usize, 0), owner.storage.live_count);
}

fn checked_tls_startup(allocator: std.mem.Allocator, ca_path: [:0]const u8) !void {
    var db = try sql.Db.init(allocator, .{
        .user = "uwz_test",
        .database = "uwz_test",
        .connections = 8,
        .tls = .{ .ca_path = ca_path, .server_name = "localhost" },
        .limits = .{ .max_message_bytes = 1024, .max_response_bytes = 1024 },
        .write_bytes = 1024,
    });
    defer db.deinit();
    try std.testing.expect(db.drained());
    for (db.connections, db.cancel_connections) |*normal, *cancel| {
        try std.testing.expectEqual(@as(?*anyopaque, &normal.ssl_storage), normal.ssl_storage.domain.context);
        try std.testing.expectEqual(@as(?*anyopaque, &cancel.ssl_storage), cancel.ssl_storage.domain.context);
        try std.testing.expect(normal.ssl_storage.backing.ptr != cancel.ssl_storage.backing.ptr);
        try std.testing.expect(normal.ssl_storage.blocks.ptr != cancel.ssl_storage.blocks.ptr);
        try cancel.session.init_for_protocol_with_domains(db.context.?.ctx, "localhost", true, .postgres, .{ .construction = try cancel.ssl_storage.domain_for_session(), .bio = try cancel.bio_storage.domain_for_pair() });
        try std.testing.expectEqual(sql.connection.Phase.dormant, cancel.phase);
        try std.testing.expect(cancel.ssl_storage.live_count > 0);
    }
}

test "sql SSL storage: TLS startup failure cleanup includes dormant cancellation sessions" {
    const ca_path = try fixture.required_env_z("UWZ_SQL_TEST_CA_PATH");
    defer std.testing.allocator.free(ca_path);
    try std.testing.checkAllAllocationFailures(std.testing.allocator, checked_tls_startup, .{ca_path});
}
