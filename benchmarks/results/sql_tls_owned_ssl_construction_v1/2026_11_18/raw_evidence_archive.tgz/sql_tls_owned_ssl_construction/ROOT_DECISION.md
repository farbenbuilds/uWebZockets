# Root integration decision

Accept the frozen isolated SSL construction/setup increment for artifact
packaging and commit to `impl/implement-2.3.0`, subject to final archive checks.
This decision covers the source/evidence below; the final archive checksum and
Git push are verified separately after archive freezing.

- Native parent: exact 8709 files, identity
  `698bc252dcd3b629fb4f779e18ec3889aa96ccf5ab2b6eb2f174e0789647ed7b`.
- Native candidate: 16 permitted replacements, same file/mode set, identity
  `4b2feb7f16a45250c88feb1ab57a24fd3ea0196f8cde777cd87c9f8ba54d3699`.
- SDK: 501 source files, two additions and six modifications, identity
  `e9b6135a8da083cbdac2bb51554f15e6602397ba9c05e555c330b61be92372bf`.
- Proof: 16 frozen inputs, identity
  `c1872c689545c5c9e3ca946ef757ba82df701b161c7b04f58dbe40c384045f67`.
- Native/proof/build: 57/57 steps, 26 construction rows with 24 all-C-zero;
  fifteen separate verified TLS compatibility cases pass. Ordinary allocation
  and cold/shared-ownership controls remain allocating and explicitly scoped.
- Complete live SDK/root suites: 1205/1205 and 1182/1182, no skips. SDK Safe/Fast
  builds: 24/24 each. Required formatting, conventions and version checks pass.
- Paired original lifecycle: all six functional/callback/pool/preparation and
  interval invariants match; removal is 180 mallocs, 180 frees and 53847 bytes.
  Both strict whole-lifecycle measurements remain RED.
- Fresh whole-native optimized-Python restoration: 54/54 default proof steps;
  all 28 negative restore cases reject. Four malformed lifecycle comparisons
  reject under optimized Python. Private fixture/container cleanup is verified;
  no fresh secrets were found in the public evidence/delivery scan.

Independent contract, native source, SDK source/correction and frozen native
proof reviews have no unresolved source findings. Initial failed focused tests
and the inherited hostname-copy OOM RED remain retained. Native ordinary
success/allocation representation, existing destructive clear behavior and all
SQL protocol/verification options remain preserved.

No PostgreSQL exception, allocator routing, spare SSL stock, admission pause,
delayed callback/free, narrowed interval or weakened gate is accepted. SQLite's
SQL-ALLOC-001 approval remains specific to that backend. Native publication,
production pins/adoption, whole TLS capacity/ownership, D-5 throughput and other
open v2.3.0 requirements remain part of the active goal. Dedicated smoke,
security, sanitizer and fuzz campaigns stay user-deferred. No release is made.
