const std = @import("std");
const boringssl = @import("builds/vendor/boringssl.zig");
const lsquic = @import("builds/vendor/lsquic.zig");
const sanitizers = @import("builds/sanitizers.zig");
const zlib = @import("builds/vendor/zlib.zig");
const upstream = @import("upstream_tests.zig");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const sanitizer = sanitizers.configure(b, target, target.result.os.tag == .linux);
    const bssl = boringssl.build(b, target, optimize, sanitizer);
    const z = zlib.build(b, target, optimize, sanitizer);
    const ls = lsquic.build(b, target, optimize, sanitizer, bssl, z, false);
    const libraries = b.step("libraries", "Compile unmodified-clock production objects");
    libraries.dependOn(&ls.library.step);
    if (target.result.os.tag == .linux and optimize == .Debug)
        upstream.configure(b, target, optimize, sanitizer, ls, bssl, z);
}
