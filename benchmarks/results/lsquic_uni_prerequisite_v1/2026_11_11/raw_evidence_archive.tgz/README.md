# Outgoing unidirectional stream API: local evidence

Final native results are GREEN: all eight real-engine case groups in Debug,
ReleaseSafe, and ReleaseSafe with ASan, UBSan and LeakSanitizer. The unchanged
TLS-only immediate-engine-destruction probe is also sanitizer GREEN. Exact
commands and raw logs are retained; the root agent ran the final full sanitizer
invocation. All 83 existing Linux Debug runtime cases also passed (165/165
build steps). ReleaseSafe production libraries cross-compiled for
`x86_64-windows-gnu` and `aarch64-macos` (9/9 steps each); no foreign runtime
test was executed. Earlier reports of 84 existing cases were a count arithmetic
error: 83 existing cases plus the new integration registration make 84 CMake
cases. No actual cases or gate thresholds changed.

Run `sh verify.sh` from any directory for offline integrity/evidence validation.
It verifies the complete file manifest, the five production C/header hashes and
fixture hash, identical pre/post source IDs, exact eight PASS groups and exit
codes in all three final logs, the exact 83 existing case names, both cross-build
summaries, owner-supplied terminal codes, and retained earlier failing cohorts.
It needs a POSIX shell, ordinary POSIX tools, and `sha256sum` or `shasum`; it
does not run a compiler, tests, Python, or network requests.

`candidate/` contains exact changed source/header/docs/test snapshots and the
new fixture; `base_snapshots/` contains their exact base versions. The base is
maintained lsquic commit `85bd081c9103c077a7cc98271d09334d0f1043d4`.
`candidate.diff` is the complete delta against the explicit base commit,
including the new C fixture. The earlier dirty-status record is labeled as
historical; the final local candidate checkout is clean. `source_ids.sha256` identifies the exact tested five
production C/header files and fixture. All other inputs are covered by the
complete package manifest. Runtime executable hashes are retained as provenance
only; executable bodies, caches and dependency package bodies are excluded.

`native_harness/` is the exact Zig-native build scaffold used for testing, with
three explicitly documented test-only clock/constructor/hash definition seams.
Its four dependency URLs and hashes are preserved verbatim in
`native_harness/build.zig.zon`. No CMake, Ninja, Go, Perl, Python, or system zlib
is a build requirement. The Linux CMake compatibility registration is included
as source and was independently reviewed; CMake was not run.

`native_runner/` is the exact separate root runner for the existing tests and
production cross-builds. It disables all three clock/fault seams. Its six
standalone tests retain upstream implementation linkage without a vendor
library, and all 83 emitted case names match the copied runner enumeration.
The original three root shell commands had no `.exit` files; their reported
tool-terminal codes are explicitly recorded in `owner_terminal_results.txt`
and `owner_terminal_provenance.txt` rather than presented as original files.

To reproduce in a new location, obtain the exact base in a separate scratch
checkout, then copy `candidate/` over that scratch checkout. Keep that prepared
tree outside any root dependency cache or pin. From `native_harness/`, supply
all three absolute-path options below; this leaves the tested graph unchanged
while overriding its original machine-local defaults:

```sh
zig build test -Doptimize=Debug -j2 --summary all \
  -Dlsquic-source=/absolute/prepared-fork \
  -Dfixture=/absolute/package/candidate/tests/uwz_uni_stream.c \
  -Dfixture-includes=/absolute/prepared-fork/src/liblsquic
```

Repeat with `-Doptimize=ReleaseSafe`. For the strict sanitizer mode, also use:

```sh
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1:strict_string_checks=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
zig build test -Doptimize=ReleaseSafe -Dsanitize=true \
  -Dsanitizer-lib-dir=/absolute/llvm21-runtime/lib/linux \
  -Dlsquic-source=/absolute/prepared-fork \
  -Dfixture=/absolute/package/candidate/tests/uwz_uni_stream.c \
  -Dfixture-includes=/absolute/prepared-fork/src/liblsquic \
  -j2 --summary all
```

Zig 0.16.0 and LLVM compiler-rt 21.1.8 were used; exact local tool hashes are in
`evidence/toolchain.sha256`. The original commands, cache locations, synthetic
clock, bounded encrypted packet queues, fault seams and all preceding cohorts
are documented in `evidence/README.md` and `commands.txt`.

The earlier missing-API RED, callback-close RED, both lifecycle-omission REDs,
base ACK-callback UBSan RED, zero-capacity QPACK VLA RED, and TLS-teardown leak
RED are preserved independently. None was suppressed or relabeled as passing.
TLS keys were generated only in memory. `EXCLUSIONS.txt` records the deliberate
inventory and excluded artifacts. No WebTransport setting/capability was enabled;
this verifies a prerequisite API and does not complete WebTransport support.

The five local unpublished commits end at
`0f7382b17b38d7fb0496a0b75b3c66ace79e49e8` on
`proposal/lsquic-uni-prerequisites-20261111`. `review_only/` retains their exact
list, a small incremental Git bundle, the root agent's independent offline
import/fsck result, and all ten source-file hashes. Those hashes match the
packaged snapshots; the tested five production files and fixture are unchanged.

The bundle, diff, and snapshots are REVIEW EVIDENCE ONLY. They are not a root
build input, dependency overlay, local pin, or WebTransport capability switch.
The root pin remains the original full base commit and WebTransport stays off.
A maintainer must import the proposal into an authorized fork scratch branch,
review with an assigned owner and existing repository label, merge append-only,
and only then integrate a fresh full 40-hex pin/hash across all four zon views.
No remote publication or root dependency change occurred in this slice.
