#!/bin/sh
set -eu

cd "$(dirname "$0")"
temporary_evidence_dir=$(mktemp -d)
trap 'rm -rf "$temporary_evidence_dir"' EXIT HUP INT TERM

if command -v sha256sum >/dev/null 2>&1; then
    checksum_command=sha256sum
elif command -v shasum >/dev/null 2>&1; then
    checksum_command=shasum
else
    printf '%s\n' 'A SHA256 implementation (sha256sum or shasum) is required.' >&2
    exit 1
fi

find . -type l > "$temporary_evidence_dir/symlinks"
test ! -s "$temporary_evidence_dir/symlinks"
find . ! -type f ! -type d > "$temporary_evidence_dir/nonregular"
test ! -s "$temporary_evidence_dir/nonregular"
find . -type f ! -path './manifest.sha256' > "$temporary_evidence_dir/files-unsorted"
LC_ALL=C sort "$temporary_evidence_dir/files-unsorted" > "$temporary_evidence_dir/files"
awk '
    length($1) != 64 || $1 !~ /^[0-9a-f]+$/ || substr($0, 65, 2) != "  " { exit 1 }
    {
        name = substr($0, 67)
        if (name ~ /^\// || name ~ /(^|\/)\.\.(\/|$)/)
            exit 1
        print "./" name
    }
' manifest.sha256 > "$temporary_evidence_dir/manifest-files-unsorted"
LC_ALL=C sort "$temporary_evidence_dir/manifest-files-unsorted" > "$temporary_evidence_dir/manifest-files"
cmp "$temporary_evidence_dir/files" "$temporary_evidence_dir/manifest-files"

if test "$checksum_command" = sha256sum; then
    sha256sum -c manifest.sha256 > "$temporary_evidence_dir/hash-results"
    (cd candidate && sha256sum -c ../source_ids.sha256) >> "$temporary_evidence_dir/hash-results"
    (cd candidate && sha256sum -c ../review_only/source_ids.sha256) >> "$temporary_evidence_dir/hash-results"
else
    shasum -a 256 -c manifest.sha256 > "$temporary_evidence_dir/hash-results"
    (cd candidate && shasum -a 256 -c ../source_ids.sha256) >> "$temporary_evidence_dir/hash-results"
    (cd candidate && shasum -a 256 -c ../review_only/source_ids.sha256) >> "$temporary_evidence_dir/hash-results"
fi
cmp source_ids.sha256 evidence/final-cleanup-inputs-before.sha256
cmp source_ids.sha256 evidence/final-cleanup-inputs-after.sha256
test "$(cat base_commit.txt)" = 85bd081c9103c077a7cc98271d09334d0f1043d4
test "$(cat candidate_commit.txt)" = 0f7382b17b38d7fb0496a0b75b3c66ace79e49e8

for mode in debug release-safe sanitizers; do
    test "$(cat "evidence/final-cleanup-$mode.exit")" = 0
    awk '
        NR == FNR { expected[$0]++; wanted++; next }
        /^PASS / { seen[$0]++; found++ }
        /^All real-engine unidirectional stream API tests passed$/ { complete++ }
        /^Build Summary: 12\/12 steps succeeded$/ { summary++ }
        END {
            if (wanted != 8 || found != 8 || complete != 1 || summary != 1)
                exit 1
            for (line in expected)
                if (expected[line] != 1 || seen[line] != 1)
                    exit 1
            for (line in seen)
                if (!(line in expected))
                    exit 1
        }
    ' expected_groups.txt "evidence/final-cleanup-$mode.log"
done

test "$(cat evidence/tls-only-destroy-sanitizers-green.exit)" = 0
awk '
    /^TLS-only immediate engine_destroy complete; new uni API was never invoked$/ { complete++ }
    /^Build Summary: 12\/12 steps succeeded$/ { summary++ }
    END { if (complete != 1 || summary != 1) exit 1 }
' evidence/tls-only-destroy-sanitizers-green.log
awk '
    /ERROR: (AddressSanitizer|LeakSanitizer)|SUMMARY: (AddressSanitizer|UndefinedBehaviorSanitizer)|runtime error:/ { bad = 1 }
    END { exit bad }
' evidence/final-cleanup-sanitizers.log evidence/tls-only-destroy-sanitizers-green.log

for cohort in red-clean-debug-unsandboxed red-callback-close-debug \
    red-omitted-raw-credit-debug red-omitted-graceful-drain-debug \
    baseline-handshake-sanitizers green-expanded-sanitizers \
    final-sanitizers final-qpack-fix-sanitizers tls-only-destroy-sanitizers-red; do
    test "$(cat "evidence/$cohort.exit")" = 1
done

awk '
    NR == FNR { expected[$0]++; wanted++; next }
    /^\+- run upstream [^ ]+ success / { seen[$4]++; found++ }
    /^Build Summary: 165\/165 steps succeeded$/ { summary++ }
    END {
        if (wanted != 83 || found != 83 || summary != 1)
            exit 1
        for (name in expected)
            if (expected[name] != 1 || seen[name] != 1)
                exit 1
        for (name in seen)
            if (!(name in expected))
                exit 1
    }
' expected_upstream_cases.txt evidence/upstream-final-debug.log

for target in windows macos; do
    case "$target" in
        windows) triple=x86_64-windows-gnu ;;
        macos) triple=aarch64-macos ;;
    esac
    awk -v triple="$triple" '
        /^Build Summary: 9\/9 steps succeeded$/ { summary++ }
        index($0, "compile lib lsquic ReleaseSafe " triple " success") { library++ }
        END { if (summary != 1 || library != 1) exit 1 }
    ' "evidence/production-cross-$target.log"
done
awk '
    $1 == "upstream_linux_debug" && $2 == 0 && $3 == 47447 { upstream++ }
    $1 == "cross_windows_release_safe" && $2 == 0 && $3 == 5072 { windows++ }
    $1 == "cross_macos_release_safe" && $2 == 0 && $3 == 80583 { macos++ }
    END { if (NR != 3 || upstream != 1 || windows != 1 || macos != 1) exit 1 }
' owner_terminal_results.txt
awk '
    index($0, "lsquic.build(b, target, optimize, sanitizer, bssl, z, false)") { disabled++ }
    END { if (disabled != 1) exit 1 }
' native_runner/build.zig

printf '%s\n' 'VERIFIED: full manifest and frozen source IDs; all 8 integration groups in 3 modes; TLS-only leak probe; 83 existing Linux cases; Windows/macOS production cross-builds.'
printf '%s\n' 'Verification used retained evidence only; no tests, builds, or network requests were run.'
