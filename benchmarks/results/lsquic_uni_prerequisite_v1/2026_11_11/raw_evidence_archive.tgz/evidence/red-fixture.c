/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <netinet/in.h>

#include <openssl/evp.h>
#include <openssl/rsa.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>

#include "lsquic.h"
#include "lsquic_int_types.h"

#ifdef NDEBUG
#error "uwz_uni_stream requires active assertions"
#endif

extern int lsquic_conn_make_uni_stream (lsquic_conn_t *) __attribute__((weak));

enum {
    MAX_DATAGRAM = 4096,
    MAX_PACKETS = 128,
    MAX_STREAMS = 64,
    MAX_STEPS = 20000,
    EXPECT_UNI_OK = 0,
    EXPECT_UNI_BLOCKED = 1,
    EXPECT_UNI_UNSUPPORTED = -1,
    EXPECT_UNI_CLOSED = -2,
    EXPECT_UNI_NOMEM = -3,
};

struct fixture;
struct endpoint;

struct queued_packet {
    size_t qp_size;
    unsigned char qp_bytes[MAX_DATAGRAM];
};

struct packet_queue {
    unsigned pq_head;
    unsigned pq_count;
    struct queued_packet pq_packets[MAX_PACKETS];
};

struct stream_state {
    struct endpoint *ss_endpoint;
    lsquic_stream_t *ss_stream;
    lsquic_stream_id_t ss_id;
    const char *ss_send;
    size_t ss_send_size;
    size_t ss_send_offset;
    size_t ss_received;
    unsigned ss_fin;
    unsigned ss_closed;
    unsigned char ss_bytes[256];
};

struct endpoint {
    struct fixture *ep_fixture;
    struct endpoint *ep_peer;
    lsquic_engine_t *ep_engine;
    lsquic_conn_t *ep_conn;
    SSL_CTX *ep_ssl;
    struct sockaddr_in ep_address;
    struct packet_queue ep_incoming;
    unsigned ep_server;
    unsigned ep_new_connections;
    unsigned ep_handshake_ok;
    unsigned ep_closed_connections;
    unsigned ep_packets_sent;
    unsigned ep_packets_received;
    unsigned ep_stream_count;
    struct stream_state ep_streams[MAX_STREAMS];
};

struct fixture {
    struct endpoint f_client;
    struct endpoint f_server;
    unsigned f_failed;
};

/* The engine exposes one process-wide OS clock without a context parameter. */
static lsquic_time_t fixture_clock = 1000000;

static const char raw_alpn[] = "uwz-uni-test";
static const char uni_payload[] = "bounded encrypted uni payload";


lsquic_time_t
__wrap_lsquic_time_now (void)
{
    return fixture_clock;
}


static int
select_alpn (SSL *UNUSED_ssl, const unsigned char **selected,
             unsigned char *selected_size, const unsigned char *offered,
             unsigned offered_size, void *UNUSED_ctx)
{
    unsigned offset = 0;
    unsigned size;

    while (offset < offered_size)
    {
        size = offered[offset++];
        if (size > offered_size - offset)
            return SSL_TLSEXT_ERR_ALERT_FATAL;
        if (size == sizeof(raw_alpn) - 1
            && 0 == memcmp(offered + offset, raw_alpn, size))
        {
            *selected = offered + offset;
            *selected_size = size;
            return SSL_TLSEXT_ERR_OK;
        }
        offset += size;
    }
    return SSL_TLSEXT_ERR_ALERT_FATAL;
}


static SSL_CTX *
new_tls_context (int server)
{
    SSL_CTX *ctx;
    EVP_PKEY_CTX *key_context;
    EVP_PKEY *key = NULL;
    X509 *certificate;
    X509_NAME *name;

    ctx = SSL_CTX_new(TLS_method());
    assert(ctx);
    assert(SSL_CTX_set_min_proto_version(ctx, TLS1_3_VERSION));
    assert(SSL_CTX_set_max_proto_version(ctx, TLS1_3_VERSION));
    SSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, NULL);
    if (!server)
        return ctx;

    key_context = EVP_PKEY_CTX_new_id(EVP_PKEY_RSA, NULL);
    assert(key_context);
    assert(1 == EVP_PKEY_keygen_init(key_context));
    assert(1 == EVP_PKEY_CTX_set_rsa_keygen_bits(key_context, 2048));
    assert(1 == EVP_PKEY_keygen(key_context, &key));
    certificate = X509_new();
    assert(certificate);
    assert(1 == X509_set_version(certificate, 2));
    assert(1 == ASN1_INTEGER_set(X509_get_serialNumber(certificate), 1));
    assert(X509_gmtime_adj(X509_get_notBefore(certificate), 0));
    assert(X509_gmtime_adj(X509_get_notAfter(certificate), 86400));
    assert(1 == X509_set_pubkey(certificate, key));
    name = X509_get_subject_name(certificate);
    assert(1 == X509_NAME_add_entry_by_txt(name, "CN", MBSTRING_ASC,
                            (const unsigned char *) "localhost", -1, -1, 0));
    assert(1 == X509_set_issuer_name(certificate, name));
    assert(X509_sign(certificate, key, EVP_sha256()) > 0);
    assert(1 == SSL_CTX_use_certificate(ctx, certificate));
    assert(1 == SSL_CTX_use_PrivateKey(ctx, key));
    assert(1 == SSL_CTX_check_private_key(ctx));
    SSL_CTX_set_alpn_select_cb(ctx, select_alpn, NULL);
    X509_free(certificate);
    EVP_PKEY_free(key);
    EVP_PKEY_CTX_free(key_context);
    return ctx;
}


static SSL_CTX *
get_tls_context (void *peer_ctx, const struct sockaddr *UNUSED_local)
{
    struct endpoint *endpoint = peer_ctx;
    return endpoint->ep_ssl;
}


static SSL_CTX *
lookup_certificate (void *ctx, const struct sockaddr *UNUSED_local,
                    const char *UNUSED_sni)
{
    struct endpoint *endpoint = ctx;
    return endpoint->ep_ssl;
}


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct endpoint *endpoint = ctx;

    endpoint->ep_conn = conn;
    ++endpoint->ep_new_connections;
    if (endpoint->ep_server)
        endpoint->ep_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct endpoint *endpoint = (struct endpoint *) lsquic_conn_get_ctx(conn);

    assert(!endpoint->ep_server);
    if (status == LSQ_HSK_OK)
        endpoint->ep_handshake_ok = 1;
    else
    {
        fprintf(stderr, "TLS handshake failed with status %d\n", status);
        endpoint->ep_fixture->f_failed = 1;
    }
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct endpoint *endpoint = (struct endpoint *) lsquic_conn_get_ctx(conn);
    lsquic_conn_set_ctx(conn, NULL);
    ++endpoint->ep_closed_connections;
    endpoint->ep_conn = NULL;
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct endpoint *endpoint = ctx;
    struct stream_state *state;
    unsigned outgoing;

    assert(stream);
    assert(endpoint->ep_stream_count < MAX_STREAMS);
    state = &endpoint->ep_streams[endpoint->ep_stream_count++];
    memset(state, 0, sizeof(*state));
    state->ss_endpoint = endpoint;
    state->ss_stream = stream;
    state->ss_id = lsquic_stream_id(stream);
    outgoing = (state->ss_id & 1) == endpoint->ep_server;
    if ((state->ss_id & 2) && outgoing)
    {
        state->ss_send = uni_payload;
        state->ss_send_size = sizeof(uni_payload) - 1;
        assert(lsquic_stream_wantwrite(stream, 1) >= 0);
    }
    else
        assert(lsquic_stream_wantread(stream, 1) >= 0);
    return (lsquic_stream_ctx_t *) state;
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct stream_state *state = (struct stream_state *) ctx;
    unsigned char bytes[64];
    ssize_t size;

    while (1)
    {
        size = lsquic_stream_read(stream, bytes, sizeof(bytes));
        if (size > 0)
        {
            assert((size_t) size <= sizeof(state->ss_bytes) - state->ss_received);
            memcpy(state->ss_bytes + state->ss_received, bytes, size);
            state->ss_received += size;
        }
        else if (size == 0)
        {
            ++state->ss_fin;
            assert(state->ss_fin == 1);
            assert(lsquic_stream_wantread(stream, 0) >= 0);
            assert(0 == lsquic_stream_shutdown(stream, 0));
            return;
        }
        else
        {
            assert(errno == EWOULDBLOCK || errno == EAGAIN);
            return;
        }
    }
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct stream_state *state = (struct stream_state *) ctx;
    ssize_t size;

    assert(state->ss_send);
    size = lsquic_stream_write(stream, state->ss_send + state->ss_send_offset,
                              state->ss_send_size - state->ss_send_offset);
    if (size < 0)
    {
        assert(errno == EWOULDBLOCK || errno == EAGAIN);
        return;
    }
    state->ss_send_offset += size;
    if (state->ss_send_offset == state->ss_send_size)
    {
        assert(lsquic_stream_wantwrite(stream, 0) >= 0);
        assert(0 == lsquic_stream_shutdown(stream, 1));
    }
}


static void
close_stream (lsquic_stream_t *UNUSED_stream, lsquic_stream_ctx_t *ctx)
{
    struct stream_state *state = (struct stream_state *) ctx;
    ++state->ss_closed;
    assert(state->ss_closed == 1);
    state->ss_stream = NULL;
}


static const struct lsquic_stream_if stream_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_new_stream = new_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_hsk_done = handshake_done,
};


static int
queue_packets (void *ctx, const struct lsquic_out_spec *specs, unsigned count)
{
    struct endpoint *endpoint = ctx;
    struct packet_queue *queue = &endpoint->ep_peer->ep_incoming;
    struct queued_packet *packet;
    unsigned index, iov_index;
    size_t offset;

    for (index = 0; index < count; ++index)
    {
        assert(queue->pq_count < MAX_PACKETS);
        packet = &queue->pq_packets[(queue->pq_head + queue->pq_count) % MAX_PACKETS];
        offset = 0;
        for (iov_index = 0; iov_index < specs[index].iovlen; ++iov_index)
        {
            assert(specs[index].iov[iov_index].iov_len <= MAX_DATAGRAM - offset);
            memcpy(packet->qp_bytes + offset, specs[index].iov[iov_index].iov_base,
                   specs[index].iov[iov_index].iov_len);
            offset += specs[index].iov[iov_index].iov_len;
        }
        packet->qp_size = offset;
        ++queue->pq_count;
        ++endpoint->ep_packets_sent;
    }
    return count;
}


static void
deliver_packets (struct endpoint *endpoint)
{
    struct packet_queue *queue = &endpoint->ep_incoming;
    struct queued_packet *packet;
    unsigned available = queue->pq_count;
    unsigned index;
    int result;

    for (index = 0; index < available; ++index)
    {
        packet = &queue->pq_packets[queue->pq_head];
        result = lsquic_engine_packet_in(endpoint->ep_engine, packet->qp_bytes,
                    packet->qp_size, (struct sockaddr *) &endpoint->ep_address,
                    (struct sockaddr *) &endpoint->ep_peer->ep_address,
                    endpoint, 0);
        assert(result >= 0);
        queue->pq_head = (queue->pq_head + 1) % MAX_PACKETS;
        --queue->pq_count;
        ++endpoint->ep_packets_received;
    }
}


static void
pump_step (struct fixture *fixture)
{
    fixture_clock += 1000;
    lsquic_engine_process_conns(fixture->f_client.ep_engine);
    lsquic_engine_process_conns(fixture->f_server.ep_engine);
    deliver_packets(&fixture->f_client);
    deliver_packets(&fixture->f_server);
}


static void
init_endpoint (struct fixture *fixture, struct endpoint *endpoint,
               unsigned server, unsigned uni_limit)
{
    struct lsquic_engine_settings settings;
    struct lsquic_engine_api api;
    unsigned flags = server ? LSENG_SERVER : 0;

    endpoint->ep_fixture = fixture;
    endpoint->ep_server = server;
    endpoint->ep_ssl = new_tls_context(server);
    endpoint->ep_address.sin_family = AF_INET;
    endpoint->ep_address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    endpoint->ep_address.sin_port = htons(server ? 12001 : 12002);
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = 1U << LSQVER_I001;
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = uni_limit;
    memset(&api, 0, sizeof(api));
    api.ea_settings = &settings;
    api.ea_stream_if = &stream_callbacks;
    api.ea_stream_if_ctx = endpoint;
    api.ea_packets_out = queue_packets;
    api.ea_packets_out_ctx = endpoint;
    api.ea_lookup_cert = lookup_certificate;
    api.ea_cert_lu_ctx = endpoint;
    api.ea_get_ssl_ctx = get_tls_context;
    api.ea_alpn = raw_alpn;
    endpoint->ep_engine = lsquic_engine_new(flags, &api);
    assert(endpoint->ep_engine);
}


static void
init_fixture (struct fixture *fixture)
{
    memset(fixture, 0, sizeof(*fixture));
    init_endpoint(fixture, &fixture->f_client, 0, 2);
    init_endpoint(fixture, &fixture->f_server, 1, 2);
    fixture->f_client.ep_peer = &fixture->f_server;
    fixture->f_server.ep_peer = &fixture->f_client;
    assert(lsquic_engine_connect(fixture->f_client.ep_engine, LSQVER_I001,
                (struct sockaddr *) &fixture->f_client.ep_address,
                (struct sockaddr *) &fixture->f_server.ep_address,
                &fixture->f_client, NULL, "localhost", 0, NULL, 0, NULL, 0));
}


static void
cleanup_fixture (struct fixture *fixture)
{
    lsquic_engine_destroy(fixture->f_client.ep_engine);
    lsquic_engine_destroy(fixture->f_server.ep_engine);
    SSL_CTX_free(fixture->f_client.ep_ssl);
    SSL_CTX_free(fixture->f_server.ep_ssl);
}


static int
complete_handshake (struct fixture *fixture)
{
    unsigned step;

    for (step = 0; step < MAX_STEPS; ++step)
    {
        if (fixture->f_client.ep_handshake_ok
            && fixture->f_server.ep_handshake_ok)
            return 0;
        if (fixture->f_failed)
            return -1;
        pump_step(fixture);
    }
    return -1;
}


int
main (void)
{
    struct fixture fixture;
    int result;

    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    init_fixture(&fixture);
    result = complete_handshake(&fixture);
    if (result != 0)
    {
        fprintf(stderr, "Real-engine TLS handshake did not complete: client=%u server=%u packets=%u/%u\n",
                fixture.f_client.ep_handshake_ok, fixture.f_server.ep_handshake_ok,
                fixture.f_client.ep_packets_received, fixture.f_server.ep_packets_received);
        cleanup_fixture(&fixture);
        lsquic_global_cleanup();
        return 2;
    }
    printf("Real-engine encrypted TLS handshake complete: client=%u server=%u packets=%u/%u\n",
            fixture.f_client.ep_handshake_ok, fixture.f_server.ep_handshake_ok,
            fixture.f_client.ep_packets_received, fixture.f_server.ep_packets_received);
    if (!lsquic_conn_make_uni_stream)
    {
        fprintf(stderr, "RED: public lsquic_conn_make_uni_stream API is absent after successful real TLS handshake\n");
        cleanup_fixture(&fixture);
        lsquic_global_cleanup();
        return 1;
    }
    assert(EXPECT_UNI_OK == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert(fixture.f_server.ep_stream_count == 1);
    assert(fixture.f_server.ep_streams[0].ss_id == 3);
    cleanup_fixture(&fixture);
    lsquic_global_cleanup();
    return 0;
}

