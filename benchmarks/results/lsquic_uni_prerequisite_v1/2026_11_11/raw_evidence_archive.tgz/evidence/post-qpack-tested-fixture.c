/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <sys/queue.h>
#include <netinet/in.h>

#include <openssl/evp.h>
#include <openssl/rsa.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>

#include "lsquic.h"
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_packet_in.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"
#include "lsxpack_header.h"

#ifdef NDEBUG
#error "uwz_uni_stream requires active assertions"
#endif

extern int lsquic_conn_make_uni_stream (lsquic_conn_t *) __attribute__((weak));

enum {
    MAX_DATAGRAM = 4096,
    MAX_PACKETS = 256,
    MAX_STREAMS = 64,
    MAX_STEPS = 20000,
    EXPECT_UNI_OK = 0,
    EXPECT_UNI_BLOCKED = 1,
    EXPECT_UNI_UNSUPPORTED = -1,
    EXPECT_UNI_CLOSED = -2,
    EXPECT_UNI_NOMEM = -3,
};

enum callback_action {
    ACTION_NONE,
    ACTION_CLOSE_CONNECTION,
    ACTION_CLOSE_STREAM,
    ACTION_REENTER,
};

struct fixture;
struct endpoint;

struct queued_packet {
    size_t qp_size;
    unsigned char qp_bytes[MAX_DATAGRAM];
};

struct packet_queue {
    unsigned pq_head;
    unsigned pq_count;
    struct queued_packet pq_packets[MAX_PACKETS];
};

struct stream_state {
    struct endpoint *ss_endpoint;
    lsquic_stream_t *ss_stream;
    lsquic_stream_id_t ss_id;
    const char *ss_send;
    size_t ss_send_size;
    size_t ss_send_offset;
    size_t ss_received;
    unsigned ss_fin;
    unsigned ss_closed;
    unsigned ss_auto_fin;
    unsigned ss_headers_sent;
    unsigned char ss_bytes[4096];
};

struct endpoint {
    struct fixture *ep_fixture;
    struct endpoint *ep_peer;
    lsquic_engine_t *ep_engine;
    lsquic_conn_t *ep_conn;
    SSL_CTX *ep_ssl;
    struct sockaddr_in ep_address;
    struct packet_queue ep_incoming;
    unsigned ep_server;
    unsigned ep_new_connections;
    unsigned ep_handshake_ok;
    unsigned ep_closed_connections;
    unsigned ep_packets_sent;
    unsigned ep_packets_received;
    unsigned ep_stream_count;
    enum callback_action ep_action;
    int ep_nested_result;
    unsigned ep_auto_send;
    unsigned ep_http;
    unsigned ep_h3_peer;
    const char *ep_alpn;
    enum LSQUIC_CONN_STATUS ep_closed_status;
    char ep_close_reason[128];
    struct stream_state ep_streams[MAX_STREAMS];
};

struct fixture {
    struct endpoint f_client;
    struct endpoint f_server;
    unsigned f_failed;
};

/* The engine exposes one process-wide OS clock without a context parameter. */
static lsquic_time_t fixture_clock = 1000000;

static const char raw_alpn[] = "uwz-uni-test";
static const char uni_payload[] = "bounded encrypted uni payload";

/* Constructor/hash entry points have no allocator context; only the armed
 * synchronous API call consumes these process-wide one-shot fault switches. */
static unsigned fail_stream_new;
static unsigned fail_hash_insert;

extern lsquic_stream_t *
lsquic_real_stream_new (lsquic_stream_id_t, struct lsquic_conn_public *,
    const struct lsquic_stream_if *, void *, unsigned, uint64_t,
    enum stream_ctor_flags);

extern struct lsquic_hash_elem *
lsquic_real_hash_insert (struct lsquic_hash *, const void *, unsigned,
                        void *, struct lsquic_hash_elem *);


lsquic_stream_t *
lsquic_stream_new (lsquic_stream_id_t id, struct lsquic_conn_public *conn_pub,
    const struct lsquic_stream_if *callbacks, void *ctx, unsigned receive_window,
    uint64_t send_offset, enum stream_ctor_flags flags)
{
    if (fail_stream_new)
    {
        --fail_stream_new;
        return NULL;
    }
    return lsquic_real_stream_new(id, conn_pub, callbacks, ctx,
                                 receive_window, send_offset, flags);
}


struct lsquic_hash_elem *
lsquic_hash_insert (struct lsquic_hash *hash, const void *key, unsigned key_size,
                   void *value, struct lsquic_hash_elem *element)
{
    if (fail_hash_insert)
    {
        --fail_hash_insert;
        return NULL;
    }
    return lsquic_real_hash_insert(hash, key, key_size, value, element);
}


lsquic_time_t
__wrap_lsquic_time_now (void)
{
    return fixture_clock;
}


static int
select_alpn (SSL *UNUSED_ssl, const unsigned char **selected,
             unsigned char *selected_size, const unsigned char *offered,
             unsigned offered_size, void *ctx)
{
    const char *alpn = ctx;
    unsigned offset = 0;
    unsigned size;

    while (offset < offered_size)
    {
        size = offered[offset++];
        if (size > offered_size - offset)
            return SSL_TLSEXT_ERR_ALERT_FATAL;
        if (size == strlen(alpn)
            && 0 == memcmp(offered + offset, alpn, size))
        {
            *selected = offered + offset;
            *selected_size = size;
            return SSL_TLSEXT_ERR_OK;
        }
        offset += size;
    }
    return SSL_TLSEXT_ERR_ALERT_FATAL;
}


static SSL_CTX *
new_tls_context (int server, const char *alpn)
{
    SSL_CTX *ctx;
    EVP_PKEY_CTX *key_context;
    EVP_PKEY *key = NULL;
    X509 *certificate;
    X509_NAME *name;

    ctx = SSL_CTX_new(TLS_method());
    assert(ctx);
    assert(SSL_CTX_set_min_proto_version(ctx, TLS1_3_VERSION));
    assert(SSL_CTX_set_max_proto_version(ctx, TLS1_3_VERSION));
    SSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, NULL);
    if (!server)
        return ctx;

    key_context = EVP_PKEY_CTX_new_id(EVP_PKEY_RSA, NULL);
    assert(key_context);
    assert(1 == EVP_PKEY_keygen_init(key_context));
    assert(1 == EVP_PKEY_CTX_set_rsa_keygen_bits(key_context, 2048));
    assert(1 == EVP_PKEY_keygen(key_context, &key));
    certificate = X509_new();
    assert(certificate);
    assert(1 == X509_set_version(certificate, 2));
    assert(1 == ASN1_INTEGER_set(X509_get_serialNumber(certificate), 1));
    assert(1 == ASN1_TIME_set_string(X509_get_notBefore(certificate),
                                   "20260101000000Z"));
    assert(1 == ASN1_TIME_set_string(X509_get_notAfter(certificate),
                                   "20300101000000Z"));
    assert(1 == X509_set_pubkey(certificate, key));
    name = X509_get_subject_name(certificate);
    assert(1 == X509_NAME_add_entry_by_txt(name, "CN", MBSTRING_ASC,
                            (const unsigned char *) "localhost", -1, -1, 0));
    assert(1 == X509_set_issuer_name(certificate, name));
    assert(X509_sign(certificate, key, EVP_sha256()) > 0);
    assert(1 == SSL_CTX_use_certificate(ctx, certificate));
    assert(1 == SSL_CTX_use_PrivateKey(ctx, key));
    assert(1 == SSL_CTX_check_private_key(ctx));
    SSL_CTX_set_alpn_select_cb(ctx, select_alpn, (void *) alpn);
    X509_free(certificate);
    EVP_PKEY_free(key);
    EVP_PKEY_CTX_free(key_context);
    return ctx;
}


static SSL_CTX *
get_tls_context (void *peer_ctx, const struct sockaddr *UNUSED_local)
{
    struct endpoint *endpoint = peer_ctx;
    return endpoint->ep_ssl;
}


static SSL_CTX *
lookup_certificate (void *ctx, const struct sockaddr *UNUSED_local,
                    const char *UNUSED_sni)
{
    struct endpoint *endpoint = ctx;
    return endpoint->ep_ssl;
}


static lsquic_conn_ctx_t *
new_connection (void *ctx, lsquic_conn_t *conn)
{
    struct endpoint *endpoint = ctx;

    endpoint->ep_conn = conn;
    ++endpoint->ep_new_connections;
    if (endpoint->ep_server)
        endpoint->ep_handshake_ok = 1;
    return (lsquic_conn_ctx_t *) endpoint;
}


static void
handshake_done (lsquic_conn_t *conn, enum lsquic_hsk_status status)
{
    struct endpoint *endpoint = (struct endpoint *) lsquic_conn_get_ctx(conn);

    assert(!endpoint->ep_server);
    if (status == LSQ_HSK_OK)
        endpoint->ep_handshake_ok = 1;
    else
    {
        fprintf(stderr, "TLS handshake failed with status %d\n", status);
        endpoint->ep_fixture->f_failed = 1;
    }
}


static void
connection_closed (lsquic_conn_t *conn)
{
    struct endpoint *endpoint = (struct endpoint *) lsquic_conn_get_ctx(conn);
    endpoint->ep_closed_status = lsquic_conn_status(conn,
                    endpoint->ep_close_reason, sizeof(endpoint->ep_close_reason));
    lsquic_conn_set_ctx(conn, NULL);
    ++endpoint->ep_closed_connections;
    endpoint->ep_conn = NULL;
}


static lsquic_stream_ctx_t *
new_stream (void *ctx, lsquic_stream_t *stream)
{
    struct endpoint *endpoint = ctx;
    struct stream_state *state;
    unsigned outgoing;

    assert(stream);
    assert(endpoint->ep_stream_count < MAX_STREAMS);
    state = &endpoint->ep_streams[endpoint->ep_stream_count++];
    memset(state, 0, sizeof(*state));
    state->ss_endpoint = endpoint;
    state->ss_stream = stream;
    state->ss_id = lsquic_stream_id(stream);
    outgoing = (state->ss_id & 1) == endpoint->ep_server;
    if ((state->ss_id & 2) && outgoing
        && endpoint->ep_action == ACTION_CLOSE_CONNECTION)
    {
        lsquic_conn_close(lsquic_stream_conn(stream));
        return (lsquic_stream_ctx_t *) state;
    }
    if ((state->ss_id & 2) && outgoing
        && endpoint->ep_action == ACTION_CLOSE_STREAM)
    {
        assert(0 == lsquic_stream_close(stream));
        return (lsquic_stream_ctx_t *) state;
    }
    if ((state->ss_id & 2) && outgoing
        && endpoint->ep_action == ACTION_REENTER)
    {
        endpoint->ep_action = ACTION_NONE;
        endpoint->ep_nested_result = lsquic_conn_make_uni_stream(endpoint->ep_conn);
    }
    if ((state->ss_id & 2) && outgoing)
    {
        if (endpoint->ep_auto_send)
        {
            state->ss_send = uni_payload;
            state->ss_send_size = sizeof(uni_payload) - 1;
            state->ss_auto_fin = 1;
            assert(lsquic_stream_wantwrite(stream, 1) >= 0);
        }
    }
    else
        assert(lsquic_stream_wantread(stream, 1) >= 0);
    return (lsquic_stream_ctx_t *) state;
}


static void
read_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct stream_state *state = (struct stream_state *) ctx;
    unsigned char bytes[64];
    ssize_t size;

    while (1)
    {
        size = lsquic_stream_read(stream, bytes, sizeof(bytes));
        if (size > 0)
        {
            assert((size_t) size <= sizeof(state->ss_bytes) - state->ss_received);
            memcpy(state->ss_bytes + state->ss_received, bytes, size);
            state->ss_received += size;
        }
        else if (size == 0)
        {
            ++state->ss_fin;
            assert(state->ss_fin == 1);
            assert(lsquic_stream_wantread(stream, 0) >= 0);
            assert(0 == lsquic_stream_shutdown(stream, 0));
            if (state->ss_endpoint->ep_http && !(state->ss_id & 2))
                assert(lsquic_stream_wantwrite(stream, 1) >= 0);
            else if (state->ss_endpoint->ep_server && !(state->ss_id & 2))
            {
                state->ss_send = uni_payload;
                state->ss_send_size = sizeof(uni_payload) - 1;
                state->ss_auto_fin = 1;
                assert(lsquic_stream_wantwrite(stream, 1) >= 0);
            }
            return;
        }
        else
        {
            assert(errno == EWOULDBLOCK || errno == EAGAIN);
            return;
        }
    }
}


static void
write_stream (lsquic_stream_t *stream, lsquic_stream_ctx_t *ctx)
{
    struct stream_state *state = (struct stream_state *) ctx;
    ssize_t size;

    if (state->ss_endpoint->ep_http && !(state->ss_id & 2))
    {
        static const char response[] = ":status200";
        struct lsxpack_header header;
        struct lsquic_http_headers headers = { 1, &header };

        assert(!state->ss_headers_sent);
        lsxpack_header_set_offset2(&header, response, 0, 7, 7, 3);
        assert(0 == lsquic_stream_send_headers(stream, &headers, 1));
        ++state->ss_headers_sent;
        assert(lsquic_stream_wantwrite(stream, 0) >= 0);
        assert(0 == lsquic_stream_shutdown(stream, 1));
        return;
    }

    assert(state->ss_send);
    size = lsquic_stream_write(stream, state->ss_send + state->ss_send_offset,
                              state->ss_send_size - state->ss_send_offset);
    if (size < 0)
    {
        assert(errno == EWOULDBLOCK || errno == EAGAIN);
        return;
    }
    state->ss_send_offset += size;
    if (state->ss_send_offset == state->ss_send_size)
    {
        assert(lsquic_stream_wantwrite(stream, 0) >= 0);
        if (state->ss_auto_fin)
            assert(0 == lsquic_stream_shutdown(stream, 1));
        else
            assert(0 == lsquic_stream_flush(stream));
    }
}


static void
close_stream (lsquic_stream_t *UNUSED_stream, lsquic_stream_ctx_t *ctx)
{
    struct stream_state *state = (struct stream_state *) ctx;
    ++state->ss_closed;
    assert(state->ss_closed == 1);
    state->ss_stream = NULL;
}


static const struct lsquic_stream_if stream_callbacks = {
    .on_new_conn = new_connection,
    .on_conn_closed = connection_closed,
    .on_new_stream = new_stream,
    .on_read = read_stream,
    .on_write = write_stream,
    .on_close = close_stream,
    .on_hsk_done = handshake_done,
};


static int
queue_packets (void *ctx, const struct lsquic_out_spec *specs, unsigned count)
{
    struct endpoint *endpoint = ctx;
    struct packet_queue *queue = &endpoint->ep_peer->ep_incoming;
    struct queued_packet *packet;
    unsigned index, iov_index;
    size_t offset;

    for (index = 0; index < count; ++index)
    {
        assert(queue->pq_count < MAX_PACKETS);
        packet = &queue->pq_packets[(queue->pq_head + queue->pq_count) % MAX_PACKETS];
        offset = 0;
        for (iov_index = 0; iov_index < specs[index].iovlen; ++iov_index)
        {
            assert(specs[index].iov[iov_index].iov_len <= MAX_DATAGRAM - offset);
            memcpy(packet->qp_bytes + offset, specs[index].iov[iov_index].iov_base,
                   specs[index].iov[iov_index].iov_len);
            offset += specs[index].iov[iov_index].iov_len;
        }
        packet->qp_size = offset;
        ++queue->pq_count;
        ++endpoint->ep_packets_sent;
    }
    return count;
}


static void
deliver_packets (struct endpoint *endpoint)
{
    struct packet_queue *queue = &endpoint->ep_incoming;
    struct queued_packet *packet;
    unsigned available = queue->pq_count;
    unsigned index;
    int result;

    for (index = 0; index < available; ++index)
    {
        packet = &queue->pq_packets[queue->pq_head];
        result = lsquic_engine_packet_in(endpoint->ep_engine, packet->qp_bytes,
                    packet->qp_size, (struct sockaddr *) &endpoint->ep_address,
                    (struct sockaddr *) &endpoint->ep_peer->ep_address,
                    endpoint, 0);
        assert(result >= 0);
        queue->pq_head = (queue->pq_head + 1) % MAX_PACKETS;
        --queue->pq_count;
        ++endpoint->ep_packets_received;
    }
}


static void
pump_step (struct fixture *fixture)
{
    fixture_clock += 1000;
    lsquic_engine_process_conns(fixture->f_client.ep_engine);
    lsquic_engine_process_conns(fixture->f_server.ep_engine);
    deliver_packets(&fixture->f_client);
    deliver_packets(&fixture->f_server);
}


static void
init_endpoint (struct fixture *fixture, struct endpoint *endpoint,
               unsigned server, unsigned uni_limit, unsigned http)
{
    struct lsquic_engine_settings settings;
    struct lsquic_engine_api api;
    unsigned flags = server ? LSENG_SERVER : 0;

    if (http)
        flags |= LSENG_HTTP;

    endpoint->ep_fixture = fixture;
    endpoint->ep_server = server;
    endpoint->ep_http = http;
    endpoint->ep_alpn = fixture->f_server.ep_h3_peer ? "h3" : raw_alpn;
    endpoint->ep_ssl = new_tls_context(server, endpoint->ep_alpn);
    endpoint->ep_address.sin_family = AF_INET;
    endpoint->ep_address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    endpoint->ep_address.sin_port = htons(server ? 12001 : 12002);
    lsquic_engine_init_settings(&settings, flags);
    settings.es_versions = (1U << LSQVER_I001) | (1U << LSQVER_043);
    settings.es_pace_packets = 0;
    settings.es_init_max_streams_uni = uni_limit;
    /* Raw client transport parameters use the legacy incoming-stream bound. */
    settings.es_max_streams_in = uni_limit;
    settings.es_qpack_dec_max_size = 0;
    settings.es_qpack_dec_max_blocked = 0;
    settings.es_qpack_enc_max_size = 0;
    settings.es_qpack_enc_max_blocked = 0;
    memset(&api, 0, sizeof(api));
    api.ea_settings = &settings;
    api.ea_stream_if = &stream_callbacks;
    api.ea_stream_if_ctx = endpoint;
    api.ea_packets_out = queue_packets;
    api.ea_packets_out_ctx = endpoint;
    api.ea_lookup_cert = lookup_certificate;
    api.ea_cert_lu_ctx = endpoint;
    api.ea_get_ssl_ctx = get_tls_context;
    api.ea_alpn = endpoint->ep_alpn;
    endpoint->ep_engine = lsquic_engine_new(flags, &api);
    assert(endpoint->ep_engine);
}


static void
init_fixture_mode (struct fixture *fixture, unsigned h3, unsigned uni_limit)
{
    memset(fixture, 0, sizeof(*fixture));
    fixture->f_server.ep_h3_peer = h3;
    fixture->f_client.ep_h3_peer = h3;
    init_endpoint(fixture, &fixture->f_client, 0, uni_limit, 0);
    init_endpoint(fixture, &fixture->f_server, 1, uni_limit, h3);
    fixture->f_client.ep_peer = &fixture->f_server;
    fixture->f_server.ep_peer = &fixture->f_client;
    assert(lsquic_engine_connect(fixture->f_client.ep_engine, LSQVER_I001,
                (struct sockaddr *) &fixture->f_client.ep_address,
                (struct sockaddr *) &fixture->f_server.ep_address,
                &fixture->f_client, NULL, "localhost", 0, NULL, 0, NULL, 0));
}


static void
cleanup_fixture (struct fixture *fixture)
{
    lsquic_engine_destroy(fixture->f_client.ep_engine);
    lsquic_engine_destroy(fixture->f_server.ep_engine);
    SSL_CTX_free(fixture->f_client.ep_ssl);
    SSL_CTX_free(fixture->f_server.ep_ssl);
}


static int
complete_handshake (struct fixture *fixture)
{
    unsigned step;

    for (step = 0; step < MAX_STEPS; ++step)
    {
        if (fixture->f_client.ep_handshake_ok
            && fixture->f_server.ep_handshake_ok)
            return 0;
        if (fixture->f_failed)
            return -1;
        pump_step(fixture);
    }
    return -1;
}


static void
pump_steps (struct fixture *fixture, unsigned count)
{
    unsigned step;

    for (step = 0; step < count; ++step)
        pump_step(fixture);
}


static void
start_fixture (struct fixture *fixture, unsigned h3, unsigned uni_limit)
{
    init_fixture_mode(fixture, h3, uni_limit);
    assert(0 == complete_handshake(fixture));
    assert(fixture->f_server.ep_new_connections == 1);
    assert(fixture->f_client.ep_new_connections == 1);
    assert(fixture->f_server.ep_packets_received > 0);
    assert(fixture->f_client.ep_packets_received > 0);
}


static struct stream_state *
find_stream (struct endpoint *endpoint, lsquic_stream_id_t id)
{
    unsigned index;

    for (index = 0; index < endpoint->ep_stream_count; ++index)
        if (endpoint->ep_streams[index].ss_id == id)
            return &endpoint->ep_streams[index];
    return NULL;
}


static void
send_bytes (struct stream_state *state, const char *bytes, size_t size,
            unsigned fin)
{
    assert(state && state->ss_stream);
    state->ss_send = bytes;
    state->ss_send_size = size;
    state->ss_send_offset = 0;
    state->ss_auto_fin = fin;
    assert(lsquic_stream_wantwrite(state->ss_stream, 1) >= 0);
}


static void
assert_received (struct stream_state *state, const char *bytes, size_t size)
{
    assert(state);
    assert(state->ss_received == size);
    assert(0 == memcmp(state->ss_bytes, bytes, size));
    assert(state->ss_fin == 1);
}


static void
assert_payload (struct stream_state *state, const char *bytes, size_t size)
{
    assert_received(state, bytes, size);
    assert(state->ss_closed == 1);
}


static void
assert_transport_closed (struct fixture *fixture, unsigned packets_before)
{
    unsigned step;

    for (step = 0; step < 2000; ++step)
    {
        if (fixture->f_client.ep_closed_connections
            && fixture->f_server.ep_closed_connections)
            break;
        pump_step(fixture);
    }
    assert(fixture->f_server.ep_closed_connections == 1);
    assert(fixture->f_client.ep_closed_connections == 1);
    assert(fixture->f_client.ep_packets_received > packets_before);
    assert(fixture->f_server.ep_closed_status != LSCONN_ST_TIMED_OUT);
    assert(fixture->f_client.ep_closed_status != LSCONN_ST_TIMED_OUT);
}


static void
test_prehandshake_and_unsupported (void)
{
    struct fixture fixture;
    lsquic_conn_t *legacy;

    assert(EXPECT_UNI_UNSUPPORTED == lsquic_conn_make_uni_stream(NULL));
    init_fixture_mode(&fixture, 0, 2);
    assert(fixture.f_client.ep_conn);
    assert(EXPECT_UNI_BLOCKED == lsquic_conn_make_uni_stream(fixture.f_client.ep_conn));
    assert(fixture.f_client.ep_stream_count == 0);
    assert(0 == lsquic_conn_n_pending_streams(fixture.f_client.ep_conn));
    assert(0 == complete_handshake(&fixture));
    assert(EXPECT_UNI_OK == lsquic_conn_make_uni_stream(fixture.f_client.ep_conn));
    assert(fixture.f_client.ep_stream_count == 1);
    assert(fixture.f_client.ep_streams[0].ss_id == 2);
    cleanup_fixture(&fixture);

    memset(&fixture, 0, sizeof(fixture));
    init_endpoint(&fixture, &fixture.f_client, 0, 2, 0);
    fixture.f_client.ep_peer = &fixture.f_server;
    fixture.f_server.ep_address.sin_family = AF_INET;
    fixture.f_server.ep_address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    fixture.f_server.ep_address.sin_port = htons(12001);
    legacy = lsquic_engine_connect(fixture.f_client.ep_engine, LSQVER_043,
                (struct sockaddr *) &fixture.f_client.ep_address,
                (struct sockaddr *) &fixture.f_server.ep_address,
                &fixture.f_client, NULL, "localhost", 0, NULL, 0, NULL, 0);
    assert(legacy);
    assert(EXPECT_UNI_UNSUPPORTED == lsquic_conn_make_uni_stream(legacy));
    assert(fixture.f_client.ep_stream_count == 0);
    assert(0 == lsquic_conn_n_pending_streams(legacy));
    lsquic_engine_destroy(fixture.f_client.ep_engine);
    SSL_CTX_free(fixture.f_client.ep_ssl);
    puts("PASS prehandshake BLOCKED, NULL and real gQUIC UNSUPPORTED, no callback or pending request");
}


static void
test_raw_credit_and_fin (void)
{
    struct fixture fixture;
    unsigned step, callbacks;

    start_fixture(&fixture, 0, 2);
    fixture.f_server.ep_auto_send = 1;
    assert(EXPECT_UNI_OK == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert(EXPECT_UNI_OK == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert(fixture.f_server.ep_stream_count == 2);
    assert(fixture.f_server.ep_streams[0].ss_id == 3);
    assert(fixture.f_server.ep_streams[1].ss_id == 7);
    assert(EXPECT_UNI_BLOCKED == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert(fixture.f_server.ep_stream_count == 2);
    assert(0 == lsquic_conn_n_pending_streams(fixture.f_server.ep_conn));

    /* Withhold the encrypted return path, including genuine MAX_STREAMS. */
    for (step = 0; step < 100; ++step)
    {
        fixture_clock += 1000;
        lsquic_engine_process_conns(fixture.f_server.ep_engine);
        deliver_packets(&fixture.f_client);
        lsquic_engine_process_conns(fixture.f_client.ep_engine);
    }
    assert(fixture.f_client.ep_stream_count == 2);
    assert_received(find_stream(&fixture.f_client, 3), uni_payload, sizeof(uni_payload) - 1);
    assert_received(find_stream(&fixture.f_client, 7), uni_payload, sizeof(uni_payload) - 1);
    assert(fixture.f_server.ep_incoming.pq_count > 0);
    assert(EXPECT_UNI_BLOCKED == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    callbacks = fixture.f_server.ep_stream_count;
    deliver_packets(&fixture.f_server);
    pump_steps(&fixture, 100);
    assert(fixture.f_server.ep_stream_count == callbacks);
    assert(0 == lsquic_conn_n_pending_streams(fixture.f_server.ep_conn));
    assert(EXPECT_UNI_OK == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert(fixture.f_server.ep_stream_count == 3);
    assert(fixture.f_server.ep_streams[2].ss_id == 11);
    pump_steps(&fixture, 200);
    assert_payload(find_stream(&fixture.f_client, 11), uni_payload, sizeof(uni_payload) - 1);
    assert(fixture.f_server.ep_streams[0].ss_closed == 1);
    assert(fixture.f_server.ep_streams[1].ss_closed == 1);
    assert(fixture.f_server.ep_streams[2].ss_closed == 1);
    assert(find_stream(&fixture.f_client, 3)->ss_closed == 1);
    assert(find_stream(&fixture.f_client, 7)->ss_closed == 1);
    cleanup_fixture(&fixture);
    puts("PASS encrypted server uni IDs3/7/11, exact bytes+FIN, genuine MAX_STREAMS only, no automatic queue");
}


static void
test_allocation_failure (void)
{
    struct fixture fixture;

    start_fixture(&fixture, 0, 2);
    fail_stream_new = 1;
    assert(EXPECT_UNI_NOMEM == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert(fail_stream_new == 0);
    assert(fixture.f_server.ep_stream_count == 0);
    assert(0 == lsquic_conn_n_pending_streams(fixture.f_server.ep_conn));
    fail_hash_insert = 1;
    assert(EXPECT_UNI_NOMEM == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert(fail_hash_insert == 0);
    assert(fixture.f_server.ep_stream_count == 0);
    assert(0 == lsquic_conn_n_pending_streams(fixture.f_server.ep_conn));
    fixture.f_server.ep_auto_send = 1;
    assert(EXPECT_UNI_OK == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert(fixture.f_server.ep_streams[0].ss_id == 3);
    pump_steps(&fixture, 200);
    assert_payload(find_stream(&fixture.f_client, 3), uni_payload, sizeof(uni_payload) - 1);
    assert(fixture.f_server.ep_stream_count == 1);
    assert(fixture.f_client.ep_stream_count == 1);
    assert(!fixture.f_server.ep_closed_connections);
    cleanup_fixture(&fixture);
    puts("PASS constructor/hash failure NOMEM, no callback/queue/ID loss, successful same-ID retry");
}


static void
test_reentrant_and_stream_close (void)
{
    struct fixture fixture;

    start_fixture(&fixture, 0, 2);
    fixture.f_server.ep_action = ACTION_REENTER;
    fixture.f_server.ep_auto_send = 1;
    assert(EXPECT_UNI_OK == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert(fixture.f_server.ep_nested_result == EXPECT_UNI_OK);
    assert(fixture.f_server.ep_stream_count == 2);
    assert(fixture.f_server.ep_streams[0].ss_id == 3);
    assert(fixture.f_server.ep_streams[1].ss_id == 7);
    pump_steps(&fixture, 200);
    assert_payload(find_stream(&fixture.f_client, 3), uni_payload, sizeof(uni_payload) - 1);
    assert_payload(find_stream(&fixture.f_client, 7), uni_payload, sizeof(uni_payload) - 1);
    cleanup_fixture(&fixture);

    start_fixture(&fixture, 0, 2);
    fixture.f_server.ep_action = ACTION_CLOSE_STREAM;
    assert(EXPECT_UNI_OK == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert(fixture.f_server.ep_stream_count == 1);
    pump_steps(&fixture, 200);
    assert(fixture.f_server.ep_streams[0].ss_closed == 1);
    assert(!fixture.f_server.ep_closed_connections);
    cleanup_fixture(&fixture);
    puts("PASS reentrant synchronous creation IDs3/7 and callback-only stream close, exactly-once release");
}


static void
test_explicit_connection_close (void)
{
    struct fixture fixture;
    unsigned packets_before;

    start_fixture(&fixture, 0, 2);
    fixture.f_server.ep_action = ACTION_CLOSE_CONNECTION;
    packets_before = fixture.f_client.ep_packets_received;
    assert(EXPECT_UNI_OK == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert(fixture.f_server.ep_stream_count == 1);
    assert(fixture.f_server.ep_streams[0].ss_id == 3);
    assert(EXPECT_UNI_CLOSED == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert_transport_closed(&fixture, packets_before);
    assert(fixture.f_server.ep_streams[0].ss_closed == 1);
    cleanup_fixture(&fixture);

    start_fixture(&fixture, 0, 2);
    assert(EXPECT_UNI_OK == lsquic_conn_make_uni_stream(fixture.f_client.ep_conn));
    send_bytes(&fixture.f_client.ep_streams[0], uni_payload, sizeof(uni_payload) - 1, 0);
    pump_steps(&fixture, 200);
    assert(fixture.f_server.ep_stream_count == 1);
    assert(fixture.f_server.ep_streams[0].ss_received == sizeof(uni_payload) - 1);
    assert(fixture.f_server.ep_streams[0].ss_fin == 0);
    assert(fixture.f_server.ep_streams[0].ss_closed == 0);
    packets_before = fixture.f_client.ep_packets_received;
    lsquic_conn_close(fixture.f_server.ep_conn);
    assert(EXPECT_UNI_CLOSED == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert_transport_closed(&fixture, packets_before);
    assert(fixture.f_server.ep_streams[0].ss_closed == 1);
    cleanup_fixture(&fixture);
    puts("PASS callback-only and idle-incoming explicit CONNECTION_CLOSE without FIN, no idle timeout shortcut");
}


static void
test_bidirectional_unchanged (void)
{
    struct fixture fixture;

    start_fixture(&fixture, 0, 2);
    lsquic_conn_make_stream(fixture.f_client.ep_conn);
    pump_steps(&fixture, 20);
    assert(fixture.f_client.ep_stream_count == 1);
    assert(fixture.f_client.ep_streams[0].ss_id == 0);
    send_bytes(&fixture.f_client.ep_streams[0], uni_payload, sizeof(uni_payload) - 1, 1);
    pump_steps(&fixture, 200);
    assert_payload(find_stream(&fixture.f_server, 0), uni_payload, sizeof(uni_payload) - 1);
    assert_payload(find_stream(&fixture.f_client, 0), uni_payload, sizeof(uni_payload) - 1);
    cleanup_fixture(&fixture);
    puts("PASS existing bidirectional request/response IDs0, exact bytes+FIN both directions");
}


static void
assert_h3_critical (struct fixture *fixture, unsigned encoder)
{
    struct stream_state *control = find_stream(&fixture->f_client, 3);
    struct stream_state *decoder = find_stream(&fixture->f_client, 7);
    struct stream_state *encoder_stream = find_stream(&fixture->f_client, 11);

    assert(control && control->ss_received && control->ss_bytes[0] == 0);
    assert(decoder && decoder->ss_received && decoder->ss_bytes[0] == 3);
    assert(control->ss_fin == 0 && control->ss_closed == 0);
    assert(decoder->ss_fin == 0 && decoder->ss_closed == 0);
    if (encoder)
    {
        assert(encoder_stream && encoder_stream->ss_received);
        assert(encoder_stream->ss_bytes[0] == 2);
        assert(encoder_stream->ss_fin == 0 && encoder_stream->ss_closed == 0);
    }
    else
        assert(!encoder_stream);
}


static void
init_h3_settings (struct fixture *fixture, unsigned peer_limit)
{
    static const char control_type[] = { 0 };
    static const char encoder_type[] = { 2 };
    static const char decoder_type[] = { 3 };
    static const char settings_frame[] = { 4, 0 };
    unsigned index;

    start_fixture(fixture, 1, peer_limit);
    pump_steps(fixture, 100);
    assert_h3_critical(fixture, 0);
    assert(EXPECT_UNI_BLOCKED == lsquic_conn_make_uni_stream(fixture->f_server.ep_conn));
    assert(fixture->f_server.ep_stream_count == 0);
    assert(0 == lsquic_conn_n_pending_streams(fixture->f_server.ep_conn));
    for (index = 0; index < 3; ++index)
        assert(EXPECT_UNI_OK == lsquic_conn_make_uni_stream(fixture->f_client.ep_conn));
    send_bytes(find_stream(&fixture->f_client, 2), control_type, sizeof(control_type), 0);
    send_bytes(find_stream(&fixture->f_client, 6), encoder_type, sizeof(encoder_type), 0);
    send_bytes(find_stream(&fixture->f_client, 10), decoder_type, sizeof(decoder_type), 0);
    pump_steps(fixture, 100);
    assert(!fixture->f_server.ep_closed_connections);
    assert(EXPECT_UNI_BLOCKED == lsquic_conn_make_uni_stream(fixture->f_server.ep_conn));
    assert_h3_critical(fixture, 0);
    send_bytes(find_stream(&fixture->f_client, 2), settings_frame, sizeof(settings_frame), 0);
    pump_steps(fixture, 100);
    assert(!fixture->f_server.ep_closed_connections);
    assert_h3_critical(fixture, 1);
    assert(fixture->f_server.ep_stream_count == 0);
}


static void
test_h3_critical_credit (void)
{
    static const char grease_payload[] = "\x21" "bounded encrypted uni payload";
    struct fixture fixture;

    init_h3_settings(&fixture, 3);
    assert(EXPECT_UNI_BLOCKED == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert(fixture.f_server.ep_stream_count == 0);
    assert(0 == lsquic_conn_n_pending_streams(fixture.f_server.ep_conn));
    cleanup_fixture(&fixture);

    init_h3_settings(&fixture, 4);
    assert(EXPECT_UNI_OK == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert(fixture.f_server.ep_stream_count == 1);
    assert(fixture.f_server.ep_streams[0].ss_id == 15);
    assert(EXPECT_UNI_BLOCKED == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    send_bytes(&fixture.f_server.ep_streams[0], grease_payload, sizeof(grease_payload) - 1, 1);
    pump_steps(&fixture, 200);
    assert_payload(find_stream(&fixture.f_client, 15), grease_payload, sizeof(grease_payload) - 1);
    assert_h3_critical(&fixture, 1);
    assert(!fixture.f_server.ep_closed_connections);
    cleanup_fixture(&fixture);
    puts("PASS H3 critical IDs3/7/11 and zero-dynamic QPACK, delayed SETTINGS guard, credit3 blocked/credit4 app15");
}


static size_t
encode_request (char *bytes, size_t capacity)
{
    static const char *names[] = { ":method", ":scheme", ":authority", ":path" };
    static const char *values[] = { "GET", "https", "localhost", "/" };
    size_t offset = 4, name_size, value_size;
    unsigned index;

    assert(capacity >= 64);
    bytes[0] = 1;
    bytes[2] = 0;
    bytes[3] = 0;
    for (index = 0; index < 4; ++index)
    {
        name_size = strlen(names[index]);
        value_size = strlen(values[index]);
        bytes[offset++] = 0x20 | (name_size < 7 ? name_size : 7);
        if (name_size >= 7)
            bytes[offset++] = name_size - 7;
        memcpy(bytes + offset, names[index], name_size);
        offset += name_size;
        bytes[offset++] = value_size;
        memcpy(bytes + offset, values[index], value_size);
        offset += value_size;
    }
    assert(offset - 2 < 64);
    bytes[1] = offset - 2;
    return offset;
}


static void
test_h3_graceful_drain (void)
{
    static const char first[] = "\x21" "before-goaway";
    static const char second[] = "-after-last-bidi-fin";
    char request[128], expected[128];
    size_t request_size;
    struct fixture fixture;
    struct stream_state *application, *received, *bidi;
    unsigned step;

    init_h3_settings(&fixture, 4);
    lsquic_conn_make_stream(fixture.f_client.ep_conn);
    pump_steps(&fixture, 20);
    bidi = find_stream(&fixture.f_client, 0);
    assert(bidi);
    request_size = encode_request(request, sizeof(request));
    send_bytes(bidi, request, request_size, 0);
    assert(EXPECT_UNI_OK == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    application = find_stream(&fixture.f_server, 15);
    assert(application);
    send_bytes(application, first, sizeof(first) - 1, 0);
    pump_steps(&fixture, 200);
    received = find_stream(&fixture.f_client, 15);
    assert(received && received->ss_received == sizeof(first) - 1);
    assert(received->ss_fin == 0);
    assert(find_stream(&fixture.f_server, 0));
    lsquic_conn_going_away(fixture.f_server.ep_conn);
    assert(EXPECT_UNI_CLOSED == lsquic_conn_make_uni_stream(fixture.f_server.ep_conn));
    assert(0 == lsquic_stream_shutdown(bidi->ss_stream, 1));
    pump_steps(&fixture, 300);
    assert(find_stream(&fixture.f_server, 0)->ss_closed == 1);
    assert(bidi->ss_closed == 1);
    assert(!fixture.f_server.ep_closed_connections);
    assert(!fixture.f_client.ep_closed_connections);
    assert(application->ss_stream && application->ss_closed == 0);
    assert(received->ss_fin == 0 && received->ss_closed == 0);
    send_bytes(application, second, sizeof(second) - 1, 1);
    for (step = 0; step < 2000; ++step)
    {
        if (fixture.f_client.ep_closed_connections
            && fixture.f_server.ep_closed_connections)
            break;
        pump_step(&fixture);
    }
    memcpy(expected, first, sizeof(first) - 1);
    memcpy(expected + sizeof(first) - 1, second, sizeof(second) - 1);
    assert_payload(received, expected, sizeof(first) + sizeof(second) - 2);
    assert(application->ss_closed == 1);
    assert(fixture.f_server.ep_closed_connections == 1);
    assert(fixture.f_client.ep_closed_connections == 1);
    assert(fixture.f_server.ep_closed_status != LSCONN_ST_TIMED_OUT);
    assert(fixture.f_client.ep_closed_status != LSCONN_ST_TIMED_OUT);
    cleanup_fixture(&fixture);
    puts("PASS H3 graceful GOAWAY drains app uni after queued data ACK and last bidi close, then bytes+FIN and transport close");
}


int
main (void)
{
    struct fixture fixture;

    assert(0 == setvbuf(stdout, NULL, _IONBF, 0));
    assert(0 == lsquic_global_init(LSQUIC_GLOBAL_CLIENT | LSQUIC_GLOBAL_SERVER));
    if (!lsquic_conn_make_uni_stream)
    {
        start_fixture(&fixture, 0, 2);
        fprintf(stderr, "RED: public API absent after successful real encrypted TLS handshake\n");
        cleanup_fixture(&fixture);
        lsquic_global_cleanup();
        return 1;
    }
    test_prehandshake_and_unsupported();
    test_raw_credit_and_fin();
    test_allocation_failure();
    test_reentrant_and_stream_close();
    test_explicit_connection_close();
    test_bidirectional_unchanged();
    test_h3_critical_credit();
    test_h3_graceful_drain();
    lsquic_global_cleanup();
    puts("All real-engine unidirectional stream API tests passed");
    return 0;
}
