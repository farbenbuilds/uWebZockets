# Real-engine outgoing unidirectional stream verification

The maintained-fork base is `85bd081c9103c077a7cc98271d09334d0f1043d4`.
All work is isolated under `/tmp`; root dependency pins, package contents,
production sources, and system installations are unchanged by this harness.

`tests/uwz_uni_stream.c` drives two actual production lsquic engines through a
TLS 1.3 handshake and encrypted QUIC packets. Fixed caller-owned packet queues
defer `packet_in` until after `packets_out` returns. A test-only process clock
advances 1 ms per bounded pump; there are no sockets, sleeps, or timed throughput
claims. TLS, BoringSSL, and lsquic retain their ordinary C heap allocations.
No WebTransport setting or capability is enabled. The HTTP/3 peer negotiates
`h3`, sends actual SETTINGS/QPACK and a literal QPACK request, and uses a legal
unknown stream type `0x21` for application data.

The Linux native build uses Zig 0.16.0 for all C/C++ dependencies and the same
native source lists/macros as the root build graph. The isolated scaffold copies
dependency packages without modifying them and assembles the explicit scratch
lsquic source override. It requires no CMake, Ninja, Go, Perl, or system zlib.

Only three translation-unit definition seams differ from an ordinary library:
`lsquic_util.c` renames its OS clock definition to `lsquic_real_time_now`,
`lsquic_stream.c` renames its constructor definition to `lsquic_real_stream_new`,
and `lsquic_hash.c` renames insertion to `lsquic_real_hash_insert`. All callers
retain their original symbols. The fixture supplies the clock and normally
delegating constructor/hash proxies, arming a one-shot NULL result only for the
specific synchronous API fault test after a successful real handshake.
There are no fabricated connection/stream objects or transport parameters.
The separate upstream-test build disables all three seams.

## Exact commands

Working directory for each command: `/tmp/uwz-lsquic-uni-harness`.

```sh
export PATH=/tmp/zig-x86_64-linux-0.16.0:$PATH
export ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-uni-global-cache
zig build test -Doptimize=Debug -j2 --summary all
zig build test -Doptimize=ReleaseSafe -j2 --summary all
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1:strict_string_checks=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
zig build test -Doptimize=ReleaseSafe -Dsanitize=true \
  -Dsanitizer-lib-dir=/tmp/uwz-compiler-rt/usr/lib/llvm-21/lib/clang/21/lib/linux \
  -j2 --summary all
```

The scaffold adds its native ASan preload and `use_sigaltstack=0` as recorded
verbatim in the sanitizer build output. The compiler-rt runtime is LLVM 21.1.8.
Sanitizer errors are fatal; no check is suppressed. An unavailable external
symbolizer warning is retained; `preexisting-sanitizer-symbolized.txt` was
generated with system `addr2line` against the exact retained executable.

Source overrides append these exact options to the corresponding command:

```sh
-Dlsquic-source=/tmp/uwz-lsquic-uni-harness/baseline-source \
-Dfixture-includes=/tmp/uwz-lsquic-uni-harness/baseline-source/src/liblsquic

-Dlsquic-source=/tmp/uwz-lsquic-uni-harness/omit-raw-receive-finish \
-Dfixture-includes=/tmp/uwz-lsquic-uni-harness/omit-raw-receive-finish/src/liblsquic

-Dlsquic-source=/tmp/uwz-lsquic-uni-harness/omit-graceful-uni-drain \
-Dfixture-includes=/tmp/uwz-lsquic-uni-harness/omit-graceful-uni-drain/src/liblsquic
```

`baseline-source` was exported with `git archive` from the exact base commit.
Each omission tree was copied from the frozen candidate and removes exactly
the documented lifecycle change; its raw patch and source hash are retained.

## Evidence cohorts

- `red-clean-debug-unsandboxed.log`: valid initial runtime RED. Two engines
  completed the real encrypted handshake, then the weak missing API check
  returned exit 1. Both engine-destroy calls returned before exit; no assertion
  abort. Leak freedom was not established by that Debug run.
- `red-callback-close-debug.log`: valid targeted RED after the API existed.
  Server callback only called `conn_close`, without FIN or `stream_close`;
  both close callbacks remained zero after 2,000 bounded pump steps.
- `green-expanded-debug-2.log`, `green-expanded-release-safe.log`: all eight
  case groups passed on production `full_conn_ietf.c` hash `1ecec21a...`.
- `green-expanded-sanitizers.log`: strict sanitizer RED in the real handshake,
  before the first API case completed. An existing ACK callback cast invoked
  `lsquic_rechist_first` through an incompatible function-pointer type at
  `lsquic_parse_ietf_v1.c:1007`. This is not a sanitizer pass.
- `baseline-handshake-sanitizers.log`: the exact untouched base reproduces
  the same ACK callback UB before the missing-API assertion, proving it
  predates the new API. No sanitizer suppression was introduced.
- `red-omitted-raw-credit-debug.log`: with only raw receive completion omitted,
  exact bytes+FIN arrive, returned encrypted packets are delivered, but the
  next explicit uni retry remains blocked. Real MAX_STREAMS restoration fails.
- `red-omitted-graceful-drain-debug.log`: first seven case groups pass; with
  only uni drain accounting omitted, GOAWAY closes the server after the last
  bidi closes while application uni 15 still awaits more bytes and FIN.

Earlier setup/test failures remain raw and separately named. The first raw
credit fixture set only `es_init_max_streams_uni`; pinned raw client transport
parameters actually use `es_max_streams_in`. Both now request the same exact
bound 2. Deliberately unfinished stream chunks now call public `stream_flush`
after writing. Neither correction changes production or lowers an assertion.
Receiver close assertions were moved after the explicit credit retry to make
the controlled omission fail at the missing credit itself; they remain required.

The complete suite checks raw IDs 3/7/11, exact payload and FIN, exactly-once
sender/receiver close, no callback/pending queue during credit or allocation
failure, genuine received MAX_STREAMS recovery with explicit retry, pre-handshake
blocking, real gQUIC/NULL unsupported status, reentrant callbacks, callback-only
stream/connection close, idle incoming uni close, bidi request/response, HTTP/3
critical IDs 3/7/11, zero-dynamic QPACK, delayed SETTINGS guard, peer uni limits
3 versus 4, first HTTP/3 app ID 15, and graceful last-bidi/application-uni drain.

## Post-ACK-adapter cohort

`final-debug.log` and `final-release-safe.log` pass all eight groups against
`full_conn_ietf.c` SHA256 `2a833f2c649a73815adfd8975f88bf1895b79b53eca1feb010700ccdfb690b50`
and `lsquic_conn.h` SHA256 `1c4214e84b00c475ed34cc7333484e78c8e8018278a28dd89b8a5946fc858e45`.
The corresponding exact executables and hashes are retained in `binaries/` and
`final-*-binary.txt`.

`final-sanitizers.log` passes the first seven groups, then finds another existing
UB in the required zero-dynamic QPACK response path: `qeh_write_headers` declares
a VLA with bound `qpe_cur_max_capacity * 2`, which is zero. The file
`lsquic_qenc_hdl.c` is unchanged from the exact base. This is a strict sanitizer
failure, not a pass. `preexisting-qpack-vla-symbolized.txt` records the exact
stack through the real public `stream_send_headers` call. Neither the zero
capacity requirement nor the sanitizer gate was weakened.

The subsequent cohorts below retain the later fixes and outcomes separately.
No successful sanitizer claim is made for either preceding failing cohort.

## Post-QPACK-fix teardown finding

`final-qpack-fix-debug.log` and `final-qpack-fix-release-safe.log` pass all eight
groups against the physical-buffer fix in `lsquic_qenc_hdl.c`, SHA256
`881bdc81f7da5763c60dd8058fd52f601b14a6b96a3c2490d96d8e0148bc9c08`.
`final-qpack-fix-sanitizers.log` reaches all eight PASS groups with no preceding
ASan/UBSan report, but LeakSanitizer fails normal process exit: 2,170 bytes in
three allocations remain. Thus the sanitizer gate is still failed.

`tls-only-destroy-probe.c` isolates a real encrypted TLS handshake followed
immediately by public `engine_destroy`, with zero application stream callbacks
and no invocation of the new uni API. `tls-only-destroy-sanitizers-red.log`
reproduces the same leak. `final-qpack-fix-leaks-symbolized.txt` identifies the
crypto stream (720 bytes), its data-in state (80 bytes), and a retained decrypted
packet buffer (1,370 bytes). The public engine destroy contract promises to free
all connections, streams, and associated memory, so an extra graceful-drain
workaround was not added. Immediate TLS-only teardown is now also retained in
the first permanent test group. The strict leak check remains enabled.

## Protocol references

Stream ID expectations follow [RFC 9000 section 2.1](https://www.rfc-editor.org/rfc/rfc9000.html#section-2.1).
Credit expectations follow [RFC 9000 section 4.6](https://www.rfc-editor.org/rfc/rfc9000.html#section-4.6).
WebTransport negotiation in [draft-16 section 3.1](https://www.ietf.org/archive/id/draft-ietf-webtrans-http3-16.html#section-3.1)
is outside this prerequisite; no such setting or capability is enabled here.

## Final cleanup-fixed cohort

`final-cleanup-debug.log`, `final-cleanup-release-safe.log`, and
`final-cleanup-sanitizers.log` each pass all eight permanent case groups and
12/12 native build steps with exit 0. The root agent ran the final full strict
sanitizer command (handle 93258); there is no ASan, UBSan or LeakSanitizer report.
`tls-only-destroy-sanitizers-green.log` also exits 0 on the identical standalone
probe that previously leaked 2,170 bytes. No extra engine tick, graceful drain,
leak suppression or disabled function-type check was added.

Final full-connection source SHA256 is
`0719109644a372e8901198453d83886143ac8ca0da3ed0e3f22e21ad6e7efa9f`;
final QPACK source SHA256 remains
`881bdc81f7da5763c60dd8058fd52f601b14a6b96a3c2490d96d8e0148bc9c08`;
the fixture SHA256 is
`71f3535950c32cbe8b2dc1981a2d8fb8ec4185d939785d17dce049b3add8ad98`.
`final-cleanup-inputs-before.sha256` and `final-cleanup-inputs-after.sha256`
are identical for all five production C/header files plus the fixture.

Root later supplied terminal results: all 83 existing Linux Debug runtime cases
passed (165/165 build steps), and ReleaseSafe production-library cross-builds
passed 9/9 steps each for x86_64-windows-gnu and aarch64-macos. The earlier 84
existing count was a report arithmetic error; 83 existing plus 1 new integration
registration equals 84 total CMake cases. Actual cases/gates were unchanged.
Raw logs, exact commands, copied seam-disabled native runner, and owner-supplied
terminal-code provenance are included in the portable package. No foreign
runtime was executed or claimed.
