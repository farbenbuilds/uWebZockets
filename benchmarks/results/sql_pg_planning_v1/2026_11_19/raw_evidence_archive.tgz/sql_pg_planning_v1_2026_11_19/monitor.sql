WITH target AS (
    SELECT (SELECT oid FROM pg_database WHERE datname = 'benchmark') AS dbid,
           (SELECT oid FROM pg_roles WHERE rolname = 'bench') AS userid
), selected AS (
    SELECT s.userid,s.dbid,s.toplevel,s.queryid::text AS queryid,s.query,
           s.plans,s.calls,s.total_plan_time,s.total_exec_time,s.rows,
           s.shared_blks_hit,s.shared_blks_read,s.stats_since
    FROM pg_stat_statements s,target t
    WHERE s.dbid=t.dbid AND s.userid=t.userid AND s.toplevel
      AND s.query='SELECT id,name,category,price,quantity,active,tags,rating_score,rating_count FROM items WHERE price BETWEEN $1 AND $2 LIMIT $3'
)
SELECT json_build_object(
    'schema','uwz_pgss_snapshot_v1',
    'monitor_database',current_database(),
    'target',(SELECT row_to_json(t) FROM target t),
    'info',(SELECT row_to_json(i) FROM pg_stat_statements_info i),
    'statements',COALESCE((SELECT json_agg(s) FROM selected s),'[]'::json));
