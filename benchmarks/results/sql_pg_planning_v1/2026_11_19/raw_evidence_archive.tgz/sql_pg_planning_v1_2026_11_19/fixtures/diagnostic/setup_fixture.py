#!/usr/bin/env python3
"""Create only the labeled local PostgreSQL performance fixture."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import socket
import subprocess
import time


WORK = Path(__file__).resolve().parent
PRIVATE = WORK / "private"
PUBLIC = WORK / "fixture"
IMAGE = (WORK / "archived_fixture/image.txt").read_text().strip()
LABEL = "sql-pg-planning-20261119"


def require(condition, message):
    if not condition:
        raise SystemExit(message)


def write_private(name, text):
    fd = os.open(PRIVATE / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as stream:
        stream.write(text)


def sql(container, text):
    return subprocess.check_output(
        ["docker", "exec", container, "psql", "-X", "-U", "bench", "-d",
         "benchmark", "-A", "-t", "-vON_ERROR_STOP=1", "-c", text], text=True)


def main():
    require(re.fullmatch(r"postgres@sha256:[0-9a-f]{64}", IMAGE), "image pin differs")
    subprocess.run(["docker", "image", "inspect", IMAGE], check=True,
                   stdout=subprocess.DEVNULL)
    PRIVATE.mkdir(mode=0o700, exist_ok=False)
    PUBLIC.mkdir(exist_ok=False)
    password = secrets.token_hex(24)
    owner_token = secrets.token_hex(16)
    write_private("owner_token", owner_token + "\n")
    write_private("postgres.env", "POSTGRES_USER=bench\nPOSTGRES_DB=benchmark\n"
                  "POSTGRES_PASSWORD=" + password + "\n")
    command = ["docker", "run", "--detach", "--pull=never", "--label",
               "uwz.sql-experiment=" + LABEL, "--label", "uwz.role=database",
               "--label", "uwz.run-token=" + owner_token,
               "--env-file", str(PRIVATE / "postgres.env"), "--publish",
               "127.0.0.1::5432", "--tmpfs", "/var/lib/postgresql", IMAGE,
               "-c", "max_connections=272",
               "-c", "shared_preload_libraries=pg_stat_statements",
               "-c", "compute_query_id=on",
               "-c", "pg_stat_statements.track=top",
               "-c", "pg_stat_statements.track_planning=on",
               "-c", "pg_stat_statements.track_utility=off",
               "-c", "pg_stat_statements.save=off"]
    container = subprocess.check_output(command, text=True).strip()
    require(re.fullmatch(r"[0-9a-f]{64}", container), "container identity differs")
    write_private("container.id", container + "\n")
    for _ in range(60):
        ready = subprocess.run(
            ["docker", "exec", container, "pg_isready", "-h127.0.0.1", "-Ubench",
             "-dbenchmark"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if ready.returncode == 0:
            break
        time.sleep(0.5)
    else:
        raise SystemExit("database readiness failed; owned fixture retained for cleanup")
    seed = WORK / "archived_fixture/pgdb-seed.sql"
    with seed.open("rb") as source, (PUBLIC / "seed.log").open("wb") as log:
        subprocess.run(["docker", "exec", "-i", container, "psql", "-X", "-Ubench",
                        "-dbenchmark", "-vON_ERROR_STOP=1"], stdin=source,
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    mapping = subprocess.check_output(["docker", "port", container, "5432/tcp"],
                                      text=True).strip()
    require(re.fullmatch(r"127\.0\.0\.1:[0-9]+", mapping), "port mapping differs")
    pg_port = int(mapping.rsplit(":", 1)[1])
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        http_port = listener.getsockname()[1]
    write_private("app.env", "DATABASE_URL=postgres://bench:" + password +
                  "@127.0.0.1:" + str(pg_port) + "/benchmark\nDATABASE_MAX_CONN=256\n"
                  "UWZ_HTTP_PORT=" + str(http_port) + "\n")
    require(sql(container, "SELECT count(*) FROM public.items;").strip() == "100000",
            "seed row count differs")
    (PUBLIC / "version.txt").write_text(sql(container, "SELECT version();"))
    (PUBLIC / "schema.txt").write_text(sql(container, "SELECT column_name,data_type "
        "FROM information_schema.columns WHERE table_schema='public' AND "
        "table_name='items' ORDER BY ordinal_position;"))
    (PUBLIC / "indexes.txt").write_text(sql(container, "SELECT indexname,indexdef "
        "FROM pg_indexes WHERE schemaname='public' AND tablename='items';"))
    (PUBLIC / "settings.txt").write_text(sql(container, "SELECT name,setting,unit "
        "FROM pg_settings WHERE name IN ('max_connections','shared_buffers',"
        "'fsync','synchronous_commit','jit','track_counts','track_io_timing',"
        "'plan_cache_mode','default_statistics_target','log_statement') ORDER BY name;"))
    shape = "json_build_object('id',id,'name',name,'category',category,'price',price," \
        "'quantity',quantity,'active',active,'tags',tags,'rating'," \
        "json_build_object('score',rating_score,'count',rating_count))"
    expected = PUBLIC / "expected_items.jsonl"
    expected.write_text(sql(container, "SELECT " + shape +
                            " FROM public.items WHERE price BETWEEN 10 AND 50;"))
    query = "SELECT id,name,category,price,quantity,active,tags,rating_score," \
        "rating_count FROM items WHERE price BETWEEN $1 AND $2 LIMIT $3"
    for limit in (5, 10, 20, 35, 50):
        plan = sql(container, "PREPARE arena_range(int,int,int) AS " + query +
                   "; EXPLAIN (ANALYZE, BUFFERS, TIMING OFF, FORMAT JSON) "
                   "EXECUTE arena_range(10,50," + str(limit) + ");")
        (PUBLIC / ("offload_explain_" + str(limit) + ".txt")).write_text(plan)
    record = {"created_utc": datetime.now(timezone.utc).isoformat(), "image": IMAGE,
              "container": container, "label": LABEL, "owner_token": owner_token,
              "pg_host_port": pg_port,
              "http_port": http_port, "pg_user": "bench", "pg_database": "benchmark",
              "seed_sha256": hashlib.sha256(seed.read_bytes()).hexdigest(),
              "seed_rows": 100000, "expected_items_path": str(expected),
              "expected_rows": len(expected.read_text().splitlines()),
              "postgres_tls": "disabled; explicit local loopback profile",
              "query_latency_scope": "off-load EXPLAIN only; no under-load SQL latency",
              "host_policy": "shared development host; no official or quiet-host claim",
              "runtime_resource_policy": "official memlock/nofile/seccomp settings",
              "private_inputs_recorded": False, "docker_command": command}
    (WORK / "fixture.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({key: record[key] for key in
                      ("image", "pg_host_port", "http_port", "seed_rows", "expected_rows")}))


if __name__ == "__main__":
    main()
