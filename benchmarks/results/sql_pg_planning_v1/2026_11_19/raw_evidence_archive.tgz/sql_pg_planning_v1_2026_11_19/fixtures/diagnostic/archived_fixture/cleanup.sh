#!/usr/bin/env sh
set -eu
fixture_directory=$(cat /tmp/uwz_arena_validation_path)
fixture_container=$(cat "$fixture_directory/container.id")
fixture_owner=$(docker inspect --format '{{ index .Config.Labels "uwz.agent" }}' "$fixture_container")
[ "$fixture_owner" = arena_adapter ]
docker rm --force "$fixture_container" >/dev/null
rm -f "$fixture_directory/postgres.env" "$fixture_directory/"*.private.env
