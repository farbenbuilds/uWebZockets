#!/usr/bin/env sh
set -eu
fixture_source=$(CDPATH='' cd "$(dirname "$0")" && pwd)
fixture_directory=$(mktemp -d "${TMPDIR:-/tmp}/uwz_arena_validation.XXXXXXXX")
umask 077
printf 'POSTGRES_PASSWORD=' > "$fixture_directory/postgres.env"
openssl rand -hex 24 >> "$fixture_directory/postgres.env"
printf '%s\n' POSTGRES_USER=bench POSTGRES_DB=benchmark >> "$fixture_directory/postgres.env"
fixture_image=$(cat "$fixture_source/image.txt")
fixture_container=$(docker run --detach --rm --label uwz.agent=arena_adapter --label uwz.purpose=v230-httparena --env-file "$fixture_directory/postgres.env" --publish 127.0.0.1::5432 --tmpfs /var/lib/postgresql "$fixture_image" -c max_connections=272)
printf '%s\n' "$fixture_container" > "$fixture_directory/container.id"
printf '%s\n' "$fixture_image" > "$fixture_directory/image.txt"
fixture_attempt=0
until docker exec "$fixture_container" pg_isready -h127.0.0.1 -Ubench -dbenchmark >/dev/null 2>&1; do
    fixture_attempt=$((fixture_attempt + 1))
    [ "$fixture_attempt" -lt 30 ] || exit 1
    sleep 1
done
docker exec -i "$fixture_container" psql -Ubench -dbenchmark -vON_ERROR_STOP=1 < "$fixture_source/pgdb-seed.sql" > "$fixture_directory/seed.log"
docker port "$fixture_container" 5432/tcp > "$fixture_directory/port.txt"
mkdir -p "$fixture_directory/final/runtime"
cp "$fixture_source/dataset.json" "$fixture_directory/final/"
cp /usr/lib/x86_64-linux-gnu/libc.so.6 /usr/lib/x86_64-linux-gnu/libm.so.6 /usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2 "$fixture_directory/final/runtime/"
printf '%s\n' "$fixture_directory" > /tmp/uwz_arena_validation_path
printf 'fixture_directory=%s\n' "$fixture_directory"
