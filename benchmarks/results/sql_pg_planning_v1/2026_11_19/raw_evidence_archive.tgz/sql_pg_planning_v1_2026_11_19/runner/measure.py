import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import http.client
import json
import os
from pathlib import Path
import platform
import re
import resource
import secrets
import shutil
import signal
import socket
import statistics
import subprocess
import time


LIMITS = (5, 10, 20, 35, 50)
WORKERS, CONNECTIONS, THREADS = 32, 1024, 8
MODES = ("normal", "diagnostic")
ORDER = (("normal", "diagnostic"), ("diagnostic", "normal"), ("normal", "diagnostic"))
RUN_LABELS = {
    "uwz.sql-experiment": "sql-pg-planning-20261119",
    "uwz.role": "application",
    "uwz.measurement": "sql-pg-planning-20261119",
}
COUNTERS = re.compile(r"benchmark database rendered_queries=(\d+) empty_fallbacks=(\d+) rejected_responses=(\d+)")
STATS_SQL = """
SELECT json_build_object(
  'seq_scan', seq_scan, 'idx_scan', idx_scan, 'seq_tup_read', seq_tup_read,
  'tcp_clients', (SELECT count(*) FROM pg_stat_activity
    WHERE backend_type = 'client backend' AND datname = current_database() AND client_addr IS NOT NULL),
  'active_clients', (SELECT count(*) FROM pg_stat_activity
    WHERE backend_type = 'client backend' AND datname = current_database() AND client_addr IS NOT NULL AND state = 'active'),
  'ssl_clients', (SELECT count(*) FROM pg_stat_activity a JOIN pg_stat_ssl s USING (pid)
    WHERE a.backend_type = 'client backend' AND a.datname = current_database() AND a.client_addr IS NOT NULL AND s.ssl),
  'reset_at', (SELECT stats_reset FROM pg_stat_database WHERE datname = current_database()))
FROM pg_stat_user_tables WHERE schemaname = 'public' AND relname = 'items';
"""


def now():
    return datetime.now(timezone.utc).isoformat()


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def terminate_group(command):
    try:
        os.killpg(command.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass  # The whole subprocess group has already exited.
    return command.communicate()


def run(directory, label, argv, timeout=60, check=True, stdin_file=None):
    started = now()
    interrupted = False
    input_data = stdin_file.read_bytes() if stdin_file else None
    before_ns = time.monotonic_ns()
    with subprocess.Popen(argv, stdin=subprocess.PIPE if input_data is not None else None,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True) as command:
        try:
            stdout, stderr = command.communicate(input=input_data, timeout=timeout)
            code = command.returncode
        except subprocess.TimeoutExpired:
            stdout, stderr = terminate_group(command)
            code = "timeout"
        except KeyboardInterrupt:
            stdout, stderr = terminate_group(command)
            code, interrupted = "interrupted", True
    after_ns = time.monotonic_ns()
    (directory / f"{label}.stdout").write_bytes(stdout)
    (directory / f"{label}.stderr").write_bytes(stderr)
    record = {
        "argv": [str(arg) for arg in argv], "started_at": started,
        "finished_at": now(), "exit_code": code,
        "monotonic_before_spawn_ns": before_ns, "monotonic_after_reap_ns": after_ns,
    }
    if input_data is not None:
        record.update({"stdin_file": str(stdin_file), "stdin_sha256": hashlib.sha256(input_data).hexdigest()})
    save_json(directory / f"{label}.command.json", record)
    if interrupted:
        raise KeyboardInterrupt
    if check and code != 0:
        raise RuntimeError(f"{label} exit={code}. See {directory}.")
    return stdout.decode(errors="replace")


def snapshot_stats(args, directory, label):
    result = run(directory, label, [
        "docker", "exec", "--user", "postgres", args.db_container, "psql", "-X", "-w", "-At",
        "-h", "/var/run/postgresql", "-U", args.db_user, "-d", args.db_name,
        "-v", "ON_ERROR_STOP=1", "-c", STATS_SQL,
    ])
    return json.loads(result)


def snapshot_phase(args, directory, label):
    snapshot = {"table": snapshot_stats(args, directory, label)}
    if args.mode == "diagnostic":
        result = run(directory, f"{label}_pgss", [
            "docker", "exec", "-i", "--user", "postgres", args.db_container, "psql", "-X", "-w", "-At",
            "-h", "/var/run/postgresql", "-U", args.db_user, "-d", "postgres",
            "-v", "ON_ERROR_STOP=1",
        ], stdin_file=args.pgss_sql)
        pgss = json.loads(result)
        if pgss["schema"] != "uwz_pgss_snapshot_v1" or pgss["monitor_database"] != "postgres" or len(pgss["statements"]) > 1:
            raise ValueError("PGSS probe did not identify a unique eligible statement")
        snapshot["pgss"] = pgss
    return snapshot


def settled_stats(args, directory, label, clients=0, baseline=None, floor=0):
    previous = None
    for index in range(20):
        current = snapshot_phase(args, directory, f"{label}_{index:02}")
        table = current["table"]
        scans = table["seq_scan"] - baseline["table"]["seq_scan"] if baseline else 0
        if (current == previous and table["tcp_clients"] == clients and table["active_clients"] == 0
                and scans >= floor and (baseline is None or equal_pgss_calls(baseline, current, scans))):
            return current
        previous = current
        time.sleep(1)
    raise RuntimeError(f"PostgreSQL statistics or TCP connections did not settle at {label}")


def equal_pgss_calls(before, after, scans):
    if "pgss" not in before:
        return "pgss" not in after
    start, end = (snapshot["pgss"] for snapshot in (before, after))
    if start["info"] != end["info"] or start["target"] != end["target"]:
        return False
    entries = [snapshot["statements"][0] if snapshot["statements"] else None for snapshot in (start, end)]
    if entries[0] and (entries[1] is None or any(entries[0][key] != entries[1][key]
                                               for key in ("queryid", "stats_since", "query", "userid", "dbid", "toplevel"))):
        return False
    initial, final = (entry["calls"] if entry else 0 for entry in entries)
    return final - initial == scans


def validate_phases(snapshots, warmup_calls, timed_calls, connections):
    names = ("before", "pre_warmup", "post_warmup", "pre_timed", "post_timed", "after")
    if not all(name in snapshots for name in names):
        return False
    for left, right, calls in zip(names, names[1:], (0, warmup_calls, 0, timed_calls, 0)):
        first, last = snapshots[left]["table"], snapshots[right]["table"]
        scans = last["seq_scan"] - first["seq_scan"]
        if (first["reset_at"] != last["reset_at"] or (first["idx_scan"] or 0) != (last["idx_scan"] or 0)
                or not calls <= scans <= calls + (connections if calls else 0)
                or not equal_pgss_calls(snapshots[left], snapshots[right], scans)):
            return False
    return True


def process_state(pid):
    proc = Path(f"/proc/{pid}")
    data = {"pid": pid}
    try:
        data["proc_stat"] = (proc / "stat").read_text().strip()
        data["rss"] = {key: val.strip() for key, val in (
            line.split(":", 1) for line in (proc / "status").read_text().splitlines()
        ) if key in ("VmRSS", "VmHWM", "RssAnon", "RssFile", "RssShmem", "Threads")}
        data["cgroup"] = (proc / "cgroup").read_text()
        cgroup_path = next(line[3:] for line in data["cgroup"].splitlines() if line.startswith("0::"))
        cgroup = Path("/sys/fs/cgroup") / cgroup_path.lstrip("/")
        for filename in ("cpu.stat", "cpu.max", "memory.current", "memory.peak", "memory.stat", "memory.max"):
            path = cgroup / filename
            if path.exists():
                data[filename] = path.read_text().strip()
    except (OSError, StopIteration) as error:
        data["unavailable"] = str(error)
    return data


def resource_snapshot(args, directory, label, app_pid):
    resource_data = {
        "at": now(), "monotonic_start_ns": time.monotonic_ns(),
        "application": process_state(app_pid), "postgres": process_state(args.db_pid),
        "inactive_postgres": process_state(args.inactive_db_pid),
        "monotonic_end_ns": time.monotonic_ns(),
    }
    save_json(directory / f"{label}.resources.json", resource_data)
    return resource_data


def cpu_delta(before, after):
    result = {}
    for role in ("application", "postgres"):
        if "cpu.stat" not in before[role] or "cpu.stat" not in after[role]:
            result[role] = {"unavailable": "Missing cgroup cpu.stat. See raw resource snapshots."}
            continue
        first, second = (dict(line.split() for line in snapshot[role]["cpu.stat"].splitlines())
                         for snapshot in (before, after))
        result[role] = {key: int(second[key]) - int(first[key]) for key in ("usage_usec", "user_usec", "system_usec")}
    return result


def read_pid(directory, label, container):
    return int(run(directory, label, ["docker", "inspect", "--format", "{{.State.Pid}}", container]))


def clock_namespace(raw):
    inode, child_inode, monotonic, boottime, boot_hash = raw.splitlines()
    if not re.fullmatch(r"time:\[\d+\]", inode) or inode != child_inode or not re.fullmatch(r"[0-9a-f]{64}", boot_hash):
        raise ValueError("Malformed kernel or Linux time namespace identity")
    offsets = {}
    for expected, line in (("monotonic", monotonic), ("boottime", boottime)):
        clock, seconds, nanos = line.split()
        if clock != expected or not 0 <= int(nanos) < 1_000_000_000:
            raise ValueError("Malformed Linux time namespace offset")
        offsets[clock] = int(seconds) * 1_000_000_000 + int(nanos)
    return {"inode": inode, "child_inode": child_inode, "offsets_ns": offsets, "kernel_boot_sha256": boot_hash}


def same_clock(left, right):
    # The offset is relative to the initial time namespace of this kernel.
    return (left["kernel_boot_sha256"] == right["kernel_boot_sha256"]
            and left["offsets_ns"] == right["offsets_ns"] == {"monotonic": 0, "boottime": 0})


def host_clock_binding(pid, container):
    proc = Path(f"/proc/{pid}")
    cgroup = (proc / "cgroup").read_text()
    matching_paths = [line[3:] for line in cgroup.splitlines() if line.startswith("0::")]
    if len(matching_paths) != 1 or Path(matching_paths[0]).name not in (container, f"docker-{container}.scope"):
        raise ValueError("Docker immutable application ID does not match the host PID cgroup")
    binding = {"pid": pid, "cgroup": cgroup}
    try:
        binding["time_inode"] = os.readlink(proc / "ns/time")
    except PermissionError as error:
        binding["unavailable_time_inode_errno"] = error.errno
    return binding


def ready(args, directory, name, workers):
    expected = workers * 8
    for index in range(45):
        details = snapshot_stats(args, directory, f"ready_sql_{index:02}")
        if details["tcp_clients"] == expected and details["ssl_clients"] == 0:
            try:
                with socket.create_connection(("127.0.0.1", args.port), timeout=0.5):
                    return details
            except OSError:
                pass  # TCP is a readiness check with no HTTP completion.
        state = run(directory, f"ready_app_{index:02}", ["docker", "inspect", "--format", "{{.State.Status}}", name])
        if state.strip() != "running":
            raise RuntimeError(f"Application startup ended in container state {state.strip()}")
        time.sleep(1)
    raise RuntimeError(f"Application did not listen with exactly {expected} plaintext PostgreSQL sockets")


def get_item_rows(path):
    items = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    rows = {item["id"]: item for item in items}
    if len(rows) != len(items) or not rows:
        raise ValueError("Expected a nonempty raw PostgreSQL export with unique IDs")
    return rows


def request_path(limit):
    return f"/async-db?min=10&max=50&limit={limit}"


def fixed_response(port, limit):
    path = request_path(limit)
    request = {"method": "GET", "version": "HTTP/1.1", "path": path, "limit": limit,
               "headers": {"Host": f"127.0.0.1:{port}", "Accept-Encoding": "identity", "Connection": "close"}}
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    try:
        conn.request(request["method"], path, headers=request["headers"])
        response = conn.getresponse()
        body = response.read()
        return {"request": request, "status": response.status, "reason": response.reason,
                "version": response.version, "headers": response.getheaders(),
                "body_utf8": body.decode("utf-8")}
    except (OSError, http.client.HTTPException, UnicodeDecodeError) as error:
        return {"request": request, "error": str(error)}
    finally:
        conn.close()


def check_response(response, rows):
    if response.get("status") != 200 or response.get("version") != 11:
        raise ValueError(f"Invalid HTTP response status/version: {response.get('status')}, {response.get('version')}")
    headers = {name.lower(): value for name, value in response["headers"]}
    if headers.get("content-type") != "application/json":
        raise ValueError("Expected application/json")
    limit = response["request"]["limit"]
    payload = json.loads(response["body_utf8"])
    if set(payload) != {"items", "count"} or type(payload["count"]) is not int or payload["count"] != limit:
        raise ValueError("Expected exact requested count")
    items = payload["items"]
    if type(items) is not list or len(items) != limit or len({item["id"] for item in items}) != limit:
        raise ValueError("Expected exact number of unique items")
    for item in items:
        expected = rows[item["id"]]
        if json.dumps(item, sort_keys=True) != json.dumps(expected, sort_keys=True) or not 10 <= item["price"] <= 50:
            raise ValueError(f"Wrong item fields or price for ID {item['id']}")


def fixed_load(args, directory, connections):
    limits = LIMITS * 10
    with ThreadPoolExecutor(max_workers=min(connections, len(limits))) as executor:
        responses = list(executor.map(lambda limit: fixed_response(args.port, limit), limits))
    save_json(directory / "fixed_responses.json", responses)
    errors = []
    for index, response in enumerate(responses):
        try:
            check_response(response, args.rows)
        except (ValueError, KeyError, TypeError) as error:
            errors.append({"request_index": index, "error": str(error)})
    return {"issued": len(limits), "completed": sum("status" in response for response in responses),
            "validated": len(responses) - len(errors), "errors": errors}


def wrk_load(args, directory, label, seconds, connections, threads, app_pid):
    before = resource_snapshot(args, directory, f"{label}_before", app_pid)
    result = run(directory, label, [
        "env", "LC_ALL=C", "/usr/bin/time", "-v", "-o", directory / f"{label}.client_time.txt", args.wrk,
        "-t", str(threads), "-c", str(connections), "-d", f"{seconds}s", "--timeout", "2s", "--latency",
        "-s", Path(__file__).with_name("async_db.lua").resolve(), f"http://127.0.0.1:{args.port}",
    ], check=False)
    after = resource_snapshot(args, directory, f"{label}_after", app_pid)
    stats_line = next((line for line in result.splitlines() if line.startswith("UWZ_WRK ")), "")
    stats = {key: int(value) for key, value in re.findall(r"(\w+)=(\d+)", stats_line)}
    metadata = json.loads((directory / f"{label}.command.json").read_text())
    if not stats or stats["duration_us"] <= 0:
        return {"exit_code": metadata["exit_code"], "error": "Missing complete wrk metrics"}
    stats["rps"] = stats["completed"] * 1e6 / stats["duration_us"]
    stats["exit_code"] = metadata["exit_code"]
    stats["client_generated_per_thread"] = [
        {key: int(value) for key, value in re.findall(r"(\w+)=(\d+)", line)}
        for line in result.splitlines() if line.startswith("UWZ_WRK_GENERATED ")
    ]
    stats["cpu_delta"] = cpu_delta(before, after)
    return stats


def valid_load(sample, seconds):
    return (sample.get("exit_code") == 0 and sample.get("completed", 0) > 0
            and sample.get("duration_us", 0) >= seconds * 1_000_000
            and all(sample.get(key) == 0 for key in ("status", "connect", "read", "write", "timeout")))


def find_owned_container(directory, labels):
    filters = [arg for key, value in labels.items() for arg in ("--filter", f"label={key}={value}")]
    for index in range(3):
        matches = run(directory, f"app_lookup_{index:02}", [
            "docker", "ps", "--all", "--quiet", "--no-trunc", *filters,
        ]).splitlines()
        if not matches:
            time.sleep(1)
            continue
        if len(matches) != 1 or not re.fullmatch(r"[0-9a-f]{64}", matches[0]):
            raise RuntimeError("Unexpected owned Docker container lookup result")
        return matches[0]
    return None


def collect_stop(directory, container, labels):
    actual_labels = json.loads(run(directory, "app_verify_ownership", [
        "docker", "inspect", "--format", "{{json .Config.Labels}}", container,
    ]))
    if not isinstance(actual_labels, dict) or any(actual_labels.get(key) != value for key, value in labels.items()):
        raise RuntimeError(f"Ownership labels do not match immutable container ID {container}")
    run(directory, "app_stop", ["docker", "stop", "--time", "30", container], check=False)
    logs = run(directory, "app_logs", ["docker", "logs", "--timestamps", container], check=False)
    logs += (directory / "app_logs.stderr").read_text()
    state = run(directory, "app_final_state", ["docker", "inspect", "--format", "{{json .State}}", container], check=False)
    run(directory, "app_remove", ["docker", "rm", "--force", container], check=False)
    for operation in ("app_logs", "app_final_state", "app_remove"):
        if json.loads((directory / f"{operation}.command.json").read_text())["exit_code"] != 0:
            raise RuntimeError(f"Failed to capture or clean owned application. See {directory}.")
    counts = [tuple(int(value) for value in match) for match in COUNTERS.findall(logs)]
    return counts, json.loads(state)


def measure(args, directory, mode, fixed):
    workers, connections, threads = WORKERS, CONNECTIONS, THREADS
    directory.mkdir()
    label = directory.name
    print(f"Starting {label}", flush=True)
    before = settled_stats(args, directory, "pg_before")
    owner = secrets.token_hex(16)
    name = f"uwz-async-db-{label}-{owner[:8]}"
    labels = RUN_LABELS | {"uwz.run-owner": owner}
    save_json(directory / "app_ownership.json", {"name": name, "labels": labels})
    label_options = [arg for key, value in labels.items() for arg in ("--label", f"{key}={value}")]
    config = ["--env", "DATABASE_MAX_CONN=256", "--env", f"UWZ_HTTP_PORT={args.port}"]
    argv = ["docker", "run", "--detach", "--name", name, "--pull=never", "--network", "host",
            *label_options,
            "--security-opt", "seccomp=unconfined", "--ulimit", "memlock=-1:-1", "--ulimit", "nofile=524288:524288",
            "--stop-signal", "SIGTERM", "--env-file", args.app_env, *config,
            "--mount", f"type=bind,source={args.binary},target=/server,readonly", "--entrypoint", "/server", args.image]
    snapshots = {"before": before}
    work = {"mode": mode, "workers": workers, "connections": connections, "threads": threads, "pg_snapshots": snapshots}
    container = None
    try:
        started_container = run(directory, "app_run", argv).strip()
        if not re.fullmatch(r"[0-9a-f]{64}", started_container):
            raise RuntimeError("Docker run did not return an immutable container ID")
        container = started_container
        work["ready"] = ready(args, directory, container, workers)
        app_pid = read_pid(directory, "app_pid", container)
        namespace = run(directory, "app_clock_namespace", [
            "docker", "exec", container, "sh", "-ec",
            "readlink /proc/1/ns/time\nreadlink /proc/1/ns/time_for_children\ncat /proc/1/timens_offsets\n"
            "sha256sum /proc/sys/kernel/random/boot_id | cut -d ' ' -f 1",
        ])
        work["clock_namespace"] = clock_namespace(namespace)
        host_app = host_clock_binding(app_pid, container)
        save_json(directory / "app_host_clock_namespace.json", host_app)
        if "time_inode" in host_app and host_app["time_inode"] != work["clock_namespace"]["inode"]:
            raise RuntimeError("Docker host PID and application PID 1 time namespaces disagree")
        if not same_clock(work["clock_namespace"], args.clock_namespace):
            raise RuntimeError("Application and client clocks have different Linux kernels or CLOCK_MONOTONIC offsets")
        limits_and_fds = run(directory, "application_limits_and_fds", [
            "docker", "exec", container, "sh", "-ec", "cat /proc/1/limits\nls -l /proc/1/fd",
        ])
        work["io_uring_fds"] = limits_and_fds.count("anon_inode:[io_uring]")
        if fixed:
            work["fixed"] = fixed_load(args, directory, connections)
        else:
            clients = workers * 8
            snapshots["pre_warmup"] = settled_stats(args, directory, "pg_pre_warmup", clients, before)
            work["warmup"] = wrk_load(args, directory, "warmup", 5, connections, threads, app_pid)
            if not valid_load(work["warmup"], 5):
                raise ValueError("Invalid warmup HTTP load")
            warmup_calls = work["warmup"]["completed"]
            snapshots["post_warmup"] = settled_stats(args, directory, "pg_post_warmup", clients, before, warmup_calls)
            snapshots["pre_timed"] = snapshot_phase(args, directory, "pg_pre_timed")
            if snapshots["pre_timed"] != snapshots["post_warmup"]:
                raise ValueError("PostgreSQL counters changed after the quiescent warmup boundary")
            work["timed"] = wrk_load(args, directory, "timed", 10, connections, threads, app_pid)
            if not valid_load(work["timed"], 10):
                raise ValueError("Invalid timed HTTP load")
            completed = warmup_calls + work["timed"]["completed"]
            snapshots["post_timed"] = settled_stats(args, directory, "pg_post_timed", clients, before, completed)
    except (OSError, ValueError, RuntimeError) as error:
        work["runtime_error"] = str(error)
    finally:
        container = container or find_owned_container(directory, labels)
        counts, state = collect_stop(directory, container, labels) if container else ([], {"ExitCode": None, "OOMKilled": None})
    try:
        after = settled_stats(args, directory, "pg_after", baseline=before)
    except (OSError, ValueError, RuntimeError) as error:
        work.update({"runtime_error": str(error), "valid": False, "app_counters": counts, "app_state": state})
        save_json(directory / "summary.json", work)
        print(f"Finished {label} valid=False: {error}", flush=True)
        return work
    snapshots["after"] = after
    initial_table, final_table = before["table"], after["table"]
    rendered, empty, rejected = (sum(tup[index] for tup in counts) for index in range(3))
    scans = final_table["seq_scan"] - initial_table["seq_scan"]
    index_scans = (final_table["idx_scan"] or 0) - (initial_table["idx_scan"] or 0)
    common_valid = ("runtime_error" not in work and state["ExitCode"] == 0 and not state["OOMKilled"]
                    and len(counts) == workers and work.get("io_uring_fds") == workers
                    and empty == 0 and rejected == 0 and initial_table["reset_at"] == final_table["reset_at"]
                    and index_scans == 0 and final_table["tcp_clients"] == 0)
    work.update({"app_counters": counts, "app_state": state,
                 "rendered_queries": rendered, "empty_fallbacks": empty, "rejected_responses": rejected,
                 "seq_scan_delta": scans, "idx_scan_delta": index_scans,
                 "seq_tup_read_delta": final_table["seq_tup_read"] - initial_table["seq_tup_read"]})
    if fixed:
        fixed_result = work.get("fixed", {})
        completed = fixed_result.get("completed", 0)
        work["valid"] = common_valid and completed == fixed_result.get("validated") == fixed_result.get("issued") == rendered == scans
    else:
        samples = [work.get("warmup", {}), work.get("timed", {})]
        completed = sum(sample.get("completed", 0) for sample in samples)
        allowance = 2 * connections
        sample_valid = all(valid_load(sample, seconds) for sample, seconds in zip(samples, (5, 10)))
        work["deadline_allowance"] = allowance
        work["valid"] = (common_valid and sample_valid and completed <= rendered == scans <= completed + allowance
                         and validate_phases(snapshots, samples[0]["completed"], samples[1]["completed"], connections))
    work["completed"] = completed
    work["rendered_minus_completed"] = rendered - completed
    work["scan_minus_rendered"] = scans - rendered
    save_json(directory / "summary.json", work)
    print(f"Finished {label} valid={work['valid']} completed={completed} rendered={rendered} scans={scans}", flush=True)
    return work


def hash_file(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()


def bind_fixture(args):
    fixture = json.loads(args.fixture.read_text())
    args.db_container, args.image = fixture["container"], fixture["image"]
    args.db_user, args.db_name = fixture["pg_user"], fixture["pg_database"]
    args.port = fixture["http_port"]
    args.items = Path(fixture["expected_items_path"]).resolve(strict=True)
    args.rows = get_item_rows(args.items)
    if len(args.rows) != fixture["expected_rows"]:
        raise ValueError("PostgreSQL comparison export row count differs from fixture metadata")
    fields = "\n".join((
        "{{json .Id}}", "{{json .Image}}", "{{json .Config.Image}}", "{{json .State.Pid}}",
        '{{json (index .NetworkSettings.Ports "5432/tcp")}}',
        "{{json .Config.Labels}}",
    ))
    evidence = args.output / f"{args.mode}_database"
    evidence.mkdir()
    captured = run(evidence, "db_identity", ["docker", "inspect", "--format", fields, args.db_container])
    container, image_id, image, args.db_pid, bindings, labels = map(json.loads, captured.splitlines())
    required_image_id = run(evidence, "db_expected_image_id", [
        "docker", "image", "inspect", "--format", "{{.Id}}", args.image,
    ]).strip()
    if (container != args.db_container or image != args.image or image_id != required_image_id or args.db_pid <= 0
            or bindings != [{"HostIp": "127.0.0.1", "HostPort": str(fixture["pg_host_port"])}]):
        raise ValueError("Live PostgreSQL fixture identity, image, or loopback binding differs from the recorded fixture")
    expected_labels = {"uwz.sql-experiment": fixture["label"], "uwz.role": "database", "uwz.run-token": fixture["owner_token"]}
    if not isinstance(labels, dict) or any(labels.get(key) != value for key, value in expected_labels.items()):
        raise ValueError("Live PostgreSQL fixture ownership labels differ from the recorded fixture")
    return fixture


def summarize(fixed, samples, workers, connections, threads):
    valid = fixed["valid"] and len(samples) == len(ORDER) and all(sample["valid"] for sample in samples)
    report = {"workers": workers, "connections": connections, "threads": threads,
              "fixed": fixed, "samples": samples, "valid": valid, "threshold_rps": 300000}
    metrics = ("rps", "p50_us", "p90_us", "p95_us", "p99_us")
    if len(samples) == len(ORDER) and all(all(metric in sample.get("timed", {}) for metric in metrics) for sample in samples):
        report["sample_medians"] = {metric: statistics.median(sample["timed"][metric] for sample in samples) for metric in metrics}
    report["throughput_gate_met"] = valid and workers == 32 and report.get("sample_medians", {}).get("rps", 0) > 300000
    return report


def main():
    parser = argparse.ArgumentParser(description="Local reconstruction of the HttpArena async-db profile on a shared host")
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--wrk", type=Path, required=True)
    for mode in MODES:
        parser.add_argument(f"--{mode}-fixture", type=Path, required=True)
        parser.add_argument(f"--{mode}-app-env", type=Path, required=True)
    parser.add_argument("--pgss-sql", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    for key in ("binary", "wrk", "pgss_sql", "normal_fixture", "normal_app_env", "diagnostic_fixture", "diagnostic_app_env"):
        setattr(args, key, getattr(args, key).resolve(strict=True))
    args.output = args.output.resolve()
    args.output.mkdir()
    clock = time.get_clock_info("monotonic")
    if clock.implementation != "clock_gettime(CLOCK_MONOTONIC)" or not clock.monotonic or clock.adjustable:
        raise RuntimeError("Python time.monotonic_ns is not Linux CLOCK_MONOTONIC")
    clock_raw = (os.readlink("/proc/self/ns/time") + "\n" + os.readlink("/proc/self/ns/time_for_children") + "\n"
                 + Path("/proc/self/timens_offsets").read_text() + hash_file(Path("/proc/sys/kernel/random/boot_id")) + "\n")
    args.clock_namespace = clock_namespace(clock_raw)
    (args.output / "host_clock_namespace.txt").write_text(clock_raw)
    lua = Path(__file__).with_name("async_db.lua").resolve()
    profiles, identities = {}, {}
    artifacts = [args.binary, args.wrk, args.pgss_sql, Path(__file__).resolve(), lua]
    for mode in MODES:
        config = argparse.Namespace(**vars(args), mode=mode,
                                    fixture=getattr(args, mode + "_fixture"), app_env=getattr(args, mode + "_app_env"))
        fixture = bind_fixture(config)
        profiles[mode] = config
        identities[mode] = {"db_image": config.image, "db_container": config.db_container, "db_seed_rows": fixture["seed_rows"],
                            "db_seed_sha256": fixture["seed_sha256"], "fixture_rows_exported": len(config.rows),
                            "http_port": config.port, "pg_host_port": fixture["pg_host_port"],
                            "fixture_path": str(config.fixture), "items_path": str(config.items)}
        artifacts.extend((config.fixture, config.items))
        save_json(args.output / f"{mode}_database" / "resources.json", process_state(config.db_pid))
    profiles["normal"].inactive_db_pid = profiles["diagnostic"].db_pid
    profiles["diagnostic"].inactive_db_pid = profiles["normal"].db_pid
    digests = {str(path): hash_file(path) for path in artifacts}
    if (len({profile.db_container for profile in profiles.values()}) != 2
            or len({profile.port for profile in profiles.values()}) != 2
            or len({profile.image for profile in profiles.values()}) != 1
            or len({digests[str(profile.items)] for profile in profiles.values()}) != 1
            or len({identity["db_seed_sha256"] for identity in identities.values()}) != 1):
        raise RuntimeError("Fixtures must be independent with identical seeded database exports and image")
    save_json(args.output / "metadata.json", {
        "profile": "Local reconstruction of HttpArena async-db on a shared host",
        "io": "HTTP/1.1 over loopback and plaintext PostgreSQL TCP from the production adapter",
        "parameters": {"min": 10, "max": 50, "rotating_limits": LIMITS, "pipeline_depth": 1},
        "start": now(), "linux": platform.release(), "arch": platform.machine(), "python": platform.python_version(),
        "client_cpu_affinity": sorted(os.sched_getaffinity(0)), "client_nofile": resource.getrlimit(resource.RLIMIT_NOFILE),
        "python_monotonic_clock": vars(clock), "clock_namespace": args.clock_namespace, "paired_run_order": ORDER,
        "proc_clock_ticks_per_second": os.sysconf("SC_CLK_TCK"),
        "cpu_window": "Application and PostgreSQL cgroup snapshots bracket each wrk subprocess. GNU time measures the client subprocess. CPU per request uses completed responses during the corresponding full wrk run.",
        "profiles": identities,
        "wrk_status_errors": "HTTP status greater than 399. The fixed-count cohort checks exact HTTP 200 and PostgreSQL fields.",
        "wrk_generated": "Request hook calls and shapes per Lua thread. Counts can include construction or deadline calls and do not prove completed response mix.",
        "rss_metrics": "Application and PostgreSQL postmaster RSS from /proc; container CPU and memory from their cgroups when available. Client peak RSS and CPU from GNU time.",
        "executable": {"path": str(args.binary), "sha256": digests[str(args.binary)]},
        "wrk": {"path": str(args.wrk), "sha256": digests[str(args.wrk)]},
        "lua": {"path": str(lua), "sha256": digests[str(lua)]},
        "pgss_sql": {"path": str(args.pgss_sql), "sha256": digests[str(args.pgss_sql)]},
        "sha256": digests,
    })
    run(args.output, "elf", [shutil.which("readelf") or "readelf", "-h", "-l", args.binary, args.wrk])
    run(args.output, "wrk_version", [args.wrk, "--version"], check=False)
    run(args.output, "docker_version", ["docker", "version", "--format", "{{.Server.Version}}"])
    fixed = {}
    for mode in MODES:
        fixed[mode] = measure(profiles[mode], args.output / f"{mode}_fixed", mode, fixed=True)
        if not fixed[mode]["valid"]:
            break
    samples = {mode: [] for mode in MODES}
    for pair, order in enumerate(ORDER, 1):
        if len(fixed) != len(MODES) or not all(run_info["valid"] for run_info in (*fixed.values(), *samples["normal"], *samples["diagnostic"])):
            break
        for mode in order:
            run_info = measure(profiles[mode], args.output / f"pair_{pair:02}_{mode}", mode, fixed=False)
            samples[mode].append(run_info)
            if not run_info["valid"]:
                break
    report = {mode: summarize(fixed[mode], samples[mode], WORKERS, CONNECTIONS, THREADS) for mode in fixed}
    save_json(args.output / "summary.json", report)
    inventory = run(args.output, "app_final_inventory", [
        "docker", "ps", "--all", "--quiet", "--no-trunc",
        *(arg for key, value in RUN_LABELS.items() for arg in ("--filter", f"label={key}={value}")),
    ])
    return 0 if not inventory and len(report) == len(MODES) and all(cohort["valid"] for cohort in report.values()) else 2


def interrupted(_signum, _frame):
    raise KeyboardInterrupt


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, interrupted)
    raise SystemExit(main())
