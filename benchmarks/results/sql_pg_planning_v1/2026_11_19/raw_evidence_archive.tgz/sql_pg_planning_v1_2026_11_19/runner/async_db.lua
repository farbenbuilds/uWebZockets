local limits = {5, 10, 20, 35, 50}
local requests = {}
local index = 0
local threads = {}

generated = 0

function setup(thread)
    threads[#threads + 1] = thread
end

function init()
    for i, limit in ipairs(limits) do
        requests[i] = wrk.format("GET", "/async-db?min=10&max=50&limit=" .. limit)
    end
end

function request()
    index = index % #requests + 1
    generated = generated + 1
    return requests[index]
end

function done(summary, latency, _)
    io.write(string.format(
        "UWZ_WRK completed=%d duration_us=%d status=%d connect=%d read=%d write=%d timeout=%d p50_us=%d p90_us=%d p95_us=%d p99_us=%d\n",
        summary.requests, summary.duration, summary.errors.status, summary.errors.connect,
        summary.errors.read, summary.errors.write, summary.errors.timeout,
        latency:percentile(50.0), latency:percentile(90.0),
        latency:percentile(95.0), latency:percentile(99.0)))
    for number, thread in ipairs(threads) do
        local count = thread:get("generated")
        local complete_cycles = math.floor(count / #limits)
        local extra = count % #limits
        io.write(string.format("UWZ_WRK_GENERATED thread=%d calls=%d", number, count))
        for i, limit in ipairs(limits) do
            local shape_count = complete_cycles + (i <= extra and 1 or 0)
            io.write(string.format(" limit_%d=%d", limit, shape_count))
        end
        io.write("\n")
    end
end
