import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re
import statistics


WORKERS, THREADS, CONNECTIONS = 32, 8, 1024
PERCENTILES = (50, 90, 95, 99)
LIMITS = (5, 10, 20, 35, 50)
MODES = ("normal", "diagnostic")
PAIR_ORDER = (("normal", "diagnostic"), ("diagnostic", "normal"), ("normal", "diagnostic"))
CONTROL_SHA = "836f823e81f6d8fd7242dfc5b3910ceb6d72930bc7a115c05aff01c79e09989b"
LUA_SHA = "2ca83b5f5a30fc9fe46bd8e9fba9e852dd3afd0809d586ba00edb0a237ad7750"
WRK_SHA = "f6536e3f9479584fa2b4a97d12c56671487be9f1011f309dc7a3b1bb0f6ea06c"
SEED_SHA = "f020c2c6851ea1c53cd1b90c94baadd5645b2fc3e4caed5b0daf71a61bff9e21"
QUERY = "SELECT id,name,category,price,quantity,active,tags,rating_score,rating_count FROM items WHERE price BETWEEN $1 AND $2 LIMIT $3"
PGSS_COUNTS = ("plans", "calls", "rows", "shared_blks_hit", "shared_blks_read")
PGSS_TIMES = ("total_plan_time", "total_exec_time")
PHASES = ("before", "pre_warmup", "post_warmup", "pre_timed", "post_timed", "after")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def unique_fields(entries):
    result = dict(entries)
    require(len(result) == len(entries), "Duplicate JSON field")
    return result


def recorded_clock(raw):
    inode, child_inode, monotonic, boottime, kernel = raw.splitlines()
    offsets = [line.split() for line in (monotonic, boottime)]
    require(re.fullmatch(r"time:\[\d+\]", inode) and re.fullmatch(r"[0-9a-f]{64}", kernel)
            and inode == child_inode and [row[0] for row in offsets] == ["monotonic", "boottime"], "Invalid Linux time namespace evidence")
    require(all(len(row) == 3 and 0 <= int(row[2]) < 1_000_000_000 for row in offsets), "Invalid time namespace offsets")
    return {"inode": inode, "child_inode": child_inode, "kernel_boot_sha256": kernel,
            "offsets_ns": {clock: 1_000_000_000 * int(seconds) + int(nanos) for clock, seconds, nanos in offsets}}


def require_same_clock(host, app):
    require(app["kernel_boot_sha256"] == host["kernel_boot_sha256"]
            and app["offsets_ns"] == host["offsets_ns"] == {"monotonic": 0, "boottime": 0},
            "Application and host have differing clock coordinates")


def case_path(root, mode, pair):
    return root / (f"pair_{pair:02}_{mode}" if pair else f"{mode}_fixed")


def cgroup_container(cgroup, container):
    lines = re.findall(r"^0::(.+)$", cgroup, re.M)
    return len(lines) == 1 and Path(lines[0]).name in (container, f"docker-{container}.scope")


def proc_cpu(raw, pid):
    beginning, counters = raw.rsplit(")", 1)
    require(int(beginning.split(" (", 1)[0]) == pid, "Unexpected PID in /proc stat")
    fields = counters.split()
    user, system, start_tick = (int(fields[index]) for index in (11, 12, 19))
    require(min(user, system, start_tick) >= 0, "Negative /proc stat ticks")
    return user, system, start_tick


def snapshot_cpu(first, second, app_pid, db_pid, container, db_container, clock_ticks):
    totals = {}
    for role, pid, cid in (("application", app_pid, container), ("postgres", db_pid, db_container)):
        start, end = first[role], second[role]
        require(start["pid"] == end["pid"] == pid and start["cgroup"] == end["cgroup"]
                and cgroup_container(start["cgroup"], cid), f"CPU snapshot does not identify {role}")
        usage = [dict(line.split() for line in state["cpu.stat"].splitlines()) for state in (start, end)]
        fields = ("usage_usec", "user_usec", "system_usec")
        delta = {field: int(usage[1][field]) - int(usage[0][field]) for field in fields}
        require(min(delta.values()) >= 0 and delta["usage_usec"] > 0, f"Invalid CPU counter delta for {role}")
        totals[role + "_cgroup"] = delta
        usersys = [proc_cpu(state["proc_stat"], pid) for state in (start, end)]
        require(usersys[0][2] == usersys[1][2] and min(usersys[1][i] - usersys[0][i] for i in (0, 1)) >= 0,
                f"PID changed or CPU ticks decreased for {role}")
        if role == "application":
            user, system = ((usersys[1][i] - usersys[0][i]) * 1_000_000 / clock_ticks for i in (0, 1))
            totals["application_process"] = {"usage_usec": user + system, "user_usec": user, "system_usec": system}
    return totals


def client_cpu(raw):
    require(re.findall(r"^\s*Exit status: (\d+)\s*$", raw, re.M) == ["0"], "GNU time reported a nonzero client exit")
    readings = [re.findall(rf"^\s*{key} time \(seconds\): (\d+\.\d+)\s*$", raw, re.M) for key in ("User", "System")]
    require(all(len(bucket) == 1 for bucket in readings), "Missing or duplicate GNU time CPU fields")
    user, system = (round(float(bucket[0]) * 1_000_000) for bucket in readings)
    require(user + system > 0, "GNU time client CPU was zero")
    return {"usage_usec": user + system, "user_usec": user, "system_usec": system}


def request_shape_calls(raw):
    rows = re.findall(r"^UWZ_WRK_GENERATED thread=(\d+) calls=(\d+) (.+)$", raw, re.M)
    require([int(thread) for thread, _, _ in rows] == list(range(1, THREADS + 1)), "Missing or duplicated wrk thread")
    totals = Counter()
    for _, count, values in rows:
        cycles, remainder = divmod(int(count), len(LIMITS))
        expected = {limit: cycles + (index < remainder) for index, limit in enumerate(LIMITS)}
        seen = [(int(limit), int(calls)) for limit, calls in re.findall(r"limit_(\d+)=(\d+)", values)]
        require(int(count) > 0 and seen == list(expected.items()), "Unexpected wrk shape rotation")
        totals.update(dict(seen))
    return dict(totals)


def read_window(case, label, seconds, metadata, app_pid, db_pid, container):
    command = read(case / f"{label}.command.json")
    argv = command["argv"]
    expected = [metadata["wrk"]["path"], "-t", str(THREADS), "-c", str(CONNECTIONS), "-d", f"{seconds}s",
                "--timeout", "2s", "--latency", "-s", metadata["lua"]["path"], f"http://127.0.0.1:{metadata['http_port']}"]
    require(argv[:5] == ["env", "LC_ALL=C", "/usr/bin/time", "-v", "-o"] and argv[6:] == expected
            and Path(argv[5]).name == f"{label}.client_time.txt", f"Unexpected wrk command {case.name}/{label}")
    raw = (case / f"{label}.stdout").read_text()
    summary, = re.findall(r"^UWZ_WRK (.+)$", raw, re.M)
    stats = {name: int(value) for name, value in re.findall(r"(\w+)=(\d+)", summary)}
    completed, duration = stats["completed"], stats["duration_us"]
    require(command["exit_code"] == 0 and completed > 0 and duration >= seconds * 1_000_000,
            f"Unhealthy client {case.name}/{label}")
    require(all(stats[name] == 0 for name in ("status", "connect", "read", "write", "timeout")),
            f"Client errors {case.name}/{label}")
    delays = [stats[f"p{p}_us"] for p in PERCENTILES]
    require(delays == sorted(delays) and min(delays) > 0, "Invalid wrk latency percentile")
    before, after = (read(case / f"{label}_{when}.resources.json") for when in ("before", "after"))
    launch, reaped = command["monotonic_before_spawn_ns"], command["monotonic_after_reap_ns"]
    require(before["monotonic_start_ns"] <= before["monotonic_end_ns"] <= launch
            and launch + duration * 1_000 <= reaped <= after["monotonic_start_ns"] <= after["monotonic_end_ns"],
            f"CPU sampling did not bracket the client interval {case.name}/{label}")
    cpu = snapshot_cpu(before, after, app_pid, db_pid, container, metadata["db_container"], metadata["proc_clock_ticks_per_second"])
    cpu["wrk_process"] = client_cpu((case / f"{label}.client_time.txt").read_text())
    idle_before, idle_after = (window["inactive_postgres"] for window in (before, after))
    require(idle_before["pid"] == idle_after["pid"] == metadata["inactive_db_pid"]
            and idle_before["cgroup"] == idle_after["cgroup"] and cgroup_container(idle_before["cgroup"], metadata["inactive_db_container"]),
            "Inactive database cgroup identity mismatch")
    idle_start, idle_end = (int(dict(line.split() for line in state["cpu.stat"].splitlines())["usage_usec"]) for state in (idle_before, idle_after))
    require(0 <= idle_start <= idle_end, "Inactive database CPU counter went backward")
    stats["rps"] = completed * 1_000_000 / duration
    stats["generated_calls_by_limit"] = request_shape_calls(raw)
    stats["client_monotonic_ns"] = (launch, reaped)
    stats["cpu_usec"] = cpu
    stats["cpu_usec_per_completed_request"] = {role: values["usage_usec"] / completed for role, values in cpu.items()}
    stats["inactive_postgres_cgroup_cpu_usec"] = idle_end - idle_start
    return stats


def fixed_responses(case, rows):
    responses = read(case / "fixed_responses.json")
    shapes = Counter()
    for response in responses:
        require(response["status"] == 200 and response["version"] == 11, "Fixed response is not HTTP/1.1 200")
        headers = {key.lower(): val for key, val in response["headers"]}
        request = response["request"]
        limit = request["limit"]
        require(len(headers) == len(response["headers"]) and headers.get("content-type") == "application/json"
                and headers.get("content-length") == str(len(response["body_utf8"].encode("utf-8"))) and request["method"] == "GET"
                and request["path"] == f"/async-db?min=10&max=50&limit={limit}", "Incorrect fixed request or content type")
        payload = json.loads(response["body_utf8"], object_pairs_hook=unique_fields)
        require(set(payload) == {"items", "count"} and type(payload["count"]) is int and payload["count"] == limit
                and len(payload["items"]) == len({item["id"] for item in payload["items"]}) == limit, "Fixed payload has wrong count")
        for item in payload["items"]:
            require(10 <= item["price"] <= 50 and json.dumps(item, sort_keys=True) == json.dumps(rows[item["id"]], sort_keys=True),
                    "Fixed payload has incorrect typed fields or PostgreSQL values")
        shapes[limit] += 1
    require(shapes == {limit: 10 for limit in LIMITS}, "Fixed requests do not cover the exact five shapes")
    return len(responses)


def pgss_snapshot(report):
    require(report["schema"] == "uwz_pgss_snapshot_v1" and report["monitor_database"] == "postgres",
            "Invalid PGSS monitor schema or database")
    target = report["target"]
    require(all(isinstance(target[key], str) and re.fullmatch(r"[1-9]\d*", target[key])
                and int(target[key]) < (1 << 32) for key in ("userid", "dbid")), "Invalid PGSS target OIDs")
    require(type(report["info"]["dealloc"]) is int and report["info"]["dealloc"] >= 0
            and isinstance(report["info"]["stats_reset"], str), "PGSS reset or deallocation continuity unavailable")
    statements = report["statements"]
    require(type(statements) is list and len(statements) <= 1, "Duplicate or invalid PGSS statement identity")
    if not statements:
        return None
    row = statements[0]
    require(row["dbid"] == target["dbid"] and row["userid"] == target["userid"] and row["toplevel"] is True
            and row["query"] == QUERY and re.fullmatch(r"-?[1-9]\d*", row["queryid"])
            and isinstance(row["stats_since"], str) and row["stats_since"], "PGSS target statement identity mismatch")
    require(all(type(row[key]) is int and row[key] >= 0 for key in PGSS_COUNTS)
            and all(type(row[key]) in (float, int) and math.isfinite(row[key]) and row[key] >= 0 for key in PGSS_TIMES), "Invalid PGSS counters")
    return row


def pgss_delta(first, last, scans):
    before, after = (pgss_snapshot(snap) for snap in (first, last))
    require(first["info"] == last["info"] and first["target"] == last["target"], "PGSS reset, allocation, or OID continuity changed")
    if before is not None:
        require(after is not None and all(before[key] == after[key] for key in ("queryid", "stats_since")),
                "PGSS statement disappeared or changed key")
    totals = {key: (after[key] if after else 0) - (before[key] if before else 0) for key in (*PGSS_COUNTS, *PGSS_TIMES)}
    calls = totals["calls"]
    require(min(totals.values()) >= 0 and calls == scans and 5 * calls <= totals["rows"] <= 50 * calls,
            "PGSS nonmonotonic counters, calls, or returned-row bounds do not reconcile")
    require((totals["plans"] > 0 or totals["total_plan_time"] == 0) and (calls > 0 or totals["total_exec_time"] == 0),
            "PGSS elapsed time increased without corresponding observations")
    if calls:
        totals.update({"plans_per_call": totals["plans"] / calls,
                       "planning_wall_ms_per_call": totals["total_plan_time"] / calls,
                       "execution_wall_ms_per_call": totals["total_exec_time"] / calls})
    return totals


def recorded_phase(case, label, mode, metadata, clients):
    if label == "pre_timed":
        stems = [f"pg_{label}"]
    else:
        stems = [path.stem for path in sorted(case.glob(f"pg_{label}_*.stdout")) if re.fullmatch(rf"pg_{label}_\d{{2}}", path.stem)]
        require(len(stems) >= 2, f"Missing quiescent polling at {case.name}/{label}")
    observations = []
    for stem in stems[-2:]:
        table = read(case / f"{stem}.stdout")
        cmd = read(case / f"{stem}.command.json")
        require(cmd["exit_code"] == 0 and cmd["argv"][4] == metadata["db_container"] and "benchmark" in cmd["argv"],
                f"Unhealthy benchmark table snapshot {case.name}/{label}")
        snapshot = {"table": table}
        if mode == "diagnostic":
            pgss_cmd = read(case / f"{stem}_pgss.command.json")
            expected = ["docker", "exec", "-i", "--user", "postgres", metadata["db_container"], "psql", "-X", "-w", "-At",
                        "-h", "/var/run/postgresql", "-U", "bench", "-d", "postgres", "-v", "ON_ERROR_STOP=1"]
            require(pgss_cmd["exit_code"] == 0 and pgss_cmd["argv"] == expected
                    and pgss_cmd["stdin_file"] == metadata["pgss_sql"]["path"]
                    and pgss_cmd["stdin_sha256"] == metadata["pgss_sql"]["sha256"],
                    f"Unexpected PGSS snapshot command {case.name}/{label}")
            require(cmd["monotonic_after_reap_ns"] <= pgss_cmd["monotonic_before_spawn_ns"], "PGSS and table probes overlapped")
            snapshot["pgss"] = read(case / f"{stem}_pgss.stdout")
            pgss_snapshot(snapshot["pgss"])
        else:
            require(not (case / f"{stem}_pgss.stdout").exists(), "Normal run contains PGSS monitoring")
        observations.append((snapshot, cmd["monotonic_before_spawn_ns"],
                             (pgss_cmd if mode == "diagnostic" else cmd)["monotonic_after_reap_ns"]))
    result, _start, end = observations[-1]
    require(result == observations[0][0] and result["table"]["active_clients"] == 0
            and result["table"]["tcp_clients"] == clients and result["table"]["ssl_clients"] == 0,
            f"PostgreSQL snapshots did not settle at {case.name}/{label}")
    return result, observations[0][1], end


def phase_delta(first, last, completed, allowance):
    before, after = first["table"], last["table"]
    scans = after["seq_scan"] - before["seq_scan"]
    read_rows = after["seq_tup_read"] - before["seq_tup_read"]
    require(before["reset_at"] == after["reset_at"] and (before["idx_scan"] or 0) == (after["idx_scan"] or 0)
            and completed <= scans <= completed + allowance and read_rows >= 0, "Table scan phase does not reconcile")
    result = {"completed": completed, "scans": scans, "seq_tup_read": read_rows, "deadline_excess": scans - completed}
    if "pgss" in first:
        result["pgss"] = pgss_delta(first["pgss"], last["pgss"], scans)
    return result


def verify_case(case, mode, fixed, rows, metadata, db_pid):
    summary = read(case / "summary.json")
    host = metadata["clock_namespace"]
    app = recorded_clock((case / "app_clock_namespace.stdout").read_text())
    host_app_ns = read(case / "app_host_clock_namespace.json")
    link_verified = host_app_ns.get("time_inode") == app["inode"]
    link_unavailable = "time_inode" not in host_app_ns and host_app_ns.get("unavailable_time_inode_errno") in (1, 13)
    app_pid = int((case / "app_pid.stdout").read_text())
    require(app == summary["clock_namespace"] and (link_verified or link_unavailable)
            and host_app_ns["pid"] == app_pid, f"Clock namespace mismatch {case.name}")
    require_same_clock(host, app)
    require(summary["valid"] is True and summary["io_uring_fds"] == WORKERS and summary["mode"] == mode,
            f"Original runner marked invalid or unexpected configuration {case.name}")
    run_cmd, stop_cmd, remove_cmd = (read(case / f"app_{label}.command.json") for label in ("run", "stop", "remove"))
    require(run_cmd["exit_code"] == stop_cmd["exit_code"] == remove_cmd["exit_code"] == 0, f"Lifecycle command failed {case.name}")
    executable = metadata["executable"]
    argv = run_cmd["argv"]
    mounts = [value for option, value in zip(argv, argv[1:]) if option == "--mount"]
    require(mounts ==
            [f"type=bind,source={executable['path']},target=/server,readonly"]
            and metadata["sha256"][executable["path"]] == executable["sha256"] and argv[-3:] == ["--entrypoint", "/server", metadata["db_image"]]
            and argv[argv.index("--network") + 1] == "host" and "--pull=never" in argv,
            f"Incorrect normal executable or image mode {case.name}")
    require({value for option, value in zip(argv, argv[1:]) if option == "--env"} ==
            {"DATABASE_MAX_CONN=256", f"UWZ_HTTP_PORT={metadata['http_port']}"}, f"Incorrect application arguments {case.name}")
    state = read(case / "app_final_state.stdout")
    require(state["ExitCode"] == 0 and not state["OOMKilled"], f"Application exit was unhealthy {case.name}")
    cid = (case / "app_run.stdout").read_text().strip()
    require(cgroup_container(host_app_ns["cgroup"], cid),
            f"Host PID cgroup does not identify the immutable application container {case.name}")
    labels = read(case / "app_ownership.json")["labels"]
    claimed = read(case / "app_verify_ownership.stdout")
    require(re.fullmatch(r"[0-9a-f]{64}", cid) and stop_cmd["argv"][-1] == remove_cmd["argv"][-1] == cid
            and labels["uwz.measurement"] == labels["uwz.sql-experiment"] == "sql-pg-planning-20261119"
            and labels["uwz.role"] == "application"
            and re.fullmatch(r"[0-9a-f]{32}", labels["uwz.run-owner"])
            and all(claimed[key] == value for key, value in labels.items()), f"Application ownership mismatch {case.name}")
    labels = ("before", "after") if fixed else PHASES
    observations = {label: recorded_phase(case, label, mode, metadata, 0 if label in ("before", "after") else WORKERS * 8)
                    for label in labels}
    snapshots = {label: observations[label][0] for label in labels}
    require(all(snapshots[label] == summary["pg_snapshots"][label] for label in labels), "Measured snapshot summary disagrees with raw probes")
    require(observations["before"][2] <= run_cmd["monotonic_before_spawn_ns"]
            and remove_cmd["monotonic_after_reap_ns"] <= observations["after"][1], "Lifetime snapshots do not bracket application")
    before, after = (snapshots[label]["table"] for label in ("before", "after"))
    scans = after["seq_scan"] - before["seq_scan"]
    require(before["reset_at"] == after["reset_at"] and (before["idx_scan"] or 0) == (after["idx_scan"] or 0),
            f"Unexpected PostgreSQL index scans or reset {case.name}")
    readiness = read(sorted(case.glob("ready_sql_*.stdout"))[-1])
    require(readiness["tcp_clients"] == WORKERS * 8 and readiness["ssl_clients"] == 0, f"Unexpected SQL pool readiness {case.name}")
    fd_log = (case / "application_limits_and_fds.stdout").read_text()
    require(fd_log.count("anon_inode:[io_uring]") == WORKERS
            and re.search(r"^Max open files\s+524288\s+524288\s+files", fd_log, re.M)
            and re.search(r"^Max locked memory\s+unlimited\s+unlimited\s+bytes", fd_log, re.M), f"Invalid app resources {case.name}")
    raw_log = "\n".join((case / f"app_logs.{stream}").read_text() for stream in ("stdout", "stderr"))
    require(re.findall(r"benchmark SQL workers=(\d+) connections=(\d+)", raw_log) == [("32", "256")]
            and "query timing start worker=" not in raw_log and "diagnostic SQL worker override=" not in raw_log,
            f"Unexpected application startup mode {case.name}")
    route_counts = [tuple(map(int, fields)) for fields in re.findall(
        r"benchmark database rendered_queries=(\d+) empty_fallbacks=(\d+) rejected_responses=(\d+)", raw_log)]
    require(len(route_counts) == WORKERS and all(empty == rejected == 0 for _, empty, rejected in route_counts),
            f"Application route counters are missing or nonzero {case.name}")
    rendered = sum(row[0] for row in route_counts)
    require(summary["rendered_queries"] == rendered and summary["seq_scan_delta"] == scans,
            f"Application or PostgreSQL summary differs from raw evidence {case.name}")
    phases = {}
    if fixed:
        completed = fixed_responses(case, rows)
        require(completed == rendered == scans, f"Drained counters do not reconcile {case.name}")
        loads = {}
    else:
        loads = {label: read_window(case, label, seconds, metadata, app_pid, db_pid, cid)
                 for label, seconds in (("warmup", 5), ("timed", 10))}
        warmup, timed = (loads[label]["client_monotonic_ns"] for label in ("warmup", "timed"))
        require(run_cmd["monotonic_after_reap_ns"] <= observations["pre_warmup"][1]
                and observations["pre_warmup"][2] <= warmup[0] < warmup[1] <= observations["post_warmup"][1]
                and observations["post_warmup"][2] <= observations["pre_timed"][1]
                and observations["pre_timed"][2] <= timed[0] < timed[1] <= observations["post_timed"][1]
                and observations["post_timed"][2] <= stop_cmd["monotonic_before_spawn_ns"],
                f"PostgreSQL phase snapshots do not bracket both wrk invocations {case.name}")
        segments = ("startup_gap", "warmup", "between_loads_gap", "timed", "shutdown_gap")
        for phase, start, end in zip(segments, PHASES, PHASES[1:]):
            count = loads[phase]["completed"] if phase in loads else 0
            phases[phase] = phase_delta(snapshots[start], snapshots[end], count, CONNECTIONS if count else 0)
        require(sum(phase["scans"] for phase in phases.values()) == scans, "Phase scans do not add to lifetime")
        completed = sum(sample["completed"] for sample in loads.values())
        require(completed <= rendered == scans <= completed + 2 * CONNECTIONS, f"Deadline counters do not reconcile {case.name}")
    require(summary["completed"] == completed, f"Client summary does not reconcile {case.name}")
    lifetime = phase_delta(snapshots["before"], snapshots["after"], completed, 0 if fixed else 2 * CONNECTIONS)
    if mode == "diagnostic" and phases:
        overall = lifetime["pgss"]
        require(all(math.isclose(sum(phase["pgss"][key] for phase in phases.values()), overall[key], rel_tol=0, abs_tol=1e-6)
                    for key in (*PGSS_COUNTS, *PGSS_TIMES)), "PGSS phase metrics do not add to lifetime")
    return {"mode": mode, "wrk": loads, "completed": completed, "rendered": rendered, "seq_scans": scans,
            "rendered_minus_completed": rendered - completed, "pg_lifetime": lifetime, "pg_phases": phases,
            "pg_snapshots": snapshots, "clock_binding": {
                "host": host, "app": app, "host_pid_time_inode_verified": link_verified,
                "host_pid_time_inode_unavailable_errno": host_app_ns.get("unavailable_time_inode_errno")}}


def file_digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def database_pid(root, fixture_path, metadata):
    fixture = read(fixture_path)
    require(fixture["seed_rows"] == metadata["db_seed_rows"] == 100000
            and fixture["seed_sha256"] == metadata["db_seed_sha256"] == SEED_SHA, "Unexpected database seed")
    digest = file_digest(fixture_path)
    require(any(Path(path).name == "fixture.json" and sha == digest for path, sha in metadata["sha256"].items()),
            "Database fixture digest mismatch")
    cid, actual_image_id, image, pid, bindings, labels = map(json.loads, (root / "db_identity.stdout").read_text().splitlines())
    require(cid == fixture["container"] == metadata["db_container"] and image == fixture["image"] == metadata["db_image"]
            and actual_image_id == (root / "db_expected_image_id.stdout").read_text().strip()
            and pid > 0 and fixture["pg_host_port"] == metadata["pg_host_port"] and fixture["http_port"] == metadata["http_port"]
            and bindings == [{"HostIp": "127.0.0.1", "HostPort": str(fixture["pg_host_port"])}], "Database fixture identity mismatch")
    expected_labels = {"uwz.sql-experiment": fixture["label"], "uwz.role": "database", "uwz.run-token": fixture["owner_token"]}
    require(all(labels[key] == value for key, value in expected_labels.items()), "Database fixture ownership mismatch")
    resources = read(root / "resources.json")
    require(resources["pid"] == pid and cgroup_container(resources["cgroup"], cid), "Database resource cgroup identity mismatch")
    return pid


def verify(root, profiles, monitor_path, executable_paths):
    metadata = read(root / "metadata.json")
    require(metadata["python_monotonic_clock"]["implementation"] == "clock_gettime(CLOCK_MONOTONIC)", "Wrong Python clock")
    require(recorded_clock((root / "host_clock_namespace.txt").read_text()) == metadata["clock_namespace"],
            "Host Linux time namespace differs from raw observation")
    require((root / "app_final_inventory.stdout").read_text() == "", "Experiment left application containers")
    identities = {"binary": metadata["executable"], "wrk": metadata["wrk"], "lua": metadata["lua"], "pgss_sql": metadata["pgss_sql"]}
    require(identities["binary"]["sha256"] == CONTROL_SHA and identities["lua"]["sha256"] == LUA_SHA
            and identities["wrk"]["sha256"] == WRK_SHA, "Unexpected original application, client, or Lua fingerprint")
    require(all(metadata["sha256"][identity["path"]] == identity["sha256"] for identity in identities.values()),
            "Inconsistent executable or script digests")
    for mode, path in executable_paths.items():
        require(file_digest(path) == identities[mode]["sha256"], f"Executable or Lua digest mismatch for {mode}")
    require(file_digest(monitor_path) == identities["pgss_sql"]["sha256"], "Unmatched PGSS monitor SQL digest")
    elf_sections = re.split(r"^File: (.+)$", (root / "elf.stdout").read_text(), flags=re.M)[1:]
    elf = dict(zip(elf_sections[::2], elf_sections[1::2]))
    elf_body = elf[identities["binary"]["path"]]
    require("ELF64" in elf_body and "Advanced Micro Devices X86-64" in elf_body and "INTERP" not in elf_body,
            "Application is not the expected x86-64 static ELF mode")
    require(metadata["parameters"] == {"min": 10, "max": 50, "rotating_limits": list(LIMITS), "pipeline_depth": 1}
            and metadata["paired_run_order"] == [list(pair) for pair in PAIR_ORDER], "Unexpected recorded benchmark profile")
    resolved = {}
    for mode in MODES:
        fixture, items = profiles[mode]
        profile = metadata["profiles"][mode]
        database = root / f"{mode}_database"
        pid = database_pid(database, fixture, metadata | profile)
        item_rows = [json.loads(line) for line in items.read_text().splitlines() if line]
        rows = {row["id"]: row for row in item_rows}
        require(len(rows) == len(item_rows) == profile["fixture_rows_exported"]
                and file_digest(items) == metadata["sha256"][profile["items_path"]]
                and file_digest(fixture) == metadata["sha256"][profile["fixture_path"]], "Incorrect item or fixture fingerprint")
        resolved[mode] = (rows, metadata | profile, pid)
    for mode, other in (("normal", "diagnostic"), ("diagnostic", "normal")):
        resolved[mode][1].update({"inactive_db_pid": resolved[other][2], "inactive_db_container": resolved[other][1]["db_container"]})
    require(resolved["normal"][0] == resolved["diagnostic"][0] and len({profile[1]["db_container"] for profile in resolved.values()}) == 2
            and len({profile[1]["db_image"] for profile in resolved.values()}) == 1
            and len({profile[1]["http_port"] for profile in resolved.values()}) == 2
            and len({metadata["sha256"][profile[1]["items_path"]] for profile in resolved.values()}) == 1,
            "Test clusters do not have identical seeded rows or distinct endpoint identity")
    resources = [read(root / f"{mode}_database" / "resources.json") for mode in MODES]
    require(all(resources[0][key] == resources[1][key] for key in ("cpu.max", "memory.max")),
            "Database resource limits differ between profiles")
    normal_fixed = case_path(root, "normal", 0)
    diagnostic_fixed = case_path(root, "diagnostic", 0)
    require(read(normal_fixed / "app_remove.command.json")["monotonic_after_reap_ns"]
            < read(diagnostic_fixed / "app_run.command.json")["monotonic_before_spawn_ns"], "Fixed validations overlap or are reversed")
    fixed = {mode: verify_case(case_path(root, mode, 0), mode, True, *resolved[mode]) for mode in MODES}
    prepare_path = monitor_path.parent / "preflight" / "prepared_monitor.json"
    prepared = read(prepare_path)
    diagnostic_initial = fixed["diagnostic"]["pg_snapshots"]["before"]["pgss"]
    require(prepared["container"] == resolved["diagnostic"][1]["db_container"]
            and prepared["reset_before_measurement_only"] is True and prepared["monitor_exit_code"] == prepared["setup_exit_code"] == 0
            and prepared["snapshot"] == diagnostic_initial and diagnostic_initial["statements"] == [],
            "Diagnostic fixed baseline does not match the prepared monitor epoch")
    last_exit = read(diagnostic_fixed / "app_remove.command.json")["monotonic_after_reap_ns"]
    last_pg = {mode: fixed[mode]["pg_snapshots"]["after"] for mode in MODES}
    pairs = []
    for num, order in enumerate(PAIR_ORDER, 1):
        pair = {}
        for mode in order:
            case = case_path(root, mode, num)
            started = read(case / "app_run.command.json")["monotonic_before_spawn_ns"]
            require(last_exit < started, "Paired cases overlap or were not run in the declared order")
            last_exit = read(case / "app_remove.command.json")["monotonic_after_reap_ns"]
            pair[mode] = verify_case(case, mode, False, *resolved[mode])
            snapshots = pair[mode]["pg_snapshots"]
            require(snapshots["before"] == last_pg[mode], "Database counters drifted between cases of the same profile")
            last_pg[mode] = snapshots["after"]
        normal, diagnostic = (case_metrics(pair[mode]) for mode in MODES)
        pair["diagnostic_minus_normal_percent"] = {metric: 100 * (diagnostic[metric] / value - 1) for metric, value in normal.items()}
        pairs.append(pair)
    metrics = list(case_metrics(pairs[0]["normal"]))
    intervals = {mode: {metric: summarize_values([case_metrics(pair[mode])[metric] for pair in pairs]) for metric in metrics}
                 for mode in MODES}
    deltas = {metric: summarize_values([pair["diagnostic_minus_normal_percent"][metric] for pair in pairs]) for metric in metrics}
    pg_metrics = {phase: combined_pgss([pair["diagnostic"]["pg_phases"][phase]["pgss"] for pair in pairs]) for phase in ("warmup", "timed")}
    return {"valid": True, "fixed": fixed, "pairs": pairs, "timed_run_observed_ranges": intervals,
            "paired_diagnostic_minus_normal_percent": deltas, "diagnostic_pgss_phases": pg_metrics,
            "prepared_monitor_sha256": file_digest(prepare_path),
            "file_digests_checked": sorted((*executable_paths, "pgss_sql")), "throughput_threshold_rps": 300000,
            "throughput_gate_met": intervals["normal"]["rps"]["median"] > 300000}


def combined_pgss(windows):
    totals = {key: sum(window[key] for window in windows) for key in (*PGSS_COUNTS, *PGSS_TIMES)}
    calls = totals["calls"]
    return totals | {"plans_per_call": totals["plans"] / calls,
                     "planning_wall_ms_per_call": totals["total_plan_time"] / calls,
                     "execution_wall_ms_per_call": totals["total_exec_time"] / calls}


def case_metrics(case):
    timed = case["wrk"]["timed"]
    metrics = {key: timed[key] for key in ("rps", *(f"p{p}_us" for p in PERCENTILES))}
    metrics.update({role + "_cpu_usec_per_completed_request": value for role, value in timed["cpu_usec_per_completed_request"].items()})
    return metrics


def summarize_values(values):
    return {"min": min(values), "median": statistics.median(values), "max": max(values)}


def main():
    parser = argparse.ArgumentParser(description="Offline verification of paired PostgreSQL planning measurements")
    parser.add_argument("measurements", type=Path)
    for mode in MODES:
        parser.add_argument(f"--{mode}-items", type=Path, required=True)
        parser.add_argument(f"--{mode}-fixture", type=Path, required=True)
    parser.add_argument("--pgss-sql", type=Path, required=True)
    for artifact in ("binary", "wrk", "lua"):
        parser.add_argument("--" + artifact, type=Path)
    args = parser.parse_args()
    sources = {name: getattr(args, name) for name in ("binary", "wrk", "lua") if getattr(args, name)}
    profiles = {mode: (getattr(args, mode + "_fixture"), getattr(args, mode + "_items")) for mode in MODES}
    result = verify(args.measurements, profiles, args.pgss_sql, sources)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
