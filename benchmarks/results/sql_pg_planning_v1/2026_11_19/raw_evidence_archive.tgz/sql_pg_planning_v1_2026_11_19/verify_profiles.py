#!/usr/bin/env python3
"""Record the exact settable and derived differences between owned profiles."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


DIAGNOSTIC = {"compute_query_id", "shared_preload_libraries"}
DERIVED = {"shared_memory_size", "shared_memory_size_in_huge_pages"}
EXPECTED = {
    "normal": {"compute_query_id": "auto", "shared_preload_libraries": ""},
    "diagnostic": {"compute_query_id": "on", "shared_preload_libraries": "pg_stat_statements",
        "pg_stat_statements.max": "5000", "pg_stat_statements.save": "off",
        "pg_stat_statements.track": "top", "pg_stat_statements.track_planning": "on",
        "pg_stat_statements.track_utility": "off"},
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fixtures", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    profiles = {}
    exports = {}
    for profile in ("normal", "diagnostic"):
        directory = args.fixtures / profile
        fixture = json.loads((directory / "fixture.json").read_text())
        command = ["docker", "exec", fixture["container"], "psql", "-X", "-U", "bench",
                   "-d", "postgres", "-At", "-vON_ERROR_STOP=1", "-c",
                   "SELECT json_agg(s) FROM (SELECT name,setting,context,source,pending_restart FROM pg_settings ORDER BY name) s;"]
        result = subprocess.run(command, text=True, capture_output=True, check=True)
        rows = json.loads(result.stdout)
        profiles[profile] = {row["name"]: row for row in rows}
        for name, expected in EXPECTED[profile].items():
            if profiles[profile].get(name, {}).get("setting") != expected:
                raise RuntimeError("Unexpected " + profile + " setting: " + name)
        extension_keys = {name for name in profiles[profile] if name.startswith("pg_stat_statements.")}
        expected_keys = {name for name in EXPECTED[profile] if name.startswith("pg_stat_statements.")}
        if extension_keys != expected_keys:
            raise RuntimeError("Unexpected extension settings in " + profile)
        (directory / "fixture/all_settings.json").write_text(json.dumps(
            {"argv": command, "exit_code": result.returncode, "rows": rows}, indent=2) + "\n")
        export = directory / "fixture/expected_items.jsonl"
        exports[profile] = hashlib.sha256(export.read_bytes()).hexdigest()
        fixture["performance_profile"] = profile
        fixture["statement_statistics_monitor"] = "postgres only" if profile == "diagnostic" else None
        fixture["exports"] = [{"file": "expected_items.jsonl", "sha256": exports[profile]}]
        (directory / "fixture.json").write_text(json.dumps(fixture, indent=2) + "\n")
    if exports["normal"] != exports["diagnostic"]:
        raise RuntimeError("The exact dataset exports differ")
    changes = {}
    for name in sorted(set(profiles["normal"]) | set(profiles["diagnostic"])):
        first, second = (profiles[profile].get(name) for profile in ("normal", "diagnostic"))
        if first and second and first["setting"] == second["setting"]:
            continue
        if name not in DIAGNOSTIC | DERIVED and not name.startswith("pg_stat_statements."):
            raise RuntimeError("Undeclared profile difference: " + name)
        if name in DERIVED and not all(row and row["context"] == "internal" and not row["pending_restart"] for row in (first, second)):
            raise RuntimeError("Expected read-only derived memory totals: " + name)
        changes[name] = {"normal": first, "diagnostic": second}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({"differences": changes, "byte_identical_items_export": True,
        "export_sha256": exports["normal"], "settable_differences_are_diagnostic_only": True,
        "derived_internal_memory_differences_recorded": True}, indent=2) + "\n")
    print("Profiles verified: identical dataset; only declared instrumentation and derived memory differ")


if __name__ == "__main__":
    main()
