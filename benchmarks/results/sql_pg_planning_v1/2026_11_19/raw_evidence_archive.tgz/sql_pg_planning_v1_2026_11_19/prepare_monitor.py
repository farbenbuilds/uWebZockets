#!/usr/bin/env python3
"""Initialize diagnostic counters before any owned workload starts."""
import argparse
import json
from pathlib import Path
import re
import subprocess
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fixture", type=Path, required=True)
    parser.add_argument("--monitor", type=Path, required=True)
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if (args.run_root / "measurements").exists():
        raise RuntimeError("Counter initialization is forbidden after measurement starts")
    fixture = json.loads(args.fixture.read_text())
    container = fixture["container"]
    if not re.fullmatch(r"[0-9a-f]{64}", container):
        raise RuntimeError("An immutable container ID is required")
    labels = json.loads(subprocess.check_output(
        ["docker", "inspect", "--format", "{{json .Config.Labels}}", container], text=True))
    expected = {"uwz.sql-experiment": "sql-pg-planning-20261119",
                "uwz.role": "database", "uwz.run-token": fixture["owner_token"]}
    if any(labels.get(key) != value for key, value in expected.items()):
        raise RuntimeError("Diagnostic fixture ownership differs")
    command = ["docker", "exec", "-i", container, "psql", "-X", "-U", "bench",
               "-d", "postgres", "-At", "-vON_ERROR_STOP=1"]
    clients_sql = "SELECT count(*) FROM pg_stat_activity WHERE client_addr IS NOT NULL;"
    clients = subprocess.run(command, input=clients_sql, text=True, capture_output=True, check=True)
    if clients.stdout.strip() != "0":
        raise RuntimeError("Cannot initialize counters with live TCP clients")
    setup_sql = "CREATE EXTENSION IF NOT EXISTS pg_stat_statements; SELECT pg_stat_statements_reset();"
    setup = subprocess.run(command, input=setup_sql, text=True, capture_output=True, check=True)
    monitor_sql = args.monitor.read_text()
    observed = subprocess.run(command, input=monitor_sql, text=True, capture_output=True, check=True)
    snapshot = json.loads(observed.stdout)
    if snapshot["monitor_database"] != "postgres" or snapshot["statements"]:
        raise RuntimeError("Initial target counters must be empty in the monitoring database")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({"observed_unix_ns": time.time_ns(), "container": container,
        "expected_labels": expected, "argv": command, "clients_sql": clients_sql,
        "clients_stdout": clients.stdout, "setup_sql": setup_sql, "setup_exit_code": setup.returncode,
        "setup_stdout": setup.stdout, "setup_stderr": setup.stderr,
        "monitor_sql": monitor_sql, "monitor_exit_code": observed.returncode,
        "snapshot": snapshot, "reset_before_measurement_only": True}, indent=2) + "\n")
    print("Diagnostic monitor prepared before workload; target statement counters empty")


if __name__ == "__main__":
    main()
