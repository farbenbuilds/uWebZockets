#!/usr/bin/env python3
"""Verify the extracted source, profiles, epoch and results offline."""
import hashlib
import json
from pathlib import Path
import re
import stat
import subprocess
import sys


MODES = ('normal', 'diagnostic')
BINARY = 'install/bin/sql_httparena'
WRK = 'tooling/root/usr/bin/wrk'
LUA = 'runner/async_db.lua'
EXPECTED = {
    'normal': {'compute_query_id': 'auto', 'shared_preload_libraries': ''},
    'diagnostic': {'compute_query_id': 'on', 'shared_preload_libraries': 'pg_stat_statements',
                   'pg_stat_statements.max': '5000', 'pg_stat_statements.save': 'off',
                   'pg_stat_statements.track': 'top', 'pg_stat_statements.track_planning': 'on',
                   'pg_stat_statements.track_utility': 'off'},
}
DERIVED = {'normal': {'shared_memory_size': '161', 'shared_memory_size_in_huge_pages': '81'},
           'diagnostic': {'shared_memory_size': '163', 'shared_memory_size_in_huge_pages': '82'}}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def mode(path):
    return stat.S_IMODE(path.stat().st_mode)


def check_inventory(root, entries, manifest=None):
    expected = set()
    for entry in entries:
        name = entry['path']
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts and name not in expected, f'Invalid inventory path {name}')
        expected.add(name)
        member = root / path
        require(member.is_file() and not member.is_symlink() and mode(member) == entry['mode'] and
                sha(member) == entry['sha256'], f'File identity differs: {name}')
    observed = {path.relative_to(root).as_posix() for path in root.rglob('*') if not path.is_dir() or path.is_symlink()}
    if manifest is not None:
        expected.add(manifest)
    require(observed == expected, f'File inventory differs under {root.name}')
    return len(entries)


def verify_source(root):
    plan = load(root / 'decision_plan.json')
    build = load(root / 'build/result.json')
    package = load(root / 'packaged_source_identity.json')
    base = load(root / 'source_identity.json')
    provenance = load(root / 'source_provenance.json')
    require(check_inventory(root / 'source', package['files']) == provenance['verified_git_blob_identities'] == 346 and
            package['commit'] == base['commit'] == build['source_commit'] == provenance['build_source_commit'] and
            plan['base_commit'] == provenance['measurement_workspace_commit'] and plan['source_changes'] is False,
            'Source provenance differs')
    package_by_path = {entry['path']: entry for entry in package['files']}
    require(len(base['files']) == 288, 'Build input subset differs')
    for item in base['files']:
        expected = package_by_path[item['path']]
        require(all(item[key] == expected[key] for key in ('sha256', 'mode')), f"Build subset differs: {item['path']}")
    require(build['exit_code'] == 0 and sha(root / BINARY) == build['binary_sha256'] == plan['normal_binary_sha256'] and
            (root / BINARY).stat().st_size == build['binary_bytes'], 'Build binary differs')
    tools = load(root / 'tooling/identity.json')
    require(sha(root / WRK) == tools['wrk_sha256'] and
            sha(root / 'tooling/wrk_4.1.0-4build3_amd64.deb') == tools['package_sha256'], 'wrk identity differs')


def verify_settings(root):
    derived = load(root / 'preflight/derived_memory_settings.json')
    profiles = {}
    for profile in MODES:
        recorded = load(root / 'fixtures' / profile / 'fixture/all_settings.json')
        rows = {row['name']: row for row in recorded['rows']}
        exact = EXPECTED[profile]
        require(recorded['exit_code'] == 0 and len(rows) == len(recorded['rows']) and
                {key for key in rows if key.startswith('pg_stat_statements.')} ==
                {key for key in exact if key.startswith('pg_stat_statements.')}, f'Unexpected {profile} GUC inventory')
        for name, value in exact.items():
            require(rows[name]['setting'] == value and rows[name]['pending_restart'] is False,
                    f'Unexpected {profile} GUC setting: {name}')
        memory = {row['name']: row for row in derived[profile]['rows']}
        require(derived[profile]['exit_code'] == 0 and set(memory) == set(DERIVED[profile]), 'Derived memory proof differs')
        for name, value in DERIVED[profile].items():
            require(memory[name] == rows[name] and rows[name]['setting'] == value and rows[name]['context'] == 'internal'
                    and rows[name]['pending_restart'] is False, f'Unexpected derived {profile} setting: {name}')
        profiles[profile] = rows
    normal, diagnostic = (profiles[profile] for profile in MODES)
    changes = {name: {'normal': normal.get(name), 'diagnostic': diagnostic.get(name)}
               for name in normal.keys() | diagnostic.keys()
               if normal.get(name, {}).get('setting') != diagnostic.get(name, {}).get('setting')}
    compare = load(root / 'preflight/profile_settings_comparison.json')
    require(set(changes) == set(EXPECTED['diagnostic']) | set(DERIVED['diagnostic']) and
            changes == compare['differences'], 'Unrecorded GUC differences')


def verify_fixture(root, profile):
    directory = root / 'fixtures' / profile
    fixture = load(directory / 'fixture.json')
    for entry in load(root / 'archived_inputs.json')['files']:
        file = directory / 'archived_fixture' / Path(entry['member']).name
        require(sha(file) == entry['sha256'] and mode(file) == entry['mode'], f'Archived fixture input differs: {profile}/{file.name}')
    need_monitor = 'postgres only' if profile == 'diagnostic' else None
    require(fixture['seed_sha256'] == sha(directory / 'archived_fixture/pgdb-seed.sql') and
            fixture['image'] == (directory / 'archived_fixture/image.txt').read_text().strip() and
            fixture['seed_rows'] == 100000 and fixture['expected_rows'] == 8237 and
            fixture['statement_statistics_monitor'] == need_monitor and fixture['performance_profile'] == profile,
            f'Fixture identity differs: {profile}')
    cleanup = load(directory / 'cleanup.json')
    last = load(directory / 'fixture/post_measurement_state.json')
    require(last['exit_code'] == 0 and last['argv'][2] == fixture['container'] and last['snapshot']['tcp_clients'] == 0 and
            last['snapshot']['monitor_extension'] is None, f'Post-measurement observation differs: {profile}')
    require(cleanup['container_removed_or_absent'] is True and cleanup['private_inputs_removed'] is True and
            cleanup['matched_database_containers'] == 1 and cleanup['label'] == fixture['label'] and
            cleanup['ownership_token_sha256'] == hashlib.sha256(fixture['owner_token'].encode()).hexdigest(),
            f'Cleanup identity differs: {profile}')
    return fixture


def verify_epoch(root, run, diagnostic):
    epoch = load(root / 'preflight/prepared_monitor.json')
    snap = epoch['snapshot']
    require(epoch['container'] == diagnostic['container'] and epoch['expected_labels']['uwz.run-token'] == diagnostic['owner_token']
            and epoch['clients_stdout'].strip() == '0' and epoch['setup_exit_code'] == epoch['monitor_exit_code'] == 0
            and epoch['reset_before_measurement_only'] is True and epoch['monitor_sql'] == (root / 'monitor.sql').read_text(),
            'Monitor preparation does not bind to the owned diagnostic database')
    require(snap['monitor_database'] == 'postgres' and snap['statements'] == [] and snap['info']['dealloc'] == 0 and
            isinstance(snap['info']['stats_reset'], str) and snap['info']['stats_reset'] and
            all(type(oid) is str and oid.isdigit() for oid in snap['target'].values()), 'Prepared epoch is not an empty target')
    for suffix in ('00', '01'):
        path = run / 'diagnostic_fixed' / f'pg_before_{suffix}_pgss.stdout'
        require(load(path) == snap, f'First diagnostic fixed snapshot differs from prepared epoch: {path.name}')


def verify_prelaunch(root):
    seen = set()
    expected = {BINARY, WRK, LUA, 'runner/measure.py', 'verification/verify.py', 'verification/test_verify.py', 'monitor.sql',
                'preflight/prepared_monitor.json', 'preflight/profile_settings_comparison.json'}
    for profile in MODES:
        expected.update({f'fixtures/{profile}/fixture.json', f'fixtures/{profile}/fixture/expected_items.jsonl'})
    for line in (root / 'verification/prelaunch.sha256').read_text().splitlines():
        digest, path = line.split()
        work, name = path.removeprefix('.zig-cache/').split('/', 1)
        require(work in {'sql-pg-planning-20261119', 'async-db-performance-20261118'} and name not in seen and name in expected and
                sha(root / name) == digest, f'Prelaunch identity differs: {name}')
        seen.add(name)
    require(seen == expected, 'Unexpected prelaunch input inventory')


def verify_extension(root, normal, diagnostic):
    cached = load(root / 'preflight/cached_extension.json')
    digests = cached['library_sha256_stdout'].split()
    require(cached['exit_code'] == cached['library_exit_code'] == 0 and normal['container'] != diagnostic['container'] and
            cached['immutable_container'] == normal['container'] and cached['image'] == normal['image'] == diagnostic['image'] and
            cached['result']['extension'] == [{'name': 'pg_stat_statements', 'default_version': '1.12', 'installed_version': None}] and
            re.fullmatch(r'[a-f0-9]{64}', digests[0]) and digests[1].endswith('/pg_stat_statements.so'), 'Cached PGss library identity differs')


def main():
    root = Path(__file__).resolve().parent
    run = root / 'measurements/run_01'
    count = check_inventory(root, load(root / 'payload_manifest.json')['files'], 'payload_manifest.json')
    verify_source(root)
    verify_settings(root)
    normal, diagnostic = (verify_fixture(root, profile) for profile in MODES)
    verify_extension(root, normal, diagnostic)
    verify_epoch(root, run, diagnostic)
    verify_prelaunch(root)
    compare = load(root / 'preflight/profile_settings_comparison.json')
    exports = [sha(root / 'fixtures' / profile / 'fixture/expected_items.jsonl') for profile in MODES]
    require(exports[0] == exports[1] == compare['export_sha256'], 'Profile dataset export bytes differ')
    profiles = []
    for profile in MODES:
        directory = root / 'fixtures' / profile
        profiles.extend((f'--{profile}-items', directory / 'fixture/expected_items.jsonl',
                         f'--{profile}-fixture', directory / 'fixture.json'))
    out = subprocess.check_output([sys.executable, '-B', root / 'verification/verify.py', run, *profiles,
                                   '--pgss-sql', root / 'monitor.sql', '--binary', root / BINARY,
                                   '--wrk', root / WRK, '--lua', root / LUA])
    result = json.loads(out)
    require(result == load(run / 'verified.json'), 'Recomputed benchmark differs from retained verification')
    pgss = result['diagnostic_pgss_phases']['timed']
    print(f'Verified {count} payload files, 346 source files, exact profile settings, and the diagnostic epoch.')
    print(f"Recomputed eight cases, 100 fixed responses and {pgss['plans']:,} timed plans across {pgss['calls']:,} diagnostic calls.")
    print('300,000 requests/s gate:', 'met' if result['throughput_gate_met'] else 'unmet')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, subprocess.CalledProcessError) as error:
        raise SystemExit(f'Verification failed: {error}') from error
