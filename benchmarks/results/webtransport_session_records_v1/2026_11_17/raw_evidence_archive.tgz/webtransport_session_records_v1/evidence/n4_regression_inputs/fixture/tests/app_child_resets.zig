const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const h = @import("app_children.zig").ChildrenSupport;
const testing = std.testing;
const backend = support.webtransport_backend;
const child = support.webtransport_child_runtime;
const stop_code: u64 = (@as(u64, 1) << 61) + 37;
const reset_code: u64 = (@as(u64, 1) << 62) - 19;

fn await_stop(application: *h.Application, clients: []const *c.struct_uwz_app_client, observed: *h.Observation, key: child.Key) !*h.Record {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(application, clients, observed);
        const record = h.find_record(observed, key.connection, key.stream_id) orelse continue;
        if (record.stop_calls == 0) continue;
        try testing.expectEqual(@as(usize, 1), record.stop_calls);
        try testing.expectEqual(@as(?u64, stop_code), record.stop_code);
        return record;
    }
    return error.ChildStopNotificationTimeout;
}

test "peer BIDI STOP preserves receiving then independent RESET closes once with full errors" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application };
    const port = try h.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    _ = try h.accept(&application, client, &clients, &observed, 0);
    const id = try h.open_child(&application, client, 0, .bidi);
    const key = try h.key_for(&application, index, 0, id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, "before", 6, 0));
    _ = try h.await_data(&application, &clients, &observed, key, "before");
    try testing.expectEqual(backend.StopResult.ok, backend.stop_receiving(try h.native_client_stream(client, id), stop_code));
    const record = try await_stop(&application, &clients, &observed, key);
    try testing.expect(record.closed == null and record.reset_calls == 0 and record.eof_calls == 0);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, "after", 5, 0));
    _ = try h.await_data(&application, &clients, &observed, key, "beforeafter");
    try testing.expectEqual(backend.ResetResult.ok, backend.reset_stream(try h.native_client_stream(client, id), reset_code));
    _ = try h.await_closed(&application, &clients, &observed, key);
    try testing.expectEqual(@as(usize, 1), record.reset_calls);
    try testing.expectEqual(@as(?u64, reset_code), record.reset_code);
    try testing.expectEqual(@as(?u64, 11), record.reset_size);
    try testing.expectEqual(child.CloseReason.peer_reset, record.closed.?.reason);
    try testing.expectEqual(@as(?u64, reset_code), record.closed.?.code);
    try testing.expectEqual(@as(?u64, 11), record.closed.?.final_payload_size);
    try testing.expectEqual(@as(u64, 11), record.closed.?.accounted_bytes);
    try testing.expectEqual(@as(usize, 1), record.stop_calls);
    try testing.expectEqual(@as(usize, 0), record.eof_calls);
    for (0..16) |_| try h.pump(&application, &clients, &observed);
    try h.healthy_http(&application, client, &clients, &observed);
}

test "hidden reliable reset admits and delivers its reliable payload before visible reset" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application };
    const port = try h.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    const id = try h.raw_uni(client, 0, "abcdefghijkl");
    try h.await_pending_native(&application, &clients, &observed, index, id, 0);
    try h.await_buffered(&application, &clients, &observed, index, id, "abcdefghijkl");
    try testing.expectEqual(@as(c_int, c.LSQUIC_SRA_OK), c.lsquic_stream_reset_at(try h.native_client_stream(client, id), reset_code, 7));
    try h.deliver_client_batch(&application, client, &observed, index);
    const before = try h.receive_snapshot(&application, index, id);
    try testing.expectEqual(@as(?u64, reset_code), before.reset_error);
    try testing.expect(!before.reset_visible and !before.read_cancelled);
    try testing.expectEqual(@as(?u64, 15), before.final_size);
    try testing.expectEqual(@as(?u64, 7), before.reliable_size);
    _ = try h.waiting_state(&application, index, id);
    try testing.expectEqual(@as(usize, 0), observed.count);
    _ = try h.accept(&application, client, &clients, &observed, 0);
    const key = try h.key_for(&application, index, 0, id);
    const record = try h.await_closed(&application, &clients, &observed, key);
    try testing.expectEqualSlices(u8, "abcd", record.bytes[0..record.received]);
    try testing.expectEqual(@as(usize, 1), record.data_calls);
    try testing.expectEqual(@as(usize, 1), record.reset_after_data_calls);
    try testing.expectEqual(@as(usize, 1), record.reset_calls);
    try testing.expectEqual(@as(?u64, reset_code), record.reset_code);
    try testing.expectEqual(@as(?u64, 12), record.reset_size);
    try testing.expectEqual(@as(u64, 12), record.closed.?.accounted_bytes);
    try testing.expectEqual(@as(?u64, 12), record.closed.?.final_payload_size);
    try testing.expectEqual(child.CloseReason.peer_reset, record.closed.?.reason);
    try testing.expectEqual(@as(usize, 0), record.eof_calls);
    try testing.expectEqual(@as(usize, 0), record.stop_calls);
    try h.healthy_http(&application, client, &clients, &observed);
}

test "visible reset while waiting prevents consumer open after later parent admission" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application };
    const port = try h.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    const id = try h.raw_uni(client, 0, "abandoned");
    try h.await_pending_native(&application, &clients, &observed, index, id, 0);
    try h.await_buffered(&application, &clients, &observed, index, id, "abandoned");
    const deadline = (try h.waiting_state(&application, index, id)).deadline_us;
    const future = try h.raw_uni(client, 4, "future");
    try h.await_pending_native(&application, &clients, &observed, index, future, 4);
    try h.await_buffered(&application, &clients, &observed, index, future, "future");
    try testing.expectEqual(backend.ResetResult.ok, backend.reset_stream(try h.native_client_stream(client, id), reset_code));
    try h.deliver_client_batch(&application, client, &observed, index);
    const engine = &application.quic_transport.?.engine;
    const binding = engine.binding.?;
    try testing.expect(binding.clock(binding.context) < deadline);
    var receive: c.struct_lsquic_stream_recv_state = undefined;
    const found = c.uwz_app_sibling_receive(try h.native_server_stream(&application, index, future), id, &receive);
    try testing.expect(found >= 0);
    if (found == 1) {
        try testing.expect(receive.flags & c.LSQUIC_SRS_RESET_VISIBLE != 0);
        try testing.expectEqual(reset_code, receive.reset_error_code);
    }
    _ = try h.accept(&application, client, &clients, &observed, 0);
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expectEqual(@as(usize, 1), engine.pending_child_count);
    _ = try h.waiting_state(&application, index, future);
    try h.finish_send(client, 0);
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        if (engine.session_index.?.find(.{ .connection = engine.connections.pool.storage[index].handle, .session_id = 0 }) == null) break;
    }
    _ = try h.accept(&application, client, &clients, &observed, 4);
    const key = try h.key_for(&application, index, 4, future);
    _ = try h.await_data(&application, &clients, &observed, key, "future");
    try h.finish_send(client, future);
    try h.expect_completed(try h.await_closed(&application, &clients, &observed, key), "future");
    try testing.expectEqual(@as(usize, 1), observed.count);
    try h.healthy_http(&application, client, &clients, &observed);
}
