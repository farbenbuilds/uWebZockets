comptime {
    _ = @import("app_child_lifecycle.zig");
    _ = @import("app_child_teardown.zig");
    _ = @import("app_child_callbacks.zig");
    _ = @import("app_child_resets.zig");
}
