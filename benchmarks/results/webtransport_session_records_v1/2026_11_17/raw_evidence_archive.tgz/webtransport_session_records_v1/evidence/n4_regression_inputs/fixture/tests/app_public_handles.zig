const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const h = @import("app_children.zig").ChildrenSupport;
const testing = std.testing;
const streams = h.Streams;

fn await_sessions(application: *h.Application, clients: []const *c.struct_uwz_app_client, observed: *h.Observation, count: usize) !void {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(application, clients, observed);
        if (observed.session_closed_count == count) return;
    }
    return error.PublicSessionCloseTimeout;
}

fn await_eof(application: *h.Application, clients: []const *c.struct_uwz_app_client, observed: *h.Observation, key: support.webtransport_child_runtime.Key) !*h.Record {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(application, clients, observed);
        const record = h.find_record(observed, key.connection, key.stream_id) orelse continue;
        if (record.eof_calls != 0) return record;
    }
    return error.PublicEofTimeout;
}

test "public child handles reject wrong App and stale generation at a reused slot" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application, .verify_open_not_ready = true };
    const port = try h.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    _ = try h.accept(&application, client, &clients, &observed, 0);
    const id = try h.open_child(&application, client, 0, .uni);
    const key = try h.key_for(&application, index, 0, id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, "first", 5, 0));
    const first = try h.await_data(&application, &clients, &observed, key, "first");
    const stale = first.public_info.handle;
    try testing.expectEqual(@as(usize, 1), observed.open_not_ready_checks);
    var invalid = [_]streams.Handle{ stale, stale, stale };
    invalid[0].index = std.math.maxInt(usize);
    invalid[1].generation = 0;
    invalid[2].generation += 1;
    for (invalid) |handle| {
        try testing.expectError(error.StaleHandle, application.webtransport_stream_cancel(handle, 91));
        try testing.expectError(error.StaleHandle, application.webtransport_stream_finish(handle));
    }
    try testing.expect(first.closed == null);

    var other = try h.initialize();
    defer h.destroy(&other);
    var sibling: h.Observation = .{ .application = &other };
    const other_port = try h.listen(&other, &sibling);
    const peer = c.uwz_app_client_create(other_port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(peer);
    const peers = [_]*c.struct_uwz_app_client{peer};
    const other_index = try h.handshake(&other, peer, &peers, &sibling);
    _ = try h.accept(&other, peer, &peers, &sibling, 0);
    const peer_id = try h.open_child(&other, peer, 0, .uni);
    const peer_key = try h.key_for(&other, other_index, 0, peer_id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(peer, peer_id, "other", 5, 0));
    const foreign = try h.await_data(&other, &peers, &sibling, peer_key, "other");
    try testing.expectEqual(stale.index, foreign.public_info.handle.index);
    try testing.expectEqual(stale.generation, foreign.public_info.handle.generation);
    try testing.expect(!std.meta.eql(stale.owner, foreign.public_info.handle.owner));
    try testing.expectError(error.WrongApp, other.webtransport_stream_cancel(stale, 99));
    try testing.expectError(error.WrongApp, other.webtransport_stream_finish(stale));
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(peer, peer_id, "+", 1, 0));
    _ = try h.await_data(&other, &peers, &sibling, peer_key, "other+");
    try testing.expect(foreign.closed == null);

    try h.finish_send(client, id);
    try h.expect_completed(try h.await_closed(&application, &clients, &observed, key), "first");
    const next_id = try h.open_child(&application, client, 0, .uni);
    const next_key = try h.key_for(&application, index, 0, next_id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, next_id, "fresh", 5, 0));
    const fresh = try h.await_data(&application, &clients, &observed, next_key, "fresh");
    try testing.expectEqual(stale.index, fresh.public_info.handle.index);
    try testing.expect(fresh.public_info.handle.generation > stale.generation);
    try testing.expectError(error.StaleHandle, application.webtransport_stream_cancel(stale, 101));
    try testing.expectError(error.StaleHandle, application.webtransport_stream_finish(stale));
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, next_id, "+", 1, 0));
    _ = try h.await_data(&application, &clients, &observed, next_key, "fresh+");
    try testing.expect(fresh.closed == null);
    try testing.expectEqual(@as(usize, 2), observed.open_not_ready_checks);
    try h.finish_send(client, next_id);
    try h.expect_completed(try h.await_closed(&application, &clients, &observed, next_key), "fresh+");
    try h.finish_send(peer, peer_id);
    try h.expect_completed(try h.await_closed(&other, &peers, &sibling, peer_key), "other+");
    try h.healthy_http(&application, client, &clients, &observed);
    try h.healthy_http(&other, peer, &peers, &sibling);
}

test "public application cancellation reaches the peer with its typed application error" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application };
    const port = try h.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    _ = try h.accept(&application, client, &clients, &observed, 0);
    const id = try h.open_child(&application, client, 0, .uni);
    const key = try h.key_for(&application, index, 0, id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, "cancel", 6, 0));
    const record = try h.await_data(&application, &clients, &observed, key, "cancel");
    try application.webtransport_stream_cancel(record.public_info.handle, 373);
    try h.peer_stop(&application, client, &clients, &observed, id, support.webtransport.application_error_to_http3(373));
    _ = try h.await_closed(&application, &clients, &observed, key);
    try testing.expectEqualDeep(streams.ErrorCode{ .application = 373 }, record.public_closed.?.code.?);
    try testing.expectEqual(@as(u64, 6), record.public_closed.?.accounted_bytes);
    try testing.expectEqual(@as(usize, 0), observed.session_closed_count);
    try h.healthy_http(&application, client, &clients, &observed);
}

test "public BIDI EOF retains its send half until explicit finish reaches the peer" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application, .finish_on_receive_terminal = false };
    const port = try h.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    _ = try h.accept(&application, client, &clients, &observed, 0);
    const id = try h.open_child(&application, client, 0, .bidi);
    const key = try h.key_for(&application, index, 0, id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, "half", 4, 1));
    const record = try await_eof(&application, &clients, &observed, key);
    try testing.expectEqualSlices(u8, "half", record.bytes[0..record.received]);
    try testing.expectEqual(@as(?u64, 4), record.eof_size);
    for (0..16) |_| try h.pump(&application, &clients, &observed);
    try testing.expect(record.closed == null);
    try testing.expectEqual(@as(c_uint, 0), (try h.response_snapshot(client, id)).fin_received);
    try application.webtransport_stream_finish(record.public_info.handle);
    try h.expect_completed(try h.await_closed(&application, &clients, &observed, key), "half");
    var peer_finished = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        const peer = try h.response_snapshot(client, id);
        if (peer.fin_received == 0) continue;
        try testing.expectEqual(@as(c_uint, 1), peer.fin_received);
        try testing.expectEqual(@as(usize, 0), peer.received);
        peer_finished = true;
        break;
    }
    try testing.expect(peer_finished);
    try testing.expectError(error.StaleHandle, application.webtransport_stream_finish(record.public_info.handle));
    try h.healthy_http(&application, client, &clients, &observed);
}

test "public stream routes retain their own context and report each session once" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var first: h.Observation = .{ .application = &application };
    var second: h.Observation = .{ .application = &application, .connect_path = "/other" };
    try application.enable_http3_ephemeral();
    _ = try application.webtransport_streams_context("/wt", &first, h.Consumer.callbacks);
    _ = try application.webtransport_streams_context("/other", &second, h.Consumer.callbacks);
    _ = try application.route_context(.connect, "/wt", &first, h.authorize);
    _ = try application.route_context(.connect, "/other", &second, h.authorize);
    _ = try application.route_context(.post, "/health", &first, h.health);
    try application.listen_udp("127.0.0.1", 0);
    const port = application.quic_transport.?.local_address.ip4.port;
    const a = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(a);
    const b = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(b);
    const clients = [_]*c.struct_uwz_app_client{ a, b };
    const ai = try h.handshake(&application, a, &clients, &first);
    const bi = try h.handshake(&application, b, &clients, &second);
    _ = try h.accept(&application, a, &clients, &first, 0);
    _ = try h.accept(&application, b, &clients, &second, 0);
    try testing.expectEqual(@as(usize, 1), first.session_count);
    try testing.expectEqual(@as(usize, 1), second.session_count);
    try testing.expect(!std.meta.eql(first.sessions[0].?.info.handle, second.sessions[0].?.info.handle));
    const aid = try h.open_child(&application, a, 0, .uni);
    const bid = try h.open_child(&application, b, 0, .uni);
    const ak = try h.key_for(&application, ai, 0, aid);
    const bk = try h.key_for(&application, bi, 0, bid);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(a, aid, "routeA", 6, 1));
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(b, bid, "routeB", 6, 1));
    const ar = try h.await_closed(&application, &clients, &first, ak);
    const br = try h.await_closed(&application, &clients, &second, bk);
    try h.expect_completed(ar, "routeA");
    try h.expect_completed(br, "routeB");
    try testing.expectEqual(@as(usize, 1), first.count);
    try testing.expectEqual(@as(usize, 1), second.count);
    try testing.expectEqualDeep(first.sessions[0].?.info.handle, ar.public_info.session);
    try testing.expectEqualDeep(second.sessions[0].?.info.handle, br.public_info.session);
    try testing.expectEqual(@as(usize, 0), first.session_closed_count);
    try testing.expectEqual(@as(usize, 0), second.session_closed_count);
    try h.finish_send(a, 0);
    try await_sessions(&application, &clients, &first, 1);
    try testing.expectEqual(@as(usize, 0), second.session_closed_count);
    try h.finish_send(b, 0);
    try await_sessions(&application, &clients, &second, 1);
    for (0..16) |_| try h.pump(&application, &clients, &first);
    try h.checked(&second);
    try testing.expectEqual(@as(usize, 1), first.session_closed_count);
    try testing.expectEqual(@as(usize, 1), second.session_closed_count);
    try h.healthy_http(&application, a, &clients, &first);
}

test "public BIDI reset retains sending until explicit finish produces peer FIN" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application, .finish_on_receive_terminal = false };
    const port = try h.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    _ = try h.accept(&application, client, &clients, &observed, 0);
    const id = try h.open_child(&application, client, 0, .bidi);
    const key = try h.key_for(&application, index, 0, id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, "reset-half", 10, 0));
    const record = try h.await_data(&application, &clients, &observed, key, "reset-half");
    const reset_code: u64 = (@as(u64, 1) << 62) - 19;
    try testing.expectEqual(support.webtransport_backend.ResetResult.ok, support.webtransport_backend.reset_stream(try h.native_client_stream(client, id), reset_code));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        if (record.reset_calls != 0) break;
    }
    try testing.expectEqual(@as(usize, 1), record.reset_calls);
    try testing.expectEqualDeep(streams.ErrorCode{ .http3 = reset_code }, record.public_reset_code.?);
    for (0..16) |_| try h.pump(&application, &clients, &observed);
    try testing.expect(record.closed == null);
    const before = try h.response_snapshot(client, id);
    try testing.expectEqual(@as(c_uint, 0), before.fin_received);
    try testing.expectEqual(@as(c_uint, 0), before.reset_events[0]);
    try application.webtransport_stream_finish(record.public_info.handle);
    _ = try h.await_closed(&application, &clients, &observed, key);
    try testing.expectEqual(streams.CloseReason.peer_reset, record.public_closed.?.reason);
    try testing.expectEqualDeep(streams.ErrorCode{ .http3 = reset_code }, record.public_closed.?.code.?);
    try testing.expectEqual(@as(?u64, 10), record.public_closed.?.final_payload_size);
    try testing.expectEqual(@as(u64, 10), record.public_closed.?.accounted_bytes);
    var peer_finished = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        const peer = try h.response_snapshot(client, id);
        try testing.expectEqual(@as(c_uint, 0), peer.reset_events[0]);
        if (peer.fin_received == 0) continue;
        try testing.expectEqual(@as(c_uint, 1), peer.fin_received);
        try testing.expectEqual(@as(usize, 0), peer.received);
        peer_finished = true;
        break;
    }
    try testing.expect(peer_finished);
    try testing.expectEqual(@as(usize, 0), record.eof_calls);
    try h.healthy_http(&application, client, &clients, &observed);
}

test "public stream generation exhaustion rejects admission without invalidating an owned handle" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application };
    const port = try h.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    _ = try h.accept(&application, client, &clients, &observed, 0);
    const id = try h.open_child(&application, client, 0, .bidi);
    const key = try h.key_for(&application, index, 0, id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, "retained", 8, 0));
    const record = try h.await_data(&application, &clients, &observed, key, "retained");
    const handle = record.public_info.handle;
    const engine = &application.quic_transport.?.engine;
    const active = engine.stream_pool.count_active();
    // This supplied Root-only counter seam leaves native protocol state untouched.
    engine.stream_generation = std.math.maxInt(u64);
    const rejected = try h.raw_uni(client, 0, "exhausted");
    try h.peer_stop(&application, client, &clients, &observed, rejected, support.webtransport.wt_buffered_stream_rejected);
    try testing.expectEqual(std.math.maxInt(u64), engine.stream_generation);
    try testing.expectEqual(active, engine.stream_pool.count_active());
    try testing.expectEqual(@as(usize, 0), engine.pending_child_count);
    try testing.expectEqual(@as(usize, 1), observed.count);
    try testing.expect(record.closed == null);
    try testing.expectEqualDeep(handle, record.public_info.handle);
    try application.webtransport_stream_finish(handle);
    var peer_finished = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        const peer = try h.response_snapshot(client, id);
        try testing.expectEqual(@as(c_uint, 0), peer.reset_events[0]);
        if (peer.fin_received == 0) continue;
        try testing.expectEqual(@as(usize, 0), peer.received);
        peer_finished = true;
        break;
    }
    try testing.expect(peer_finished);
    try testing.expect(record.closed == null);
    try h.finish_send(client, id);
    try h.expect_completed(try h.await_closed(&application, &clients, &observed, key), "retained");
    try testing.expectEqual(std.math.maxInt(u64), engine.stream_generation);
    try testing.expectEqual(@as(usize, 1), engine.stream_pool.count_active());
    try testing.expectEqual(@as(usize, 0), engine.pending_child_count);
    try testing.expectEqual(@as(usize, 0), engine.child_retry_count);
}
