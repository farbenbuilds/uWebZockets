const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const sessions = @import("session_observer.zig");
const child = support.webtransport_child_runtime;
const streams = support.public_api.webtransport_stream;
const testing = std.testing;

const config = support.config.default_config.with(.{
    .max_connections = 8,
    .max_h3_response_header_size = 16384,
});
pub const Application = support.builder.configured_builder(config).AppType;

/// Private facts are observed only to retain the inherited identity assertions.
pub const Record = struct {
    info: child.Info,
    public_info: streams.Info,
    public_closed: ?streams.ClosedEvent = null,
    public_reset_code: ?streams.ErrorCode = null,
    public_stop_code: ?streams.ErrorCode = null,
    bytes: [4096]u8 = @splat(0),
    received: usize = 0,
    data_calls: usize = 0,
    eof_calls: usize = 0,
    eof_size: ?u64 = null,
    reset_calls: usize = 0,
    reset_after_data_calls: usize = 0,
    reset_code: ?u64 = null,
    reset_size: ?u64 = null,
    stop_calls: usize = 0,
    stop_code: ?u64 = null,
    closed: ?child.ClosedEvent = null,
};

pub const SessionRecord = struct {
    info: streams.SessionInfo,
    closed: ?streams.SessionClosedEvent = null,
};

pub const Observation = struct {
    application: *Application,
    records: [32]?Record = @splat(null),
    sessions: [32]?SessionRecord = @splat(null),
    count: usize = 0,
    session_count: usize = 0,
    session_closed_count: usize = 0,
    authorization_calls: usize = 0,
    http_calls: usize = 0,
    datagram_calls: usize = 0,
    allow_open: bool = true,
    cancel_data: bool = false,
    request_cooldown: bool = false,
    cooldown_on_open: bool = false,
    cooldown_open_target: ?u64 = null,
    required_owned_sibling: ?u64 = null,
    owned_sibling_proven: bool = false,
    sibling_bytes_at_cooldown: usize = 0,
    sibling_calls_at_cooldown: usize = 0,
    abort_on_data: bool = false,
    abort_status: c_int = -1,
    reentry_returns: usize = 0,
    deferred_cooldown: bool = false,
    connect_path: [:0]const u8 = "/wt",
    finish_on_receive_terminal: bool = true,
    verify_open_not_ready: bool = false,
    cooldown_on_authorize: bool = false,
    open_not_ready_checks: usize = 0,
    failure: ?anyerror = null,
};

pub fn raw_error(code: streams.ErrorCode) u64 {
    return switch (code) {
        .application => |value| support.webtransport.application_error_to_http3(value),
        .http3 => |value| value,
    };
}

pub fn record_for_handle(observed: *Observation, handle: streams.Handle) !*Record {
    for (observed.records[0..observed.count]) |*slot| {
        if (std.meta.eql(slot.*.?.public_info.handle, handle)) return &slot.*.?;
    }
    return error.UnknownPublicHandle;
}

fn observe_info(observed: *Observation, info: streams.Info) !child.Info {
    const engine = &observed.application.quic_transport.?.engine;
    try testing.expect(info.handle.generation != 0);
    try testing.expect(engine.stream_pool.is_active(info.handle.index));
    const state = engine.stream_contexts[info.handle.index].child orelse return error.MissingPublicChild;
    const key = state.key orelse return error.MissingPublicParent;
    try testing.expectEqual(info.handle.index, key.location.index);
    try testing.expectEqual(info.handle.generation, key.location.generation);
    try testing.expectEqual(info.session_id, key.session_id);
    try testing.expectEqual(info.stream_id, key.stream_id);
    try testing.expectEqualStrings(@tagName(state.metadata.direction), @tagName(info.direction));
    try testing.expectEqualStrings("peer", @tagName(info.initiator));
    const connection = engine.connections.find(key.connection) orelse return error.MissingConsumerConnection;
    try testing.expectEqual(state.route.?, key.route);
    const parent = try sessions.snapshot(Application, observed.application, key.connection.index, key.session_id);
    try testing.expectEqualDeep(connection.handle, key.connection);
    try testing.expectEqualDeep(parent.handle, key.session);
    try testing.expect(parent.notice_published);
    const phase = parent.phase;
    try testing.expect(phase == .established or phase == .draining);
    try testing.expect(observed.authorization_calls > 0);
    var session_found = false;
    for (observed.sessions[0..observed.session_count]) |slot| {
        const current = slot.?;
        if (!std.meta.eql(current.info.handle, info.session)) continue;
        try testing.expectEqual(current.info.session_id, info.session_id);
        try testing.expect(current.closed == null);
        session_found = true;
    }
    try testing.expect(session_found);
    return .{
        .key = key,
        .route = state.route orelse return error.MissingConsumerRoute,
        .direction = state.metadata.direction,
        .receive_prefix_size = state.metadata.receive_prefix_size,
    };
}

fn consume_open(observed: *Observation, info: streams.Info) !bool {
    const private = try observe_info(observed, info);
    try testing.expect(observed.count < observed.records.len);
    for (observed.records[0..observed.count]) |slot| {
        try testing.expect(!std.meta.eql(slot.?.public_info.handle, info.handle));
    }
    observed.records[observed.count] = .{ .info = private, .public_info = info };
    observed.count += 1;
    if (observed.verify_open_not_ready) {
        try testing.expectError(error.NotReady, observed.application.webtransport_stream_cancel(info.handle, 37));
        try testing.expectError(error.NotReady, observed.application.webtransport_stream_finish(info.handle));
        observed.open_not_ready_checks += 1;
    }
    if (observed.cooldown_open_target == info.stream_id) {
        if (observed.required_owned_sibling) |id| {
            var found = false;
            for (observed.records[0..observed.count]) |slot| {
                const sibling = slot.?;
                if (sibling.public_info.stream_id != id or !std.meta.eql(sibling.public_info.session, info.session)) continue;
                const engine = &observed.application.quic_transport.?.engine;
                const state = engine.stream_contexts[sibling.public_info.handle.index].child orelse return error.MissingOwnedSibling;
                try testing.expect(sibling.closed == null);
                try testing.expect(state.consumer_owned and state.phase == .active);
                try testing.expect(sibling.eof_calls == 0 and sibling.reset_calls == 0 and sibling.stop_calls == 0);
                observed.sibling_bytes_at_cooldown = sibling.received;
                observed.sibling_calls_at_cooldown = sibling.data_calls;
                found = true;
            }
            try testing.expect(found);
            observed.owned_sibling_proven = true;
        }
    }
    return observed.allow_open;
}

fn opened(context: *anyopaque, info: streams.Info) bool {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const accepted = consume_open(observed, info) catch |err| {
        observed.failure = err;
        return false;
    };
    if (observed.cooldown_on_open and (observed.cooldown_open_target == null or observed.cooldown_open_target.? == info.stream_id)) {
        const engine = &observed.application.quic_transport.?.engine;
        engine.cooldown();
        observed.deferred_cooldown = engine.callback_depth > 0 and engine.cooldown_pending and !engine.in_cooldown;
    }
    return accepted;
}

fn consume_data(observed: *Observation, handle: streams.Handle, bytes: []const u8) !bool {
    const record = try record_for_handle(observed, handle);
    _ = try observe_info(observed, record.public_info);
    try testing.expect(record.closed == null);
    try testing.expect(record.eof_calls == 0 and record.reset_calls == 0);
    try testing.expect(bytes.len > 0 and bytes.len <= record.bytes.len - record.received);
    @memcpy(record.bytes[record.received..][0..bytes.len], bytes);
    record.received += bytes.len;
    record.data_calls += 1;
    const engine = &observed.application.quic_transport.?.engine;
    try testing.expect(engine.callback_depth > 0);
    engine.process();
    observed.reentry_returns += 1;
    if (observed.request_cooldown) {
        engine.cooldown();
        observed.deferred_cooldown = engine.callback_depth > 0 and engine.cooldown_pending and !engine.in_cooldown;
    }
    if (observed.abort_on_data) {
        const connection = engine.connections.find(record.info.key.connection) orelse return error.MissingConsumerConnection;
        c.lsquic_conn_abort(connection.native);
        observed.abort_status = @intCast(c.lsquic_conn_status(connection.native, null, 0));
    }
    return !observed.cancel_data;
}

fn data(context: *anyopaque, handle: streams.Handle, bytes: []const u8) bool {
    const observed: *Observation = @ptrCast(@alignCast(context));
    return consume_data(observed, handle, bytes) catch |err| {
        observed.failure = err;
        return false;
    };
}

fn finish_receive(observed: *Observation, record: *Record) void {
    if (!observed.finish_on_receive_terminal or record.public_info.direction != .bidi) return;
    if (record.stop_calls != 0) {
        testing.expectError(error.WriteClosed, observed.application.webtransport_stream_finish(record.public_info.handle)) catch |err| {
            observed.failure = err;
        };
        return;
    }
    observed.application.webtransport_stream_finish(record.public_info.handle) catch |err| {
        observed.failure = err;
    };
}

fn eof(context: *anyopaque, handle: streams.Handle, size: u64) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const record = record_for_handle(observed, handle) catch |err| {
        observed.failure = err;
        return;
    };
    if (record.eof_calls != 0 or record.reset_calls != 0) {
        observed.failure = error.DuplicateReceiveTerminal;
        return;
    }
    record.eof_calls += 1;
    record.eof_size = size;
    finish_receive(observed, record);
}

fn reset(context: *anyopaque, handle: streams.Handle, code: streams.ErrorCode, size: u64) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const record = record_for_handle(observed, handle) catch |err| {
        observed.failure = err;
        return;
    };
    if (record.eof_calls != 0 or record.reset_calls != 0) {
        observed.failure = error.DuplicateReceiveTerminal;
        return;
    }
    record.reset_calls += 1;
    record.reset_after_data_calls = record.data_calls;
    record.public_reset_code = code;
    record.reset_code = raw_error(code);
    record.reset_size = size;
    finish_receive(observed, record);
}

fn stop(context: *anyopaque, handle: streams.Handle, code: streams.ErrorCode) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const record = record_for_handle(observed, handle) catch |err| {
        observed.failure = err;
        return;
    };
    if (record.stop_calls != 0) {
        observed.failure = error.DuplicateSendingStop;
        return;
    }
    record.stop_calls += 1;
    record.public_stop_code = code;
    record.stop_code = raw_error(code);
}

fn closed(context: *anyopaque, event: streams.ClosedEvent) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const record = record_for_handle(observed, event.handle) catch |err| {
        observed.failure = err;
        return;
    };
    if (record.closed != null) {
        observed.failure = error.DuplicateConsumerClose;
        return;
    }
    const reason = std.meta.stringToEnum(child.CloseReason, @tagName(event.reason)) orelse {
        observed.failure = error.UnknownPublicCloseReason;
        return;
    };
    record.public_closed = event;
    record.closed = .{
        .key = record.info.key,
        .reason = reason,
        .code = if (event.code) |code| raw_error(code) else null,
        .final_payload_size = event.final_payload_size,
        .accounted_bytes = event.accounted_bytes,
    };
}

fn session_open(context: *anyopaque, info: streams.SessionInfo) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    if (observed.session_count == observed.sessions.len) {
        observed.failure = error.SessionObservationCapacity;
        return;
    }
    for (observed.sessions[0..observed.session_count]) |slot| {
        if (!std.meta.eql(slot.?.info.handle, info.handle)) continue;
        observed.failure = error.DuplicateSessionOpen;
        return;
    }
    observed.sessions[observed.session_count] = .{ .info = info };
    observed.session_count += 1;
}

fn session_closed(context: *anyopaque, event: streams.SessionClosedEvent) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const engine = &observed.application.quic_transport.?.engine;
    if (engine.session_index) |*index| {
        if (index.find(.{
            .connection = .{ .index = event.handle.connection_index, .generation = event.handle.connection_generation },
            .session_id = event.session_id,
        }) != null) {
            observed.failure = error.SessionIndexSurvivedClose;
            return;
        }
    }
    if (engine.stream_pool.is_active(event.handle.index)) {
        const parent = &engine.stream_contexts[event.handle.index];
        if (parent.generation == event.handle.generation and (parent.session_record != null or parent.state.session != null)) {
            observed.failure = error.SessionRecordSurvivedClose;
            return;
        }
    }
    for (observed.sessions[0..observed.session_count]) |*slot| {
        const current = &slot.*.?;
        if (!std.meta.eql(current.info.handle, event.handle)) continue;
        if (current.closed != null or current.info.session_id != event.session_id) {
            observed.failure = error.DuplicateSessionClose;
            return;
        }
        current.closed = event;
        observed.session_closed_count += 1;
        return;
    }
    observed.failure = error.UnknownSessionClose;
}

pub const callbacks: streams.Callbacks = .{
    .open = opened,
    .data = data,
    .eof = eof,
    .reset = reset,
    .stop = stop,
    .closed = closed,
    .session_open = session_open,
    .session_closed = session_closed,
};
