const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const h = @import("app_children.zig").ChildrenSupport;
const testing = std.testing;
const streams = h.Streams;

test "public session Close preserves application code before peer FIN" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application };
    const port = try h.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    _ = try h.handshake(&application, client, &clients, &observed);
    _ = try h.accept(&application, client, &clients, &observed, 0);
    try testing.expectEqual(@as(usize, 1), observed.session_count);
    const opened = observed.sessions[0].?.info;
    var capsule: [64]u8 = undefined;
    const size = try support.webtransport.encode_close_session(37, "public-close", &capsule);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, 0, &capsule, size, 0));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        if (observed.session_closed_count != 0) break;
    }
    try testing.expectEqual(@as(usize, 1), observed.session_closed_count);
    const event = observed.sessions[0].?.closed orelse return error.MissingPublicSessionClose;
    try testing.expectEqualDeep(opened.handle, event.handle);
    try testing.expectEqual(@as(u64, 0), event.session_id);
    try testing.expectEqual(streams.CloseReason.session_closed, event.reason);
    try testing.expectEqualDeep(streams.ErrorCode{ .application = 37 }, event.code.?);
    var native: c.struct_uwz_app_stream_diagnostics = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_stream_diagnose(try h.native_client_stream(client, 0), &native));
    try testing.expectEqual(@as(c_uint, 0), native.send_shutdown);
    try h.finish_send(client, 0);
    for (0..16) |_| try h.pump(&application, &clients, &observed);
    try testing.expectEqual(@as(usize, 1), observed.session_closed_count);
    try testing.expectEqual(@as(usize, 0), observed.count);
}

test "public session admission callback cooldown publishes no session" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: h.Observation = .{ .application = &application, .cooldown_on_authorize = true };
    const port = try h.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    _ = try h.handshake(&application, client, &clients, &observed);
    var request: c.struct_uwz_app_connect_request = .{
        .origin = "https://localhost",
        .authorization = "Bearer admission-fixture",
        .duplicate_origin = 0,
    };
    try testing.expectEqual(@as(u64, 0), c.uwz_app_client_open_connect(client, &request));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        if (observed.authorization_calls != 0) break;
    }
    try testing.expectEqual(@as(usize, 1), observed.authorization_calls);
    try testing.expect(observed.deferred_cooldown);
    const engine = &application.quic_transport.?.engine;
    try testing.expect(engine.children_shutdown);
    try testing.expect(!engine.cooldown_pending and !engine.in_cooldown and engine.callback_depth == 0);
    var drained = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        if (engine.stream_pool.count_active() != 0) continue;
        drained = true;
        break;
    }
    try testing.expect(drained);
    for (0..16) |_| try h.pump(&application, &clients, &observed);
    try testing.expectEqual(@as(usize, 0), observed.session_count);
    try testing.expectEqual(@as(usize, 0), observed.session_closed_count);
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expectEqual(@as(usize, 0), engine.pending_child_count);
    try testing.expectEqual(@as(usize, 0), engine.child_retry_count);
}
