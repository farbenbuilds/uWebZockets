const h = @import("app_children.zig").ChildrenSupport;
comptime {
    _ = h.Application.webtransport_stream_create;
}
