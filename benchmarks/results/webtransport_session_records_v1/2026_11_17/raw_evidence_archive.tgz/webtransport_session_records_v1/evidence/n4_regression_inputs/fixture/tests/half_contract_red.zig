const h = @import("app_children.zig").ChildrenSupport;

test "public local receive STOP and send RESET are callable" {
    _ = h.Application.webtransport_stream_stop;
    _ = h.Application.webtransport_stream_reset;
}
