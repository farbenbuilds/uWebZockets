comptime {
    _ = @import("children_main.zig");
    _ = @import("app_public_tx.zig");
    _ = @import("app_public_tx_wake.zig");
}
