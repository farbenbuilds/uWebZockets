const std = @import("std");
const admission = @import("builds/admission.zig");

pub fn build(b: *std.Build) void {
    admission.configure(b);
}
