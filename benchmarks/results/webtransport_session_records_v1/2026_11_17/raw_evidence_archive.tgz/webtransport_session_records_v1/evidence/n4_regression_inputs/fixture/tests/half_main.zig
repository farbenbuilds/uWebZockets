comptime {
    _ = @import("tx_main.zig");
    _ = @import("app_public_half.zig");
}
