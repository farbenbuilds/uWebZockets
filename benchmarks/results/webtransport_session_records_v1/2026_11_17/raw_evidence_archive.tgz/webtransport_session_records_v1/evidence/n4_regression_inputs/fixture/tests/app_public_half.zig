const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const h = @import("app_children.zig").ChildrenSupport;
const testing = std.testing;
const streams = h.Streams;
const backend = support.webtransport_backend;

const Observation = struct {
    base: h.Observation,
    verify_open: bool = true,
    stop_on_data: bool = false,
    reset_on_data: bool = false,
    reset_on_writable: bool = false,
    reset_in_data: usize = 0,
    operation_active: bool = false,
    open_checks: usize = 0,
    stopped_in_data: usize = 0,
    writable_calls: usize = 0,
};

fn opened(context: *anyopaque, info: streams.Info) bool {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const accepted = h.Consumer.callbacks.open(&observed.base, info);
    if (!accepted) return false;
    if (observed.verify_open) {
        opening_operations(observed, info.handle) catch |err| {
            observed.base.failure = err;
            return false;
        };
    }
    return true;
}

fn opening_operations(observed: *Observation, handle: streams.Handle) !void {
    try testing.expectError(error.NotReady, observed.base.application.webtransport_stream_stop(handle, 11));
    try testing.expectError(error.NotReady, observed.base.application.webtransport_stream_reset(handle, 12));
    observed.open_checks += 1;
}

fn received(context: *anyopaque, handle: streams.Handle, bytes: []const u8) bool {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const accepted = h.Consumer.callbacks.data.?(&observed.base, handle, bytes);
    if (!accepted) return false;
    if (observed.reset_on_data) {
        observed.base.application.webtransport_stream_reset(handle, 91) catch |err| {
            observed.base.failure = err;
            return false;
        };
        observed.reset_in_data += 1;
    }
    if (!observed.stop_on_data) return true;
    observed.base.application.webtransport_stream_stop(handle, 0xffff_ffff) catch |err| {
        observed.base.failure = err;
        return false;
    };
    observed.stopped_in_data += 1;
    return true;
}

fn eof(context: *anyopaque, handle: streams.Handle, size: u64) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    if (observed.operation_active) observed.base.failure = error.InlineNotification;
    h.Consumer.callbacks.eof.?(&observed.base, handle, size);
}

fn reset(context: *anyopaque, handle: streams.Handle, code: streams.ErrorCode, size: u64) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    if (observed.operation_active) observed.base.failure = error.InlineNotification;
    h.Consumer.callbacks.reset.?(&observed.base, handle, code, size);
}

fn stopped(context: *anyopaque, handle: streams.Handle, code: streams.ErrorCode) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    if (observed.operation_active) observed.base.failure = error.InlineNotification;
    h.Consumer.callbacks.stop.?(&observed.base, handle, code);
}

fn closed(context: *anyopaque, event: streams.ClosedEvent) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    if (observed.operation_active) observed.base.failure = error.InlineNotification;
    h.Consumer.callbacks.closed.?(&observed.base, event);
}

fn session_open(context: *anyopaque, info: streams.SessionInfo) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    h.Consumer.callbacks.session_open.?(&observed.base, info);
}

fn session_closed(context: *anyopaque, event: streams.SessionClosedEvent) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    h.Consumer.callbacks.session_closed.?(&observed.base, event);
}

fn writable(context: *anyopaque, handle: streams.Handle) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    if (observed.operation_active) observed.base.failure = error.InlineNotification;
    observed.writable_calls += 1;
    if (observed.reset_on_writable) {
        observed.base.application.webtransport_stream_reset(handle, 92) catch |err| {
            observed.base.failure = err;
        };
    }
}

const callbacks: streams.Callbacks = .{
    .open = opened,
    .data = received,
    .eof = eof,
    .reset = reset,
    .stop = stopped,
    .closed = closed,
    .writable = writable,
    .session_open = session_open,
    .session_closed = session_closed,
};

fn listen(application: *h.Application, observed: *Observation) !u16 {
    try application.enable_http3_ephemeral();
    _ = try application.webtransport_streams_context("/wt", observed, callbacks);
    _ = try application.route_context(.connect, "/wt", &observed.base, h.authorize);
    _ = try application.route_context(.post, "/health", &observed.base, h.health);
    try application.listen_udp("127.0.0.1", 0);
    return application.quic_transport.?.local_address.ip4.port;
}

fn admitted(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation, index: usize, direction: backend.Direction) !*h.Record {
    const clients = [_]*c.struct_uwz_app_client{client};
    _ = try h.accept(application, client, &clients, &observed.base, 0);
    const id = try h.open_child(application, client, 0, direction);
    const key = try h.key_for(application, index, 0, id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, "request", 7, 0));
    return h.await_data(application, &clients, &observed.base, key, "request");
}

fn await_peer_error(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation, id: u64, how: usize, code: u32) !void {
    const clients = [_]*c.struct_uwz_app_client{client};
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(application, &clients, &observed.base);
        const response = try h.response_snapshot(client, id);
        if (response.reset_events[how] == 0) continue;
        try testing.expectEqual(@as(c_uint, 1), response.reset_events[how]);
        try testing.expectEqual(@as(c_int, c.LSQUIC_SERR_AVAILABLE), response.reset_error_status[how]);
        try testing.expectEqual(support.webtransport.application_error_to_http3(code), response.reset_error_code[how]);
        return;
    }
    return error.PeerHalfErrorTimeout;
}

fn await_peer_fin(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation, id: u64, bytes: []const u8) !void {
    const clients = [_]*c.struct_uwz_app_client{client};
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(application, &clients, &observed.base);
        const response = try h.response_snapshot(client, id);
        if (response.fin_received == 0) continue;
        try testing.expectEqualSlices(u8, bytes, response.bytes[0..response.received]);
        try testing.expectEqual(@as(c_uint, 0), response.reset_events[0]);
        return;
    }
    return error.PeerHalfFinTimeout;
}

fn expect_rx_silent(record: *const h.Record, bytes: []const u8) !void {
    try testing.expectEqualSlices(u8, bytes, record.bytes[0..record.received]);
    try testing.expectEqual(@as(usize, 0), record.eof_calls);
    try testing.expectEqual(@as(usize, 0), record.reset_calls);
}

test "public local STOP abandons RX and preserves binary TX through FIN" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted(&application, client, &observed, index, .bidi);
    const handle = record.public_info.handle;
    observed.operation_active = true;
    try application.webtransport_stream_stop(handle, 0xffff_ffff);
    try application.webtransport_stream_stop(handle, 0xffff_ffff);
    try testing.expectError(error.ConflictingIntent, application.webtransport_stream_stop(handle, 0));
    const bytes = [_]u8{ 0, 0xff, 's', 't', 'o', 'p', 0xfe };
    try testing.expectEqual(bytes.len, try application.webtransport_stream_write(handle, &bytes));
    try application.webtransport_stream_finish(handle);
    observed.operation_active = false;
    try await_peer_error(&application, client, &observed, record.info.key.stream_id, 1, 0xffff_ffff);
    try await_peer_fin(&application, client, &observed, record.info.key.stream_id, &bytes);
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try expect_rx_silent(record, "request");
    try testing.expectEqual(@as(?u64, 7), record.public_closed.?.final_payload_size);
    try testing.expectEqual(@as(u64, 7), record.public_closed.?.accounted_bytes);
    try testing.expectEqual(@as(usize, 1), observed.open_checks);
    try testing.expectEqual(@as(usize, 0), observed.writable_calls);
    try h.healthy_http(&application, client, &clients, &observed.base);
}

test "public local RESET preserves RX and prevents writes FIN and writable callbacks" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted(&application, client, &observed, index, .bidi);
    const handle = record.public_info.handle;
    try application.webtransport_stream_want_writable(handle, true);
    observed.operation_active = true;
    try application.webtransport_stream_reset(handle, 0);
    try application.webtransport_stream_reset(handle, 0);
    try testing.expectError(error.ConflictingIntent, application.webtransport_stream_reset(handle, 1));
    try testing.expectError(error.WriteClosed, application.webtransport_stream_write(handle, "late"));
    try testing.expectError(error.WriteClosed, application.webtransport_stream_finish(handle));
    try testing.expectError(error.WriteClosed, application.webtransport_stream_want_writable(handle, true));
    try application.webtransport_stream_want_writable(handle, false);
    observed.operation_active = false;
    try await_peer_error(&application, client, &observed, record.info.key.stream_id, 0, 0);
    try testing.expect(record.closed == null);
    const extra = [_]u8{ 0xff, 0, 0xfe, 'r', 'x' };
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, record.info.key.stream_id, &extra, extra.len, 1));
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try testing.expectEqualSlices(u8, "request" ++ extra, record.bytes[0..record.received]);
    try testing.expectEqual(@as(usize, 1), record.eof_calls);
    try testing.expectEqual(@as(?u64, 7 + extra.len), record.eof_size);
    try testing.expectEqual(@as(usize, 0), record.reset_calls);
    try testing.expectEqual(@as(usize, 0), record.stop_calls);
    try testing.expectEqual(@as(usize, 0), observed.writable_calls);
    try h.healthy_http(&application, client, &clients, &observed.base);
}

test "public independent STOP and RESET retain different first codes through whole cancel" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted(&application, client, &observed, index, .bidi);
    const handle = record.public_info.handle;
    observed.operation_active = true;
    try application.webtransport_stream_stop(handle, 42);
    try application.webtransport_stream_reset(handle, 43);
    try application.webtransport_stream_cancel(handle, 44);
    try application.webtransport_stream_cancel(handle, 44);
    try testing.expectError(error.ConflictingIntent, application.webtransport_stream_cancel(handle, 45));
    observed.operation_active = false;
    try await_peer_error(&application, client, &observed, record.info.key.stream_id, 1, 42);
    try await_peer_error(&application, client, &observed, record.info.key.stream_id, 0, 43);
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try expect_rx_silent(record, "request");
    try testing.expectEqualDeep(streams.ErrorCode{ .application = 44 }, record.public_closed.?.code.?);
    try testing.expectEqual(streams.CloseReason.consumer_cancelled, record.public_closed.?.reason);
    try testing.expectEqual(@as(usize, 0), application.quic_transport.?.engine.child_retry_count);
    try h.healthy_http(&application, client, &clients, &observed.base);
}

fn fail_wake(_: *anyopaque) error{WakeFailed}!void {
    return error.WakeFailed;
}

test "public half-control wake failure leaves native state and all intents unchanged" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted(&application, client, &observed, index, .bidi);
    const handle = record.public_info.handle;
    const engine = &application.quic_transport.?.engine;
    const context = &engine.stream_contexts[handle.index];
    const before_actions = context.child_actions;
    const before_state = context.child;
    const before_tx = context.transmit;
    var before_native: c.struct_uwz_app_stream_diagnostics = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_stream_diagnose(try h.native_server_stream(&application, index, record.info.key.stream_id), &before_native));
    const original = engine.binding.?.wake;
    defer engine.binding.?.wake = original;
    engine.binding.?.wake = fail_wake;
    try testing.expectError(error.WakeFailed, application.webtransport_stream_stop(handle, 51));
    try testing.expectError(error.WakeFailed, application.webtransport_stream_reset(handle, 52));
    try testing.expectEqualDeep(before_actions, context.child_actions);
    try testing.expectEqualDeep(before_state, context.child);
    try testing.expectEqualDeep(before_tx, context.transmit);
    var after_native: c.struct_uwz_app_stream_diagnostics = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_stream_diagnose(try h.native_server_stream(&application, index, record.info.key.stream_id), &after_native));
    try testing.expectEqualDeep(before_native, after_native);
    engine.binding.?.wake = original;
    try application.webtransport_stream_stop(handle, 51);
    try application.webtransport_stream_reset(handle, 52);
    engine.binding.?.wake = fail_wake;
    try application.webtransport_stream_stop(handle, 51);
    try application.webtransport_stream_reset(handle, 52);
    try testing.expectError(error.ConflictingIntent, application.webtransport_stream_stop(handle, 53));
    try testing.expectError(error.ConflictingIntent, application.webtransport_stream_reset(handle, 53));
    engine.binding.?.wake = original;
    try await_peer_error(&application, client, &observed, record.info.key.stream_id, 1, 51);
    try await_peer_error(&application, client, &observed, record.info.key.stream_id, 0, 52);
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try h.healthy_http(&application, client, &clients, &observed.base);
}

test "public half controls reject wrong owner stale handles and RESET on peer UNI" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted(&application, client, &observed, index, .uni);
    const handle = record.public_info.handle;
    try testing.expectError(error.WriteClosed, application.webtransport_stream_reset(handle, 61));
    var invalid = [_]streams.Handle{ handle, handle, handle, handle };
    invalid[0].owner += 1;
    invalid[1].index = std.math.maxInt(usize);
    invalid[2].generation = 0;
    invalid[3].generation += 1;
    try testing.expectError(error.WrongApp, application.webtransport_stream_stop(invalid[0], 61));
    try testing.expectError(error.WrongApp, application.webtransport_stream_reset(invalid[0], 61));
    for (invalid[1..]) |stale| {
        try testing.expectError(error.StaleHandle, application.webtransport_stream_stop(stale, 61));
        try testing.expectError(error.StaleHandle, application.webtransport_stream_reset(stale, 61));
    }
    try application.webtransport_stream_stop(handle, 61);
    try await_peer_error(&application, client, &observed, record.info.key.stream_id, 1, 61);
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try expect_rx_silent(record, "request");
    try testing.expectError(error.StaleHandle, application.webtransport_stream_stop(handle, 61));
    try testing.expectError(error.StaleHandle, application.webtransport_stream_reset(handle, 61));
    try h.healthy_http(&application, client, &clients, &observed.base);
}

test "public RESET cannot replace an accepted FIN while RX continues" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted(&application, client, &observed, index, .bidi);
    try application.webtransport_stream_finish(record.public_info.handle);
    try testing.expectError(error.WriteClosed, application.webtransport_stream_reset(record.public_info.handle, 71));
    try await_peer_fin(&application, client, &observed, record.info.key.stream_id, "");
    try testing.expect(record.closed == null);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, record.info.key.stream_id, "after", 5, 1));
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try testing.expectEqualSlices(u8, "requestafter", record.bytes[0..record.received]);
    try testing.expectEqual(@as(usize, 1), record.eof_calls);
    try h.healthy_http(&application, client, &clients, &observed.base);
}

fn stage_prebuffer(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation, index: usize, bytes: *const [3072]u8) !u64 {
    const clients = [_]*c.struct_uwz_app_client{client};
    const id = try h.raw_uni(client, 0, "");
    try h.await_pending_native(application, &clients, &observed.base, index, id, 0);
    {
        const native = try h.native_client_stream(client, id);
        try testing.expectEqual(@as(isize, bytes.len), c.lsquic_stream_write(native, bytes, bytes.len));
        try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_shutdown(native, 1));
    }
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(application, &clients, &observed.base);
        const native = try h.native_server_stream(application, index, id);
        var received_state: backend.ReceiveSnapshot = .{};
        try testing.expectEqual(backend.QueryResult.ok, backend.read_receive(native, &received_state));
        if (c.uwz_app_stream_buffered_bytes(native) != bytes.len or !received_state.fin_received) continue;
        _ = try h.waiting_state(application, index, id);
        try testing.expectEqual(@as(usize, 0), observed.base.count);
        return id;
    }
    return error.StopCallbackPrebufferTimeout;
}

test "public reentrant STOP suppresses the next prebuffered RX chunk and retains final accounting" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false }, .stop_on_data = true };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    var bytes: [3072]u8 = undefined;
    for (&bytes, 0..) |*byte, offset| byte.* = @truncate(offset * 29);
    const id = try stage_prebuffer(&application, client, &observed, index, &bytes);
    _ = try h.accept(&application, client, &clients, &observed.base, 0);
    const key = try h.key_for(&application, index, 0, id);
    const record = try h.await_closed(&application, &clients, &observed.base, key);
    try testing.expectEqual(@as(usize, 1), observed.stopped_in_data);
    try testing.expectEqual(@as(usize, 1), record.data_calls);
    try expect_rx_silent(record, bytes[0..2048]);
    try testing.expectEqual(@as(?u64, bytes.len), record.public_closed.?.final_payload_size);
    try testing.expectEqual(@as(u64, bytes.len), record.public_closed.?.accounted_bytes);
    try h.healthy_http(&application, client, &clients, &observed.base);
}

test "public STOP after receive EOF preserves completed RX and live TX" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted(&application, client, &observed, index, .bidi);
    try h.finish_send(client, record.info.key.stream_id);
    var ended = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed.base);
        if (record.eof_calls != 1) continue;
        ended = true;
        break;
    }
    try testing.expect(ended and record.closed == null);
    try application.webtransport_stream_stop(record.public_info.handle, 81);
    try application.webtransport_stream_stop(record.public_info.handle, 81);
    try testing.expectError(error.ConflictingIntent, application.webtransport_stream_stop(record.public_info.handle, 82));
    try testing.expectEqual(@as(usize, 5), try application.webtransport_stream_write(record.public_info.handle, "after"));
    try application.webtransport_stream_finish(record.public_info.handle);
    try await_peer_fin(&application, client, &observed, record.info.key.stream_id, "after");
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try testing.expectEqual(@as(usize, 1), record.eof_calls);
    try testing.expectEqual(@as(usize, 0), record.reset_calls);
    try testing.expectEqual(@as(?u64, 7), record.public_closed.?.final_payload_size);
    try h.healthy_http(&application, client, &clients, &observed.base);
}

fn reentrant_reset_case(from_writable: bool) !void {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{
        .base = .{ .application = &application, .finish_on_receive_terminal = false },
        .reset_on_data = !from_writable,
        .reset_on_writable = from_writable,
    };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted(&application, client, &observed, index, .bidi);
    if (from_writable) try application.webtransport_stream_want_writable(record.public_info.handle, true);
    try await_peer_error(&application, client, &observed, record.info.key.stream_id, 0, if (from_writable) 92 else 91);
    try testing.expect(record.closed == null);
    try testing.expectEqual(@as(usize, @intFromBool(from_writable)), observed.writable_calls);
    try testing.expectEqual(@as(usize, @intFromBool(!from_writable)), observed.reset_in_data);
    observed.reset_on_data = false;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, record.info.key.stream_id, "after", 5, 1));
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try testing.expectEqualSlices(u8, "requestafter", record.bytes[0..record.received]);
    try testing.expectEqual(@as(usize, 1), record.eof_calls);
    try testing.expectEqual(@as(usize, 0), record.reset_calls);
    try testing.expectEqual(@as(usize, 0), application.quic_transport.?.engine.child_retry_count);
    try h.healthy_http(&application, client, &clients, &observed.base);
}

test "public RESET from data callback leaves later receive bytes live" {
    try reentrant_reset_case(false);
}

test "public RESET from writable callback disarms interest and leaves receiving live" {
    try reentrant_reset_case(true);
}

test "public local STOP still delivers an independent peer STOP notification" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted(&application, client, &observed, index, .bidi);
    try application.webtransport_stream_stop(record.public_info.handle, 101);
    // Both commands precede pumping; the peer cannot finish our receive half first.
    try testing.expectEqual(backend.StopResult.ok, backend.stop_receiving(try h.native_client_stream(client, record.info.key.stream_id), support.webtransport.application_error_to_http3(102)));
    try await_peer_error(&application, client, &observed, record.info.key.stream_id, 1, 101);
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try expect_rx_silent(record, "request");
    try testing.expectEqual(@as(usize, 1), record.stop_calls);
    try testing.expectEqualDeep(streams.ErrorCode{ .application = 102 }, record.public_stop_code.?);
    try h.healthy_http(&application, client, &clients, &observed.base);
}

test "public RESET reports native closed without accepting a replacement error" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted(&application, client, &observed, index, .bidi);
    try testing.expectEqual(backend.StopResult.ok, backend.stop_receiving(try h.native_client_stream(client, record.info.key.stream_id), support.webtransport.application_error_to_http3(112)));
    var notified = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed.base);
        if (record.stop_calls != 1) continue;
        notified = true;
        break;
    }
    try testing.expect(notified and record.closed == null);
    try testing.expectError(error.WriteClosed, application.webtransport_stream_reset(record.public_info.handle, 113));
    try testing.expectError(error.WriteClosed, application.webtransport_stream_reset(record.public_info.handle, 114));
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, record.info.key.stream_id, "after", 5, 1));
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try testing.expectEqualSlices(u8, "requestafter", record.bytes[0..record.received]);
    try testing.expectEqual(@as(usize, 1), record.eof_calls);
    try testing.expectEqual(@as(usize, 0), record.reset_calls);
    try h.healthy_http(&application, client, &clients, &observed.base);
}

fn cancel_remaining_half_case(stop_first: bool) !void {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted(&application, client, &observed, index, .bidi);
    const handle = record.public_info.handle;
    if (stop_first) {
        try application.webtransport_stream_stop(handle, 121);
    } else {
        try application.webtransport_stream_reset(handle, 122);
    }
    try application.webtransport_stream_cancel(handle, 123);
    try await_peer_error(&application, client, &observed, record.info.key.stream_id, 1, if (stop_first) 121 else 123);
    try await_peer_error(&application, client, &observed, record.info.key.stream_id, 0, if (stop_first) 123 else 122);
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try testing.expectEqualDeep(streams.ErrorCode{ .application = 123 }, record.public_closed.?.code.?);
    try testing.expectEqual(streams.CloseReason.consumer_cancelled, record.public_closed.?.reason);
    try testing.expectEqual(@as(usize, 0), application.quic_transport.?.engine.child_retry_count);
    try h.healthy_http(&application, client, &clients, &observed.base);
}

test "public whole cancel preserves prior STOP and fills only the missing RESET intent" {
    try cancel_remaining_half_case(true);
}

test "public whole cancel preserves prior RESET and fills only the missing STOP intent" {
    try cancel_remaining_half_case(false);
}
