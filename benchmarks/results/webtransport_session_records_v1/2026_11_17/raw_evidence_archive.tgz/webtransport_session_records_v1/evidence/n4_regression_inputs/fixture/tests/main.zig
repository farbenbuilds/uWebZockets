test {
    _ = @import("app_admission.zig");
    _ = @import("app_routing.zig");
    _ = @import("app_pending.zig");
}
