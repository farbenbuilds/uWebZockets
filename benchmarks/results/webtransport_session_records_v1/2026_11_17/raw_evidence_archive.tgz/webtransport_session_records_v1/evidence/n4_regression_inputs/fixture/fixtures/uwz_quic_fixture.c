/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <sys/queue.h>

#include <openssl/evp.h>
#include <openssl/rsa.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>

#include "lsquic.h"
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_packet_in.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"
#include "uwz_quic_fixture.h"

#ifdef NDEBUG
#error "uwz_quic_fixture requires active assertions"
#endif

/* The engine exposes one process-wide OS clock without a context parameter. */
static lsquic_time_t fixture_clock = 1000000;

/* Constructor/hash entry points have no allocator context; only the armed
 * synchronous API call consumes these process-wide one-shot fault switches. */
static unsigned fail_stream_new;
static unsigned fail_hash_insert;

extern lsquic_stream_t *
lsquic_real_stream_new (lsquic_stream_id_t, struct lsquic_conn_public *,
    const struct lsquic_stream_if *, void *, unsigned, uint64_t,
    enum stream_ctor_flags);

extern struct lsquic_hash_elem *
lsquic_real_hash_insert (struct lsquic_hash *, const void *, unsigned,
                        void *, struct lsquic_hash_elem *);


lsquic_stream_t *
lsquic_stream_new (lsquic_stream_id_t id, struct lsquic_conn_public *conn_pub,
    const struct lsquic_stream_if *callbacks, void *ctx, unsigned receive_window,
    uint64_t send_offset, enum stream_ctor_flags flags)
{
    if (fail_stream_new)
    {
        --fail_stream_new;
        return NULL;
    }
    return lsquic_real_stream_new(id, conn_pub, callbacks, ctx,
                                 receive_window, send_offset, flags);
}


struct lsquic_hash_elem *
lsquic_hash_insert (struct lsquic_hash *hash, const void *key, unsigned key_size,
                   void *value, struct lsquic_hash_elem *element)
{
    if (fail_hash_insert)
    {
        --fail_hash_insert;
        return NULL;
    }
    return lsquic_real_hash_insert(hash, key, key_size, value, element);
}


lsquic_time_t
__wrap_lsquic_time_now (void)
{
    return fixture_clock;
}


static int
select_alpn (SSL *UNUSED_ssl, const unsigned char **selected,
             unsigned char *selected_size, const unsigned char *offered,
             unsigned offered_size, void *ctx)
{
    const char *alpn = ctx;
    unsigned offset = 0;
    unsigned size;

    while (offset < offered_size)
    {
        size = offered[offset++];
        if (size > offered_size - offset)
            return SSL_TLSEXT_ERR_ALERT_FATAL;
        if (size == strlen(alpn)
            && 0 == memcmp(offered + offset, alpn, size))
        {
            *selected = offered + offset;
            *selected_size = size;
            return SSL_TLSEXT_ERR_OK;
        }
        offset += size;
    }
    return SSL_TLSEXT_ERR_ALERT_FATAL;
}


SSL_CTX *
lsquic_test_tls_context_new (unsigned server, const char *alpn)
{
    SSL_CTX *ctx;
    EVP_PKEY_CTX *key_context;
    EVP_PKEY *key = NULL;
    X509 *certificate;
    X509_NAME *name;

    if (!alpn || !alpn[0] || strlen(alpn) > UCHAR_MAX)
    {
        errno = EINVAL;
        return NULL;
    }
    ctx = SSL_CTX_new(TLS_method());
    assert(ctx);
    assert(SSL_CTX_set_min_proto_version(ctx, TLS1_3_VERSION));
    assert(SSL_CTX_set_max_proto_version(ctx, TLS1_3_VERSION));
    SSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, NULL);
    if (!server)
        return ctx;

    key_context = EVP_PKEY_CTX_new_id(EVP_PKEY_RSA, NULL);
    assert(key_context);
    assert(1 == EVP_PKEY_keygen_init(key_context));
    assert(1 == EVP_PKEY_CTX_set_rsa_keygen_bits(key_context, 2048));
    assert(1 == EVP_PKEY_keygen(key_context, &key));
    certificate = X509_new();
    assert(certificate);
    assert(1 == X509_set_version(certificate, 2));
    assert(1 == ASN1_INTEGER_set(X509_get_serialNumber(certificate), 1));
    assert(1 == ASN1_TIME_set_string(X509_get_notBefore(certificate),
                                   "20260101000000Z"));
    assert(1 == ASN1_TIME_set_string(X509_get_notAfter(certificate),
                                   "20300101000000Z"));
    assert(1 == X509_set_pubkey(certificate, key));
    name = X509_get_subject_name(certificate);
    assert(1 == X509_NAME_add_entry_by_txt(name, "CN", MBSTRING_ASC,
                            (const unsigned char *) "localhost", -1, -1, 0));
    assert(1 == X509_set_issuer_name(certificate, name));
    assert(X509_sign(certificate, key, EVP_sha256()) > 0);
    assert(1 == SSL_CTX_use_certificate(ctx, certificate));
    assert(1 == SSL_CTX_use_PrivateKey(ctx, key));
    assert(1 == SSL_CTX_check_private_key(ctx));
    SSL_CTX_set_alpn_select_cb(ctx, select_alpn, (void *) alpn);
    X509_free(certificate);
    EVP_PKEY_free(key);
    EVP_PKEY_CTX_free(key_context);
    return ctx;
}


static SSL_CTX *
get_tls_context (void *ctx, const struct sockaddr *UNUSED_local)
{
    struct lsquic_test_endpoint *endpoint = ctx;

    return endpoint->lte_tls;
}


static SSL_CTX *
lookup_certificate (void *ctx, const struct sockaddr *UNUSED_local,
                    const char *UNUSED_sni)
{
    struct lsquic_test_endpoint *endpoint = ctx;

    return endpoint->lte_tls;
}


static int
queue_packets (void *ctx, const struct lsquic_out_spec *specs, unsigned count)
{
    struct lsquic_test_endpoint *endpoint = ctx;
    struct lsquic_test_queue *queue = &endpoint->lte_peer->lte_incoming;
    struct lsquic_test_packet *packet;
    unsigned index, iov_index;
    size_t offset;

    for (index = 0; index < count; ++index)
    {
        if (queue->ltq_count == LSQUIC_TEST_MAX_PACKETS)
        {
            errno = EAGAIN;
            return index;
        }
        packet = &queue->ltq_packets[(queue->ltq_head + queue->ltq_count)
                                                    % LSQUIC_TEST_MAX_PACKETS];
        offset = 0;
        for (iov_index = 0; iov_index < specs[index].iovlen; ++iov_index)
        {
            if (specs[index].iov[iov_index].iov_len
                                        > LSQUIC_TEST_MAX_DATAGRAM - offset)
            {
                errno = EMSGSIZE;
                return index;
            }
            memcpy(packet->ltp_bytes + offset,
                   specs[index].iov[iov_index].iov_base,
                   specs[index].iov[iov_index].iov_len);
            offset += specs[index].iov[iov_index].iov_len;
        }
        if (offset == 0)
        {
            errno = EINVAL;
            return index;
        }
        packet->ltp_size = offset;
        ++queue->ltq_count;
        ++endpoint->lte_packets_sent;
    }
    return count;
}


int
lsquic_test_endpoint_init (struct lsquic_test_endpoint *endpoint,
    struct lsquic_test_endpoint *peer,
    const struct lsquic_test_endpoint_config *config, uint16_t port)
{
    struct lsquic_engine_api api;

    if (!endpoint || !peer || endpoint == peer || !config || !config->ltec_tls
        || !config->ltec_settings || !config->ltec_stream_if
        || !config->ltec_alpn || !config->ltec_alpn[0]
        || strlen(config->ltec_alpn) > UCHAR_MAX)
    {
        errno = EINVAL;
        return -1;
    }
    memset(endpoint, 0, sizeof(*endpoint));
    if (SSL_CTX_up_ref(config->ltec_tls) != 1)
    {
        errno = ENOMEM;
        return -1;
    }
    endpoint->lte_tls = config->ltec_tls;
    endpoint->lte_peer = peer;
    endpoint->lte_address.sin_family = AF_INET;
    endpoint->lte_address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    endpoint->lte_address.sin_port = htons(port);
    memset(&api, 0, sizeof(api));
    api.ea_settings = config->ltec_settings;
    api.ea_stream_if = config->ltec_stream_if;
    api.ea_stream_if_ctx = config->ltec_stream_if_ctx;
    api.ea_hsi_if = config->ltec_hsi_if;
    api.ea_hsi_ctx = config->ltec_hsi_ctx;
    api.ea_packets_out = queue_packets;
    api.ea_packets_out_ctx = endpoint;
    api.ea_lookup_cert = lookup_certificate;
    api.ea_cert_lu_ctx = endpoint;
    api.ea_get_ssl_ctx = get_tls_context;
    api.ea_alpn = config->ltec_alpn;
    endpoint->lte_engine = lsquic_engine_new(config->ltec_flags, &api);
    if (!endpoint->lte_engine)
    {
        SSL_CTX_free(endpoint->lte_tls);
        endpoint->lte_tls = NULL;
        return -1;
    }
    return 0;
}


void
lsquic_test_endpoint_destroy (struct lsquic_test_endpoint *endpoint)
{
    if (endpoint->lte_engine)
    {
        lsquic_engine_destroy(endpoint->lte_engine);
        endpoint->lte_engine = NULL;
    }
    SSL_CTX_free(endpoint->lte_tls);
    endpoint->lte_tls = NULL;
}


void
lsquic_test_pair_process (struct lsquic_test_pair *pair, uint64_t advance_us)
{
    assert(pair);
    assert(advance_us <= UINT64_MAX - fixture_clock);
    fixture_clock += advance_us;
    if (pair->ltp_client.lte_engine)
        lsquic_engine_process_conns(pair->ltp_client.lte_engine);
    if (pair->ltp_server.lte_engine)
        lsquic_engine_process_conns(pair->ltp_server.lte_engine);
}


int
lsquic_test_packet_take (struct lsquic_test_endpoint *endpoint,
                        unsigned index, struct lsquic_test_packet *out)
{
    struct lsquic_test_queue *queue;
    unsigned offset;

    if (!endpoint || !out || index >= endpoint->lte_incoming.ltq_count)
    {
        errno = EINVAL;
        return -1;
    }
    queue = &endpoint->lte_incoming;
    *out = queue->ltq_packets[(queue->ltq_head + index)
                                                   % LSQUIC_TEST_MAX_PACKETS];
    if (index == 0)
        queue->ltq_head = (queue->ltq_head + 1) % LSQUIC_TEST_MAX_PACKETS;
    else
        for (offset = index; offset + 1 < queue->ltq_count; ++offset)
            queue->ltq_packets[(queue->ltq_head + offset) % LSQUIC_TEST_MAX_PACKETS]
                = queue->ltq_packets[(queue->ltq_head + offset + 1)
                                                   % LSQUIC_TEST_MAX_PACKETS];
    --queue->ltq_count;
    return 0;
}


int
lsquic_test_packet_deliver (struct lsquic_test_endpoint *endpoint,
                          const struct lsquic_test_packet *packet)
{
    int result;

    if (!endpoint || !endpoint->lte_engine || !endpoint->lte_peer || !packet
        || packet->ltp_size == 0 || packet->ltp_size > LSQUIC_TEST_MAX_DATAGRAM)
    {
        errno = EINVAL;
        return -1;
    }
    result = lsquic_engine_packet_in(endpoint->lte_engine, packet->ltp_bytes,
                packet->ltp_size, (struct sockaddr *) &endpoint->lte_address,
                (struct sockaddr *) &endpoint->lte_peer->lte_address,
                endpoint, 0);
    if (result >= 0)
        ++endpoint->lte_packets_received;
    return result;
}


void
lsquic_test_deliver_all (struct lsquic_test_endpoint *endpoint)
{
    struct lsquic_test_packet packet;
    unsigned count = endpoint->lte_incoming.ltq_count;
    unsigned index;

    for (index = 0; index < count; ++index)
    {
        assert(0 == lsquic_test_packet_take(endpoint, 0, &packet));
        assert(lsquic_test_packet_deliver(endpoint, &packet) >= 0);
    }
}


void
lsquic_test_fail_next_stream_new (void)
{
    assert(fail_stream_new == 0);
    fail_stream_new = 1;
}


void
lsquic_test_fail_next_hash_insert (void)
{
    assert(fail_hash_insert == 0);
    fail_hash_insert = 1;
}


unsigned
lsquic_test_stream_new_failures_pending (void)
{
    return fail_stream_new;
}


unsigned
lsquic_test_hash_insert_failures_pending (void)
{
    return fail_hash_insert;
}


