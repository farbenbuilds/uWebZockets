/* Copyright (c) 2026 uWebZockets contributors.  See LICENSE. */
#ifndef UWZ_QUIC_FIXTURE_H
#define UWZ_QUIC_FIXTURE_H

#include <stddef.h>
#include <stdint.h>
#include <netinet/in.h>

struct lsquic_engine;
struct lsquic_engine_settings;
struct lsquic_stream_if;
struct lsquic_hset_if;
struct ssl_ctx_st;

enum {
    LSQUIC_TEST_MAX_DATAGRAM = 4096,
    LSQUIC_TEST_MAX_PACKETS = 256,
};

struct lsquic_test_packet {
    size_t ltp_size;
    unsigned char ltp_bytes[LSQUIC_TEST_MAX_DATAGRAM];
};

struct lsquic_test_queue {
    unsigned ltq_head;
    unsigned ltq_count;
    struct lsquic_test_packet ltq_packets[LSQUIC_TEST_MAX_PACKETS];
};

struct lsquic_test_endpoint {
    struct lsquic_engine *lte_engine;
    struct ssl_ctx_st *lte_tls;
    struct lsquic_test_endpoint *lte_peer;
    struct sockaddr_in lte_address;
    struct lsquic_test_queue lte_incoming;
    unsigned lte_packets_sent;
    unsigned lte_packets_received;
};

struct lsquic_test_pair {
    struct lsquic_test_endpoint ltp_client;
    struct lsquic_test_endpoint ltp_server;
};

struct lsquic_test_endpoint_config {
    unsigned ltec_flags;
    const struct lsquic_engine_settings *ltec_settings;
    const struct lsquic_stream_if *ltec_stream_if;
    void *ltec_stream_if_ctx;
    const char *ltec_alpn;
    struct ssl_ctx_st *ltec_tls;
    const struct lsquic_hset_if *ltec_hsi_if;
    void *ltec_hsi_ctx;
};

/* The caller owns the returned reference and chooses its verification policy. */
struct ssl_ctx_st *
lsquic_test_tls_context_new (unsigned server, const char *alpn);

/* Retains one supplied TLS-context reference without changing its policy. */
int
lsquic_test_endpoint_init (struct lsquic_test_endpoint *,
    struct lsquic_test_endpoint *peer,
    const struct lsquic_test_endpoint_config *, uint16_t port);

void
lsquic_test_endpoint_destroy (struct lsquic_test_endpoint *);

/* Processing never recursively delivers output packets to the peer engine. */
void
lsquic_test_pair_process (struct lsquic_test_pair *, uint64_t advance_us);

/* Removes a selected packet and preserves the order of all remaining packets. */
int
lsquic_test_packet_take (struct lsquic_test_endpoint *, unsigned queue_index,
                        struct lsquic_test_packet *out);

int
lsquic_test_packet_deliver (struct lsquic_test_endpoint *,
                          const struct lsquic_test_packet *);

void
lsquic_test_deliver_all (struct lsquic_test_endpoint *);

void
lsquic_test_fail_next_stream_new (void);

void
lsquic_test_fail_next_hash_insert (void);

unsigned
lsquic_test_stream_new_failures_pending (void);

unsigned
lsquic_test_hash_insert_failures_pending (void);

#endif
