const std = @import("std");
const support = @import("test_support");

test "actual App has a private startup child consumer field" {
    var application = try support.builder.Server.builder(std.testing.io)
        .with_max_clients(8).with_webtransport_datagrams(1200, 4)
        .with_max_h3_response_header_size(16384).build(std.testing.allocator);
    defer application.deinit();
    application.webtransport_child_consumer = null;
}
