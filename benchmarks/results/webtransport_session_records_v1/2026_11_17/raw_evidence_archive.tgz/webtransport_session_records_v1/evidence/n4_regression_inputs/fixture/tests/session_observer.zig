const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const wt = support.webtransport;

/// A validated CONNECT lease, not a compatibility view of old Connection fields.
pub const SessionSnapshot = struct {
    handle: wt.SessionHandle,
    phase: wt.SessionState,
    route: support.datagram.RouteId,
    notice_published: bool,
    stream_index: usize,
};

/// Accepts configured App types; their compile-time capacities differ in this cohort.
pub fn snapshot(comptime Application: type, application: *const Application, connection_index: usize, session_id: u64) !SessionSnapshot {
    const engine = &application.quic_transport.?.engine;
    if (!engine.connections.pool.is_active(connection_index)) return error.MissingObservedConnection;
    const connection = &engine.connections.pool.storage[connection_index];
    const index = if (engine.session_index) |*active| active else return error.MissingSessionIndex;
    const handle = index.find(.{ .connection = connection.handle, .session_id = session_id }) orelse return error.MissingObservedSession;
    if (handle.generation == 0 or !engine.stream_pool.is_active(handle.index)) return error.MissingObservedConnect;
    const parent = &engine.stream_contexts[handle.index];
    if (parent.generation != handle.generation or !parent.state.lease.active or
        !std.meta.eql(parent.state.lease.connection, connection.handle) or parent.state.role != .connect or
        parent.state.session == null or !std.meta.eql(parent.state.session.?, handle)) return error.InvalidObservedConnect;
    const record = parent.session_record orelse return error.MissingObservedRecord;
    if (!std.meta.eql(record.notice.connection, connection.handle) or
        !std.meta.eql(record.notice.session, handle) or record.notice.session_id != session_id or
        record.phase == .closed) return error.InvalidObservedRecord;
    if (application.webtransport_endpoints.get(record.notice.route) == null) return error.InvalidObservedRoute;
    if (c.lsquic_stream_id(parent.http.stream) != session_id or
        c.lsquic_stream_get_ctx(parent.http.stream) != @as(?*c.lsquic_stream_ctx, @ptrCast(@constCast(parent)))) return error.InvalidObservedNativeLease;
    return .{ .handle = handle, .phase = record.phase, .route = record.notice.route, .notice_published = record.notice_published, .stream_index = handle.index };
}
