const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const sessions = @import("session_observer.zig");
const backend = support.webtransport_backend;
const child = support.webtransport_child_runtime;
const consumer = @import("public_consumer.zig");
const testing = std.testing;
const App = consumer.Application;
const Record = consumer.Record;
const Observation = consumer.Observation;
const payload = [_]u8{ 0x41, 0, 0xff, 'r', 'a', 'w', 0x54, 0x40, 0, 0xfe };

fn authorize(context: *anyopaque, request: *support.Request, response: *support.public_api.Response) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    observed.authorization_calls += 1;
    const origin = request.get_unique_header("origin") orelse "";
    const authorization = request.get_unique_header("authorization") orelse "";
    const allowed = std.mem.eql(u8, origin, "https://localhost") and std.mem.eql(u8, authorization, "Bearer admission-fixture");
    response.end(if (allowed) "200 OK" else "403 Forbidden", "") catch |err| {
        observed.failure = err;
    };
    if (observed.cooldown_on_authorize) {
        const engine = &observed.application.quic_transport.?.engine;
        engine.cooldown();
        observed.deferred_cooldown = engine.callback_depth > 0 and engine.cooldown_pending and !engine.in_cooldown;
    }
}

fn health(context: *anyopaque, request: *support.Request, response: *support.public_api.Response) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    observed.http_calls += 1;
    if (!std.mem.eql(u8, request.path, "/health") or !std.mem.eql(u8, request.body, "healthy-body")) {
        observed.failure = error.InvalidHealthyHttpRequest;
    }
    response.end("200 OK", "healthy-response") catch |err| {
        observed.failure = err;
    };
}

fn initialize() !App {
    return support.builder.Server.builder(testing.io).with_max_clients(8)
        .with_max_h3_response_header_size(16384)
        .build(testing.allocator);
}

fn listen(application: *App, observed: *Observation) !u16 {
    try application.enable_http3_ephemeral();
    _ = try application.webtransport_streams_context("/wt", observed, consumer.callbacks);
    _ = try application.route_context(.connect, "/wt", observed, authorize);
    _ = try application.route_context(.post, "/health", observed, health);
    try application.listen_udp("127.0.0.1", 0);
    const active = application.quic_transport.?.engine.binding.?;
    try testing.expectEqual(@as(*anyopaque, application), active.context);
    try testing.expectEqual(@as(usize, 0), observed.session_count);
    return application.quic_transport.?.local_address.ip4.port;
}

fn destroy(application: *App) void {
    if (application.quic_transport) |*transport| {
        transport.shutdown();
        var step: usize = 0;
        while (step < c.UWZ_APP_MAX_STEPS and !transport.is_drained()) : (step += 1) {
            application.loop.get_xev_loop().run(.no_wait) catch |err| {
                std.debug.panic("actual child completion drain: {s}", .{@errorName(err)});
            };
        }
        std.debug.assert(transport.is_drained() and transport.close_complete);
        std.debug.assert(!transport.read_active and !transport.timer_active);
        std.debug.assert(!transport.read_cancel_active and !transport.timer_cancel_active);
    }
    application.shutdown() catch |err| {
        std.debug.panic("actual child App shutdown: {s}", .{@errorName(err)});
    };
    application.deinit();
}

fn checked(observed: *const Observation) !void {
    if (observed.failure) |err| {
        std.debug.print("child consumer failure={s} auth={d} opens={d}\n", .{ @errorName(err), observed.authorization_calls, observed.count });
        return err;
    }
}

fn pump(application: *App, clients: []const *c.struct_uwz_app_client, observed: *const Observation) !void {
    for (clients) |client| {
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_process(client));
        try testing.expect(c.uwz_app_client_send_udp(client) >= 0);
    }
    try application.loop.get_xev_loop().run(.no_wait);
    application.quic_transport.?.engine.process();
    for (clients) |client| try testing.expect(c.uwz_app_client_receive_udp(client) >= 0);
    try checked(observed);
}

fn connection_index(application: *App, client: *c.struct_uwz_app_client) !usize {
    const pool = &application.quic_transport.?.engine.connections.pool;
    const port = c.uwz_app_client_port(client);
    for (pool.storage, 0..) |connection, index| {
        if (pool.is_active(index) and c.uwz_app_connection_peer_port(connection.native) == port) return index;
    }
    return error.MissingClientConnection;
}

fn response_snapshot(client: *c.struct_uwz_app_client, id: u64) !c.struct_uwz_app_response_snapshot {
    var result: c.struct_uwz_app_response_snapshot = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_response(client, id, &result));
    return result;
}

fn handshake(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, observed: *const Observation) !usize {
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_connect(client));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, clients, observed);
        var native: c.struct_uwz_app_client_snapshot = undefined;
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_observe(client, &native));
        if (native.handshake_complete == 0 or native.settings_callbacks == 0) continue;
        const index = connection_index(application, client) catch continue;
        if (application.quic_transport.?.engine.connections.pool.storage[index].peer != null) return index;
    }
    return error.ChildHandshakeTimeout;
}

fn accept(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, observed: *const Observation, expected: u64) !usize {
    var input: c.struct_uwz_app_connect_request = .{
        .origin = "https://localhost",
        .authorization = "Bearer admission-fixture",
        .duplicate_origin = 0,
    };
    const id = c.uwz_app_client_open_connect_path(client, &input, observed.connect_path);
    try testing.expectEqual(expected, id);
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, clients, observed);
        const response = try response_snapshot(client, id);
        if (response.header_callbacks == 0) continue;
        try testing.expectEqual(@as(c_uint, 200), response.status_code);
        try testing.expectEqual(@as(c_uint, 0), response.fin_received);
        try testing.expectEqual(backend.CreateResult.ok, backend.accept_connect(c.uwz_app_client_stream(client, id)));
        const index = try connection_index(application, client);
        const engine = &application.quic_transport.?.engine;
        try testing.expectEqual(.established, (try sessions.snapshot(App, application, index, expected)).phase);
        try testing.expectEqual(@as(usize, 0), engine.header_pool.count_active());
        return index;
    }
    return error.ChildConnectTimeout;
}

fn open_child(application: *App, client: *c.struct_uwz_app_client, session_id: u64, direction: backend.Direction) !u64 {
    const result = backend.create_child(c.uwz_app_client_connection(client), session_id, direction);
    if (result != .ok) {
        var params: c.struct_uwz_app_peer_transport_diagnostics = undefined;
        const status = c.uwz_app_peer_transport_diagnose(c.uwz_app_client_connection(client), &params);
        std.debug.print("child factory={s} TPstatus={d} peerUNIstreams={d} serverUNIsetting={d}\n", .{ @tagName(result), status, if (status == 0) params.streams_uni else 0, application.quic_transport.?.engine.settings.es_init_max_streams_uni });
    }
    try testing.expectEqual(backend.CreateResult.ok, result);
    const id = c.uwz_app_client_last_stream_id(client);
    try testing.expect(id != std.math.maxInt(u64));
    return id;
}

fn healthy_http(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, observed: *const Observation) !void {
    const body = "healthy-body";
    const id = c.uwz_app_client_open_post(client, "/health", body.len);
    try testing.expect(id != std.math.maxInt(u64));
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, body, body.len, 1));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, clients, observed);
        const response = try response_snapshot(client, id);
        if (response.fin_received == 0) continue;
        try testing.expectEqual(@as(c_uint, 200), response.status_code);
        try testing.expectEqualSlices(u8, "healthy-response", response.bytes[0..response.received]);
        return;
    }
    return error.ChildHealthyHttpTimeout;
}

test "authorized App incoming UNI delivers exact binary bytes through private consumer" {
    var application = try initialize();
    defer destroy(&application);
    var observed: Observation = .{ .application = &application };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try handshake(&application, client, &clients, &observed);
    try testing.expectEqual(index, try accept(&application, client, &clients, &observed, 0));
    try testing.expectEqual(@as(usize, 1), observed.authorization_calls);
    const id = try open_child(&application, client, 0, .uni);
    const native_creation = try response_snapshot(client, id);
    try testing.expectEqual(@as(c_int, c.LSQUIC_WTS_OK), native_creation.new_info_result);
    try testing.expectEqual(@as(u64, 0), native_creation.new_info.session_id);
    try testing.expectEqual(@as(c_uint, 3), native_creation.new_info.send_prefix_size);
    try testing.expectEqual(@as(c_uint, c.LSQUIC_WTSF_CHILD | c.LSQUIC_WTSF_LOCAL | c.LSQUIC_WTSF_UNI), native_creation.new_info.flags);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, &payload, payload.len, 1));
    var complete = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(&application, &clients, &observed);
        if (observed.count == 0) continue;
        const record = &observed.records[0].?;
        if (record.received != payload.len or record.eof_calls != 1 or record.closed == null) continue;
        complete = true;
        break;
    }
    if (!complete) {
        var native: c.struct_uwz_app_response_snapshot = undefined;
        const status = c.uwz_app_client_response(client, id, &native);
        std.debug.print("child consumer missing: auth={d} opens={d} childSnapshot={d} typed={d} nativeClose={d} closeInfo={d}\n", .{
            observed.authorization_calls,
            observed.count,
            status,
            if (status == 0) native.typed_callbacks else 0,
            if (status == 0) native.close_callbacks else 0,
            if (status == 0) native.close_info_result else -1,
        });
    }
    try testing.expect(complete);
    const record = &observed.records[0].?;
    const connection = &application.quic_transport.?.engine.connections.pool.storage[index];
    try testing.expectEqualDeep(connection.handle, record.info.key.connection);
    try testing.expectEqualDeep((try sessions.snapshot(App, &application, index, 0)).handle, record.info.key.session);
    try testing.expectEqual(@as(u64, 0), record.info.key.session_id);
    try testing.expectEqual(id, record.info.key.stream_id);
    try testing.expectEqual(child.Direction.uni, record.info.direction);
    try testing.expectEqual(@as(u8, 3), record.info.receive_prefix_size);
    try testing.expectEqualSlices(u8, &payload, record.bytes[0..record.received]);
    try testing.expectEqual(@as(?u64, payload.len), record.eof_size);
    try testing.expectEqual(child.CloseReason.completed, record.closed.?.reason);
    try testing.expectEqual(@as(?u64, payload.len), record.closed.?.final_payload_size);
    try testing.expectEqual(@as(u64, payload.len), record.closed.?.accounted_bytes);
    try testing.expectEqual(@as(usize, 0), observed.http_calls);
    try testing.expectEqual(@as(usize, 0), application.quic_transport.?.engine.header_pool.count_active());
    try healthy_http(&application, client, &clients, &observed);
    try testing.expectEqual(@as(usize, 1), observed.http_calls);
}

const ConnectionHandle = support.webtransport_runtime.ConnectionHandle;

// Before publication only logical identity exists; callbacks also check location.
fn same_logical_key(expected: child.Key, actual: child.Key) bool {
    return std.meta.eql(expected.connection, actual.connection) and
        std.meta.eql(expected.session, actual.session) and
        expected.session_id == actual.session_id and expected.stream_id == actual.stream_id;
}

fn key_for(application: *App, index: usize, session_id: u64, stream_id: u64) !child.Key {
    const pool = &application.quic_transport.?.engine.connections.pool;
    try testing.expect(pool.is_active(index));
    const connection = &pool.storage[index];
    return .{
        .connection = connection.handle,
        .session = (try sessions.snapshot(App, application, index, session_id)).handle,
        .session_id = session_id,
        .stream_id = stream_id,
    };
}

fn find_record(observed: *Observation, connection: ConnectionHandle, id: u64) ?*Record {
    for (observed.records[0..observed.count]) |*slot| {
        const record = &slot.*.?;
        if (std.meta.eql(record.info.key.connection, connection) and record.info.key.stream_id == id) return record;
    }
    return null;
}

fn await_data(application: *App, clients: []const *c.struct_uwz_app_client, observed: *Observation, key: child.Key, bytes: []const u8) !*Record {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        if (find_record(observed, key.connection, key.stream_id)) |record| {
            if (record.received == bytes.len) {
                try testing.expect(same_logical_key(key, record.info.key));
                try testing.expectEqualSlices(u8, bytes, record.bytes[0..record.received]);
                return record;
            }
        }
        try pump(application, clients, observed);
    }
    return error.ChildDataTimeout;
}

fn await_closed(application: *App, clients: []const *c.struct_uwz_app_client, observed: *Observation, key: child.Key) !*Record {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        if (find_record(observed, key.connection, key.stream_id)) |record| {
            if (record.closed != null) {
                try testing.expect(same_logical_key(key, record.closed.?.key));
                return record;
            }
        }
        try pump(application, clients, observed);
    }
    const record = find_record(observed, key.connection, key.stream_id);
    if (record) |value| std.debug.print("close timeout data={d}/{d} reset={d}/{any} stop={d}/{any} eof={d}\n", .{ value.data_calls, value.received, value.reset_calls, value.reset_code, value.stop_calls, value.stop_code, value.eof_calls });
    const engine = &application.quic_transport.?.engine;
    for (engine.stream_contexts, 0..) |*context, index| {
        if (!engine.stream_pool.is_active(index)) continue;
        const state = if (context.child) |*value| value else continue;
        if (!std.meta.eql(state.metadata.connection, key.connection) or state.metadata.stream_id != key.stream_id) continue;
        var received: backend.ReceiveSnapshot = .{};
        const result = backend.read_receive(context.http.stream, &received);
        std.debug.print("child phase={s} reason={any} actions={any} query={s} resetvisible={any} readcancelled={any} final={any}\n", .{ @tagName(state.phase), state.cancel_reason, context.child_actions, @tagName(result), received.reset_visible, received.read_cancelled, received.final_size });
    }
    return error.ChildCloseTimeout;
}

fn expect_completed(record: *const Record, bytes: []const u8) !void {
    try testing.expectEqualSlices(u8, bytes, record.bytes[0..record.received]);
    try testing.expectEqual(@as(usize, 1), record.eof_calls);
    try testing.expectEqual(@as(?u64, bytes.len), record.eof_size);
    try testing.expectEqual(@as(usize, 0), record.reset_calls);
    const event = record.closed orelse return error.MissingConsumerClose;
    try testing.expectEqual(child.CloseReason.completed, event.reason);
    try testing.expectEqual(@as(?u64, bytes.len), event.final_payload_size);
    try testing.expectEqual(@as(u64, bytes.len), event.accounted_bytes);
}

fn native_client_stream(client: *c.struct_uwz_app_client, id: u64) !*c.lsquic_stream {
    return c.uwz_app_client_stream(client, id) orelse error.ClientNativeStreamClosed;
}

fn native_server_stream(application: *App, index: usize, id: u64) !*c.lsquic_stream {
    const engine = &application.quic_transport.?.engine;
    try testing.expect(engine.connections.pool.is_active(index));
    const handle = engine.connections.pool.storage[index].handle;
    for (engine.stream_contexts, 0..) |*context, stream_index| {
        if (!engine.stream_pool.is_active(stream_index)) continue;
        const state = if (context.child) |*value| value else continue;
        if (state.phase == .closed or !std.meta.eql(state.metadata.connection, handle) or state.metadata.stream_id != id) continue;
        try testing.expect(context.state.lease.active);
        try testing.expectEqualDeep(handle, context.state.lease.connection);
        // The active Root lease ends in native on-close; never keep this across pumps.
        return context.http.stream;
    }
    return error.ServerNativeStreamClosed;
}

fn receive_snapshot(application: *App, index: usize, id: u64) !backend.ReceiveSnapshot {
    var result: backend.ReceiveSnapshot = .{};
    try testing.expectEqual(backend.QueryResult.ok, backend.read_receive(try native_server_stream(application, index, id), &result));
    return result;
}

fn raw_uni(client: *c.struct_uwz_app_client, session_id: u64, bytes: []const u8) !u64 {
    var id: u64 = std.math.maxInt(u64);
    try testing.expectEqual(@as(c_int, c.LSQUIC_MUS_OK), c.uwz_app_client_open_raw_uni(client, &id));
    try testing.expect(id != std.math.maxInt(u64));
    var prefix: [16]u8 = undefined;
    const size = try support.webtransport.encode_unidirectional_header(session_id, &prefix);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, &prefix, size, 0));
    if (bytes.len != 0) try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, bytes.ptr, bytes.len, 0));
    return id;
}

fn await_pending_native(application: *App, clients: []const *c.struct_uwz_app_client, observed: *Observation, index: usize, id: u64, session_id: u64) !void {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, clients, observed);
        const native = native_server_stream(application, index, id) catch continue;
        var info: backend.StreamInfo = .{};
        if (backend.read_stream(native, &info) != .ok) continue;
        try testing.expectEqual(backend.Association.child, info.association);
        try testing.expectEqual(session_id, info.session_id);
        try testing.expectEqual(backend.Direction.uni, info.direction);
        try testing.expectEqual(backend.Initiator.peer, info.initiator);
        return;
    }
    return error.PendingNativeChildTimeout;
}

const Preview = struct {
    bytes: [16]u8 = @splat(0),
    length: usize = 0,
};

fn preview_bytes(context: ?*anyopaque, bytes: [*c]const u8, length: usize, _: c_int) callconv(.c) usize {
    const preview: *Preview = @ptrCast(@alignCast(context.?));
    preview.length = @min(length, preview.bytes.len);
    @memcpy(preview.bytes[0..preview.length], bytes[0..preview.length]);
    return 0;
}

fn waiting_state(application: *App, index: usize, id: u64) !*child.State {
    const engine = &application.quic_transport.?.engine;
    const handle = engine.connections.pool.storage[index].handle;
    for (engine.stream_contexts, 0..) |*context, stream_index| {
        if (!engine.stream_pool.is_active(stream_index)) continue;
        const state = if (context.child) |*value| value else continue;
        if (!std.meta.eql(state.metadata.connection, handle) or state.metadata.stream_id != id) continue;
        try testing.expectEqual(child.Phase.waiting_parent, state.phase);
        try testing.expect(state.pending_reserved and !state.pending_taken);
        try testing.expect(state.cancel_reason == null and !state.consumer_owned);
        try testing.expectEqual(@as(u64, 0), state.ledger.payload_read);
        return state;
    }
    return error.MissingWaitingChild;
}

fn await_buffered(application: *App, clients: []const *c.struct_uwz_app_client, observed: *Observation, index: usize, id: u64, expected: []const u8) !void {
    try testing.expect(expected.len != 0 and expected.len <= 16);
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        var preview: Preview = .{};
        const raw = try native_server_stream(application, index, id);
        _ = c.lsquic_stream_readf(raw, preview_bytes, &preview);
        if (preview.length >= expected.len) {
            try testing.expectEqualSlices(u8, expected, preview.bytes[0..expected.len]);
            _ = try waiting_state(application, index, id);
            return;
        }
        try pump(application, clients, observed);
    }
    return error.BufferedChildPayloadTimeout;
}

fn peer_stop(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, observed: *const Observation, id: u64, expected: u64) !void {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, clients, observed);
        const native = try response_snapshot(client, id);
        if (native.reset_events[1] == 0) continue;
        try testing.expectEqual(@as(c_uint, 1), native.reset_events[1]);
        try testing.expectEqual(@as(c_int, c.LSQUIC_SERR_AVAILABLE), native.reset_error_status[1]);
        try testing.expectEqual(expected, native.reset_error_code[1]);
        return;
    }
    const peer = try response_snapshot(client, id);
    std.debug.print("STOP diagnostic id={d} resets={any} codes={any} close={d} typed={d} closeRecv={d} flags={x} pending={d} active={d}\n", .{
        id,                        peer.reset_events,        peer.reset_error_code,                                   peer.close_callbacks,                                           peer.typed_callbacks,
        peer.close_receive_result, peer.close_receive.flags, application.quic_transport.?.engine.pending_child_count, application.quic_transport.?.engine.stream_pool.count_active(),
    });
    const engine = &application.quic_transport.?.engine;
    for (engine.stream_contexts, 0..) |*context, stream_index| {
        if (!engine.stream_pool.is_active(stream_index)) continue;
        const state = if (context.child) |*value| value else continue;
        if (state.metadata.stream_id != id) continue;
        std.debug.print("Root child conn={any} phase={s} reason={any} code={any} actions={any} final={any} prefix={d}\n", .{
            state.metadata.connection,        @tagName(state.phase), state.cancel_reason,
            state.cancel_code,                context.child_actions, state.ledger.final_size,
            state.ledger.receive_prefix_size,
        });
    }
    return error.PeerStopTimeout;
}

fn finish_send(client: *c.struct_uwz_app_client, id: u64) !void {
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, "", 0, 1));
}

fn abort_connection(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, observed: *const Observation) !ConnectionHandle {
    const index = try connection_index(application, client);
    const engine = &application.quic_transport.?.engine;
    const handle = engine.connections.pool.storage[index].handle;
    c.lsquic_conn_abort(engine.connections.pool.storage[index].native);
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, clients, observed);
        if (engine.connections.find(handle) == null) return handle;
    }
    return error.ChildConnectionAbortTimeout;
}

test "incoming BIDI delivers receive bytes and only an empty transmit FIN" {
    var application = try initialize();
    defer destroy(&application);
    var observed: Observation = .{ .application = &application };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    _ = try handshake(&application, client, &clients, &observed);
    const index = try accept(&application, client, &clients, &observed, 0);
    const id = try open_child(&application, client, 0, .bidi);
    const key = try key_for(&application, index, 0, id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, &payload, payload.len, 1));
    const record = try await_closed(&application, &clients, &observed, key);
    try expect_completed(record, &payload);
    try testing.expectEqual(child.Direction.bidi, record.info.direction);
    var peer_finished = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        const peer = try response_snapshot(client, id);
        if (peer.fin_received != 0) {
            try testing.expectEqual(@as(usize, 0), peer.received);
            try testing.expectEqual(@as(c_uint, 0), peer.header_callbacks);
            peer_finished = true;
            break;
        }
        try pump(&application, &clients, &observed);
    }
    try testing.expect(peer_finished);
    try testing.expectEqual(@as(usize, 0), observed.http_calls);
    try healthy_http(&application, client, &clients, &observed);
}

test "raw UNI before CONNECT preserves bytes until authorization then consumes fragments" {
    var application = try initialize();
    defer destroy(&application);
    var observed: Observation = .{ .application = &application };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try handshake(&application, client, &clients, &observed);
    const id = try raw_uni(client, 0, payload[0..1]);
    try await_pending_native(&application, &clients, &observed, index, id, 0);
    try await_buffered(&application, &clients, &observed, index, id, payload[0..1]);
    try testing.expectEqual(@as(usize, 0), observed.authorization_calls);
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expectEqual(@as(usize, 0), application.quic_transport.?.engine.connections.pool.storage[index].session_count);
    _ = try accept(&application, client, &clients, &observed, 0);
    const key = try key_for(&application, index, 0, id);
    const record = try await_data(&application, &clients, &observed, key, payload[0..1]);
    for (payload[1..], 1..) |*byte, end| {
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, byte, 1, 0));
        _ = try await_data(&application, &clients, &observed, key, payload[0 .. end + 1]);
    }
    try testing.expectEqual(payload.len, record.data_calls);
    try testing.expectEqual(@as(usize, 0), record.eof_calls);
    try finish_send(client, id);
    _ = try await_closed(&application, &clients, &observed, key);
    try expect_completed(record, &payload);
    try testing.expectEqual(payload.len, observed.reentry_returns);
}

test "raw child before held SETTINGS and CONNECT waits for real negotiation and admission" {
    var application = try initialize();
    defer destroy(&application);
    var observed: Observation = .{ .application = &application };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_HELD_SETTINGS) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_connect(client));
    var index: ?usize = null;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(&application, &clients, &observed);
        var peer: c.struct_uwz_app_client_snapshot = undefined;
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_observe(client, &peer));
        if (peer.handshake_complete == 0 or peer.settings_callbacks == 0) continue;
        index = connection_index(&application, client) catch continue;
        try testing.expectEqual(@as(c_uint, 1), peer.control_held);
        break;
    }
    const connection_index_value = index orelse return error.HeldSettingsHandshakeTimeout;
    const connection = &application.quic_transport.?.engine.connections.pool.storage[connection_index_value];
    var peer: backend.Peer = .{ .initial_max_data = 0x12345678 };
    const canary = peer;
    try testing.expectEqual(backend.QueryResult.pending, backend.read_peer(connection.native, &peer));
    try testing.expectEqualDeep(canary, peer);
    try testing.expect(connection.peer == null);
    try settle(&application, &clients, &observed, connection_index_value);
    const id = try raw_uni(client, 0, &payload);
    try deliver_client_batch(&application, client, &observed, connection_index_value);
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expectEqual(@as(usize, 0), observed.authorization_calls);
    try testing.expect(connection.peer == null);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_release_settings(client));
    try await_pending_native(&application, &clients, &observed, connection_index_value, id, 0);
    try testing.expect(connection.peer != null);
    try await_buffered(&application, &clients, &observed, connection_index_value, id, &payload);
    try testing.expectEqual(@as(usize, 0), observed.count);
    _ = try accept(&application, client, &clients, &observed, 0);
    const key = try key_for(&application, connection_index_value, 0, id);
    const record = try await_data(&application, &clients, &observed, key, &payload);
    try finish_send(client, id);
    _ = try await_closed(&application, &clients, &observed, key);
    try expect_completed(record, &payload);
}

test "full width unknown child session does not alias live zero and expires on OS awake time" {
    var application = try initialize();
    defer destroy(&application);
    var observed: Observation = .{ .application = &application };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    _ = try handshake(&application, client, &clients, &observed);
    const index = try accept(&application, client, &clients, &observed, 0);
    const clock = application.quic_transport.?.engine.binding.?;
    const before = clock.clock(clock.context);
    const wide_id: u64 = 1 << 40;
    const id = try raw_uni(client, wide_id, &payload);
    try await_pending_native(&application, &clients, &observed, index, id, wide_id);
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expectEqual(@as(usize, 1), application.quic_transport.?.engine.connections.pool.storage[index].session_count);
    var info: backend.StreamInfo = .{};
    try testing.expectEqual(backend.QueryResult.ok, backend.read_stream(try native_server_stream(&application, index, id), &info));
    var prefix: [16]u8 = undefined;
    const prefix_size = try support.webtransport.encode_unidirectional_header(wide_id, &prefix);
    try testing.expectEqual(@as(u8, @intCast(prefix_size)), info.receive_prefix_size);
    try await_buffered(&application, &clients, &observed, index, id, &payload);
    try settle(&application, &clients, &observed, index);
    const state = try waiting_state(&application, index, id);
    const after = clock.clock(clock.context);
    try testing.expect(state.deadline_us >= before + 1_000_000);
    try testing.expect(state.deadline_us <= after + 1_000_000 and after < state.deadline_us);
    try testing.expectEqual(@as(usize, 1), application.quic_transport.?.engine.pending_child_count);
    try testing.expectEqual(@as(usize, 1), application.quic_transport.?.engine.connections.pool.storage[index].pending_child_count);
    const prior = try response_snapshot(client, id);
    try testing.expectEqual(@as(c_uint, 0), prior.reset_events[1]);
    try std.Io.sleep(testing.io, .fromMilliseconds(1100), .awake);
    try peer_stop(&application, client, &clients, &observed, id, support.webtransport.wt_buffered_stream_rejected);
    try testing.expectEqual(@as(usize, 0), application.quic_transport.?.engine.pending_child_count);
    try testing.expectEqual(@as(usize, 0), application.quic_transport.?.engine.connections.pool.storage[index].pending_child_count);
    try testing.expectEqual(@as(usize, 0), observed.count);
    try healthy_http(&application, client, &clients, &observed);
    try testing.expectEqual(@as(usize, 1), observed.authorization_calls);
}

fn input_stats(application: *App, index: usize) !c.struct_uwz_app_input_statistics {
    const pool = &application.quic_transport.?.engine.connections.pool;
    try testing.expect(pool.is_active(index));
    var result: c.struct_uwz_app_input_statistics = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_connection_input_statistics(pool.storage[index].native, &result));
    return result;
}

fn settle(application: *App, clients: []const *c.struct_uwz_app_client, observed: *const Observation, index: usize) !void {
    var previous = try input_stats(application, index);
    var quiet: usize = 0;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, clients, observed);
        const current = try input_stats(application, index);
        var empty = true;
        for (clients) |client| empty = empty and c.uwz_app_client_pending_packets(client) == 0;
        quiet = if (current.packets == previous.packets and empty) quiet + 1 else 0;
        if (quiet == 8) return;
        previous = current;
    }
    return error.ChildSettleTimeout;
}

// No client ticks intervene while the actual encrypted UDP batch reaches Root.
fn deliver_client_batch(application: *App, client: *c.struct_uwz_app_client, observed: *const Observation, index: usize) !void {
    const before = try input_stats(application, index);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_process(client));
    const queued = c.uwz_app_client_pending_packets(client);
    try testing.expect(queued > 0);
    try testing.expectEqual(@as(c_int, @intCast(queued)), c.uwz_app_client_send_udp(client));
    var arrived = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try application.loop.get_xev_loop().run(.no_wait);
        application.quic_transport.?.engine.process();
        try checked(observed);
        const current = try input_stats(application, index);
        if (current.packets < before.packets + queued) continue;
        try testing.expectEqual(before.packets + queued, current.packets);
        try testing.expectEqual(before.undec_packets, current.undec_packets);
        try testing.expectEqual(before.dup_packets, current.dup_packets);
        try testing.expectEqual(before.err_packets, current.err_packets);
        arrived = true;
        break;
    }
    try testing.expect(arrived);
    try testing.expect(c.uwz_app_client_receive_udp(client) >= 0);
}

const module = @This();
pub const ChildrenSupport = struct {
    pub const Application = module.App;
    pub const Consumer = consumer;
    pub const Streams = support.public_api.webtransport_stream;
    pub const authorize = module.authorize;
    pub const health = module.health;
    pub const Observation = module.Observation;
    pub const Record = module.Record;
    pub const initialize = module.initialize;
    pub const listen = module.listen;
    pub const destroy = module.destroy;
    pub const pump = module.pump;
    pub const checked = module.checked;
    pub const handshake = module.handshake;
    pub const accept = module.accept;
    pub const key_for = module.key_for;
    pub const open_child = module.open_child;
    pub const raw_uni = module.raw_uni;
    pub const find_record = module.find_record;
    pub const await_data = module.await_data;
    pub const await_closed = module.await_closed;
    pub const expect_completed = module.expect_completed;
    pub const await_pending_native = module.await_pending_native;
    pub const native_client_stream = module.native_client_stream;
    pub const native_server_stream = module.native_server_stream;
    pub const receive_snapshot = module.receive_snapshot;
    pub const response_snapshot = module.response_snapshot;
    pub const peer_stop = module.peer_stop;
    pub const finish_send = module.finish_send;
    pub const healthy_http = module.healthy_http;
    pub const connection_index = module.connection_index;
    pub const abort_connection = module.abort_connection;
    pub const input_stats = module.input_stats;
    pub const waiting_state = module.waiting_state;
    pub const await_buffered = module.await_buffered;
    pub const settle = module.settle;
    pub const deliver_client_batch = module.deliver_client_batch;
};
