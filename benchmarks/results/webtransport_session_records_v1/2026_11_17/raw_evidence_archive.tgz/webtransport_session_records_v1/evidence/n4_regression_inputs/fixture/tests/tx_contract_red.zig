const App = @import("public_consumer.zig").Application;
const streams = @import("test_support").public_api.webtransport_stream;

test "public TX increment requires write and writable operations" {
    _ = App.webtransport_stream_write;
    _ = App.webtransport_stream_want_writable;
    _ = streams.WriteError;
}
