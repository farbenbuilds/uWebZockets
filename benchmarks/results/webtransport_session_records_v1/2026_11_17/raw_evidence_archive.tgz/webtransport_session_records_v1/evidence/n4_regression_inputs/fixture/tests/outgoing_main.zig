comptime {
    _ = @import("half_main.zig");
    _ = @import("app_public_outgoing.zig");
}
