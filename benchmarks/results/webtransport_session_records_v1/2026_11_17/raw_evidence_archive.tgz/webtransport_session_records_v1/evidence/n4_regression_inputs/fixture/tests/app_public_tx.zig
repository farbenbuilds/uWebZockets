const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const h = @import("app_children.zig").ChildrenSupport;
const testing = std.testing;
const streams = h.Streams;

/// Public callbacks retain the inherited identity oracles and add TX outcomes.
const Observation = struct {
    base: h.Observation,
    echo: bool = false,
    verify_open: bool = false,
    arm_open: bool = false,
    shutdown_writable: bool = false,
    inside_operation: bool = false,
    echoed: usize = 0,
    writable_calls: usize = 0,
    last_writable: ?streams.Handle = null,
};

fn opened(context: *anyopaque, info: streams.Info) bool {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const accepted = h.Consumer.callbacks.open(&observed.base, info);
    if (!accepted) return false;
    open_operations(observed, info.handle) catch |err| {
        observed.base.failure = err;
        return false;
    };
    return true;
}

fn open_operations(observed: *Observation, handle: streams.Handle) !void {
    if (observed.verify_open) {
        try testing.expectError(error.NotReady, observed.base.application.webtransport_stream_write(handle, "open"));
        try testing.expectError(error.NotReady, observed.base.application.webtransport_stream_finish(handle));
    }
    if (observed.arm_open) {
        try observed.base.application.webtransport_stream_want_writable(handle, true);
        try testing.expectEqual(@as(usize, 0), observed.writable_calls);
    }
}

fn received(context: *anyopaque, handle: streams.Handle, bytes: []const u8) bool {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const accepted = h.Consumer.callbacks.data.?(&observed.base, handle, bytes);
    if (!accepted or !observed.echo) return accepted;
    const written = observed.base.application.webtransport_stream_write(handle, bytes) catch |err| {
        observed.base.failure = err;
        return false;
    };
    if (written != bytes.len) {
        observed.base.failure = error.PartialSmallEcho;
        return false;
    }
    observed.echoed += written;
    return true;
}

fn eof(context: *anyopaque, handle: streams.Handle, size: u64) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    h.Consumer.callbacks.eof.?(&observed.base, handle, size);
}

fn reset(context: *anyopaque, handle: streams.Handle, code: streams.ErrorCode, size: u64) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    h.Consumer.callbacks.reset.?(&observed.base, handle, code, size);
}

fn stopped(context: *anyopaque, handle: streams.Handle, code: streams.ErrorCode) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    h.Consumer.callbacks.stop.?(&observed.base, handle, code);
}

fn closed(context: *anyopaque, event: streams.ClosedEvent) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    h.Consumer.callbacks.closed.?(&observed.base, event);
}

fn session_open(context: *anyopaque, info: streams.SessionInfo) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    h.Consumer.callbacks.session_open.?(&observed.base, info);
}

fn session_closed(context: *anyopaque, event: streams.SessionClosedEvent) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    h.Consumer.callbacks.session_closed.?(&observed.base, event);
}

fn writable(context: *anyopaque, handle: streams.Handle) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    if (observed.inside_operation) {
        observed.base.failure = error.InlineWritable;
        return;
    }
    _ = h.Consumer.record_for_handle(&observed.base, handle) catch |err| {
        observed.base.failure = err;
        return;
    };
    const current = &observed.base.application.quic_transport.?.engine.stream_contexts[handle.index];
    if (!current.transmit.published or !current.child.?.consumer_owned) {
        observed.base.failure = error.WritableBeforePublication;
        return;
    }
    observed.writable_calls += 1;
    observed.last_writable = handle;
    if (observed.shutdown_writable) {
        observed.base.application.shutdown() catch |err| {
            observed.base.failure = err;
        };
    }
}

const callbacks: streams.Callbacks = .{
    .open = opened,
    .data = received,
    .eof = eof,
    .reset = reset,
    .stop = stopped,
    .closed = closed,
    .session_open = session_open,
    .session_closed = session_closed,
};

const callbacks_with_writable: streams.Callbacks = blk: {
    var value = callbacks;
    value.writable = writable;
    break :blk value;
};

fn listen(application: *h.Application, observed: *Observation, with_writable: bool) !u16 {
    try application.enable_http3_ephemeral();
    _ = try application.webtransport_streams_context("/wt", observed, if (with_writable) callbacks_with_writable else callbacks);
    _ = try application.route_context(.connect, "/wt", &observed.base, h.authorize);
    _ = try application.route_context(.post, "/health", &observed.base, h.health);
    try application.listen_udp("127.0.0.1", 0);
    return application.quic_transport.?.local_address.ip4.port;
}

fn pump(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation) !void {
    const clients = [_]*c.struct_uwz_app_client{client};
    try h.pump(application, &clients, &observed.base);
}

fn admitted_bidi(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation, index: usize) !*h.Record {
    const clients = [_]*c.struct_uwz_app_client{client};
    _ = try h.accept(application, client, &clients, &observed.base, 0);
    const id = try h.open_child(application, client, 0, .bidi);
    const key = try h.key_for(application, index, 0, id);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, "request", 7, 0));
    return h.await_data(application, &clients, &observed.base, key, "request");
}

fn await_peer(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation, id: u64, expected: []const u8, fin: bool) !void {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, client, observed);
        const response = try h.response_snapshot(client, id);
        if (response.received < expected.len or (fin and response.fin_received == 0)) continue;
        try testing.expectEqual(expected.len, response.received);
        try testing.expectEqualSlices(u8, expected, response.bytes[0..response.received]);
        try testing.expectEqual(@as(c_uint, @intFromBool(fin)), response.fin_received);
        try testing.expectEqual(@as(c_uint, 0), response.reset_events[0]);
        return;
    }
    return error.PeerPayloadTimeout;
}

fn await_terminal(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation, record: *h.Record, is_reset: bool) !void {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, client, observed);
        if (if (is_reset) record.reset_calls == 1 else record.eof_calls == 1) return;
    }
    return error.ReceiveTerminalTimeout;
}

test "public BIDI write echoes binary callback bytes and finishes the accepted prefix" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false }, .echo = true, .verify_open = true };
    const port = try listen(&application, &observed, true);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted_bidi(&application, client, &observed, index);
    const bytes = [_]u8{ 0, 0xff, 0x40, 'e', 'c', 'h', 'o', 0, 0xfe };
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, record.info.key.stream_id, &bytes, bytes.len, 1));
    try await_terminal(&application, client, &observed, record, false);
    try testing.expectEqual(@as(usize, 7 + bytes.len), observed.echoed);
    try application.webtransport_stream_finish(record.public_info.handle);
    try await_peer(&application, client, &observed, record.info.key.stream_id, "request" ++ bytes, true);
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try testing.expectEqual(streams.CloseReason.completed, record.public_closed.?.reason);
    try testing.expectEqual(@as(usize, 0), observed.writable_calls);
    try h.healthy_http(&application, client, &clients, &observed.base);
}

fn await_writable(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation, count: usize) !void {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, client, observed);
        if (observed.writable_calls == count) return;
        try testing.expect(observed.writable_calls < count);
    }
    return error.WritableTimeout;
}

fn stream_diagnostics(application: *h.Application, index: usize, id: u64) !c.struct_uwz_app_stream_diagnostics {
    var out: c.struct_uwz_app_stream_diagnostics = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_stream_diagnose(try h.native_server_stream(application, index, id), &out));
    return out;
}

fn connection_cap(application: *h.Application, index: usize, id: u64) !c.struct_uwz_app_connection_send_cap {
    var out: c.struct_uwz_app_connection_send_cap = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_stream_connection_send_cap(try h.native_server_stream(application, index, id), &out));
    return out;
}

fn credit_case(connection_limited: bool, with_writable: bool) !void {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try listen(&application, &observed, with_writable);
    const variant: c.enum_uwz_app_client_variant = if (connection_limited) c.UWZ_APP_CLIENT_CONNECTION_CREDIT else c.UWZ_APP_CLIENT_SMALL_RESPONSE_CREDIT;
    const client = c.uwz_app_client_create_variant(port, variant) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    var profile: c.struct_uwz_app_client_snapshot = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_observe(client, &profile));
    try testing.expectEqual(@as(u64, if (connection_limited) 65536 else 4096), profile.configured_bidi_local);
    if (connection_limited) try testing.expectEqual(@as(u64, 16384), profile.configured_max_data);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_pause_child_reads(client, 1));
    const record = try admitted_bidi(&application, client, &observed, index);
    const id = record.info.key.stream_id;
    const handle = record.public_info.handle;
    const size: usize = if (connection_limited) 32768 else 8192;
    var expected: [32768]u8 = undefined;
    for (&expected, 0..) |*byte, offset| byte.* = @truncate(offset * 29 + offset / 251);
    var offered = expected;
    const accepted = try application.webtransport_stream_write(handle, offered[0..size]);
    try testing.expect(accepted > 0 and accepted < size);
    @memset(offered[0..accepted], 0xa5);
    const before = try stream_diagnostics(&application, index, id);
    const cap_before = try connection_cap(&application, index, id);
    if (connection_limited) {
        try testing.expectEqual(cap_before.maximum, cap_before.sent);
        try testing.expect(before.send_limit > before.send_offset + before.buffered_bytes);
    } else {
        try testing.expectEqual(@as(u64, 4096), before.send_limit);
        try testing.expectEqual(before.send_limit, before.send_offset + before.buffered_bytes);
        try testing.expect(cap_before.maximum > cap_before.sent);
    }
    try testing.expectError(error.WouldBlock, application.webtransport_stream_write(handle, offered[accepted..size]));
    const context = &application.quic_transport.?.engine.stream_contexts[handle.index];
    try testing.expectEqual(@as(u64, @intCast(accepted)), context.transmit.accepted_bytes);
    try testing.expectEqual(with_writable, context.transmit.writable_requested);
    if (with_writable) try application.webtransport_stream_want_writable(handle, false);
    for (0..32) |_| try pump(&application, client, &observed);
    try testing.expectEqual(@as(usize, 0), observed.writable_calls);
    try testing.expectEqual(@as(usize, 0), (try h.response_snapshot(client, id)).received);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_enable_stream_reads(client, id));
    var granted = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(&application, client, &observed);
        const stream_now = try stream_diagnostics(&application, index, id);
        const cap_now = try connection_cap(&application, index, id);
        if ((try h.response_snapshot(client, id)).received != accepted) continue;
        if (connection_limited and cap_now.maximum <= cap_before.maximum) continue;
        if (!connection_limited and stream_now.send_limit <= before.send_limit) continue;
        granted = true;
        break;
    }
    try testing.expect(granted);
    try testing.expectEqual(@as(usize, 0), observed.writable_calls);
    if (with_writable) {
        observed.inside_operation = true;
        try application.webtransport_stream_want_writable(handle, true);
        try testing.expectEqual(@as(usize, 0), observed.writable_calls);
        observed.inside_operation = false;
        try await_writable(&application, client, &observed, 1);
        try testing.expectEqualDeep(handle, observed.last_writable.?);
        for (0..32) |_| try pump(&application, client, &observed);
        try testing.expectEqual(@as(usize, 1), observed.writable_calls);
        try application.webtransport_stream_want_writable(handle, true);
        try await_writable(&application, client, &observed, 2);
        for (0..32) |_| try pump(&application, client, &observed);
        try testing.expectEqual(@as(usize, 2), observed.writable_calls);
    } else {
        try testing.expectError(error.NoWritableCallback, application.webtransport_stream_want_writable(handle, true));
    }
    var total = accepted;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        if (total == size) break;
        const count = application.webtransport_stream_write(handle, offered[total..size]) catch |err| {
            if (err != error.WouldBlock) return err;
            try pump(&application, client, &observed);
            continue;
        };
        try testing.expect(count > 0 and count <= size - total);
        @memset(offered[total..][0..count], 0xa5);
        total += count;
        try pump(&application, client, &observed);
    }
    try testing.expectEqual(size, total);
    try testing.expectEqual(@as(u64, @intCast(size)), context.transmit.accepted_bytes);
    try application.webtransport_stream_finish(handle);
    try application.webtransport_stream_finish(handle);
    try application.webtransport_stream_want_writable(handle, false);
    try testing.expectError(error.WriteClosed, application.webtransport_stream_write(handle, "late"));
    try await_peer(&application, client, &observed, id, expected[0..size], true);
    try testing.expect(record.closed == null);
    try h.finish_send(client, id);
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try testing.expectEqual(streams.CloseReason.completed, record.public_closed.?.reason);
    try h.healthy_http(&application, client, &clients, &observed.base);
}

test "public TX stream credit produces partial and blocked writes then one shot writable" {
    try credit_case(false, true);
}

test "public TX connection credit recovers through real MAX_DATA independently of stream credit" {
    try credit_case(true, true);
}

test "public TX without writable callback uses explicit retry and rejects notification requests" {
    try credit_case(false, false);
}

fn after_receive_terminal(is_reset: bool) !void {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try listen(&application, &observed, true);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted_bidi(&application, client, &observed, index);
    const id = record.info.key.stream_id;
    const reset_code: u64 = (@as(u64, 1) << 61) + 431;
    if (is_reset) {
        try testing.expectEqual(support.webtransport_backend.ResetResult.ok, support.webtransport_backend.reset_stream(try h.native_client_stream(client, id), reset_code));
    } else try h.finish_send(client, id);
    try await_terminal(&application, client, &observed, record, is_reset);
    try testing.expect(record.closed == null);
    var bytes = [_]u8{ 0, 0xff, 0xfe, 'a', 'f', 't', 'e', 'r', 0 };
    const expected = bytes;
    try testing.expectEqual(bytes.len, try application.webtransport_stream_write(record.public_info.handle, &bytes));
    @memset(&bytes, 0x55);
    try application.webtransport_stream_finish(record.public_info.handle);
    try application.webtransport_stream_finish(record.public_info.handle);
    try await_peer(&application, client, &observed, id, &expected, true);
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try testing.expectEqual(if (is_reset) streams.CloseReason.peer_reset else .completed, record.public_closed.?.reason);
    try testing.expectEqual(@as(?u64, 7), record.public_closed.?.final_payload_size);
    try testing.expectEqual(@as(u64, 7), record.public_closed.?.accounted_bytes);
    if (is_reset) try testing.expectEqualDeep(streams.ErrorCode{ .http3 = reset_code }, record.public_closed.?.code.?);
    try testing.expectError(error.StaleHandle, application.webtransport_stream_write(record.public_info.handle, "stale"));
    try testing.expectError(error.StaleHandle, application.webtransport_stream_want_writable(record.public_info.handle, true));
    try h.healthy_http(&application, client, &clients, &observed.base);
}

test "public BIDI writes binary bytes after receive EOF and copies accepted storage" {
    try after_receive_terminal(false);
}

test "public BIDI writes binary bytes after independent receive RESET" {
    try after_receive_terminal(true);
}

test "public TX peer STOP closes sending while subsequent receive bytes remain live" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try listen(&application, &observed, true);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted_bidi(&application, client, &observed, index);
    const id = record.info.key.stream_id;
    const code: u64 = (@as(u64, 1) << 61) + 37;
    try testing.expectEqual(support.webtransport_backend.StopResult.ok, support.webtransport_backend.stop_receiving(try h.native_client_stream(client, id), code));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(&application, client, &observed);
        if (record.stop_calls != 0) break;
    }
    try testing.expectEqual(@as(usize, 1), record.stop_calls);
    try testing.expectEqualDeep(streams.ErrorCode{ .http3 = code }, record.public_stop_code.?);
    try testing.expectError(error.WriteClosed, application.webtransport_stream_write(record.public_info.handle, "blocked"));
    try testing.expectError(error.WriteClosed, application.webtransport_stream_finish(record.public_info.handle));
    try testing.expectError(error.WriteClosed, application.webtransport_stream_want_writable(record.public_info.handle, true));
    try application.webtransport_stream_want_writable(record.public_info.handle, false);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, "more", 4, 1));
    _ = try h.await_data(&application, &clients, &observed.base, record.info.key, "requestmore");
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try testing.expectEqual(@as(usize, 1), record.eof_calls);
    try testing.expectEqual(@as(u64, 11), record.public_closed.?.accounted_bytes);
    try testing.expectEqual(@as(usize, 0), observed.writable_calls);
    try h.healthy_http(&application, client, &clients, &observed.base);
}

test "public writable requested during open waits for accepted typed publication and disarms" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false }, .verify_open = true, .arm_open = true };
    const port = try listen(&application, &observed, true);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted_bidi(&application, client, &observed, index);
    try await_writable(&application, client, &observed, 1);
    for (0..64) |_| try pump(&application, client, &observed);
    try testing.expectEqual(@as(usize, 1), observed.writable_calls);
    try testing.expectEqual(@as(usize, 0), try application.webtransport_stream_write(record.public_info.handle, ""));
    try testing.expect(!application.quic_transport.?.engine.stream_contexts[record.public_info.handle.index].transmit.writable_requested);
    try application.webtransport_stream_finish(record.public_info.handle);
    try h.finish_send(client, record.info.key.stream_id);
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
}

fn fail_wake(_: *anyopaque) error{WakeFailed}!void {
    return error.WakeFailed;
}

test "explicit Root wake fault preserves native bytes and all child intents before retry" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try listen(&application, &observed, true);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted_bidi(&application, client, &observed, index);
    const handle = record.public_info.handle;
    const engine = &application.quic_transport.?.engine;
    const original = engine.binding.?.wake;
    try testing.expect(original != null and engine.callback_depth == 0);
    defer engine.binding.?.wake = original;
    const before_native = try stream_diagnostics(&application, index, record.info.key.stream_id);
    const before_tx = engine.stream_contexts[handle.index].transmit;
    const before_child = engine.stream_contexts[handle.index].child;
    engine.binding.?.wake = fail_wake;
    const bytes = [_]u8{ 0, 0xff, 'w', 'a', 'k', 'e', 0xfe };
    try testing.expectError(error.WakeFailed, application.webtransport_stream_write(handle, &bytes));
    try testing.expectEqualDeep(before_native, try stream_diagnostics(&application, index, record.info.key.stream_id));
    try testing.expectEqualDeep(before_tx, engine.stream_contexts[handle.index].transmit);
    try testing.expectError(error.WakeFailed, application.webtransport_stream_finish(handle));
    try testing.expectEqualDeep(before_tx, engine.stream_contexts[handle.index].transmit);
    try testing.expectError(error.WakeFailed, application.webtransport_stream_cancel(handle, 91));
    try testing.expectEqualDeep(before_child, engine.stream_contexts[handle.index].child);
    try testing.expectError(error.WakeFailed, application.webtransport_stream_want_writable(handle, true));
    try testing.expectEqualDeep(before_tx, engine.stream_contexts[handle.index].transmit);
    try testing.expectEqualDeep(before_native, try stream_diagnostics(&application, index, record.info.key.stream_id));
    engine.binding.?.wake = original;
    try testing.expectEqual(bytes.len, try application.webtransport_stream_write(handle, &bytes));
    try application.webtransport_stream_finish(handle);
    try await_peer(&application, client, &observed, record.info.key.stream_id, &bytes, true);
    try testing.expect(record.closed == null);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, record.info.key.stream_id, "after", 5, 1));
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try testing.expectEqualSlices(u8, "requestafter", record.bytes[0..record.received]);
    try testing.expectEqual(streams.CloseReason.completed, record.public_closed.?.reason);
    try testing.expectEqual(@as(usize, 0), observed.writable_calls);
}

test "public writable callback App shutdown closes its owned child and session exactly once" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try listen(&application, &observed, true);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try admitted_bidi(&application, client, &observed, index);
    observed.shutdown_writable = true;
    observed.inside_operation = true;
    try application.webtransport_stream_want_writable(record.public_info.handle, true);
    try testing.expectEqual(@as(usize, 0), observed.writable_calls);
    observed.inside_operation = false;
    var drained = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(&application, client, &observed);
        if (record.closed == null or !application.quic_transport.?.is_drained()) continue;
        drained = true;
        break;
    }
    try testing.expect(drained);
    try testing.expectEqual(@as(usize, 1), observed.writable_calls);
    try testing.expectEqual(streams.CloseReason.shutdown, record.public_closed.?.reason);
    try testing.expectEqual(@as(u64, 7), record.public_closed.?.accounted_bytes);
    try testing.expectEqualSlices(u8, "request", record.bytes[0..record.received]);
    try testing.expectEqual(@as(usize, 1), observed.base.session_count);
    try testing.expectEqual(@as(usize, 1), observed.base.session_closed_count);
    try testing.expectEqual(streams.CloseReason.shutdown, observed.base.sessions[0].?.closed.?.reason);
    const engine = &application.quic_transport.?.engine;
    try testing.expectEqual(@as(usize, 0), engine.stream_pool.count_active());
    try testing.expectEqual(@as(usize, 0), engine.connections.pool.count_active());
    try testing.expectEqual(@as(usize, 0), engine.pending_child_count);
    try testing.expectEqual(@as(usize, 0), engine.child_retry_count);
    try testing.expectError(error.ShuttingDown, application.webtransport_stream_write(record.public_info.handle, "late"));
    for (0..16) |_| try pump(&application, client, &observed);
    try testing.expectEqual(@as(usize, 1), observed.writable_calls);
    try testing.expectEqual(@as(usize, 1), observed.base.session_closed_count);
}

const module = @This();
pub const TxSupport = struct {
    pub const Observation = module.Observation;
    pub const listen = module.listen;
    pub const pump = module.pump;
    pub const admitted_bidi = module.admitted_bidi;
};
