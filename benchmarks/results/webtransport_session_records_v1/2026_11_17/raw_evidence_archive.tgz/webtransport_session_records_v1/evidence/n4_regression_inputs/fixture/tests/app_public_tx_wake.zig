const std = @import("std");
const c = @import("c");
const h = @import("app_children.zig").ChildrenSupport;
const tx = @import("app_public_tx.zig").TxSupport;
const testing = std.testing;

fn monotonic_ms() !i64 {
    var now: std.os.linux.timespec = undefined;
    const result = std.os.linux.clock_gettime(std.os.linux.CLOCK.MONOTONIC, &now);
    try testing.expectEqual(@as(usize, 0), result);
    return @as(i64, @intCast(now.sec)) * 1000 + @divFloor(@as(i64, @intCast(now.nsec)), 1_000_000);
}

/// Copy the actual armed deadline; no timer, native clock or credit is altered.
fn timer_deadline_ms(application: *h.Application) !i64 {
    const transport = &application.quic_transport.?;
    try testing.expect(transport.timer_active and !transport.timer_cancel_active);
    return switch (transport.timer_completion.value) {
        .epoll => |completion| @as(i64, @intCast(completion.op.timer.next.sec)) * 1000 + @divFloor(@as(i64, @intCast(completion.op.timer.next.nsec)), 1_000_000),
        .io_uring => |completion| @as(i64, @intCast(completion.op.timer.next.sec)) * 1000 + @divFloor(@as(i64, @intCast(completion.op.timer.next.nsec)), 1_000_000),
    };
}

fn await_long_timer(application: *h.Application, client: *c.struct_uwz_app_client, observed: *tx.Observation, index: usize) !i64 {
    const clients = [_]*c.struct_uwz_app_client{client};
    try h.settle(application, &clients, &observed.base, index);
    for (0..1000) |_| {
        try tx.pump(application, client, observed);
        const transport = &application.quic_transport.?;
        if (transport.process_requested or transport.timer_cancel_active or !transport.timer_active) continue;
        const deadline = try timer_deadline_ms(application);
        if (deadline - try monotonic_ms() >= 500 and c.uwz_app_client_pending_packets(client) == 0) return deadline;
        try std.Io.sleep(testing.io, .fromMilliseconds(1), .awake);
    }
    return error.LongTimerBoundaryNotAttained;
}

/// Only xev drives Root here; client ACKs stay queued until this proof ends.
fn await_loop_only(application: *h.Application, client: *c.struct_uwz_app_client, observed: *tx.Observation, index: usize, id: u64, expected: []const u8, fin: bool, writable_count: usize, old_deadline: i64) !void {
    const before = try h.input_stats(application, index);
    const started = try monotonic_ms();
    try testing.expect(old_deadline - started >= 400);
    for (0..200) |_| {
        try application.loop.get_xev_loop().run(.no_wait);
        try testing.expect(c.uwz_app_client_receive_udp(client) >= 0);
        try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_process(client));
        try h.checked(&observed.base);
        const peer = try h.response_snapshot(client, id);
        const now = try monotonic_ms();
        try testing.expect(now < old_deadline);
        try testing.expect(now - started < 250);
        if (peer.received == expected.len and peer.fin_received == @intFromBool(fin) and observed.writable_calls == writable_count) {
            try testing.expectEqualSlices(u8, expected, peer.bytes[0..peer.received]);
            try testing.expectEqual(@as(c_uint, 0), peer.reset_events[0]);
            try testing.expectEqualDeep(before, try h.input_stats(application, index));
            return;
        }
        try std.Io.sleep(testing.io, .fromMilliseconds(1), .awake);
    }
    return error.ExternalOperationWakeTimeout;
}

test "outside public write writable and later finish each replace a long UDP deadline" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: tx.Observation = .{ .base = .{ .application = &application, .finish_on_receive_terminal = false } };
    const port = try tx.listen(&application, &observed, true);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed.base);
    const record = try tx.admitted_bidi(&application, client, &observed, index);
    const handle = record.public_info.handle;
    const id = record.info.key.stream_id;
    const bytes = [_]u8{ 0, 0xff, 'w', 'a', 'k', 'e', 0xfe, 0 };
    var deadline = try await_long_timer(&application, client, &observed, index);
    try testing.expectEqual(@as(usize, 0), application.quic_transport.?.engine.callback_depth);
    try testing.expectEqual(bytes.len, try application.webtransport_stream_write(handle, &bytes));
    try await_loop_only(&application, client, &observed, index, id, &bytes, false, 0, deadline);
    deadline = try await_long_timer(&application, client, &observed, index);
    observed.inside_operation = true;
    try application.webtransport_stream_want_writable(handle, true);
    try testing.expectEqual(@as(usize, 0), observed.writable_calls);
    observed.inside_operation = false;
    try await_loop_only(&application, client, &observed, index, id, &bytes, false, 1, deadline);
    deadline = try await_long_timer(&application, client, &observed, index);
    try application.webtransport_stream_finish(handle);
    try await_loop_only(&application, client, &observed, index, id, &bytes, true, 1, deadline);
    try testing.expect(record.closed == null);
    try h.finish_send(client, id);
    _ = try h.await_closed(&application, &clients, &observed.base, record.info.key);
    try testing.expectEqual(h.Streams.CloseReason.completed, record.public_closed.?.reason);
    try h.healthy_http(&application, client, &clients, &observed.base);
}
