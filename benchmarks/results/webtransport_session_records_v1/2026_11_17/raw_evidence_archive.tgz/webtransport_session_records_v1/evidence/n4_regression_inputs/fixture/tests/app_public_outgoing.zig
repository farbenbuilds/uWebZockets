const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const h = @import("app_children.zig").ChildrenSupport;
const streams = h.Streams;
const testing = std.testing;

const Record = struct {
    info: streams.Info,
    bytes: [4096]u8 = @splat(0),
    received: usize = 0,
    data_calls: usize = 0,
    eof_calls: usize = 0,
    eof_size: ?u64 = null,
    reset_calls: usize = 0,
    reset_code: ?streams.ErrorCode = null,
    reset_size: ?u64 = null,
    stop_calls: usize = 0,
    stop_code: ?streams.ErrorCode = null,
    writable_calls: usize = 0,
    closed: ?streams.ClosedEvent = null,
};

const Observation = struct {
    base: h.Observation,
    records: [16]?Record = @splat(null),
    count: usize = 0,
    creating: bool = false,
    inside_open: bool = false,
    create_on_session: bool = false,
    create_on_open: bool = false,
    create_on_writable: bool = false,
    create_on_data: bool = false,
    allow_local_open: bool = true,
    arm_open: bool = false,
    created: [8]?streams.Handle = @splat(null),
    created_count: usize = 0,
};

fn record_for(observed: *Observation, handle: streams.Handle) !*Record {
    for (observed.records[0..observed.count]) |*slot| {
        if (std.meta.eql(slot.*.?.info.handle, handle)) return &slot.*.?;
    }
    return error.UnknownOutgoingHandle;
}

fn create(observed: *Observation, parent: streams.SessionHandle, direction: streams.Direction) !streams.Handle {
    const count = observed.count;
    try testing.expect(!observed.creating);
    observed.creating = true;
    defer observed.creating = false;
    const handle = observed.base.application.webtransport_stream_create(parent, direction) catch |err| {
        var peer: c.struct_uwz_app_peer_transport_diagnostics = undefined;
        const conn = observed.base.application.quic_transport.?.engine.connections.pool.storage[parent.connection_index].native;
        const status = c.uwz_app_peer_transport_diagnose(conn, &peer);
        std.debug.print("outgoing create error={s} direction={s} peerTPstatus={d} bidi={d} uni={d} bidiRemote={d}\n", .{ @errorName(err), @tagName(direction), status, if (status == 0) peer.streams_bidi else 0, if (status == 0) peer.streams_uni else 0, if (status == 0) peer.bidi_remote else 0 });
        return err;
    };
    try testing.expectEqual(count, observed.count);
    try testing.expectError(error.NotReady, observed.base.application.webtransport_stream_write(handle, "early"));
    try testing.expectError(error.NotReady, observed.base.application.webtransport_stream_finish(handle));
    try testing.expectError(error.NotReady, observed.base.application.webtransport_stream_cancel(handle, 9));
    try testing.expect(observed.created_count < observed.created.len);
    observed.created[observed.created_count] = handle;
    observed.created_count += 1;
    return handle;
}

fn open_checked(observed: *Observation, info: streams.Info) !bool {
    try testing.expect(!observed.creating and !observed.inside_open);
    observed.inside_open = true;
    defer observed.inside_open = false;
    try testing.expect(info.initiator == .local);
    try testing.expectEqual(@as(u64, 1), info.stream_id & 1);
    try testing.expectEqual(info.direction == .uni, info.stream_id & 2 != 0);
    try testing.expect(info.handle.owner == @intFromPtr(observed.base.application));
    const engine = &observed.base.application.quic_transport.?.engine;
    const state = engine.stream_contexts[info.handle.index].child orelse return error.MissingOutgoingState;
    const key = state.key orelse return error.MissingOutgoingParent;
    try testing.expectEqual(info.handle.generation, key.location.generation);
    try testing.expectEqual(@as(u8, 0), state.ledger.receive_prefix_size);
    try testing.expectEqual(.opening, state.phase);
    try testing.expect(engine.callback_depth > 0);
    var native: support.webtransport_backend.StreamInfo = .{};
    try testing.expectEqual(.ok, support.webtransport_backend.read_stream(engine.stream_contexts[info.handle.index].http.stream, &native));
    try testing.expectEqual(.local, native.initiator);
    try testing.expect(native.send_prefix_size >= 3 and native.receive_prefix_size == 0);
    try testing.expect(observed.count < observed.records.len);
    observed.records[observed.count] = .{ .info = info };
    observed.count += 1;
    try testing.expectError(error.NotReady, observed.base.application.webtransport_stream_write(info.handle, "open"));
    try testing.expectError(error.NotReady, observed.base.application.webtransport_stream_finish(info.handle));
    if (observed.arm_open) try observed.base.application.webtransport_stream_want_writable(info.handle, true);
    if (observed.create_on_open) {
        observed.create_on_open = false;
        _ = try create(observed, info.session, .bidi);
    }
    return observed.allow_local_open;
}

fn opened(context: *anyopaque, info: streams.Info) bool {
    const observed: *Observation = @ptrCast(@alignCast(context));
    return open_checked(observed, info) catch |err| {
        observed.base.failure = err;
        return false;
    };
}

fn received(context: *anyopaque, handle: streams.Handle, bytes: []const u8) bool {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const record = record_for(observed, handle) catch |err| {
        observed.base.failure = err;
        return false;
    };
    if (observed.creating or record.info.direction != .bidi or record.closed != null or record.eof_calls != 0 or record.reset_calls != 0 or bytes.len > record.bytes.len - record.received) {
        observed.base.failure = error.InvalidOutgoingData;
        return false;
    }
    @memcpy(record.bytes[record.received..][0..bytes.len], bytes);
    record.received += bytes.len;
    record.data_calls += 1;
    if (observed.create_on_data) {
        observed.create_on_data = false;
        _ = create(observed, record.info.session, .bidi) catch |err| {
            observed.base.failure = err;
            return false;
        };
    }
    return true;
}

fn eof(context: *anyopaque, handle: streams.Handle, size: u64) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const record = record_for(observed, handle) catch |err| {
        observed.base.failure = err;
        return;
    };
    if (observed.creating or record.info.direction != .bidi or record.eof_calls != 0 or record.reset_calls != 0) observed.base.failure = error.InvalidOutgoingEof;
    record.eof_calls += 1;
    record.eof_size = size;
}

fn reset(context: *anyopaque, handle: streams.Handle, code: streams.ErrorCode, size: u64) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const record = record_for(observed, handle) catch |err| {
        observed.base.failure = err;
        return;
    };
    if (observed.creating or record.info.direction != .bidi or record.eof_calls != 0 or record.reset_calls != 0) observed.base.failure = error.InvalidOutgoingReset;
    record.reset_calls += 1;
    record.reset_code = code;
    record.reset_size = size;
}

fn stopped(context: *anyopaque, handle: streams.Handle, code: streams.ErrorCode) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const record = record_for(observed, handle) catch |err| {
        observed.base.failure = err;
        return;
    };
    if (observed.creating or record.stop_calls != 0) observed.base.failure = error.InvalidOutgoingStop;
    record.stop_calls += 1;
    record.stop_code = code;
}

fn closed(context: *anyopaque, event: streams.ClosedEvent) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const record = record_for(observed, event.handle) catch |err| {
        observed.base.failure = err;
        return;
    };
    if (observed.creating or record.closed != null or !observed.allow_local_open) observed.base.failure = error.InvalidOutgoingClose;
    record.closed = event;
}

fn session_open(context: *anyopaque, info: streams.SessionInfo) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    h.Consumer.callbacks.session_open.?(&observed.base, info);
    if (observed.create_on_session) {
        observed.create_on_session = false;
        _ = create(observed, info.handle, .uni) catch |err| {
            observed.base.failure = err;
            return;
        };
    }
}

fn session_closed(context: *anyopaque, event: streams.SessionClosedEvent) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    h.Consumer.callbacks.session_closed.?(&observed.base, event);
}

fn writable(context: *anyopaque, handle: streams.Handle) void {
    const observed: *Observation = @ptrCast(@alignCast(context));
    const record = record_for(observed, handle) catch |err| {
        observed.base.failure = err;
        return;
    };
    if (observed.creating) observed.base.failure = error.InlineOutgoingWritable;
    record.writable_calls += 1;
    if (observed.create_on_writable) {
        observed.create_on_writable = false;
        _ = create(observed, record.info.session, .bidi) catch |err| {
            observed.base.failure = err;
            return;
        };
    }
}

const callbacks: streams.Callbacks = .{ .open = opened, .data = received, .eof = eof, .reset = reset, .stop = stopped, .closed = closed, .session_open = session_open, .session_closed = session_closed, .writable = writable };

fn listen(application: *h.Application, observed: *Observation) !u16 {
    try application.enable_http3_ephemeral();
    _ = try application.webtransport_streams_context("/wt", observed, callbacks);
    _ = try application.route_context(.connect, "/wt", &observed.base, h.authorize);
    _ = try application.route_context(.post, "/health", &observed.base, h.health);
    try application.listen_udp("127.0.0.1", 0);
    return application.quic_transport.?.local_address.ip4.port;
}

fn pump(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation) !void {
    const clients = [_]*c.struct_uwz_app_client{client};
    try h.pump(application, &clients, &observed.base);
}

fn establish(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation) !streams.SessionHandle {
    const clients = [_]*c.struct_uwz_app_client{client};
    _ = try h.handshake(application, client, &clients, &observed.base);
    _ = try h.accept(application, client, &clients, &observed.base, 0);
    try testing.expectEqual(@as(usize, 1), observed.base.session_count);
    return observed.base.sessions[0].?.info.handle;
}

fn await_open(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation, handle: streams.Handle) !*Record {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        if (record_for(observed, handle)) |record| return record else |err| if (err != error.UnknownOutgoingHandle) return err;
        try pump(application, client, observed);
    }
    return error.OutgoingOpenTimeout;
}

fn await_peer(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation, id: u64, bytes: []const u8, fin: bool) !void {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, client, observed);
        var response: c.struct_uwz_app_response_snapshot = undefined;
        if (c.uwz_app_client_response(client, id, &response) != 0) continue;
        if (response.typed_callbacks == 0 or response.received < bytes.len or (fin and response.fin_received == 0)) continue;
        try testing.expectEqual(@as(c_int, c.LSQUIC_WTS_OK), response.typed_info_result);
        try testing.expect(response.typed_info.flags & c.LSQUIC_WTSF_CHILD != 0);
        try testing.expect(response.typed_info.flags & c.LSQUIC_WTSF_LOCAL == 0);
        try testing.expect(response.typed_info.receive_prefix_size >= 3);
        try testing.expectEqualSlices(u8, bytes, response.bytes[0..response.received]);
        try testing.expectEqual(@as(c_uint, 0), response.header_callbacks);
        return;
    }
    return error.OutgoingPeerTimeout;
}

fn await_closed(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation, record: *Record) !streams.ClosedEvent {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        if (record.closed) |event| return event;
        try pump(application, client, observed);
    }
    return error.OutgoingCloseTimeout;
}

fn healthy(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation) !void {
    const clients = [_]*c.struct_uwz_app_client{client};
    try h.healthy_http(application, client, &clients, &observed.base);
}

fn finish_bidi(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation, record: *Record) !void {
    try application.webtransport_stream_finish(record.info.handle);
    try await_peer(application, client, observed, record.info.stream_id, "", true);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, record.info.stream_id, "", 0, 1));
    _ = try await_closed(application, client, observed, record);
}

test "public outgoing UNI sends binary payload and FIN without a receive half" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_OUTGOING) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const parent = try establish(&application, client, &observed);
    const handle = try create(&observed, parent, .uni);
    const record = try await_open(&application, client, &observed, handle);
    try testing.expectError(error.Unsupported, application.webtransport_stream_stop(handle, 1));
    var bytes = [_]u8{ 0, 0xff, 0x41, 'u', 'n', 'i', 0xfe };
    const expected = bytes;
    try testing.expectEqual(bytes.len, try application.webtransport_stream_write(handle, &bytes));
    @memset(&bytes, 0xa5);
    try application.webtransport_stream_finish(handle);
    try await_peer(&application, client, &observed, record.info.stream_id, &expected, true);
    const event = try await_closed(&application, client, &observed, record);
    try testing.expectEqual(@as(?u64, null), event.final_payload_size);
    try testing.expectEqual(@as(u64, 0), event.accounted_bytes);
    try testing.expectEqual(@as(usize, 0), record.data_calls + record.eof_calls + record.reset_calls);
    try testing.expectError(error.StaleHandle, application.webtransport_stream_write(handle, "stale"));
    try healthy(&application, client, &observed);
}

test "public outgoing BIDI exchanges payload with zero receive prefix accounting" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_OUTGOING) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const parent = try establish(&application, client, &observed);
    const handle = try create(&observed, parent, .bidi);
    const record = try await_open(&application, client, &observed, handle);
    const request = [_]u8{ 0, 's', 'e', 'n', 'd', 0xff };
    try testing.expectEqual(request.len, try application.webtransport_stream_write(handle, &request));
    try application.webtransport_stream_finish(handle);
    try await_peer(&application, client, &observed, record.info.stream_id, &request, true);
    const reply = [_]u8{ 0xfe, 'r', 'e', 'p', 'l', 'y', 0 };
    const reply_result = c.uwz_app_client_write(client, record.info.stream_id, &reply, reply.len, 1);
    if (reply_result != 0) {
        var advertised: c.struct_uwz_app_peer_transport_diagnostics = undefined;
        const status = c.uwz_app_peer_transport_diagnose(c.uwz_app_client_connection(client), &advertised);
        std.debug.print("BIDI peer reply result={d} serverTPstatus={d} bidiLocal={d} bidiRemote={d}\n", .{ reply_result, status, if (status == 0) advertised.bidi_local else 0, if (status == 0) advertised.bidi_remote else 0 });
    }
    try testing.expectEqual(@as(c_int, 0), reply_result);
    const event = try await_closed(&application, client, &observed, record);
    try testing.expectEqualSlices(u8, &reply, record.bytes[0..record.received]);
    try testing.expectEqual(@as(usize, 1), record.eof_calls);
    try testing.expectEqual(@as(?u64, reply.len), record.eof_size);
    try testing.expectEqual(@as(?u64, reply.len), event.final_payload_size);
    try testing.expectEqual(@as(u64, reply.len), event.accounted_bytes);
    try healthy(&application, client, &observed);
}

test "public outgoing creation from session open defers local admission" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application }, .create_on_session = true, .arm_open = true };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_OUTGOING) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    _ = try establish(&application, client, &observed);
    try testing.expectEqual(@as(usize, 1), observed.created_count);
    const record = try await_open(&application, client, &observed, observed.created[0].?);
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        if (record.writable_calls != 0) break;
        try pump(&application, client, &observed);
    }
    try testing.expectEqual(@as(usize, 1), record.writable_calls);
    try application.webtransport_stream_finish(record.info.handle);
    try await_peer(&application, client, &observed, record.info.stream_id, "", true);
    _ = try await_closed(&application, client, &observed, record);
    try healthy(&application, client, &observed);
}

test "public outgoing creation from local open and writable callbacks is deferred" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application }, .create_on_open = true };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_OUTGOING) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const parent = try establish(&application, client, &observed);
    const first = try create(&observed, parent, .bidi);
    const first_record = try await_open(&application, client, &observed, first);
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        if (observed.created_count == 2 and observed.count == 2) break;
        try pump(&application, client, &observed);
    }
    try testing.expectEqual(@as(usize, 2), observed.created_count);
    try testing.expectEqual(@as(usize, 2), observed.count);
    observed.create_on_writable = true;
    try application.webtransport_stream_want_writable(first, true);
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        if (observed.created_count == 3 and observed.count == 3) break;
        try pump(&application, client, &observed);
    }
    try testing.expectEqual(@as(usize, 3), observed.created_count);
    try testing.expectEqual(@as(usize, 1), first_record.writable_calls);
    for (observed.records[0..observed.count]) |*slot| try finish_bidi(&application, client, &observed, &slot.*.?);
    try healthy(&application, client, &observed);
}

fn fail_wake(_: *anyopaque) error{WakeFailed}!void {
    return error.WakeFailed;
}

test "public outgoing creation wake and identity failures preserve reservations" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_OUTGOING) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const parent = try establish(&application, client, &observed);
    const engine = &application.quic_transport.?.engine;
    const before_count = engine.stream_pool.count_active();
    const before_generation = engine.stream_generation;
    const before_leases = engine.connections.pool.storage[parent.connection_index].stream_count;
    const wake = engine.binding.?.wake;
    defer engine.binding.?.wake = wake;
    engine.binding.?.wake = fail_wake;
    try testing.expectError(error.WakeFailed, application.webtransport_stream_create(parent, .bidi));
    try testing.expectEqual(before_count, engine.stream_pool.count_active());
    try testing.expectEqual(before_generation, engine.stream_generation);
    try testing.expectEqual(before_leases, engine.connections.pool.storage[parent.connection_index].stream_count);
    engine.binding.?.wake = wake;
    var wrong = parent;
    wrong.owner += 1;
    try testing.expectError(error.WrongApp, application.webtransport_stream_create(wrong, .bidi));
    wrong = parent;
    wrong.generation += 1;
    try testing.expectError(error.StaleHandle, application.webtransport_stream_create(wrong, .bidi));
    wrong = parent;
    wrong.connection_generation += 1;
    try testing.expectError(error.StaleHandle, application.webtransport_stream_create(wrong, .uni));
    try testing.expectEqual(before_count, engine.stream_pool.count_active());
    try testing.expectEqual(before_generation, engine.stream_generation);
    try testing.expectEqual(before_leases, engine.connections.pool.storage[parent.connection_index].stream_count);
    for (0..64) |_| try pump(&application, client, &observed);
    try testing.expectEqual(@as(usize, 0), observed.count);
    const handle = try create(&observed, parent, .bidi);
    try finish_bidi(&application, client, &observed, try await_open(&application, client, &observed, handle));
    try healthy(&application, client, &observed);
}

test "public outgoing creation refuses generation exhaustion before native work" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_OUTGOING) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const parent = try establish(&application, client, &observed);
    const engine = &application.quic_transport.?.engine;
    const before_count = engine.stream_pool.count_active();
    const before_leases = engine.connections.pool.storage[parent.connection_index].stream_count;
    const generation = engine.stream_generation;
    engine.stream_generation = std.math.maxInt(u64);
    try testing.expectError(error.GenerationExhausted, application.webtransport_stream_create(parent, .bidi));
    try testing.expectEqual(before_count, engine.stream_pool.count_active());
    try testing.expectEqual(before_leases, engine.connections.pool.storage[parent.connection_index].stream_count);
    try testing.expectEqual(std.math.maxInt(u64), engine.stream_generation);
    for (0..64) |_| try pump(&application, client, &observed);
    try testing.expectEqual(@as(usize, 0), observed.count);
    engine.stream_generation = generation;
    try healthy(&application, client, &observed);
}

test "public outgoing default zero BIDI byte credit returns WouldBlock without queued creation" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const parent = try establish(&application, client, &observed);
    const engine = &application.quic_transport.?.engine;
    const before_count = engine.stream_pool.count_active();
    const before_generation = engine.stream_generation;
    const before_leases = engine.connections.pool.storage[parent.connection_index].stream_count;
    var peer: c.struct_uwz_app_peer_transport_diagnostics = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_peer_transport_diagnose(engine.connections.pool.storage[parent.connection_index].native, &peer));
    try testing.expectEqual(@as(u64, 8), peer.streams_bidi);
    try testing.expectEqual(@as(u64, 0), peer.bidi_remote);
    try testing.expectError(error.WouldBlock, application.webtransport_stream_create(parent, .bidi));
    try testing.expectEqual(before_count, engine.stream_pool.count_active());
    try testing.expectEqual(before_generation, engine.stream_generation);
    try testing.expectEqual(before_leases, engine.connections.pool.storage[parent.connection_index].stream_count);
    for (0..64) |_| try pump(&application, client, &observed);
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expectEqual(before_count, engine.stream_pool.count_active());
    try healthy(&application, client, &observed);
}

test "public outgoing pool exhaustion reserves before native creation and releases after close" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_OUTGOING) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const parent = try establish(&application, client, &observed);
    const engine = &application.quic_transport.?.engine;
    try testing.expectEqual(@as(usize, 1), engine.stream_pool.count_active());
    for (0..7) |_| _ = try create(&observed, parent, .bidi);
    try testing.expectEqual(@as(usize, 8), engine.stream_pool.count_active());
    const generation = engine.stream_generation;
    try testing.expectError(error.CapacityExceeded, application.webtransport_stream_create(parent, .bidi));
    try testing.expectEqual(generation, engine.stream_generation);
    try testing.expectEqual(@as(usize, 8), engine.connections.pool.storage[parent.connection_index].stream_count);
    for (observed.created[0..observed.created_count]) |handle| _ = try await_open(&application, client, &observed, handle.?);
    for (0..64) |_| try pump(&application, client, &observed);
    try testing.expectEqual(@as(usize, 7), observed.count);
    for (observed.records[0..observed.count]) |*slot| try finish_bidi(&application, client, &observed, &slot.*.?);
    try testing.expectEqual(@as(usize, 1), engine.stream_pool.count_active());
    try healthy(&application, client, &observed);
}

fn credit_recovery(direction: streams.Direction, variant: c.enum_uwz_app_client_variant, initial: usize) !void {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, variant) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const parent = try establish(&application, client, &observed);
    const engine = &application.quic_transport.?.engine;
    var peer: c.struct_uwz_app_peer_transport_diagnostics = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_peer_transport_diagnose(engine.connections.pool.storage[parent.connection_index].native, &peer));
    try testing.expectEqual(@as(u64, 65536), peer.bidi_remote);
    if (direction == .bidi) try testing.expectEqual(@as(u64, 2), peer.streams_bidi) else try testing.expectEqual(@as(u64, 4), peer.streams_uni);
    for (0..initial) |_| _ = try create(&observed, parent, direction);
    const before_count = engine.stream_pool.count_active();
    const before_generation = engine.stream_generation;
    const before_leases = engine.connections.pool.storage[parent.connection_index].stream_count;
    try testing.expect(before_count < 8);
    try testing.expectError(error.WouldBlock, application.webtransport_stream_create(parent, direction));
    try testing.expectEqual(before_count, engine.stream_pool.count_active());
    try testing.expectEqual(before_generation, engine.stream_generation);
    try testing.expectEqual(before_leases, engine.connections.pool.storage[parent.connection_index].stream_count);
    for (observed.created[0..observed.created_count]) |handle| _ = try await_open(&application, client, &observed, handle.?);
    const first = try record_for(&observed, observed.created[0].?);
    if (direction == .bidi) {
        try finish_bidi(&application, client, &observed, first);
    } else {
        try application.webtransport_stream_finish(first.info.handle);
        try await_peer(&application, client, &observed, first.info.stream_id, "", true);
        _ = try await_closed(&application, client, &observed, first);
    }
    // Only actual stream completion and peer MAX_STREAMS can replenish this credit.
    for (0..128) |_| try pump(&application, client, &observed);
    try testing.expectEqual(initial, observed.count);
    try testing.expectEqual(initial, observed.created_count);
    var next: ?streams.Handle = null;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        const handle = application.webtransport_stream_create(parent, direction) catch |err| {
            if (err != error.WouldBlock) return err;
            try pump(&application, client, &observed);
            continue;
        };
        next = handle;
        break;
    }
    const handle = next orelse return error.OutgoingCreditRecoveryTimeout;
    const record = try await_open(&application, client, &observed, handle);
    try testing.expect(record.info.stream_id > first.info.stream_id);
    if (direction == .bidi) {
        try finish_bidi(&application, client, &observed, record);
    } else {
        try application.webtransport_stream_finish(handle);
        try await_peer(&application, client, &observed, record.info.stream_id, "", true);
        _ = try await_closed(&application, client, &observed, record);
    }
    for (observed.records[0..observed.count]) |*slot| {
        if (slot.*.?.closed != null) continue;
        try finish_bidi(&application, client, &observed, &slot.*.?);
    }
    try healthy(&application, client, &observed);
}

test "public outgoing BIDI MAX_STREAMS blocking and real completion credit recover without queued factory work" {
    try credit_recovery(.bidi, c.UWZ_APP_CLIENT_OUTGOING_BIDI_CREDIT, 2);
}

test "public outgoing UNI MAX_STREAMS blocking and real completion credit recover without queued factory work" {
    try credit_recovery(.uni, c.UWZ_APP_CLIENT_OUTGOING_UNI_CREDIT, 1);
}

fn await_peer_error(application: *h.Application, client: *c.struct_uwz_app_client, observed: *Observation, id: u64, how: usize, code: u32) !void {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try pump(application, client, observed);
        var response: c.struct_uwz_app_response_snapshot = undefined;
        if (c.uwz_app_client_response(client, id, &response) != 0) continue;
        if (response.reset_events[how] == 0 or response.typed_callbacks == 0) continue;
        try testing.expectEqual(@as(c_uint, 1), response.reset_events[how]);
        try testing.expectEqual(@as(c_int, c.LSQUIC_SERR_AVAILABLE), response.reset_error_status[how]);
        try testing.expectEqual(support.webtransport.application_error_to_http3(code), response.reset_error_code[how]);
        try testing.expectEqual(@as(c_int, c.LSQUIC_WTS_OK), response.typed_info_result);
        try testing.expectEqual(@as(c_uint, 1), response.typed_callbacks);
        try testing.expect(response.typed_info.flags & c.LSQUIC_WTSF_CHILD != 0);
        try testing.expect(response.typed_info.flags & c.LSQUIC_WTSF_LOCAL == 0);
        try testing.expect(response.typed_info.receive_prefix_size >= 3);
        return;
    }
    return error.OutgoingPeerErrorTimeout;
}

test "public outgoing UNI reset retains its reliable association prefix and mapped code" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_OUTGOING) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const parent = try establish(&application, client, &observed);
    const record = try await_open(&application, client, &observed, try create(&observed, parent, .uni));
    try application.webtransport_stream_reset(record.info.handle, 0xffff_ffff);
    try testing.expectError(error.WriteClosed, application.webtransport_stream_finish(record.info.handle));
    try await_peer_error(&application, client, &observed, record.info.stream_id, 0, 0xffff_ffff);
    const event = try await_closed(&application, client, &observed, record);
    try testing.expectEqual(@as(?u64, null), event.final_payload_size);
    try testing.expectEqual(@as(u64, 0), event.accounted_bytes);
    try testing.expectEqual(@as(usize, 0), record.data_calls + record.eof_calls + record.reset_calls);
    try healthy(&application, client, &observed);
}

test "public outgoing BIDI local half controls preserve their opposite halves" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_OUTGOING) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const parent = try establish(&application, client, &observed);
    const stopped_record = try await_open(&application, client, &observed, try create(&observed, parent, .bidi));
    try await_peer(&application, client, &observed, stopped_record.info.stream_id, "", false);
    try application.webtransport_stream_stop(stopped_record.info.handle, 71);
    try testing.expectEqual(@as(usize, 5), try application.webtransport_stream_write(stopped_record.info.handle, "after"));
    try application.webtransport_stream_finish(stopped_record.info.handle);
    try await_peer_error(&application, client, &observed, stopped_record.info.stream_id, 1, 71);
    try await_peer(&application, client, &observed, stopped_record.info.stream_id, "after", true);
    _ = try await_closed(&application, client, &observed, stopped_record);
    try testing.expectEqual(@as(usize, 0), stopped_record.data_calls + stopped_record.eof_calls + stopped_record.reset_calls);
    const reset_record = try await_open(&application, client, &observed, try create(&observed, parent, .bidi));
    try await_peer(&application, client, &observed, reset_record.info.stream_id, "", false);
    try application.webtransport_stream_reset(reset_record.info.handle, 72);
    try await_peer_error(&application, client, &observed, reset_record.info.stream_id, 0, 72);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, reset_record.info.stream_id, "reply", 5, 1));
    const event = try await_closed(&application, client, &observed, reset_record);
    try testing.expectEqualSlices(u8, "reply", reset_record.bytes[0..reset_record.received]);
    try testing.expectEqual(@as(?u64, 5), event.final_payload_size);
    try testing.expectEqual(@as(u64, 5), event.accounted_bytes);
    try testing.expectEqual(@as(usize, 1), reset_record.eof_calls);
    try healthy(&application, client, &observed);
}

test "public outgoing creation from data callback defers a second local admission" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application }, .create_on_data = true };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_OUTGOING) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const parent = try establish(&application, client, &observed);
    const record = try await_open(&application, client, &observed, try create(&observed, parent, .bidi));
    try testing.expectEqual(@as(usize, 5), try application.webtransport_stream_write(record.info.handle, "first"));
    try await_peer(&application, client, &observed, record.info.stream_id, "first", false);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, record.info.stream_id, "data", 4, 0));
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        if (observed.created_count == 2 and observed.count == 2) break;
        try pump(&application, client, &observed);
    }
    try testing.expectEqual(@as(usize, 2), observed.created_count);
    try testing.expectEqual(@as(usize, 2), observed.count);
    try testing.expectEqualSlices(u8, "data", record.bytes[0..record.received]);
    try application.webtransport_stream_finish(record.info.handle);
    try await_peer(&application, client, &observed, record.info.stream_id, "first", true);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, record.info.stream_id, "", 0, 1));
    _ = try await_closed(&application, client, &observed, record);
    try finish_bidi(&application, client, &observed, try record_for(&observed, observed.created[1].?));
    try healthy(&application, client, &observed);
}

test "public outgoing declined admission owns no close notification" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application }, .allow_local_open = false };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_OUTGOING) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const parent = try establish(&application, client, &observed);
    const handle = try create(&observed, parent, .uni);
    const record = try await_open(&application, client, &observed, handle);
    try await_peer_error(&application, client, &observed, record.info.stream_id, 0, 0);
    for (0..64) |_| try pump(&application, client, &observed);
    try testing.expect(record.closed == null);
    try testing.expectError(error.StaleHandle, application.webtransport_stream_finish(handle));
    try healthy(&application, client, &observed);
}

test "public outgoing shutdown before typed publication owns no admission or close" {
    var application = try h.initialize();
    var destroyed = false;
    defer if (!destroyed) h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_OUTGOING) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const parent = try establish(&application, client, &observed);
    _ = try create(&observed, parent, .bidi);
    try testing.expectEqual(@as(usize, 0), observed.count);
    try application.shutdown();
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        if (application.quic_transport.?.is_drained()) break;
        try application.loop.get_xev_loop().run(.no_wait);
    }
    try testing.expect(application.quic_transport.?.is_drained());
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expectError(error.ShuttingDown, application.webtransport_stream_create(parent, .uni));
    // I/O drain precedes native destruction, which owns final lease release.
    h.destroy(&application);
    destroyed = true;
    try testing.expectEqual(@as(usize, 0), observed.count);
    try h.checked(&observed.base);
}

test "public outgoing parent closure retires owned local child and factory session handle" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .base = .{ .application = &application } };
    const port = try listen(&application, &observed);
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_OUTGOING) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const parent = try establish(&application, client, &observed);
    const record = try await_open(&application, client, &observed, try create(&observed, parent, .bidi));
    try h.finish_send(client, 0);
    const event = try await_closed(&application, client, &observed, record);
    try testing.expectEqual(.session_closed, event.reason);
    try testing.expectEqual(@as(usize, 1), observed.base.session_closed_count);
    try testing.expectError(error.StaleHandle, application.webtransport_stream_create(parent, .uni));
    try testing.expectError(error.StaleHandle, application.webtransport_stream_write(record.info.handle, "stale"));
    try healthy(&application, client, &observed);
}
