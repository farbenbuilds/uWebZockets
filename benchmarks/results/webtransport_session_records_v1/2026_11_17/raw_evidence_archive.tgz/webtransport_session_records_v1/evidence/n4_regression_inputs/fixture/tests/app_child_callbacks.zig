const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const h = @import("app_children.zig").ChildrenSupport;
const testing = std.testing;
const App = h.Application;
const Observation = h.Observation;
const child = support.webtransport_child_runtime;
const backend = support.webtransport_backend;
const payload_size = 3072;

fn fill_payload(bytes: *[payload_size]u8) void {
    for (bytes, 0..) |*byte, index| byte.* = @truncate(index * 17);
}

fn stage(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, observed: *Observation, index: usize, bytes: *const [payload_size]u8) !u64 {
    const id = try h.raw_uni(client, 0, "");
    try h.await_pending_native(application, clients, observed, index, id, 0);
    {
        const native = try h.native_client_stream(client, id);
        try testing.expectEqual(@as(isize, bytes.len), c.lsquic_stream_write(native, bytes, bytes.len));
        try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_shutdown(native, 1));
    }
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(application, clients, observed);
        const native = try h.native_server_stream(application, index, id);
        var before: backend.ReceiveSnapshot = .{};
        try testing.expectEqual(backend.QueryResult.ok, backend.read_receive(native, &before));
        const readable = c.uwz_app_stream_buffered_bytes(native);
        try testing.expect(readable != std.math.maxInt(u64));
        var after: backend.ReceiveSnapshot = .{};
        try testing.expectEqual(backend.QueryResult.ok, backend.read_receive(native, &after));
        try testing.expectEqualDeep(before, after);
        if (readable != bytes.len or !before.fin_received) continue;
        const state = try h.waiting_state(application, index, id);
        try testing.expectEqual(@as(?u64, bytes.len + state.metadata.receive_prefix_size), before.final_size);
        try testing.expectEqual(@as(u64, 0), state.ledger.payload_read);
        try testing.expectEqual(@as(usize, 0), observed.count);
        try testing.expectEqual(@as(usize, 0), observed.authorization_calls);
        return id;
    }
    return error.MultiChunkStagingTimeout;
}

fn open_parent(client: *c.struct_uwz_app_client) !void {
    var request: c.struct_uwz_app_connect_request = .{
        .origin = "https://localhost",
        .authorization = "Bearer admission-fixture",
        .duplicate_origin = 0,
    };
    try testing.expectEqual(@as(u64, 0), c.uwz_app_client_open_connect(client, &request));
}

fn await_owned_close(application: *App, clients: []const *c.struct_uwz_app_client, observed: *Observation) !*h.Record {
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(application, clients, observed);
        if (observed.count == 0 or observed.records[0].?.closed == null) continue;
        return &observed.records[0].?;
    }
    return error.CallbackOwnedCloseTimeout;
}

fn expect_terminal(record: *const h.Record, reason: child.CloseReason, expected: []const u8) !void {
    try testing.expectEqualSlices(u8, expected, record.bytes[0..record.received]);
    try testing.expectEqual(@as(usize, if (expected.len == 0) 0 else 1), record.data_calls);
    try testing.expectEqual(@as(usize, 0), record.eof_calls);
    try testing.expectEqual(@as(usize, 0), record.reset_calls);
    try testing.expectEqual(@as(usize, 0), record.stop_calls);
    const event = record.closed orelse return error.MissingOwnedClose;
    try testing.expectEqual(reason, event.reason);
    try testing.expectEqual(@as(?u64, payload_size), event.final_payload_size);
    try testing.expectEqual(@as(u64, payload_size), event.accounted_bytes);
}

fn drain_children(application: *App, clients: []const *c.struct_uwz_app_client, observed: *Observation, handle: support.webtransport_runtime.ConnectionHandle) !void {
    const engine = &application.quic_transport.?.engine;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(application, clients, observed);
        if (engine.connections.find(handle) != null) continue;
        try testing.expectEqual(@as(usize, 0), engine.stream_pool.count_active());
        try testing.expectEqual(@as(usize, 0), engine.connections.pool.count_active());
        try testing.expectEqual(@as(usize, 0), engine.active_connections);
        try testing.expectEqual(@as(usize, 0), engine.pending_child_count);
        try testing.expectEqual(@as(usize, 0), engine.child_retry_count);
        try testing.expectEqual(@as(usize, 1), observed.count);
        try testing.expect(observed.records[0].?.closed != null);
        try testing.expectEqual(@as(usize, 1), observed.session_count);
        try testing.expectEqual(@as(usize, 1), observed.session_closed_count);
        try testing.expectEqual(h.Streams.CloseReason.shutdown, observed.sessions[0].?.closed.?.reason);
        for (0..16) |_| try h.pump(application, clients, observed);
        try testing.expectEqual(@as(usize, 0), engine.stream_pool.count_active());
        try testing.expectEqual(@as(usize, 0), engine.pending_child_count);
        try testing.expectEqual(@as(usize, 0), engine.child_retry_count);
        try testing.expectEqual(@as(usize, 1), observed.count);
        try testing.expectEqual(@as(usize, 1), observed.session_closed_count);
        return;
    }
    return error.CallbackChildDrainTimeout;
}

fn cooldown_case(on_open: bool) !void {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{
        .application = &application,
        .cooldown_on_open = on_open,
        .request_cooldown = !on_open,
    };
    const port = try h.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    const engine = &application.quic_transport.?.engine;
    const handle = engine.connections.pool.storage[index].handle;
    var bytes: [payload_size]u8 = undefined;
    fill_payload(&bytes);
    const id = try stage(&application, client, &clients, &observed, index, &bytes);
    const future = try h.raw_uni(client, 4, "future");
    try h.await_pending_native(&application, &clients, &observed, index, future, 4);
    try h.await_buffered(&application, &clients, &observed, index, future, "future");
    try testing.expectEqual(@as(usize, 2), engine.pending_child_count);
    try open_parent(client);
    const record = try await_owned_close(&application, &clients, &observed);
    try testing.expectEqualDeep(handle, record.info.key.connection);
    try testing.expectEqual(id, record.info.key.stream_id);
    try expect_terminal(record, .shutdown, bytes[0..if (on_open) 0 else 2048]);
    try testing.expectEqual(@as(?u64, support.webtransport.wt_session_gone), record.closed.?.code);
    try testing.expect(observed.deferred_cooldown and engine.children_shutdown);
    try testing.expect(!engine.cooldown_pending and !engine.in_cooldown and engine.callback_depth == 0);
    try testing.expectEqual(@as(c_int, c.LSCONN_ST_GOING_AWAY), @as(c_int, @intCast(c.lsquic_conn_status(engine.connections.pool.storage[index].native, null, 0))));
    try drain_children(&application, &clients, &observed, handle);
    try expect_terminal(record, .shutdown, bytes[0..if (on_open) 0 else 2048]);
}

test "accepted child open cooldown owns close without delivering prebuffered data" {
    try cooldown_case(true);
}

test "child data cooldown stops before a second prebuffered read chunk" {
    try cooldown_case(false);
}

test "child data connection abort stops before a second prebuffered read chunk" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .application = &application, .abort_on_data = true };
    const port = try h.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    const engine = &application.quic_transport.?.engine;
    const handle = engine.connections.pool.storage[index].handle;
    var bytes: [payload_size]u8 = undefined;
    fill_payload(&bytes);
    const id = try stage(&application, client, &clients, &observed, index, &bytes);
    try open_parent(client);
    const record = try await_owned_close(&application, &clients, &observed);
    try testing.expectEqual(@as(c_int, c.LSCONN_ST_USER_ABORTED), observed.abort_status);
    try testing.expectEqualDeep(handle, record.info.key.connection);
    try testing.expectEqual(id, record.info.key.stream_id);
    try expect_terminal(record, .connection_closed, bytes[0..2048]);
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        if (engine.connections.find(handle) != null) continue;
        try testing.expectEqual(@as(usize, 0), engine.stream_pool.count_active());
        try testing.expectEqual(@as(usize, 0), engine.pending_child_count);
        try testing.expectEqual(@as(usize, 0), engine.child_retry_count);
        for (0..16) |_| try h.pump(&application, &clients, &observed);
        try expect_terminal(record, .connection_closed, bytes[0..2048]);
        return;
    }
    return error.CallbackAbortDrainTimeout;
}

fn await_parent_only(application: *App, clients: []const *c.struct_uwz_app_client, observed: *Observation, index: usize) !void {
    const engine = &application.quic_transport.?.engine;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(application, clients, observed);
        if (engine.stream_pool.count_active() != 1) continue;
        try testing.expectEqual(@as(usize, 1), engine.connections.pool.storage[index].stream_count);
        try testing.expectEqual(@as(usize, 0), engine.pending_child_count);
        try testing.expectEqual(@as(usize, 0), engine.child_retry_count);
        for (0..16) |_| try h.pump(application, clients, observed);
        return;
    }
    return error.RejectedChildLeaseTimeout;
}

test "declined child open sends exact rejection without consumer close ownership" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .application = &application, .allow_open = false };
    const port = try h.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    _ = try h.accept(&application, client, &clients, &observed, 0);
    const id = try h.open_child(&application, client, 0, .uni);
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_write(client, id, "decline", 7, 0));
    try h.peer_stop(&application, client, &clients, &observed, id, support.webtransport.application_error_to_http3(0));
    try await_parent_only(&application, &clients, &observed, index);
    try testing.expectEqual(@as(usize, 1), observed.count);
    const record = &observed.records[0].?;
    try testing.expectEqual(id, record.info.key.stream_id);
    try testing.expectEqual(@as(usize, 0), record.received);
    try testing.expectEqual(@as(usize, 0), record.data_calls);
    try testing.expectEqual(@as(usize, 0), record.eof_calls);
    try testing.expectEqual(@as(usize, 0), record.reset_calls);
    try testing.expectEqual(@as(usize, 0), record.stop_calls);
    try testing.expect(record.closed == null);
    try h.healthy_http(&application, client, &clients, &observed);
}

test "declined data cancels only the owned child after one complete borrowed chunk" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .application = &application, .cancel_data = true };
    const port = try h.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    var bytes: [payload_size]u8 = undefined;
    fill_payload(&bytes);
    const id = try stage(&application, client, &clients, &observed, index, &bytes);
    _ = try h.accept(&application, client, &clients, &observed, 0);
    const key = try h.key_for(&application, index, 0, id);
    const record = try h.await_closed(&application, &clients, &observed, key);
    try expect_terminal(record, .consumer_cancelled, bytes[0..2048]);
    try testing.expectEqual(@as(?u64, support.webtransport.application_error_to_http3(0)), record.closed.?.code);
    try await_parent_only(&application, &clients, &observed, index);
    try expect_terminal(record, .consumer_cancelled, bytes[0..2048]);
    try testing.expect(!application.quic_transport.?.engine.children_shutdown);
    try h.healthy_http(&application, client, &clients, &observed);
}

test "second child open cooldown preserves shutdown cause for its already owned sibling" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .application = &application, .cooldown_on_open = true };
    const port = try h.listen(&application, &observed);
    const client = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(client);
    const clients = [_]*c.struct_uwz_app_client{client};
    const index = try h.handshake(&application, client, &clients, &observed);
    const engine = &application.quic_transport.?.engine;
    const handle = engine.connections.pool.storage[index].handle;
    const sibling_id = try h.raw_uni(client, 0, "owned");
    try h.await_pending_native(&application, &clients, &observed, index, sibling_id, 0);
    try h.await_buffered(&application, &clients, &observed, index, sibling_id, "owned");
    var bytes: [payload_size]u8 = undefined;
    fill_payload(&bytes);
    const trigger_id = try h.raw_uni(client, 0, "");
    try h.await_pending_native(&application, &clients, &observed, index, trigger_id, 0);
    {
        const native = try h.native_client_stream(client, trigger_id);
        try testing.expectEqual(@as(isize, bytes.len), c.lsquic_stream_write(native, &bytes, bytes.len));
        try testing.expectEqual(@as(c_int, 0), c.lsquic_stream_flush(native));
    }
    var buffered = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        const native = try h.native_server_stream(&application, index, trigger_id);
        const snapshot = try h.receive_snapshot(&application, index, trigger_id);
        try testing.expect(!snapshot.fin_received and snapshot.final_size == null);
        if (c.uwz_app_stream_buffered_bytes(native) != bytes.len) continue;
        _ = try h.waiting_state(&application, index, trigger_id);
        buffered = true;
        break;
    }
    try testing.expect(buffered);
    observed.cooldown_open_target = sibling_id;
    observed.required_owned_sibling = trigger_id;
    try testing.expectEqual(@as(usize, 2), engine.pending_child_count);
    try open_parent(client);
    var sibling: ?*h.Record = null;
    var trigger: ?*h.Record = null;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        sibling = h.find_record(&observed, handle, sibling_id);
        trigger = h.find_record(&observed, handle, trigger_id);
        if (sibling == null or trigger == null) continue;
        if (sibling.?.closed != null and trigger.?.closed != null) break;
    }
    const first = sibling orelse return error.MissingOwnedSibling;
    const second = trigger orelse return error.MissingCooldownTrigger;
    try testing.expect(observed.owned_sibling_proven and observed.deferred_cooldown);
    try testing.expectEqual(@as(usize, 2), observed.count);
    try testing.expect(observed.sibling_bytes_at_cooldown == 0 or observed.sibling_bytes_at_cooldown == bytes.len);
    try testing.expectEqualSlices(u8, bytes[0..observed.sibling_bytes_at_cooldown], second.bytes[0..second.received]);
    try testing.expectEqual(observed.sibling_calls_at_cooldown, second.data_calls);
    try testing.expectEqual(@as(usize, 0), first.received);
    try testing.expectEqual(@as(usize, 0), first.data_calls);
    try testing.expectEqual(@as(usize, 0), first.eof_calls);
    try testing.expectEqual(@as(usize, 0), first.reset_calls);
    try testing.expectEqual(@as(usize, 0), first.stop_calls);
    const event = first.closed orelse return error.MissingSiblingClose;
    try testing.expectEqual(child.CloseReason.shutdown, event.reason);
    try testing.expectEqual(@as(?u64, support.webtransport.wt_session_gone), event.code);
    try testing.expectEqual(@as(u64, 5), event.accounted_bytes);
    try testing.expectEqual(@as(?u64, 5), event.final_payload_size);
    try testing.expectEqual(@as(usize, payload_size), observed.sibling_bytes_at_cooldown);
    try testing.expectEqual(@as(usize, 2), second.data_calls);
    try testing.expectEqual(@as(usize, 0), second.eof_calls);
    try testing.expectEqual(@as(usize, 0), second.reset_calls);
    try testing.expectEqual(@as(usize, 0), second.stop_calls);
    try testing.expectEqual(child.CloseReason.shutdown, second.closed.?.reason);
    try testing.expectEqual(@as(?u64, payload_size), second.closed.?.final_payload_size);
    try testing.expectEqual(@as(u64, payload_size), second.closed.?.accounted_bytes);
    try testing.expectEqual(@as(?u64, support.webtransport.wt_session_gone), second.closed.?.code);
    var drained = false;
    for (0..c.UWZ_APP_MAX_STEPS) |_| {
        try h.pump(&application, &clients, &observed);
        if (engine.connections.find(handle) != null) continue;
        drained = true;
        break;
    }
    try testing.expect(drained);
    try testing.expectEqual(@as(usize, 0), engine.stream_pool.count_active());
    try testing.expectEqual(@as(usize, 0), engine.connections.pool.count_active());
    try testing.expectEqual(@as(usize, 0), engine.pending_child_count);
    try testing.expectEqual(@as(usize, 0), engine.child_retry_count);
    try testing.expectEqual(@as(usize, 1), observed.session_count);
    try testing.expectEqual(@as(usize, 1), observed.session_closed_count);
    try testing.expectEqual(h.Streams.CloseReason.shutdown, observed.sessions[0].?.closed.?.reason);
    for (0..16) |_| try h.pump(&application, &clients, &observed);
    try testing.expectEqual(@as(usize, 2), observed.count);
    try testing.expectEqual(@as(usize, 1), observed.session_closed_count);
}
