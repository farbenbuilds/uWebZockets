# Session registry fixture handoff

Implementation commit: `eebd42ee8dc618434f9d9025159c9d8885576861`.
All 258 final Root source/build inputs were byte-verified against that commit.
Final source: `fixture/project_v4`.
Root manifest SHA-256: `8200fa9790bd24771071d920a1cc8afd593b957d5e3c3f8ce96c2034e4fa941e`.
Fixture40 manifest SHA-256: `2ffa53a7d57f778a5cb3540214374659b8c60dcb2f01ccfea38d61884e819e5a`.

The retained67 stream cohort and existing N4 33-case datagram cohort each
passed Debug, ReleaseSafe and ReleaseFast. Every final invocation completed
16/16 build steps with exit0. Counts remain separate. Raw logs are named
`v4-Streams-{mode}.log` and `v4-N4-{mode}.log`; results.json retains their
hashes. commands.txt contains expanded invocations and equivalent historical
replay commands. fixture/replay.sh validates source inventories before build.
No child build is live. The full warm cache was preserved and relocated to
/home/foo/Desktop/Repos/uWebZockets/.zig-cache/wt-session-records-proof-20261117
after a packaging write hit /tmp quota; parent owns any final replay coordination.

Seven old Zig fixture files changed only private observations. The one named
snapshot helper validates the global index/CONNECT lease and copies named
values. All original named tests, logical cases and wire/callback/queue
assertions are preserved. Public close observation gained checks for map and
record removal before callback. Fixture C and build/compiler inputs other
than those eight Zig files are unchanged. Exact diffs and assertion census
are retained. The N4 migration RED40 compiler inputs are byte-identical to
final40, verified in n4_regression_inputs/comparison_to_final.json.

Regression history is intentionally retained: original fixture/original Root
baseline32/33, migration v1 31/33, publication filter v2 32/33, scoped
write_connect trace1/2, broad flush v3 N4 33/33 but public streams64/67
(Debug and ReleaseSafe), then narrow v4 both cohorts fully green. No
expect_retired seam or reclassification was introduced. The baseline is
linked by immutable prior archive hash; all migration snapshots and exact
fix/trace diffs are included. project_trace_inputs.sha256 plus project_v2 and
n4-trace.diff reconstruct the isolated diagnostic source.

Two inherited N4 blocked-response reset cases privately enlarge client
sf_max_recv_win before asking Native to queue and send actual wire credit.
Their unchanged assertions verify the resulting MAX_STREAM_DATA/reset path,
but do not prove autonomous receiver credit growth. These are explicitly
named in source_profile.json. Streams67 has its separate actual wire
MAX_STREAMS recovery scope without private credit grants. Do not claim all
cases avoid private Native mutation.

Native005 and XEV heads are clean and unchanged; exact raw checks are in
dependency_status.log. Native observer proposals remain separate. This
source-only delivery includes no native/package trees, caches or binaries.
Dedicated smoke/security/sanitizer/fuzz campaigns remain user-deferred;
positive/multi-session flow, non-Linux runtime, independent draft-16 clients
and Native allocation-failure injection are outside this proof.

Parent ordinary v4 logs were independently copied after terminal completion:
1073/1073 unit tests (20/20steps), ReleaseSafe test-compile21/21steps,
ReleaseFast lib21/21steps, package-consumer18/18steps. They are separate from
this fixture matrix. Root graphify-v4 log was still live when copied and is
left to the parent. Index source/log proof is now included under state/: stub RED, initial GREEN,
churn RED and final six-test GREEN, plus x86 compile-only logs (no execution).
Final index/tests match the implementation commit. The new centralized unit
suite is separately retained under state; it is not a fixture compiler input.
Caches and x86 binaries are excluded. Parent owns final relocated replay, final
verification JSON, archive checksums and repository publication.
