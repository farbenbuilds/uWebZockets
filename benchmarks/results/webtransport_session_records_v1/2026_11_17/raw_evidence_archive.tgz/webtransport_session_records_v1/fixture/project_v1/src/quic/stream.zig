const std = @import("std");
const c = @import("c");
const Request = @import("../http/request.zig").Request;
const http_response = @import("../http/response.zig");
const Response = http_response.Response;
const Http3Target = http_response.Http3Target;
const file_transfer = @import("../http/file_transfer.zig");
const request_body = @import("../http/request_body.zig");
const streaming_request_module = @import("../http/streaming_request.zig");
const Router = @import("../router/radix.zig").Router;
const radix = @import("../router/radix.zig");
const validation = @import("validation.zig");
const dev_log_module = @import("../observability/dev_log.zig");

/// Reports that HTTP/3 stream support is compiled in.
pub const available = true;

/// Per-stream caller-owned storage and field capacities.
pub const Capacities = @import("stream_capacities.zig").Capacities;

/// Default capacity record used by the production stream.
pub const default_capacities: Capacities = @import("stream_capacities.zig").default_capacities;

/// Per-stream decoded request-header storage capacity of the default record.
pub const header_capacity = default_capacities.request_header_size;
/// Per-stream request body capacity of the default record.
pub const request_body_capacity = default_capacities.request_body_size;
/// Per-stream encoded response-header storage capacity of the default record.
pub const response_header_capacity = default_capacities.response_header_size;

/// Bounded decoded request and trailer fields with one-shot owner release.
pub const HeaderSet = @import("header_set.zig").HeaderSet;

const ResponsePhase = enum(u8) {
    idle,
    streaming,
    ready,
    sending,
    done,
};

const RequestPhase = enum(u8) {
    waiting_headers,
    body,
    trailers,
    complete,
};

/// Flushes queued native bytes without ending the write side.
pub const FlushFn = *const fn (?*c.lsquic_stream) callconv(.c) c_int;

/// lsquic stream entry points the response state machine calls.
///
/// Production binds `lsquic_stream_io`; tests substitute a fake so producer
/// resumption and drain accounting run without a live QUIC connection.
pub const StreamIo = struct {
    wantread: *const fn (?*c.lsquic_stream, c_int) callconv(.c) c_int,
    read: *const fn (?*c.lsquic_stream, ?*anyopaque, usize) callconv(.c) isize,
    wantwrite: *const fn (?*c.lsquic_stream, c_int) callconv(.c) c_int,
    write: *const fn (?*c.lsquic_stream, ?*const anyopaque, usize) callconv(.c) isize,
    send_headers: *const fn (
        ?*c.lsquic_stream,
        [*c]const c.lsquic_http_headers_t,
        c_int,
    ) callconv(.c) c_int,
    flush: FlushFn,
    shutdown: *const fn (?*c.lsquic_stream, c_int) callconv(.c) c_int,
    close: *const fn (?*c.lsquic_stream) callconv(.c) c_int,
};

/// Production lsquic stream entry points for one HTTP/3 stream.
pub const lsquic_stream_io: StreamIo = .{
    .wantread = c.lsquic_stream_wantread,
    .read = c.lsquic_stream_read,
    .wantwrite = c.lsquic_stream_wantwrite,
    .write = c.lsquic_stream_write,
    .send_headers = c.lsquic_stream_send_headers,
    .flush = c.lsquic_stream_flush,
    .shutdown = c.lsquic_stream_shutdown,
    .close = c.lsquic_stream_close,
};

/// Returns connection-owned, fixed-buffer HTTP/3 stream state bound to the
/// given lsquic stream entry points and per-stream capacity record.
pub fn stream_with(comptime io: StreamIo, comptime capacities: Capacities) type {
    if (capacities.response_header_size == 0 or
        capacities.response_header_size > std.math.maxInt(u16))
    {
        @compileError("HTTP/3 response header size must fit u16 offsets");
    }
    if (capacities.response_header_count == 0) {
        @compileError("HTTP/3 response header count must be greater than zero");
    }

    return struct {
        const Self = @This();
        /// Returns a stream to the owner that lent it storage.
        const StreamReleaseFn = *const fn (*anyopaque, *Self) void;

        owner: *anyopaque = undefined,
        release_fn: ?StreamReleaseFn = null,
        stream: *c.lsquic_stream = undefined,
        router: *const Router = undefined,
        header_set: ?*HeaderSet = null,
        body_storage: []u8 = &.{},
        response_body_storage: []u8 = &.{},
        response_header_storage: []u8 = &.{},
        // Engine-owned capture capacity slices, reused by every request this
        // stream dispatches; empty when captures stay inline.
        extra_param_names: [][]const u8 = &.{},
        extra_param_values: [][]const u8 = &.{},
        // Engine-owned request-field capacity slices, reused by every header
        // set this stream presents; empty when request fields stay inline.
        header_extra_names: [][]const u8 = &.{},
        header_extra_values: [][]const u8 = &.{},
        response_name_offsets: [capacities.response_header_count]u16 = .{0} ** capacities.response_header_count,
        response_name_lengths: [capacities.response_header_count]u16 = .{0} ** capacities.response_header_count,
        response_value_offsets: [capacities.response_header_count]u16 = .{0} ** capacities.response_header_count,
        response_value_lengths: [capacities.response_header_count]u16 = .{0} ** capacities.response_header_count,
        response_status: [10]u8 = undefined,
        /// Numeric status of the prepared response, recorded on completion.
        response_status_code: u16 = 0,
        body_length: usize = 0,
        response_body_length: usize = 0,
        response_body_offset: usize = 0,
        response_header_length: usize = 0,
        response_header_count: usize = 0,
        response_phase: ResponsePhase = .idle,
        request_phase: RequestPhase = .waiting_headers,
        headers_sent: bool = false,
        suppress_body: bool = false,
        dispatched: bool = false,
        stream_producer_context: ?*anyopaque = null,
        stream_producer: ?http_response.StreamProducer = null,
        async_response_state: http_response.AsyncResponseState = .{},
        file_transfer_state: file_transfer.FileTransfer = .{},
        streaming_active: bool = false,
        streaming_route: ?*const request_body.BodyRoute = null,
        streaming_request: streaming_request_module.StreamingRequest = undefined,
        streaming_pending_headers: request_body.PendingHeaders = .{},
        body_state: request_body.BodyState = .{},
        streaming_paused: bool = false,
        streaming_pending_len: usize = 0,

        /// Reinitializes a pooled stream with borrowed transport and storage.
        ///
        /// `extra_param_names`, `extra_param_values`, `header_extra_names`,
        /// and `header_extra_values` are equal-length caller-owned capacity
        /// slices; pass empty slices when the inline `Request` arrays cover
        /// every configured capture and request field.
        pub fn reset(
            self: *Self,
            owner: *anyopaque,
            release_fn: StreamReleaseFn,
            stream: *c.lsquic_stream,
            router: *const Router,
            body_storage: []u8,
            response_body_storage: []u8,
            response_header_storage: []u8,
            extra_param_names: [][]const u8,
            extra_param_values: [][]const u8,
            header_extra_names: [][]const u8,
            header_extra_values: [][]const u8,
        ) void {
            self.clear_stream_producer();
            var next_generation = self.async_response_state.generation +% 1;
            if (next_generation == 0) next_generation = 1;
            self.* = .{
                .owner = owner,
                .release_fn = release_fn,
                .stream = stream,
                .router = router,
                .body_storage = body_storage,
                .response_body_storage = response_body_storage,
                .response_header_storage = response_header_storage,
                .extra_param_names = extra_param_names,
                .extra_param_values = extra_param_values,
                .header_extra_names = header_extra_names,
                .header_extra_values = header_extra_values,
            };
            self.async_response_state.generation = next_generation;
            self.async_response_state.state = .cancelled;
        }

        /// Claims a finished header set or closes on invalid ownership state.
        pub fn attach_headers(self: *Self, header_set: *HeaderSet) void {
            if (!header_set.finished or header_set.claimed) {
                header_set.release();
                self.close_now();
                return;
            }

            if (header_set.is_trailer) {
                if (self.header_set == null or self.request_phase != .body) {
                    header_set.release();
                    self.close_now();
                    return;
                }
                header_set.claimed = true;
                self.request_phase = .trailers;
                header_set.release();
                return;
            }

            if (self.header_set != null or self.request_phase != .waiting_headers) {
                header_set.release();
                self.close_now();
                return;
            }
            header_set.claimed = true;
            self.header_set = header_set;
            self.request_phase = .body;
            _ = self.start_streaming_request();
        }

        /// Drains readable request bytes and dispatches a complete request.
        pub fn on_read(self: *Self) void {
            if (self.streaming_active) {
                self.stream_request_body();
                return;
            }
            if (self.header_set == null or self.dispatched) {
                self.close_now();
                return;
            }
            if (self.header_set.?.content_length) |expected| {
                if (expected > self.header_set.?.capacities.request_body_size) {
                    self.queue_error("413 Payload Too Large", "Payload Too Large");
                    return;
                }
            }

            while (true) {
                if (self.body_length == self.body_storage.len) {
                    var overflow_probe: [1]u8 = undefined;
                    const read_length = io.read(self.stream, &overflow_probe, overflow_probe.len);
                    if (read_length > 0) {
                        self.queue_error("413 Payload Too Large", "Payload Too Large");
                    } else if (read_length == 0) {
                        self.dispatch();
                    } else if (std.c.errno(read_length) != .AGAIN) {
                        self.close_now();
                    }
                    return;
                }

                const destination = self.body_storage[self.body_length..];
                const read_length = io.read(self.stream, destination.ptr, destination.len);
                if (read_length < 0) {
                    if (std.c.errno(read_length) != .AGAIN) self.close_now();
                    return;
                }
                if (read_length == 0) {
                    self.dispatch();
                    return;
                }
                self.body_length += @intCast(read_length);

                if (self.header_set.?.content_length) |expected| {
                    if (self.body_length > expected) {
                        self.queue_error("400 Bad Request", "Content-Length mismatch");
                        return;
                    }
                }
            }
        }

        /// Flushes queued response fields and body bytes without blocking.
        ///
        /// An armed producer is stepped at most once per write event plus the
        /// drain loop, so a producer that returns `.pending` without yielding
        /// bytes cannot spin. The stream stays armed until the producer finishes
        /// and the final storage drains.
        pub fn on_write(self: *Self) void {
            if (!self.response_pumpable()) {
                _ = io.wantwrite(self.stream, 0);
                return;
            }

            if (!self.headers_sent) {
                if (!self.send_headers()) {
                    self.close_now();
                    return;
                }
                self.headers_sent = true;
                // A producer keeps `.streaming` so its write_chunk calls stay
                // valid until it calls end_chunks; a prepared body moves on.
                if (self.stream_producer == null) self.response_phase = .sending;
            }

            if (!self.flush_response_body()) return;

            if (self.stream_producer != null and self.response_phase == .streaming) {
                self.response_body_offset = 0;
                self.response_body_length = 0;
                _ = self.step_stream_producer();
                if (self.response_phase == .done) return;
                if (!self.flush_response_body()) return;
            }

            if (self.stream_producer != null) return;

            _ = io.wantwrite(self.stream, 0);
            _ = io.shutdown(self.stream, 1);
            self.response_phase = .done;
            self.log_http_request();
        }

        /// Reports whether the response state machine may advance on a write event.
        fn response_pumpable(self: *const Self) bool {
            return switch (self.response_phase) {
                .ready, .sending => true,
                .streaming => self.stream_producer != null,
                .idle, .done => false,
            };
        }

        /// Moves queued body bytes into the stream; false when closed or blocked.
        fn flush_response_body(self: *Self) bool {
            while (self.response_body_offset < self.response_body_length) {
                const body = self.response_body_storage[self.response_body_offset..self.response_body_length];
                const written = io.write(self.stream, body.ptr, body.len);
                if (written < 0) {
                    self.close_now();
                    return false;
                }
                if (written == 0) return false;
                self.response_body_offset += @intCast(written);
            }
            return true;
        }

        /// Advances the armed producer once into the bounded body storage.
        ///
        /// The producer writes through `write_response`, so a full storage region
        /// surfaces as `error.WouldBlock`; the producer turns that into `.pending`
        /// and the next write event retries it. A producer fault clears the state
        /// and either queues a 500 while the head is still buffered or resets the
        /// stream once the head is on the wire.
        fn step_stream_producer(self: *Self) http_response.StreamStatus {
            const producer = self.stream_producer orelse return .done;
            const producer_context = self.stream_producer_context orelse {
                self.clear_stream_producer();
                return .done;
            };

            if (self.file_transfer_state.file != null) {
                self.file_transfer_state.chunk_limit = self.response_body_storage.len - self.response_body_length;
            }
            var response = Response{
                .target = .{ .http3 = self.target() },
                .state = .streaming,
            };
            const status = producer(producer_context, &response) catch {
                self.fail_stream_producer();
                return .done;
            };
            // end_chunks moved the phase out of `.streaming`; a later `.pending`
            // must not leave wantwrite armed forever.
            if (self.response_phase != .streaming) {
                self.clear_stream_producer();
                return .done;
            }
            if (status == .done) {
                self.fail_stream_producer();
                return .done;
            }
            return status;
        }

        /// Reports a producer fault through the normal response error path.
        fn fail_stream_producer(self: *Self) void {
            self.clear_stream_producer();
            if (self.headers_sent or self.response_phase != .streaming) {
                self.close_now();
                return;
            }
            self.response_phase = .idle;
            end_response(self, "500 Internal Server Error", "", "") catch self.close_now();
        }

        /// Disarms the response producer without altering the response phase.
        fn clear_stream_producer(self: *Self) void {
            self.stream_producer = null;
            self.stream_producer_context = null;
            file_transfer.close(&self.file_transfer_state);
        }

        /// Cancels deferred dispatch and returns pooled state to its owner.
        pub fn on_close(self: *Self) void {
            self.async_response_state.cancel();
            self.cancel_streaming_body(.peer_closed);
            self.clear_stream_producer();
            if (self.header_set) |header_set| header_set.release();
            self.header_set = null;

            const callback = self.release_fn orelse return;
            self.release_fn = null;
            callback(self.owner, self);
        }

        /// Starts a route-level H3 body sink before request-body collection.
        fn start_streaming_request(self: *Self) bool {
            if (self.body_storage.len == 0) return false;
            const header_set = self.header_set orelse return false;
            const method = radix.HttpMethod.parse(header_set.request.method) orelse return false;
            if (method != .post and method != .put and method != .patch) return false;
            header_set.request.extra_param_names = self.extra_param_names;
            header_set.request.extra_param_values = self.extra_param_values;
            header_set.request.extra_param_count = 0;
            const matched = self.router.match_request(&header_set.request, method) orelse return false;
            const handler = matched.handler orelse return false;
            const route_ptr = switch (handler) {
                .streaming => |pointer| pointer,
                else => return false,
            };
            const route: *const request_body.BodyRoute = @ptrCast(@alignCast(route_ptr));
            if (route.middleware_policy == .reject_legacy and self.router.has_middleware()) {
                self.queue_error("503 Service Unavailable", "Streaming route requires headers-only middleware");
                return true;
            }
            if (self.router.has_middleware()) {
                var response = Response{ .target = .{ .http3 = self.target() } };
                if (self.router.run_middleware(&header_set.request, &response) == .stop) {
                    self.finish_early_stream_response(&response);
                    return true;
                }
            }
            if (route.limits.max_active == 0) {
                self.queue_error("500 Internal Server Error", "Invalid upload limits");
                return true;
            }
            self.streaming_request = streaming_request_module.StreamingRequest.from_request(&header_set.request);
            self.streaming_route = route;
            self.streaming_paused = false;
            const control = self.body_state.arm(.{
                .context = self,
                .resume_fn = streaming_resume,
                .cancel_fn = streaming_cancel_control,
            }, route.limits, header_set.content_length) catch {
                self.queue_error("413 Payload Too Large", "Payload Too Large");
                return true;
            };
            const binding = route.sink.begin(route.sink.context, &self.streaming_request, control) catch {
                _ = self.body_state.reject_begin();
                self.streaming_route = null;
                self.queue_error("500 Internal Server Error", "Upload begin failed");
                return true;
            };
            self.streaming_active = true;
            if (self.body_state.accept_begin(binding)) |terminal| {
                self.streaming_active = false;
                switch (terminal) {
                    .cancel => |cancellation| route.sink.cancel(cancellation.binding.context, cancellation.reason),
                    .end => {},
                }
                _ = self.body_state.finish_terminal();
                self.streaming_route = null;
                self.queue_error("400 Bad Request", "Upload canceled");
                return true;
            }
            if (self.body_state.readiness == .paused) {
                self.streaming_paused = true;
                _ = io.wantread(self.stream, 0);
            }
            if (header_set.request.header_has_token("Expect", "100-continue") and !self.send_continue()) {
                self.close_now();
            }
            return true;
        }

        /// Sends an interim 100 response without committing final headers.
        fn send_continue(self: *Self) bool {
            @memcpy(self.response_status[0..7], ":status");
            @memcpy(self.response_status[7..10], "100");
            self.response_header_count = 0;
            self.response_header_length = 0;
            const sent = self.send_headers();
            self.response_header_count = 0;
            self.response_header_length = 0;
            self.response_phase = .idle;
            return sent;
        }

        /// Finishes a middleware response before any request body is read.
        fn finish_early_stream_response(self: *Self, response: *Response) void {
            self.dispatched = true;
            self.request_phase = .complete;
            _ = io.wantread(self.stream, 0);
            _ = io.shutdown(self.stream, 0);
            if (response.is_complete() or response.is_started()) return;
            self.queue_error("500 Internal Server Error", "Middleware did not complete the response");
        }

        fn stream_request_body(self: *Self) void {
            if (self.streaming_paused) return;
            const route = self.streaming_route orelse return;
            while (true) {
                if (self.streaming_pending_len != 0) {
                    const pending = self.body_storage[0..self.streaming_pending_len];
                    self.body_state.prepare_chunk(pending.len) catch {
                        self.fail_streaming_body(.invalid_body);
                        return;
                    };
                    const binding = self.body_state.binding orelse {
                        self.fail_streaming_body(.invalid_body);
                        return;
                    };
                    const progress = route.sink.chunk(binding.context, pending) catch {
                        self.fail_streaming_chunk();
                        return;
                    };
                    const terminal = self.body_state.accept_chunk(progress) catch {
                        self.fail_streaming_chunk();
                        return;
                    };
                    if (terminal) |pending_terminal| {
                        self.invoke_streaming_terminal(pending_terminal);
                        return;
                    }
                    if (progress.consumed != pending.len) {
                        const remaining = pending.len - progress.consumed;
                        std.mem.copyForwards(u8, self.body_storage[0..remaining], pending[progress.consumed..]);
                        self.streaming_pending_len = remaining;
                    } else {
                        self.streaming_pending_len = 0;
                    }
                    if (progress.readiness == .paused) {
                        self.streaming_paused = true;
                        _ = io.wantread(self.stream, 0);
                        return;
                    }
                    continue;
                }

                const scratch = self.body_storage[0..@min(self.body_storage.len, 8192)];
                const read_length = io.read(self.stream, scratch.ptr, scratch.len);
                if (read_length < 0) {
                    if (std.c.errno(read_length) != .AGAIN) self.close_now();
                    return;
                }
                if (read_length == 0) {
                    self.finish_streaming_body();
                    return;
                }
                const bytes = scratch[0..@intCast(read_length)];
                self.body_state.prepare_chunk(bytes.len) catch |err| {
                    self.fail_streaming_body(if (err == error.BodyTooLarge) .body_too_large else .invalid_body);
                    return;
                };
                const binding = self.body_state.binding orelse {
                    self.fail_streaming_body(.invalid_body);
                    return;
                };
                const progress = route.sink.chunk(binding.context, bytes) catch {
                    self.fail_streaming_chunk();
                    return;
                };
                const terminal = self.body_state.accept_chunk(progress) catch {
                    self.fail_streaming_chunk();
                    return;
                };
                if (terminal) |pending_terminal| {
                    self.invoke_streaming_terminal(pending_terminal);
                    return;
                }
                if (progress.consumed != bytes.len) {
                    const remaining = bytes.len - progress.consumed;
                    std.mem.copyForwards(u8, self.body_storage[0..remaining], bytes[progress.consumed..]);
                    self.streaming_pending_len = remaining;
                }
                if (progress.readiness == .paused) {
                    self.streaming_paused = true;
                    _ = io.wantread(self.stream, 0);
                    return;
                }
            }
        }

        fn finish_streaming_body(self: *Self) void {
            const route = self.streaming_route orelse return;
            const terminal = self.body_state.take_end(true, 0) catch {
                self.fail_streaming_body(.invalid_body);
                return;
            };
            if (io.shutdown(self.stream, 0) != 0) {
                _ = self.body_state.finish_terminal();
                self.streaming_active = false;
                self.streaming_route = null;
                self.close_now();
                route.sink.cancel(terminal.end.context, .peer_closed);
                return;
            }
            var response = Response{ .target = .{ .http3 = self.target() } };
            self.streaming_pending_headers.apply(&response);
            route.sink.end(terminal.end.context, &self.streaming_request, &response) catch {
                self.fail_streaming_body(.sink_failure);
                return;
            };
            if (!response.is_complete() and !response.is_started()) {
                response.end("500 Internal Server Error", "Handler did not complete the response") catch {
                    self.fail_streaming_body(.sink_failure);
                    return;
                };
            }
            _ = self.body_state.finish_terminal();
            self.streaming_active = false;
            self.streaming_route = null;
        }

        /// Delivers a cancellation recorded while the sink owned the chunk.
        fn invoke_streaming_terminal(self: *Self, terminal: request_body.BodyTerminal) void {
            const route = self.streaming_route orelse return;
            switch (terminal) {
                .cancel => |cancellation| {
                    route.sink.cancel(cancellation.binding.context, cancellation.reason);
                    _ = self.body_state.finish_terminal();
                    self.streaming_active = false;
                    self.streaming_route = null;
                    self.streaming_paused = false;
                    self.streaming_pending_len = 0;
                    self.streaming_pending_headers.clear();
                    const status = switch (cancellation.reason) {
                        .body_too_large => "413 Payload Too Large",
                        .invalid_body, .sink_failure => "400 Bad Request",
                        .peer_closed, .reset, .shutdown, .timeout => {
                            self.close_now();
                            return;
                        },
                        else => "400 Bad Request",
                    };
                    self.queue_error(status, "Upload failed");
                },
                .end => {},
            }
        }

        /// Delivers a sink/chunk failure after the callback has returned.
        fn fail_streaming_chunk(self: *Self) void {
            const route = self.streaming_route orelse return;
            const terminal = self.body_state.fail_chunk();
            switch (terminal) {
                .cancel => |cancellation| route.sink.cancel(cancellation.binding.context, cancellation.reason),
                .end => {},
            }
            _ = self.body_state.finish_terminal();
            self.streaming_active = false;
            self.streaming_route = null;
            self.streaming_paused = false;
            self.streaming_pending_len = 0;
            self.queue_error("400 Bad Request", "Upload failed");
        }

        fn fail_streaming_body(self: *Self, reason: request_body.BodyCancelReason) void {
            self.cancel_streaming_body(reason);
            const status = if (reason == .body_too_large) "413 Payload Too Large" else "400 Bad Request";
            self.queue_error(status, "Upload failed");
        }

        fn cancel_streaming_body(self: *Self, reason: request_body.BodyCancelReason) void {
            if (!self.streaming_active) return;
            self.streaming_active = false;
            self.streaming_paused = false;
            self.streaming_pending_len = 0;
            if (self.streaming_route) |route| {
                if (self.body_state.request_cancel(reason)) |terminal| {
                    switch (terminal) {
                        .cancel => |cancellation| route.sink.cancel(cancellation.binding.context, cancellation.reason),
                        .end => {},
                    }
                }
                _ = self.body_state.finish_terminal();
                self.streaming_route = null;
            }
        }

        fn streaming_resume(context: *anyopaque) error{BodyDeliveryFailed}!void {
            const self: *Self = @ptrCast(@alignCast(context));
            if (!self.streaming_active or !self.streaming_paused) return error.BodyDeliveryFailed;
            self.streaming_paused = false;
            _ = io.wantread(self.stream, 1);
            self.stream_request_body();
        }

        fn streaming_cancel_control(context: *anyopaque) void {
            const self: *Self = @ptrCast(@alignCast(context));
            self.cancel_streaming_body(.cancelled);
            self.queue_error("400 Bad Request", "Upload canceled");
        }

        fn dispatch(self: *Self) void {
            if (self.dispatched) return;
            self.dispatched = true;
            self.request_phase = .complete;
            _ = io.wantread(self.stream, 0);

            const header_set = self.header_set.?;
            if (header_set.content_length) |expected| {
                if (expected != self.body_length) {
                    self.queue_error("400 Bad Request", "Content-Length mismatch");
                    return;
                }
            }
            // EOF alone does not mark lsquic's user-read half closed.
            if (io.shutdown(self.stream, 0) != 0) {
                self.close_now();
                return;
            }
            header_set.request.body = self.body_storage[0..self.body_length];

            const method = radix.HttpMethod.parse(header_set.request.method);
            self.suppress_body = method == .head;
            var response = Response{ .target = .{ .http3 = self.target() } };
            if (std.mem.eql(u8, header_set.request.method, "CONNECT")) {
                response.end("501 Not Implemented", "HTTP/3 CONNECT is not supported") catch
                    self.close_now();
                return;
            }
            if (!header_set.request.valid_query_content_type()) {
                response.end("400 Bad Request", "QUERY requires a valid Content-Type") catch
                    self.close_now();
                return;
            }
            // The header set owns the request view; wire this stream's
            // engine-owned capture slices before the capture pass so wide
            // patterns can spill past the inline array.
            header_set.request.extra_param_names = self.extra_param_names;
            header_set.request.extra_param_values = self.extra_param_values;
            header_set.request.extra_param_count = 0;
            const route = self.router.match_request(&header_set.request, method);
            if (self.router.run_middleware(&header_set.request, &response) == .stop) {
                self.finish_sync_dispatch(&response);
                return;
            }

            if (method == .options and std.mem.eql(u8, header_set.request.path, "*")) {
                response.end("204 No Content", "") catch self.close_now();
                return;
            }

            const matched_route = route orelse {
                response.end("404 Not Found", "Route not found") catch self.close_now();
                return;
            };

            if (matched_route.handler) |handler| {
                self.invoke_handler(handler, &header_set.request, &response);
                return;
            }

            if (method == .options) {
                self.send_method_response(&response, matched_route.allowed_methods, "204 No Content", "");
                return;
            }
            if (matched_route.ws_behavior != null and method == .get) {
                response.end("426 Upgrade Required", "WebSocket over HTTP/3 is not supported") catch self.close_now();
                return;
            }
            self.send_method_response(&response, matched_route.allowed_methods, "405 Method Not Allowed", "Method Not Allowed");
        }

        fn invoke_handler(
            self: *Self,
            handler: radix.RouteHandler,
            request: *Request,
            response: *Response,
        ) void {
            switch (handler) {
                .synchronous => |callback| {
                    callback(request, response);
                    self.finish_sync_dispatch(response);
                },
                .contextual => |binding| {
                    binding.callback(binding.context, request, response);
                    self.finish_sync_dispatch(response);
                },
                .asynchronous => |callback| {
                    const token = self.async_response_state.arm(self.async_target());
                    callback(request, token);
                },
                .contextual_async => |binding| {
                    const token = self.async_response_state.arm(self.async_target());
                    binding.callback(binding.context, request, token);
                },
                .streaming => {
                    response.end_best_effort("501 Not Implemented", "Streaming route is HTTP/1.1 only");
                },
            }
        }

        fn finish_sync_dispatch(self: *Self, response: *Response) void {
            if (response.is_complete()) return;
            // A pending producer owns completion and resumes on write events.
            if (self.stream_producer != null) return;
            if (response.is_started()) {
                self.close_now();
                return;
            }
            response.end("500 Internal Server Error", "Handler did not complete response") catch
                self.close_now();
        }

        fn async_target(self: *Self) http_response.AsyncTarget {
            return .{
                .context = self,
                .complete_fn = complete_async_response,
                .wake_fn = wake_async_dispatch,
            };
        }

        fn complete_async_response(
            context: *anyopaque,
            status: []const u8,
            headers: []const u8,
            body: []const u8,
        ) !void {
            const self: *Self = @ptrCast(@alignCast(context));
            if (self.release_fn == null) return error.StreamClosed;
            end_response(self, status, headers, body) catch |err| {
                self.close_now();
                return err;
            };
        }

        /// QUIC completions arm the response directly, so the transport-level
        /// wake hook has no queued dispatch to resume.
        fn wake_async_dispatch(_: *anyopaque) void {}

        fn send_method_response(
            self: *Self,
            response: *Response,
            allowed_methods: u16,
            status: []const u8,
            body: []const u8,
        ) void {
            var allow_value_buffer: [64]u8 = undefined;
            const allow_value = radix.format_allowed_methods(allowed_methods, &allow_value_buffer) catch {
                self.close_now();
                return;
            };
            var allow_header_buffer: [80]u8 = undefined;
            const allow_header = std.fmt.bufPrint(
                &allow_header_buffer,
                "Allow: {s}\r\n",
                .{allow_value},
            ) catch {
                self.close_now();
                return;
            };
            response.end_with_headers(status, allow_header, body) catch self.close_now();
        }

        /// Returns the response callbacks bound to this stream.
        pub fn target(self: *Self) Http3Target {
            return .{
                .context = self,
                .end_fn = end_response,
                .begin_fn = begin_response,
                .write_fn = write_response,
                .finish_fn = finish_response,
                .abort_fn = abort_response,
                .begin_stream_fn = begin_stream_response,
                .stream_file_fn = begin_file_response,
            };
        }

        /// Success is still buffered: CONNECT must keep both transport halves open.
        pub fn connect_response_ready(self: *const Self) bool {
            if (self.release_fn == null or self.response_phase != .ready or self.headers_sent) return false;
            if (self.response_status_code < 200 or self.response_status_code >= 300) return false;
            if (self.response_body_length != 0) return false;
            for (0..self.response_header_count) |index| {
                const start = self.response_name_offsets[index];
                const name = self.response_header_storage[start..][0..self.response_name_lengths[index]];
                if (std.mem.eql(u8, name, "content-length")) return false;
            }
            return true;
        }

        /// Commits only the prepared response head, without ordinary HTTP FIN.
        pub fn send_connect_head(self: *Self) bool {
            if (!self.connect_response_ready()) return false;
            if (!self.send_headers()) return false;
            self.headers_sent = true;
            self.response_phase = .streaming;
            // Native header completion must retain a callback to flush without FIN.
            return true;
        }

        /// Called after native header completion, including a credit-blocked head.
        pub fn flush_connect_head(self: *Self) bool {
            if (!self.headers_sent or self.response_phase != .streaming) return false;
            if (io.flush(self.stream) != 0) return false;
            _ = io.wantwrite(self.stream, 0);
            return true;
        }

        /// Replaces an unsent admission result with a complete refusal.
        pub fn refuse_connect(self: *Self, status: []const u8, body: []const u8) void {
            if (self.headers_sent) {
                self.close_now();
                return;
            }
            self.clear_stream_producer();
            self.response_phase = .idle;
            self.response_body_length = 0;
            self.response_body_offset = 0;
            self.queue_error(status, body);
        }

        /// Preserves an application's prepared non-success refusal.
        pub fn finish_connect_refusal(self: *Self) void {
            self.dispatched = true;
            _ = io.wantread(self.stream, 0);
            if (io.shutdown(self.stream, 0) != 0) self.close_now();
        }

        /// Cancels unsent success and owns no application response after return.
        pub fn abort_connect(self: *Self) void {
            self.clear_stream_producer();
            self.release_connect_request();
            self.close_now();
        }

        /// The admitted route identity must be copied before request storage ends.
        pub fn release_connect_request(self: *Self) void {
            if (self.header_set) |headers| headers.release();
            self.header_set = null;
        }

        fn end_response(context: *anyopaque, status: []const u8, headers: []const u8, body: []const u8) !void {
            const self: *Self = @ptrCast(@alignCast(context));
            if (self.response_phase != .idle) return error.ResponseAlreadyStarted;
            try self.prepare_response(status, headers);

            if (!self.suppress_body) {
                if (body.len > self.response_body_storage.len) return error.WouldBlock;
                @memcpy(self.response_body_storage[0..body.len], body);
                self.response_body_length = body.len;
            }
            self.response_phase = .ready;
            _ = io.wantwrite(self.stream, 1);
        }

        fn begin_response(context: *anyopaque, status: []const u8, headers: []const u8) !void {
            const self: *Self = @ptrCast(@alignCast(context));
            if (self.response_phase != .idle) return error.ResponseAlreadyStarted;
            if (self.suppress_body) return error.BodyNotAllowed;
            try self.prepare_response(status, headers);
            self.response_phase = .streaming;
        }

        fn begin_stream_response(
            context: *anyopaque,
            status: []const u8,
            headers: []const u8,
            producer_context: *anyopaque,
            producer: http_response.StreamProducer,
        ) anyerror!bool {
            const self: *Self = @ptrCast(@alignCast(context));
            if (self.response_phase != .idle) return error.ResponseAlreadyStarted;
            if (self.suppress_body) return error.BodyNotAllowed;

            try self.prepare_response(status, headers);
            self.response_phase = .streaming;
            self.response_body_offset = 0;
            self.response_body_length = 0;
            self.stream_producer = producer;
            self.stream_producer_context = producer_context;

            if (self.step_stream_producer() != .done) {
                _ = io.wantwrite(self.stream, 1);
                return false;
            }
            return true;
        }

        /// Commits ownership only after the known-length head fits the fixed storage.
        fn begin_file_response(
            context: *anyopaque,
            status: []const u8,
            headers: []const u8,
            source: http_response.FileSource,
        ) anyerror!void {
            const self: *Self = @ptrCast(@alignCast(context));
            if (self.response_phase != .idle) return error.ResponseAlreadyStarted;
            if (self.file_transfer_state.file != null) return error.ResponseAlreadyStarted;
            const code = http_response.status_code(status) orelse return error.InvalidStatus;
            if (http_response.status_forbids_body(code)) return error.BodyNotAllowed;
            if (code < 300 and self.header_set != null and
                std.mem.eql(u8, self.header_set.?.request.method, "CONNECT")) return error.BodyNotAllowed;
            if (!http_response.valid_headers(headers)) return error.InvalidHeaders;
            if (source.buffer.len == 0) return error.InvalidFileSource;
            _ = std.math.add(u64, source.offset, source.length) catch return error.InvalidFileSource;
            if (!self.suppress_body and source.length != 0 and self.response_body_storage.len == 0) {
                return error.WouldBlock;
            }
            try self.prepare_response(status, headers);
            try self.prepare_file_length(source.length);

            self.response_body_offset = 0;
            self.response_body_length = 0;
            self.response_phase = .streaming;
            self.stream_producer = file_transfer.produce;
            self.stream_producer_context = &self.file_transfer_state;
            self.file_transfer_state = .{
                .io = source.io,
                .file = source.file,
                .buffer = source.buffer,
                .offset = source.offset,
                .remaining = if (self.suppress_body) 0 else source.length,
            };
            // Producer faults now own teardown; returning an error would imply
            // the caller still owns a descriptor the stream has already closed.
            if (self.step_stream_producer() != .done) _ = io.wantwrite(self.stream, 1);
        }

        /// Adds generated framing without extending field or byte capacity.
        fn prepare_file_length(self: *Self, length: u64) !void {
            const name = "content-length";
            var digits: [20]u8 = undefined;
            const value = std.fmt.bufPrint(&digits, "{d}", .{length}) catch return error.BufferOverflow;
            if (self.response_header_count == capacities.response_header_count) return error.BufferOverflow;
            const required = name.len + value.len;
            if (required > self.response_header_storage.len - self.response_header_length) return error.BufferOverflow;
            const index = self.response_header_count;
            const name_offset = self.response_header_length;
            const value_offset = name_offset + name.len;
            @memcpy(self.response_header_storage[name_offset..][0..name.len], name);
            @memcpy(self.response_header_storage[value_offset..][0..value.len], value);
            self.response_name_offsets[index] = @intCast(name_offset);
            self.response_name_lengths[index] = name.len;
            self.response_value_offsets[index] = @intCast(value_offset);
            self.response_value_lengths[index] = @intCast(value.len);
            self.response_header_length += required;
            self.response_header_count += 1;
        }

        fn write_response(context: *anyopaque, body: []const u8) !void {
            const self: *Self = @ptrCast(@alignCast(context));
            if (self.response_phase != .streaming) return error.ResponseNotStreaming;
            if (body.len > self.response_body_storage.len - self.response_body_length) {
                return error.WouldBlock;
            }
            @memcpy(
                self.response_body_storage[self.response_body_length .. self.response_body_length + body.len],
                body,
            );
            self.response_body_length += body.len;
        }

        fn finish_response(context: *anyopaque) !void {
            const self: *Self = @ptrCast(@alignCast(context));
            if (self.response_phase != .streaming) return error.ResponseNotStreaming;
            // end_chunks is terminal for a producer-fed body: whether the
            // producer or the application called it, nothing may re-arm.
            self.clear_stream_producer();
            self.response_phase = .ready;
            _ = io.wantwrite(self.stream, 1);
        }

        fn prepare_response(self: *Self, status: []const u8, headers: []const u8) !void {
            self.response_status_code = http_response.status_code(status) orelse
                return error.InvalidStatus;
            @memcpy(self.response_status[0..7], ":status");
            @memcpy(self.response_status[7..10], status[0..3]);
            self.response_header_length = 0;
            self.response_header_count = 0;

            var lines = std.mem.splitSequence(u8, headers, "\r\n");
            while (lines.next()) |line| {
                if (line.len == 0) continue;
                if (self.response_header_count >= capacities.response_header_count) {
                    return error.BufferOverflow;
                }
                const colon = std.mem.indexOfScalar(u8, line, ':') orelse return error.InvalidHeaders;
                const name = line[0..colon];
                const value = std.mem.trim(u8, line[colon + 1 ..], " \t");
                if (validation.connection_specific_header(name) or
                    std.ascii.eqlIgnoreCase(name, "te"))
                {
                    return error.InvalidHeaders;
                }

                const required = std.math.add(usize, name.len, value.len) catch return error.BufferOverflow;
                if (required > self.response_header_storage.len - self.response_header_length) {
                    return error.BufferOverflow;
                }

                const index = self.response_header_count;
                const name_offset = self.response_header_length;
                for (name, 0..) |byte, offset| {
                    self.response_header_storage[name_offset + offset] = std.ascii.toLower(byte);
                }
                self.response_header_length += name.len;
                const value_offset = self.response_header_length;
                @memcpy(
                    self.response_header_storage[value_offset .. value_offset + value.len],
                    value,
                );
                self.response_header_length += value.len;

                self.response_name_offsets[index] = @intCast(name_offset);
                self.response_name_lengths[index] = @intCast(name.len);
                self.response_value_offsets[index] = @intCast(value_offset);
                self.response_value_lengths[index] = @intCast(value.len);
                self.response_header_count += 1;
            }
        }

        /// Records one completed request/response cycle in this thread's log.
        ///
        /// The record borrows the attached header set's method and path, which
        /// the stream keeps alive until `on_close`. Recording is best effort:
        /// a silent sink is skipped before any clock read, and a full sink
        /// counts the line as dropped.
        fn log_http_request(self: *Self) void {
            const sink = dev_log_module.thread_sink();
            if (!sink.enabled) return;
            const header_set = self.header_set orelse return;
            sink.record(.{
                .timestamp_ms = dev_log_module.now_ms(sink.io),
                .level = .info,
                .direction = .data_out,
                .event = .{ .http_request = .{
                    .method = header_set.request.method,
                    .path = header_set.request.path,
                    .status = self.response_status_code,
                } },
            });
        }

        fn send_headers(self: *Self) bool {
            var header_array: [capacities.response_header_count + 1]c.struct_uz_lsxpack_header = undefined;
            set_xpack_header(&header_array[0], &self.response_status, 0, 7, 7, 3);

            var index: usize = 0;
            while (index < self.response_header_count) : (index += 1) {
                set_xpack_header(
                    &header_array[index + 1],
                    self.response_header_storage,
                    self.response_name_offsets[index],
                    self.response_name_lengths[index],
                    self.response_value_offsets[index],
                    self.response_value_lengths[index],
                );
            }

            var headers = c.lsquic_http_headers_t{
                .count = @intCast(self.response_header_count + 1),
                .headers = @ptrCast(&header_array[0]),
            };
            return io.send_headers(self.stream, &headers, 0) == 0;
        }

        fn queue_error(self: *Self, status: []const u8, body: []const u8) void {
            if (self.response_phase != .idle) {
                self.close_now();
                return;
            }
            self.dispatched = true;
            _ = io.wantread(self.stream, 0);
            _ = io.shutdown(self.stream, 0);
            end_response(self, status, "", body) catch self.close_now();
        }

        fn abort_response(context: *anyopaque) void {
            const self: *Self = @ptrCast(@alignCast(context));
            self.close_now();
        }

        fn close_now(self: *Self) void {
            self.async_response_state.cancel();
            self.clear_stream_producer();
            self.response_phase = .done;
            _ = io.close(self.stream);
        }
    };
}

/// Production HTTP/3 stream state bound to the lsquic stream API.
pub const QuicStream = stream_with(lsquic_stream_io, default_capacities);

fn set_xpack_header(
    header: *c.struct_uz_lsxpack_header,
    buffer: []const u8,
    name_offset: usize,
    name_length: usize,
    value_offset: usize,
    value_length: usize,
) void {
    header.* = std.mem.zeroes(c.struct_uz_lsxpack_header);
    header.buf = @ptrCast(@constCast(buffer.ptr));
    header.name_offset = @intCast(name_offset);
    header.name_len = @intCast(name_length);
    header.val_offset = @intCast(value_offset);
    header.val_len = @intCast(value_length);
}
