const std = @import("std");
const Request = @import("request.zig").Request;
const Response = @import("response.zig").Response;
const radix = @import("../router/radix.zig");

pub const CorsOptions = struct {
    origins: []const []const u8,
    methods: []const radix.HttpMethod = &.{ .get, .head, .post },
    allow_headers: []const []const u8 = &.{},
    expose_headers: []const []const u8 = &.{},
    allow_credentials: bool = false,
    max_age: ?u32 = null,
};

pub const Cors = struct {
    options: CorsOptions,

    pub fn handler(context: *anyopaque, request: *Request, response: *Response) radix.MiddlewareResult {
        const self: *const Cors = @ptrCast(@alignCast(context));
        const origin = request.get_unique_header("origin") orelse return .continue_dispatch;
        if (!contains_exact(self.options.origins, origin)) return .continue_dispatch;

        response.append_header("Access-Control-Allow-Origin", origin) catch {
            fail_response(response);
            return .stop;
        };
        response.append_header("Vary", "Origin") catch {
            fail_response(response);
            return .stop;
        };
        if (self.options.allow_credentials) {
            response.append_header("Access-Control-Allow-Credentials", "true") catch {
                fail_response(response);
                return .stop;
            };
        }
        append_list(response, "Access-Control-Expose-Headers", self.options.expose_headers) catch {
            fail_response(response);
            return .stop;
        };

        if (!std.mem.eql(u8, request.method, "OPTIONS")) return .continue_dispatch;
        const requested_method = request.get_unique_header("access-control-request-method") orelse {
            return .continue_dispatch;
        };
        const method = radix.HttpMethod.parse(requested_method) orelse {
            response.end_best_effort("403 Forbidden", "");
            return .stop;
        };
        if (!contains_method(self.options.methods, method) or
            !requested_headers_allowed(request, self.options.allow_headers))
        {
            response.end_best_effort("403 Forbidden", "");
            return .stop;
        }

        append_methods(response, self.options.methods) catch {
            fail_response(response);
            return .stop;
        };
        append_list(response, "Access-Control-Allow-Headers", self.options.allow_headers) catch {
            fail_response(response);
            return .stop;
        };
        if (self.options.max_age) |max_age| {
            var value_buffer: [16]u8 = undefined;
            const value = std.fmt.bufPrint(&value_buffer, "{d}", .{max_age}) catch {
                fail_response(response);
                return .stop;
            };
            response.append_header("Access-Control-Max-Age", value) catch {
                fail_response(response);
                return .stop;
            };
        }
        response.end_best_effort("204 No Content", "");
        return .stop;
    }
};

pub fn cors(options: CorsOptions) Cors {
    return .{ .options = options };
}

pub const SecurityHeadersOptions = struct {
    strict_transport_security: ?[]const u8 = "max-age=31536000; includeSubDomains",
    content_security_policy: ?[]const u8 = "default-src 'self'",
    x_content_type_options: bool = true,
    x_frame_options: ?[]const u8 = "DENY",
    referrer_policy: ?[]const u8 = "no-referrer",
};

pub const SecurityHeaders = struct {
    options: SecurityHeadersOptions,

    pub fn handler(context: *anyopaque, _: *Request, response: *Response) radix.MiddlewareResult {
        const self: *const SecurityHeaders = @ptrCast(@alignCast(context));
        append(response, "Strict-Transport-Security", self.options.strict_transport_security) catch {
            fail_response(response);
            return .stop;
        };
        append(response, "Content-Security-Policy", self.options.content_security_policy) catch {
            fail_response(response);
            return .stop;
        };
        if (self.options.x_content_type_options) {
            response.append_header("X-Content-Type-Options", "nosniff") catch {
                fail_response(response);
                return .stop;
            };
        }
        append(response, "X-Frame-Options", self.options.x_frame_options) catch {
            fail_response(response);
            return .stop;
        };
        append(response, "Referrer-Policy", self.options.referrer_policy) catch {
            fail_response(response);
            return .stop;
        };
        return .continue_dispatch;
    }
};

pub fn security_headers(options: SecurityHeadersOptions) SecurityHeaders {
    return .{ .options = options };
}

/// One plaintext Basic credential accepted by `auth`.
pub const BasicCredential = struct {
    username: []const u8,
    password: []const u8,
};

/// One plaintext Bearer token accepted by `auth`.
pub const BearerToken = struct {
    token: []const u8,
};

/// Challenge realm and accepted credentials for `auth`.
pub const AuthOptions = struct {
    realm: []const u8 = "restricted",
    basic: []const BasicCredential = &.{},
    bearer: []const BearerToken = &.{},
};

/// Fixed-state Basic and Bearer authentication middleware.
///
/// Credentials are borrowed from the caller for the lifetime of the handler.
/// Each request decodes at most one 512-byte Basic payload on the stack and
/// compares credentials with a constant-time primitive. Missing, duplicate, or
/// invalid credentials receive `401 Unauthorized` with a challenge that lists
/// only the configured schemes.
pub const Auth = struct {
    options: AuthOptions,

    pub fn handler(context: *anyopaque, request: *Request, response: *Response) radix.MiddlewareResult {
        const self: *const Auth = @ptrCast(@alignCast(context));
        if (request.get_unique_header("authorization")) |value| {
            if (authorized(self.options, value)) return .continue_dispatch;
        }
        reject_auth(self.options, response);
        return .stop;
    }
};

/// Builds Basic and Bearer authentication over caller-owned credentials.
pub fn auth(options: AuthOptions) Auth {
    return .{ .options = options };
}

/// Maximum decoded credential bytes accepted from one Basic field.
const max_credential_bytes = 512;

/// Maximum formatted authentication challenge, including the realm.
const max_challenge_bytes = 1024;

/// Fixed block size used for constant-time credential comparison.
const comparison_block_bytes = 64;

fn authorized(options: AuthOptions, value: []const u8) bool {
    if (scheme_remainder(value, "Basic")) |encoded| return authorized_basic(options.basic, encoded);
    if (scheme_remainder(value, "Bearer")) |token| return authorized_bearer(options.bearer, token);
    return false;
}

/// Splits `value` after the case-insensitive `scheme` and its whitespace.
fn scheme_remainder(value: []const u8, scheme: []const u8) ?[]const u8 {
    if (value.len <= scheme.len) return null;
    if (!std.ascii.eqlIgnoreCase(value[0..scheme.len], scheme)) return null;
    const separator = value[scheme.len];
    if (separator != ' ' and separator != '\t') return null;
    return std.mem.trimStart(u8, value[scheme.len..], " \t");
}

fn authorized_basic(credentials: []const BasicCredential, encoded: []const u8) bool {
    var decoded_buffer: [max_credential_bytes]u8 = undefined;
    const decoded = decode_basic(encoded, &decoded_buffer) orelse return false;
    const separator = std.mem.indexOfScalar(u8, decoded, ':') orelse return false;
    const username = decoded[0..separator];
    const password = decoded[separator + 1 ..];

    var matches: u1 = 0;
    for (credentials) |credential| {
        const username_equal: u1 = @intFromBool(constant_time_eql(username, credential.username));
        const password_equal: u1 = @intFromBool(constant_time_eql(password, credential.password));
        matches |= username_equal & password_equal;
    }
    return matches != 0;
}

fn authorized_bearer(tokens: []const BearerToken, token: []const u8) bool {
    if (token.len == 0) return false;
    var matches: u1 = 0;
    for (tokens) |candidate| {
        matches |= @intFromBool(constant_time_eql(token, candidate.token));
    }
    return matches != 0;
}

/// Decodes one RFC 4648 Basic payload into bounded caller storage.
fn decode_basic(encoded: []const u8, buffer: []u8) ?[]const u8 {
    const decoder = std.base64.standard.Decoder;
    const size = decoder.calcSizeForSlice(encoded) catch return null;
    if (size > buffer.len) return null;
    decoder.decode(buffer[0..size], encoded) catch return null;
    return buffer[0..size];
}

/// Compares equal-length byte strings through a constant-time primitive.
///
/// Length is public metadata, so unequal lengths return false immediately.
/// Equal-length content is zero-padded into fixed blocks and compared with
/// `std.crypto.timing_safe.eql`, which never exits early.
fn constant_time_eql(a: []const u8, b: []const u8) bool {
    if (a.len != b.len) return false;
    var difference: u8 = 0;
    var index: usize = 0;
    while (index < a.len) : (index += comparison_block_bytes) {
        const count = @min(comparison_block_bytes, a.len - index);
        var left: [comparison_block_bytes]u8 = @splat(0);
        var right: [comparison_block_bytes]u8 = @splat(0);
        @memcpy(left[0..count], a[index..][0..count]);
        @memcpy(right[0..count], b[index..][0..count]);
        difference |= @intFromBool(!std.crypto.timing_safe.eql([comparison_block_bytes]u8, left, right));
    }
    return difference == 0;
}

fn reject_auth(options: AuthOptions, response: *Response) void {
    var buffer: [max_challenge_bytes]u8 = undefined;
    const challenge = format_challenge(&buffer, options) catch {
        fail_response(response);
        return;
    };
    if (challenge.len != 0) {
        response.append_header("WWW-Authenticate", challenge) catch {
            fail_response(response);
            return;
        };
    }
    response.end_best_effort("401 Unauthorized", "");
}

/// Formats the challenge for the configured schemes without CR/LF or quotes
/// leaking out of the realm.
fn format_challenge(buffer: []u8, options: AuthOptions) ![]const u8 {
    const has_basic = options.basic.len != 0;
    const has_bearer = options.bearer.len != 0;
    if (has_basic and has_bearer) {
        try validate_realm(options.realm);
        return std.fmt.bufPrint(buffer, "Basic realm=\"{s}\", Bearer", .{options.realm});
    }
    if (has_basic) {
        try validate_realm(options.realm);
        return std.fmt.bufPrint(buffer, "Basic realm=\"{s}\"", .{options.realm});
    }
    if (has_bearer) return "Bearer";
    return "";
}

fn validate_realm(realm: []const u8) !void {
    if (std.mem.indexOfAny(u8, realm, "\"\r\n") != null) return error.InvalidRealm;
}

/// Rate-limit types and entry points; `rate_limit.zig` owns the table and LRU.
pub const RateLimitBucket = @import("rate_limit.zig").RateLimitBucket;
pub const RateLimitKeyFn = @import("rate_limit.zig").RateLimitKeyFn;
pub const RateLimitOptions = @import("rate_limit.zig").RateLimitOptions;
pub const RateLimitDecision = @import("rate_limit.zig").RateLimitDecision;
pub const RateLimitIndexSlot = @import("rate_limit.zig").RateLimitIndexSlot;
pub const RateLimitLink = @import("rate_limit.zig").RateLimitLink;
pub const RateLimitTable = @import("rate_limit.zig").RateLimitTable;
pub const RateLimit = @import("rate_limit.zig").RateLimit;
pub const rate_limit = @import("rate_limit.zig").rate_limit;
pub const rate_limit_indexed = @import("rate_limit.zig").rate_limit_indexed;
pub const rate_limit_step = @import("rate_limit.zig").rate_limit_step;
pub const fnv1a_64 = @import("rate_limit.zig").fnv1a_64;

fn requested_headers_allowed(request: *const Request, allowed: []const []const u8) bool {
    const value = request.get_unique_header("access-control-request-headers") orelse return true;
    var headers = std.mem.splitScalar(u8, value, ',');
    while (headers.next()) |raw_header| {
        const header = std.mem.trim(u8, raw_header, " \t");
        var found = false;
        for (allowed) |candidate| {
            if (!std.ascii.eqlIgnoreCase(candidate, header)) continue;
            found = true;
            break;
        }
        if (!found) return false;
    }
    return true;
}

fn contains_exact(values: []const []const u8, expected: []const u8) bool {
    for (values) |value| {
        if (std.mem.eql(u8, value, expected)) return true;
    }
    return false;
}

fn contains_method(methods: []const radix.HttpMethod, expected: radix.HttpMethod) bool {
    for (methods) |method| {
        if (method == expected or method == .any) return true;
    }
    return false;
}

fn append(response: *Response, name: []const u8, value: ?[]const u8) !void {
    if (value) |present| try response.append_header(name, present);
}

fn append_list(response: *Response, name: []const u8, values: []const []const u8) !void {
    if (values.len == 0) return;
    var buffer: [1024]u8 = undefined;
    const value = try format_list(&buffer, values);
    try response.append_header(name, value);
}

fn append_methods(response: *Response, methods: []const radix.HttpMethod) !void {
    var names: [10][]const u8 = undefined;
    if (methods.len > names.len) return error.TooManyCorsMethods;
    for (methods, 0..) |method, index| names[index] = method.name();
    try append_list(response, "Access-Control-Allow-Methods", names[0..methods.len]);
}

fn format_list(buffer: []u8, values: []const []const u8) ![]const u8 {
    var offset: usize = 0;
    for (values, 0..) |value, index| {
        if (std.mem.indexOfAny(u8, value, "\r\n,") != null) return error.InvalidHeaderValue;
        const separator = if (index == 0) "" else ", ";
        if (separator.len + value.len > buffer.len - offset) return error.BufferTooSmall;
        @memcpy(buffer[offset..][0..separator.len], separator);
        offset += separator.len;
        @memcpy(buffer[offset..][0..value.len], value);
        offset += value.len;
    }
    return buffer[0..offset];
}

fn fail_response(response: *Response) void {
    response.end_best_effort("500 Internal Server Error", "");
}
