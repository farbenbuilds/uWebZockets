# Isolated WebTransport session ownership proof

The final frozen Root snapshot is `project_v4`, equivalent in all 258 retained
inputs to implementation commit
`eebd42ee8dc618434f9d9025159c9d8885576861`. Its manifest SHA-256 is:
`8200fa9790bd24771071d920a1cc8afd593b957d5e3c3f8ce96c2034e4fa941e`.
The 40 fixture/compiler inputs have manifest SHA-256
`2ffa53a7d57f778a5cb3540214374659b8c60dcb2f01ccfea38d61884e819e5a`.
Root session records now live in occupied CONNECT stream slots. A global
bounded index resolves the connection generation and full session ID to that
slot's generation-checked handle. The public API and flow-off one-session
policy remain unchanged.

Two functional cohorts run independently against the actual App, UDP, TLS and
Native005. `streams` retains all 67 prior child/receive/transmit/half/outgoing
cases. `datagrams` runs the existing N4 33-case admission/routing/pending
driver. Each passed Debug, ReleaseSafe and ReleaseFast with 16/16 build steps.
These are separate driver counts; they are not a count of 100 disjoint tests.
The datagram root includes its import test, and some helpers are shared.

Only private observations changed in seven prior Zig fixture files. The new
`tests/session_observer.zig` validates the full index key, occupied CONNECT
slot, generation, active connection lease, record identity, route and Native
stream context before returning named handle/phase/route values. Existing
wire, callback, queue, child and admission expectations remain intact.
The public close observer additionally requires index removal and record
invalidation before notification. Existing cases exercise equal SID zero on
different connections, generation reuse and stale handles. Observer-owned
session arrays retain their original meaning.

## Replay

Use Zig 0.16.0, Native005
`005ab244169f269689e511d6b77dd2187e318df1`, XEV
`5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5`, and the offline packages selected by
`build.zig.zon`. Dependencies are compiled with Zig's own C/C++ toolchain.
No dependency pin or fork is activated by this proof.

```sh
UWZ_ZIG=/path/to/zig-0.16.0 \
UWZ_LSQUIC_SOURCE=/path/to/native005 \
UWZ_LIBXEV_SOURCE=/path/to/xev5b2c \
UWZ_PACKAGE_DIR=/path/to/offline-zig-packages \
UWZ_CACHE_DIR=/path/to/disposable-cache \
ZIG_GLOBAL_CACHE_DIR=/path/to/disposable-global-cache \
sh replay.sh Debug streams
```

Select `Debug`, `ReleaseSafe` or `ReleaseFast`, and `streams` or `datagrams`.
The script checks all 40 fixture and 258 Root input hashes before compiling.
`UWZ_PROJECT_SOURCE` may point to another location with exactly the same
manifest. Use a single writer for the selected cache. Loopback socket
permission is required. Dedicated smoke targets are not part of these drivers.

Native source/history is retained in
`benchmarks/results/webtransport_child_lifecycle_v1/2026_11_16/raw_evidence_archive.tgz`
(SHA-256 `3e27ce7137f3791cf977d0b4c83bee4ea72c873b1af125c3a13616695b2a8418`).
Its ls-hpack gitlink is `cf0f70dd10b352194c97448eb5d00b4aa484f531`;
the compiled ls-hpack package is `fda48e02491d865cce00612be8cc10c2622b8e55`.
Both actual ls-qpack and its gitlink use
`91567706c41c0d97ab8dc576873ecd472d7869fa`. Native/XEV source trees, Git
metadata, offline packages, caches and executables are not duplicated here.

## Retained regression history

The original outgoing delivery archive is
`benchmarks/results/webtransport_public_outgoing_v1/2026_11_17/raw_evidence_archive.tgz`
(SHA-256 `8bab160e149a443651934a16e01199664f956675e420e2f00254ea7b10badacc`).
Its original fixture plus original `project_v2` reproduced a pre-existing
N4 cooldown failure at 32/33. Current migration v1 was 31/33: it added a
regression that discarded queued datagrams during callback-requested cooldown.
Exact original inputs remain in the referenced immutable archive. Exact
migration RED fixture inputs are retained in `evidence/n4_regression_inputs`.

Root v2 retained unpublished datagram records during cooldown, returning N4
to 32/33. An isolated diagnostic v2 copy then proved `write_connect` retired
an established, unpublished record after the first drained callback queued
cooldown. The original test explicitly requires both the first queued entry
and a later direct-after-going-away callback to survive. No retired-session
exception or changed expectation was added to that test.

Root v3 allowed established-session flushing before its shutdown guard. N4
passed 33/33, while three unchanged public-session cooldown cases exposed a
real drain regression: streams 64/67 in Debug and ReleaseSafe. Root v4 restored
the early shutdown/abort behavior with a narrowly bounded exception for an
existing unpublished established/draining datagram session. Both unchanged
cohorts then passed all three modes. Exact Root snapshots, fix diffs, trace
diff and raw failure/pass logs are retained separately. Only
`src/quic/engine.zig` differs between migration snapshots v1 through v4.

## Limits

The stream cohort's public count-credit recovery uses actual peer
MAX_STREAMS and leaves Native credit fields untouched. Two inherited N4
blocked-response reset tests instead stage a larger receiver window by
writing the private client `sf_max_recv_win`, call Native's receive-window
update, verify a queued update, then exercise the real wire MAX_STREAM_DATA
and reset. Their unchanged test names do not prove receiver credit grew
without private staging. Those two cases are explicitly identified in the
source profile.

Native scheduling uses inherited synthetic fixture time. App expiry uses the
production awake clock; the inherited TX wake case uses Linux monotonic time
and a read-only xev deadline. Most cases manually pump the engine. Explicit
Root fault seams remain as inherited. Native allocation failures, unsupported
returns, actual OS submission failures, non-Linux runtime and independent
draft-16 clients were not forced. No allocation-free claim is made for Native.
Positive/multi-session flow remains off. Native observer proposals are separate
from this unchanged Native005 matrix. Dedicated smoke/security/sanitizer/fuzz
campaigns remain user-deferred.
