#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/queue.h>
#include <sys/types.h>
#include "lsquic.h"
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_packet_in.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"
#include "lsquic_packet_out.h"

int
main(void)
{
    printf("{\"stream_size\":%zu,\"stream_alignment\":%zu,"
           "\"packet_size\":%zu,\"packet_alignment\":%zu,"
           "\"frame_record_size\":%zu,\"settings_size\":%zu}\n",
           sizeof(struct lsquic_stream), _Alignof(struct lsquic_stream),
           sizeof(struct lsquic_packet_out), _Alignof(struct lsquic_packet_out),
           sizeof(struct frame_rec), sizeof(struct lsquic_engine_settings));
    return 0;
}
