# Independent review record

The receive-path review checked the partial-header reset correction and
IETF STOP_SENDING receive-state preservation at stream source SHA-256
8d4c36299c3eda69ffdf70727fb30e577a9b07a6d8c3dc0c01e4697c017658a6.
It reported no actionable findings.

The later read-only review covered tests/test_send_headers.c,
tests/test_stream.c and tests/uwz_reset_ack.c since c434c4ae. It confirmed
all original upstream assertions remain, with stronger deferred delivery
and lifetime assertions. The ACK fixture uses real TLS engines, captured
encrypted datagrams and real parsed ACK records; all eight candidates share
one observed scan, records match actual retained packets, and no sender
closes before RESET acknowledgment. Obsolete-ACK shrink coverage remains.
No actionable findings were reported. The reviewer ran no builds or scans.

This establishes fixed in-memory workloads, not throughput. ReleaseSafe and
cross-target runs were performed separately by root and are retained here.
Remaining smoke and security runs are deferred to the user.
