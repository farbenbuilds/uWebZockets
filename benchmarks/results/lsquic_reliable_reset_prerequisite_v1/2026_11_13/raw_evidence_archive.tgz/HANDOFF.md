# Reliable reset functional prerequisite

Restore the archived dependency and uni-stream histories first. Verify and
fetch reliable-reset.bundle, requiring 0f7382b17b38d7fb0496a0b75b3c66ace79e49e8.
The frozen tip is 3640992bb231d3f0f2647e03fda6a2776fcc23ca. Its working tree
was clean. The source manifest covers all tracked regular files at that tip.

All 83 upstream Debug cases pass, 165/165 build steps. The initial send_headers
and two active IETF stream-fixture expectations needed the real loop's
quiescent reset service; assertions were preserved and strengthened, with no
production workaround. Earlier standalone-link failures were native scaffold
configuration errors; its corrected manifest is retained.

Both roles pass obsolete-ACK shrink recovery and an eight-stream coalesced
ACK scan. Native ACK records are validated and included in counts; the test
never fabricates ACK packets or silently filters retained records. Initial
fixture failures are retained separately from final GREEN results.

Ten reset regression executables pass ReleaseSafe. Windows GNU and macOS
ARM64 production libraries compile without fixture hooks or ACK observers.
These are not foreign-runtime results. Native layout is 720->760 bytes per
stream, alignment 8 unchanged; packet 144, frame record 16 and settings 352 bytes
remain unchanged. Native reliable-reset interoperability against pinned
quic-go already passed before the final test-only commit; source diff proves
no production change afterward. No fixture private key is archived.

The scaffold and Git bundle are review and reproduction material, never a
root build overlay. Scratch paths need relocation; dependencies remain the
unchanged pinned native Zig packages. The older checkpoint retains external
oracle sources and provenance. This archive intentionally excludes module
caches, binaries and private keys.

Remaining smoke/security runs are deferred to the user. Live WebTransport
SETTINGS, CONNECT, raw child association, Zig session integration and the
compatible draft-16 client gate remain required. Generic reset behavior does
not enforce the future WebTransport child-prefix floor; that belongs in the
classified child path. Early-disabled pre-handshake queueing remains outside
the resumption matrix. No maintained-fork publication, root pin change,
capability activation, release tag or push is included.
