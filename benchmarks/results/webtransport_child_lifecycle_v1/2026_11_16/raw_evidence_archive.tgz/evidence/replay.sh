#!/bin/sh
set -eu
ulimit -c 0
checkpoint=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
zig_bin=${ZIG:-zig}
mode=${1:-Debug}
cohort=${2:-lifecycle}
case "$mode" in Debug|ReleaseSafe|ReleaseFast) ;; *) exit 2 ;; esac
case "$cohort" in
    lifecycle) driver=tests/children_main.zig ;;
    existing) driver=tests/main.zig ;;
    *) exit 2 ;;
esac
native_source=${LSQUIC_SOURCE:-"$checkpoint/native-source"}
xev_source=${LIBXEV_SOURCE:-"$checkpoint/libxev-source"}
cd "$checkpoint/app"
exec "$zig_bin" build test -Doptimize="$mode" \
  -Dproject-source="$checkpoint/app/project_cio" -Dtest-source="$driver" \
  -Dlsquic-source="$native_source" -Dlibxev-source="$xev_source" \
  -j2 --summary all
