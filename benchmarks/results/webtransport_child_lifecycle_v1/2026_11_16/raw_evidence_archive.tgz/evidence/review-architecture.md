# Final child lifecycle architecture review

Date: 2026-11-16. Read-only changed-work review using the standard and explicitly requested thermo-nuclear code quality lenses. No required findings remain in the reviewed Root/native changes. The earlier finding and review remain preserved under `review-round1/`; this document supersedes their open status.

## Reviewed inputs

- Root `src/quic/engine.zig` and the harness `project_cio` copy both have SHA-256 `88dbeaffd5335e040dbd5775baee76333abc9354d0a24fe1763f0744d075d70c`.
- Native local proposal: `005ab244169f269689e511d6b77dd2187e318df1` in `/tmp/uwz-lsquic-wt-uni-credit-20261116`; working tree was clean when reviewed. Maintained production pins remain unchanged.
- `tests/app_children.zig`: `a2f76b5dd255dbcd71246402882f92f475c2d9961e0ec0ef24ebeabce927ec35`.
- `tests/app_child_lifecycle.zig`: `d59b5d1b5137aa2c06dae16ef7c373af6dcec7f83694fde3ad003939bdfcf4a1`.
- `tests/app_child_teardown.zig`: `425f17c7604cc7267ba2dd6e6490443ab027be39283b54d9bc694727747209d8`.
- `fixtures/uwz_app_client.c`: `a94a8d893b73f373d829c02ea4146799381ab20487902ad87f559cc8bbff1c77`.
- `fixtures/uwz_app_client.h`: `a97dd01cebd105f58299ef73eda9f3f4b980bc0e04b31585b603b237ca7e9212`.

## Resolved findings and changed-work acceptance

The constructor deferral remains limited to the bound candidate's peer-UNI PENDING/null-context publication gap. Fresh positive typed metadata precedes coded rejection. Unresolved BIDI/ordinary HTTP capacity handling is not represented as positively classified child rejection.

Root now handles terminal STOP CLOSED by shutting down the application's receive half. This fixes the prefix-only FIN orphan: consumed FIN does not itself set native U_READ_DONE. Other unexpected STOP failures are logged and closed. The retained `orphan-terminal-red-Debug.log` fails the live-connection native disappearance assertion before this cleanup; the final test repeats six prefix-only FIN children while all eight Root slots remain occupied.

The test reacquires a retained Root-owned anchor immediately before each synchronous native hash query. The C helper reads that anchor's connection stream table and copies a public receive snapshot; it changes no flags or callbacks and retains no target pointer. Pumping occurs only after the query. Absence follows actual encrypted-batch delivery, and the earlier RED observes the target remaining present. The proof therefore checks native cleanup rather than inferring it from Root counters or connection abort.

`native_connection_live` gives retirement, guard-failure handling, and close classification one native status policy. The abort regression exposed session_closed winning incorrectly during native connection teardown; the corrected case requires connection_closed, unknown final size, preserved actual byte accounting, zero pending/retry/stream counts, and successful same-slot/full-stream-ID reuse under a larger connection generation.

## Native UNI credit proposal

The six-line native diff changes only opt-in HTTP WebTransport UNI close scheduling. It preserves the existing coalesced MAX_STREAMS flag, credit guard, and generator, whose advertised limit remains closed-stream count plus configured concurrency window. Ordinary disabled behavior and bidirectional scheduling remain unchanged. It adds no allocation or callback dispatch.

Persistent critical/pending streams can prevent the prior half-window threshold from ever replenishing credit. The retained `lifecycle-credit-recovery-Debug.log` fails with PeerUniCreditRecoveryTimeout after cleanup is fixed but before the native proposal. The final same-connection test creates a UNI stream whose ordinal exceeds the initial advertised limit, while retained pending streams remain live. This demonstrates real peer-visible credit recovery. Multiple closes before frame generation remain coalesced.

The client fixture's 16 observation records hold cumulative stream history for this test. Root's configured global stream budget remains eight, and local/global active and pending assertions remain exact. This is fixture storage capacity, not a relaxed production limit or assertion.

## Architecture and evidence

The accepted ownership boundary remains: pure child state and ledger; child_io native reads, terminal dispatch and cancellation; Engine association, quotas, expiry, leases and callback routing. Effects, clocks, C handles and callbacks remain outside pure transitions. No new Root slab, global mutable state, public child API, generic vtable, or dependency pin update was introduced.

Engine is now 1596 lines, an explicit maintainability flag. The native liveness helper removes duplicated status policy; unowned-child rejection centralizes the constructor/typed-callback invariant. No further decomposition is required for this diff: moving association out would expose Engine pool/session ownership or add dispatch, while deleting child_io would put the read/accounting/cancellation loop and callback guards back in Engine.

The nine cases cover binary UNI delivery, BIDI receive plus actual zero-byte reverse EOF, payload fragmentation, pre-admission buffered bytes, held SETTINGS, full-width session identity and real App awake-clock expiry, per-connection/global quotas, native orphan cleanup and credit recovery, parent teardown isolation/future SID4 admission, and connection abort/reuse. Earlier retention and expiry staging gaps remain resolved by non-consuming native preview, waiting/reservation checks, real deadline brackets, and zero STOP before expiry. Close0 is sent with FIN in the new teardown case; it establishes parent teardown isolation without separately proving child cancellation before parent FIN.

Inspected retained summaries show nine actual-App cases passing Debug, ReleaseSafe and ReleaseFast; Root central tests show 1035/1035 and ReleaseSafe compilation shows 21/21 steps. These are inspected artifacts, not executions by this reviewer. Root owns authoritative process exits, remaining native regression modes, final manifests, integration, commit and push.

This increment remains private receive-only candidate evidence. Callback-triggered shutdown, broader RESET/STOP runtime cases, public APIs, TX, flow, multisession, independent client acceptance and release gates remain full-goal work. Dedicated smoke/security/fuzz/sanitizer campaigns remain deferred by the user. No source edits, builds or campaigns were performed during this review.
