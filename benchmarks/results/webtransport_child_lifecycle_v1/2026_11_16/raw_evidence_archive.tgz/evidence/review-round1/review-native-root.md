# Independent native/Root review

No remaining actionable findings in the global-pool rejection fix against
Root `0f9365e`. Reviewed engine SHA-256:
`4dff879473821d3215e225511a5e35cd72842b74ebfcc96b305b9315d32c2a5a`.
The copied project engine has the same hash.

Native proposal `530e9e505eb04a0a4095b290f7eb052504ace94e` clears WT_READY
before the UNI application constructor and sets WT_NOTIFIED afterward. Its
public association query returns PENDING in that interval. The former Root
pool-full fallback therefore closed this stream before exact coded rejection.

The fix defers only the full-contract, bound, peer-UNI PENDING constructor
case, returning NULL context with reads disabled. PENDING is not treated as
positive child metadata. The subsequent typed callback recovers and validates
the connection owner through public APIs, obtains fresh OK/child/peer metadata,
and issues coded rejection. Existing native ownership bridges this immediate
callback boundary and retains queued STOP/final-size ownership. No Root stream
slot, lease, pending reservation, queue, allocation, public API, native patch or
dependency-pin change is added. Unclassified BIDI/ordinary HTTP and unsupported
backend refusal retain the existing generic path.

The supported pre-engine client delayed-close setting preserves the FIN
rejection callback oracle; it does not fabricate protocol flags or replace
production callbacks. FIN-bearing exact-code, quota/isolation and cleanup
assertions remain required. Sending FIN alone does not establish that rejection
occurred after server FIN receipt; that stronger ordering needs its own
authoritative observation, as in the earlier standalone native proof.

Read `quota-fixed-Debug.log`: 7/7 tests and 16/16 build steps passed. This
artifact records that Debug result only. Parent-Close/future-session additions,
other optimization modes and broader lifecycle coverage are not established
by this review. The reviewer ran no builds, runtime tests, smoke or security
campaigns and changed only this requested review artifact.
