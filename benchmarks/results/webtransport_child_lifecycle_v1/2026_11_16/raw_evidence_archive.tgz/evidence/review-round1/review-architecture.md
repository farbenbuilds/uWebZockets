# Child lifecycle architecture and acceptance review

Date: 2026-11-16. Read-only standard and thermo-nuclear review of Root changes after `0f9365e` and the new scratch lifecycle harness. No builds, source edits, dependency changes, or smoke/security/fuzz/sanitizer campaigns were performed by this reviewer.

Reviewed SHA-256 inputs:

- Root `src/quic/engine.zig`: `4dff879473821d3215e225511a5e35cd72842b74ebfcc96b305b9315d32c2a5a`.
- Scratch `tests/app_children.zig`: `a2f76b5dd255dbcd71246402882f92f475c2d9961e0ec0ef24ebeabce927ec35`.
- Scratch `tests/app_child_lifecycle.zig`: `2a84515afeb4d08d074b3dc5525c90e2cd240b9ff3e93ff2ca8539f08bf18f0a`.

## Accepted boundary

Native interface construction can precede typed publication for incoming peer UNI children. Deferring only the bound candidate's peer-UNI PENDING/null-context case, then querying fresh positive metadata in the typed callback, is a narrowly justified fix for the observed generic HEC_NO_ERROR rejection. It adds no Root lease, pending payload slab, native mutation, generic vtable, or public child API.

Retain the existing pure lifecycle / child native I/O / Engine association-and-lease boundary. Engine remains oversized; the added constructor/publication branch is cohesive and cannot be removed without losing the required publication invariant. A mechanical split would not fix the lifecycle finding below. Positively classified UNI capacity rejection is proved separately from unresolved BIDI/ordinary HTTP, which cannot yet be identified as children at pool exhaustion.

## Required finding: finish terminal orphan receive halves

`src/quic/engine.zig:1064` ignores `stop_receiving` results and reports an unowned child handled even when STOP returns CLOSED without setting native `STREAM_U_READ_DONE`.

Reachable sequence: fill the Root global stream pool, then send a peer UNI containing exactly its complete WebTransport prefix followed by FIN. Native classification consumes the final prefix byte and reaches FIN before interface publication. The constructor returns null and disables reads. The typed callback queries valid child metadata, but coded STOP returns CLOSED because FIN was already reached (`lsquic_stream.c:4849`). No Root context exists to perform EOF shutdown. Native on-close/finish still requires both application halves closed (`lsquic_stream.h:568`, `lsquic_stream.c:819`), so the stream can remain allocated until connection destruction. An already-known RESET needs the same application-half cleanup consideration.

Required remedy: inspect the terminal STOP result and finish the receive half when it no longer needs or accepts a coded STOP, while preserving successful coded STOP emission and delayed-final-size retention. Prove this with a genuine failing prefix-only FIN/global-exhaustion case, then native closure or recovered stream credit on the same live connection. Aborting that connection alone would mask the orphan. This is a source-backed review finding; this reviewer did not execute its proposed regression.

## Proof acceptance

- Earlier before-CONNECT retention gap is resolved by an actual non-consuming native `readf` preview of buffered bytes, followed by exact admitted payload delivery.
- Earlier expiry gap is resolved by waiting phase/reservation checks, local/global counters, real supplied-clock deadline brackets, zero peer STOP before sleep, and exact expiry rejection afterward. The App awake clock and synthetic native fixture clock remain distinct disclosed domains.
- Per-connection quota stages four actual buffered pending children, rejects the fifth FIN with the required exact code, preserves another connection, then admits/completes retained children and verifies counters and healthy HTTP siblings.
- Global quota fills exactly eight Root slots while the rejected connection remains below its own quota. It checks exact peer STOP and unchanged Root counts, frees another connection, and verifies admitted payload recovery. The test establishes Root slot recovery, but does not currently prove rejected null-context native streams close before connection destruction; add the terminal finding's regression.
- Root reports strengthened base five and combined seven Debug cases green. Retained log summaries were inspected; no independent execution is claimed. These results do not resolve the required terminal orphan finding or complete the wider cohort.

## Next bounded acceptance

Parent Close0 must cancel owned SID0 children with exact WT_SESSION_GONE and one owned close while retaining buffered future SID4 UNI children. A subsequent real CONNECT4 must admit their exact bytes under a new parent generation; another connection's SID0 child must remain usable. Abort/reuse must show old leases and pending/retry counts drain, connection generation changes, and old keys cannot deliver into the replacement. Callback shutdown still requires more than one native read chunk already buffered, no post-shutdown delivery, and exactly one owned close. Public APIs, TX, flow, multisession, independent client acceptance, and release gates remain open full-goal work.
