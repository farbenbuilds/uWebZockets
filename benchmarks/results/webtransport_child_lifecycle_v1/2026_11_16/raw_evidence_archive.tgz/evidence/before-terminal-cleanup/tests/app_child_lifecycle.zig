const std = @import("std");
const c = @import("c");
const support = @import("test_support");
const h = @import("app_children.zig").ChildrenSupport;
const testing = std.testing;
const App = h.Application;
const Observation = h.Observation;

fn delayed_client(port: u16) !*c.struct_uwz_app_client {
    const client = c.uwz_app_client_create_variant(port, c.UWZ_APP_CLIENT_DELAYED_CLOSE) orelse return error.ClientInitialization;
    errdefer c.uwz_app_client_destroy(client);
    var profile: c.struct_uwz_app_client_snapshot = undefined;
    try testing.expectEqual(@as(c_int, 0), c.uwz_app_client_observe(client, &profile));
    try testing.expectEqual(@as(c_uint, 1), profile.configured_delay_onclose);
    return client;
}

fn expect_pending(application: *App, index: usize, local: usize, total: usize) !void {
    const engine = &application.quic_transport.?.engine;
    try testing.expectEqual(local, engine.connections.pool.storage[index].pending_child_count);
    try testing.expectEqual(total, engine.pending_child_count);
}

fn buffered_child(application: *App, client: *c.struct_uwz_app_client, clients: []const *c.struct_uwz_app_client, observed: *Observation, index: usize, bytes: []const u8) !u64 {
    const id = try h.raw_uni(client, 0, bytes);
    try h.await_pending_native(application, clients, observed, index, id, 0);
    try h.await_buffered(application, clients, observed, index, id, bytes);
    return id;
}

test "pending child connection quota rejects fifth FIN while retaining four and a sibling" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .application = &application };
    const port = try h.listen(&application, &observed);
    const a = try delayed_client(port);
    defer c.uwz_app_client_destroy(a);
    const b = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(b);
    const clients = [_]*c.struct_uwz_app_client{ a, b };
    const ai = try h.handshake(&application, a, &clients, &observed);
    const bi = try h.handshake(&application, b, &clients, &observed);
    var retained: [4]u64 = undefined;
    for (&retained) |*id| id.* = try buffered_child(&application, a, &clients, &observed, ai, "A");
    const sibling = try buffered_child(&application, b, &clients, &observed, bi, "B");
    try expect_pending(&application, ai, 4, 5);
    try expect_pending(&application, bi, 1, 5);
    try testing.expectEqual(@as(usize, 0), observed.count);
    try testing.expectEqual(@as(usize, 0), observed.authorization_calls);
    const rejected = try h.raw_uni(a, 0, "unread-final");
    try h.finish_send(a, rejected);
    try h.peer_stop(&application, a, &clients, &observed, rejected, support.webtransport.wt_buffered_stream_rejected);
    try expect_pending(&application, ai, 4, 5);
    try expect_pending(&application, bi, 1, 5);
    for (retained) |id| _ = try h.waiting_state(&application, ai, id);
    _ = try h.waiting_state(&application, bi, sibling);
    try testing.expectEqual(@as(usize, 0), observed.count);
    _ = try h.accept(&application, a, &clients, &observed, 0);
    for (retained) |id| {
        const key = try h.key_for(&application, ai, 0, id);
        _ = try h.await_data(&application, &clients, &observed, key, "A");
        try h.finish_send(a, id);
        try h.expect_completed(try h.await_closed(&application, &clients, &observed, key), "A");
    }
    try expect_pending(&application, ai, 0, 1);
    try expect_pending(&application, bi, 1, 1);
    try testing.expectEqual(@as(usize, 4), observed.count);
    _ = try h.accept(&application, b, &clients, &observed, 0);
    const key = try h.key_for(&application, bi, 0, sibling);
    _ = try h.await_data(&application, &clients, &observed, key, "B");
    try h.finish_send(b, sibling);
    try h.expect_completed(try h.await_closed(&application, &clients, &observed, key), "B");
    try expect_pending(&application, bi, 0, 0);
    try h.healthy_http(&application, a, &clients, &observed);
    try h.healthy_http(&application, b, &clients, &observed);
}

test "shared child pool rejects known UNI below connection quota and recovers after abort" {
    var application = try h.initialize();
    defer h.destroy(&application);
    var observed: Observation = .{ .application = &application };
    const port = try h.listen(&application, &observed);
    const a = try delayed_client(port);
    defer c.uwz_app_client_destroy(a);
    const b = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(b);
    const d = c.uwz_app_client_create(port) orelse return error.ClientInitialization;
    defer c.uwz_app_client_destroy(d);
    const clients = [_]*c.struct_uwz_app_client{ a, b, d };
    const ai = try h.handshake(&application, a, &clients, &observed);
    const bi = try h.handshake(&application, b, &clients, &observed);
    const di = try h.handshake(&application, d, &clients, &observed);
    var retained: [3]u64 = undefined;
    for (&retained) |*id| id.* = try buffered_child(&application, a, &clients, &observed, ai, "A");
    for (0..3) |_| _ = try buffered_child(&application, b, &clients, &observed, bi, "B");
    for (0..2) |_| _ = try buffered_child(&application, d, &clients, &observed, di, "D");
    const engine = &application.quic_transport.?.engine;
    try expect_pending(&application, ai, 3, 8);
    try expect_pending(&application, bi, 3, 8);
    try expect_pending(&application, di, 2, 8);
    try testing.expectEqual(@as(usize, 8), engine.stream_pool.count_active());
    const rejected = try h.raw_uni(a, 0, "global-full");
    try h.finish_send(a, rejected);
    try h.peer_stop(&application, a, &clients, &observed, rejected, support.webtransport.wt_buffered_stream_rejected);
    try expect_pending(&application, ai, 3, 8);
    try testing.expectEqual(@as(usize, 8), engine.stream_pool.count_active());
    try testing.expectEqual(@as(usize, 0), observed.count);
    _ = try h.abort_connection(&application, b, &clients, &observed);
    try expect_pending(&application, ai, 3, 5);
    try expect_pending(&application, di, 2, 5);
    try testing.expectEqual(@as(usize, 5), engine.stream_pool.count_active());
    _ = try h.accept(&application, a, &clients, &observed, 0);
    for (retained) |id| {
        const key = try h.key_for(&application, ai, 0, id);
        _ = try h.await_data(&application, &clients, &observed, key, "A");
        try h.finish_send(a, id);
        try h.expect_completed(try h.await_closed(&application, &clients, &observed, key), "A");
    }
    try expect_pending(&application, ai, 0, 2);
    try testing.expectEqual(@as(usize, 3), observed.count);
    try h.healthy_http(&application, a, &clients, &observed);
    _ = try h.abort_connection(&application, d, &clients, &observed);
    try expect_pending(&application, ai, 0, 0);
}
