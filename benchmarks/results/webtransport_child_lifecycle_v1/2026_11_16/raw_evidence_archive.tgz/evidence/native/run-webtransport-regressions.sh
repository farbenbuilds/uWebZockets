#!/bin/sh
set -eu
ulimit -c 0
proposal=/tmp/uwz-lsquic-wt-uni-credit-20261116
harness=/tmp/uwz-native-stop-checkpoint-20261116/harness/build.zig
logs=/tmp/uwz-wt-child-lifecycle-evidence-20261116/native
for cohort in normal resets classification placement; do
    case "$cohort" in
        normal) fixture=uwz_webtransport_streams.c ;;
        resets) fixture=uwz_webtransport_stream_resets.c ;;
        classification) fixture=uwz_webtransport_classification.c ;;
        placement) fixture=uwz_webtransport_frame_errors.c ;;
    esac
    ZIG_GLOBAL_CACHE_DIR=/tmp/uwz-uni-global-cache \
      /tmp/zig-x86_64-linux-0.16.0/zig build test --build-file "$harness" \
      -Doptimize=Debug -Dlsquic-source="$proposal" \
      -Dfixture="$proposal/tests/$fixture" \
      -Dfixture-includes="$proposal/src/liblsquic" \
      -Dfixture-support="$proposal/tests/uwz_quic_fixture.c" \
      -Dfixture-name="uwz_credit_$cohort" \
      --cache-dir /tmp/uwz-native-credit-regression-cache -j2 --summary all -- all \
      > "$logs/webtransport-$cohort-Debug.log" 2>&1
    printf 'PASS %s\n' "$cohort"
done
