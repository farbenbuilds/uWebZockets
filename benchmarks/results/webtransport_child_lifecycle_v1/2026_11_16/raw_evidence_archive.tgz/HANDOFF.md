# Incoming-child lifecycle checkpoint

Root base: 0f9365e925f735eeb7be95d0dbe8285538279732.
Final Root/copied Engine SHA256:
88dbeaffd5335e040dbd5775baee76333abc9354d0a24fe1763f0744d075d70c.
Native candidate: 005ab244169f269689e511d6b77dd2187e318df1,
parent 530e9e505eb04a0a4095b290f7eb052504ace94e.
Required libxev candidate: 5b2cde22c4ab8e472b4d810a2f7225ff95cd61d5.
All production dependency views remain unchanged; these proposals are local.

## Final authoritative checks

root/commands.txt records exact commands. metadata/results.json records final
terminal results. Root passes 1035/1035 centralized functional tests in 20/20
steps, ReleaseSafe test compilation and ReleaseFast library each 21/21 steps.
All 300 retained source/build inputs survive protected formatting unchanged;
conventions, release metadata and whitespace checks pass.

The actual App nine-case cohort passes Debug, ReleaseSafe, ReleaseFast, 9/9 tests
and 16/16 steps each. All 33 existing App cases (32 functional plus one import
anchor) pass in those three modes. The 261-input fixture/project manifest is
unchanged after all runs. Native four-group WT regressions pass 65 scenarios
(8 normal, 12 reset, 33 classification, 12 placement),12/12 steps per group. All 83
upstream Debug executables pass in 165/165 steps; their 83 unique successful
run entries were counted independently in the raw log.

Smoke, dedicated security, sanitizer and fuzz campaigns remain user-deferred.
The normal full functional target is test-unit: default test also executes a
smoke artifact. No gate, default, assertion or threshold was weakened.

## Causal failures and corrections

The initial five drafted tests passed, but review found weak preauthorization
buffering and expiry oracles. A zero-consuming public native readf preview now
observes actual buffered bytes before CONNECT. Waiting phase/reservation,
local/global counts, actual supplied-clock deadline brackets and no prior peer
STOP establish real waiting before one-second expiry. Strengthened five stay
green. No fragmented-prefix proof is claimed by the fragmented-payload case.

Both original FIN capacity tests timed out because the client default closes
its local UNI before receiving STOP. The supported pre-engine delayed-close
profile preserves the same exact-code oracle; its configured setting is
observed. This changes fixture lifetime, not protocol bits. The original
failures and diagnostic close callback are retained.

Global refusal still failed: a no-FIN control observed constructor query
PENDING and legacy 256 instead of WT_BUFFERED_STREAM_REJECTED 966049156. Native
clears WT_READY before its UNI interface switch, then sets WT_NOTIFIED after
Root on_new returns. Root now defers only that bound candidate peer-UNI case,
without taking a sidecar, and queries fresh positive child/peer metadata in the
null-context typed callback before coded rejection. Ordinary unidentified
BIDI/HTTP capacity refusal retains generic behavior.

Review then found a prefix-only FIN orphan. The actual failing case repeatedly
found that live native stream with FIN and final offset 3 after Root owned no
slot. SST_CLOSED had not closed the app read half. Root now shuts that half;
other failed orphan cancellation statuses log and close. The read-only C
observer finds a target through a freshly reacquired retained stream anchor's
native hash and copies the public receive snapshot synchronously. It never
keeps target pointers across pumps and never mutates native state.

The new abort/reuse case initially reported session_closed. Native could close
CONNECT before the child while the connection was already aborted. Root now
uses canonical native connection status before choosing the first immutable
child close cause. Close0+FIN isolation and unknown-final abort/reuse pass.

Creation beyond initial UNI credit then stalled with Root cleanup already
correct. Native closed 5 + floor(window 11 / 2) = 10 never reached advertised 11 while
six streams persisted. Its UNI factory returns BLOCKED without sending a
STREAMS_BLOCKED notification. Native 005ab244 schedules close-driven UNI credit
only in WT-enabled HTTP through the existing coalesced send flag; peer/dedup
guards and closed+configured-window generator remain. No initial credit was
raised. The unchanged regression creates six prefix-only rejected streams,
verifies native removal on the live connection, and crosses the original
stream-ID credit. Sixteen client history cells permit this test; Root capacity
remains eight. Real MAX_STREAMS progress is awaited through the public factory.

## Scope and reproduction

app/ contains exact current project copy, test drivers and C fixtures; use the
package replay.sh for lifecycle or existing cohorts with Zig 0.16.0. native-source/
contains all tracked 005ab244 source; git/ retains its full history. libxev-source/
retains all tracked 5b2cde22 source. The copied native regression harness uses
only Zig's C toolchain; source CMake files are not build requirements. Package
metadata records immutable dependencies. Actual compiled hpack is
fda48e02491d865cce00612be8cc10c2622b8e55; its native gitlink remains
cf0f70dd10b352194c97448eb5d00b4aa484f531. qpack
91567706c41c0d97ab8dc576873ecd472d7869fa matches its gitlink.

App runs actual TLS/native engines, Linux loopback UDP and xev. Native scheduling
time is inherited synthetic fixture time; App waiting expiry uses actual awake
monotonic time and a real 1.1 second sleep. Current Close0 test sends FIN with its
capsule and therefore does not prove child cancellation before parent FIN.

Round-one review findings and failed variants are preserved. Final read-only
reviews are clear at exact Root 88dbeaff/native 005ab244 bytes. Their preparation
status for some checks is historical; final commands/results/logs above are
authoritative. Initial empty logs during a sandbox quota failure are not pass
evidence. Only two inactive, regenerable old Zig caches were cleared after
checking no live compiler used them; source/history/evidence were preserved.

Callback shutdown, wider actual-App RESET/STOP ordering, public child I/O/TX,
flow accounting, multi-session support, independent-client acceptance and fork
publication/pins remain required. The full v2.3.0 objective, SQL allocation and
performance gates and other recorded platform/release requirements remain
active and incomplete. This checkpoint is not release acceptance.

The independently extracted source snapshot also replayed all nine Debug cases
(exit0,16/16steps). evidence/relocated-replay-Debug.log retains the result.
Its first envelope SHA256 was79ca4dad6cd2d2ac47fc3b61fe7ab17d37b90f2a8787fcb28a96aaf6f66bde70;
this final envelope adds only that result and this note. Program source, native
commit, replay script and all261 source inputs are identical.
