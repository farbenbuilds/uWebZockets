comptime {
    _ = @import("app_child_lifecycle.zig");
    _ = @import("app_child_teardown.zig");
}
