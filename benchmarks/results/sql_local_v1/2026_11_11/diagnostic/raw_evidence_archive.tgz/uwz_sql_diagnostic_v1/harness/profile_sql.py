#!/usr/bin/env python3
"""Scoped diagnostic cohort; never an acceptance measurement."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import urllib.request

OUTPUT = Path(sys.argv[1]).resolve()
OUTPUT.mkdir()
SOURCE = Path('/tmp/uwz_sql_local_v1.dCC4RYXk')
SERVER = SOURCE / 'workers_12/build/bin/sql_cluster_server'
WRK = '/tmp/uwz-sql-perf-tools/usr/bin/wrk'
LUA = SOURCE / 'harness/benchmarks/sql_report.lua'
if not LUA.exists():
    LUA = Path.cwd() / 'benchmarks/sql_report.lua'
CONTAINER = 'uwz-v230-sql-agent'
PORT = 31631
HZ = os.sysconf('SC_CLK_TCK')


def command(args, **kwargs):
    return subprocess.run(args, check=True, text=True, capture_output=True, **kwargs).stdout


def pg(query):
    return command(['docker', 'exec', '--user', 'postgres', CONTAINER,
                    'psql', '-XAt', '-U', 'uwz_test', '-d', 'uwz_test', '-c', query])


def snapshot(pid, include_tasks):
    paths = [Path(f'/proc/{pid}')]
    if include_tasks:
        paths += sorted(Path(f'/proc/{pid}/task').glob('*'))
    result = []
    for path in paths:
        try:
            raw = (path / 'stat').read_text()
            fields = raw[raw.rfind(')') + 2:].split()
            status = {}
            for line in (path / 'status').read_text().splitlines():
                key, _, value = line.partition(':')
                if key in ('voluntary_ctxt_switches', 'nonvoluntary_ctxt_switches', 'Cpus_allowed_list', 'VmRSS'):
                    status[key] = value.strip()
            result.append(dict(pid=pid, tid=int(path.name), task='/task/' in str(path),
                               state=fields[0], utime=int(fields[11]), stime=int(fields[12]),
                               cpu=int(fields[36]), wchan=(path / 'wchan').read_text().strip(), **status))
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    return result


def pg_pids():
    lines = command(['docker', 'top', CONTAINER, '-eo', 'pid,ppid,comm'])
    return lines, [int(line.split()[0]) for line in lines.splitlines()[1:]
                   if len(line.split()) == 3 and line.split()[2] == 'postgres']


def host_snapshot():
    return dict(cpu=Path('/proc/stat').read_text().splitlines()[0],
                load=Path('/proc/loadavg').read_text().strip(),
                pressure=Path('/proc/pressure/cpu').read_text().strip())


def ready(log, workers, server):
    for _ in range(300):
        if server.poll() is not None:
            raise RuntimeError('owned server exited before readiness')
        if log.read_text().count('server listening on 127.0.0.1:31631') >= workers:
            with urllib.request.urlopen(f'http://127.0.0.1:{PORT}/db') as response:
                if response.status == 200:
                    return
        time.sleep(.05)
    raise RuntimeError('owned server readiness bound exceeded')


def stop(server):
    if server is None:
        return
    server.terminate()
    try:
        server.wait(timeout=15)
    except subprocess.TimeoutExpired:
        server.kill()
        server.wait()
        raise RuntimeError('owned server exceeded shutdown bound')
    if server.returncode != 0:
        raise RuntimeError(f'owned server failed: {server.returncode}')


STATS = "SELECT row_to_json(s) FROM (SELECT xact_commit,xact_rollback,blks_read,blks_hit,tup_returned,tup_fetched,tup_inserted,tup_updated,deadlocks,blk_read_time,blk_write_time FROM pg_stat_database WHERE datname='uwz_test') s"
WAITS = "SELECT extract(epoch FROM clock_timestamp()),coalesce(state,''),coalesce(wait_event_type,'CPU_or_unreported'),coalesce(wait_event,''),count(*) FROM pg_stat_activity WHERE datname='uwz_test' AND pid<>pg_backend_pid() GROUP BY state,wait_event_type,wait_event ORDER BY 2,3,4;\n\\watch 0.2\n"
metadata = dict(diagnostic_only=True, official_acceptance=False, hz=HZ,
                source_evidence=str(SOURCE), server_binary=str(SERVER),
                perf_event_paranoid=Path('/proc/sys/kernel/perf_event_paranoid').read_text().strip(),
                host_policy='shared development host', warmup_seconds=2, load_seconds=20,
                process_sample_seconds=.2, pg_wait_sample_seconds=.2)
(OUTPUT / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
(OUTPUT / 'server.sha256').write_text(command(['sha256sum', str(SERVER)]))
(OUTPUT / 'tool_versions.txt').write_text(command(['strace', '-V']) + command(['perf', '--version']))
for workers, trace in ((8, False), (12, False), (12, True)):
    cohort = OUTPUT / f'workers_{workers}{"_strace" if trace else ""}'
    cohort.mkdir()
    server = tracer = watch = load = None
    handles = []
    try:
        environment = os.environ.copy()
        environment.update(UWZ_HTTP_PORT=str(PORT), UWZ_SQL_WORKERS=str(workers), UWZ_SQL_AFFINITY='1')
        log = cohort / 'server.log'
        log_handle = log.open('w')
        handles.append(log_handle)
        if trace:
            tracer = subprocess.Popen(['strace', '-f', '-c', '-o', str(cohort / 'strace_summary.txt'), str(SERVER)], env=environment, stdout=log_handle, stderr=log_handle)
            for _ in range(100):
                children = Path(f'/proc/{tracer.pid}/task/{tracer.pid}/children').read_text().split()
                if children:
                    break
                time.sleep(.02)
            pid = int(children[0])
            ready(log, workers, tracer)
        else:
            server = subprocess.Popen([str(SERVER)], env=environment, stdout=log_handle, stderr=log_handle)
            pid = server.pid
            ready(log, workers, server)
        listener = command(['ss', '-ltnp', f'sport = :{PORT}'])
        if f'pid={pid},' not in listener:
            raise RuntimeError('listener ownership mismatch')
        (cohort / 'listener.txt').write_text(listener)
        base = [WRK, '-t4', f'-c{workers * 16}', '--latency', '-s', str(LUA), f'http://127.0.0.1:{PORT}/db', '--', str(cohort / 'request.http')]
        (cohort / 'warmup.log').write_text(command(base[:3] + ['-d2s'] + base[3:], env=environment))
        top, postgres_pids = pg_pids()
        (cohort / 'postgres_processes.txt').write_text(top)
        (cohort / 'database.before.json').write_text(pg(STATS))
        (cohort / 'host.before.json').write_text(json.dumps(host_snapshot()) + '\n')
        wait_log = (cohort / 'postgres_waits.txt').open('w')
        handles.append(wait_log)
        watch = subprocess.Popen(['docker', 'exec', '-i', '--user', 'postgres', CONTAINER,
                                  'timeout', '22', 'psql', '-XAt', '-U', 'uwz_test', '-d', 'uwz_test'], stdin=subprocess.PIPE, stdout=wait_log, stderr=subprocess.STDOUT, text=True)
        watch.stdin.write(WAITS)
        watch.stdin.close()
        load_log = (cohort / 'load.log').open('w')
        handles.append(load_log)
        load = subprocess.Popen(base[:3] + ['-d20s'] + base[3:], env=environment, stdout=load_log, stderr=subprocess.STDOUT)
        (cohort / 'command.json').write_text(json.dumps(dict(server_pid=pid, wrk_pid=load.pid, workers=workers, strace=trace, command=load.args), indent=2) + '\n')
        with (cohort / 'samples.jsonl').open('w') as samples:
            while load.poll() is None:
                item = dict(monotonic=time.monotonic(), server=snapshot(pid, True),
                            wrk=snapshot(load.pid, True), postgres=[row for pg_pid in postgres_pids for row in snapshot(pg_pid, False)], host=host_snapshot())
                samples.write(json.dumps(item) + '\n')
                samples.flush()
                time.sleep(.2)
        if load.returncode != 0:
            raise RuntimeError('wrk failed')
        watch.wait(timeout=4)
        if watch.returncode not in (0, 124):
            raise RuntimeError('bounded postgres sampler failed')
        watch = None
        (cohort / 'database.after.json').write_text(pg(STATS))
        (cohort / 'host.after.json').write_text(json.dumps(host_snapshot()) + '\n')
        if trace:
            os.kill(pid, 15)
            tracer.wait(timeout=15)
            if tracer.returncode != 0:
                raise RuntimeError('traced owned server failed')
            tracer = None
        else:
            stop(server)
            server = None
        print(f'{cohort.name}: complete', flush=True)
    finally:
        if load is not None and load.poll() is None:
            load.terminate()
            load.wait(timeout=5)
        if watch is not None and watch.poll() is None:
            watch.terminate()
            watch.wait(timeout=5)
        stop(server)
        if tracer is not None and tracer.poll() is None:
            if 'pid' in locals():
                os.kill(pid, 15)
            tracer.wait(timeout=15)
        for handle in handles:
            handle.close()
(OUTPUT / 'run.status').write_text('passed\n')
