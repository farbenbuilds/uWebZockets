import collections
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
hz = json.loads((root / 'metadata.json').read_text())['hz']
summary = {}
for cohort in sorted(root.glob('workers_*')):
    if not (cohort / 'database.after.json').exists():
        continue
    rows = [json.loads(line) for line in (cohort / 'samples.jsonl').read_text().splitlines()]
    elapsed = rows[-1]['monotonic'] - rows[0]['monotonic']
    def counter(group, field, task=False):
        initial = {}
        final = {}
        for row in rows:
            for x in row[group]:
                if x['task'] != task:
                    continue
                key = x['pid'], x['tid']
                initial.setdefault(key, x)
                final[key] = x
        return sum(int(x.get(field, 0)) - int(initial[key].get(field, 0)) for key, x in final.items() if key in initial)
    item = {'sample_elapsed_seconds': elapsed, 'sample_count': len(rows)}
    for group in ('server', 'wrk', 'postgres'):
        user = counter(group, 'utime') / hz / elapsed * 100
        system = counter(group, 'stime') / hz / elapsed * 100
        item[group] = {'user_cpu_percent': user, 'system_cpu_percent': system, 'total_cpu_percent': user + system}
        if group != 'postgres':
            item[group]['voluntary_switches_per_second'] = counter(group, 'voluntary_ctxt_switches', True) / elapsed
            item[group]['involuntary_switches_per_second'] = counter(group, 'nonvoluntary_ctxt_switches', True) / elapsed
            item[group]['wchan_task_samples'] = dict(collections.Counter(x['wchan'] for row in rows for x in row[group] if x['task']))
            item[group]['thread_affinities'] = sorted(set(x.get('Cpus_allowed_list', '') for row in rows for x in row[group] if x['task']))
    waits = collections.Counter()
    for line in (cohort / 'postgres_waits.txt').read_text().splitlines():
        fields = line.split('|')
        if len(fields) == 5:
            waits['|'.join(fields[1:4])] += int(fields[4])
    total = sum(waits.values())
    item['pg_backend_observation_count'] = total
    item['pg_wait_backend_observation_percent'] = {key: value / total * 100 for key, value in waits.items()}
    before = json.loads((cohort / 'database.before.json').read_text())
    after = json.loads((cohort / 'database.after.json').read_text())
    item['pg_database_delta'] = {key: after[key] - before[key] for key in before}
    for line in (cohort / 'load.log').read_text().splitlines():
        if line.startswith('SQL_SAMPLE '):
            item['http'] = json.loads(line.removeprefix('SQL_SAMPLE '))
            item['http']['rps'] = item['http']['requests'] * 1e6 / item['http']['duration_us']
    first = [int(x) for x in rows[0]['host']['cpu'].split()[1:]]
    last = [int(x) for x in rows[-1]['host']['cpu'].split()[1:]]
    delta = [b - a for a, b in zip(first, last)]
    total_ticks = sum(delta[:8])
    item['host_cpu_percent'] = {name: delta[index] / total_ticks * 100 for index, name in enumerate(('user','nice','system','idle','iowait','irq','softirq','steal'))}
    item['load_first'] = rows[0]['host']['load']
    item['load_last'] = rows[-1]['host']['load']
    summary[cohort.name] = item
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
