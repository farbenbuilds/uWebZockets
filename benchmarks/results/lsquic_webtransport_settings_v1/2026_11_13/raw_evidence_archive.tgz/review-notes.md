# Independent review record

Generation code/tests, peer parser/publication and lifecycle fixtures were
independently reviewed. No remaining actionable findings. The last review
found the second-frame fixture could hit duplicate detection before testing
snapshot mutation. Its revised first frame explicitly omits all flow IDs;
the incomplete second frame introduces unseen DATA, with an immediate query
before END. Frozen delivery-test SHA256:
300134d4ed37b781169ad75afb5907b7a60ab77646655812b8b8069f246d568c.
A second read-only review confirmed the masking gap is closed and callback,
exact error and close-snapshot assertions remain intact.

The truncated-frame fixture initially closed both halves of an outgoing
critical uni stream. Its nonexistent read half generated STOP_SENDING and a
transport stream-state error. It now uses public write-half shutdown and
asserts no STOP is queued. No production workaround was added.

The getter rejects raw QUIC and validates IETF/full tags before casting.
Actual GQUIC/mini calls and real resumed SETTINGS traffic are not covered.
Root live early data stays disabled. Remaining smoke/security runs are
deferred; no new scanner or sanitizer pass is claimed for this increment.

## Accepted next child-backend plan, not implemented here

Only the child initiator sends an association prefix. Metadata must expose
full uint64 session IDs and separate send/receive prefix lengths. Subtract
only the corresponding directional prefix from final size; reliable-reset
floors apply only to the sending initiator. Handle WT STOP before existing
buffered-data discard so the prefix survives.

WT opt-in clients need configured uni admission and matching TLS advertisement;
ordinary HTTP keeps three critical incoming streams. WT bidi admission must
match advertised count. Configure positive receive windows for both halves
of server-bidi streams and select send credit by stream initiator, not old
HTTP client/server roles.

Use existing stream ownership/lookup, immediate typed creation results and
quiescent classification notifications. Outgoing prefixes/metadata exist
before callbacks; incoming application context and metadata precede typed
notification and reset visibility. Do not enable the legacy WT macro: it
uses obsolete settings, narrow session IDs and incomplete raw transitions.
No new C session registry or delayed queue is needed. Zig owns bounded pending
associations and authenticated, Origin-approved CONNECT admission. Missing
SETTINGS blocks outgoing creation without a busy service queue. Preserve
ordinary HTTP siblings and default-off behavior.
