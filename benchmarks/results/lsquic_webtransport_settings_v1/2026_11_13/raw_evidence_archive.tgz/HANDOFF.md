# WebTransport SETTINGS checkpoint

Restore archived uni and reliable-reset histories first. This incremental
bundle requires reset 3640992bb231d3f0f2647e03fda6a2776fcc23ca and contains
generation 74b8a8e1213b73b3c86f3b43c9b6437f30f0d908 plus peer-publication
8b0ef12414cdcf7b8c20e0b9f4fceb321358c2d0. Verify the bundle, fetch its branch,
and compare proposal-inputs.sha256 after checkout. Root pins/capabilities
remain unchanged.

The native scaffold compiles dependencies with Zig 0.16.0. Relocate scratch
paths using -Dlsquic-source, -Dfixture, -Dfixture-includes and
-Dfixture-support. The zon file retains existing exact native dependency
pins. Earlier dependency archives provide offline sources; caches and build
artifacts are not included. Set ulimit -c 0 for fixture execution.

Upstream tests use -Dupstream-tests=true -Dfixture-hooks=false and
-Dwt-settings-observer=false. Cross-target library gates also disable both
fixture switches. Production builds have no settings-observer call.

Wire and control-delivery fixtures require -Dwt-settings-observer=true,
-Dfixture-hooks=true and shared support uwz_quic_fixture.c. The constructor
observer borrows the actual control stream. Writes/flushes/half shutdowns
use public APIs; frames travel through real native QUIC encryption/parsing.
No fake ACK or encrypted-packet mutation is used. Peer lifecycle fixtures
need shared support but no settings observer; pure config/state fixtures
need no support. Fixture assertions stay enabled in optimized modes.

Command JSON/logs distinguish generation-only gates at 74b8a8e from final
peer gates at 8b0ef124. The last delivery change affects only the second-frame
workload; its focused reruns have separate Debug/ReleaseSafe/ReleaseFast logs.
Earlier failures retain original statuses. Public layout probes are compiler
results, not foreign runtime execution. This is not live-session/client
acceptance, maintained-fork publication, root activation or v2.3.0 completion.
