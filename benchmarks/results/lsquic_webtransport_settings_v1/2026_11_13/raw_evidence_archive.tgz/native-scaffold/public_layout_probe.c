#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/queue.h>
#include <sys/types.h>
#include "lsquic.h"
#include "lsquic_int_types.h"
#include "lsquic_packet_common.h"
#include "lsquic_alarmset.h"
#include "lsquic_packet_in.h"
#include "lsquic_conn_flow.h"
#include "lsquic_rtt.h"
#include "lsquic_sfcw.h"
#include "lsquic_varint.h"
#include "lsquic_hq.h"
#include "lsquic_hash.h"
#include "lsquic_stream.h"
#include "lsquic_packet_out.h"

const uint64_t uwz_wt_layout[] = {
    sizeof(struct lsquic_engine_settings),
    _Alignof(struct lsquic_engine_settings),
    sizeof(struct lsquic_stream_if),
    offsetof(struct lsquic_stream_if, on_hset_in),
    offsetof(struct lsquic_engine_settings, es_max_header_sets),
    offsetof(struct lsquic_engine_settings, es_reset_stream_at),
    sizeof(struct lsquic_stream),
    sizeof(struct lsquic_packet_out),
    sizeof(struct frame_rec),
#ifdef WT_LAYOUT_NEW
    offsetof(struct lsquic_engine_settings, es_webtransport),
    offsetof(struct lsquic_stream_if, on_h3_settings),
#else
    0, 0,
#endif
};
