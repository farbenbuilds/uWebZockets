; ModuleID = '/tmp/uwz-lsquic-webtransport-harness/public_layout_probe.c'
source_filename = "/tmp/uwz-lsquic-webtransport-harness/public_layout_probe.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux5.10.0-gnu2.31.0"

@uwz_wt_layout = constant [11 x i64] [i64 352, i64 8, i64 120, i64 112, i64 344, i64 348, i64 760, i64 144, i64 16, i64 0, i64 0], align 16, !dbg !0

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!15, !16, !17, !18, !19, !20}
!llvm.ident = !{!21}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "uwz_wt_layout", scope: !2, file: !5, line: 20, type: !6, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "clang version 21.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/tmp/uwz-lsquic-webtransport-harness/public_layout_probe.c", directory: "/home/foo/Desktop/Repos/uWebZockets")
!4 = !{!0}
!5 = !DIFile(filename: "/tmp/uwz-lsquic-webtransport-harness/public_layout_probe.c", directory: "")
!6 = !DICompositeType(tag: DW_TAG_array_type, baseType: !7, size: 704, elements: !13)
!7 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !8)
!8 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !9, line: 27, baseType: !10)
!9 = !DIFile(filename: "/tmp/zig-x86_64-linux-0.16.0/lib/libc/include/generic-glibc/bits/stdint-uintn.h", directory: "")
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !11, line: 45, baseType: !12)
!11 = !DIFile(filename: "/tmp/zig-x86_64-linux-0.16.0/lib/libc/include/generic-glibc/bits/types.h", directory: "")
!12 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!13 = !{!14}
!14 = !DISubrange(count: 11)
!15 = !{i32 7, !"Dwarf Version", i32 4}
!16 = !{i32 2, !"Debug Info Version", i32 3}
!17 = !{i32 1, !"wchar_size", i32 4}
!18 = !{i32 8, !"PIC Level", i32 2}
!19 = !{i32 7, !"uwtable", i32 2}
!20 = !{i32 7, !"frame-pointer", i32 2}
!21 = !{!"clang version 21.1.0"}
