"""Copy explicit evidence files and preserve source identities and modes."""
import hashlib
import json
from pathlib import Path
import shutil
import stat


MANIFEST = 'payload_manifest.json'
FORBIDDEN_PARTS = {'.git', '.zig-cache', 'zig-pkg', 'private', '__pycache__', 'build-cache', 'unit-cache'}
FORBIDDEN_EXTENSIONS = {'.a', '.bin', '.env', '.key', '.o', '.pem', '.pyc', '.so'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def mode(path):
    return stat.S_IMODE(path.stat().st_mode)


def checked_path(name):
    path = Path(name)
    require(path.parts and not path.is_absolute() and '..' not in path.parts and
            not FORBIDDEN_PARTS.intersection(path.parts) and path.suffix not in FORBIDDEN_EXTENSIONS,
            f'Path outside the public payload: {name}')
    return path


def copy_file(source, destination, name):
    path = checked_path(name)
    original = source / path
    require(original.is_file() and not original.is_symlink(), f'Expected public regular file: {original}')
    output = destination / path
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(original, output)


def copy_group(source, destination, group):
    directory = source / checked_path(group)
    require(directory.is_dir() and not directory.is_symlink(), f'Expected an evidence directory: {directory}')
    (destination / group).mkdir(parents=True, exist_ok=True)
    for path in sorted(directory.rglob('*')):
        rel = checked_path(path.relative_to(source))
        require(not path.is_symlink(), f'Unexpected evidence link: {rel}')
        if path.is_dir():
            (destination / rel).mkdir(exist_ok=True)
            continue
        copy_file(source, destination, rel)


def require_identity(root, entry):
    path = root / checked_path(entry['path'])
    require(path.is_file() and not path.is_symlink(), f'Missing regular file: {path}')
    expected_mode = entry['mode']
    if isinstance(expected_mode, str):
        expected_mode = int(expected_mode, 8)
    require(sha(path) == entry['sha256'] and mode(path) == expected_mode, f'File identity differs: {path}')
    return path


def copy_closure(source, destination, entries):
    names = set()
    for entry in entries:
        name = entry['path']
        require(name not in names, f'Duplicate source path: {name}')
        require_identity(source, entry)
        copy_file(source, destination, name)
        names.add(name)
    return names


def inventory(root):
    regular = set()
    for path in root.rglob('*'):
        name = checked_path(path.relative_to(root)).as_posix()
        require(not path.is_symlink(), f'Unexpected evidence link: {name}')
        if path.is_dir():
            continue
        require(path.is_file(), f'Expected public regular file: {name}')
        regular.add(name)
    return regular


def write_manifest(root):
    entries = [{'path': name, 'sha256': sha(root / name), 'mode': mode(root / name)}
               for name in sorted(inventory(root) - {MANIFEST})]
    (root / MANIFEST).write_text(json.dumps({'files': entries}, indent=2) + '\n')
    return len(entries)


def check_manifest(root):
    entries = load(root / MANIFEST)['files']
    names = {entry['path'] for entry in entries}
    require(len(names) == len(entries) and inventory(root) == names | {MANIFEST}, 'Payload inventory differs')
    for entry in entries:
        require_identity(root, entry)
    return len(entries)
