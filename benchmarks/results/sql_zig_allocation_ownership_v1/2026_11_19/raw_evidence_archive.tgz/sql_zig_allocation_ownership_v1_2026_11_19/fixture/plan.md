# Plaintext PostgreSQL allocation verification fixture

## Setup

1. Use the cached PostgreSQL 18.6 image `postgres@sha256:e3d24f6906d0760bf4da0dae872415391ededefad23fd471c47dc53b0ddf3c42` with `--pull=never`. Create a new host-network container with an owned tmpfs, `max_connections=100`, and `listen_addresses=127.0.0.1` on a fresh ephemeral port. Persist the new ownership nonce before Docker creation and bind the returned full container ID to that nonce.
2. Initialize with `--auth-local=trust --auth-host=scram-sha-256`. Inspect the actual ordered HBA rules and require the first IPv4 loopback rule to use SCRAM. Verify the image ID, full container ID, role and nonce labels, host PID and cgroup, exact IPv4 listener and owning file descriptor, postmaster start time, and Unix socket port before provisioning.
3. Use a fixture administrator over the owned Unix socket. Create a fresh non-superuser `uwz_test` login and its owned `uwz_test` database. Set its random password through psql input and confirm an ordinary plaintext TCP login with the expected role, database, and endpoint.
4. Create `private/unit.env` mode `0600`, under a directory mode `0700`, with exactly `UWZ_SQL_TEST_PASSWORD` and `UWZ_SQL_TEST_PORT`. Load both into the ordinary test child environment. This matches the hard-coded role/database and environment names in `src/tests/sql_test_support.zig`.
5. If the architect selects an end-to-end application run, provision its own role/database and a separate private app env that matches the selected entry point. Use one worker and its normal eight SQL sessions. The architect supplies the route and exact seed before application provisioning.

## Ownership and teardown

- Use the label `uwz.sql-experiment=sql-allocation-permitted-20261119` with an exact database or application role and a per-creation nonce. A failed creation can recover ownership only by that exact label set and a full immutable container ID.
- Write public JSON receipts in this fixture subtree. Include identities, readiness and after-test session counts, command exit statuses, and the generated file inventory. Keep environment and authentication inputs private.
- At teardown, require zero application containers, TCP sessions, and other client backends, including Unix controllers. Recheck the original postmaster identity, PID/cgroup, and listener ownership. Use `docker stop --timeout 30` on the verified ID, inspect exit zero, recheck ownership, and remove that container by ID. Check listener release and shared image retention, then unlink only the verified generated private files.

## Reuse boundary

Derive the loopback listener and ordered HBA checks from the retained D-5 `host_fixture/setup_fixture.py`. Derive scoped role creation and private file writing from `host_fixture/setup_unit_fixture.py`. Use the stop-state, inventory, and exact-file deletion patterns in `final_cleanup/teardown.py` and `final_cleanup/finish_teardown.py`. Bind all new paths and receipts under this fixture subtree with fresh identifiers.

Root approval after the architect’s plan is the prerequisite for Docker, SQL, or application execution.
