#!/usr/bin/env python3
"""Authenticate the archived source, Zig test and PostgreSQL fixture receipts."""
import difflib
import json
from pathlib import Path
import re
import sys

from bundle_files import check_manifest, checked_path, inventory, load, require, require_identity, sha


BUNDLE = Path(__file__).resolve().parent
SOURCE = BUNDLE / 'source'
DEV = BUNDLE / 'developer'
FIXTURE = BUNDLE / 'fixture/setup_01'
PARENT = '66804326e4f58e276cb51006d5b24186c405af25'
MAIN = 'src/tests/main.zig'
TEST = 'src/tests/sql_allocation_ownership_tests.zig'
IMPORT = '        _ = @import("sql_allocation_ownership_tests.zig");\n'
COMPILER = '2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c'


def verify_source():
    identity = load(BUNDLE / 'source_identity.json')
    require(identity['parent_commit'] == PARENT and identity['parent_tree'] == 'ef417e5968865e6c3db58f69467ecbeb49e96932',
            'Wrong parent source identity')
    entry = identity['parent_main']
    require(entry['path'] == f'parent/{MAIN}' and entry['sha256'] ==
            '4ca6f6b355f21d84b6cf378847c93a239a0cb1e254f6d9a6c6b50e823223c9f6', 'Wrong parent test entry point')
    base = require_identity(BUNDLE, entry).read_text()
    entries = {entry['path']: entry for entry in identity['source']}
    require(len(entries) == len(identity['source']) and inventory(SOURCE) == entries.keys(), 'Wrong selected source inventory')
    for path, entry in entries.items():
        relation = {MAIN: 'modified', TEST: 'added'}.get(path, 'byte_identical')
        require(entry['relation_to_parent'] == relation, f'Unexpected source delta: {path}')
        require_identity(SOURCE, entry)
    current_main = (SOURCE / MAIN).read_text()
    require(current_main.count(IMPORT) == 1 and current_main.replace(IMPORT, '') == base, 'Main changes exceed the new import')
    delta = []
    for original, name in ((base, MAIN), ('', TEST)):
        delta.extend(difflib.unified_diff(original.splitlines(keepends=True), (SOURCE / name).read_text().splitlines(keepends=True),
                                          fromfile=f'a/{name}' if original else '/dev/null', tofile=f'b/{name}'))
    require(''.join(delta) == (BUNDLE / 'test_delta.patch').read_text(), 'Test source delta differs')
    return {name: entry['sha256'] for name, entry in entries.items()}


def verify_test_runs(summary, source):
    counts = {
        'controls_01': (1, None),
        'controls_02': (0, '23/23 steps succeeded; 2/2 tests passed'),
        'live_runtime_01': (0, '23/23 steps succeeded; 3/3 tests passed'),
        'live_world_01': (0, '23/23 steps succeeded; 4/4 tests passed'),
        'full_units_01': (0, '23/23 steps succeeded; 1202/1209 tests passed (7 skipped)'),
    }
    historical_test_hashes = {
        'controls_01': 'bcc480960c8d073731766fe57315949aafee1df5ae57c8c7a8fb3c31c5556bde',
        'controls_02': '39ae76bb9be88f9372eec88ae635f4cce61c8cd15ad5c41d9a41ab54c4599d62',
        'live_runtime_01': '90c21900fe8bbe3a507833c640f2eb4fc5f5146013404f2e8d4e091ea028cdb7',
    }
    sources = {path: source[path] for path in (TEST, MAIN, 'examples/sql_postgres.zig', 'src/sql/db.zig', 'src/sql/connection.zig')}
    require(sources == summary['sources'] and summary['compiler']['sha256'] == COMPILER, 'Wrong tested source or compiler identity')
    for name, (exit_code, expected_summary) in counts.items():
        data = load(DEV / f'{name}.json')
        log = (DEV / f'{name}.stdout').read_text() + (DEV / f'{name}.stderr').read_text()
        last = name == 'full_units_01'
        flags = ['build', 'test-unit', '-Dsql=true', '-Dsqlite=true']
        if not last:
            flags.append('-Dtest-filter=sql allocation ownership:')
        argv = data['argv']
        require(data['exit_code'] == exit_code and data['started_unix'] < data['finished_unix'] and data['pid'] > 0,
                f'Unexpected original process result: {name}')
        require(argv[0] == summary['compiler']['path'] and argv[1:1 + len(flags)] == flags and
                argv[1 + len(flags)::2] == ['--global-cache-dir', '--cache-dir', '--summary'] and argv[-1] == 'all',
                f'Wrong test command: {name}')
        require(data['sources'] == sources | {TEST: historical_test_hashes.get(name, source[TEST])},
                f'Wrong sources for {name}')
        observed = re.findall(r'(?:\d+/?)+(?: tests? passed| pass| skip| fail| crashed)', log)
        require(observed == data['test_counts'], f'Raw test counts differ: {name}')
        if expected_summary:
            require(f'Build Summary: {expected_summary}' in log and not re.search(r'\b\d+ (?:fail|crashed)\b', log),
                    f'Expected build summary differs: {name}')
        else:
            require('expected type \'sql_allocation_ownership_tests.Allocation\', found' in log and
                    'compile test Debug native 1 errors' in log and 'run test transitive failure' in log,
                    'Initial failure must be compile-only')
        if name in ('live_world_01', 'full_units_01'):
            outcome = summary['full_ordinary' if last else 'focused']
            require(outcome['receipt'] == f'{name}.json' and outcome['exit_code'] == exit_code and outcome['argv'] == argv,
                    f'Final assertion receipt is detached: {name}')
        if last:
            warnings = [line for line in log.splitlines() if 'SQL integration skipped:' in line]
            require(len(warnings) == 7 and warnings == outcome['skip_warnings'] and
                    (outcome['passed'], outcome['skipped'], outcome['total']) == (1202, 7, 1209), 'Wrong ordinary-test skips')
        if name == 'live_world_01':
            require((outcome['passed'], outcome['skipped']) == (4, 0), 'Wrong final focused outcome')


def verify_assertion_summary(summary):
    require(summary['schema'] == 'uwz_supplied_zig_allocator_assertions_v1', 'Wrong assertion scope')
    require(set(summary['positive_controls'].values()) == {1} and len(summary['positive_controls']) == 6,
            'Wrong positive control counts')
    require(set(summary['db_owners']) == {'offline_init', 'live_runtime', 'world_context_db'} and
            all(owner == {'startup_allocations': 3, 'matching_deinit_frees': 3} for owner in summary['db_owners'].values()),
            'Wrong Db ownership assertions')
    counts = {key: 0 for key in ('alloc_attempts', 'resize_attempts', 'remap_attempts', 'frees')}
    require(len(summary['cases']) == 10 and set(summary['drain_windows']) == {'runtime', 'world'} and
            all(case['armed_counts'] == counts for case in (*summary['cases'], *summary['drain_windows'].values())),
            'Wrong armed assertion counts')
    cases = {case['case']: case['once_only_assertions'] for case in summary['cases']}
    runtime_source = (SOURCE / 'src/sql/runtime_types.zig').read_text()
    chunk = int(re.search(r'pub const max_batch_statements = (\d+);', runtime_source)[1])
    for route, count, width, multiplier in (('db', 1, chunk, 1), ('queries', 20, chunk, 1), ('queries', 500, chunk, 1),
                                            ('updates', 20, chunk // 2, 2), ('updates', 500, chunk // 2, 2)):
        continuations = (count + width - 1) // width
        require(cases[f'/{route} count={count}'] == {'complete': 1, 'wake': 1, 'begin': continuations,
                                                   'end': continuations, 'aggregate_actual_typed_rows': count * multiplier},
                f'Wrong World assertion summary: {route}/{count}')


def verify_fixture():
    prefix = '.zig-cache/sql-allocation-permitted-20261119/'
    checked = set()
    for line in (FIXTURE / 'sha256.txt').read_text().splitlines():
        digest, name = line.split(maxsplit=1)
        path = checked_path(name.removeprefix(prefix))
        require(name.startswith(prefix) and path not in checked and sha(BUNDLE / path) == digest,
                f'Fixture producer checksum differs: {name}')
        checked.add(path)
    require(checked == {path.relative_to(BUNDLE) for path in FIXTURE.glob('*.json')} |
            {Path('setup_fixture.py'), Path('fixture/plan.md')}, 'Wrong fixture setup receipt inventory')
    fixture_path = FIXTURE / 'fixture.json'
    fixture = load(fixture_path)
    launcher = load(FIXTURE / 'launcher.json')
    require(launcher['exit_code'] == 0 and launcher['fixture_receipt_sha256'] == sha(fixture_path) and
            launcher['setup_sha256'] == sha(BUNDLE / 'setup_fixture.py') and fixture['private_values_recorded'] is False,
            'Wrong fixture launcher binding')
    ordered = load(FIXTURE / 'ordered_hba_rules.json')
    rules = json.loads(ordered['stdout'])
    require(ordered['exit_code'] == 0 and rules == load(FIXTURE / 'hba_rules.json') and
            all(rule['error'] is None for rule in rules), 'Wrong ordered HBA evidence')
    first_ipv4 = next(rule for rule in rules if rule['type'] == 'host' and rule['address'] in ('127.0.0.1', 'all'))
    require(first_ipv4['auth_method'] == 'scram-sha-256' and fixture['identity']['server_version_num'] == '180006',
            'Wrong SCRAM rule or server version')
    correct = load(FIXTURE / 'unit_auth_correct.json')
    wrong = load(FIXTURE / 'unit_auth_incorrect.json')
    positive, negative = load(FIXTURE / 'suite_auth.json')
    connection = positive['connection']
    require([positive, negative] == fixture['credential_proofs'] and
            positive['outcome'] == 'accepted' and negative['outcome'] == 'password_rejected' and
            (positive['exit_code'], correct['exit_code'], negative['exit_code'], wrong['exit_code']) == (0, 0, 2, 2) and
            correct['private_input_received'] and wrong['private_input_received'] and correct['argv'] == wrong['argv'],
            'Wrong correct/wrong test login proof')
    require(connection == {'role': fixture['test_role']['name'], 'database': fixture['test_role']['database'], 'port': fixture['pg_port'],
                           'postmaster': fixture['identity']['postmaster'], 'client': '127.0.0.1', 'server': '127.0.0.1'},
            'Test login endpoint differs')
    cleanup = load(DEV / 'cleanup_receipt.json')
    inspect, observe = cleanup['commands']
    cid, pid, running, labels, network = map(json.loads, inspect['stdout'].splitlines())
    require(cleanup['status'] == 'clean_verified' and cleanup['read_only'] and cleanup['all_commands_reaped'] and
            inspect['exit_code'] == observe['exit_code'] == 0 and running is True and network == 'host' and
            (cid, pid, labels) == (fixture['container'], fixture['pid'], fixture['labels']), 'Wrong post-test container identity')
    state = json.loads(observe['stdout'])
    require(cleanup['state'] == state and state['postmaster'] == connection['postmaster'] and state['port'] == str(connection['port']) and
            all(state[name] == 0 for name in ('all_tcp_clients', 'other_clients', 'temporary_world_relations', 'lock_schemas')),
            'Post-test fixture was not idle and clean')


def main():
    count = check_manifest(BUNDLE)
    source = verify_source()
    summary = load(DEV / 'verification_summary.json')
    verify_test_runs(summary, source)
    verify_assertion_summary(summary)
    verify_fixture()
    print(f'Verified {count} archived file identities, selected source, test delta and original command receipts.')
    print('Final focused suite: 4 passed. Ordinary suite: 1,202 passed and 7 skipped of 1,209.')
    print('Verified SCRAM fixture receipts and zero clients at the post-test boundary.')


if __name__ == '__main__':
    try:
        main()
    except (KeyError, OSError, StopIteration, ValueError, TypeError) as error:
        sys.exit(f'Allocation evidence verification failed: {error}')
