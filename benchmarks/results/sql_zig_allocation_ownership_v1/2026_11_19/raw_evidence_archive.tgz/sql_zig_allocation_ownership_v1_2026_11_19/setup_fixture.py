#!/usr/bin/env python3
"""Provision the owned plaintext PostgreSQL allocation-test fixture."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import secrets
import socket
import subprocess
import time


WORK = Path(__file__).resolve().parent
PUBLIC = WORK / "fixture" / "setup_01"
PRIVATE = WORK / "private"
REFERENCE = WORK.parent / "sql-d5-throughput-20261119/host_fixture/setup_fixture.py"
IMAGE = "postgres@sha256:e3d24f6906d0760bf4da0dae872415391ededefad23fd471c47dc53b0ddf3c42"
LABEL = "sql-allocation-permitted-20261119"
ADMIN = "fixture_admin"
TEST = "uwz_test"
AUTH_PSQL = """
IFS= read -r PGPASSWORD
export PGPASSWORD
exec psql "$@"
"""
IDENTITY_SQL = """
SELECT json_build_object('role',current_user,'database',current_database(),
 'postmaster',pg_postmaster_start_time(),'data_directory',current_setting('data_directory'),
 'port',current_setting('port'),'listen_addresses',current_setting('listen_addresses'),
 'max_connections',current_setting('max_connections'),'server_version_num',current_setting('server_version_num'),
 'socket_admin',inet_client_addr() IS NULL,
 'tcp_clients',(SELECT count(*) FROM pg_stat_activity WHERE client_addr IS NOT NULL),
 'other_client_backends',(SELECT count(*) FROM pg_stat_activity WHERE backend_type='client backend' AND pid<>pg_backend_pid()));
"""
LOGIN_SQL = """
SELECT json_build_object('role',current_user,'database',current_database(),
 'postmaster',pg_postmaster_start_time(),'client',host(inet_client_addr()),
 'server',host(inet_server_addr()),'port',inet_server_port());
"""


def require(condition, message):
    if not condition:
        raise ValueError(message)


def record(name, value):
    (PUBLIC / name).write_text(json.dumps(value, indent=2) + "\n")


def private_file(name, value):
    descriptor = os.open(PRIVATE / name, os.O_CREAT | os.O_WRONLY | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w") as output:
        output.write(value)
        output.flush()
        os.fsync(output.fileno())
    directory = os.open(PRIVATE, os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def command(label, argv, *, data=None, private_input=False, timeout=20):
    start = time.monotonic_ns()
    stamp = {"argv": argv, "started_monotonic_ns": start, "private_input_received": private_input}
    try:
        result = subprocess.run(argv, input=data, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        stamp.update({"exit_code": "timeout", "finished_monotonic_ns": time.monotonic_ns()})
        record(f"{label}.json", stamp)
        raise RuntimeError(f"{label} timed out") from None
    stamp.update({"exit_code": result.returncode, "finished_monotonic_ns": time.monotonic_ns()})
    if not private_input:
        stamp.update({"stdout": result.stdout, "stderr": result.stderr})
    record(f"{label}.json", stamp)
    return result


def checked(label, argv, **options):
    result = command(label, argv, **options)
    require(result.returncode == 0, f"{label} failed; see setup receipt")
    return result.stdout.strip()


def reference():
    spec = importlib.util.spec_from_file_location("d5_fixture_readonly_reference", REFERENCE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    record("derivation.json", {"reference": str(REFERENCE), "sha256": hashlib.sha256(REFERENCE.read_bytes()).hexdigest(),
                              "reused": ["prove_listener", "HBA_RULES_SQL", "check_hba_rules"],
                              "suite_role_pattern": "D-5 host_fixture/setup_unit_fixture.py"})
    return module


def psql_argv(container, port):
    return ["docker", "exec", "-i", "--user", "postgres", container, "psql", "-qXAt", "-w",
            "-h", "/var/run/postgresql", "-p", str(port), "-U", ADMIN, "-d", "postgres", "-vON_ERROR_STOP=1"]


def sql(label, container, port, statement):
    return checked(label, psql_argv(container, port) + ["-c", statement])


def idle_identity(label, container, port):
    state = json.loads(sql(label, container, port, IDENTITY_SQL))
    require(state["role"] == ADMIN and state["database"] == "postgres" and state["socket_admin"] is True
            and state["port"] == str(port) and state["listen_addresses"] == "127.0.0.1" and state["max_connections"] == "100"
            and state["server_version_num"] == "180006" and state["data_directory"] == "/var/lib/postgresql/18/docker"
            and state["tcp_clients"] == state["other_client_backends"] == 0, "Wrong owned fixture endpoint, version or client inventory")
    return state


def exact_image_labels(container, label_set, image_id):
    fields = "\n".join(("{{json .Id}}", "{{json .Image}}", "{{json .Config.Image}}", "{{json .Config.Labels}}",
                        "{{json .State.Running}}", "{{json .HostConfig.Tmpfs}}"))
    result = checked("image_labels", ["docker", "inspect", "--format", fields, container])
    require(tuple(map(json.loads, result.splitlines())) == (container, image_id, IMAGE, label_set, True, {"/var/lib/postgresql": ""}),
            "Owned database Docker image, labels or tmpfs changed")


def verify_login(container, port, password, intended, postmaster):
    label = "unit_auth_correct" if intended else "unit_auth_incorrect"
    argv = ["docker", "exec", "-i", "--user", "postgres", container, "sh", "-ec", AUTH_PSQL, "sh",
            "-qXAt", "-w", "-h", "127.0.0.1", "-p", str(port), "-U", TEST, "-d", TEST, "-vON_ERROR_STOP=1", "-c", LOGIN_SQL]
    result = command(label, argv, data=password + "\n", private_input=True, timeout=10)
    if intended:
        require(result.returncode == 0 and not result.stderr, "Correct suite credential failed")
        visible = json.loads(result.stdout)
        require(visible == {"role": TEST, "database": TEST, "postmaster": postmaster, "client": "127.0.0.1",
                            "server": "127.0.0.1", "port": port}, "Suite plaintext login reached another endpoint")
        return {"outcome": "accepted", "exit_code": result.returncode, "connection": visible}
    require(result.returncode == 2 and not result.stdout and "password authentication failed" in result.stderr,
            "Incorrect suite credential did not produce a password rejection")
    return {"outcome": "password_rejected", "exit_code": result.returncode}


def launch(label_set, image_id, pg_args):
    command_line = ["docker", "run", "--detach", "--pull=never", "--network", "host",
                    *(entry for key, value in label_set.items() for entry in ("--label", f"{key}={value}")),
                    "--env-file", str(PRIVATE / "postgres.env"), "--tmpfs", "/var/lib/postgresql", IMAGE, *pg_args]
    try:
        container = checked("create", command_line, timeout=45)
    except (RuntimeError, ValueError):
        # A daemon-side create may complete after the client fails. Record only an exact ownership match.
        filters = [entry for key, value in label_set.items() for entry in ("--filter", f"label={key}={value}")]
        candidates = checked("lookup_after_failed_create", ["docker", "ps", "--all", "--quiet", "--no-trunc", *filters]).splitlines()
        if len(candidates) == 1 and re.fullmatch(r"[0-9a-f]{64}", candidates[0]):
            private_file("container.id", candidates[0] + "\n")
            record("recovered_container.json", {"container": candidates[0], "labels": label_set, "image_id": image_id})
        raise
    require(re.fullmatch(r"[0-9a-f]{64}", container), "Docker did not provide a full immutable container ID")
    private_file("container.id", container + "\n")
    return container


def main():
    require(not PRIVATE.exists() and not PRIVATE.is_symlink() and not PUBLIC.exists(), "Fixture setup already has outputs")
    PUBLIC.mkdir()
    builder = reference()
    image_id = checked("cached_image", ["docker", "image", "inspect", "--format", "{{.Id}}", IMAGE])
    require(re.fullmatch(r"sha256:[0-9a-f]{64}", image_id), "Pinned local PostgreSQL image is unavailable")
    with socket.socket() as temporary:
        temporary.bind(("127.0.0.1", 0))
        port = temporary.getsockname()[1]
    PRIVATE.mkdir(mode=0o700)
    nonce = secrets.token_hex(16)
    admin_password, suite_password, wrong_password = (secrets.token_hex(24) for _ in range(3))
    require(len({admin_password, suite_password, wrong_password}) == 3, "Private fixture secrets collided")
    private_file("owner_token", nonce + "\n")
    private_file("pg_port", str(port) + "\n")
    private_file("postgres.env", f"POSTGRES_USER={ADMIN}\nPOSTGRES_DB=postgres\nPOSTGRES_PASSWORD={admin_password}\n"
                 "POSTGRES_INITDB_ARGS=--auth-local=trust --auth-host=scram-sha-256\n")
    labels = {"uwz.sql-experiment": LABEL, "uwz.role": "database", "uwz.run-token": nonce}
    pg_args = ["-c", "max_connections=100", "-c", "listen_addresses=127.0.0.1", "-c", f"port={port}"]
    prepared = {"image": IMAGE, "image_id": image_id, "labels": labels, "pg_port": port, "pg_args": pg_args}
    record("prepared.json", prepared)
    container = launch(labels, image_id, pg_args)
    exact_image_labels(container, labels, image_id)
    ready = ["docker", "exec", container, "pg_isready", "-h", "127.0.0.1", "-p", str(port), "-U", ADMIN, "-d", "postgres"]
    for index in range(45):
        if command(f"ready_{index:02}", ready, timeout=5).returncode == 0:
            break
        time.sleep(.4)
    else:
        raise RuntimeError("Owned PostgreSQL loopback listener did not become ready")
    listener = builder.prove_listener(container, port, pg_args)
    record("listener.json", listener)
    before = idle_identity("initial_identity", container, port)
    rules = json.loads(sql("ordered_hba_rules", container, port, builder.HBA_RULES_SQL))
    builder.check_hba_rules(rules, "scram-sha-256")
    record("hba_rules.json", rules)
    roles = json.loads(sql("initial_role_database", container, port,
        "SELECT json_build_array(EXISTS(SELECT 1 FROM pg_roles WHERE rolname='uwz_test'),"
        "EXISTS(SELECT 1 FROM pg_database WHERE datname='uwz_test'));"))
    require(roles == [False, False], "Expected a fresh role and database")
    checked("create_test_role_database", psql_argv(container, port),
            data="CREATE ROLE uwz_test LOGIN;\nCREATE DATABASE uwz_test OWNER uwz_test;\n")
    checked("set_test_role_password", psql_argv(container, port) + ["-c", "\\password uwz_test"],
            data=f"{suite_password}\n{suite_password}\n", private_input=True)
    role = json.loads(sql("test_role_database", container, port, """
SELECT json_build_object('name',r.rolname,'can_login',r.rolcanlogin,'superuser',r.rolsuper,
 'database',d.datname,'owner',pg_get_userbyid(d.datdba),'scram',r.rolpassword LIKE 'SCRAM-SHA-256$%')
FROM pg_authid r JOIN pg_database d ON d.datdba=r.oid WHERE r.rolname='uwz_test' AND d.datname='uwz_test';
"""))
    require(role == {"name": TEST, "can_login": True, "superuser": False, "database": TEST, "owner": TEST, "scram": True},
            "Wrong suite role, owned database or SCRAM verifier")
    proofs = [verify_login(container, port, suite_password, True, before["postmaster"]),
              verify_login(container, port, wrong_password, False, before["postmaster"])]
    record("suite_auth.json", proofs)
    after = idle_identity("ready_identity", container, port)
    require(after == before, "Owned cluster changed during test setup")
    private_file("unit.env", f"UWZ_SQL_TEST_PASSWORD={suite_password}\nUWZ_SQL_TEST_PORT={port}\n")
    record("fixture.json", prepared | {"container": container, "pid": listener["pid"], "cgroup": listener["cgroup"],
           "listener_inode": listener["inode"], "identity": after, "credential_proofs": proofs,
           "test_role": role, "unit_env_path": str(PRIVATE / "unit.env"), "private_values_recorded": False,
           "created_utc": datetime.now(timezone.utc).isoformat()})
    print(f"Owned PostgreSQL 18.6 fixture ready at 127.0.0.1:{port}; uwz_test login and database verified.")


if __name__ == "__main__":
    main()
