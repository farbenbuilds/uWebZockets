import json,pathlib,subprocess,time
base=pathlib.Path('.zig-cache/sql-allocation-permitted-20261119')
fixture=json.loads((base/'fixture/setup_01/fixture.json').read_text())
work=base/'developer'
commands=[]
def command(argv,sql=None):
 start=time.time(); result=subprocess.run(argv,input=sql,capture_output=True,text=True,timeout=20)
 commands.append({'argv':argv,'sql':sql,'started_unix':start,'finished_unix':time.time(),'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
 assert result.returncode==0,result.stderr
 return result.stdout.strip()
report={'read_only':True,'new_test_data':'backend-local TEMP World only; dropped by owned backend close'}
try:
 cid=fixture['container']
 assert cid=='f129e4fe2ad747700d7ba79da8cffab9268e7ec9d3eab1104f95f0b45d0c3032'
 output=command(['docker','inspect','--format','{{json .Id}}\n{{json .State.Pid}}\n{{json .State.Running}}\n{{json .Config.Labels}}\n{{json .HostConfig.NetworkMode}}',cid])
 identifier,pid,running,labels,network=[json.loads(line) for line in output.splitlines()]
 assert identifier==cid and pid==fixture['pid'] and running and labels==fixture['labels'] and network=='host'
 assert pathlib.Path('/proc',str(pid),'cgroup').read_text()==fixture['cgroup']
 listeners=[]
 for line in pathlib.Path('/proc',str(pid),'net/tcp').read_text().splitlines()[1:]:
  fields=line.split()
  if fields[3]=='0A' and fields[1]=='0100007F:8585': listeners.append(fields[9])
 assert listeners==[fixture['listener_inode']],listeners
 report['identity']={'cid':cid,'pid':pid,'labels':labels,'cgroup_matches':True,'loopback_listener_inode':listeners[0],'port':34181}
 argv=['docker','exec','-i',cid,'psql','-qXAt','-w','-h','/var/run/postgresql','-p','34181','-U','fixture_admin','-d','uwz_test','-vON_ERROR_STOP=1']
 sql="""SELECT json_build_object('role',current_user,'database',current_database(),'port',current_setting('port'),'postmaster',pg_postmaster_start_time(),'data_directory',current_setting('data_directory'),'all_tcp_clients',(SELECT count(*) FROM pg_stat_activity WHERE client_addr IS NOT NULL),'other_clients',(SELECT count(*) FROM pg_stat_activity WHERE backend_type='client backend' AND pid<>pg_backend_pid()),'temporary_world_relations',(SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname LIKE 'pg_temp_%' AND c.relname='world'),'lock_schemas',(SELECT count(*) FROM pg_namespace WHERE nspname LIKE 'uwz_update_lock_%'));"""
 state=json.loads(command(argv,sql))
 assert state['role']=='fixture_admin' and state['database']=='uwz_test' and state['port']=='34181'
 assert state['postmaster']==fixture['identity']['postmaster'] and state['data_directory']==fixture['identity']['data_directory']
 assert state['all_tcp_clients']==state['other_clients']==state['temporary_world_relations']==state['lock_schemas']==0,state
 report['state']=state
 report['status']='clean_verified'
 report['all_commands_reaped']=True
finally:
 report['commands']=commands
 (work/'cleanup_receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ('status','state','all_commands_reaped')}))
