"""Bounded ELF comparison reused from the reviewed ticket delivery proof."""
import hashlib
import json
import struct


def digest(data):
    return hashlib.sha256(data).hexdigest()


def bounded(data, offset, size):
    if offset < 0 or size < 0 or offset + size > len(data):
        raise ValueError('ELF region exceeds file bounds')
    return data[offset:offset + size]


def elf_snapshot(data):
    header = struct.unpack('<16sHHIQQQIHHHHHH', bounded(data, 0, 64))
    ident, kind, machine, version, entry, phoff, shoff, flags = header[:8]
    ehsize, phsize, phnum, shsize, shnum, shstrings = header[8:]
    if ident[:7] != b'\x7fELF\x02\x01\x01' or machine != 62:
        raise ValueError('Only the retained little-endian ELF64 x86-64 inventory is supported')
    if ehsize != 64 or phsize != 56 or shsize != 64 or not 0 < phnum < 128:
        raise ValueError('Unexpected native ELF header layout')
    if not 0 < shnum < 65535 or not 0 <= shstrings < shnum:
        raise ValueError('Extended or absent ELF section tables are not supported')
    sections = [struct.unpack('<IIQQQQIIQQ', bounded(data, shoff + i * shsize, shsize))
                for i in range(shnum)]
    strings_section = sections[shstrings]
    strings = bounded(data, strings_section[4], strings_section[5])

    def section_name(index):
        offset = sections[index][0]
        if not 0 <= offset < len(strings):
            raise ValueError('Invalid section-name offset')
        end = strings.find(b'\0', offset)
        if end < 0:
            raise ValueError('Unterminated section name')
        return strings[offset:end].decode('ascii')

    allocated = []
    debug_names = []
    regular_symbol_table_present = False
    for index, section in enumerate(sections):
        _, section_type, section_flags, address, offset, size, link, info, align, entsize = section
        name = section_name(index)
        if section_type == 2 and size > 0:
            regular_symbol_table_present = True
        if name.startswith(('.debug', '.zdebug')):
            debug_names.append(name)
        if not section_flags & 2:
            continue
        payload = b'' if section_type == 8 else bounded(data, offset, size)
        allocated.append({
            'name': name, 'type': section_type, 'flags': section_flags,
            'address': address, 'size': size, 'alignment': align, 'entry_size': entsize,
            'link': section_name(link) if link else None,
            'info': section_name(info) if section_type in (4, 9) and info else info,
            'payload_sha256': digest(payload),
        })
    programs = []
    loads = []
    for index in range(phnum):
        program = struct.unpack('<IIQQQQQQ', bounded(data, phoff + index * phsize, phsize))
        programs.append(list(program))
        if program[0] != 1:
            continue
        offset, file_size = program[2], program[5]
        payload = bytearray(bounded(data, offset, file_size))
        # ELF section-table coordinates change; all other mapped bytes must match.
        for start, end in ((40, 48), (60, 64)):
            lower, upper = max(start, offset), min(end, offset + file_size)
            if lower < upper:
                payload[lower - offset:upper - offset] = b'\0' * (upper - lower)
        loads.append({'index': index, 'normalized_payload_sha256': digest(payload)})
    return {
        'header_identity': [ident.hex(), kind, machine, version, entry, phoff,
                            flags, ehsize, phsize, phnum, shsize],
        'section_table_metadata': {'offset': shoff, 'count': shnum, 'strings_index': shstrings},
        'program_headers': programs, 'allocated_sections': allocated,
        'normalized_load_segments': loads, 'debug_sections': debug_names,
        'regular_symbol_table_present': regular_symbol_table_present,
    }


def compare_elf(before, after):
    original, delivered = elf_snapshot(before), elf_snapshot(after)
    for key in ('header_identity', 'program_headers', 'allocated_sections',
                'normalized_load_segments'):
        if original[key] != delivered[key]:
            raise ValueError('Strip-debug changed executable property: ' + key)
    if not original['regular_symbol_table_present'] or not delivered['regular_symbol_table_present']:
        raise ValueError('Regular symbol table must remain present')
    if not original['debug_sections'] or delivered['debug_sections']:
        raise ValueError('Expected original DWARF and its complete delivery removal')
    return {
        'entrypoint_abi_unchanged': True, 'program_headers_unchanged': True,
        'allocated_sections_unchanged': True,
        'regular_symbol_table_retained': True,
        'normalized_load_segments_unchanged': True,
        'normalized_load_exclusions': [
            {'file_offset': 40, 'bytes': 8, 'field': 'e_shoff'},
            {'file_offset': 60, 'bytes': 2, 'field': 'e_shnum'},
            {'file_offset': 62, 'bytes': 2, 'field': 'e_shstrndx'},
        ],
        'allocated_section_count': len(original['allocated_sections']),
        'load_segment_count': len(original['normalized_load_segments']),
        'removed_debug_sections': original['debug_sections'],
        'before_section_table': original['section_table_metadata'],
        'after_section_table': delivered['section_table_metadata'],
        'runtime_snapshot_sha256': digest(json.dumps({
            key: original[key] for key in ('header_identity', 'program_headers',
                                           'allocated_sections', 'normalized_load_segments')
        }, sort_keys=True).encode()),
    }
