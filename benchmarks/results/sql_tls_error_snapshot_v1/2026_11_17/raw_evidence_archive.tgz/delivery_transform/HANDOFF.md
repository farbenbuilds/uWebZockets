# Error-snapshot delivery transformation

The frozen native/direct/SSL and wire producers were copied from their explicit
allowlists, then only staged selected executables had nonallocated debug sections
removed. No compiler, optimizer, relinker or native source modification was used.
The operation covered 28 Debug ELF64 x86-64 programs, reducing executable bytes
from 443,019,392 to 122,127,264.

| Subtree | Programs | Original executable bytes | Delivered executable bytes |
|---|---:|---:|---:|
| native | 21 | 311,222,968 | 85,225,312 |
| wire | 7 | 131,796,424 | 36,901,952 |

`manifest.json` records every original measured identity, actual delivered
identity, byte count, command, exit status, mode and bounded ELF comparison.
`freeze_config.json` binds both exact original inventories and current identity
maps. Original producer manifests and identity maps are archived unchanged as
`original_native_files.sha256`, `original_native_prebuilt_identity.json`,
`original_wire_payload_manifest.json` and
`original_wire_prebuilt_identity.json`.

Current native identity metadata changes only its 21 selected binary hashes.
Its optimization and both native archive maps remain identical. Current wire
identity changes only its seven selected binary hashes and its explicit
`delivery_stripping` flag from false to true. Its optimization field describes
the original measured Debug build. No delivery-size or indirection fields were
added to either current identity map. Only hash values were refreshed in each
current subtree manifest; all other JSON manifest metadata remains unchanged.

The wire files `original_measured_identity.json`, `baseline_frozen.json` and raw
result identities are historical original Debug measurements and remain
byte-identical. Current prebuilt replay validates `prebuilt_identity.json` and
`payload_manifest.json`; it does not compare a historical Debug binary hash to
the stripped delivery copy. Native raw measurements likewise remain unchanged.

The existing tool was `/usr/bin/objcopy --strip-debug`, SHA-256
`05f4473d24f7330a9b13f43d007d619a2e792e33de453cd7533a2d97c30da770`.
The complete version output is recorded in the transformation manifest. No tool
was installed, and this evidence-packaging operation adds no native build or
prebuilt-replay dependency. Prior retained evidence established that pinned
Zig 0.16.0 ELF-to-ELF objcopy is unimplemented; no additional probe was run.

For every executable, the entrypoint/ABI identity, program-header tuples,
allocated-section metadata and payloads are unchanged. Every PT_LOAD byte is
unchanged after normalizing only `e_shoff` at offset 40 for 8 bytes, `e_shnum`
at offset 60 for 2 bytes and `e_shstrndx` at offset 62 for 2 bytes. Regular symbol
tables and executable permissions remain present and unchanged. Original debug
sections are absent from delivery copies; complete-file hashes differ.

Independent static rechecking passed for both complete original payloads,
1,512 selected files, 1,480 untouched staged entries and all 28 runtime ELF,
regular-symbol-table and permission proofs. This includes all selected native
sources, fixture assertions, raw results, replay wrappers, historical identities
and archive provenance. Original producer files remain unchanged under:

- `.zig-cache/sql-tls-error-snapshot-fixed-20261117`: 1,210 selected files and
  1,209 hash entries, 21 programs.
- `.zig-cache/sql-tls-error-allocation-witness-20261117`: 302 selected files and
  301 hash entries, seven programs.

`verify_delivery.py` can recheck these original producers against this staged
layout. It intentionally needs the immutable original producer roots for the
before/after comparison. The prebuilt native and wire replays need neither
original producer sources nor native archives. Run the static verification with:

```sh
env PYTHONDONTWRITEBYTECODE=1 python3 delivery_transform/verify_delivery.py
```

Root still owns both complete final copied-layout functional replays, using
`native/replay_prebuilt.py` and `wire/replay_prebuilt.py` with the exact offline
PKI tool and absent output directories outside the combined evidence root.
Root also adds the combined-root bootstrap marker and its checks/reviews, then
verifies the final archive. The temporary `tools/wt-tools` helper must be omitted
from that archive. This packaging step ran no dedicated smoke, security,
sanitizer, fuzz or scan campaign and makes no PostgreSQL allocation-gate claim.
