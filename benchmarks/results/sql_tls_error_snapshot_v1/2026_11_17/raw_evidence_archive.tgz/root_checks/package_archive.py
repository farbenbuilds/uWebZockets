from pathlib import Path, PurePosixPath
import argparse
import gzip
import hashlib
import io
import json
import os
import tarfile


def sha(payload):
    return hashlib.sha256(payload).hexdigest()


parser = argparse.ArgumentParser(description='Package and verify the retained regular-file evidence.')
parser.add_argument('destination', type=Path)
args = parser.parse_args()
base = Path(__file__).resolve().parents[1]
destination = args.destination.resolve(strict=True)
assert {p.name for p in destination.iterdir()} <= {'README.md', 'manifest.sha256', 'raw_evidence_archive.tgz'}
assert (destination / 'README.md').is_file()
paths = []
for path in sorted(base.rglob('*')):
    assert not path.is_symlink(), path
    if path.is_dir():
        continue
    assert path.is_file(), path
    name = path.relative_to(base).as_posix()
    if name == 'tools/wt-tools':
        assert sha(path.read_bytes()) == '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9'
        continue
    if name == 'files.sha256':
        continue
    relative = PurePosixPath(name)
    assert not relative.is_absolute() and '..' not in relative.parts and '\n' not in name
    assert relative.parts[0] != 'tools'
    assert not any(part in {'.zig-cache', 'zig-cache', '__pycache__', 'private_pki'} for part in relative.parts)
    assert path.suffix not in {'.a', '.o', '.pem', '.key', '.crt', '.der'}
    paths.append(path)
records = {p.relative_to(base).as_posix(): sha(p.read_bytes()) for p in paths}
(base / 'files.sha256').write_text(''.join(checksum + '  ' + name + '\n' for name, checksum in records.items()))
checksums = records | {'files.sha256': sha((base / 'files.sha256').read_bytes())}
paths.append(base / 'files.sha256')
temporary = destination / 'raw_evidence_archive.tgz.tmp'
assert not temporary.exists() and not temporary.is_symlink()
with temporary.open('xb') as raw:
    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for path in paths:
                payload = path.read_bytes()
                member = tarfile.TarInfo(path.relative_to(base).as_posix())
                member.size = len(payload)
                member.mode = path.stat().st_mode & 0o777
                member.mtime = 0
                archive.addfile(member, io.BytesIO(payload))
assert temporary.stat().st_size < 100 * 1024 * 1024
with tarfile.open(temporary, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(paths)
    assert len({member.name for member in members}) == len(members)
    assert {member.name for member in members} == set(records) | {'files.sha256'}
    for member in members:
        assert member.isfile()
        relative = PurePosixPath(member.name)
        assert not relative.is_absolute() and '..' not in relative.parts
        with archive.extractfile(member) as stream:
            payload = stream.read()
        assert sha(payload) == checksums[member.name], member.name
target = destination / 'raw_evidence_archive.tgz'
os.replace(temporary, target)
digest = sha(target.read_bytes())
(destination / 'manifest.sha256').write_text(digest + '  raw_evidence_archive.tgz\n')
assert {p.name for p in destination.iterdir()} == {'README.md', 'manifest.sha256', 'raw_evidence_archive.tgz'}
print(json.dumps({'archive_sha256': digest, 'archive_bytes': target.stat().st_size,
                  'payload_files': len(records), 'archive_regular_members': len(paths),
                  'all_compressed_member_hashes_verified': True}, indent=2))
