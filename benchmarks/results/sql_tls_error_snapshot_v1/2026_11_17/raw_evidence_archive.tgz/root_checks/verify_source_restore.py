from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('native', type=Path)
parser.add_argument('work', type=Path)
args = parser.parse_args()
native = args.native.resolve(strict=True)
work = args.work.absolute()
assert not work.exists() and not work.is_symlink()
work.mkdir()
checks = Path(__file__).resolve().parent
helper = native / 'restore_source.py'
expected = json.loads((native / 'candidate_source_inventory.json').read_text())['entries']
sources = {
    'baseline': Path('/tmp/uwz-wt-child-callbacks-20261116/zig-pkg/N-V-__8AAA5Ieg5843crc8uXWdNhmmfStwJqA-9TknJSx3_n'),
    'ticket-discard': Path('/home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-ticket-discard-fixed-20261117/boringssl'),
}
records = []

def run(source, target, kind, name, status):
    command = [sys.executable, str(helper), '--source-kind', kind, str(source), str(target)]
    result = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (checks / (name + '.stdout')).write_text(result.stdout)
    (checks / (name + '.stderr')).write_text(result.stderr)
    records.append({'name': name, 'command': command, 'exit_code': result.returncode, 'expected_exit_code': status})
    assert result.returncode == status, (name, result.stderr)
    return result

def verify(target):
    names = {p.relative_to(target).as_posix() for p in target.rglob('*') if p.is_file() or p.is_symlink()}
    assert names == {entry['path'] for entry in expected}
    for entry in expected:
        path = target / entry['path']
        mode = path.lstat().st_mode
        assert stat.S_IMODE(mode) == entry['mode'], entry['path']
        if entry['kind'] == 'symlink':
            assert stat.S_ISLNK(mode) and os.readlink(path) == entry['target'], entry['path']
        else:
            assert stat.S_ISREG(mode) and hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256'], entry['path']

for kind, source in sources.items():
    target = work / kind
    run(source, target, kind, 'restore-' + kind, 0)
    verify(target)
    run(source, target, kind, 'restore-' + kind + '-existing', 1)

wrong_kind = work / 'wrong-source-kind'
run(sources['ticket-discard'], wrong_kind, 'baseline', 'restore-wrong-source-kind', 1)
assert not wrong_kind.exists() and not wrong_kind.is_symlink()
bad_input = work / 'changed-input-mode'
shutil.copytree(sources['ticket-discard'], bad_input, symlinks=True)
entry = next(e for e in expected if e['kind'] == 'file')
changed = bad_input / entry['path']
changed.chmod(stat.S_IMODE(changed.lstat().st_mode) ^ stat.S_IXUSR)
bad_target = work / 'wrong-file-mode-output'
result = run(bad_input, bad_target, 'ticket-discard', 'restore-wrong-file-mode', 1)
assert 'mode' in result.stderr.lower()
assert not bad_target.exists() and not bad_target.is_symlink()
report = {'complete': True, 'each_mode_verified_entries': len(expected), 'types_modes_links_hashes_exact': True,
          'existing_destination_refusals': 2, 'wrong_source_kind_refused_before_write': True,
          'wrong_filesystem_mode_refused_before_write': True, 'commands': records}
report['verified_input_sha256'] = {name: hashlib.sha256((native / name).read_bytes()).hexdigest()
                                  for name in ('restore_source.py', 'candidate_source_inventory.json',
                                               'baseline_inventory.json', 'original_source_inventory.json', 'provenance.json')}
(checks / 'source_restore_results.json').write_text(json.dumps(report, indent=2) + '\n')
print('PASS: both source modes restore every entry including mode/type/link/hash; four refusals pass')
