from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('stage', type=Path)
parser.add_argument('repository', type=Path)
args = parser.parse_args()
stage = args.stage.resolve(strict=True)
repository = args.repository.resolve(strict=True)
checks = Path(__file__).resolve().parent
restored = json.loads((checks / 'source_restore_results.json').read_text())
for name, checksum in restored['verified_input_sha256'].items():
    assert hashlib.sha256((stage / 'native' / name).read_bytes()).hexdigest() == checksum, name
inputs = json.loads((checks / 'production_input_sha256.json').read_text())
for name, checksum in inputs.items():
    assert hashlib.sha256((repository / name).read_bytes()).hexdigest() == checksum, name
messages = {
    'native': {'combined_inside': 'Keep replay output outside the retained evidence tree',
               'existing': 'Choose an absent replay output directory'},
    'wire': {'combined_inside': 'Keep output outside retained evidence',
             'existing': 'Choose an absent output directory'},
}
environment = os.environ.copy()
environment['PYTHONDONTWRITEBYTECODE'] = '1'
records = []
for kind in ('native', 'wire'):
    existing = repository / ('.zig-cache/sql-tls-error-snapshot-' + kind + '-final-replay-20261117')
    for guard, target in [('combined_inside', stage / ('guard-' + kind)), ('existing', existing)]:
        command = [sys.executable, str(stage / kind / 'replay_prebuilt.py'), '--pki-tool',
                   str(stage / 'tools/wt-tools'), '--output', str(target)]
        result = subprocess.run(command, env=environment, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        (checks / (kind + '_' + guard + '.stdout')).write_text(result.stdout)
        (checks / (kind + '_' + guard + '.stderr')).write_text(result.stderr)
        assert result.returncode == 1 and messages[kind][guard] in result.stderr, (kind, guard, result.stderr)
        if guard == 'combined_inside':
            assert not target.exists() and not target.is_symlink()
        records.append({'command': command, 'guard': guard, 'exit_code': result.returncode,
                        'expected_exit_code': 1, 'exact_refusal': messages[kind][guard]})
(checks / 'delivery_guard_results.json').write_text(json.dumps({'complete': True, 'guards': records,
    'production_inputs_unchanged': len(inputs), 'restore_inputs_unchanged': len(restored['verified_input_sha256'])}, indent=2) + '\n')
print('PASS: four combined/existing-output refusals and unchanged production/restore inputs')
