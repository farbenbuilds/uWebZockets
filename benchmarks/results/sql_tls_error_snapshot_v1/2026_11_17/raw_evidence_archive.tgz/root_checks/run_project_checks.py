import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
zig=Path('/tmp/zig-x86_64-linux-0.16.0/zig')
assert hashlib.sha256(zig.read_bytes()).hexdigest()=='2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c'
commands=[('format',[str(zig),'fmt','src','builds','examples','tests','fuzz']),('conventions',['sh','scripts/check_conventions.sh']),('release_version',['sh','scripts/check_release_version.sh']),('documentation',['sh','scripts/check_docs.sh'])]
results=[]
for name,cmd in commands:
 start=time.time()
 p=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (out/(name+'.log')).write_text(p.stdout)
 results.append({'name':name,'command':cmd,'exit_code':p.returncode,'seconds':time.time()-start})
 print(name,p.returncode,flush=True)
 if p.returncode: print(p.stdout,flush=True);break
(out/'project_checks.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(row['exit_code'] for row in results))
