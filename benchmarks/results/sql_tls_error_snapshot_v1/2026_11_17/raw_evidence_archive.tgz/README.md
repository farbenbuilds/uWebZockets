# TLS error snapshot candidate evidence

This is an isolated native proposal, not production adoption or a release.
`native/` contains the six-file increment, fourteen-file cumulative proposal,
8709-entry source inventories, restoration tools, Zig-only build identities,
ownership/lifecycle/fault fixtures and inherited controls. `wire/` contains the
frozen five-fault and inherited protocol/control measurements. Both handoffs
identify original measured binaries separately from delivered copies.

`delivery_transform/` records the selected executable transformation, original
identities/manifests, normalized ELF load-image comparisons and unchanged-file
proofs. Only staged copies have debug sections removed. Raw measurement logs,
source and historical identity maps are unchanged. `root_checks/` records fresh
production unit/project checks, independent source restoration and final
delivered-program replays; `reviews/` contains independent review reports.

Verify every retained payload hash from this extracted directory:

```sh
sha256sum -c files.sha256
```

The external `wt-tools` PKI helper is deliberately excluded from this archive.
`external_inputs.json` records its exact hash and the earlier retained archive
member containing it. After obtaining that verified tool, replay into absent
directories outside this extracted evidence tree:

```sh
python3 native/replay_prebuilt.py --pki-tool /absolute/path/wt-tools --output /absolute/path/new-native-results
python3 wire/replay_prebuilt.py --pki-tool /absolute/path/wt-tools --output /absolute/path/new-wire-results
```

Alternatively, `python3 restore_pki_tool.py /absolute/path/repository` restores
that exact helper into tools/wt-tools from the already retained repository
artifact, without a network request or compiler.

These selected host Debug programs need no compiler, native source or native
archives for replay. Ephemeral PKI is created outside the evidence and removed
on completion. The native source restoration helper separately accepts exact
original BoringSSL d3bf4795ad5b79d646cddf2fec687da5b9b502db source, or the exact
preceding ticket-discard candidate with `--source-kind ticket-discard`.
Inventories bind file sets, types, modes, symlink targets and file hashes.

Metadata-only fatal calls are allocation-free within the measured scope.
Peer-alert text and the complete fatal gate intentionally remain RED. Generic
long diagnostic data remains supported with heap copying. Query teardown,
cancellation/reconnect work, publication, production adoption and the complete
PostgreSQL request-path allocation proof remain open. Dedicated smoke/security/
sanitizer/fuzz/scan campaigns remain user-deferred.
