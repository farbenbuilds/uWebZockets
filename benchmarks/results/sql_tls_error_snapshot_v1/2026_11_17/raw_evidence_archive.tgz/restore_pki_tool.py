#!/usr/bin/env python3
"""Restore the pinned fixture PKI executable from an existing offline artifact."""
import argparse
import hashlib
from pathlib import Path
import tarfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repository_root', type=Path)
    arguments = parser.parse_args()
    archive = arguments.repository_root / 'benchmarks/results/webtransport_independent_client_v1/2026_11_17/raw_evidence_archive.tgz'
    digest = '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9'
    if hashlib.sha256(archive.read_bytes()).hexdigest() != '11fe77a53dc966f924f3dc76f2b9ecbafedadfa7c4dd75b18edb7f40d491eb44':
        raise ValueError('The retained PKI artifact checksum differs')
    with tarfile.open(archive, 'r:gz') as source:
        member = source.getmember('client/wt-tools')
        if not member.isfile() or member.size != 5252542:
            raise ValueError('Unexpected PKI executable archive member')
        with source.extractfile(member) as stream:
            payload = stream.read(member.size + 1)
    if len(payload) != 5252542 or hashlib.sha256(payload).hexdigest() != digest:
        raise ValueError('The PKI executable checksum differs')
    directory = Path(__file__).resolve().parent / 'tools'
    if directory.is_symlink():
        raise ValueError('The tool directory must not be a symlink')
    directory.mkdir(exist_ok=True)
    target = directory / 'wt-tools'
    if target.exists() or target.is_symlink():
        if target.is_symlink() or not target.is_file():
            raise ValueError('Unexpected existing PKI destination')
        if hashlib.sha256(target.read_bytes()).hexdigest() != digest:
            raise ValueError('Refusing to overwrite an existing tool')
        if target.stat().st_mode & 0o111 == 0:
            raise ValueError('Existing PKI tool is not executable')
        return
    with target.open('xb') as output:
        output.write(payload)
    target.chmod(0o755)
    print('Restored verified PKI executable')


if __name__ == '__main__':
    main()
