#include <openssl/err.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "crypto/err/internal.h"
#include "ticket_fault.h"

#define REQUIRE(value) do { if (!(value)) { fprintf(stderr, "FAIL line%d: %s\n", __LINE__, #value); abort(); } } while (0)

#if ERROR_RESERVED_API
using Snapshot = bssl::UniquePtr<bssl::ERR_RESERVED_STATE>;
#else
using Snapshot = bssl::UniquePtr<bssl::ERR_SAVE_STATE>;
#endif

static void create(Snapshot *out) {
#if ERROR_RESERVED_API
  out->reset(bssl::ERR_RESERVED_STATE_new());
  REQUIRE(out->get() != nullptr);
#else
  (void)out;
#endif
}

static void capture(Snapshot *out) {
#if ERROR_RESERVED_API
  bssl::ERR_save_reserved_state(out->get());
#else
  out->reset(bssl::ERR_save_state());
#endif
}

static void restore(const Snapshot &saved) {
#if ERROR_RESERVED_API
  bssl::ERR_restore_reserved_state(saved.get());
#else
  bssl::ERR_restore_state(saved.get());
#endif
}

static void push_data(unsigned reason) {
  char data[6001];
  memset(data, 'd', sizeof(data) - 1);
  data[sizeof(data) - 1] = 0;
  ERR_put_error(ERR_LIB_SSL, 0, static_cast<int>(reason), "synthetic_error_oom.cc", 71);
  ERR_set_error_data(data, ERR_FLAG_STRING);
}

static void require_omitted_data(unsigned reason) {
  const char *file = nullptr;
  const char *data = nullptr;
  int line = 0;
  int flags = -1;
  REQUIRE(ERR_get_error_line_data(&file, &line, &data, &flags) == ERR_PACK(ERR_LIB_SSL, reason));
  REQUIRE(strcmp(file, "synthetic_error_oom.cc") == 0 && line == 71);
  REQUIRE(strcmp(data, "") == 0 && flags == 0);
  REQUIRE(ERR_get_error() == 0);
}

static void copy_oom(bool restoration) {
  ERR_clear_error();
  Snapshot saved;
  create(&saved);
  push_data(1801);
  if (restoration) {
    capture(&saved);
    ERR_clear_error();
  }
  ticket_fault_reset();
  const size_t fail_ordinal = restoration || ERROR_RESERVED_API ? 1 : 3;
  ticket_fault_arm_ordinal(fail_ordinal);
  if (restoration) restore(saved); else capture(&saved);
  ticket_fault_disarm();
  REQUIRE(ticket_fault_read().injected == 1);
  if (!restoration) {
    ERR_clear_error();
    restore(saved);
  }
  require_omitted_data(1801);
  saved.reset();
  const TicketFaultStats stats = ticket_fault_read();
  REQUIRE(stats.live == 0 && stats.successful == stats.actual_frees);
  REQUIRE(stats.attempts == fail_ordinal && stats.calloc_calls == 0 && stats.realloc_calls == 0);
  REQUIRE(stats.cleanse_failures == 0);
  printf("PASS %s_copy_oom: attempts=%llu successful=%llu freed=%llu; metadata preserved, omitted data matches generic semantics\n",
         restoration ? "restore" : "capture",
         static_cast<unsigned long long>(stats.attempts),
         static_cast<unsigned long long>(stats.successful),
         static_cast<unsigned long long>(stats.actual_frees));
  ERR_clear_error();
}

static void shrinking_owns_no_trailing_data() {
  ERR_clear_error();
  Snapshot saved;
  create(&saved);
  for (unsigned i = 0; i < 15; i++) push_data(1901 + i);
  ticket_fault_reset();
  ticket_fault_arm_ordinal(0);
  capture(&saved);
  ticket_fault_disarm();
  REQUIRE(ticket_fault_read().successful == (ERROR_RESERVED_API ? 15 : 17));
  ERR_clear_error();
  ERR_put_error(ERR_LIB_SSL, 0, 1951, "synthetic_error_oom.cc", 71);
  ticket_fault_arm_ordinal(0);
  capture(&saved);
  ticket_fault_disarm();
  REQUIRE(ticket_fault_read().live == (ERROR_RESERVED_API ? 0 : 2));
  ERR_clear_error();
  ticket_fault_arm_ordinal(0);
  capture(&saved);
  ticket_fault_disarm();
  REQUIRE(ticket_fault_read().live == 0);
  saved.reset();
  const TicketFaultStats stats = ticket_fault_read();
  REQUIRE(stats.actual_frees == stats.successful && stats.injected == 0);
  REQUIRE(stats.cleanse_failures == 0 && stats.calloc_calls == 0 && stats.realloc_calls == 0);
  printf("PASS shrinking_owns_no_trailing_data: 15 -> 1 -> 0; successful=%llu freed=%llu\n",
         static_cast<unsigned long long>(stats.successful),
         static_cast<unsigned long long>(stats.actual_frees));
}

int main() {
  ERR_clear_error();
  copy_oom(false);
  copy_oom(true);
  shrinking_owns_no_trailing_data();
  puts("PASS three direct ownership fault cases; raw snapshots/data have no erasure contract");
}
