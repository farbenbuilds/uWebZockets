#!/usr/bin/env python3
"""Rebuild unchanged bounded reservation witnesses against the supplied native libraries."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('pki_tool', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    native = args.native_root.resolve(strict=True)
    tool = args.pki_tool.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    if sha(tool) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('PKI helper differs')
    inherited = base / 'regressions'
    lineage = json.loads((base / 'inherited_input_lineage.json').read_text())
    for entry in lineage['entries']:
        if sha(inherited / entry['path']) != entry['sha256']:
            raise ValueError('Inherited input differs: ' + entry['path'])
    output.mkdir(mode=0o700)
    commands = []
    wrapper = base / 'zig_ssd.sh'
    todo = [
        ('output/run_direct.py', [str(native), str(tool), str(inherited / 'output/direct')]),
        ('output/run_lifecycle.py', [str(native), str(tool), str(inherited / 'output/lifecycle')]),
        ('aead/run_direct.py', [str(native), str(inherited / 'aead/direct')]),
        ('aead/run_lifecycle.py', [str(native), str(tool), str(inherited / 'aead/lifecycle')]),
        ('hs/run_helper.py', [str(native), str(tool), str(inherited / 'hs/helper'), '--reserved']),
        ('hs/run_lifecycle.py', [str(native), str(tool), str(inherited / 'hs/lifecycle')]),
        ('run_record_regressions.py', [str(native), str(tool)]),
        ('inherited_hkdf/run_witness.py', [str(native), str(inherited / 'inherited_hkdf/results')]),
    ]
    for index, (name, arguments) in enumerate(todo):
        command = [sys.executable, str(inherited / name), *arguments, '--zig', str(wrapper)]
        with (output / (str(index) + '.stdout')).open('wb') as stdout, \
             (output / (str(index) + '.stderr')).open('wb') as stderr:
            result = subprocess.run(command, stdout=stdout, stderr=stderr)
        commands.append({'command': command, 'exit_code': result.returncode})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode:
            raise RuntimeError('Inherited command failed: ' + name)
    command = [sys.executable, str(inherited / 'inherited_hkdf/compare_results.py'),
               str(inherited / 'inherited_hkdf/prior_baseline.stdout'),
               str(inherited / 'inherited_hkdf/results/require-zero.stdout')]
    with (output / 'hkdf_differential.stdout').open('wb') as stdout, \
         (output / 'hkdf_differential.stderr').open('wb') as stderr:
        result = subprocess.run(command, stdout=stdout, stderr=stderr)
    if result.returncode:
        raise RuntimeError('Inherited HKDF differential failed')
    (output / 'results.json').write_text(json.dumps({'complete': True,
        'commands': commands, 'hkdf_compare_command': command,
        'hkdf_compare_exit_code': result.returncode, 'preserved_prior_inputs': 51,
        'unchanged_orchestration_driver': True,
        'native_archives_sha256': {p.name: sha(p) for p in (native / 'native_out/lib').glob('*.a')},
        'zig_wrapper_sha256': sha(wrapper),
        'dedicated_campaigns_run': False}, indent=2) + '\n')
    print('PASS all inherited bounded reservation families; 51 prior inputs unchanged')


if __name__ == '__main__':
    main()
