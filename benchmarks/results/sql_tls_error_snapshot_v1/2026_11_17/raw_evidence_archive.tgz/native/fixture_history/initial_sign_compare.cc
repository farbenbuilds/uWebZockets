// Test-only native error ownership witness; never linked into the library.
#include <openssl/err.h>
#include <openssl/mem.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "crypto/err/internal.h"

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

#if ERROR_RESERVED_API
using Snapshot = bssl::UniquePtr<bssl::ERR_RESERVED_STATE>;
#else
using Snapshot = bssl::UniquePtr<bssl::ERR_SAVE_STATE>;
#endif

static const char kFile[] = "error_snapshot_fixture.cc";

static void require(bool condition, const char *why) {
  if (condition) {
    return;
  }
  fprintf(stderr, "FAIL: %s\n", why);
  abort();
}

static void create_snapshot(Snapshot *out) {
#if ERROR_RESERVED_API
  out->reset(bssl::ERR_RESERVED_STATE_new());
  require(out->get() != nullptr, "reserved factory");
#else
  (void)out;
#endif
}

static void capture(Snapshot *out) {
#if ERROR_RESERVED_API
  bssl::ERR_save_reserved_state(out->get());
#else
  out->reset(bssl::ERR_save_state());
#endif
}

static void restore(const Snapshot &state) {
#if ERROR_RESERVED_API
  bssl::ERR_restore_reserved_state(state.get());
#else
  bssl::ERR_restore_state(state.get());
#endif
}

static void push(unsigned reason, unsigned line, const char *data) {
  ERR_put_error(ERR_LIB_SSL, 0, static_cast<int>(reason), kFile, line);
  if (data != nullptr) {
    ERR_set_error_data(const_cast<char *>(data), ERR_FLAG_STRING);
  }
}

static void pop(unsigned reason, unsigned line, const char *expected) {
  const char *file = nullptr;
  const char *data = nullptr;
  int actual_line = 0;
  int flags = -1;
  uint32_t value = ERR_get_error_line_data(&file, &actual_line, &data, &flags);
  require(ERR_GET_LIB(value) == ERR_LIB_SSL && ERR_GET_REASON(value) == reason,
          "reason and library");
  require(strcmp(file, kFile) == 0 && actual_line == static_cast<int>(line),
          "file and line");
  require(strcmp(data, expected == nullptr ? "" : expected) == 0,
          "complete error text");
  require(flags == (expected == nullptr ? 0 : ERR_FLAG_STRING | ERR_FLAG_MALLOCED),
          "queue-owned string lifetime flags");
}

static void empty_queue() {
  require(ERR_get_error() == 0, "queue drained");
}

static void full_queue_wrap() {
  ERR_clear_error();
  Snapshot saved;
  create_snapshot(&saved);
  for (unsigned index = 1; index <= 20; index++) {
    push(1000 + index, 100 + index, nullptr);
  }
  capture(&saved);
  ERR_clear_error();
  restore(saved);
  for (unsigned index = 6; index <= 20; index++) {
    pop(1000 + index, 100 + index, nullptr);
  }
  empty_queue();
  printf("PASS full_queue_wrap: 15 complete entries\n");
}

static void marks_match_generic_copy() {
  ERR_clear_error();
  Snapshot saved;
  create_snapshot(&saved);
  push(1201, 201, nullptr);
  require(ERR_set_mark() == 1, "initial mark");
  push(1202, 202, nullptr);
  capture(&saved);
  ERR_clear_error();
  restore(saved);
  require(ERR_pop_to_mark() == 0, "saved copies reset marks like generic path");
  empty_queue();
  printf("PASS marks_match_generic_copy\n");
}

static void independent_snapshots() {
  ERR_clear_error();
  Snapshot first;
  Snapshot second;
  create_snapshot(&first);
  create_snapshot(&second);
  push(1301, 301, nullptr);
  capture(&first);
  ERR_clear_error();
  push(1302, 302, "synthetic diagnostic B");
  capture(&second);
  for (unsigned round = 0; round < 3; round++) {
    restore(first);
    pop(1301, 301, nullptr);
    empty_queue();
    restore(second);
    pop(1302, 302, "synthetic diagnostic B");
    empty_queue();
  }
  restore(first);
  pop(1301, 301, nullptr);
  empty_queue();
  printf("PASS independent_snapshots: A-B-A restoration\n");
}

static void arbitrary_data_and_popped_lifetime() {
  ERR_clear_error();
  char text[6001];
  memset(text, 'x', sizeof(text) - 1);
  text[sizeof(text) - 1] = 0;
  Snapshot saved;
  create_snapshot(&saved);
  push(1401, 401, text);
  capture(&saved);
  ERR_clear_error();
  restore(saved);
  const char *file = nullptr;
  const char *data = nullptr;
  int line = 0;
  int flags = 0;
  uint32_t value = ERR_get_error_line_data(&file, &line, &data, &flags);
  require(ERR_GET_REASON(value) == 1401 && line == 401 &&
              strcmp(file, kFile) == 0 &&
              flags == (ERR_FLAG_STRING | ERR_FLAG_MALLOCED),
          "long data metadata");
  require(data != text && strcmp(data, text) == 0, "long data deep copy");
  saved.reset();
  require(strcmp(data, text) == 0, "popped queue string outlives snapshot");
  empty_queue();
  ERR_clear_error();
  printf("PASS arbitrary_data_and_popped_lifetime: 6000 text bytes\n");
}

static void shrink_and_empty() {
  ERR_clear_error();
  Snapshot saved;
  create_snapshot(&saved);
  for (unsigned index = 0; index < 15; index++) {
    push(1500 + index, 500 + index, "synthetic owned data");
  }
  capture(&saved);
  ERR_clear_error();
  push(1515, 515, nullptr);
  capture(&saved);
  ERR_clear_error();
  restore(saved);
  pop(1515, 515, nullptr);
  empty_queue();
  capture(&saved);
  push(1516, 516, "replace this queue");
  restore(saved);
  empty_queue();
  printf("PASS shrink_and_empty: 15 -> 1 -> 0 entries\n");
}

static void metered_static_capture() {
  ERR_clear_error();
  Snapshot saved;
  create_snapshot(&saved);
  push(1601, 601, nullptr);
  uwz_alloc_begin();
  for (unsigned round = 0; round < 8; round++) {
    capture(&saved);
    ERR_clear_error();
    restore(saved);
  }
  uwz_alloc_end();
  const auto mallocs = uwz_alloc_malloc_calls();
  const auto frees = uwz_alloc_free_calls();
  const auto bytes = uwz_alloc_requested_bytes();
  require(uwz_alloc_calloc_calls() == 0 && uwz_alloc_realloc_calls() == 0,
          "no hidden allocation family");
#if ERROR_RESERVED_API
  require(mallocs == 0 && frees == 0 && bytes == 0,
          "reserved static capture and restore allocate nothing");
#else
  require(mallocs == 16 && frees == 14 && bytes == 320,
          "generic static baseline allocation shape");
#endif
  pop(1601, 601, nullptr);
  empty_queue();
  printf("PASS metered_static_capture: malloc=%llu free=%llu bytes=%llu\n",
         static_cast<unsigned long long>(mallocs),
         static_cast<unsigned long long>(frees),
         static_cast<unsigned long long>(bytes));
}

int main() {
  require(uwz_alloc_self_test() == 1, "unchanged all-C counter self-test63");
  ERR_clear_error();
  full_queue_wrap();
  marks_match_generic_copy();
  independent_snapshots();
  arbitrary_data_and_popped_lifetime();
  shrink_and_empty();
  metered_static_capture();
  ERR_clear_error();
  printf("PASS six direct error snapshot cases\n");
  return 0;
}
