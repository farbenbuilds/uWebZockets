#include "ticket_pair.h"

struct ErrorEntry {
  uint32_t packed;
  int line;
  int flags;
  char file[256];
  char data[128];
};

struct ErrorQueue {
  ErrorEntry entries[15];
  size_t count;
};

struct NestedContext {
  BIO *underlying;
  SSL *other;
  bool armed;
  unsigned calls;
  ErrorQueue original;
  ErrorQueue nested;
};

static void take_queue(ErrorQueue *out) {
  memset(out, 0, sizeof(*out));
  for (;;) {
    const char *file = nullptr;
    const char *data = nullptr;
    int line = 0;
    int flags = 0;
    const uint32_t packed = ERR_get_error_line_data(&file, &line, &data, &flags);
    if (packed == 0) return;
    CHECK(out->count < 15);
    ErrorEntry *entry = &out->entries[out->count++];
    CHECK(strlen(file) < sizeof(entry->file) && strlen(data) < sizeof(entry->data));
    entry->packed = packed;
    entry->line = line;
    entry->flags = flags;
    memcpy(entry->file, file, strlen(file) + 1);
    memcpy(entry->data, data, strlen(data) + 1);
  }
}

static int nested_create(BIO *bio) {
  BIO_set_init(bio, 1);
  return 1;
}

static int nested_destroy(BIO *bio) {
  BIO_set_data(bio, nullptr);
  return 1;
}

static int nested_write(BIO *bio, const char *data, int length) {
  auto *context = static_cast<NestedContext *>(BIO_get_data(bio));
  if (context->armed) {
    context->armed = false;
    context->calls++;
    take_queue(&context->original);
    uint8_t output;
    const int result = SSL_read(context->other, &output, 1);
    const int error = SSL_get_error(context->other, result);
    CHECK(result < 0 && error == SSL_ERROR_SSL);
    take_queue(&context->nested);
  }
  BIO_clear_retry_flags(bio);
  const int result = BIO_write(context->underlying, data, length);
  if (result <= 0 && BIO_should_retry(context->underlying)) BIO_set_retry_write(bio);
  return result;
}

static long nested_ctrl(BIO *bio, int command, long value, void *pointer) {
  auto *context = static_cast<NestedContext *>(BIO_get_data(bio));
  return BIO_ctrl(context->underlying, command, value, pointer);
}

static PeerPair ready(char **arguments) {
  PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 4096);
  CHECK(SSL_reserve_record_buffers(pair.client));
  CHECK(SSL_reserve_client_post_handshake_buffer(pair.client));
  CHECK(SSL_reserve_key_update_context(pair.client));
  CHECK(SSL_reserve_key_update_output_buffers(pair.client));
  CHECK(SSL_discard_client_session_tickets(pair.client));
#if ERROR_RESERVED_API
  CHECK(SSL_reserve_error_state(pair.client));
#endif
  return pair;
}

static void require_read_queue(SSL *ssl, const ErrorQueue &expected) {
  uint8_t output;
  const int result = SSL_read(ssl, &output, 1);
  const int error = SSL_get_error(ssl, result);
  CHECK(result < 0 && error == SSL_ERROR_SSL);
  ErrorQueue actual;
  take_queue(&actual);
  CHECK(memcmp(&expected, &actual, sizeof(actual)) == 0);
}

int main(int argc, char **argv) {
  CHECK(argc == 4);
  PeerPair first = ready(argv);
  PeerPair second = ready(argv);
  CHECK(SSL_send_fatal_alert(second.server, SSL_AD_ACCESS_DENIED) == 1);

  BIO *underlying = SSL_get_wbio(first.client);
  CHECK(BIO_up_ref(underlying));
  BIO_METHOD *method = BIO_meth_new(BIO_TYPE_FILTER, "nested other SSL queue witness");
  CHECK(method != nullptr);
  CHECK(BIO_meth_set_create(method, nested_create));
  CHECK(BIO_meth_set_destroy(method, nested_destroy));
  CHECK(BIO_meth_set_write(method, nested_write));
  CHECK(BIO_meth_set_ctrl(method, nested_ctrl));
  BIO *filter = BIO_new(method);
  CHECK(filter != nullptr);
  NestedContext context = {underlying, second.client, true, 0, {}, {}};
  BIO_set_data(filter, &context);
  SSL_set0_wbio(first.client, filter);

  uint8_t input[64];
  memset(input, 0x53, sizeof(input));
  CHECK(BIO_ctrl_pending(SSL_get_rbio(first.client)) == 0);
  CHECK(SSL_write(first.server, input, sizeof(input)) == static_cast<int>(sizeof(input)));
  uint8_t record[256];
  const int count = BIO_read(SSL_get_rbio(first.client), record, sizeof(record));
  CHECK(count > 5 && static_cast<size_t>(count) == 5 + 17 + sizeof(input));
  record[count - 1] ^= 1;
  CHECK(BIO_write(SSL_get_wbio(first.server), record, count) == count);

  uint8_t output;
  const int result = SSL_read(first.client, &output, 1);
  const int error = SSL_get_error(first.client, result);
  CHECK(result < 0 && error == SSL_ERROR_SSL && context.calls == 1);
  ErrorQueue actual;
  take_queue(&actual);
  CHECK(context.original.count == 2 && memcmp(&actual, &context.original, sizeof(actual)) == 0);
  CHECK(ERR_GET_LIB(actual.entries[0].packed) == ERR_LIB_CIPHER && ERR_GET_REASON(actual.entries[0].packed) == 101);
  CHECK(ERR_GET_LIB(actual.entries[1].packed) == ERR_LIB_SSL && ERR_GET_REASON(actual.entries[1].packed) == SSL_R_DECRYPTION_FAILED_OR_BAD_RECORD_MAC);
  CHECK(actual.entries[0].flags == 0 && actual.entries[1].flags == 0);
  CHECK(context.nested.count == 1 && context.nested.entries[0].packed == ERR_PACK(ERR_LIB_SSL, SSL_AD_REASON_OFFSET + SSL_AD_ACCESS_DENIED));
  CHECK(context.nested.entries[0].flags == (ERR_FLAG_STRING | ERR_FLAG_MALLOCED));
  CHECK(strcmp(context.nested.entries[0].data, "SSL alert number 49") == 0);
  require_read_queue(second.client, context.nested);
  require_read_queue(first.client, context.original);
  CHECK(context.calls == 1);
  destroy_pair(&first);
  BIO_free(underlying);
  BIO_meth_free(method);
  destroy_pair(&second);
  ERR_clear_error();
  puts("PASS real nested BIO other-SSL read: original two-entry badMAC queue restored, nested peer-alert text independently replayed, one alert callback; functional-only scope");
}
