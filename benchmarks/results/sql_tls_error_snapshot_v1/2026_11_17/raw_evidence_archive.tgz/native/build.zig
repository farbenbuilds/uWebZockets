const std = @import("std");
const boringssl = @import("builds/vendor/boringssl.zig");
const sanitizers = @import("builds/sanitizers.zig");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const mode = sanitizers.configure(b, target, true);
    const native = boringssl.build(b, target, optimize, mode);
    b.installArtifact(native.crypto);
    b.installArtifact(native.ssl);
}
