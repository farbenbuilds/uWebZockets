#ifndef UWZ_HS_FAULT_ALLOC_H
#define UWZ_HS_FAULT_ALLOC_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

struct HsFaultStats {
    uint64_t attempts;
    uint64_t successful;
    uint64_t injected;
    uint64_t live;
    uint64_t actual_frees;
    uint64_t cleanse_failures;
    uint64_t calloc_calls;
    uint64_t realloc_calls;
    uint64_t requested_bytes;
};

void hs_fault_reset(void);
void hs_fault_arm(size_t ordinal);
void hs_fault_disarm(void);
struct HsFaultStats hs_fault_read(void);

#ifdef __cplusplus
}
#endif
#endif
