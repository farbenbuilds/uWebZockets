#ifndef UWZ_AEAD_INJECT_H
#define UWZ_AEAD_INJECT_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

enum InitFaultMode { init_fault_none, init_fault_null, init_fault_live, init_fault_malloc };

struct InitFaultObservation {
    uint64_t armed_calls;
    uint64_t populated_inline_bytes;
    int real_result;
    int returned_null_aead;
};

void init_fault_arm(enum InitFaultMode mode, size_t ordinal);
struct InitFaultObservation init_fault_read(void);

#ifdef __cplusplus
}
#endif
#endif
