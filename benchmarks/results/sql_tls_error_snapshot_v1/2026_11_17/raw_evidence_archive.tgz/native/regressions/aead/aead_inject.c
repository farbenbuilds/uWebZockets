/* Test-only link wrapper; normal direct and wire binaries do not link it. */
#include "aead_inject.h"
#include <openssl/aead.h>
#include <openssl/err.h>
#include <stdlib.h>
#include <string.h>

extern int __real_EVP_AEAD_CTX_init_with_direction(EVP_AEAD_CTX *context,
    const EVP_AEAD *aead, const uint8_t *key, size_t key_length, size_t tag_length,
    enum evp_aead_direction_t direction);
extern void hs_fault_arm(size_t ordinal) __attribute__((weak));

/* Injection state is confined to the fixture's single OS thread. */
static _Thread_local enum InitFaultMode fault_mode;
static _Thread_local size_t fail_malloc_ordinal;
static _Thread_local struct InitFaultObservation observation;

void init_fault_arm(enum InitFaultMode mode, size_t ordinal)
{
    if (fault_mode != init_fault_none) abort();
    memset(&observation, 0, sizeof(observation));
    fault_mode = mode;
    fail_malloc_ordinal = ordinal;
}

struct InitFaultObservation init_fault_read(void) { return observation; }

int __wrap_EVP_AEAD_CTX_init_with_direction(EVP_AEAD_CTX *context,
    const EVP_AEAD *aead, const uint8_t *key, size_t key_length, size_t tag_length,
    enum evp_aead_direction_t direction)
{
    const int result = __real_EVP_AEAD_CTX_init_with_direction(context, aead, key,
        key_length, tag_length, direction);
    if (fault_mode == init_fault_none) return result;
    const enum InitFaultMode mode = fault_mode;
    fault_mode = init_fault_none;
    observation.armed_calls++;
    observation.real_result = result;
    if (result != 1) return result;
    for (size_t index = 0; index < sizeof(context->state.opaque); index++) {
        if (context->state.opaque[index] != 0) observation.populated_inline_bytes++;
    }
    if (mode == init_fault_malloc) {
        if (hs_fault_arm == NULL) abort();
        hs_fault_arm(fail_malloc_ordinal);
        return result;
    }
    if (mode == init_fault_null) context->aead = NULL;
    observation.returned_null_aead = context->aead == NULL;
    OPENSSL_PUT_ERROR(CIPHER, ERR_R_INTERNAL_ERROR);
    return 0;
}
