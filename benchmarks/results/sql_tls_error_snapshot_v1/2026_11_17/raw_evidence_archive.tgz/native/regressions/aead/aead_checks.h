#ifndef UWZ_AEAD_CHECKS_H
#define UWZ_AEAD_CHECKS_H
#include <ssl/internal.h>
#include <openssl/err.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

struct AllocationCounts {
    uint64_t malloc_calls;
    uint64_t calloc_calls;
    uint64_t realloc_calls;
    uint64_t free_calls;
    uint64_t bytes;
};

struct ContextLayout {
    size_t object_size;
    size_t context_offset;
    size_t context_size;
    size_t nonce_offset;
    size_t nonce_capacity;
    size_t nonce_length_offset;
    size_t variable_length_offset;
    size_t flags_offset;
    uint8_t flags_mask;
};

// Pinned x86_64 Debug compiler layout; the retained record dump proves offsets.
static constexpr ContextLayout context_layout = {600, 8, 576, 584, 12, 596, 597, 598, 31};
static_assert(sizeof(bssl::SSLAEADContext) == context_layout.object_size);
static_assert(sizeof(EVP_AEAD_CTX) == context_layout.context_size);

static void check(bool value, const char *expression, int line)
{
    if (value) return;
    fprintf(stderr, "check failed at %d: %s\n", line, expression);
    ERR_print_errors_fp(stderr);
    abort();
}

#define AEAD_CHECK(value) check(static_cast<bool>(value), #value, __LINE__)

static AllocationCounts counts(void)
{
    return {uwz_alloc_malloc_calls(), uwz_alloc_calloc_calls(),
            uwz_alloc_realloc_calls(), uwz_alloc_free_calls(),
            uwz_alloc_requested_bytes()};
}

static void check_zero(const AllocationCounts *value)
{
    AEAD_CHECK(value->malloc_calls == 0 && value->calloc_calls == 0);
    AEAD_CHECK(value->realloc_calls == 0 && value->free_calls == 0 && value->bytes == 0);
}

static bool zero_region(const uint8_t *bytes, size_t length)
{
    for (size_t index = 0; index < length; index++) if (bytes[index] != 0) return false;
    return true;
}

static void check_empty(const bssl::SSLAEADContext *context)
{
    AEAD_CHECK(bssl::SSLAEADContext::IsKeyUpdateSpare(context));
    AEAD_CHECK(context->cipher() == nullptr);
    const uint8_t *bytes = reinterpret_cast<const uint8_t *>(context);
    AEAD_CHECK(zero_region(bytes + context_layout.context_offset, context_layout.context_size));
    AEAD_CHECK(zero_region(bytes + context_layout.nonce_offset, context_layout.nonce_capacity));
    AEAD_CHECK(bytes[context_layout.nonce_length_offset] == 0);
    AEAD_CHECK(bytes[context_layout.variable_length_offset] == 0);
    AEAD_CHECK((bytes[context_layout.flags_offset] & context_layout.flags_mask) == 0);
}

#endif
