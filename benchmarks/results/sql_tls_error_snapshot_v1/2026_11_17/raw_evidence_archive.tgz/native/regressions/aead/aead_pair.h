#ifndef UWZ_HS_PAIR_H
#define UWZ_HS_PAIR_H
#include <ssl/internal.h>
#include <openssl/err.h>
#include <openssl/x509_vfy.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK(expression) do { if (!(expression)) fail(__LINE__, #expression); } while (0)

struct PeerPair {
    SSL_CTX *client_context;
    SSL_CTX *server_context;
    SSL *client;
    SSL *server;
};

static void fail(int line, const char *expression)
{
    fprintf(stderr, "check failed at %d: %s\n", line, expression);
    ERR_print_errors_fp(stderr);
    abort();
}

static bool retry(SSL *ssl, int result)
{
    const int error = SSL_get_error(ssl, result);
    return error == SSL_ERROR_WANT_READ || error == SSL_ERROR_WANT_WRITE;
}

static void attach_bios(PeerPair *pair, size_t capacity)
{
    BIO *client = nullptr;
    BIO *server = nullptr;
    CHECK(BIO_new_bio_pair(&client, capacity, &server, capacity));
    SSL_set_bio(pair->client, client, client);
    SSL_set_bio(pair->server, server, server);
    SSL_set_connect_state(pair->client);
    SSL_set_accept_state(pair->server);
}

static void handshake(PeerPair *pair, uint16_t version)
{
    bool client_done = false;
    bool server_done = false;
    for (size_t index = 0; index < 100000 && (!client_done || !server_done); index++) {
        if (!client_done) {
            const int result = SSL_do_handshake(pair->client);
            if (result == 1) client_done = true;
            else CHECK(retry(pair->client, result));
        }
        if (!server_done) {
            const int result = SSL_do_handshake(pair->server);
            if (result == 1) server_done = true;
            else CHECK(retry(pair->server, result));
        }
    }
    CHECK(client_done && server_done);
    CHECK(SSL_version(pair->client) == version);
    CHECK(SSL_version(pair->server) == version);
    CHECK(SSL_get_verify_result(pair->client) == X509_V_OK);
    CHECK(SSL_get0_peer_certificates(pair->client) != nullptr);
}

static PeerPair make_pair(char **arguments, uint16_t version, size_t capacity,
                         uint16_t suite = 0x1301)
{
    PeerPair pair = {};
    pair.client_context = SSL_CTX_new(TLS_method());
    pair.server_context = SSL_CTX_new(TLS_method());
    CHECK(pair.client_context != nullptr && pair.server_context != nullptr);
    CHECK(SSL_CTX_set_min_proto_version(pair.client_context, version));
    CHECK(SSL_CTX_set_max_proto_version(pair.client_context, version));
    CHECK(SSL_CTX_set_min_proto_version(pair.server_context, version));
    CHECK(SSL_CTX_set_max_proto_version(pair.server_context, version));
    if (version == TLS1_3_VERSION) {
        CHECK(SSL_CTX_set1_tls13_ciphers(pair.client_context, &suite, nullptr, 1));
        CHECK(SSL_CTX_set1_tls13_ciphers(pair.server_context, &suite, nullptr, 1));
    }
    CHECK(SSL_CTX_set_num_tickets(pair.server_context, 0));
    CHECK(SSL_CTX_use_certificate_chain_file(pair.server_context, arguments[1]));
    CHECK(SSL_CTX_use_PrivateKey_file(pair.server_context, arguments[2], SSL_FILETYPE_PEM));
    CHECK(SSL_CTX_check_private_key(pair.server_context));
    CHECK(SSL_CTX_load_verify_locations(pair.client_context, arguments[3], nullptr));
    SSL_CTX_set_verify(pair.client_context, SSL_VERIFY_PEER, nullptr);
    pair.client = SSL_new(pair.client_context);
    pair.server = SSL_new(pair.server_context);
    CHECK(pair.client != nullptr && pair.server != nullptr);
    CHECK(SSL_set_tlsext_host_name(pair.client, "localhost"));
    CHECK(SSL_set1_host(pair.client, "localhost"));
    attach_bios(&pair, capacity);
    handshake(&pair, version);
    if (version == TLS1_3_VERSION) {
        CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair.client)) == suite);
        CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair.server)) == suite);
    }
    return pair;
}

static void destroy_pair(PeerPair *pair)
{
    SSL_free(pair->client);
    SSL_free(pair->server);
    SSL_CTX_free(pair->client_context);
    SSL_CTX_free(pair->server_context);
    memset(pair, 0, sizeof(*pair));
}

#endif
