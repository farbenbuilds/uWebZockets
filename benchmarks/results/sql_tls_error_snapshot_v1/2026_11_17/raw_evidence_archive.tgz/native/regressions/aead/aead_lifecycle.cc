#include "aead_pair.h"
#include "aead_inject.h"
#include "hs_fault_alloc.h"

struct SliceSnapshot {
    uintptr_t pointer;
    size_t length;
    size_t capacity;
    uint64_t hash;
};

struct PendingSnapshot {
    SliceSnapshot slices[7];
    uintptr_t descriptor;
    uintptr_t read_error;
    uintptr_t key_update_cipher;
    uintptr_t key_update_spare;
    uintptr_t key_update_candidate;
    uintptr_t read_context;
    uintptr_t write_context;
    uint8_t read_context_bytes[600];
    uint8_t write_context_bytes[600];
    uint8_t spare_context_bytes[600];
    uint8_t read_secret[SSL_MAX_MD_SIZE];
    uint8_t write_secret[SSL_MAX_MD_SIZE];
    size_t read_secret_length;
    size_t write_secret_length;
    size_t unreported_bytes;
    long max_cert_list;
    uint32_t ceiling;
    uint32_t flight_offset;
    uint32_t pending_write_type;
    uint8_t has_message;
    uint8_t key_update_pending;
    uint8_t alert_dispatch;
    uint8_t read_shutdown;
    uint8_t write_shutdown;
};

static uint64_t byte_hash(const uint8_t *bytes, size_t length)
{
    uint64_t hash = 1469598103934665603ULL;
    for (size_t index = 0; index < length; index++) {
        hash ^= bytes[index];
        hash *= 1099511628211ULL;
    }
    return hash;
}

static SliceSnapshot slice(const uint8_t *bytes, size_t length, size_t capacity)
{
    return {reinterpret_cast<uintptr_t>(bytes), length, capacity, byte_hash(bytes, length)};
}

static SliceSnapshot buffer(const BUF_MEM *value)
{
    if (!value) return {};
    return slice(reinterpret_cast<const uint8_t *>(value->data), value->length, value->max);
}

static void capture(SSL *ssl, PendingSnapshot *result)
{
    auto *state = bssl::FromOpaque(ssl)->s3;
    memset(result, 0, sizeof(*result));
    result->slices[0] = buffer(state->hs_buf.get());
    result->slices[1] = slice(state->read_buffer.cap() ? state->read_buffer.data() : nullptr,
        state->read_buffer.size(), state->read_buffer.cap());
    result->slices[2] = slice(state->write_buffer.cap() ? state->write_buffer.data() : nullptr,
        state->write_buffer.size(), state->write_buffer.cap());
    result->slices[3] = slice(state->pending_app_data.data(), state->pending_app_data.size(), 0);
    result->slices[4] = slice(state->pending_write.data(), state->pending_write.size(), 0);
    result->slices[5] = buffer(state->pending_hs_data.get());
    result->slices[6] = buffer(state->pending_flight.get());
    result->descriptor = reinterpret_cast<uintptr_t>(state->hs_buf.get());
    result->read_error = reinterpret_cast<uintptr_t>(state->read_error.get());
    result->key_update_cipher = reinterpret_cast<uintptr_t>(state->key_update_cipher);
    result->key_update_spare = reinterpret_cast<uintptr_t>(state->key_update_spare.get());
    result->key_update_candidate = reinterpret_cast<uintptr_t>(state->key_update_candidate);
    result->read_context = reinterpret_cast<uintptr_t>(state->aead_read_ctx.get());
    result->write_context = reinterpret_cast<uintptr_t>(state->aead_write_ctx.get());
    if (state->aead_read_ctx) memcpy(result->read_context_bytes,
        state->aead_read_ctx.get(), sizeof(result->read_context_bytes));
    if (state->aead_write_ctx) memcpy(result->write_context_bytes,
        state->aead_write_ctx.get(), sizeof(result->write_context_bytes));
    if (state->key_update_spare) memcpy(result->spare_context_bytes,
        state->key_update_spare.get(), sizeof(result->spare_context_bytes));
    result->read_secret_length = state->read_traffic_secret.size();
    result->write_secret_length = state->write_traffic_secret.size();
    memcpy(result->read_secret, state->read_traffic_secret.data(), result->read_secret_length);
    memcpy(result->write_secret, state->write_traffic_secret.data(), result->write_secret_length);
    result->unreported_bytes = state->unreported_bytes_written;
    result->max_cert_list = SSL_get_max_cert_list(ssl);
    result->ceiling = state->client_post_handshake_max_message_len;
    result->flight_offset = state->pending_flight_offset;
    result->pending_write_type = state->pending_write_type;
    result->has_message = state->has_message;
    result->key_update_pending = state->key_update_pending;
    result->alert_dispatch = state->alert_dispatch;
    result->read_shutdown = state->read_shutdown;
    result->write_shutdown = state->write_shutdown;
}

static void check_released(uint64_t allocations)
{
    const HsFaultStats stats = hs_fault_read();
    CHECK(stats.successful == allocations);
    CHECK(stats.live == 0 && stats.actual_frees == allocations);
    CHECK(stats.cleanse_failures == 0);
    CHECK(stats.calloc_calls == 0 && stats.realloc_calls == 0);
}

static void reject_unchanged(SSL *ssl)
{
    PendingSnapshot before;
    capture(ssl, &before);
    const HsFaultStats old = hs_fault_read();
    ERR_clear_error();
    hs_fault_arm(0);
    CHECK(!SSL_reserve_key_update_context(ssl));
    hs_fault_disarm();
    CHECK(ERR_peek_error() != 0);
    PendingSnapshot after;
    capture(ssl, &after);
    const HsFaultStats current = hs_fault_read();
    CHECK(memcmp(&before, &after, sizeof(before)) == 0);
    OPENSSL_cleanse(&before, sizeof(before));
    OPENSSL_cleanse(&after, sizeof(after));
    CHECK(memcmp(&old, &current, sizeof(old)) == 0);
    ERR_clear_error();
}

static void check_spare(const bssl::SSLAEADContext *context)
{
    static_assert(sizeof(bssl::SSLAEADContext) == 600);
    static_assert(sizeof(EVP_AEAD_CTX) == 576);
    CHECK(bssl::SSLAEADContext::IsKeyUpdateSpare(context));
    const uint8_t *bytes = reinterpret_cast<const uint8_t *>(context);
    for (size_t index = 8; index < 596; index++) CHECK(bytes[index] == 0);
    CHECK(bytes[596] == 0 && bytes[597] == 0 && (bytes[598] & 31) == 0);
    CHECK(context->cipher() == nullptr);
}

static void reserve(SSL *ssl)
{
    const HsFaultStats before = hs_fault_read();
    hs_fault_arm(0);
    CHECK(SSL_reserve_key_update_context(ssl));
    hs_fault_disarm();
    const HsFaultStats after = hs_fault_read();
    CHECK(after.attempts == before.attempts + 1);
    CHECK(after.successful == before.successful + 1 && after.live == before.live + 1);
    CHECK(after.requested_bytes == before.requested_bytes + 608);
    auto *state = bssl::FromOpaque(ssl)->s3;
    CHECK(state->key_update_cipher == SSL_get_current_cipher(ssl));
    CHECK(state->key_update_candidate == nullptr);
    check_spare(state->key_update_spare.get());
}

static void failure(char **arguments, size_t ordinal)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    hs_fault_reset();
    PendingSnapshot before;
    capture(pair.client, &before);
    hs_fault_arm(ordinal);
    CHECK(!SSL_reserve_key_update_context(pair.client));
    hs_fault_disarm();
    CHECK(ERR_peek_error() != 0);
    PendingSnapshot after;
    capture(pair.client, &after);
    CHECK(memcmp(&before, &after, sizeof(before)) == 0);
    OPENSSL_cleanse(&before, sizeof(before));
    OPENSSL_cleanse(&after, sizeof(after));
    const HsFaultStats stats = hs_fault_read();
    CHECK(stats.attempts == ordinal && stats.injected == 1);
    CHECK(stats.successful == ordinal - 1);
    CHECK(stats.live == 0 && stats.actual_frees == ordinal - 1);
    CHECK(stats.cleanse_failures == 0);
    ERR_clear_error();
    // Failure is atomic, so the same verified connection remains reservable.
    reserve(pair.client);
    destroy_pair(&pair);
    check_released(ordinal);
}

static void idempotent(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    hs_fault_reset();
    reserve(pair.client);
    PendingSnapshot before;
    capture(pair.client, &before);
    const HsFaultStats old = hs_fault_read();
    hs_fault_arm(0);
    CHECK(SSL_reserve_key_update_context(pair.client));
    hs_fault_disarm();
    PendingSnapshot after;
    capture(pair.client, &after);
    const HsFaultStats current = hs_fault_read();
    CHECK(memcmp(&before, &after, sizeof(before)) == 0);
    OPENSSL_cleanse(&before, sizeof(before));
    OPENSSL_cleanse(&after, sizeof(after));
    CHECK(memcmp(&old, &current, sizeof(old)) == 0);
    destroy_pair(&pair);
    check_released(1);
}

static void fill_payload(uint8_t *bytes, size_t length)
{
    for (size_t index = 0; index < length; index++) bytes[index] = index * 13 + 7;
}

static void exchange(SSL *sender, SSL *receiver, size_t length, const uint8_t *existing = nullptr)
{
    uint8_t generated[4096];
    uint8_t output[sizeof(generated)];
    CHECK(length <= sizeof(generated));
    if (!existing) fill_payload(generated, length);
    const uint8_t *input = existing ? existing : generated;
    bool written = false;
    size_t received = 0;
    for (size_t iteration = 0; iteration < 100000 && (!written || received != length); iteration++) {
        if (!written) {
            const int result = SSL_write(sender, input, static_cast<int>(length));
            if (result > 0) {
                CHECK(static_cast<size_t>(result) == length);
                written = true;
            } else CHECK(retry(sender, result));
        }
        if (received < length) {
            const int result = SSL_read(receiver, output + received,
                static_cast<int>(length - received));
            if (result > 0) received += static_cast<size_t>(result);
            else CHECK(retry(receiver, result));
        }
    }
    CHECK(written && received == length && memcmp(input, output, length) == 0);
}

static void pending_plaintext(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    uint8_t input[128];
    uint8_t first = 0;
    fill_payload(input, sizeof(input));
    CHECK(SSL_write(pair.server, input, sizeof(input)) == static_cast<int>(sizeof(input)));
    CHECK(SSL_read(pair.client, &first, 1) == 1 && first == input[0]);
    CHECK(SSL_pending(pair.client) == static_cast<int>(sizeof(input) - 1));
    hs_fault_reset();
    reject_unchanged(pair.client);
    uint8_t rest[127];
    CHECK(SSL_read(pair.client, rest, sizeof(rest)) == static_cast<int>(sizeof(rest)));
    CHECK(memcmp(rest, input + 1, sizeof(rest)) == 0);
    reserve(pair.client);
    destroy_pair(&pair);
    check_released(1);
}

static void pending_record(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    uint8_t input[4096];
    uint8_t output[32];
    fill_payload(input, sizeof(input));
    int result = SSL_write(pair.server, input, sizeof(input));
    CHECK(result < 0 && SSL_get_error(pair.server, result) == SSL_ERROR_WANT_WRITE);
    result = SSL_read(pair.client, output, sizeof(output));
    CHECK(result < 0 && SSL_get_error(pair.client, result) == SSL_ERROR_WANT_READ);
    const auto *state = bssl::FromOpaque(pair.client)->s3;
    CHECK(state->read_buffer.size() > 0 && state->pending_app_data.empty());
    hs_fault_reset();
    reject_unchanged(pair.client);
    // Retry the same write and complete its verified plaintext after rejection.
    exchange(pair.server, pair.client, sizeof(input), input);
    reserve(pair.client);
    destroy_pair(&pair);
    check_released(1);
}

static void pending_write(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    uint8_t input[4096];
    fill_payload(input, sizeof(input));
    const int result = SSL_write(pair.client, input, sizeof(input));
    CHECK(result < 0 && SSL_get_error(pair.client, result) == SSL_ERROR_WANT_WRITE);
    const auto *state = bssl::FromOpaque(pair.client)->s3;
    CHECK(!state->pending_write.empty() && !state->write_buffer.empty());
    hs_fault_reset();
    reject_unchanged(pair.client);
    exchange(pair.client, pair.server, sizeof(input), input);
    reserve(pair.client);
    destroy_pair(&pair);
    check_released(1);
}

static void outgoing_key_update(char **arguments, bool backpressure)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    if (backpressure) {
        uint8_t bytes[1000];
        fill_payload(bytes, sizeof(bytes));
        CHECK(SSL_write(pair.client, bytes, sizeof(bytes)) == static_cast<int>(sizeof(bytes)));
    }
    CHECK(SSL_key_update(pair.client, SSL_KEY_UPDATE_NOT_REQUESTED));
    if (backpressure) {
        // SSL_write moves flights into write_buffer; exercise the flight itself.
        const int result = bssl::tls_flush(bssl::FromOpaque(pair.client));
        CHECK(result < 0 && SSL_get_error(pair.client, result) == SSL_ERROR_WANT_WRITE);
    }
    const auto *state = bssl::FromOpaque(pair.client)->s3;
    CHECK(state->key_update_pending);
    CHECK((state->pending_hs_data && state->pending_hs_data->length != 0) ||
        (state->pending_flight && state->pending_flight->length != 0));
    if (backpressure) CHECK(state->pending_flight && state->pending_flight->length > state->pending_flight_offset);
    hs_fault_reset();
    reject_unchanged(pair.client);
    destroy_pair(&pair);
    check_released(0);
}

static void control_traffic(char **arguments, bool reverse)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    hs_fault_reset();
    if (reverse) exchange(pair.server, pair.client, 4096);
    else exchange(pair.client, pair.server, 4096);
    reserve(pair.client);
    destroy_pair(&pair);
    check_released(1);
}

static void excluded_configured(bool dtls, bool quic)
{
    SSL_CTX *context = SSL_CTX_new(dtls ? DTLS_method() : TLS_method());
    CHECK(context != nullptr);
    SSL *ssl = SSL_new(context);
    CHECK(ssl != nullptr);
    SSL_set_connect_state(ssl);
    if (quic) {
        static const SSL_QUIC_METHOD method = {};
        CHECK(SSL_set_quic_method(ssl, &method) && SSL_is_quic(ssl));
    }
    if (dtls) CHECK(SSL_is_dtls(ssl));
    hs_fault_reset();
    reject_unchanged(ssl);
    SSL_free(ssl);
    SSL_CTX_free(context);
    check_released(0);
}

static void excluded_pair(char **arguments, bool server)
{
    PeerPair pair = make_pair(arguments, server ? TLS1_3_VERSION : TLS1_2_VERSION, 1024);
    hs_fault_reset();
    reject_unchanged(server ? pair.server : pair.client);
    destroy_pair(&pair);
    check_released(0);
}

static void excluded_null(void)
{
    hs_fault_reset();
    hs_fault_arm(0);
    CHECK(!SSL_reserve_key_update_context(nullptr));
    hs_fault_disarm();
    CHECK(ERR_peek_error() != 0 && hs_fault_read().attempts == 0);
    check_released(0);
    ERR_clear_error();
}

static void shutdown_rejection(char **arguments, bool received)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    if (received) {
        CHECK(SSL_shutdown(pair.server) == 0);
        uint8_t byte;
        const int result = SSL_read(pair.client, &byte, 1);
        CHECK(result == 0 && SSL_get_error(pair.client, result) == SSL_ERROR_ZERO_RETURN);
    } else CHECK(SSL_shutdown(pair.client) == 0);
    hs_fault_reset();
    reject_unchanged(pair.client);
    destroy_pair(&pair);
    check_released(0);
}

static void fatal_alert_rejection(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    CHECK(SSL_send_fatal_alert(pair.server, SSL_AD_INTERNAL_ERROR) == 1);
    uint8_t byte;
    int result = SSL_read(pair.client, &byte, 1);
    CHECK(result < 0 && SSL_get_error(pair.client, result) == SSL_ERROR_SSL);
    const auto *state = bssl::FromOpaque(pair.client)->s3;
    CHECK(state->read_shutdown == bssl::ssl_shutdown_error && state->read_error);
    hs_fault_reset();
    reject_unchanged(pair.client);
    result = SSL_read(pair.client, &byte, 1);
    CHECK(result < 0 && SSL_get_error(pair.client, result) == SSL_ERROR_SSL);
    CHECK(state->read_shutdown == bssl::ssl_shutdown_error && state->read_error);
    destroy_pair(&pair);
    check_released(0);
    ERR_clear_error();
}

static void clear_rehandshake(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    hs_fault_reset();
    reserve(pair.client);
    CHECK(SSL_clear(pair.client) && SSL_clear(pair.server));
    check_released(1);
    CHECK(bssl::FromOpaque(pair.client)->s3->client_post_handshake_max_message_len == 0);
    CHECK(!bssl::FromOpaque(pair.client)->s3->hs_buf);
    CHECK(!bssl::FromOpaque(pair.client)->s3->key_update_spare);
    CHECK(bssl::FromOpaque(pair.client)->s3->key_update_cipher == nullptr);
    CHECK(bssl::FromOpaque(pair.client)->s3->key_update_candidate == nullptr);
    SSL_set_max_cert_list(pair.client, 200000);
    CHECK(SSL_get_max_cert_list(pair.client) == 200000);
    reject_unchanged(pair.client);
    SSL_set_max_cert_list(pair.client, 102400);
    CHECK(SSL_set_session(pair.client, nullptr));
    attach_bios(&pair, 1024);
    handshake(&pair, TLS1_3_VERSION);
    CHECK(!SSL_session_reused(pair.client));
    reserve(pair.client);
    CHECK(SSL_key_update(pair.client, SSL_KEY_UPDATE_NOT_REQUESTED));
    exchange(pair.client, pair.server, 4096);
    CHECK(SSL_key_update(pair.server, SSL_KEY_UPDATE_NOT_REQUESTED));
    exchange(pair.server, pair.client, 4096);
    destroy_pair(&pair);
    check_released(2);
}

static void independent_contexts(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    hs_fault_reset();
    reserve(pair.client);
    PendingSnapshot before;
    capture(pair.client, &before);
    SSL *other = SSL_new(pair.client_context);
    CHECK(other);
    SSL_set_connect_state(other);
    CHECK(!bssl::FromOpaque(other)->s3->key_update_spare);
    CHECK(bssl::FromOpaque(other)->s3->key_update_cipher == nullptr);
    reject_unchanged(other);
    PendingSnapshot after;
    capture(pair.client, &after);
    CHECK(memcmp(&before, &after, sizeof(before)) == 0);
    OPENSSL_cleanse(&before, sizeof(before));
    OPENSSL_cleanse(&after, sizeof(after));
    SSL_free(other);
    destroy_pair(&pair);
    check_released(1);
}

static void preparation_failure(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    hs_fault_reset();
    reserve(pair.client);
    const evp_aead_direction_t directions[] = {evp_aead_open, evp_aead_seal};
    for (evp_aead_direction_t direction : directions) {
        PendingSnapshot before;
        capture(pair.client, &before);
        const HsFaultStats old = hs_fault_read();
        init_fault_arm(init_fault_null, 0);
        hs_fault_arm(0);
        CHECK(!bssl::tls13_rotate_traffic_key(bssl::FromOpaque(pair.client), direction));
        hs_fault_disarm();
        const InitFaultObservation observation = init_fault_read();
        CHECK(observation.armed_calls == 1 && observation.real_result == 1);
        CHECK(observation.populated_inline_bytes > 0 && observation.returned_null_aead);
        PendingSnapshot after;
        capture(pair.client, &after);
        const HsFaultStats current = hs_fault_read();
        CHECK(memcmp(&before, &after, sizeof(before)) == 0);
        OPENSSL_cleanse(&before, sizeof(before));
        OPENSSL_cleanse(&after, sizeof(after));
        CHECK(memcmp(&old, &current, sizeof(old)) == 0);
        check_spare(bssl::FromOpaque(pair.client)->s3->key_update_spare.get());
        ERR_clear_error();
    }
    destroy_pair(&pair);
    check_released(1);
}

static void write_hook_failure(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    hs_fault_reset();
    reserve(pair.client);
    PendingSnapshot before;
    capture(pair.client, &before);
    const HsFaultStats old = hs_fault_read();
    // Arm flight-storage failure only after real initializer population succeeds.
    init_fault_arm(init_fault_malloc, 2);
    CHECK(!SSL_key_update(pair.client, SSL_KEY_UPDATE_NOT_REQUESTED));
    hs_fault_disarm();
    const InitFaultObservation observation = init_fault_read();
    CHECK(observation.armed_calls == 1 && observation.real_result == 1);
    CHECK(observation.populated_inline_bytes > 0);
    PendingSnapshot after;
    capture(pair.client, &after);
    CHECK(before.write_context == after.write_context);
    CHECK(memcmp(before.write_context_bytes, after.write_context_bytes,
        sizeof(before.write_context_bytes)) == 0);
    CHECK(before.write_secret_length == after.write_secret_length);
    CHECK(memcmp(before.write_secret, after.write_secret, before.write_secret_length) == 0);
    CHECK(before.key_update_cipher == after.key_update_cipher);
    CHECK(before.key_update_spare == after.key_update_spare);
    CHECK(after.key_update_candidate == 0);
    OPENSSL_cleanse(&before, sizeof(before));
    OPENSSL_cleanse(&after, sizeof(after));
    const auto *state = bssl::FromOpaque(pair.client)->s3;
    check_spare(state->key_update_spare.get());
    // The pinned flush consumes pending_hs_data before failed flight storage.
    CHECK(!state->pending_hs_data);
    CHECK(state->pending_flight && state->pending_flight->length == 0);
    const HsFaultStats current = hs_fault_read();
    CHECK(current.injected == 1 && current.attempts == old.attempts + 2);
    CHECK(current.successful == old.successful + 1);
    CHECK(current.actual_frees == old.actual_frees);
    CHECK(current.live == old.live + 1);
    destroy_pair(&pair);
    check_released(2);
    ERR_clear_error();
}

enum CaseId {
    startup_failure_case, idempotent_case,
    pending_plaintext_case, pending_record_case, pending_write_case,
    queued_key_update_case, pending_flight_case, control_read_case, control_write_case,
    null_case, unfinished_case, dtls_case, quic_case, server_case, tls12_case,
    write_shutdown_case, read_shutdown_case, fatal_alert_case, clear_rehandshake_case, independent_contexts_case,
    preparation_failure_case, write_hook_failure_case,
    unknown_case,
};

struct CaseName {
    const char *name;
    CaseId id;
};

static CaseId parse_case(const char *name)
{
    static const CaseName names[] = {
        {"startup_failure", startup_failure_case},
        {"idempotent", idempotent_case}, {"pending_plaintext", pending_plaintext_case},
        {"pending_record", pending_record_case}, {"pending_write", pending_write_case},
        {"queued_key_update", queued_key_update_case}, {"pending_flight", pending_flight_case},
        {"control_read", control_read_case}, {"control_write", control_write_case},
        {"null", null_case}, {"unfinished", unfinished_case}, {"dtls_configured", dtls_case},
        {"quic_configured", quic_case}, {"server", server_case}, {"tls12_complete", tls12_case},
        {"write_shutdown", write_shutdown_case}, {"read_shutdown", read_shutdown_case},
        {"fatal_alert", fatal_alert_case},
        {"clear_rehandshake", clear_rehandshake_case}, {"independent_contexts", independent_contexts_case},
        {"preparation_failure", preparation_failure_case}, {"write_hook_failure", write_hook_failure_case},
    };
    for (const CaseName &entry : names) if (!strcmp(name, entry.name)) return entry.id;
    return unknown_case;
}

int main(int argc, char **argv)
{
    CHECK(argc == 5);
    CHECK(!SSL_reserve_key_update_context(nullptr));
    ERR_clear_error();
    switch (parse_case(argv[4])) {
        case startup_failure_case: failure(argv, 1); break;
        case idempotent_case: idempotent(argv); break;
        case pending_plaintext_case: pending_plaintext(argv); break;
        case pending_record_case: pending_record(argv); break;
        case pending_write_case: pending_write(argv); break;
        case queued_key_update_case: outgoing_key_update(argv, false); break;
        case pending_flight_case: outgoing_key_update(argv, true); break;
        case control_read_case: control_traffic(argv, true); break;
        case control_write_case: control_traffic(argv, false); break;
        case null_case: excluded_null(); break;
        case unfinished_case: excluded_configured(false, false); break;
        case dtls_case: excluded_configured(true, false); break;
        case quic_case: excluded_configured(false, true); break;
        case server_case: excluded_pair(argv, true); break;
        case tls12_case: excluded_pair(argv, false); break;
        case write_shutdown_case: shutdown_rejection(argv, false); break;
        case read_shutdown_case: shutdown_rejection(argv, true); break;
        case fatal_alert_case: fatal_alert_rejection(argv); break;
        case clear_rehandshake_case: clear_rehandshake(argv); break;
        case independent_contexts_case: independent_contexts(argv); break;
        case preparation_failure_case: preparation_failure(argv); break;
        case write_hook_failure_case: write_hook_failure(argv); break;
        case unknown_case: CHECK(false); break;
    }
    const HsFaultStats stats = hs_fault_read();
    printf("{\"case\":\"%s\",\"pass\":true,\"attempts\":%llu,\"successful\":%llu,"
        "\"injected\":%llu,\"live\":%llu,\"actual_frees\":%llu,\"cleanse_failures\":%llu,"
        "\"calloc\":%llu,\"realloc\":%llu,\"requested_bytes\":%llu}\n", argv[4],
        static_cast<unsigned long long>(stats.attempts),
        static_cast<unsigned long long>(stats.successful),
        static_cast<unsigned long long>(stats.injected),
        static_cast<unsigned long long>(stats.live),
        static_cast<unsigned long long>(stats.actual_frees),
        static_cast<unsigned long long>(stats.cleanse_failures),
        static_cast<unsigned long long>(stats.calloc_calls),
        static_cast<unsigned long long>(stats.realloc_calls),
        static_cast<unsigned long long>(stats.requested_bytes));
}
