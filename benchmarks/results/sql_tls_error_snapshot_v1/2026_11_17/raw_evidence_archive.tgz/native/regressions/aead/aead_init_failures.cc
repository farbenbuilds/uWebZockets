#include "aead_checks.h"
#include "aead_inject.h"

static void run_failure(bssl::SSLAEADContext *context, uint16_t suite,
                        evp_aead_direction_t direction, InitFaultMode mode)
{
    uint8_t key[32], iv[12];
    memset(key, 0x7d, sizeof(key));
    memset(iv, 0x63, sizeof(iv));
    const SSL_CIPHER *cipher = SSL_get_cipher_by_value(suite);
    const size_t key_size = suite == 0x1301 ? 16 : 32;
    init_fault_arm(mode, 0);
    uwz_alloc_begin();
    AEAD_CHECK(!bssl::SSLAEADContext::InitForKeyUpdate(context, direction, cipher,
        bssl::Span(key).first(key_size), iv));
    uwz_alloc_end();
    const AllocationCounts value = counts();
    check_zero(&value);
    const InitFaultObservation observed = init_fault_read();
    AEAD_CHECK(observed.armed_calls == 1 && observed.real_result == 1);
    AEAD_CHECK(observed.populated_inline_bytes > 0);
    AEAD_CHECK(observed.returned_null_aead == (mode == init_fault_null));
    check_empty(context);
    AEAD_CHECK(ERR_peek_error() != 0);
    ERR_clear_error();
    printf("{\"suite\":%u,\"direction\":\"%s\",\"forced_null_aead\":%s,"
        "\"real_initializer_populated_inline_state\":true,\"recovered_empty\":true,"
        "\"heap_operations\":0}\n", suite,
        direction == evp_aead_seal ? "seal" : "open",
        mode == init_fault_null ? "true" : "false");
}

int main()
{
    AEAD_CHECK(uwz_alloc_self_test());
    auto context = bssl::SSLAEADContext::CreateNullCipher();
    AEAD_CHECK(context);
    bssl::SSLAEADContext::ResetForKeyUpdate(context.get());
    // Prime the real error queue before injected complete-call accounting.
    uint8_t key[15] = {}, iv[12] = {};
    AEAD_CHECK(!bssl::SSLAEADContext::InitForKeyUpdate(context.get(), evp_aead_seal,
        SSL_get_cipher_by_value(0x1301), key, iv));
    ERR_clear_error();
    const uint16_t suites[] = {0x1301, 0x1302, 0x1303};
    for (uint16_t suite : suites) {
        run_failure(context.get(), suite, evp_aead_seal, init_fault_null);
        run_failure(context.get(), suite, evp_aead_open, init_fault_null);
        run_failure(context.get(), suite, evp_aead_seal, init_fault_live);
        run_failure(context.get(), suite, evp_aead_open, init_fault_live);
    }
    puts("PASS: 12 populated initializer failures preserve an empty reusable candidate; self-test63");
}
