/* Test-only fixed bookkeeping; never linked into production or ordinary counting. */
#include "hs_fault_alloc.h"
#include <errno.h>
#include <stdlib.h>
#include <string.h>

extern void *__libc_malloc(size_t size);
extern void *__libc_calloc(size_t count, size_t size);
extern void *__libc_realloc(void *pointer, size_t size);
extern void __libc_free(void *pointer);

struct AllocationRecord {
    void *pointer;
    size_t size;
    int live;
};

/* One process/OS-thread owns each fixture and its allocation records. */
static _Thread_local struct AllocationRecord records[32];
static _Thread_local size_t record_count;
static _Thread_local size_t fail_ordinal;
static _Thread_local size_t ordinal;
static _Thread_local int armed;
static _Thread_local struct HsFaultStats stats;

__attribute__((noinline)) void *malloc(size_t size)
{
    if (armed) {
        ordinal++;
        stats.attempts++;
        stats.requested_bytes += size;
        if (ordinal == fail_ordinal) {
            stats.injected++;
            errno = ENOMEM;
            return NULL;
        }
    }
    void *pointer = __libc_malloc(size);
    if (!armed || pointer == NULL) return pointer;
    if (record_count == 32) abort();
    records[record_count++] = (struct AllocationRecord){pointer, size, 1};
    stats.successful++;
    stats.live++;
    /* Nonzero full raw allocations make later cleansing observations real. */
    memset(pointer, 0xa5, size);
    return pointer;
}

__attribute__((noinline)) void *calloc(size_t count, size_t size)
{
    if (armed) stats.calloc_calls++;
    return __libc_calloc(count, size);
}

__attribute__((noinline)) void *realloc(void *pointer, size_t size)
{
    if (armed) stats.realloc_calls++;
    return __libc_realloc(pointer, size);
}

__attribute__((noinline)) void free(void *pointer)
{
    size_t matched = 32;
    for (size_t index = 0; index < record_count; index++) {
        if (!records[index].live || records[index].pointer != pointer) continue;
        matched = index;
        const volatile unsigned char *bytes = pointer;
        for (size_t offset = 0; offset < records[index].size; offset++) {
            if (bytes[offset] == 0) continue;
            stats.cleanse_failures++;
            break;
        }
        records[index].live = 0;
        stats.live--;
        break;
    }
    __libc_free(pointer);
    if (matched != 32) stats.actual_frees++;
}

void hs_fault_reset(void)
{
    if (armed || stats.live != 0) abort();
    memset(records, 0, sizeof(records));
    memset(&stats, 0, sizeof(stats));
    record_count = ordinal = fail_ordinal = 0;
}

void hs_fault_arm(size_t requested_ordinal)
{
    if (armed) abort();
    armed = 1;
    fail_ordinal = requested_ordinal;
    ordinal = 0;
}

void hs_fault_disarm(void)
{
    armed = 0;
    ordinal = fail_ordinal = 0;
}

struct HsFaultStats hs_fault_read(void) { return stats; }
