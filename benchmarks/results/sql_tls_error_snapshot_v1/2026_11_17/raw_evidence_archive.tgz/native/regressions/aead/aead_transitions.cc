#include "aead_pair.h"
#include "aead_checks.h"

struct InstalledSnapshot {
    uintptr_t read_context;
    uintptr_t write_context;
    uintptr_t cipher;
    uintptr_t candidate;
    uint8_t read_bytes[sizeof(bssl::SSLAEADContext)];
    uint8_t write_bytes[sizeof(bssl::SSLAEADContext)];
    uint8_t read_secret[SSL_MAX_MD_SIZE];
    uint8_t write_secret[SSL_MAX_MD_SIZE];
    size_t read_secret_length;
    size_t write_secret_length;
    uint64_t read_sequence;
    uint64_t write_sequence;
};

static void capture_installed(SSL *ssl, InstalledSnapshot *result)
{
    auto *state = bssl::FromOpaque(ssl)->s3;
    memset(result, 0, sizeof(*result));
    result->read_context = reinterpret_cast<uintptr_t>(state->aead_read_ctx.get());
    result->write_context = reinterpret_cast<uintptr_t>(state->aead_write_ctx.get());
    result->cipher = reinterpret_cast<uintptr_t>(state->key_update_cipher);
    result->candidate = reinterpret_cast<uintptr_t>(state->key_update_candidate);
    memcpy(result->read_bytes, state->aead_read_ctx.get(), sizeof(result->read_bytes));
    memcpy(result->write_bytes, state->aead_write_ctx.get(), sizeof(result->write_bytes));
    result->read_secret_length = state->read_traffic_secret.size();
    result->write_secret_length = state->write_traffic_secret.size();
    memcpy(result->read_secret, state->read_traffic_secret.data(), result->read_secret_length);
    memcpy(result->write_secret, state->write_traffic_secret.data(), result->write_secret_length);
    result->read_sequence = state->read_sequence;
    result->write_sequence = state->write_sequence;
}

static void check_object_set(bssl::SSL3_STATE *state, const uintptr_t *objects)
{
    const uintptr_t current[] = {reinterpret_cast<uintptr_t>(state->aead_read_ctx.get()),
        reinterpret_cast<uintptr_t>(state->aead_write_ctx.get()),
        reinterpret_cast<uintptr_t>(state->key_update_spare.get())};
    CHECK(current[0] != current[1] && current[0] != current[2] && current[1] != current[2]);
    for (uintptr_t pointer : current) {
        CHECK(pointer == objects[0] || pointer == objects[1] || pointer == objects[2]);
    }
    CHECK(state->key_update_candidate == nullptr);
    check_empty(state->key_update_spare.get());
}

static void reject_rotation_unchanged(SSL *ssl, evp_aead_direction_t direction)
{
    InstalledSnapshot before;
    capture_installed(ssl, &before);
    ERR_clear_error();
    uwz_alloc_begin();
    CHECK(!bssl::tls13_rotate_traffic_key(bssl::FromOpaque(ssl), direction));
    uwz_alloc_end();
    const AllocationCounts value = counts();
    check_zero(&value);
    InstalledSnapshot after;
    capture_installed(ssl, &after);
    CHECK(memcmp(&before, &after, sizeof(before)) == 0);
    OPENSSL_cleanse(&before, sizeof(before));
    OPENSSL_cleanse(&after, sizeof(after));
    ERR_clear_error();
}

static void unavailable_spare(SSL *ssl)
{
    auto *state = bssl::FromOpaque(ssl)->s3;
    auto held = std::move(state->key_update_spare);
    CHECK(held && !state->key_update_spare);
    reject_rotation_unchanged(ssl, evp_aead_open);
    reject_rotation_unchanged(ssl, evp_aead_seal);
    // Internal ownership-guard fixture; no parser state or peer data is staged.
    state->key_update_candidate = held.get();
    reject_rotation_unchanged(ssl, evp_aead_open);
    reject_rotation_unchanged(ssl, evp_aead_seal);
    state->key_update_candidate = nullptr;
    state->key_update_spare = std::move(held);
    check_empty(state->key_update_spare.get());
}

static void inconsistent_spare(SSL *ssl, uint16_t suite)
{
    auto *state = bssl::FromOpaque(ssl)->s3;
    uint8_t key[32], iv[12];
    memset(key, 0x37, sizeof(key));
    memset(iv, 0x75, sizeof(iv));
    CHECK(bssl::SSLAEADContext::InitForKeyUpdate(state->key_update_spare.get(), evp_aead_seal,
        state->key_update_cipher, bssl::Span(key).first(suite == 0x1301 ? 16 : 32), iv));
    reject_rotation_unchanged(ssl, evp_aead_open);
    reject_rotation_unchanged(ssl, evp_aead_seal);
    bssl::SSLAEADContext::ResetForKeyUpdate(state->key_update_spare.get());
    check_empty(state->key_update_spare.get());
    OPENSSL_cleanse(key, sizeof(key));
    OPENSSL_cleanse(iv, sizeof(iv));
}

static void run_suite(char **arguments, uint16_t suite)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024, suite);
    uwz_alloc_begin();
    CHECK(SSL_reserve_key_update_context(pair.client));
    uwz_alloc_end();
    const AllocationCounts startup = counts();
    CHECK(startup.malloc_calls == 1 && startup.bytes == 608);
    CHECK(startup.calloc_calls == 0 && startup.realloc_calls == 0 && startup.free_calls == 0);
    auto *state = bssl::FromOpaque(pair.client)->s3;
    const uintptr_t objects[] = {reinterpret_cast<uintptr_t>(state->aead_read_ctx.get()),
        reinterpret_cast<uintptr_t>(state->aead_write_ctx.get()),
        reinterpret_cast<uintptr_t>(state->key_update_spare.get())};
    check_object_set(state, objects);
    for (unsigned epoch = 0; epoch < 8; epoch++) {
        uwz_alloc_begin();
        CHECK(bssl::tls13_rotate_traffic_key(bssl::FromOpaque(pair.client), evp_aead_open));
        uwz_alloc_end();
        AllocationCounts value = counts();
        check_zero(&value);
        CHECK(state->read_sequence == 0);
        check_object_set(state, objects);
        uwz_alloc_begin();
        CHECK(bssl::tls13_rotate_traffic_key(bssl::FromOpaque(pair.client), evp_aead_seal));
        uwz_alloc_end();
        value = counts();
        check_zero(&value);
        CHECK(state->write_sequence == 0);
        check_object_set(state, objects);
    }
    unavailable_spare(pair.client);
    inconsistent_spare(pair.client, suite);
    check_object_set(state, objects);
    printf("{\"scope\":\"direct_key_install_helpers_after_verified_TLS13\",\"suite\":%u,"
        "\"transitions\":16,\"owned_contexts\":3,\"no_alias_or_growth\":true,"
        "\"zero_transition_heap_operations\":true,\"missing_busy_inconsistent_guards\":true,"
        "\"startup_malloc\":1,\"startup_bytes\":608,\"context_bytes\":600,"
        "\"sizeof_ssl3_state\":%zu}\n", suite, sizeof(bssl::SSL3_STATE));
    destroy_pair(&pair);
}

int main(int argc, char **argv)
{
    CHECK(argc == 4);
    CHECK(uwz_alloc_self_test());
    CHECK(!SSL_reserve_key_update_context(nullptr));
    ERR_clear_error();
    const uint16_t suites[] = {0x1301, 0x1302, 0x1303};
    for (uint16_t suite : suites) run_suite(argv, suite);
    puts("PASS: 48 direct transitions retain exactly three contexts and cleanse reclaimed objects; unavailable/busy/inconsistent profiles never allocate fallback");
}
