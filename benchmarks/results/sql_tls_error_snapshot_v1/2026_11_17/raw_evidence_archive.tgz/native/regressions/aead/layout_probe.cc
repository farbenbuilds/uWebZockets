#include <ssl/internal.h>
#include <stdio.h>

int main()
{
    printf("context=%zu evp=%zu state=%zu\n", sizeof(bssl::SSLAEADContext),
        sizeof(EVP_AEAD_CTX), sizeof(bssl::SSL3_STATE));
}
