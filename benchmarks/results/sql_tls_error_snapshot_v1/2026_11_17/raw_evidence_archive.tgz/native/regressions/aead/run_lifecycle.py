#!/usr/bin/env python3
"""Run normal direct key transitions and separately injected AEAD lifecycle cases."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess

CASES = ('startup_failure', 'idempotent', 'pending_plaintext', 'pending_record',
    'pending_write', 'queued_key_update', 'pending_flight', 'control_read', 'control_write',
    'null', 'unfinished', 'dtls_configured', 'quic_configured', 'server', 'tls12_complete',
    'write_shutdown', 'read_shutdown', 'fatal_alert', 'clear_rehandshake',
    'independent_contexts', 'preparation_failure', 'write_hook_failure')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('pki_tool', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--zig', default='/tmp/zig-x86_64-linux-0.16.0/zig')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    native = args.native_root.resolve(strict=True)
    tool = args.pki_tool.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    if sha(tool) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('PKI helper differs')
    output.mkdir(mode=0o700)
    environment = dict(os.environ)
    environment['ZIG_GLOBAL_CACHE_DIR'] = '/tmp/uwz-zig-cache'
    commands = []
    rows = []
    complete = False

    def run(command, stem):
        with (output / (stem + '.stdout')).open('wb') as stdout, \
             (output / (stem + '.stderr')).open('wb') as stderr:
            result = subprocess.run(command, cwd=output, env=environment,
                                    stdout=stdout, stderr=stderr)
        commands.append({'command': command, 'exit_code': result.returncode, 'stem': stem})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode != 0:
            raise RuntimeError('Command failed: ' + str(output / stem))

    archives = [native / 'native_out/lib/libssl.a', native / 'native_out/lib/libcrypto.a']
    sources = ['aead_pair.h', 'aead_checks.h', 'aead_transitions.cc', 'aead_lifecycle.cc',
        'aead_inject.c', 'aead_inject.h', 'hs_fault_alloc.c', 'hs_fault_alloc.h', 'allocation_scope.c']
    (output / 'provenance.json').write_text(json.dumps({
        'native_archives': {p.name: sha(p) for p in archives},
        'source_sha256': {name: sha(base / name) for name in sources},
        'optimization': 'Debug (-O0 -g)',
        'normal_transition_binary_wrapped_or_fault_interposed': False,
        'lifecycle_binary_uses_separate_test_observer_and_initializer_wrapper': True,
    }, indent=2) + '\n')
    for stem in ['allocation_scope', 'hs_fault_alloc', 'aead_inject']:
        run([args.zig, 'cc', '-std=c11', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
             '-fno-builtin-malloc', '-fno-builtin-calloc', '-fno-builtin-realloc', '-fno-builtin-free',
             '-isystem', str(native / 'boringssl/include'), '-c', str(base / (stem + '.c')),
             '-o', str(output / (stem + '.o'))], 'build-' + stem)
    common = [args.zig, 'c++', '-std=c++17', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
        '-DBORINGSSL_IMPLEMENTATION', '-isystem', str(native / 'boringssl'),
        '-isystem', str(native / 'boringssl/include')]
    run([*common, str(base / 'aead_transitions.cc'), str(output / 'allocation_scope.o'),
         *[str(p) for p in archives], '-o', str(output / 'aead_transitions')], 'link-transitions')
    run([*common, '-c', str(base / 'aead_lifecycle.cc'), '-o', str(output / 'aead_lifecycle.o')],
        'compile-lifecycle')
    run([*common, str(base / 'layout_probe.cc'), '-v', '-o', str(output / 'layout_link_probe')],
        'link-template')
    linker_line = next(line for line in (output / 'link-template.stderr').read_text().splitlines()
        if line.startswith('ld.lld '))
    arguments = shlex.split(linker_line)[1:]
    arguments[arguments.index('-o') + 1] = str(output / 'aead_lifecycle')
    # The driver emits a cached object for the sole source; replace that object.
    candidates = [index for index, token in enumerate(arguments)
        if token.endswith('.o') and Path(token).name not in ('crt1.o', 'crti.o', 'crtn.o')]
    if len(candidates) != 1:
        raise ValueError('Unexpected driver object inventory')
    index = candidates[0]
    arguments[index:index + 1] = [str(output / 'aead_lifecycle.o'),
        str(output / 'hs_fault_alloc.o'), str(output / 'aead_inject.o'), *[str(p) for p in archives]]
    run([args.zig, 'ld.lld', *arguments,
         '--wrap=EVP_AEAD_CTX_init_with_direction'], 'link-lifecycle')
    pki = output / 'private_pki'
    try:
        run([str(tool), 'pki', str(pki)], 'pki_metadata')
        fixture = [str(pki / name) for name in ['server.pem', 'server.key', 'ca.pem']]
        run([str(output / 'aead_transitions'), *fixture], 'transitions')
        for name in CASES:
            run([str(output / 'aead_lifecycle'), *fixture, name], name)
            result = json.loads((output / (name + '.stdout')).read_text())
            if result['case'] != name or result['pass'] is not True:
                raise ValueError('Unexpected lifecycle output: ' + name)
            rows.append({'case': name, 'result': result,
                'stdout_sha256': sha(output / (name + '.stdout')),
                'stderr_sha256': sha(output / (name + '.stderr'))})
        complete = True
    finally:
        if pki.exists():
            names = {p.name for p in pki.iterdir()}
            if names - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected private fixture output')
            for name in names:
                (pki / name).unlink()
            pki.rmdir()
        (output / 'results.json').write_text(json.dumps({'complete': complete,
            'rows': rows, 'private_pki_removed': not pki.exists(),
            'binary_sha256': sha(output / 'aead_lifecycle')}, indent=2) + '\n')
    print('PASS: 48 normal direct transitions and ' + str(len(rows)) + ' lifecycle/failure cases')


if __name__ == '__main__':
    main()
