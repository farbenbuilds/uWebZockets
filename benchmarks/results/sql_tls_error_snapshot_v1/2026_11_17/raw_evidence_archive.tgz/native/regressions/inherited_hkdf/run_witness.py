#!/usr/bin/env python3
"""Compile one immutable witness against a specified complete native build."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--zig', default='/tmp/zig-x86_64-linux-0.16.0/zig')
    args = parser.parse_args()
    source = Path(__file__).resolve().parent
    native = args.native_root.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    output.mkdir()
    environment = dict(os.environ)
    environment['ZIG_GLOBAL_CACHE_DIR'] = '/tmp/uwz-zig-cache'
    commands = []

    def run(command, stem, expected=0):
        with (output / (stem + '.stdout')).open('w') as stdout, (output / (stem + '.stderr')).open('w') as stderr:
            result = subprocess.run(command, cwd=output, env=environment,
                                    stdout=stdout, stderr=stderr)
        commands.append({'command': command, 'exit_code': result.returncode,
                         'expected_exit_code': expected, 'stem': stem})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode != expected:
            raise RuntimeError('Unexpected status; see ' + str(output / stem))

    crypto = native / 'native_out/lib/libcrypto.a'
    source_file = native / 'boringssl/crypto/fipsmodule/tls/kdf.cc.inc'
    provenance = {'native_root': str(native), 'crypto_archive_sha256': sha(crypto),
                  'native_source_sha256': sha(source_file),
                  'witness_sha256': sha(source / 'hkdf_witness.cc'),
                  'interposer_sha256': sha(source / 'allocation_scope.c'),
                  'optimization': 'Debug (-O0 -g)', 'compiler': args.zig}
    (output / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    run([args.zig, 'cc', '-c', str(source / 'allocation_scope.c'), '-O0', '-g',
         '-fno-omit-frame-pointer', '-o', str(output / 'allocation_scope.o')], 'build-counter')
    run([args.zig, 'c++', '-std=c++17', '-O0', '-g', '-fno-omit-frame-pointer',
         '-Wall', '-Wextra', '-Werror', '-I', str(native / 'boringssl/include'),
         '-I', str(native / 'boringssl'), str(source / 'hkdf_witness.cc'),
         str(output / 'allocation_scope.o'), str(crypto), '-o', str(output / 'hkdf_witness')],
        'build-witness')
    run([str(output / 'hkdf_witness'), '--observe'], 'observe')
    rows = [json.loads(row) for row in (output / 'observe.stdout').read_text().splitlines()]
    allocating = sum(row['result'] == 1 and any(row[key] for key in
        ['malloc', 'calloc', 'realloc', 'free', 'requested_bytes']) for row in rows)
    run([str(output / 'hkdf_witness'), '--require-zero'], 'require-zero', 1 if allocating else 0)
    (output / 'binary.sha256').write_text(sha(output / 'hkdf_witness') + '  hkdf_witness\n')
    print(json.dumps({'cases': len(rows), 'allocating_successes': allocating,
                      'require_zero_exit': 1 if allocating else 0}))


if __name__ == '__main__':
    main()
