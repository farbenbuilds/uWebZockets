#include <openssl/digest.h>
#include <openssl/err.h>
#include <openssl/hkdf.h>
#include <openssl/sha.h>
#include "crypto/fipsmodule/tls/internal.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

struct allocation_counts {
    uint64_t malloc_calls;
    uint64_t calloc_calls;
    uint64_t realloc_calls;
    uint64_t free_calls;
    uint64_t bytes;
};

struct error_codes {
    uint32_t values[32];
    size_t count;
};

// A fixed digest constructor accepted by the KDF boundary fixture.
using digest_function = const EVP_MD *(*)(void);

struct digest_case {
    const char *name;
    digest_function function;
};

struct test_inputs {
    uint8_t secret[64];
    uint8_t label[250];
    uint8_t context[256];
};

static void check(bool value, const char *expression, int line)
{
    if (value) return;
    fprintf(stderr, "check failed at %d: %s\n", line, expression);
    ERR_print_errors_fp(stderr);
    abort();
}

#define CHECK(value) check((value), #value, __LINE__)

static allocation_counts snapshot(void)
{
    return {uwz_alloc_malloc_calls(), uwz_alloc_calloc_calls(),
            uwz_alloc_realloc_calls(), uwz_alloc_free_calls(),
            uwz_alloc_requested_bytes()};
}

static error_codes drain_errors(void)
{
    error_codes result = {};
    uint32_t value;
    while ((value = ERR_get_error()) != 0) {
        CHECK(result.count < 32);
        result.values[result.count++] =
            (static_cast<uint32_t>(ERR_GET_LIB(value)) << 24) |
            static_cast<uint32_t>(ERR_GET_REASON(value));
    }
    return result;
}

static bool same_errors(const error_codes *left, const error_codes *right)
{
    return left->count == right->count &&
        memcmp(left->values, right->values,
               left->count * sizeof(left->values[0])) == 0;
}

static bool sentinel_range(const uint8_t *output, size_t start, size_t end)
{
    for (size_t index = start; index < end; index++) {
        if (output[index] != 0xa5) return false;
    }
    return true;
}

static size_t encode_label(uint8_t *encoded, size_t output_length,
                          const test_inputs *inputs, size_t label_length,
                          size_t context_length)
{
    static const uint8_t prefix[] = {'t', 'l', 's', '1', '3', ' '};
    CHECK(label_length <= 249 && context_length <= 255);
    const uint16_t narrowed = static_cast<uint16_t>(output_length);
    encoded[0] = narrowed >> 8;
    encoded[1] = narrowed & 255;
    encoded[2] = static_cast<uint8_t>(sizeof(prefix) + label_length);
    memcpy(encoded + 3, prefix, sizeof(prefix));
    memcpy(encoded + 3 + sizeof(prefix), inputs->label, label_length);
    const size_t context_offset = 3 + sizeof(prefix) + label_length;
    encoded[context_offset] = static_cast<uint8_t>(context_length);
    memcpy(encoded + context_offset + 1, inputs->context, context_length);
    return context_offset + 1 + context_length;
}

static void print_errors(const error_codes *errors)
{
    putchar('[');
    for (size_t index = 0; index < errors->count; index++) {
        if (index != 0) putchar(',');
        printf("%u", errors->values[index]);
    }
    putchar(']');
}

static void print_hash(const uint8_t *output, size_t length)
{
    uint8_t hash[SHA256_DIGEST_LENGTH];
    CHECK(SHA256(output, length, hash) != nullptr);
    for (size_t index = 0; index < sizeof(hash); index++) printf("%02x", hash[index]);
}

static bool run_case(const digest_case *digest, const test_inputs *inputs,
                     size_t label_length, size_t context_length,
                     size_t output_length, size_t case_id)
{
    uint8_t output[65568];
    uint8_t reference[sizeof(output)];
    uint8_t encoded[514];
    const EVP_MD *algorithm = digest->function();
    const bool encoding_valid = label_length <= 249 && context_length <= 255;
    const size_t secret_length = EVP_MD_size(algorithm);
    memset(output, 0xa5, sizeof(output));
    memset(reference, 0xa5, sizeof(reference));
    CHECK(output_length <= 65536);
    ERR_clear_error();
    uwz_alloc_begin();
    const int result = bssl::CRYPTO_tls13_hkdf_expand_label(
        output, output_length, algorithm, inputs->secret, secret_length,
        inputs->label, label_length, inputs->context, context_length);
    uwz_alloc_end();
    const allocation_counts counts = snapshot();
    const error_codes errors = drain_errors();
    CHECK(sentinel_range(output, output_length, sizeof(output)));
    if (encoding_valid) {
        const size_t encoded_length = encode_label(encoded, output_length,
            inputs, label_length, context_length);
        ERR_clear_error();
        const int expected = HKDF_expand(reference, output_length, algorithm,
            inputs->secret, secret_length, encoded, encoded_length);
        const error_codes reference_errors = drain_errors();
        CHECK(result == expected);
        CHECK(memcmp(output, reference, sizeof(output)) == 0);
        CHECK(same_errors(&errors, &reference_errors));
    } else {
        CHECK(result == 0);
        CHECK(sentinel_range(output, 0, sizeof(output)));
        CHECK(errors.count != 0);
    }
    printf("{\"case\":%zu,\"digest\":\"%s\",\"label_length\":%zu,"
           "\"context_length\":%zu,\"output_length\":%zu,\"result\":%d,"
           "\"encoding_valid\":%s,\"errors\":",
           case_id, digest->name, label_length, context_length, output_length,
           result, encoding_valid ? "true" : "false");
    print_errors(&errors);
    printf(",\"buffer_sha256\":\"");
    print_hash(output, sizeof(output));
    printf("\",\"malloc\":%llu,\"calloc\":%llu,\"realloc\":%llu,"
           "\"free\":%llu,\"requested_bytes\":%llu}\n",
           static_cast<unsigned long long>(counts.malloc_calls),
           static_cast<unsigned long long>(counts.calloc_calls),
           static_cast<unsigned long long>(counts.realloc_calls),
           static_cast<unsigned long long>(counts.free_calls),
           static_cast<unsigned long long>(counts.bytes));
    return result == 0 ||
        (counts.malloc_calls == 0 && counts.calloc_calls == 0 &&
         counts.realloc_calls == 0 && counts.free_calls == 0 && counts.bytes == 0);
}

static size_t run_digest(const digest_case *digest, const test_inputs *inputs,
                         size_t *case_id)
{
    const size_t label_lengths[] = {0, 1, 7, 248, 249, 250};
    const size_t context_lengths[] = {0, 1, 32, 254, 255, 256};
    const size_t digest_size = EVP_MD_size(digest->function());
    const size_t output_lengths[] = {0, 1, digest_size - 1, digest_size,
        digest_size + 1, 2 * digest_size, 255 * digest_size,
        255 * digest_size + 1, 65535, 65536};
    size_t allocating_successes = 0;
    for (size_t label_length : label_lengths) {
        for (size_t context_length : context_lengths) {
            for (size_t output_length : output_lengths) {
                if (!run_case(digest, inputs, label_length, context_length,
                              output_length, (*case_id)++)) allocating_successes++;
            }
        }
    }
    return allocating_successes;
}

int main(int argc, char **argv)
{
    CHECK(argc == 2);
    const bool require_zero = strcmp(argv[1], "--require-zero") == 0;
    CHECK(require_zero || strcmp(argv[1], "--observe") == 0);
    CHECK(uwz_alloc_self_test());
    fprintf(stderr, "interposer_self_test: malloc=1 calloc=1 realloc=1 free=2 bytes=63 PASS\n");
    const digest_case digests[] = {{"SHA1", EVP_sha1}, {"SHA256", EVP_sha256},
        {"SHA384", EVP_sha384}, {"SHA512", EVP_sha512}};
    test_inputs inputs = {};
    for (size_t index = 0; index < sizeof(inputs.secret); index++) inputs.secret[index] = index * 3 + 1;
    for (size_t index = 0; index < sizeof(inputs.label); index++) inputs.label[index] = index * 7;
    for (size_t index = 0; index < sizeof(inputs.context); index++) inputs.context[index] = index * 11;
    // Prime digest dispatch and the error queue before accounting any case.
    uint8_t warm[64];
    for (const digest_case &digest : digests) {
        CHECK(bssl::CRYPTO_tls13_hkdf_expand_label(warm, 1, digest.function(),
            inputs.secret, 16, inputs.label, 1, inputs.context, 1));
        CHECK(!HKDF_expand(warm, 65536, digest.function(), inputs.secret, 16,
            inputs.context, 1));
        ERR_clear_error();
    }
    size_t cases = 0;
    size_t allocating_successes = 0;
    for (const digest_case &digest : digests) {
        allocating_successes += run_digest(&digest, &inputs, &cases);
    }
    fprintf(stderr, "cases=%zu allocating_successes=%zu reference_checks=PASS\n",
        cases, allocating_successes);
    if (require_zero && allocating_successes != 0) return 1;
    return 0;
}
