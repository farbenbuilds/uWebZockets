#!/usr/bin/env python3
"""Check baseline/candidate behavior equivalence and the strict KDF allocation gate."""
import argparse
import hashlib
import json
from pathlib import Path


def compare(baseline, candidate):
    left = [json.loads(row) for row in baseline.read_text().splitlines()]
    right = [json.loads(row) for row in candidate.read_text().splitlines()]
    semantic_fields = ('case', 'digest', 'label_length', 'context_length',
                       'output_length', 'result', 'encoding_valid', 'errors',
                       'buffer_sha256')
    counters = ('malloc', 'calloc', 'realloc', 'free', 'requested_bytes')
    assert len(left) == len(right) == 1440
    assert {row['digest'] for row in left} == {'SHA1', 'SHA256', 'SHA384', 'SHA512'}
    assert [row['case'] for row in left] == list(range(1440))
    successful = 0
    rejected = 0
    for before, after in zip(left, right):
        assert {key: before[key] for key in semantic_fields} == {
            key: after[key] for key in semantic_fields}, before['case']
        assert all(after[key] >= 0 for key in counters)
        if after['result'] != 1:
            rejected += 1
            continue
        successful += 1
        assert (before['malloc'], before['calloc'], before['realloc'], before['free']) == (1, 0, 0, 1)
        assert before['requested_bytes'] == 18 + before['label_length'] + before['context_length']
        assert all(after[key] == 0 for key in counters), after['case']
    assert successful == 700 and rejected == 740
    for digest in ('SHA1', 'SHA256', 'SHA384', 'SHA512'):
        assert any(row['digest'] == digest and row['label_length'] == 249 and
                   row['context_length'] == 255 and row['result'] == 1 for row in right)
    return {'cases': len(left), 'successful_cases': successful,
            'rejected_cases': rejected, 'semantic_equality': True,
            'full_buffer_bytes_hashed_per_case': 65568,
            'candidate_successes_allocate_or_free': False,
            'invalid_path_allocation_is_zero_claimed': False,
            'baseline_sha256': hashlib.sha256(baseline.read_bytes()).hexdigest(),
            'candidate_sha256': hashlib.sha256(candidate.read_bytes()).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('candidate', type=Path)
    args = parser.parse_args()
    print(json.dumps(compare(args.baseline, args.candidate), indent=2))


if __name__ == '__main__':
    main()
