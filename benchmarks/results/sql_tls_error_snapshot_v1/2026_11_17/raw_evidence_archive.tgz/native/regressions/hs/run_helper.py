#!/usr/bin/env python3
"""Build and run the direct handshake-buffer helper with explicit reservation mode."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('pki_tool', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--reserved', action='store_true')
    parser.add_argument('--zig', default='/tmp/zig-x86_64-linux-0.16.0/zig')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    native = args.native_root.resolve(strict=True)
    tool = args.pki_tool.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    if sha(tool) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('PKI helper differs')
    output.mkdir(mode=0o700)
    environment = dict(os.environ)
    environment['ZIG_GLOBAL_CACHE_DIR'] = '/tmp/uwz-zig-cache'
    commands = []

    def run(command, stem, expected=0):
        with (output / (stem + '.stdout')).open('wb') as stdout, \
             (output / (stem + '.stderr')).open('wb') as stderr:
            result = subprocess.run(command, cwd=output, env=environment,
                                    stdout=stdout, stderr=stderr)
        commands.append({'command': command, 'exit_code': result.returncode,
                         'expected_exit_code': expected, 'stem': stem})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode != expected:
            raise RuntimeError('Unexpected command status; see ' + str(output / stem))

    archives = [native / 'native_out/lib/libssl.a', native / 'native_out/lib/libcrypto.a']
    provenance = {'reserved': args.reserved, 'native_root': str(native),
        'native_archives': {p.name: sha(p) for p in archives},
        'source_sha256': {name: sha(base / name) for name in
            ['hs_pair.h', 'hs_buffer_helper.cc', 'allocation_scope.c']},
        'native_source_sha256': {name: sha(native / 'boringssl' / name) for name in
            ['include/openssl/ssl.h', 'ssl/internal.h', 'ssl/ssl_lib.cc', 'ssl/s3_both.cc']},
        'optimization': 'Debug (-O0 -g)'}
    (output / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    run([args.zig, 'cc', '-c', str(base / 'allocation_scope.c'), '-O0', '-g',
         '-fno-omit-frame-pointer', '-o', str(output / 'allocation_scope.o')], 'build-counter')
    run([args.zig, 'c++', '-std=c++17', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
         '-DBORINGSSL_IMPLEMENTATION', '-DUWZ_HS_RESERVATION=' + str(int(args.reserved)),
         '-isystem', str(native / 'boringssl'), '-isystem', str(native / 'boringssl/include'),
         str(base / 'hs_buffer_helper.cc'), str(output / 'allocation_scope.o'),
         *[str(p) for p in archives], '-o', str(output / 'hs_buffer_helper')], 'build-helper')
    pki = output / 'private_pki'
    try:
        run([str(tool), 'pki', str(pki)], 'pki_metadata')
        arguments = [str(pki / name) for name in ['server.pem', 'server.key', 'ca.pem']]
        run([str(output / 'hs_buffer_helper'), *arguments, '--observe'], 'observe')
        run([str(output / 'hs_buffer_helper'), *arguments, '--require-zero'],
            'require-zero', 0 if args.reserved else 1)
    finally:
        if pki.exists():
            names = {p.name for p in pki.iterdir()}
            if names - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected private fixture output')
            for name in names:
                (pki / name).unlink()
            pki.rmdir()
    print((output / 'observe.stdout').read_text(), end='')


if __name__ == '__main__':
    main()
