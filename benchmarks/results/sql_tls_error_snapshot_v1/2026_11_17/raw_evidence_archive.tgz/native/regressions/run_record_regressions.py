#!/usr/bin/env python3
"""Rebuild unchanged record-reservation witnesses against the new native state layout."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('pki_tool', type=Path)
    parser.add_argument('--zig', default='/tmp/zig-x86_64-linux-0.16.0/zig')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    native = args.native_root.resolve(strict=True)
    source = base / 'inherited_record'
    tool = args.pki_tool.resolve(strict=True)
    if sha(tool) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('PKI helper differs')
    generated = ['build', 'results', 'lifecycle_test', 'buffer_test', 'tls_pair_test', 'private_pki']
    if any((source / name).exists() or (source / name).is_symlink() for name in generated):
        raise ValueError('Refusing to overwrite inherited witness output')
    output = source / 'build'
    output.mkdir()
    environment = dict(os.environ)
    environment['ZIG_GLOBAL_CACHE_DIR'] = '/tmp/uwz-zig-cache'
    commands = []

    def run(command, stem):
        with (output / (stem + '.log')).open('wb') as stream:
            result = subprocess.run(command, cwd=base, env=environment,
                                    stdout=stream, stderr=subprocess.STDOUT)
        commands.append({'command': command, 'exit_code': result.returncode, 'stem': stem})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode != 0:
            raise RuntimeError('Command failed: ' + str(output / stem))

    archives = [native / 'native_out/lib/libssl.a', native / 'native_out/lib/libcrypto.a']
    (output / 'provenance.json').write_text(json.dumps({
        'native_archive_sha256': {p.name: sha(p) for p in archives},
        'source_sha256': {p.name: sha(p) for p in source.iterdir() if p.is_file()},
        'optimization': 'Debug (-O0 -g)',
        'whole_native_archive_abi_rebuild': True,
    }, indent=2) + '\n')
    for stem in ['lifecycle_alloc', 'buffer_allocation_scope', 'cleansed_free_hook']:
        run([args.zig, 'cc', '-std=c11', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
             '-fno-builtin-malloc', '-fno-builtin-calloc', '-fno-builtin-realloc', '-fno-builtin-free',
             '-c', str(source / (stem + '.c')), '-o', str(output / (stem + '.o'))], 'build-' + stem)
    common = [args.zig, 'c++', '-std=c++17', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
        '-DBORINGSSL_IMPLEMENTATION', '-isystem', str(native), '-isystem', str(native / 'boringssl'),
        '-isystem', str(native / 'boringssl/include')]
    run([*common, str(source / 'lifecycle_test.cc'), str(output / 'lifecycle_alloc.o'),
         *[str(p) for p in archives], '-o', str(source / 'lifecycle_test')], 'link-lifecycle')
    for stem in ['buffer_test', 'tls_pair_test']:
        run([*common, str(source / (stem + '.cc')), str(output / 'buffer_allocation_scope.o'),
             str(output / 'cleansed_free_hook.o'), *[str(p) for p in archives],
             '-o', str(source / stem)], 'link-' + stem)
    pki = source / 'private_pki'
    try:
        run([str(tool), 'pki', str(pki)], 'pki_metadata')
        run([sys.executable, str(source / 'run_cases.py'), '--pki', str(pki),
             '--output', str(source / 'results')], 'lifecycle-driver')
        run([str(source / 'buffer_test')], 'buffer_test')
        run([str(source / 'tls_pair_test'),
             *[str(pki / name) for name in ['server.pem', 'server.key', 'ca.pem']]], 'tls_pair_test')
    finally:
        if pki.exists():
            names = {p.name for p in pki.iterdir()}
            if names - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected private fixture output')
            for name in names:
                (pki / name).unlink()
            pki.rmdir()
    print('PASS: unchanged inherited 16 record-lifecycle cases, buffer and TLS-pair witnesses')


if __name__ == '__main__':
    main()
