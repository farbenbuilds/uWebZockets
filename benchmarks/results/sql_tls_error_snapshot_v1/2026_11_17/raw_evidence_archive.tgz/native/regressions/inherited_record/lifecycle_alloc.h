#ifndef UWZ_LIFECYCLE_ALLOC_H
#define UWZ_LIFECYCLE_ALLOC_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

struct uwz_fault_stats {
    uint64_t attempts;
    uint64_t successful;
    uint64_t injected;
    uint64_t live;
    uint64_t actual_frees;
    uint64_t cleanse_failures;
};

void uwz_fault_reset(void);
void uwz_fault_arm(size_t ordinal);
void uwz_fault_disarm(void);
struct uwz_fault_stats uwz_fault_read(void);
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);

#ifdef __cplusplus
}
#endif
#endif
