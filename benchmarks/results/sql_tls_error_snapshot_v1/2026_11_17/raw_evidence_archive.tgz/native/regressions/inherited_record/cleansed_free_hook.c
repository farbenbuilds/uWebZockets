#include <stddef.h>
#include <stdint.h>

static _Thread_local const volatile uint8_t *expected;
static _Thread_local size_t expected_length;
static _Thread_local int observed;

void uwz_expect_cleansed_free(void *pointer, size_t length)
{
    expected = pointer;
    expected_length = length;
    observed = 0;
}

void uwz_check_cleansed_free(void *pointer)
{
    if (pointer != (const void *)expected) return;
    observed = 1;
    for (size_t i = 0; i < expected_length; i++) {
        if (expected[i] != 0) observed = -1;
    }
    expected = NULL;
    expected_length = 0;
}

int uwz_cleansed_free_observed(void) { return observed == 1; }
