#include "boringssl/ssl/internal.h"
#include <openssl/err.h>
#include <openssl/x509_vfy.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK(expr) do { if (!(expr)) { fprintf(stderr, "check failed line %d\n", __LINE__); abort(); } } while (0)

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

static bool retry(SSL *ssl, int result) {
  const int error = SSL_get_error(ssl, result);
  return error == SSL_ERROR_WANT_READ || error == SSL_ERROR_WANT_WRITE;
}

int main(int argc, char **argv) {
  CHECK(argc == 4);
  CHECK(uwz_alloc_self_test());
  SSL_CTX *server_context = SSL_CTX_new(TLS_method());
  SSL_CTX *client_context = SSL_CTX_new(TLS_method());
  CHECK(server_context != nullptr && client_context != nullptr);
  CHECK(SSL_CTX_set_min_proto_version(server_context, TLS1_3_VERSION));
  CHECK(SSL_CTX_set_max_proto_version(server_context, TLS1_3_VERSION));
  CHECK(SSL_CTX_set_min_proto_version(client_context, TLS1_3_VERSION));
  CHECK(SSL_CTX_set_max_proto_version(client_context, TLS1_3_VERSION));
  CHECK(SSL_CTX_set_num_tickets(server_context, 0));
  CHECK(SSL_CTX_use_certificate_chain_file(server_context, argv[1]));
  CHECK(SSL_CTX_use_PrivateKey_file(server_context, argv[2], SSL_FILETYPE_PEM));
  CHECK(SSL_CTX_check_private_key(server_context));
  CHECK(SSL_CTX_load_verify_locations(client_context, argv[3], nullptr));
  SSL_CTX_set_verify(client_context, SSL_VERIFY_PEER, nullptr);
  SSL *client = SSL_new(client_context);
  SSL *server = SSL_new(server_context);
  CHECK(client != nullptr && server != nullptr);
  CHECK(SSL_set_tlsext_host_name(client, "localhost"));
  CHECK(SSL_set1_host(client, "localhost"));
  SSL_set_connect_state(client);
  SSL_set_accept_state(server);
  BIO *client_bio = nullptr;
  BIO *server_bio = nullptr;
  CHECK(BIO_new_bio_pair(&client_bio, 1024, &server_bio, 1024));
  SSL_set_bio(client, client_bio, client_bio);
  SSL_set_bio(server, server_bio, server_bio);
  bool client_done = false;
  bool server_done = false;
  for (size_t i = 0; i < 10000 && (!client_done || !server_done); i++) {
    if (!client_done) {
      int result = SSL_do_handshake(client);
      if (result == 1) client_done = true;
      else CHECK(retry(client, result));
    }
    if (!server_done) {
      int result = SSL_do_handshake(server);
      if (result == 1) server_done = true;
      else CHECK(retry(server, result));
    }
  }
  CHECK(client_done && server_done);
  CHECK(SSL_version(client) == TLS1_3_VERSION);
  CHECK(SSL_get_verify_result(client) == X509_V_OK);
  CHECK(SSL_get0_peer_certificates(client) != nullptr);
  uwz_alloc_begin();
  CHECK(SSL_reserve_record_buffers(client));
  CHECK(SSL_reserve_record_buffers(server));
  uwz_alloc_end();
  CHECK(uwz_alloc_malloc_calls() == 4);
  CHECK(uwz_alloc_requested_bytes() == 262140);

  uint8_t input[16384];
  uint8_t output[16384];
  const size_t lengths[] = {1, 5, 127, 1024, 4096, 16383, 16384};
  for (size_t length : lengths) {
    for (size_t i = 0; i < length; i++) input[i] = static_cast<uint8_t>(i);
    bool written = false;
    size_t received = 0;
    uwz_alloc_begin();
    for (size_t i = 0; i < 10000 && (!written || received != length); i++) {
      if (!written) {
        int result = SSL_write(client, input, static_cast<int>(length));
        if (result > 0) {
          CHECK(static_cast<size_t>(result) == length);
          written = true;
        } else {
          CHECK(retry(client, result));
        }
      }
      if (received < length) {
        const size_t remaining = length - received;
        int result = SSL_read(server, output + received,
                              static_cast<int>(remaining < 257 ? remaining : 257));
        if (result > 0) received += static_cast<size_t>(result);
        else CHECK(retry(server, result));
      }
    }
    uwz_alloc_end();
    CHECK(written && received == length);
    CHECK(memcmp(input, output, length) == 0);
    CHECK(uwz_alloc_malloc_calls() == 0);
    CHECK(uwz_alloc_calloc_calls() == 0);
    CHECK(uwz_alloc_realloc_calls() == 0);
    CHECK(uwz_alloc_free_calls() == 0);
    CHECK(uwz_alloc_requested_bytes() == 0);
  }
  // The existing clear path destroys and recreates SSL3_STATE and drops reserve.
  CHECK(SSL_clear(client));
  CHECK(!SSL_reserve_record_buffers(client));
  ERR_clear_error();
  SSL_free(client);
  SSL_free(server);
  SSL_CTX_free(client_context);
  SSL_CTX_free(server_context);
  puts("PASS: verified TLS 1.3 BIO pair; four startup reservations/262140 bytes; seven record sizes through 16384 bytes with 1024-byte BIO backpressure and 257-byte plaintext reads; zero measured C allocator calls; SSL_clear resets reservation");
}
