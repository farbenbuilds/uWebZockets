#include <ssl/internal.h>
#include "lifecycle_alloc.h"
#include <openssl/err.h>
#include <openssl/x509_vfy.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK(expression) do { \
    if (!(expression)) { \
        fprintf(stderr, "check failed %s:%d: %s\n", __FILE__, __LINE__, #expression); \
        abort(); \
    } \
} while (0)

struct PeerPair {
    SSL_CTX *client_context;
    SSL_CTX *server_context;
    SSL *client;
    SSL *server;
};

struct PendingSnapshot {
    uintptr_t read_pointer;
    uintptr_t write_pointer;
    uintptr_t plaintext_pointer;
    uintptr_t pending_write_pointer;
    size_t read_size;
    size_t read_capacity;
    size_t write_size;
    size_t write_capacity;
    size_t plaintext_size;
    size_t pending_write_size;
    size_t unreported_write;
    uint64_t read_hash;
    uint64_t write_hash;
    uint64_t plaintext_hash;
    uint64_t pending_write_hash;
    unsigned pending_write_type;
};

static bool retry(SSL *ssl, int result)
{
    const int error = SSL_get_error(ssl, result);
    return error == SSL_ERROR_WANT_READ || error == SSL_ERROR_WANT_WRITE;
}

static void attach_bios(PeerPair *pair, size_t capacity)
{
    BIO *client = nullptr;
    BIO *server = nullptr;
    CHECK(BIO_new_bio_pair(&client, capacity, &server, capacity));
    SSL_set_bio(pair->client, client, client);
    SSL_set_bio(pair->server, server, server);
    SSL_set_connect_state(pair->client);
    SSL_set_accept_state(pair->server);
}

static void handshake(PeerPair *pair, uint16_t version)
{
    bool client_done = false;
    bool server_done = false;
    for (size_t i = 0; i < 100000 && (!client_done || !server_done); i++) {
        if (!client_done) {
            const int result = SSL_do_handshake(pair->client);
            if (result == 1) client_done = true;
            else CHECK(retry(pair->client, result));
        }
        if (!server_done) {
            const int result = SSL_do_handshake(pair->server);
            if (result == 1) server_done = true;
            else CHECK(retry(pair->server, result));
        }
    }
    CHECK(client_done && server_done);
    CHECK(SSL_version(pair->client) == version);
    CHECK(SSL_version(pair->server) == version);
    CHECK(SSL_get_verify_result(pair->client) == X509_V_OK);
    CHECK(SSL_get0_peer_certificates(pair->client) != nullptr);
}

static PeerPair make_pair(char **arguments, uint16_t version, size_t capacity)
{
    PeerPair pair = {};
    pair.client_context = SSL_CTX_new(TLS_method());
    pair.server_context = SSL_CTX_new(TLS_method());
    CHECK(pair.client_context != nullptr && pair.server_context != nullptr);
    CHECK(SSL_CTX_set_min_proto_version(pair.client_context, version));
    CHECK(SSL_CTX_set_max_proto_version(pair.client_context, version));
    CHECK(SSL_CTX_set_min_proto_version(pair.server_context, version));
    CHECK(SSL_CTX_set_max_proto_version(pair.server_context, version));
    CHECK(SSL_CTX_set_num_tickets(pair.server_context, 0));
    CHECK(SSL_CTX_use_certificate_chain_file(pair.server_context, arguments[1]));
    CHECK(SSL_CTX_use_PrivateKey_file(pair.server_context, arguments[2], SSL_FILETYPE_PEM));
    CHECK(SSL_CTX_check_private_key(pair.server_context));
    CHECK(SSL_CTX_load_verify_locations(pair.client_context, arguments[3], nullptr));
    SSL_CTX_set_verify(pair.client_context, SSL_VERIFY_PEER, nullptr);
    pair.client = SSL_new(pair.client_context);
    pair.server = SSL_new(pair.server_context);
    CHECK(pair.client != nullptr && pair.server != nullptr);
    CHECK(SSL_set_tlsext_host_name(pair.client, "localhost"));
    CHECK(SSL_set1_host(pair.client, "localhost"));
    attach_bios(&pair, capacity);
    handshake(&pair, version);
    return pair;
}

static void destroy_pair(PeerPair *pair)
{
    SSL_free(pair->client);
    SSL_free(pair->server);
    SSL_CTX_free(pair->client_context);
    SSL_CTX_free(pair->server_context);
    memset(pair, 0, sizeof(*pair));
}

static void check_released(uint64_t successful)
{
    const uwz_fault_stats stats = uwz_fault_read();
    CHECK(stats.successful == successful);
    CHECK(stats.live == 0);
    CHECK(stats.actual_frees == successful);
    CHECK(stats.cleanse_failures == 0);
}

static uint64_t byte_hash(const uint8_t *data, size_t length)
{
    uint64_t hash = 1469598103934665603ULL;
    for (size_t i = 0; i < length; i++) {
        hash ^= data[i];
        hash *= 1099511628211ULL;
    }
    return hash;
}

static PendingSnapshot capture(SSL *ssl)
{
    auto *state = bssl::FromOpaque(ssl)->s3;
    const uint8_t *read_data = state->read_buffer.cap() ? state->read_buffer.data() : nullptr;
    const uint8_t *write_data = state->write_buffer.cap() ? state->write_buffer.data() : nullptr;
    PendingSnapshot snapshot;
    memset(&snapshot, 0, sizeof(snapshot));
    snapshot.read_pointer = reinterpret_cast<uintptr_t>(read_data);
    snapshot.write_pointer = reinterpret_cast<uintptr_t>(write_data);
    snapshot.plaintext_pointer = reinterpret_cast<uintptr_t>(state->pending_app_data.data());
    snapshot.pending_write_pointer = reinterpret_cast<uintptr_t>(state->pending_write.data());
    snapshot.read_size = state->read_buffer.size();
    snapshot.read_capacity = state->read_buffer.cap();
    snapshot.write_size = state->write_buffer.size();
    snapshot.write_capacity = state->write_buffer.cap();
    snapshot.plaintext_size = state->pending_app_data.size();
    snapshot.pending_write_size = state->pending_write.size();
    snapshot.unreported_write = state->unreported_bytes_written;
    snapshot.pending_write_type = state->pending_write_type;
    snapshot.read_hash = byte_hash(read_data, state->read_buffer.size());
    snapshot.write_hash = byte_hash(write_data, state->write_buffer.size());
    snapshot.plaintext_hash = byte_hash(state->pending_app_data.data(), state->pending_app_data.size());
    snapshot.pending_write_hash = byte_hash(state->pending_write.data(), state->pending_write.size());
    return snapshot;
}

static void reject_unchanged(SSL *ssl)
{
    const PendingSnapshot before = capture(ssl);
    const uwz_fault_stats old_stats = uwz_fault_read();
    ERR_clear_error();
    uwz_fault_arm(0);
    const int result = SSL_reserve_record_buffers(ssl);
    uwz_fault_disarm();
    CHECK(result == 0);
    CHECK(ERR_peek_error() != 0);
    const PendingSnapshot after = capture(ssl);
    const uwz_fault_stats stats = uwz_fault_read();
    CHECK(memcmp(&before, &after, sizeof(before)) == 0);
    CHECK(stats.attempts == old_stats.attempts);
    CHECK(stats.successful == old_stats.successful);
    CHECK(stats.live == old_stats.live);
    ERR_clear_error();
}

static void fill_payload(uint8_t *bytes, size_t length)
{
    for (size_t i = 0; i < length; i++) bytes[i] = static_cast<uint8_t>(i * 13 + 7);
}

static void exchange(SSL *sender, SSL *receiver, size_t length, bool measured)
{
    uint8_t input[16384];
    uint8_t output[16384];
    CHECK(length > 0 && length <= sizeof(input));
    fill_payload(input, length);
    bool written = false;
    size_t received = 0;
    if (measured) uwz_alloc_begin();
    for (size_t i = 0; i < 100000 && (!written || received != length); i++) {
        if (!written) {
            const int result = SSL_write(sender, input, static_cast<int>(length));
            if (result > 0) {
                CHECK(static_cast<size_t>(result) == length);
                written = true;
            } else {
                CHECK(retry(sender, result));
            }
        }
        if (received < length) {
            const size_t remaining = length - received;
            const int result = SSL_read(receiver, output + received,
                static_cast<int>(remaining < 257 ? remaining : 257));
            if (result > 0) received += static_cast<size_t>(result);
            else CHECK(retry(receiver, result));
        }
    }
    if (measured) uwz_alloc_end();
    CHECK(written && received == length);
    CHECK(memcmp(input, output, length) == 0);
    if (!measured) return;
    CHECK(uwz_alloc_malloc_calls() == 0);
    CHECK(uwz_alloc_calloc_calls() == 0);
    CHECK(uwz_alloc_realloc_calls() == 0);
    CHECK(uwz_alloc_free_calls() == 0);
    CHECK(uwz_alloc_requested_bytes() == 0);
}

static void reserve_pair(PeerPair *pair)
{
    uwz_fault_arm(0);
    CHECK(SSL_reserve_record_buffers(pair->client));
    CHECK(SSL_reserve_record_buffers(pair->server));
    uwz_fault_disarm();
}

static void allocation_failure(char **arguments, size_t ordinal)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    uwz_fault_reset();
    uwz_fault_arm(ordinal);
    const int result = SSL_reserve_record_buffers(pair.client);
    uwz_fault_disarm();
    CHECK(result == 0);
    CHECK(ERR_peek_error() != 0);
    const uwz_fault_stats stats = uwz_fault_read();
    CHECK(stats.attempts == ordinal);
    CHECK(stats.injected == 1);
    CHECK(stats.successful == ordinal - 1);
    CHECK(stats.live == ordinal - 1);
    /* The documented failure contract requires free, including partial RX. */
    destroy_pair(&pair);
    check_released(ordinal - 1);
    ERR_clear_error();
}

static void idempotent(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    uwz_fault_reset();
    reserve_pair(&pair);
    const uwz_fault_stats before = uwz_fault_read();
    CHECK(before.attempts == 4 && before.successful == 4 && before.live == 4);
    uwz_alloc_begin();
    reserve_pair(&pair);
    uwz_alloc_end();
    const uwz_fault_stats after = uwz_fault_read();
    CHECK(memcmp(&before, &after, sizeof(before)) == 0);
    CHECK(uwz_alloc_malloc_calls() == 0 && uwz_alloc_calloc_calls() == 0);
    CHECK(uwz_alloc_realloc_calls() == 0 && uwz_alloc_free_calls() == 0);
    CHECK(uwz_alloc_requested_bytes() == 0);
    destroy_pair(&pair);
    check_released(4);
}

static void pending_plaintext(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    uint8_t input[128];
    uint8_t first = 0;
    fill_payload(input, sizeof(input));
    CHECK(SSL_write(pair.server, input, sizeof(input)) == static_cast<int>(sizeof(input)));
    CHECK(SSL_read(pair.client, &first, 1) == 1 && first == input[0]);
    CHECK(SSL_pending(pair.client) == static_cast<int>(sizeof(input) - 1));
    uwz_fault_reset();
    reject_unchanged(pair.client);
    destroy_pair(&pair);
    check_released(0);
}

static void pending_record(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    uint8_t input[4096];
    uint8_t output[32];
    fill_payload(input, sizeof(input));
    int result = SSL_write(pair.server, input, sizeof(input));
    CHECK(result < 0 && SSL_get_error(pair.server, result) == SSL_ERROR_WANT_WRITE);
    result = SSL_read(pair.client, output, sizeof(output));
    CHECK(result < 0 && SSL_get_error(pair.client, result) == SSL_ERROR_WANT_READ);
    CHECK(SSL_pending(pair.client) == 0);
    const auto *state = bssl::FromOpaque(pair.client)->s3;
    CHECK(state->read_buffer.size() > 0 && state->read_buffer.size() < sizeof(input));
    CHECK(state->pending_app_data.empty());
    uwz_fault_reset();
    reject_unchanged(pair.client);
    destroy_pair(&pair);
    check_released(0);
}

static void pending_write(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    uint8_t input[4096];
    fill_payload(input, sizeof(input));
    const int result = SSL_write(pair.client, input, sizeof(input));
    CHECK(result < 0 && SSL_get_error(pair.client, result) == SSL_ERROR_WANT_WRITE);
    const auto *state = bssl::FromOpaque(pair.client)->s3;
    CHECK(!state->pending_write.empty() && !state->write_buffer.empty());
    uwz_fault_reset();
    reject_unchanged(pair.client);
    destroy_pair(&pair);
    check_released(0);
}

static void traffic_control(char **arguments, size_t length, bool reverse)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    uwz_fault_reset();
    if (reverse) exchange(pair.server, pair.client, length, false);
    else exchange(pair.client, pair.server, length, false);
    destroy_pair(&pair);
    check_released(0);
}

static void excluded_tls12(char **arguments)
{
    /* Isolated negative eligibility fixture, never a production TLS policy. */
    PeerPair pair = make_pair(arguments, TLS1_2_VERSION, 1024);
    uwz_fault_reset();
    reject_unchanged(pair.client);
    destroy_pair(&pair);
    check_released(0);
}

static void excluded_configured(bool dtls, bool quic)
{
    SSL_CTX *context = SSL_CTX_new(dtls ? DTLS_method() : TLS_method());
    CHECK(context != nullptr);
    SSL *ssl = SSL_new(context);
    CHECK(ssl != nullptr);
    SSL_set_connect_state(ssl);
    if (quic) {
        /* Configured-only rejection; no QUIC handshake/callback is exercised. */
        static const SSL_QUIC_METHOD method = {};
        CHECK(SSL_set_quic_method(ssl, &method));
        CHECK(SSL_is_quic(ssl));
    }
    if (dtls) CHECK(SSL_is_dtls(ssl));
    uwz_fault_reset();
    reject_unchanged(ssl);
    SSL_free(ssl);
    SSL_CTX_free(context);
    check_released(0);
}

static void excluded_null()
{
    uwz_fault_reset();
    uwz_fault_arm(0);
    CHECK(!SSL_reserve_record_buffers(nullptr));
    uwz_fault_disarm();
    CHECK(ERR_peek_error() != 0);
    CHECK(uwz_fault_read().attempts == 0);
    check_released(0);
    ERR_clear_error();
}

static void clear_reject(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    uwz_fault_reset();
    reserve_pair(&pair);
    CHECK(SSL_clear(pair.client));
    CHECK(SSL_clear(pair.server));
    check_released(4);
    reject_unchanged(pair.client);
    destroy_pair(&pair);
    check_released(4);
}

static void clear_rehandshake(char **arguments)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024);
    uwz_fault_reset();
    reserve_pair(&pair);
    CHECK(SSL_clear(pair.client));
    CHECK(SSL_clear(pair.server));
    check_released(4);
    /* A rejected reservation is tested separately, because it mandates free. */
    CHECK(SSL_set_session(pair.client, nullptr));
    attach_bios(&pair, 1024);
    handshake(&pair, TLS1_3_VERSION);
    CHECK(!SSL_session_reused(pair.client));
    reserve_pair(&pair);
    CHECK(uwz_fault_read().successful == 8 && uwz_fault_read().live == 4);
    const size_t lengths[] = {1, 5, 127, 1024, 4096, 16383, 16384};
    for (size_t length : lengths) {
        exchange(pair.client, pair.server, length, true);
        exchange(pair.server, pair.client, length, true);
    }
    destroy_pair(&pair);
    check_released(8);
}

enum CaseId {
    failure_first_case, failure_second_case, idempotent_case,
    pending_plaintext_case, pending_record_case, pending_write_case,
    control_plaintext_case, control_record_case, control_write_case,
    null_case, unfinished_case, dtls_configured_case, quic_configured_case,
    tls12_complete_case, clear_reject_case, clear_rehandshake_case,
    unknown_case,
};

struct CaseName {
    const char *name;
    CaseId id;
};

static CaseId parse_case(const char *name)
{
    static const CaseName names[] = {
        {"failure_first", failure_first_case}, {"failure_second", failure_second_case},
        {"idempotent", idempotent_case}, {"pending_plaintext", pending_plaintext_case},
        {"pending_record", pending_record_case}, {"pending_write", pending_write_case},
        {"control_plaintext", control_plaintext_case}, {"control_record", control_record_case},
        {"control_write", control_write_case}, {"null", null_case},
        {"unfinished", unfinished_case}, {"dtls_configured", dtls_configured_case},
        {"quic_configured", quic_configured_case}, {"tls12_complete", tls12_complete_case},
        {"clear_reject", clear_reject_case}, {"clear_rehandshake", clear_rehandshake_case},
    };
    for (const CaseName &entry : names) {
        if (!strcmp(name, entry.name)) return entry.id;
    }
    return unknown_case;
}

int main(int argc, char **argv)
{
    CHECK(argc == 5);
    CHECK(uwz_alloc_self_test());
    /* Error reporting may initialize its thread-local queue outside injection. */
    CHECK(!SSL_reserve_record_buffers(nullptr));
    ERR_clear_error();
    const char *name = argv[4];
    switch (parse_case(name)) {
        case failure_first_case: allocation_failure(argv, 1); break;
        case failure_second_case: allocation_failure(argv, 2); break;
        case idempotent_case: idempotent(argv); break;
        case pending_plaintext_case: pending_plaintext(argv); break;
        case pending_record_case: pending_record(argv); break;
        case pending_write_case: pending_write(argv); break;
        case control_plaintext_case: traffic_control(argv, 128, true); break;
        case control_record_case: traffic_control(argv, 4096, true); break;
        case control_write_case: traffic_control(argv, 4096, false); break;
        case null_case: excluded_null(); break;
        case unfinished_case: excluded_configured(false, false); break;
        case dtls_configured_case: excluded_configured(true, false); break;
        case quic_configured_case: excluded_configured(false, true); break;
        case tls12_complete_case: excluded_tls12(argv); break;
        case clear_reject_case: clear_reject(argv); break;
        case clear_rehandshake_case: clear_rehandshake(argv); break;
        case unknown_case: CHECK(false); break;
    }
    const uwz_fault_stats stats = uwz_fault_read();
    printf("{\"case\":\"%s\",\"pass\":true,\"reservation_attempts\":%llu,"
        "\"successful_reservations\":%llu,\"injected_failures\":%llu,"
        "\"live_reservations\":%llu,\"actual_reserved_frees\":%llu,"
        "\"cleanse_failures\":%llu}\n", name,
        static_cast<unsigned long long>(stats.attempts),
        static_cast<unsigned long long>(stats.successful),
        static_cast<unsigned long long>(stats.injected),
        static_cast<unsigned long long>(stats.live),
        static_cast<unsigned long long>(stats.actual_frees),
        static_cast<unsigned long long>(stats.cleanse_failures));
    return 0;
}
