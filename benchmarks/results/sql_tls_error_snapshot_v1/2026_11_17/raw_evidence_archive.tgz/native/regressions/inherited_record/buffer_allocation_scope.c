/* Test-only glibc interposition: never linked into the library or its build. */
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>

extern void *__libc_malloc(size_t size);
extern void *__libc_calloc(size_t count, size_t size);
extern void *__libc_realloc(void *pointer, size_t size);
extern void __libc_free(void *pointer);
extern void uwz_check_cleansed_free(void *pointer);

static _Thread_local int active;
static _Thread_local uint64_t malloc_calls;
static _Thread_local uint64_t calloc_calls;
static _Thread_local uint64_t realloc_calls;
static _Thread_local uint64_t free_calls;
static _Thread_local uint64_t requested_bytes;
static _Thread_local uintptr_t malloc_sites[2];

static void count_bytes(size_t size)
{
    if (size > UINT64_MAX - requested_bytes) requested_bytes = UINT64_MAX;
    else requested_bytes += size;
}

__attribute__((noinline)) void *malloc(size_t size)
{
    if (active) {
        if (malloc_calls < 2) malloc_sites[malloc_calls] = (uintptr_t)__builtin_return_address(0);
        malloc_calls++;
        count_bytes(size);
    }
    return __libc_malloc(size);
}

__attribute__((noinline)) void *calloc(size_t count, size_t size)
{
    if (active) {
        calloc_calls++;
        if (size != 0 && count > SIZE_MAX / size) requested_bytes = UINT64_MAX;
        else count_bytes(count * size);
    }
    return __libc_calloc(count, size);
}

__attribute__((noinline)) void *realloc(void *pointer, size_t size)
{
    if (active) { realloc_calls++; count_bytes(size); }
    return __libc_realloc(pointer, size);
}

__attribute__((noinline)) void free(void *pointer)
{
    if (active && pointer != NULL) free_calls++;
    uwz_check_cleansed_free(pointer);
    __libc_free(pointer);
}

void uwz_alloc_begin(void)
{
    malloc_calls = calloc_calls = realloc_calls = free_calls = requested_bytes = 0;
    malloc_sites[0] = malloc_sites[1] = 0;
    active = 1;
}

void uwz_alloc_end(void) { active = 0; }
uint64_t uwz_alloc_malloc_calls(void) { return malloc_calls; }
uint64_t uwz_alloc_calloc_calls(void) { return calloc_calls; }
uint64_t uwz_alloc_realloc_calls(void) { return realloc_calls; }
uint64_t uwz_alloc_free_calls(void) { return free_calls; }
uint64_t uwz_alloc_requested_bytes(void) { return requested_bytes; }
uint64_t uwz_alloc_malloc_site(unsigned int index) { return index < 2 ? malloc_sites[index] : 0; }

int uwz_alloc_self_test(void)
{
    uwz_alloc_begin();
    void *first = malloc(17);
    void *second = calloc(3, 5);
    if (first == NULL || second == NULL) abort();
    ((volatile unsigned char *)first)[0] = 1;
    ((volatile unsigned char *)second)[0] = 2;
    first = realloc(first, 31);
    if (first == NULL) abort();
    free(first);
    free(second);
    uwz_alloc_end();
    return malloc_calls == 1 && calloc_calls == 1 && realloc_calls == 1 &&
        free_calls == 2 && requested_bytes == 63;
}
