/* Test-only OS-thread bookkeeping. Never linked into the library or SQL probe. */
#include "lifecycle_alloc.h"
#include <errno.h>
#include <stdlib.h>
#include <string.h>

extern void *__libc_malloc(size_t size);
extern void *__libc_calloc(size_t count, size_t size);
extern void *__libc_realloc(void *pointer, size_t size);
extern void __libc_free(void *pointer);

enum { reservation_size = 65535, record_limit = 32 };

struct reservation_record {
    void *pointer;
    int live;
};

/* Interposition must not allocate its own bookkeeping or share test threads. */
static _Thread_local struct reservation_record records[record_limit];
static _Thread_local size_t record_count;
static _Thread_local int fault_armed;
static _Thread_local size_t fail_ordinal;
static _Thread_local size_t arm_ordinal;
static _Thread_local struct uwz_fault_stats fault_stats;
static _Thread_local int active;
static _Thread_local uint64_t malloc_calls;
static _Thread_local uint64_t calloc_calls;
static _Thread_local uint64_t realloc_calls;
static _Thread_local uint64_t free_calls;
static _Thread_local uint64_t requested_bytes;

static void count_bytes(size_t size)
{
    if (size > UINT64_MAX - requested_bytes) requested_bytes = UINT64_MAX;
    else requested_bytes += size;
}

__attribute__((noinline)) void *malloc(size_t size)
{
    if (active) {
        malloc_calls++;
        count_bytes(size);
    }
    const int reservation = fault_armed && size == reservation_size;
    if (reservation) {
        arm_ordinal++;
        fault_stats.attempts++;
        if (arm_ordinal == fail_ordinal) {
            fault_stats.injected++;
            errno = ENOMEM;
            return NULL;
        }
    }
    void *pointer = __libc_malloc(size);
    if (!reservation || pointer == NULL) return pointer;
    if (record_count == record_limit) abort();
    records[record_count].pointer = pointer;
    records[record_count].live = 1;
    record_count++;
    fault_stats.successful++;
    fault_stats.live++;
    /* Nonzero fresh bytes make the later full-allocation cleanse check real. */
    memset(pointer, 0xa5, size);
    return pointer;
}

__attribute__((noinline)) void *calloc(size_t count, size_t size)
{
    if (active) {
        calloc_calls++;
        if (size != 0 && count > SIZE_MAX / size) requested_bytes = UINT64_MAX;
        else count_bytes(count * size);
    }
    return __libc_calloc(count, size);
}

__attribute__((noinline)) void *realloc(void *pointer, size_t size)
{
    if (active) {
        realloc_calls++;
        count_bytes(size);
    }
    return __libc_realloc(pointer, size);
}

__attribute__((noinline)) void free(void *pointer)
{
    if (active && pointer != NULL) free_calls++;
    size_t matched = record_limit;
    for (size_t i = 0; i < record_count; i++) {
        if (!records[i].live || records[i].pointer != pointer) continue;
        matched = i;
        const volatile unsigned char *bytes = pointer;
        for (size_t offset = 0; offset < reservation_size; offset++) {
            if (bytes[offset] == 0) continue;
            fault_stats.cleanse_failures++;
            break;
        }
        records[i].live = 0;
        fault_stats.live--;
        break;
    }
    __libc_free(pointer);
    if (matched != record_limit) fault_stats.actual_frees++;
}

void uwz_fault_reset(void)
{
    if (fault_stats.live != 0 || fault_armed) abort();
    memset(records, 0, sizeof(records));
    memset(&fault_stats, 0, sizeof(fault_stats));
    record_count = 0;
    fail_ordinal = arm_ordinal = 0;
}

void uwz_fault_arm(size_t ordinal)
{
    if (fault_armed) abort();
    fault_armed = 1;
    fail_ordinal = ordinal;
    arm_ordinal = 0;
}

void uwz_fault_disarm(void)
{
    fault_armed = 0;
    fail_ordinal = arm_ordinal = 0;
}

struct uwz_fault_stats uwz_fault_read(void) { return fault_stats; }

void uwz_alloc_begin(void)
{
    malloc_calls = calloc_calls = realloc_calls = free_calls = requested_bytes = 0;
    active = 1;
}

void uwz_alloc_end(void) { active = 0; }
uint64_t uwz_alloc_malloc_calls(void) { return malloc_calls; }
uint64_t uwz_alloc_calloc_calls(void) { return calloc_calls; }
uint64_t uwz_alloc_realloc_calls(void) { return realloc_calls; }
uint64_t uwz_alloc_free_calls(void) { return free_calls; }
uint64_t uwz_alloc_requested_bytes(void) { return requested_bytes; }

int uwz_alloc_self_test(void)
{
    uwz_alloc_begin();
    void *first = malloc(17);
    void *second = calloc(3, 5);
    if (first == NULL || second == NULL) abort();
    ((volatile unsigned char *)first)[0] = 1;
    ((volatile unsigned char *)second)[0] = 2;
    first = realloc(first, 31);
    if (first == NULL) abort();
    free(first);
    free(second);
    uwz_alloc_end();
    return malloc_calls == 1 && calloc_calls == 1 && realloc_calls == 1 &&
        free_calls == 2 && requested_bytes == 63;
}
