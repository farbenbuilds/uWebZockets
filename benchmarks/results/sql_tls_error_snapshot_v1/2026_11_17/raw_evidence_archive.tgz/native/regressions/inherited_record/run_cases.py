#!/usr/bin/env python3
"""Run the bounded lifecycle cases into a new, non-overwriting evidence folder."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


CASES = (
    'failure_first', 'failure_second', 'idempotent',
    'pending_plaintext', 'pending_record', 'pending_write',
    'control_plaintext', 'control_record', 'control_write',
    'null', 'unfinished', 'dtls_configured', 'quic_configured',
    'tls12_complete', 'clear_reject', 'clear_rehandshake',
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pki', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    arguments = parser.parse_args()
    if arguments.output.exists() or arguments.output.is_symlink():
        raise ValueError('Choose an absent evidence output directory')
    if arguments.pki.joinpath('server.key').stat().st_mode & 0o077:
        raise ValueError('The generated fixture key must remain private')
    arguments.output.mkdir(parents=True)
    rows = []
    binary = base / 'lifecycle_test'
    for case in CASES:
        command = [
            str(binary), str(arguments.pki / 'server.pem'),
            str(arguments.pki / 'server.key'), str(arguments.pki / 'ca.pem'), case,
        ]
        result = subprocess.run(command, cwd=base, capture_output=True, timeout=30)
        stdout = arguments.output / (case + '.stdout')
        stderr = arguments.output / (case + '.stderr')
        stdout.write_bytes(result.stdout)
        stderr.write_bytes(result.stderr)
        row = {
            'case': case, 'command': command, 'exit_code': result.returncode,
            'stdout': stdout.name, 'stderr': stderr.name,
            'stdout_sha256': digest(stdout), 'stderr_sha256': digest(stderr),
        }
        rows.append(row)
        if result.returncode != 0:
            raise RuntimeError('Lifecycle case failed: ' + case)
        data = json.loads(result.stdout)
        if data['case'] != case or data['pass'] is not True or result.stderr:
            raise ValueError('Unexpected lifecycle result: ' + case)
        row['result'] = data
        print(case + ': PASS', flush=True)
    source_names = ['lifecycle_test.cc', 'lifecycle_alloc.c', 'lifecycle_alloc.h']
    sources = {name: digest(base / name) for name in source_names if (base / name).is_file()}
    archive_names = ['libssl.a', 'libcrypto.a']
    archive_root = base / 'native_out/lib'
    archives = {
        name: digest(archive_root / name)
        for name in archive_names if (archive_root / name).is_file()
    }
    records = {
        'complete': True, 'case_count': len(rows), 'rows': rows,
        'binary_sha256': digest(binary),
        'source_sha256': sources,
        'native_archive_sha256': archives,
        'runtime_requires_native_archives_or_source': False,
        'injected_failures_are_ordinary_zero_allocation_measurements': False,
    }
    (arguments.output / 'results.json').write_text(json.dumps(records, indent=2) + '\n')


if __name__ == '__main__':
    main()
