#include "boringssl/ssl/internal.h"
#include <openssl/err.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define CHECK(expr) do { if (!(expr)) { fprintf(stderr, "check failed line %d\n", __LINE__); abort(); } } while (0)

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
void uwz_expect_cleansed_free(void *, size_t);
int uwz_cleansed_free_observed(void);
}

static void no_allocations() {
  CHECK(uwz_alloc_malloc_calls() == 0);
  CHECK(uwz_alloc_calloc_calls() == 0);
  CHECK(uwz_alloc_realloc_calls() == 0);
  CHECK(uwz_alloc_free_calls() == 0);
  CHECK(uwz_alloc_requested_bytes() == 0);
}

int main() {
  CHECK(uwz_alloc_self_test());
  constexpr size_t kCapacity = 65528;
  {
    bssl::SSLBuffer buffer;
    CHECK(buffer.Reserve());
    auto *base = buffer.data();
    CHECK(buffer.cap() == kCapacity);
    uwz_expect_cleansed_free(base, 65535);
    uwz_alloc_begin();
    for (size_t iteration = 0; iteration < 256; iteration++) {
      const size_t header = iteration % 31;
      CHECK(buffer.EnsureCap(header, 5));
      CHECK((reinterpret_cast<uintptr_t>(buffer.data()) + header) % 8 == 0);
      memset(buffer.data(), 0x5a, 5);
      buffer.DidWrite(5);
      CHECK(buffer.EnsureCap(header, kCapacity));
      memset(buffer.data() + 5, 0xa5, kCapacity - 5);
      buffer.DidWrite(kCapacity - 5);
      buffer.Consume(32000);
      CHECK(buffer.EnsureCap(header, kCapacity));
      for (size_t i = 0; i < buffer.size(); i++) {
        CHECK(buffer.data()[i] == 0xa5);
      }
      memset(buffer.data() + buffer.size(), 0x33, 32000);
      buffer.DidWrite(32000);
      buffer.Consume(kCapacity);
      buffer.DiscardConsumed();
      CHECK(buffer.empty());
      CHECK(buffer.cap() == kCapacity);
      CHECK(buffer.data() == base);
      for (size_t i = 0; i < kCapacity; i++) {
        CHECK(base[i] == 0);
      }
      CHECK(buffer.Reserve());
    }
    uwz_alloc_end();
    no_allocations();
    CHECK(!buffer.EnsureCap(0, kCapacity + 1));
    ERR_clear_error();
    CHECK(buffer.EnsureCap(5, 100));
    memset(buffer.data(), 0x7e, 100);
    buffer.DidWrite(100);
    uwz_alloc_begin();
  }
  uwz_alloc_end();
  CHECK(uwz_alloc_malloc_calls() == 0);
  CHECK(uwz_alloc_calloc_calls() == 0);
  CHECK(uwz_alloc_realloc_calls() == 0);
  CHECK(uwz_alloc_free_calls() == 1);
  CHECK(uwz_cleansed_free_observed());

  CHECK(!SSL_reserve_record_buffers(nullptr));
  ERR_clear_error();
  SSL_CTX *context = SSL_CTX_new(TLS_method());
  CHECK(context != nullptr);
  SSL *ssl = SSL_new(context);
  CHECK(ssl != nullptr);
  CHECK(!SSL_reserve_record_buffers(ssl));
  ERR_clear_error();
  SSL_free(ssl);
  SSL_CTX_free(context);
  puts("PASS: wrapper self-test, 256 maximum-size retention/compaction loops, alignment, capacity recovery, cleansing, one actual destructor free, API pre-handshake rejection");
}
