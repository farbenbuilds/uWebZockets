/* Test-only failure wrapper; normal helper and peer binaries never link it. */
#include "seal_fault.h"
#include <openssl/aead.h>
#include <openssl/err.h>
#include <openssl/mem.h>
#include <stdlib.h>
#include <string.h>

extern int __real_EVP_AEAD_CTX_seal_scatter(const EVP_AEAD_CTX *context,
    uint8_t *out, uint8_t *out_tag, size_t *out_tag_length, size_t max_out_tag_length,
    const uint8_t *nonce, size_t nonce_length, const uint8_t *in, size_t in_length,
    const uint8_t *extra_in, size_t extra_in_length, const uint8_t *ad, size_t ad_length);

/* The single fixture OS thread owns this one-shot injection. */
static _Thread_local int armed;
static _Thread_local struct SealFaultObservation observation;

void seal_fault_arm(void)
{
    if (armed) abort();
    memset(&observation, 0, sizeof(observation));
    armed = 1;
}

struct SealFaultObservation seal_fault_read(void) { return observation; }

int __wrap_EVP_AEAD_CTX_seal_scatter(const EVP_AEAD_CTX *context,
    uint8_t *out, uint8_t *out_tag, size_t *out_tag_length, size_t max_out_tag_length,
    const uint8_t *nonce, size_t nonce_length, const uint8_t *in, size_t in_length,
    const uint8_t *extra_in, size_t extra_in_length, const uint8_t *ad, size_t ad_length)
{
    const int result = __real_EVP_AEAD_CTX_seal_scatter(context, out, out_tag,
        out_tag_length, max_out_tag_length, nonce, nonce_length, in, in_length,
        extra_in, extra_in_length, ad, ad_length);
    if (!armed) return result;
    armed = 0;
    observation.calls++;
    observation.real_result = result;
    if (result != 1) return result;
    observation.produced_bytes = in_length + *out_tag_length;
    // Preserve the real failure output contract, while allowing internal effects.
    OPENSSL_cleanse(out, in_length);
    OPENSSL_cleanse(out_tag, *out_tag_length);
    *out_tag_length = 0;
    OPENSSL_PUT_ERROR(CIPHER, ERR_R_INTERNAL_ERROR);
    return 0;
}
