#include <ssl/internal.h>
#include <stdio.h>

int main()
{
    printf("context=%zu state=%zu\n", sizeof(bssl::SSLAEADContext), sizeof(bssl::SSL3_STATE));
}
