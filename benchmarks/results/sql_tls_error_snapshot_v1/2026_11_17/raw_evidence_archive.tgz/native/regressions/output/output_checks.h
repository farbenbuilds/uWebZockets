#ifndef UWZ_OUTPUT_CHECKS_H
#define UWZ_OUTPUT_CHECKS_H
#include "output_pair.h"

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

struct AllocationCounts {
    uint64_t malloc_calls;
    uint64_t calloc_calls;
    uint64_t realloc_calls;
    uint64_t free_calls;
    uint64_t bytes;
};

struct OutputSnapshot {
    uintptr_t plain_owner;
    uintptr_t plain_data;
    uintptr_t flight_owner;
    uintptr_t flight_data;
    uintptr_t cipher;
    size_t plain_length;
    size_t plain_capacity;
    size_t flight_length;
    size_t flight_capacity;
    uint32_t flight_offset;
    uint8_t plain_bytes[8];
    uint8_t flight_bytes[40];
};

static AllocationCounts counts(void)
{
    return {uwz_alloc_malloc_calls(), uwz_alloc_calloc_calls(),
            uwz_alloc_realloc_calls(), uwz_alloc_free_calls(),
            uwz_alloc_requested_bytes()};
}

static void check_zero(const AllocationCounts *value)
{
    CHECK(value->malloc_calls == 0 && value->calloc_calls == 0);
    CHECK(value->realloc_calls == 0 && value->free_calls == 0 && value->bytes == 0);
}

static void capture_output(const bssl::SSL3_STATE *state, OutputSnapshot *result)
{
    memset(result, 0, sizeof(*result));
    CHECK(state->pending_hs_data && state->pending_flight);
    result->plain_owner = reinterpret_cast<uintptr_t>(state->pending_hs_data.get());
    result->plain_data = reinterpret_cast<uintptr_t>(state->pending_hs_data->data);
    result->flight_owner = reinterpret_cast<uintptr_t>(state->pending_flight.get());
    result->flight_data = reinterpret_cast<uintptr_t>(state->pending_flight->data);
    result->cipher = reinterpret_cast<uintptr_t>(state->key_update_output_cipher);
    result->plain_length = state->pending_hs_data->length;
    result->plain_capacity = state->pending_hs_data->max;
    result->flight_length = state->pending_flight->length;
    result->flight_capacity = state->pending_flight->max;
    result->flight_offset = state->pending_flight_offset;
    // Physical allocations are known 8/40 even in explicitly narrowed-cap fixtures.
    memcpy(result->plain_bytes, state->pending_hs_data->data, sizeof(result->plain_bytes));
    memcpy(result->flight_bytes, state->pending_flight->data, sizeof(result->flight_bytes));
}

static void check_output_owners(const bssl::SSL3_STATE *state, const OutputSnapshot *initial)
{
    CHECK(reinterpret_cast<uintptr_t>(state->pending_hs_data.get()) == initial->plain_owner);
    CHECK(reinterpret_cast<uintptr_t>(state->pending_hs_data->data) == initial->plain_data);
    CHECK(reinterpret_cast<uintptr_t>(state->pending_flight.get()) == initial->flight_owner);
    CHECK(reinterpret_cast<uintptr_t>(state->pending_flight->data) == initial->flight_data);
    CHECK(state->pending_hs_data->max == 8 && state->pending_flight->max == 40);
    CHECK(reinterpret_cast<uintptr_t>(state->key_update_output_cipher) == initial->cipher);
}

static void check_bytes(const char *bytes, size_t start, size_t end, uint8_t expected)
{
    for (size_t index = start; index < end; index++) {
        CHECK(static_cast<uint8_t>(bytes[index]) == expected);
    }
}

static void prepare_profile(PeerPair *pair)
{
    CHECK(SSL_reserve_key_update_output_buffers(pair->client));
    auto *state = bssl::FromOpaque(pair->client)->s3;
    CHECK(state->key_update_output_cipher == SSL_get_current_cipher(pair->client));
    CHECK(state->pending_hs_data && state->pending_flight);
    CHECK(state->pending_hs_data->max == 8 && state->pending_flight->max == 40);
    CHECK(state->pending_hs_data->length == 0 && state->pending_flight->length == 0);
    CHECK(state->pending_flight_offset == 0 && SSL_max_seal_overhead(pair->client) == 22);
    CHECK(SSL_reserve_record_buffers(pair->client));
    CHECK(SSL_reserve_client_post_handshake_buffer(pair->client));
    CHECK(SSL_reserve_key_update_context(pair->client));
    // Empty capacity contents are seeded only for direct erasure/guard observations.
    memset(state->pending_hs_data->data, 0x5a, 8);
    memset(state->pending_flight->data, 0x6b, 40);
}

#endif
