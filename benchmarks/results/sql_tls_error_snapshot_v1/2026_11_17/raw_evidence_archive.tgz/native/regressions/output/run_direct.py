#!/usr/bin/env python3
"""Build normal output-buffer helpers and a separate real-sealer-failure fixture."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('pki_tool', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--zig', default='/tmp/zig-x86_64-linux-0.16.0/zig')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    native = args.native_root.resolve(strict=True)
    tool = args.pki_tool.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    if sha(tool) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('PKI helper checksum differs')
    output.mkdir(mode=0o700)
    environment = dict(os.environ)
    environment['ZIG_GLOBAL_CACHE_DIR'] = '/tmp/uwz-zig-cache'
    commands = []
    complete = False

    def run(command, stem):
        with (output / (stem + '.stdout')).open('wb') as stdout, \
             (output / (stem + '.stderr')).open('wb') as stderr:
            result = subprocess.run(command, cwd=output, env=environment,
                                    stdout=stdout, stderr=stderr)
        commands.append({'command': command, 'exit_code': result.returncode, 'stem': stem})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode != 0:
            raise RuntimeError('Command failed: ' + str(output / stem))

    archives = [native / 'native_out/lib/libssl.a', native / 'native_out/lib/libcrypto.a']
    source_names = ['output_pair.h', 'output_checks.h', 'output_direct.cc', 'output_failures.cc',
        'seal_fault.c', 'seal_fault.h', 'allocation_scope.c', 'layout_probe.cc']
    (output / 'provenance.json').write_text(json.dumps({
        'native_archive_sha256': {p.name: sha(p) for p in archives},
        'source_sha256': {name: sha(base / name) for name in source_names},
        'optimization': 'Debug (-O0 -g)', 'normal_direct_binary_wrapped': False,
        'failure_binary_wraps_real_sealer_only': True}, indent=2) + '\n')
    for stem in ['allocation_scope', 'seal_fault']:
        run([args.zig, 'cc', '-std=c11', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
             '-isystem', str(native / 'boringssl/include'), '-c', str(base / (stem + '.c')),
             '-o', str(output / (stem + '.o'))], 'build-' + stem)
    common = [args.zig, 'c++', '-std=c++17', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
        '-DBORINGSSL_IMPLEMENTATION', '-isystem', str(native / 'boringssl'),
        '-isystem', str(native / 'boringssl/include')]
    run([*common, str(base / 'output_direct.cc'), str(output / 'allocation_scope.o'),
         *[str(p) for p in archives], '-o', str(output / 'output_direct')], 'link-direct')
    run([*common, '-c', str(base / 'output_failures.cc'), '-o', str(output / 'output_failures.o')],
        'compile-failures')
    run([*common, str(base / 'layout_probe.cc'), '-v', '-o', str(output / 'layout_probe')],
        'link-template')
    linker_line = next(line for line in (output / 'link-template.stderr').read_text().splitlines()
        if line.startswith('ld.lld '))
    arguments = shlex.split(linker_line)[1:]
    arguments[arguments.index('-o') + 1] = str(output / 'output_failures')
    candidates = [index for index, token in enumerate(arguments)
        if token.endswith('.o') and Path(token).name not in ('crt1.o', 'crti.o', 'crtn.o')]
    if len(candidates) != 1:
        raise ValueError('Unexpected driver object inventory')
    index = candidates[0]
    arguments[index:index + 1] = [str(output / 'output_failures.o'),
        str(output / 'allocation_scope.o'), str(output / 'seal_fault.o'), *[str(p) for p in archives]]
    run([args.zig, 'ld.lld', *arguments, '--wrap=EVP_AEAD_CTX_seal_scatter'], 'link-failures')
    pki = output / 'private_pki'
    try:
        run([str(tool), 'pki', str(pki)], 'pki_metadata')
        fixture = [str(pki / name) for name in ['server.pem', 'server.key', 'ca.pem']]
        run([str(output / 'output_direct'), *fixture], 'direct')
        run([str(output / 'output_failures'), *fixture], 'failures')
        complete = True
    finally:
        if pki.exists():
            names = {p.name for p in pki.iterdir()}
            if names - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected private fixture output')
            for name in names:
                (pki / name).unlink()
            pki.rmdir()
        (output / 'results.json').write_text(json.dumps({'complete': complete,
            'private_pki_removed': not pki.exists(),
            'binaries': {name: sha(output / name) for name in ['output_direct', 'output_failures']}},
            indent=2) + '\n')
    print('PASS: all-suite direct output guards/encoding/erasure and separate real-sealer failures')


if __name__ == '__main__':
    main()
