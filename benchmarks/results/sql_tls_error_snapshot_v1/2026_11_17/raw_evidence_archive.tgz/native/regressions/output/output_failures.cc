#include "output_checks.h"
#include "seal_fault.h"

static void run_suite(char **arguments, uint16_t suite)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024, suite);
    prepare_profile(&pair);
    auto *state = bssl::FromOpaque(pair.client)->s3;
    OutputSnapshot initial;
    capture_output(state, &initial);
    const uint8_t message[] = {SSL3_MT_KEY_UPDATE, 0, 0, 1, 0};
    CHECK(bssl::tls_add_message_borrowed(bssl::FromOpaque(pair.client), message));
    CHECK(state->pending_hs_data->length == 5);
    const bssl::SSLAEADContext *installed = state->aead_write_ctx.get();
    seal_fault_arm();
    uwz_alloc_begin();
    CHECK(!bssl::tls_flush_pending_hs_data(bssl::FromOpaque(pair.client)));
    uwz_alloc_end();
    const AllocationCounts value = counts();
    check_zero(&value);
    const SealFaultObservation result = seal_fault_read();
    CHECK(result.calls == 1 && result.real_result == 1 && result.produced_bytes == 22);
    CHECK(state->aead_write_ctx.get() == installed);
    CHECK(state->pending_hs_data->length == 0 && state->pending_flight->length == 0);
    CHECK(state->pending_flight_offset == 0);
    check_output_owners(state, &initial);
    check_bytes(state->pending_hs_data->data, 0, 5, 0);
    check_bytes(state->pending_hs_data->data, 5, 8, 0x5a);
    CHECK(BIO_ctrl_pending(SSL_get_rbio(pair.server)) == 0);
    CHECK(ERR_peek_error() != 0);
    ERR_clear_error();
    printf("{\"scope\":\"injected_real_sealer_failure\",\"suite\":%u,"
        "\"real_seal_succeeded_before_injected_failure\":true,\"borrowed_owner_restored\":true,"
        "\"plaintext_consumed_and_cleansed\":true,\"no_whole_crypto_rollback_claim\":true,"
        "\"heap_operations\":0}\n", suite);
    destroy_pair(&pair);
}

int main(int argc, char **argv)
{
    CHECK(argc == 4);
    CHECK(uwz_alloc_self_test());
    CHECK(!SSL_reserve_key_update_output_buffers(nullptr));
    ERR_clear_error();
    const uint16_t suites[] = {0x1301, 0x1302, 0x1303};
    for (uint16_t suite : suites) run_suite(argv, suite);
    puts("PASS: all-suite real-sealer failure restores retained plaintext ownership; self-test63");
}
