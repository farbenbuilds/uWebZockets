#ifndef UWZ_SEAL_FAULT_H
#define UWZ_SEAL_FAULT_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

struct SealFaultObservation {
    uint64_t calls;
    size_t produced_bytes;
    int real_result;
};

void seal_fault_arm(void);
struct SealFaultObservation seal_fault_read(void);

#ifdef __cplusplus
}
#endif
#endif
