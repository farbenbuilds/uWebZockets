#include "output_checks.h"

struct Observations {
    size_t messages;
    uint8_t encoded[8][5];
    bool copied_before_callback;
};

static void observe(int writing, int version, int type, const void *bytes,
                    size_t length, SSL *ssl, void *argument)
{
    (void)version;
    if (!writing || type != SSL3_RT_HANDSHAKE) return;
    const uint8_t *message = static_cast<const uint8_t *>(bytes);
    if (length != 5 || message[0] != SSL3_MT_KEY_UPDATE) return;
    auto *result = static_cast<Observations *>(argument);
    CHECK(result->messages < 8);
    memcpy(result->encoded[result->messages++], bytes, 5);
    const auto *state = bssl::FromOpaque(ssl)->s3;
    result->copied_before_callback = state->pending_hs_data &&
        state->pending_hs_data->length == 5 &&
        memcmp(state->pending_hs_data->data, bytes, 5) == 0;
}

static void reject_append(PeerPair *pair, const uint8_t *bytes, size_t length,
                          const Observations *observations)
{
    const auto *state = bssl::FromOpaque(pair->client)->s3;
    OutputSnapshot before, after;
    capture_output(state, &before);
    const size_t callbacks = observations->messages;
    uwz_alloc_begin();
    CHECK(!bssl::tls_add_message_borrowed(bssl::FromOpaque(pair->client),
        bssl::Span<const uint8_t>(bytes, length)));
    uwz_alloc_end();
    const AllocationCounts value = counts();
    check_zero(&value);
    capture_output(state, &after);
    CHECK(memcmp(&before, &after, sizeof(before)) == 0);
    CHECK(observations->messages == callbacks);
    ERR_clear_error();
}

static void empty_and_bounds(char **arguments, uint16_t suite)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024, suite);
    prepare_profile(&pair);
    auto *state = bssl::FromOpaque(pair.client)->s3;
    Observations observations = {};
    SSL_set_msg_callback(pair.client, observe);
    SSL_set_msg_callback_arg(pair.client, &observations);
    OutputSnapshot before, after;
    capture_output(state, &before);
    uwz_alloc_begin();
    CHECK(bssl::tls_flush_pending_hs_data(bssl::FromOpaque(pair.client)));
    CHECK(bssl::tls_flush(bssl::FromOpaque(pair.client)) == 1);
    CHECK(SSL_reserve_key_update_output_buffers(pair.client));
    CHECK(SSL_reserve_record_buffers(pair.client));
    CHECK(SSL_reserve_client_post_handshake_buffer(pair.client));
    CHECK(SSL_reserve_key_update_context(pair.client));
    CHECK(SSL_set_max_send_fragment(pair.client, 0));
    CHECK(bssl::FromOpaque(pair.client)->max_send_fragment == 512);
    CHECK(SSL_set_max_send_fragment(pair.client, 16384));
    CHECK(bssl::FromOpaque(pair.client)->max_send_fragment == 16384);
    uwz_alloc_end();
    const AllocationCounts empty_counts = counts();
    check_zero(&empty_counts);
    capture_output(state, &after);
    CHECK(memcmp(&before, &after, sizeof(before)) == 0);
    CHECK(observations.messages == 0 && BIO_ctrl_pending(SSL_get_rbio(pair.server)) == 0);
    const uint8_t message[] = {SSL3_MT_KEY_UPDATE, 0, 0, 1, 0, 9};
    reject_append(&pair, message, 6, &observations);
    reject_append(&pair, message, SIZE_MAX, &observations);
    // Internal inconsistent-capacity guards do not model peer protocol traffic.
    state->pending_hs_data->max = 4;
    reject_append(&pair, message, 5, &observations);
    state->pending_hs_data->max = 8;
    state->pending_flight_offset = 1;
    reject_append(&pair, message, 5, &observations);
    state->pending_flight_offset = 0;
    uwz_alloc_begin();
    CHECK(bssl::tls_add_message_borrowed(bssl::FromOpaque(pair.client),
        bssl::Span(message).first(5)));
    uwz_alloc_end();
    const AllocationCounts append_counts = counts();
    check_zero(&append_counts);
    CHECK(observations.messages == 1 && observations.copied_before_callback);
    CHECK(memcmp(observations.encoded[0], message, 5) == 0);
    CHECK(state->pending_hs_data->length == 5);
    reject_append(&pair, message, 1, &observations);
    // Cipher storage below logical 27 fails after borrowing, consuming plaintext.
    state->pending_flight->max = 26;
    uwz_alloc_begin();
    CHECK(!bssl::tls_flush_pending_hs_data(bssl::FromOpaque(pair.client)));
    uwz_alloc_end();
    const AllocationCounts failed_flush = counts();
    check_zero(&failed_flush);
    CHECK(state->pending_hs_data->length == 0 && state->pending_flight->length == 0);
    CHECK(state->pending_flight_offset == 0);
    check_bytes(state->pending_hs_data->data, 0, 5, 0);
    check_bytes(state->pending_hs_data->data, 5, 8, 0x5a);
    check_bytes(state->pending_flight->data, 0, 40, 0x6b);
    state->pending_flight->max = 40;
    check_output_owners(state, &before);
    ERR_clear_error();
    printf("{\"scope\":\"direct_output_helpers\",\"suite\":%u,\"empty_is_absent\":true,"
        "\"logical5_guards\":true,\"storage27_guard\":true,\"borrow_restored_consumed\":true,"
        "\"guards_no_mutation_or_callback\":true,\"heap_operations\":0}\n", suite);
    destroy_pair(&pair);
}

static void encoded_flight(char **arguments, uint16_t suite, int mode)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024, suite);
    // Isolate actual output-profile startup from prior profiles and handshake.
    uwz_alloc_begin();
    CHECK(SSL_reserve_key_update_output_buffers(pair.client));
    uwz_alloc_end();
    const AllocationCounts startup = counts();
    CHECK(startup.malloc_calls == 4 && startup.bytes == 128);
    CHECK(startup.calloc_calls == 0 && startup.realloc_calls == 0 && startup.free_calls == 0);
    prepare_profile(&pair);
    auto *state = bssl::FromOpaque(pair.client)->s3;
    OutputSnapshot initial;
    capture_output(state, &initial);
    Observations observations = {};
    SSL_set_msg_callback(pair.client, observe);
    SSL_set_msg_callback_arg(pair.client, &observations);
    CHECK(SSL_set_max_send_fragment(pair.client, mode ? 512 : 16384));
    uwz_alloc_begin();
    CHECK(SSL_key_update(pair.client, mode));
    uwz_alloc_end();
    const AllocationCounts update_counts = counts();
    check_zero(&update_counts);
    const uint8_t expected[] = {SSL3_MT_KEY_UPDATE, 0, 0, 1, static_cast<uint8_t>(mode)};
    CHECK(observations.messages == 1 && observations.copied_before_callback);
    CHECK(memcmp(observations.encoded[0], expected, 5) == 0);
    CHECK(state->pending_hs_data->length == 0 && state->pending_flight->length == 27);
    CHECK(state->pending_flight_offset == 0);
    check_bytes(state->pending_hs_data->data, 0, 5, 0);
    check_bytes(state->pending_hs_data->data, 5, 8, 0x5a);
    check_bytes(state->pending_flight->data, 27, 40, 0x6b);
    const uint8_t record_header[] = {SSL3_RT_APPLICATION_DATA, 3, 3, 0, 22};
    CHECK(memcmp(state->pending_flight->data, record_header, sizeof(record_header)) == 0);
    uint8_t flight[27];
    memcpy(flight, state->pending_flight->data, sizeof(flight));
    uwz_alloc_begin();
    CHECK(bssl::tls_flush(bssl::FromOpaque(pair.client)) == 1);
    uwz_alloc_end();
    const AllocationCounts flush_counts = counts();
    check_zero(&flush_counts);
    CHECK(state->pending_flight->length == 0 && state->pending_flight_offset == 0);
    check_bytes(state->pending_flight->data, 0, 27, 0);
    check_bytes(state->pending_flight->data, 27, 40, 0x6b);
    check_output_owners(state, &initial);
    uint8_t transport[27];
    CHECK(BIO_read(SSL_get_rbio(pair.server), transport, sizeof(transport)) == 27);
    CHECK(memcmp(transport, flight, sizeof(flight)) == 0);
    printf("{\"scope\":\"generated_encoding_and_direct_BIO_flush\",\"suite\":%u,"
        "\"mode\":%d,\"encoding_bytes\":5,\"flight_bytes\":27,\"startup_malloc\":4,"
        "\"startup_bytes\":128,\"sizeof_ssl3_state\":%zu,\"owners_stable\":true,"
        "\"consumed_only_cleansed\":true,\"heap_operations\":0}\n", suite, mode,
        sizeof(bssl::SSL3_STATE));
    destroy_pair(&pair);
}

static void partial_flight(char **arguments, uint16_t suite)
{
    PeerPair pair = make_pair(arguments, TLS1_3_VERSION, 1024, suite);
    prepare_profile(&pair);
    uint8_t application[1000];
    memset(application, 0x72, sizeof(application));
    CHECK(SSL_write(pair.client, application, sizeof(application)) == 1000);
    CHECK(BIO_ctrl_pending(SSL_get_rbio(pair.server)) == 1022);
    auto *state = bssl::FromOpaque(pair.client)->s3;
    OutputSnapshot initial;
    capture_output(state, &initial);
    CHECK(SSL_key_update(pair.client, SSL_KEY_UPDATE_NOT_REQUESTED));
    uint8_t flight[27];
    CHECK(state->pending_flight->length == sizeof(flight));
    memcpy(flight, state->pending_flight->data, sizeof(flight));
    uwz_alloc_begin();
    CHECK(bssl::tls_flush(bssl::FromOpaque(pair.client)) < 0);
    uwz_alloc_end();
    const AllocationCounts partial_counts = counts();
    check_zero(&partial_counts);
    CHECK(state->pending_flight_offset == 2 && state->pending_flight->length == 27);
    check_bytes(state->pending_flight->data, 0, 2, 0);
    CHECK(memcmp(state->pending_flight->data + 2, flight + 2, 25) == 0);
    check_bytes(state->pending_flight->data, 27, 40, 0x6b);
    Observations observations = {};
    const uint8_t message[] = {SSL3_MT_KEY_UPDATE, 0, 0, 1, 0};
    reject_append(&pair, message, sizeof(message), &observations);
    uint8_t drained[1024];
    CHECK(BIO_read(SSL_get_rbio(pair.server), drained, sizeof(drained)) == 1024);
    CHECK(memcmp(drained + 1022, flight, 2) == 0);
    uwz_alloc_begin();
    CHECK(bssl::tls_flush(bssl::FromOpaque(pair.client)) == 1);
    uwz_alloc_end();
    const AllocationCounts completion_counts = counts();
    check_zero(&completion_counts);
    CHECK(state->pending_flight_offset == 0 && state->pending_flight->length == 0);
    check_bytes(state->pending_flight->data, 0, 27, 0);
    check_bytes(state->pending_flight->data, 27, 40, 0x6b);
    CHECK(BIO_read(SSL_get_rbio(pair.server), drained, sizeof(drained)) == 25);
    CHECK(memcmp(drained, flight + 2, 25) == 0);
    check_output_owners(state, &initial);
    printf("{\"scope\":\"direct_generated_transport_not_peer_decryption\",\"suite\":%u,"
        "\"partial_prefix\":2,\"remaining_tail\":25,\"only_consumed_bytes_cleansed\":true,"
        "\"partial_offset_append_rejected\":true,\"owners_stable\":true,\"heap_operations\":0}\n", suite);
    destroy_pair(&pair);
}

int main(int argc, char **argv)
{
    CHECK(argc == 4);
    CHECK(uwz_alloc_self_test());
    CHECK(!SSL_reserve_key_update_output_buffers(nullptr));
    ERR_clear_error();
    const uint16_t suites[] = {0x1301, 0x1302, 0x1303};
    for (uint16_t suite : suites) {
        empty_and_bounds(argv, suite);
        encoded_flight(argv, suite, SSL_KEY_UPDATE_NOT_REQUESTED);
        encoded_flight(argv, suite, SSL_KEY_UPDATE_REQUESTED);
        partial_flight(argv, suite);
    }
    puts("PASS: all-suite encoding, exact output bounds, borrowed restore, empty semantics and partial/full erasure; self-test63");
}
