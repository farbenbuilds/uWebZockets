#!/usr/bin/env python3
"""Build or replay one real nested BIO other-SSL error-queue preservation control."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('pki_tool', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--prebuilt', type=Path)
    parser.add_argument('--candidate', action='store_true')
    parser.add_argument('--zig', default='/tmp/zig-x86_64-linux-0.16.0/zig')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    native = args.native_root.resolve(strict=True)
    tool = args.pki_tool.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    if sha(tool) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('PKI helper checksum differs')
    output.mkdir(mode=0o700)
    environment = dict(os.environ)
    environment['ZIG_GLOBAL_CACHE_DIR'] = str(base / 'global-cache')
    commands = []
    complete = False

    def run(command, stem):
        with (output / (stem + '.stdout')).open('wb') as stdout, \
             (output / (stem + '.stderr')).open('wb') as stderr:
            result = subprocess.run(command, cwd=output, env=environment,
                                    stdout=stdout, stderr=stderr)
        commands.append({'command': command, 'exit_code': result.returncode, 'stem': stem})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode != 0:
            raise RuntimeError('Command failed: ' + str(output / stem))

    archives = [native / 'native_out/lib/libssl.a', native / 'native_out/lib/libcrypto.a']
    names = ['ticket_pair.h', 'error_snapshot_nested.cc']
    (output / 'provenance.json').write_text(json.dumps({
        'native_archive_sha256': {p.name: sha(p) for p in archives},
        'source_sha256': {name: sha(base / name) for name in names},
        'candidate_api': args.candidate, 'optimization': 'Debug (-O0 -g)',
        'scope': 'real A fatal-alert BIO write synchronously reads independent SSL B; exact original and nested full error queues replay; functional-only, no heap-count claim'}, indent=2) + '\n')
    binary = args.prebuilt.resolve(strict=True) if args.prebuilt else output / 'error_snapshot_nested'
    if not args.prebuilt:
        run([args.zig, 'c++', '-std=c++17', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
             '-DBORINGSSL_IMPLEMENTATION', '-DERROR_RESERVED_API=' + str(int(args.candidate)),
             '-isystem', str(native / 'boringssl'), '-isystem', str(native / 'boringssl/include'),
             str(base / 'error_snapshot_nested.cc'),
             *[str(p) for p in archives], '-o', str(output / 'error_snapshot_nested')], 'build-direct')
    pki = output / 'private_pki'
    try:
        run([str(tool), 'pki', str(pki)], 'pki_metadata')
        fixture = [str(pki / name) for name in ['server.pem', 'server.key', 'ca.pem']]
        run([str(binary), *fixture], 'clear')
        complete = True
    finally:
        if pki.exists():
            names = {p.name for p in pki.iterdir()}
            if names - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected private fixture output')
            for name in names:
                (pki / name).unlink()
            pki.rmdir()
        (output / 'results.json').write_text(json.dumps({'complete': complete,
            'private_pki_removed': not pki.exists(), 'binary_sha256': sha(binary)}, indent=2) + '\n')
    print('PASS: real nested BIO other-SSL error-queue preservation; private PKI removed')


if __name__ == '__main__':
    main()
