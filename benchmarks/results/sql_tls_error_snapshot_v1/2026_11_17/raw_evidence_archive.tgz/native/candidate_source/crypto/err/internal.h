// Copyright 2017 The BoringSSL Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef OPENSSL_HEADER_CRYPTO_ERR_INTERNAL_H
#define OPENSSL_HEADER_CRYPTO_ERR_INTERNAL_H

#include <openssl/err.h>


BSSL_NAMESPACE_BEGIN

// Private error queue functions.

// ERR_SAVE_STATE contains a saved representation of the error queue. It is
// slightly more compact than `ERR_STATE` as the error queue will typically not
// contain `ERR_NUM_ERRORS` entries.
typedef struct err_save_state_st ERR_SAVE_STATE;

// ERR_SAVE_STATE_free releases all memory associated with `state`.
OPENSSL_EXPORT void ERR_SAVE_STATE_free(ERR_SAVE_STATE *state);

// ERR_save_state returns a newly-allocated `ERR_SAVE_STATE` structure
// containing the current state of the error queue or NULL on allocation
// error. It should be released with `ERR_SAVE_STATE_free`.
OPENSSL_EXPORT ERR_SAVE_STATE *ERR_save_state();

// ERR_restore_state clears the error queue and replaces it with `state`.
OPENSSL_EXPORT void ERR_restore_state(const ERR_SAVE_STATE *state);

BORINGSSL_MAKE_DELETER(ERR_SAVE_STATE, ERR_SAVE_STATE_free)

// ERR_RESERVED_STATE owns capacity for every error queue entry. Unlike
// ERR_SAVE_STATE, capturing and restoring entries without data allocates nothing.
typedef struct err_reserved_state_st ERR_RESERVED_STATE;

// ERR_RESERVED_STATE_new initializes the calling thread's error queue and
// allocates an empty reserved state without changing queued errors. It returns
// nullptr on allocation failure.
OPENSSL_EXPORT ERR_RESERVED_STATE *ERR_RESERVED_STATE_new();

// ERR_RESERVED_STATE_free releases the state and all owned error data.
OPENSSL_EXPORT void ERR_RESERVED_STATE_free(ERR_RESERVED_STATE *state);

// ERR_save_reserved_state replaces a non-null reserved state with a deep copy of
// the calling thread's error queue. Error data retains the generic heap-copy
// behavior, including possible data loss on copy allocation failure.
OPENSSL_EXPORT void ERR_save_reserved_state(ERR_RESERVED_STATE *state);

// ERR_restore_reserved_state replaces the calling thread's error queue with a
// deep copy of the reserved state, or clears the queue if state is nullptr.
OPENSSL_EXPORT void ERR_restore_reserved_state(const ERR_RESERVED_STATE *state);

BORINGSSL_MAKE_DELETER(ERR_RESERVED_STATE, ERR_RESERVED_STATE_free)

BSSL_NAMESPACE_END

#endif  // OPENSSL_HEADER_CRYPTO_ERR_INTERNAL_H
