#include <openssl/err.h>
#include <openssl/ssl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#include "crypto/err/internal.h"
#include "crypto/internal.h"
#include "ticket_fault.h"

#define REQUIRE(value) do { if (!(value)) { fprintf(stderr, "FAIL line%d: %s\n", __LINE__, #value); abort(); } } while (0)

struct FactoryCase {
  size_t fail_ordinal;
  TicketFaultStats stats;
  bool complete;
};

static void *cold_factory(void *opaque) {
  auto *test = static_cast<FactoryCase *>(opaque);
  REQUIRE(bssl::CRYPTO_get_thread_local(bssl::OPENSSL_THREAD_LOCAL_ERR) == nullptr);
  ticket_fault_reset();
  ticket_fault_arm_ordinal(test->fail_ordinal);
  bssl::UniquePtr<bssl::ERR_RESERVED_STATE> failed(bssl::ERR_RESERVED_STATE_new());
  ticket_fault_disarm();
  REQUIRE(failed == nullptr);
  REQUIRE(bssl::CRYPTO_get_thread_local(bssl::OPENSSL_THREAD_LOCAL_ERR) == nullptr);
  const TicketFaultStats stats = ticket_fault_read();
  REQUIRE(stats.attempts == test->fail_ordinal && stats.injected == 1);
  REQUIRE(stats.successful == test->fail_ordinal - 1 && stats.actual_frees == stats.successful && stats.live == 0);
  REQUIRE(stats.requested_bytes == (test->fail_ordinal == 1 ? 400 : 440));
  REQUIRE(stats.calloc_calls == 0 && stats.realloc_calls == 0 && stats.cleanse_failures == 0);

  bssl::UniquePtr<bssl::ERR_RESERVED_STATE> retry(bssl::ERR_RESERVED_STATE_new());
  REQUIRE(retry != nullptr);
  REQUIRE(ERR_get_error() == 0);
  ERR_put_error(ERR_LIB_SSL, 0, SSL_R_DECODE_ERROR, "synthetic_factory_retry.cc", 71);
  bssl::ERR_save_reserved_state(retry.get());
  ERR_clear_error();
  bssl::ERR_restore_reserved_state(retry.get());
  REQUIRE(ERR_get_error() == ERR_PACK(ERR_LIB_SSL, SSL_R_DECODE_ERROR));
  REQUIRE(ERR_get_error() == 0);
  retry.reset();
  ERR_clear_error();
  test->stats = ticket_fault_read();
  REQUIRE(test->stats.live == 0 && test->stats.actual_frees == stats.actual_frees);
  test->complete = true;
  return nullptr;
}

int main() {
  ERR_clear_error();
  for (size_t ordinal = 1; ordinal <= 2; ordinal++) {
    FactoryCase test = {ordinal, {}, false};
    pthread_t thread;
    REQUIRE(pthread_create(&thread, nullptr, cold_factory, &test) == 0);
    REQUIRE(pthread_join(thread, nullptr) == 0 && test.complete);
    printf("PASS cold_factory_oom: ordinal=%zu attempts=%llu successful=%llu freed=%llu bytes=%llu live=0; ERRslot absent, retry empty then capture/restore valid\n",
           ordinal, static_cast<unsigned long long>(test.stats.attempts),
           static_cast<unsigned long long>(test.stats.successful),
           static_cast<unsigned long long>(test.stats.actual_frees),
           static_cast<unsigned long long>(test.stats.requested_bytes));
  }
  puts("PASS two cold calling-thread initialization failure cases; independent from SSL owner-pair publication");
}
