#!/usr/bin/env python3
"""Build or replay bounded error snapshot ownership checks using supplied libraries."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--candidate', action='store_true')
    parser.add_argument('--prebuilt', type=Path)
    parser.add_argument('--zig', default='/tmp/zig-x86_64-linux-0.16.0/zig')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    native = args.native_root.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    output.mkdir(mode=0o700)
    environment = dict(os.environ, ZIG_GLOBAL_CACHE_DIR=str(base / 'global-cache'))
    commands = []

    def run(command, name):
        with (output / (name + '.stdout')).open('wb') as stdout, \
             (output / (name + '.stderr')).open('wb') as stderr:
            result = subprocess.run(command, cwd=output, env=environment,
                                    stdout=stdout, stderr=stderr)
        commands.append({'command': command, 'exit_code': result.returncode, 'stem': name})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode:
            raise RuntimeError('Command failed: ' + str(output / name))

    binary = args.prebuilt.resolve(strict=True) if args.prebuilt else output / 'error_snapshot_direct'
    archives = [native / 'native_out/lib/libcrypto.a']
    if not args.prebuilt:
        run([args.zig, 'cc', '-std=c11', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
             '-c', str(base / 'allocation_scope.c'), '-o', str(output / 'allocation_scope.o')], 'build-counter')
        run([args.zig, 'c++', '-std=c++17', '-O0', '-g', '-Wall', '-Wextra', '-Werror',
             '-DBORINGSSL_IMPLEMENTATION', '-DERROR_RESERVED_API=' + str(int(args.candidate)),
             '-isystem', str(native / 'boringssl'), '-isystem', str(native / 'boringssl/include'),
             str(base / 'error_snapshot_direct.cc'), str(output / 'allocation_scope.o'),
             *[str(p) for p in archives], '-pthread', '-o', str(binary)], 'build-direct')
    run([str(binary)], 'direct')
    (output / 'results.json').write_text(json.dumps({
        'complete': True, 'candidate_api': args.candidate,
        'binary_sha256': sha(binary),
        'native_archives_sha256': {p.name: sha(p) for p in archives},
        'sources_sha256': {n: sha(base / n) for n in ['allocation_scope.c', 'error_snapshot_direct.cc', 'run_direct.py']},
    }, indent=2) + '\n')
    print((output / 'direct.stdout').read_text(), end='')


if __name__ == '__main__':
    main()
