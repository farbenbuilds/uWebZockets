# Reusable TLS error snapshots, Phase A

This is an isolated native candidate, not production integration or the complete
PostgreSQL allocation gate. It changes six paths relative to the validated
ticket-discard candidate and fourteen paths cumulatively relative to pinned
BoringSSL d3bf4795ad5b79d646cddf2fec687da5b9b502db. All 8709 source entries are
inventoried. The initial cumulative-path estimate of fifteen was corrected by
the inventory: ssl/s3_pkt.cc was already modified in the preceding candidate.

## Contract and ownership

`SSL_reserve_error_state` prepares two independent opaque error snapshots for
an idle completed ordinary TLS 1.3 client. Each fixed record capacity holds all
fifteen error queue entries. On the measured x86_64 build, each owner requests
368 raw C bytes; both startup owners request 736 bytes. Both must be prepared
before either is published. SSL3_STATE grows from 640 to 656 bytes.

The persistent read snapshot and temporary alert snapshot cannot alias: alert
output may disturb the calling thread's queue before the fatal read state is
captured. Default generic ERR_SAVE_STATE remains a sixteen-byte descriptor
with its original separately allocated entry array. Existing generic capture,
restore, destructor and err_copy bodies are unchanged. Saved copies continue
to reset marks, as the original implementation does.

No-data capture and restoration require no heap operation after reservation
and actual-thread queue initialization. Arbitrary error text still uses the
generic full raw C heap deep copy; allocation failure preserves metadata and
may omit the copied data exactly as before. There is no text truncation or
new PostgreSQL allocation exception. Reserved alert text remains owned until
recapture or SSL state destruction, while the original temporary owner frees
its copy immediately after restoration; data free timing is not claimed equal.

Mutating SSL I/O must be serialized and non-reentrant. The first successful
reservation initializes the calling thread's queue. Serial migration requires
the destination thread to initialize its own queue before counted use;
idempotent reservation does not warm another thread implicitly. Cold worker
restore measured two mallocs and 440 bytes: a 400-byte ERR_STATE plus the
forty-byte thread-local pointer table. Warm worker restore measured zero.

Successful SSL_clear releases both owners and resets the reservation. A public
configuration-shedding preflight failure preserves the old S3 and owners.
Replacement-state allocation failure destroys old S3 and owners before failing;
this is not atomic rollback. SSL_free releases each owner once. Thread queue
data and a popped ERR_get_error_line_data string remain independent of SSL
storage. Non-reentrant mutation applies to each SSL separately. The nested
control below mutates a distinct SSL B while SSL A owns its alert-write snapshot. Raw error states/data have no secure-erasure contract; the separate
explicit OpenSSL S3 erasure watch verifies the 656-byte state payload.

## Build and exact source

`build_commands.json` and `build-native.log` record a fresh native Zig Debug
build, six of six steps, covering the full matching SSL/crypto graph. Build
inputs match the previous candidate. Compilation and linking use Zig only.
The immutable native libraries remain external to this evidence payload:

- libssl.a: 48e2928a79013579ddec9dea7bd1d750771e30a35d5091182db26af5555e960d
- libcrypto.a: 2143f831f9f57907f47a51dfc0fae9942f33b8c3ca6d378cca6cc90b387ea4dd

`stage_a.patch` is the six-file incremental diff. `candidate.patch` and
`candidate_source/` contain the cumulative fourteen-file proposal.
`source_invariants.json` proves eleven relevant pre-existing function bodies
unchanged, including all prior reservation APIs, ticket policy and SSL_clear.

Restore into an absent directory using an exact external source input:

```
python3 restore_source.py ORIGINAL_SOURCE ABSENT_OUTPUT
python3 restore_source.py --source-kind ticket-discard PRIOR_SOURCE ABSENT_OUTPUT
```

Both modes validate the complete file set, regular file types, modes and hashes
before copying. Final snapshot modes match the candidate inventory. Two complete
8709-entry restorations match all types/modes/hashes/links; two existing-output
refusals and one chmod-only input refusal occur before destination creation.

## Selected functional evidence

Seven direct cases cover fifteen-entry wrap, original mark-reset behavior,
independent A-B-A snapshots, full 6000-byte data and popped-string lifetime,
15-to-1-to-0 reuse, repeated static capture and cold/warm worker handoff.
Eight repeated static captures/restores count sixteen mallocs/fourteen frees/
320 bytes on the baseline and zero operations on the reserved candidate.

Two additional fresh-thread factory fault rows target the 400-byte ERR_STATE
allocation and the subsequent forty-byte thread-local table allocation. Factory
failure leaves the thread ERR slot absent and balances the allocations made on
the failed path (zero/zero and one/one). A disarmed successful retry begins with
an empty queue, captures/restores a synthetic reason and frees the snapshot.
Retry thread queue/table storage remains owned by the thread until pthread
teardown; the failed-path balance does not assert early freeing of that storage.
`factory_oom_candidate_corrected` records these internal constructor controls,
separate from the public SSL owner-pair publication tests. Initial test compilation
required adding the explicit SSL header for its reason constant; no assertion or
native behavior changed.

Both selected direct binaries use the exact original all-C counter
afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac,
including its 63-byte self-test. Their result directories are
`direct_baseline_original_counter` and `direct_candidate_original_counter`.

Three separate ownership fault cases preserve generic capture/restore data-copy
OOM semantics and prove all fifteen old copied strings are released when a
reserved capture shrinks to one and then zero entries. The baseline and candidate
fault binaries live in `oom_baseline` and `oom_candidate`; successful final runner
replays are in `oom_baseline_final` and `oom_candidate_final`.

`lifecycle_candidate_corrected` proves successful startup and both nth-owner
allocation failures, queue text/flags/metadata and prior SSL option preservation,
idle idempotence, sibling independence, seventeen isolated state guards plus null
SSL rejection, and the three public clear boundaries. Every tracked raw snapshot
owner is freed once; each watched OpenSSL S3 is erased and freed once.

All five inherited reservation families rebuild against the final native pair.
The fifty-one previous source/data inputs, plus the unchanged record-family
orchestration driver, remain byte-identical. They prove output direct/sealer
failure/23 lifetime cases; AEAD 24 epochs, 12 initializer failures, 48 transitions
and 22 lifetime cases; 64 incoming handshake loops and 21 lifetime cases;
16 record lifecycle cases plus buffer/TLS-pair controls; and 1440 HKDF cases
(700 successful calls zero heap operations and 740 unchanged rejections).
`inherited_run/` records the aggregate commands. Its tiny Zig wrapper sets the
workspace SSD cache while the inherited input runners remain unchanged.

`prebuilt_identity.json` selects twenty-one measured Debug executables. Replay
requires only Python and the external checksum-verified offline PKI helper:

```
python3 replay_prebuilt.py --pki-tool PKI_TOOL --output ABSENT_OUTPUT
```

The final producer replay completed 86 commands with matching recorded outputs,
removed the private PKI, and passed existing-output and bad-tool refusals.
`prebuilt_replay_complete/` contains that replay; earlier eighteen-program/83-command and twenty-program/85-command replays remain in `prebuilt_replay/` and `prebuilt_replay_final/`. Source and native archives are not
required for this prebuilt replay. No private certificate/key bytes are retained.

A separate authentic nested BIO control passes on both prior generic and new
reserved libraries. Verified client A receives a corrupted encrypted application
record. Its actual fatal-alert BIO write synchronously reads a queued public
fatal alert on distinct verified client B, replacing the same thread's error
queue. A then exposes its exact two-entry bad-MAC queue, including file, line,
flags and order. B's repeated public read restores its own full diagnostic text,
and A repeats its original queue. Both native snapshots remain independent.
This is a functional control, with no nested callback allocation claim.
`nested_baseline` and `nested_candidate` hold the selected binaries;
`nested_baseline_final` and `nested_candidate_final` hold corrected-scope final
runner replays and provenance. Their initial compile directories retain copied
lifecycle-scope metadata as historical driver lineage, not the selected scope.

## Fixture corrections and limits

Preliminary direct compilation exposed a signed/unsigned test comparison; an
explicit cast fixed the fixture without weakening -Werror. The initial cold
thread expectation counted ERR_STATE but omitted the forty-byte native TLS
pointer table. Raw diagnostic counts and source attribution corrected the exact
assertion from one/400 to two/440; the warm-zero assertion remained unchanged.

The initially copied earlier helper counter was a return-site diagnostic variant,
not the original counter. Those preliminary results remain diagnostic lineage.
Both final direct binaries were rebuilt with the exact original counter above.
`fixture_history/` includes source versions reconstructed from the recorded edits,
the diagnostic counter and the cold-thread diagnostic source. They are labeled
history, not frozen originals of earlier output directories.

Initial public fixture compilation also found a local parameter shadowing the
inherited CHECK failure function and a const Span assigned to mutable pending
data. Correcting those test types/names preserved every assertion. An OOM driver
then used the wrong filename only when printing already successful results;
the corrected driver replayed the same immutable binaries into fresh result
directories and exited zero. Failed logs remain retained; preliminary binaries
are excluded from the selected payload.

The source-restoration mode check was added after independent review detected
that hash-only validation could propagate chmod-only drift. The focused mode
refusal and both complete restoration checks above verify the correction;
native source and archives did not change.

Authentic public fatal traffic and healthy ticket/KeyUpdate controls are in the
separate wire producer. This producer establishes bounded helper and lifetime
evidence only. Peer-alert diagnostic strings still allocate in Phase A. SQL
session teardown, reconnect/cancellation attribution, native publication,
production adoption and the complete PostgreSQL gate remain open. Dedicated
smoke/security/sanitizer/fuzz/scan campaigns remain user-deferred.
