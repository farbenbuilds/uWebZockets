# PostgreSQL TLS error storage: read-only architecture plan

Date: 2026-11-17. Scope accepted by Root for the still-active TODO.md v2.3.0 objective. This report contains planning and source analysis only; no native or repository edits, builds, tests, campaigns, pins, or remote writes were performed by the architect. The requested report itself is stored outside the repository.

## Decision and assumptions

Proceed in two independently reviewable native slices. Phase A adds explicitly reserved error snapshots for an ordinary completed TLS 1.3 client, preserving the generic saved-state type and byte counts. It must eliminate request-time allocation for fatal paths with metadata-only errors. Phase B adds owned short-string storage and removes the known peer-alert formatting allocation while retaining full heap fallback for arbitrary longer diagnostics. Phase A deliberately retains the peer-alert allocation as a positive control.

The exact immutable baseline is `.zig-cache/sql-tls-ticket-discard-fixed-20261117/boringssl`, based on BoringSSL d3bf4795ad5b79d646cddf2fec687da5b9b502db plus the reviewed record/HKDF/handshake/AEAD/output/ticket-discard proposals. Root reports 12 cumulative changed paths and 8709 source entries. The protected vendor trees are not source or mutation targets. New work starts from an exact copied candidate with an inventory; integration and pin/source policy remain Root's separate responsibility.

No PostgreSQL allocation exception is authorized. SQLite SQL-ALLOC-001 is the only approved exception. This plan does not assert zero allocation over reconnect, cancellation handshake, teardown, arbitrary application callbacks, or a new worker thread's first use. Those are separate attribution obligations, not automatic lifecycle exemptions. Root independently inspected the production SQL boundary and owns that follow-up.

The counted native scope is an already established ordinary TLS 1.3 client on an initialized worker, with the previously accepted record/post-handshake/KeyUpdate reservations enabled, no application callbacks that allocate or synthesize unbounded diagnostics, and authentic public SSL_read/SSL_write execution. The implementation must continue to accept longer diagnostic data with existing semantics outside that source-bounded native case.

## Source contract and allocation roots

All local references below are to the immutable candidate, not protected vendor copies.

- `crypto/err/err.cc:39-73`: private error records own optional raw-system-malloc data. ERR_STATE contains a 16-slot ring, top/bottom, and an independently owned popped-data slot. `include/openssl/err.h:397-400` fixes the live bound at ERR_NUM_ERRORS - 1, currently 15.
- `crypto/err/err.cc:78-113`: err_copy clears its destination, copies metadata, and duplicates optional data using raw malloc. It does not copy marks. On text-copy OOM, metadata is replaced and optional text can be absent; this existing non-atomic behavior must not be misrepresented as transactional.
- `crypto/err/err.cc:130-146`: ERR_STATE is lazily allocated per thread, registered with the existing OS thread-local destructor. Main-thread warming does not warm a worker. ERR_remove_thread_state clears entries rather than destroying the thread object.
- `crypto/err/err.cc:148-205` and `include/openssl/err.h:83-108`: returned data is owned by the error queue, including after a pop. Its guaranteed lifetime lasts until the next call affecting that same thread's error queue. ERR_FLAG_MALLOCED means non-static lifetime on output; the caller must never free the returned pointer. Peeking must not invalidate the queue's data.
- `crypto/err/err.cc:622-703`: public concatenation/printf/set operations accept unbounded caller strings. ERR_set_error_data copies input before replacing old data and consumes OPENSSL_malloc input when its input MALLOCED flag is set. Alias-safe replacement and allocator provenance must remain intact.
- `crypto/err/err.cc:749-840`: ERR_SAVE_STATE is currently a 16-byte descriptor on x86_64 plus a separate N * 24-byte record allocation. Saving and restoring duplicate optional data. The generic descriptor, allocation strategy, and entry size are unchanged in Phase A.
- `ssl/ssl_lib.cc:75-97`: ssl_set_read_error retains a persistent snapshot; check_read_error restores it on subsequent calls. SSL_read clears the thread queue on entry and then restores this error. There is no equivalent persistent write snapshot to invent.
- `ssl/s3_pkt.cc:340-355`: ssl_send_alert separately snapshots the queue around output. Its comment explicitly permits a BIO which calls SSL_write on another SSL. Therefore the temporary alert snapshot and persistent read snapshot must have independent owners. One shared buffer is incorrect.
- `ssl/tls_record.cc:448-500`: a received fatal alert appends the exact diagnostic `SSL alert number %d`, with an 8-bit alert description. The longest native value, 255, requires 21 bytes including NUL. It must preserve the same reason, metadata, diagnostic text, flags, callback order, and absence of a response alert.
- `ssl/tls_record.cc` record parse/authentication failures and `ssl/tls13_both.cc:731-790` completed-client post-handshake failures use static metadata. Initial certificate/extension/handshake formatted errors elsewhere are not evidence of ordinary completed-client reachability.
- `crypto/mem.cc:454-503`: OPENSSL_vasprintf_internal always allocates an initial 64-byte buffer, formats once, and may resize/reformat. Generic formatting must not be casually changed to a two-pass implementation, particularly for varargs side effects, aliasing, errors, or platform behavior.
- `ssl/ssl_lib.cc:3593-3631`: SSL_clear preflight failure (for example shed config) retains old state. Once method->ssl_free runs, replacement allocation failure is destructive: old S3 and its owners are already gone. Preserve this distinction.

The ERR implementation prohibits OPENSSL_malloc internally because reporting an allocation failure could recurse into the queue. Use raw malloc/free only for its owned allocations, as today. No global arena, allocator interception, new thread singleton, borrowed SSL-backed data, or refcount scheme is needed.

Primary sources: [pinned ERR header](https://github.com/google/boringssl/blob/d3bf4795ad5b79d646cddf2fec687da5b9b502db/include/openssl/err.h), [pinned ERR implementation](https://github.com/google/boringssl/blob/d3bf4795ad5b79d646cddf2fec687da5b9b502db/crypto/err/err.cc), [pinned alert parser](https://github.com/google/boringssl/blob/d3bf4795ad5b79d646cddf2fec687da5b9b502db/ssl/tls_record.cc), [TLS 1.3 error alerts](https://www.rfc-editor.org/rfc/rfc8446.html#section-6.2). Local candidate reads establish the proposal-specific state; upstream source links establish the unchanged original contract. No protocol validation, cryptographic failure, or termination rule is relaxed.

## Accepted Phase A type and API

Keep ERR_SAVE_STATE and ERR_save_state/ERR_restore_state unchanged. Add a distinct opaque internal ERR_RESERVED_STATE in `crypto/err/internal.h`; its definition is private to err.cc:

    struct err_reserved_state_st {
      err_error_st errors[ERR_NUM_ERRORS - 1];
      size_t num_errors;
    };

Use these internal functions and the existing UniquePtr deleter mechanism:

    ERR_RESERVED_STATE *ERR_RESERVED_STATE_new();
    void ERR_RESERVED_STATE_free(ERR_RESERVED_STATE *state);
    void ERR_save_reserved_state(ERR_RESERVED_STATE *state);
    void ERR_restore_reserved_state(const ERR_RESERVED_STATE *state);

The named type proves a full queue capacity and owns a single raw startup allocation. It has no grow path and no public configurable capacity. A new owner starts empty with initialized entries. Its constructor also ensures the current thread's ERR_STATE exists without consuming/replacing that queue; failure returns null and avoids recursive error reporting. On current x86_64 layout the owner is 15 * 24 + 8 = 368 bytes, two owners 736 bytes per opted-in SSL, plus two owner pointers in S3. Tests must measure actual sizeof/alignment rather than make an external ABI promise.

Saving copies the source queue's logical FIFO order without modifying it. Shrinking or empty capture clears every formerly owned trailing entry, then records the new count. Restoring preserves the same logical queue order, metadata, optional text, and mark-clearing behavior as existing err_copy. Text remains a deep copy with the current full raw-malloc fallback and current non-atomic copy-OOM behavior; Phase A makes no allocation-free promise for data-bearing entries. A null/empty reserved restore follows the generic empty-restore clearing behavior. Do not expose a borrowed generic-state pointer or a pointer accessor into the reserved object.

The ERR module owns queue representation, copied data, snapshots, and lifetime. SSL knows only the opaque owner and capture/restore operations. A shared private copy/restore algorithm is justified by the ownership and fixed-capacity invariant, not forwarding convenience. Deletion test: deleting the opt-in and its SSL fields must leave the generic ERR APIs and default SSL behavior intact; no SSL-specific queue representation or allocator logic may remain in SSL.

## Phase A SSL opt-in and lifecycle

Add `SSL_reserve_error_state(SSL *ssl)` to the native header/implementation, following the existing explicit reservation family. Keep the generic S3 read_error owner. Add reserved_read_error and reserved_alert_error owners. Allocate both into locals and publish both only after success; runtime uses the reserved branch only for a complete pair. No partially installed option is allowed.

Eligibility uses the ordinary-client guards of the existing KeyUpdate output/ticket opt-ins: non-null S3, TLS 1.3, non-DTLS/non-QUIC, client, completed handshake, no shutdown/error, no pending app/write/read/output data, no unreported writes/message/alert/KeyUpdate candidate or dispatch, no partial handshake/flight contents or nonzero flight offset. It does not require a new cipher or cache restriction. Calls are serial and must not recursively mutate the same SSL; observational callbacks remain governed by existing contracts.

A repeated eligible call is idempotent. The first successful call prepares only that calling thread's error queue. A later serial handoff of SSL is permitted, but zero-allocation use on the destination thread requires that thread's ERR queue to have been initialized before counted work. Idempotent repeat does not promise to warm a different thread. No new public thread-initialization API or hidden thread registry is introduced.

In ssl_set_read_error capture into reserved_read_error when enabled; otherwise retain the existing generic path. In check_read_error restore from that same selected owner. In ssl_send_alert save/restore through reserved_alert_error when enabled; otherwise retain its existing local generic snapshot. Nested use of another SSL therefore cannot alias either saved owner. Preserve alert/write/backpressure/callback ordering.

Allocation failure must not publish one owner, discard an existing option, or change live crypto/IO state. Internal raw constructor failure returns null without consuming the existing queue. Invalid public argument/state guards still report the same conventional SSL errors as the existing reservation APIs; therefore 'every failed call leaves the entire queue bit-for-bit unchanged' is not the contract. Test both preserved preexisting entries and documented added error reporting.

Successful SSL_clear destroys old S3, frees both reservations, and resets the opt-in; a new handshake requires a new reservation. Preflight failure preserves old S3 and owners. Replacement-state OOM after ssl_free destroys them, as the baseline already does. SSL_free frees both owners exactly once. The thread queue and any popped-data pointer remain independent and may outlive SSL. No application-callback completion or SQL reconnect exemption follows from this lifecycle.

## Phase B: short data, separately approved implementation

The narrow extension is owned inline short-string capacity in private ERR records and an independently owned thread popped-data slot, with unchanged full heap spill for longer strings. A 32-byte inline capacity safely contains the native 21-byte alert string. It is an optimization threshold, never a diagnostic limit. No data may be truncated, omitted because it crosses that threshold, or borrowed from an SSL snapshot. The exact representation and measured size require separate review; a straightforward 32-byte payload raises a private record from 24 to roughly 56 bytes, the thread queue from 400 to roughly 944 bytes, and each 15-record reservation from 368 to roughly 848 bytes on x86_64. These are estimates, not ABI claims.

Required operations are explicit owned-data clear, copy, and move-to-popped-storage. Inline data must not be raw-pointer-copied across records. On a data-bearing pop, copy short text into thread-owned popped storage or transfer an owned heap block; return STRING|MALLOCED even when physically inline. On peek, return the current owned text without invalidating it. SSL destruction must never invalidate returned queue data. Replacement must first stage/copy aliased input before clearing it. Preserve allocator provenance and existing input MALLOCED consumption, marks, queue overflow, null-data versus empty-string semantics, and optional-data OOM behavior.

Avoid a generic vsnprintf/vasprintf rewrite. Format the one source-bounded peer-alert diagnostic into a local buffer sized for the proven 0..255 range, verify the formatting result, and pass it through the copy-taking ERR_set_error_data path. A known-safe bounded decimal encoder is another implementation option only if the crypto owner justifies it; the preferred minimal change is the existing snprintf family plus an exact bound and public-path allocation witness. General ERR_add_error_dataf/concatenation retains full existing formatting behavior and heap fallback. Short data installed by ERR_set_error_data, and all snapshot save/restore copies of it, use owned inline storage. The API must not claim generic unbounded diagnostics are allocation-free.

This split is meaningful: Phase A removes the 16-byte saved header and N-record array per static failure without touching the error data layout; Phase B then removes initial peer-alert text allocation and subsequent text duplication. Phase B may change private default memory sizes; Phase A must retain current generic descriptor/array byte-count controls.

## Ordered TDD and acceptance

1. Preserve a fresh immutable baseline witness first. Test owner uses the real public TLS client path with authentic ciphertext and all existing reservations. Initial five rows for suite 1301: empty NewSessionTicket, duplicate-flags NewSessionTicket, bad MAC, oversized record header, encrypted peer fatal alert. Observe first failure and three post-fatal read/write cycles; call SSL_get_error immediately before other queue operations. Snapshot/drain complete ERR_get_error_line_data output between cycles. Retain raw allocation counts and exact queue/callback/wire behavior. This is the required pre-edit RED, not a fake internal-state substitute.
2. Crypto owner adds the internal reserved-state primitive and focused ERR tests. Verify empty, one, full 15, wrap/overflow FIFO, long text fallback, capture without source mutation, repeated restore, shrink-to-zero cleanup, mark behavior, independence of two snapshots, and all raw allocation failure indices. Generic ERR_SAVE_STATE count/bytes remain unchanged in Phase A. Use real queue APIs; constructing public queue entries for unit tests is allowed, staging SSL internal state is not.
3. Crypto owner adds the SSL opt-in and two-owner wiring. Build/vendor owner supplies exact native Zig-only compilation/inventory. Repeat the same five rows: metadata-only rows must be 0 malloc/0 free in the defined window, including replay; peer-alert text remains a positive RED. Extend to all currently exercised 18 fatal rows and three supported suites only after the small matrix passes. Compare exact alert reason/data/file/line/flags, callbacks, output ordering, fatal state, and no plaintext delivery.
4. Independently review Phase A before freezing its candidate. Review focus is ownership, raw allocator provenance, same-SSL reentrancy, thread warming, data-copy OOM and clear failure distinctions. Root decides when the separate Phase B edit is released.
5. Phase B starts with peer-alert RED and direct ERR data boundary REDs. Test empty string, inline threshold minus one/exact/plus one including NUL, long and much longer strings, aliased current-data replacement, input MALLOCED consumption, peek/pop lifetime, overflow/marks, repeated capture/replay, and OOM on heap spill. For peer alert test descriptions 0, 99, 255 and malformed alert bodies. Native ordinary fatal rows then require 0 malloc/0 free, while arbitrary long-data and unreserved paths remain honest allocating controls.

Mandatory cross-cutting checks in the focused functional witness:

- Default/unreserved control remains allocating with identical observable diagnostics; Phase A generic one-entry snapshot retains header16 + record24 on current x86_64.
- A fails, B fails on the same thread, then A replays: A's complete saved queue must return. Nested BIO use of B must not overwrite A's temporary or persistent owner.
- Pop a data-bearing error, retain its returned pointer, then free SSL without an intervening same-thread queue operation: text remains valid. Apply a queue-affecting operation only afterward. Preserve STRING|MALLOCED and no caller ownership.
- Startup OOM at first owner, second owner, and thread initialization when cold: fail cleanly with no partial publication or leaks. Retry after failure succeeds. Heap-spill/copy OOM retains existing metadata/data best-effort semantics, rather than inventing atomic diagnostic restoration.
- Clear success removes opt-in; preflight failure retains it; destructive replacement OOM frees old owners. Final free and thread destructor release each owned heap block once. Capture shrinking from a longer queue frees all stale owned tail data.
- First use on a cold other thread is an allocation control; preinitialized destination-thread use demonstrates the supported warmed-thread bound. No new SSL thread-affinity restriction is implied.
- Ineligible null, server, DTLS/QUIC, initial handshake, closed/fatal, pending input/output/handshake/flight/KeyUpdate and partial-publication states are rejected without enabling a partial option. Test runtime guard cases through real public state transitions where feasible; focused internal unit tests may enforce impossible invariant states separately and be labeled accordingly.
- Healthy application data, ticket-discard, requested/unrequested KeyUpdate controls remain zero with unchanged results. No native cipher policy, cache/session callback behavior, protocol validation, crypto result, or alert ordering changes.

Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain deferred by the user; this report does not claim they ran or relax their configured thresholds. Required repository gates remain zig fmt src builds examples tests fuzz; sh scripts/check_conventions.sh; sh scripts/check_release_version.sh; zig build test, with normal build/cross checks appropriate to integration. Any unrun campaign or external host/release gate is recorded as unrun, not satisfied by the focused witness.

## Ownership and delivery

- crypto_tls / native author: candidate-only crypto/err/err.cc, crypto/err/internal.h, ssl/internal.h, ssl/ssl_lib.cc, ssl/s3_pkt.cc, include/openssl/ssl.h; Phase B additionally ssl/tls_record.cc. The existing default APIs remain the reference behavior. No public root/App/C ABI TLS type is added.
- verification / wire owner: fresh pre-edit public-path RED; focused ERR and SSL functional/lifecycle/control harnesses and readable allocation ledger. No staging of private SSL crypto/session/sequence state.
- build_vendor: exact candidate copy, source inventory, Zig 0.16.0 native source-list build and auditable artifact identity. No CMake/Ninja/Perl/Python/patch build requirement, overlays, protected-vendor mutation, or pin change.
- reviewer plus crypto specialist: independent read-only review of resulting diff and evidence, including boundary sizes, ownership, queue survival after SSL destruction, OOM and nested-BIO behavior. Re-review any fix before integration.
- Root/integrator: production wrapper adoption only after the native seam is proven, plus SQL failure/close/reconnect/cancel attribution, public bindings/source policy, repository gates, release docs and commits. Push only to origin/impl/implement-2.3.0. This architecture work itself makes no remote write.

The plan stress test resolves the main branches explicitly: queue lifetime is independent of SSL; two owners handle alert and read snapshots; arbitrary diagnostic data remains unbounded with honest spill; cold-thread setup is distinct from replay; clear OOM is destructive after replacement begins; SQL reconnect/cancel allocations remain open production work. The pinned grill-me/grilling routing was read; no new requirement interview is introduced because Root has supplied and accepted these decisions. The older crypto role's blanket patch/upstream guidance conflicts with the current task's immutable-candidate/no-write constraints and newer root build/fork policy; Root's current constraints govern, and no patch/remote action is proposed.

Next concrete action: Root releases the accepted Phase A candidate edit only after the test owner records the five-row public-path baseline. Native author then implements the opaque reserved ERR type and its tests first, followed by SSL opt-in wiring; the peer-alert allocation remains a visible Phase B control.
