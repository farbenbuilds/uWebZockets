# Independent final delivery review: TLS error snapshots

Date: 2026-11-17. Reviewer: /root/tls_error_review.

No unresolved actionable findings remain in the prepared delivery stage:
.zig-cache/sql-tls-error-snapshot-evidence-20261117.
The final compressed archive has not yet been assembled; its exact members,
compressed bytes/hash and archive-present project gates remain Root-owned.

## Transformation and immutable inputs

I independently recomputed the read-only delivery proof for all 28 selected
ELF executables, rather than relying on the recorded success flag. Total size
changes from 443019392 to 122127264 bytes. Entrypoint/ABI, every program header,
allocated section contents/metadata, normalized PT_LOAD contents, regular symbol
tables and executable permissions remain unchanged. Load normalization excludes
only ELF section-table coordinates e_shoff, e_shnum and e_shstrndx. Debug sections
are removed from staged copies only; no native compilation/relinking occurs.
The GNU objcopy executable matches its recorded SHA256.

All 1512 original producer payload entries rehash successfully. The 1480 staged
entries outside the authorized executable/identity/manifest changes match the
producers byte for byte. Both staged subtrees have their exact frozen file sets,
with no added files or symlinks. Original measured executable maps, raw results,
source, runners and the historical wire baseline manifest are unchanged.
The native identity changes only its 21 executable hashes. The wire identity
changes seven hashes and its explicit delivery_stripping false-to-true flag.
Other JSON manifest metadata remains identical.

Bindings independently checked:

- Transform manifest: 81481ce6e332c60cfd2311d30d93aa9402d384fcf9042b18b7000b73eabca998.
- Transform files.sha256: cebaf6953e5b5fcbc2eebf0ba9eb8e092a96a55412a47cfe0397d7ad1947889b.
- Current native files.sha256: 12950d4599ba7aac3a3ad06806ceb40f6b1a5bc93110413aab4e955f000b6416.
- Current wire payload_manifest.json: 7dd133e8b0b670f850e31d8a234c164f838e5925ae0774345b31b3114f710446.

## Runtime records, boundaries and bootstrap

Root's delivered-program replay records contain 86 native and eighteen wire
commands, all with their expected statuses, completion flags and removed private
PKI. Executable command paths refer to the stage. I independently compared all
48 wire raw replay result files with retained measured bytes, and checked all
206 native plus 106 wire copied replay files against the external Root outputs.
I reviewed the native runner's output/case comparisons and its selected inventory;
I did not rerun the full matrices during this final delivery review.

All 312 production-input hashes and five source-restoration input bindings match
current files. Four combined-tree/existing-output refusal records match each
runner's actual error message, produce no stdout, and leave forbidden new
outputs absent. The checker-only correction distinguishes the native and wire
messages; the runners and refusal thresholds remain unchanged.

The bootstrap restores exactly the checksum-pinned offline archive member and
refuses unexpected existing targets. The temporary tools/wt-tools currently
exists in the stage, with the expected 5252542-byte size and SHA256
531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9.
It must be omitted from the final archive. The reviewed package builder explicitly
verifies and omits that file, rejects other tools, caches, private PKI, native
objects/archives and symlinks, and validates unique regular members with exact
payload hashes. It enforces README.md, manifest.sha256 and one archive as the
only three outer result files.

## Documentation and remaining work

Outer README, stage README, SQL documentation and updated plan retain the correct
scope: metadata-only fatal calls are zero; peer-data and full fatal gates remain
RED. The plan now explicitly separates three-suite protocol coverage from the
0x1301 public-control coverage. No production pin/adoption, PostgreSQL allocation
exception or release-completion claim is introduced. Recorded ordinary production
units are 1158/1182 with 24 live-PostgreSQL skips; those test production pins,
while the isolated native candidate has separate evidence.

Root must still assemble and verify the actual archive and outer manifest, run
the final archive-present convention/version/documentation gates and preserve
only the authorized tracked changes before commit/push. Dedicated smoke/security/
sanitizer/fuzz/scan campaigns remain user-deferred. The complete PostgreSQL
request-path allocation and production lifecycle gates remain open.
