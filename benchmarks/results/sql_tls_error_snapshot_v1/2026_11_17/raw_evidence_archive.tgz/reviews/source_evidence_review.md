# Independent review: reusable TLS error snapshots, Phase A

Date: 2026-11-17. Reviewer: /root/tls_error_review.

No unresolved actionable findings remain in the reviewed native source and
functional evidence. This conclusion covers retention of the isolated candidate;
production adoption, PostgreSQL's complete allocation gate and the final
transformed delivery archive are separate work.

## Reviewed identity and scope

- Incremental patch: e6b0086e78da6ff0051ec215febd327ed3467398fcbe98b198c0531624b54021.
- Cumulative patch: f6506a0e21b65ec0079198e64103e8752ee11dfa2c47cc617150e542c653a64f.
- Matching libssl.a: 48e2928a79013579ddec9dea7bd1d750771e30a35d5091182db26af5555e960d.
- Matching libcrypto.a: 2143f831f9f57907f47a51dfc0fae9942f33b8c3ca6d378cca6cc90b387ea4dd.
- Native producer: .zig-cache/sql-tls-error-snapshot-fixed-20261117.
- Wire producer: .zig-cache/sql-tls-error-allocation-witness-20261117.

The six changed native paths implement an opaque fifteen-record reserved state
and two independent per-SSL owners, with transactional startup publication.
Fourteen native paths differ cumulatively from the pinned original. I checked
all 8709 current candidate file/type/mode/hash entries and all eleven recorded
unchanged function bodies, including generic ERR copy/save/restore/free, earlier
reservation/policy APIs, SSL_clear and SSL_shutdown. The generic sixteen-byte
snapshot descriptor and arbitrary diagnostic text behavior remain intact.
The focused structural review found no unjustified abstraction or file split.

The read snapshot and alert snapshot cannot alias. Thread queue copies own their
data independently; queue data may outlive SSL_free. Non-reentrant mutation is
required for each SSL separately. The distinct-SSL nested BIO control verifies
the intended shared-thread error-queue boundary. Successful clear, preserving
preflight failure and destructive replacement-allocation failure remain distinct.
The reserved alert snapshot can retain its copied text until recapture/free;
identical diagnostic-data free timing is explicitly not claimed.

## Independently executed controls

I executed both selected original-counter seven-case direct binaries. Both
returned zero. Fifteen-entry wrap, original mark reset, A-B-A restoration,
6000-byte untruncated text and popped-string lifetime, shrinking/empty reuse and
serial worker handoff passed. Eight static capture/restore loops changed from
16 mallocs/14 frees/320 requested bytes to zero. A cold worker still requires
2 mallocs/440 bytes; a warmed worker requires zero.

I executed both selected three-case copy-OOM binaries. Metadata survives failed
6000-byte string copying with the same omitted-data behavior as the generic
implementation. All fifteen old copied strings are released on shrink/empty.
I executed the selected public lifecycle binary with fresh ephemeral PKI:
startup ordinals 0/1/2, two 368-byte owners, idempotence, sibling independence,
seventeen state guards plus null and all three clear boundaries passed. The
watched 656-byte S3 payload is erased and freed once; raw ERR objects/data have
no erasure contract.

I executed both authentic nested-BIO binaries with fresh ephemeral PKI. A real
A bad-MAC alert BIO write synchronously invokes B's public SSL_read and immediate
SSL_get_error for a public peer fatal alert. A's exact two-entry queue and B's
full diagnostic text/flags restore correctly on later reads. This is a functional
control with no nested-callback allocation claim. I also executed the two cold
factory OOM rows: fresh threads fail the 400-byte ERR state or subsequent
40-byte thread table allocation, return null with no ERR slot and balanced
failed-path ownership, then successfully retry/capture/restore/free. Retry thread
startup storage remains thread-owned until exit; the test does not claim it was
freed before that boundary.

Selected executable, fixture, fault-observer and native hashes were checked.
Every independently generated private PKI directory was removed. Independent
public/nested replay records are under the corresponding
.zig-cache/sql-tls-error-snapshot-review-* directories.

## Reconciled recorded evidence

I recomputed the five-fault baseline and candidate comparisons over all 163
operations per selector. Default candidate count vectors exactly match baseline.
All 29 reserved metadata fatal/cross calls are zero across malloc/calloc/realloc/
free/requested bytes. The nine peer-data calls remain 7 mallocs/5 frees/184 bytes;
the first peer-data failure remains 2 mallocs/84 bytes. Metadata GREEN is scoped:
peer-data and unchanged full fatal gates correctly remain RED.

Full five-fault queue order, packed codes, file, line, data and flags are retained.
All seven mapped error sites bind to exact unchanged statements, source blocks
and full-file hashes; each observed line number remains identical. No raw path
or line field was rewritten or globally excluded. Peer-fatal writes still succeed
and deliver exact bytes, unlike the four local-rejection cases. Cross-SSL queue
restoration and the popped string after SSL_free remain checked.

I recomputed inherited protocol and public-control comparisons: 27 protocol
rows/1320 calls across actual negotiated 0x1301/0x1302/0x1303, including eighteen
fatal rows, and twelve controls/255 calls. Reserved vectors are zero; unopted
raw records match prior evidence exactly. The unopted controls are also zero.
The inherited protocol witness preserves complete ordered packed error queues
and alert observations; the separate five-fault witness retains full per-entry
file/line/data/flags. These measurement scopes are not conflated.

All 52 inherited lineage entries match both the earlier and current files:
51 prior inputs plus the unchanged orchestration driver. I checked the eight
aggregate groups, HKDF comparison and complete passing lifecycle result families.
These inherited matrices were reconciled from retained producer records rather
than independently rerun in this review.

Both Root-restored source trees were independently hashed: all 8709 entries
match the candidate, including types and modes. Existing destinations, a wrong
source kind and a chmod-only changed input are rejected before output creation.
The chmod-only input has identical contents and exactly one changed file mode.

The frozen helper payload has 1210 regular selected files and 1209 verified
hashes; HANDOFF SHA256 is
cf0e430f238fc34fabe1cf6cbcf9ac4ae5ddba9ecc7eed948ec5ddcf40cac35c.
Its recorded prebuilt replay selects 21 Debug programs and completes 86 expected
commands with private PKI removed. The wire payload has 302 regular selected
files/301 verified hashes and seven selected programs; its recorded replay and
comparison statuses also match. These are producer records, preceding the
separate staged stripping/archive review.

## Corrections closed and remaining limits

The restoration helper originally omitted recorded file modes; pre-write lstat
mode/type checks and exact candidate output modes now close that finding. The
inherited reporting boolean originally used opt-in status rather than raw count
vectors; it now correctly reports the unopted controls as zero without changing
runtime records or assertions. Corrected final nested provenance describes the
nested queue control rather than the copied lifecycle scope.

The original all-C counter/self-test is preserved in selected allocation proofs.
Diagnostic counter lineage, corrected cold-thread expectations, earlier fixture
failures and the OOM driver's post-success printing correction are explicitly
recorded; no lowered allocation threshold or dropped error entry was accepted.

No dedicated smoke/security/sanitizer/fuzz/scan campaign was run in this review,
consistent with user deferral. Arbitrary error strings, SQL TLS teardown,
reconnect/cancellation overlap, native publication, production adoption and the
complete PostgreSQL allocation proof remain open. No PostgreSQL allocation
exception or release-completion claim is approved here.
