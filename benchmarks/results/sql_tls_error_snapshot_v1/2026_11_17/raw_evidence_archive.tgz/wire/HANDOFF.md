# Fatal-error snapshot wire evidence, Phase A

The explicit `SSL_reserve_error_state` startup option makes metadata-only first failures allocation-free and preserves existing client protocol/error behavior. Formatted peer-fatal error data still allocates: its separate gate and the unchanged full fatal-error gate remain RED. This evidence does not close the complete PostgreSQL allocation gate.

## Measured result

| First fatal client read | Baseline and new unopted: malloc/free/bytes | Reserved: malloc/free/bytes |
|---|---|---|
| Empty ticket | 2/0/40 | 0/0/0 |
| Duplicate flags | 4/2/80 | 0/0/0 |
| BadMAC | 4/2/128 | 0/0/0 |
| Oversized record | 4/2/80 | 0/0/0 |
| Peer fatal alert with string data | 4/0/124 | 2/0/84 |

All calloc/realloc counts are zero. Exact free placement for peer-data repeat calls is retained per operation; it must not be summarized as a free on every restore. Repeated reads allocate one 20B string, while pending queue-owned strings can be freed by a subsequent write. The reserved peer-data aggregate is7malloc/5free/184B over its nine fatal/cross/lifetime calls; baseline is9malloc/5free/224B. No diagnostic allocator replaces the original counter.

| Group | Variants | Rows / client calls per selector | Result |
|---|---|---|---|
| Five authentic fault cases | old baseline; new unopted; new reserved | 5 /163 | Observe0 everywhere; metadata gate RED1 unopted/GREEN0 reserved; peer-data/full gates RED1 |
| Inherited ticket protocol | new unopted; new reserved | 27 /1320 | All 27 reserved rows, including 18 fatal rows across three suites, zero in all count fields |
| Original public controls | new unopted; new reserved | 12 /255 | All reserved app/ticket/KeyUpdate client count fields zero |

The old baseline executes observe and full strict selectors. Each new small variant executes observe, metadata-only, peer-data and unchanged full selectors, with byte-identical raw outputs within the variant. New unopted count vectors equal the old baseline at every small-witness call. Inherited new unopted operation and summary bytes equal authoritative prior ticket-discard evidence exactly; that old full matrix was not rerun. The source-free prebuilt replay executes seven selected binaries in 14 runs, covering 4780 complete client calls.

Every client call includes its immediate error classification inside the all-C allocation interval. Peer setup/preparation, queue observation and logging remain outside. All executables require the original self-test: malloc 1/calloc 1/realloc 1/free 2/requested 63B. Interposer SHA256 `afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac`. Compilation/linking uses Zig 0.16 Debug `-O0 -g`; these are measured counts, not estimates.

## Functional scope

The small witness uses five fresh CA/localhost verified TLS1.3 pairs, public singleton 0x1301 configuration with null flags and both negotiated IDs asserted. Every pair first exchanges exact 4096B in each direction. Existing record, incoming-handshake, AEAD-context, outgoing-KeyUpdate reservations and validated ticket discard are enabled before warm traffic; error-state reservation is the only candidate startup addition. The125 warm calls are zero, and 38 fatal/cross/lifetime calls retain full per-call observations.

Two synthetic malformed ticket inputs and badMAC are produced through the native server's sealing routine and actual BIO. The badMAC input changes only the final ciphertext byte. The oversized record input deliberately supplies an invalid record header. Peer fatal alert uses public `SSL_send_fatal_alert(...,SSL_AD_ACCESS_DENIED)`. Client parser/cipher state is never staged. Synthetic opaque ticket contents are protocol inputs, with no resumption claim.

The five faults preserve ordered full library/reason queues: empty ticket SSL 16/137; duplicate flags SSL 16/257; badMAC CIPHER 30/101 then SSL 16/139; oversized record SSL 16/146; peer fatal SSL 16/1049 with flags 3 and exact nonsensitive `SSL alert number 49`. Event logs retain actual filename, line, flags and data, including the empty string returned for non-data errors. The fixture's256B error-text storage is an asserted bound for these known inputs, not a production truncation policy or a claim about arbitrary public error strings.

Three subsequent read/write cycles are required for each case. After local fatal rejection, writes fail with SSL reason 194. After receiving a peer fatal alert, client writes succeed and the peer receives exact bytes 0x71/0x72/0x73. This baseline distinction is preserved. Actual sender/receiver fatal callback order is checked, and emitted peer alert receipt requires the expected alert reason. The client queue is drained between operations so later calls must restore it. A non-data SSL restores its error after a data-error SSL on the same thread, then the data SSL restores its own queue. Its popped queue-owned string and STRING|MALLOCED flags remain valid after client `SSL_free`, before any queue-modifying call.

`candidate_comparison.json` checks every small operation tuple, complete ordered queue/data/flags and alert observation against the old baseline. It also binds seven exact error source sites using hashes, unchanged statements and matching source blocks. All observed line numbers happen to stay identical in this patch. Raw full paths/lines are never rewritten or globally excluded. The source-backed comparison and `--frozen-sites` offline comparison produce identical bytes; the retained site map is available for independent review.

Inherited source inputs are copies from the immutable ticket-discard producer. Their only input edits add the conditional startup API; exact diffs are `inherited_protocol_startup_delta.patch` and `inherited_control_startup_delta.patch`. Protocol inputs publicly negotiate actual0x1301/0x1302/0x1303 and check both peers. The controls preserve their original0x1301 scope. Full error queues, callback bytes, alert order, retries, payloads and requested/unrequested KeyUpdate behavior remain equal. `inherited_comparison.json` reconciles all operations and enforces reserved zero, including every fatal client operation. Independent review corrected its derived all-client-zero reporting field to use actual vectors: the unopted controls are also zero, while unopted fatal protocol rows allocate. Only comparison/report copies were regenerated; no runtime inputs/results were changed. The prior report/script is retained under `reporting_correction/`.

`BASELINE_HANDOFF.md` and historical `baseline_frozen.json` preserve the accepted original measurement. The first failed fixture expected a one-entry badMAC queue. Its exact failed source/logs are retained under `baseline_first/`; the corrected test preserves both original cipher and SSL entries and the unchanged zero threshold. Outside-interval flushing ensures later assertion failures retain complete rows. The failed executable and objects are unselected.

Allocation call-site explanations in the baseline report are explicitly source inference. No separate diagnostic call-site measurement was performed. Thread ERR_STATE cold creation, arbitrary public error strings, direct snapshot/callback/failure ownership and reservation lifecycle are outside this wire witness and belong to their independent owner. Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain deferred by user instruction.

## Build identities and immutable records

Original native baseline: `.zig-cache/sql-tls-ticket-discard-fixed-20261117`.

- libssl.a `b9891425c059d826fd83a3335fe72207d73cebe992521ca6df473aaba0bfe88f`
- libcrypto.a `0d5945f932ce7620c2c4d431ce1cf85db95900ef134e84d88d2d088f960feaa9`

Phase A matching native build: `.zig-cache/sql-tls-error-snapshot-fixed-20261117`, six-file source patch `e6b0086e78da6ff0051ec215febd327ed3467398fcbe98b198c0531624b54021`.

- libssl.a `48e2928a79013579ddec9dea7bd1d750771e30a35d5091182db26af5555e960d`
- libcrypto.a `2143f831f9f57907f47a51dfc0fae9942f33b8c3ca6d378cca6cc90b387ea4dd`

Each measurement directory retains exact compile/link/run commands, statuses, raw logs, input/archive hashes and operation records. Native-source hash lists are labeled subsets. No source/archive/private PKI dependency is included in the prebuilt payload.

`original_measured_identity.json`, historical `baseline_frozen.json` and raw `result.json` binary IDs describe the original measured Debug files and remain unchanged. Current delivery validation uses `prebuilt_identity.json` and `payload_manifest.json`. Delivery may strip only staged selected copies, refresh seven current identity hashes and `delivery_stripping` false→true, and refresh corresponding current manifest fields under separate ELF proof. It must not refresh the historical baseline manifest or rewrite raw measurement files. `verify_frozen.py` validates the current payload manifest without treating historical Debug binary hashes as current delivery identities.

## Replay and rebuilding

Run from anywhere, with an absent output outside the evidence tree:

```sh
python3 /ABS/wire/replay_prebuilt.py --pki-tool /ABS/wt-tools --output /ABS/ABSENT_EXTERNAL_OUTPUT
```

PKI helper must be exact SHA256 `531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9`; original path `/tmp/uwz-wt-upstream-backport-client-20261117/client/wt-tools`. It runs offline. Owned ephemeral PKI is removed in a finally block on success/failure. The wrapper validates seven current executable hashes, checks expected functional/gate statuses, requires every raw replay file to match retained bytes, then runs baseline, candidate/offline-site and inherited comparisons. It needs no compiler/native source/native archives.

A self-relative prebuilt replay passed from `replay_stage/` with output `replay_evidence/`, both under the owned producer scratch. The stage is unselected. `replay_evidence/results.json` retains exact commands/statuses and successful cleanup. `replay_guards.json` records six rejected outputs/helpers: existing path, own evidence tree, packaged native sibling, packaged helper sibling, dangling output symlink and wrong PKI helper. The combined-root guard is inherited from the hardened prior workflow; standalone fallback protects its own tree.

For new compilation, use absent outputs:

```sh
python3 run_baseline.py NATIVE_ROOT PKI_HELPER ABSENT_OUTPUT
python3 run_candidate.py NATIVE_ROOT PKI_HELPER ABSENT_OUTPUT [--reserve]
python3 run_inherited.py NATIVE_ROOT PKI_HELPER ABSENT_OUTPUT --fixture protocol|control [--reserve]
```

All original exact invocations are in the per-directory `commands.json`. Baseline and candidate fixtures are separate; the frozen original is not edited. Root owns native integration, final independent review/replay, delivery and commit/push. This verifier made no production/native/pin/fork changes.
