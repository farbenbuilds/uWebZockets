#!/usr/bin/env python3
"""Reconcile real/synthetic encrypted ticket cases and complete error/alert outputs."""
import argparse
import csv
import json
from pathlib import Path

SCENARIOS=('initial_native','late_fragmented_coalesced_opaque','late_unknown_duplicates_flags',
 'empty_ticket','trailing_extensions','duplicate_flags','bad_early_before_flags','bad_flags','duplicate_early_before_body')
SUITES=(0x1301,0x1302,0x1303)
FIELDS=('malloc','calloc','realloc','free','bytes')


def verify(directory):
    rows=[json.loads(line) for line in (directory/'summary.jsonl').read_text().splitlines()]
    operations=list(csv.DictReader((directory/'operations.csv').open()))
    assert [(r['suite'],r['scenario']) for r in rows]==[(s,n) for s in SUITES for n in SCENARIOS]
    count=0
    for row in rows:
        scenario=row['scenario']; suite=row['suite']
        selected=[op for op in operations if op['scenario']==str(suite)+'_'+scenario]
        reads=[op for op in selected if op['phase'] in ('read','ticket_read')]
        writes=[op for op in selected if op['phase']=='response_write']
        assert len(reads)+len(writes)==len(selected)
        assert row['tls13_verified'] and row['hostname_verified']
        assert row['client_negotiated_suite']==row['server_negotiated_suite']==suite
        assert len(reads)==row['read_operations'] and len(writes)==row['write_operations']
        for phase,name in [(reads,'client_read'),(writes,'client_write')]:
            assert {field:sum(int(op[field]) for op in phase) for field in FIELDS}==row[name]
            assert all(int(op[field])>=0 for op in phase for field in FIELDS)
        assert sum(max(int(op['result']),0) for op in reads)==row['client_received_bytes']
        assert sum(max(int(op['result']),0) for op in writes)==row['server_received_bytes']
        assert all(int(op['error']) in (0,1,2,3) for op in selected)
        initial=scenario=='initial_native'; healthy=scenario in SCENARIOS[:3]
        assert row['initial_real_ticket']==initial
        assert row['issued_after_warm_payload']==(not initial)
        assert row['synthetic_opaque_nonresumption_test']==(not initial)
        assert row['complete_synthetic_bytes_exact']==(None if initial else True)
        assert row['cache_mode']==(0 if initial else 2)
        assert row['received_tickets']==(2 if initial else 6 if scenario=='late_fragmented_coalesced_opaque' else 1)
        if healthy:
            assert row['terminal_error']==row['peer_error']==0
            assert row['client_error_queue']==row['peer_error_queue']==[]
            assert row['client_alerts']==row['peer_alerts']==[]
            assert row['client_key_updates']==2 and row['client_sent_updates']==row['peer_received_updates']==1
            assert row['client_received_bytes']==row['server_received_bytes']==(12288 if initial else 16384)
            if row['discarded']:assert all(value==0 for name in ['client_read','client_write'] for value in row[name].values())
        else:
            assert row['terminal_error']==row['peer_error']==1
            assert row['client_error_queue'] and row['peer_error_queue']
            alert=47 if scenario in ('duplicate_flags','bad_flags','duplicate_early_before_body') else 50
            assert row['client_alerts']==[[1,2,alert]] and row['peer_alerts']==[[0,2,alert]]
            assert row['client_key_updates']==row['client_sent_updates']==row['peer_received_updates']==0
            assert row['client_received_bytes']==row['server_received_bytes']==4096
        count+=len(selected)
    assert count==len(operations)
    return {'rows_verified':len(rows),'operations_verified':count,'healthy_rows':9,'fatal_rows':18,
        'actual_suites':list(SUITES),'real_initial_and_post_startup_synthetic_distinguished':True,
        'synthetic_tickets_not_resumption_tested':True,'full_error_queues_and_alert_order_checked':True,
        'recognized_duplicate_and_semantic_precedence_checked':True,
        'request_and_no_response_key_updates_preserved':True,'strict_postgresql_gate_closed':False}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('directory',type=Path)
    print(json.dumps(verify(p.parse_args().directory),indent=2))


if __name__=='__main__':main()
