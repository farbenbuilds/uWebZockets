#!/usr/bin/env python3
"""Compare fatal-call semantics with explicit unchanged-source error-site mappings."""
import argparse
import csv
import difflib
import hashlib
import json
from pathlib import Path

FIELDS=('malloc','calloc','realloc','free','bytes')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def lines(path):
    return path.read_text().splitlines()


def source_site(before,after,baseline,candidate,frozen_sites):
    a=Path(before['file']);b=Path(after['file'])
    relative=a.relative_to(baseline/'boringssl')
    assert relative==b.relative_to(candidate/'boringssl')
    key=(str(relative),before['line'],after['line'])
    if frozen_sites is not None:
        assert key in frozen_sites,key
        return frozen_sites[key]
    old=lines(a);new=lines(b)
    old_index=before['line']-1;new_index=after['line']-1
    assert old[old_index]==new[new_index]
    blocks=difflib.SequenceMatcher(None,old,new,autojunk=False).get_matching_blocks()
    matching=[block for block in blocks if block.a<=old_index<block.a+block.size and block.b+(old_index-block.a)==new_index]
    assert len(matching)==1,(str(relative),before['line'],after['line'])
    return {'relative_file':str(relative),'baseline_line':old_index+1,'candidate_line':new_index+1,
        'unchanged_statement':old[old_index],'matching_source_block_lines':matching[0].size,
        'baseline_source_sha256':digest(a),'candidate_source_sha256':digest(b),
        'baseline_context':old[max(0,old_index-2):old_index+3],
        'candidate_context':new[max(0,new_index-2):new_index+3]}


def records(directory):
    operations=list(csv.DictReader((directory/'observe_operations.csv').open()))
    events=[json.loads(line) for line in (directory/'observe_events.jsonl').read_text().splitlines()]
    return operations,events


def compare(base,frozen_sites=None):
    baseline=base/'baseline';native=Path(json.loads((baseline/'provenance.json').read_text())['native_root'])
    original_ops,original_events=records(baseline)
    sites={};variants=[]
    for name in ('candidate_unreserved','candidate'):
        directory=base/name
        current_native=Path(json.loads((directory/'provenance.json').read_text())['native_root'])
        operations,events=records(directory)
        assert len(operations)==len(events)==len(original_ops)==163
        data_changes=[]
        for index,(old_op,op,old_event,event) in enumerate(zip(original_ops,operations,original_events,events)):
            assert {k:v for k,v in old_op.items() if k not in FIELDS}=={k:v for k,v in op.items() if k not in FIELDS}
            assert {k:v for k,v in old_event.items() if k!='queue'}=={k:v for k,v in event.items() if k!='queue'}
            assert len(old_event['queue'])==len(event['queue'])
            for old_entry,entry in zip(old_event['queue'],event['queue']):
                assert {k:v for k,v in old_entry.items() if k not in ('file','line')}=={k:v for k,v in entry.items() if k not in ('file','line')}
                site=source_site(old_entry,entry,native,current_native,frozen_sites)
                key=(site['relative_file'],site['baseline_line'],site['candidate_line'])
                if key in sites:assert sites[key]==site
                sites[key]=site
            counts={k:int(op[k]) for k in FIELDS}
            previous={k:int(old_op[k]) for k in FIELDS}
            if name=='candidate_unreserved':assert counts==previous
            elif op['scenario']!='peer_fatal_alert':assert all(v==0 for v in counts.values())
            elif counts!=previous:data_changes.append({'index':index,'phase':op['phase'],'step':int(op['step']),'baseline':previous,'reserved':counts})
        for mode in ('metadata','peer_data','strict'):
            for filename in ('operations.csv','events.jsonl','summary.jsonl','lifetime.json'):
                assert (directory/('observe_'+filename)).read_bytes()==(directory/(mode+'_'+filename)).read_bytes()
        commands=json.loads((directory/'commands.json').read_text())
        statuses={c['command'][-1]:c['exit_code'] for c in commands if c['command'][-1].startswith('--')}
        assert statuses=={'--observe':0,'--require-zero-metadata':0 if name=='candidate' else 1,'--require-zero-peer-data':1,'--require-zero':1}
        result=json.loads((directory/'result.json').read_text());assert result['complete'] and result['private_pki_removed']
        variants.append({'variant':name,'client_calls_per_selector':163,'metadata_zero':name=='candidate',
            'default_generic_count_vectors_exactly_preserved':name=='candidate_unreserved',
            'full_error_queue_flags_data_and_order_preserved':True,'file_line_sites_explicitly_mapped':True,
            'peer_fatal_successful_writes_and_exact_peer_bytes_preserved':True,
            'strict_statuses':statuses,'peer_data_count_changes':data_changes})
    return {'variants':variants,'error_source_sites':list(sites.values()),
        'source_site_mapping_requires_independent_review':True,'raw_file_line_logs_rewritten':False,
        'dedicated_smoke_security_sanitizer_fuzz_campaigns_run':False,'complete_postgresql_gate_closed':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('directory',type=Path)
    parser.add_argument('--frozen-sites',type=Path)
    args=parser.parse_args()
    sites=None
    if args.frozen_sites:
        rows=json.loads(args.frozen_sites.read_text())['error_source_sites']
        sites={(row['relative_file'],row['baseline_line'],row['candidate_line']):row for row in rows}
        assert len(sites)==len(rows)
    print(json.dumps(compare(args.directory.resolve(),sites),indent=2))


if __name__=='__main__':main()
