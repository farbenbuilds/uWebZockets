#!/usr/bin/env python3
"""Replay the bounded fatal-error snapshot evidence without source or archives."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pki-tool',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    base=Path(__file__).resolve().parent
    evidence_root=base
    if ((base.parent/'restore_pki_tool.py').is_file() and
            (base.parent/'native/HANDOFF.md').is_file()):
        evidence_root=base.parent
    output=args.output.absolute();helper=args.pki_tool.resolve(strict=True)
    if output.exists() or output.is_symlink():raise ValueError('Choose an absent output directory')
    if output.resolve().is_relative_to(evidence_root):raise ValueError('Keep output outside retained evidence')
    if digest(helper)!='531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':raise ValueError('PKI helper checksum differs')
    identity=json.loads((base/'prebuilt_identity.json').read_text())
    expected={'baseline/fatal_witness','candidate/fatal_witness','candidate_unreserved/fatal_witness',
        'candidate_protocol/protocol_witness','candidate_unreserved_protocol/protocol_witness',
        'candidate_controls/control_witness','candidate_unreserved_controls/control_witness'}
    if set(identity['binaries'])!=expected:raise ValueError('Unexpected executable inventory')
    for name,checksum in identity['binaries'].items():
        if digest(base/name)!=checksum:raise ValueError('Executable checksum differs: '+name)
    output.mkdir(parents=True,mode=0o700)
    commands=[];profile_commands={};complete=False;pki=output/'private_pki'

    def run(command,name,status=0,profile=None):
        with (output/(name+'.stdout')).open('wb') as out,(output/(name+'.stderr')).open('wb') as err:
            result=subprocess.run(command,cwd=output,stdout=out,stderr=err)
        item={'command':command,'exit_code':result.returncode,'expected_exit_code':status}
        commands.append(item)
        if profile is not None:profile_commands.setdefault(profile,[]).append(item)
        if result.returncode!=status:raise RuntimeError('Unexpected command status: '+name)

    def compare_files(directory,names):
        for name in names:
            if (output/directory/name).read_bytes()!=(base/directory/name).read_bytes():raise ValueError('Replay differs: '+directory+'/'+name)

    def cleanup_pki():
        if not pki.exists():return
        names={path.name for path in pki.iterdir()}
        if names-{'ca.pem','server.pem','server.key'}:raise ValueError('Unexpected PKI output')
        for name in names:(pki/name).unlink()
        pki.rmdir()

    try:
        try:
            run([str(helper),'pki',str(pki)],'pki_metadata')
            arguments=[str(pki/name) for name in ('server.pem','server.key','ca.pem')]
            for name in ('baseline','candidate_unreserved','candidate'):
                target=output/name;target.mkdir()
                shutil.copy2(base/name/'provenance.json',target/'provenance.json')
                modes=[('observe','--observe',0),('strict','--require-zero',1)] if name=='baseline' else [
                    ('observe','--observe',0),('metadata','--require-zero-metadata',0 if name=='candidate' else 1),
                    ('peer_data','--require-zero-peer-data',1),('strict','--require-zero',1)]
                for mode,option,status in modes:
                    paths=[str(target/(mode+'_'+part)) for part in ('operations.csv','events.jsonl','summary.jsonl','lifetime.json')]
                    run([str(base/name/'fatal_witness'),*arguments,*paths,option],name+'_'+mode,status,name)
                    compare_files(name,[mode+'_'+part for part in ('operations.csv','events.jsonl','summary.jsonl','lifetime.json')])
            for name in ('candidate_protocol','candidate_unreserved_protocol','candidate_controls','candidate_unreserved_controls'):
                target=output/name;target.mkdir();control=name.endswith('controls')
                binary='control_witness' if control else 'protocol_witness'
                run([str(base/name/binary),*arguments,str(target/'operations.csv'),str(target/'summary.jsonl')],name,0,name)
                compare_files(name,['operations.csv','summary.jsonl'])
            for name in ('inherited_baseline_protocol','inherited_baseline_control'):
                target=output/name;target.mkdir()
                for part in ('operations.csv','summary.jsonl'):
                    shutil.copy2(base/name/part,target/part)
        finally:
            cleanup_pki()
        for name,items in profile_commands.items():
            target=output/name
            (target/'commands.json').write_text(json.dumps(items,indent=2)+'\n')
            binary='fatal_witness' if name in ('baseline','candidate','candidate_unreserved') else 'control_witness' if name.endswith('controls') else 'protocol_witness'
            (target/'result.json').write_text(json.dumps({'complete':True,'private_pki_removed':not pki.exists(),
                'binary_sha256':digest(base/name/binary)},indent=2)+'\n')
        run([sys.executable,str(base/'verify_baseline.py'),str(output/'baseline')],'baseline_verification')
        run([sys.executable,str(base/'compare_candidate.py'),str(output),'--frozen-sites',str(base/'candidate_comparison.json')],'candidate_comparison')
        run([sys.executable,str(base/'compare_inherited.py'),str(output)],'inherited_comparison')
        complete=True
    finally:
        cleanup_pki()
        (output/'results.json').write_text(json.dumps({'complete':complete,'commands':commands,
            'private_pki_removed':not pki.exists(),'requires_compiler_native_source_or_archives':False,
            'metadata_zero_only':True,'peer_data_and_full_fatal_gate_remain_red':True,
            'complete_postgresql_gate_closed':False},indent=2)+'\n')
    print('PASS: metadata RED/GREEN, generic parity, peer-data/full RED, inherited zero and exact raw replay; PKI removed')


if __name__=='__main__':main()
