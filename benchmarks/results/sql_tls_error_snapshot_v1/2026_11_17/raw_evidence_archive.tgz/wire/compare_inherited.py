#!/usr/bin/env python3
"""Check inherited three-suite ticket and public-control parity and all-call zero."""
import argparse
import csv
import json
from pathlib import Path
import verify_protocol
import verify_controls

FIELDS=('malloc','calloc','realloc','free','bytes')


def semantic(value):
    if isinstance(value,dict):
        return {key:semantic(item) for key,item in value.items() if not (isinstance(item,dict) and set(item)==set(FIELDS))}
    if isinstance(value,list):return [semantic(item) for item in value]
    return value


def verify(base):
    report=[]
    for kind in ('protocol','control'):
        baseline=base/('inherited_baseline_'+kind)
        variants={True:base/('candidate_'+('controls' if kind=='control' else kind)),False:base/('candidate_unreserved_'+('controls' if kind=='control' else kind))}
        old_rows=[json.loads(line) for line in (baseline/'summary.jsonl').read_text().splitlines()]
        for reserved,directory in variants.items():
            if kind=='protocol':result=verify_protocol.verify(directory)
            else:result=verify_controls.verify(directory,'operations.csv','summary.jsonl',True,True,True)
            rows=[json.loads(line) for line in (directory/'summary.jsonl').read_text().splitlines()]
            operations=list(csv.DictReader((directory/'operations.csv').open()))
            assert semantic(rows)==semantic(old_rows)
            all_zero=all(int(op[field])==0 for op in operations for field in FIELDS)
            if reserved:assert all_zero
            else:
                for filename in ('operations.csv','summary.jsonl'):
                    assert (directory/filename).read_bytes()==(baseline/filename).read_bytes(),kind+'/'+filename
            old_ops=list(csv.DictReader((baseline/'operations.csv').open()))
            assert len(old_ops)==len(operations)
            assert [{k:v for k,v in op.items() if k not in FIELDS} for op in old_ops]==[{k:v for k,v in op.items() if k not in FIELDS} for op in operations]
            report.append({'kind':kind,'error_state_reserved':reserved,'rows':len(rows),'client_calls':len(operations),
                'all_client_count_fields_zero':all_zero,'default_raw_count_and_semantic_bytes_exact':not reserved,
                'error_queues_alert_order_payload_callbacks_and_retries_preserved':True,'verifier':result})
    return {'comparisons':report,'authoritative_old_baseline_not_rerun':True,
        'inherited_fatal_rows_zero_with_reservation':18,'actual_protocol_suites':[0x1301,0x1302,0x1303],
        'full_postgresql_gate_closed':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('directory',type=Path)
    print(json.dumps(verify(parser.parse_args().directory),indent=2))


if __name__=='__main__':main()
