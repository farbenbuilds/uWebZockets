# Fatal-error allocation baseline

Five authentic suite0x1301 fault rows pass all functional checks, then the unchanged complete-call zero-allocation assertion exits1. Observe exits0. Both runs produce byte-identical operation, full-error-event, summary and lifetime outputs. The selected final baseline is `baseline/`; `baseline_first/` retains the initial incorrect fixture expectation and its raw failure, with exact failed source/runner copies.

| First client fatal read | malloc | free | requested bytes | Full library/reason sequence |
|---|---:|---:|---:|---|
| Empty NewSessionTicket | 2 | 0 | 40 | SSL16 /137 |
| Duplicate recognized flags | 4 | 2 | 80 | SSL16 /257 |
| Corrupted encrypted application record | 4 | 2 | 128 | CIPHER30 /101, SSL16 /139 |
| Oversized TLS record header | 4 | 2 | 80 | SSL16 /146 |
| Received peer fatal alert | 4 | 0 | 124 | SSL16 /1049, flags3, `SSL alert number 49` |

Each of five verified CA/localhost TLS1.3 pairs first exchanges exact4096B in both directions. Both contexts use public singleton cipher0x1301 with null flags; both actual negotiated IDs are asserted. Server initial ticket count is zero. All prior record/HS/AEAD/KU-output reservations and ticket-discard policy are enabled before warm traffic. The125 warm client calls are zero for malloc/calloc/realloc/free/requested bytes. The38 fatal/cross/lifetime calls include first failure, three read/write cycles on each pair, A(nondata) after B(data) and B after A restoration, and one popped-string lifetime call. Total163 client calls per run; original all-C interposer/selftest63 is byte-identical.

BadMAC is native peer-sealed ciphertext with only its final byte flipped; oversized framing is an intentionally invalid record header. Both ticket syntax cases are native peer-sealed synthetic inputs, with no resumption claim. Peer fatal alert uses public `SSL_send_fatal_alert(...,SSL_AD_ACCESS_DENIED)`; no client private state is staged. All client operation returns and immediate `SSL_get_error` classifications, full ordered error library/reason/file/line/data/flags and alert observations are retained. Peer receipt of emitted alerts is required, with its expected SSL alert reason asserted; the summary retains peer callback alert order. No ticket, key, session or context contents/hashes are logged.

All repeated metadata-only reads and writes are already allocation-free on baseline. In the data case, repeated reads allocate one20B string; free placement varies because the popped string remains queue-owned. First repeat read frees one old string; later repeat reads may free none while the following write frees one pending queue string. Preserve the exact operation vectors rather than averaging lifetime effects. Peer-fatal writes succeed with result1/error0 and peer receives exact bytes0x71/0x72/0x73; the other four rows fail writes with result-1/error1 and SSL reason194. No fixture expectation converts those outcomes into a uniform result.

The received alert's popped string remains readable with flags STRING|MALLOCED after client `SSL_free`, before any further queue modification. Cross-SSL calls restore complete queue snapshots after another SSL has replaced the same thread's queue. Stored snapshot copies in the witness are fixed caller-owned test records; strings remain queue-owned under the native API.

`baseline_first/` failed because the initial fixture incorrectly required exactly one error entry for badMAC. Native badMAC preserves both cipher and SSL entries. The corrected fixture requires the final SSL badMAC reason and records the full queue; independent verification binds the exact two-entry order. This fixes the fixture expectation without changing any allocator threshold. Outside-interval flushes were added to retain complete rows before failing assertions. No native implementation was changed.

Allocation attribution is **source inference**, not measured call-site tracing: `ERR_save_state` allocates a16B descriptor and N*24B error records on this target, plus copied error data; `ssl_set_read_error` retains a saved state, while `ssl_send_alert` temporarily saves/restores around alert BIO work. Generic error strings and first-use thread ERR_STATE storage remain distinct. No diagnostic interposer was substituted for the original measurement counter.

Exact command:

```sh
python3 .zig-cache/sql-tls-error-allocation-witness-20261117/run_baseline.py /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-ticket-discard-fixed-20261117 /tmp/uwz-wt-upstream-backport-client-20261117/client/wt-tools /home/foo/Desktop/Repos/uWebZockets/.zig-cache/sql-tls-error-allocation-witness-20261117/baseline
python3 .zig-cache/sql-tls-error-allocation-witness-20261117/verify_baseline.py .zig-cache/sql-tls-error-allocation-witness-20261117/baseline
```

The first command requires an absent output; use a different absent path for a new run. Per-command exact arguments, statuses and raw output are retained in `baseline/commands.json` and named stdout/stderr files. Native libssl SHA256 `b9891425c059d826fd83a3335fe72207d73cebe992521ca6df473aaba0bfe88f`, libcrypto `0d5945f932ce7620c2c4d431ce1cf85db95900ef134e84d88d2d088f960feaa9`. PKI helper SHA256 `531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9`. All compilation/linking used Zig0.16 Debug `-O0 -g`. Owned ephemeral PKI was removed in finally blocks, including the failed initial run.

`baseline_frozen.json` binds baseline source/counter/runner, all selected successful raw records, the selected executable, retained failed-fixture source/logs and the reconciled report. Object files and the failed preliminary executable remain unselected. Metadata-only PhaseA zero criteria will be separate from peer-fatal formatted-data PhaseB RED; this baseline does not establish a complete PostgreSQL zero-allocation gate. Dedicated smoke/security/sanitizer/fuzz/scan campaigns remain deferred.
