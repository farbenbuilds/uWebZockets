#!/usr/bin/env python3
"""Run Phase A candidate metadata/full/data gates without modifying the frozen baseline."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root',type=Path)
    parser.add_argument('pki_helper',type=Path)
    parser.add_argument('output',type=Path)
    parser.add_argument('--reserve',action='store_true')
    args=parser.parse_args()
    base=Path(__file__).resolve().parent
    native=args.native_root.resolve(strict=True);helper=args.pki_helper.resolve(strict=True)
    output=args.output.absolute()
    if output.exists() or output.is_symlink():raise ValueError('Choose absent output')
    if digest(helper)!='531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':raise ValueError('PKI helper differs')
    if digest(base/'allocation_scope.c')!='afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac':raise ValueError('Original counter differs')
    output.mkdir(mode=0o700)
    zig='/tmp/zig-x86_64-linux-0.16.0/zig'
    env=dict(os.environ);env['ZIG_GLOBAL_CACHE_DIR']='/tmp/uwz-zig-cache'
    archives=[native/'native_out/lib/libssl.a',native/'native_out/lib/libcrypto.a']
    paths=['crypto/err/err.cc','crypto/err/internal.h','ssl/ssl_lib.cc','ssl/s3_pkt.cc','ssl/tls_record.cc','include/openssl/err.h','include/openssl/ssl.h']
    provenance={'optimization':'Debug (-O0 -g)','compiler':zig,'native_root':str(native),
        'archive_sha256':{p.name:digest(p) for p in archives},
        'source_subset_sha256':{name:digest(native/'boringssl'/name) for name in paths},
        'counter_sha256':digest(base/'allocation_scope.c'),'fixture_sha256':digest(base/'candidate_witness.cc'),
        'pki_helper_sha256':digest(helper),'dedicated_smoke_security_sanitizer_fuzz_campaigns_run':False,'error_state_reserved':args.reserve}
    (output/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
    commands=[]
    def run(command,name,status=0):
        with (output/(name+'.stdout')).open('wb') as out,(output/(name+'.stderr')).open('wb') as err:
            result=subprocess.run(command,cwd=output,env=env,stdout=out,stderr=err)
        commands.append({'command':command,'exit_code':result.returncode,'expected_exit_code':status})
        (output/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        if result.returncode!=status:raise RuntimeError('Unexpected status: '+name)
    pki=output/'private_pki';binary=output/'fatal_witness';complete=False
    try:
        run([zig,'cc','-std=c11','-O0','-g','-c',str(base/'allocation_scope.c'),'-o',str(output/'allocation_scope.o')],'build-counter')
        run([zig,'c++','-std=c++17','-O0','-g','-fno-omit-frame-pointer','-Wall','-Wextra','-Werror','-DBORINGSSL_IMPLEMENTATION',*(['-DUWZ_RESERVE_ERROR_STATE=1'] if args.reserve else []),
            '-isystem',str(native/'boringssl'),'-isystem',str(native/'boringssl/include'),str(base/'candidate_witness.cc'),
            str(output/'allocation_scope.o'),*[str(path) for path in archives],'-o',str(binary)],'build-witness')
        run([str(helper),'pki',str(pki)],'pki-metadata')
        arguments=[str(pki/name) for name in ('server.pem','server.key','ca.pem')]
        modes=[('observe','--observe',0),('metadata','--require-zero-metadata',0 if args.reserve else 1),
            ('peer_data','--require-zero-peer-data',1),('strict','--require-zero',1)]
        for mode,option,status in modes:
            run([str(binary),*arguments,*[str(output/(mode+'_'+name)) for name in ('operations.csv','events.jsonl','summary.jsonl','lifetime.json')],
                option],mode,status)
        for mode,_,_ in modes[1:]:
            for name in ('operations.csv','events.jsonl','summary.jsonl','lifetime.json'):
                assert (output/('observe_'+name)).read_bytes()==(output/(mode+'_'+name)).read_bytes(),mode+'/'+name
        complete=True
    finally:
        if pki.exists():
            names={p.name for p in pki.iterdir()}
            if names-{'ca.pem','server.pem','server.key'}:raise ValueError('Unexpected PKI files')
            for name in names:(pki/name).unlink()
            pki.rmdir()
        (output/'result.json').write_text(json.dumps({'complete':complete,'private_pki_removed':not pki.exists(),
            'binary_sha256':digest(binary) if binary.exists() else None,'strict_exit_code':1},indent=2)+'\n')
    print('PASS Phase A observe0, metadata'+('GREEN0' if args.reserve else 'RED1')+', peer-data/full RED1; owned PKI removed')


if __name__=='__main__':main()
