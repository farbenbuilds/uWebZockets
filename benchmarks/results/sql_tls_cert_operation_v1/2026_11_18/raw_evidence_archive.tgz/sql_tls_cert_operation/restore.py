#!/usr/bin/env python3
"""Restore the isolated certificate allocation proof from two exact parent trees."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess


INPUT_SHA256 = "b9cf0bfaa9317013429520f6971cada58ddaadc491ed759cded88fe0d380ce15"
ZIG_SHA256 = "2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c"
HEADER = "crypto/cert_alloc_internal.h"
BUILDER = "builds/vendor/boringssl.zig"
TARGETS = ["proof", "wire-proof", "cert-operation-proof"]
STEPS = 71


def require(condition, message):
    if not condition:
        raise SystemExit(message)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def inventory(root):
    require(root.is_dir() and not root.is_symlink(), f"missing or linked source directory: {root}")
    names = {}
    pending = [root]
    while pending:
        for child in pending.pop().iterdir():
            mode = child.lstat().st_mode
            if stat.S_ISDIR(mode):
                pending.append(child)
                continue
            name = child.relative_to(root).as_posix()
            require(stat.S_ISREG(mode), f"non-regular source: {child}")
            names[name] = stat.S_IMODE(mode)
    return names


def verify_tree(root, entries):
    actual = inventory(root)
    expected = {entry["path"] for entry in entries}
    require(len(expected) == len(entries), f"duplicate identity path: {root}")
    require(set(actual) == expected, f"source file set differs: {root}")
    for entry in entries:
        name = entry["path"]
        require(actual[name] == entry["mode"], f"source mode differs: {root / name}")
        require(digest(root / name) == entry["sha256"], f"source hash differs: {root / name}")


def copy_tree(root, destination, entries):
    for entry in entries:
        source = root / entry["path"]
        copied = destination / entry["path"]
        copied.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, copied, follow_symlinks=False)


def overlaps(left, right):
    return left.is_relative_to(right) or right.is_relative_to(left)


def source_root(path):
    require(not path.is_symlink(), f"source root is linked: {path}")
    return path.resolve(strict=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--parent-native", required=True, type=Path)
    parser.add_argument("--parent-sdk", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--zig", required=True, type=Path)
    parser.add_argument("--global-cache", type=Path, help="reuse an existing Zig global cache")
    args = parser.parse_args()

    packet = Path(__file__).resolve().parent
    require(not os.path.lexists(args.output), f"output already exists: {args.output}")
    out = args.output.resolve()
    native = source_root(args.parent_native)
    sdk = source_root(args.parent_sdk)
    require(not overlaps(out, native) and not overlaps(out, sdk) and not overlaps(out, packet),
            "output overlaps an input tree")
    cache = source_root(args.global_cache) if args.global_cache else out / "global_cache"
    if args.global_cache:
        require(cache.is_dir() and not any(overlaps(cache, path) for path in (out, native, sdk, packet)),
                "global cache overlaps an input or output tree, or is not a directory")

    zig = source_root(args.zig)
    require(zig.is_file() and os.access(zig, os.X_OK) and digest(zig) == ZIG_SHA256,
            "Zig executable identity differs")
    identity = packet / "input_identity.json"
    require(stat.S_ISREG(identity.lstat().st_mode) and digest(identity) == INPUT_SHA256,
            "package input identity differs")
    inputs = packet / "inputs"
    input_entries = read_json(identity)
    verify_tree(inputs, input_entries)

    source_identity = inputs / "source_identity"
    native_identity = read_json(source_identity / "parent_native_identity.json")
    sdk_entries = read_json(source_identity / "parent_sdk_identity.json")["files"]
    native_entries = native_identity["files"]
    verify_tree(native, native_entries)
    verify_tree(sdk, sdk_entries)

    proof_entries = [entry for entry in input_entries
                     if entry["path"] == "build.zig" or entry["path"].startswith("proof/")]
    header_entry = next(entry for entry in input_entries if entry["path"] == f"native_delta/{HEADER}")
    candidate_entries = sorted([*native_entries, {**header_entry, "path": HEADER}],
                               key=lambda entry: entry["path"])
    canonical = json.dumps(candidate_entries, sort_keys=True, separators=(",", ":")).encode()
    candidate_sha256 = hashlib.sha256(canonical).hexdigest()
    delta = read_json(source_identity / "delta.json")
    require(candidate_sha256 == delta["native_files_canonical_sha256"], "derived native identity differs")

    old_source = os.fsencode(native_identity["actual_candidate_source"])
    builder_text = (sdk / BUILDER).read_bytes()
    old_literal = b'.cwd_relative = "' + old_source + b'"'
    require(builder_text.count(old_source) == 1 and builder_text.count(old_literal) == 1,
            "expected exactly one SDK native source path")
    dest_native = out / "boringssl"
    encoded = "".join(chr(byte) if 32 <= byte < 127 and byte not in (34, 92)
                      else "\\x%02x" % byte for byte in os.fsencode(dest_native)).encode()
    new_builder = builder_text.replace(old_literal, b'.cwd_relative = "' + encoded + b'"')

    out.mkdir(parents=True, exist_ok=False)
    copy_tree(native, dest_native, native_entries)
    copy_tree(inputs / "native_delta", dest_native, [{**header_entry, "path": HEADER}])
    verify_tree(dest_native, candidate_entries)
    dest_sdk = out / "sdk"
    copy_tree(sdk, dest_sdk, sdk_entries)
    builder = dest_sdk / BUILDER
    builder.write_bytes(new_builder)
    builder_sha256 = hashlib.sha256(new_builder).hexdigest()
    rebound_sdk = [{**entry, "sha256": builder_sha256} if entry["path"] == BUILDER else entry
                   for entry in sdk_entries]
    verify_tree(dest_sdk, rebound_sdk)
    copy_tree(inputs, out, proof_entries)
    verify_tree(out / "proof", [{**entry, "path": entry["path"].removeprefix("proof/")}
                                for entry in proof_entries if entry["path"].startswith("proof/")])
    expected_build = next(entry["sha256"] for entry in proof_entries if entry["path"] == "build.zig")
    require(digest(out / "build.zig") == expected_build, "restored proof builder hash differs")

    temporary = out / "tmp"
    temporary.mkdir()
    env = {key: value for key, value in os.environ.items() if not key.startswith("ZIG_")}
    env.update({key: str(temporary) for key in ("TMPDIR", "TMP", "TEMP")})
    command = [str(zig), "build", *TARGETS, "-Doptimize=ReleaseSafe", "-j2", "--cache-dir", "cache",
               "--global-cache-dir", str(cache), "--prefix", "proof_out", "--summary", "all"]
    log = out / "proof.log"
    with log.open("wb") as stream:
        result = subprocess.run(command, cwd=out, env=env, stdout=stream, stderr=subprocess.STDOUT)
    summary = re.findall(r"Build Summary: (\d+)/(\d+) steps succeeded", log.read_text(encoding="utf-8"))
    passed = result.returncode == 0 and bool(summary) and tuple(map(int, summary[-1])) == (STEPS, STEPS)
    record = {
        "cwd": str(out),
        "command": command,
        "temporary_directory": str(temporary),
        "parent_native_files": len(native_entries),
        "candidate_native_files": len(candidate_entries),
        "candidate_native_inventory_sha256": candidate_sha256,
        "parent_sdk_files": len(sdk_entries),
        "sdk_builder_rebound_from": os.fsdecode(old_source),
        "sdk_builder_rebound_to": str(dest_native),
        "sdk_builder_replacements": 1,
        "restored_sdk_builder_sha256": builder_sha256,
        "proof_sources": len(proof_entries) - 1,
        "expected_steps": STEPS,
        "exit_code": result.returncode,
        "passed": passed,
        "proof_log_sha256": digest(log),
        "input_identity_sha256": INPUT_SHA256,
        "restore_helper_sha256": digest(Path(__file__).resolve()),
    }
    (out / "restoration.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    require(passed, f"ReleaseSafe proof failed or incomplete: {log}")
    print(f"ReleaseSafe proof passed {STEPS}/{STEPS} steps: {log}")


if __name__ == "__main__":
    try:
        main()
    except OSError as exc:
        raise SystemExit(str(exc))
