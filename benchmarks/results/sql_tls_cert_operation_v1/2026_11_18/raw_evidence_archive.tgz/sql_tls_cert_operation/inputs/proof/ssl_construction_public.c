#include <openssl/err.h>
#include <openssl/mem.h>
#include <openssl/ssl.h>

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(SSL_CONSTRUCTION_FULL_HOOK)
union hook_header {
    max_align_t alignment;
    size_t bytes;
};

/* The weak-hook ABI requires these test-process counters without a context. */
static size_t hook_allocations;
static size_t hook_releases;
static size_t hook_sizes;

void *OPENSSL_memory_alloc(size_t bytes)
{
    hook_allocations++;
    if (bytes > SIZE_MAX - sizeof(union hook_header)) return NULL;
    union hook_header *header = malloc(sizeof(*header) + bytes);
    if (header == NULL) return NULL;
    header->bytes = bytes;
    return header + 1;
}

void OPENSSL_memory_free(void *pointer)
{
    hook_releases++;
    union hook_header *header = (union hook_header *)pointer - 1;
    OPENSSL_cleanse(pointer, header->bytes);
    free(header);
}

size_t OPENSSL_memory_get_size(void *pointer)
{
    hook_sizes++;
    return ((union hook_header *)pointer - 1)->bytes;
}
#endif

static void *reject_allocate(void *context, size_t bytes, size_t alignment)
{
    (void)bytes;
    (void)alignment;
    (*(size_t *)context)++;
    return NULL;
}

static void reject_release(void *context, void *pointer, size_t bytes, size_t alignment)
{
    (void)pointer;
    (void)bytes;
    (void)alignment;
    (*(size_t *)context)++;
}

int main(void)
{
    SSL_CLIENT_CONSTRUCTION_REQUIREMENTS requirements = {0, 0, 0, 0};
    SSL_CTX *context = SSL_CTX_new(TLS_client_method());
    size_t callbacks = 0;
    const OPENSSL_ALLOCATION_DOMAIN domain = {&callbacks, reject_allocate, reject_release};
    if (context == NULL) return 1;
    OPENSSL_PUT_ERROR(CRYPTO, ERR_R_MALLOC_FAILURE);
    const uint32_t before_error = ERR_peek_error();
#if defined(SSL_CONSTRUCTION_FULL_HOOK)
    SSL *ordinary = SSL_new(context);
    if (ordinary == NULL) return 5;
    SSL_free(ordinary);
    const size_t before_allocations = hook_allocations;
    const size_t before_releases = hook_releases;
    const size_t before_sizes = hook_sizes;
#endif
    if (!SSL_client_construction_storage_requirements(context, 255, &requirements)) return 2;
    if (requirements.alignment == 0 || requirements.block_bytes == 0 ||
        requirements.block_count == 0 || requirements.bytes / requirements.block_count != requirements.block_bytes ||
        requirements.bytes % requirements.block_count != 0 || ERR_peek_error() != before_error) return 3;
    if (SSL_new_client_with_construction_domain(context, &domain) != NULL) return 4;
#if defined(SSL_CONSTRUCTION_FULL_HOOK)
    if (callbacks != 0 || hook_allocations != before_allocations ||
        hook_releases != before_releases || hook_sizes != before_sizes) return 6;
    puts("ssl_construction_full_hook real_context query_no_hook_calls factory_rejected_before_callback ordinary_SSL_control=pass");
#else
    if (callbacks != 1) return 7;
    puts("ssl_construction_public_c declarations_link_layout first_allocation_failure=pass");
#endif
    SSL_CTX_free(context);
    return 0;
}
