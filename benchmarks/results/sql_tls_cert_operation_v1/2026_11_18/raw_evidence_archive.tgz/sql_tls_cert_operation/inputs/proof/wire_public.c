#include <openssl/err.h>
#include <openssl/ssl.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

#if defined(WIRE_FULL_HOOK)
union hook_header { max_align_t alignment; size_t bytes; };
/* The context-free weak-hook ABI requires these process counters. */
static size_t hook_calls;
void *OPENSSL_memory_alloc(size_t bytes)
{
    hook_calls++;
    if (bytes > SIZE_MAX - sizeof(union hook_header)) return NULL;
    union hook_header *p = malloc(sizeof(*p) + bytes);
    if (p == NULL) return NULL;
    p->bytes = bytes;
    return p + 1;
}
void OPENSSL_memory_free(void *pointer)
{
    hook_calls++;
    union hook_header *p = (union hook_header *)pointer - 1;
    OPENSSL_cleanse(pointer, p->bytes);
    free(p);
}
size_t OPENSSL_memory_get_size(void *pointer)
{
    hook_calls++;
    return ((union hook_header *)pointer - 1)->bytes;
}
#endif
static void *reject_allocate(void *argument, size_t bytes, size_t alignment)
{
    (void)bytes; (void)alignment;
    (*(size_t *)argument)++;
    return NULL;
}
static void reject_release(void *argument, void *pointer, size_t bytes, size_t alignment)
{
    (void)pointer; (void)bytes; (void)alignment;
    (*(size_t *)argument)++;
}
int main(void)
{
    SSL_CTX *ctx = SSL_CTX_new(TLS_client_method());
    if (ctx == NULL || !SSL_CTX_set_min_proto_version(ctx, TLS1_3_VERSION) ||
        !SSL_CTX_set_max_proto_version(ctx, TLS1_3_VERSION)) return 1;
    SSL *ssl = SSL_new(ctx);
    if (ssl == NULL) return 2;
    SSL_set_connect_state(ssl);
    OPENSSL_PUT_ERROR(CRYPTO, ERR_R_MALLOC_FAILURE);
    const uint32_t old_error = ERR_peek_error();
#if defined(WIRE_FULL_HOOK)
    const size_t before = hook_calls;
#endif
    SSL_CLIENT_WIRE_STORAGE_REQUIREMENTS requirements = {0};
    if (!SSL_client_wire_storage_requirements(ctx, &requirements) ||
        requirements.block_count != 12 || requirements.class_count == 0 ||
        requirements.class_count > SSL_CLIENT_WIRE_STORAGE_MAX_CLASSES ||
        ERR_peek_error() != old_error) return 3;
    size_t callbacks = 0;
    const OPENSSL_ALLOCATION_DOMAIN domain = {&callbacks, reject_allocate, reject_release};
    if (SSL_set_client_wire_storage_domain(ssl, &domain)) return 4;
#if defined(WIRE_FULL_HOOK)
    if (callbacks != 0 || hook_calls != before) return 5;
    puts("wire_public_full_hook query_pure real_SSL_bind_rejected_before_callback=pass");
#else
    if (callbacks == 0) return 6;
    puts("wire_public declarations_link classes12 persistent_shortage_fails=pass");
#endif
    SSL_free(ssl);
    SSL_CTX_free(ctx);
    return 0;
}
