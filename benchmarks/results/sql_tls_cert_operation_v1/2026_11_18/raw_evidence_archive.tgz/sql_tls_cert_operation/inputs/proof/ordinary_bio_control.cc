#include <openssl/bio.h>
#include <openssl/err.h>

#include <stdint.h>
#include <stdio.h>
#include <string.h>

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

int main(int argc, char **argv)
{
    if (!uwz_alloc_self_test()) return 2;
    ERR_clear_error();
    BIO *first = nullptr;
    BIO *second = nullptr;
    uint8_t output[7] = {};
    const uint8_t payload[] = {19, 88, 0, 231, 42, 9, 73};
    uwz_alloc_begin();
    const int created = BIO_new_bio_pair(&first, 32768, &second, 32768);
    int written = 0;
    int read = 0;
    if (created) {
        written = BIO_write(first, payload, sizeof(payload));
        read = BIO_read(second, output, sizeof(output));
    }
    BIO_free(first);
    BIO_free(second);
    uwz_alloc_end();
    const bool functional = created == 1 && written == 7 && read == 7 &&
        memcmp(payload, output, sizeof(payload)) == 0;
    const auto mallocs = uwz_alloc_malloc_calls();
    const auto callocs = uwz_alloc_calloc_calls();
    const auto reallocs = uwz_alloc_realloc_calls();
    const auto frees = uwz_alloc_free_calls();
    const auto bytes = uwz_alloc_requested_bytes();
    printf("ordinary_bio_pair functional=%d malloc=%llu calloc=%llu realloc=%llu free=%llu bytes=%llu strict_zero=0 selftest63=pass\n",
           functional, static_cast<unsigned long long>(mallocs),
           static_cast<unsigned long long>(callocs), static_cast<unsigned long long>(reallocs),
           static_cast<unsigned long long>(frees), static_cast<unsigned long long>(bytes));
    if (!functional || mallocs != 6 || callocs != 0 || reallocs != 0 || frees != 6 || bytes != 65856) return 3;
    return argc == 2 && strcmp(argv[1], "--strict") == 0 ? 1 : 0;
}
