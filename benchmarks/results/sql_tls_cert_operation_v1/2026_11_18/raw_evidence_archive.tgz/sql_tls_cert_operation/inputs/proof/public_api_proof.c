#include <openssl/bytestring.h>
#include <openssl/mem.h>

#include <stddef.h>
#include <stdint.h>
#include <string.h>

struct proof_storage {
    _Alignas(max_align_t) unsigned char slots[4][1024];
    size_t sizes[4];
    unsigned char active[4];
    size_t allocated;
    size_t released;
    int failed;
};

static void *proof_allocate(void *context, size_t raw_size, size_t alignment)
{
    struct proof_storage *storage = context;
    if (alignment != _Alignof(max_align_t) || raw_size > 1024) return NULL;
    for (size_t index = 0; index < 4; index++) {
        if (storage->active[index]) continue;
        storage->active[index] = 1;
        storage->sizes[index] = raw_size;
        storage->allocated++;
        memset(storage->slots[index], 0xa5, raw_size);
        return storage->slots[index];
    }
    return NULL;
}

static void proof_release(void *context, void *raw_pointer, size_t raw_size,
                          size_t alignment)
{
    struct proof_storage *storage = context;
    for (size_t index = 0; index < 4; index++) {
        if (raw_pointer != storage->slots[index]) continue;
        if (!storage->active[index] || storage->sizes[index] != raw_size ||
            alignment != _Alignof(max_align_t)) storage->failed = 1;
        for (size_t offset = 0; offset < raw_size; offset++) {
            if (storage->slots[index][offset] != 0) storage->failed = 1;
        }
        storage->active[index] = 0;
        storage->released++;
        return;
    }
    storage->failed = 1;
}

int main(void)
{
    struct proof_storage storage = {0};
    OPENSSL_ALLOCATION_DOMAIN domain = {&storage, proof_allocate, proof_release};
    unsigned char *pointer = OPENSSL_malloc_with_domain(13, &domain);
    if (pointer == NULL || (uintptr_t)pointer % _Alignof(max_align_t) != 0) return 1;
    memset(pointer, 0x63, 13);
    unsigned char *grown = OPENSSL_realloc(pointer, 33);
    if (grown == NULL) return 2;
    for (size_t index = 0; index < 13; index++) if (grown[index] != 0x63) return 3;
    OPENSSL_free(grown);

    CBB builder;
    if (!CBB_init_with_domain(&builder, 0, &domain)) return 4;
    if (!CBB_add_u8(&builder, 0x42)) return 5;
    unsigned char *output = NULL;
    size_t output_size = 0;
    if (!CBB_finish(&builder, &output, &output_size)) return 6;
    if (output_size != 1 || output[0] != 0x42) return 7;
    CBB_cleanup(&builder);
    OPENSSL_free(output);
    return storage.failed || storage.allocated != storage.released;
}
