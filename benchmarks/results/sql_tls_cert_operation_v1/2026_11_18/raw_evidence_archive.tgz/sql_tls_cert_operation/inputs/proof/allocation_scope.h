#ifndef UWZ_BIO_PROOF_ALLOCATION_SCOPE_H
#define UWZ_BIO_PROOF_ALLOCATION_SCOPE_H

#include <stdint.h>

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
}

// Include every operation and requested byte in the zero-allocation invariant.
static inline bool uwz_all_c_zero(void)
{
    return uwz_alloc_malloc_calls() == 0 && uwz_alloc_calloc_calls() == 0 &&
        uwz_alloc_realloc_calls() == 0 && uwz_alloc_free_calls() == 0 &&
        uwz_alloc_requested_bytes() == 0;
}

#endif
