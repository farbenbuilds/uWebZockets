#ifndef UWZ_WIRE_TEST_STORAGE_H
#define UWZ_WIRE_TEST_STORAGE_H
#include <openssl/bio.h>
#include <openssl/buf.h>
#include <openssl/bytestring.h>
#include <openssl/err.h>
#include <openssl/mem.h>
#include <openssl/rand.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>
#include <pthread.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "ssl/internal.h"
#include "crypto/buf/internal.h"
#include "crypto/bytestring/internal.h"
#include "crypto/x509/internal.h"
#include "allocation_scope.h"

extern "C" int uwz_alloc_self_test(void);
#define REQUIRE(condition) do { if (!(condition)) return __LINE__; } while (0)

struct wire_block {
    void *pointer;
    size_t bytes;
    size_t alignment;
    size_t generations;
    size_t stride;
    bool live;
};
struct wire_storage {
    alignas(max_align_t) uint8_t backing[1048576];
    wire_block blocks[64];
    SSL_CLIENT_WIRE_STORAGE_REQUIREMENTS plan;
    OPENSSL_ALLOCATION_DOMAIN domain;
    size_t attempts;
    size_t allocations;
    size_t releases;
    size_t live;
    size_t peak;
    size_t reused;
    size_t fail_attempt;
    size_t failure_hits;
    bool exact;
    bool bad;
};
static void *wire_allocate(void *argument, size_t bytes, size_t alignment)
{
    auto *storage = static_cast<wire_storage *>(argument);
    storage->attempts++;
    if (storage->attempts == storage->fail_attempt) {
        storage->failure_hits++;
        return nullptr;
    }
    size_t first = 0;
    for (size_t index = 0; index < storage->plan.class_count; index++) {
        const auto &entry = storage->plan.classes[index];
        const bool matches = storage->exact ? bytes == entry.raw_bytes : bytes <= entry.raw_bytes;
        if (!matches || alignment != entry.alignment) { first += entry.count; continue; }
        for (size_t slot = 0; slot < entry.count; slot++) {
            auto *block = &storage->blocks[first + slot];
            if (block->live) continue;
            void *pointer = storage->backing + entry.offset + slot * entry.stride;
            if (reinterpret_cast<uintptr_t>(pointer) % alignment != 0) { storage->bad = true; return nullptr; }
            if (block->generations != 0) storage->reused++;
            *block = {pointer, bytes, alignment, block->generations + 1, entry.stride, true};
            memset(pointer, 0xa5, bytes);
            storage->allocations++;
            storage->live++;
            if (storage->live > storage->peak) storage->peak = storage->live;
            return pointer;
        }
        return nullptr;
    }
    storage->bad = true;
    return nullptr;
}
static void wire_release(void *argument, void *pointer, size_t bytes, size_t alignment)
{
    auto *storage = static_cast<wire_storage *>(argument);
    for (size_t slot = 0; slot < storage->plan.block_count; slot++) {
        auto *block = &storage->blocks[slot];
        if (!block->live || block->pointer != pointer) continue;
        if (bytes != block->bytes || alignment != block->alignment || storage->live == 0) {
            storage->bad = true; return;
        }
        const auto *raw = static_cast<const uint8_t *>(pointer);
        for (size_t index = 0; index < bytes; index++) if (raw[index] != 0) storage->bad = true;
        for (size_t index = bytes; index < block->stride; index++) if (raw[index] != 0xc3) storage->bad = true;
        memset(pointer, 0xc3, block->stride);
        block->live = false;
        storage->live--;
        storage->releases++;
        return;
    }
    storage->bad = true;
}
static bool validate_plan(const SSL_CLIENT_WIRE_STORAGE_REQUIREMENTS &plan)
{
    if (plan.class_count == 0 || plan.class_count > SSL_CLIENT_WIRE_STORAGE_MAX_CLASSES ||
        plan.block_count == 0 || plan.block_count > 64 || plan.alignment == 0 ||
        plan.alignment > alignof(max_align_t) || (plan.alignment & (plan.alignment - 1)) != 0) return false;
    size_t end = 0, blocks = 0;
    for (size_t index = 0; index < plan.class_count; index++) {
        const auto &entry = plan.classes[index];
        if (entry.raw_bytes == 0 || entry.alignment != plan.alignment || entry.count == 0 ||
            entry.stride < entry.raw_bytes || entry.stride % entry.alignment != 0 ||
            entry.offset != end || entry.offset % entry.alignment != 0 ||
            entry.count > SIZE_MAX / entry.stride || end > SIZE_MAX - entry.count * entry.stride ||
            blocks > SIZE_MAX - entry.count) return false;
        for (size_t prior = 0; prior < index; prior++) {
            if (plan.classes[prior].raw_bytes == entry.raw_bytes && plan.classes[prior].alignment == entry.alignment) return false;
        }
        end += entry.count * entry.stride;
        blocks += entry.count;
    }
    return end == plan.bytes && blocks == plan.block_count;
}
static bool initialize_wire(wire_storage *storage, SSL_CTX *ctx)
{
    if (!SSL_client_wire_storage_requirements(ctx, &storage->plan) || !validate_plan(storage->plan) ||
        storage->plan.bytes > sizeof(storage->backing)) return false;
    storage->exact = true;
    storage->domain = {storage, wire_allocate, wire_release};
    memset(storage->backing, 0xc3, sizeof(storage->backing));
    return true;
}
static bool initialize_constructor(wire_storage *storage, SSL_CTX *ctx)
{
    SSL_CLIENT_CONSTRUCTION_REQUIREMENTS requirements = {};
    if (!SSL_client_construction_storage_requirements(ctx, 255, &requirements) ||
        requirements.bytes > sizeof(storage->backing) || requirements.block_count > 64) return false;
    storage->plan = {};
    storage->plan.bytes = requirements.bytes;
    storage->plan.alignment = requirements.alignment;
    storage->plan.class_count = 1;
    storage->plan.block_count = requirements.block_count;
    storage->plan.classes[0] = {requirements.block_bytes, requirements.alignment,
                              requirements.block_bytes, 0, requirements.block_count};
    storage->domain = {storage, wire_allocate, wire_release};
    memset(storage->backing, 0xc3, sizeof(storage->backing));
    return true;
}
static bool storage_empty(const wire_storage &storage)
{
    return !storage.bad && storage.live == 0 && storage.allocations == storage.releases;
}
static SSL_CTX *make_wire_context(bool verify = true)
{
    SSL_CTX *ctx = SSL_CTX_new(TLS_client_method());
    if (ctx == nullptr) return nullptr;
    if (!SSL_CTX_set_min_proto_version(ctx, TLS1_3_VERSION) || !SSL_CTX_set_max_proto_version(ctx, TLS1_3_VERSION)) {
        SSL_CTX_free(ctx); return nullptr;
    }
    SSL_CTX_set_verify(ctx, verify ? SSL_VERIFY_PEER : SSL_VERIFY_NONE, nullptr);
    return ctx;
}


#endif
