#include "crypto/cert_alloc_internal.h"
#include "crypto/mem_internal.h"
#include "allocation_scope.h"

#include <openssl/err.h>
#include <openssl/mem.h>

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

extern "C" int uwz_alloc_self_test(void);

#define REQUIRE(condition) do { if (!(condition)) return __LINE__; } while (0)

struct fixed_domain_storage {
    alignas(max_align_t) uint8_t slots[4][256];
    size_t extents[4];
    size_t attempts;
    size_t allocations;
    size_t releases;
    bool fail_next;
    bool invalid;
};

struct proof_value {
    uint32_t key;
    uint32_t tag;
};

static void *allocate_slot(void *context, size_t bytes, size_t alignment)
{
    auto *storage = static_cast<fixed_domain_storage *>(context);
    storage->attempts++;
    if (storage->fail_next) {
        storage->fail_next = false;
        return nullptr;
    }
    if (alignment != alignof(max_align_t) || bytes == 0 || bytes > sizeof(storage->slots[0])) {
        storage->invalid = true;
        return nullptr;
    }
    for (size_t index = 0; index < 4; index++) {
        if (storage->extents[index] != 0) continue;
        storage->extents[index] = bytes;
        storage->allocations++;
        memset(storage->slots[index], 0xa5, sizeof(storage->slots[index]));
        return storage->slots[index];
    }
    storage->invalid = true;
    return nullptr;
}

static void release_slot(void *context, void *pointer, size_t bytes, size_t alignment)
{
    auto *storage = static_cast<fixed_domain_storage *>(context);
    for (size_t index = 0; index < 4; index++) {
        if (pointer != storage->slots[index]) continue;
        if (alignment != alignof(max_align_t) || bytes == 0 || bytes != storage->extents[index]) break;
        for (size_t offset = 0; offset < sizeof(storage->slots[index]); offset++) {
            const uint8_t expected = offset < bytes ? 0 : 0xa5;
            if (storage->slots[index][offset] != expected) storage->invalid = true;
        }
        storage->extents[index] = 0;
        storage->releases++;
        return;
    }
    storage->invalid = true;
}

static bool drained(const fixed_domain_storage &storage)
{
    return !storage.invalid && !storage.fail_next && storage.allocations == storage.releases;
}

static int owned_targets_and_lifetimes(void)
{
    fixed_domain_storage durable_storage = {}, scratch_storage = {}, foreign_storage = {};
    const OPENSSL_ALLOCATION_DOMAIN durable = {&durable_storage, allocate_slot, release_slot};
    const OPENSSL_ALLOCATION_DOMAIN scratch = {&scratch_storage, allocate_slot, release_slot};
    const OPENSSL_ALLOCATION_DOMAIN foreign = {&foreign_storage, allocate_slot, release_slot};
    const uint8_t original[] = {0x19, 0, 0xfa};
    const proof_value value = {0x10203040, 0x90807060};
    uint8_t *durable_bytes = nullptr, *foreign_bytes = nullptr, *scratch_bytes = nullptr;
    proof_value *object = nullptr, *default_value = nullptr;
    {
        bssl::CertOperation first = {&durable, &scratch};
        bssl::CertOperation second = {&foreign, &scratch};
        durable_bytes = static_cast<uint8_t *>(bssl::cert_memdup({&first, first.durable}, original, sizeof(original)));
        foreign_bytes = static_cast<uint8_t *>(bssl::cert_memdup({&second, second.durable}, original, sizeof(original)));
        scratch_bytes = static_cast<uint8_t *>(bssl::cert_memdup({&first, first.scratch}, original, sizeof(original)));
        object = bssl::cert_new<proof_value>({&second, &durable}, value);
        default_value = bssl::cert_new<proof_value>({nullptr, &scratch});
        REQUIRE(durable_bytes && foreign_bytes && scratch_bytes && object && default_value);
        REQUIRE(!first.allocation_failed && !second.allocation_failed);
    }

    REQUIRE(bssl::GetAllocationDomain(durable_bytes) == &durable);
    REQUIRE(bssl::GetAllocationDomain(foreign_bytes) == &foreign);
    REQUIRE(bssl::GetAllocationDomain(scratch_bytes) == &scratch);
    REQUIRE(bssl::GetAllocationDomain(object) == &durable);
    REQUIRE(bssl::GetAllocationDomain(default_value) == &scratch);
    REQUIRE(durable_bytes != foreign_bytes && scratch_bytes != durable_bytes && foreign_bytes != scratch_bytes);
    REQUIRE(memcmp(durable_bytes, original, sizeof(original)) == 0);
    REQUIRE(memcmp(foreign_bytes, original, sizeof(original)) == 0);
    REQUIRE(memcmp(scratch_bytes, original, sizeof(original)) == 0);
    REQUIRE(object->key == value.key && object->tag == value.tag);
    REQUIRE(default_value->key == 0 && default_value->tag == 0);

    OPENSSL_free(foreign_bytes);
    bssl::Delete(object);
    OPENSSL_free(scratch_bytes);
    OPENSSL_free(durable_bytes);
    bssl::Delete(default_value);
    REQUIRE(durable_storage.attempts == 2 && scratch_storage.attempts == 2 && foreign_storage.attempts == 1);
    REQUIRE(drained(durable_storage) && drained(scratch_storage) && drained(foreign_storage));
    return 0;
}

static int empty_duplication(void)
{
    fixed_domain_storage storage = {};
    const OPENSSL_ALLOCATION_DOMAIN domain = {&storage, allocate_slot, release_slot};
    bssl::CertOperation operation = {&domain, nullptr};
    const uint8_t byte = 0x59;
    REQUIRE(bssl::cert_memdup({&operation, &domain}, nullptr, 0) == nullptr);
    REQUIRE(bssl::cert_memdup({&operation, &domain}, &byte, 0) == nullptr);
    REQUIRE(bssl::cert_memdup({&operation, nullptr}, nullptr, 0) == nullptr);
    REQUIRE(bssl::cert_memdup({nullptr, &domain}, &byte, 0) == nullptr);
    REQUIRE(!operation.allocation_failed && storage.attempts == 0 && storage.releases == 0);
    REQUIRE(ERR_peek_error() == 0 && drained(storage));
    return 0;
}

static int sticky_failure_and_early_refusal(void)
{
    fixed_domain_storage storage = {};
    const OPENSSL_ALLOCATION_DOMAIN domain = {&storage, allocate_slot, release_slot};
    bssl::CertOperation operation = {&domain, nullptr};
    const bssl::CertTarget target = {&operation, &domain};
    storage.fail_next = true;
    REQUIRE(bssl::cert_alloc_nonzero(target, 16) == nullptr);
    REQUIRE(operation.allocation_failed && storage.attempts == 1 && storage.releases == 0);
    ERR_clear_error();
    REQUIRE(ERR_peek_error() == 0 && operation.allocation_failed);

    auto *bytes = static_cast<uint8_t *>(bssl::cert_alloc_nonzero(target, 16));
    const uint8_t sample[] = {0x64, 0, 0xb7};
    auto *copy = static_cast<uint8_t *>(bssl::cert_memdup(target, sample, sizeof(sample)));
    REQUIRE(bytes && copy && bssl::GetAllocationDomain(bytes) == &domain);
    REQUIRE(memcmp(copy, sample, sizeof(sample)) == 0 && operation.allocation_failed);
    OPENSSL_free(copy);
    OPENSSL_free(bytes);

    bssl::CertOperation overflow = {&domain, nullptr};
    const size_t old_attempts = storage.attempts;
    REQUIRE(bssl::cert_alloc_nonzero({&overflow, &domain}, SIZE_MAX) == nullptr);
    REQUIRE(overflow.allocation_failed && storage.attempts == old_attempts);
    bssl::CertOperation ordinary_overflow = {};
    REQUIRE(bssl::cert_alloc_nonzero({&ordinary_overflow, nullptr}, SIZE_MAX) == nullptr);
    REQUIRE(ordinary_overflow.allocation_failed && storage.attempts == old_attempts);
    ERR_clear_error();

    bssl::CertOperation dup_failure = {&domain, nullptr};
    storage.fail_next = true;
    REQUIRE(bssl::cert_memdup({&dup_failure, &domain}, sample, sizeof(sample)) == nullptr);
    REQUIRE(dup_failure.allocation_failed && storage.attempts == old_attempts + 1);
    bssl::CertOperation typed_failure = {&domain, nullptr};
    storage.fail_next = true;
    REQUIRE(bssl::cert_new<proof_value>({&typed_failure, &domain}) == nullptr);
    REQUIRE(typed_failure.allocation_failed && storage.attempts == old_attempts + 2);

    // A preexisting allocation error cannot make a successful call fail.
    bssl::CertOperation unrelated = {&domain, nullptr};
    REQUIRE(ERR_peek_error() != 0);
    void *fresh = bssl::cert_alloc_nonzero({&unrelated, &domain}, 5);
    REQUIRE(fresh && !unrelated.allocation_failed && operation.allocation_failed);
    OPENSSL_free(fresh);
    REQUIRE(drained(storage));
    return 0;
}

static int existing_owner_resize(void)
{
    fixed_domain_storage durable_storage = {}, scratch_storage = {};
    const OPENSSL_ALLOCATION_DOMAIN durable = {&durable_storage, allocate_slot, release_slot};
    const OPENSSL_ALLOCATION_DOMAIN scratch = {&scratch_storage, allocate_slot, release_slot};
    bssl::CertOperation operation = {&durable, &scratch};
    const bssl::CertTarget fresh_scratch = {&operation, &scratch};
    const bssl::CertTarget offered_durable = {&operation, &durable};
    const uint8_t payload[] = {1, 17, 0, 192, 255, 0, 44};
    auto *first = static_cast<uint8_t *>(bssl::cert_resize_nonzero(fresh_scratch, nullptr, sizeof(payload)));
    REQUIRE(first && bssl::GetAllocationDomain(first) == &scratch);
    memcpy(first, payload, sizeof(payload));

    auto *grown = static_cast<uint8_t *>(bssl::cert_resize_nonzero(fresh_scratch, first, 32));
    REQUIRE(grown && bssl::GetAllocationDomain(grown) == &scratch);
    REQUIRE(memcmp(grown, payload, sizeof(payload)) == 0 && scratch_storage.releases == 1);
    auto *shrunk = static_cast<uint8_t *>(bssl::cert_resize_nonzero(offered_durable, grown, sizeof(payload)));
    REQUIRE(shrunk && bssl::GetAllocationDomain(shrunk) == &scratch);
    REQUIRE(memcmp(shrunk, payload, sizeof(payload)) == 0 && scratch_storage.releases == 2);
    REQUIRE(durable_storage.attempts == 0 && !operation.allocation_failed);

    scratch_storage.fail_next = true;
    REQUIRE(bssl::cert_resize_nonzero(offered_durable, shrunk, 48) == nullptr);
    REQUIRE(operation.allocation_failed && scratch_storage.attempts == 4 && scratch_storage.releases == 2);
    REQUIRE(bssl::GetAllocationDomain(shrunk) == &scratch && memcmp(shrunk, payload, sizeof(payload)) == 0);
    REQUIRE(durable_storage.attempts == 0 && durable_storage.releases == 0);

    ERR_clear_error();
    auto *recovered = static_cast<uint8_t *>(bssl::cert_resize_nonzero({nullptr, &durable}, shrunk, 19));
    REQUIRE(recovered && bssl::GetAllocationDomain(recovered) == &scratch);
    REQUIRE(memcmp(recovered, payload, sizeof(payload)) == 0 && operation.allocation_failed);
    OPENSSL_free(recovered);
    REQUIRE(scratch_storage.attempts == 5 && scratch_storage.releases == 4);
    REQUIRE(durable_storage.attempts == 0 && drained(scratch_storage) && drained(durable_storage));
    return 0;
}

static int public_zero_size_control(void)
{
    fixed_domain_storage storage = {};
    const OPENSSL_ALLOCATION_DOMAIN domain = {&storage, allocate_slot, release_slot};
    void *empty = OPENSSL_malloc_with_domain(0, &domain);
    REQUIRE(empty && bssl::GetAllocationDomain(empty) == &domain);
    OPENSSL_free(empty);

    auto *old = static_cast<uint8_t *>(OPENSSL_malloc_with_domain(1, &domain));
    REQUIRE(old);
    *old = 0xb6;
    storage.fail_next = true;
    REQUIRE(OPENSSL_realloc(old, 0) == nullptr);
    REQUIRE(*old == 0xb6 && bssl::GetAllocationDomain(old) == &domain && storage.releases == 1);
    void *replacement = OPENSSL_realloc(old, 0);
    REQUIRE(replacement && bssl::GetAllocationDomain(replacement) == &domain && storage.releases == 2);
    OPENSSL_free(replacement);
    REQUIRE(storage.attempts == 4 && storage.allocations == 3 && drained(storage));
    return 0;
}

static int ordinary_control(void)
{
    fixed_domain_storage storage = {};
    const OPENSSL_ALLOCATION_DOMAIN offered = {&storage, allocate_slot, release_slot};
    bssl::CertOperation operation = {&offered, nullptr};
    const uint8_t payload[] = {0x81, 0, 0x32};
    auto *first = static_cast<uint8_t *>(bssl::cert_alloc_nonzero({&operation, nullptr}, 16));
    REQUIRE(first && bssl::GetAllocationDomain(first) == nullptr);
    memcpy(first, payload, sizeof(payload));
    auto *grown = static_cast<uint8_t *>(bssl::cert_resize_nonzero({&operation, &offered}, first, 32));
    if (!grown) OPENSSL_free(first);
    REQUIRE(grown && bssl::GetAllocationDomain(grown) == nullptr);
    REQUIRE(memcmp(grown, payload, sizeof(payload)) == 0 && !operation.allocation_failed);
    OPENSSL_free(grown);
    REQUIRE(storage.attempts == 0 && drained(storage));
    return 0;
}

using proof_function = int (*)(void);

struct proof_case {
    const char *name;
    proof_function run;
    bool ordinary_heap;
};

int main(void)
{
    if (!uwz_alloc_self_test()) {
        fputs("original all-C counter self-test failed\n", stderr);
        return 1;
    }

    OPENSSL_PUT_ERROR(CRYPTO, ERR_R_INTERNAL_ERROR);
    ERR_clear_error();
    const proof_case cases[] = {
        {"owned_targets_and_lifetimes", owned_targets_and_lifetimes, false},
        {"empty_duplication", empty_duplication, false},
        {"sticky_failure_and_early_refusal", sticky_failure_and_early_refusal, false},
        {"existing_owner_resize", existing_owner_resize, false},
        {"public_zero_size_control", public_zero_size_control, false},
        {"ordinary_control", ordinary_control, true},
    };
    bool all_passed = true;
    for (const proof_case &entry : cases) {
        ERR_clear_error();
        uwz_alloc_begin();
        const int failure_line = entry.run();
        uwz_alloc_end();

        const auto mallocs = static_cast<unsigned long long>(uwz_alloc_malloc_calls());
        const auto callocs = static_cast<unsigned long long>(uwz_alloc_calloc_calls());
        const auto reallocs = static_cast<unsigned long long>(uwz_alloc_realloc_calls());
        const auto frees = static_cast<unsigned long long>(uwz_alloc_free_calls());
        const auto bytes = static_cast<unsigned long long>(uwz_alloc_requested_bytes());
        const bool counts_pass = entry.ordinary_heap
            ? mallocs == 2 && callocs == 0 && reallocs == 0 && frees == 2 && bytes >= 48
            : uwz_all_c_zero();
        const bool passed = failure_line == 0 && counts_pass;
        printf("%s %s line=%d malloc=%llu calloc=%llu realloc=%llu free=%llu bytes=%llu\n",
               entry.name, passed ? "PASS" : "FAIL", failure_line, mallocs, callocs, reallocs, frees, bytes);
        all_passed = all_passed && passed;
    }
    return all_passed ? 0 : 1;
}
