#include <openssl/bio.h>
#include <openssl/bytestring.h>
#include <openssl/err.h>
#include <openssl/mem.h>

#include <stddef.h>
#include <stdio.h>

#include "crypto/mem_internal.h"
#include "allocation_scope.h"

// The weak-hook ABI has no context argument; this test singleton counts accidental calls.
static size_t partial_calls;

#if defined(PARTIAL_ALLOC)
extern "C" void *OPENSSL_memory_alloc(size_t) { partial_calls++; return nullptr; }
#elif defined(PARTIAL_FREE)
extern "C" void OPENSSL_memory_free(void *) { partial_calls++; }
#elif defined(PARTIAL_SIZE)
extern "C" size_t OPENSSL_memory_get_size(void *) { partial_calls++; return 0; }
#else
#error Specify one weak-hook configuration.
#endif

static void *must_not_allocate(void *context, size_t, size_t)
{
    *static_cast<int *>(context) += 1;
    return nullptr;
}

static void must_not_release(void *context, void *, size_t, size_t)
{
    *static_cast<int *>(context) += 1;
}

int main(void)
{
    int callbacks = 0;
    const OPENSSL_ALLOCATION_DOMAIN domain = {&callbacks, must_not_allocate, must_not_release};
    if (OPENSSL_malloc_with_domain(0, &domain) != nullptr) return 1;
    if (OPENSSL_malloc_with_domain(13, &domain) != nullptr) return 2;
    CBB builder;
    if (CBB_init_with_domain(&builder, 0, &domain)) return 3;
    if (CBB_add_u8(&builder, 1)) return 4;
    CBB_cleanup(&builder);
    if (callbacks != 0) return 5;
    if (bssl::GetAllocationDomain(reinterpret_cast<const void *>(1)) != nullptr) return 6;
    BIO_PAIR_STORAGE_REQUIREMENTS requirements = {};
    ERR_clear_error();
    OPENSSL_PUT_ERROR(CRYPTO, ERR_R_MALLOC_FAILURE);
    const uint32_t old_error = ERR_peek_error();
    if (old_error == 0) return 7;
    uwz_alloc_begin();
    if (!BIO_pair_storage_requirements(32768, 32768, &requirements)) return 7;
    if (requirements.bytes != 66016 || requirements.alignment != alignof(max_align_t)) return 8;
    BIO_PAIR_STORAGE_REQUIREMENTS overflow = {19, 73};
    if (BIO_pair_storage_requirements(SIZE_MAX, 32768, &overflow)) return 11;
    if (overflow.bytes != 0 || overflow.alignment != 0 || ERR_peek_error() != old_error) return 12;
    uwz_alloc_end();
    if (!uwz_all_c_zero()) return 13;
    if (ERR_get_error() != old_error || ERR_get_error() != 0) return 15;
    BIO *first = reinterpret_cast<BIO *>(1), *second = reinterpret_cast<BIO *>(1);
    uwz_alloc_begin();
    if (BIO_new_bio_pair_with_domain(&first, 8, &second, 5, &domain)) return 9;
    uwz_alloc_end();
    if (!uwz_all_c_zero()) return 14;
    if (first != nullptr || second != nullptr || callbacks != 0 || partial_calls != 0) return 10;
    printf("partial_weak_hook owned_rejected_before_callback no_prefix_query callbacks=%d PASS\n", callbacks);
    printf("partial_weak_hook bio_requirements_pure owned_pair_rejected hook_calls=%zu PASS\n", partial_calls);
    printf("partial_weak_hook bio_query_valid_overflow_ERR_unchanged owned_factory_rejected all_C_zero PASS\n");
    return 0;
}
