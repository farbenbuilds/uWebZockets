#include <openssl/bio.h>
#include <openssl/mem.h>

int main(void)
{
    BIO_PAIR_STORAGE_REQUIREMENTS requirements;
    BIO *first = NULL;
    BIO *second = NULL;
    const OPENSSL_ALLOCATION_DOMAIN domain = {NULL, NULL, NULL};
    if (!BIO_pair_storage_requirements(32768, 32768, &requirements)) return 1;
    return BIO_new_bio_pair_with_domain(&first, 32768, &second, 32768, &domain);
}
