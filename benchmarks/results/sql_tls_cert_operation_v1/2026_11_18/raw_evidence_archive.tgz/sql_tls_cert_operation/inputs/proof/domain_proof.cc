#include <openssl/bytestring.h>
#include <openssl/err.h>
#include <openssl/mem.h>

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <type_traits>
#include <utility>

#include "crypto/bytestring/internal.h"
#include "crypto/mem_internal.h"

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

#define REQUIRE(condition) do { if (!(condition)) return __LINE__; } while (0)

struct DomainStorage {
    alignas(max_align_t) uint8_t slots[16][16384];
    size_t sizes[16];
    unsigned char active[16];
    size_t attempts;
    size_t allocated;
    size_t released;
    size_t fail_attempt;
    size_t peak_live;
    size_t live;
    bool failed;
};

struct Reference {
    uint8_t bytes[256];
    size_t size;
};

struct ProofInput {
    Reference sets[5][2];
};

using OpaqueStorage = std::aligned_storage_t<1024, alignof(max_align_t)>;

struct OpaqueDomainStorage {
    OpaqueStorage raw;
    size_t extent;
    size_t allocations;
    size_t releases;
    bool live;
    bool failed;
};

static void *opaque_allocate(void *context, size_t raw_size, size_t alignment)
{
    auto *storage = static_cast<OpaqueDomainStorage *>(context);
    if (storage->live || raw_size > sizeof(storage->raw) || alignment != alignof(max_align_t)) {
        storage->failed = true;
        return nullptr;
    }
    storage->extent = raw_size;
    storage->live = true;
    storage->allocations++;
    memset(&storage->raw, 0xa5, sizeof(storage->raw));
    return &storage->raw;
}

static void opaque_release(void *context, void *pointer, size_t raw_size,
                           size_t alignment)
{
    auto *storage = static_cast<OpaqueDomainStorage *>(context);
    if (pointer != &storage->raw || !storage->live || raw_size != storage->extent ||
        alignment != alignof(max_align_t)) storage->failed = true;
    const auto *bytes = static_cast<const uint8_t *>(pointer);
    for (size_t index = 0; index < raw_size; index++) {
        if (bytes[index] != 0) storage->failed = true;
    }
    storage->live = false;
    storage->releases++;
}

static int opaque_raw_storage_metadata_lifetime(const ProofInput *)
{
    OpaqueDomainStorage storage = {};
    const OPENSSL_ALLOCATION_DOMAIN domain = {&storage, opaque_allocate, opaque_release};
    for (size_t size : {size_t{0}, size_t{1}, size_t{257}}) {
        auto *pointer = static_cast<uint8_t *>(OPENSSL_malloc_with_domain(size, &domain));
        REQUIRE(pointer != nullptr && bssl::GetAllocationDomain(pointer) == &domain);
        REQUIRE(reinterpret_cast<uintptr_t>(pointer) % alignof(max_align_t) == 0);
        memset(pointer, 0x93, size);
        OPENSSL_free(pointer);
        REQUIRE(!storage.live && !storage.failed);
    }
    REQUIRE(storage.allocations == 3 && storage.releases == 3);
    return 0;
}

static void *domain_allocate(void *context, size_t raw_size, size_t alignment)
{
    auto *storage = static_cast<DomainStorage *>(context);
    storage->attempts++;
    if (storage->attempts == storage->fail_attempt) return nullptr;
    if (alignment != alignof(max_align_t) || raw_size > sizeof(storage->slots[0])) {
        storage->failed = true;
        return nullptr;
    }
    for (size_t index = 0; index < 16; index++) {
        if (storage->active[index]) continue;
        storage->active[index] = 1;
        storage->sizes[index] = raw_size;
        storage->allocated++;
        storage->live++;
        if (storage->live > storage->peak_live) storage->peak_live = storage->live;
        memset(storage->slots[index], 0xa5, raw_size);
        return storage->slots[index];
    }
    storage->failed = true;
    return nullptr;
}

static void domain_release(void *context, void *raw_pointer, size_t raw_size,
                           size_t alignment)
{
    auto *storage = static_cast<DomainStorage *>(context);
    for (size_t index = 0; index < 16; index++) {
        if (raw_pointer != storage->slots[index]) continue;
        if (!storage->active[index] || storage->sizes[index] != raw_size ||
            alignment != alignof(max_align_t)) {
            storage->failed = true;
            return;
        }
        for (size_t offset = 0; offset < raw_size; offset++) {
            if (storage->slots[index][offset] != 0) storage->failed = true;
        }
        storage->active[index] = 0;
        storage->released++;
        storage->live--;
        return;
    }
    storage->failed = true;
}

static bool storage_clean(const DomainStorage *storage)
{
    return !storage->failed && storage->live == 0 &&
        storage->allocated == storage->released;
}

static bool payload_matches(const uint8_t *data, size_t size, uint8_t value)
{
    for (size_t index = 0; index < size; index++) if (data[index] != value) return false;
    return true;
}

static int interleaved_domains(const ProofInput *)
{
    DomainStorage first = {}, second = {};
    const OPENSSL_ALLOCATION_DOMAIN domain_a = {&first, domain_allocate, domain_release};
    const OPENSSL_ALLOCATION_DOMAIN domain_b = {&second, domain_allocate, domain_release};
    const size_t sizes[] = {0, 1, 7, 8, 15, 16, 17, 63, 64, 255};
    uint8_t *pointers[10] = {};
    for (size_t index = 0; index < 10; index++) {
        const auto *domain = index % 2 ? &domain_b : &domain_a;
        pointers[index] = static_cast<uint8_t *>(OPENSSL_malloc_with_domain(sizes[index], domain));
        REQUIRE(pointers[index] != nullptr);
        REQUIRE(reinterpret_cast<uintptr_t>(pointers[index]) % alignof(max_align_t) == 0);
        REQUIRE(bssl::GetAllocationDomain(pointers[index]) == domain);
        memset(pointers[index], 0x71 + index, sizes[index]);
    }
    for (size_t index = 10; index > 0; index--) OPENSSL_free(pointers[index - 1]);
    REQUIRE(first.allocated == 5 && second.allocated == 5);
    REQUIRE(storage_clean(&first) && storage_clean(&second));
    return 0;
}

static int invalid_domains_and_overflow(const ProofInput *)
{
    DomainStorage storage = {};
    const OPENSSL_ALLOCATION_DOMAIN valid = {&storage, domain_allocate, domain_release};
    const OPENSSL_ALLOCATION_DOMAIN no_allocate = {&storage, nullptr, domain_release};
    const OPENSSL_ALLOCATION_DOMAIN no_release = {&storage, domain_allocate, nullptr};
    REQUIRE(OPENSSL_malloc_with_domain(1, nullptr) == nullptr);
    REQUIRE(OPENSSL_malloc_with_domain(0, nullptr) == nullptr);
    REQUIRE(OPENSSL_malloc_with_domain(1, &no_allocate) == nullptr);
    REQUIRE(OPENSSL_malloc_with_domain(1, &no_release) == nullptr);
    REQUIRE(OPENSSL_malloc_with_domain(SIZE_MAX, &valid) == nullptr);
    REQUIRE(OPENSSL_malloc_with_domain(SIZE_MAX - 7, &valid) == nullptr);
    REQUIRE(storage.attempts == 0);
    OPENSSL_free(nullptr);
    REQUIRE(storage_clean(&storage));
    return 0;
}

static int realloc_preserves_owner_and_oom(const ProofInput *)
{
    DomainStorage storage = {};
    const OPENSSL_ALLOCATION_DOMAIN domain = {&storage, domain_allocate, domain_release};
    auto *pointer = static_cast<uint8_t *>(OPENSSL_malloc_with_domain(37, &domain));
    REQUIRE(pointer != nullptr);
    memset(pointer, 0x83, 37);
    storage.fail_attempt = storage.attempts + 1;
    REQUIRE(OPENSSL_realloc(pointer, 90) == nullptr);
    REQUIRE(storage.live == 1 && storage.released == 0);
    REQUIRE(payload_matches(pointer, 37, 0x83));
    REQUIRE(bssl::GetAllocationDomain(pointer) == &domain);
    storage.fail_attempt = 0;
    REQUIRE(OPENSSL_realloc(pointer, SIZE_MAX) == nullptr);
    REQUIRE(payload_matches(pointer, 37, 0x83));
    auto *grown = static_cast<uint8_t *>(OPENSSL_realloc(pointer, 90));
    REQUIRE(grown != nullptr && grown != pointer);
    REQUIRE(payload_matches(grown, 37, 0x83));
    REQUIRE(bssl::GetAllocationDomain(grown) == &domain);
    memset(grown, 0x94, 90);
    auto *shrunk = static_cast<uint8_t *>(OPENSSL_realloc(grown, 9));
    REQUIRE(shrunk != nullptr && payload_matches(shrunk, 9, 0x94));
    auto *zero = static_cast<uint8_t *>(OPENSSL_realloc(shrunk, 0));
    REQUIRE(zero != nullptr && bssl::GetAllocationDomain(zero) == &domain);
    OPENSSL_free(zero);
    REQUIRE(storage.allocated == 4 && storage.released == 4);
    REQUIRE(storage_clean(&storage));
    return 0;
}

static int callback_oom_and_recycling(const ProofInput *)
{
    DomainStorage storage = {};
    const OPENSSL_ALLOCATION_DOMAIN domain = {&storage, domain_allocate, domain_release};
    storage.fail_attempt = 1;
    REQUIRE(OPENSSL_malloc_with_domain(0, &domain) == nullptr);
    REQUIRE(storage.allocated == 0 && storage.released == 0);
    storage.fail_attempt = 0;
    for (size_t index = 0; index < 100; index++) {
        void *pointer = OPENSSL_malloc_with_domain(index, &domain);
        REQUIRE(pointer != nullptr);
        memset(pointer, 0xc8, index);
        OPENSSL_free(pointer);
    }
    REQUIRE(storage.peak_live == 1 && storage.allocated == 100);
    REQUIRE(storage_clean(&storage));
    return 0;
}

static int owned_cbb_finish_and_nested_growth(const ProofInput *)
{
    DomainStorage storage = {};
    const OPENSSL_ALLOCATION_DOMAIN domain = {&storage, domain_allocate, domain_release};
    CBB root, child, grandchild;
    REQUIRE(CBB_init_with_domain(&root, 0, &domain));
    REQUIRE(CBB_add_u16_length_prefixed(&root, &child));
    REQUIRE(CBB_add_u8_length_prefixed(&child, &grandchild));
    for (size_t index = 0; index < 160; index++) REQUIRE(CBB_add_u8(&grandchild, index));
    uint8_t *output = nullptr;
    size_t size = 0;
    REQUIRE(CBB_finish(&root, &output, &size));
    REQUIRE(size == 163 && output[0] == 0 && output[1] == 161 && output[2] == 160);
    for (size_t index = 0; index < 160; index++) REQUIRE(output[index + 3] == index);
    REQUIRE(storage.live == 1 && bssl::GetAllocationDomain(output) == &domain);
    CBB_cleanup(&root);
    REQUIRE(storage.live == 1);
    auto *larger = static_cast<uint8_t *>(OPENSSL_realloc(output, 250));
    REQUIRE(larger != nullptr && larger[162] == 159);
    OPENSSL_free(larger);
    REQUIRE(storage_clean(&storage));
    return 0;
}

static int owned_cbb_init_failure_sticky(const ProofInput *)
{
    const size_t capacities[] = {0, 1, 64};
    for (size_t capacity : capacities) {
        DomainStorage storage = {};
        const OPENSSL_ALLOCATION_DOMAIN domain = {&storage, domain_allocate, domain_release};
        storage.fail_attempt = 1;
        CBB root;
        memset(&root, 0xa5, sizeof(root));
        REQUIRE(!CBB_init_with_domain(&root, capacity, &domain));
        REQUIRE(root.u.base.error && !root.is_child && root.child == nullptr);
        REQUIRE(!CBB_add_u8(&root, 1));
        uint8_t *output = nullptr;
        size_t size = 0;
        REQUIRE(!CBB_finish(&root, &output, &size));
        CBB_cleanup(&root);
        CBB_cleanup(&root);
        REQUIRE(storage.attempts == 1 && storage_clean(&storage));
    }
    CBB root;
    REQUIRE(!CBB_init_with_domain(&root, 0, nullptr));
    REQUIRE(!CBB_add_u8(&root, 2));
    CBB_cleanup(&root);
    return 0;
}

static int owned_cbb_growth_failure_sticky(const ProofInput *)
{
    DomainStorage storage = {};
    const OPENSSL_ALLOCATION_DOMAIN domain = {&storage, domain_allocate, domain_release};
    CBB root;
    REQUIRE(CBB_init_with_domain(&root, 1, &domain));
    REQUIRE(CBB_add_u8(&root, 0x73));
    uint8_t *original = root.u.base.buf;
    storage.fail_attempt = storage.attempts + 1;
    REQUIRE(!CBB_add_u8(&root, 0x74));
    REQUIRE(root.u.base.buf == original && original[0] == 0x73);
    REQUIRE(storage.live == 1 && root.u.base.error);
    storage.fail_attempt = 0;
    REQUIRE(!CBB_add_u8(&root, 0x75));
    uint8_t *output = nullptr;
    size_t size = 0;
    REQUIRE(!CBB_finish(&root, &output, &size));
    CBB_cleanup(&root);
    REQUIRE(storage_clean(&storage));
    return 0;
}

static size_t set_count(size_t which)
{
    const size_t counts[] = {0, 1, 2, 16, 9};
    return counts[which];
}

static int fill_set(CBB *root, CBB *child, bool nested, size_t which)
{
    CBB *destination = root;
    if (nested) {
        if (!CBB_add_asn1(root, child, CBS_ASN1_SET)) return 0;
        destination = child;
    }
    size_t count = set_count(which);
    for (size_t index = 0; index < count; index++) {
        uint64_t value = which == 4 ? (count - index) % 3 : count - index;
        if (!CBB_add_asn1_uint64(destination, value)) return 0;
    }
    return 1;
}

static int prepare_references(ProofInput *input)
{
    for (size_t which = 0; which < 5; which++) {
        for (size_t nested = 0; nested < 2; nested++) {
            CBB root, child;
            REQUIRE(CBB_init(&root, 1));
            REQUIRE(fill_set(&root, &child, nested, which));
            REQUIRE(CBB_flush_asn1_set_of(nested ? &child : &root));
            uint8_t *output = nullptr;
            size_t size = 0;
            REQUIRE(CBB_finish(&root, &output, &size));
            REQUIRE(size <= sizeof(input->sets[which][nested].bytes));
            memcpy(input->sets[which][nested].bytes, output, size);
            input->sets[which][nested].size = size;
            OPENSSL_free(output);
        }
    }
    return 0;
}

static int owned_set_parity(const ProofInput *input)
{
    for (size_t which = 0; which < 5; which++) {
        for (size_t nested = 0; nested < 2; nested++) {
            DomainStorage storage = {};
            const OPENSSL_ALLOCATION_DOMAIN domain = {&storage, domain_allocate, domain_release};
            CBB root, child;
            REQUIRE(CBB_init_with_domain(&root, 1, &domain));
            REQUIRE(fill_set(&root, &child, nested, which));
            size_t before = storage.allocated;
            REQUIRE(CBB_flush_asn1_set_of(nested ? &child : &root));
            REQUIRE(storage.allocated - before == (set_count(which) >= 2 ? 2u : 0u));
            uint8_t *output = nullptr;
            size_t size = 0;
            REQUIRE(CBB_finish(&root, &output, &size));
            const Reference *reference = &input->sets[which][nested];
            REQUIRE(size == reference->size && memcmp(output, reference->bytes, size) == 0);
            OPENSSL_free(output);
            REQUIRE(storage_clean(&storage));
        }
    }
    return 0;
}

static int owned_set_scratch_oom(const ProofInput *)
{
    for (size_t nested = 0; nested < 2; nested++) {
        for (size_t failure = 1; failure <= 2; failure++) {
            DomainStorage storage = {};
            const OPENSSL_ALLOCATION_DOMAIN domain = {&storage, domain_allocate, domain_release};
            CBB root, child;
            REQUIRE(CBB_init_with_domain(&root, 128, &domain));
            REQUIRE(fill_set(&root, &child, nested, 3));
            storage.fail_attempt = storage.attempts + failure;
            REQUIRE(!CBB_flush_asn1_set_of(nested ? &child : &root));
            REQUIRE(root.u.base.error && storage.live == 1);
            REQUIRE(storage.attempts == storage.fail_attempt);
            REQUIRE(!CBB_add_u8(&root, 1));
            uint8_t *output = nullptr;
            size_t size = 0;
            REQUIRE(!CBB_finish(&root, &output, &size));
            CBB_cleanup(&root);
            REQUIRE(storage_clean(&storage));
        }
    }
    return 0;
}

static int owned_set_malformed_cleanup(const ProofInput *)
{
    DomainStorage storage = {};
    const OPENSSL_ALLOCATION_DOMAIN domain = {&storage, domain_allocate, domain_release};
    CBB root;
    REQUIRE(CBB_init_with_domain(&root, 8, &domain));
    const uint8_t malformed[] = {0x02, 0x03, 0x01};
    REQUIRE(CBB_add_bytes(&root, malformed, sizeof(malformed)));
    REQUIRE(!CBB_flush_asn1_set_of(&root));
    CBB_cleanup(&root);
    REQUIRE(storage_clean(&storage));
    return 0;
}

static int array_transfer_move_and_replace(const ProofInput *)
{
    DomainStorage first = {}, second = {};
    const OPENSSL_ALLOCATION_DOMAIN domain_a = {&first, domain_allocate, domain_release};
    const OPENSSL_ALLOCATION_DOMAIN domain_b = {&second, domain_allocate, domain_release};
    CBB builder_a, builder_b;
    REQUIRE(CBB_init_with_domain(&builder_a, 3, &domain_a));
    REQUIRE(CBB_add_u8(&builder_a, 0x31));
    uint8_t *base_a = builder_a.u.base.buf;
    bssl::Array<uint8_t> array;
    REQUIRE(bssl::CBBFinishArray(&builder_a, &array));
    REQUIRE(array.data() == base_a && array.size() == 1 && array[0] == 0x31);
    REQUIRE(first.live == 1);
    CBB_cleanup(&builder_a);
    bssl::Array<uint8_t> moved(std::move(array));
    REQUIRE(array.empty() && array.data() == nullptr && moved.data() == base_a);
    REQUIRE(CBB_init_with_domain(&builder_b, 4, &domain_b));
    REQUIRE(CBB_add_u8(&builder_b, 0x42));
    uint8_t *base_b = builder_b.u.base.buf;
    REQUIRE(bssl::CBBFinishArray(&builder_b, &moved));
    REQUIRE(storage_clean(&first));
    REQUIRE(second.live == 1 && moved.data() == base_b && moved[0] == 0x42);
    bssl::Array<uint8_t> assigned;
    assigned = std::move(moved);
    REQUIRE(moved.empty() && assigned.data() == base_b);
    assigned.Reset();
    CBB_cleanup(&builder_b);
    REQUIRE(storage_clean(&second));
    return 0;
}

static int fixed_cbb_control(const ProofInput *input)
{
    uint8_t fixed[256];
    memset(fixed, 0xa5, sizeof(fixed));
    CBB root, child;
    REQUIRE(CBB_init_fixed(&root, fixed, sizeof(fixed)));
    REQUIRE(fill_set(&root, &child, true, 1));
    REQUIRE(CBB_flush_asn1_set_of(&child));
    uint8_t *output = nullptr;
    size_t size = 0;
    REQUIRE(CBB_finish(&root, &output, &size));
    REQUIRE(output == fixed && size == input->sets[1][1].size);
    REQUIRE(memcmp(output, input->sets[1][1].bytes, size) == 0);
    CBB_cleanup(&root);
    REQUIRE(fixed[size] == 0xa5);
    REQUIRE(CBB_init_fixed(&root, fixed, 0));
    REQUIRE(!CBB_add_u8(&root, 0xff));
    CBB_cleanup(&root);
    return 0;
}

static int ordinary_memory_and_fixed_multi_set(const ProofInput *input)
{
    auto *ordinary = static_cast<uint8_t *>(OPENSSL_malloc(13));
    REQUIRE(ordinary != nullptr && bssl::GetAllocationDomain(ordinary) == nullptr);
    size_t recorded = 0;
    memcpy(&recorded, ordinary - 8, sizeof(recorded));
    REQUIRE(recorded == 13);
    memset(ordinary, 0xb1, 13);
    auto *grown = static_cast<uint8_t *>(OPENSSL_realloc(ordinary, 29));
    REQUIRE(grown != nullptr && payload_matches(grown, 13, 0xb1));
    REQUIRE(bssl::GetAllocationDomain(grown) == nullptr);
    REQUIRE(OPENSSL_realloc(grown, SIZE_MAX) == nullptr);
    REQUIRE(payload_matches(grown, 13, 0xb1));
    OPENSSL_free(grown);
    auto *from_null = OPENSSL_realloc(nullptr, 4);
    REQUIRE(from_null != nullptr && bssl::GetAllocationDomain(from_null) == nullptr);
    OPENSSL_free(from_null);
    auto *zeroed = static_cast<uint8_t *>(OPENSSL_calloc(5, 3));
    REQUIRE(zeroed != nullptr && payload_matches(zeroed, 15, 0));
    OPENSSL_free(zeroed);
    REQUIRE(OPENSSL_calloc(SIZE_MAX, 2) == nullptr);
    for (size_t which = 2; which < 5; which++) {
        uint8_t fixed[256];
        CBB root, child;
        REQUIRE(CBB_init_fixed(&root, fixed, sizeof(fixed)));
        REQUIRE(fill_set(&root, &child, true, which));
        REQUIRE(CBB_flush_asn1_set_of(&child));
        uint8_t *output = nullptr;
        size_t size = 0;
        REQUIRE(CBB_finish(&root, &output, &size));
        REQUIRE(output == fixed && size == input->sets[which][1].size);
        REQUIRE(memcmp(output, input->sets[which][1].bytes, size) == 0);
        CBB_cleanup(&root);
    }
    return 0;
}

using ProofFunction = int (*)(const ProofInput *);

struct ProofCase {
    const char *name;
    ProofFunction run;
};

static int run_owned_case(const ProofCase *proof_case, const ProofInput *input)
{
    ERR_clear_error();
    uwz_alloc_begin();
    int result = proof_case->run(input);
    uwz_alloc_end();
    uint64_t malloc_count = uwz_alloc_malloc_calls();
    uint64_t calloc_count = uwz_alloc_calloc_calls();
    uint64_t realloc_count = uwz_alloc_realloc_calls();
    uint64_t free_count = uwz_alloc_free_calls();
    uint64_t requested = uwz_alloc_requested_bytes();
    bool clean = malloc_count == 0 && calloc_count == 0 && realloc_count == 0 &&
        free_count == 0 && requested == 0;
    printf("%s result=%d malloc=%llu calloc=%llu realloc=%llu free=%llu requested=%llu\n",
           proof_case->name, result, (unsigned long long)malloc_count,
           (unsigned long long)calloc_count, (unsigned long long)realloc_count,
           (unsigned long long)free_count, (unsigned long long)requested);
    return result != 0 || !clean;
}

int main(void)
{
    setvbuf(stdout, nullptr, _IONBF, 0);
    if (!uwz_alloc_self_test()) return 1;
    printf("all_c_counter_self_test malloc=1 calloc=1 realloc=1 free=2 requested=63 PASS\n");
    OPENSSL_PUT_ERROR(CRYPTO, ERR_R_MALLOC_FAILURE);
    ERR_clear_error();
    printf("ERR thread queue initialized outside measured scopes; cold ERR ownership unclaimed\n");
    ProofInput input = {};
    int setup = prepare_references(&input);
    if (setup) {
        printf("ordinary_reference_setup failed line=%d\n", setup);
        return 1;
    }
    const ProofCase cases[] = {
        {"opaque_aligned_raw_storage_metadata_lifetime", opaque_raw_storage_metadata_lifetime},
        {"interleaved_domains_alignment_zero_full_raw_cleanse", interleaved_domains},
        {"invalid_domains_overflow_before_callback", invalid_domains_and_overflow},
        {"realloc_owner_grow_shrink_zero_oom_preserves_old", realloc_preserves_owner_and_oom},
        {"callback_oom_and_recyclable_storage", callback_oom_and_recycling},
        {"owned_cbb_nested_growth_raw_finish", owned_cbb_finish_and_nested_growth},
        {"owned_cbb_zero_nonzero_init_oom_sticky", owned_cbb_init_failure_sticky},
        {"owned_cbb_growth_oom_sticky", owned_cbb_growth_failure_sticky},
        {"owned_set_0_1_2_many_reversed_duplicates_child_parity", owned_set_parity},
        {"owned_set_each_copy_descriptor_scratch_oom", owned_set_scratch_oom},
        {"owned_set_malformed_cleanup", owned_set_malformed_cleanup},
        {"owned_array_exact_transfer_move_cross_domain_replace", array_transfer_move_and_replace},
        {"fixed_cbb_no_owner_probe_control", fixed_cbb_control},
    };
    int failed = 0;
    for (const auto &proof_case : cases) failed += run_owned_case(&proof_case, &input);
    int ordinary = ordinary_memory_and_fixed_multi_set(&input);
    printf("ordinary_8byte_prefix_realloc_null_calloc_fixed_multi_set result=%d\n", ordinary);
    failed += ordinary != 0;
    printf("native_domain_proof rows=%zu failed=%d\n", sizeof(cases) / sizeof(cases[0]) + 1, failed);
    return failed != 0;
}
