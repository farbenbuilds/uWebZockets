#include <openssl/err.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "crypto/x509/internal.h"

#define REQUIRE(condition) do { if (!(condition)) return __LINE__; } while (0)

struct alignas(max_align_t) HookHeader { size_t bytes; };
// The weak-hook ABI has no context argument; this test process has one owner.
static size_t rejected_size;
static size_t rejection_count;

extern "C" void *OPENSSL_memory_alloc(size_t bytes)
{
    if (rejected_size != 0 && bytes == rejected_size) {
        rejection_count++;
        return nullptr;
    }
    if (bytes > SIZE_MAX - sizeof(HookHeader)) return nullptr;
    auto *header = static_cast<HookHeader *>(malloc(sizeof(HookHeader) + bytes));
    if (header == nullptr) return nullptr;
    header->bytes = bytes;
    return header + 1;
}

extern "C" size_t OPENSSL_memory_get_size(void *pointer)
{
    return (static_cast<HookHeader *>(pointer) - 1)->bytes;
}

extern "C" void OPENSSL_memory_free(void *pointer)
{
    if (pointer != nullptr) free(static_cast<HookHeader *>(pointer) - 1);
}

int main(int argc, char **argv)
{
    const bool expect_fixed = argc == 2 && strcmp(argv[1], "--expect-fixed") == 0;
    SSL_CTX *ctx = SSL_CTX_new(TLS_client_method());
    REQUIRE(ctx != nullptr);
    SSL *warm = SSL_new(ctx);
    REQUIRE(warm != nullptr);
    SSL_free(warm);
    const char name[] = "required-constructor-host-constraint.example.test";
    REQUIRE(X509_VERIFY_PARAM_set1_host(SSL_CTX_get0_param(ctx), name, strlen(name)));
    ERR_clear_error();
    rejected_size = sizeof(name);
    SSL *ssl = SSL_new(ctx);
    rejected_size = 0;
    const bool dropped = ssl != nullptr && SSL_get0_param(ssl)->hosts == nullptr;
    printf("inherit_name_allocation_failure injected=%zu ssl_returned=%d inherited_name_dropped=%d expected_fixed=%d\n",
           rejection_count, ssl != nullptr, dropped, expect_fixed);
    const bool valid = rejection_count == 1 && (expect_fixed ? ssl == nullptr : dropped);
    SSL_free(ssl);
    SSL_CTX_free(ctx);
    ERR_clear_error();
    REQUIRE(valid);
    return 0;
}
