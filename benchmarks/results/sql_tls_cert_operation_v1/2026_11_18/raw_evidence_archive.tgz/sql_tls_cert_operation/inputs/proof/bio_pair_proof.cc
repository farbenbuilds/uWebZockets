#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/mem.h>
#include <openssl/ssl.h>

#include <limits.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "crypto/mem_internal.h"

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

#define REQUIRE(condition) do { if (!(condition)) return __LINE__; } while (0)

struct RawBlock {
    void *pointer;
    size_t bytes;
    size_t alignment;
    bool live;
};

struct PairStorage {
    alignas(max_align_t) uint8_t backing[131072];
    RawBlock blocks[8];
    OPENSSL_ALLOCATION_DOMAIN domain;
    size_t capacity;
    size_t cursor;
    size_t peak;
    size_t live;
    size_t attempts;
    size_t allocations;
    size_t releases;
    size_t raw_bytes;
    size_t rounded_bytes;
    size_t fail_attempt;
    bool failed;
};

static void *allocate_pair(void *context, size_t bytes, size_t alignment)
{
    auto *storage = static_cast<PairStorage *>(context);
    storage->attempts++;
    if (storage->attempts == storage->fail_attempt) return nullptr;
    if (alignment == 0 || alignment > alignof(max_align_t) ||
        (alignment & (alignment - 1)) != 0 || storage->cursor > SIZE_MAX - (alignment - 1)) {
        storage->failed = true;
        return nullptr;
    }
    const size_t offset = (storage->cursor + alignment - 1) & ~(alignment - 1);
    if (offset > storage->capacity || bytes > storage->capacity - offset) return nullptr;
    size_t slot = 0;
    while (slot < 8 && storage->blocks[slot].live) slot++;
    if (slot == 8) {
        storage->failed = true;
        return nullptr;
    }
    void *pointer = storage->backing + offset;
    if (reinterpret_cast<uintptr_t>(pointer) % alignment != 0) {
        storage->failed = true;
        return nullptr;
    }
    storage->blocks[slot] = {pointer, bytes, alignment, true};
    storage->cursor = offset + bytes;
    if (storage->cursor > storage->peak) storage->peak = storage->cursor;
    storage->live++;
    storage->allocations++;
    storage->raw_bytes += bytes;
    storage->rounded_bytes += (bytes + alignment - 1) & ~(alignment - 1);
    memset(pointer, 0xa5, bytes);
    return pointer;
}

static void release_pair(void *context, void *pointer, size_t bytes, size_t alignment)
{
    auto *storage = static_cast<PairStorage *>(context);
    size_t slot = 0;
    while (slot < 8 && (!storage->blocks[slot].live || storage->blocks[slot].pointer != pointer)) slot++;
    if (slot == 8 || storage->blocks[slot].bytes != bytes ||
        storage->blocks[slot].alignment != alignment || storage->live == 0) {
        storage->failed = true;
        return;
    }
    const auto *raw = static_cast<const uint8_t *>(pointer);
    for (size_t index = 0; index < bytes; index++) {
        if (raw[index] != 0) storage->failed = true;
    }
    storage->blocks[slot].live = false;
    storage->live--;
    storage->releases++;
    if (storage->live == 0) storage->cursor = 0;
}

static bool configure_storage(PairStorage *storage, const BIO_PAIR_STORAGE_REQUIREMENTS &requirements,
                              void *backing, size_t capacity)
{
    if (storage->live != 0 || backing != storage->backing || requirements.alignment == 0 ||
        requirements.alignment > alignof(max_align_t) ||
        reinterpret_cast<uintptr_t>(backing) % requirements.alignment != 0 ||
        capacity < requirements.bytes || capacity > sizeof(storage->backing)) return false;
    storage->capacity = capacity;
    storage->domain = {storage, allocate_pair, release_pair};
    return true;
}

static int initialize(PairStorage *storage, size_t first, size_t second)
{
    BIO_PAIR_STORAGE_REQUIREMENTS requirements = {};
    REQUIRE(BIO_pair_storage_requirements(first, second, &requirements));
    REQUIRE(configure_storage(storage, requirements, storage->backing, requirements.bytes));
    return 0;
}

static int cold_requirements(void)
{
    BIO_PAIR_STORAGE_REQUIREMENTS requirements = {19, 73};
    REQUIRE(BIO_pair_storage_requirements(32768, 32768, &requirements));
    REQUIRE(requirements.bytes == 66016 && requirements.alignment == alignof(max_align_t));
    REQUIRE(!BIO_pair_storage_requirements(32768, 32768, nullptr));
    requirements = {19, 73};
    REQUIRE(!BIO_pair_storage_requirements(SIZE_MAX, 0, &requirements));
    REQUIRE(requirements.bytes == 0 && requirements.alignment == 0);
    return 0;
}

static int requirements_purity_and_overflow(void)
{
    OPENSSL_PUT_ERROR(CRYPTO, ERR_R_MALLOC_FAILURE);
    const uint32_t before = ERR_peek_error();
    REQUIRE(before != 0);
    BIO_PAIR_STORAGE_REQUIREMENTS defaults = {}, explicit_defaults = {};
    REQUIRE(BIO_pair_storage_requirements(0, 0, &defaults));
    REQUIRE(BIO_pair_storage_requirements(17 * 1024, 17 * 1024, &explicit_defaults));
    REQUIRE(defaults.bytes == explicit_defaults.bytes && defaults.alignment == explicit_defaults.alignment);
    REQUIRE(ERR_peek_error() == before);
    bssl::AllocationDomainRequirements raw = {};
    REQUIRE(bssl::GetAllocationDomainRequirements(0, &raw));
    REQUIRE(raw.raw_size != 0 && raw.alignment == alignof(max_align_t));
    const size_t overflow[] = {SIZE_MAX, SIZE_MAX - raw.raw_size, SIZE_MAX / 2};
    for (size_t size : overflow) {
        BIO_PAIR_STORAGE_REQUIREMENTS bad = {19, 73};
        REQUIRE(!BIO_pair_storage_requirements(size, size, &bad));
        REQUIRE(bad.bytes == 0 && bad.alignment == 0 && ERR_peek_error() == before);
    }
    ERR_clear_error();
    return 0;
}

static int capacity_and_bound_parity(void)
{
    const size_t capacities[][2] = {{0, 0}, {1, 3}, {3, 1}, {19, 73}, {32768, 32768}};
    for (const auto &capacity : capacities) {
        PairStorage storage = {};
        REQUIRE(initialize(&storage, capacity[0], capacity[1]) == 0);
        BIO_PAIR_STORAGE_REQUIREMENTS requirements = {};
        REQUIRE(BIO_pair_storage_requirements(capacity[0], capacity[1], &requirements));
        BIO *first = nullptr, *second = nullptr;
        REQUIRE(BIO_new_bio_pair_with_domain(&first, capacity[0], &second, capacity[1], &storage.domain));
        REQUIRE(first != nullptr && second != nullptr && first != second);
        REQUIRE(storage.allocations == 6 && storage.live == 6 && storage.peak <= requirements.bytes);
        REQUIRE(storage.rounded_bytes == requirements.bytes);
        REQUIRE(BIO_ctrl_get_write_guarantee(first) == (capacity[0] ? capacity[0] : 17 * 1024));
        REQUIRE(BIO_ctrl_get_write_guarantee(second) == (capacity[1] ? capacity[1] : 17 * 1024));
        const uint8_t byte = 199;
        uint8_t result = 0;
        REQUIRE(BIO_write(first, &byte, 1) == 1 && BIO_read(second, &result, 1) == 1 && result == byte);
        BIO_free(first);
        REQUIRE(storage.live == 3 && storage.cursor != 0);
        BIO_free(second);
        REQUIRE(storage.live == 0 && storage.cursor == 0 && storage.releases == 6 && !storage.failed);
    }
    return 0;
}

static int ring_wrap_retry_and_half_close(void)
{
    PairStorage storage = {};
    REQUIRE(initialize(&storage, 8, 5) == 0);
    BIO *first = nullptr, *second = nullptr;
    REQUIRE(BIO_new_bio_pair_with_domain(&first, 8, &second, 5, &storage.domain));
    uint8_t bytes[16] = {};
    const uint8_t initial[] = {0, 1, 2, 3, 4, 5, 6, 7};
    const uint8_t wrapped[] = {31, 32, 33};
    REQUIRE(BIO_read(second, bytes, 3) == -1 && BIO_should_read(second) && BIO_should_retry(second));
    REQUIRE(BIO_ctrl_get_read_request(first) == 3);
    REQUIRE(BIO_ctrl(first, BIO_C_RESET_READ_REQUEST, 0, nullptr) == 1);
    REQUIRE(BIO_ctrl_get_read_request(first) == 0);
    REQUIRE(BIO_write(first, initial, sizeof(initial)) == 8);
    REQUIRE(BIO_pending(second) == 8 && BIO_wpending(first) == 8);
    REQUIRE(BIO_ctrl_get_write_guarantee(first) == 0);
    REQUIRE(BIO_write(first, wrapped, 1) == -1 && BIO_should_write(first) && BIO_should_retry(first));
    REQUIRE(BIO_read(second, bytes, 3) == 3 && memcmp(bytes, initial, 3) == 0);
    REQUIRE(BIO_write(first, wrapped, sizeof(wrapped)) == 3);
    REQUIRE(BIO_read(second, bytes, sizeof(bytes)) == 8);
    REQUIRE(memcmp(bytes, initial + 3, 5) == 0 && memcmp(bytes + 5, wrapped, 3) == 0);
    REQUIRE(BIO_write(second, initial, sizeof(initial)) == 5);
    REQUIRE(BIO_read(first, bytes, sizeof(bytes)) == 5 && memcmp(bytes, initial, 5) == 0);
    REQUIRE(BIO_flush(first) == 1 && BIO_flush(second) == 1);
    REQUIRE(BIO_write(first, wrapped, sizeof(wrapped)) == 3);
    REQUIRE(BIO_shutdown_wr(first) == 1 && BIO_ctrl_get_write_guarantee(first) == 0);
    REQUIRE(!BIO_eof(second));
    REQUIRE(BIO_read(second, bytes, sizeof(bytes)) == 3 && memcmp(bytes, wrapped, 3) == 0);
    REQUIRE(BIO_read(second, bytes, 1) == 0 && !BIO_should_retry(second) && BIO_eof(second));
    REQUIRE(BIO_write(first, wrapped, 1) == -1 && !BIO_should_retry(first));
    REQUIRE(BIO_write(second, wrapped, sizeof(wrapped)) == 3);
    REQUIRE(BIO_read(first, bytes, sizeof(bytes)) == 3 && memcmp(bytes, wrapped, 3) == 0);
    REQUIRE(BIO_shutdown_wr(second) == 1 && BIO_read(first, bytes, 1) == 0 && BIO_eof(first));
    BIO_free(second);
    BIO_free(first);
    REQUIRE(storage.live == 0 && storage.allocations == storage.releases && !storage.failed);
    ERR_clear_error();
    return 0;
}

static int six_failure_sites_and_reuse(void)
{
    for (size_t fault = 1; fault <= 6; fault++) {
        PairStorage storage = {};
        REQUIRE(initialize(&storage, 32768, 32768) == 0);
        storage.fail_attempt = fault;
        BIO *first = reinterpret_cast<BIO *>(1), *second = reinterpret_cast<BIO *>(1);
        REQUIRE(!BIO_new_bio_pair_with_domain(&first, 32768, &second, 32768, &storage.domain));
        REQUIRE(first == nullptr && second == nullptr && storage.attempts == fault);
        REQUIRE(storage.live == 0 && storage.cursor == 0 && storage.allocations == storage.releases && !storage.failed);
        storage.fail_attempt = 0;
        REQUIRE(BIO_new_bio_pair_with_domain(&first, 32768, &second, 32768, &storage.domain));
        BIO_free(fault % 2 ? first : second);
        REQUIRE(storage.live == 3 && storage.cursor != 0);
        BIO_free(fault % 2 ? second : first);
        REQUIRE(storage.live == 0 && storage.cursor == 0 && storage.allocations == storage.releases && !storage.failed);
        ERR_clear_error();
    }
    return 0;
}

static int invalid_outputs_descriptors_and_bounds(void)
{
    PairStorage storage = {};
    REQUIRE(initialize(&storage, 8, 5) == 0);
    BIO *first = reinterpret_cast<BIO *>(1), *second = reinterpret_cast<BIO *>(1);
    REQUIRE(!BIO_new_bio_pair_with_domain(nullptr, 8, &second, 5, &storage.domain) && second == nullptr);
    REQUIRE(!BIO_new_bio_pair_with_domain(&first, 8, nullptr, 5, &storage.domain) && first == nullptr);
    first = reinterpret_cast<BIO *>(1);
    REQUIRE(!BIO_new_bio_pair_with_domain(&first, 8, &first, 5, &storage.domain) && first == nullptr);
    REQUIRE(!BIO_new_bio_pair_with_domain(nullptr, 8, nullptr, 5, &storage.domain));
    const OPENSSL_ALLOCATION_DOMAIN invalid[] = {{&storage, nullptr, release_pair}, {&storage, allocate_pair, nullptr}};
    for (const auto &domain : invalid) {
        first = second = reinterpret_cast<BIO *>(1);
        REQUIRE(!BIO_new_bio_pair_with_domain(&first, 8, &second, 5, &domain));
        REQUIRE(first == nullptr && second == nullptr);
    }
    first = second = reinterpret_cast<BIO *>(1);
    REQUIRE(!BIO_new_bio_pair_with_domain(&first, 8, &second, 5, nullptr));
    REQUIRE(first == nullptr && second == nullptr);
    const size_t overflow[] = {SIZE_MAX, SIZE_MAX - 32, SIZE_MAX / 2};
    for (size_t size : overflow) {
        first = second = reinterpret_cast<BIO *>(1);
        REQUIRE(!BIO_new_bio_pair_with_domain(&first, size, &second, size, &storage.domain));
        REQUIRE(first == nullptr && second == nullptr);
    }
    REQUIRE(storage.attempts == 0 && storage.live == 0 && !storage.failed);
    ERR_clear_error();
    return 0;
}

static int backing_rejection_and_overlap(void)
{
    PairStorage storage = {};
    BIO_PAIR_STORAGE_REQUIREMENTS requirements = {};
    REQUIRE(BIO_pair_storage_requirements(32768, 32768, &requirements));
    REQUIRE(!configure_storage(&storage, requirements, storage.backing + 1, requirements.bytes));
    REQUIRE(!configure_storage(&storage, requirements, storage.backing, requirements.bytes - 1));
    REQUIRE(storage.attempts == 0);
    REQUIRE(configure_storage(&storage, requirements, storage.backing, requirements.bytes));
    BIO *first = nullptr, *second = nullptr;
    REQUIRE(BIO_new_bio_pair_with_domain(&first, 32768, &second, 32768, &storage.domain));
    BIO *other_first = reinterpret_cast<BIO *>(1), *other_second = reinterpret_cast<BIO *>(1);
    REQUIRE(!BIO_new_bio_pair_with_domain(&other_first, 32768, &other_second, 32768, &storage.domain));
    REQUIRE(other_first == nullptr && other_second == nullptr && storage.live == 6);
    REQUIRE(!configure_storage(&storage, requirements, storage.backing, requirements.bytes));
    uint8_t expected = 173, output = 0;
    REQUIRE(BIO_write(first, &expected, 1) == 1 && BIO_read(second, &output, 1) == 1 && output == expected);
    BIO_free(first);
    BIO_free(second);
    REQUIRE(storage.live == 0 && storage.cursor == 0 && !storage.failed);
    ERR_clear_error();
    return 0;
}

static int independent_domains_and_recycling(void)
{
    PairStorage left = {}, right = {};
    REQUIRE(initialize(&left, 32768, 32768) == 0 && initialize(&right, 8, 5) == 0);
    for (size_t cycle = 0; cycle < 128; cycle++) {
        BIO *a = nullptr, *b = nullptr, *c = nullptr, *d = nullptr;
        REQUIRE(BIO_new_bio_pair_with_domain(&a, 32768, &b, 32768, &left.domain));
        REQUIRE(BIO_new_bio_pair_with_domain(&c, 8, &d, 5, &right.domain));
        uint8_t input = static_cast<uint8_t>(cycle * 73 + 19), output = 0;
        REQUIRE(BIO_write(a, &input, 1) == 1 && BIO_read(b, &output, 1) == 1 && output == input);
        REQUIRE(BIO_write(d, &input, 1) == 1 && BIO_read(c, &output, 1) == 1 && output == input);
        BIO_free(cycle % 2 ? b : a);
        BIO_free(cycle % 2 ? c : d);
        REQUIRE(left.live == 3 && right.live == 3);
        BIO_free(cycle % 2 ? a : b);
        REQUIRE(left.live == 0 && right.live == 3 && right.cursor != 0);
        BIO_free(cycle % 2 ? d : c);
        REQUIRE(right.live == 0 && left.cursor == 0 && right.cursor == 0);
        REQUIRE(!left.failed && !right.failed);
    }
    REQUIRE(left.allocations == 128 * 6 && right.allocations == 128 * 6);
    REQUIRE(left.releases == left.allocations && right.releases == right.allocations);
    return 0;
}

static int final_reference_in_both_orders(void)
{
    for (size_t order = 0; order < 2; order++) {
        PairStorage storage = {};
        REQUIRE(initialize(&storage, 8, 5) == 0);
        BIO *first = nullptr, *second = nullptr;
        REQUIRE(BIO_new_bio_pair_with_domain(&first, 8, &second, 5, &storage.domain));
        REQUIRE(BIO_up_ref(first) == 1 && BIO_up_ref(second) == 1);
        BIO_free(first);
        BIO_free(second);
        REQUIRE(storage.live == 6 && storage.releases == 0);
        uint8_t value = 91, output = 0;
        REQUIRE(BIO_write(first, &value, 1) == 1 && BIO_read(second, &output, 1) == 1 && output == value);
        BIO_free(order ? first : second);
        REQUIRE(storage.live == 3 && storage.cursor != 0);
        BIO_free(order ? second : first);
        REQUIRE(storage.live == 0 && storage.cursor == 0 && storage.releases == 6 && !storage.failed);
    }
    return 0;
}

static int ssl_transfer_allocating_control(void)
{
    SSL_CTX *context = SSL_CTX_new(TLS_method());
    REQUIRE(context != nullptr);
    for (size_t order = 0; order < 2; order++) {
        SSL *ssl = SSL_new(context);
        REQUIRE(ssl != nullptr);
        PairStorage storage = {};
        REQUIRE(initialize(&storage, 32768, 32768) == 0);
        BIO *internal = nullptr, *network = nullptr;
        REQUIRE(BIO_new_bio_pair_with_domain(&internal, 32768, &network, 32768, &storage.domain));
        REQUIRE(BIO_up_ref(internal) == 1);
        SSL_set_bio(ssl, internal, internal);
        if (order == 0) {
            BIO_free(network);
            REQUIRE(storage.live == 3);
            SSL_free(ssl);
            REQUIRE(storage.live == 3 && storage.cursor != 0);
            BIO_free(internal);
        } else {
            BIO_free(internal);
            REQUIRE(storage.live == 6);
            SSL_free(ssl);
            REQUIRE(storage.live == 3 && storage.cursor != 0);
            BIO_free(network);
        }
        REQUIRE(storage.live == 0 && storage.cursor == 0 && storage.releases == 6 && !storage.failed);
    }
    SSL_CTX_free(context);
    return 0;
}

using CaseFunction = int (*)(void);
struct ProofCase {
    const char *name;
    CaseFunction run;
    bool zero;
};

static int run_case(const ProofCase &proof)
{
    uwz_alloc_begin();
    const int line = proof.run();
    uwz_alloc_end();
    const auto mallocs = uwz_alloc_malloc_calls();
    const auto callocs = uwz_alloc_calloc_calls();
    const auto reallocs = uwz_alloc_realloc_calls();
    const auto frees = uwz_alloc_free_calls();
    const auto bytes = uwz_alloc_requested_bytes();
    const bool zero = mallocs == 0 && callocs == 0 && reallocs == 0 && frees == 0 && bytes == 0;
    const bool failed = line != 0 || (proof.zero ? !zero : zero);
    printf("bio_pair_case=%s failed=%d line=%d malloc=%llu calloc=%llu realloc=%llu free=%llu bytes=%llu expected=%s\n",
           proof.name, failed, line, static_cast<unsigned long long>(mallocs),
           static_cast<unsigned long long>(callocs), static_cast<unsigned long long>(reallocs),
           static_cast<unsigned long long>(frees), static_cast<unsigned long long>(bytes),
           proof.zero ? "zero" : "allocating_ssl_control");
    return failed;
}

int main(void)
{
    int failed = run_case({"cold_requirements_no_heap", cold_requirements, true});
    if (!uwz_alloc_self_test()) return 2;
    ERR_clear_error();
    const ProofCase cases[] = {
        {"requirements_purity_default_overflow", requirements_purity_and_overflow, true},
        {"capacity_bound_zero_default_tiny_asymmetric_32k", capacity_and_bound_parity, true},
        {"ring_wrap_retry_pending_halfclose", ring_wrap_retry_and_half_close, true},
        {"all_six_oom_sites_and_reuse", six_failure_sites_and_reuse, true},
        {"invalid_output_alias_descriptor_overflow", invalid_outputs_descriptors_and_bounds, true},
        {"bad_backing_overlap_no_live_reset", backing_rejection_and_overlap, true},
        {"two_domains_128_recycles_each", independent_domains_and_recycling, true},
        {"extra_refs_either_final_release_order", final_reference_in_both_orders, true},
        {"ssl_same_bio_both_roles_whole_ssl_control", ssl_transfer_allocating_control, false},
    };
    for (const auto &proof : cases) failed += run_case(proof);
    printf("native_owned_bio_proof rows=10 failed=%d selftest63=pass ssl_lifecycle_zero_claim=0\n", failed);
    return failed != 0;
}
