#include <openssl/mem.h>

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct SizedFreeState {
    void *expected;
    size_t extent;
    size_t called;
    bool failed;
};

struct OwnedStorage {
    alignas(max_align_t) uint8_t bytes[256];
    size_t extent;
    size_t released;
    bool failed;
};

static void *owned_allocate(void *context, size_t size, size_t alignment)
{
    auto *storage = static_cast<OwnedStorage *>(context);
    if (size > sizeof(storage->bytes) || alignment != alignof(max_align_t)) return nullptr;
    storage->extent = size;
    memset(storage->bytes, 0xa5, size);
    return storage->bytes;
}

static void owned_release(void *context, void *pointer, size_t size, size_t alignment)
{
    auto *storage = static_cast<OwnedStorage *>(context);
    if (pointer != storage->bytes || size != storage->extent ||
        alignment != alignof(max_align_t)) storage->failed = true;
    const auto *bytes = static_cast<const uint8_t *>(pointer);
    for (size_t index = 0; index < size; index++) {
        if (bytes[index] != 0) storage->failed = true;
    }
    storage->released++;
}

// Test-only sized-free ABI has no context argument and requires this process singleton.
static SizedFreeState *sized_free_state;

extern "C" void sdallocx(void *pointer, size_t size, int flags)
{
    if (pointer != sized_free_state->expected || size != sized_free_state->extent || flags != 0) {
        sized_free_state->failed = true;
    }
    const auto *bytes = static_cast<const uint8_t *>(pointer);
    for (size_t offset = 0; offset < size; offset++) {
        if (bytes[offset] != 0) sized_free_state->failed = true;
    }
    sized_free_state->called++;
    free(pointer);
}

int main(void)
{
    SizedFreeState state = {};
    sized_free_state = &state;
    auto *pointer = static_cast<uint8_t *>(OPENSSL_malloc(23));
    if (pointer == nullptr) return 1;
    size_t recorded = 0;
    memcpy(&recorded, pointer - 8, sizeof(recorded));
    if (recorded != 23) return 2;
    memset(pointer, 0x78, 23);
    state.expected = pointer - 8;
    state.extent = 31;
    OPENSSL_free(pointer);
    OwnedStorage owned = {};
    const OPENSSL_ALLOCATION_DOMAIN domain = {&owned, owned_allocate, owned_release};
    void *owned_pointer = OPENSSL_malloc_with_domain(65, &domain);
    if (owned_pointer == nullptr) return 3;
    memset(owned_pointer, 0x89, 65);
    OPENSSL_free(owned_pointer);
    printf("ordinary_sdallocx_8byte_prefix_exact_extent_full_cleanse called=%zu failed=%d\n",
           state.called, state.failed);
    printf("owned_release_bypasses_sdallocx released=%zu failed=%d\n", owned.released, owned.failed);
    sized_free_state = nullptr;
    return state.called != 1 || state.failed || owned.released != 1 || owned.failed;
}
