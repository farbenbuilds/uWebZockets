#include <openssl/err.h>
#include <openssl/mem.h>
#include <openssl/rand.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>

#include <limits.h>
#include <pthread.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "ssl/internal.h"
#include "crypto/x509/internal.h"
#include "allocation_scope.h"

extern "C" int uwz_alloc_self_test(void);
#define REQUIRE(condition) do { if (!(condition)) return __LINE__; } while (0)

struct raw_block {
    size_t bytes;
    size_t alignment;
    size_t generations;
    bool live;
};

struct construction_storage {
    alignas(max_align_t) uint8_t backing[131072];
    raw_block blocks[64];
    SSL_CLIENT_CONSTRUCTION_REQUIREMENTS requirements;
    OPENSSL_ALLOCATION_DOMAIN domain;
    size_t slots;
    size_t live;
    size_t peak;
    size_t attempts;
    size_t allocations;
    size_t releases;
    size_t fail_attempt;
    size_t failure_hits;
    size_t largest_raw;
    size_t reused;
    bool failed;
};

static void *allocate_slot(void *context, size_t bytes, size_t alignment)
{
    auto *storage = static_cast<construction_storage *>(context);
    storage->attempts++;
    if (storage->attempts == storage->fail_attempt) {
        storage->failure_hits++;
        return nullptr;
    }
    if (bytes == 0 || bytes > storage->requirements.block_bytes ||
        alignment != storage->requirements.alignment) {
        storage->failed = true;
        return nullptr;
    }
    size_t slot = 0;
    while (slot < storage->slots && storage->blocks[slot].live) slot++;
    if (slot == storage->slots) return nullptr;
    auto *pointer = storage->backing + slot * storage->requirements.block_bytes;
    if (reinterpret_cast<uintptr_t>(pointer) % alignment != 0) {
        storage->failed = true;
        return nullptr;
    }
    raw_block *block = &storage->blocks[slot];
    if (block->generations != 0) storage->reused++;
    block->bytes = bytes;
    block->alignment = alignment;
    block->generations++;
    block->live = true;
    storage->allocations++;
    if (bytes > storage->largest_raw) storage->largest_raw = bytes;
    storage->live++;
    if (storage->live > storage->peak) storage->peak = storage->live;
    memset(pointer, 0xa5, bytes);
    return pointer;
}

static void release_slot(void *context, void *pointer, size_t bytes, size_t alignment)
{
    auto *storage = static_cast<construction_storage *>(context);
    const uintptr_t start = reinterpret_cast<uintptr_t>(storage->backing);
    const uintptr_t address = reinterpret_cast<uintptr_t>(pointer);
    if (address < start || address - start >= storage->requirements.bytes ||
        (address - start) % storage->requirements.block_bytes != 0) {
        storage->failed = true;
        return;
    }
    const size_t slot = (address - start) / storage->requirements.block_bytes;
    raw_block *block = &storage->blocks[slot];
    if (slot >= storage->slots || !block->live || bytes != block->bytes ||
        alignment != block->alignment || storage->live == 0) {
        storage->failed = true;
        return;
    }
    const auto *raw = static_cast<const uint8_t *>(pointer);
    for (size_t index = 0; index < bytes; index++) {
        if (raw[index] != 0) storage->failed = true;
    }
    for (size_t index = bytes; index < storage->requirements.block_bytes; index++) {
        if (raw[index] != 0xc3) storage->failed = true;
    }
    memset(pointer, 0xc3, storage->requirements.block_bytes);
    block->live = false;
    storage->live--;
    storage->releases++;
}

static bool initialize_storage(construction_storage *storage, SSL_CTX *ctx, size_t name_bytes = 255)
{
    if (!SSL_client_construction_storage_requirements(ctx, name_bytes, &storage->requirements)) return false;
    const auto &requirements = storage->requirements;
    if (requirements.bytes > sizeof(storage->backing) || requirements.alignment == 0 ||
        requirements.alignment > alignof(max_align_t) ||
        (requirements.alignment & (requirements.alignment - 1)) != 0 ||
        requirements.block_bytes == 0 || requirements.block_bytes % requirements.alignment != 0 ||
        requirements.block_count == 0 || requirements.block_count > 64 ||
        requirements.block_bytes > SIZE_MAX / requirements.block_count ||
        requirements.bytes != requirements.block_bytes * requirements.block_count) return false;
    storage->slots = requirements.block_count;
    storage->domain = {storage, allocate_slot, release_slot};
    memset(storage->backing, 0xc3, sizeof(storage->backing));
    return true;
}

static bool empty_storage(const construction_storage &storage)
{
    return !storage.failed && storage.live == 0 && storage.allocations == storage.releases;
}

static int inspect_owners(SSL *ssl, construction_storage *storage)
{
    auto *impl = bssl::FromOpaque(ssl);
    const OPENSSL_ALLOCATION_DOMAIN *owner = &storage->domain;
    // Every argument here is an exact allocation root in this image.
    REQUIRE(bssl::GetAllocationDomain(impl) == owner);
    REQUIRE(bssl::GetAllocationDomain(impl->config.get()) == owner);
    REQUIRE(bssl::GetAllocationDomain(impl->config->cert.get()) == owner);
    REQUIRE(bssl::GetAllocationDomain(impl->config->cert->legacy_credential.get()) == owner);
    REQUIRE(bssl::GetAllocationDomain(impl->s3) == owner);
    REQUIRE(bssl::GetAllocationDomain(impl->s3->aead_read_ctx.get()) == owner);
    REQUIRE(bssl::GetAllocationDomain(impl->s3->aead_write_ctx.get()) == owner);
    REQUIRE(bssl::GetAllocationDomain(impl->s3->hs.get()) == owner);
    REQUIRE(bssl::GetAllocationDomain(SSL_get0_param(ssl)) == owner);
    REQUIRE(bssl::GetAllocationDomain(bssl::FromOpaque(SSL_get_SSL_CTX(ssl))) == nullptr);
    return 0;
}

static int query_cold(SSL_CTX *ctx)
{
    const auto *impl = bssl::FromOpaque(ctx);
    uint8_t snapshot[sizeof(*impl)];
    uint8_t cert_snapshot[sizeof(*impl->cert)];
    uint8_t param_snapshot[sizeof(*impl->param)];
    memcpy(snapshot, impl, sizeof(snapshot));
    memcpy(cert_snapshot, impl->cert.get(), sizeof(cert_snapshot));
    memcpy(param_snapshot, impl->param, sizeof(param_snapshot));
    SSL_CLIENT_CONSTRUCTION_REQUIREMENTS requirements = {};
    REQUIRE(SSL_client_construction_storage_requirements(ctx, 255, &requirements));
    REQUIRE(requirements.bytes != 0 && requirements.alignment == alignof(max_align_t));
    REQUIRE(memcmp(snapshot, impl, sizeof(snapshot)) == 0);
    REQUIRE(memcmp(cert_snapshot, impl->cert.get(), sizeof(cert_snapshot)) == 0);
    REQUIRE(memcmp(param_snapshot, impl->param, sizeof(param_snapshot)) == 0);
    return 0;
}

static int query_guards(SSL_CTX *ctx)
{
    const uint32_t before = ERR_peek_error();
    REQUIRE(before != 0);
    REQUIRE(!SSL_client_construction_storage_requirements(ctx, 255, nullptr));
    const size_t invalid[] = {0, 256, SIZE_MAX, SIZE_MAX / 2};
    for (size_t bytes : invalid) {
        SSL_CLIENT_CONSTRUCTION_REQUIREMENTS requirements = {19, 73, 29, 31};
        REQUIRE(!SSL_client_construction_storage_requirements(ctx, bytes, &requirements));
        REQUIRE(requirements.bytes == 0 && requirements.alignment == 0 &&
                requirements.block_bytes == 0 && requirements.block_count == 0);
    }
    SSL_CLIENT_CONSTRUCTION_REQUIREMENTS requirements = {19, 73, 29, 31};
    REQUIRE(!SSL_client_construction_storage_requirements(nullptr, 255, &requirements));
    REQUIRE(requirements.bytes == 0 && requirements.alignment == 0 &&
            requirements.block_bytes == 0 && requirements.block_count == 0);
    SSL_CLIENT_CONSTRUCTION_REQUIREMENTS tiny = {}, maximum = {};
    REQUIRE(SSL_client_construction_storage_requirements(ctx, 1, &tiny));
    REQUIRE(SSL_client_construction_storage_requirements(ctx, 255, &maximum));
    REQUIRE(tiny.bytes <= maximum.bytes && tiny.block_count == maximum.block_count);
    REQUIRE(ERR_peek_error() == before);
    return 0;
}

static int expect_rejected(SSL_CTX *ctx)
{
    construction_storage storage = {};
    storage.domain = {&storage, allocate_slot, release_slot};
    SSL_CLIENT_CONSTRUCTION_REQUIREMENTS requirements = {19, 73, 29, 31};
    const uint32_t before = ERR_peek_error();
    REQUIRE(!SSL_client_construction_storage_requirements(ctx, 255, &requirements));
    REQUIRE(requirements.bytes == 0 && requirements.alignment == 0 &&
            requirements.block_bytes == 0 && requirements.block_count == 0);
    REQUIRE(ERR_peek_error() == before);
    REQUIRE(SSL_new_client_with_construction_domain(ctx, &storage.domain) == nullptr);
    REQUIRE(storage.attempts == 0 && empty_storage(storage));
    return 0;
}

#define REJECT_VALUE(field, value) do { \
    const auto saved_value = (field); \
    (field) = (value); \
    const int rejected_line = expect_rejected(ctx); \
    (field) = saved_value; \
    REQUIRE(rejected_line == 0); \
} while (0)

#define REJECT_ROOT(field, type) do { \
    auto *saved_root = (field).release(); \
    (field).reset(reinterpret_cast<type *>(uintptr_t{1})); \
    const int rejected_line = expect_rejected(ctx); \
    (void)(field).release(); \
    (field).reset(saved_root); \
    REQUIRE(rejected_line == 0); \
} while (0)

static int profile_reject_guards(SSL_CTX *ctx)
{
    auto *impl = bssl::FromOpaque(ctx);
    REQUIRE(expect_rejected(nullptr) == 0);
    auto cert = std::move(impl->cert);
    const int null_cert = expect_rejected(ctx);
    impl->cert = std::move(cert);
    REQUIRE(null_cert == 0);
    auto credential = std::move(impl->cert->legacy_credential);
    const int null_credential = expect_rejected(ctx);
    impl->cert->legacy_credential = std::move(credential);
    REQUIRE(null_credential == 0);
    auto *param = impl->param;
    impl->param = nullptr;
    const int null_param = expect_rejected(ctx);
    impl->param = param;
    REQUIRE(null_param == 0);
    REJECT_VALUE(impl->method, DTLS_client_method()->method);
    REJECT_VALUE(impl->quic_method, reinterpret_cast<const SSL_QUIC_METHOD *>(uintptr_t{1}));
    REJECT_VALUE(impl->x509_method, &bssl::ssl_noop_x509_method);
    REJECT_VALUE(impl->cert->x509_method, &bssl::ssl_noop_x509_method);
    auto *legacy = impl->cert->legacy_credential.get();
    REJECT_VALUE(legacy->type, bssl::SSLCredentialType::kRawPublicKey);
    REJECT_VALUE(legacy->dc_algorithm, 1);
    REJECT_VALUE(legacy->key_method, reinterpret_cast<const SSL_PRIVATE_KEY_METHOD *>(uintptr_t{1}));
    REJECT_ROOT(legacy->pubkey, EVP_PKEY);
    REJECT_ROOT(legacy->privkey, EVP_PKEY);
    REJECT_ROOT(legacy->dc, CRYPTO_BUFFER);
    REJECT_ROOT(legacy->chain, STACK_OF(CRYPTO_BUFFER));
    REJECT_ROOT(legacy->signed_cert_timestamp_list, CRYPTO_BUFFER);
    REJECT_ROOT(legacy->ocsp_response, CRYPTO_BUFFER);
    legacy->sid_ctx.PushBack(1);
    const int sid_rejected = expect_rejected(ctx);
    legacy->sid_ctx.clear();
    REQUIRE(sid_rejected == 0);
    REJECT_VALUE(impl->param->policies, reinterpret_cast<STACK_OF(ASN1_OBJECT) *>(uintptr_t{1}));
    REJECT_VALUE(impl->param->hosts, reinterpret_cast<STACK_OF(OPENSSL_STRING) *>(uintptr_t{1}));
    REJECT_VALUE(impl->param->email, reinterpret_cast<char *>(uintptr_t{1}));
    REJECT_VALUE(impl->param->ip, reinterpret_cast<unsigned char *>(uintptr_t{1}));
    REJECT_VALUE(impl->param->poison, 1);
    REJECT_ROOT(impl->psk_identity_hint, char);
    impl->requested_trust_anchors.emplace();
    const int present_empty = expect_rejected(ctx);
    impl->requested_trust_anchors.reset();
    REQUIRE(present_empty == 0);
    uint16_t *groups = nullptr;
    uint32_t *flags = nullptr;
    size_t group_count = 0, flag_count = 0;
    const size_t overflowing_counts[] = {SIZE_MAX, SIZE_MAX / 2, SIZE_MAX / 4 + 1};
    for (size_t count : overflowing_counts) {
        impl->supported_group_list.Release(&groups, &group_count);
        impl->supported_group_list_flags.Release(&flags, &flag_count);
        impl->supported_group_list.Reset(groups, count);
        impl->supported_group_list_flags.Reset(flags, count);
        const int overflow_rejected = expect_rejected(ctx);
        size_t discarded_count = 0;
        impl->supported_group_list.Release(&groups, &discarded_count);
        impl->supported_group_list_flags.Release(&flags, &discarded_count);
        impl->supported_group_list.Reset(groups, group_count);
        impl->supported_group_list_flags.Reset(flags, flag_count);
        REQUIRE(overflow_rejected == 0);
    }
    REQUIRE(query_cold(ctx) == 0);
    return 0;
}

static int descriptor_guards(SSL_CTX *ctx)
{
    construction_storage storage = {};
    REQUIRE(initialize_storage(&storage, ctx));
    const OPENSSL_ALLOCATION_DOMAIN missing_allocate = {&storage, nullptr, release_slot};
    const OPENSSL_ALLOCATION_DOMAIN missing_release = {&storage, allocate_slot, nullptr};
    REQUIRE(SSL_new_client_with_construction_domain(ctx, nullptr) == nullptr);
    REQUIRE(SSL_new_client_with_construction_domain(ctx, &missing_allocate) == nullptr);
    REQUIRE(SSL_new_client_with_construction_domain(ctx, &missing_release) == nullptr);
    REQUIRE(SSL_new_client_with_construction_domain(nullptr, &storage.domain) == nullptr);
    REQUIRE(storage.attempts == 0 && empty_storage(storage));
    return 0;
}

static int setup_identity(SSL *ssl, size_t identity)
{
    REQUIRE(SSL_set_tlsext_host_name(ssl, "localhost") == 1);
    auto *param = SSL_get0_param(ssl);
    if (identity == 0) {
        REQUIRE(SSL_set1_host(ssl, "localhost") == 1);
        REQUIRE(param->hosts != nullptr && sk_OPENSSL_STRING_num(param->hosts) == 1);
        REQUIRE(strcmp(sk_OPENSSL_STRING_value(param->hosts, 0), "localhost") == 0);
        return 0;
    }
    const char *address = identity == 1 ? "127.0.0.1" : "::1";
    REQUIRE(X509_VERIFY_PARAM_set1_ip_asc(param, address) == 1);
    REQUIRE(param->ip != nullptr && param->iplen == (identity == 1 ? 4 : 16));
    REQUIRE(param->ip[param->iplen - 1] == 1);
    return 0;
}

static int constructor_identity_and_clear(SSL_CTX *ctx)
{
    for (size_t identity = 0; identity < 3; identity++) {
        construction_storage storage = {};
        REQUIRE(initialize_storage(&storage, ctx));
        SSL *ssl = SSL_new_client_with_construction_domain(ctx, &storage.domain);
        REQUIRE(ssl != nullptr && !SSL_is_server(ssl));
        REQUIRE(SSL_get_verify_mode(ssl) == SSL_CTX_get_verify_mode(ctx));
        REQUIRE(inspect_owners(ssl, &storage) == 0);
        REQUIRE(setup_identity(ssl, identity) == 0);
        REQUIRE(storage.live <= storage.requirements.block_count);
        REQUIRE((storage.largest_raw + storage.requirements.alignment - 1) /
                storage.requirements.alignment * storage.requirements.alignment == storage.requirements.block_bytes);
        auto *impl = bssl::FromOpaque(ssl);
        REQUIRE(bssl::GetAllocationDomain(impl->hostname.get()) == &storage.domain);
        auto *param = SSL_get0_param(ssl);
        if (identity == 0) {
            REQUIRE(bssl::GetAllocationDomain(param->hosts) == &storage.domain);
            REQUIRE(bssl::GetAllocationDomain(sk_OPENSSL_STRING_value(param->hosts, 0)) == &storage.domain);
        } else {
            REQUIRE(bssl::GetAllocationDomain(param->ip) == &storage.domain);
        }
        const size_t before_live = storage.live;
        for (size_t cycle = 0; cycle < 128; cycle++) {
            REQUIRE(SSL_clear(ssl) == 1);
            SSL_set_connect_state(ssl);
            REQUIRE(storage.live == before_live && inspect_owners(ssl, &storage) == 0);
        }
        SSL_free(ssl);
        REQUIRE(empty_storage(storage) && storage.reused >= 128 * 5);
    }
    return 0;
}

static int maximum_name_and_tiny_bound(SSL_CTX *ctx)
{
    const size_t lengths[] = {1, 255};
    for (size_t length : lengths) {
        construction_storage storage = {};
        REQUIRE(initialize_storage(&storage, ctx, length));
        char name[256];
        memset(name, 'a', length);
        name[length] = 0;
        SSL *ssl = SSL_new_client_with_construction_domain(ctx, &storage.domain);
        REQUIRE(ssl != nullptr && SSL_set_tlsext_host_name(ssl, name) == 1 && SSL_set1_host(ssl, name) == 1);
        REQUIRE(strcmp(SSL_get_servername(ssl, TLSEXT_NAMETYPE_host_name), name) == 0);
        REQUIRE(strlen(sk_OPENSSL_STRING_value(SSL_get0_param(ssl)->hosts, 0)) == length);
        SSL_free(ssl);
        REQUIRE(empty_storage(storage));
    }
    return 0;
}

static int constructor_fault_sweep(SSL_CTX *ctx)
{
    construction_storage baseline = {};
    REQUIRE(initialize_storage(&baseline, ctx));
    SSL *ssl = SSL_new_client_with_construction_domain(ctx, &baseline.domain);
    REQUIRE(ssl != nullptr);
    const size_t operations = baseline.attempts;
    SSL_free(ssl);
    REQUIRE(empty_storage(baseline) && operations > 0);
    for (size_t fault = 1; fault <= operations; fault++) {
        construction_storage storage = {};
        REQUIRE(initialize_storage(&storage, ctx));
        storage.fail_attempt = fault;
        SSL *failed_ssl = SSL_new_client_with_construction_domain(ctx, &storage.domain);
        REQUIRE(failed_ssl == nullptr && storage.failure_hits == 1 &&
                storage.attempts >= fault && storage.attempts <= operations && empty_storage(storage));
        storage.fail_attempt = 0;
        ssl = SSL_new_client_with_construction_domain(ctx, &storage.domain);
        REQUIRE(ssl != nullptr && setup_identity(ssl, 0) == 0);
        SSL_free(ssl);
        REQUIRE(empty_storage(storage));
    }
    return 0;
}

static int setup_fault_sweep(SSL_CTX *ctx)
{
    for (size_t identity = 0; identity < 3; identity++) {
        construction_storage baseline = {};
        REQUIRE(initialize_storage(&baseline, ctx));
        SSL *ssl = SSL_new_client_with_construction_domain(ctx, &baseline.domain);
        REQUIRE(ssl != nullptr);
        const size_t constructor_attempts = baseline.attempts;
        REQUIRE(setup_identity(ssl, identity) == 0);
        const size_t operations = baseline.attempts - constructor_attempts;
        SSL_free(ssl);
        REQUIRE(empty_storage(baseline) && operations != 0);
        for (size_t fault = 1; fault <= operations; fault++) {
            construction_storage storage = {};
            REQUIRE(initialize_storage(&storage, ctx));
            ssl = SSL_new_client_with_construction_domain(ctx, &storage.domain);
            REQUIRE(ssl != nullptr);
            storage.fail_attempt = storage.attempts + fault;
            REQUIRE(setup_identity(ssl, identity) != 0);
            REQUIRE(storage.failure_hits == 1 && storage.attempts >= storage.fail_attempt);
            SSL_free(ssl);
            REQUIRE(empty_storage(storage));
        }
    }
    return 0;
}

static int clear_fault_sweep(SSL_CTX *ctx)
{
    construction_storage baseline = {};
    REQUIRE(initialize_storage(&baseline, ctx));
    SSL *ssl = SSL_new_client_with_construction_domain(ctx, &baseline.domain);
    REQUIRE(ssl != nullptr && setup_identity(ssl, 0) == 0);
    const size_t before = baseline.attempts;
    REQUIRE(SSL_clear(ssl) == 1);
    const size_t operations = baseline.attempts - before;
    SSL_free(ssl);
    REQUIRE(empty_storage(baseline) && operations != 0);
    for (size_t fault = 1; fault <= operations; fault++) {
        construction_storage storage = {};
        REQUIRE(initialize_storage(&storage, ctx));
        ssl = SSL_new_client_with_construction_domain(ctx, &storage.domain);
        REQUIRE(ssl != nullptr && setup_identity(ssl, 0) == 0);
        storage.fail_attempt = storage.attempts + fault;
        REQUIRE(SSL_clear(ssl) == 0 && storage.failure_hits == 1 &&
                storage.attempts >= storage.fail_attempt);
        SSL_free(ssl);
        REQUIRE(empty_storage(storage));
    }
    return 0;
}

static int bounded_exhaustion(SSL_CTX *ctx)
{
    SSL_CLIENT_CONSTRUCTION_REQUIREMENTS requirements = {};
    REQUIRE(SSL_client_construction_storage_requirements(ctx, 255, &requirements));
    for (size_t slots = 0; slots <= requirements.block_count; slots++) {
        construction_storage storage = {};
        REQUIRE(initialize_storage(&storage, ctx));
        storage.slots = slots;
        SSL *partial = SSL_new_client_with_construction_domain(ctx, &storage.domain);
        if (partial != nullptr) {
            const int setup_line = setup_identity(partial, 0);
            SSL_free(partial);
            REQUIRE(slots != requirements.block_count || setup_line == 0);
        } else {
            REQUIRE(slots < requirements.block_count);
        }
        REQUIRE(empty_storage(storage));
    }
    construction_storage storage = {};
    REQUIRE(initialize_storage(&storage, ctx));
    SSL *ssl = SSL_new_client_with_construction_domain(ctx, &storage.domain);
    REQUIRE(ssl != nullptr && setup_identity(ssl, 0) == 0);
    const size_t live = storage.live;
    REQUIRE(SSL_new_client_with_construction_domain(ctx, &storage.domain) == nullptr);
    REQUIRE(storage.live == live && !storage.failed && inspect_owners(ssl, &storage) == 0);
    REQUIRE(strcmp(SSL_get_servername(ssl, TLSEXT_NAMETYPE_host_name), "localhost") == 0);
    SSL_free(ssl);
    REQUIRE(empty_storage(storage));
    return 0;
}

static int interleaved_recycling(SSL_CTX *ctx)
{
    construction_storage left = {}, right = {};
    REQUIRE(initialize_storage(&left, ctx) && initialize_storage(&right, ctx));
    for (size_t cycle = 0; cycle < 128; cycle++) {
        SSL *a = SSL_new_client_with_construction_domain(ctx, &left.domain);
        SSL *b = SSL_new_client_with_construction_domain(ctx, &right.domain);
        REQUIRE(a != nullptr && b != nullptr);
        REQUIRE(setup_identity(a, cycle % 3) == 0 && setup_identity(b, (cycle + 1) % 3) == 0);
        REQUIRE(SSL_clear(a) == 1 && SSL_clear(b) == 1);
        if (cycle % 2 == 0) SSL_free(a);
        else SSL_free(b);
        REQUIRE((cycle % 2 == 0 ? left.live : right.live) == 0);
        REQUIRE((cycle % 2 == 0 ? right.live : left.live) > 0);
        if (cycle % 2 == 0) SSL_free(b);
        else SSL_free(a);
        REQUIRE(empty_storage(left) && empty_storage(right));
    }
    REQUIRE(left.reused != 0 && right.reused != 0);
    return 0;
}

static int scalar_and_shared_state(SSL_CTX *ctx)
{
    construction_storage storage = {};
    REQUIRE(initialize_storage(&storage, ctx));
    SSL *ssl = SSL_new_client_with_construction_domain(ctx, &storage.domain);
    REQUIRE(ssl != nullptr);
    const auto *source = SSL_CTX_get0_param(ctx);
    const auto *destination = SSL_get0_param(ssl);
    REQUIRE(source != destination && source->depth == destination->depth && source->flags == destination->flags);
    REQUIRE(source->purpose == destination->purpose && source->trust == destination->trust);
    REQUIRE(source->check_time == destination->check_time && source->hostflags == destination->hostflags);
    REQUIRE(bssl::FromOpaque(ctx)->cert_store != nullptr);
    REQUIRE(bssl::FromOpaque(ssl)->config->cert->verify_store == bssl::FromOpaque(ctx)->cert->verify_store);
    REQUIRE(setup_identity(ssl, 0) == 0);
    REQUIRE(source->hosts == nullptr && source->ip == nullptr && source->email == nullptr);
    REQUIRE(bssl::GetAllocationDomain(source) == nullptr);
    SSL_free(ssl);
    REQUIRE(empty_storage(storage));
    return 0;
}

static int copy_destination_lifetimes(SSL_CTX *ctx)
{
    for (size_t identity = 0; identity < 3; identity++) {
        construction_storage storage = {};
        REQUIRE(initialize_storage(&storage, ctx));
        SSL *ssl = SSL_new_client_with_construction_domain(ctx, &storage.domain);
        REQUIRE(ssl != nullptr && setup_identity(ssl, identity) == 0);
        X509_VERIFY_PARAM *ordinary = X509_VERIFY_PARAM_new();
        REQUIRE(ordinary != nullptr && X509_VERIFY_PARAM_set1(ordinary, SSL_get0_param(ssl)) == 1);
        SSL_free(ssl);
        REQUIRE(empty_storage(storage) && bssl::GetAllocationDomain(ordinary) == nullptr);
        if (identity == 0) {
            REQUIRE(strcmp(sk_OPENSSL_STRING_value(ordinary->hosts, 0), "localhost") == 0);
            REQUIRE(bssl::GetAllocationDomain(ordinary->hosts) == nullptr);
            REQUIRE(bssl::GetAllocationDomain(sk_OPENSSL_STRING_value(ordinary->hosts, 0)) == nullptr);
        } else {
            REQUIRE(ordinary->iplen == (identity == 1 ? 4 : 16) && ordinary->ip[ordinary->iplen - 1] == 1);
            REQUIRE(bssl::GetAllocationDomain(ordinary->ip) == nullptr);
        }
        ssl = SSL_new_client_with_construction_domain(ctx, &storage.domain);
        REQUIRE(ssl != nullptr && X509_VERIFY_PARAM_set1(SSL_get0_param(ssl), ordinary) == 1);
        X509_VERIFY_PARAM_free(ordinary);
        const auto *destination = SSL_get0_param(ssl);
        if (identity == 0) {
            REQUIRE(strcmp(sk_OPENSSL_STRING_value(destination->hosts, 0), "localhost") == 0);
            REQUIRE(bssl::GetAllocationDomain(destination->hosts) == &storage.domain);
            REQUIRE(bssl::GetAllocationDomain(sk_OPENSSL_STRING_value(destination->hosts, 0)) == &storage.domain);
        } else {
            REQUIRE(destination->iplen == (identity == 1 ? 4 : 16) && destination->ip[destination->iplen - 1] == 1);
            REQUIRE(bssl::GetAllocationDomain(destination->ip) == &storage.domain);
        }
        SSL_free(ssl);
        REQUIRE(empty_storage(storage));
    }
    return 0;
}

static int shared_context_last_reference(SSL_CTX *ctx)
{
    SSL_CTX *shared = SSL_CTX_new(TLS_client_method());
    REQUIRE(shared != nullptr);
    X509_STORE *store = SSL_CTX_get_cert_store(ctx);
    REQUIRE(X509_STORE_up_ref(store) == 1);
    SSL_CTX_set_cert_store(shared, store);
    construction_storage left = {}, right = {};
    REQUIRE(initialize_storage(&left, shared) && initialize_storage(&right, shared));
    SSL *a = SSL_new_client_with_construction_domain(shared, &left.domain);
    SSL *b = SSL_new_client_with_construction_domain(shared, &right.domain);
    REQUIRE(a != nullptr && b != nullptr);
    SSL_CTX_free(shared);
    REQUIRE(setup_identity(a, 0) == 0 && setup_identity(b, 2) == 0);
    SSL_free(a);
    REQUIRE(empty_storage(left) && right.live > 0);
    REQUIRE(SSL_clear(b) == 1 && inspect_owners(b, &right) == 0);
    SSL_free(b);
    REQUIRE(empty_storage(right) && SSL_CTX_get_cert_store(ctx) == store);
    return 0;
}

static int admission_callback(SSL *, void *argument)
{
    *static_cast<size_t *>(argument) += 1;
    return 0;
}

static int nonclone_callback_admitted(SSL_CTX *ctx)
{
    size_t calls = 0;
    SSL_CTX_set_cert_cb(ctx, admission_callback, &calls);
    construction_storage storage = {};
    const bool initialized = initialize_storage(&storage, ctx);
    SSL *ssl = initialized ? SSL_new_client_with_construction_domain(ctx, &storage.domain) : nullptr;
    SSL_CTX_set_cert_cb(ctx, nullptr, nullptr);
    REQUIRE(initialized && ssl != nullptr && calls == 0);
    REQUIRE(bssl::FromOpaque(ssl)->config->cert->cert_cb_arg == &calls);
    REQUIRE(setup_identity(ssl, 0) == 0);
    SSL_free(ssl);
    REQUIRE(calls == 0 && empty_storage(storage));
    return 0;
}

using case_function = int (*)(SSL_CTX *ctx);
struct proof_case {
    const char *name;
    case_function run;
    bool strict_zero;
};

static int run_case(const proof_case &test, SSL_CTX *ctx)
{
    uwz_alloc_begin();
    const int line = test.run(ctx);
    uwz_alloc_end();
    const bool zero = uwz_all_c_zero();
    const bool failed = line != 0 || (test.strict_zero && !zero);
    printf("ssl_construction_case=%s failed=%d line=%d malloc=%llu calloc=%llu realloc=%llu free=%llu bytes=%llu strict_zero=%d\n",
           test.name, failed, line,
           static_cast<unsigned long long>(uwz_alloc_malloc_calls()),
           static_cast<unsigned long long>(uwz_alloc_calloc_calls()),
           static_cast<unsigned long long>(uwz_alloc_realloc_calls()),
           static_cast<unsigned long long>(uwz_alloc_free_calls()),
           static_cast<unsigned long long>(uwz_alloc_requested_bytes()), test.strict_zero);
    return failed;
}

struct thread_input {
    SSL_CTX *ctx;
    int failed;
};

static void *cold_thread(void *argument)
{
    auto *input = static_cast<thread_input *>(argument);
    input->failed = run_case({"fresh_thread_query_before_ERR_RNG", query_cold, true}, input->ctx);
    uint8_t byte = 0;
    uwz_alloc_begin();
    const int rng_ok = RAND_bytes(&byte, 1);
    OPENSSL_PUT_ERROR(CRYPTO, ERR_R_MALLOC_FAILURE);
    const bool err_ok = ERR_peek_error() != 0;
    uwz_alloc_end();
    printf("ssl_construction_cold_thread_rng_ERR_control rng_ok=%d err_ok=%d malloc=%llu calloc=%llu realloc=%llu free=%llu bytes=%llu\n",
           rng_ok, err_ok, static_cast<unsigned long long>(uwz_alloc_malloc_calls()),
           static_cast<unsigned long long>(uwz_alloc_calloc_calls()),
           static_cast<unsigned long long>(uwz_alloc_realloc_calls()),
           static_cast<unsigned long long>(uwz_alloc_free_calls()),
           static_cast<unsigned long long>(uwz_alloc_requested_bytes()));
    input->failed += rng_ok != 1 || !err_ok;
    return nullptr;
}

static SSL_CTX *make_context(bool verify, const char *ca_bundle)
{
    SSL_CTX *ctx = SSL_CTX_new(TLS_client_method());
    if (ctx == nullptr) return nullptr;
    if (!SSL_CTX_set_min_proto_version(ctx, TLS1_3_VERSION) ||
        !SSL_CTX_set_max_proto_version(ctx, TLS1_3_VERSION) ||
        (ca_bundle != nullptr && !SSL_CTX_load_verify_locations(ctx, ca_bundle, nullptr))) {
        SSL_CTX_free(ctx);
        return nullptr;
    }
    SSL_CTX_set_verify(ctx, verify ? SSL_VERIFY_PEER : SSL_VERIFY_NONE, nullptr);
    auto *param = SSL_CTX_get0_param(ctx);
    X509_VERIFY_PARAM_set_depth(param, 19);
    X509_VERIFY_PARAM_set_time_posix(param, 1700000000);
    X509_VERIFY_PARAM_set_hostflags(param, X509_CHECK_FLAG_NO_PARTIAL_WILDCARDS);
    if (!X509_VERIFY_PARAM_set_purpose(param, X509_PURPOSE_SSL_SERVER) ||
        !X509_VERIFY_PARAM_set_trust(param, X509_TRUST_SSL_SERVER) ||
        !X509_VERIFY_PARAM_set_flags(param, X509_V_FLAG_TRUSTED_FIRST)) {
        SSL_CTX_free(ctx);
        return nullptr;
    }
    return ctx;
}

int main(int argc, char **argv)
{
    SSL_CTX *ctx = make_context(true, argc > 1 ? argv[1] : nullptr);
    REQUIRE(ctx != nullptr);
    int failed = run_case({"process_query_before_ERR_RNG", query_cold, true}, ctx);
    thread_input input = {ctx, 0};
    pthread_t thread;
    REQUIRE(pthread_create(&thread, nullptr, cold_thread, &input) == 0);
    REQUIRE(pthread_join(thread, nullptr) == 0);
    failed += input.failed;
    REQUIRE(uwz_alloc_self_test());
    uint8_t byte = 0;
    REQUIRE(RAND_bytes(&byte, 1) == 1);
    OPENSSL_PUT_ERROR(CRYPTO, ERR_R_MALLOC_FAILURE);
    REQUIRE(ERR_peek_error() != 0);
    SSL_CTX *no_verify = make_context(false, nullptr);
    REQUIRE(no_verify != nullptr);
    SSL_CLIENT_CONSTRUCTION_REQUIREMENTS layout = {};
    REQUIRE(SSL_client_construction_storage_requirements(ctx, 255, &layout));
    printf("ssl_construction_native_requirements name_bytes=255 bytes=%zu alignment=%zu block_bytes=%zu block_count=%zu\n",
           layout.bytes, layout.alignment, layout.block_bytes, layout.block_count);
    const char *dynamic_names[] = {
        "reject_cert_credentials", "reject_available_trust_anchors", "reject_legacy_sigalgs",
        "reject_ALPN", "reject_verify_sigalgs", "reject_DTLS",
    };
    for (size_t index = 0; index < sizeof(dynamic_names) / sizeof(dynamic_names[0]); index++) {
        SSL_CTX *unsupported = index == 5 ? SSL_CTX_new(DTLS_client_method()) : make_context(true, nullptr);
        REQUIRE(unsupported != nullptr);
        auto *impl = bssl::FromOpaque(unsupported);
        bool configured = true;
        switch (index) {
            case 0:
                configured = impl->cert->credentials.Push(bssl::MakeUnique<bssl::SSLCredential>(bssl::SSLCredentialType::kX509));
                break;
            case 1: configured = impl->cert->available_trust_anchors.Init(1); break;
            case 2: configured = impl->cert->legacy_credential->sigalgs.Init(1); break;
            case 3: configured = impl->alpn_client_proto_list.Init(1); break;
            case 4: configured = impl->verify_sigalgs.Init(1); break;
        }
        REQUIRE(configured);
        failed += run_case({dynamic_names[index], expect_rejected, true}, unsupported);
        SSL_CTX_free(unsupported);
    }
    const proof_case tests[] = {
        {"query_output_name_bounds_ERR_unchanged", query_guards, true},
        {"profile_scalar_pointer_overflow_reject", profile_reject_guards, true},
        {"null_malformed_domain_before_callback", descriptor_guards, true},
        {"DNS_IPv4_IPv6_128_clear_each", constructor_identity_and_clear, true},
        {"name_1_and_255_query_sized_storage", maximum_name_and_tiny_bound, true},
        {"every_constructor_failure_cleanup_reuse", constructor_fault_sweep, true},
        {"every_SNI_DNS_IP_failure_freeable", setup_fault_sweep, true},
        {"every_destructive_clear_failure_freeable", clear_fault_sweep, true},
        {"bounded_exhaustion_preserves_live_owner", bounded_exhaustion, true},
        {"two_domains_128_create_clear_free", interleaved_recycling, true},
        {"scalar_inherit_shared_store_unchanged", scalar_and_shared_state, true},
        {"nonclone_cert_callback_admitted_not_invoked", nonclone_callback_admitted, true},
        {"shared_context_caller_freed_before_two_SSL", shared_context_last_reference, false},
        {"param_copy_destination_owner_source_freed_first", copy_destination_lifetimes, false},
    };
    for (const auto &test : tests) failed += run_case(test, ctx);
    const char *capacity_names[] = {
        "admit_zero_group_arrays", "admit_custom_public_group_order", "admit_retained_cipher_stack_capacity",
    };
    for (size_t index = 0; index < sizeof(capacity_names) / sizeof(capacity_names[0]); index++) {
        SSL_CTX *sized_ctx = make_context(true, nullptr);
        REQUIRE(sized_ctx != nullptr);
        auto *impl = bssl::FromOpaque(sized_ctx);
        if (index == 0) {
            impl->supported_group_list.Reset();
            impl->supported_group_list_flags.Reset();
        }
        if (index == 1) REQUIRE(SSL_CTX_set1_groups_list(sized_ctx, "P-384:P-256:X25519") == 1);
        if (index == 2) {
            auto *ciphers = impl->tls13_cipher_list.ciphers();
            const auto *cipher = sk_SSL_CIPHER_value(ciphers, 0);
            const size_t count = sk_SSL_CIPHER_num(ciphers);
            for (size_t extra = 0; extra < 256; extra++) REQUIRE(sk_SSL_CIPHER_push(ciphers, cipher) != 0);
            for (size_t extra = 0; extra < 256; extra++) REQUIRE(sk_SSL_CIPHER_pop(ciphers) == cipher);
            REQUIRE(sk_SSL_CIPHER_num(ciphers) == count);
        }
        SSL_CLIENT_CONSTRUCTION_REQUIREMENTS sized_layout = {};
        REQUIRE(SSL_client_construction_storage_requirements(sized_ctx, 255, &sized_layout));
        if (index == 0) REQUIRE(sized_layout.block_count < layout.block_count);
        if (index == 2) REQUIRE(sized_layout.block_bytes > layout.block_bytes);
        printf("ssl_construction_capacity_shape=%s bytes=%zu alignment=%zu block_bytes=%zu block_count=%zu\n",
               capacity_names[index], sized_layout.bytes, sized_layout.alignment,
               sized_layout.block_bytes, sized_layout.block_count);
        failed += run_case({capacity_names[index], constructor_identity_and_clear, true}, sized_ctx);
        SSL_CTX_free(sized_ctx);
    }
    failed += run_case({"verify_false_DNS_IPv4_IPv6_clear", constructor_identity_and_clear, true}, no_verify);
    SSL_CTX_free(no_verify);
    SSL_CTX_free(ctx);
    printf("ssl_construction_unit_result failed=%d selftest63=pass RNG_ERR_warmed_outside_owned_intervals=1 handshake_payload_owned=0 total_TLS_zero_claim=0\n", failed);
    return failed != 0;
}
