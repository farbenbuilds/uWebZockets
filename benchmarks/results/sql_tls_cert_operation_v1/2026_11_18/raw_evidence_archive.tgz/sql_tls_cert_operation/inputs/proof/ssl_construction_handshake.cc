#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/mem.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define REQUIRE(condition) do { if (!(condition)) return __LINE__; } while (0)

struct raw_slot {
    size_t bytes;
    size_t alignment;
    bool live;
};

struct handshake_storage {
    alignas(max_align_t) uint8_t backing[131072];
    raw_slot slots[64];
    SSL_CLIENT_CONSTRUCTION_REQUIREMENTS requirements;
    OPENSSL_ALLOCATION_DOMAIN domain;
    size_t allocations;
    size_t releases;
    size_t live;
    bool bad;
};

static void *allocate_slot(void *argument, size_t bytes, size_t alignment)
{
    auto *storage = static_cast<handshake_storage *>(argument);
    if (bytes > storage->requirements.block_bytes || alignment != storage->requirements.alignment) {
        storage->bad = true;
        return nullptr;
    }
    for (size_t slot = 0; slot < storage->requirements.block_count; slot++) {
        if (storage->slots[slot].live) continue;
        void *pointer = storage->backing + slot * storage->requirements.block_bytes;
        if (reinterpret_cast<uintptr_t>(pointer) % alignment != 0) {
            storage->bad = true;
            return nullptr;
        }
        storage->slots[slot] = {bytes, alignment, true};
        storage->allocations++;
        storage->live++;
        memset(pointer, 0xa5, bytes);
        return pointer;
    }
    return nullptr;
}

static void release_slot(void *argument, void *pointer, size_t bytes, size_t alignment)
{
    auto *storage = static_cast<handshake_storage *>(argument);
    for (size_t slot = 0; slot < storage->requirements.block_count; slot++) {
        if (pointer != storage->backing + slot * storage->requirements.block_bytes) continue;
        auto *block = &storage->slots[slot];
        if (!block->live || block->bytes != bytes || block->alignment != alignment || storage->live == 0) {
            storage->bad = true;
            return;
        }
        const auto *raw = static_cast<const uint8_t *>(pointer);
        for (size_t index = 0; index < bytes; index++) {
            if (raw[index] != 0) storage->bad = true;
        }
        block->live = false;
        storage->live--;
        storage->releases++;
        return;
    }
    storage->bad = true;
}

static bool fixture_path(char *output, size_t capacity, const char *directory, const char *name)
{
    const int length = snprintf(output, capacity, "%s/%s", directory, name);
    return length >= 0 && static_cast<size_t>(length) < capacity;
}

struct handshake_result {
    bool complete;
    bool fatal;
    uint32_t client_error;
    uint32_t server_error;
};

static int handshake_step(SSL *ssl, bool *complete, uint32_t *error)
{
    if (*complete) return 1;
    ERR_clear_error();
    const int result = SSL_do_handshake(ssl);
    if (result == 1) {
        *complete = true;
        return 1;
    }
    const int ssl_error = SSL_get_error(ssl, result);
    if (ssl_error == SSL_ERROR_WANT_READ || ssl_error == SSL_ERROR_WANT_WRITE) return 0;
    *error = ERR_peek_error();
    return -1;
}

static handshake_result drive_handshake(SSL *client, SSL *server)
{
    bool client_complete = false, server_complete = false;
    handshake_result result = {};
    for (size_t step = 0; step < 4096; step++) {
        if (handshake_step(client, &client_complete, &result.client_error) < 0 ||
            handshake_step(server, &server_complete, &result.server_error) < 0) {
            result.fatal = true;
            return result;
        }
        if (client_complete && server_complete) {
            result.complete = true;
            return result;
        }
    }
    return result;
}

static int application_roundtrip(SSL *client, SSL *server)
{
    const uint8_t request[] = {0, 17, 99, 255, 42};
    const uint8_t response[] = {201, 0, 73, 13};
    uint8_t output[16] = {};
    REQUIRE(SSL_write(client, request, sizeof(request)) == sizeof(request));
    REQUIRE(SSL_read(server, output, sizeof(output)) == sizeof(request));
    REQUIRE(memcmp(output, request, sizeof(request)) == 0);
    REQUIRE(SSL_write(server, response, sizeof(response)) == sizeof(response));
    REQUIRE(SSL_read(client, output, sizeof(output)) == sizeof(response));
    REQUIRE(memcmp(output, response, sizeof(response)) == 0);
    return 0;
}

static int run_handshake(const char *directory, uint16_t cipher, size_t scenario)
{
    handshake_storage storage = {};
    bssl::UniquePtr<SSL_CTX> client_ctx(SSL_CTX_new(TLS_client_method()));
    bssl::UniquePtr<SSL_CTX> server_ctx(SSL_CTX_new(TLS_server_method()));
    REQUIRE(client_ctx && server_ctx);
    char path[1024];
    REQUIRE(fixture_path(path, sizeof(path), directory, scenario == 3 ? "untrusted.pem" : "ca.pem"));
    REQUIRE(SSL_CTX_load_verify_locations(client_ctx.get(), path, nullptr) == 1);
    REQUIRE(fixture_path(path, sizeof(path), directory, "server.pem"));
    REQUIRE(SSL_CTX_use_certificate_chain_file(server_ctx.get(), path) == 1);
    REQUIRE(fixture_path(path, sizeof(path), directory, "server.key"));
    REQUIRE(SSL_CTX_use_PrivateKey_file(server_ctx.get(), path, SSL_FILETYPE_PEM) == 1);
    REQUIRE(SSL_CTX_check_private_key(server_ctx.get()) == 1);
    REQUIRE(SSL_CTX_set_min_proto_version(client_ctx.get(), TLS1_3_VERSION) == 1);
    REQUIRE(SSL_CTX_set_max_proto_version(client_ctx.get(), TLS1_3_VERSION) == 1);
    const uint16_t server_version = scenario == 4 ? TLS1_2_VERSION : TLS1_3_VERSION;
    REQUIRE(SSL_CTX_set_min_proto_version(server_ctx.get(), server_version) == 1);
    REQUIRE(SSL_CTX_set_max_proto_version(server_ctx.get(), server_version) == 1);
    REQUIRE(SSL_CTX_set1_tls13_ciphers(client_ctx.get(), &cipher, nullptr, 1) == 1);
    REQUIRE(SSL_CTX_set1_tls13_ciphers(server_ctx.get(), &cipher, nullptr, 1) == 1);
    SSL_CTX_set_verify(client_ctx.get(), SSL_VERIFY_PEER, nullptr);
    REQUIRE(SSL_client_construction_storage_requirements(client_ctx.get(), 255, &storage.requirements));
    const auto &requirements = storage.requirements;
    REQUIRE(requirements.alignment != 0 && requirements.alignment <= alignof(max_align_t));
    REQUIRE(requirements.block_count != 0 && requirements.block_count <= 64 &&
            requirements.block_bytes != 0 && requirements.block_bytes % requirements.alignment == 0 &&
            requirements.block_bytes <= SIZE_MAX / requirements.block_count &&
            requirements.bytes == requirements.block_bytes * requirements.block_count &&
            requirements.bytes <= sizeof(storage.backing));
    storage.domain = {&storage, allocate_slot, release_slot};
    bssl::UniquePtr<SSL> client(SSL_new_client_with_construction_domain(client_ctx.get(), &storage.domain));
    bssl::UniquePtr<SSL> server(SSL_new(server_ctx.get()));
    REQUIRE(client && server);
    SSL_set_accept_state(server.get());
    REQUIRE(SSL_set_tlsext_host_name(client.get(), "localhost") == 1);
    if (scenario == 1) {
        REQUIRE(X509_VERIFY_PARAM_set1_ip_asc(SSL_get0_param(client.get()), "127.0.0.1") == 1);
    } else {
        REQUIRE(SSL_set1_host(client.get(), scenario == 2 ? "wrong.example.test" : "localhost") == 1);
    }
    BIO *client_bio = nullptr, *server_bio = nullptr;
    REQUIRE(BIO_new_bio_pair(&client_bio, 0, &server_bio, 0) == 1);
    SSL_set_bio(client.get(), client_bio, client_bio);
    SSL_set_bio(server.get(), server_bio, server_bio);
    const handshake_result result = drive_handshake(client.get(), server.get());
    const long verification = SSL_get_verify_result(client.get());
    if (scenario <= 1) {
        REQUIRE(result.complete && !result.fatal && verification == X509_V_OK);
        REQUIRE(SSL_version(client.get()) == TLS1_3_VERSION && SSL_version(server.get()) == TLS1_3_VERSION);
        REQUIRE(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(client.get())) == cipher);
        REQUIRE(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(server.get())) == cipher);
        bssl::UniquePtr<X509> peer(SSL_get_peer_certificate(client.get()));
        REQUIRE(peer != nullptr && application_roundtrip(client.get(), server.get()) == 0);
    } else {
        REQUIRE(!result.complete && result.fatal);
        if (scenario == 2) REQUIRE(verification == X509_V_ERR_HOSTNAME_MISMATCH);
        if (scenario == 3) REQUIRE((verification == X509_V_ERR_UNABLE_TO_GET_ISSUER_CERT_LOCALLY ||
                                     verification == X509_V_ERR_SELF_SIGNED_CERT_IN_CHAIN) &&
                                    result.client_error != 0);
        if (scenario == 4) REQUIRE(ERR_GET_REASON(result.server_error) == SSL_R_UNSUPPORTED_PROTOCOL ||
                                  ERR_GET_REASON(result.client_error) == SSL_R_TLSV1_ALERT_PROTOCOL_VERSION);
    }
    client.reset();
    server.reset();
    REQUIRE(!storage.bad && storage.live == 0 && storage.allocations == storage.releases);
    printf("ssl_construction_handshake cipher=0x%04x scenario=%zu complete=%d fatal=%d verify=%ld client_reason=%d server_reason=%d domain_alloc=%zu domain_free=%zu live=%zu whole_handshake_zero_claim=0\n",
           cipher, scenario, result.complete, result.fatal, verification,
           ERR_GET_REASON(result.client_error), ERR_GET_REASON(result.server_error),
           storage.allocations, storage.releases, storage.live);
    return 0;
}

int main(int argc, char **argv)
{
    if (argc != 2) return 2;
    const uint16_t ciphers[] = {0x1301, 0x1302, 0x1303};
    size_t failed = 0;
    for (uint16_t cipher : ciphers) {
        for (size_t scenario = 0; scenario < 5; scenario++) {
            const int line = run_handshake(argv[1], cipher, scenario);
            if (line == 0) continue;
            printf("ssl_construction_handshake_failure cipher=0x%04x scenario=%zu line=%d\n", cipher, scenario, line);
            failed++;
        }
    }
    printf("ssl_construction_handshake_result rows=15 failed=%zu DNS_IPv4_verified=1 IPv6_handshake_claim=0 whole_handshake_zero_claim=0\n", failed);
    return failed != 0;
}
