#include "crypto/cert_alloc_internal.h"
#include "allocation_scope.h"

#include <openssl/mem.h>

#include <stddef.h>
#include <stdio.h>

struct hook_counts {
    size_t allocate;
    size_t release;
    size_t get_size;
};

// The weak hook ABI is process-wide and supplies no context argument.
static hook_counts full_hooks;

extern "C" void *OPENSSL_memory_alloc(size_t)
{
    full_hooks.allocate++;
    return nullptr;
}

extern "C" void OPENSSL_memory_free(void *)
{
    full_hooks.release++;
}

extern "C" size_t OPENSSL_memory_get_size(void *)
{
    full_hooks.get_size++;
    return 0;
}

static void *domain_allocate(void *context, size_t, size_t)
{
    auto *calls = static_cast<hook_counts *>(context);
    calls->allocate++;
    return nullptr;
}

static void domain_release(void *context, void *, size_t, size_t)
{
    auto *calls = static_cast<hook_counts *>(context);
    calls->release++;
}

int main(void)
{
    hook_counts domain_calls = {};
    const OPENSSL_ALLOCATION_DOMAIN domain = {&domain_calls, domain_allocate, domain_release};
    bssl::CertOperation operation = {&domain, nullptr};

    // The first native call includes any cold ERR reporting allocations.
    uwz_alloc_begin();
    void *result = bssl::cert_alloc_nonzero({&operation, &domain}, 17);
    uwz_alloc_end();

    const auto mallocs = static_cast<unsigned long long>(uwz_alloc_malloc_calls());
    const auto callocs = static_cast<unsigned long long>(uwz_alloc_calloc_calls());
    const auto reallocs = static_cast<unsigned long long>(uwz_alloc_realloc_calls());
    const auto frees = static_cast<unsigned long long>(uwz_alloc_free_calls());
    const auto bytes = static_cast<unsigned long long>(uwz_alloc_requested_bytes());
    const bool passed = result == nullptr && operation.allocation_failed &&
        domain_calls.allocate == 0 && domain_calls.release == 0 &&
        full_hooks.allocate == 0 && full_hooks.release == 0 && full_hooks.get_size == 0 &&
        (mallocs > 0 || callocs > 0 || reallocs > 0) && bytes > 0;
    printf("cold_full_hook_refusal %s sticky=%d domain_alloc=%zu domain_free=%zu "
           "hook_alloc=%zu hook_free=%zu hook_size=%zu malloc=%llu calloc=%llu realloc=%llu free=%llu bytes=%llu\n",
           passed ? "PASS" : "FAIL", operation.allocation_failed, domain_calls.allocate, domain_calls.release,
           full_hooks.allocate, full_hooks.release, full_hooks.get_size, mallocs, callocs, reallocs, frees, bytes);
    return passed ? 0 : 1;
}
