#include <openssl/err.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>

#include <stdio.h>
#include <string.h>

#include "allocation_scope.h"

extern "C" int uwz_alloc_self_test(void);
#define REQUIRE(condition) do { if (!(condition)) return __LINE__; } while (0)

int main(int argc, char **argv)
{
    REQUIRE(uwz_alloc_self_test());
    SSL_CTX *ctx = SSL_CTX_new(TLS_client_method());
    REQUIRE(ctx != nullptr);
    REQUIRE(SSL_CTX_set_min_proto_version(ctx, TLS1_3_VERSION));
    REQUIRE(SSL_CTX_set_max_proto_version(ctx, TLS1_3_VERSION));
    SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, nullptr);
    SSL *warm = SSL_new(ctx);
    REQUIRE(warm != nullptr);
    SSL_free(warm);
    ERR_clear_error();

    uwz_alloc_begin();
    SSL *ssl = SSL_new(ctx);
    const bool functional = ssl != nullptr &&
        SSL_set_tlsext_host_name(ssl, "localhost") == 1 &&
        SSL_set1_host(ssl, "localhost") == 1;
    SSL_free(ssl);
    uwz_alloc_end();
    const bool allocating = !uwz_all_c_zero();
    printf("ordinary_ssl_construction_setup functional=%d malloc=%llu calloc=%llu realloc=%llu free=%llu bytes=%llu strict_zero=%d selftest63=pass rng_ERR_warmed_outside=1\n",
           functional, static_cast<unsigned long long>(uwz_alloc_malloc_calls()),
           static_cast<unsigned long long>(uwz_alloc_calloc_calls()),
           static_cast<unsigned long long>(uwz_alloc_realloc_calls()),
           static_cast<unsigned long long>(uwz_alloc_free_calls()),
           static_cast<unsigned long long>(uwz_alloc_requested_bytes()), !allocating);
    SSL_CTX_free(ctx);
    REQUIRE(functional && allocating);
    return argc == 2 && strcmp(argv[1], "--strict") == 0 ? 1 : 0;
}
