#include "wire_test_storage.h"
static int query_pure(SSL_CTX *ctx)
{
    const auto *impl = bssl::FromOpaque(ctx);
    uint8_t before[sizeof(*impl)];
    memcpy(before, impl, sizeof(before));
    SSL_CLIENT_WIRE_STORAGE_REQUIREMENTS requirements = {};
    REQUIRE(SSL_client_wire_storage_requirements(ctx, &requirements));
    REQUIRE(requirements.block_count == 12 && validate_plan(requirements));
    REQUIRE(memcmp(before, impl, sizeof(before)) == 0);
    return 0;
}
static int query_guards(SSL_CTX *ctx)
{
    const uint32_t error = ERR_peek_error();
    REQUIRE(error != 0 && !SSL_client_wire_storage_requirements(ctx, nullptr));
    SSL_CLIENT_WIRE_STORAGE_REQUIREMENTS output, zero = {};
    memset(&output, 0xa5, sizeof(output));
    REQUIRE(!SSL_client_wire_storage_requirements(nullptr, &output));
    REQUIRE(memcmp(&output, &zero, sizeof(output)) == 0);
    auto *impl = bssl::FromOpaque(ctx);
    const uint32_t old_limit = impl->max_cert_list;
    impl->max_cert_list = UINT32_MAX;
    const bool rejected = !SSL_client_wire_storage_requirements(ctx, &output);
    impl->max_cert_list = old_limit;
    REQUIRE(rejected && memcmp(&output, &zero, sizeof(output)) == 0 && ERR_peek_error() == error);
    const size_t capacities[] = {0, 1, 2, 3, 16384, UINT16_MAX, SIZE_MAX / 2, SIZE_MAX - 3, SIZE_MAX};
    for (size_t capacity : capacities) {
        size_t actual = 91;
        const bool valid = bssl::BUF_MEM_allocation_size(capacity, &actual);
        const bool expected = capacity <= SIZE_MAX - 3 && (capacity + 3) / 3 <= SIZE_MAX / 4;
        REQUIRE(valid == expected);
        REQUIRE(actual == (expected ? 4 * ((capacity + 3) / 3) : 0));
    }
    REQUIRE(!bssl::BUF_MEM_allocation_size(19, nullptr));
    REQUIRE(ERR_peek_error() == error);
    return 0;
}
#define REJECT_QUERY_VALUE(field, value) do {     const auto saved = (field); (field) = (value);     SSL_CLIENT_WIRE_STORAGE_REQUIREMENTS bad; memset(&bad, 0xa5, sizeof(bad));     const bool rejected = !SSL_client_wire_storage_requirements(ctx, &bad); (field) = saved;     const SSL_CLIENT_WIRE_STORAGE_REQUIREMENTS zero = {};     REQUIRE(rejected && memcmp(&bad, &zero, sizeof(bad)) == 0); } while (0)
static int query_profile_guards(SSL_CTX *ctx)
{
    auto *impl = bssl::FromOpaque(ctx);
    const uint32_t error = ERR_peek_error();
    REJECT_QUERY_VALUE(impl->conf_min_version, TLS1_2_VERSION);
    REJECT_QUERY_VALUE(impl->conf_max_version, TLS1_2_VERSION);
    REJECT_QUERY_VALUE(impl->options, impl->options | SSL_OP_NO_TLSv1_3);
    REJECT_QUERY_VALUE(impl->max_send_fragment, 511);
    REJECT_QUERY_VALUE(impl->max_send_fragment, 16385);
    REJECT_QUERY_VALUE(impl->enable_early_data, true);
    REJECT_QUERY_VALUE(impl->channel_id_enabled, true);
    REJECT_QUERY_VALUE(impl->permute_extensions, true);
    REJECT_QUERY_VALUE(impl->supported_group_list[0], UINT16_MAX);
    REJECT_QUERY_VALUE(impl->supported_group_list_flags[0], UINT32_MAX);
    REQUIRE(impl->supported_group_list.size() > 1);
    REJECT_QUERY_VALUE(impl->supported_group_list[1], impl->supported_group_list[0]);
    const uint32_t old_limit = impl->max_cert_list;
    impl->max_cert_list = (1u << 24) - 1;
    SSL_CLIENT_WIRE_STORAGE_REQUIREMENTS maximum = {};
    const bool admitted = SSL_client_wire_storage_requirements(ctx, &maximum);
    impl->max_cert_list = old_limit;
    REQUIRE(admitted && validate_plan(maximum) && maximum.bytes > 1048576);
    REQUIRE(ERR_peek_error() == error);
    return 0;
}
static int bind_and_roles(SSL_CTX *ctx)
{
    wire_storage constructor = {}, wire = {};
    REQUIRE(initialize_constructor(&constructor, ctx) && initialize_wire(&wire, ctx));
    SSL *ssl = SSL_new_client_with_construction_domain(ctx, &constructor.domain);
    REQUIRE(ssl != nullptr && SSL_set1_host(ssl, "localhost") == 1);
    auto *impl = bssl::FromOpaque(ssl);
    auto *descriptor = impl->s3->hs->transcript.buffer_.get();
    REQUIRE(bssl::GetAllocationDomain(descriptor) == &constructor.domain);
    REQUIRE(SSL_set_client_wire_storage_domain(ssl, &wire.domain) == 1);
    REQUIRE(wire.attempts == 9 && wire.live == 9 && !wire.bad);
    REQUIRE(impl->s3->hs->transcript.buffer_.get() == descriptor);
    REQUIRE(bssl::GetAllocationDomain(descriptor->data) == &wire.domain);
    CBB message, key, cookie;
    REQUIRE(bssl::CBB_init_bounded_with_domain(&message, impl->client_wire_limits.message, &wire.domain));
    REQUIRE(bssl::CBB_init_bounded_with_domain(&key, UINT16_MAX, &wire.domain));
    REQUIRE(bssl::CBB_init_bounded_with_domain(&cookie, UINT16_MAX, &wire.domain));
    REQUIRE(wire.live == 12 && wire.peak == 12);
    CBB extra;
    REQUIRE(!bssl::CBB_init_bounded_with_domain(&extra, UINT16_MAX, &wire.domain));
    CBB_cleanup(&extra);
    CBB_cleanup(&key);
    REQUIRE(bssl::CBB_init_bounded_with_domain(&key, UINT16_MAX, &wire.domain));
    REQUIRE(wire.live == 12 && wire.reused != 0);
    CBB_cleanup(&cookie); CBB_cleanup(&key); CBB_cleanup(&message);
    const size_t attempts = wire.attempts;
    REQUIRE(!SSL_set_client_wire_storage_domain(ssl, &wire.domain));
    REQUIRE(wire.attempts == attempts && wire.live == 9);
    SSL_free(ssl);
    REQUIRE(storage_empty(constructor) && storage_empty(wire));
    return 0;
}
static int bind_failures(SSL_CTX *ctx)
{
    for (size_t fault = 1; fault <= 9; fault++) {
        wire_storage constructor = {}, wire = {};
        REQUIRE(initialize_constructor(&constructor, ctx) && initialize_wire(&wire, ctx));
        SSL *ssl = SSL_new_client_with_construction_domain(ctx, &constructor.domain);
        REQUIRE(ssl != nullptr);
        auto *impl = bssl::FromOpaque(ssl);
        auto *descriptor = impl->s3->hs->transcript.buffer_.get();
        const size_t constructor_live = constructor.live;
        wire.fail_attempt = fault;
        REQUIRE(!SSL_set_client_wire_storage_domain(ssl, &wire.domain));
        REQUIRE(wire.failure_hits == 1 && wire.attempts >= fault && storage_empty(wire));
        REQUIRE(impl->client_wire_domain == nullptr && impl->s3->hs->transcript.buffer_.get() == descriptor);
        REQUIRE(descriptor->data == nullptr && descriptor->length == 0 && descriptor->max == 0);
        REQUIRE(constructor.live == constructor_live && bssl::GetAllocationDomain(descriptor) == &constructor.domain);
        wire.fail_attempt = 0;
        REQUIRE(SSL_set_client_wire_storage_domain(ssl, &wire.domain) == 1);
        SSL_free(ssl);
        REQUIRE(storage_empty(constructor) && storage_empty(wire));
    }
    return 0;
}
static int malformed_domains(SSL_CTX *ctx)
{
    wire_storage constructor = {}, wire = {};
    REQUIRE(initialize_constructor(&constructor, ctx) && initialize_wire(&wire, ctx));
    SSL *ssl = SSL_new_client_with_construction_domain(ctx, &constructor.domain);
    REQUIRE(ssl != nullptr);
    const OPENSSL_ALLOCATION_DOMAIN no_allocate = {&wire, nullptr, wire_release};
    const OPENSSL_ALLOCATION_DOMAIN no_release = {&wire, wire_allocate, nullptr};
    REQUIRE(!SSL_set_client_wire_storage_domain(ssl, nullptr));
    REQUIRE(!SSL_set_client_wire_storage_domain(ssl, &no_allocate));
    REQUIRE(!SSL_set_client_wire_storage_domain(ssl, &no_release));
    REQUIRE(!SSL_set_client_wire_storage_domain(nullptr, &wire.domain));
    REQUIRE(wire.attempts == 0 && bssl::FromOpaque(ssl)->client_wire_domain == nullptr);
    REQUIRE(SSL_set_client_wire_storage_domain(ssl, &wire.domain));
    SSL_free(ssl);
    REQUIRE(storage_empty(constructor) && storage_empty(wire));
    return 0;
}
static int fixed_cbb_and_transient_failures(SSL_CTX *ctx)
{
    wire_storage constructor = {}, wire = {};
    REQUIRE(initialize_constructor(&constructor, ctx) && initialize_wire(&wire, ctx));
    SSL *ssl = SSL_new_client_with_construction_domain(ctx, &constructor.domain);
    REQUIRE(ssl != nullptr && SSL_set_client_wire_storage_domain(ssl, &wire.domain));
    auto *impl = bssl::FromOpaque(ssl);
    const size_t capacities[] = {impl->client_wire_limits.message, UINT16_MAX, UINT16_MAX};
    for (size_t capacity : capacities) {
        CBB cbb;
        wire.fail_attempt = wire.attempts + 1;
        REQUIRE(!bssl::CBB_init_bounded_with_domain(&cbb, capacity, &wire.domain));
        CBB_cleanup(&cbb);
        REQUIRE(wire.live == 9 && !wire.bad);
        wire.fail_attempt = 0;
        REQUIRE(bssl::CBB_init_bounded_with_domain(&cbb, capacity, &wire.domain));
        REQUIRE(cbb.u.base.fixed_capacity && cbb.u.base.can_resize);
        uint8_t *output;
        REQUIRE(CBB_add_space(&cbb, &output, capacity));
        for (size_t index = 0; index < capacity; index++) output[index] = static_cast<uint8_t>(index * 31 + 7);
        bssl::Array<uint8_t> result;
        REQUIRE(bssl::CBBFinishArray(&cbb, &result) && result.size() == capacity && wire.live == 10);
        REQUIRE(result.front() == 7 && result.back() == static_cast<uint8_t>((capacity - 1) * 31 + 7));
        CBB_cleanup(&cbb);
        result.Reset();
        REQUIRE(wire.live == 9);
        REQUIRE(bssl::CBB_init_bounded_with_domain(&cbb, capacity, &wire.domain));
        const size_t before = wire.attempts;
        REQUIRE(!CBB_add_space(&cbb, &output, capacity + 1));
        REQUIRE(wire.attempts == before && CBB_len(&cbb) == 0);
        CBB_cleanup(&cbb);
    }
    CBB ordinary;
    REQUIRE(CBB_init_fixed(&ordinary, constructor.backing, 8));
    REQUIRE(!ordinary.u.base.fixed_capacity && !ordinary.u.base.can_resize);
    CBB_cleanup(&ordinary);
    SSL_free(ssl);
    REQUIRE(storage_empty(constructor) && storage_empty(wire));
    return 0;
}
static int coalesced_bounds_and_records(SSL_CTX *ctx)
{
    wire_storage constructor = {}, wire = {};
    REQUIRE(initialize_constructor(&constructor, ctx) && initialize_wire(&wire, ctx));
    SSL *ssl = SSL_new_client_with_construction_domain(ctx, &constructor.domain);
    REQUIRE(ssl != nullptr && SSL_set_client_wire_storage_domain(ssl, &wire.domain));
    auto *impl = bssl::FromOpaque(ssl);
    uint8_t bytes[16384];
    memset(bytes, 0x73, sizeof(bytes));
    const size_t limit = impl->client_wire_limits.input;
    size_t appended = 0;
    while (appended < limit) {
        const size_t amount = std::min(sizeof(bytes), limit - appended);
        REQUIRE(bssl::tls_append_handshake_data(impl, bssl::Span<const uint8_t>(bytes, amount)));
        appended += amount;
    }
    const size_t before = wire.attempts;
    REQUIRE(!bssl::tls_append_handshake_data(impl, bssl::Span<const uint8_t>(bytes, 1)));
    REQUIRE(impl->s3->hs_buf->length == limit && wire.attempts == before);
    impl->s3->hs_buf->length = 0;
    auto &transcript = impl->s3->hs->transcript;
    size_t transcript_bytes = 0;
    while (transcript_bytes < impl->client_wire_limits.transcript) {
        const size_t amount = std::min(sizeof(bytes), impl->client_wire_limits.transcript - transcript_bytes);
        REQUIRE(transcript.Update(bssl::Span<const uint8_t>(bytes, amount)));
        transcript_bytes += amount;
    }
    REQUIRE(!transcript.Update(bssl::Span<const uint8_t>(bytes, 1)));
    REQUIRE(transcript.buffer().size() == impl->client_wire_limits.transcript);
    transcript.buffer_->length = 0;
    auto *flight = impl->s3->pending_flight.get();
    flight->length = impl->client_wire_limits.flight;
    const uint8_t message[] = {SSL3_MT_CERTIFICATE, 0, 0, 1, 19};
    REQUIRE(!bssl::tls_add_message_borrowed(impl, bssl::Span<const uint8_t>(message)));
    REQUIRE(flight->length == impl->client_wire_limits.flight && wire.attempts == before);
    flight->length = 0;
    auto *record = &impl->s3->read_buffer;
    for (size_t fragment : {size_t{512}, size_t{1024}, size_t{4096}, size_t{16384}}) {
        REQUIRE(record->EnsureCap(5, fragment));
        memset(record->data(), 0x91, fragment); record->DidWrite(fragment);
        record->Consume(fragment); record->DiscardConsumed();
        REQUIRE(record->empty() && !record->is_uninitialized());
    }
    REQUIRE(!record->EnsureCap(5, bssl::SSLBuffer::kWireCapacity + 1));
    REQUIRE(wire.attempts == before);
    SSL_free(ssl);
    REQUIRE(storage_empty(constructor) && storage_empty(wire));
    return 0;
}
static int clear_faults_and_interleaving(SSL_CTX *ctx)
{
    for (size_t fault = 0; fault <= 9; fault++) {
        wire_storage constructor = {}, wire = {};
        REQUIRE(initialize_constructor(&constructor, ctx) && initialize_wire(&wire, ctx));
        SSL *ssl = SSL_new_client_with_construction_domain(ctx, &constructor.domain);
        REQUIRE(ssl != nullptr && SSL_set_client_wire_storage_domain(ssl, &wire.domain));
        wire.fail_attempt = fault == 0 ? 0 : wire.attempts + fault;
        const int result = SSL_clear(ssl);
        REQUIRE((fault == 0 && result == 1) || (fault != 0 && result == 0 && wire.failure_hits == 1));
        SSL_free(ssl);
        REQUIRE(storage_empty(constructor) && storage_empty(wire));
    }
    wire_storage a_constructor = {}, a_wire = {}, b_constructor = {}, b_wire = {};
    REQUIRE(initialize_constructor(&a_constructor, ctx) && initialize_wire(&a_wire, ctx));
    REQUIRE(initialize_constructor(&b_constructor, ctx) && initialize_wire(&b_wire, ctx));
    for (size_t cycle = 0; cycle < 64; cycle++) {
        SSL *a = SSL_new_client_with_construction_domain(ctx, &a_constructor.domain);
        SSL *b = SSL_new_client_with_construction_domain(ctx, &b_constructor.domain);
        REQUIRE(a && b && SSL_set_client_wire_storage_domain(a, &a_wire.domain) && SSL_set_client_wire_storage_domain(b, &b_wire.domain));
        REQUIRE(SSL_clear(a) == 1 && SSL_clear(b) == 1);
        SSL_free(a);
        REQUIRE(storage_empty(a_wire) && b_wire.live == 9);
        SSL_free(b);
        REQUIRE(storage_empty(a_constructor) && storage_empty(a_wire) && storage_empty(b_constructor) && storage_empty(b_wire));
    }
    return 0;
}
static int actual_public_guards(SSL_CTX *ctx)
{
    const uint8_t protocol[] = {2, 'h', '2'};
    for (size_t variant = 0; variant < 6; variant++) {
        wire_storage wire = {};
        REQUIRE(initialize_wire(&wire, ctx));
        SSL *ssl = SSL_new(ctx);
        REQUIRE(ssl != nullptr);
        SSL_set_connect_state(ssl);
        if (variant == 0) REQUIRE(SSL_set_alpn_protos(ssl, protocol, sizeof(protocol)) == 0);
        if (variant == 1) REQUIRE(SSL_add_application_settings(ssl, protocol + 1, 2, nullptr, 0) == 1);
        if (variant == 2) {
            SSL_SESSION *session = SSL_SESSION_new(ctx);
            REQUIRE(session && SSL_set_session(ssl, session));
            SSL_SESSION_free(session);
        }
        if (variant == 3) SSL_set_accept_state(ssl);
        if (variant >= 4) {
            const int result = SSL_do_handshake(ssl);
            REQUIRE(result != 1);
        }
        if (variant == 5) {
            REQUIRE(SSL_clear(ssl));
            SSL_set_connect_state(ssl);
        }
        REQUIRE(!SSL_set_client_wire_storage_domain(ssl, &wire.domain));
        REQUIRE(wire.attempts == 0 && storage_empty(wire));
        SSL_free(ssl);
    }
    return 0;
}
static int fixed_plaintext_ciphertext_differential(SSL_CTX *ctx)
{
    for (uint16_t suite : {uint16_t{0x1301}, uint16_t{0x1302}, uint16_t{0x1303}}) {
        wire_storage constructor = {}, wire = {};
        REQUIRE(initialize_constructor(&constructor, ctx) && initialize_wire(&wire, ctx));
        bssl::UniquePtr<SSL> owned(SSL_new_client_with_construction_domain(ctx, &constructor.domain));
        bssl::UniquePtr<SSL> ordinary(SSL_new(ctx));
        REQUIRE(owned && ordinary && SSL_set_client_wire_storage_domain(owned.get(), &wire.domain));
        uint8_t key[32], iv[12];
        for (size_t index = 0; index < sizeof(key); index++) key[index] = static_cast<uint8_t>(index * 13 + 7);
        for (size_t index = 0; index < sizeof(iv); index++) iv[index] = static_cast<uint8_t>(index * 11 + 3);
        const auto *cipher = SSL_get_cipher_by_value(suite);
        const size_t key_length = suite == 0x1301 ? 16 : 32;
        const uint8_t message[] = {SSL3_MT_CERTIFICATE, 0, 0, 5, 19, 31, 73, 0, 255};
        for (SSL *ssl : {owned.get(), ordinary.get()}) {
            auto *impl = bssl::FromOpaque(ssl);
            impl->s3->version = TLS1_3_VERSION;
            impl->s3->aead_write_ctx = bssl::SSLAEADContext::Create(evp_aead_seal, TLS1_3_VERSION, cipher,
                bssl::Span<const uint8_t>(key, key_length), {}, bssl::Span<const uint8_t>(iv));
            REQUIRE(impl->s3->aead_write_ctx != nullptr);
            REQUIRE(bssl::tls_add_message_borrowed(impl, bssl::Span<const uint8_t>(message)));
            REQUIRE(impl->s3->pending_hs_data->length == sizeof(message));
            REQUIRE(memcmp(impl->s3->pending_hs_data->data, message, sizeof(message)) == 0);
            REQUIRE(bssl::tls_flush_pending_hs_data(impl));
        }
        auto *a = bssl::FromOpaque(owned.get())->s3;
        auto *b = bssl::FromOpaque(ordinary.get())->s3;
        REQUIRE(a->pending_flight->length == b->pending_flight->length && a->pending_flight->length > sizeof(message));
        REQUIRE(memcmp(a->pending_flight->data, b->pending_flight->data, a->pending_flight->length) == 0);
        REQUIRE(wire.attempts == 9 && !wire.bad);
        owned.reset(); ordinary.reset();
        REQUIRE(storage_empty(constructor) && storage_empty(wire));
    }
    return 0;
}
static int ordinary_direct_buffer_control(SSL_CTX *)
{
    bssl::SSLBuffer ordinary;
    REQUIRE(ordinary.EnsureCap(5, 4096));
    memset(ordinary.data(), 0x37, 4096); ordinary.DidWrite(4096);
    REQUIRE(ordinary.Reserve() == false);
    ordinary.Consume(4096); ordinary.DiscardConsumed();
    REQUIRE(ordinary.is_uninitialized());
    REQUIRE(ordinary.Reserve());
    ordinary.Clear();
    REQUIRE(!ordinary.is_uninitialized() && ordinary.empty());
    return 0;
}
static int partial_client_hello_alert_retention(SSL_CTX *ctx)
{
    wire_storage constructor = {}, wire = {};
    REQUIRE(initialize_constructor(&constructor, ctx) && initialize_wire(&wire, ctx));
    bssl::UniquePtr<SSL> ssl(SSL_new_client_with_construction_domain(ctx, &constructor.domain));
    REQUIRE(ssl && SSL_set_client_wire_storage_domain(ssl.get(), &wire.domain));
    BIO *inside = nullptr, *outside = nullptr;
    REQUIRE(BIO_new_bio_pair(&inside, 17, &outside, 17));
    bssl::UniquePtr<BIO> peer(outside);
    SSL_set_bio(ssl.get(), inside, inside);
    ERR_clear_error();
    const int hello = SSL_do_handshake(ssl.get());
    REQUIRE(SSL_get_error(ssl.get(), hello) == SSL_ERROR_WANT_WRITE);
    auto *state = bssl::FromOpaque(ssl.get())->s3;
    REQUIRE(state->pending_flight && state->pending_flight_offset > 0 &&
            state->pending_flight_offset < state->pending_flight->length);
    auto *flight = state->pending_flight.get();
    char *data = flight->data;
    const size_t releases = wire.releases;
    const size_t live = wire.live;
    uwz_alloc_begin();
    const int alert = SSL_send_fatal_alert(ssl.get(), SSL_AD_INTERNAL_ERROR);
    const int error = alert > 0 ? SSL_ERROR_NONE : SSL_get_error(ssl.get(), alert);
    uwz_alloc_end();
    const bool retained = state->pending_flight.get() == flight && state->pending_flight->data == data;
    const bool good = retained && wire.releases == releases && wire.live == live && uwz_all_c_zero();
    printf("wire_scoped_alert_retention failed=%d alert_result=%d error=%d flight_same=%d live_before=%zu live_after=%zu releases_before=%zu releases_after=%zu malloc=%llu calloc=%llu realloc=%llu free=%llu bytes=%llu strict_zero=1\n",
           !good, alert, error, retained, live, wire.live, releases, wire.releases,
           static_cast<unsigned long long>(uwz_alloc_malloc_calls()),static_cast<unsigned long long>(uwz_alloc_calloc_calls()),
           static_cast<unsigned long long>(uwz_alloc_realloc_calls()),static_cast<unsigned long long>(uwz_alloc_free_calls()),
           static_cast<unsigned long long>(uwz_alloc_requested_bytes()));
    ssl.reset(); peer.reset();
    REQUIRE(storage_empty(constructor) && storage_empty(wire));
    return !good;
}
static int direct_alert_clear_binding_guard(SSL_CTX *ctx)
{
    wire_storage wire = {};
    REQUIRE(initialize_wire(&wire, ctx));
    bssl::UniquePtr<SSL> ssl(SSL_new(ctx));
    REQUIRE(ssl != nullptr);
    SSL_set_connect_state(ssl.get());
    BIO *inside = nullptr, *outside = nullptr;
    REQUIRE(BIO_new_bio_pair(&inside, 1024, &outside, 1024));
    bssl::UniquePtr<BIO> peer(outside);
    SSL_set_bio(ssl.get(), inside, inside);
    ERR_clear_error();
    const int alert = SSL_send_fatal_alert(ssl.get(), SSL_AD_INTERNAL_ERROR);
    REQUIRE(alert == 1);
    REQUIRE(SSL_clear(ssl.get()));
    SSL_set_connect_state(ssl.get());
    uwz_alloc_begin();
    const int bound = SSL_set_client_wire_storage_domain(ssl.get(), &wire.domain);
    uwz_alloc_end();
    const bool good = bound == 0 && wire.attempts == 0 && uwz_all_c_zero();
    printf("wire_scoped_alert_latch failed=%d alert_result=%d bind_after_clear=%d callbacks=%zu malloc=%llu calloc=%llu realloc=%llu free=%llu bytes=%llu strict_zero=1\n",
           !good,alert,bound,wire.attempts,
           static_cast<unsigned long long>(uwz_alloc_malloc_calls()),static_cast<unsigned long long>(uwz_alloc_calloc_calls()),
           static_cast<unsigned long long>(uwz_alloc_realloc_calls()),static_cast<unsigned long long>(uwz_alloc_free_calls()),
           static_cast<unsigned long long>(uwz_alloc_requested_bytes()));
    ssl.reset(); peer.reset();
    REQUIRE(storage_empty(wire));
    return !good;
}
using wire_case_function = int (*)(SSL_CTX *);
static int run_wire_case(const char *name, wire_case_function function, SSL_CTX *ctx, bool strict)
{
    uwz_alloc_begin();
    const int line = function(ctx);
    uwz_alloc_end();
    const bool failed = line != 0 || (strict && !uwz_all_c_zero());
    printf("wire_case=%s failed=%d line=%d malloc=%llu calloc=%llu realloc=%llu free=%llu bytes=%llu strict_zero=%d\n", name, failed, line,
           static_cast<unsigned long long>(uwz_alloc_malloc_calls()), static_cast<unsigned long long>(uwz_alloc_calloc_calls()),
           static_cast<unsigned long long>(uwz_alloc_realloc_calls()), static_cast<unsigned long long>(uwz_alloc_free_calls()),
           static_cast<unsigned long long>(uwz_alloc_requested_bytes()), strict);
    return failed;
}
struct cold_input { SSL_CTX *ctx; int failed; };
static void *cold_query_thread(void *argument)
{
    auto *input = static_cast<cold_input *>(argument);
    input->failed = run_wire_case("cold_thread_query", query_pure, input->ctx, true);
    uwz_alloc_begin();
    OPENSSL_PUT_ERROR(CRYPTO, ERR_R_MALLOC_FAILURE);
    uint8_t byte;
    const bool good = ERR_peek_error() != 0 && RAND_bytes(&byte, 1) == 1;
    uwz_alloc_end();
    printf("wire_cold_ERR_RNG_control success=%d malloc=%llu calloc=%llu bytes=%llu\n", good,
           static_cast<unsigned long long>(uwz_alloc_malloc_calls()), static_cast<unsigned long long>(uwz_alloc_calloc_calls()),
           static_cast<unsigned long long>(uwz_alloc_requested_bytes()));
    input->failed += !good || uwz_all_c_zero();
    return nullptr;
}
int main(void)
{
    SSL_CTX *ctx = make_wire_context();
    if (ctx == nullptr) return 2;
    int failed = run_wire_case("cold_process_query", query_pure, ctx, true);
    cold_input input = {ctx, 0}; pthread_t thread;
    if (pthread_create(&thread, nullptr, cold_query_thread, &input) != 0 || pthread_join(thread, nullptr) != 0) return 2;
    failed += input.failed;
    if (!uwz_alloc_self_test()) return 2;
    uint8_t byte;
    if (RAND_bytes(&byte, 1) != 1) return 2;
    OPENSSL_PUT_ERROR(CRYPTO, ERR_R_MALLOC_FAILURE);
    failed += run_wire_case("pure_query_outputs_overflow_BUF_geometry_ERR", query_guards, ctx, true);
    failed += run_wire_case("context_versions_flags_groups_limit_guards", query_profile_guards, ctx, true);
    failed += run_wire_case("bind_nine_persistent_twelve_live_exact_classes", bind_and_roles, ctx, true);
    failed += run_wire_case("all_nine_bind_failures_last_transcript_rollback", bind_failures, ctx, true);
    failed += run_wire_case("null_half_domains_before_callbacks_retry", malformed_domains, ctx, true);
    failed += run_wire_case("transient_failure_fixed_CBB_Array_transfer", fixed_cbb_and_transient_failures, ctx, true);
    failed += run_wire_case("coalesced_I_limit_records_512_16384", coalesced_bounds_and_records, ctx, true);
    failed += run_wire_case("destructive_clear_failures_64_interleaved_cycles", clear_faults_and_interleaving, ctx, true);
    failed += run_wire_case("actual_SSL_ALPN_ALPS_session_role_late_guards", actual_public_guards, ctx, false);
    failed += run_wire_case("fixed_plaintext_ciphertext_all_three_suites_differential", fixed_plaintext_ciphertext_differential, ctx, false);
    failed += run_wire_case("ordinary_direct_malloc_buffer_control", ordinary_direct_buffer_control, ctx, false);
    failed += partial_client_hello_alert_retention(ctx);
    failed += direct_alert_clear_binding_guard(ctx);
    SSL_CLIENT_WIRE_STORAGE_REQUIREMENTS wire = {};
    SSL_CLIENT_CONSTRUCTION_REQUIREMENTS constructor = {};
    if (!SSL_client_wire_storage_requirements(ctx, &wire) || !SSL_client_construction_storage_requirements(ctx, 255, &constructor)) return 2;
    printf("wire_layout SSLImpl=%zu SSL3_STATE=%zu SSL_HANDSHAKE=%zu SSLTranscript=%zu SSLBuffer=%zu CBB=%zu BUF_MEM=%zu constructor_bytes=%zu constructor_stride=%zu constructor_count=%zu wire_bytes=%zu classes=%zu blocks=%zu\n",
           sizeof(bssl::SSLImpl), sizeof(bssl::SSL3_STATE), sizeof(bssl::SSL_HANDSHAKE), sizeof(bssl::SSLTranscript), sizeof(bssl::SSLBuffer), sizeof(CBB), sizeof(BUF_MEM),
           constructor.bytes, constructor.block_bytes, constructor.block_count, wire.bytes, wire.class_count, wire.block_count);
    for (size_t index = 0; index < wire.class_count; index++) {
        const auto &entry = wire.classes[index];
        printf("wire_class index=%zu raw=%zu alignment=%zu stride=%zu offset=%zu count=%zu\n", index, entry.raw_bytes, entry.alignment, entry.stride, entry.offset, entry.count);
    }
    SSL_CTX_free(ctx);
    printf("wire_unit_result failed=%d selftest63=pass whole_handshake_zero_claim=0\n", failed);
    return failed != 0;
}
