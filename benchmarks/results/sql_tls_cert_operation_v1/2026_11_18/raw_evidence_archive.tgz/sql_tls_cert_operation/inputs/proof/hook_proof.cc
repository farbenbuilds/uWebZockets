#include <openssl/bio.h>
#include <openssl/bytestring.h>
#include <openssl/err.h>
#include <openssl/mem.h>

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#include "crypto/mem_internal.h"
#include "allocation_scope.h"

#define REQUIRE(condition) do { if (!(condition)) return __LINE__; } while (0)

struct HookStorage {
    alignas(max_align_t) uint8_t buffers[16][2048];
    size_t sizes[16];
    bool active[16];
    size_t allocations;
    size_t releases;
    size_t size_queries;
    size_t domain_attempts;
    bool failed;
};

// Test-only weak-hook ABI has no context argument and requires this process singleton.
static HookStorage *hook_storage;

extern "C" void *OPENSSL_memory_alloc(size_t size)
{
    if (size > 2048 || hook_storage == nullptr) return nullptr;
    for (size_t index = 0; index < 16; index++) {
        if (hook_storage->active[index]) continue;
        hook_storage->active[index] = true;
        hook_storage->sizes[index] = size;
        hook_storage->allocations++;
        memset(hook_storage->buffers[index], 0xa5, 2048);
        return hook_storage->buffers[index];
    }
    hook_storage->failed = true;
    return nullptr;
}

extern "C" void OPENSSL_memory_free(void *pointer)
{
    for (size_t index = 0; index < 16; index++) {
        if (hook_storage->buffers[index] != pointer) continue;
        if (!hook_storage->active[index]) hook_storage->failed = true;
        memset(pointer, 0, hook_storage->sizes[index]);
        hook_storage->active[index] = false;
        hook_storage->releases++;
        return;
    }
    hook_storage->failed = true;
}

extern "C" size_t OPENSSL_memory_get_size(void *pointer)
{
    hook_storage->size_queries++;
    for (size_t index = 0; index < 16; index++) {
        if (hook_storage->buffers[index] == pointer && hook_storage->active[index]) {
            return hook_storage->sizes[index];
        }
    }
    hook_storage->failed = true;
    return 0;
}

static void *rejected_allocate(void *context, size_t, size_t)
{
    static_cast<HookStorage *>(context)->domain_attempts++;
    return nullptr;
}

static void rejected_release(void *context, void *, size_t, size_t)
{
    static_cast<HookStorage *>(context)->failed = true;
}

static int check_hooks(HookStorage *storage)
{
    const OPENSSL_ALLOCATION_DOMAIN domain = {storage, rejected_allocate, rejected_release};
    REQUIRE(OPENSSL_malloc_with_domain(13, &domain) == nullptr);
    REQUIRE(OPENSSL_malloc_with_domain(0, &domain) == nullptr);
    REQUIRE(storage->domain_attempts == 0);
    CBB owned;
    REQUIRE(!CBB_init_with_domain(&owned, 0, &domain));
    REQUIRE(!CBB_add_u8(&owned, 1));
    CBB_cleanup(&owned);
    REQUIRE(storage->domain_attempts == 0);

    auto *ordinary = static_cast<uint8_t *>(OPENSSL_malloc(19));
    REQUIRE(ordinary != nullptr);
    memset(ordinary, 0x87, 19);
    REQUIRE(bssl::GetAllocationDomain(ordinary) == nullptr);
    auto *grown = static_cast<uint8_t *>(OPENSSL_realloc(ordinary, 29));
    REQUIRE(grown != nullptr);
    for (size_t index = 0; index < 19; index++) REQUIRE(grown[index] == 0x87);
    OPENSSL_free(grown);

    CBB root, child;
    REQUIRE(CBB_init(&root, 0));
    REQUIRE(CBB_add_asn1(&root, &child, CBS_ASN1_SET));
    for (size_t value = 5; value > 0; value--) REQUIRE(CBB_add_asn1_uint64(&child, value));
    size_t before = storage->allocations;
    REQUIRE(CBB_flush_asn1_set_of(&child));
    REQUIRE(storage->allocations == before + 2);
    uint8_t *output = nullptr;
    size_t size = 0;
    REQUIRE(CBB_finish(&root, &output, &size));
    const uint8_t expected[] = {0x31, 15, 2, 1, 1, 2, 1, 2, 2, 1, 3, 2, 1, 4, 2, 1, 5};
    REQUIRE(size == sizeof(expected) && memcmp(output, expected, size) == 0);
    OPENSSL_free(output);
    CBB_cleanup(&root);
    REQUIRE(storage->allocations == storage->releases && !storage->failed);

    BIO_PAIR_STORAGE_REQUIREMENTS requirements = {};
    const size_t old_allocations = storage->allocations;
    const size_t old_releases = storage->releases;
    const size_t old_queries = storage->size_queries;
    ERR_clear_error();
    OPENSSL_PUT_ERROR(CRYPTO, ERR_R_MALLOC_FAILURE);
    const uint32_t old_error = ERR_peek_error();
    REQUIRE(old_error != 0);
    uwz_alloc_begin();
    REQUIRE(BIO_pair_storage_requirements(32768, 32768, &requirements));
    REQUIRE(requirements.bytes == 66016 && requirements.alignment == alignof(max_align_t));
    BIO_PAIR_STORAGE_REQUIREMENTS overflow = {19, 73};
    REQUIRE(!BIO_pair_storage_requirements(SIZE_MAX, 32768, &overflow));
    REQUIRE(overflow.bytes == 0 && overflow.alignment == 0 && ERR_peek_error() == old_error);
    uwz_alloc_end();
    REQUIRE(uwz_all_c_zero());
    REQUIRE(ERR_get_error() == old_error && ERR_get_error() == 0);
    REQUIRE(storage->allocations == old_allocations && storage->releases == old_releases &&
            storage->size_queries == old_queries && storage->domain_attempts == 0);
    BIO *first = reinterpret_cast<BIO *>(1), *second = reinterpret_cast<BIO *>(1);
    uwz_alloc_begin();
    REQUIRE(!BIO_new_bio_pair_with_domain(&first, 8, &second, 5, &domain));
    uwz_alloc_end();
    REQUIRE(uwz_all_c_zero());
    REQUIRE(first == nullptr && second == nullptr && storage->domain_attempts == 0);
    REQUIRE(storage->allocations == old_allocations && storage->releases == old_releases &&
            storage->size_queries == old_queries);
    REQUIRE(BIO_new_bio_pair(&first, 8, &second, 5));
    const uint8_t input[] = {17, 221, 0, 91};
    uint8_t result[sizeof(input)] = {};
    REQUIRE(BIO_write(first, input, sizeof(input)) == 4);
    REQUIRE(BIO_read(second, result, sizeof(result)) == 4 && memcmp(input, result, sizeof(input)) == 0);
    BIO_free(first);
    BIO_free(second);
    REQUIRE(storage->allocations == old_allocations + 6 && storage->releases == old_releases + 6);
    REQUIRE(storage->allocations == storage->releases && !storage->failed);
    printf("full_weak_hook bio_query_valid_overflow_ERR_unchanged owned_factory_rejected all_C_zero PASS\n");
    return 0;
}

static int guarded_no_prefix_query(void)
{
    long page_size = sysconf(_SC_PAGESIZE);
    REQUIRE(page_size > 0);
    size_t extent = static_cast<size_t>(page_size) * 2;
    auto *mapping = static_cast<uint8_t *>(mmap(nullptr, extent, PROT_READ | PROT_WRITE,
                                              MAP_PRIVATE | MAP_ANONYMOUS, -1, 0));
    REQUIRE(mapping != MAP_FAILED);
    REQUIRE(mprotect(mapping, page_size, PROT_NONE) == 0);
    const void *unprefixed = mapping + page_size;
    REQUIRE(bssl::GetAllocationDomain(unprefixed) == nullptr);
    REQUIRE(munmap(mapping, extent) == 0);
    return 0;
}

int main(void)
{
    HookStorage storage = {};
    hook_storage = &storage;
    OPENSSL_PUT_ERROR(CRYPTO, ERR_R_MALLOC_FAILURE);
    ERR_clear_error();
    int hooks = check_hooks(&storage);
    int guard = guarded_no_prefix_query();
    printf("ordinary_hook_unprefixed_realloc_child_set_parity result=%d alloc=%zu free=%zu size_queries=%zu owned_callbacks=%zu\n",
           hooks, storage.allocations, storage.releases, storage.size_queries, storage.domain_attempts);
    printf("hook_present_guard_page_private_query_no_prefix_read result=%d\n", guard);
    hook_storage = nullptr;
    return hooks != 0 || guard != 0;
}
