# D-10 certificate allocation operation prerequisite

This is an implementation component of existing frozen requirements R3/R4.
The required end state remains complete ownership of the observed 179-allocation
certificate path, its source-derived capacity, SDK integration and unchanged
full-interval proof. This component alone closes no checklist requirement.

## Purpose and scope

ASN.1 and X.509 deliberately clear some errors or accept an unsupported optional
key. Certificate ownership therefore needs a synchronous allocation-failure
status that survives error-queue changes. Its destination owner must remain
independent of the operation: foreign authentication graphs and shared anchors
keep their original owner, while verifier scratch belongs to the current call.

The permitted native change for this prerequisite is one internal header,
`crypto/cert_alloc_internal.h`. Existing public headers, ABI layouts, memory
functions, allocator representations and ordinary behavior remain unchanged.
No production TLS or SDK binder is added in this step. The complete native
capacity ledger remains a prerequisite to SDK storage allocation/admission.

## Internal data contract

Use named flat C++ data structs, free functions and explicit inputs:

- `CertOperation`: durable and scratch borrowed domain descriptors plus a
  sticky allocation-failure bit, initially false.
- `CertTarget`: pointer to the synchronous operation and an independently
  selected destination domain. An ordinary allocation target has a null owner.
  A null operation disables only failure tracking; a non-null owner still
  selects its domain, independently of the operation pointer.

These are private implementation data, not new public APIs. An operation can
reside on the stack and must never be stored in an allocation header, cached
certificate, key, callback descriptor, global or thread-local state. The raw
allocation header stores only the existing stable borrowed owner descriptor.
Caller descriptors and backing outlive the last native reference.

The initial C++ interface, in namespace `bssl`, is:

```cpp
struct CertOperation {
  const OPENSSL_ALLOCATION_DOMAIN *durable = nullptr;
  const OPENSSL_ALLOCATION_DOMAIN *scratch = nullptr;
  bool allocation_failed = false;
};
struct CertTarget {
  CertOperation *operation = nullptr;
  const OPENSSL_ALLOCATION_DOMAIN *owner = nullptr;
};
void *cert_alloc_nonzero(CertTarget target, size_t bytes);
void *cert_resize_nonzero(CertTarget target, void *ptr, size_t bytes);
void *cert_memdup(CertTarget target, const void *data, size_t bytes);
template <typename T, typename... Args>
T *cert_new(CertTarget target, Args &&...args);
```

Definitions may be inline in the single private header. Public native functions
and public structure sizes remain unchanged. Known internal callers construct
targets explicitly rather than consulting ambient state.

## Allocation helpers

Provide the minimum internal operations needed by the upcoming call tree:
positive-size allocation, positive-size resize, duplication and typed
construction. Names use snake_case.
Reuse existing domain-aware memory primitives; introduce no allocator backend,
owner router, registry, fallback path or speculative allocator framework.

Set the operation's sticky failure bit when a real allocation fails, including
failure before the user allocation callback: overflow, unavailable hooks or
the native allocation fault path. Never infer OOM from ERR queue contents or
turn a syntax/unsupported-algorithm result into allocation failure. A later
success does not clear a recorded failure.

Resize preserves an existing allocation's owner. The selected target supplies
the owner for a null/new destination; it does not migrate a non-null allocation.
A failed resize preserves the old pointer and contents. Allocation and resize
have an explicit positive-size precondition, enforced as an internal assertion.
Callers handle empty arrays before calling them. This avoids ambiguous tracked
ordinary `malloc(0)` results under full hooks. It does not change either public
native allocator's zero-size semantics. Do not route a positive-size request
through an untracked fallback to avoid a recorded failure.

`cert_memdup(_, _, 0)` follows pinned `OPENSSL_memdup`: return null without
allocating or recording failure. With a positive length its input points to
accessible source bytes. `cert_new<T>` has positive `sizeof(T)` and the existing
native alignment/constructor preconditions. The operation tracks positive
ordinary requests, owned requests and early native refusal uniformly.

Typed construction is genuinely polymorphic and limited to the audited native
data constructors used by this certificate path. Placement construction follows
the existing native idiom; it introduces no new allocation inside a constructor
and no persistent operation pointer. Existing native destruction/free uses the
raw owner's provenance and cleanses the complete raw extent.

## Verification and ownership

Verification owns new standalone proof sources and reuses the unchanged all-C
counter. Root owns the scratch build graph. The native implementation owner owns
only the new internal header. No one edits the immutable parent or root vendor.

Required proof cases cover ordinary and owned operation, separate durable and
scratch destinations, sticky OOM after later success/error clearing, failed
resize preservation, existing-owner retention, zero-size behavior, typed object
lifetime, interleaved owners, and final free after the operation has ended.
Empty duplication and the public native allocator's distinct zero-size behavior
are documented controls, not unsupported tracked ordinary zero-size requests.

Cold full-hook rejection must occur before domain callbacks and still set the
explicit failure status. Its ERR reporting may allocate a cold thread's ERR
state: record that real C traffic honestly. Separately warm ERR for measured
owned cases; all five C allocation fields must then remain zero in those owned
counted scopes. Allocating ordinary and cold controls stay explicit. Preserve
existing native memory/BIO/constructor/wire proofs.

Before implementation, retain a genuine missing-interface RED from these proof
inputs. Before acceptance, independently review source and proof behavior.
Dedicated smoke/security/sanitizer/fuzz campaigns remain user-deferred.

## Remaining current requirement

After this prerequisite, propagate explicit targets through the entire required
SQL certificate path and transactional caches. Complete native checked sizing,
normal/cancellation storage integration, all required compatibility/error and
final-reference checks, and the unchanged six original worker intervals.
Optional native contexts and generic policy/allocator work stay in the next
version list. No current allocation requirement or release gate is deferred.
