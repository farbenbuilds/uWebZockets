// Copyright 2026 The BoringSSL Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0

#ifndef OPENSSL_HEADER_CRYPTO_CERT_ALLOC_INTERNAL_H
#define OPENSSL_HEADER_CRYPTO_CERT_ALLOC_INTERNAL_H

#include <assert.h>
#include <stddef.h>
#include <utility>

#include "mem_internal.h"

BSSL_NAMESPACE_BEGIN

// The operation is borrowed for a synchronous call. Its domains can outlive it.
struct CertOperation {
  const OPENSSL_ALLOCATION_DOMAIN *durable = nullptr;
  const OPENSSL_ALLOCATION_DOMAIN *scratch = nullptr;
  bool allocation_failed = false;
};

// The destination can belong to a certificate created by another operation.
struct CertTarget {
  CertOperation *operation = nullptr;
  const OPENSSL_ALLOCATION_DOMAIN *owner = nullptr;
};

template <typename T>
inline T *cert_track_allocation(CertOperation *operation, T *result) {
  if (result == nullptr && operation != nullptr) {
    operation->allocation_failed = true;
  }
  return result;
}

inline void *cert_alloc_nonzero(CertTarget target, size_t bytes) {
  assert(bytes > 0);
  void *result = target.owner == nullptr
                     ? OPENSSL_malloc(bytes)
                     : OPENSSL_malloc_with_domain(bytes, target.owner);
  return cert_track_allocation(target.operation, result);
}

inline void *cert_resize_nonzero(CertTarget target, void *ptr, size_t bytes) {
  assert(bytes > 0);
  if (ptr == nullptr) {
    return cert_alloc_nonzero(target, bytes);
  }
  // OPENSSL_realloc preserves the allocation's original owner.
  return cert_track_allocation(target.operation, OPENSSL_realloc(ptr, bytes));
}

inline void *cert_memdup(CertTarget target, const void *data, size_t bytes) {
  if (bytes == 0) {
    return nullptr;
  }
  void *result = cert_alloc_nonzero(target, bytes);
  if (result != nullptr) {
    OPENSSL_memcpy(result, data, bytes);
  }
  return result;
}

// Audited constructors must complete without allocating or throwing.
template <typename T, typename... Args>
T *cert_new(CertTarget target, Args &&...args) {
  // Ordinary OPENSSL_malloc offsets the malloc base by eight bytes.
  static_assert(alignof(T) <= 8 && alignof(T) <= alignof(max_align_t));
  T *result = NewWithDomain<T>(target.owner, std::forward<Args>(args)...);
  return cert_track_allocation(target.operation, result);
}

BSSL_NAMESPACE_END

#endif  // OPENSSL_HEADER_CRYPTO_CERT_ALLOC_INTERNAL_H
