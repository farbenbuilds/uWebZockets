# Cold ERR traffic predicate

The first ReleaseSafe runtime recorded this cold-hook result.

```text
cold_full_hook_refusal FAIL sticky=1 domain_alloc=0 domain_free=0 hook_alloc=0 hook_free=0 hook_size=0 malloc=0 calloc=2 realloc=0 free=0 bytes=984
```

BoringSSL's `OPENSSL_malloc_with_domain` rejects installed hooks and reports
`ERR_R_MALLOC_FAILURE` before its domain allocation callback in
`crypto/mem.cc`. The cold ERR path in `crypto/err/err.cc` obtains
`ERR_STATE`, and `crypto/thread_pthread.cc` obtains the thread-local slot
array when absent. The reviewed contract requires measuring that reporting
traffic without treating the cold scope as zero. The original proof
overspecified the libc operation kind by requiring a malloc event.
The instrumented build reported two calloc events. The cause of that
difference from the source-level calls was outside this proof.

The corrected proof requires a positive requested-byte count and at least
one malloc, calloc or realloc event. It preserves the null result, sticky
status and zero domain and weak-hook callback assertions, and still prints
all five counters. The original source and the first build log are retained.
The root agent owns the revised runtime build and rerun.
