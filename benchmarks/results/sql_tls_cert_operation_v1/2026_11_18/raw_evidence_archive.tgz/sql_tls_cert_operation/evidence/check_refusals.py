#!/usr/bin/env python3
"""Exercise restore refusals before output creation under both Python modes."""
import argparse
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys


def replace_file(path, data, mode):
    path.unlink()
    path.write_bytes(data)
    path.chmod(mode)


def copy_variant(source, work, name):
    target = work / name
    shutil.copytree(source, target, copy_function=os.link)
    return target


def prepare_cases(packet, native, sdk, zig, work):
    cases = {}

    def case(name, message, changed_input=None, output=None):
        changed_input = changed_input or {}
        expected_inputs = {"packet": packet, "native": native, "sdk": sdk, "zig": zig}
        cases[name] = (message, expected_inputs | changed_input, output or work / f"output_{name}")

    for name, file_name in [
        ("operation_header", "native_delta/crypto/cert_alloc_internal.h"),
        ("operation_proof", "proof/cert_alloc_operation_proof.cc"),
        ("contract", "allocation_operation_contract.md"),
        ("proof_builder", "build.zig"),
    ]:
        modified = copy_variant(packet, work, name)
        path = modified / "inputs" / file_name
        replace_file(path, path.read_bytes() + b"\n", stat.S_IMODE(path.stat().st_mode))
        case(name, "source hash differs", {"packet": modified})

    identity = copy_variant(packet, work, "draft_identity")
    identity_file = identity / "input_identity.json"
    replace_file(identity_file, b"[]\n", stat.S_IMODE(identity_file.stat().st_mode))
    case("input_identity", "package input identity differs", {"packet": identity})

    extra = copy_variant(packet, work, "package_extra")
    (extra / "inputs" / "unlisted").write_text("unlisted\n", encoding="utf-8")
    case("package_extra", "source file set differs", {"packet": extra})

    missing = copy_variant(packet, work, "package_missing")
    (missing / "inputs" / "proof" / "allocation_scope.c").unlink()
    case("package_missing", "source file set differs", {"packet": missing})

    linked = copy_variant(packet, work, "package_symlink")
    fixture = linked / "inputs" / "proof" / "cert_alloc_hook_proof.cc"
    fixture.unlink()
    fixture.symlink_to(packet / "inputs" / "proof" / fixture.name)
    case("package_symlink", "non-regular source", {"packet": linked})

    wrong_native = copy_variant(native, work, "native_tamper")
    native_file = wrong_native / "crypto" / "mem_internal.h"
    replace_file(native_file, native_file.read_bytes() + b"\n", stat.S_IMODE(native_file.stat().st_mode))
    case("native_tamper", "source hash differs", {"native": wrong_native})

    wrong_sdk = copy_variant(sdk, work, "sdk_tamper")
    builder = wrong_sdk / "builds" / "vendor" / "boringssl.zig"
    replace_file(builder, builder.read_bytes() + b"\n", stat.S_IMODE(builder.stat().st_mode))
    case("sdk_tamper", "source hash differs", {"sdk": wrong_sdk})

    wrong_mode = copy_variant(sdk, work, "sdk_mode")
    builder = wrong_mode / "builds" / "vendor" / "boringssl.zig"
    replace_file(builder, builder.read_bytes(), stat.S_IMODE(builder.stat().st_mode) ^ 0o010)
    case("sdk_mode", "source mode differs", {"sdk": wrong_mode})

    extra_sdk = copy_variant(sdk, work, "sdk_extra")
    (extra_sdk / "unlisted").write_text("unlisted\n", encoding="utf-8")
    case("sdk_extra", "source file set differs", {"sdk": extra_sdk})

    linked_sdk = work / "sdk_symlink"
    linked_sdk.symlink_to(sdk, target_is_directory=True)
    case("sdk_symlink", "source root is linked", {"sdk": linked_sdk})

    fake_zig = work / "wrong_zig"
    fake_zig.write_text("wrong compiler\n", encoding="utf-8")
    fake_zig.chmod(0o755)
    case("zig_identity", "Zig executable identity differs", {"zig": fake_zig})

    existing = work / "existing"
    existing.mkdir()
    (existing / "marker").write_text("preserve\n", encoding="utf-8")
    case("existing_output", "output already exists", output=existing)

    dangling = work / "dangling"
    dangling.symlink_to(work / "missing_target")
    case("dangling_output", "output already exists", output=dangling)

    case("overlapping_output", "output overlaps an input tree", output=packet / "overlap")
    return cases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ("packet", "native", "sdk", "zig", "work"):
        parser.add_argument(f"--{flag}", required=True, type=Path)
    args = parser.parse_args()
    work = args.work.resolve()
    work.mkdir(exist_ok=False)
    cases = prepare_cases(args.packet.resolve(), args.native.resolve(), args.sdk.resolve(), args.zig.resolve(), work)
    results = []
    for name, (expected, paths, output) in cases.items():
        before = os.path.lexists(output)
        for flags in ([], ["-O"]):
            command = [sys.executable, *flags, str(paths["packet"] / "restore.py"),
                       "--parent-native", str(paths["native"]), "--parent-sdk", str(paths["sdk"]),
                       "--output", str(output), "--zig", str(paths["zig"])]
            result = subprocess.run(command, check=False, capture_output=True, text=True)
            passed = result.returncode == 1 and expected in result.stderr and os.path.lexists(output) == before
            results.append({"case": name, "optimized": bool(flags), "command": command,
                            "expected_diagnostic": expected, "exit_code": result.returncode,
                            "stdout": result.stdout, "stderr": result.stderr, "passed": passed})
    unchanged = (work / "existing" / "marker").read_text(encoding="utf-8") == "preserve\n"
    unchanged = unchanged and (work / "dangling").readlink() == work / "missing_target"
    unchanged = unchanged and not (work / "missing_target").exists()
    report = {"complete": all(row["passed"] for row in results) and unchanged,
              "cases": len(cases), "runs": len(results), "existing_outputs_preserved": unchanged,
              "results": results}
    (work / "refusal_results.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if not report["complete"]:
        raise SystemExit("one or more malformed-input controls failed")
    print(f"Passed {len(results)} malformed-input controls across ordinary and optimized Python")


if __name__ == "__main__":
    main()
