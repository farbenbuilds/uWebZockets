# KeyUpdate retained-output wire verification

This directory contains verification only. The native proposal belongs to
`/tmp/uwz-pg-tls-ku-output-fixed-20261117`; its baseline is the prior complete
AEAD-context candidate. This verifier changed no native, repository, production
pin or protected vendor source. All measured binaries are the original Zig
0.16 Debug executables; any delivery-only stripping and ELF equivalence proof
remain Root-owned and separate from these measured identities.

## Primary RED/GREEN assertion

`key_update_witness.cc`, the original all-C counter and the build runner are
anchored in `baseline_frozen.json`. Both peers explicitly select each actual
TLS 1.3 suite through `SSL_CTX_set1_tls13_ciphers` with singleton protocol IDs
0x1301/0x1302/0x1303 and null flags. Successful API calls, both negotiated IDs,
TLS 1.3, CA trust and localhost verification are asserted.

Eight peer REQUESTED updates per suite carry exact 4096-byte application data
in both directions after every update. Response modes and client/server callback
counts are checked. Each run has 24 updates and 600 complete client SSL read/write
calls, including immediate error mapping. Existing record, incoming-handshake
and AEAD reservations run during startup in every variant. The new output
reservation is optional only for the reserved candidate.

| Variant | Per-update client read | Following app/response write | Strict exit |
| --- | --- | --- | --- |
| Prior AEAD candidate | 5 malloc/3 free/200 bytes | 0 malloc/2 free | 1 |
| New native candidate, output unreserved | same | same | 1 |
| New native candidate, output reserved | zero allocator operations | zero | 0 |

All 24 successful reserved updates count zero malloc, calloc, realloc, free and
requested bytes. Observe and strict runs finish all payloads and produce identical
raw operation/summary bytes. Baseline RED predates the native edit. The original
counter SHA-256 remains `afd763bd0dbda66b4e7ee5193bb5c6c785e79f9c6d8ddf2dd671911341cf66ac`;
its unchanged self-test requires 63 requested bytes.

## Bounded protocol matrix

`protocol_witness.cc` and `protocol_output_cases.cc.inc` contain eight accepted
case families for each suite, 24 rows per variant. Each variant records 3855
measured operations: 3843 SSL read/write calls, including nine zero-length
flush calls, plus twelve complete local `SSL_key_update` calls. Peer setup,
server operations, validation and logging remain outside accounting. Observer
callbacks themselves use fixed storage and comparisons without allocating.

All fifteen healthy reserved rows require zero counts in every measured phase:
reads, writes, local update preparation and zero-length flushes. Error rows do
not make that allocation claim. Baseline/new-unreserved summaries and operation
bytes are identical, including allocation counts; reserved variants preserve
all protocol, payload, callback, retry and error outcomes.

- Requested chains and pending-response coalescing retain the previous cases.
  Relative identities show the same three AEAD objects changing RX/TX/spare
  roles. Every outgoing complete five-byte KeyUpdate callback verifies those
  exact bytes already exist in separately owned pending plaintext storage.
  Across the matrix, 63 callbacks and old-key record-header observations prove
  synchronous copying and old active TX with a distinct borrowed candidate.
- Local REQUESTED updates alternate with peer REQUESTED updates. Both response
  directions and exact application data are verified. Local control preparation
  is metered separately instead of hiding it in peer work.
- A real 4096-byte client app record is partially written into BIO1024, then a
  peer request produces a new KeyUpdate flight. The original pending-write
  pointer/length remain unchanged. Retrying the original buffer delivers that
  old application record before any response KeyUpdate, then the response and
  new application record are accepted in order.
- With BIO capacity 17, a zero-length write stages a 27-byte KeyUpdate, writes
  17 bytes and leaves ten older ciphertext bytes in `write_buffer`. A second
  peer request queues another 27-byte flight behind them. The real server later
  accepts both KeyUpdates in order and the exact new payload. Logical source
  emptiness is not mistaken for transport completion.
- A changed-buffer retry after an older pending app record and queued response
  is rejected with `BAD_WRITE_RETRY`. Pending ownership, older ciphertext,
  queued flight bytes and BIO occupancy remain unchanged. That error row ends
  with cleanup; no error-recovery continuation is claimed.
- Existing actual encrypted excess-old-epoch and 33rd-consecutive-update error
  cases remain. Old RX/context bytes/traffic secret/sequence are captured after
  decryption but before preparation, preserved on read-hook rejection, and the
  same spare returns to its exact neutral representation. Sensitive transient
  snapshots are cleansed and never logged.

No client parser or cipher fields are staged. Private access is read-only state,
length, capacity and pointer observation. Native server record sealing is used
only for the deliberate malformed old-epoch input; ordinary update/backpressure
rows use public SSL APIs. Reserved plaintext/flight descriptors and data pointers
stay stable, with logical bounds 5/27 and physical capacities 8/40.

Zero-length semantics were checked against the pinned source before protocol
execution: successful requested-length-zero `SSL_write` returns zero, and its
immediate `SSL_get_error(ssl, 0)` is `SSL_ERROR_SYSCALL` (5) with an empty error
queue. The raw 0/5 tuple is retained, never replaced with NONE or classified as
a transport failure merely from that generic mapping. Six such successful flushes
and three negative WANT_WRITE flushes are observed. Exact peer processing,
empty/staged buffer state and baseline/candidate equivalence establish their
control outcome. Retry counts include negative WANT results only.

Transport scope is default BIO pairs with successful flush semantics, capacity
1024 or 17. There is no claim about recovery after a custom BIO_flush failure
once all flight bytes were already accepted. Direct offset/erasure/fault tests
belong to the separate helper/lifecycle experiment.

## Existing public controls

Each public variant retains twelve rows and 255 client calls. The source delta
adds the new startup option while keeping all earlier reservations enabled.
The verifier preserves prior requirements and strengthens the output-reserved
requested-read and following-write phases to require zero counts.

| Scenario | Baseline read malloc/free/bytes | Reserved read malloc/free/bytes |
| --- | --- | --- |
| Ticket-free app data | 0/0/0 | 0/0/0 |
| Two initially queued tickets, caching off | 12/12/1600 | 12/12/1600 |
| Peer NOT_REQUESTED update | 0/0/0 | 0/0/0 |
| Peer REQUESTED update | 5/3/200 | 0/0/0 |

The following response/app write changes from zero malloc/two frees to zero
allocator operations. These are synthetic TLS/BIO call counts, not PostgreSQL
query measurements or arbitrary later ticket issuance. Ticket/session and error
allocations remain separate work.

## Provenance and replay

Original measured Debug binary and linked archive identities are retained.
`native_source_sha256` in the original run records is a selected interface/AEAD
path subset, not a complete source inventory. `supplemental_source_identity.json`
adds the two output-delta implementation paths after verifying all exact linked
archives remain unchanged. The native experiment's full 8709-entry manifests
are authoritative for the complete source tree. No measured record is rewritten.

The self-relative prebuilt replay checks eight executable identities, requires
baseline/unreserved strict exits 1 and reserved exit 0, repeats the whole bounded
matrix and compares every operation/summary byte:

```sh
python3 replay_prebuilt.py --pki-tool /absolute/path/to/wt-tools --output /tmp/uwz-ku-output-wire-new-replay
```

Output must be absent and outside retained evidence. The hardened guard detects
a combined parent root through its restore helper and native handoff, rejecting
outputs inside any sibling subtree; standalone delivery falls back to guarding
its own tree. Five refusal checks cover existing output, standalone containment,
wrong helper and two packaged-parent paths. The pinned PKI helper requires no
network; owned fixture PKI is removed in finally. `replay_validation/` records
one complete successful replay. No compiler, native archives or source are
needed by that prebuilt path.

`compare_results.py` repeats comparisons offline. Source runners are
`run_key_updates.py NATIVE_ROOT PKI_HELPER NEW_OUTPUT` and `build_run.py` with
`--fixture protocol` or `--fixture control`; add `--reserved` for output storage.
They use complete matching native Debug libraries and Zig 0.16, record commands,
actual hashes and statuses, and refuse overwriting outputs. Python is evidence
tooling, not a new project build requirement. No duplicate preliminary binaries,
objects, native archives, private keys or certificates are in the payload.

Strict PostgreSQL allocation compliance and production integration remain open.
No PostgreSQL exception, FIPS validation or release completion is claimed.
Dedicated smoke/security/sanitizer/fuzz/scan campaigns were not run.
