#include <openssl/err.h>
#include <openssl/ssl.h>
#include <openssl/ssl3.h>
#include <openssl/x509_vfy.h>
#include <openssl/mem.h>
#include "ssl/internal.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK(value) do { if (!(value)) fail(__LINE__, #value); } while (0)

extern "C" {
void uwz_alloc_begin(void);
void uwz_alloc_end(void);
uint64_t uwz_alloc_malloc_calls(void);
uint64_t uwz_alloc_calloc_calls(void);
uint64_t uwz_alloc_realloc_calls(void);
uint64_t uwz_alloc_free_calls(void);
uint64_t uwz_alloc_requested_bytes(void);
int uwz_alloc_self_test(void);
}

struct allocation_counts {
    uint64_t malloc_calls;
    uint64_t calloc_calls;
    uint64_t realloc_calls;
    uint64_t free_calls;
    uint64_t requested_bytes;
};

struct measured_result {
    int result;
    int error;
    allocation_counts counts;
};

struct protocol_observations {
    unsigned int received_tickets;
    unsigned int received_key_updates;
    unsigned int sent_key_updates;
    uint8_t received_modes[96];
    uint8_t sent_modes[96];
    bool invalid;
    bool watch_sealing;
    const bssl::SSLAEADContext *expected_old_write;
    unsigned int old_key_headers;
    unsigned int borrowed_headers;
    bool capture_read_state;
    const bssl::SSLAEADContext *old_read;
    uint8_t old_read_bytes[sizeof(bssl::SSLAEADContext)];
    uint8_t old_secret[SSL_MAX_MD_SIZE];
    size_t old_secret_length;
    uint64_t old_read_sequence;
    unsigned int copied_messages;
    const BUF_MEM *reserved_plaintext;
    const BUF_MEM *reserved_flight;
    const char *reserved_plaintext_data;
    const char *reserved_flight_data;
};

struct tls_pair {
    SSL_CTX *client_context;
    SSL_CTX *server_context;
    SSL *client;
    SSL *server;
    protocol_observations client_observations;
    protocol_observations server_observations;
};

struct phase_result {
    allocation_counts counts;
    unsigned int operations;
    unsigned int retries;
};

static void fail(int line, const char *expression)
{
    fprintf(stderr, "check failed at line %d: %s\n", line, expression);
    ERR_print_errors_fp(stderr);
    abort();
}

static allocation_counts snapshot_counts(void)
{
    return {uwz_alloc_malloc_calls(), uwz_alloc_calloc_calls(),
            uwz_alloc_realloc_calls(), uwz_alloc_free_calls(),
            uwz_alloc_requested_bytes()};
}

static void add_counts(allocation_counts *total, allocation_counts value)
{
    total->malloc_calls += value.malloc_calls;
    total->calloc_calls += value.calloc_calls;
    total->realloc_calls += value.realloc_calls;
    total->free_calls += value.free_calls;
    total->requested_bytes += value.requested_bytes;
}

static bool retry_error(int error)
{
    return error == SSL_ERROR_WANT_READ || error == SSL_ERROR_WANT_WRITE;
}

static void check_peer_result(SSL *ssl, int result)
{
    if (result > 0) return;
    CHECK(retry_error(SSL_get_error(ssl, result)));
}

static void observe_message(int is_write, int version, int content_type,
                            const void *buffer, size_t length, SSL *ssl,
                            void *argument)
{
    protocol_observations *observed = static_cast<protocol_observations *>(argument);
    const bssl::SSLImpl *impl = bssl::FromOpaque(ssl);
    if (is_write && content_type == SSL3_RT_HEADER && observed->watch_sealing) {
        if (length != 5 || impl->s3->aead_write_ctx.get() != observed->expected_old_write)
            observed->invalid = true;
        observed->old_key_headers++;
#if defined(UWZ_RESERVE_KEY_UPDATE_CONTEXT)
        if (impl->s3->key_update_spare || !impl->s3->key_update_candidate ||
            impl->s3->key_update_candidate == impl->s3->aead_write_ctx.get() ||
            impl->s3->key_update_candidate == impl->s3->aead_read_ctx.get())
            observed->invalid = true;
        else observed->borrowed_headers++;
#endif
    }
    if (content_type != SSL3_RT_HANDSHAKE || length == 0) return;
    const uint8_t *bytes = static_cast<const uint8_t *>(buffer);
    if (bytes[0] != SSL3_MT_KEY_UPDATE) return;
    if (version != TLS1_3_VERSION || length != 5 || bytes[1] != 0 ||
        bytes[2] != 0 || bytes[3] != 1 || bytes[4] > 1) {
        observed->invalid = true;
        return;
    }
    if (!is_write && observed->capture_read_state) {
        observed->old_read = impl->s3->aead_read_ctx.get();
        memcpy(observed->old_read_bytes, observed->old_read, sizeof(observed->old_read_bytes));
        observed->old_secret_length = impl->s3->read_traffic_secret.size();
        memcpy(observed->old_secret, impl->s3->read_traffic_secret.data(), observed->old_secret_length);
        observed->old_read_sequence = impl->s3->read_sequence;
    }
    if (is_write) {
        const BUF_MEM *pending = impl->s3->pending_hs_data.get();
        if (!pending || pending->length != 5 || pending->data == buffer ||
            memcmp(pending->data, buffer, 5) != 0) observed->invalid = true;
        else observed->copied_messages++;
    }
    unsigned int *count = is_write ? &observed->sent_key_updates : &observed->received_key_updates;
    uint8_t *modes = is_write ? observed->sent_modes : observed->received_modes;
    if (*count == 96) {
        observed->invalid = true;
        return;
    }
    modes[(*count)++] = bytes[4];
}

static void prepare_pair(tls_pair *pair, const char *certificate,
                         const char *private_key, const char *ca,
                         unsigned int tickets, uint16_t suite)
{
    pair->client_context = SSL_CTX_new(TLS_method());
    pair->server_context = SSL_CTX_new(TLS_method());
    CHECK(pair->client_context && pair->server_context);
    CHECK(SSL_CTX_set1_tls13_ciphers(pair->client_context, &suite, nullptr, 1));
    CHECK(SSL_CTX_set1_tls13_ciphers(pair->server_context, &suite, nullptr, 1));
    CHECK(SSL_CTX_set_min_proto_version(pair->client_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_max_proto_version(pair->client_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_min_proto_version(pair->server_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_max_proto_version(pair->server_context, TLS1_3_VERSION));
    CHECK(SSL_CTX_set_num_tickets(pair->server_context, tickets));
    SSL_CTX_set_session_cache_mode(pair->client_context, SSL_SESS_CACHE_OFF);
    CHECK(SSL_CTX_get_session_cache_mode(pair->client_context) == SSL_SESS_CACHE_OFF);
    CHECK(SSL_CTX_sess_get_new_cb(pair->client_context) == nullptr);
    CHECK(SSL_CTX_use_certificate_chain_file(pair->server_context, certificate));
    CHECK(SSL_CTX_use_PrivateKey_file(pair->server_context, private_key,
                                     SSL_FILETYPE_PEM));
    CHECK(SSL_CTX_check_private_key(pair->server_context));
    CHECK(SSL_CTX_load_verify_locations(pair->client_context, ca, nullptr));
    SSL_CTX_set_verify(pair->client_context, SSL_VERIFY_PEER, nullptr);
    SSL_CTX_set_msg_callback(pair->client_context, observe_message);
    SSL_CTX_set_msg_callback_arg(pair->client_context, &pair->client_observations);
    SSL_CTX_set_msg_callback(pair->server_context, observe_message);
    SSL_CTX_set_msg_callback_arg(pair->server_context, &pair->server_observations);
    pair->client = SSL_new(pair->client_context);
    pair->server = SSL_new(pair->server_context);
    CHECK(pair->client && pair->server);
    CHECK(SSL_set_tlsext_host_name(pair->client, "localhost"));
    CHECK(SSL_set1_host(pair->client, "localhost"));
    SSL_set_connect_state(pair->client);
    SSL_set_accept_state(pair->server);
    BIO *client_bio = nullptr;
    BIO *server_bio = nullptr;
    CHECK(BIO_new_bio_pair(&client_bio, 1024, &server_bio, 1024));
    SSL_set_bio(pair->client, client_bio, client_bio);
    SSL_set_bio(pair->server, server_bio, server_bio);
    bool client_done = false;
    bool server_done = false;
    for (unsigned int i = 0; i < 10000 && (!client_done || !server_done); i++) {
        if (!client_done) {
            int result = SSL_do_handshake(pair->client);
            if (result == 1) client_done = true;
            else check_peer_result(pair->client, result);
        }
        if (!server_done) {
            int result = SSL_do_handshake(pair->server);
            if (result == 1) server_done = true;
            else check_peer_result(pair->server, result);
        }
    }
    CHECK(client_done && server_done);
    CHECK(SSL_version(pair->client) == TLS1_3_VERSION);
    CHECK(SSL_version(pair->server) == TLS1_3_VERSION);
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->client)) == suite);
    CHECK(SSL_CIPHER_get_protocol_id(SSL_get_current_cipher(pair->server)) == suite);
    CHECK(SSL_get_verify_result(pair->client) == X509_V_OK);
    CHECK(SSL_get0_peer_certificates(pair->client) != nullptr);
    CHECK(pair->client_observations.received_tickets == 0);
}

static measured_result measured_read(SSL *client, void *output, int length)
{
    uwz_alloc_begin();
    const int result = SSL_read(client, output, length);
    const int error = result > 0 ? SSL_ERROR_NONE : SSL_get_error(client, result);
    uwz_alloc_end();
    return {result, error, snapshot_counts()};
}

static measured_result measured_write(SSL *client, const void *input, int length)
{
    uwz_alloc_begin();
    const int result = SSL_write(client, input, length);
    const int error = result > 0 ? SSL_ERROR_NONE : SSL_get_error(client, result);
    uwz_alloc_end();
    return {result, error, snapshot_counts()};
}

static void record_operation(FILE *output, unsigned int round, const char *row,
                              const char *phase, measured_result operation,
                              const protocol_observations *observed,
                              phase_result *result)
{
    const allocation_counts count = operation.counts;
    fprintf(output, "%u,%s,%s,%u,%d,%d,%llu,%llu,%llu,%llu,%llu,%u,%u,%u\n",
            round, row, phase, result->operations, operation.result, operation.error,
            (unsigned long long)count.malloc_calls,
            (unsigned long long)count.calloc_calls,
            (unsigned long long)count.realloc_calls,
            (unsigned long long)count.free_calls,
            (unsigned long long)count.requested_bytes,
            observed->received_tickets, observed->received_key_updates,
            observed->sent_key_updates);
    add_counts(&result->counts, count);
    result->operations++;
    if (operation.result <= 0 && retry_error(operation.error)) result->retries++;
}

static phase_result read_payload(tls_pair *pair, const uint8_t *payload,
                                  int length, FILE *operations,
                                  unsigned int round, const char *row)
{
    uint8_t received[4096];
    CHECK(length == sizeof(received));
    bool written = false;
    int offset = 0;
    phase_result result{};
    for (unsigned int i = 0; i < 10000 && (!written || offset != length); i++) {
        if (!written) {
            const int sent = SSL_write(pair->server, payload, length);
            if (sent > 0) {
                CHECK(sent == length);
                written = true;
            } else check_peer_result(pair->server, sent);
        }
        if (offset == length) continue;
        const int remaining = length - offset;
        measured_result operation = measured_read(pair->client, received + offset,
                                                   remaining < 257 ? remaining : 257);
        record_operation(operations, round, row, "read", operation,
                          &pair->client_observations, &result);
        if (operation.result > 0) offset += operation.result;
        else CHECK(retry_error(operation.error));
    }
    CHECK(written && offset == length);
    CHECK(memcmp(received, payload, length) == 0);
    return result;
}

static phase_result write_reply(tls_pair *pair, const uint8_t *payload,
                                 int length, FILE *operations,
                                 unsigned int round, const char *row)
{
    uint8_t received[4096];
    CHECK(length == sizeof(received));
    bool written = false;
    int offset = 0;
    phase_result result{};
    for (unsigned int i = 0; i < 10000 && (!written || offset != length); i++) {
        if (!written) {
            measured_result operation = measured_write(pair->client, payload, length);
            record_operation(operations, round, row, "response_write", operation,
                              &pair->client_observations, &result);
            if (operation.result > 0) {
                CHECK(operation.result == length);
                written = true;
            } else CHECK(retry_error(operation.error));
        }
        if (offset == length) continue;
        const int remaining = length - offset;
        const int count = SSL_read(pair->server, received + offset,
                                   remaining < 257 ? remaining : 257);
        if (count > 0) offset += count;
        else check_peer_result(pair->server, count);
    }
    CHECK(written && offset == length);
    CHECK(memcmp(received, payload, length) == 0);
    return result;
}

static void print_counts(FILE *output, allocation_counts counts)
{
    fprintf(output, "{\"malloc\":%llu,\"calloc\":%llu,\"realloc\":%llu,\"free\":%llu,\"bytes\":%llu}",
            (unsigned long long)counts.malloc_calls,
            (unsigned long long)counts.calloc_calls,
            (unsigned long long)counts.realloc_calls,
            (unsigned long long)counts.free_calls,
            (unsigned long long)counts.requested_bytes);
}

struct context_pool {
    const bssl::SSLAEADContext *objects[3];
};

struct pool_ids {
    int read;
    int write;
    int spare;
};

struct protocol_result {
    phase_result reads;
    phase_result writes;
    unsigned int completed_updates;
    size_t client_received_bytes;
    size_t server_received_bytes;
    int terminal_error;
    uint32_t terminal_reason;
    bool read_hook_state_preserved;
    bool spare_recovered_clean;
    pool_ids trace[8];
    size_t trace_count;
    phase_result local_updates;
    phase_result zero_flushes;
    unsigned int zero_successes;
    unsigned int zero_would_block;
    bool pending_write_preserved;
    bool older_app_before_response;
    bool partial_old_key_update;
    bool changed_retry_rejected;
};

static void accumulate_phase(phase_result *total, phase_result phase)
{
    add_counts(&total->counts, phase.counts);
    total->operations += phase.operations;
    total->retries += phase.retries;
}

static void prepare_profile(tls_pair *pair, context_pool *pool)
{
    CHECK(SSL_reserve_record_buffers(pair->client));
    CHECK(SSL_reserve_client_post_handshake_buffer(pair->client));
#if defined(UWZ_RESERVE_KEY_UPDATE_CONTEXT)
    CHECK(SSL_reserve_key_update_context(pair->client));
    const bssl::SSLImpl *client = bssl::FromOpaque(pair->client);
    pool->objects[0] = client->s3->aead_read_ctx.get();
    pool->objects[1] = client->s3->aead_write_ctx.get();
    pool->objects[2] = client->s3->key_update_spare.get();
    CHECK(pool->objects[0] && pool->objects[1] && pool->objects[2]);
    CHECK(pool->objects[0] != pool->objects[1] && pool->objects[0] != pool->objects[2]);
    CHECK(pool->objects[1] != pool->objects[2]);
#if defined(UWZ_RESERVE_KEY_UPDATE_OUTPUT)
    CHECK(SSL_reserve_key_update_output_buffers(pair->client));
    protocol_observations *observed = &pair->client_observations;
    observed->reserved_plaintext = client->s3->pending_hs_data.get();
    observed->reserved_flight = client->s3->pending_flight.get();
    CHECK(observed->reserved_plaintext && observed->reserved_flight);
    observed->reserved_plaintext_data = observed->reserved_plaintext->data;
    observed->reserved_flight_data = observed->reserved_flight->data;
#endif
#else
    (void)pool;
#endif
}

static void inspect_output_storage(const tls_pair *pair)
{
#if defined(UWZ_RESERVE_KEY_UPDATE_OUTPUT)
    const bssl::SSLImpl *client = bssl::FromOpaque(pair->client);
    const protocol_observations *observed = &pair->client_observations;
    CHECK(client->s3->pending_hs_data.get() == observed->reserved_plaintext);
    CHECK(client->s3->pending_flight.get() == observed->reserved_flight);
    CHECK(observed->reserved_plaintext->data == observed->reserved_plaintext_data);
    CHECK(observed->reserved_flight->data == observed->reserved_flight_data);
    CHECK(observed->reserved_plaintext->max == 8 && observed->reserved_plaintext->length <= 5);
    CHECK(observed->reserved_flight->max == 40 && observed->reserved_flight->length <= 27);
    CHECK(client->s3->pending_flight_offset <= observed->reserved_flight->length);
    if (observed->reserved_flight->length == 0) CHECK(client->s3->pending_flight_offset == 0);
#else
    (void)pair;
#endif
}

static pool_ids inspect_pool(tls_pair *pair, const context_pool *pool)
{
    pool_ids ids{-1, -1, -1};
    inspect_output_storage(pair);
#if defined(UWZ_RESERVE_KEY_UPDATE_CONTEXT)
    const bssl::SSLImpl *client = bssl::FromOpaque(pair->client);
    CHECK(client->s3->key_update_spare && !client->s3->key_update_candidate);
    CHECK(bssl::SSLAEADContext::IsKeyUpdateSpare(client->s3->key_update_spare.get()));
    for (int i = 0; i < 3; i++) {
        if (client->s3->aead_read_ctx.get() == pool->objects[i]) ids.read = i;
        if (client->s3->aead_write_ctx.get() == pool->objects[i]) ids.write = i;
        if (client->s3->key_update_spare.get() == pool->objects[i]) ids.spare = i;
    }
    CHECK(ids.read >= 0 && ids.write >= 0 && ids.spare >= 0);
    CHECK(ids.read != ids.write && ids.read != ids.spare && ids.write != ids.spare);
#else
    (void)pair;
    (void)pool;
#endif
    return ids;
}

static void make_payload(uint8_t *payload, size_t length, uint16_t suite,
                          unsigned int update)
{
    for (size_t i = 0; i < length; i++)
        payload[i] = static_cast<uint8_t>(i * 11 + suite + update);
}

static void run_requested_chain(tls_pair *pair, const context_pool *pool,
                                 uint16_t suite, const char *name,
                                 FILE *operations, protocol_result *result)
{
    for (unsigned int update = 0; update < 8; update++) {
        protocol_observations *observed = &pair->client_observations;
        observed->expected_old_write = bssl::FromOpaque(pair->client)->s3->aead_write_ctx.get();
        observed->watch_sealing = true;
        CHECK(SSL_key_update(pair->server, SSL_KEY_UPDATE_REQUESTED));
        uint8_t payload[4096];
        make_payload(payload, sizeof(payload), suite, update);
        const phase_result reads = read_payload(pair, payload, sizeof(payload), operations, update, name);
        observed->watch_sealing = false;
        const phase_result writes = write_reply(pair, payload, sizeof(payload), operations, update, name);
        CHECK(observed->received_key_updates == update + 1);
        CHECK(observed->sent_key_updates == update + 1);
        CHECK(pair->server_observations.received_key_updates == update + 1);
        CHECK(observed->received_modes[update] == SSL_KEY_UPDATE_REQUESTED);
        CHECK(observed->sent_modes[update] == SSL_KEY_UPDATE_NOT_REQUESTED);
        CHECK(pair->server_observations.received_modes[update] == SSL_KEY_UPDATE_NOT_REQUESTED);
        CHECK(observed->old_key_headers == update + 1);
#if defined(UWZ_RESERVE_KEY_UPDATE_CONTEXT)
        CHECK(observed->borrowed_headers == update + 1);
#endif
        result->trace[result->trace_count++] = inspect_pool(pair, pool);
        accumulate_phase(&result->reads, reads);
        accumulate_phase(&result->writes, writes);
        result->completed_updates++;
        result->client_received_bytes += sizeof(payload);
        result->server_received_bytes += sizeof(payload);
    }
}

static measured_result read_no_payload(tls_pair *pair, const char *name,
                                        const char *phase, unsigned int update,
                                        FILE *operations, phase_result *total)
{
    uint8_t unused[257];
    const measured_result operation = measured_read(pair->client, unused, sizeof(unused));
    record_operation(operations, update, name, phase, operation,
                      &pair->client_observations, total);
    CHECK(operation.result <= 0);
    return operation;
}

static void flush_server_update(tls_pair *pair, int mode)
{
    CHECK(SSL_key_update(pair->server, mode));
    CHECK(SSL_write(pair->server, nullptr, 0) == 0);
}

static void run_coalesced_requests(tls_pair *pair, const context_pool *pool,
                                   uint16_t suite, const char *name,
                                   FILE *operations, protocol_result *result)
{
    protocol_observations *observed = &pair->client_observations;
    observed->expected_old_write = bssl::FromOpaque(pair->client)->s3->aead_write_ctx.get();
    observed->watch_sealing = true;
    for (unsigned int update = 0; update < 2; update++) {
        flush_server_update(pair, SSL_KEY_UPDATE_REQUESTED);
        const measured_result operation = read_no_payload(pair, name, "coalesced_read",
            update, operations, &result->reads);
        CHECK(retry_error(operation.error));
        CHECK(observed->received_key_updates == update + 1);
        CHECK(observed->sent_key_updates == 1);
        inspect_pool(pair, pool);
    }
    observed->watch_sealing = false;
    uint8_t payload[4096];
    make_payload(payload, sizeof(payload), suite, 0);
    accumulate_phase(&result->reads, read_payload(pair, payload, sizeof(payload), operations, 2, name));
    accumulate_phase(&result->writes, write_reply(pair, payload, sizeof(payload), operations, 2, name));
    CHECK(observed->old_key_headers == 1 && observed->sent_key_updates == 1);
    CHECK(pair->server_observations.received_key_updates == 1);
#if defined(UWZ_RESERVE_KEY_UPDATE_CONTEXT)
    CHECK(observed->borrowed_headers == 1);
#endif
    result->completed_updates = 2;
    result->client_received_bytes = sizeof(payload);
    result->server_received_bytes = sizeof(payload);
    result->trace[result->trace_count++] = inspect_pool(pair, pool);
}

static void run_excess_old_epoch(tls_pair *pair, const context_pool *pool,
                                 const char *name, FILE *operations,
                                 protocol_result *result)
{
#if defined(UWZ_RESERVE_KEY_UPDATE_CONTEXT)
    const bssl::SSLAEADContext *before_spare = bssl::FromOpaque(pair->client)->s3->key_update_spare.get();
    uint8_t neutral_spare[sizeof(bssl::SSLAEADContext)];
    CHECK(before_spare && bssl::SSLAEADContext::IsKeyUpdateSpare(before_spare));
    memcpy(neutral_spare, before_spare, sizeof(neutral_spare));
#endif
    const uint8_t messages[] = {SSL3_MT_KEY_UPDATE, 0, 0, 1, 0,
                               SSL3_MT_KEY_UPDATE, 0, 0, 1, 0};
    uint8_t encrypted[128];
    size_t encrypted_length = 0;
    CHECK(bssl::tls_seal_record(bssl::FromOpaque(pair->server), encrypted,
        &encrypted_length, sizeof(encrypted), SSL3_RT_HANDSHAKE, messages, sizeof(messages)));
    CHECK(BIO_write(SSL_get_wbio(pair->server), encrypted, static_cast<int>(encrypted_length)) ==
          static_cast<int>(encrypted_length));
    pair->client_observations.capture_read_state = true;
    const measured_result operation = read_no_payload(pair, name, "excess_read", 0,
                                                        operations, &result->reads);
    CHECK(operation.error == SSL_ERROR_SSL);
    const uint32_t error = ERR_peek_last_error();
    CHECK(ERR_GET_REASON(error) == SSL_R_EXCESS_HANDSHAKE_DATA);
    const bssl::SSLImpl *client = bssl::FromOpaque(pair->client);
    protocol_observations *observed = &pair->client_observations;
    CHECK(observed->received_key_updates == 1 && observed->old_read);
    CHECK(client->s3->aead_read_ctx.get() == observed->old_read);
    CHECK(CRYPTO_memcmp(client->s3->aead_read_ctx.get(), observed->old_read_bytes,
                        sizeof(observed->old_read_bytes)) == 0);
    CHECK(client->s3->read_traffic_secret.size() == observed->old_secret_length);
    CHECK(CRYPTO_memcmp(client->s3->read_traffic_secret.data(), observed->old_secret,
                        observed->old_secret_length) == 0);
    CHECK(client->s3->read_sequence == observed->old_read_sequence);
    result->read_hook_state_preserved = true;
    result->terminal_error = operation.error;
    result->terminal_reason = (static_cast<uint32_t>(ERR_GET_LIB(error)) << 24) |
        static_cast<uint32_t>(ERR_GET_REASON(error));
#if defined(UWZ_RESERVE_KEY_UPDATE_CONTEXT)
    inspect_pool(pair, pool);
    CHECK(client->s3->key_update_spare.get() == before_spare);
    CHECK(CRYPTO_memcmp(before_spare, neutral_spare, sizeof(neutral_spare)) == 0);
    OPENSSL_cleanse(neutral_spare, sizeof(neutral_spare));
    result->spare_recovered_clean = true;
#else
    (void)pool;
#endif
    OPENSSL_cleanse(observed->old_read_bytes, sizeof(observed->old_read_bytes));
    OPENSSL_cleanse(observed->old_secret, sizeof(observed->old_secret));
}

static void run_consecutive_limit(tls_pair *pair, const context_pool *pool,
                                  const char *name, FILE *operations,
                                  protocol_result *result)
{
    for (unsigned int update = 0; update < 33; update++) {
        flush_server_update(pair, SSL_KEY_UPDATE_NOT_REQUESTED);
        const measured_result operation = read_no_payload(pair, name, "limit_read", update,
                                                            operations, &result->reads);
        CHECK(pair->client_observations.received_key_updates == update + 1);
        if (update != 32) {
            CHECK(retry_error(operation.error));
            result->completed_updates++;
            inspect_pool(pair, pool);
            continue;
        }
        CHECK(operation.error == SSL_ERROR_SSL);
        const uint32_t error = ERR_peek_last_error();
        CHECK(ERR_GET_REASON(error) == SSL_R_TOO_MANY_KEY_UPDATES);
        result->terminal_error = operation.error;
        result->terminal_reason = (static_cast<uint32_t>(ERR_GET_LIB(error)) << 24) |
            static_cast<uint32_t>(ERR_GET_REASON(error));
        inspect_pool(pair, pool);
    }
}

#include "protocol_output_cases.cc.inc"

static void run_protocol_case(uint16_t suite, unsigned int scenario,
                              const char *certificate, const char *private_key,
                              const char *ca, FILE *operations, FILE *summary)
{
    static const char *names[] = {"requested_chain", "coalesced_requests",
        "excess_old_epoch", "consecutive_limit", "local_alternating",
        "older_application_write", "older_key_update_write", "changed_buffer_retry"};
    const char *cipher_name = suite == 0x1301 ? "aes_128_gcm" :
        suite == 0x1302 ? "aes_256_gcm" : "chacha20_poly1305";
    char name[80];
    CHECK(snprintf(name, sizeof(name), "%s_%s", cipher_name, names[scenario]) > 0);
    tls_pair pair{};
    prepare_pair(&pair, certificate, private_key, ca, 0, suite);
    if (scenario == 6) {
        BIO *client_bio = nullptr, *server_bio = nullptr;
        CHECK(BIO_new_bio_pair(&client_bio, 17, &server_bio, 17));
        SSL_set_bio(pair.client, client_bio, client_bio);
        SSL_set_bio(pair.server, server_bio, server_bio);
    }
    context_pool pool{};
    prepare_profile(&pair, &pool);
    inspect_pool(&pair, &pool);
    protocol_result result{};
    if (scenario == 0) run_requested_chain(&pair, &pool, suite, name, operations, &result);
    if (scenario == 1) run_coalesced_requests(&pair, &pool, suite, name, operations, &result);
    if (scenario == 2) run_excess_old_epoch(&pair, &pool, name, operations, &result);
    if (scenario == 3) run_consecutive_limit(&pair, &pool, name, operations, &result);
    if (scenario == 4) run_local_alternating(&pair, &pool, suite, name, operations, &result);
    if (scenario == 5 || scenario == 7) run_older_application(&pair, &pool, suite, name, operations, &result, scenario == 7);
    if (scenario == 6) run_older_key_update(&pair, &pool, suite, name, operations, &result);
    CHECK(!pair.client_observations.invalid && !pair.server_observations.invalid);
    CHECK(pair.client_observations.copied_messages == pair.client_observations.sent_key_updates);
#if defined(UWZ_RESERVE_KEY_UPDATE_OUTPUT)
    const bool reserved = true;
#else
    const bool reserved = false;
#endif
    fprintf(summary, "{\"suite\":%u,\"scenario\":\"%s\",\"reserved\":%s,\"tls13_verified\":true,\"hostname_verified\":true,\"client_negotiated_suite\":%u,\"server_negotiated_suite\":%u,\"completed_updates\":%u,\"client_received_bytes\":%zu,\"server_received_bytes\":%zu,\"payloads_exact\":true,\"client_received_key_updates\":%u,\"client_sent_key_updates\":%u,\"server_received_key_updates\":%u,\"old_key_sealing_headers\":%u,\"borrowed_candidate_headers\":%u,\"read_hook_state_preserved\":%s,\"spare_recovered_clean\":%s,\"terminal_error\":%d,\"terminal_reason\":%u,\"read_operations\":%u,\"read_retries\":%u,\"write_operations\":%u,\"write_retries\":%u,\"pool_trace\":[",
        suite, names[scenario], reserved ? "true" : "false", suite, suite,
        result.completed_updates, result.client_received_bytes, result.server_received_bytes,
        pair.client_observations.received_key_updates, pair.client_observations.sent_key_updates,
        pair.server_observations.received_key_updates, pair.client_observations.old_key_headers,
        pair.client_observations.borrowed_headers, result.read_hook_state_preserved ? "true" : "false",
        result.spare_recovered_clean ? "true" : "false", result.terminal_error, result.terminal_reason,
        result.reads.operations, result.reads.retries, result.writes.operations, result.writes.retries);
    for (size_t i = 0; i < result.trace_count; i++) fprintf(summary, "%s[%d,%d,%d]",
        i ? "," : "", result.trace[i].read, result.trace[i].write, result.trace[i].spare);
    fprintf(summary, "],\"copied_messages\":%u,\"output_storage_stable\":%s,\"zero_successes\":%u,\"zero_would_block\":%u,\"pending_write_preserved\":%s,\"older_app_before_response\":%s,\"partial_old_key_update\":%s,\"changed_retry_rejected\":%s,\"local_update_operations\":%u,\"zero_flush_operations\":%u,\"client_read\":",
        pair.client_observations.copied_messages, reserved ? "true" : "null",
        result.zero_successes, result.zero_would_block, result.pending_write_preserved ? "true" : "false",
        result.older_app_before_response ? "true" : "false", result.partial_old_key_update ? "true" : "false",
        result.changed_retry_rejected ? "true" : "false", result.local_updates.operations, result.zero_flushes.operations);
    print_counts(summary, result.reads.counts);
    fprintf(summary, ",\"client_write\":");
    print_counts(summary, result.writes.counts);
    fprintf(summary, ",\"local_update_counts\":");
    print_counts(summary, result.local_updates.counts);
    fprintf(summary, ",\"zero_flush_counts\":");
    print_counts(summary, result.zero_flushes.counts);
    fprintf(summary, "}\n");
    SSL_free(pair.client);
    SSL_free(pair.server);
    SSL_CTX_free(pair.client_context);
    SSL_CTX_free(pair.server_context);
}

int main(int argc, char **argv)
{
    CHECK(argc == 6);
    CHECK(uwz_alloc_self_test());
    FILE *operations = fopen(argv[4], "wx");
    FILE *summary = fopen(argv[5], "wx");
    CHECK(operations && summary);
    fprintf(operations, "update,scenario,phase,operation,result,error,malloc,calloc,realloc,free,bytes,received_tickets,received_key_updates,sent_key_updates\n");
    const uint16_t suites[] = {0x1301, 0x1302, 0x1303};
    for (uint16_t suite : suites) {
        for (unsigned int scenario = 0; scenario < 8; scenario++)
            run_protocol_case(suite, scenario, argv[1], argv[2], argv[3], operations, summary);
    }
    CHECK(fclose(operations) == 0 && fclose(summary) == 0);
    puts("PASS: 24 three-suite protocol rows; output retention, old-key ordering, real backpressure, retries and protocol errors");
    return 0;
}
