#!/usr/bin/env python3
"""Compile and run one control/wire fixture against a complete native build."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_root', type=Path)
    parser.add_argument('pki_helper', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--fixture', choices=['control', 'protocol'], default='control')
    parser.add_argument('--reserved', action='store_true')
    parser.add_argument('--zig', default='/tmp/zig-x86_64-linux-0.16.0/zig')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    native = args.native_root.resolve(strict=True)
    helper = args.pki_helper.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent output directory')
    if digest(helper) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('The retained PKI helper checksum differs')
    output.mkdir(mode=0o700)
    environment = dict(os.environ)
    environment['ZIG_GLOBAL_CACHE_DIR'] = '/tmp/uwz-zig-cache'
    commands = []
    source = base / (args.fixture + '_witness.cc')
    binary = output / (args.fixture + '_witness')
    archives = [native / 'native_out/lib/libssl.a', native / 'native_out/lib/libcrypto.a']
    native_paths = ['include/openssl/ssl.h', 'ssl/internal.h', 'ssl/ssl_lib.cc',
                    'ssl/s3_both.cc', 'ssl/ssl_buffer.cc', 'crypto/fipsmodule/tls/kdf.cc.inc',
                    'ssl/ssl_aead_ctx.cc', 'ssl/tls13_enc.cc', 'ssl/tls_method.cc',
                    'ssl/s3_pkt.cc', 'ssl/tls13_both.cc']
    provenance = {
        'fixture': args.fixture, 'reserved': args.reserved,
        'compiler': args.zig, 'optimization': 'Debug (-O0 -g)',
        'native_root': str(native),
        'native_archive_sha256': {path.name: digest(path) for path in archives},
        'native_source_sha256': {name: digest(native / 'boringssl' / name) for name in native_paths},
        'source_sha256': {source.name: digest(source), 'allocation_scope.c': digest(base / 'allocation_scope.c')},
        'pki_helper_sha256': digest(helper),
    }
    if args.fixture == 'protocol':
        provenance['source_sha256']['protocol_output_cases.cc.inc'] = digest(base / 'protocol_output_cases.cc.inc')
    (output / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')

    def run(command, name):
        with (output / (name + '.log')).open('wb') as stream:
            result = subprocess.run(command, cwd=output, env=environment,
                                    stdout=stream, stderr=subprocess.STDOUT)
        commands.append({'command': command, 'exit_code': result.returncode, 'log': name + '.log'})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode != 0:
            raise RuntimeError('Command failed: ' + name)

    pki = output / 'private_pki'
    complete = False
    try:
        run([args.zig, 'cc', '-std=c11', '-O0', '-g', '-fno-omit-frame-pointer',
             '-c', str(base / 'allocation_scope.c'), '-o', str(output / 'allocation_scope.o')], 'build-counter')
        command = [args.zig, 'c++', '-std=c++17', '-O0', '-g', '-fno-omit-frame-pointer',
                   '-Wall', '-Wextra', '-Werror', '-DBORINGSSL_IMPLEMENTATION', '-DUWZ_RESERVE_KEY_UPDATE_CONTEXT=1',
                   '-isystem', str(native / 'boringssl'),
                   '-isystem', str(native / 'boringssl/include')]
        if args.reserved:
            command.append('-DUWZ_RESERVE_KEY_UPDATE_OUTPUT=1')
        run([*command, str(source), str(output / 'allocation_scope.o'),
             *[str(path) for path in archives], '-o', str(binary)], 'build-witness')
        run([str(helper), 'pki', str(pki)], 'pki-metadata')
        run([str(binary), *[str(pki / name) for name in ['server.pem', 'server.key', 'ca.pem']],
             str(output / 'operations.csv'), str(output / 'summary.jsonl')], 'run')
        verifier = base / ('verify_controls.py' if args.fixture == 'control' else 'verify_protocol.py')
        command = [sys.executable, str(verifier), str(output)]
        if args.fixture == 'control':
            command.extend(['--operations', 'operations.csv', '--summary', 'summary.jsonl'])
            command.append('--key-update-reserved')
            if args.reserved:
                command.append('--key-update-output-reserved')
        run(command, 'verification')
        complete = True
    finally:
        if pki.exists():
            names = {path.name for path in pki.iterdir()}
            if names - {'ca.pem', 'server.pem', 'server.key'}:
                raise ValueError('Unexpected fixture PKI contents; refusing broad cleanup')
            for name in names:
                (pki / name).unlink()
            pki.rmdir()
        (output / 'result.json').write_text(json.dumps({
            'complete': complete, 'private_pki_removed': not pki.exists(),
            'binary_sha256': digest(binary) if binary.exists() else None,
        }, indent=2) + '\n')
    print('PASS: ' + args.fixture + (' reserved' if args.reserved else ' unreserved') + '; private PKI removed')


if __name__ == '__main__':
    main()
