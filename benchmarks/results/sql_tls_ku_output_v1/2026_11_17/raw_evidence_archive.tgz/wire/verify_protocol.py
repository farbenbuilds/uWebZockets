#!/usr/bin/env python3
"""Check bounded KeyUpdate output, exact retries and real peer outcomes."""
import argparse
import csv
import json
from pathlib import Path

SCENARIOS = ('requested_chain','coalesced_requests','excess_old_epoch','consecutive_limit',
             'local_alternating','older_application_write','older_key_update_write','changed_buffer_retry')
SUITES = (0x1301,0x1302,0x1303)
FIELDS = ('malloc','calloc','realloc','free','bytes')
READ_PHASES = frozenset(('read','coalesced_read','excess_read','limit_read'))
WRITE_PHASES = frozenset(('response_write','old_application_start','old_application_retry','changed_buffer_retry'))


def verify(directory):
    rows=[json.loads(line) for line in (directory/'summary.jsonl').read_text().splitlines()]
    operations=list(csv.DictReader((directory/'operations.csv').open()))
    assert [(r['suite'],r['scenario']) for r in rows]==[(s,n) for s in SUITES for n in SCENARIOS]
    checked=0
    for row in rows:
        suite=row['suite']; scenario=row['scenario']
        cipher_name='aes_128_gcm' if suite==0x1301 else 'aes_256_gcm' if suite==0x1302 else 'chacha20_poly1305'
        selected=[op for op in operations if op['scenario']==cipher_name+'_'+scenario]
        groups={
            'client_read':[op for op in selected if op['phase'] in READ_PHASES],
            'client_write':[op for op in selected if op['phase'] in WRITE_PHASES],
            'local_update_counts':[op for op in selected if op['phase']=='local_update'],
            'zero_flush_counts':[op for op in selected if op['phase']=='zero_flush']}
        assert sum(len(value) for value in groups.values())==len(selected)
        assert row['tls13_verified'] and row['hostname_verified'] and row['payloads_exact']
        assert row['client_negotiated_suite']==row['server_negotiated_suite']==suite
        assert len(groups['client_read'])==row['read_operations']
        assert len(groups['client_write'])==row['write_operations']
        assert len(groups['local_update_counts'])==row['local_update_operations']
        assert len(groups['zero_flush_counts'])==row['zero_flush_operations']
        for name,subset in groups.items():
            assert {field:sum(int(op[field]) for op in subset) for field in FIELDS}==row[name]
            assert all(int(op[field])>=0 for op in subset for field in FIELDS)
        for name,prefix in [('client_read','read'),('client_write','write')]:
            assert sum(int(op['result'])<0 and int(op['error']) in (2,3) for op in groups[name])==row[prefix+'_retries']
        assert sum(max(int(op['result']),0) for op in groups['client_read'])==row['client_received_bytes']
        assert sum(max(int(op['result']),0) for op in groups['client_write'])==row['server_received_bytes']
        assert all(int(op['result'])==1 and int(op['error'])==0 for op in groups['local_update_counts'])
        zero=groups['zero_flush_counts']
        assert sum(int(op['result'])==0 and int(op['error'])==5 for op in zero)==row['zero_successes']
        assert sum(int(op['result'])<0 and int(op['error']) in (2,3) for op in zero)==row['zero_would_block']
        assert len(zero)==row['zero_successes']+row['zero_would_block']
        assert all(int(op['error']) in (0,1,2,3) or (op['phase']=='zero_flush' and int(op['result'])==0 and int(op['error'])==5) for op in selected)
        assert row['copied_messages']==row['client_sent_key_updates']==row['old_key_sealing_headers']==row['borrowed_candidate_headers']
        assert all(sorted(ids)==[0,1,2] for ids in row['pool_trace'])
        healthy=scenario not in ('excess_old_epoch','consecutive_limit','changed_buffer_retry')
        assert row['terminal_error']==(0 if healthy else 1)
        assert (row['terminal_reason']!=0)==(not healthy)
        if row['reserved']:
            assert row['output_storage_stable'] is True
            if healthy:assert all(value==0 for name in groups for value in row[name].values())
        else:assert row['output_storage_stable'] is None
        if scenario=='requested_chain':
            assert row['completed_updates']==8 and row['client_received_bytes']==row['server_received_bytes']==32768
            assert row['client_received_key_updates']==row['client_sent_key_updates']==row['server_received_key_updates']==8
        elif scenario=='coalesced_requests':
            assert row['completed_updates']==2 and row['client_received_bytes']==row['server_received_bytes']==4096
            assert row['client_received_key_updates']==2 and row['client_sent_key_updates']==row['server_received_key_updates']==1
        elif scenario=='excess_old_epoch':
            assert row['read_hook_state_preserved'] and row['spare_recovered_clean']
            assert row['client_received_key_updates']==1 and row['client_sent_key_updates']==0
            assert row['client_received_bytes']==row['server_received_bytes']==0
        elif scenario=='consecutive_limit':
            assert row['completed_updates']==32 and row['client_received_key_updates']==33
            assert row['client_sent_key_updates']==0 and row['client_received_bytes']==row['server_received_bytes']==0
        elif scenario=='local_alternating':
            assert row['completed_updates']==8 and row['local_update_operations']==4
            assert row['client_received_bytes']==row['server_received_bytes']==32768
            assert row['client_received_key_updates']==row['client_sent_key_updates']==row['server_received_key_updates']==8
            assert row['zero_successes']==1 and row['zero_would_block']==0
        elif scenario=='older_application_write':
            assert row['pending_write_preserved'] and row['older_app_before_response']
            assert row['client_received_bytes']==4096 and row['server_received_bytes']==8192
            assert row['client_received_key_updates']==row['client_sent_key_updates']==row['server_received_key_updates']==1
        elif scenario=='older_key_update_write':
            assert row['partial_old_key_update'] and row['zero_successes']==row['zero_would_block']==1
            assert row['client_received_bytes']==8192 and row['server_received_bytes']==4096
            assert row['client_received_key_updates']==row['client_sent_key_updates']==row['server_received_key_updates']==2
        else:
            assert row['pending_write_preserved'] and row['changed_retry_rejected']
            assert row['client_received_bytes']==4096 and row['server_received_bytes']==0
            assert row['client_received_key_updates']==row['client_sent_key_updates']==1 and row['server_received_key_updates']==0
        checked+=len(selected)
    assert checked==len(operations)
    return {'rows_verified':len(rows),'operations_verified':checked,
        'actual_negotiated_suites':list(SUITES),'synchronous_exact_message_copy':True,
        'old_key_sealing_and_three_context_ownership':True,'actual_old_ciphertext_first_ordering':True,
        'raw_successful_zero_write_tuple':[0,5],'changed_retry_rejected_without_continuation_claim':True,
        'reserved_healthy_complete_call_counts_zero':True,
        'bio_scope':'default BIO pairs;17-byte or1024-byte capacity; no custom BIO_flush-failure recovery claim',
        'strict_postgresql_gate_closed':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',type=Path)
    args=parser.parse_args()
    print(json.dumps(verify(args.directory),indent=2))


if __name__=='__main__':main()
