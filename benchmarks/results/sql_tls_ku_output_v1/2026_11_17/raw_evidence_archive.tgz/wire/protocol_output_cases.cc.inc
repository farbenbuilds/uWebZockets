static measured_result measured_zero_flush(SSL *client)
{
    uwz_alloc_begin();
    const int value = SSL_write(client, nullptr, 0);
    const int error = SSL_get_error(client, value);
    uwz_alloc_end();
    CHECK(value <= 0);
    return {value, error, snapshot_counts()};
}

static void record_zero_flush(tls_pair *pair, const char *name, unsigned int step,
                              FILE *operations, protocol_result *result)
{
    const measured_result operation = measured_zero_flush(pair->client);
    record_operation(operations, step, name, "zero_flush", operation,
                      &pair->client_observations, &result->zero_flushes);
    if (operation.result == 0) {
        CHECK(operation.error == SSL_ERROR_SYSCALL && ERR_peek_error() == 0);
        result->zero_successes++;
    } else {
        CHECK(retry_error(operation.error));
        result->zero_would_block++;
    }
    inspect_output_storage(pair);
}

static void run_local_alternating(tls_pair *pair, const context_pool *pool,
                                  uint16_t suite, const char *name,
                                  FILE *operations, protocol_result *result)
{
    for (unsigned int update = 0; update < 8; update++) {
        uint8_t payload[4096];
        make_payload(payload, sizeof(payload), suite, update + 40);
        protocol_observations *observed = &pair->client_observations;
        observed->expected_old_write = bssl::FromOpaque(pair->client)->s3->aead_write_ctx.get();
        observed->watch_sealing = true;
        if (update % 2 == 0) {
            uwz_alloc_begin();
            const int value = SSL_key_update(pair->client, SSL_KEY_UPDATE_REQUESTED);
            uwz_alloc_end();
            const measured_result operation{value, value == 1 ? SSL_ERROR_NONE : SSL_ERROR_SSL, snapshot_counts()};
            record_operation(operations, update, name, "local_update", operation,
                              observed, &result->local_updates);
            CHECK(value == 1);
            observed->watch_sealing = false;
            accumulate_phase(&result->writes, write_reply(pair, payload, sizeof(payload), operations, update, name));
            accumulate_phase(&result->reads, read_payload(pair, payload, sizeof(payload), operations, update, name));
        } else {
            CHECK(SSL_key_update(pair->server, SSL_KEY_UPDATE_REQUESTED));
            accumulate_phase(&result->reads, read_payload(pair, payload, sizeof(payload), operations, update, name));
            observed->watch_sealing = false;
            accumulate_phase(&result->writes, write_reply(pair, payload, sizeof(payload), operations, update, name));
        }
        CHECK(observed->received_key_updates == update + 1 && observed->sent_key_updates == update + 1);
        CHECK(pair->server_observations.received_key_updates == update + 1);
        CHECK(observed->received_modes[update] == (update % 2 == 0 ? 0 : 1));
        CHECK(observed->sent_modes[update] == (update % 2 == 0 ? 1 : 0));
        result->trace[result->trace_count++] = inspect_pool(pair, pool);
        result->client_received_bytes += sizeof(payload);
        result->server_received_bytes += sizeof(payload);
        result->completed_updates++;
    }
    record_zero_flush(pair, name, 8, operations, result);
    CHECK(result->zero_successes == 1);
}

static void complete_original_write(tls_pair *pair, const uint8_t *payload,
                                    const char *name, FILE *operations,
                                    protocol_result *result)
{
    uint8_t received[4096];
    size_t count = 0;
    bool sent = false;
    for (unsigned int attempt = 0; attempt < 10000 && (!sent || count != sizeof(received)); attempt++) {
        if (!sent) {
            const measured_result operation = measured_write(pair->client, payload, sizeof(received));
            record_operation(operations, 1, name, "old_application_retry", operation,
                              &pair->client_observations, &result->writes);
            if (operation.result > 0) {
                CHECK(operation.result == sizeof(received));
                sent = true;
            } else CHECK(retry_error(operation.error));
        }
        if (count != sizeof(received)) {
            const size_t remaining = sizeof(received) - count;
            const int value = SSL_read(pair->server, received + count,
                                       static_cast<int>(remaining > 257 ? 257 : remaining));
            if (value > 0) count += static_cast<size_t>(value);
            else check_peer_result(pair->server, value);
        }
        inspect_output_storage(pair);
    }
    CHECK(sent && count == sizeof(received) && memcmp(received, payload, sizeof(received)) == 0);
    CHECK(pair->server_observations.received_key_updates == 0);
    result->server_received_bytes += sizeof(received);
    result->older_app_before_response = true;
}

static void run_older_application(tls_pair *pair, const context_pool *pool,
                                  uint16_t suite, const char *name,
                                  FILE *operations, protocol_result *result,
                                  bool changed_retry)
{
    uint8_t old_payload[4096], new_payload[4096], peer_payload[4096];
    make_payload(old_payload, sizeof(old_payload), suite, 20);
    make_payload(new_payload, sizeof(new_payload), suite, 21);
    make_payload(peer_payload, sizeof(peer_payload), suite, 22);
    const measured_result initial = measured_write(pair->client, old_payload, sizeof(old_payload));
    record_operation(operations, 0, name, "old_application_start", initial,
                      &pair->client_observations, &result->writes);
    CHECK(initial.result < 0 && initial.error == SSL_ERROR_WANT_WRITE);
    bssl::SSLImpl *client = bssl::FromOpaque(pair->client);
    CHECK(client->s3->pending_write.data() == old_payload && client->s3->pending_write.size() == sizeof(old_payload));
    CHECK(!client->s3->write_buffer.empty());
    pair->client_observations.expected_old_write = client->s3->aead_write_ctx.get();
    pair->client_observations.watch_sealing = true;
    CHECK(SSL_key_update(pair->server, SSL_KEY_UPDATE_REQUESTED));
    accumulate_phase(&result->reads, read_payload(pair, peer_payload, sizeof(peer_payload), operations, 0, name));
    pair->client_observations.watch_sealing = false;
    result->client_received_bytes += sizeof(peer_payload);
    CHECK(client->s3->pending_write.data() == old_payload && client->s3->pending_write.size() == sizeof(old_payload));
    CHECK(!client->s3->write_buffer.empty());
    CHECK(client->s3->pending_flight && client->s3->pending_flight->length == 27);
    CHECK(client->s3->pending_flight_offset == 0);
    result->pending_write_preserved = true;
    inspect_pool(pair, pool);
    if (changed_retry) {
        uint8_t old_ciphertext[8192], old_flight[27];
        const size_t cipher_length = client->s3->write_buffer.size();
        CHECK(cipher_length <= sizeof(old_ciphertext));
        memcpy(old_ciphertext, client->s3->write_buffer.data(), cipher_length);
        memcpy(old_flight, client->s3->pending_flight->data, sizeof(old_flight));
        const size_t bio_pending = BIO_ctrl_pending(SSL_get_rbio(pair->server));
        const measured_result operation = measured_write(pair->client, new_payload, sizeof(new_payload));
        record_operation(operations, 1, name, "changed_buffer_retry", operation,
                          &pair->client_observations, &result->writes);
        CHECK(operation.result < 0 && operation.error == SSL_ERROR_SSL);
        const uint32_t error = ERR_peek_last_error();
        CHECK(ERR_GET_REASON(error) == SSL_R_BAD_WRITE_RETRY);
        CHECK(client->s3->pending_write.data() == old_payload && client->s3->pending_write.size() == sizeof(old_payload));
        CHECK(client->s3->write_buffer.size() == cipher_length);
        CHECK(memcmp(old_ciphertext, client->s3->write_buffer.data(), cipher_length) == 0);
        CHECK(client->s3->pending_flight->length == sizeof(old_flight) && client->s3->pending_flight_offset == 0);
        CHECK(memcmp(old_flight, client->s3->pending_flight->data, sizeof(old_flight)) == 0);
        CHECK(BIO_ctrl_pending(SSL_get_rbio(pair->server)) == bio_pending);
        result->changed_retry_rejected = true;
        result->terminal_error = operation.error;
        result->terminal_reason = (static_cast<uint32_t>(ERR_GET_LIB(error)) << 24) | ERR_GET_REASON(error);
        inspect_pool(pair, pool);
        return;
    }
    complete_original_write(pair, old_payload, name, operations, result);
    accumulate_phase(&result->writes, write_reply(pair, new_payload, sizeof(new_payload), operations, 2, name));
    result->server_received_bytes += sizeof(new_payload);
    CHECK(pair->server_observations.received_key_updates == 1);
    CHECK(pair->server_observations.received_modes[0] == SSL_KEY_UPDATE_NOT_REQUESTED);
    CHECK(client->s3->pending_write.empty());
    inspect_pool(pair, pool);
    result->completed_updates = 1;
}

static void run_older_key_update(tls_pair *pair, const context_pool *pool,
                                 uint16_t suite, const char *name,
                                 FILE *operations, protocol_result *result)
{
    uint8_t payload[4096];
    for (unsigned int update = 0; update < 2; update++) {
        make_payload(payload, sizeof(payload), suite, update + 30);
        pair->client_observations.expected_old_write = bssl::FromOpaque(pair->client)->s3->aead_write_ctx.get();
        pair->client_observations.watch_sealing = true;
        CHECK(SSL_key_update(pair->server, SSL_KEY_UPDATE_REQUESTED));
        accumulate_phase(&result->reads, read_payload(pair, payload, sizeof(payload), operations, update, name));
        pair->client_observations.watch_sealing = false;
        result->client_received_bytes += sizeof(payload);
        inspect_pool(pair, pool);
        if (update == 0) {
            record_zero_flush(pair, name, 0, operations, result);
            CHECK(result->zero_would_block == 1);
            const bssl::SSLImpl *client = bssl::FromOpaque(pair->client);
            CHECK(client->s3->write_buffer.size() == 10 && client->s3->pending_write.empty());
            CHECK(!client->s3->key_update_pending);
            CHECK(!client->s3->pending_flight || client->s3->pending_flight->length == 0);
        }
    }
    const bssl::SSLImpl *client = bssl::FromOpaque(pair->client);
    CHECK(client->s3->write_buffer.size() == 10 && client->s3->pending_flight && client->s3->pending_flight->length == 27);
    CHECK(client->s3->pending_flight_offset == 0 && pair->server_observations.received_key_updates == 0);
    result->partial_old_key_update = true;
    make_payload(payload, sizeof(payload), suite, 32);
    accumulate_phase(&result->writes, write_reply(pair, payload, sizeof(payload), operations, 2, name));
    result->server_received_bytes += sizeof(payload);
    CHECK(pair->server_observations.received_key_updates == 2);
    CHECK(pair->server_observations.received_modes[0] == 0 && pair->server_observations.received_modes[1] == 0);
    record_zero_flush(pair, name, 3, operations, result);
    CHECK(result->zero_successes == 1 && result->zero_would_block == 1);
    result->completed_updates = 2;
    inspect_pool(pair, pool);
}
