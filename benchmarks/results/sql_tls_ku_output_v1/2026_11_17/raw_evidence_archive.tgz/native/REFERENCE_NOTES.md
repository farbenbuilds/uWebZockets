# Outgoing KeyUpdate reference scope

reference_map.before.txt and reference_map.final.txt retain the complete scoped
native ssl/ pending_hs_data/pending_flight reference inventories before and after
this proposal. The final map also includes the profile marker, captured bound
helper and borrowed-message adapter. Source content identity is recorded by the
full source inventories and provenance.json.

Reserved queueing rejects a partial flight before plaintext mutation. The seal
path keeps the original no-plaintext-owner and zero-flight-offset assertions;
the plaintext owner is temporarily moved out, then cleansed and restored empty
after an attempt, including failure. Ciphertext append checks arithmetic and its
logical limit before sealing, with no reserve/growth call in the reserved path.
Generic owned messages keep their owner until the synchronous Span implementation
has copied the complete message, invoked the existing callback and returned.

Logical plaintext is five bytes. Supported ordinary TLS 1.3 application contexts
give seal overhead 22 bytes (record header 5, inner content type 1, tag 16), so
ciphertext is at most 27 bytes. The captured cipher and actual seal overhead are
validated before use. Legal max_send_fragment values remain 512..16384; all can
hold the five-byte message. No fragment setter clamp was introduced. The fresh
BUF_MEM allocations round to eight and 40 data bytes.

An empty retained flight is treated as absent when considering queued work.
Successful direct BIO writes cleanse only their accepted prefix and advance the
existing offset. Staging copies the unsent tail to write_buffer before cleansing
it, then resets length and offset together. Existing write_buffer-first order,
pending-write retry spans and KeyUpdate uncorking on staging remain unchanged.

reference_map.bio_flush.txt retains exact primary source lines from the unchanged
crypto/bio/pair.cc. Its BIO_CTRL_FLUSH branch at lines 366-367 unconditionally
returns one. The ordinary in-memory BIO-pair witnesses therefore cannot reach
the inherited custom-BIO edge where tls_flush has offset equal to flight length,
BIO_flush fails, and a later different nonempty do_tls_write skips the empty-tail
reset before uncorking. Baseline and candidate have that edge; this proposal does
not repair it or claim arbitrary custom-BIO cross-operation failure recovery.
The limitation is distinct from supported short-write/backpressure progress on
the in-memory BIO pair, where unsent bytes remain owned and unchanged.
