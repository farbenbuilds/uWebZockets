# Reserved TLS 1.3 KeyUpdate output proposal

This isolated native proposal adds SSL_reserve_key_update_output_buffers. It
does not adopt a production dependency, pin or maintained fork. The baseline is
exact BoringSSL revision d3bf4795ad5b79d646cddf2fec687da5b9b502db with the preceding
record, fixed-HKDF, handshake-buffer and AEAD-context proposals. Their source
directories remain immutable. Input package identity is in input_provenance.json.

## Interface, ownership and bounds

The new independent API accepts an idle completed ordinary TLS 1.3 client, with
peer CA and hostname verification performed by its caller. Both active
application contexts must match a supported negotiated cipher. Initialization,
servers, DTLS, QUIC, shutdown/error, pending data/messages/writes/flights/updates
and borrowed AEAD candidates are rejected before allocation. Mutating SSL I/O is
serialized and non-reentrant; observation callbacks remain supported.

Two fresh BUF_MEM descriptors and their data allocations are prepared in local
temporaries. Both owners and key_update_output_cipher are committed only after
every allocation succeeds. Failure preserves previous ownership/configuration;
idle repeated calls allocate nothing. The single captured cipher pointer enables
the profile and binds its supported seal bound. SSL_clear frees and disables it.
Existing reservation APIs keep their own memory contracts and implementations.

The logical plaintext/ciphertext limits are 5/27 bytes. A fixed five-byte stack
CBB uses the existing u8/u24-child builders and flush, without transferring stack
storage into an owned Array. The synchronous borrowed-Span message implementation
copies the entire message before its callback; the original owned-Array entry
keeps its source alive through that call. The generic constructor is unchanged.
Record overhead is validated as 22 bytes for supported ordinary TLS 1.3
application contexts. Every legal later fragment setting 512..16384 fits the
message, so no new setter clamp is needed. Actual rounded data capacities are
eight and 40 bytes.

During sealing, plaintext ownership is temporarily borrowed so the original
sealing assertion still sees no pending plaintext owner. Occupied plaintext is
cleansed and its empty allocation restored after the attempt, including failure;
the pre-existing failure behavior consumes that plaintext. Flight arithmetic and
logical capacity are checked before sealing, with no heap growth fallback.
Partial-flight appends are rejected before plaintext mutation. Direct writes
cleanse only accepted prefixes, preserving unsent bytes. Staging copies a tail
to the bounded write buffer before cleansing it and resets length/offset together.
Older ciphertext, retry spans, KeyUpdate coalescing and uncork-on-staging retain
their existing order. Old-key sealing still precedes the AEAD-context swap.

REFERENCE_NOTES.md and the three reference maps record every relevant pointer,
length, offset and reset site plus the exact pinned BIO-pair flush behavior.
Custom-BIO cross-operation recovery after a flush failure remains an explicitly
inherited limit, rather than a new recovery claim. Ordinary BIO-pair short-write
and backpressure witnesses have an unconditional-success flush control.

## Source, build and measured evidence

Root authorized edits after a genuine allocation RED: 24 valid REQUESTED peer
updates across actual negotiated suites 0x1301/0x1302/0x1303, with exact
4096-byte bidirectional application data and response checks. Each client read
had five mallocs/three frees/200 requested bytes, followed by a write with two
frees. All 600 instrumented calls completed; observe exited zero and the unchanged
complete-call strict-zero assertion exited one with identical data rows. The
original 63-byte interposer self-test passed; generated private PKI was removed.

Exactly six current source files differ among 8709 entries: ssl.h, internal.h,
ssl_lib.cc, tls13_both.cc, s3_both.cc and s3_pkt.cc. The cumulative proposal changes
11 unique files from the exact original package. Full baseline/candidate
inventories, source_difference.json, all 11 candidate snapshots and provenance
retain exact identities. The frozen current patch SHA-256 is
4b0d518d821117ef6e6215ee501c4291eb1d53696ac302563eab49d1d0f9e9ad.

The full crypto library and all 38 SSL translation units were rebuilt together
through unchanged Zig 0.16.0 native source lists and a fresh local cache. The
process exited zero and all six build steps succeeded. build_commands.json
records exact commands and compiler/input hashes; build-native.log and
native_archives.json record output and archive identities. Debug archive hashes
depend on source paths and are provenance, not portable rebuild requirements.

The direct verification owner measures four C mallocs totaling 128 requested
bytes at output reservation and SSL3_STATE growing from 632 to 640 bytes,
including for connections that do not enable this profile. Across all three
suites its encoding/callback lifetime, logical/SIZE_MAX/capacity/partial-offset
guards, empty-buffer semantics, consumed-plaintext restoration and partial/full
transferred-region cleansing pass with zero direct heap calls. Separate real
sealer-success followed by forced-failure-return cases preserve the consumed,
clean empty plaintext owner without heap calls. That injected proof is separate
from ordinary accounting with the unchanged original all-C counter.

Root reports the primary final requested-update strict-zero witness exits zero;
the final unreserved control still exits one. The helper owner reports all 23
new lifecycle cases, the separate direct/sealer-failure checks and inherited
record, handshake-buffer, 1440-case HKDF and AEAD proofs passing, including the
prior 22 lifecycle cases.
Its 38 inherited fixture inputs remain byte-identical. Companion protocol,
backpressure and prebuilt replay matrices retain separate evidence owners.
Their commands, statuses and raw hashes are authoritative; this source payload
does not infer unreported results or replace their proof.

## Source restoration

The allowlist retains six baseline files, 11 cumulative candidate snapshots, the
minimal current patch, full inventories, build inputs/logs, provenance, reference
maps and source restoration evidence. Full native source copies, native archives,
compilation caches, private PKI and secrets are excluded.

From a copied payload directory, restore an exact original package into an absent
destination and use the native source-list builder:

    python3 restore_source.py /path/to/exact-original-package ./boringssl
    /path/to/zig build -Doptimize=Debug --cache-dir /tmp/new-ku-output-cache \
      -p native_out -j2 --summary all

The exact preceding AEAD proposal is accepted only with --source-kind aead. Both
modes verify the complete expected old file set and hashes and all 11 snapshots
before creating a new directory. Existing destinations are refused and cached
input is never modified. No patch executable is needed. Python prepares external
evidence and is not a library build dependency; all native SSL units build together.

restore_validation.json records a successful prior-AEAD restoration matching all
8709 final source entries, an existing-output rejection and rejection of AEAD
input presented as the original package. Owned generated sources in the assigned
workspace cache were removed. Successful original-package restoration in the
final copied delivery layout remains Root-owned and is not claimed here.

## Remaining scope

This addresses the bounded outgoing KeyUpdate storage component. Session tickets,
other errors/reconnects and lifetime paths, maintenance policy and production
integration remain separate work. SQL-ALLOC-002 and the strict PostgreSQL gate
remain open; there is no PostgreSQL exception, whole-lifetime allocation guarantee
or FIPS certification claim. Dedicated smoke/security/sanitizer/fuzz/scan campaigns
remain user-deferred.
