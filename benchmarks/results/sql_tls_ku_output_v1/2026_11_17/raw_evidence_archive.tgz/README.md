# Bounded client KeyUpdate output evidence

This isolated proposal adds SSL_reserve_key_update_output_buffers for an idle,
completed ordinary TLS 1.3 client. Startup prepares both descriptor/data pairs
before committing ownership: four C mallocs, 128 requested bytes. Logical
plaintext/ciphertext limits are 5/27 bytes; rounded data capacities are 8/40.
The extra captured-cipher pointer grows SSL3_STATE from 632 to 640 bytes.
Retained empty buffers and fixed CBB construction eliminate measured requested
response allocations. Production pins and PostgreSQL's full gate remain open.

After fresh extraction, verify and replay from this directory:

```sh
sha256sum -c files.sha256
python3 restore_pki_tool.py /absolute/path/to/uWebZockets
python3 helper/replay_prebuilt.py --pki-tool tools/wt-tools --output /tmp/uwz-ku-output-helper-final-replay
python3 wire/replay_prebuilt.py --pki-tool tools/wt-tools --output /tmp/uwz-ku-output-wire-final-replay
```

Choose absent directories outside this entire evidence tree. The restore tool
reads the checksum-pinned PKI executable from the existing independent-client
artifact named in external_inputs.json. No network, compiler, native archives
or objcopy is needed. Replay verifies current delivery identities and exact
outcomes, requires the baseline/unreserved allocation RED and reserved GREEN,
and removes owned private PKI. Root's successful complete copied-layout replays
are retained under root_checks/helper_delivery_replay and wire_delivery_replay:
78 helper commands and 15 wire commands with their expected statuses.

Measured programs use Zig Debug. Existing GNU objcopy --strip-debug removes
debug information from 21 delivery copies, reducing 380612944 to 105848016
bytes. Native/test sources, assertions, raw results and native build/link
inputs are unchanged. delivery_transform/HANDOFF.md and manifest.json preserve
original/current identities and verify allocated sections, entrypoint/ABI,
program layout, normalized load bytes and retained regular symbol tables.
Section-table coordinates and file hashes deliberately differ. Current
prebuilt_identity.json maps and delivery byte fields identify actual delivered
copies; original measured Debug maps and size fields remain preserved.
Both complete replays pass after transformation. Replay wrappers are unchanged
and protect the combined root, with their own-tree fallback for standalone use.

Primary proof: 24 requested peer updates across three actually negotiated
suites and 600 complete client calls per variant, all reserved counts zero.
Protocol proof: 24 rows/3855 measured operations per variant, fifteen healthy
zero-count rows, 63 copied-message/old-key observations and exact ordering/retry
semantics. Public controls have twelve rows/255 calls per build. Initial queued
tickets still count twelve mallocs/twelve frees/1600 bytes. Error paths also
remain open. BIO-pair flush always succeeds; no new arbitrary custom-BIO flush
failure recovery is claimed. The actual successful zero-write tuple is retained
separately from its known success outcome, as explained in wire/HANDOFF.md.

Direct checks cover three-suite encoding, output bounds, partial/full flush
cleansing and zero heap calls; three sealer-failure cases and 23 lifecycle
cases pass. All inherited record/HS/HKDF/AEAD proofs pass with 38 unchanged
fixture inputs. Read each producer HANDOFF for precise scope and original
measured provenance.

native/HANDOFF.md documents restoration from the exact original pinned package
or explicit prior-AEAD source input. Root verifies both against all 8709 final
entries, including existing-destination and wrong-mode refusals. Evidence is in
root_checks/source_restore_results.json. No patch executable is required.

Ordinary formatting leaves 314 source/build inputs unchanged. SQL/SQLite unit
tests pass 1158 cases with 24 live-PostgreSQL cases skipped without fixture
settings. Dedicated smoke, security, sanitizer, fuzz and scan campaigns remain
user-deferred. Ticket/session, error/reconnect, maintained native publication,
production integration and PostgreSQL's strict allocation gate remain work;
no PostgreSQL exception is approved.
