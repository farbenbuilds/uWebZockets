#!/usr/bin/env python3
"""Prove early replay refusal across combined evidence and standalone layouts."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pki-tool', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source = Path(__file__).resolve().parent / 'replay_prebuilt.py'
    tool = args.pki_tool.resolve(strict=True)
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Choose an absent guard-validation output')
    if sha(tool) != '531532ccc9bba8ae4d50df1fbe4418b78d53c2366e1cd529e4a0f0545003dcd9':
        raise ValueError('Guard cases require the valid retained PKI helper')
    output.mkdir(mode=0o700)
    probe = output / 'probe'
    owned_files = []
    rows = []

    def fixture(name, restore, native):
        root = probe / name
        helper = root / 'helper'
        helper.mkdir(parents=True)
        script = helper / 'replay_prebuilt.py'
        script.write_bytes(source.read_bytes())
        owned_files.append(script)
        if restore:
            marker = root / 'restore_pki_tool.py'
            marker.write_text('# Guard-only fixture marker.\n')
            owned_files.append(marker)
        if native:
            marker = root / 'native/HANDOFF.md'
            marker.parent.mkdir()
            marker.write_text('Guard-only native marker.\n')
            owned_files.append(marker)
        return root, script

    def refuse(name, script, helper, target, reason, valid_helper=True):
        existed = target.exists()
        command = [sys.executable, str(script), '--pki-tool', str(helper), '--output', str(target)]
        result = subprocess.run(command, cwd=output, capture_output=True)
        (output / (name + '.stdout')).write_bytes(result.stdout)
        (output / (name + '.stderr')).write_bytes(result.stderr)
        if result.returncode == 0 or reason.encode() not in result.stderr:
            raise ValueError('Expected early refusal missing: ' + name)
        if target.exists() != existed:
            raise ValueError('Refusal modified target existence: ' + name)
        rows.append({'case': name, 'command': command, 'exit_code': result.returncode,
            'expected_error_substring': reason, 'valid_pki_helper_used': valid_helper,
            'target_existence_unchanged': True})

    try:
        combined, script = fixture('combined', True, True)
        for name, target in [('combined_helper', combined / 'helper/new_output'),
                             ('combined_native', combined / 'native/new_output'),
                             ('combined_wire', combined / 'wire/new_output'),
                             ('combined_root', combined / 'new_output')]:
            refuse(name, script, tool, target, 'outside the retained evidence tree')
        standalone, script = fixture('standalone', False, False)
        refuse('standalone_own_tree', script, tool, standalone / 'helper/new_output',
            'outside the retained evidence tree')
        # Missing identity proves a sibling passes the own-tree guard, without execution.
        refuse('standalone_parent_fallback', script, tool, standalone / 'sibling_output',
            'prebuilt_identity.json')
        single, script = fixture('single_marker', True, False)
        refuse('single_marker_parent_fallback', script, tool, single / 'sibling_output',
            'prebuilt_identity.json')
        refuse('existing_output', source, tool, output, 'Choose an absent replay output directory')
        outside = output.parent / (output.name + '_wrong_helper_absent')
        if outside.exists() or outside.is_symlink():
            raise ValueError('Wrong-helper target must remain absent')
        # Use the standalone copy so its own-tree guard cannot mask checksum refusal.
        refuse('wrong_helper', probe / 'standalone/helper/replay_prebuilt.py', Path('/bin/true'),
            outside, 'PKI helper checksum differs', False)
    finally:
        if probe.exists():
            actual = {path for path in probe.rglob('*') if path.is_file() or path.is_symlink()}
            if actual != set(owned_files):
                raise ValueError('Unexpected guard fixture files; refusing broad cleanup')
            for path in owned_files:
                path.unlink()
            for directory in sorted((path for path in probe.rglob('*') if path.is_dir()),
                                    key=lambda path: len(path.parts), reverse=True):
                directory.rmdir()
            probe.rmdir()
        (output / 'results.json').write_text(json.dumps({'cases': rows,
            'source_sha256': sha(source), 'valid_pki_helper_sha256': sha(tool),
            'guard_fixture_removed': not probe.exists(),
            'combined_root_requires_both_markers': True}, indent=2) + '\n')
    print('PASS: combined evidence root, standalone fallback, existing-output and helper-hash guards')


if __name__ == '__main__':
    main()
