from pathlib import Path
import json
import subprocess

root = Path('/home/foo/Desktop/Repos/uWebZockets')
checks = Path(__file__).resolve().parent
commands = [
    ('conventions', ['sh', 'scripts/check_conventions.sh']),
    ('release-version', ['sh', 'scripts/check_release_version.sh']),
    ('docs', ['sh', 'scripts/check_docs.sh']),
    ('diff', ['git', 'diff', '--check']),
]
records = []
for name, command in commands:
    with (checks / (name + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
    records.append({'command': command, 'cwd': str(root), 'exit_code': result.returncode, 'output': name + '.log'})
    if result.returncode != 0:
        (checks / 'project-checks.json').write_text(json.dumps(records, indent=2) + '\n')
        raise SystemExit(result.returncode)
(checks / 'project-checks.json').write_text(json.dumps(records, indent=2) + '\n')
print('Conventions, release version, documentation links and diff checks pass')
