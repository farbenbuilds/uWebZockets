from pathlib import Path
import json
import subprocess
import sys

base = Path(__file__).resolve().parents[1]
checks = Path(__file__).resolve().parent
component = sys.argv[1]
assert component in {'helper', 'wire'}
output = Path('/tmp/uwz-ku-output-' + component + '-final-replay')
assert not output.exists() and not output.is_symlink()
command = ['python3', str(base / component / 'replay_prebuilt.py'),
           '--pki-tool', str(base / 'tools/wt-tools'), '--output', str(output)]
with (checks / (component + '-delivery-replay.log')).open('w') as log:
    result = subprocess.run(command, cwd=base, stdout=log, stderr=subprocess.STDOUT)
(checks / (component + '-delivery-command.json')).write_text(json.dumps({
    'command': command, 'cwd': str(base), 'exit_code': result.returncode,
    'log': component + '-delivery-replay.log',
}, indent=2) + '\n')
print(component, 'delivery replay exit code:', result.returncode)
raise SystemExit(result.returncode)
