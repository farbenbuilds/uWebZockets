from pathlib import Path
import json
import os
import subprocess

root = Path('/home/foo/Desktop/Repos/uWebZockets')
checks = Path(__file__).resolve().parent
command = [
    '/tmp/zig-x86_64-linux-0.16.0/zig', 'build', 'test-unit',
    '-Dsql=true', '-Dsqlite=true', '-j2', '--summary', 'all',
    '--cache-dir', str(root / '.zig-cache'),
    '--global-cache-dir', '/tmp/uwz-zig-cache',
]
env = os.environ.copy()
env['ZIG_GLOBAL_CACHE_DIR'] = '/tmp/uwz-zig-cache'
with (checks / 'test-unit.log').open('w') as output:
    result = subprocess.run(command, cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT)
(checks / 'test-unit-command.json').write_text(json.dumps({
    'command': command,
    'cwd': str(root),
    'env': {'ZIG_GLOBAL_CACHE_DIR': '/tmp/uwz-zig-cache'},
    'exit_code': result.returncode,
    'output': 'test-unit.log',
    'smoke_security_sanitizer_fuzz_scan_campaigns': 'user-deferred; not invoked',
}, indent=2) + '\n')
print('Functional unit suite exit code:', result.returncode)
raise SystemExit(result.returncode)
