#!/usr/bin/env python3
"""Strip only delivery DWARF and verify the bounded native ELF inventories."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import struct
import subprocess


def digest(data):
    return hashlib.sha256(data).hexdigest()


def bounded(data, offset, size):
    if offset < 0 or size < 0 or offset + size > len(data):
        raise ValueError('ELF region exceeds file bounds')
    return data[offset:offset + size]


def elf_snapshot(data):
    header = struct.unpack('<16sHHIQQQIHHHHHH', bounded(data, 0, 64))
    ident, kind, machine, version, entry, phoff, shoff, flags = header[:8]
    ehsize, phsize, phnum, shsize, shnum, shstrings = header[8:]
    if ident[:7] != b'\x7fELF\x02\x01\x01' or machine != 62:
        raise ValueError('Only the retained little-endian ELF64 x86-64 inventory is supported')
    if ehsize != 64 or phsize != 56 or shsize != 64 or not 0 < phnum < 128:
        raise ValueError('Unexpected native ELF header layout')
    if not 0 < shnum < 65535 or not 0 <= shstrings < shnum:
        raise ValueError('Extended or absent ELF section tables are not supported')
    sections = [struct.unpack('<IIQQQQIIQQ', bounded(data, shoff + i * shsize, shsize))
                for i in range(shnum)]
    strings_section = sections[shstrings]
    strings = bounded(data, strings_section[4], strings_section[5])

    def section_name(index):
        offset = sections[index][0]
        if not 0 <= offset < len(strings):
            raise ValueError('Invalid section-name offset')
        end = strings.find(b'\0', offset)
        if end < 0:
            raise ValueError('Unterminated section name')
        return strings[offset:end].decode('ascii')

    allocated = []
    debug_names = []
    regular_symbol_table_present = False
    for index, section in enumerate(sections):
        _, section_type, section_flags, address, offset, size, link, info, align, entsize = section
        name = section_name(index)
        if section_type == 2 and size > 0:
            regular_symbol_table_present = True
        if name.startswith(('.debug', '.zdebug')):
            debug_names.append(name)
        if not section_flags & 2:
            continue
        payload = b'' if section_type == 8 else bounded(data, offset, size)
        allocated.append({
            'name': name, 'type': section_type, 'flags': section_flags,
            'address': address, 'size': size, 'alignment': align, 'entry_size': entsize,
            'link': section_name(link) if link else None,
            'info': section_name(info) if section_type in (4, 9) and info else info,
            'payload_sha256': digest(payload),
        })
    programs = []
    loads = []
    for index in range(phnum):
        program = struct.unpack('<IIQQQQQQ', bounded(data, phoff + index * phsize, phsize))
        programs.append(list(program))
        if program[0] != 1:
            continue
        offset, file_size = program[2], program[5]
        payload = bytearray(bounded(data, offset, file_size))
        # ELF section-table coordinates change; all other mapped bytes must match.
        for start, end in ((40, 48), (60, 64)):
            lower, upper = max(start, offset), min(end, offset + file_size)
            if lower < upper:
                payload[lower - offset:upper - offset] = b'\0' * (upper - lower)
        loads.append({'index': index, 'normalized_payload_sha256': digest(payload)})
    return {
        'header_identity': [ident.hex(), kind, machine, version, entry, phoff,
                            flags, ehsize, phsize, phnum, shsize],
        'section_table_metadata': {'offset': shoff, 'count': shnum, 'strings_index': shstrings},
        'program_headers': programs, 'allocated_sections': allocated,
        'normalized_load_segments': loads, 'debug_sections': debug_names,
        'regular_symbol_table_present': regular_symbol_table_present,
    }


def compare_elf(before, after):
    original, delivered = elf_snapshot(before), elf_snapshot(after)
    for key in ('header_identity', 'program_headers', 'allocated_sections',
                'normalized_load_segments'):
        if original[key] != delivered[key]:
            raise ValueError('Strip-debug changed executable property: ' + key)
    if not original['regular_symbol_table_present'] or not delivered['regular_symbol_table_present']:
        raise ValueError('Regular symbol table must remain present')
    if not original['debug_sections'] or delivered['debug_sections']:
        raise ValueError('Expected original DWARF and its complete delivery removal')
    return {
        'entrypoint_abi_unchanged': True, 'program_headers_unchanged': True,
        'allocated_sections_unchanged': True,
        'regular_symbol_table_retained': True,
        'normalized_load_segments_unchanged': True,
        'normalized_load_exclusions': [
            {'file_offset': 40, 'bytes': 8, 'field': 'e_shoff'},
            {'file_offset': 60, 'bytes': 2, 'field': 'e_shnum'},
            {'file_offset': 62, 'bytes': 2, 'field': 'e_shstrndx'},
        ],
        'allocated_section_count': len(original['allocated_sections']),
        'load_segment_count': len(original['normalized_load_segments']),
        'removed_debug_sections': original['debug_sections'],
        'before_section_table': original['section_table_metadata'],
        'after_section_table': delivered['section_table_metadata'],
        'runtime_snapshot_sha256': digest(json.dumps({
            key: original[key] for key in ('header_identity', 'program_headers',
                                           'allocated_sections', 'normalized_load_segments')
        }, sort_keys=True).encode()),
    }


def verify_manifest(directory):
    rows = []
    for line in (directory / 'files.sha256').read_text().splitlines():
        checksum, name = line.split('  ', 1)
        relative = PurePosixPath(name)
        path = directory / name
        if relative.is_absolute() or '..' in relative.parts or path.is_symlink():
            raise ValueError('Unsafe manifest entry: ' + name)
        if digest(path.read_bytes()) != checksum:
            raise ValueError('Original staged checksum differs: ' + name)
        rows.append(name)
    return rows


def main():
    stage = Path('/tmp/uwz-sql-tls-ku-output-evidence-20261117')
    scratch = Path(__file__).resolve().parent
    outputs = scratch / 'stripped'
    transform = stage / 'delivery_transform'
    if outputs.exists() or transform.exists():
        raise ValueError('Choose fresh delivery transformation outputs')
    authorization = json.loads((scratch / 'authorization.json').read_text())
    expected_counts = authorization['expected_binary_counts']
    if authorization.get('root_explicitly_authorized') is not True or set(expected_counts) != {'helper', 'wire'}:
        raise ValueError('Explicit Root freeze authorization is required')
    if expected_counts['helper'] != 13 or not 1 <= expected_counts['wire'] <= 16:
        raise ValueError('Unexpected bounded outgoing replay inventory')
    inventories = {}
    members = {}
    for name, count in expected_counts.items():
        if digest((stage / name / 'files.sha256').read_bytes()) != authorization['stage_manifest_sha256'][name]:
            raise ValueError('Staged manifest differs from Root freeze identity: ' + name)
        members[name] = verify_manifest(stage / name)
        inventories[name] = json.loads((stage / name / 'prebuilt_identity.json').read_text())
        if len(inventories[name]['binaries']) != count:
            raise ValueError('Unexpected retained binary count: ' + name)
    outputs.mkdir()
    tool = Path('/usr/bin/objcopy')
    version = subprocess.check_output([str(tool), '--version'], text=True)
    tool_identity = {'path': str(tool), 'sha256': digest(tool.read_bytes()),
                     'version_output': version, 'operation': '--strip-debug'}
    rows = []
    for subtree, inventory in inventories.items():
        for name, checksum in inventory['binaries'].items():
            source = stage / subtree / name
            before = source.read_bytes()
            if source.is_symlink() or digest(before) != checksum:
                raise ValueError('Original binary identity differs: ' + name)
            destination = outputs / subtree / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            command = [str(tool), '--strip-debug', str(source), str(destination)]
            result = subprocess.run(command, capture_output=True, text=True)
            if result.returncode != 0:
                raise RuntimeError('objcopy failed: ' + result.stderr)
            after = destination.read_bytes()
            proof = compare_elf(before, after)
            if len(after) >= len(before):
                raise ValueError('Delivery binary did not shrink: ' + name)
            rows.append({'subtree': subtree, 'path': name, 'command': command,
                         'exit_code': result.returncode,
                         'original_measured_sha256': digest(before),
                         'original_measured_bytes': len(before),
                         'delivered_sha256': digest(after), 'delivered_bytes': len(after),
                         'executable_mode': stat.S_IMODE(source.stat().st_mode),
                         'elf_comparison': proof})
    transform.mkdir()
    for subtree in inventories:
        shutil.copy2(stage / subtree / 'prebuilt_identity.json',
                     transform / ('original_' + subtree + '_prebuilt_identity.json'))
        shutil.copy2(stage / subtree / 'files.sha256',
                     transform / ('original_' + subtree + '_files.sha256'))
    for row in rows:
        target = stage / row['subtree'] / row['path']
        temporary = target.with_name(target.name + '.delivery-strip-tmp')
        if temporary.exists() or digest(target.read_bytes()) != row['original_measured_sha256']:
            raise ValueError('Concurrent delivery binary mutation')
        shutil.copyfile(outputs / row['subtree'] / row['path'], temporary)
        temporary.chmod(row['executable_mode'])
        os.replace(temporary, target)
        inventories[row['subtree']]['binaries'][row['path']] = row['delivered_sha256']
        inventories[row['subtree']].setdefault('delivery_bytes', {})[row['path']] = row['delivered_bytes']
        if 'sizes' in inventories[row['subtree']]:
            inventories[row['subtree']]['sizes'][row['path']] = row['delivered_bytes']
    for subtree, inventory in inventories.items():
        inventory['delivery_transform'] = '../delivery_transform/manifest.json'
        (stage / subtree / 'prebuilt_identity.json').write_text(json.dumps(inventory, indent=2) + '\n')
        (stage / subtree / 'files.sha256').write_text(''.join(
            digest((stage / subtree / name).read_bytes()) + '  ' + name + '\n'
            for name in members[subtree]))
        verify_manifest(stage / subtree)
    record = {
        'complete': True, 'scope': 'delivery-only debug-section removal',
        'tool': tool_identity,
        'root_freeze_authorization': authorization,
        'zig_objcopy_limitation': {
            'zig_version': '0.16.0',
            'zig_sha256': '2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c',
            'attempted_operation': 'zig objcopy --strip-debug', 'exit_code': 1,
            'stderr': 'error: unimplemented',
            'pinned_source': 'lib/compiler/objcopy.zig:207',
            'reason': 'ELF-to-ELF output is unconditionally unimplemented in this pin',
            'historical_observation_reused_without_new_probe': True,
            'prior_evidence': 'sql_tls_aead_reuse_v1/2026_11_17 delivery_transform/manifest.json',
        },
        'binary_count': len(rows),
        'original_measured_binary_bytes': sum(row['original_measured_bytes'] for row in rows),
        'delivered_binary_bytes': sum(row['delivered_bytes'] for row in rows),
        'native_sources_or_test_assertions_changed': False,
        'original_source_build_provenance_and_raw_results_changed': False,
        'functional_replay_status': 'Root must rerun both complete delivery replays',
        'binaries': rows,
    }
    (transform / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
    shutil.copy2(Path(__file__).resolve(), transform / 'strip_delivery.py')
    print(json.dumps({key: record[key] for key in ('binary_count',
        'original_measured_binary_bytes', 'delivered_binary_bytes')}, indent=2))


if __name__ == '__main__':
    main()
