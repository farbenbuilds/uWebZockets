# Delivery-only debug stripping

The measured KeyUpdate programs were built in Debug with Zig 0.16.0. This
packaging operation removed nonallocated debug sections from 21 staged delivery
copies: 13 helper executables and 8 wire executables. Their total size changed
from 380,612,944 bytes to 105,848,016 bytes. Optimization settings and native
code were preserved; no compilation, optimization or relinking occurred.

`manifest.json` maps every original measured SHA-256 and byte count to its
actual delivered SHA-256 and byte count, with the exact tool command and ELF
comparison result. The original identity maps and subtree checksum manifests
are retained as `original_helper_*` and `original_wire_*`. Current
`helper/prebuilt_identity.json`, `wire/prebuilt_identity.json` and their current
`files.sha256` identify the delivered bytes. Each current identity map adds an
explicit `delivery_bytes` map and a link to this transformation record. Existing
measured Debug field values, including `measured_debug_bytes`, are preserved.
Separate `measured_debug_identity.json` files remain byte-for-byte unchanged
where present.
Historical build, provenance and result records describe the measured Debug
artifacts and retain their original identities.

Root explicitly authorized the operation after freezing and verifying both
producer copies. `authorization.json` and the embedded authorization in
`manifest.json` retain the exact inventory counts and original manifest hashes.
The immutable original producers are:

- Helper: `/tmp/uwz-pg-tls-ku-output-verify-20261117` (566 checksum entries,
  567 payload files, 13 executables).
- Wire: `/tmp/uwz-pg-tls-ku-output-wire-20261117` (177 checksum entries,
  178 payload files, 8 executables).

The operation used existing `/usr/bin/objcopy --strip-debug`, GNU Binutils for
Ubuntu 2.46. The tool SHA-256 is
`05f4473d24f7330a9b13f43d007d619a2e792e33de453cd7533a2d97c30da770`;
its complete version output is recorded in `manifest.json`. No tool was
installed. This is artifact packaging only and adds no native compilation,
linking, source-replay or project build dependency. Prebuilt replay needs
neither objcopy nor a compiler.

The prior evidence established that the pinned Zig 0.16.0
`objcopy --strip-debug` ELF-to-ELF operation returns `error: unimplemented`
at `lib/compiler/objcopy.zig:207`. That historical observation and pinned Zig
identity are retained in `manifest.json`; this operation did not repeat the
probe.

Before replacing any staged executable, all 21 outputs passed the bounded
little-endian ELF64 x86-64 comparison. The entrypoint and ELF ABI identity,
every program-header tuple, and every allocated section's name, type, flags,
address, size, alignment, entry size, linked-section meaning and payload remain
equal. Every PT_LOAD byte range matches after normalizing only the section-table
coordinates in the ELF header: `e_shoff` at offset 40 for 8 bytes, `e_shnum` at
offset 60 for 2 bytes and `e_shstrndx` at offset 62 for 2 bytes. Original debug
sections are absent from delivery copies; regular symbol tables remain present.
The delivered files have different complete file bytes and hashes.

`verify_delivery.py` independently rechecks both frozen producer manifests,
all 743 original producer entries, 720 staged entries outside the 21 binaries
and two current identity maps, all 21 original-to-delivery maps and runtime ELF
proofs, and all 21 regular symbol tables. Its result is
`post_transform_verification.json`. Replay wrappers, native and measurement
fixture sources, assertions, raw results, build inputs, and measured Debug
identities were not changed. There is no additional wrapper transformation.

To regenerate a delivery executable from an original Debug executable, use the
recorded command shape:

```sh
/usr/bin/objcopy --strip-debug ORIGINAL_DEBUG_EXECUTABLE NEW_DELIVERY_EXECUTABLE
```

Require the original input identity, preserve executable permissions and compare
the ELF properties before replacing a delivery copy. `strip_delivery.py`
records the actual one-time staging operation, explicit staging/scratch roots,
authorization input and refusal of existing transformation outputs. For a fresh
namespace, adapt only those explicit roots after preparing and authorizing
fresh original inputs; do not rerun it against the stripped delivery tree.
Debug hashes from source rebuilds can depend on paths and must be recorded for
those rebuilds rather than assumed equal to historical measurements.

Static verification used:

```sh
env PYTHONDONTWRITEBYTECODE=1 python3 delivery_transform/verify_delivery.py
```

That verifier needs the original producer paths above. No functional replay,
smoke, security or additional native test campaign ran during this packaging
operation. Root owns both complete happy-path prebuilt replays against the
final delivered binaries and the final archive checks.
