#!/usr/bin/env python3
"""Independent integrity checks for the compile/size measurement records."""
import hashlib
import json
from pathlib import Path
import statistics
import os
import subprocess


def reference(inputs):
    identifier = int(inputs.get('SQL_MAPPING_ID', '42'))
    if identifier < -2147483648 or identifier > 2147483647:
        return 'error=Overflow\n'
    label = inputs.get('SQL_MAPPING_LABEL', 'world')
    if len(label.encode('utf-8')) > 256:
        return 'error=InvalidValue\n'
    enabled = inputs.get('SQL_MAPPING_ENABLED', 'true')
    if enabled not in ('true', 'false'):
        return 'error=InvalidValue\n'
    errors = dict(wrong_column='TypeMismatch', null_id='NullValue', invalid_bool='InvalidValue', short_parameters='BufferTooSmall')
    failure = errors.get(inputs.get('SQL_MAPPING_MODE', 'valid'))
    if failure:
        return f'error={failure}\n'
    return f'id={identifier} label={label} enabled={enabled} params=23:{identifier},25:{label},16:{enabled}\n'

root = Path(__file__).parent.resolve()
summary = json.loads((root / 'summary.json').read_text())
records = summary['records']
assert len(records) == 28
assert len({record['id'] for record in records}) == 28
assert (root / 'inputs.before.json').read_bytes() == (root / 'inputs.after.json').read_bytes()
checks = [json.loads(line) for line in (root / 'results/verification.jsonl').read_text().splitlines()]
assert len(checks) == 280
assert len({(item['build'], item['case']) for item in checks}) == 280
assert all(item['exit_status'] == 0 and item['actual'] == item['expected'] and not item['stderr'] for item in checks)
for item in checks:
    assert item['expected'] == reference(item['input'])
    environment = {key: value for key, value in os.environ.items() if not key.startswith('SQL_MAPPING_')}
    environment.update(item['input'])
    binary = root / 'results' / item['build'] / 'sql_mapping'
    result = subprocess.run([str(binary)], env=environment, text=True, capture_output=True, timeout=10)
    assert result.returncode == 0 and result.stdout == reference(item['input']) and not result.stderr
for record in records:
    directory = root / 'results' / record['id']
    assert json.loads((directory / 'result.json').read_text()) == record
    binary = (directory / 'sql_mapping').read_bytes()
    assert len(binary) == record['file_bytes']
    assert hashlib.sha256(binary).hexdigest() == record['sha256']
    timing = dict(line.split('=', 1) for line in (directory / 'gnu_time.txt').read_text().splitlines())
    assert timing['exit_status'] == '0'
    assert abs(float(timing['elapsed_seconds']) - record['wall_nanoseconds'] / 1e9) < .2
    assert len([item for item in checks if item['build'] == record['id']]) == 10
    assert not (directory / 'stderr.txt').read_text()
    text_lines = [line.split() for line in (directory / 'readelf_sections.txt').read_text().splitlines() if '] .text ' in line]
    assert len(text_lines) == 1
    text_line = text_lines[0]
    name_index = text_line.index('.text')
    assert int(text_line[name_index + 4], 16) == record['sections_bytes']['.text']
for mode in ('ReleaseSafe', 'ReleaseFast'):
    measured = [record for record in records if record['mode'] == mode and record['measured']]
    assert [(record['sample'], record['variant']) for record in measured] == [
        (sample, variant) for sample in range(1, 7)
        for variant in (('direct', 'named') if sample % 2 else ('named', 'direct'))
    ]
    for variant in ('direct', 'named'):
        chosen = [record for record in measured if record['variant'] == variant]
        assert len(chosen) == 6
        assert summary['modes'][mode][variant]['median_compile_seconds'] == statistics.median(record['wall_nanoseconds'] / 1e9 for record in chosen)
assert summary['threshold'] is None
assert (root / 'run.status').read_text() == 'passed\n'
print('PASS: 28 successful builds, 24 alternating measured samples, 280 outputs independently modeled and re-executed, stable inputs, binary/section hashes and summary medians verified')
