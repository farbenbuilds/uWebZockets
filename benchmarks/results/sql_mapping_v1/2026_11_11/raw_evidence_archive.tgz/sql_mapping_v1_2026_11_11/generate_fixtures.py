from pathlib import Path

root = Path(__file__).parent
template = (root / 'main.template').read_text()
direct = '''try rows.validate_mapping(&common.columns, &actual_columns);
    record = .{
        .id = try row.get(i32, 0),
        .label = try row.get([]const u8, 1),
        .enabled = try row.get(bool, 2),
    };
    if (parameter_capacity < 3) return error.BufferTooSmall;
    parameter_storage = .{
        .{ .value = .{ .int4 = record.id }, .oid = 23 },
        .{ .value = .{ .text = record.label }, .oid = 25 },
        .{ .value = .{ .bool = record.enabled }, .oid = 16 },
    };
    const parameters = parameter_storage[0..3];'''
declarations = '''const from_row = rows.FromRow{ .columns = &common.columns, .map = map_record };
const to_param = rows.ToParam{ .encode = encode_record };

fn map_record(row: rows.Row, destination: *anyopaque) types.SqlError!void {
    const record: *common.Record = @ptrCast(@alignCast(destination));
    record.* = .{
        .id = try row.get(i32, 0),
        .label = try row.get([]const u8, 1),
        .enabled = try row.get(bool, 2),
    };
}

fn encode_record(source: *const anyopaque, storage: []types.Param) types.SqlError![]const types.Param {
    if (storage.len < 3) return error.BufferTooSmall;
    const record: *const common.Record = @ptrCast(@alignCast(source));
    storage[0..3].* = .{
        .{ .value = .{ .int4 = record.id }, .oid = 23 },
        .{ .value = .{ .text = record.label }, .oid = 25 },
        .{ .value = .{ .bool = record.enabled }, .oid = 16 },
    };
    return storage[0..3];
}'''
named = '''try rows.validate_mapping(from_row.columns, &actual_columns);
    try from_row.map(row, &record);
    const parameters = try to_param.encode(&record, parameter_storage[0..parameter_capacity]);'''
(root / 'fixtures/direct.zig').write_text(template.replace('@DECLARATIONS@', '').replace('@MAPPING@', direct))
(root / 'fixtures/named.zig').write_text(template.replace('@DECLARATIONS@', declarations).replace('@MAPPING@', named))
