#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import time

ROOT = Path(__file__).parent.resolve()
ZIG = Path(os.environ.get('UWZ_ZIG', '/tmp/zig-x86_64-linux-0.16.0/zig'))
GLOBAL = ROOT / 'global-cache'
FIXTURES = ROOT / 'fixtures'
RESULTS = ROOT / 'results'
RESULTS.mkdir()
CASES = [
    ('default', {}, 'id=42 label=world enabled=true params=23:42,25:world,16:true\n'),
    ('negative_unicode', {'SQL_MAPPING_ID': '-2147483648', 'SQL_MAPPING_LABEL': 'Nöde/東京', 'SQL_MAPPING_ENABLED': 'false'}, 'id=-2147483648 label=Nöde/東京 enabled=false params=23:-2147483648,25:Nöde/東京,16:false\n'),
    ('maximum_empty_label', {'SQL_MAPPING_ID': '2147483647', 'SQL_MAPPING_LABEL': ''}, 'id=2147483647 label= enabled=true params=23:2147483647,25:,16:true\n'),
    ('wrong_column', {'SQL_MAPPING_MODE': 'wrong_column'}, 'error=TypeMismatch\n'),
    ('null_id', {'SQL_MAPPING_MODE': 'null_id'}, 'error=NullValue\n'),
    ('invalid_bool', {'SQL_MAPPING_MODE': 'invalid_bool'}, 'error=InvalidValue\n'),
    ('short_parameters', {'SQL_MAPPING_MODE': 'short_parameters'}, 'error=BufferTooSmall\n'),
    ('invalid_enabled', {'SQL_MAPPING_ENABLED': 'invalid'}, 'error=InvalidValue\n'),
    ('id_overflow', {'SQL_MAPPING_ID': '2147483648'}, 'error=Overflow\n'),
    ('oversized_label', {'SQL_MAPPING_LABEL': 'x' * 257}, 'error=InvalidValue\n'),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify(binary, identifier):
    results = []
    for name, overrides, expected in CASES:
        environment = {key: value for key, value in os.environ.items() if not key.startswith('SQL_MAPPING_')}
        environment.update(overrides)
        result = subprocess.run([str(binary)], env=environment, text=True, capture_output=True, timeout=10)
        record = dict(build=identifier, case=name, input=overrides, expected=expected,
                      actual=result.stdout, stderr=result.stderr, exit_status=result.returncode)
        results.append(record)
        if result.returncode != 0 or result.stdout != expected or result.stderr:
            raise RuntimeError(f'{identifier}: equivalence fixture {name} failed: {record}')
    with (RESULTS / 'verification.jsonl').open('a') as output:
        for result in results:
            output.write(json.dumps(result, ensure_ascii=False) + '\n')


def build(mode, variant, sample, measured):
    identifier = f'{mode}_{sample}_{variant}'
    target = RESULTS / identifier
    target.mkdir()
    binary = target / 'sql_mapping'
    local = ROOT / 'local-cache' / identifier
    command = [str(ZIG), 'build-exe', str(FIXTURES / f'{variant}.zig'), '-O', mode,
               '-fstrip', '-target', 'x86_64-linux-gnu', '-mcpu', 'baseline', '--name', 'sql_mapping',
               '--cache-dir', str(local), '--global-cache-dir', str(GLOBAL), f'-femit-bin={binary}']
    wrapper = ['/usr/bin/time', '-f', 'elapsed_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmaximum_rss_kib=%M\nexit_status=%x',
               '-o', str(target / 'gnu_time.txt')] + command
    (target / 'command.json').write_text(json.dumps(wrapper, indent=2) + '\n')
    start = time.perf_counter_ns()
    process = subprocess.run(wrapper, text=True, capture_output=True, timeout=180)
    elapsed = time.perf_counter_ns() - start
    (target / 'stdout.txt').write_text(process.stdout)
    (target / 'stderr.txt').write_text(process.stderr)
    if process.returncode != 0:
        raise RuntimeError(f'{identifier}: compiler exited {process.returncode}: {process.stderr}')
    size = subprocess.run(['size', '-A', str(binary)], check=True, capture_output=True, text=True).stdout
    (target / 'size_sections.txt').write_text(size)
    sections = {}
    for line in size.splitlines():
        fields = line.split()
        if len(fields) == 3 and fields[0].startswith('.'):
            sections[fields[0]] = int(fields[1])
    (target / 'readelf_sections.txt').write_text(subprocess.run(['readelf', '-SW', str(binary)], check=True, capture_output=True, text=True).stdout)
    result = dict(id=identifier, mode=mode, variant=variant, sample=sample, measured=measured,
                  wall_nanoseconds=elapsed, file_bytes=binary.stat().st_size,
                  sha256=digest(binary), sections_bytes=sections,
                  load_average=Path('/proc/loadavg').read_text().strip())
    (target / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    verify(binary, identifier)
    print(f'{identifier}: {elapsed / 1e9:.6f}s, {binary.stat().st_size} bytes, equivalence passed', flush=True)
    return result


before = {str(path.relative_to(FIXTURES)): digest(path) for path in sorted(FIXTURES.rglob('*.zig'))}
(ROOT / 'inputs.before.json').write_text(json.dumps(before, indent=2) + '\n')
records = []
for mode in ('ReleaseSafe', 'ReleaseFast'):
    for variant in ('direct', 'named'):
        records.append(build(mode, variant, 'warmup', False))
    for sample in range(1, 7):
        order = ('direct', 'named') if sample % 2 else ('named', 'direct')
        for variant in order:
            records.append(build(mode, variant, sample, True))
after = {str(path.relative_to(FIXTURES)): digest(path) for path in sorted(FIXTURES.rglob('*.zig'))}
(ROOT / 'inputs.after.json').write_text(json.dumps(after, indent=2) + '\n')
if before != after:
    raise RuntimeError('fixture source changed during measurement')
summary = dict(benchmark='sql-mapping-v1', threshold=None, shared_host=True,
               cache_scope='fresh local cache for every build; cohort-global cache primed by both variants per mode; OS page cache uncontrolled',
               records=records, modes={})
for mode in ('ReleaseSafe', 'ReleaseFast'):
    variants = {}
    for variant in ('direct', 'named'):
        chosen = [record for record in records if record['measured'] and record['mode'] == mode and record['variant'] == variant]
        timings = [record['wall_nanoseconds'] / 1e9 for record in chosen]
        variants[variant] = dict(samples=len(chosen), median_compile_seconds=statistics.median(timings),
                                 minimum_compile_seconds=min(timings), maximum_compile_seconds=max(timings),
                                 file_bytes=sorted(set(record['file_bytes'] for record in chosen)),
                                 text_section_bytes=sorted(set(record['sections_bytes']['.text'] for record in chosen)),
                                 unique_binary_hashes=sorted(set(record['sha256'] for record in chosen)))
    summary['modes'][mode] = variants
(ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(ROOT / 'run.status').write_text('passed\n')
