const std = @import("std");
pub const rows = @import("sql/rows.zig");
pub const types = @import("sql/types.zig");

pub const Record = struct { id: i32, label: []const u8, enabled: bool };
pub const columns = [_]types.Column{
    .{ .name = "id", .oid = 23 },
    .{ .name = "label", .oid = 25 },
    .{ .name = "enabled", .oid = 16 },
};

pub fn format_result(record: Record, parameters: []const types.Param, output: []u8) ![]const u8 {
    if (parameters.len != 3) return error.InvalidValue;
    if (parameters[0].value != .int4 or parameters[1].value != .text or parameters[2].value != .bool) return error.TypeMismatch;
    return std.fmt.bufPrint(output, "id={d} label={s} enabled={} params={d}:{d},{d}:{s},{d}:{}\n", .{
        record.id,                record.label,             record.enabled,
        parameters[0].oid,        parameters[0].value.int4, parameters[1].oid,
        parameters[1].value.text, parameters[2].oid,        parameters[2].value.bool,
    });
}
