const std = @import("std");
const common = @import("common.zig");
const rows = common.rows;
const types = common.types;

const from_row = rows.FromRow{ .columns = &common.columns, .map = map_record };
const to_param = rows.ToParam{ .encode = encode_record };

fn map_record(row: rows.Row, destination: *anyopaque) types.SqlError!void {
    const record: *common.Record = @ptrCast(@alignCast(destination));
    record.* = .{
        .id = try row.get(i32, 0),
        .label = try row.get([]const u8, 1),
        .enabled = try row.get(bool, 2),
    };
}

fn encode_record(source: *const anyopaque, storage: []types.Param) types.SqlError![]const types.Param {
    if (storage.len < 3) return error.BufferTooSmall;
    const record: *const common.Record = @ptrCast(@alignCast(source));
    storage[0..3].* = .{
        .{ .value = .{ .int4 = record.id }, .oid = 23 },
        .{ .value = .{ .text = record.label }, .oid = 25 },
        .{ .value = .{ .bool = record.enabled }, .oid = 16 },
    };
    return storage[0..3];
}

fn transform(environ: *const std.process.Environ.Map, output: []u8) ![]const u8 {
    const id = try std.fmt.parseInt(i32, environ.get("SQL_MAPPING_ID") orelse "42", 10);
    const label = environ.get("SQL_MAPPING_LABEL") orelse "world";
    if (label.len > 256) return error.InvalidValue;
    const enabled_text = environ.get("SQL_MAPPING_ENABLED") orelse "true";
    const enabled = if (std.mem.eql(u8, enabled_text, "true")) true else if (std.mem.eql(u8, enabled_text, "false")) false else return error.InvalidValue;
    const mode = environ.get("SQL_MAPPING_MODE") orelse "valid";
    var id_bytes: [4]u8 = undefined;
    std.mem.writeInt(i32, &id_bytes, id, .big);
    var bool_bytes = [_]u8{@intFromBool(enabled)};
    var fields = [_]types.Field{
        .{ .bytes = &id_bytes, .oid = 23 },
        .{ .bytes = label, .oid = 25 },
        .{ .bytes = &bool_bytes, .oid = 16 },
    };
    var actual_columns = common.columns;
    if (std.mem.eql(u8, mode, "wrong_column")) actual_columns[0].oid = 25;
    if (std.mem.eql(u8, mode, "null_id")) fields[0].bytes = null;
    if (std.mem.eql(u8, mode, "invalid_bool")) bool_bytes[0] = 2;
    const row = rows.Row{ .fields = &fields };
    var record: common.Record = undefined;
    var parameter_storage: [3]types.Param = undefined;
    const parameter_capacity: usize = if (std.mem.eql(u8, mode, "short_parameters")) 2 else 3;
    try rows.validate_mapping(from_row.columns, &actual_columns);
    try from_row.map(row, &record);
    const parameters = try to_param.encode(&record, parameter_storage[0..parameter_capacity]);
    return common.format_result(record, parameters, output);
}

pub fn main(init: std.process.Init) !void {
    var output: [2048]u8 = undefined;
    const text = transform(init.environ_map, &output) catch |err| {
        const failure = try std.fmt.bufPrint(&output, "error={s}\n", .{@errorName(err)});
        try std.Io.File.stdout().writeStreamingAll(init.io, failure);
        return;
    };
    try std.Io.File.stdout().writeStreamingAll(init.io, text);
}
