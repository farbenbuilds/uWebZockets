# Native domain/CBB source handoff

Contract SHA256: `bfaa5edeeab68f6150a5e562412e61d6f04f309ea21e83e7d731099b4f8f6733`.
Implementation is confined to the approved five paths in the complete candidate
tree. The parent is the immutable
`sql-tls-preparation-integration-20261117/boringssl_final` tree. No production
vendor, pin, overlay, source build list, or publication destination was changed.

`native_source_identity.json` contains every candidate path, SHA256, and mode.
Its canonical sorted entry-manifest SHA256 is
`f351788b556ffcbf41d89e8a4f4e134f11553d1eaaf4145739aba47cd1a1fa0d`.
There are 8709 regular files, with exactly five changed paths and no added,
deleted, or mode-changed path against the immutable parent.
`native_source_delta.json` retains the five before/after entries.
`native_leaf.diff` SHA256 is
`e066f53a71670ac53851155b8a42d3d64506c3b953158dce80d8309bfe192408`.

The verification owner retained the genuine missing-public-API RED before native
implementation. Its source is `proof/public_api_proof.c` (SHA256
`326288a98a85e1f41998553a802d831e735acec7336d89c80413b02d3d0034b3`), compiled
against the immutable parent's public headers. Exit 1 identifies the absent
domain type and two new entry points. The raw log is
`proof_evidence/parent_public_api_red.log` (SHA256
`0e157f0540235b0ec90560081a2ec04f148ea029f6f90d3c30a04a30669b8b01`).

## Implementation and source basis

- `include/openssl/mem.h` adds named allocation/release callback aliases, the
  borrowed immutable descriptor, and `OPENSSL_malloc_with_domain`. Comments
  state raw extent/alignment, callback non-reentrancy, descriptor lifetime,
  no fallback, and compatible-image ownership.
- `crypto/mem.cc` preserves the existing ordinary eight-byte prefix, malloc
  hook branches, and sdallocx path. Owned metadata stores the descriptor and
  requested payload size before an extent rounded to `alignof(max_align_t)`.
  The discriminator is a `size_t` at exactly payload minus eight bytes.
  Existing ordinary overflow rejection makes `SIZE_MAX` unavailable to a
  successful ordinary no-hook allocation. Free saves all release arguments,
  unpoisons and clears the entire header/padding/payload, then calls release
  once. Realloc restores poison before either outcome, uses the same domain,
  and frees the old block only after successful replacement. The private query
  rejects any of the three hooks before inspecting a pointer or prefix.
- `crypto/mem_internal.h` declares that private exact-base query and adds only
  `Array<T>::InitForOverwriteWithDomain(domain, count)`. It preserves the existing
  Array reset, zero-count, checked multiplication, and default-construction
  rules. No owner field or layout change was added.
- `crypto/bytestring/cbb.cc` adds owned initialization, including a real owned
  zero-capacity buffer. Every NULL initialization sets the top-level error bit
  in a zeroed cleanup-safe CBB. Existing generic realloc/free paths preserve
  ownership. SET OF queries only a growable non-NULL destination base; both
  scratch arrays use its domain. Either owned scratch OOM sets sticky failure
  and ordinary RAII cleanup releases any partial scratch. Every copied byte and
  parsed CBS is filled before sorting. The original ordinary/fixed allocation
  branch is retained. `CBBFinishArray` remains unchanged and transfers the exact
  base through existing Array ownership.
- `include/openssl/bytestring.h` documents the initializer, retained owner of
  output, failed-init state, and no fallback. CBB's public layout is unchanged.

Primary API and error/poison behavior came from the frozen parent's
`crypto/mem.cc`, `crypto/mem_internal.h`, `crypto/bytestring/cbb.cc`, and their
two public headers. No current upstream documentation was substituted for the
pinned implementation. This is an allocator provenance/CBB leaf, not proof of
full SSL/X509/ASN1/ERR ownership or a numerical TLS capacity bound.

## Source compilation

Both changed C++ translation units compiled successfully as objects with Zig
0.16.0 and the verification owner's native flags. Logs are `mem_compile.log`
and `bytestring_cbb_compile.log`; both commands exited zero.

```sh
ZIG_GLOBAL_CACHE_DIR=/home/foo/Desktop/Repos/uWebZockets/.zig-cache/tls-domain-leaf-fixed-20261118/native-global-cache \
/tmp/zig-x86_64-linux-0.16.0/zig c++ -std=gnu++17 \
  -DBORINGSSL_IMPLEMENTATION -D_XOPEN_SOURCE=700 -D_FORTIFY_SOURCE=0 \
  -fno-sanitize=undefined -fno-stack-protector -fno-sanitize-trap=undefined \
  -fno-exceptions -fno-rtti \
  -I /home/foo/Desktop/Repos/uWebZockets/.zig-cache/tls-domain-leaf-fixed-20261118/boringssl/include \
  -c /home/foo/Desktop/Repos/uWebZockets/.zig-cache/tls-domain-leaf-fixed-20261118/boringssl/crypto/mem.cc \
  -o /home/foo/Desktop/Repos/uWebZockets/.zig-cache/tls-domain-leaf-fixed-20261118/native_evidence/mem.o
```

The second command substitutes `crypto/bytestring/cbb.cc` and
`native_evidence/bytestring_cbb.o`. Preliminary `-fsyntax-only` attempts were not
successful checks: the default cache was read-only; an SSD-cache attempt still
reported `FileNotFound` for the syntax-only source. Their retained logs are
`native_syntax_check.log` and `native_mem_syntax_check.log`. Actual object
compilation above succeeded with the normal native flags.

The candidate was frozen and its identity sent to the verification owner before
GREEN builds. Functional tests, heap-counter evidence, hook/sdallocx controls,
normal SDK compatibility, and independent source review are owned by the root
and verification agents. This source handoff does not claim those checks ran or
passed. Broad smoke/security/sanitizer/fuzz campaigns remain user-deferred.
