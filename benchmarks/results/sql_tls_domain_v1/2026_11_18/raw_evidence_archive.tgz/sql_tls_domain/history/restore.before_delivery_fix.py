#!/usr/bin/env python3
"""Restore a complete experimental image from an exact external parent tree."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--parent', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--zig', type=Path)
args = parser.parse_args()
packet = Path(__file__).resolve().parent
out = args.output.resolve()
for ancestor in (out, *out.parents):
    if (ancestor / 'files.sha256').exists():
        raise SystemExit('output must be outside an evidence artifact')
parent = args.parent.resolve()
expected = json.loads((packet / 'source_identity/parent_native_identity.json').read_text())['entries']
candidate = json.loads((packet / 'source_identity/native_source_identity.json').read_text())

def verify(directory, entries):
    actual = {str(p.relative_to(directory)) for p in directory.rglob('*')
              if p.is_file() and '.git' not in p.relative_to(directory).parts}
    assert actual == {e['path'] for e in entries}, 'source file set differs'
    for entry in entries:
        path = directory / entry['path']
        assert not path.is_symlink(), entry['path']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256'], entry['path']
        assert path.stat().st_mode & 0o777 == entry['mode'], entry['path']

verify(parent, expected)
out.mkdir(parents=True, exist_ok=False)
source = out / 'boringssl'
for entry in expected:
    path = source / entry['path']
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(parent / entry['path'], path)
for name in candidate['changed_paths']:
    shutil.copy2(packet / 'candidate_files' / name, source / name)
verify(source, candidate['files'])
for directory in ['sdk', 'proof']:
    shutil.copytree(packet / directory, out / directory)
shutil.copy2(packet / 'build.zig', out / 'build.zig')
builder = out / 'sdk/builds/vendor/boringssl.zig'
text = builder.read_text()
old = candidate['actual_candidate_source']
assert text.count(old) == 1
builder.write_text(text.replace(old, str(source)))
record = {'parent_verified_files': len(expected), 'candidate_verified_files': len(candidate['files']),
          'changed_paths': candidate['changed_paths'], 'builder_path_rebound': True,
          'proof_executed': False}
if args.zig:
    zig = args.zig.resolve()
    assert hashlib.sha256(zig.read_bytes()).hexdigest() == '2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c'
    command = [str(zig), 'build', 'proof', '-Doptimize=ReleaseSafe', '-j4',
               '--cache-dir', 'cache', '--global-cache-dir', 'global-cache', '--summary', 'all']
    with (out / 'proof.log').open('wb') as stream:
        result = subprocess.run(command, cwd=out, stdout=stream, stderr=subprocess.STDOUT)
    record.update(proof_executed=True, command=command, exit_code=result.returncode)
    (out / 'restoration.json').write_text(json.dumps(record, indent=2) + '\n')
    assert result.returncode == 0
else:
    (out / 'restoration.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
