# Independent isolated native memory-domain/CBB review

Reviewed candidate: `/home/foo/Desktop/Repos/uWebZockets/.zig-cache/tls-domain-leaf-fixed-20261118/boringssl`.
Parent: `.zig-cache/sql-tls-preparation-integration-20261117/boringssl_final`.
Reviewed diff SHA256: `e066f53a71670ac53851155b8a42d3d64506c3b953158dce80d8309bfe192408`.
Contract SHA256: `bfaa5edeeab68f6150a5e562412e61d6f04f309ea21e83e7d731099b4f8f6733`.
Read-only source review; no native, harness, SDK, vendor, pin, or tracked file was edited.

1. **[P2] Begin the private metadata objects' lifetimes in callback storage** — `boringssl/crypto/mem.cc:260-266`.

   `OPENSSL_malloc_with_domain` casts `raw` to `AllocationDomainHeader*` and assigns its members, then casts another part of the storage to `size_t*` for the marker. The public callback contract guarantees accessible, sufficiently sized and aligned storage; it does not guarantee that either private C++ object already exists. For example, a C++17 callback backed by fixed `std::aligned_storage_t<16384, alignof(max_align_t)> slots[16]` can return `&slots[index]` without constructing either private type. The resulting member/scalar accesses have no established object lifetime, making an otherwise conforming custom adapter invoke undefined behavior before its first payload is returned. The byte-array proof adapters do not establish support for this case.

   Placement-construct the header and the separate scalar marker, retaining the existing extent/alignment/layout, or consistently encode and decode metadata as bytes through local live objects. Do not rely solely on changing the standard mode: the implicit-creation rules designate particular operations and do not turn every allocator callback or cast into object creation. Primary basis: [WG21 P0593R6, sections 3.2 and 5.1](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2020/p0593r6.html), and [C++17 draft N4659, meta.trans.other](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2017/n4659.pdf).

No additional actionable ownership, cleansing, overflow, hook-dispatch, CBB, or structural finding was established. The null-domain/zero-count `Array::InitForOverwriteWithDomain` result is not reported as a defect: it acquires no storage, follows the existing empty-Array contract, and both actual SET OF calls are reached only with a non-null recovered owner and at least two elements. All five touched native files remain below 1000 lines; the provenance query stays in the memory module and introduces no duplicated header decoder into CBB.

Verification boundaries:

- Independently compared the complete trees with `diff -qr`: exactly the approved five files differ; no added/deleted paths were reported. Read the complete supplied diff, actual changed source and surrounding dispatch, public API declarations, proof sources, contract, root decision, source handoff, and retained initial RED/build evidence.
- The retained parent API RED is genuine missing declarations. Object-compilation success is reported in the source handoff; no functional PASS is inferred from it.
- The retained second proof build failed on duplicate sanitizer-option registration. Root reports that boundary corrected and a third build running. Functional/hook/sdallocx/heap-counter evidence and normal SDK/project gates remain pending at this report's issue time; this is not merge or pin-adoption approval.
- ASan prefix behavior was reviewed in source only. Dedicated smoke, security, sanitizer and fuzz campaigns remain user-deferred. This leaf does not establish complete SSL/X509/ASN1/ERR/thread ownership, a numerical capacity bound, or the full PostgreSQL allocation gate.
