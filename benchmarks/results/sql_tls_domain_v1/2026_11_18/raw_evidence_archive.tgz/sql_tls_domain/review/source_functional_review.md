# Final isolated native leaf source and functional-evidence review

No actionable findings. The original P2 metadata-lifetime finding is resolved, and the retained post-fix normal native proof supports the isolated allocation-domain/CBB contract. This verdict does not approve production pin adoption or establish full PostgreSQL/TLS ownership.

Reviewed final source and identity:

- Parent source: `.zig-cache/sql-tls-preparation-integration-20261117/boringssl_final`, local proposal `f6176c03304e835d315cf4d9cbd86fc27e979f95`.
- Candidate source: `.zig-cache/tls-domain-leaf-fixed-20261118/boringssl`.
- Final diff: `native_evidence/root_final/native_leaf.diff`, SHA256 `45e1ca6ea7e1ffa1b52262017f09b4ae5e80debbc0935f4a5cc9fcbaedb0e52b`.
- Final source manifest: `native_evidence/root_final/native_source_identity.json`, SHA256 `d3f644b25ac53ff800610dff16f980296f68ffb39fa5e319f5f8a32d8c6f43fa`.

The reviewer independently recomputed all 8709 candidate file SHA256 values and modes against the manifest, compared the complete parent/candidate path sets and hashes/modes, and regenerated the complete five-file unified diff. Every recorded entry matched. Exactly `crypto/bytestring/cbb.cc`, `crypto/mem.cc`, `crypto/mem_internal.h`, `include/openssl/bytestring.h`, and `include/openssl/mem.h` changed; there were no added/deleted paths or mode changes. The regenerated diff exactly matches the final patch artifact. Earlier inherited producer-path labels were not treated as source identity.

The final diff retains the reviewed explicit placement construction of both private metadata objects. Ownership dispatch, checked extent/alignment, exact nearest eight-byte discriminator, hook-first query, same-owner realloc/OOM preservation, complete cleanse, sticky owned CBB initialization/scratch failure, child-base SET OF ownership and ordinary/fixed branches match the prior source review. No new source changes beyond the targeted fix were found. See `source_initial_review.md` for the original finding and `source_targeted_recheck.md` for its disposition.

Post-fix normal proof evidence:

- Read `proof_evidence/proof_metadata_restored_toolchain.json`: the retained `zig build proof -Doptimize=ReleaseSafe -j4 --cache-dir native-cache --global-cache-dir native-global-cache --summary all` command exited zero.
- Independently hashed the actual restored compiler executable at `.zig-cache/toolchains/zig-x86_64-linux-0.16.0/zig`: SHA256 `2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c`, matching the execution record.
- Read the complete `proof_evidence/proof_metadata_restored_toolchain.log`: **22/22 build steps succeeded**, `native_domain_proof rows=14 failed=0`. All **13 measured cases** report result zero and zero malloc/calloc/realloc/free/requested-byte counters, including the new opaque aligned-storage case. The fourteenth row is the ordinary/fixed compatibility control outside those measured scopes.
- The counter's positive self-test records malloc=1, calloc=1, realloc=1, free=2 and requested=63. The thread ERR queue is explicitly initialized before measured cases; cold-thread ownership is not inferred.
- Ordinary unprefixed hooked realloc/child SET parity, guarded no-prefix lookup, all three partial-hook rejection configurations, ordinary exact-extent sdallocx cleansing and owned release bypass of sdallocx pass in the retained log.
- Reviewed the actual proof build and counter source: proof files retain `-Wall -Wextra -Werror`, vendor headers are system includes, the native source list comes from the full candidate tree, and the sdallocx control links a complete separately configured crypto image. The all-C counter has no owned-case allocation exclusion. No dedicated campaign was rerun by the reviewer.

Evidence hashes:

- Post-fix proof log: `b181d87f025af3c5b7b284dd12e1a2215ec7db57795989a57638c4e0e928c423`.
- Post-fix execution record: `42fa68c306e0cdc1148122caea0757fe971a6d8ef7501a9b298c1ccf79e47e94`.
- Domain proof source: `bf6796a29e257589bef12820579f8e83f38c0d0c93310c8759b94f5ab849c7b9`.
- Sdallocx proof source: `c977128c9d3f3f0d1cddf1b29b768945b7e0a966fd56fb15217278f28d6fcaf8`.

Remaining verification boundaries:

- Normal SDK/project gate success is not claimed here. Root owns those executions and has not supplied their completed exit disposition for this review.
- These are normal native source/functional results on the recorded native target, not cross-target, ASan or other sanitizer validation. Dedicated smoke/security/sanitizer/fuzz campaigns remain user-deferred.
- Full SSL/X509/ASN1/ERR/thread ownership, numerical capacity and the worker-wide PostgreSQL failure/reconnect/cancel allocation gate remain open. The experimental leaf and its proof adapter establish no production allocator policy or fallback exception.

Only this review artifact was written. No source, proof, SDK, vendor or pin file was edited by the reviewer.
