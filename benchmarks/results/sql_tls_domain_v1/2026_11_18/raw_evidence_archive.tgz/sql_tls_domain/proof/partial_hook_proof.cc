#include <openssl/bytestring.h>
#include <openssl/mem.h>

#include <stddef.h>
#include <stdio.h>

#include "crypto/mem_internal.h"

#if defined(PARTIAL_ALLOC)
extern "C" void *OPENSSL_memory_alloc(size_t) { return nullptr; }
#elif defined(PARTIAL_FREE)
extern "C" void OPENSSL_memory_free(void *) {}
#elif defined(PARTIAL_SIZE)
extern "C" size_t OPENSSL_memory_get_size(void *) { return 0; }
#else
#error Specify one weak-hook configuration.
#endif

static void *must_not_allocate(void *context, size_t, size_t)
{
    *static_cast<int *>(context) += 1;
    return nullptr;
}

static void must_not_release(void *context, void *, size_t, size_t)
{
    *static_cast<int *>(context) += 1;
}

int main(void)
{
    int callbacks = 0;
    const OPENSSL_ALLOCATION_DOMAIN domain = {&callbacks, must_not_allocate, must_not_release};
    if (OPENSSL_malloc_with_domain(0, &domain) != nullptr) return 1;
    if (OPENSSL_malloc_with_domain(13, &domain) != nullptr) return 2;
    CBB builder;
    if (CBB_init_with_domain(&builder, 0, &domain)) return 3;
    if (CBB_add_u8(&builder, 1)) return 4;
    CBB_cleanup(&builder);
    if (callbacks != 0) return 5;
    if (bssl::GetAllocationDomain(reinterpret_cast<const void *>(1)) != nullptr) return 6;
    printf("partial_weak_hook owned_rejected_before_callback no_prefix_query callbacks=%d PASS\n", callbacks);
    return 0;
}
