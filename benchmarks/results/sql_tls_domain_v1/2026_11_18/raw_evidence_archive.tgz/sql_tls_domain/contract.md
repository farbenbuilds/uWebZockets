# Proposed native memory provenance and CBB ownership slice

Status: revised after two actionable independent contract findings; requires
the revised-contract check before implementation. Full SQL lifecycle ownership and any total byte bound remain
unproved. This is a prerequisite implementation slice for the v2.3.0 goal.

## Evidence and source

Parent native source is the complete immutable 8709-file tree at
`../sql-tls-preparation-integration-20261117/boringssl_final`, local source
proposal f6176c03304e835d315cf4d9cbd86fc27e979f95. Root's last pushed checkpoint
is 06a25061eb5edb388756705edb94edeffef492bb. No production pin adoption or
publication destination is approved. Copies for implementation must be fresh,
complete trees on workspace SSD; no overlay or build-time patching.

Architect source audit identifies these immediate seams:

- crypto/mem.cc:43 fixes the ordinary allocation prefix at eight bytes.
  :183-220 rejects payload+prefix overflow, so successful ordinary no-hook
  allocations cannot record SIZE_MAX. :243-295 implement generic free/realloc.
- crypto/bytestring/cbb.cc:47 allocates the initial growable buffer; :79-117
  grows through OPENSSL_realloc; :65-77 cleans up through OPENSSL_free;
  :134-158 transfers the raw allocation on finish. Fixed CBB storage is separate.
- :719-747 also allocate two Array scratch buffers while sorting ASN1 SET OF.
  Owned CBB storage is complete only when those buffers inherit the destination
  domain, including when sorting a child CBB whose data is an interior span.
- crypto/x509/x_pubkey.cc:44-78 uses CBB for SPKI encoding, then EVP decoding.
  This provides an actual future native caller rather than a hypothetical seam.

## Root's selected contract for independent review

An explicit borrowed immutable domain descriptor contains a context pointer and
named allocation/release callback aliases. Allocation receives requested raw
bytes and alignment; release receives that same pointer, size and alignment.
The caller owns the descriptor, callback code, context and storage until after
the last release. Domain operations do not call BoringSSL recursively. SQL's
eventual adapter remains worker-confined; this slice adds no allocator policy,
registry, current-owner variable, thread-local router or concurrency mechanism.

Use these additive C declarations consistently in implementation and proof:
OPENSSL_ALLOCATION_DOMAIN has context, allocate and release fields with named
OPENSSL_domain_alloc_func and OPENSSL_domain_free_func aliases. Their arguments
are (context, raw_size, alignment) and (context, raw_pointer, raw_size, alignment).
OPENSSL_malloc_with_domain takes (size_t size, const domain*). CBB_init_with_domain
takes (CBB*, size_t initial_capacity, const domain*). The public headers retain
C compatibility. No additional public getter or allocator family is required.

Add only the memory allocation entry point needed by CBB and the owned CBB
initializer. An explicit domain allocation rejects NULL descriptors, missing
callbacks, arithmetic overflow and coexistence with any existing weak memory
hook. There is no heap fallback. Ordinary OPENSSL_malloc/zero/calloc behavior,
its eight-byte layout and its hook path stay unchanged. A callback failure uses
the existing native memory error mechanism. Thread ERR initialization is a
separate lifetime; the leaf cannot claim cold-thread error emission is owned.

An owned allocation has an extended private header. The ordinary nearest
eight-byte prefix contains a size_t SIZE_MAX discriminator; preceding metadata
contains the explicit domain and requested payload size. Owned header extent is
rounded to the build's alignof(max_align_t), and the callback must return raw
storage with the requested alignment. Marker location remains exactly eight
bytes before the returned pointer on both 32-bit and 64-bit targets; compare
size_t rather than all eight bytes. Reject header/payload overflow before any
callback. A successful zero-size allocation remains non-null and header-backed.

Generic OPENSSL_free/realloc preserve their existing hook-first behavior and
never inspect a hook-owned pointer. Only an identified owned allocation uses
its domain. Free saves release arguments, cleanses the complete owned header,
padding and requested payload, then releases exactly once through the owner.
The ordinary sdallocx/free path remains unchanged. Realloc of a non-null owned
block allocates through the same owner, preserves min(old,new) payload bytes,
and frees the old allocation only after success. Failure preserves old payload,
metadata and ownership. Ordinary realloc(NULL,size) stays ordinary allocation;
explicit creation uses the additive owned entry point.

Metadata accesses must follow the existing ASan poison/unpoison convention.
Unpoison the nearest prefix before its discriminator, then unpoison the rest of
an identified owned header. Re-poison metadata on continuing paths. Never use
SIZE_MAX in extent arithmetic. Pool callbacks must return accessible storage;
released-storage poisoning belongs to the explicit adapter contract. Dedicated
sanitizer campaigns remain user-deferred, not claimed by ordinary tests.

The owned allocation format is private to one compatible native BoringSSL image.
An older image cannot free it. Owner recovery is permitted only from exact base
pointers guaranteed to belong to this OPENSSL allocation family. No stack,
static, embedded, interior or arbitrary pointer probing is permitted. All
headers/native archives/translated bindings in an SDK build use one full tree.

Add CBB_init_with_domain with an explicit CBB pointer, initial capacity and domain.
Its initial buffer uses the owned allocator even at capacity zero, retaining an
owner for later generic realloc. Existing growth, cleanup and finish use the
same public CBB interface and generic free. Stack CBBs and CBB public layout do
not change. CBB_init_fixed remains caller-storage-only and never probes or
releases that caller buffer. Ordinary growable CBB behavior remains unchanged.
Unlike ordinary CBB_init, owned initialization returns zero on every NULL
allocation, including capacity zero. It leaves a zeroed, cleanup-safe CBB with
its top-level error bit set. Later add/finish fails before any realloc(NULL)
could fall back to the ordinary heap.

SET OF obtains its destination domain through one private memory-module query.
It may inspect only cbb_get_base(cbb)->buf after checking can_resize and non-NULL;
that exact base is guaranteed to originate from OPENSSL allocation. It must not
probe CBBAsSpan.data, a child/embedded CBB address, or fixed caller storage. Keep
header decoding in mem.cc; declare the private helper in existing mem_internal.h.
The private helper must itself check for any weak memory-hook presence before
reading any pointer/header, and return no domain in that configuration. Ordinary
growable CBB storage returned by a hook is an exact OPENSSL base pointer but has
no prefix. Owned creation already rejects hooks, so this early result preserves
the original hooked scratch path. Test ordinary hooked multi-element SET OF
parity and dispatch, plus direct hook-present no-prefix-read behavior.
Add one internal Array<T>::InitForOverwriteWithDomain storage initializer for
the two actual trivial element types, uint8_t and CBS. Fill copied bytes and
every parsed CBS before sorting. Preserve the original ordinary/fixed scratch
allocation branch. Owned scratch allocation failure releases partial scratch,
marks the builder failed and never falls back. Public domain-getter, CBB owner
field, duplicate header decoder and speculative allocator wrappers are excluded.
Existing owned CBBFinishArray transfers the exact base to Array::Reset, which
retains generic free provenance; fixed buffers are outside that helper's existing
ownership contract and are tested through CBB_finish instead.

## Ordered implementation and acceptance

1. Memory provenance: crypto/mem.cc and include/openssl/mem.h, with ordinary
   negative/functional tests written before implementation. Test two interleaved
   fixed-storage domains, alignment, zero size, overflow-before-callback,
   callback failure, same-owner realloc, preserved old bytes on realloc OOM,
   complete cleansing and exactly-once release. Test ordinary weak-hook and
   sdallocx controls without introducing a production global allocator policy.
2. Complete CBB leaf: crypto/bytestring/cbb.cc and
   include/openssl/bytestring.h. Exercise zero-capacity growth, nested builders,
   cleanup, finished-output and Array transfer/free, OOM rollback, and
   ordinary/fixed controls. Include multi-element DER SET OF sorting on a child
   CBB, byte parity with ordinary mode, and each scratch-OOM index. Explicitly
   test zero-capacity initialization OOM, cleanup and failed subsequent add/finish.
   With an explicitly initialized thread error queue, the owned
   successful and failure cases must show no C heap calls using the original
   unchanged counter. Report cold-thread facilities separately.
3. Verify native default compatibility and normal Zig-only SDK integration.
   Existing prepared SQL functional/allocation controls must retain their
   behavior. Freeze the justified five-path delta (including mem_internal.h), full-tree identity, build outputs,
   functional evidence and independent review before committing a proposal.

No production bounded allocator algorithm or total capacity is approved by this
contract. A test adapter is evidence-only. Deleting the memory provenance module
should force owner-specific release code into CBB/raw-output consumers and later
Delete/refcount/array call sites; otherwise the seam is not earning its keep.

The initial contract review's SET OF escape and zero-capacity OOM findings, and
the recheck's hook-owned-buffer lookup finding, are classified valid and
actionable. Revisions broaden implementation and acceptance to resolve them;
the full owned-CBB claim was not narrowed.

## Explicit remaining ownership work

SSL_new clones CERT/config, creates S3/null-AEAD/handshake state and inherits
verification parameters. Handshake transcript BUF_MEM and BIO pair allocation
need explicit destination ownership. Peer certificates lead through CRYPTO_BUFFER,
X509/ASN1 names/extensions, SPKI CBB and EVP/RSA/BN/EC workspaces. Verification
stacks and X509_STORE_CTX temporaries differ from persistent trust-certificate
lazy caches. Session/peer export, shared pools and final-reference thread/lifetime
must be excluded or supported before any epoch reset.

Fatal handshake state uses generic ERR_save_state; raw ERR descriptors/arrays,
formatted data and pthread facilities bypass OPENSSL_malloc. Existing established
record reservations do not close those paths. RNG/algorithm internals and generic
ASN1 external callbacks remain unmapped. The new runtime trace is observational
evidence, not an exhaustive error/algorithm reachability or numerical bound.

Keep the original worker-wide failure/reconnect/cancel RED, pool capacity,
admission, deadlines, quarantine and callback ordering unchanged. No PostgreSQL
allocation exception is approved. No finite spare stock, callback deferral,
admission pause, maintenance relabeling or hidden allocation route is allowed.
