const std = @import("std");
const boringssl = @import("sdk/builds/vendor/boringssl.zig");
const sanitizers = @import("sdk/builds/sanitizers.zig");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const native = boringssl.build(b, target, optimize, sanitizers.configure(b, target, true));
    const install_crypto = b.addInstallArtifact(native.crypto, .{});
    const native_step = b.step("native", "Compile the complete normal crypto source list");
    native_step.dependOn(&install_crypto.step);
    const proof_step = b.step("proof", "Run native allocation-domain and CBB proof");
    add_proof(b, target, optimize, native, proof_step, "public_api_proof", false);
    add_proof(b, target, optimize, native, proof_step, "domain_proof", true);
    add_proof(b, target, optimize, native, proof_step, "hook_proof", true);
    add_partial_hook(b, target, optimize, native, proof_step, "partial_alloc", "-DPARTIAL_ALLOC");
    add_partial_hook(b, target, optimize, native, proof_step, "partial_free", "-DPARTIAL_FREE");
    add_partial_hook(b, target, optimize, native, proof_step, "partial_size", "-DPARTIAL_SIZE");
    add_sdallocx(b, target, optimize, native, proof_step);
}

fn add_partial_hook(
    b: *std.Build,
    target: std.Build.ResolvedTarget,
    optimize: std.builtin.OptimizeMode,
    native: boringssl.Artifacts,
    proof_step: *std.Build.Step,
    name: []const u8,
    definition: []const u8,
) void {
    const module = b.createModule(.{ .target = target, .optimize = optimize, .link_libc = true, .link_libcpp = true });
    module.addIncludePath(native.include_root);
    module.addIncludePath(b.path("boringssl"));
    module.addCSourceFile(.{
        .file = b.path("proof/partial_hook_proof.cc"),
        .flags = &.{ "-std=c++17", "-Wall", "-Wextra", "-Werror", definition },
    });
    module.linkLibrary(native.crypto);
    const executable = b.addExecutable(.{ .name = name, .root_module = module });
    const run = b.addRunArtifact(executable);
    proof_step.dependOn(&run.step);
}

fn add_sdallocx(
    b: *std.Build,
    target: std.Build.ResolvedTarget,
    optimize: std.builtin.OptimizeMode,
    native: boringssl.Artifacts,
    proof_step: *std.Build.Step,
) void {
    const module = b.createModule(.{ .target = target, .optimize = optimize, .link_libc = true, .link_libcpp = true });
    module.addIncludePath(native.include_root);
    module.addCSourceFile(.{
        .file = b.path("proof/sdallocx_proof.cc"),
        .flags = &.{ "-std=c++17", "-Wall", "-Wextra", "-Werror" },
    });
    module.addCSourceFile(.{
        .file = b.path("boringssl/crypto/mem.cc"),
        .flags = &.{ "-std=gnu++17", "-DBORINGSSL_DETECT_SDALLOCX", "-DBORINGSSL_IMPLEMENTATION", "-D_FORTIFY_SOURCE=0", "-fno-sanitize=undefined", "-fno-stack-protector", "-fno-sanitize-trap=undefined", "-fno-exceptions", "-fno-rtti" },
    });
    module.linkLibrary(native.crypto);
    const executable = b.addExecutable(.{ .name = "sdallocx_proof", .root_module = module });
    const run = b.addRunArtifact(executable);
    proof_step.dependOn(&run.step);
}

fn add_proof(
    b: *std.Build,
    target: std.Build.ResolvedTarget,
    optimize: std.builtin.OptimizeMode,
    native: boringssl.Artifacts,
    proof_step: *std.Build.Step,
    name: []const u8,
    cpp: bool,
) void {
    const module = b.createModule(.{
        .target = target,
        .optimize = optimize,
        .link_libc = true,
        .link_libcpp = cpp,
    });
    module.addIncludePath(native.include_root);
    module.addIncludePath(b.path("boringssl"));
    module.addCSourceFile(.{
        .file = b.path(b.fmt("proof/{s}.{s}", .{ name, if (cpp) "cc" else "c" })),
        .flags = &.{ if (cpp) "-std=c++17" else "-std=c11", "-Wall", "-Wextra", "-Werror", "-fno-exceptions", "-fno-rtti" },
    });
    if (std.mem.eql(u8, name, "domain_proof")) {
        module.addCSourceFile(.{ .file = b.path("proof/allocation_scope.c"), .flags = &.{ "-std=c11", "-fno-builtin" } });
    }
    module.linkLibrary(native.crypto);
    const executable = b.addExecutable(.{ .name = name, .root_module = module });
    const install = b.addInstallArtifact(executable, .{});
    const run = b.addRunArtifact(executable);
    proof_step.dependOn(&install.step);
    proof_step.dependOn(&run.step);
}
