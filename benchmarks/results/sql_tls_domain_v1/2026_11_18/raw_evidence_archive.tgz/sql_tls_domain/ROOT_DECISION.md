# Isolated owned-memory/CBB implementation decision

Root approves implementation of only the five-path native memory-provenance and
complete owned-CBB leaf described in contract.md (bfaa5edeeab68f6150a5e562412e61d6f04f309ea21e83e7d731099b4f8f6733).
Architecture and bounded independent contract review are complete. The three
actionable omissions were resolved: SET scratch, zero-capacity OOM, hook-owned
prefix lookup. This accepts the same-image/borrowed-stable-domain/max-align
callback contract and no-heap-fallback behavior for this isolated proof.

No total TLS allocator/domain/capacity, production pin or new remote publication
is approved. Future SSL/X509/ASN1/ERR/thread owner propagation remains open.
Developer owns native five paths; verification owns proof/build files. Root owns
the prepared SDK copy and integration, evidence/review/commits. Do not edit
frozen parent sources or protected vendors. Write tests and retain the missing-API
RED before implementing; no fabricated behavioral RED. Broad smoke/security/
sanitizer/fuzz campaigns remain user-deferred. Ordinary native tests and default
SDK compatibility remain required.
