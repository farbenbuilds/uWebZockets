"""Explicit owned provider state; protocol and closing remain canonical."""
from functools import partial


def require(value, message):
    if not value:
        raise ValueError(message)


def validate_ready(child):
    watcher,capture = child['watcher'],child['capture']
    require(type(watcher) is dict and type(capture) is dict,'missing watcher or capture')
    require(capture['overflow'] is False and capture['error'] is None,'capture failed')
    expected = dict(pid=child['pid'],start=child['start'],listener=child['listener'],nonce=child['nonce'],
                    source_sha256=child['source_sha256'],binary_sha256=child['binary_sha256'],
                    order=('listen','catch_shutdown_signals','H2_READY','run'),ready=('info: H2_READY '+child['nonce']+'\n').encode())
    require(watcher==expected,'watcher startup/source/build/capture binding differs')
    ready = expected['ready']
    require(type(capture.get('bytes')) in (bytes,bytearray) and len(capture['bytes'])<=65536 and
            bytes(capture['bytes']).splitlines(keepends=True).count(ready)==1,'watcher READY absent from actual capture')


def signal_prerequisites(child, handle, deadline, now):
    validate_ready(child)
    require(type(deadline) is int and type(now) is int and now<deadline and not child['signaled'],'signal deadline or duplicate effect')
    if handle is None:
        require(all(item in child['closed_handles'] for item in child['handles']),'ordinary signal has open clients')
        return
    require(handle in child['handles'] and handle not in child['closed_handles'],'signal client not owned/open')
    if hasattr(handle,'fileno'):
        require(handle.fileno()>=0,'signal client descriptor closed')


def validate_terminal(child):
    require(type(child['capture']) is dict and child['capture']['finished'] is True and
            child['capture']['overflow'] is False and child['capture']['error'] is None,'terminal capture missing')
    require(type(child['process_status']) is int and child['process_status']==0 and child['reaped'] is True and
            child['listener_gone'] is True and child['joined'] is True and child['pipe_closed'] is True and
            child['removed'] is True and child['forced'] is False and type(child['post']) is dict,'terminal process/post/cleanup missing')


def release_handle(child, handle, close):
    require(any(item is handle for item in child['handles']) and
            not any(item is handle for item in child['closed_handles']) and
            not any(item is handle for item in child['release_attempts']),'duplicate or foreign release')
    child['release_attempts'].append(handle)
    result = close(handle)
    require(result is None,'close result differs')
    child['closed_handles'].append(handle)
    return None


def new_provider(config, *, clock, ops):
    require(type(config) is dict and callable(clock) and type(ops) is dict,'provider static inputs')
    require(len(config['nonces'])==2 and len(set(config['nonces']))==2,'child nonce declarations')
    state = dict(config=config,clock=clock,ops=ops,children=config['pending'],failure=None,cleanup_started=False,cleanup_errors=[],receipts=None,
                 failure_errors=[],failure_error_count=0)
    return partial(child_factory,state),state


def child_factory(state,run_identity,index,selection,ready,whole):
    import native_transport as transport
    import h2_client
    require(state['failure'] is None and index==len(state['children']) and index<2 and
            run_identity==state['config']['run_identity'],'provider child identity/order')
    child = state['ops']['new_child'](state['config'],index,ready,whole)
    validate_ready(child)
    binding = dict(identity=(run_identity,index),selection=selection,ready_start=ready-15000000000,
                   ready_at=child['ready_at'],ready_deadline=ready,whole_start=state['config']['whole_start'],whole_deadline=whole,
                   pid=child['pid'],start_identity=child['start'],listener=child['listener'],address=child['listener'],
                   certificate_sha256=child['certificate_sha256'])
    child['selection'] = selection
    child['transport'] = transport.new_transport(binding,clock=state['clock'],ops=state['ops']['transport_ops'](child,h2_client.new_protocol,selection))
    current = child['transport']
    result = dict(identity=binding['identity'],ready=True,fresh_application=True,connect=partial(transport.connect,current),
                  bind_context=partial(transport.bind_context,current),bind_collection=partial(bind_collection,child),signal=partial(signal_child,state,child),
                  process=partial(process_child,state,child),post=partial(post_child,state,child))
    if any(case!='shutdown_active' for case in selection):
        result['close'] = partial(transport.close,current)
    if 'disconnect' in selection:
        result['disconnect_close'] = partial(transport.disconnect_close,current)
    if 'shutdown_active' in selection:
        result['termination'] = partial(transport.termination,current)
    if any(case in ('shutdown_idle','shutdown_active') for case in selection):
        result['preconditions'] = partial(preconditions,state,child)
    return result


def preconditions(state,child,context):
    import native_transport as transport
    current = child['transport']
    transport.owned(current,min(context['stage']['case_deadline'],context['stage']['whole_deadline']))
    row = current['current']
    require(row is not None and not row['closed'],'shutdown client missing')
    if child['selection'][-1]=='shutdown_active':
        require(all(item['closed'] and item['release'] is not None for item in current['history'][:-1]),'prior release incomplete')
        return dict(client_open=True,prior_complete=True)
    require(len(current['history'])==1 and child['selection']==('shutdown_idle',),'idle child not fresh')
    return dict(client_open=True,fresh_application=True)


def bind_collection(child,context,actual_capture):
    import coordinator
    import model
    import shutdown_cases
    row = child['transport']['current']
    require(child['before'] is None and row is not None and not row['closed'] and not child['signaled'],'collection missing or duplicate ownership')
    anchor = row['context_binding']
    require(anchor is not None and anchor[0] is context and context['stage']['case']==child['selection'][-1],
            'collection context or terminal case differs')
    require(type(actual_capture) is dict and actual_capture.keys()=={'records','metrics'},'collection capture schema')
    selection = child['selection']
    model.validate_records(selection,'before',actual_capture['records'])
    model.validate_metrics(selection,'before',actual_capture['metrics'])
    outputs,binding = shutdown_cases.outputs(context,selection)
    child['before'] = coordinator.copy_facts(dict(actual_capture,outputs=outputs,binding=binding))
    child['collection_context'] = context


def signal_child(state,child,context,deadline):
    import native_transport as transport
    require(type(child['before']) is dict and child.get('collection_context') is context,'missing frozen collection before signal')
    current = child['transport']
    if child['selection'][-1]=='shutdown_active':
        return transport.signal(current,partial(state['ops']['signal'],child),context,deadline)
    require(current['current']['closed'] and current['current']['release'] is not None,'ordinary shutdown before client close')
    evidence = state['ops']['signal'](child,current['child'],None,deadline)
    return dict(evidence[0])


def process_child(state,child,context,deadline):
    import native_post
    require(child['process_facts'] is None and child['before'] is not None,'process duplicate or missing frozen facts')
    captured = state['ops']['complete'](child,deadline)
    parsed = native_post.parse_capture(captured,child['nonce'],state['config']['capacity'])
    native_post.validate_post(child['selection'],child['before'],parsed)
    child['post'] = parsed
    state['ops']['remove'](child)
    validate_terminal(child)
    child['process_facts'] = dict(exit_code=child['process_status'],reaped=child['reaped'],forced=child['forced'],run_ok=True,deinit_ok=True,key_removed=child['removed'])
    return dict(child['process_facts'])


def post_child(state,child,context,deadline):
    import native_post
    import coordinator
    validate_terminal(child)
    captured = state['ops']['snapshot'](child)
    parsed = native_post.parse_capture(captured,child['nonce'],state['config']['capacity'])
    native_post.validate_post(child['selection'],child['before'],parsed)
    require(parsed==child['post'],'post capture changed')
    return coordinator.copy_facts(parsed)


def aggregate(state,result):
    import native_transport as transport
    import test_all40_descriptors as descriptors
    expected = tuple((child['identity'][1],summary['case'],summary['case_connection']) for child in result['children'] for summary in child['connections'])
    actual = tuple(row['identity'] for child in state['children'] for row in child['transport']['history'])
    require(actual==expected and len(set(actual))==len(actual),'missing duplicate unordered receipt')
    receipts = []
    for child in state['children']:
        validate_terminal(child)
        receipts.extend(transport.transport_receipt(child['transport'],row['identity']) for row in child['transport']['history'])
    prefixes = tuple(item[2][0] if item[1]=='active' else item[2] for item in receipts)
    require(descriptors.receipt_counts(prefixes)==result['totals'],'canonical totals differ')
    state['receipts'] = tuple(receipts)
    return state['receipts']


def failure_boundary(state,error):
    import native_transport as transport
    if state['failure'] is None:
        state['failure'] = error
    if state['cleanup_started']:
        return
    state['cleanup_started'] = True
    for child in state['children']:
        current = child.get('transport')
        if current is not None:
            transport.fail_transport(current,state['failure'])
        try:
            state['ops']['cleanup'](child,state['failure'])
        except BaseException as secondary:
            require(len(state['cleanup_errors'])<2,'provider cleanup error bound')
            state['cleanup_errors'].append(secondary)
