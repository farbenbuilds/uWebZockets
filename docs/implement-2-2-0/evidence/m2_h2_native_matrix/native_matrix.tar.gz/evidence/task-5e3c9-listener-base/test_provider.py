"""Deterministic hostile checks of owned provider acceptance boundaries."""
import native_provider as provider


def require(value, message):
    if not value:
        raise ValueError(message)


def rejected(callback, message):
    try:
        callback()
    except ValueError:
        return
    raise ValueError('Accepted ' + message)


def ready_child():
    return dict(watcher=dict(pid=19, start='77', listener=('127.0.0.1',28443), nonce='c9_0',
                            source_sha256='a'*64, binary_sha256='b'*64,
                            order=('listen','catch_shutdown_signals','H2_READY','run'), ready=b'info: H2_READY c9_0\n'),
                pid=19, start='77', listener=('127.0.0.1',28443), nonce='c9_0',
                source_sha256='a'*64, binary_sha256='b'*64, capture=dict(bytes=b'info: H2_READY c9_0\n',overflow=False,error=None,finished=False),
                signaled=False, handles=[], closed_handles=[],release_attempts=[], process_status=0, reaped=True,
                listener_gone=True, joined=True, pipe_closed=True, removed=True, forced=False, post={'actual':True})


def readiness():
    for field in ('watcher','capture'):
        child = ready_child()
        child[field] = None
        rejected(lambda: provider.validate_ready(child), 'missing ' + field)
    child = ready_child()
    child['watcher']['nonce'] = 'foreign'
    rejected(lambda: provider.validate_ready(child), 'foreign watcher')
    child = ready_child()
    child['capture']['bytes'] = b'foreign\n'
    rejected(lambda: provider.validate_ready(child),'READY absent from actual capture')
    print('readiness ownership rejects missing/foreign evidence')


def terminal():
    for field, value in [('capture',None),('process_status',None),('post',None),('removed',False),('forced',True),
                         ('reaped',False),('listener_gone',False),('joined',False),('pipe_closed',False)]:
        child = ready_child()
        child['capture']['finished'] = True
        child[field] = value
        rejected(lambda: provider.validate_terminal(child), 'terminal ' + field)
    print('terminal acceptance rejects missing capture/exit/post and failed cleanup')


def signal():
    handle = object()
    child = ready_child()
    child['handles'].append(handle)
    provider.signal_prerequisites(child,handle,100,20)
    child['closed_handles'].append(handle)
    rejected(lambda: provider.signal_prerequisites(child,handle,100,20),'closed client signal')
    child['closed_handles'].clear()
    child['signaled'] = True
    rejected(lambda: provider.signal_prerequisites(child,handle,100,20),'duplicate signal')
    print('signal ownership rejects closed client and duplicate effect')


def release():
    child, handle, calls = ready_child(), object(), []
    child['handles'].append(handle)
    provider.release_handle(child,handle,lambda item:calls.append(item))
    rejected(lambda: provider.release_handle(child,handle,lambda item:calls.append(item)), 'duplicate release')
    require(calls == [handle],'duplicate release performed an effect')
    print('release is one-shot')


def failures():
    primary, secondary = RuntimeError('primary'), RuntimeError('cleanup')
    calls = []
    def cleanup(child,error):
        require(error is primary,'primary identity changed')
        calls.append(child)
        raise secondary
    state = dict(failure=None,cleanup_started=False,children=[{}],ops=dict(cleanup=cleanup),cleanup_errors=[])
    provider.failure_boundary(state,primary)
    provider.failure_boundary(state,RuntimeError('later'))
    require(state['failure'] is primary and state['cleanup_errors'] == [secondary] and len(calls)==1,'failure boundary changed primary or retried cleanup')
    print('failure boundary retains exact primary and separate one-shot cleanup error')


def main():
    readiness()
    terminal()
    signal()
    release()
    failures()
    strict_tls()
    send_deadline()
    interleaved_ready()
    reserved_ready()
    collection_binding()
    normal_file_cleanup()
    print('11 focused groups passed')


def raise_exact(error,*args,**kwargs):
    raise error


def strict_tls():
    import native_host as host
    from types import SimpleNamespace
    from functools import partial
    primary,secondary = RuntimeError('handshake'),RuntimeError('candidate cleanup')
    raw_closes = []
    wrapped = SimpleNamespace(do_handshake=partial(raise_exact,primary),close=partial(raise_exact,secondary))
    duplicate = SimpleNamespace(settimeout=lambda seconds:None)
    raw = SimpleNamespace(dup=lambda:duplicate,close=lambda:raw_closes.append('raw'))
    child = dict(tls_context=SimpleNamespace(wrap_socket=lambda *args,**kwargs:wrapped),handles=[raw],closed_handles=[],release_attempts=[],wrap_candidates=[],cleanup_errors=[])
    try:
        host.wrap(child,raw,'localhost',False,1.0)
    except RuntimeError as error:
        require(error is primary and child['cleanup_errors']==[secondary] and not raw_closes,'failed wrap lost primary/raw ownership')
        candidate = child['wrap_candidates'][0]
        require(candidate['handle'] is wrapped and candidate['cleanup_started'] and not candidate['closed'],'failed candidate cleanup target not retained')
    else:
        raise ValueError('failed wrap accepted')
    returned = object()
    handle = SimpleNamespace(unwrap=lambda:returned)
    child.update(handles=[handle],closed_handles=[])
    require(host.unwrap(child,handle) is returned and child['handles'][-1] is returned and child['closed_handles']==[handle],'unwrap handle transfer lost')
    rejected(lambda:host.unwrap(child,SimpleNamespace(unwrap=lambda:None)),'absent unwrap handle')
    eof = RuntimeError('primitive EOF error')
    ops = host.transport_ops(child,lambda:None,('disconnect',),lambda:1)
    require(ops['recv'](SimpleNamespace(recv=lambda maximum:b''),8192)==b'','raw EOF normalized')
    try:
        ops['recv'](SimpleNamespace(recv=partial(raise_exact,eof)),8192)
    except RuntimeError as error:
        require(error is eof,'primitive receive exception reconstructed')
    else:
        raise ValueError('primitive receive error swallowed')
    print('TLS failure/unwrap transfer and raw EOF/exception identity passed')


def send_deadline():
    import native_host as host
    from types import SimpleNamespace
    ticks,timeouts,writes = iter((10,30)),[],[]
    handle = SimpleNamespace(settimeout=lambda seconds:timeouts.append(seconds),send=lambda data:(writes.append(bytes(data)) or min(len(data),2)))
    child = dict(transport=dict(current=dict(case_deadline=100,whole_deadline=200,signal_deadline=None)))
    host.full_send(child,lambda:next(ticks),handle,b'abcd')
    require(writes==[b'abcd',b'cd'] and timeouts==[90/1000000000,70/1000000000],'send timeout was reset')
    rejected(lambda:host.full_send(child,lambda:100,handle,b'a'),'send beyond absolute deadline')
    print('partial send reclips original absolute deadline')


def interleaved_ready():
    import native_host as host
    import threading
    from types import SimpleNamespace
    child = ready_child()
    child['process'] = SimpleNamespace(poll=lambda:None)
    child['capture'].update(lock=threading.Lock(),event=SimpleNamespace(wait=lambda seconds:None,clear=lambda:None),
                            bytes=bytearray(b'info: H2_CAPACITY independent\ninfo(server): server listening on 127.0.0.1:28443\ninfo: H2_READY c9_0\n'))
    ticks = iter((10,100))
    original = host.listeners
    host.listeners = lambda pid:('owned_inode',)
    try:
        returned = host.readiness(child,dict(capacity='independent',source_sha256='a'*64,binary_sha256='b'*64),100,lambda:next(ticks))
        require(returned==10 and child['listener_inode']=='owned_inode','interleaved log changed readiness')
    finally:
        host.listeners = original
    print('readiness accepts interleaved ordinary log with exact ordered fixture markers')


def reserved_ready():
    import native_host as host
    import threading
    from types import SimpleNamespace
    for extra in (b'info: H2_READY c9_0\n',b'info: H2_UNKNOWN c9_0\n',b'info: H2_CAPACITY independent\n'):
        child = ready_child()
        child['process'] = SimpleNamespace(poll=lambda:None)
        child['capture'].update(lock=threading.Lock(),bytes=bytearray(b'info: H2_CAPACITY independent\ninfo: H2_READY c9_0\n'+extra))
        rejected(lambda:host.readiness(child,dict(capacity='independent'),100,lambda:1),'duplicate/unexpected reserved readiness marker')
    print('duplicate/unexpected reserved readiness markers reject before listener acceptance')


def collection_binding():
    import model
    selection = ('shutdown_idle',)
    context = dict(stage=dict(case='shutdown_idle'))
    row = dict(closed=False,context_binding=(context,))
    child = dict(before=None,signaled=False,selection=selection,transport=dict(current=row))
    actual = dict(records=model.records(selection,'before'),metrics=dict(model.metrics(selection,'before'),slot0_active=False,slot1_active=False))
    foreign = dict(context)
    rejected(lambda:provider.bind_collection(child,foreign,actual),'foreign collection context')
    rejected(lambda:provider.signal_child({},child,context,100),'signal without collected baseline')
    require(provider.bind_collection(child,context,actual) is None,'collection callback returned replacement')
    tag = next(iter(actual['records']))
    frozen = dict(child['before']['records'][tag])
    actual['records'][tag]['bytes'] += 1
    require(child['before']['records'][tag]==frozen,'capture mutation changed frozen facts')
    rejected(lambda:provider.bind_collection(child,context,actual),'duplicate collection binding')
    print('collection requires exact context, one-shot capture and frozen baseline before signal')


def normal_file_cleanup():
    import native_host as host
    from types import SimpleNamespace
    from functools import partial
    present,events = dict(cert=True,key=True,transfer=True),[]
    def unlink(name):
        events.append(name)
        present[name] = False
    child = dict(handles=[],closed_handles=[],wrap_candidates=[],removed=False)
    for name in present:
        child[name] = SimpleNamespace(unlink=partial(unlink,name),exists=lambda name=name:present[name])
    host.remove_owned(child)
    require(child['removed'] is True and not any(present.values()) and set(events)==set(present) and len(events)==3,
            'Normal cleanup did not remove all three owned files exactly once')
    primary = RuntimeError('owned transfer unlink')
    child['removed'] = False
    present['transfer'] = True
    child['transfer'] = SimpleNamespace(unlink=partial(raise_exact,primary),exists=lambda:present['transfer'])
    try:
        host.remove_owned(child)
    except RuntimeError as error:
        require(error is primary and not child['removed'],'Unlink failure lost primary or earned cleanup acceptance')
    else:
        raise ValueError('Failed owned unlink accepted')
    print('Normal host cleanup removes transfer/certificate/key; unlink failure preserves primary and rejects')


if __name__ == '__main__':
    main()
