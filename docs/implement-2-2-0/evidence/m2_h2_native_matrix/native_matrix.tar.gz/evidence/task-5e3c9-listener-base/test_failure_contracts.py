"""Controlled source-only regressions for bootstrap and failure ownership."""
import errno
from functools import partial
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import threading
from types import SimpleNamespace
import run_native as runner


def require(value,message):
    if not value:
        raise ValueError(message)


def raise_exact(error,*args,**kwargs):
    raise error


def private_paths(child,events,failed=None):
    for name in ('cert','key','transfer'):
        def unlink(*args,name=name,**kwargs):
            events.append(name)
            if name==failed:
                raise OSError(errno.EACCES,'controlled owned unlink '+name)
        child[name] = SimpleNamespace(unlink=unlink,exists=lambda:False)


def child_state():
    return dict(handles=[],closed_handles=[],release_attempts=[],wrap_candidates=[],cleanup_started=False,cleanup_errors=[],
                cleanup_error_count=0,process=None,capture=None,removed=False,transport=None)


def release_handoff():
    import native_host as host
    import native_provider as provider
    import native_transport as transport
    primary,secondary = RuntimeError('original transport failure'),OSError(errno.EBADF,'controlled close failure')
    calls,unlinks = [],[]
    def close():
        calls.append('close')
        raise secondary
    handle = SimpleNamespace(close=close)
    child = child_state()
    child['handles'] = [handle]
    private_paths(child,unlinks)
    row = dict(handle=handle,closed=False,cleanup_started=False,release=None)
    state = dict(failure=None,cleanup_errors=[],current=row,busy=False,ops=dict(close=partial(host.close,child)))
    child['transport'] = state
    outer = dict(failure=None,cleanup_started=False,cleanup_errors=[],children=[child],ops=dict(cleanup=partial(host.cleanup,clock=lambda:1)))
    transport.fail_transport(state,primary)
    provider.failure_boundary(outer,primary)
    provider.failure_boundary(outer,RuntimeError('later failure'))
    print('underlying_close_attempts',len(calls),'closed_successes',len(child['closed_handles']))
    require(len(calls)==1,'Transport-to-host handoff retried failed close')
    require(state['failure'] is primary and outer['failure'] is primary and state['cleanup_errors']==[secondary],
            'Cleanup replaced primary or lost separate close failure')
    require(not row['closed'] and row['release'] is None and not child['closed_handles'] and not child['removed'],
            'Failed release earned normal acceptance')
    require(set(unlinks)=={'cert','key','transfer'},'Failed release prevented private-file cleanup')


def capture_cleanup(root):
    from unittest import mock
    import native_host as host
    child,events = child_state(),[]
    private_paths(child,events,failed='cert')
    pipe = SimpleNamespace(close=lambda:None,closed=True)
    child.update(process=SimpleNamespace(poll=lambda:0,wait=lambda **kwargs:0,stdout=pipe),
                 capture=dict(lock=threading.Lock(),bytes=bytearray(b'controlled capture\n'),overflow=False,error=None,finished=True),
                 directory=root,forced=False)
    primary,secondary = RuntimeError('original failure'),OSError(errno.ENOSPC,'controlled failure capture')
    caught = None
    with mock.patch.object(Path,'write_bytes',partial(raise_exact,secondary)):
        try:
            host.cleanup(child,primary,lambda:1)
        except BaseException as error:
            caught = error
    print('private_unlink_attempts',events,'capture_cleanup_raised',type(caught).__name__ if caught else None)
    require(set(events)=={'cert','key','transfer'} and len(events)==3,'Capture-write/unlink failure skipped another private file')
    require(not child['removed'] and child['cleanup_started'],'Failure cleanup earned normal acceptance')
    require(child['cleanup_error_count']==2 and len(child['cleanup_errors'])==2,'Cleanup secondaries missing or unbounded')


def reporting(packet,label):
    from unittest import mock
    import coordinator
    import native_provider as provider
    import time
    primary,secondary = OSError(errno.ENOSPC,'original acceptance/capture failure'),OSError(errno.ENOSPC,'failure receipt write')
    state = dict(failure=None,cleanup_started=False,cleanup_errors=[],children=[],ops={},failure_errors=[],failure_error_count=0)
    authority = dict(modes=dict(db=dict(path='/not-executed',sha256='a'*64)),source=dict(sha256='b'*64),capacity='not-executed')
    def save(path,value):
        if path.name=='failure.json':
            raise secondary
    actual = None
    with mock.patch.object(time,'monotonic_ns',lambda:1), mock.patch.object(provider,'new_provider',lambda *args,**kwargs:(lambda *args:None,state)), mock.patch.object(runner,'closure_check',lambda *args:dict(maps='controlled')), mock.patch.object(coordinator,'run',partial(raise_exact,primary)), mock.patch.object(runner,'save',save):
        try:
            runner.execute(packet,{}, {},(),authority,'db','e',label)
        except BaseException as error:
            actual = error
    print('reporting_preserved_primary',actual is primary)
    require(actual is primary,'Failure reporting replaced exact primary exception')
    require(state['failure'] is primary and state['failure_errors']==[secondary] and state['failure_error_count']==1,
            'Reporting failure not retained separately and bounded')
    original = RuntimeError('original combined failure')
    cleanup_error,report_error = OSError(errno.EACCES,'secondary cleanup'),OSError(errno.ENOSPC,'secondary report')
    combined = dict(failure=None,failure_errors=[],failure_error_count=0)
    observed = None
    try:
        try:
            raise original
        except BaseException as error:
            runner.preserve_failure(combined,error,partial(raise_exact,cleanup_error),partial(raise_exact,report_error))
            raise
    except BaseException as error:
        observed = error
    require(observed is original and combined['failure_errors']==[cleanup_error,report_error] and combined['failure_error_count']==2,
            'Combined cleanup/reporting errors changed primary or escaped their fixed bound')
    print('combined_cleanup_reporting_preserved_primary',observed is original,'secondary_count',combined['failure_error_count'])


def bytecode(packet,root,label):
    optimized = sys.flags.optimize==1
    name,pin = ('r94','25663987bd16c7ba191d84c230e95cc09f90c722197e6c5a7d8192eaf78ada9d') if optimized else ('r93','436617cc26cdad67aa621e7686059ea17672227a656a226f2c46c54030d454c9')
    existing = Path('/tmp/uwz-h2-native-c9/fix1_checks')/name
    fixture,marker = existing/'packet',existing/'unapproved-bytecode-sentinel'
    data = (existing/'fixture-inputs.json').read_bytes()
    require(hashlib.sha256(data).hexdigest()==pin,'Existing regression input inventory changed')
    for relative,identity in json.loads(data).items():
        content = (fixture/relative).read_bytes()
        require(len(content)==identity['bytes'] and hashlib.sha256(content).hexdigest()==identity['sha256'],'Existing regression input changed')
    require(not marker.exists(),'Existing benign marker must be absent before rejection')
    prior = packet.parent/'native_runtime_builds'
    environment = dict(PATH='/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1',OPENSSL_CONF='/opt/conda/ssl/openssl.cnf',
                       OPENSSL_MODULES='/tmp/uwz-h2-native-c8-fix1/empty-providers',PYTHONPATH=str(packet)+':'+str(prior))
    python = ['/home/codespace/.python/current/bin/python3','-B','-S']+(['-O'] if optimized else [])
    commands = [('controller',['/bin/sh',str(packet/'run_control.sh'),'--bytecode-check',str(fixture)]),
                ('loader',python+[str(packet/'run_native.py'),'--provider-admission-check',str(fixture)])]
    violations = []
    for stage,argv in commands:
        result = subprocess.run(argv,cwd='/workspaces/uWebZockets',env=environment,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
        observed = marker.exists()
        (root/(stage+'.stdout')).write_bytes(result.stdout)
        (root/(stage+'.stderr')).write_bytes(result.stderr)
        (root/(stage+'.json')).write_text(json.dumps(dict(argv=argv,status=result.returncode,sentinel_executed=observed),indent=2)+'\n')
        print('eligible_bytecode',stage,'optimized',optimized,'status',result.returncode,'sentinel_executed',observed)
        if observed or result.returncode==0:
            violations.append(stage)
    require(not violations,'Unapproved eligible bytecode executed or was accepted: '+repr(violations))


def main(argv):
    require(len(argv)==2 and argv[0] in ('release','capture','reporting','bytecode') and argv[1].isascii() and argv[1].isalnum() and len(argv[1])<=6,
            'Failure-test control arguments differ')
    packet,manifest,files,absent = runner.bootstrap(source_only=True)
    root = Path('/tmp/uwz-h2-native-c9/fix1_checks')/argv[1]
    root.mkdir(parents=True,mode=0o700)
    if argv[0]=='release':
        release_handoff()
    elif argv[0]=='capture':
        capture_cleanup(root)
    elif argv[0]=='reporting':
        reporting(packet,argv[1])
    else:
        bytecode(packet,root,argv[1])
    print('Failure-contract proof passed:',argv[0])


if __name__=='__main__':
    main(sys.argv[1:])
