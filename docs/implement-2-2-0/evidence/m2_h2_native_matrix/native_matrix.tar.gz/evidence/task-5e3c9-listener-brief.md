# C9 live listener observation: equivalent bounded prefix

Read the complete `task-5e3c9-listener-strategy-review.md` first. Root approves
its exact strategy and constraints, retaining the existing live ownership
predicate. The actual rejected r5 control110 reached 75,422,594 upload bytes
before its unchanged 180-second case deadline. Frequent complete proc-table
reads are a plausible harness cost, not proof of a target throughput defect.
The real four-run acceptance requirement remains unmet.

PRIMARY authority: https://docs.kernel.org/networking/proc_net_tcp.html,
retrieved 2026-11-09. The documented interface emits all listening TCP sockets
before the established-connection section. Root and the SAME independent
reviewer verified this ordering. Rely on that kernel contract explicitly;
do not pretend that an early-stop reader validates its unread tail.

## Ownership and implementation

SAME C9 implementer owns only its existing native_provider packet. Confine
production helper changes to `native_host.py` plus a small named pure parser
module only if it actually adds a bound/invariant. Add focused tests in own
`test_provider.py` or one named listener test file; update source/control
inventories and entrypoint wiring only as required for admission and tests.
No edits to canonical46/native7/C8/candidate/fixtures/binaries/product/pins.
No Netlink protocol, cached ownership, first-match shortcut, new dependency,
new bytecode fixture construction, alternative backend or changed budgets.
You are not alone; preserve all others' changes. Root owns review/docs/Git.

Reopen literal `/proc/net/tcp` for every observation. Use an unbuffered binary
descriptor/stream and small bounded reads. Consume the header and ALL leading
LISTEN rows, preserving order and multiplicity. Stop only on genuine EOF or
after a complete valid non-LISTEN row. Keep every fresh process-start and
complete actual child-FD/inode check; do not cache or fabricate fields.
Ownership still requires exactly the retained owned listener. Completion
still requires no matching IPv4 listener. Duplicate owned LISTEN rows,
including the last row before the non-LISTEN boundary, must still reject.

Bound each read and partial-line storage. Bound total scan/row work if needed,
but exceeding any bound must reject rather than return a partial successful
projection. Header/required-field corruption, incomplete trailing lines and
read failures must reject or propagate; none may become an empty listener set.
Keep parsing/validation pure and file I/O explicit, close each descriptor on
all paths, and preserve the relevant original exception. Shallow named data
contracts, no classes/asserts/mutable module globals/custom errors or unnecessary
abstractions; new nesting at most three.

## Focused evidence and review sequence

Preserve snapshot109 source and control identities and r5 failures unchanged.
Before execution snapshot every amended source/control; reference immutable
large metadata rather than duplicating it. Use pinned Python/fresh119 in the
same Root-cwd shell and the existing independent native/import/bytecode controls.
No actual project cache modifications or private25/key/certificate reads.

Prove complete valid-table projection equivalence, multiple unrelated and
owned listeners, duplicate-at-end refusal, exact ownership and completion
semantics, no-match and EOF, split boundaries/short reads, corrupt/truncated
consumed records, I/O failure and exhausted bounds. Exercise the production
reader/parser, not a mirrored decision model. Check that the reader does not
traverse an arbitrarily large established tail after the complete prefix;
record actual requested/read byte and call bounds with controlled source-only
fixtures. A first-match implementation must fail the duplicate test.

Run focused normal/-O plus relevant inert/foreign-cwd checks. Do not repeat
unchanged old source40/C4-C8 suites. Read-only diagnostic timing of the old and
new proc reader may use the actual local kernel, with sanitized counts and
observed timing, but no new target/socket/signal/certificate operations before
the scoped source review. Do not publish unrelated socket addresses or claim
quiet-host/server throughput results from that diagnostic.

Freeze the resulting source and append exact changes, identities, commands,
outputs and limits to the C9 report. Send the scoped diff against snapshot109
for SAME reviewer approval. New native target runs remain held until PASS and
Root release, then perform fresh r6 (or next unique nonce) and the four original
actual full40 variants. That later actual evidence must establish the workload
finishes under its existing budgets; the source strategy alone proves no speedup.
