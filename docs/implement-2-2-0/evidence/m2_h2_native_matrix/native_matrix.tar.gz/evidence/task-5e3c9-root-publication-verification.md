# C9 publication verification qualification

The four historical native receipts and eight child captures remain unchanged
from the final independent native PASS. The old Root preservation audit still
records terminal1 at the absent C7 candidate root. Physical recovery is a
separate operation and is excluded from this checkpoint; no new native replay,
current preservation pass, production adoption or whole-M2 claim is made.

The retained original Root gates include fresh-runtime seed0x090611c9:
852/852 tests and22/22 steps, warm compiler cache, with negative-path diagnostic
output retained. The earlier cached test invocation is not a second fresh test
run. Format, convention, version, docs and dependency policy gates also passed.
Version remains2.1.6. Those gates exercise the tracked baseline, not a final
production adoption of the isolated candidate and dependency override.

The additional publication AST update completed0 with19824nodes/22931edges.
Its command, fresh119 receipt and raw stdout/stderr/status are copied here under
root-publication-graph names; the originals used publish-graph names. Unsupported
symbol/sequential-fallback warnings and the semantic-update tip remain raw;
no model API extraction or ignored-helper topology coverage is claimed.
Final documentation/link and whitespace outputs are copied under
root-publication-docs and root-publication-whitespace names. These narrow checks
cover the final prose corrections without repeating unchanged native/unit runs.

The first metadata-copy command used dots where four original graph filenames
used hyphens. Those four reads failed without changing evidence; corrected
explicit names were copied afterward. This was metadata bookkeeping, not a
failed Graph or native execution.
