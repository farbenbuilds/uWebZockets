"""Create the scoped source diff from the preserved review baseline."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sources(directory):
    result = {}
    for path in sorted(directory.iterdir()):
        if path.suffix not in ('.py', '.sh') and path.name != 'source.sha256':
            continue
        require(path.is_file() and not path.is_symlink(), 'Invalid source member')
        result[path.name] = path
    return result


def identity(path):
    if path is None:
        return None
    data = path.read_bytes()
    data.decode('utf-8')
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def difference(before, after):
    command = ['git', 'diff', '--no-index', '--no-ext-diff', '--no-textconv', '--',
               str(before) if before else '/dev/null', str(after) if after else '/dev/null']
    environment = dict(PATH='/usr/bin:/bin', GIT_CONFIG_NOSYSTEM='1',
                       GIT_CONFIG_GLOBAL='/dev/null', GIT_TERMINAL_PROMPT='0')
    result = subprocess.run(command, env=environment, capture_output=True)
    require(result.returncode in (0, 1) and not result.stderr, 'Source diff failed')
    result.stdout.decode('utf-8')
    return result.stdout


def prepare():
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    before = sources(plan / 'task-5e3c9-fix1-base')
    after = sources(Path('.uwz-work/evidence/h2-streaming/native_provider'))
    rows = {}
    patches = []
    for name in sorted(set(before) | set(after)):
        old, new = identity(before.get(name)), identity(after.get(name))
        rows[name] = dict(before=old, after=new, changed=old != new)
        if old != new:
            patches.append(difference(before.get(name), after.get(name)))
    data = b''.join(patches)
    (plan / 'task-5e3c9-fix1-review-package.diff').write_bytes(data)
    result = dict(package_bytes=len(data), package_sha256=hashlib.sha256(data).hexdigest(),
                  files=rows, changed_files=[name for name, row in rows.items() if row['changed']])
    (plan / 'task-5e3c9-fix1-review-package.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'files'}))


def main(arguments):
    if arguments == ['--prepare']:
        prepare()


if __name__ == '__main__':
    main(sys.argv[1:])
