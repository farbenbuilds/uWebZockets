**The strategy preserves the existing IPv4 listener predicate for valid, ordered `/proc/net/tcp` output.** Linux documents that listening sockets precede established connections. [Linux kernel documentation](https://docs.kernel.org/networking/proc_net_tcp.html)

Required constraints:

- Reopen the file on every observation; retain the fresh process-start check and complete child-FD/inode correlation.
- Scan **every LISTEN row**, preserving multiplicity and order. Never stop at the first matching socket or deduplicate matches; a duplicate at the prefix’s end must still reject ownership.
- Stop only after a complete, valid non-LISTEN row or genuine EOF. Validate the header and required fields. Reject malformed rows, incomplete trailing lines, read failures, and exhausted bounds; never interpret truncation as “no listener.”
- Bound individual reads and retained partial-line storage. If imposing a total-byte or row limit, exceeding it must reject rather than accept a partial prefix.
- Use an unbuffered descriptor or binary stream. Buffered `readline()` can read ahead into the established-connection tail and undermine the intended reduction in work.
- Keep both callers’ semantics: ownership requires exactly the retained owned listener; completion requires no matching IPv4 listener.

This is equivalence under the documented kernel ordering, **not** arbitrary malformed or reordered input: an early-stop reader cannot validate the unread tail. Tests should explicitly cover malformed/truncated consumed input and a duplicate at the last LISTEN row.

The strategy does not establish a speedup or resolve the 180-second failure by itself. Preserve the budgets and obtain measured evidence after the scoped implementation review.
