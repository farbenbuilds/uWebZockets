# C9: real owned provider and four actual native HTTP/2 all40 runs

Read `task-5e3c9-plan-report.md` FIRST: concrete interfaces, reusable archived
host algorithms, independent capacity provenance and acceptance ordering.
BASE67a8be8b4a6a4aa35e94fae68d53d0f7d2dd3c7b is reviewed/pushed/clean.
C8 corrected source, input closure and fresh binaries are accepted. This task
must implement the actual provider and execute the required native matrix.

Own only NEW `.uwz-work/evidence/h2-streaming/native_provider/` source, focused
tests, controls and evidence, and exclusive `/tmp/uwz-h2-native-c9/` run state.
You are sole implementer, not alone: preserve all other changes. No subagents,
Root Git/publication/docs writes, network beyond owned localhost tests,
dependency installation, product/pin edits, historical helper/evidence edits,
C7 re-materialization or compiler rebuilds. Root handles domain consultations,
review, docs, commit and immediate push. Read AGENTS/CODING_CONVENTION and
relevant verification/transport_io/crypto_tls instructions and narrow skills.
Graphify before new codebase questions; supplied paths are already located.

## Accepted handoff

Authenticate `docs/implement-2-2-0/evidence/m2_h2_native_builds/native_builds.tar.gz`,
SHA e3b8fe1c3c0a5f99a8144752eddab62f5568dcf6c9f7a51719bd669f3b6874a0.
Current C8 packet is `.uwz-work/evidence/h2-streaming/native_runtime_builds/`.
Use corrected `preflight-fix1.json` SHA
e78cbbc2f1665e6999a5502f2817be531909a80d72e1dbd0fd22055dc93bb53c and
`output-native-closure-fix1.json` SHA
334a4c9e27b9837f9aa65bd01ffcc01328e79fdc59e003f5236bcd23921b0cd5.
The current source/control inventory SHA is
f343b91b79ea31b89190475512f6c6bf5007459d9816a9b5dae8e99efb5c33ad.

Actual accepted binaries, never previously executed:
- `/tmp/uwz-h2-native-c8-fix1/debug/profile`,72174904bytes,
  SHA4c89d63f760f467315e83d8c40021f49335b432490e9a06f8cf3f604e69bb476.
- `/tmp/uwz-h2-native-c8-fix1/release/profile`,31072272bytes,
  SHA94510b8b95880b084f5a2250fd825db181cc9f1320d36f59130f3bdcf64d2f10.
Derive selection from exact receipt/argv and recheck actual identities.
Original non-fix1 runtime acceptance is unestablished and cannot be reused.
Fixture25/C7candidate1031/libxev93/SDK19542/zslay14/sixarchives remain fixed;
production c49 pin stays unchanged. Retain before/after identity checks.

C6c accepted native7 and canonical46 stay unchanged. Primary native authority:
`m2_h2_native_active/native-active.tar.gz` SHA
6fda8cfaac4b8c866ff352848c12397a9775a7bd09397f1db7c9740707c50b14;
transport1ed1d45eab45820ba5e619aaa10525ad5e77e092ac3478c131bc15682e113d1b,
coordinator6585ad2323ce38a75948c7c365ceb7b9589c06e1c6010ae01ba35de0f11e6b32.
Authenticate archived host-algorithm sources before adaptation; never import
obsolete five-key factories or duplicate protocol/case/closing/post parsers.

## Implementation and runtime controls

Use only minimal explicit data/function modules `native_host.py`,
`native_provider.py`, `run_native.py` and focused tests/controls. No classes,
asserts/custom errors/mutable module globals; new nesting<=3. Stdlib objects
may implement OS/SSL operations, with all owned state passed explicitly.
Reuse canonical `h2_client.new_protocol` and accepted native_transport APIs,
including actual post-open bind_context and conditional public unwrap.

Extend C8's reviewed closure with exact new source/import identities BEFORE
effects. Preserve P1's independent prior native approvals: discovery never
authorizes itself. Identity-bound unused extensions with no approved graph
must reject before loading. If new native dependencies genuinely need approval,
identify their authenticated authority or report exact missing paths to Root.
Do not bless discovered current hashes or weaken import/bytecode/mapping gates.
Use explicit env-i bootstrap controls, ordered codecs, approved origins,
OpenSSL config/provider rules, actual loaded mappings and before/after checks.
No interpreter/toolchain/Graphify copies.

TLS must actually verify localhost/certificate, negotiateTLS1.3+h2, and disable
ragged EOF suppression. Map actual socket/SSL operations to the exact accepted
contracts, including failed-wrap ownership, returned-unwrap handle/raw EOF/
normal close, one-shot failure cleanup and live receipts. Preserve the exact
primary exception, bounded separate cleanup errors, canonical caller bare
rethrow and actual final ordered receipt aggregation.

Bind owned SIGTERM to actual child PID/start/listener, watcher/source/build/
nonce-bound READY proof, exact open client and ordered real operation ticks.
Watcher attestation is source/build/startup-order plus actual capture, not a
fabricated object/Boolean or a claim of direct OS object inspection. Do not
require continued process/listener existence after successful signal. Idle
normal-client shutdown uses its separate host path; active C6c signal does
not apply to idle/ordinary closure. Canonical code alone begins/finishes
termination. Capture/watcher evidence must exist before signaling.

## Focused proof and actual execution

TDD tests must cover readiness/signal ownership, missing capture/exit/post,
failed cleanup, duplicate release, strict unwrap and failure-boundary handling.
Use focused normal/-O and inert/foreign-cwd import/CLI checks; distinguish true
behavioral RED from absent-interface errors. Do not repeat unchanged C4-C8
suites. Snapshot every exercised source/control before runs.

Root explicitly authorizes local certificate/key generation and real owned
server/client/socket/SSL/clock/SIGTERM operations after focused checks and full
runtime preflight pass. Use a new exclusive subdirectory/nonces for each run
and preserved failure; never repair/delete a previous run. Native loopback or
kernel-I/O sandbox refusals may use escalation for the unchanged exact control,
with captured original failure; never change backend or skip cases to pass.

Execute BOTH full40 variants in BOTH Debug and ReleaseSafe: four actual runs.
Explicit passes catalogue.CASES; default genuinely omits selection from the
coordinator call. Each has fresh idle/main children and41connections, retaining
ready15 once perchild/whole900/case30-or180/clippedgrace<=15 integer-ns deadlines.
No budget reset, filtered matrix, synthetic logs, copied observed counters or
simulated post facts. Record actual100MB hashes/output/file facts, generations,
scheduling and bounded-memory facts. Native generation must not be hardcoded18.

Use the independently authenticated FULL native capacity from output-driver
manifest-v5 after candidate/config/layout equality, never test_native_post's
synthetic value or this run's observed capacity as its expectation. Nonces are
declared before spawn, unique/run/child, grammar[A-Za-z0-9_]{1,32}. Native log
markers include `info: H2_CAPACITY`; preserve fixture/capture62144/65536 bounds.

Acceptance requires actual exit0/reap, listener disappearance, completed
healthy bounded capture, C5 parse_capture/validate_post over real capture and
frozen actual pre-facts, normal client/file/key/certificate cleanup and final
live receipt revalidation. Forced cleanup or missing terminal evidence rejects
even with a valid local closing tuple. Keep ordinary seals+active prefix
separate from closing deltas/debt; retain C4's unknown/internal-prefix and
unauthenticated-closure limits. Keep actual evidence available through errors.

Never publish private certificate/key bytes. They may be read only as required
for this owned TLS test. NEVER read/hash/copy the25 prior private native-post
environment originals; no ambient environment dumps. New raw controls contain
only explicit safe settings. Retain full outputs/status, sanitized ownership
and cleanup facts, source hashes and actual command/receipt identities.

Every dependent Python shell uses pinned
`/home/codespace/.python/current/bin/python3 -B -S`,
SHA4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601,
PYTHONDONTWRITEBYTECODE=1, pre-start C8 bootstrap checks and fresh unchanged
task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT in the SAME
Root-cwd shell. Restore before changing to foreign cwd. Authenticate all
additional helpers and source bytes before behavior. No old receipt reuse.
Use /tmp for large runtime data/cache; workspace1.8GiB free, /tmp32GiB free.
Do not delete evidence, zig-pkg, zig-out/lib or/tmp/uwz-original-zig-cache.

If the real target fails, retain precise case/control/capture/error and report
the owning source defect; do not edit accepted sources or weaken acceptance.
Full report<=1400words at task-5e3c9-report.md: status, changedfiles, exact
commands/results and four run receipts, self-review and unresolved limits.
Return short status/results/report path. Actual native all40 is this task's
target; H3, adoption, repository/platform/release and full M2 remain later.
