#!/bin/sh
set -eu
cd /workspaces/uWebZockets
packet=/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native_provider
prior=/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native_runtime_builds
root=/tmp/uwz-h2-native-c9
name=$1
shift
mkdir "$packet/snapshots/$name"
cp "$packet"/*.py "$packet"/*.sha256 "$packet/run_control.sh" "$packet/snapshots/$name/"
mkdir "$packet/snapshots/$name/native" "$packet/snapshots/$name/canonical" "$packet/snapshots/$name/core" "$packet/snapshots/$name/contract" "$packet/snapshots/$name/client" "$packet/snapshots/$name/c8"
cp "$packet/../combined-native/"*.py "$packet/snapshots/$name/native/"
cp "$packet/../integration-owned/combined-cases/"*.py "$packet/snapshots/$name/canonical/"
cp /tmp/uwz-task5e3a-snapshot-v9/source/*.py "$packet/snapshots/$name/core/"
cp /tmp/uwz-task5e1-contract-v3/*.py "$packet/snapshots/$name/contract/"
cp "$packet/../integration-client/h2_client.py" "$packet/snapshots/$name/client/"
cp "$prior"/*.py "$prior"/*.sha256 "$prior/run_control.sh" "$packet/snapshots/$name/c8/"
printf '%s\n' 'Large immutable metadata stays at its authenticated C8 paths; identities are in c8/frozen-current-fix1.sha256.' > "$packet/snapshots/$name/c8/metadata-reference.txt"
sha256sum "$packet"/*.py "$packet"/*.sha256 "$packet/run_control.sh" > "$packet/snapshots/$name/code.sha256"
sha256sum -c "$packet/snapshots/$name/code.sha256" > "$packet/raw/${name}_source-check.stdout"
sha256sum -c "$prior/bootstrap.sha256" > "$packet/raw/${name}_bootstrap-check.stdout"
sha256sum -c "$prior/metadata-tools.sha256" > "$packet/raw/${name}_metadata-tools-check.stdout"
sha256sum -c "$prior/bootstrap-data.sha256" > "$packet/raw/${name}_bootstrap-data-check.stdout"
printf '%s\n' 'f343b91b79ea31b89190475512f6c6bf5007459d9816a9b5dae8e99efb5c33ad  /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native_runtime_builds/frozen-current-fix1.sha256' | sha256sum -c - > "$packet/raw/${name}_c8-inventory-check.stdout"
sha256sum -c "$prior/frozen-current-fix1.sha256" > "$packet/raw/${name}_c8-check.stdout"
sha256sum -c "$packet/source.sha256" > "$packet/raw/${name}_provider-check.stdout"
test ! -e /etc/ld.so.preload
test ! -e /home/codespace/.python/current/lib/python314.zip
printf '%s\n' 'aa6d5a881925917f4254f518643e5dbb888ba1d163fafe73d1c857b491c69dea  /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py' | sha256sum -c - > "$packet/raw/${name}_restore-source-check.stdout"
export PYTHONDONTWRITEBYTECODE=1
export OPENSSL_CONF=/opt/conda/ssl/openssl.cnf
export OPENSSL_MODULES=/tmp/uwz-h2-native-c8-fix1/empty-providers
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore "$root/restore-$name.json" > "$packet/raw/${name}_restore.stdout" 2> "$packet/raw/${name}_restore.stderr"
export PYTHONPATH="$packet:$prior"
printf '%s\n' "$@" > "$packet/raw/$name.argv"
set +e
/home/codespace/.python/current/bin/python3 -B -S "$@" > "$packet/raw/$name.stdout" 2> "$packet/raw/$name.stderr"
status=$?
set -e
printf '%s\n' "$status" > "$packet/raw/$name.exit"
exit "$status"
