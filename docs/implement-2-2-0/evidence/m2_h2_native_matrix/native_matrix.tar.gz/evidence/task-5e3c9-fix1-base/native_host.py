"""Owned Linux/TLS effects adapted from authenticated output-driver algorithms."""
import hashlib
import os
from pathlib import Path
import signal
import socket
import ssl
import subprocess
import threading
from functools import partial
import native_provider as provider


def remaining(clock, deadline):
    tick = clock()
    provider.require(type(tick) is int and tick < deadline, 'host deadline expired')
    return (deadline-tick)/1000000000


def process_start(pid):
    text = Path('/proc',str(pid),'stat').read_text()
    fields = text[text.rfind(')')+2:].split()
    provider.require(len(fields)>19 and fields[19].isdigit(),'invalid process start')
    return fields[19]


def listener_rows():
    return [row.split() for row in Path('/proc/net/tcp').read_text().splitlines()[1:]]


def listeners(pid):
    links = []
    for entry in Path('/proc',str(pid),'fd').iterdir():
        try:
            links.append(os.readlink(entry))
        except FileNotFoundError:
            continue
    inodes = {link[8:-1] for link in links if link.startswith('socket:[') and link.endswith(']')}
    return tuple(row[9] for row in listener_rows() if row[1]=='0100007F:6F1B' and row[3]=='0A' and row[9] in inodes)


def ownership(child):
    process = child['process']
    running = process.poll() is None
    start = process_start(child['pid']) if running else ''
    actual = listeners(child['pid']) if running else ()
    owned = actual == (child['listener_inode'],)
    return dict(pid=child['pid'], running=running, start_identity=start,
                listeners=(child['listener'],) if owned else ())


def snapshot(child):
    capture = child['capture']
    with capture['lock']:
        return dict(bytes=bytes(capture['bytes']),overflow=capture['overflow'],error=capture['error'],finished=capture['finished'])


def capture_health(child):
    result = snapshot(child)
    return dict(overflow=result['overflow'],error=result['error'],complete=result['finished'])


def collect(capture, pipe):
    try:
        while True:
            data = os.read(pipe.fileno(),8192)
            if not data:
                break
            collect_chunk(capture,data)
    except BaseException as error:
        with capture['lock']:
            capture['error'] = error
    finally:
        with capture['lock']:
            capture['finished'] = True
            capture['event'].set()


def collect_chunk(capture,data):
    provider.require(type(data) is bytes and len(data)<=8192,'collector read bound')
    with capture['lock']:
        room = 65536-len(capture['bytes'])
        capture['bytes'].extend(data[:room])
        capture['overflow'] = capture['overflow'] or len(data)>room
        capture['event'].set()


def readiness(child,config,deadline,clock):
    expected = (('info: H2_CAPACITY '+config['capacity']+'\n').encode(),('info: H2_READY '+child['nonce']+'\n').encode())
    while True:
        data = snapshot(child)
        provider.require(data['overflow'] is False and data['error'] is None,'readiness capture failure')
        provider.require(child['process'].poll() is None,'child exited before readiness')
        entries = tuple(line for line in data['bytes'].splitlines(keepends=True) if line.startswith(b'info: H2_'))
        if expected[1] in entries:
            provider.require(entries==expected,'readiness markers differ')
            actual = listeners(child['pid'])
            provider.require(len(actual)==1,'owned listener differs')
            child['listener_inode'] = actual[0]
            child['watcher'] = dict(pid=child['pid'],start=child['start'],listener=child['listener'],nonce=child['nonce'],
                                    source_sha256=config['source_sha256'],binary_sha256=config['binary_sha256'],
                                    order=('listen','catch_shutdown_signals','H2_READY','run'),ready=('info: H2_READY '+child['nonce']+'\n').encode())
            provider.validate_ready(child)
            return clock()
        provider.require(not data['finished'],'capture ended before readiness')
        child['capture']['event'].wait(min(0.01,remaining(clock,deadline)))
        child['capture']['event'].clear()


def new_child(config,index,ready,whole,clock):
    directory = Path(config['directory'])/('child_'+str(index))
    directory.mkdir(mode=0o700)
    cert,key,transfer = (directory/name for name in ('certificate.pem','private-key.pem','transfer.bin'))
    child = dict(directory=directory,cert=cert,key=key,transfer=transfer,nonce=config['nonces'][index],
                 process=None,pid=None,start=None,listener=('127.0.0.1',28443),listener_inode=None,
                 source_sha256=config['source_sha256'],binary_sha256=config['binary_sha256'],watcher=None,capture=None,
                 handles=[],closed_handles=[],wrap_candidates=[],signaled=False,signal_evidence=None,forced=False,process_status=None,
                 reaped=False,listener_gone=False,joined=False,pipe_closed=False,removed=False,post=None,cleanup_started=False,
                 cleanup_errors=[],transport=None,before=None,process_facts=None,events=[])
    config['pending'].append(child)
    argv = ['/opt/conda/bin/openssl','req','-x509','-newkey','rsa:2048','-nodes','-days','1',
            '-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost','-keyout',str(key),'-out',str(cert)]
    environment = dict(OPENSSL_CONF='/opt/conda/ssl/openssl.cnf',OPENSSL_MODULES='/tmp/uwz-h2-native-c8-fix1/empty-providers')
    result = subprocess.run(argv,env=environment,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=remaining(clock,ready),check=False)
    (directory/'certificate-command.json').write_text(__import__('json').dumps(dict(argv=argv,environment=environment,status=result.returncode)))
    (directory/'certificate.stdout').write_bytes(result.stdout)
    (directory/'certificate.stderr').write_bytes(result.stderr)
    provider.require(result.returncode==0 and len(result.stdout)<=65536 and len(result.stderr)<=65536,'certificate generation failed')
    key.chmod(0o600)
    child['certificate_sha256'] = hashlib.sha256(ssl.PEM_cert_to_DER_cert(cert.read_text())).hexdigest()
    context = ssl.create_default_context(cafile=str(cert))
    context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_3
    context.set_alpn_protocols(['h2'])
    child['tls_context'] = context
    environment = dict(H2_PROFILE_CERT=str(cert),H2_PROFILE_KEY=str(key),H2_PROFILE_NONCE=child['nonce'],H2_PROFILE_FILE=str(transfer))
    child['environment'] = environment
    child['argv'] = [config['binary']]
    process = subprocess.Popen(child['argv'],env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    child.update(process=process,pid=process.pid,start=process_start(process.pid))
    capture = dict(lock=threading.Lock(),event=threading.Event(),bytes=bytearray(),overflow=False,error=None,finished=False)
    child['capture'] = capture
    thread = threading.Thread(target=collect,args=(capture,process.stdout),daemon=True)
    child['thread'] = thread
    thread.start()
    child['ready_at'] = readiness(child,config,ready,clock)
    return child


def dial(child,address,seconds):
    provider.require(address==child['listener'],'foreign dial address')
    raw = socket.create_connection(address,timeout=seconds)
    child['handles'].append(raw)
    return raw


def wrap(child,raw,hostname,suppress,seconds):
    provider.require(hostname=='localhost' and suppress is False,'TLS wrap policy')
    duplicate = raw.dup()
    candidate = dict(handle=duplicate,cleanup_started=False,closed=False,transferred=False)
    child['wrap_candidates'].append(candidate)
    wrapped = None
    try:
        duplicate.settimeout(seconds)
        wrapped = child['tls_context'].wrap_socket(duplicate,server_hostname=hostname,suppress_ragged_eofs=suppress,do_handshake_on_connect=False)
        candidate['handle'] = wrapped
        wrapped.do_handshake()
        raw.close()
    except BaseException:
        cleanup_candidate(child,candidate)
        raise
    child['closed_handles'].append(raw)
    child['handles'].append(wrapped)
    candidate['transferred'] = True
    return wrapped


def cleanup_candidate(child,candidate):
    if candidate['cleanup_started'] or candidate['closed'] or candidate['transferred']:
        return
    candidate['cleanup_started'] = True
    try:
        candidate['handle'].close()
        candidate['closed'] = True
    except BaseException as secondary:
        provider.require(len(child['cleanup_errors'])<2,'TLS cleanup error bound')
        child['cleanup_errors'].append(secondary)


def inspect(child,handle):
    context = handle.context
    return dict(tls=handle.version(),alpn=handle.selected_alpn_protocol(),hostname=handle.server_hostname,
                check_hostname=context.check_hostname,certificate_verified=context.verify_mode==ssl.CERT_REQUIRED and bool(handle.getpeercert()),
                certificate_sha256=hashlib.sha256(handle.getpeercert(binary_form=True)).hexdigest(),suppress_ragged_eofs=handle.suppress_ragged_eofs)


def unwrap(child,handle):
    raw = handle.unwrap()
    provider.require(raw is not None,'unwrap returned no owned handle')
    if raw is not handle:
        child['closed_handles'].append(handle)
        child['handles'].append(raw)
    return raw


def close(child,handle):
    return provider.release_handle(child,handle,lambda owned:owned.close())


def full_send(child,clock,handle,data):
    row = child['transport']['current']
    deadline = min(row['case_deadline'],row['whole_deadline'])
    if row['signal_deadline'] is not None:
        deadline = min(deadline,row['signal_deadline'])
    view = memoryview(data)
    while view:
        handle.settimeout(remaining(clock,deadline))
        sent = handle.send(view)
        provider.require(type(sent) is int and 0<sent<=len(view),'TLS partial send made no progress')
        view = view[sent:]


def transport_ops(child,new_protocol,selection,clock):
    result = dict(dial=partial(dial,child),wrap=partial(wrap,child),inspect=partial(inspect,child),
                  set_timeout=lambda handle,seconds:handle.settimeout(seconds),send=partial(full_send,child,clock),
                  recv=lambda handle,maximum:handle.recv(maximum),close=partial(close,child),
                  ownership=partial(ownership,child),capture=partial(capture_health,child),new_protocol=new_protocol)
    if 'disconnect' in selection:
        result['unwrap'] = partial(unwrap,child)
    return result


def send_signal(child,binding,handle,deadline,clock):
    now = clock()
    provider.signal_prerequisites(child,handle,deadline,now)
    actual = ownership(child)
    provider.require(actual==dict(pid=child['pid'],running=True,start_identity=child['start'],listeners=(child['listener'],)),'signal process ownership changed')
    observed = clock()
    prerequisites = (child['pid'],child['start'],child['listener'],child['watcher'],handle,observed)
    child['signaled'] = True
    operation_tick = clock()
    provider.require(observed<=operation_tick<deadline,'signal operation deadline expired')
    result = os.kill(child['pid'],signal.SIGTERM)
    returned = clock()
    operation = ('SIGTERM',child['pid'],child['start'],child['watcher'],handle,operation_tick,result)
    facts = dict(signal='SIGTERM',owned_identity=True,watcher_installed=True,client_open=handle is not None)
    evidence = (facts,binding,handle,prerequisites,operation,returned)
    child['signal_evidence'] = evidence
    return evidence


def complete(child,deadline,clock):
    provider.require(child['signaled'] and not child['forced'],'normal completion requires signal')
    child['process_status'] = child['process'].wait(timeout=remaining(clock,deadline))
    child['reaped'] = child['process'].returncode is not None
    child['thread'].join(timeout=remaining(clock,deadline))
    child['joined'] = not child['thread'].is_alive()
    provider.require(child['joined'],'collector did not finish')
    child['process'].stdout.close()
    child['pipe_closed'] = child['process'].stdout.closed
    child['listener_gone'] = not any(row[1]=='0100007F:6F1B' and row[3]=='0A' for row in listener_rows())
    captured = snapshot(child)
    (child['directory']/'capture.bin').write_bytes(captured['bytes'])
    provider.require(not captured['overflow'] and captured['error'] is None and captured['finished'],'incomplete capture')
    provider.require(child['process_status']==0 and child['reaped'] and child['listener_gone'],'process did not normally exit/reap/release listener')
    return captured


def remove_owned(child):
    provider.require(all(handle in child['closed_handles'] for handle in child['handles']),'open client at cleanup')
    provider.require(all(row['closed'] or row['transferred'] for row in child['wrap_candidates']),'unreleased TLS candidate')
    for name in ('key','transfer','cert'):
        child[name].unlink()
    child['removed'] = all(not child[name].exists() for name in ('cert','key','transfer'))
    provider.require(child['removed'],'owned file cleanup failed')


def cleanup(child,error,clock):
    if child['cleanup_started']:
        return
    child['cleanup_started'] = True
    deadline = clock()+15000000000
    for candidate in child['wrap_candidates']:
        cleanup_candidate(child,candidate)
    for handle in child['handles']:
        cleanup_handle(child,handle)
    process = child['process']
    if process is None:
        cleanup_files(child)
        return
    try:
        cleanup_process(child,deadline,clock)
    except BaseException as secondary:
        child['cleanup_errors'].append(repr(secondary))
    if child['capture'] is not None:
        (child['directory']/'failure-capture.bin').write_bytes(snapshot(child)['bytes'])
    cleanup_files(child)


def cleanup_handle(child,handle):
    if handle in child['closed_handles']:
        return
    try:
        close(child,handle)
    except BaseException as secondary:
        child['cleanup_errors'].append(repr(secondary))


def cleanup_process(child,deadline,clock):
    process = child['process']
    if process.poll() is None:
        provider.require(process_start(process.pid)==child['start'],'foreign cleanup process')
        child['forced'] = True
        process.kill()
    child['process_status'] = process.wait(timeout=remaining(clock,deadline))
    child['reaped'] = True
    if 'thread' in child:
        child['thread'].join(timeout=remaining(clock,deadline))
        child['joined'] = not child['thread'].is_alive()
    if process.stdout is not None:
        process.stdout.close()
        child['pipe_closed'] = process.stdout.closed


def cleanup_files(child):
    for name in ('cert','key','transfer'):
        try:
            child[name].unlink(missing_ok=True)
        except BaseException as secondary:
            child['cleanup_errors'].append(repr(secondary))


def operations(clock):
    return dict(new_child=partial(new_child,clock=clock),transport_ops=partial(transport_ops,clock=clock),
                signal=partial(send_signal,clock=clock),complete=partial(complete,clock=clock),
                remove=remove_owned,cleanup=partial(cleanup,clock=clock),snapshot=snapshot)
