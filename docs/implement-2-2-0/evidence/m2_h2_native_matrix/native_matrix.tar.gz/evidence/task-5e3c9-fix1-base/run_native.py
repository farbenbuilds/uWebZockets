"""Authenticate explicit closure before importing provider or host effects."""
import hashlib
import json
from pathlib import Path
import sys
import subprocess
import runtime_closure as r


def bootstrap(source_only=False):
    root = Path('/workspaces/uWebZockets')
    packet = root / '.uwz-work/evidence/h2-streaming/native_provider'
    prior = packet.parent / 'native_runtime_builds'
    controls = [('preflight-fix1.json','e78cbbc2f1665e6999a5502f2817be531909a80d72e1dbd0fd22055dc93bb53c'),
                ('output-native-closure-fix1.json','334a4c9e27b9837f9aa65bd01ffcc01328e79fdc59e003f5236bcd23921b0cd5')]
    for name,pin in controls:
        r.require(hashlib.sha256((prior/name).read_bytes()).hexdigest()==pin,'C8 authority changed')
    manifest = json.loads((prior/'preflight-fix1.json').read_bytes())
    import native_override as override
    authority = override.authenticate(root)
    files = override.apply(manifest['files'],authority,root)
    for line in (packet/'source.sha256').read_text().splitlines():
        pin,path = line.split('  ',1)
        path = str(root/path) if not Path(path).is_absolute() else path
        override.owned_path(packet,files,path)
        identity = r.file_identity(path)
        r.require(identity['sha256']==pin and identity['resolved']==path,'New source changed')
        files[path] = identity
    for name in ('source.sha256','run_control.sh'):
        path = str(packet/name)
        r.require(path not in files,'Duplicate provider control admission')
        files[path] = r.file_identity(path)
    archive = authority['archive']
    r.require(archive['path'] not in manifest['authorities'],'Published authority unexpectedly replaces C8 control')
    authorities = dict(manifest['authorities'])
    authorities[archive['path']] = archive
    manifest = dict(manifest,files=files,authorities=authorities,c9_override=authority)
    sys.path.extend([str(packet.parent/'combined-native'),str(packet.parent/'integration-owned/combined-cases'),
                     str(packet.parent/'integration-client'),'/tmp/uwz-task5e1-contract-v3',
                     '/tmp/uwz-task5e3a-snapshot-v9/source','/tmp/uwz-h2-client-tooling/packages'])
    absent = r.eligible_bytecode(files)
    for path,identity in files.items():
        r.verify_file(path,identity)
    graph,extension = hostname_graph(manifest,files,source_only)
    manifest = dict(manifest,runtime=dict(manifest['runtime'],elf=graph),c9_native_extension=extension)
    r.install_guard(files,manifest['runtime']['interpreter'],graph)
    __import__('encodings.idna')
    reject_unused(files,graph)
    return packet,manifest,files,absent


def hostname_graph(manifest,files,source_only):
    import native_metadata as metadata
    import replay_builds as replay
    path = '/usr/local/python/3.14.2/lib/python3.14/lib-dynload/unicodedata.cpython-314-x86_64-linux-gnu.so'
    r.require(files[path]['sha256']=='e2703688aaed27d6bd1b53819551ed64135db45d7e6a7b1001c65816db40d238' and
              files[path]['bytes']==863544,'C8-approved IDNA extension identity differs')
    paths = [path]
    if source_only:
        roots = {'_heapq':'5b28d7053388cfa96ea1758a79484b52b76a15d468aaf47a072c3d94d539d22a',
                 '_asyncio':'695795a0f9114717c9213b4d35f68a9e6932812008fb0cc6cb4a13e3b237cb18',
                 '_bisect':'f35a5bbe1ee4e93d0f185c9b1f542756ff618d13d0a48d3fef5d634fea0c741f',
                 '_queue':'51ae7bd4dfa20fda045290b915de86589bf12df367aee5e3bbb6f423c4fa41a9',
                 '_pickle':'2383671444ecba2c8efd3a561c725e1b1b2498a143fda79bf4287ee9dac4394d',
                 '_interpreters':'4901490cd257cbe8d9b3fd47b4acdaa0c0b0473cff9e2a6b15f444976f8cb330',
                 'array':'458f47d9981e55e5336748816786961e3d371070414c844e16d92f8f4431eb45'}
        for name,pin in roots.items():
            origin = str(Path(path).parent/(name+'.cpython-314-x86_64-linux-gnu.so'))
            r.require(files[origin]['sha256']==pin,'C8-approved source-test extension differs')
            paths.append(origin)
    extension = metadata.closure(paths)
    replay.admit_native_closure(files,extension)
    graph = dict(manifest['runtime']['elf'])
    graph.update(extension)
    return graph,extension


def reject_unused(files,graph):
    try:
        r.guard_spec(files,'_csv',dependencies=graph)
    except ValueError as error:
        r.require('Unknown native dependency:' in str(error),'Unused extension rejected for wrong reason')
        r.require('_csv' not in sys.modules,'Unused extension loaded before rejection')
        return
    raise ValueError('Unused identity-bound extension accepted without approved graph')


def runtime_authority(packet,manifest,files):
    import build_inputs as b
    import native_host
    import native_transport
    import coordinator
    import catalogue
    base = Path('/workspaces/uWebZockets/docs/implement-2-2-0/evidence')
    archive = base/'m2_h2_output_driver/output-driver.tar.gz'
    inventory = b.archive_index(archive,'6ebc819a8407f43b8b9aafd26b0fe5c52f4345c43e30b32584f8eb896d4544dd')
    historical = b.member_bytes(archive,inventory,'provenance/manifest-v5.json')
    r.require(hashlib.sha256(historical).hexdigest()=='aab3dda65e16b0475ccb59de28028a2d324ee81c7c05dc6c48daf909f6ae9890','Historical capacity authority differs')
    r.require(historical==(packet.parent/'native_runtime_builds/historical-manifest-v5.json').read_bytes(),'C8 authority not identical')
    old = json.loads(historical)
    for label,oldroot in [('candidate','/tmp/uwz-task4d-fix1-frozen'),('libxev','/tmp/uwz-reviewed-libxev-c223-loop-callbacks')]:
        actual = {name:row['sha256'] for name,row in manifest['exports'][label].items()}
        r.require(actual==old['trees'][oldroot],'Independent capacity candidate/layout input differs')
    fixture = Path('/tmp/uwz-h2-native-c8-fix1/inputs/fixture/profile.zig').read_bytes()
    older = b.member_bytes(archive,inventory,'source/fixture/profile.zig')
    declaration = b'config: uz.ServerConfig = .{'
    config = fixture.split(declaration,1)[1].split(b'\n};',1)[0]
    r.require(config==older.split(declaration,1)[1].split(b'\n};',1)[0],'Explicit fixture config differs')
    order = [fixture.index(text) for text in (b'try server.listen(',b'try server.catch_shutdown_signals();',b'std.log.info("H2_READY ',b'try server.run();')]
    r.require(order==sorted(order) and len(set(order))==4,'Watcher startup source ordering differs')
    algorithms = {name:inventory['source/runtime/'+name] for name in ('identity.py','process_io.py','capture.py','process_setup.py','connection.py','process_shutdown.py')}
    for name in algorithms:
        b.member_bytes(archive,inventory,'source/runtime/'+name)
    closure = json.loads((packet.parent/'native_runtime_builds/output-native-closure-fix1.json').read_bytes())
    modes = {}
    for mode in ('debug','release'):
        directory = Path('/tmp/uwz-h2-native-c8-fix1')/mode
        command = json.loads((directory/'command.json').read_bytes())
        receipt = json.loads((directory/'receipt.json').read_bytes())
        emit = [arg[len('-femit-bin='):] for arg in command['argv'] if arg.startswith('-femit-bin=')]
        r.require(command['argv']==manifest['remaps'][mode][0] and command['cwd']==manifest['cwd'] and
                  command['preflight_sha256']=='e78cbbc2f1665e6999a5502f2817be531909a80d72e1dbd0fd22055dc93bb53c','Compiler receipt binding differs')
        r.require(receipt['status']==0 and receipt['inputs_preserved'] and emit==[receipt['binary']['path']],'Actual binary selection differs')
        modes[mode] = r.verify_file(emit[0],closure['modes'][mode]['binary'])
    capacity = old['capacity'].removeprefix('H2_CAPACITY ')
    return dict(archive=r.file_identity(archive),historical_sha256=hashlib.sha256(historical).hexdigest(),algorithms=algorithms,
                capacity=capacity,source=r.file_identity('/tmp/uwz-h2-native-c8-fix1/inputs/fixture/profile.zig'),modes=modes,
                candidate_equal=True,libxev_equal=True,explicit_config_equal=True,watcher_source_offsets=order,published_override=manifest['c9_override'])


def encode(value):
    if type(value) is bytes:
        return dict(bytes_hex=value.hex())
    if isinstance(value,BaseException):
        return dict(type=type(value).__name__,message=str(value))
    raise TypeError('Unpublishable receipt value: '+type(value).__name__)


def save(path,value):
    with Path(path).open('x') as output:
        json.dump(value,output,indent=2,default=encode)
        output.write('\n')


def closure_check(manifest,files,absent,before=None):
    import replay_builds as replay
    replay.verify_inputs(manifest)
    r.require(all(not Path(path).exists() for path in absent),'New eligible bytecode appeared')
    for path,identity in files.items():
        r.verify_file(path,identity)
    maps = Path('/proc/self/maps').read_text()
    origins = r.loaded_origins(files)
    mappings = r.check_mappings(files,maps)
    if before is not None:
        r.before_after(files,before,maps)
    return dict(origins=origins,mappings=mappings,maps=maps,c9_native_extension=manifest['c9_native_extension'],published_override=manifest['c9_override'])


def child_report(child):
    result = {key:child.get(key) for key in ('pid','start','listener','listener_inode','nonce','argv','environment',
              'watcher','certificate_sha256','source_sha256','binary_sha256','signaled','forced','process_status','reaped',
              'listener_gone','joined','pipe_closed','removed','selection','before','post','process_facts','ready_at')}
    watcher = result['watcher']
    result['watcher'] = None if watcher is None else dict(watcher)
    result['cleanup_errors'] = [repr(item) for item in child['cleanup_errors']]
    result['handles'] = len(child['handles'])
    result['closed_handles'] = len(child['closed_handles'])
    result['open_handles'] = sum(handle.fileno()>=0 for handle in child['handles'])
    result['private_paths_absent'] = {name:not child[name].exists() for name in ('cert','key','transfer')}
    if child['capture'] is not None:
        import native_host
        capture = native_host.snapshot(child)
        result['capture'] = dict(bytes=len(capture['bytes']),sha256=hashlib.sha256(capture['bytes']).hexdigest(),overflow=capture['overflow'],
                                 error=capture['error'],finished=capture['finished'])
    current = child['transport']
    if current is not None:
        result['transport'] = dict(failure=current['failure'],cleanup_errors=current['cleanup_errors'],
            connections=[dict(identity=row['identity'],case_deadline=row['case_deadline'],whole_deadline=row['whole_deadline'],entry=row['entry'],
                              closed=row['closed'],release=row['release'],cleanup_started=row['cleanup_started']) for row in current['history']])
        if current['current'] is not None:
            result['last_observer'] = observer_report(current['current'])
    signal = child['signal_evidence']
    if signal is not None:
        result['signal_evidence'] = dict(facts=signal[0],pid=signal[3][0],start=signal[3][1],listener=signal[3][2],
                                         watcher_is_retained=signal[3][3] is child['watcher'],client_is_retained=signal[3][4] is signal[2],
                                         observed=signal[3][5],operation=signal[4][:3],operation_tick=signal[4][5],operation_result=signal[4][6],returned=signal[5])
    return result


def observer_report(row):
    observer = row['observer']
    if observer is None:
        return None
    result = dict(failure=observer['failure'],operation=observer['operation'],busy=observer['busy'],sealed=observer['sealed'])
    for key in ('send','receive','streams'):
        if key in observer:
            result[key] = repr(observer[key])[:32768]
    context = row['context_binding']
    if context is not None:
        value = context[0]
        result['canonical'] = dict(case=value['stage']['case'],now=value['now'],raw=repr(value['raw'])[:32768])
    return result


def execute(packet,manifest,files,absent,authority,mode,selection,attempt):
    import time
    import native_host as host
    import native_provider as provider
    import coordinator
    import catalogue
    name = mode+'_'+selection+('_'+attempt if attempt else '')
    run_identity = 'c9_'+name
    directory = Path('/tmp/uwz-h2-native-c9')/name
    directory.mkdir(mode=0o700)
    nonces = (run_identity+'_0',run_identity+'_1')
    r.require(all(len(nonce)<=32 and nonce.replace('_','').isalnum() for nonce in nonces),'Declared nonce invalid')
    clock = time.monotonic_ns
    config = dict(directory=str(directory),run_identity=run_identity,nonces=nonces,whole_start=clock(),pending=[],
                  binary=authority['modes'][mode]['path'],binary_sha256=authority['modes'][mode]['sha256'],
                  source_sha256=authority['source']['sha256'],capacity=authority['capacity'])
    save(directory/'declaration.json',{key:value for key,value in config.items() if key!='pending'})
    factory,state = provider.new_provider(config,clock=clock,ops=host.operations(clock))
    before = closure_check(manifest,files,absent)
    save(directory/'preflight.json',dict(authority=authority,closure=before,new_sources=r.file_identity(packet/'source.sha256')))
    keywords = dict(run_identity=run_identity,now=config['whole_start'],units_per_second=1000000000,clock=clock,child_factory=factory)
    try:
        if selection=='explicit':
            result = coordinator.run(catalogue.CASES,**keywords)
        else:
            result = coordinator.run(**keywords)
        receipts = provider.aggregate(state,result)
        r.require(len(receipts)==41 and len(state['children'])==2,'Full40 requires 41 connections and two fresh children')
        r.require(provider.aggregate(state,result)==receipts,'Final live receipt revalidation differs')
        after = closure_check(manifest,files,absent,before['maps'])
        save(directory/'acceptance.json',dict(status='accepted',mode=mode,selection=selection,selection_omitted=selection=='omitted',
                    result=result,receipts=receipts,children=[child_report(child) for child in state['children']],after=after,
                    scope='actual_owned_native_http2_full40',limits=['Unknown/internal closing prefix and unauthenticated peer closure remain C4 limits']))
        print('ACCEPTED',mode,selection,'40 cases; 41 connections; two fresh children; actual exit0/reap/post/cleanup/live receipts')
    except BaseException as primary:
        provider.failure_boundary(state,primary)
        save(directory/'failure.json',dict(status='rejected',mode=mode,selection=selection,primary=primary,
                    children=[child_report(child) for child in state['children']],cleanup_errors=state['cleanup_errors']))
        raise


def main(argv):
    allowed = (['--test'],['--test-foreign'],['--inert'],['--preflight'],['--override-tests'],['--override-tests-foreign'])
    source = len(argv)==2 and argv[0]=='--source' and argv[1] in ('descriptor','focused','legacy','full40_explicit','full40_omitted','inert',
                                                              'regression_context','regression_capture','full40_hook_explicit','full40_hook_omitted')
    run = len(argv) in (3,4) and argv[0]=='--run' and argv[1] in ('debug','release') and argv[2] in ('explicit','omitted')
    if run and len(argv)==4:
        r.require(argv[3].isascii() and argv[3].isalnum() and 1<=len(argv[3])<=3,'Invalid attempt identity')
    if argv not in allowed and not run and not source:
        return 2
    packet,manifest,files,absent = bootstrap(source_only=source)
    if argv[0].startswith('--override-tests'):
        if argv==['--override-tests-foreign']:
            import os
            os.chdir('/tmp/uwz-h2-native-c9')
        import test_override
        import test_provider
        test_override.main(packet,manifest)
        test_provider.main()
        r.loaded_origins(files)
        r.check_mappings(files,Path('/proc/self/maps').read_text())
        return 0
    if source:
        import test_collection
        test_collection.main(argv[1])
        r.loaded_origins(files)
        r.check_mappings(files,Path('/proc/self/maps').read_text())
        return 0
    if argv[0]=='--inert':
        import test_inert
        test_inert.main(packet)
        return 0
    if argv[0].startswith('--test'):
        if argv==['--test-foreign']:
            import os
            os.chdir('/tmp/uwz-h2-native-c9')
        import test_provider
        test_provider.main()
        r.loaded_origins(files)
        r.check_mappings(files,Path('/proc/self/maps').read_text())
        return 0
    authority = runtime_authority(packet,manifest,files)
    if argv==['--preflight']:
        check = closure_check(manifest,files,absent)
        source = r.file_identity(packet/'source.sha256')
        save(packet/('runtime-preflight-'+source['sha256'][:16]+'.json'),dict(authority=authority,closure=check,new_sources=source))
        print('Runtime preflight passed: C8 fix1; candidate/config/layout equality; independently approved native imports/mappings; no target effects')
        return 0
    execute(packet,manifest,files,absent,authority,argv[1],argv[2],argv[3] if len(argv)==4 else '')
    return 0


if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
