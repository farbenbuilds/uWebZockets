"""Foreign cwd, effect guards before new provider/host import and rejected CLI."""
import os
from pathlib import Path
import runpy
import sys


def deny(event,args):
    rejected = ('subprocess.Popen','os.system','os.posix_spawn','os.mkdir','os.remove','os.rename','os.chmod','os.link','os.symlink','os.chdir','socket.__new__','socket.bind','socket.connect','os.kill')
    if event in rejected:
        raise ValueError('Inert effect attempted: '+event)
    if event=='open':
        mode,flags = args[1:3]
        if mode is not None and any(character in mode for character in 'wax+'):
            raise ValueError('Inert write attempted')
        if flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):
            raise ValueError('Inert descriptor write attempted')


def no_context(*args,**kwargs):
    raise ValueError('Inert SSLContext attempted')


def main(packet):
    os.chdir('/tmp/uwz-h2-native-c9')
    if any(name in sys.modules for name in ('native_host','native_provider')):
        raise ValueError('Provider imported before inert guard')
    import ssl
    ssl.SSLContext = no_context
    sys.addaudithook(deny)
    import native_host
    import native_provider
    sys.argv = [str(packet/'run_native.py'),'--invalid']
    try:
        runpy.run_path(str(packet/'run_native.py'),run_name='__main__')
    except SystemExit as error:
        if error.code!=2:
            raise ValueError('Rejected CLI status differs')
    else:
        raise ValueError('Rejected CLI returned normally')
    print('Foreign-cwd provider/host import and rejected direct CLI inert under effect guards')
