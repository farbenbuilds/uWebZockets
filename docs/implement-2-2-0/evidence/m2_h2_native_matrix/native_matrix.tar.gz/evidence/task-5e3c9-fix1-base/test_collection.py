"""Optional collection handoff proofs over unchanged canonical fake peers."""
from functools import partial
import coordinator
import shutdown_cases


def require(value,message):
    if not value:
        raise ValueError(message)


def reject(callback,message):
    try:
        callback()
    except ValueError as error:
        require(message in str(error),'Wrong rejection: '+str(error))
        return
    raise ValueError('Invalid collection hook accepted')


def descriptor():
    callback = lambda *args:None
    identity,selection = ('collection',0),('ready_buffered',)
    value = dict(identity=identity,ready=True,fresh_application=True,connect=callback,signal=callback,
                 process=callback,post=callback,close=callback,bind_collection=callback)
    coordinator.validate_descriptor(value,identity,selection)
    for invalid in (None,True,{}):
        reject(lambda:coordinator.validate_descriptor(dict(value,bind_collection=invalid),identity,selection),'child descriptor facts')
    reject(lambda:coordinator.validate_descriptor(dict(value,unknown=callback),identity,selection),'child descriptor fields')
    print('Optional callable descriptor accepted; malformed/unknown hooks reject')


def handoff():
    context,capture,calls = {},dict(records={'tag':{'bytes':3}},metrics={'bytes':3}),[]
    def callback(actual_context,actual_capture):
        require(actual_context is context and actual_capture is capture,'Handoff replaced input identity')
        calls.append((actual_context,actual_capture))
    shutdown_cases.handoff_collection(context,{},capture)
    require(not calls,'Absent hook invoked callback')
    shutdown_cases.handoff_collection(context,dict(bind_collection=callback),capture)
    require(len(calls)==1 and calls[0][1] is capture,'Handoff did not call exactly once')
    reject(lambda:shutdown_cases.handoff_collection(context,dict(bind_collection=lambda *args:{}),capture),'callback return')
    def mutate(actual_context,actual_capture):
        actual_capture['records']['tag']['bytes'] += 1
    reject(lambda:shutdown_cases.handoff_collection(context,dict(bind_collection=mutate),capture),'mutated capture')
    print('Exact context/capture once; absence, replacement and capture mutation boundaries passed')


def raise_exact(error,*args):
    raise error


def mutate_context(fault,context,capture):
    if fault=='heads':
        context['stage']['case_state']['heads'] += 1
    elif fault=='case_deadline':
        context['stage']['case_deadline'] += 1
    elif fault=='whole_deadline':
        context['stage']['whole_deadline'] += 1
    else:
        context['now'] += 1


def regression_context():
    import test_coordinator_shutdown as fixture
    for fault in ('heads','case_deadline','whole_deadline','now'):
        effects = []
        def control(phase,state,child,context,fact,deadline):
            if phase=='factory':
                fact['bind_collection'] = partial(mutate_context,fault)
            if phase in ('close','signal'):
                effects.append(phase)
                raise RuntimeError('terminal effect after '+fault+' mutation')
        try:
            fixture.run_selection(('ready_buffered',),control)
        except ValueError as error:
            require('collection binding mutated context' in str(error) and not effects,'Wrong context mutation boundary')
        except RuntimeError:
            print('OLD_BOUNDARY_TERMINAL_EFFECT',fault,effects)
            raise
        else:
            raise ValueError('Context mutation accepted: '+fault)
    print('Counts and inherited context deadlines/time reject before terminal effects')


def regression_capture():
    for key,original,changed in (('counter',0,False),('counter',1,True),('flag',False,0),('flag',True,1)):
        capture = dict(records={'tag':{key:original}},metrics={key:original})
        def mutate(context,actual_capture):
            actual_capture['records']['tag'][key] = changed
            actual_capture['metrics'][key] = changed
        rejected = False
        try:
            shutdown_cases.handoff_collection({},dict(bind_collection=mutate),capture)
        except ValueError as error:
            require('collection binding mutated capture' in str(error),'Wrong typed mutation boundary')
            rejected = True
        print('typed_capture_rejected',type(original).__name__,type(changed).__name__,rejected)
        require(rejected,'Equal-valued scalar type mutation accepted')


def typed_capture_terminal(selection):
    import test_coordinator_shutdown as fixture
    effects = []
    def mutate(context,capture):
        capture['metrics']['active'] = bool(capture['metrics']['active'])
    def control(phase,state,child,context,fact,deadline):
        if phase=='factory':
            fact['bind_collection'] = mutate
        if phase in ('close','signal') and context['stage']['case']==child['selection'][-1]:
            effects.append(phase)
    reject(lambda:fixture.run_selection(selection,control),'collection binding mutated capture')
    require(not effects,'Typed capture mutation reached close/signal')
    print('Typed capture mutation rejected before terminal effects',selection)


def mutated_exception():
    import test_coordinator_shutdown as fixture
    primary,effects = RuntimeError('same mutated-context callback exception'),[]
    def mutate(context,capture):
        mutate_context('heads',context,capture)
        raise primary
    def control(phase,state,child,context,fact,deadline):
        if phase=='factory':
            fact['bind_collection'] = mutate
        if phase in ('close','signal'):
            effects.append(phase)
    try:
        fixture.run_selection(('shutdown_idle',),control)
    except RuntimeError as actual:
        require(actual is primary and not effects,'Mutation guard changed original exception or reached terminal effect')
    else:
        raise ValueError('Mutating callback exception accepted')
    print('Mutating callback preserves exact exception before terminal effects')


def collection_event(evidence,child,context,capture):
    index = child['index']
    require(index not in evidence['captures'],'Duplicate collection callback')
    require(evidence['contexts'][index] is context,'Collection context differs from actual collector')
    require(capture.keys()=={'records','metrics'} and capture==evidence['copies'][index],'Collection did not hand off actual facts')
    if context['stage']['case'] not in ('shutdown_idle','shutdown_active'):
        require(context['final_observations'] is capture,'Ordinary collection handoff replaced capture')
    evidence['captures'][index] = (context,capture)
    evidence['events'].append(('bound',index))


def provider_collection(evidence,child,context,capture):
    import native_provider
    row = dict(closed=False,context_binding=(context,))
    retained = dict(before=None,signaled=False,selection=child['selection'],transport=dict(current=row))
    native_provider.bind_collection(retained,context,capture)
    evidence['provider'][child['index']] = retained['before']
    collection_event(evidence,child,context,capture)


def composition(selection, fault=None):
    import test_coordinator_shutdown as fixture
    evidence = dict(captures={},contexts={},copies={},events=[],blocked=[],provider={})
    primary = RuntimeError('collection primary')
    def control(phase,state,child,context,fact,deadline):
        index = child['index']
        evidence['events'].append((phase,index))
        if phase=='factory':
            callback = partial(collection_event,evidence,child)
            if fault=='raise':
                callback = partial(raise_exact,primary)
            if fault=='return':
                callback = lambda *args:True
            if fault=='provider':
                callback = partial(provider_collection,evidence,child)
            fact['bind_collection'] = None if fault=='callable' else callback
        if phase=='collected':
            evidence['contexts'][index] = context
            evidence['copies'][index] = state['collections'][-1][1]
        if phase in ('close','signal') and context['stage']['case']==child['selection'][-1]:
            evidence['blocked'].append(phase)
            require(index in evidence['captures'],'Close/signal preceded collection binding')
    if fault=='raise':
        try:
            fixture.run_selection(selection,control)
        except RuntimeError as actual:
            require(actual is primary and not evidence['blocked'],'Callback changed primary or reached close/signal')
        else:
            raise ValueError('Callback failure accepted')
        return
    if fault in ('return','callable'):
        message = 'callback return' if fault=='return' else 'child descriptor facts'
        reject(lambda:fixture.run_selection(selection,control),message)
        require(not evidence['blocked'],'Rejected callback reached close/signal')
        return
    baseline,baseline_state = fixture.run_selection(selection)
    result,state = fixture.run_selection(selection,control)
    require(result==baseline and state['collections']==baseline_state['collections'] and state['dispatches']==baseline_state['dispatches'],
            'Collection hook changed canonical result/requests/order')
    require(len(evidence['captures'])==len(result['children']),'Missing callback for child')
    if fault=='provider':
        require(all(evidence['provider'][index]==child['final_observations'] for index,child in enumerate(result['children'])),
                'Provider callback changed frozen canonical baseline')
    for index,(context,capture) in evidence['captures'].items():
        if result['children'][index]['selection'][-1] in ('shutdown_idle','shutdown_active'):
            require(context['final_observations'] is capture,'Canonical collector return object replaced')
        bound = evidence['events'].index(('bound',index))
        phase = 'signal' if result['children'][index]['selection'][-1]=='shutdown_active' else 'close'
        require(bound<evidence['events'].index((phase,index)),'Collection hook occurred after close/signal')
    print('Exact collection before close/signal; unchanged composition',selection)


def legacy():
    import runpy
    from pathlib import Path
    directory = Path(coordinator.__file__).parent
    for name in ('test_coordinator','test_coordinator_shutdown','test_shutdown'):
        runpy.run_path(str(directory/(name+'.py')),run_name='__main__')
        print('Unchanged legacy suite passed:',name)


def full40(omitted):
    import catalogue
    import test_all40 as driver
    driver.check_composition(catalogue.CASES,omitted=omitted)
    print('Original source full40 passed:', 'genuinely omitted' if omitted else 'explicit')


def source_collection(retained,index,selection,context,capture):
    import native_provider
    require(index not in retained,'Duplicate source provider collection')
    row = dict(closed=False,context_binding=(context,))
    child = dict(before=None,signaled=False,selection=selection,transport=dict(current=row))
    native_provider.bind_collection(child,context,capture)
    retained[index] = child['before']


def full40_hook(omitted):
    import catalogue
    import test_all40 as driver
    import test_all40_descriptors as binding
    baseline,baseline_state,baseline_receipts,evidence = driver.execute(catalogue.CASES,omitted=omitted)
    driver.check_all40(baseline,baseline_state,baseline_receipts)
    driver.check_limits(baseline,baseline_state,baseline_receipts,evidence)
    clock = lambda:2
    factory,state = binding.new_provider(clock=clock)
    retained = {}
    def child_factory(identity,index,selection,ready,whole):
        descriptor = factory(identity,index,selection,ready,whole)
        descriptor['bind_collection'] = partial(source_collection,retained,index,selection)
        return descriptor
    keywords = dict(run_identity='omitted_default' if omitted else 'binding_b',now=1,units_per_second=1000,clock=clock,child_factory=child_factory)
    result = coordinator.run(**keywords) if omitted else coordinator.run(catalogue.CASES,**keywords)
    receipts = binding.finish_binding(state,result)
    driver.check_all40(result,state,receipts)
    require(result==baseline and receipts==baseline_receipts,'Provider handoff changed full40 result/wire receipts')
    require(len(retained)==2 and all(retained[index]==child['final_observations'] for index,child in enumerate(result['children'])),
            'Provider handoff did not preserve actual full40 baseline')
    print('Provider callback full40 equals unchanged driver result/wire receipts:', 'genuinely omitted' if omitted else 'explicit')


def focused():
    import test_provider
    descriptor()
    handoff()
    regression_context()
    regression_capture()
    mutated_exception()
    for selection in (('ready_buffered',),('shutdown_idle',),('ready_buffered','shutdown_active'),
                      ('shutdown_idle','ready_buffered','shutdown_active')):
        composition(selection)
        composition(selection,'provider')
        typed_capture_terminal(selection)
    for selection in (('ready_buffered',),('shutdown_idle',),('ready_buffered','shutdown_active')):
        for fault in ('raise','return','callable'):
            composition(selection,fault)
    test_provider.main()
    print('Collection handoff focused checks passed')


def inert():
    import os
    from pathlib import Path
    import test_imports
    import test_inert
    os.chdir('/tmp/uwz-h2-native-c9')
    test_imports.check()
    test_inert.main(Path(__file__).parent)
    print('Revised canonical and provider source imports/CLI inert from foreign cwd')


def main(mode):
    if mode=='descriptor':
        descriptor()
    elif mode=='focused':
        focused()
    elif mode=='legacy':
        legacy()
    elif mode in ('full40_explicit','full40_omitted'):
        full40(mode=='full40_omitted')
    elif mode=='inert':
        inert()
    elif mode=='regression_context':
        regression_context()
    elif mode=='regression_capture':
        regression_capture()
    elif mode in ('full40_hook_explicit','full40_hook_omitted'):
        full40_hook(mode=='full40_hook_omitted')
    else:
        raise ValueError('Unknown source-only proof mode')
