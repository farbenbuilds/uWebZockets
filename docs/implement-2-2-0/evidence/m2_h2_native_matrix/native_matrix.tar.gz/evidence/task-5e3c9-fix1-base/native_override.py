"""Published two-file replacement authority; historical C8 data stays immutable."""
import json
from pathlib import Path
import build_inputs as b
import runtime_closure as r


def specification(root):
    directory = root/'.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'
    rows = [('coordinator.py',23073,'6585ad2323ce38a75948c7c365ceb7b9589c06e1c6010ae01ba35de0f11e6b32',
             23518,'4c00e7ae957d2ca488dd14b9814c91f3068a5aa61758ab9a43fb81483a200bb0'),
            ('shutdown_cases.py',7689,'2856e200fa463b26c79e4e0b74cc9ead4863f9a1dd6372c0e8249fb9b163e15c',
             10562,'c03bc49a65760d3fa99cf45078b893ecebbc4dd3602de6ced4017207b1f08eb7')]
    return {str(directory/name):dict(old=dict(bytes=old_bytes,sha256=old_pin),new=dict(bytes=new_bytes,sha256=new_pin))
            for name,old_bytes,old_pin,new_bytes,new_pin in rows}


def validate_revision(revision,expected):
    r.require(type(revision) is dict and revision.get('schema')=='C9a_two_file_source_revision_v1','Revision schema differs')
    r.require(revision.get('scope')=='source_only_pending_root_review_publication_and_native_release' and
              revision.get('base')=='67a8be8b4a6a4aa35e94fae68d53d0f7d2dd3c7b','Revision declared scope/base differs')
    rows = revision.get('files')
    r.require(type(rows) is list and len(rows)==2 and {row.get('path') for row in rows}==set(expected),'Revision replacement scope differs')
    for row in rows:
        target = expected[row['path']]
        r.require(row.get('old')==target['old'] and row.get('new')==target['new'],'Revision old/new identity differs')


def authenticate(root):
    archive = root/'docs/implement-2-2-0/evidence/m2_h2_collection_handoff/collection_handoff.tar.gz'
    pin = 'd1a51b3a24ce5724e6eb32df850ddb375636ab0b72c1cdd4e8ec621ca570f5ea'
    r.require(archive.stat().st_size==3679909,'Published handoff archive size differs')
    inventory = b.archive_index(archive,pin)
    data = b.member_bytes(archive,inventory,'SOURCE_REVISION.json')
    r.require(b.sha(data)=='8fc6c797a5d481c36b25636df0e909635000e66b7baa25ef52d5ce67b7a8f9ae','Published revision hash differs')
    revision,expected = json.loads(data),specification(root)
    validate_revision(revision,expected)
    members = {}
    for path,row in expected.items():
        name = Path(path).name
        for phase,prefix in [('old','baseline/canonical/'),('new','source/canonical/')]:
            member = prefix+name
            content = b.member_bytes(archive,inventory,member)
            r.require(len(content)==row[phase]['bytes'] and b.sha(content)==row[phase]['sha256'],'Published canonical bytes differ')
            members[member] = dict(row[phase])
    return dict(archive=r.file_identity(archive),revision_sha256=b.sha(data),revision=revision,members=members,
                release_commit='18d479dd714ea99240cfafe28a1f94bb6030d9a2')


def verify_delta(original,revised,expected):
    r.require(original.keys()==revised.keys(),'Unexpected replacement path')
    changed = {path for path in original if original[path]!=revised[path]}
    r.require(changed==set(expected),'Unexpected replacement scope')
    for path,row in expected.items():
        old,new = original[path],revised[path]
        r.require((old['bytes'],old['sha256'])==(row['old']['bytes'],row['old']['sha256']),'C8 old replacement identity differs')
        target = dict(old,bytes=row['new']['bytes'],sha256=row['new']['sha256'])
        r.require(new==target,'Replacement identity differs from published authority')


def apply(original,authority,root):
    expected = specification(root)
    validate_revision(authority['revision'],expected)
    revised = dict(original)
    for path,row in expected.items():
        r.require(path in original,'Missing C8 replacement path')
        r.require((original[path]['bytes'],original[path]['sha256'])==(row['old']['bytes'],row['old']['sha256']),
                  'C8 old replacement identity differs')
        target = dict(original[path],bytes=row['new']['bytes'],sha256=row['new']['sha256'])
        r.verify_file(path,target)
        revised[path] = target
    verify_delta(original,revised,expected)
    return revised


def owned_path(packet,files,path):
    value = Path(path)
    r.require(value.parent==packet and value.suffix in ('.py','.sha256') and path not in files,
              'New source cannot replace protected authority or escape provider scope')
