"""Focused published-authority admission; no host effects or source mutation."""
import json
from pathlib import Path
import native_override as override
import runtime_closure as r


def rejected(callback,message):
    try:
        callback()
    except ValueError as error:
        r.require(message in str(error),'Wrong override rejection: '+str(error))
        return
    raise ValueError('Invalid published override accepted')


def clone(value):
    return json.loads(json.dumps(value))


def main(packet,manifest):
    root = Path('/workspaces/uWebZockets')
    prior = packet.parent/'native_runtime_builds'
    original_bytes = (prior/'preflight-fix1.json').read_bytes()
    original = json.loads(original_bytes)
    authority = override.authenticate(root)
    expected = override.specification(root)
    for path in expected:
        rejected(lambda:r.verify_file(path,original['files'][path]),'Changed file identity')
    print('Old C8 source gate still refuses both independently published replacements')
    revised = override.apply(original['files'],authority,root)
    override.verify_delta(original['files'],revised,expected)
    r.require(all(manifest['files'][path]==revised[path] for path in expected),'Bootstrap did not use published replacements')
    archive = authority['archive']
    r.require(manifest['authorities'][archive['path']]==archive,'Published archive missing from before/after control checks')
    r.require(all(str(packet/name) in manifest['files'] for name in ('source.sha256','run_control.sh')),'Provider controls missing from closure')
    print('Exactly the two reviewed path/size/hash replacements admitted before imports')
    path = next(iter(expected))
    for field,value in [('sha256','0'*64),('bytes',expected[path]['new']['bytes']+1)]:
        revision = clone(authority['revision'])
        revision['files'][0]['new'][field] = value
        rejected(lambda:override.validate_revision(revision,expected),'Revision old/new identity')
    revision = clone(authority['revision'])
    revision['files'][0]['path'] = str(packet/'coordinator.py')
    rejected(lambda:override.validate_revision(revision,expected),'Revision replacement scope')
    revision = clone(authority['revision'])
    revision['scope'] = 'arbitrary_current_sources'
    rejected(lambda:override.validate_revision(revision,expected),'Revision declared scope/base')
    revision = clone(authority['revision'])
    revision['files'].append(clone(revision['files'][0]))
    rejected(lambda:override.validate_revision(revision,expected),'Revision replacement scope')
    extra = str(packet.parent/'integration-owned/combined-cases/adapter.py')
    unexpected = dict(revised)
    unexpected[extra] = dict(unexpected[extra],bytes=unexpected[extra]['bytes']+1)
    rejected(lambda:override.verify_delta(original['files'],unexpected,expected),'Unexpected replacement scope')
    rejected(lambda:override.owned_path(packet,original['files'],extra),'protected authority')
    print('Wrong hash/size/path, third revision/replacement and source-control scope reject')
    r.require((prior/'preflight-fix1.json').read_bytes()==original_bytes,'C8 manifest was changed')
    r.require(original['files'][path]['sha256']==expected[path]['old']['sha256'],'C8 in-memory identity mutated')
    r.require(r.file_identity(prior/'frozen-current-fix1.sha256')['sha256']=='f343b91b79ea31b89190475512f6c6bf5007459d9816a9b5dae8e99efb5c33ad',
              'C8 source/control inventory changed')
    print('C8 original manifest, controls and independently approved unused-native rejection preserved')
