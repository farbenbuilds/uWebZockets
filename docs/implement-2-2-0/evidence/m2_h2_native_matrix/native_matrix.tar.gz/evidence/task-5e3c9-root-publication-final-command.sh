#!/bin/sh
set -eu
cd /workspaces/uWebZockets
export PYTHONDONTWRITEBYTECODE=1
plan=/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan
sh scripts/check_docs.sh > "$plan/task-5e3c9-root-publication-docs.stdout" 2> "$plan/task-5e3c9-root-publication-docs.stderr"
git diff --check > "$plan/task-5e3c9-root-publication-whitespace.stdout" 2> "$plan/task-5e3c9-root-publication-whitespace.stderr"
/home/codespace/.python/current/bin/python3 -B -S "$plan/task-5e3b8a-restore-inputs.py" --restore "$plan/task-5e3c9-publish-final-build-inputs.json" > "$plan/task-5e3c9-publish-final-build-restore.stdout" 2> "$plan/task-5e3c9-publish-final-build-restore.stderr"
/home/codespace/.python/current/bin/python3 -B -S "$plan/task-5e3c9-publish.py" --build > "$plan/task-5e3c9-publish-final-build.stdout" 2> "$plan/task-5e3c9-publish-final-build.stderr"
/home/codespace/.python/current/bin/python3 -B -S "$plan/task-5e3b8a-restore-inputs.py" --restore "$plan/task-5e3c9-publish-final-audit-inputs.json" > "$plan/task-5e3c9-publish-final-audit-restore.stdout" 2> "$plan/task-5e3c9-publish-final-audit-restore.stderr"
/home/codespace/.python/current/bin/python3 -B -S "$plan/task-5e3c9-publish.py" --audit > "$plan/task-5e3c9-publish-final-audit.stdout" 2> "$plan/task-5e3c9-publish-final-audit.stderr"
