The consultation's pending outer-archive qualification is resolved by the
reviewed, pushed Root commit `67a8be8b4a6a4aa35e94fae68d53d0f7d2dd3c7b`.
Read-only `git show HEAD:docs/implement-2-2-0/evidence/m2_h2_output_driver/output-driver.tar.gz | sha256sum`
returned `6ebc819a8407f43b8b9aafd26b0fe5c52f4345c43e30b32584f8eb896d4544dd`.
The tracked sibling `manifest.json` independently records that archive name,
the same SHA-256 and 5,538,265 bytes. C8 additionally authenticates the exact
historical manifest member SHA
`aab3dda65e16b0475ccb59de28028a2d324ee81c7c05dc6c48daf909f6ae9890`.
This binds archived algorithm provenance; the accepted native callback schema
continues to come from the unchanged C6c sources.
