# C9 Round1/5 scoped re-review

SAME reviewer `/root/review_h2_native_provider`; SAME implementer. The original
full verdict is saved verbatim in `task-5e3c9-review-report.md`, SHA
5b4bdbf12bb9bafce1b4980738243c71b6a0abb0c410190511230cea816b46cb.
Root preserved the reviewed snapshot86 own source/control files under
`task-5e3c9-fix1-base`, hashes in its adjacent `.sha256` file.

Root must supply the final frozen fix snapshot, exact new identities, scoped
diff and covering commands/output after the implementer reports. Do not review
mutable source or infer a pass from this prepared brief. Native r5 never ran;
all new target effects remain held pending scoped PASS and Root release.

Review only the four original findings and important new breakage in the fix
diff. Verdict each ADDRESSED/NOT ADDRESSED, citing source and retained tests:

1. New override-helper source admission and eligible-bytecode refusal precede
   any helper behavior. Behavioral regression proves the old boundary executes
   the sentinel; final normal/-O rejects before it. `-B` alone does not suffice.
2. Transport close attempts remain one-shot through subsequent host failure
   cleanup even when the close raises. Track attempt separately from proven
   closure; a failed close cannot earn normal acceptance.
3. Private file cleanup remains independent of failure-capture writes. Cover
   capture write failure, attempts for all remaining owned files, separate
   bounded secondary errors and no false acceptance.
4. Serialization/report write failures cannot replace the exact original
   exception. Cover object identity, bare rethrow, separate bounded reporting
   errors and failure even when no report can be persisted.

The snapshot86 transfer unlink fix is already accepted; do not reopen the
unchanged source/architecture. Source-only targeted tests and inert/foreign-cwd
evidence are required. Do not rerun old whole suites or native operations.
Canonical/native7/C8/candidate/binary identities stay fixed, with the published
C9a two-file authority as the sole canonical revision. Full original C9 briefs
and the four actual native runs remain binding after this scoped review.

Return full verdict verbatim in final for Root to save. No edits/Git/publication,
tests, target/socket/TLS/signal operations or subagents. Project pinned-Python,
fresh119 Root-cwd and Graphify-before-new-question rules still apply. Never read
the 25 private historical environments or any test key/certificate bytes.
