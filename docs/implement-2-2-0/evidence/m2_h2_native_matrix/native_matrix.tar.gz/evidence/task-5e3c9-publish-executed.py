"""Publish reviewed native execution separately from pending temporary recovery."""
import base64
import hashlib
import json
from pathlib import Path
import runpy
import stat
import sys
import tarfile


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def approved_api(plan):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_collection_handoff/collection_handoff.tar.gz')
    require(sha(archive.read_bytes()) == 'd1a51b3a24ce5724e6eb32df850ddb375636ab0b72c1cdd4e8ec621ca570f5ea', 'Published C9a authority differs')
    helper = plan / 'task-5e3c9a-publication.py'
    with tarfile.open(archive, 'r:gz') as source:
        require(source.extractfile('evidence/' + helper.name).read() == helper.read_bytes(), 'Published publication helper differs')
    return runpy.run_path(str(helper))


def regular_bytes(path):
    require(not path.is_symlink() and path.is_file(), 'Nonregular evidence')
    require(path.suffix.lower() not in ('.pem', '.key') and path.name != 'environment.nul', 'Private evidence refused')
    return path.read_bytes()


def verify_native(packet):
    inventory = packet / 'native-final/package.sha256'
    require(sha(regular_bytes(inventory)) == 'd8bc9a9e58db36db8593850928ebcb6e6167f792dfb9368647b7d929fbc56b36', 'Final native evidence index differs')
    rows = inventory.read_text().splitlines()
    require(len(rows) == 34, 'Native evidence count differs')
    for row in rows:
        digest, name = row.split('  ', 1)
        path = Path(name)
        require(path.is_relative_to(packet / 'native-final') and '..' not in path.parts, 'Unsafe native evidence path')
        require(sha(regular_bytes(path)) == digest, 'Native final bytes differ')
    require(sha(regular_bytes(packet / 'source.sha256')) == '25049aab57483c0d8604c07471c04d8bc8937b3810534dbc2a5bdcb465e9ef44', 'Provider source inventory differs')
    control = packet / 'snapshots/119_listener_preflight/code.sha256'
    require(sha(regular_bytes(control)) == '9dc91d42c5714bff32558feb3d6f914a34ef899e0b8b2b6f930312b877fc4185', 'Exercised provider source control differs')
    rows = control.read_text().splitlines()
    require(len(rows) == 14, 'Exercised provider file count differs')
    for row in rows:
        digest, name = row.split('  ', 1)
        path = Path(name)
        require(path.parent == packet.resolve(), 'Provider source scope differs')
        raw = regular_bytes(path)
        require(sha(raw) == digest and regular_bytes(control.parent / path.name) == raw, 'Provider changed since native execution')
    return dict(final_evidence_files=34, exercised_provider_files=14)


def root_records(plan):
    patterns = ('brief.md', 'plan-report.md', 'report.md', 'review-report.md', 'native-review-report.md',
                'resume-brief.md', 'before-listener-report.md', 'temp-loss-observations.md',
                'root-*', 'fix1-*', 'listener-*', 'snapshot-dedup*')
    selected = set()
    for pattern in patterns:
        for path in plan.glob('task-5e3c9-' + pattern):
            require(not path.is_symlink(), 'Root evidence symlink')
            if path.is_dir():
                selected.update(path.rglob('*'))
                continue
            selected.add(path)
    selected.update(plan / ('task-5e3c9-publish' + suffix) for suffix in ('.py', '-executed.py', '-code.sha256', '-command.sh'))
    return {'evidence/' + path.relative_to(plan).as_posix(): regular_bytes(path)
            for path in sorted(selected) if not path.is_dir()}


def collect(plan, packet, api):
    facts = verify_native(packet)
    require((plan / 'task-5e3c9-root-audit.exit').read_text().strip() == '1', 'Original failed preservation audit must remain preserved')
    for name in ('format', 'conventions', 'version', 'docs', 'dependencies', 'unit-fresh', 'final-graph'):
        require((plan / ('task-5e3c9-root-' + name + '.exit')).read_text().strip() == '0', 'Root gate is not successful: ' + name)
    members, index = api['packet_objects'](packet)
    members.update(root_records(plan))
    return members, index, facts


def build(plan, packet, folder, api):
    members, index, facts = collect(plan, packet, api)
    writer = api['api'](plan, 'task-5e3c1-build-publication.py')
    safe = {}
    for name, data in members.items():
        writer['add'](safe, name, data, {})
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'native_matrix.tar.gz'
    inventory = writer['write_archive'](archive, safe)
    require(archive.stat().st_size < 100_000_000, 'Publication exceeds single-file push limit')
    manifest = dict(scope='Four reviewed historical Linux TLS/H2 native full40 runs; later temporary recovery remains open',
        base_commit='18d479dd714ea99240cfafe28a1f94bb6030d9a2', archive=archive.name,
        archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
        safe_regular_utf8_members=len(safe) + 1, inventory_entries=len(inventory),
        logical_packet_files=len(index), unique_packet_objects=len({row['object'] for row in index.values()}),
        packet_index='PACKET_INDEX.json', encoding='Lossless UTF-8/base64 objects; per-path size, SHA-256 and mode',
        native_evidence_index_sha256='d8bc9a9e58db36db8593850928ebcb6e6167f792dfb9368647b7d929fbc56b36',
        native_runs=['debug_explicit_r6', 'debug_omitted_r6', 'release_explicit_r6', 'release_omitted_r6'],
        cases_per_run=40, connection_receipts_per_run=41, fresh_owned_children_per_run=2,
        all_children_normal_exit_zero=True, cleanup_errors=0, native_full40_historical_accepted=True,
        root_unit='852/852 tests, 22/22 steps, fresh runtime seed0x090611c9, warm compiler cache; retained diagnostics',
        current_preservation_audit_passed=False, later_preservation_audit='Failed at absent C7 candidate root; original output retained',
        temporary_loss_cause='Undetermined', temporary_recovery='Pending separate review and execution; not included in this artifact',
        native_replayed_for_publication=False, binary_bytes_included=False, production_adoption=False,
        production_pin_changed=False, platform_scope='Owned Linux fixture/provider only', milestone_complete=False, **facts)
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({key: manifest[key] for key in ('archive_bytes', 'archive_sha256', 'logical_packet_files', 'unique_packet_objects')}))


def audit(plan, packet, folder, api):
    expected, index, facts = collect(plan, packet, api)
    reader = api['api'](plan, 'task-5e3c1-publication-audit.py')
    manifest = json.loads((folder / 'manifest.json').read_text())
    archive = folder / manifest['archive']
    require(archive.stat().st_size == manifest['archive_bytes'] and sha(archive.read_bytes()) == manifest['archive_sha256'], 'Published archive identity differs')
    actual = reader['read_archive'](archive)
    require(actual == expected and len(actual) == manifest['inventory_entries'], 'Published member bytes differ')
    for name, row in index.items():
        raw = actual[row['object']]
        decoded = base64.b64decode(raw.strip(), validate=True) if row['encoding'] == 'base64' else raw
        path = packet / name
        require(decoded == regular_bytes(path) and len(decoded) == row['bytes'] and sha(decoded) == row['sha256'], 'Published logical bytes differ')
        require(stat.S_IMODE(path.stat().st_mode) == row['mode'], 'Published logical mode differs')
    docs = Path('docs/implement-2-2-0')
    files = [docs / 'README.md', docs / 'm2_request_streaming.md', docs / 'm2_h2_native_matrix.md',
             folder / 'README.md', folder / 'manifest.json', archive]
    check = api['api'](plan, 'task-5e3c1-prepare-review.py')['root_check']
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=archive.stat().st_size,
        inventory_entries=len(actual), logical_packet_files=len(index), native_facts=facts,
        helper_check=check((plan / 'task-5e3c9-publish.py').resolve()),
        local_links_checked=reader['verify_links'](files),
        delivery_files={str(path): dict(size=path.stat().st_size, sha256=sha(path.read_bytes())) for path in files},
        current_preservation_audit_passed=False, native_full40_historical_accepted=True, milestone_complete=False)
    (plan / 'task-5e3c9-publish-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('helper_check', 'delivery_files')}))


def main(arguments):
    if arguments not in (['--build'], ['--audit']):
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    packet = Path('.uwz-work/evidence/h2-streaming/native_provider')
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_native_matrix')
    api = approved_api(plan)
    if arguments == ['--build']:
        build(plan, packet, folder, api)
        return
    audit(plan, packet, folder, api)


if __name__ == '__main__':
    main(sys.argv[1:])
