"""Deduplicate immutable completed snapshots without changing bytes or modes."""
import hashlib
import json
import os
import stat
import sys
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            result.update(block)
    return result.hexdigest()


def identity(path):
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode), 'Nonregular snapshot file')
    return dict(path=str(path), bytes=info.st_size, mode=stat.S_IMODE(info.st_mode),
                uid=info.st_uid, gid=info.st_gid, sha256=digest(path), inode=info.st_ino,
                device=info.st_dev, mtime_ns=info.st_mtime_ns, blocks=info.st_blocks)


def completed_files(packet):
    result = []
    for directory in sorted((packet / 'snapshots').iterdir()):
        require(directory.is_dir() and not directory.is_symlink(), 'Invalid snapshot root')
        if not (packet / 'raw' / (directory.name + '.exit')).is_file():
            continue
        for path in sorted(directory.rglob('*')):
            add_file(result, path)
    return result


def add_file(rows, path):
    require(not path.is_symlink(), 'Snapshot symlink')
    if path.is_dir():
        return
    require(path.suffix.lower() not in ('.pem', '.key'), 'Private material is outside dedup scope')
    rows.append(identity(path))


def content_key(row):
    return tuple(row[name] for name in ('bytes', 'mode', 'uid', 'gid', 'sha256'))


def link_duplicate(master, row):
    path = Path(row['path'])
    old = path.lstat()
    if (old.st_dev, old.st_ino) == (master['device'], master['inode']):
        return 0
    temporary = path.with_name(path.name + '.dedup_tmp')
    require(not temporary.exists() and not temporary.is_symlink(), 'Dedup temporary already exists')
    os.link(master['path'], temporary, follow_symlinks=False)
    os.replace(temporary, path)
    return old.st_blocks * 512 if old.st_nlink == 1 else 0


def deduplicate(plan):
    packet = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native_provider')
    before = completed_files(packet)
    receipt = plan / 'task-5e3c9-snapshot-dedup-before.json'
    require(not receipt.exists(), 'Dedup receipt already exists')
    receipt.write_text(json.dumps(before, indent=2) + '\n')
    masters = {}
    reclaimed = 0
    linked = 0
    for row in before:
        key = content_key(row)
        if key not in masters:
            masters[key] = row
            continue
        saved = link_duplicate(masters[key], row)
        reclaimed += saved
        linked += saved > 0
    after = [identity(Path(row['path'])) for row in before]
    require(all(content_key(old) == content_key(new) for old, new in zip(before, after)),
            'Snapshot byte/mode/ownership identity changed')
    require(len(before) == len(after), 'Snapshot path count changed')
    result = dict(files_checked=len(before), unique_contents=len(masters),
                  duplicate_inodes_reclaimed=linked, reclaimed_allocated_bytes=reclaimed,
                  bytes_modes_ownership_paths_preserved=True, regular_files_preserved=True,
                  scope='Completed snapshot files only; live source/control/raw/handoff untouched',
                  timestamps='Hardlinks share inode timestamps; original per-path mtime retained in before receipt',
                  target_executed=False)
    (plan / 'task-5e3c9-snapshot-dedup-after.json').write_text(json.dumps(after, indent=2) + '\n')
    (plan / 'task-5e3c9-snapshot-dedup.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__' and sys.argv[1:] == ['--deduplicate']:
    deduplicate(Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan'))
