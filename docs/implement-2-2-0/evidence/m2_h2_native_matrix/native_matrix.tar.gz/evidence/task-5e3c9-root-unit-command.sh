#!/bin/sh
set -u
cd /workspaces/uWebZockets
plan=/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan
sha256sum /nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig > "$plan/task-5e3c9-root-unit-toolchain.sha256"
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig build test -j2 \
    --cache-dir /tmp/uwz-c6c-repository-gates/cache \
    --global-cache-dir /tmp/uwz-c6c-repository-gates/global \
    --seed 0x240412be --summary all \
    > "$plan/task-5e3c9-root-unit.stdout" 2> "$plan/task-5e3c9-root-unit.stderr"
gate_status=$?
printf '%s\n' "$gate_status" > "$plan/task-5e3c9-root-unit.exit"
printf 'Unit exit: %s\n' "$gate_status"
tail -n 28 "$plan/task-5e3c9-root-unit.stderr"
exit "$gate_status"
