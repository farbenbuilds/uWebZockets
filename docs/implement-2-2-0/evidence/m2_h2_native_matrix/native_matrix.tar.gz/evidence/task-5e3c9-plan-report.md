C9 should implement the real provider and execute the four required native runs after C8 review/push and Root’s separate release. C8 remains sole implementer now. Preserve accepted native7, canonical sources, C7 exports, and product/pin state.

**Handoff and ownership**

C8 owns `.uwz-work/evidence/h2-streaming/native_runtime_builds/` and `/tmp/uwz-h2-native-c8/`. Consume its accepted `task-5e3c8-report.md`, runtime manifest/guard, and actual Debug/ReleaseSafe receipts. Select binaries from each receipt’s full `-femit-bin` argument and fresh hash; the brief does not establish final filenames. Require successful compilation, exact input preservation, and authenticated fixture25/C7 candidate1031/libxev93 identities.

C9 extends that closure with reviewed provider sources and imports before effects. Verification owns provider/run evidence; transport_io guides lifetime and signal operations, crypto_tls guides certificate/TLS handling, and build_vendor validates the C8 handoff. Use a fresh `/tmp/uwz-h2-native-c9/` run root; never reuse C8 caches as run state.

**Reuse and minimal modules**

Authenticated reusable algorithms are in `docs/implement-2-2-0/evidence/m2_h2_output_driver/output-driver.tar.gz::source/runtime/`:

| Source | Reuse/adaptation |
|---|---|
| `identity.py:4–29` | Process-start parsing and listener-inode matching |
| `process_io.py:14–79` | `/proc` observations, spawn, bounded collector, wait/join, SIGTERM and cleanup operations |
| `capture.py:5–75` | 8192-byte collection, 65536-byte cap, health snapshots and readiness |
| `process_setup.py:15–45` | Ephemeral localhost certificate command, private paths and explicit child environment |
| `connection.py:10–35` | TLS1.3/h2, verified localhost/certificate, ragged-EOF suppression disabled |

Adapt explicit deadlines to integer nanoseconds; tighten nonce to `[A-Za-z0-9_]{1,32}`. Preserve actual exceptions where transport requires them. Retain listener inode evidence internally while returning the transport’s address-tuple schema. Do not import old factories, protocol/case modules, post parser, or shutdown orchestration.

Add only:

- `native_host.py`: explicit OS/SSL effects and bounded capture, using the authenticated algorithms.
- `native_provider.py`: `new_provider(config, *, clock, ops) -> (ChildFactory, ProviderState)`; child construction, teardown, acceptance aggregation.
- `run_native.py`: mode/selection entry point and failure boundary.
- Focused provider checks and recorded native-run controls.

Use named flat data contracts: configuration; provider children≤2; child process/start/listener, nonce/certificate identity, capture/watcher evidence, transport, frozen pre-facts, terminal facts and cleanup state.

**Exact wiring**

Canonical `coordinator.py:296–342` invokes:

```text
child_factory(run_identity, child_index, selection, ready_deadline, whole_deadline)
```

Return exactly the conditional descriptor keys validated at `coordinator.py:23–43`, including actual `bind_context`. Delegate:

```text
connect(case, number, case_deadline, whole_deadline)
bind_context(context)
close(context, deadline)
disconnect_close(context)
termination(context, deadline)
```

through partials to accepted `native_transport` functions. Do not bind a replacement connection as a fresh initial context; preserve canonical disconnect replacement behavior.

Supply the operations documented at `native_transport.py:22–52`:

```text
dial(address, seconds), wrap(raw, hostname, suppress_ragged_eofs, seconds)
inspect(handle), set_timeout(handle, seconds), send(handle, bytes)
recv(handle, maximum), close(handle), ownership(), capture()
new_protocol = h2_client.new_protocol
unwrap(handle)                         # exactly when disconnect is selected
```

`recv` performs only the bound receive operation. Meet the accepted wrap/unwrap ownership contract, including failed handshakes. Strict disconnect delegates public unwrap, raw EOF and returned-handle close to `disconnect_close:423`.

Provider `signal(context, deadline)` dispatches active shutdown to `transport.signal(state, owned_signal, context, deadline)`. Idle/ordinary shutdown uses a separately validated host signal after normal client closure, returning `client_open=False`; active-only transport.signal must not serve that path.

OwnedSignal receives the exact retained child/handle/deadline and returns C6c’s six-part evidence tuple, including fresh prerequisites, actual SIGTERM operation result, and ordered ticks. It must not require live PID/listener after successful signaling.

**Independent readiness and capacity**

The authenticated fixture’s `profile.zig:267–270` performs listen, `catch_shutdown_signals`, nonce-bound READY, then run. Bind that source/build ordering and actual child-pipe READY observation into watcher-installation evidence; an arbitrary object or Boolean is insufficient.

Use `output-driver.tar.gz::provenance/manifest-v5.json["capacity"]` as the independent native capacity authority, after confirming C8’s candidate/layout and explicit fixture configuration are identical. Its numeric suffix is:

```text
request_stride=5888 h2_bytes=281200 h2_stride=281200 slab=4098304 router=884352
```

Pass the full authenticated value with only `H2_CAPACITY ` removed to C5. Never use synthetic `test_native_post.CAPACITY`, or learn the expectation from this run’s output. A mismatch blocks acceptance.

Declare unique per-run/per-child nonces before spawning, within the authenticated grammar. Bind them to exclusive child directories, certificate identity and environment; capture does not choose its own expected nonce.

**Completion and run acceptance**

1. Start fresh idle then main children. Install collection immediately; prove PID/start/listener ownership and exact capacity/READY before returning `ready=True`. Readiness occurs once; retain supplied ready15/whole900/case30-or180/clipped-grace≤15 deadlines without resets.
2. Freeze actual canonical pre-facts before signal. Active shutdown delegates C4/C6c; canonical code alone begins/finishes termination.
3. `process(context, deadline)` requires exit0/reap, listener disappearance, collector join/pipe closure, complete healthy capture and normal socket/file/key/certificate cleanup. Parse real capture with `native_post.parse_capture`, validate against frozen actual pre-facts with `validate_post`, then return exact process facts. `post` revalidates and returns detached parsed facts. Missing evidence or forced cleanup rejects.
4. Around coordinator execution and aggregation, call `fail_transport` on failure, retain the exact primary exception, perform bounded one-shot child cleanup, then bare-reraise.
5. Execute explicit `coordinator.run(catalogue.CASES, ...)` and genuinely omitted `coordinator.run(...)` separately for both build modes. Each invocation needs fresh idle/main children and 41 connections.
6. Revalidate ordered live transport receipts across both children, adapting the aggregation algorithm at `test_native_transport.py:1031`; compare ordinary seals plus active prefix with frozen canonical totals. Preserve closing deltas/debt and fresh C4 local receipt separately. Observe actual 100MB/output hashes, generations and producer/file counters; never copy simulated observations.

Retain runtime checks before/after, complete capture and failures, and no private certificate/key bytes or 25 original environment records. A native outer acceptance receipt supplements the unchanged canonical result. Full repository/platform gates and adoption remain later. No implementation or execution occurred here.
