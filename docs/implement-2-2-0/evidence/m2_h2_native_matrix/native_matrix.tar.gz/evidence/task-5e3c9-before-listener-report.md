# C9 interim report: operational Round1 FIX1

C9 native full40 acceptance is pending. This report hands the four reviewed operational fixes to the SAME reviewer; new native effects remain held until scoped PASS and Root release. No successful full40 run is claimed.

## Scope and frozen inputs

P is `.uwz-work/evidence/h2-streaming/native_provider/`. Changes are confined to P: `native_host.py`, `native_provider.py`, `native_override.py`, `run_native.py`, `run_control.sh`, `source.sha256`, new `test_failure_contracts.py`, and narrow fixture-call adjustments in `test_provider.py`/`test_override.py`. `test_collection.py` and `test_inert.py` remain byte-identical. No canonical/native7/C8/target/product/pin changes were made during FIX1.

Before state: `.superpowers/sdd/h2_streaming_plan/task-5e3c9-fix1-base/`, authenticated by adjacent `task-5e3c9-fix1-base.sha256`; P/fix1-final/base-verification.txt records PASS. Root's scoped package is `task-5e3c9-fix1-review-package.diff`, 32032 bytes, SHA-256 `0f6be2217f27a1491b88f59802b786ad9e114a46eba37dc4850b2e1c0e0c25d4`; adjacent JSON provides all before/after sizes and hashes. Worker diff P/fix1-final/scoped.diff SHA `d81cf754e60c8d90990c2e9eb0b497471acd50e41d146c7722ee2a89a816e506` additionally records unchanged-file comparison.

Final preexecution snapshot: P/snapshots/109_round1_preflight/; code.sha256 SHA `c9b23de6c6903713899e4bf67426dbfddc353b4455533f6ce7a155e5e22b41ff`. Reverification passed in P/fix1-final/frozen-verification.txt. Completed snapshots were never rewritten. Large metadata is referenced through authenticated C8 identities, not recopied.

Final P/source.sha256: `a27fde1a48eb92cd321a662b08d9fa20babab696e633ac0490ed3e0c9b90ae34`; run_control.sh: `a152324f665bfe5794d0c27aa7b68f41bdb2e512149d8ea26a38b4ece0063738`. P/fix1-final/source.sha256 lists every final source/control identity (manifest SHA `1a8e20d83e29369c52001b40cf9dd65f12db6c4dec7ad6a3c1ecb69fdf4855fd`).

## Four fixes and behavioral evidence

1. Helper admission precedes ordinary import. `run_native.admit_override` admits named source identities, rejects eligible bytecode, and installs the C8 guard before importing `native_override`. The controller's shared bytecode gate runs before any Python invocation; C8 bootstrap absences are also checked. Scope validation moved into the already admitted runner. Existing saved normal/optimized fixtures are authenticated and reused read-only; no new cache demonstration or actual project cache was constructed during recovery.
2. Handle release records an attempted release before calling close, separately from successful closure. Host failure cleanup skips attempted releases. Failed close never earns normal acceptance. The transport-to-host handoff regression retains the exact original failure and secondary close error.
3. Failure capture preservation is guarded, with private-file cleanup in `finally`. Each certificate/key/transfer unlink is independently attempted. Actual secondary exceptions are retained with total count and fixed eight-entry bound. Failure cleanup cannot set normal removal acceptance.
4. The execute boundary shields both cleanup and receipt serialization/write, then uses bare rethrow. Exact primary identity survives either or both failures; actual secondaries have a fixed two-entry bound and separate count. Fixed phase/type notes identify otherwise unsaved reporting errors.

Saved genuine REDs against the old boundary: 89 release (exit1, `underlying_close_attempts 2 closed_successes 0`); 90 capture (exit1, `private_unlink_attempts [] capture_cleanup_raised OSError`); 91 reporting (exit1, `reporting_preserved_primary False`); 93/94 cache normal/-O (exit1, controller and loader `sentinel_executed True`). Earlier 92 also exposed loader execution; its controller fixture-path rejection is retained separately, not treated as complete controller RED proof.

GREEN results:

| Controls | Mode | Actual terminal result |
| --- | --- | --- |
| 95/99 release | normal/-O | exit0; one close attempt, zero successful closes |
| 96/100 capture | normal/-O | exit0; cert/key/transfer each attempted despite capture and cert-unlink errors; two retained secondaries |
| 97/101 reporting | normal/-O | exit0; exact primary preserved |
| 98/102 cache | normal/-O | exit0 proof; controller and loader reject exit1 before marker; marker remains absent |
| 103/104 reporting final | normal/-O | exit0; primary preserved with cleanup plus reporting errors, secondary_count2 |
| 105/106 positive | normal/-O foreign cwd | exit0; published override negative cases and all11 provider groups pass |
| 107/108 inert | normal/-O | exit0; foreign-cwd import/rejected CLI remain inert under effect guards |
| 109 metadata preflight | normal | exit0; C8 fix1 capacity/config/layout/import/mapping/unused-extension checks pass; no target effects |

## Exact commands and raw records

All controls use Root cwd and `env -i PATH=/usr/bin:/bin /bin/sh P/run_control.sh LABEL ARGV...` (P expanded to its actual path). The controller snapshots first, authenticates bootstrap/source/metadata and absent caches, restores fresh119 in the same shell, then invokes pinned `/home/codespace/.python/current/bin/python3 -B -S` with recorded optional `-O`. It never reads private25 originals.

P/fix1-final/commands-record.txt contains the exact expanded 95–109 shell commands (SHA `8e27362c3585c17331bf8fb62bd99e087b0bf791a27936d85f5993113816828f`). Each P/raw/LABEL.argv, .stdout, .stderr, .exit and associated restore/check receipts are retained. P/fix1-final/control-results.txt collects exact argv, status and output for RED/GREEN/preflight. Original pre-fix snapshots and raw failures remain intact.

Preflight output: `Runtime preflight passed: C8 fix1; candidate/config/layout equality; independently approved native imports/mappings; no target effects`. P/runtime-preflight-a27fde1a48eb92cd.json SHA `b2b26a119450f2fe385a1e294b5a7ad0479194776b8331a2da7bb8028d40b07a`.

## Actual native status and limits

Last native control remains rejected 84_debug_explicit_r4. Its idle child exited0, reaped, released listener, joined collector and closed pipe without force; healthy actual capture30048 bytes SHA `04d5843e0e7c774885e21769f0adcfc634d8deb2014ef9a8d485f163ca6cdd14` passed canonical C5 post validation. Provider normal transfer-file cleanup then failed; full run rejected. Snapshot86 corrected owned unlink behavior with RED85 and GREEN86/87; no target defect established. No r5 or subsequent native run occurred during FIX1.

C9a published two-file override remains exact; C8 strict archival equality and native7 identities remain fixed. All four actual full40 receipts,100MB hashes/counters/generations and final live transport aggregation remain pending. These source-only checks do not establish native acceptance, H3, adoption or full M2. Self-review confirms failed cleanup still rejects, secondary errors stay separate, and no acceptance threshold was weakened. Graph maintenance/publication/integration remain Root-owned.

## Actual r5 after scoped review release

Root released Round1 after SAME reviewer PASS (review SHA `643ee0da703a436fde9c6bd556892b78487cbbd34eefdaf72593e266ab46150d`). Exact new command: `env -i PATH=/usr/bin:/bin /bin/sh .uwz-work/evidence/h2-streaming/native_provider/run_control.sh 110_debug_explicit_r5 .uwz-work/evidence/h2-streaming/native_provider/run_native.py --run debug explicit r5`. Snapshot110 retains reviewed source/control before execution.

Actual terminal status1: `ValueError: transport_time`, canonical `large_declared`, at original180-second case boundary. The main observer recorded55,232 operations,18,420 sends and36,811 receives;75,422,594/100,000,000 request bytes observed without final response. Entry33305959590473, deadline33485959090523ns; no budget was increased. Full failure receipt `/tmp/uwz-h2-native-c9/debug_explicit_r5/failure.json` SHA `e559cc40dc5ed9f4a99138671bdfa83ad09b8478c7c8a7807abe384f34cca5f2`; P/actual-r5/ records focused summary/identities.

Idle child completed exit0/reap/listener disappearance/collector join/pipe close, two successful closes, normal removal and all private paths absent; actual healthy capture30048 bytes SHA `582b60de6ff32421dec61386fd7adc341f2c639866664462d72ec72dcf753a24`. Main failure cleanup forced exit-9/reap/join/pipe close, six attempted/successful handle closes and all three private paths absent. Forced cleanup grants no acceptance. Its healthy completed failure capture1054 bytes SHA `4c209011d6ef6a822b0a2eea705d4dcdb2713d23c5c766022d33105fba722735`. Primary preserved; no cleanup/report errors.

Per-operation full `/proc/net/tcp` ownership observation is a candidate host overhead source (~3.26ms per observer operation, inferred from elapsed budget/operation count, not separately measured). No target defect is inferred. Source and acceptance checks remain unchanged while Root considers a strictly equivalent live observation strategy. Four accepted native receipts remain pending.
