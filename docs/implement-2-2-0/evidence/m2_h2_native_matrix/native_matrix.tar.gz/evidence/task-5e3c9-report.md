# C9: actual native HTTP/2 full40 matrix

All four required actual runs accepted with the same reviewed provider: Debug and ReleaseSafe, each with explicit and genuinely omitted selection. Each completed 40 cases, 41 ordered live connection receipts and two fresh owned children under the original ready 15s, whole 900s, case 30s/180s and clipped grace <=15s budgets. Final independent evidence review and publication remain Root-owned.

P=`.uwz-work/evidence/h2-streaming/native_provider/`; T=`/tmp/uwz-h2-native-c9/`. Exact commands are retained in P/native-final/commands-record.txt:

```sh
env -i PATH=/usr/bin:/bin /bin/sh .uwz-work/evidence/h2-streaming/native_provider/run_control.sh 121_debug_explicit_r6 .uwz-work/evidence/h2-streaming/native_provider/run_native.py --run debug explicit r6
env -i PATH=/usr/bin:/bin /bin/sh .uwz-work/evidence/h2-streaming/native_provider/run_control.sh 122_debug_omitted_r6 .uwz-work/evidence/h2-streaming/native_provider/run_native.py --run debug omitted r6
env -i PATH=/usr/bin:/bin /bin/sh .uwz-work/evidence/h2-streaming/native_provider/run_control.sh 123_release_explicit_r6 .uwz-work/evidence/h2-streaming/native_provider/run_native.py --run release explicit r6
env -i PATH=/usr/bin:/bin /bin/sh .uwz-work/evidence/h2-streaming/native_provider/run_control.sh 124_release_omitted_r6 .uwz-work/evidence/h2-streaming/native_provider/run_native.py --run release omitted r6
```

Every command terminated 0 with `ACCEPTED ... 40 cases; 41 connections; two fresh children; actual exit0/reap/post/cleanup/live receipts`. P/raw/LABEL.{argv,stdout,stderr,exit}, fresh 119 restoration/bootstrap checks and preexecution snapshots remain intact. The controller invokes pinned Python `-B -S`, an explicit safe environment and authenticated import/native/bytecode/mapping controls. Private25 originals were never read.

## Actual receipts

Full original receipts and both exact child captures are retained under P/native-final/RUN/ as well as T/RUN/:

| Control / RUN | acceptance.json SHA-256 |
| --- | --- |
|121 / debug_explicit_r6|f1d98f696d6f9b9112813842714bca5493afbfbac0bdb58b1ad1f732fbd5e450|
|122 / debug_omitted_r6|84fc8bee65ad8a326c904717722284106adc41f0387742c4e4c6c156305842c6|
|123 / release_explicit_r6|15c6586347744d9b6dd36c772010cce171f9d161b5ac7c35197ab4d70fbf9319|
|124 / release_omitted_r6|00590fe1915efe8a2e3328e14f63bff5db326d52b692bdacb2aea8d4f77a73bf|

Omitted runs execute `coordinator.run(**keywords)`; explicit runs pass catalogue.CASES. All eight children exited 0, reaped, released the listener, joined the collector and closed its pipe, with forced=False and normal removal=True. Each idle/main pair recorded 2+80 attempted and successful handle closes, zero open handles, zero cleanup errors, and absent certificate/key/transfer paths. Final filesystem checks confirm all 24 private paths absent. Healthy completed capture sizes, idle/main: 30048/30355, 29974/30281, 30196/30503, 30122/30429 bytes; no overflow/errors. Full identities are P/native-final/{runtime-identities.sha256,control-identities.sha256,source.sha256}; package.sha256 binds the safe durable packet.

C5 validates actual capture against frozen actual pre-facts and independent FULL capacity, followed by post/live receipt revalidation. TLS actually negotiated 1.3+h2 with verified localhost/peer-DER identity and ragged-EOF suppression disabled. Real SIGTERM evidence retains PID/start/listener/watcher/client bindings and ordered operation ticks. Strict public unwrap, raw EOF and returned-handle close remain delegated to native7.

## Observed workload facts

Every run observed both 100000000-byte uploads with SHA `190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2`, 12208 chunks each and maximum span 8192. Each of three 16777313-byte producer responses matched `e5b7e8c5bbad59c7bc86f18236a37661571e972f65c707d7dc1902386ec5e91d`; the 24593-byte file response matched `8cacc49e5f9553369e25a67f4e0e9a799b38c07245a6da92a54ffb58c3ebc2ac`. File facts: four reads, 24593 requested/returned, one normal close, zero errors/invalid spans, offsets 37..24630.

Actual bindings: producer generation 52, next 53, window 54, ready 55. In control order 121–124, producer/window/ready invocation counts were 271/265/259, 268/266/259, 269/269/262, 269/268/262. Blocked=pending counts were 270/264/258, 267/265/258, 268/268/261, 268/267/261. Each producer wrote 2049 times and completed exactly one terminal attempt. Full post records, scheduling and hashes are P/native-final/RUN.json, extracted from accepted receipts by retained extract.jq.

Each total: 802 heads, 789 small streams, request_flow 200091899, settings 46, informationals 2, incoming_resets 13, final_collections 2, receive_bytes 51332321, receive_calls 113518. Ordinary seals and active prefix reconcile with canonical totals; closing deltas/debt remain separate. Active shutdown retains 25-byte debt and a local post-signal TLS-EOF receipt, without claiming authenticated peer closure.

Large declared/undeclared connection-entry intervals in ns were 69710639139/68847649788, 69739891508/69654479656, 68386230906/70472059369, 69624726149/69011092641. These include transition overhead, not isolated handler duration. Raw entries/deadlines are retained. Configured capacity remains request_stride 5888, h2_bytes/h2_stride 281200, slab 4098304, router 884352 after candidate/config/layout equality and actual capacity-log validation. Span/capture/queue facts are bounded observations; no RSS or server-throughput measurement is claimed.

## Sources, fixes and retained failures

New owned modules comprise host/provider/runner, narrow published-override validation, bounded pure listener parsing, focused tests and controller. No product/pin/native7/C8/target edits. Only the exact Root-published C9a two-file canonical override is authorized (archive d1a51b3a..., revision 8fc6c797...); C8 strict archival checks remain unchanged. Original protocols, 40 cases and native7 are consumed directly.

Final source inventory SHA `25049aab57483c0d8604c07471c04d8bc8937b3810534dbc2a5bdcb465e9ef44`; controller SHA `a152324f665bfe5794d0c27aa7b68f41bdb2e512149d8ea26a38b4ece0063738`. All four snapshot code inventories match reviewed119 SHA `9dc91d42c5714bff32558feb3d6f914a34ef899e0b8b2b6f930312b877fc4185`; final reverification passed. Large immutable metadata uses authenticated references; completed snapshots were never rewritten.

Retained actual failures: 11 sandbox denial; 16/r1 readiness-log interleaving; 21/r2 missing separately approved IDNA closure; 27/r3 collection handoff gap resolved by published C9a; 84/r4 owned transfer cleanup; 110/r5 the original 180-second large-upload deadline after 75422594 bytes. Forced cleanup remains rejected; no target defect was inferred. Each failure/capture/control is preserved. Full safe r4/r5 failure receipts/captures are copied under P/native-final/. The earlier detailed report is P/native-final/before-native-final-report.md.

Operational Round1 RED89–94/GREEN95–104 proved helper admission before import, one-shot failed-close ownership, independent private-file cleanup and exact primary preservation despite reporting errors. Positive105/106, inert107/108 and preflight109 passed; the same reviewer approved. Listener RED111 exposed the full-table read; normal113/-O114, inert115/116, positive117/118 and preflight119 passed. The production reader consumes all leading LISTEN rows with multiplicity using bounded, unbuffered 128-byte reads. Only a valid boundary/EOF completes; corruption, truncation, exhaustion and errors reject. Controlled 512/8192-row tails both consumed 512 bytes/four reads. Real-kernel smoke120 passed with closure preserved. The same reviewer approved before r6. Exact commands/results/scoped diffs and pins remain P/{fix1-final,listener-final}/.

Self-review: no budget, case, backend, ownership check or acceptance threshold was weakened. Unknown/internal closing-prefix and unauthenticated-closure limits remain. H3, production adoption, repository/platform/release acceptance and full M2 remain outside this result.
