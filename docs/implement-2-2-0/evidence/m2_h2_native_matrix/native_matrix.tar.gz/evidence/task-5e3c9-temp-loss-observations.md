# Temporary-path availability after the completed C9 runs

Cause is undetermined. These are current-state observations, not an attribution
to provider cleanup or a claim that the preserved successful runs did not occur.

At 16:07–16:11 UTC on 2026-11-09, Root's new post-run preservation audit could
not resolve the original C7 source export, C8 build/input roots, C9 runtime root,
or original Zig test cache. Both default and escalated `ls` observations agree.
The failed audit source, executed copy, stdout, stderr and exit1 are retained as
`task-5e3c9-root-audit*`. It stopped at the first C7 tree check after checking
the unchanged C8 file rows, direct rows and current owned source inventory.

Earlier in this goal turn, Root independently read and hash-checked all four
original `/tmp/uwz-h2-native-c9/*_r6/acceptance.json` files. The independent
reviewer also read the original receipts, captures and C8 binary files before
issuing its final PASS. The safe workspace copies of all 34 final evidence
files still verify against package index
`d8bc9a9e58db36db8593850928ebcb6e6167f792dfb9368647b7d929fbc56b36`.

The fresh unit exit file records 11:40 UTC; the final native packet records
11:38 UTC. Current checks show `/tmp` on `/dev/sdc1`, whereas earlier tool output
showed `/dev/sdb1`. Current device/inode are 2081/2359297. These observations
do not by themselves establish why paths disappeared. No restoration,
recompilation, native replay, move or deletion was performed for this check.

The C9 implementer reported:

> All requested `/tmp` paths are absent in my current exec view. All 34 durable evidence files still verify.
>
> Provider cleanup only unlinks the three owned child files; retained commands contain no parent-directory deletion. Cause remains undetermined. No files were changed or recreated.

The independent reviewer reported:

> All four paths are absent in my current default-exec view:
>
> - `/tmp/uwz-h2-native-rehydration-c7`
> - `/tmp/uwz-h2-native-c8-fix1`
> - `/tmp/uwz-h2-native-c9`
> - `/tmp/uwz-original-zig-cache`
>
> The four preserved `P/native-final/*_r6/acceptance.json` files remain present and match their previously reviewed hashes.
>
> My final evidence review successfully read and hash-checked the original `/tmp` receipts, captures, and both C8 binaries. I ran no deletion, move, cleanup, target, or test commands. Earlier, the prescribed restoration/Graphify invocation wrote `/tmp/c9-review-restore-01.json` and reported **“restored 0.”** None of my explicit commands removed or replaced these directories.
>
> Current `/tmp` metadata shows device2081, inode2359297, and modification/change time `2026-11-09 16:11:27.778241070 UTC`. I have no prior matching metadata comparison and cannot establish the cause of the disappearance.

Recovery must use authenticated artifacts and record new recovered instances.
Do not overwrite the failed audit or imply that restored receipt files are new
native executions. Current physical input/binary availability needs recovery
before the original preservation audit can pass; the durable actual run data
remains independently reviewed evidence of the completed runs.
