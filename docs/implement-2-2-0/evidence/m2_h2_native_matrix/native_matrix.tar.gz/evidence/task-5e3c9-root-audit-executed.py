"""Audit preserved inputs and the four actual native receipts without targets."""
import hashlib
import json
import runpy
import stat
import sys
import tarfile
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def approved_api(plan):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_collection_handoff/collection_handoff.tar.gz')
    require(sha(archive.read_bytes()) == 'd1a51b3a24ce5724e6eb32df850ddb375636ab0b72c1cdd4e8ec621ca570f5ea', 'C9a archive differs')
    helper = plan / 'task-5e3c9a-root-audit.py'
    with tarfile.open(archive, 'r:gz') as source:
        require(source.extractfile('evidence/' + helper.name).read() == helper.read_bytes(), 'Published helper differs')
        revision = source.extractfile('SOURCE_REVISION.json').read()
    require(sha(revision) == '8fc6c797a5d481c36b25636df0e909635000e66b7baa25ef52d5ce67b7a8f9ae', 'Published revision differs')
    api = runpy.run_path(str(helper))
    c8, base = api['authority'](plan)
    return api, c8, base, revision


def source_inputs(packet, api, c8, base, revision):
    require((packet / 'handoff/revision.json').read_bytes() == revision, 'Live revision differs')
    revised = api['revision_files'](packet, json.loads(revision), base, c8['check_file'])
    inventory = api['check_source_inventory'](packet, '25049aab57483c0d8604c07471c04d8bc8937b3810534dbc2a5bdcb465e9ef44')
    for row in base['direct'].values():
        c8['check_file'](row)
    root = Path('/tmp/uwz-h2-native-c8-fix1')
    trees = dict(
        candidate=c8['check_tree'](Path('/tmp/uwz-h2-native-rehydration-c7/candidate'), base['exports']['candidate'], readonly=True),
        libxev=c8['check_tree'](Path('/tmp/uwz-h2-native-rehydration-c7/libxev'), base['exports']['libxev'], readonly=True),
        fixture=c8['check_tree'](root / 'inputs/fixture', base['fixtures'], readonly=True),
        sdk=c8['check_tree'](Path(base['sdk_root']), base['sdk'], base['sdk_empty']),
        zslay=c8['check_tree'](Path(base['zslay_root']), base['zslay']))
    c8['check_file'](base['generated'])
    require(stat.S_IMODE(Path(base['generated']['path']).stat().st_mode) == 0o444, 'Generated C mode differs')
    require(stat.S_IMODE((root / 'inputs').stat().st_mode) == 0o555, 'Staged inputs mode differs')
    for value in base['runtime']['bytecode_absences']:
        path = c8['safe_path'](value)
        require(not path.exists() and not path.is_symlink(), 'C8 eligible bytecode appeared')
    return dict(revised=revised, unchanged_c8_paths=len(base['files']) - 2, direct_inputs=len(base['direct']),
                source_inventory=inventory, trees=trees, bytecode_absences=len(base['runtime']['bytecode_absences']))


def verify_code(packet, snapshot):
    control = snapshot / 'code.sha256'
    require(sha(control.read_bytes()) == '9dc91d42c5714bff32558feb3d6f914a34ef899e0b8b2b6f930312b877fc4185', 'Exercised code inventory differs')
    rows = control.read_text().splitlines()
    require(len(rows) == 14, 'Code inventory scope differs')
    for line in rows:
        expected, name = line.split('  ', 1)
        path = Path(name)
        require(path.parent == packet.resolve() and path.is_file() and not path.is_symlink(), 'Code path differs')
        require(sha(path.read_bytes()) == expected, 'Current exercised source differs')
        require((snapshot / path.name).read_bytes() == path.read_bytes(), 'Preexecution source differs')
        reject_bytecode(path)
    return len(rows)


def reject_bytecode(path):
    if path.suffix != '.py':
        return
    tag = sys.implementation.cache_tag
    names = [path.with_suffix('.pyc')]
    names.extend(path.parent / '__pycache__' / (path.stem + '.' + tag + suffix + '.pyc')
                 for suffix in ('', '.opt-1', '.opt-2'))
    require(all(not name.exists() and not name.is_symlink() for name in names), 'Owned eligible bytecode appeared')


def safe_index(packet):
    index = packet / 'native-final/package.sha256'
    require(sha(index.read_bytes()) == 'd8bc9a9e58db36db8593850928ebcb6e6167f792dfb9368647b7d929fbc56b36', 'Native evidence index differs')
    rows = index.read_text().splitlines()
    require(len(rows) == 34, 'Native evidence scope differs')
    for line in rows:
        expected, name = line.split('  ', 1)
        path = Path(name)
        require(path.is_relative_to(packet / 'native-final') and '..' not in path.parts, 'Unsafe evidence path')
        require(path.suffix not in ('.pem', '.key') and path.is_file() and not path.is_symlink(), 'Private or nonregular evidence')
        require(sha(path.read_bytes()) == expected, 'Native evidence member differs')
    return len(rows)


def child_receipt(child, root, index, binary_sha):
    flags = ('reaped', 'listener_gone', 'joined', 'pipe_closed', 'removed')
    require(all(child[name] is True for name in flags) and child['forced'] is False, 'Child terminal ownership differs')
    require(type(child['process_status']) is int and child['process_status'] == 0, 'Child exit differs')
    require(child['binary_sha256'] == binary_sha, 'Child build binding differs')
    handles = 2 if index == 0 else 80
    require(all(type(child[name]) is int and child[name] == handles for name in ('handles', 'closed_handles', 'release_attempts')), 'Release facts differ')
    require(child['open_handles'] == 0 and child['cleanup_error_count'] == 0 and child['cleanup_errors'] == [], 'Child cleanup differs')
    require(child['private_paths_absent'] == dict(cert=True, key=True, transfer=True), 'Private path facts differ')
    directory = root / ('child_' + str(index))
    for name in ('certificate.pem', 'private-key.pem', 'transfer.bin'):
        path = directory / name
        require(not path.exists() and not path.is_symlink(), 'Owned private path remains')
    capture = child['capture']
    require(capture['finished'] is True and capture['overflow'] is False and capture['error'] is None, 'Capture health differs')
    data = (directory / 'capture.bin').read_bytes()
    require(0 < len(data) <= 65536 and len(data) == capture['bytes'] and sha(data) == capture['sha256'], 'Actual capture differs')
    data.decode('utf-8')
    return dict(pid=child['pid'], start=child['start'], nonce=child['nonce'], certificate_sha256=child['certificate_sha256'],
                capture_bytes=len(data), capture_sha256=sha(data), handles=handles, normal_cleanup=True)


def check_run(packet, name, expected, mode, selection, binary_sha, control):
    root = Path('/tmp/uwz-h2-native-c9') / name
    path = root / 'acceptance.json'
    data = path.read_bytes()
    require(sha(data) == expected and (packet / 'native-final' / name / path.name).read_bytes() == data, 'Original/native copy differs')
    receipt = json.loads(data)
    require(receipt['status'] == 'accepted' and receipt['mode'] == mode and receipt['selection'] == selection, 'Run identity differs')
    require(receipt['selection_omitted'] is (selection == 'omitted'), 'Omitted-selection fact differs')
    chosen = receipt['result']['selection']
    require(len(chosen) == 40 and len(set(chosen)) == 40 and all(type(value) is str for value in chosen), 'Case selection differs')
    require(len(receipt['receipts']) == 41 and len({tuple(row[0]) for row in receipt['receipts']}) == 41, 'Ordered receipt identities differ')
    totals = receipt['result']['totals']
    require(totals['connections'] == 41 and totals['heads'] == 802 and totals['request_flow'] == 200091899, 'Canonical totals differ')
    require(len(receipt['children']) == 2, 'Child count differs')
    children = [child_receipt(child, root, index, binary_sha) for index, child in enumerate(receipt['children'])]
    safe = packet / 'native-final' / name
    for index, child in enumerate(children):
        require((safe / ('child_' + str(index) + '.capture.bin')).read_bytes() ==
                (root / ('child_' + str(index)) / 'capture.bin').read_bytes(), 'Copied capture differs')
    require((packet / 'raw' / (control + '.exit')).read_text().strip() == '0', 'Native control did not succeed')
    code_rows = verify_code(packet, packet / 'snapshots' / control)
    return dict(name=name, acceptance_sha256=expected, acceptance_bytes=len(data), mode=mode, selection=selection,
                cases=chosen, totals=totals, ordered_receipts=41, children=children, exercised_source_rows=code_rows)


def matrix(packet, builds):
    controls = (
        ('debug_explicit_r6', 'f1d98f696d6f9b9112813842714bca5493afbfbac0bdb58b1ad1f732fbd5e450', 'debug', 'explicit', '121_debug_explicit_r6'),
        ('debug_omitted_r6', '84fc8bee65ad8a326c904717722284106adc41f0387742c4e4c6c156305842c6', 'debug', 'omitted', '122_debug_omitted_r6'),
        ('release_explicit_r6', '15c6586347744d9b6dd36c772010cce171f9d161b5ac7c35197ab4d70fbf9319', 'release', 'explicit', '123_release_explicit_r6'),
        ('release_omitted_r6', '00590fe1915efe8a2e3328e14f63bff5db326d52b692bdacb2aea8d4f77a73bf', 'release', 'omitted', '124_release_omitted_r6'))
    runs = [check_run(packet, name, expected, mode, selection, builds[mode]['binary']['sha256'], control)
            for name, expected, mode, selection, control in controls]
    require(all(run['cases'] == runs[0]['cases'] for run in runs), 'Full selections disagree')
    children = [child for run in runs for child in run['children']]
    for field in ('pid', 'nonce', 'certificate_sha256'):
        require(len({child[field] for child in children}) == 8, 'Child identity reuse')
    return runs


def audit(plan):
    packet = Path('.uwz-work/evidence/h2-streaming/native_provider')
    api, c8, base, revision = approved_api(plan)
    preserved = source_inputs(packet, api, c8, base, revision)
    builds = {mode: c8['check_build'](Path('/tmp/uwz-h2-native-c8-fix1'), mode,
              'e78cbbc2f1665e6999a5502f2817be531909a80d72e1dbd0fd22055dc93bb53c', expected)
              for mode, expected in (
                  ('debug', '4c89d63f760f467315e83d8c40021f49335b432490e9a06f8cf3f604e69bb476'),
                  ('release', '94510b8b95880b084f5a2250fd825db181cc9f1320d36f59130f3bdcf64d2f10'))}
    evidence_files = safe_index(packet)
    verify_code(packet, packet / 'snapshots/119_listener_preflight')
    runs = matrix(packet, builds)
    result = dict(preserved=preserved, builds=builds, safe_native_evidence_files=evidence_files, runs=runs,
                  scope='Input preservation, actual receipt/capture bytes and terminal metadata; protocol validation independently reviewed',
                  current_owned_private_paths_absent=24, target_executed_by_auditor=False,
                  native_four_run_metadata_verified=True, milestone_complete=False)
    (plan / 'task-5e3c9-root-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(unchanged_c8_paths=preserved['unchanged_c8_paths'], trees=preserved['trees'],
                         runs=len(runs), captures=8, current_private_paths_absent=24, safe_evidence_files=evidence_files)))


if __name__ == '__main__' and sys.argv[1:] == ['--audit']:
    audit(Path('.superpowers/sdd/h2_streaming_plan'))
