#!/bin/sh
set -eu
cd /workspaces/uWebZockets
export PYTHONDONTWRITEBYTECODE=1
plan=/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan
/home/codespace/.python/current/bin/python3 -B -S "$plan/task-5e3b8a-restore-inputs.py" --restore "$plan/task-5e3c9-publish-graph-inputs.json" > "$plan/task-5e3c9-publish-graph-restore.stdout" 2> "$plan/task-5e3c9-publish-graph-restore.stderr"
PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .
