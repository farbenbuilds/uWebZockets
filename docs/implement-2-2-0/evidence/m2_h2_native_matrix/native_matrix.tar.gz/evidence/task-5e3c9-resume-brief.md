# C9 resume: published C9a authority, actual native acceptance

Continue SAME C9 task/ownership under original task-5e3c9-brief.md and concrete
task-5e3c9-plan-report.md. Do not restart C7/C8 or change product/pins/native7.
Root independently audited C9a source and published evidence. SAME reviewer
approved source FIX1 and final publication. Root's separate release message
must confirm commit/push before this brief authorizes effects.

## Explicit published two-file authority

Authenticate before execution:
`docs/implement-2-2-0/evidence/m2_h2_collection_handoff/collection_handoff.tar.gz`
SHA d1a51b3a24ce5724e6eb32df850ddb375636ab0b72c1cdd4e8ec621ca570f5ea,
3679909 bytes. Authenticate its regular member inventory using accepted
archive machinery, then exact `SOURCE_REVISION.json` SHA
8fc6c797a5d481c36b25636df0e909635000e66b7baa25ef52d5ce67b7a8f9ae.
Direct archived `source/canonical/` and `baseline/canonical/` members fix:

| File | C8 old bytes / SHA-256 | Published new bytes / SHA-256 |
| --- | --- | --- |
| coordinator.py | 23073 / 6585ad2323ce38a75948c7c365ceb7b9589c06e1c6010ae01ba35de0f11e6b32 | 23518 / 4c00e7ae957d2ca488dd14b9814c91f3068a5aa61758ab9a43fb81483a200bb0 |
| shutdown_cases.py | 7689 / 2856e200fa463b26c79e4e0b74cc9ead4863f9a1dd6372c0e8249fb9b163e15c | 10562 / c03bc49a65760d3fa99cf45078b893ecebbc4dd3602de6ced4017207b1f08eb7 |

Authorize ONLY those two exact reviewed canonical paths from the published
revision, independently of their current discovered contents. Keep the old
C8 preflight e78cbbc2... and archive e3b8fe1c... unchanged. The other 44 canonical
modules, legacy tests, native7, candidate/dep/fixture/SDK/tool/runtime/binaries
remain exact C8 authority. No monkeypatch, global substitution, arbitrary
current-hash approval, original C8 helper edit or gate weakening. C8 historical
strict equality and its recorded refusal remain intact. A separate C9 validator
must distinguish the two independently authorized replacements while preserving
all other checks. Own code may explicitly copy manifest data for this run;
retain original authority and an auditable narrow override record.

Cover old-gate refusal, exact reviewed acceptance, wrong hash/size/path/scope,
unexpected third replacement and original C8 control preservation with focused
source-only normal/-O checks before fresh runtime effects. Do not re-run the
unchanged full C4-C8 suites or C9a source40 matrix. Preserve source/control
versions before execution; no importing revised code before authorization.

Keep the earlier separately approved IDNA unicodedata extension graph, native
prior-approval rejection, independent full capacity and C8 fresh binary
identities. Source-test-only extensions do not become native roots implicitly.
Use a fresh unique run directory/nonce (r4 or later); prior failed attempts
remain evidence. Pinned Python/fresh119 Root-cwd/bootstrap/closure/import and
bytecode checks still apply to every dependent invocation.

After the focused override tests and complete new runtime preflight pass,
Root authorizes the original four real full40 runs with exact original budgets,
cases, factory/protocol identity and success requirements. Escalation for owned
loopback/kernel operations is already authorized; preserve default sandbox
refusal if encountered and do not change backend. No new user permission gate.

Do not patch a target/accepted helper if an actual failure appears. Retain exact
case, runtime identity, capture, primary error and cleanup result, then report
the concrete source/interface gap to Root. Focused fixes to your OWN provider
may proceed with behavioral regressions and distinct retries. Canonical or
native7 changes require a separate scoped Root decision and review.

## Evidence storage and remaining work

Completed snapshots were hardlink-deduplicated after their proofs. Never
rewrite them: distinct historical paths may share an inode. New source versions
must use fresh snapshot paths. Reference authenticated immutable large metadata
instead of copying the same 13MB per control. Workspace is only 1.7GiB free;
runtime/large captures stay in exclusive /tmp/uwz-h2-native-c9. Do not delete
evidence, toolchains, zig-pkg, zig-out/lib or original cache. Never read the
25 private historical environments or publish test key/certificate bytes.

Finish with the original full task report: exact four actual native receipts,
process/listener/capture/normal cleanup, hashes/generation/scheduling/memory,
final ordered transport receipts, source/control identities, all retained
failures and precise limitations. C9a accepts source handoff only. C9 full40,
production adoption, H3 and full M2 remain unaccepted until their own evidence.
