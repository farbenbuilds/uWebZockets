#!/bin/sh
set -eu
cd /workspaces/uWebZockets
export PYTHONDONTWRITEBYTECODE=1
plan=/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan
cp "$plan/task-5e3c9-publish.py" "$plan/task-5e3c9-publish-executed.py"
sha256sum "$plan/task-5e3c9-publish.py" "$plan/task-5e3c9-publish-executed.py" > "$plan/task-5e3c9-publish-code.sha256"
/home/codespace/.python/current/bin/python3 -B -S "$plan/task-5e3b8a-restore-inputs.py" --restore "$plan/task-5e3c9-publish-inputs.json" > "$plan/task-5e3c9-publish-restore.stdout" 2> "$plan/task-5e3c9-publish-restore.stderr"
/home/codespace/.python/current/bin/python3 -B -S "$plan/task-5e3c9-publish.py" --build > "$plan/task-5e3c9-publish-build.stdout" 2> "$plan/task-5e3c9-publish-build.stderr"
