"""AST and inert import proof for every directly owned source module."""
import ast
import builtins
import datetime
import importlib
import os
import pathlib
import socket
import ssl
import subprocess
import sys
import time
from unittest import mock
import catalogue
import h2_client
import hpack
import model
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def reject(*_args, **_kwargs):
    raise RuntimeError('import invoked a forbidden caller hook')


def check():
    names = ('cases', 'adapter', 'test_selection', 'test_adapter', 'test_ready', 'test_async',
             'test_large', 'test_final', 'test_time', 'test_shared', 'test_negative', 'test_imports',
             'pause_cases', 'test_pause', 'admission_cases', 'test_admission', 'continue_quota_cases', 'test_continue_quota', 'credit_cases', 'test_credit', 'metadata_cases', 'concurrent_cases', 'test_metadata_concurrency', 'control_reset_cases', 'test_control_reset', 'application_error_cases', 'test_application_error', 'producer_pressure_cases', 'test_producer_pressure', 'file_early_cases', 'test_file_early', 'lifecycle_cases', 'test_lifecycle', 'shutdown_cases', 'test_shutdown', 'coordinator', 'test_coordinator', 'test_core_peer', 'test_coordinator_composition', 'test_coordinator_shutdown', 'test_terminal_peer', 'test_wire_oracle', 'test_wire_oracle_checks', 'test_all40_descriptors', 'test_all40')
    directory = pathlib.Path(__file__).parent
    if {path.stem for path in directory.glob('*.py')} != set(names):
        raise RuntimeError('authored source inventory differs')
    for name in names:
        tree = ast.parse((directory / (name + '.py')).read_text(), filename=name + '.py')
        if any(isinstance(node, (ast.ClassDef, ast.Assert)) for node in ast.walk(tree)):
            raise RuntimeError('class or assert in ' + name)
        guards = [node for node in tree.body if isinstance(node, ast.If) and
                  isinstance(node.test, ast.Compare) and isinstance(node.test.left, ast.Name) and
                  node.test.left.id == '__name__' and len(node.test.ops) == 1 and
                  isinstance(node.test.ops[0], ast.Eq) and len(node.test.comparators) == 1 and
                  isinstance(node.test.comparators[0], ast.Constant) and node.test.comparators[0].value == '__main__']
        if len(guards) != 1:
            raise RuntimeError('missing main guard: ' + name)
    replacements = [(builtins, 'open'), (socket, 'socket'), (socket, 'socketpair'),
                    (socket, 'create_connection'), (socket, 'create_server'), (ssl, 'SSLContext'),
                    (subprocess, 'Popen'), (subprocess, 'run'), (subprocess, 'call'),
                    (subprocess, 'check_call'), (subprocess, 'check_output'), (os, 'system'),
                    (os, 'popen'), (os, 'open'), (os, 'write'), (time, 'time'),
                    (time, 'monotonic'), (time, 'perf_counter'), (time, 'sleep'), (datetime, 'datetime')]
    saved = [(module, key, getattr(module, key)) for module, key in replacements]
    old_argv, old_out, old_err = sys.argv, sys.stdout, sys.stderr
    try:
        for module, key, _value in saved:
            setattr(module, key, reject)
        for argv in ([], ['foreign', '--run', 'unexpected']):
            for name in names:
                sys.modules.pop(name, None)
            sys.argv = argv
            out, err = mock.Mock(), mock.Mock()
            out.write.side_effect = reject
            err.write.side_effect = reject
            sys.stdout, sys.stderr = out, err
            for name in names:
                importlib.import_module(name)
    finally:
        sys.argv, sys.stdout, sys.stderr = old_argv, old_out, old_err
        for module, key, value in saved:
            setattr(module, key, value)
    print('AST and inert import checks passed')


if __name__ == '__main__':
    check()
