**Spec compliance: Compliant with the binding checkpoint slice.**

The diff implements the immutable `(ConnectionReceipt, operation)` contract, one-shot validation, observable final-collection boundary, held stream3, clean tails and bounded debt. Successful checkpoint creation changes only its marker; ordinary operation counting, exception propagation, sticky poison and seal/reseal behavior remain intact.

**Strengths**

- [test_wire_oracle.py:521](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_wire_oracle.py:521) keeps checkpoint validation separate from ordinary invocation. The shared prefix validation and receipt construction preserve the published seal predicates and tuple fields.
- [test_wire_checkpoint.py:52](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_wire_checkpoint.py:52) establishes the positive boundary through serialized traffic and checks operation141, exact counters, immutable receipts, fragmented refunds and ordinary reseal.
- [test_wire_checkpoint.py:79](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_wire_checkpoint.py:79) checks actual raised `SSLEOFError` identity, operation142 poison, original effects and failed ordinary sealing. Negative coverage includes all24 partial WINDOW_UPDATE tails, reentrancy and prior poison.
- The structural review found no actionable complexity regression: the oracle grows by42 lines, checkpoint tests occupy a separate196-line module, and shared receipt helpers remove duplication without adding protocol branches to `invoke`.

**Issues**

Critical: None.  
Important: None.  
Minor: None.

**Checks and evidence**

- Confirmed the supplied report/package hashes and current hashes of all three touched source modules.
- Named risk—false held-open acceptance: inspected published descriptor validation, request matching, final ordering and terminal handling. These enforce the declared open upload and leave only stream3 incomplete.
- Named risk—seal or poison regression: compared the extracted predicates and receipt fields with the published baseline and inspected unchanged `invoke`/first-poison behavior.
- Inspected retained API-absence RED, seal-scaffold behavioral RED and rejected compound-main-guard failure.
- Inspected normal and optimized focused commands, exit0 receipts, empty stderr, strict/inert results and canonical `shutdown_active` composition showing68 final responses and32/32 debt.
- Reviewed preservation auditor logic and receipts distinguishing19806 protected prior entries from two authorized source changes,809 preserved c2 files and119/118/113/42 closure.

**Verification limits**

Tests and bulk preservation audits were not rerun. Native application-record validation, PID/signal/canonical-phase authorization, closing receipts, real TLS execution and native/M2/full-goal acceptance remain external prerequisites. Full all40 and Zig gates were not repeated under this source-only authorization.

**Task quality: Approved.** No actionable findings; approval applies only to this private nonterminal checkpoint slice.
