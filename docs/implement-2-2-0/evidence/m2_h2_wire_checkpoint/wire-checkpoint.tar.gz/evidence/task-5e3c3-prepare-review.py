import difflib
import hashlib
import json
import runpy
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def baseline():
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_combined_all40/combined-all40.tar.gz')
    if sha(archive.read_bytes()) != 'd2a247eae5191cfe374dbfe298c973df1f4c92e8662b15997285dac36f7c8940':
        raise ValueError('Baseline source authority differs')
    with tarfile.open(archive, 'r:gz') as stream:
        return {name: stream.extractfile('source/current/' + name).read() for name in ('test_wire_oracle.py', 'test_imports.py')}


def main(argv):
    if argv != ['--prepare']:
        return
    plan = Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan')
    source = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    before = baseline()
    names = ('test_wire_checkpoint.py', 'test_wire_oracle.py', 'test_imports.py')
    parts = ['# c3 checkpoint source review\nBase=head d559be4d1cf877cad4ce9ea0022ec780f1be383b.\nPrivate source observer and tests; no tracked/product/native changes.\n']
    for name in names:
        old = before.get(name, b'').decode().splitlines(True)
        parts.extend(difflib.unified_diff(old, (source / name).read_text().splitlines(True), fromfile='reviewed/' + name, tofile=str(source / name), n=10))
    helpers = sorted((source / 'evidence/wire-checkpoint').glob('*.py'))
    helpers.extend((plan / 'task-5e3c3-root-audit.py', plan / 'task-5e3c3-prepare-review.py'))
    for path in helpers:
        parts.extend(difflib.unified_diff([], path.read_text().splitlines(True), fromfile='/dev/null', tofile=str(path), n=10))
    check = runpy.run_path(str(plan / 'task-5e3c1-prepare-review.py'))['root_check']
    checks = {name: check(plan / name) for name in ('task-5e3c3-root-audit.py', 'task-5e3c3-prepare-review.py')}
    (plan / 'task-5e3c3-root-helper-check.json').write_text(json.dumps(checks, indent=2) + '\n')
    for name in ('task-5e3c3-root-final-audit.json', 'task-5e3c3-root-helper-check.json'):
        parts.extend(['\n# ' + name + '\n', (plan / name).read_text()])
    output = plan / 'task-5e3c3-review-package.diff'
    output.write_text(''.join(parts))
    data = output.read_bytes()
    print(json.dumps(dict(path=str(output), bytes=len(data), sha256=sha(data))))


if __name__ == '__main__':
    main(sys.argv[1:])
