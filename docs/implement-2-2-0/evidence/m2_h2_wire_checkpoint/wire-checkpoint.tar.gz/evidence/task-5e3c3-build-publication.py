"""Publish the reviewed private checkpoint and its source-only proof."""
import hashlib
import json
import runpy
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def writer(plan):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_native_source_preparation/native-source-preparation.tar.gz')
    if sha(archive.read_bytes()) != '3c6d55ddc6a9d58445d1635a79186135f230c476eaba97257685649f7481e7de':
        raise ValueError('Writer provenance differs')
    path = plan / 'task-5e3c2-build-publication.py'
    with tarfile.open(archive, 'r:gz') as stream:
        if stream.extractfile('evidence/' + path.name).read() != path.read_bytes():
            raise ValueError('Published writer bytes differ')
    return runpy.run_path(str(path))['writer'](plan)


def add_baseline(api, members):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_combined_all40/combined-all40.tar.gz')
    if sha(archive.read_bytes()) != 'd2a247eae5191cfe374dbfe298c973df1f4c92e8662b15997285dac36f7c8940':
        raise ValueError('Published source baseline differs')
    with tarfile.open(archive, 'r:gz') as stream:
        for member in stream:
            if member.isfile() and member.name.startswith(('reference/', 'source/current/')):
                name = member.name.replace('source/current/', 'history/baseline-source/', 1)
                api['add'](members, name, stream.extractfile(member).read(), {})


def collect(api, members, source, plan):
    for path in sorted(source.glob('*.py')):
        api['add'](members, 'source/current/' + path.name, path.read_bytes(), {})
    raw = source / 'evidence/wire-checkpoint'
    for path in sorted(raw.rglob('*')):
        if path.is_symlink():
            raise ValueError('Evidence symlink')
        if path.is_file():
            api['add'](members, 'raw/wire-checkpoint/' + path.relative_to(raw).as_posix(), path.read_bytes(), {})
    names = ('task-5e3c3-brief.md', 'task-5e3c3-report.md', 'task-5e3c3-review-report.md',
             'task-5e3c3-review-package.diff', 'task-5e3c3-root-audit.py', 'task-5e3c3-root-audit-initial.py',
             'task-5e3c3-root-audit-before-baseline-scope.py', 'task-5e3c3-root-final-audit.json',
             'task-5e3c3-root-final-audit.stdout', 'task-5e3c3-root-final-audit.stderr', 'task-5e3c3-root-final-audit.exit',
             'task-5e3c3-root-scoped-audit.stdout', 'task-5e3c3-root-scoped-audit.stderr', 'task-5e3c3-root-scoped-audit.exit',
             'task-5e3c3-root-current-audit.stdout', 'task-5e3c3-root-current-audit.stderr', 'task-5e3c3-root-current-audit.exit',
             'task-5e3c3-root-final-audit-inputs.json', 'task-5e3c3-root-scoped-audit-inputs.json',
             'task-5e3c3-root-current-audit-inputs.json', 'task-5e3c3-root-helper-check.json',
             'task-5e3c3-root-review-inputs.json', 'task-5e3c3-prepare-review.py',
             'task-5e3c3-build-publication.py', 'task-5e3c3-publication-audit.py',
             'task-5e3c-terminal-contract-report.md', 'task-5e3c-terminal-doubt-artifact.md',
             'task-5e3c-terminal-doubt-report.md', 'task-5e3b8a-restore-inputs.py')
    for name in names:
        api['add'](members, 'evidence/' + name, (plan / name).read_bytes(), {})


def main(argv):
    if argv != ['--build']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    audit = json.loads((plan / 'task-5e3c3-root-final-audit.json').read_text())
    current = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if current != audit['source']['source_files'] or len(current) != 46:
        raise ValueError('Approved source changed')
    api, members = writer(plan), {}
    add_baseline(api, members)
    collect(api, members, source, plan)
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_wire_checkpoint')
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'wire-checkpoint.tar.gz'
    inventory = api['write_archive'](archive, members)
    manifest = dict(scope='Private nonterminal immutable wire checkpoint; source-only verification',
                    base_commit='d559be4d1cf877cad4ce9ea0022ec780f1be383b',
                    archive=archive.name, archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
                    safe_regular_utf8_members=len(members) + 1, inventory_entries=len(inventory),
                    current_source_files=current, baseline_modules=45, current_modules=46,
                    changed_files=['test_wire_oracle.py', 'test_imports.py'], added_files=['test_wire_checkpoint.py'], unchanged_modules=43,
                    checkpoint_contract='immutable (ConnectionReceipt, operation); one shot; nonterminal; no I/O or counter reset',
                    serialized_fixture_operation=141, later_tls_eof_operation=142, final_responses=68,
                    known_partial_tail_cases=24, ordinary_poison_unchanged=True, ordinary_seal_and_reseal_unchanged=True,
                    source_review='Spec and task quality approved; verbatim evidence/task-5e3c3-review-report.md',
                    prior_preservation=audit['preservation'], c2_packet=audit['c2_packet'],
                    touched_source_max_nesting=audit['source']['touched_max_nesting'],
                    unchanged_baseline_lexical_depth_over_three=audit['source']['unchanged_over_three'],
                    root_qa_scope_correction='Initial unpublished Root checks over-scoped untouched baseline; failures and corrections retained',
                    source_context_logging='Initial context-only console retention incomplete; substantive runs retained',
                    accepted_tls_eof_outcome_added=False, native_compiled=False, native_executed=False, milestone_complete=False,
                    remaining=['Native closing provenance and bounded local receipt', 'Native provider and fresh runtime closure',
                               'Fresh builds/native all40/full project/platform gates', 'Production adoption and remaining milestones'])
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = {key: manifest[key] for key in ('archive_sha256', 'archive_bytes', 'safe_regular_utf8_members', 'inventory_entries', 'current_modules')}
    (plan / 'task-5e3c3-root-archive-build.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
