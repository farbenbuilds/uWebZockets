"""Reopen the source checkpoint archive and bind every delivery byte."""
import hashlib
import json
import runpy
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def auditor(plan):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_native_source_preparation/native-source-preparation.tar.gz')
    if sha(archive.read_bytes()) != '3c6d55ddc6a9d58445d1635a79186135f230c476eaba97257685649f7481e7de':
        raise ValueError('Independent auditor provenance differs')
    path = plan / 'task-5e3c2-publication-audit.py'
    with tarfile.open(archive, 'r:gz') as stream:
        if stream.extractfile('evidence/' + path.name).read() != path.read_bytes():
            raise ValueError('Published auditor source differs')
    return runpy.run_path(str(path))['auditor'](plan)


def verify_sources(contents, source, manifest):
    current = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if len(current) != 46 or current != manifest['current_source_files']:
        raise ValueError('Current source inventory differs')
    for name in current:
        if contents['source/current/' + name] != (source / name).read_bytes():
            raise ValueError('Current source archive differs')
    baseline = json.loads(Path('docs/implement-2-2-0/evidence/m2_h2_combined_all40/manifest.json').read_text())['current_source_files']
    if len(baseline) != 45:
        raise ValueError('Published baseline count differs')
    for name, digest in baseline.items():
        if sha(contents['history/baseline-source/' + name]) != digest:
            raise ValueError('Archived baseline source differs')
    return dict(current=46, baseline=45)


def verify_evidence(contents, source, plan):
    root = source / 'evidence/wire-checkpoint'
    expected = {'raw/wire-checkpoint/' + path.relative_to(root).as_posix(): path.read_bytes() for path in root.rglob('*') if path.is_file()}
    actual = {name: data for name, data in contents.items() if name.startswith('raw/wire-checkpoint/')}
    if actual != expected:
        raise ValueError('Whole new evidence archive differs')
    for name, data in contents.items():
        if name.startswith('evidence/') and data != (plan / name.removeprefix('evidence/')).read_bytes():
            raise ValueError('Root archived evidence differs')
    return len(expected)


def main(argv):
    if argv != ['--audit']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    docs = Path('docs/implement-2-2-0')
    folder = docs / 'evidence/m2_h2_wire_checkpoint'
    manifest = json.loads((folder / 'manifest.json').read_text())
    archive = folder / manifest['archive']
    if sha(archive.read_bytes()) != manifest['archive_sha256'] or archive.stat().st_size != manifest['archive_bytes']:
        raise ValueError('Archive identity differs')
    api = auditor(plan)
    contents = api['read_archive'](archive)
    for data in contents.values():
        data.decode('utf-8')
    if len(contents) != manifest['inventory_entries'] or len(contents) + 1 != manifest['safe_regular_utf8_members']:
        raise ValueError('Archive member counts differ')
    sources = verify_sources(contents, source, manifest)
    raw = verify_evidence(contents, source, plan)
    check = runpy.run_path(str(plan / 'task-5e3c1-prepare-review.py'))['root_check']
    names = ('task-5e3c3-root-audit.py', 'task-5e3c3-prepare-review.py', 'task-5e3c3-build-publication.py', 'task-5e3c3-publication-audit.py')
    helpers = {name: check((plan / name).resolve()) for name in names}
    files = [docs / 'README.md', docs / 'm2_request_streaming.md', docs / 'm2_h2_wire_checkpoint.md',
             folder / 'README.md', folder / 'manifest.json', archive]
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
                  regular_utf8_members=len(contents) + 1, inventory_entries=len(contents), sources=sources,
                  raw_evidence_files=raw, root_helpers=helpers, local_links=api['verify_links'](files),
                  delivery_files={str(path): dict(size=path.stat().st_size, sha256=sha(path.read_bytes())) for path in files},
                  native_executed=False, milestone_complete=False)
    (plan / 'task-5e3c3-root-publication-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('root_helpers', 'delivery_files')}, indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
