# Native terminal observation contract decision

Status: recommendation complete; implementation and native execution remain unreleased. Only this report was authored. Source45, source/all40 evidence, candidate, dependencies and pins were not changed.

## Decision

Preserve the historical `tls_eof` outcome **only as local transport lifecycle evidence with an explicit unknown-prefix qualification**. Preserve ordinary observer exception poison, including a closing `ssl.SSLEOFError`. Do not make `seal()` succeed after that exception. Freeze a separate, immutable pre-signal checkpoint and produce a separate closing receipt that states what was returned before the terminal operation, what that operation did, and what remains unknown.

This preserves the existing acceptance scope: the canonical terminal result is literally `kind='local_transport_only'`, not proof of complete TLS delivery (`reference/core/raw_observer.py:64–79`). The active handler expressly permits `eof` and `tls_eof`, unlike strict disconnect (`shutdown_cases.py:93–103`; `reference/core/wire.py:521–539`). The legacy hook fields `frames_valid=True`, `primary_response=False`, and `trailing_bytes=0` describe the successfully returned plaintext inspected by the existing parser. They cannot describe invisible TLS internals. The native receipt must carry that scope next to the legacy hook facts; an unqualified export of those facts is unacceptable.

A consumer requiring complete closing plaintext, zero discarded plaintext, or authenticated TLS shutdown must reject the `tls_eof` receipt. That stronger requirement needs independently established clean TLS termination and possibly a separately reviewed production shutdown change. It cannot be satisfied by a receipt redesign. No production change is required merely to retain the existing local lifecycle precedent. No claim here certifies the production server's TLS shutdown compliance.

## Source authority and decisive clauses

`A` denotes `.uwz-work/evidence/h2-streaming/combined-interface-audit/`. `C` denotes `docs/implement-2-2-0/evidence/m2_h2_combined_all40/combined-all40.tar.gz`. Paths below beginning `source/` or `reference/` are archive members, not current Root source guesses. The existing authenticated authority is `A/bound-matrix.json`, its member hashes and the c1 report; this task did not repeat that authentication audit.

| Requirement | Exact authority and meaning |
| --- | --- |
| Ordinary exception poison | C `source/current/test_wire_oracle.py:130–184`, SHA256 `6401a1d42ca15a3e9cea830586f233edd294cad712064d540eb083f432cffc2f`: `invoke` poisons on every `BaseException`, re-raises it, and only observes a successfully returned result. First failure is sticky. Already failed calls preserve original effects, not later proof. |
| Existing receipt scope | Same member `:1–5,26–36,110–123,519–538`: immutable tuples at the full-send/receive seam, pinned codecs shared, ordinary final seal after hooks; no seal when poisoned. `seal` allows descriptor-declared `transport_abandon`, retaining incomplete stream and debt. |
| Final collection before signal | C `source/current/shutdown_cases.py:72–94`, SHA256 `2856e200fa463b26c79e4e0b74cc9ead4863f9a1dd6372c0e8249fb9b163e15c`: held 32-byte upload, seven accepted bytes in the model barrier, complete final records/metrics, outputs/binding, then signal, signal validation, stage signal and canonical begin. |
| Counter checkpoint | C `source/current/coordinator.py:220–239`, SHA256 `75ccc55642de0733108c15838e9dce2a3770ae0144f652f9e2960c0d3acaac53`: first teardown hook freezes counts and summary before invoking the provider; restores selected accounting afterward. It does not erase canonical terminal state. |
| Single canonical terminal owner | C `source/current/shutdown_cases.py:93–105` owns begin and finish. C `reference/core/wire.py:498–542` binds records/raw/request/credit/stage, rejects target response, calls canonical raw finish, transport end and response retirement exactly once. |
| Local scope and known tails | C `reference/core/raw_observer.py:52–79`: boundary and terminal checks reject `header`, active `frame`, or nonzero `remaining`; owned shutdown accepts `eof`/`tls_eof`; returns `local_transport_only`. |
| Closing traffic | Same member `:122–165`: <=4096 closing frames, <=65536 closing returned bytes, <=8192 per read; closing permits only length-4 WINDOW_UPDATE, flags0, unreserved stream identifier, stream0 or the held stream. C `reference/core/output_stage.py:163–209` additionally enforces remaining case/final read and byte budgets. |
| Debt | C `reference/core/output_stage.py:121–151`: active final-entry connection plus stream debt <=64; final budget derives from actual debt. C `reference/core/request_credit.py:126–155`: transport end retains nonzero debt; refunds cannot exceed existing debt. Passive credit observation at `test_wire_oracle.py:490–506` clamps and therefore does not replace canonical validation. |
| Deadlines | C `source/current/coordinator.py:13–17,296–340`, `source/current/shutdown_cases.py:11–27`, `reference/model/catalogue.py:110–142`: monotonic integer ticks, explicit positive units; readiness15s, whole900s, active case30s, grace clipped to case/whole and15s. Equality with deadline fails. |
| Real postconditions | C `reference/model/model.py:343–351,365–393`: active record gains exactly one shutdown cancel and becomes inactive/unpaused; other facts, completed outputs and binding stay unchanged. |
| Historical precedent | `m2_h2_lifecycle_close_live/lifecycle-close-live.tar.gz`, `source/runtime-v2/strict_close.py:8–55`, SHA256 `3e3dd20197f2d07e2c44afba0ef0deddad100012c8b33c9d116b8798b2e29866`: strict disconnect uses successful public unwrap plus TCP EOF; active loop catches `SSLEOFError`. Its begin/finish calls must not be reused in the combined hook. |
| Native TLS configuration | `m2_h2_output_driver/output-driver.tar.gz`, `source/runtime/connection.py:10–35`, SHA256 `d8e35532a14329324abf8597f060be2b8a0fba09340726507b684e469b837677`: TLS1.3, h2, peer identity and `suppress_ragged_eofs=False`. Fresh interpreter/OpenSSL closure remains unresolved. |

The two supplied planning reports remain context, not newly approved exception policy. Additional reads of the already located archive members above resolved the truncated wire-finish span and its directly imported raw observer; they did not discover or execute a new runtime.

## Public API semantics and limits of inference

Python defines `SSLEOFError` as abrupt TLS termination and discourages transport reuse. Its documented exception supplies no consumed-prefix bytes/count. `suppress_ragged_eofs=True` can convert unexpected EOF into empty bytes; retain `False`. `unwrap()` performs TLS shutdown and returns the socket for subsequent plain operations. `pending()` counts decrypted bytes currently available, not bytes discarded during a failed call. These API facts do not establish the fresh runtime's exact implementation/version. [Python ssl documentation](https://docs.python.org/3/library/ssl.html#ssl.SSLEOFError), [wrap_socket](https://docs.python.org/3/library/ssl.html#ssl.SSLContext.wrap_socket), [unwrap](https://docs.python.org/3/library/ssl.html#ssl.SSLSocket.unwrap), [pending](https://docs.python.org/3/library/ssl.html#ssl.SSLSocket.pending).

OpenSSL distinguishes `SSL_ERROR_ZERO_RETURN` from unexpected EOF; the former normally means a received close alert but can also arise with `SSL_OP_IGNORE_UNEXPECTED_EOF`. Its underlying-transport closure is a separate fact. Unexpected-EOF error mapping changed at OpenSSL3.0. Therefore neither exception text matching nor empty bytes alone, without verified runtime/options, proves authenticated close. [OpenSSL SSL_get_error](https://docs.openssl.org/3.0/man3/SSL_get_error/#return-values).

TLS1.3 explicitly says a transport close before `close_notify` leaves delivery completeness unknowable. Receipt of valid earlier records does not authenticate the end of the stream. [RFC8446 section6.1](https://www.rfc-editor.org/rfc/rfc8446.html#section-6.1).

Inference: two executions can expose identical returned plaintext followed by the same `SSLEOFError`, while one has an additional internally consumed incomplete TLS record. No predicate over these API observations can distinguish them. A known empty HTTP/2 parser tail cannot discharge that uncertainty. This is an information limit, not a missing assertion.

## Recommended minimal design

Use the existing native provider hooks and existing passive decoder. Add only the checkpoint/closing-receipt support required to preserve the two observation scopes. Do not add another client/parser, global monkeypatch, socket wrapper that only forwards, or descriptor conditions across shared protocol modules.

The small observer change is a nonterminal immutable checkpoint operation for this explicitly authorized lifecycle boundary. Share the existing receipt construction/validation with ordinary `seal`; the difference has an invariant: checkpoint freezes a prefix without setting `sealed` or granting an unpoisoned full-session verdict. The existing ordinary `invoke`, first-failure policy and `seal` remain semantically unchanged. A native-local closing state holds authorization, that checkpoint, baseline offsets/operation number, terminal facts and bounded diagnostics. The existing `begin_shutdown_observation` proposal is not necessary as an exception bypass.

### Order and authorization

1. Complete actual final collection and validate all67 records, metrics, outputs and binding. No receive/send may be in flight. Both canonical and independent parsers have no known partial tail; independent observer has no failure and is unsealed. The exact descriptor is the final `shutdown_active`, connection1, with the sole held `transport_abandon` upload. Validate actual request identity and completion counts, not a caller-supplied phase string alone.
2. At the start of the provider's signal hook, after the coordinator has taken its pre-teardown snapshot and before signal effects, freeze the independent checkpoint and copied per-scope debts. Bind it to run/child/connection identity and observer operation number. Neither sealing nor resetting counters occurs. No intervening application send/receive is allowed. Kernel/TLS buffers need not be empty; the checkpoint is an API observation boundary, not a timestamp claiming when network packets arrived.
3. Revalidate owned PID/start/listener and the open TLS connection; successfully issue the owned signal within the caller's grace. Record the actual result. Failed signal leaves an unactivated checkpoint and a failed native run. No cleanup or later EOF can activate it retroactively.
4. The unchanged active handler validates signal evidence, marks its stage signaled, and begins canonical termination. On entry to the provider's termination hook, validate those actual states and matching connection/held stream; activate closing observation once. Duplicate activation, stale identity, wrong descriptor, prior poison, partial tail or any operation between checkpoint and this authorized phase fails.
5. Drain only through the already wrapped receive seam; each nonempty successful return feeds the existing passive decoder and existing canonical `wire.accept` path exactly once. The provider never calls canonical begin/finish. No application writes or new streams are permitted during this closing scope. Existing canonical closing policy admits only bounded credit frames, so no reason exists to add an ACK/write path here.
6. Record exactly one terminal operation. Empty returned bytes yields `eof`. A real `ssl.SSLEOFError` originating from the actual TLS receive yields `tls_eof`, after ordinary `invoke` has poisoned and re-raised it. The native boundary may record that outcome locally; it must not return fabricated empty bytes from `receive`. Preserve exception identity through `invoke`; catch only around that receive, not around parsing, clock checks, identity checks or the whole hook.
7. Check known tails, all validations and time, freeze the closing receipt, and return the unchanged narrow hook dictionary only when its local-scope predicates hold. The unchanged handler performs canonical finish once and then real process/post-deinit validation. Successful run acceptance waits for those facts and normal cleanup. Close the owned transport; never read/unwrap it after `SSLEOFError`.

The proposal intentionally does not use ordinary `seal` to bless the full poisoned connection. A later native aggregate contains a pre-teardown checkpoint plus a scoped closing receipt, not a forged `ConnectionReceipt` for the entire session. Source all40's existing receipt shape, immutable checkpoint and ordinary poison tests remain valid and unchanged. The coordinator's existing `pure_client_synthetic_peer` result label must not be republished as a native-verification label; the native envelope states its own evidence scope.

### Facts, accounting and limits

The checkpoint contains the existing immutable connection tuple, exact receive/send successes, bytes, frames, requests/completions, observed debt per stream and connection, and operation number. Bind comparisons to the coordinator's same pre-teardown boundary. Never compare final native receive totals to frozen pre-teardown totals.

The closing receipt contains connection/checkpoint identity, authorization phase, integer start/end/deadline/units, attempts, successful returns, nonempty returns, returned bytes and existing frame/credit deltas, terminal operation number and outcome, original failure receipt, and known parser-tail facts. Include `scope='local_transport_only'`, `unknown_internal_prefix`, `complete_wire_proof=False`, and `authenticated_close_notify='not_established'`. For `tls_eof`, discarded/unreturned plaintext length is **unknown**, never0. The empty-return path proves only the observed return unless a separate clean-TLS proof is recorded.

An exception increments attempted operation count but contributes no successful return or known byte count. “No bytes returned by this call” is a fact; “this call consumed zero bytes” is not. If bytes are returned by TLS and a later timestamp/shape/decoder check fails, that is not a TLS EOF outcome: retain available diagnostics and fail. Returned bytes must not silently disappear in adapter postprocessing.

Keep all existing bounds conjunctively:

- Each returned data chunk <=8192; closing returned bytes <=65536; complete closing frames <=4096. Preserve frame length/type/flags/stream restrictions above.
- Preserve residual canonical case and final byte budgets, residual read-call caps, response/frame/header constraints and valid debt refunds. The closing65536 allowance is not extra case/final budget. Do not reset canonical stage counters inside the receive loop; the coordinator's later restoration is accounting publication, not authorization to reread another budget.
- Count every actual TLS receive attempt in the closing receipt. With no retry on exceptions, nonempty calls cannot exceed the remaining canonical read allowance; permit at most one additional terminal probe. Thus attempts <= remaining nonempty-read allowance +1. An EOF/error probe returns/raises once and stops. When byte/read allowance is exhausted, any additional positive data rejects; the terminal probe does not grant data allowance. Diagnostics retain at most one <=8192-byte overshoot chunk rather than buffering unbounded traffic.
- Integer ticks remain authoritative. Before each operation compute remaining ticks against the single caller-provided grace, already clipped to case/whole; convert to seconds only for the OS timeout. Check again after the operation and before acceptance. Regressing/noninteger clocks, deadline equality, expiry or overflow reject. Socket timeout, generic SSL errors, WANT_READ/WANT_WRITE escaping this blocking boundary and ordinary I/O errors all poison/fail; no retry or enlarged deadline.
- Maintain both frozen checkpoint debt and live closing debt. Only successfully returned, canonically validated credit frames decrease the latter. Terminal abandonment never refunds debt. Do not infer a refund hidden inside the failed receive. Preserve actual remaining connection/stream debt at canonical transport end, including nonzero abandoned upload debt.

The bounds constrain observable plaintext and caller operations. They do not bound TLS ciphertext internally consumed by an exceptional call or prove zero TLS-internal work. Deadlines bound elapsed acceptance; full process/runtime limits belong to the separately reviewed native closure.

### Seal, poison and acceptance predicates

Checkpoint creation requires no prior failure, no busy/reentrant operation, no prior seal/checkpoint, complete final collection and known clean tails. The immutable checkpoint remains a true record of that prefix even if a subsequent call fails. Its validity never means the whole run passed.

Ordinary poison remains absorbing. For `tls_eof`, require the first failure to be exactly the receive exception at the identified terminal attempt, with no earlier observer/canonical/provider failure and no intervening operation. It is still a failed full-session proof. A separate closing outcome may be recorded, but cannot clear or overwrite the failure. For `eof`, require no observer failure. In both paths reject known residual frame/header/block state, forbidden returned frames, primary response, invalid credit, changed scope, or failed time checks.

Native local-lifecycle acceptance is the conjunction of:

1. Valid immutable pre-signal checkpoint bound to actual canonical semantic counts and debts.
2. Authorized single activation after successful owned signal and canonical begin.
3. Every successfully returned closing byte observed once, accepted by both existing observer and canonical validation, within all remaining limits; known tails empty.
4. Exactly one permitted terminal outcome with the failure conditions above; explicitly qualified unknown prefix for `tls_eof`.
5. Exactly one handler-owned canonical finish, remaining debt retained, and expected post-deinit delta from actual67-record/four-output/binding/metrics capture.
6. Actual successful exit, reap, capture completion and normal owned resource cleanup, with no forced cleanup or suppressed error.

Neither termination-hook success nor receipt freezing is run acceptance. Any postterminal receive/send attempt invalidates the closing run verdict; the provider refuses further I/O. Existing passive-wrapper behavior remains unchanged if misused directly: it preserves effects and poison, never restores proof. Frozen earlier receipts are evidence prefixes and must not be reused to hide that later failure. No final acceptance is issued until hooks/cleanup finish.

## Rejected alternatives and risks

- **Special-case SSLEOF inside ordinary `invoke`, clear poison, or teach `seal` to ignore it:** manufactures full-session proof despite an unknowable consumed prefix. Rejected.
- **Seal before signal and continue ordinary wrapped I/O:** existing after-seal poison is correct; this is not a nonterminal checkpoint. Do not unseal/reset afterward.
- **Bypass the observer for closing reads:** loses returned-byte independence. Capture terminal facts separately while retaining the original wrapped seam and parser for successful returns.
- **Map SSLEOF to empty bytes or enable ragged-EOF suppression/ignore options:** conceals the distinction under review. Rejected.
- **Require unwrap on active shutdown to preserve the old test:** changes the precedent and may require production behavior changes. Appropriate only for a separately authorized stronger clean-close goal. Strict disconnect keeps its existing unwrap/TCP-EOF contract unchanged.
- **Use the archived strict active helper unchanged:** duplicates canonical ownership. Rejected.
- **Copy the parser/state into a new client or trust only canonical counts:** either unnecessary duplication or loss of independent observation. Reuse the passive decoder; canonical validation still owns stricter refund/frame policy.
- **Treat `pending()==0`, empty parser tails, signal success or child exit0 as zero discarded plaintext:** none establishes that fact. Rejected.

Residual risk is explicit: the limited receipt cannot detect a forbidden frame prefix consumed internally by the terminal TLS call, or prove all peer-sent data arrived. If Root's resolved acceptance demands either property, this recommendation's limited predicate is insufficient and must not be relabeled to satisfy it. That would require clean terminal evidence/production work, not relaxation of poison.

## Focused adversarial tests for the later released slice

Use caller-owned scripted operation/clock doubles and existing codecs; no sockets, SSLContext, runtime imports or native execution in the first slice. These are proposed tests, not tests run here.

| Stimulus | Required result |
| --- | --- |
| Valid final checkpoint, signal, legal refunds, empty receive | Local receipt succeeds only after canonical/post/cleanup facts; exact bytes/counters; no authenticated-close claim inferred. |
| Same observed returns then actual terminal SSLEOF object | Original exception propagates through ordinary wrapper unchanged; first poison identifies it; ordinary seal fails; separate local receipt records unknown prefix. |
| Two fake transports expose identical returns/SSLEOF but have different hidden consumed prefixes | Public receipts cannot distinguish hidden content and both explicitly say unknown; neither claims complete wire or zero discard. |
| Timeout/other SSL/OSError, SSLEOF raised by parser/clock/postprocessing rather than TLS receive | Run fails; no accepted terminal conversion; all available successful-byte facts retained. |
| Prior failed send/receive followed by valid-looking EOF | Checkpoint or activation fails; original poison unchanged. |
| EOF before signal, idle/disconnect descriptor, missing final response, wrong child/stream, signal failure | No authorized closing receipt and no terminal acceptance. |
| Partial9-byte header or partial4-byte WINDOW_UPDATE payload before checkpoint or at EOF/SSLEOF | Known-tail rejection, including every split point. Unknown TLS prefix is a distinct field, never encoded as an empty known tail. |
| Legal fragmented credit frames before terminal | Exact once-only parser/accounting; frozen checkpoint unchanged; live debt decreases only by real valid refunds. |
| HEADERS/DATA/RST/SETTINGS/GOAWAY, wrong-stream WINDOW_UPDATE, invalid increment, excessive refund | Canonical rejection even if passive parser alone would tolerate a frame. |
| Exactly exhausted residual limits, then terminal probe; same setup with one positive byte instead | Terminal-only probe may complete; positive byte fails without granting new budget. Test byte, read and frame ceilings independently. |
| Repeated empty polls, WANT errors, clock equality/regression, call returns after deadline | No retry; bounded attempts; failed outcome even if eventual terminal would look valid. |
| Duplicate checkpoint/activation/finish, reentrancy, send or receive after terminal | Sticky failure; no second canonical ownership; no acceptance from an old frozen receipt. |
| Terminal with unrepaid debt | Debt retained at checkpoint and abandonment; no fabricated END_STREAM or refund. |
| Post record/output/binding mismatch, collector overflow, nonzero exit, failed reap/removal, forced cleanup | Whole native attempt fails despite a valid local terminal receipt. |

## Evidence handling, review and next implementable slice

Read-only shell queries used `cat`, `sed`, `nl`, `tail`, `jq` and `tar -xOf`; all returned exit0. No Python interpreter, restorer, runtime import, source/all40 suite, build, socket, process-under-test, SSLContext or native candidate was executed. No substantive Python metadata query occurred, so no restoration receipt was required or manufactured. This report retains the substantive query forms and their decisive outputs above:

```sh
jq -r '.[] | select(.join >= 5) | "JOIN \(.join): \(.invariant)", (.refs[] | "\(.archive) :: \(.member):\(.first_line)-\(.last_line) sha256=\(.member_sha256)\n\(.excerpt)\n")' .uwz-work/evidence/h2-streaming/combined-interface-audit/bound-matrix.json
jq -r '.[] | .refs[] | select(.member == "reference/core/wire.py" or .member == "reference/core/output_stage.py" or (.member == "source/current/test_wire_oracle.py" and .first_line == 490)) | "\(.archive) :: \(.member):\(.first_line)-\(.last_line)\n\(.excerpt)"' .uwz-work/evidence/h2-streaming/combined-interface-audit/bound-matrix.json
tar -xOf docs/implement-2-2-0/evidence/m2_h2_combined_all40/combined-all40.tar.gz reference/core/wire.py | nl -ba | sed -n '508,555p'
tar -xOf docs/implement-2-2-0/evidence/m2_h2_combined_all40/combined-all40.tar.gz reference/core/raw_observer.py | nl -ba | tail -n 135
tar -xOf docs/implement-2-2-0/evidence/m2_h2_combined_all40/combined-all40.tar.gz source/current/test_wire_oracle.py | nl -ba | sed -n '185,236p'
```

Initial broad concatenated reads and the first combined matrix query exceeded console output limits. Subsequent focused reads supplied the decisive spans; missing console portions are not claimed as preserved raw logs. This report is a contract analysis, not a new authenticated packet or repeated availability audit. Primary web references were read only; no external writes occurred.

Applied narrow skill guidance: truthful observability, minimal design, source-grounded API interpretation and adversarial reasoning. No Zig coding skills or code/test gates were activated because there is no implementation. Doubt-driven fresh independent resolution remains Root-owned; this report's adversarial cases are not a claim of independent approval. Cross-model review was skipped in this non-interactive delegated task. No subagents were spawned.

Next slice, only after Root resolves/reviews this recommendation: implement the nonterminal checkpoint and separate bounded native closing receipt with source-only doubles, preserving every ordinary poison/after-seal behavior. Fix the exact immutable receipt schema and consumer scope together. Review that small diff before releasing native provider reconstruction, runtime closure or execution. If Root instead requires complete closing-wire proof, stop this acceptance path and scope clean-TLS terminal/production work explicitly.
