# Artifact

For the native shutdown_active transport only, create an immutable nonterminal
passive-observer checkpoint after successful final collection and before the
owned signal. Activate a separate bounded closing receipt after successful
signal and the existing handler-owned canonical begin. All reads still use the
ordinary wrapped seam and existing decoder; exception poison and ordinary seal
rules remain unchanged. A real receive SSLEOFError may produce a separate
local_transport_only terminal outcome carrying unknown_internal_prefix=true,
complete_wire_proof=false and no authenticated-close or zero-discard claim;
ordinary seal must still fail. Native acceptance combines the valid pre-signal
checkpoint, exactly-once returned-byte observations, permitted known-tail/frame/
credit facts, single termination ownership, actual post-deinit facts and normal
resource cleanup; the closing receipt never certifies full closing delivery.

# Contract

The detailed candidate contract is task-5e3c-terminal-contract-report.md in this
directory, especially Order and authorization, Facts/accounting/limits, and
Seal/poison/acceptance predicates. Its justification is not acceptance evidence;
test its predicates against the exact sources cited there.

- Existing archived reference/core/raw_observer.py:64-79 literally permits
  owned_shutdown post_signal eof|tls_eof and returns kind=local_transport_only.
  Known header/frame/remaining tails must be empty. Strict disconnect retains
  successful public TLS unwrap, raw TCP EOF and zero trailing bytes.
- Ordinary observer invoke poisons/rethrows every underlying BaseException;
  first failure sticky, successful returned bytes observed, no ordinary seal
  after failure. Existing seal is terminal and cannot be reset/unsealed.
- Canonical handler alone begins/finishes termination. Coordinator counters
  freeze before teardown. Actual67 final rows/metrics/four outputs/binding
  precede signal; active postdeinit adds onecancel and clears active/paused.
- Closing successfully returned data <=8192/read, <=65536bytes, <=4096frames;
  residual case/final bytes/reads/deadlines remain conjunctive. Only length4,
  flags0, valid stream0/held-stream WINDOW_UPDATE allowed. No excess refunds,
  new requests or primary response. Retain actual abandoned debt.
- One integer monotonic caller clock; ready15/whole900/case30/180; grace<=15
  clipped by case/whole; deadline equality/expired/regression reject. No retry
  after EOF/error and no fresh budget for a terminal probe returning data.
- SSL EOF error supplies no consumed-prefix count. Discarded/unreturned bytes
  are unknown. Timeout/other SSLerror/clock/parser/postprocessing failures may
  not become accepted EOF. suppress_ragged_eofs remainsFalse; no ignoreEOF option.
- A stronger full closing-wire/zero-discard/authenticated-close requirement
  must reject the qualified tls_eof receipt; no receipt design proves it.
- No source/current45/native/product/pin edits are authorized by this design
  review. No second parser/client, bypassed returned-byte observer, cleared
  poison, globalmonkeypatch or hidden synthetic nativefacts.

Exact source members/hashes/excerpts and primary Python/OpenSSL/RFC8446 links
are named in the detailed candidate report. They are already located paths;
read only focused source clauses required to demonstrate a concrete defect.
