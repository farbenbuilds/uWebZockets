"""Verify the checkpoint's source boundary and preserve prior byte authorities."""
import ast
import hashlib
import json
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def nesting(node, depth=0):
    controls = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.With, ast.AsyncWith, ast.Try, ast.TryStar, ast.Match)
    level = depth + int(isinstance(node, controls))
    return max([level] + [nesting(child, level) for child in ast.iter_child_nodes(node)])


def source_scope():
    root = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    baseline = json.loads(Path('docs/implement-2-2-0/evidence/m2_h2_combined_all40/manifest.json').read_text())['current_source_files']
    current = {path.name: sha(path.read_bytes()) for path in root.glob('*.py')}
    changed = {'test_wire_oracle.py', 'test_imports.py'}
    if len(baseline) != 45 or len(current) != 46 or current.keys() != baseline.keys() | {'test_wire_checkpoint.py'}:
        raise ValueError('Checkpoint source inventory differs')
    if {name for name in baseline if current[name] != baseline[name]} != changed:
        raise ValueError('Checkpoint old-source change scope differs')
    depths = {}
    touched = changed | {'test_wire_checkpoint.py'}
    for path in root.glob('*.py'):
        tree = ast.parse(path.read_text())
        depths[path.name] = nesting(tree)
        if (path.name in touched and nesting(tree) > 3) or any(isinstance(node, (ast.ClassDef, ast.Assert, ast.Global, ast.Nonlocal)) for node in ast.walk(tree)):
            raise ValueError('Current source structure differs: ' + path.name)
    return root, changed, dict(source_files=current, modules=46, baseline_modules=45, old_changed=sorted(changed), added=['test_wire_checkpoint.py'], unchanged=43, nesting=depths,
                              touched_max_nesting=max(depths[name] for name in touched),
                              unchanged_over_three={name: value for name, value in depths.items() if name not in touched and value > 3})


def check_row(row):
    data = Path(row['path']).read_bytes()
    if len(data) != row['bytes'] or sha(data) != row['sha256']:
        raise ValueError('Recorded input differs: ' + row['path'])


def preserve_prior(source, changed):
    before = json.loads(Path('.uwz-work/evidence/h2-streaming/combined-interface-audit/before.json').read_text())
    if len(before['combined_files']) != 19808:
        raise ValueError('Preceding inventory identity differs')
    skipped = {str((source / name).resolve()) for name in changed}
    protected = [row for row in before['combined_files'] if str(Path(row['path']).resolve()) not in skipped]
    if len(protected) != 19806:
        raise ValueError('Authorized source exclusions differ')
    for row in protected + before['closure_rows'] + before['codec_rows'] + [before['authority']]:
        check_row(row)
    if before['identity_entries'] != 119 or len(before['closure_rows']) != 118 or len(before['codec_rows']) != 42:
        raise ValueError('Canonical closure shape differs')
    resolved = {Path(row['path']).resolve(strict=True) for row in before['closure_rows']}
    if len(resolved) != 113:
        raise ValueError('Resolved closure differs')
    return dict(prior_entries=19808, authorized_changed_source_entries=2, preceding_protected_entries=19806,
                identity_entries=119, physical_rows=118, resolved_files=113, ordered_codecs=42)


def preserve_c2():
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_native_source_preparation')
    manifest = json.loads((folder / 'manifest.json').read_text())
    archive = folder / manifest['archive']
    if manifest['archive_sha256'] != '3c6d55ddc6a9d58445d1635a79186135f230c476eaba97257685649f7481e7de' or sha(archive.read_bytes()) != manifest['archive_sha256']:
        raise ValueError('Pushed c2 authority differs')
    with tarfile.open(archive, 'r:gz') as stream:
        inventory = json.loads(stream.extractfile('INVENTORY.json').read())
    expected = {name.removeprefix('packet/'): row for name, row in inventory.items() if name.startswith('packet/')}
    expected.update({name.removeprefix('packet/'): row for name, row in manifest['external_packet_members'].items()})
    root = Path('.uwz-work/evidence/h2-streaming/native-input-preparation')
    actual = {path.relative_to(root).as_posix() for path in root.rglob('*') if path.is_file()}
    if len(expected) != 809 or actual != expected.keys():
        raise ValueError('C2 packet path inventory changed')
    for name, row in expected.items():
        data = (root / name).read_bytes()
        if len(data) != row['size'] or sha(data) != row['sha256']:
            raise ValueError('C2 retained packet bytes changed')
    return dict(files=809, whole_packet_unchanged=True)


def main(argv):
    if argv != ['--audit']:
        return
    source, changed, scope = source_scope()
    result = dict(source=scope, preservation=preserve_prior(source, changed), c2_packet=preserve_c2(),
                  native_compiled=False, native_executed=False, milestone_complete=False)
    Path('.superpowers/sdd/h2_streaming_plan/task-5e3c3-root-final-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(modules=46, old_changed=2, added=1, unchanged=43, preceding_protected_entries=19806,
                         c2_packet_files=809, touched_max_nesting=scope['touched_max_nesting'],
                         unchanged_baseline_over_three=scope['unchanged_over_three'], native_executed=False)))


if __name__ == '__main__':
    main(sys.argv[1:])
