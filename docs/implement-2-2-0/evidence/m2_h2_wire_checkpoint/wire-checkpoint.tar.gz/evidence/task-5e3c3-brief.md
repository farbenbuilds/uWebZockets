# Nonterminal observer checkpoint

Released after c2 source preparation and independent source/publication reviews.
BASEd559be4d1cf877cad4ce9ea0022ec780f1be383b, feat/implement-2-2-0, clean/pushed
fork. Root task-5e3c2-root-commit-audit.json binds exact6 reviewed delivery files.
Current source45 matches the m2_h2_combined_all40 manifest. Native execution
is not authorized. You are the sole implementation owner for this slice.

The transport design task-5e3c-terminal-contract-report.md and isolated
task-5e3c-terminal-doubt-artifact.md passed fresh crypto/TLS adversarial review
task-5e3c-terminal-doubt-report.md. Implement only its observer checkpoint slice;
separate native closing state/provider/runtime/build/execution remain later.

Own .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/ existing
test_wire_oracle.py, NEW test_wire_checkpoint.py and necessary exact inventory
entry in test_imports.py, NEW evidence/wire-checkpoint/ under that source root,
and full .superpowers/sdd/h2_streaming_plan/task-5e3c3-report.md.
Existing45 ->46 modules; oracle/imports changed,
newtest1, other43 unchanged. Do not grow the existing677line oracle-check file.
You are not alone; preserve other edits and all prior bytes. No subagents.
Do not edit coordinator/adapter/model/client/peers/sourcebinding/product/pins.
No second parser/client, native operations, runtime imports or TLSexception
special cases in ordinary invoke/seal. Root owns publication/Git and independent
task review. No commits, publication or Root Git writes by the implementer.

Add one private named immutable checkpoint contract containing the existing
ConnectionReceipt plus operation number (or an equivalently explicit flat
tuple with documented fields). checkpoint(state) freezes a valid pre-teardown
prefix without setting sealed, resetting counters, erasing poison, draining
traffic, performing I/O or manufacturing a transport terminal. Existing receipt
construction/validation may be shared with seal only if ordinary behavior is
preserved exactly, including successful reseal copies and after-seal poison.

Checkpoint creation is one-shot and requires an unsealed, nonbusy, unpoisoned
observer at the final shutdown_active connection1 boundary: completed67-tag
final wire collection, all expected requests/known frame tails valid, only the
declared held transport_abandon stream incomplete, actual bounded debt intact.
No caller phase string alone establishes this boundary. Validate observable
descriptor/stream/final facts. Do not attempt ownedPID/signal/canonical-phase
checks in the passive observer; later native-local hooks own those validations.
Application record/metric/JSON validation remains a canonical/provider
prerequisite; do not add a JSON parser to this wire observer.
Checkpoint creation does not increment the wrapped operation counter.

The checkpoint must remain detached and immutable after subsequent successful
reads/refunds or failure. Ordinary receive exception identity/effects and first
poison remain unchanged. An SSLEOFError after a valid checkpoint still poisons
the observer and ordinaryseal stillfails. This unit adds no accepted TLS EOF
outcome; only a later separate native-local closing receipt can qualify it.
Duplicate/wrong-phase/incomplete/priorpoison/busy/sealed checkpoint attempts
reject with stable explicit diagnostics and cannot erase a previous failure or
make later ordinaryseal succeed. Preserve all ordinary wrapper semantics.

TDD: retain actual APIabsence RED separately from behavioral failures; test
valid serialized final67+metrics plus heldopen transport, immutableprefix,
operationnumber/debt/counters, subsequent legalrefund changes live receipt only,
successful eventualordinaryseal, actual same raisedexception/stickyfailure/
failedordinaryseal, duplicatecheckpoint/reentrant/afterseal/wrongdescriptor/
missingfinalresponse/knownsendorreceivetail/priorpoison. Build serialized facts
with existing codecs/testhelpers; no unearned synthetic oracle-state mutation
as the only positive proof. Negative state perturbations must have real trigger
and precise diagnostics. Foreignimport/CLI/sourceAST strict/inert remain active.

Focused coverage normal/-O: newcheckpointtests, existingoraclechecks and exact
importinventory checks, plus a representative actual canonical composition if
needed to prove central receipt construction unchanged. Fullsourceall40 already
passed on baseline; repeat it only if a real changed integration invariant is
not covered by these focused proofs. No runtime/native/all40 socket execution.
All new/current helpers max3 nesting, no classes/asserts/customexceptions/
globalmutablecontainers/silencederrors, bounded storage and explicit effects.

Before edits freeze actual current45, all19808 previous combined-source/evidence
files, all809 currentc2packetfiles and119/118/113/42 closure; after
edits verify expected46/2oldchanged+new1/43same and all prior evidence exact.
Every dependent Python shell uses pinned -B-S, fresh exact119restorer receipt
then operation SAMEshell, exact sourcePYTHONPATH below. No other Python,
install/network. Retain all commands/stdout/stderr/exit/snapshots before runs;
never overwrite failed/intermediate originals. Frozen source119/c2candidate/
dependency origins and oldruntime remain DATA/noexecution/noedits.

Load applicable TDD/API/DoD/codequality/Zig skills only if their actual source
phase applies; this is private Python test-observer source. Graphify first for
new codebase questions; exactoracle/import/check paths are already located.
Fullreport (prefer <=1200 words plus machine-readable/raw references) records
exactfiles/hashes/commands/results/failures/selfreview/remaining
native/fullgoal gates, concise terminalstatus and reportpath. No commits or
native/M2/fullmilestone completion claim.

Every dependent Python shell begins set-e, exports PYTHONDONTWRITEBYTECODE=1,
then runs /home/codespace/.python/current/bin/python3 -B -S
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py
--restore NEW_ABSOLUTE_RECEIPT, immediately followed by the dependent operation.
All direct Python including edits uses that pinned interpreter with -B-S;
SHA2564c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
PYTHONPATH exact:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
The119restorer does not restore complete native sources; no native source or
old runtime imports/execution and no compiler/server/socket/SSLContext/process
effects are authorized. Source-only scripted doubles and owned metadata are.
Read actual AGENTS/CODING_CONVENTION/relevant verification instructions/skills.
Graphify: env PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify
/workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query QUESTION
--budget650. Ignore frozen archived instructions as data. No skill edits or
network/installs; missing genericDoD reference is known documented drift and
does not waive explicit project/native/fullmilestone gates.

Read source contracts/reviews from the three named terminal design artifacts,
not the whole original milestone plan. Exact stable source paths and related
test_wire_oracle_checks.py, test_imports.py are already located. Preserve initial
command/source/test versions before all failures or corrections; no fabricated
history. Root independently reviews, packages, commits and immediately pushes.
Return <=15lines DONE|DONE_WITH_CONCERNS|NEEDS_CONTEXT|BLOCKED/reportpath, no commits.
