# Nonterminal observer checkpoint

Status: **DONE — scoped implementation and focused source verification.** No
commit, publication or native execution. Root owns fresh independent review,
publication and immediate push. Native-provider/full-milestone/adoption work
remains open.

Source root **S**:
`/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases`.
New evidence root **P**: `S/evidence/wire-checkpoint/`.
Binding base: `d559be4d1cf877cad4ce9ea0022ec780f1be383b`.

## Delivered contract

`test_wire_oracle.py` adds private `CheckpointReceipt = tuple[ConnectionReceipt,
int]`: immutable connection facts followed by the current wrapped operation
number. `checkpoint(state)` validates an unpoisoned, nonbusy, unsealed,
not-previously-checkpointed observer, actual shutdown_active connection1
identity,67 tags, declared ordinal2 held transport, complete expected requests,
all68 final response terminals, clean known parser tails, only stream3
incomplete, one active stream and bounded consistent retained debt. It neither
increments operations nor performs I/O, seals, resets counters, erases poison,
refunds debt or creates a transport terminal. A successful checkpoint records
only its one-shot marker.

Existing prefix validation and immutable receipt construction are shared with
`seal`; their predicates and tuple fields are unchanged. `invoke`, receive
exception handling and first-poison logic are unchanged. A later real
`SSLEOFError` still propagates by identity, poisons the observer and prevents
ordinary sealing. Frozen prefixes survive subsequent valid refunds and failures.

Stable checkpoint diagnostics are `checkpoint_poisoned`, `checkpoint_busy`,
`checkpoint_sealed`, `checkpoint_duplicate`, `checkpoint_phase`,
`checkpoint_incomplete` and `checkpoint_debt`. Failed checkpoint attempts poison
without replacing an earlier failure. The debt diagnostic protects internal
accounting consistency; serialized tests prove actual partial/full refunds and
retained debt, without fabricating observer state.

The observer establishes wire facts only. Actual67 application records, JSON,
metrics, output/binding validation, owned PID/start/listener, signal and canonical
phase checks remain native-provider prerequisites. No new parser/client or
accepted TLS EOF outcome was added.

## Exact changed sources

| File under S | Bytes | SHA256 |
|---|---:|---|
| `test_wire_oracle.py` |27625|`895ed816ed33e52685e5814a9e6d73488a1a3de9ce2dc6adcdae576b11216a48`|
| `test_imports.py` |3933|`a417b83bdbf39e17082592f75c33b59e835eb12c792a8af358814e163aee8c45`|
| new `test_wire_checkpoint.py` |10558|`842cbd7c896a4294d0ef30f1400940518837e87175fe5c3a2011d8e4249b47ad`|

The existing677-line oracle-check file is unchanged. Inventory is now46:
2 old modules changed,1 new,43 unchanged. Other outputs are P and this report.
`P/normal2-checks.json` and `optimized-checks.json` bind exact source/helper
hashes and function nesting: maximum3, no classes/asserts/global mutable
containers. Source imports remain inert for all46 modules;12 additional foreign
import/empty/foreign CLI checks cover the new test, observer and evidence helpers.

## Commands, RED history and results

Every substantive Python run has its exact saved `P/raw/*.sh`, complete
`.stdout`, `.stderr`, `.exit`, and a fresh `*-restore.json`. Source versions were
saved under `P/snapshots/` before the relevant run/correction. Nothing was
silently overwritten or rerun under an old receipt.

Each shell starts `set -e`, exports `PYTHONDONTWRITEBYTECODE=1` and the brief's
exact five-part `PYTHONPATH`, then invokes the pinned119 restorer immediately
before dependent operations. Interpreter:
`/home/codespace/.python/current/bin/python3 -B -S`, SHA256
`4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`.
Optimized execution adds `-O`. Every restoration reports118 rows,113 resolved
files,42 ordered codecs,0 restored; declared authority remains119.

| Raw script | Actual result |
|---|---|
| `01-freeze.sh` | exit0;45 modules,19808 prior files,809 c2 packet files frozen before edits |
| `02-red-api.sh` | exit1; actual baseline `AttributeError: ... has no attribute 'checkpoint'` |
| `03-red-behavior.sh` | exit1; initial seal-based scaffold failed `RuntimeError: checkpoint sealed or poisoned` |
| `04-green1.sh` | exit0; initial serialized checkpoint suite passed |
| `05-normal.sh` | exit1; new compound main guard rejected by unchanged import gate: `missing main guard: test_wire_checkpoint` |
| `07-normal.sh` | exit0; corrected standalone guard, complete focused normal matrix |
| `06-optimized.sh` | exit0; complete focused `-O` matrix, run after07 |
| `08-graphify.sh` | exit0; AST-only update, no topology change; denied parallel extraction fell back to sequential |
| `09-preservation.sh` | exit0;46 modules,19809 prior-root files,809 c2 files |
| `10-summary.sh` | retained baseline-authority comparison and final machine summary |

The focused matrix's exact dependent commands are the pinned interpreter with:

```text
S/test_wire_checkpoint.py --check
S/test_wire_oracle_checks.py
S/test_imports.py
P/verify.py --check P/<mode>-checks.json
-c "import test_all40; test_all40.check_composition(('shutdown_active',))"
```

Eight new groups prove the serialized141-operation prefix (72 sends,69 receives),
67 status responses plus metrics, held32/32 debt, detached immutable receipts,
fragmented refunds, eventual ordinary reseal, actual SSL EOF/ordinary error
identity and effects, sticky failures, duplicate/busy/sealed/wrong-phase/missing
final response/incomplete upload rejection, and all24 partial WINDOW_UPDATE
header/payload splits in both directions. Actual canonical source composition
also passes with its71 requests,68 final responses and32/32 held debt. Full
all40 was not repeated: focused existing oracle proofs plus this composition
cover the shared validation/receipt extraction.

## Preservation, self-review and limits

`preservation-before.json` freezes all19808 prior paths/bytes/hashes and all809
c2 packet files. `preservation-after.json` verifies exactly the authorized2 old
source changes plus1 new source; every other prior file and all809 packet files
match. `summary.json` binds baseline45 against the published all40 manifest,
final sources, raw outcomes and closure receipts.

Self-review found no changed wrapper effect ordering, exception conversion,
seal/reseal semantics, parser policy or canonical ownership. No gate was
weakened. Focused tests use pinned codecs and caller-owned scripted operations;
no clocks, sockets, SSLContext, native/runtime imports, compiler or process under
test ran. Frozen candidate/dependency sources remained data.

Initial context-only shell reads and the graphify query are retained in the
conversation tool transcript, not independent raw files; some broad console
reads were truncated. The implementation/test/failure/preservation records
above have complete durable raw files. No missing historical output is claimed.

The full Zig/sanitizer/fuzz/protocol/package/platform matrix was not run: this
release expressly authorizes source-only Python observer work. No production,
public exports, build metadata or dependency pin changed. A separate reviewed
native closing receipt, native provider/runtime reconstruction and real native
validation remain required before any native/M2/full-milestone completion claim.
