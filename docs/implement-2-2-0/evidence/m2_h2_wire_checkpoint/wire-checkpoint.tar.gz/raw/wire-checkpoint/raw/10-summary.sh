set -e
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/wire-checkpoint/raw/10-restore.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
import hashlib
import json
from pathlib import Path


def main():
    root = Path('/workspaces/uWebZockets')
    source = root / '.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'
    evidence = source / 'evidence/wire-checkpoint'
    before = json.loads((evidence / 'preservation-before.json').read_text())
    after = json.loads((evidence / 'preservation-after.json').read_text())
    authority = root / 'docs/implement-2-2-0/evidence/m2_h2_combined_all40/manifest.json'
    expected = json.loads(authority.read_text())['current_source_files']
    actual = {Path(key).name: value[1] for key, value in before['source'].items()}
    if actual != expected or len(actual) != 45:
        raise ValueError('baseline source differs from all40 manifest')
    for key, value in after['source'].items():
        data = Path(key).read_bytes()
        if [len(data), hashlib.sha256(data).hexdigest()] != value:
            raise ValueError('final source changed after preservation audit')
    commands = {path.name: int(path.read_text()) for path in sorted((evidence / 'raw').glob('*.exit'))}
    restorations = {path.name: json.loads(path.read_text()) for path in sorted((evidence / 'raw').glob('*-restore.json'))}
    for receipt in restorations.values():
        if (receipt['authority_entries'], receipt['physical_rows_checked'], receipt['unique_resolved_files'], receipt['ordered_codec_files_checked']) != (119, 118, 113, 42):
            raise ValueError('closure count differs')
    normal = (evidence / 'raw/07-normal.stdout').read_text().splitlines()[-1]
    optimized = (evidence / 'raw/06-optimized.stdout').read_text().splitlines()[-1]
    if normal != optimized:
        raise ValueError('canonical composition mode results differ')
    result = dict(status='DONE', source_count=46, changed_old=2, added=1, unchanged_old=43,
                  baseline45_matches_all40_manifest=True, authority_sha256=hashlib.sha256(authority.read_bytes()).hexdigest(),
                  final_source=after['source'], prior_files_checked=19808, packet_files_unchanged=809,
                  commands=commands, restorations=restorations, canonical_mode_results_identical=True,
                  native_executed=False, milestone_complete=False, full_all40_repeated=False,
                  report_sha256=hashlib.sha256((root / '.superpowers/sdd/h2_streaming_plan/task-5e3c3-report.md').read_bytes()).hexdigest())
    with (evidence / 'summary.json').open('x') as output:
        json.dump(result, output, indent=2)
        output.write('\n')
    print('DONE: baseline45 authenticated; final46 = 2 changed + 1 new + 43 unchanged; 19808 prior files/809 c2 files checked; canonical normal/-O identical')


main()
PY
