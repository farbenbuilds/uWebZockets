set -e
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/wire-checkpoint/raw/04-restore.json
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_wire_checkpoint.py
