"""Owned metadata effects; frozen inputs are read only."""
import hashlib
import json
import pathlib
import sys


def inventory(root, excluded=None):
    result = {}
    for path in sorted(root.rglob('*')):
        if excluded is not None and path.is_relative_to(excluded):
            continue
        if path.is_file():
            data = path.read_bytes()
            result[str(path)] = (len(data), hashlib.sha256(data).hexdigest())
    return result


def check(condition, message):
    if not condition:
        raise ValueError(message)


def main(mode):
    evidence = pathlib.Path(__file__).resolve().parent
    source = evidence.parent.parent
    prior = inventory(source, evidence)
    packet = inventory(source.parents[1] / 'native-input-preparation')
    current = {key: value for key, value in prior.items() if pathlib.Path(key).parent == source}
    destination = evidence / ('preservation-' + mode + '.json')
    if mode == 'before':
        check(len(prior) == 19808 and len(packet) == 809 and len(current) == 45, 'initial counts')
        result = dict(prior=prior, packet=packet, source=current)
    else:
        before = json.loads((evidence / 'preservation-before.json').read_text())
        changed = [key for key, value in before['prior'].items() if prior.get(key) != tuple(value)]
        added = sorted(set(prior) - set(before['prior']))
        check(sorted(pathlib.Path(key).name for key in changed) == ['test_imports.py', 'test_wire_oracle.py'], 'prior changed')
        check([pathlib.Path(key).name for key in added] == ['test_wire_checkpoint.py'], 'unexpected additions')
        check(packet == {key: tuple(value) for key, value in before['packet'].items()}, 'c2 packet changed')
        check(len(current) == 46, 'source count')
        result = dict(changed=changed, added=added, unchanged_source=43, prior_files_checked=len(before['prior']), packet_files_checked=len(packet), source=current)
    with destination.open('x') as output:
        json.dump(result, output, indent=2)
        output.write('\n')
    print(mode, 'prior files', len(prior), 'packet files', len(packet), 'source modules', len(current))


if __name__ == '__main__' and len(sys.argv) == 2 and sys.argv[1] in ('before', 'after'):
    main(sys.argv[1])
