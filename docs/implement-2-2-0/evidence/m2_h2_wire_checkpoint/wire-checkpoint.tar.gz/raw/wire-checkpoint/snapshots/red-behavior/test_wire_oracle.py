"""Private passive wire facts. Call seal only after caller-owned hooks finish.

Tuples are immutable contracts; dictionaries are explicit caller-owned state.
The pinned codecs are shared primitives, not an independent codec proof.
"""
import hashlib
from functools import partial
import hpack
from hpack.hpack import decode_integer
from hpack import huffman_table
from hyperframe.frame import Frame

# child, case, connection_index
ConnectionIdentity = tuple[int, str, int]
# logical_bytes, flow_bytes, sha256
PayloadExpectation = tuple[int, int, bytes]
# method, target, request_end, request_payload, response_role, terminal,
# final_status, informationals, response_payload
RequestExpectation = tuple[str, str, str, PayloadExpectation, str, str, int | None, tuple[int, ...], PayloadExpectation | None]
# identity, ordinary, final_tags
ConnectionDescriptor = tuple[ConnectionIdentity, tuple[RequestExpectation, ...], tuple[str, ...]]
# code, direction, operation, wire_offset, stream_id
FailureReceipt = tuple[str, str, int, int, int | None]
# frames, bytes, late_closed_frames, late_closed_bytes
CreditReceipt = tuple[int, int, int, int]
# calls, wire_bytes, frames, initial_heads, trailers, data_frames, logical_bytes,
# flow_bytes, padding_bytes, settings, acks, resets, connection_credit, stream_credit
DirectionReceipt = tuple[int, int, int, int, int, int, int, int, int, int, int, tuple[tuple[int, int], ...], CreditReceipt, CreditReceipt]
# ordinal, stream_id, role, request_bytes, request_flow, request_sha256,
# response_bytes, response_flow, response_sha256, request_end, response_end,
# incoming_reset, outgoing_reset, request_stream_debt, terminal_complete
StreamReceipt = tuple[int, int, str, int, int, bytes, int, int, bytes, bool, bool, int | None, int | None, int, bool]
# identity, started, sent, received, informationals, small_ends, small_complete,
# output_ends, final_requests, final_responses, final_collections,
# request_connection_debt, request_stream_debt_total, transport_incomplete, streams
ConnectionReceipt = tuple[ConnectionIdentity, bool, DirectionReceipt, DirectionReceipt, int, int, int, int, int, int, int, int, int, tuple[int, ...], tuple[StreamReceipt, ...]]
# connection facts at the prefix boundary, wrapped operation number
CheckpointReceipt = tuple[ConnectionReceipt, int]
Connection = dict
ObserverState = dict
U64 = (1 << 64) - 1
PREFACE = b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n'
COUNTERS = ('calls', 'wire_bytes', 'frames', 'initial_heads', 'trailers', 'data_frames',
            'logical_bytes', 'flow_bytes', 'padding_bytes', 'settings', 'acks')


def require(condition, code):
    if not condition:
        raise ValueError(code)


def unsigned(value):
    return type(value) is int and 0 <= value <= U64


def bounded_text(value):
    return type(value) is str and 0 < len(value) <= 4096 and value.isascii() and all(32 <= ord(c) < 127 for c in value)


def validate_payload(value):
    require(type(value) is tuple and len(value) == 3, 'descriptor')
    logical, flow, digest = value
    require(unsigned(logical) and unsigned(flow) and logical <= flow and type(digest) is bytes and len(digest) == 32, 'descriptor')


def validate_request(item):
    require(type(item) is tuple and len(item) == 9, 'descriptor')
    method, target, end, body, role, terminal, status, info, response = item
    require(method in ('GET', 'POST') and bounded_text(target) and target.startswith('/'), 'descriptor')
    require(end in ('headers', 'data', 'trailers', 'open'), 'descriptor')
    validate_payload(body)
    require(end != 'headers' or body[:2] == (0, 0), 'descriptor')
    require(type(info) is tuple and info in ((), (100,)) and all(type(value) is int for value in info), 'descriptor')
    require(role in ('small', 'output', 'reset', 'transport'), 'descriptor')
    if role in ('reset', 'transport'):
        require(status is None and info == () and response is None, 'descriptor')
        allowed = ('transport_abandon',) if role == 'transport' else ('incoming_reset_8', 'incoming_reset_2', 'outgoing_reset_8')
        require(terminal in allowed and (role != 'transport' or end == 'open'), 'descriptor')
        return
    require(type(status) is int and 200 <= status <= 599 and terminal in ('end', 'end_reset_0'), 'descriptor')
    require(role != 'output' or response is not None, 'descriptor')
    if response is not None:
        validate_payload(response)
        require(role != 'small' or response[0] <= 4095, 'descriptor')


def validate_descriptor(descriptor):
    require(type(descriptor) is tuple and len(descriptor) == 3, 'descriptor')
    identity, ordinary, tags = descriptor
    require(type(identity) is tuple and len(identity) == 3, 'descriptor')
    child, case, index = identity
    require(unsigned(child) and bounded_text(case) and unsigned(index) and index > 0, 'descriptor')
    require(type(ordinary) is tuple and type(tags) is tuple and len(tags) in (0, 67), 'descriptor')
    require(0 < len(ordinary) + (68 if tags else 0) <= 802, 'descriptor')
    require(all(bounded_text(tag) and len(tag) <= 4088 and '/' not in tag for tag in tags), 'descriptor')
    require(len(set(tags)) == len(tags), 'descriptor')
    for ordinal, item in enumerate(ordinary, 1):
        validate_request(item)
        if item[4] == 'transport':
            require(index == 1 and case in ('disconnect', 'shutdown_active') and ordinal == 2, 'descriptor')
            require(item[0] == 'POST' and item[1] == '/limit/' + case + '?case=' + case, 'descriptor')
    require(not (case == 'disconnect' and index == 1 and tags), 'descriptor')


def direction_state():
    result = dict.fromkeys(COUNTERS, 0)
    result.update(buffer=bytearray(), offset=0, decoder=hpack.Decoder(max_header_list_size=4096),
                  resets={}, connection_credit=[0, 0, 0, 0], stream_credit=[0, 0, 0, 0])
    return result


def wrap_connection(connection: Connection, descriptor: ConnectionDescriptor) -> tuple[Connection, ObserverState]:
    """Validate pre-effect, then interpose only on the full-send/receive seam."""
    validate_descriptor(descriptor)
    require(type(connection) is dict and set(connection) == {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'}, 'connection_shape')
    require(callable(connection['send']) and callable(connection['receive']), 'connection_shape')
    state = dict(descriptor=descriptor, failure=None, sealed=False, busy=False, operation=0,
                 send=direction_state(), receive=direction_state(), preface=0, streams={}, active=0,
                 informationals=0, small_ends=0, small_complete=0, output_ends=0,
                 final_requests=0, final_responses=0, request_connection_debt=0, request_stream_debt_total=0,
                 current_stream=None)
    wrapped = dict(connection)
    wrapped['send'] = partial(invoke, state, 'send', connection['send'])
    wrapped['receive'] = partial(invoke, state, 'receive', connection['receive'])
    return wrapped, state


def failure(state: ObserverState) -> FailureReceipt | None:
    return state['failure']


def poison(state, code, direction, stream=None):
    if state['failure'] is None:
        offset = state[direction]['offset'] if direction != 'none' else 0
        state['failure'] = (code, direction, state['operation'], offset, state['current_stream'] if stream is None else stream)


def increment(values, key, amount=1):
    require(unsigned(amount) and unsigned(values[key]) and values[key] <= U64 - amount, 'bound')
    values[key] += amount


def invoke(state, direction, original, *args, **kwargs):
    """Original effects win; unknown consumed prefixes make later proof impossible."""
    if state['failure'] is not None:
        return original(*args, **kwargs)
    nested, sealed = state['busy'], state['sealed']
    overflow = state['operation'] == U64
    state['busy'] = True
    state['operation'] = min(U64, state['operation'] + 1)
    try:
        result = original(*args, **kwargs)
    except BaseException:
        poison(state, direction + '_exception', direction)
        raise
    finally:
        state['busy'] = nested
    if nested or sealed:
        poison(state, 'reentrant' if nested else 'after_seal', direction)
    if overflow:
        poison(state, 'bound', direction)
    if state['failure'] is not None:
        return result
    observe_success(state, direction, args, kwargs, result)
    return result


def observe_success(state, direction, args, kwargs, result):
    try:
        increment(state[direction], 'calls')
        if direction == 'send':
            require(result is None, 'ambiguous_send')
            require(len(args) == 1 and not kwargs and type(args[0]) is bytes, 'frame')
            data = args[0]
        else:
            require(type(result) is tuple and len(result) == 2 and type(result[0]) is bytes, 'receive_shape')
            data = result[0]
        increment(state[direction], 'wire_bytes', len(data))
        feed(state, direction, data)
    except ValueError as error:
        code = error.args[0] if len(error.args) == 1 else 'internal'
        allowed = ('ambiguous_send', 'receive_shape', 'bound', 'frame', 'hpack', 'request_identity', 'settings', 'payload', 'credit', 'terminal', 'final_order')
        poison(state, code if code in allowed else 'internal', direction)
    except BaseException:
        # Observer errors never replace a successfully returned boundary value.
        poison(state, 'internal', direction)


def feed(state, direction, data):
    cursor = 0
    values = state[direction]
    if direction == 'send' and state['preface'] < len(PREFACE):
        count = min(len(data), len(PREFACE) - state['preface'])
        require(data[:count] == PREFACE[state['preface']:state['preface'] + count], 'frame')
        state['preface'] += count
        values['offset'] += count
        cursor = count
    buffer = values['buffer']
    while cursor < len(data):
        size = 9 if len(buffer) < 9 else 9 + int.from_bytes(buffer[:3], 'big')
        require(size <= 8201, 'bound')
        count = min(size - len(buffer), len(data) - cursor)
        buffer.extend(memoryview(data)[cursor:cursor + count])
        cursor += count
        if len(buffer) >= 9:
            require(int.from_bytes(buffer[:3], 'big') <= 8192, 'bound')
        if len(buffer) == 9 + int.from_bytes(buffer[:3], 'big') and len(buffer) >= 9:
            consume_frame(state, direction, bytes(buffer))
            values['offset'] += len(buffer)
            buffer.clear()


def consume_frame(state, direction, packet):
    state['current_stream'] = int.from_bytes(packet[5:9], 'big') & 0x7fffffff
    try:
        frame, length = Frame.parse_frame_header(memoryview(packet[:9]))
        frame.parse_body(memoryview(packet[9:]))
    except Exception:
        raise ValueError('frame') from None
    require(length == len(packet) - 9, 'frame')
    increment(state[direction], 'frames')
    match frame.type:
        case 4:
            settings(state, direction, frame, packet)
        case 1:
            headers(state, direction, frame)
        case 0:
            data_frame(state, direction, frame, length)
        case 3:
            reset_frame(state, direction, frame)
        case 8:
            credit_frame(state, direction, frame)
        case 5 | 9:
            raise ValueError('frame')
    state['current_stream'] = None


def settings(state, direction, frame, packet):
    require(frame.stream_id == 0, 'settings')
    if 'ACK' in frame.flags:
        require(len(packet) == 9, 'settings')
        increment(state[direction], 'acks')
        return
    for key, value in frame.settings.items():
        require(key != 1 or value <= 4096, 'settings')
        require(key != 2 or value <= 1, 'settings')
        require(key != 4 or value <= 0x7fffffff, 'settings')
        require(key != 5 or 16384 <= value <= 16777215, 'settings')
    increment(state[direction], 'settings')


def decode_headers(state, direction, frame):
    require('END_HEADERS' in frame.flags and frame.stream_id > 0, 'frame')
    require(len(frame.data) <= 4096, 'bound')
    try:
        entries = bounded_header_decode(state[direction]['decoder'], frame.data)
    except Exception:
        raise ValueError('hpack') from None
    require(sum(len(key) + len(value) + 32 for key, value in entries) <= 4096, 'bound')
    require(state[direction]['decoder'].header_table_size <= 4096, 'bound')
    seen = set()
    regular = False
    for key, value in entries:
        require(key and key.lower() == key and b'\0' not in value and b'\r' not in value and b'\n' not in value, 'frame')
        if key.startswith(b':'):
            require(not regular and key not in seen, 'request_identity')
            seen.add(key)
        else:
            regular = True
    return entries


def huffman_length(data, budget):
    """Count pinned DFA emissions without allocating a decoded string."""
    if not data:
        return 0
    state, flags, count = 0, 0, 0
    for byte in data:
        for nibble in (byte >> 4, byte & 15):
            state, flags, unused = huffman_table.HUFFMAN_TABLE[state * 16 + nibble]
            require(not flags & huffman_table.HUFFMAN_FAIL, 'hpack')
            count += int(bool(flags & huffman_table.HUFFMAN_EMIT_SYMBOL))
            require(count <= budget, 'hpack')
    require(flags & huffman_table.HUFFMAN_COMPLETE, 'hpack')
    return count


def string_span(data, cursor, budget):
    require(budget >= 0 and cursor < len(data), 'hpack')
    length, consumed = decode_integer(data[cursor:], 7)
    start, end = cursor + consumed, cursor + consumed + length
    require(end <= len(data), 'hpack')
    decoded = huffman_length(data[start:end], budget) if data[cursor] & 128 else length
    require(decoded <= budget, 'hpack')
    return decoded, end


def field_span(decoder, data, cursor, budget):
    """Preflight one representation against the remaining section budget."""
    require(budget >= 32, 'hpack')
    current = data[cursor]
    if current & 128:
        index, consumed = decode_integer(data[cursor:], 7)
        name, value = decoder.header_table.get_by_index(index)
        cost = len(name) + len(value) + 32
        require(cost <= budget, 'hpack')
        return cursor + consumed, cost
    index, consumed = decode_integer(data[cursor:], 6 if current & 64 else 4)
    cursor += consumed
    if index:
        name_length = len(decoder.header_table.get_by_index(index)[0])
    else:
        name_length, cursor = string_span(data, cursor, budget - 32)
    value_length, cursor = string_span(data, cursor, budget - 32 - name_length)
    return cursor, 32 + name_length + value_length


def bounded_header_decode(decoder, data):
    """Pinned codec owns decoding/table mutation; preflight owns growth limits."""
    entries = []
    cursor, decoded_size = 0, 0
    view = memoryview(data)
    while cursor < len(data):
        update = data[cursor] & 224 == 32
        if update:
            require(not entries, 'hpack')
            unused, consumed = decode_integer(view[cursor:], 5)
            end, cost = cursor + consumed, 0
        else:
            end, cost = field_span(decoder, view, cursor, 4096 - decoded_size)
        fields = tuple(decoder.decode(data[cursor:end], raw=True))
        require(len(fields) == (0 if update else 1), 'hpack')
        require(sum(len(key) + len(value) + 32 for key, value in fields) == cost, 'hpack')
        entries.extend(fields)
        decoded_size += cost
        cursor = end
    return tuple(entries)


def expected_request(state, ordinal):
    ordinary, tags = state['descriptor'][1:]
    if ordinal <= len(ordinary):
        return ordinary[ordinal - 1]
    index = ordinal - len(ordinary) - 1
    require(tags and index < 68, 'request_identity')
    target = '/status/' + tags[index] if index < 67 else '/metrics'
    return ('GET', target, 'headers', (0, 0, hashlib.sha256(b'').digest()), 'small', 'end', 200, (), None)


def new_stream(state, stream_id, entries, ended):
    ordinal = len(state['streams']) + 1
    require(ordinal <= 802 and state['active'] < 8, 'bound')
    require(stream_id == ordinal * 2 - 1, 'request_identity')
    expected = expected_request(state, ordinal)
    values = dict(entries)
    pseudo = tuple(key for key, value in entries if key.startswith(b':'))
    require(set(pseudo) == {b':method', b':scheme', b':authority', b':path'}, 'request_identity')
    require(values[b':method'] == expected[0].encode() and values[b':path'] == expected[1].encode(), 'request_identity')
    require(ended == (expected[2] == 'headers'), 'terminal')
    if ordinal > len(state['descriptor'][1]):
        require(all(ready_for_final(item) for item in state['streams'].values() if not item['final']), 'final_order')
        increment(state, 'final_requests')
    item = dict(ordinal=ordinal, stream_id=stream_id, expected=expected, final=ordinal > len(state['descriptor'][1]),
                request_bytes=0, request_flow=0, request_hash=hashlib.sha256(), response_bytes=0, response_flow=0,
                response_hash=hashlib.sha256(), request_end=ended, response_end=False, status=None, info=0,
                incoming_reset=None, outgoing_reset=None, debt=0, complete=False, request_trailers=False, response_trailers=False)
    state['streams'][stream_id] = item
    increment(state, 'active')
    increment(state['send'], 'initial_heads')


def headers(state, direction, frame):
    entries = decode_headers(state, direction, frame)
    stream = state['streams'].get(frame.stream_id)
    ended = 'END_STREAM' in frame.flags
    if direction == 'send' and stream is None:
        new_stream(state, frame.stream_id, entries, ended)
        return
    require(stream is not None and not stream['complete'], 'terminal')
    if direction == 'receive' and stream['status'] is None:
        response_head(state, stream, entries, ended)
        return
    require(not any(key.startswith(b':') for key, value in entries) and ended, 'terminal')
    prefix = 'request' if direction == 'send' else 'response'
    require(not stream[prefix + '_end'] and not stream[prefix + '_trailers'], 'terminal')
    require(direction != 'send' or stream['expected'][2] == 'trailers', 'terminal')
    stream[prefix + '_trailers'] = True
    increment(state[direction], 'trailers')
    mark_end(state, stream, direction)


def response_head(state, stream, entries, ended):
    expected = stream['expected']
    require(expected[4] in ('small', 'output'), 'terminal')
    pseudo = tuple((key, value) for key, value in entries if key.startswith(b':'))
    require(len(pseudo) == 1 and pseudo[0][0] == b':status', 'terminal')
    raw = pseudo[0][1]
    require(len(raw) == 3 and raw.isdigit(), 'terminal')
    status = int(raw)
    if status < 200:
        require(not ended and stream['info'] < len(expected[7]) and status == expected[7][stream['info']], 'terminal')
        increment(stream, 'info')
        increment(state, 'informationals')
        return
    require(status == expected[6] and stream['info'] == len(expected[7]), 'terminal')
    stream['status'] = status
    increment(state['receive'], 'initial_heads')
    if ended:
        mark_end(state, stream, 'receive')


def payload_matches(item, prefix, expected):
    return (item[prefix + '_bytes'], item[prefix + '_flow'], item[prefix + '_hash'].digest()) == expected


def request_matches(item):
    expected = item['expected']
    return payload_matches(item, 'request', expected[3]) and item['request_end'] == (expected[2] != 'open')


def ready_for_final(item):
    return request_matches(item) and (item['complete'] or item['expected'][5] == 'transport_abandon')


def data_frame(state, direction, frame, length):
    item = state['streams'].get(frame.stream_id)
    require(item is not None and not item['complete'], 'terminal')
    prefix = 'request' if direction == 'send' else 'response'
    require(not item[prefix + '_end'], 'terminal')
    require(direction != 'receive' or item['status'] is not None, 'terminal')
    body = frame.data
    expected = item['expected'][3 if direction == 'send' else 8]
    limit = expected[0] if expected is not None else 4095
    require(item[prefix + '_bytes'] <= limit - len(body), 'payload')
    increment(item, prefix + '_bytes', len(body))
    increment(item, prefix + '_flow', length)
    item[prefix + '_hash'].update(body)
    values = state[direction]
    increment(values, 'data_frames')
    increment(values, 'logical_bytes', len(body))
    increment(values, 'flow_bytes', length)
    increment(values, 'padding_bytes', length - len(body))
    if direction == 'send':
        increment(state, 'request_stream_debt_total', length)
        increment(item, 'debt', length)
        increment(state, 'request_connection_debt', length)
    if 'END_STREAM' in frame.flags:
        require(direction != 'send' or item['expected'][2] == 'data', 'terminal')
        mark_end(state, item, direction)


def mark_end(state, item, direction):
    prefix = 'request' if direction == 'send' else 'response'
    require(not item[prefix + '_end'], 'terminal')
    item[prefix + '_end'] = True
    expected = item['expected'][3 if direction == 'send' else 8]
    require(expected is None or payload_matches(item, prefix, expected), 'payload')
    if direction == 'send':
        return
    increment(state, 'small_ends' if item['expected'][4] == 'small' else 'output_ends')
    if item['expected'][5] == 'end':
        complete(state, item)


def complete(state, item):
    require(not item['complete'], 'terminal')
    if item['final']:
        require(item['ordinal'] == len(state['descriptor'][1]) + state['final_responses'] + 1, 'final_order')
        increment(state, 'final_responses')
    item['complete'] = True
    state['active'] -= 1
    if item['expected'][4] == 'small':
        increment(state, 'small_complete')


def reset_frame(state, direction, frame):
    item = state['streams'].get(frame.stream_id)
    require(item is not None and not item['complete'], 'terminal')
    key = 'incoming_reset' if direction == 'receive' else 'outgoing_reset'
    require(item[key] is None, 'terminal')
    terminal = item['expected'][5]
    expected = ('receive', 0) if terminal == 'end_reset_0' else (('send', 8) if terminal == 'outgoing_reset_8' else ('receive', 8 if terminal == 'incoming_reset_8' else 2))
    require(terminal in ('end_reset_0', 'incoming_reset_8', 'incoming_reset_2', 'outgoing_reset_8') and (direction, frame.error_code) == expected, 'terminal')
    require(terminal != 'end_reset_0' or item['response_end'], 'terminal')
    item[key] = frame.error_code
    counts = state[direction]['resets']
    counts.setdefault(frame.error_code, 0)
    increment(counts, frame.error_code)
    complete(state, item)


def credit_frame(state, direction, frame):
    amount = frame.window_increment
    require(0 < amount <= 0x7fffffff, 'credit')
    item = state['streams'].get(frame.stream_id)
    require(frame.stream_id == 0 or item is not None, 'credit')
    values = state[direction]['stream_credit' if item is not None else 'connection_credit']
    increment(values, 0)
    increment(values, 1, amount)
    if item is not None and item['complete']:
        increment(values, 2)
        increment(values, 3, amount)
    if direction == 'receive':
        if item is None:
            state['request_connection_debt'] = max(0, state['request_connection_debt'] - amount)
        else:
            state['request_stream_debt_total'] -= min(item['debt'], amount)
            item['debt'] = max(0, item['debt'] - amount)


def direction_receipt(values):
    return tuple(values[key] for key in COUNTERS) + (tuple(sorted(values['resets'].items())), tuple(values['connection_credit']), tuple(values['stream_credit']))


def stream_receipt(item):
    return (item['ordinal'], item['stream_id'], item['expected'][4], item['request_bytes'], item['request_flow'], item['request_hash'].digest(),
            item['response_bytes'], item['response_flow'], item['response_hash'].digest(), item['request_end'], item['response_end'],
            item['incoming_reset'], item['outgoing_reset'], item['debt'], item['complete'])


def checkpoint(state: ObserverState) -> CheckpointReceipt:
    return (seal(state), state['operation'])


def seal(state: ObserverState) -> ConnectionReceipt:
    """Freeze facts without draining traffic or manufacturing transport terminals."""
    if state['busy']:
        poison(state, 'reentrant', 'none')
    ordinary, tags = state['descriptor'][1:]
    expected_count = len(ordinary) + (68 if tags else 0)
    valid = (state['preface'] == len(PREFACE) and not state['send']['buffer'] and not state['receive']['buffer'] and
             len(state['streams']) == expected_count and all(ready_for_final(item) for item in state['streams'].values()) and
             state['final_requests'] == state['final_responses'] == (68 if tags else 0))
    if not valid:
        poison(state, 'incomplete', 'none')
    if state['failure'] is not None:
        raise ValueError('oracle_unsealed')
    state['sealed'] = True
    streams = tuple(stream_receipt(item) for item in state['streams'].values())
    debt = state['request_stream_debt_total']
    incomplete = tuple(item['stream_id'] for item in state['streams'].values() if not item['complete'])
    return (state['descriptor'][0], True, direction_receipt(state['send']), direction_receipt(state['receive']),
            state['informationals'], state['small_ends'], state['small_complete'], state['output_ends'],
            state['final_requests'], state['final_responses'], int(bool(tags)), state['request_connection_debt'], debt, incomplete, streams)


if __name__ == '__main__':
    pass
