"""Strict owned-source and inert foreign import/CLI verification."""
import ast
import contextlib
import hashlib
import io
import json
import pathlib
import sys
from unittest import mock
import builtins
import os
import socket
import ssl
import subprocess
import time
import test_wire_checkpoint
import test_imports


def require(condition, message):
    if not condition:
        raise ValueError(message)


def nesting(node, depth=0):
    controls = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.Try, ast.With, ast.AsyncWith, ast.Match)
    depth += int(isinstance(node, controls))
    return max((nesting(child, depth) for child in ast.iter_child_nodes(node)), default=depth)


def strict_source(path):
    data = path.read_bytes()
    tree = ast.parse(data, filename=str(path))
    require(not any(isinstance(node, (ast.ClassDef, ast.Assert)) for node in ast.walk(tree)), 'class/assert: ' + str(path))
    for node in tree.body:
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            require(not isinstance(node.value, (ast.List, ast.Dict, ast.Set, ast.ListComp, ast.DictComp, ast.SetComp)), 'global mutable container')
    functions = [node for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
    depths = {node.name: max((nesting(child) for child in node.body), default=0) for node in functions}
    require(all(value <= 3 for value in depths.values()), 'nesting exceeds3: ' + repr(depths))
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), function_nesting=depths)


def forbidden(*args, **kwargs):
    raise RuntimeError('inert source invoked an effect')


def inert(code, name, argv):
    effects = ((builtins, 'open'), (os, 'open'), (os, 'write'), (os, 'system'), (os, 'popen'),
               (socket, 'socket'), (socket, 'socketpair'), (socket, 'create_connection'), (socket, 'create_server'),
               (ssl, 'SSLContext'), (subprocess, 'Popen'), (subprocess, 'run'), (subprocess, 'call'),
               (subprocess, 'check_call'), (subprocess, 'check_output'), (time, 'time'), (time, 'monotonic'),
               (time, 'perf_counter'), (time, 'sleep'))
    output, error = io.StringIO(), io.StringIO()
    with contextlib.ExitStack() as stack:
        for module, key in effects:
            stack.enter_context(mock.patch.object(module, key, forbidden))
        stack.enter_context(mock.patch.object(sys, 'argv', argv))
        stack.enter_context(contextlib.redirect_stdout(output))
        stack.enter_context(contextlib.redirect_stderr(error))
        exec(code, dict(__name__=name, __file__=code.co_filename))
    require(not output.getvalue() and not error.getvalue(), 'inert source wrote output')


def main(destination):
    evidence = pathlib.Path(__file__).resolve().parent
    source = evidence.parent.parent
    paths = tuple(source / name for name in ('test_wire_oracle.py', 'test_imports.py', 'test_wire_checkpoint.py'))
    paths += (evidence / 'audit.py', evidence / 'verify.py')
    rows = {str(path): strict_source(path) for path in paths}
    for path in (paths[0], paths[2], paths[3], paths[4]):
        code = compile(path.read_bytes(), str(path), 'exec')
        for name, argv in (('foreign_checkpoint', []), ('__main__', []), ('__main__', ['foreign', '--run', 'unexpected'])):
            inert(code, name, argv)
    result = dict(source=rows, inert_cases=12, optimized=bool(sys.flags.optimize), passed=True)
    with destination.open('x') as output:
        json.dump(result, output, indent=2)
        output.write('\n')
    print('strict AST/nesting and12 foreign import/empty/foreign CLI checks passed')


if __name__ == '__main__' and len(sys.argv) == 3 and sys.argv[1] == '--check':
    main(pathlib.Path(sys.argv[2]))
