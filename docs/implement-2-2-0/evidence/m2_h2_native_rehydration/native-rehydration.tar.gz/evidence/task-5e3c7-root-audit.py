"""Independently audit source exports without executing the new materializer."""
import ast
import difflib
import hashlib
import json
import stat
import subprocess
import sys
import tarfile
from pathlib import Path


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load_archive(folder, filename, digest):
    path = Path('docs/implement-2-2-0/evidence') / folder / filename
    require(sha(path.read_bytes()) == digest, 'Published archive identity: ' + filename)
    with tarfile.open(path, 'r:gz') as stream:
        return {member.name: stream.extractfile(member).read() for member in stream if member.isfile()}


def nesting(node, depth=0):
    controls = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.With,
                ast.AsyncWith, ast.Try, ast.TryStar, ast.Match)
    level = depth + int(isinstance(node, controls))
    return max([level] + [nesting(child, level) for child in ast.iter_child_nodes(node)])


def actual_export(root, expected, count, size):
    files, directories = {}, set()
    for path in [root, *root.rglob('*')]:
        mode = path.lstat().st_mode
        name = path.relative_to(root).as_posix()
        if stat.S_ISDIR(mode):
            require(stat.S_IMODE(mode) == 0o555, 'Export directory mode: ' + name)
            directories.add(name)
        else:
            require(stat.S_ISREG(mode) and stat.S_IMODE(mode) == 0o444, 'Export file type/mode: ' + name)
            data = path.read_bytes()
            files[name] = dict(bytes=len(data), sha256=sha(data))
    require(set(files) == set(expected) and len(files) == count, 'Export file inventory')
    inferred = {'.'} | {parent.as_posix() for name in expected for parent in Path(name).parents if parent != Path('.')}
    require(directories == inferred, 'Export directory inventory')
    require(all(files[name]['sha256'] == digest for name, digest in expected.items()), 'Export bytes differ')
    require(sum(row['bytes'] for row in files.values()) == size, 'Export total size')
    ordered = {name: files[name]['sha256'] for name in expected}
    return dict(files=count, bytes=size, directories=len(directories), files_mode='0444', directories_mode='0555',
                ordered_aggregate_sha256=sha(json.dumps(list(ordered.items())).encode()), exact_paths=True)


def private_paths(native):
    archive = load_archive('m2_h2_native_post', 'native-post.tar.gz', 'd19281da19d04c3afbc3bb97ef614b21efa3746f0dc405dfb982d7cc959fbe92')
    public = native / 'evidence/native-post/privacy-publication-inputs'
    member = 'native/evidence/native-post/privacy-publication-inputs/manifest.json'
    require((public / 'manifest.json').read_bytes() == archive[member], 'Safe projection map differs')
    rows = json.loads(archive[member])['substitutions']
    excluded = {str(native / row['original_member'].removeprefix('native/')) for row in rows}
    require(len(rows) == len(excluded) == 25, 'Private exclusion count')
    for row in rows:
        require((public / row['replacement']).read_bytes() == archive[row['original_member']], 'Public projection differs')
    return excluded


def file_row(row, excluded, allowed=None):
    path = Path(row['path'])
    require(str(path) not in excluded, 'Private original in protected byte rows')
    if allowed is None:
        require(str(path).startswith(('/tmp/uwz-', '/workspaces/uWebZockets/.uwz-work/evidence/',
                                     '/workspaces/uWebZockets/docs/implement-2-2-0/evidence/')), 'Protected path outside scope')
    else:
        require(str(path) in allowed, 'Closure path outside authenticated authority')
    if row['status'] == 'absent':
        require(not path.exists() and not path.is_symlink(), 'Protected absent file appeared')
        return
    mode = path.lstat().st_mode
    require(row['status'] == 'regular' and stat.S_ISREG(mode), 'Protected file type changed')
    require(stat.S_IMODE(mode) == int(row['mode'], 8), 'Protected file mode changed')
    data = path.read_bytes()
    require(len(data) == row['bytes'] and sha(data) == row['sha256'], 'Protected file bytes changed: ' + str(path))


def scope_rows(row, excluded):
    root = Path(row['path'])
    if row['status'] == 'absent':
        require(not root.exists() and not root.is_symlink() and not row['files'] and not row['directories'], 'Absent root appeared')
        return
    expected_files = {item['path']: item for item in row['files']}
    expected_dirs = {item['path']: int(item['mode'], 8) for item in row['directories']}
    files, dirs = set(), {}
    for path in [root, *root.rglob('*')]:
        if str(path) in excluded:
            continue
        mode = path.lstat().st_mode
        require(not stat.S_ISLNK(mode), 'Protected symlink')
        if stat.S_ISDIR(mode):
            dirs[str(path)] = stat.S_IMODE(mode)
        else:
            require(str(path) in expected_files, 'Unexpected protected file')
            files.add(str(path))
    require(files == set(expected_files) and dirs == expected_dirs, 'Protected actual path/mode set changed')
    for item in expected_files.values():
        file_row(item, excluded)


def preservation(packet, native):
    excluded = private_paths(native)
    before = (packet / 'preservation-before.json').read_bytes()
    after = (packet / 'preservation-after.json').read_bytes()
    require(before == after and sha(before) == '37fdce0088781b8232faa9ab8e43d31c2aa5f573269bb3d39e860315a4c9aa6b', 'Forward preservation record identity')
    data = json.loads(before)
    require(data['excluded_private_originals'] == len(excluded) == 25, 'Private exclusion count differs')
    for row in data['scopes']:
        scope_rows(row, excluded)
    index = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/coordinator-a/immutable-inputs.json')
    identity = json.loads(index.read_text())
    allowed = {str(Path(row['path']).resolve()) for row in identity['identities']}
    allowed.update(str(Path('/tmp/uwz-h2-client-tooling/packages') / name) for name, _ in identity['codec_files'])
    require(len(allowed) == 155 and {row['path'] for row in data['closure_files']} == allowed, 'Complete closure path set differs')
    for row in data['closure_files']:
        file_row(row, excluded, allowed)
    return dict(before_after_bytes=len(before), before_after_sha256=sha(before),
                regular_file_rows=sum(len(row['files']) for row in data['scopes']),
                closure_physical_files=len(allowed), closure_observation_rows=len(data['closure_files']), scopes=len(data['scopes']),
                current_files_and_modes_and_directory_sets_match=True, private_originals_read=0,
                historical_directory_state='unproved')


def git_checks(root):
    environment = dict(PATH='/usr/bin:/bin', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null',
                       GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0')
    prefix = ['git', '--git-dir=' + str(root / 'objects.git'), '-c', 'core.hooksPath=/dev/null', '-c', 'core.fsmonitor=false']
    results = {}
    for name, arguments in (
        ('fsck', ['fsck', '--strict', '--full']), ('remotes', ['remote']),
        ('commit', ['rev-parse', 'c223bd886c6a51d2cd60def39dd9a68d701fea73^{commit}']),
        ('tree', ['rev-parse', 'c223bd886c6a51d2cd60def39dd9a68d701fea73^{tree}'])):
        result = subprocess.run(prefix + arguments, env=environment, capture_output=True, check=True)
        results[name] = dict(stdout=result.stdout.decode(), stderr=result.stderr.decode(), status=result.returncode)
    require(results['remotes']['stdout'] == '', 'Unexpected bare-store remote')
    require(results['commit']['stdout'].strip() == 'c223bd886c6a51d2cd60def39dd9a68d701fea73' and
            results['tree']['stdout'].strip() == '86c6944f53dc009d7503a9ab0bc873aef3cd7b79', 'Bare-store identity')
    return results


def source_checks(packet, c2, active):
    require((packet / 'metadata.py').read_bytes() == c2['packet/metadata.py'], 'C2 metadata helper changed')
    require((packet / 'authority/prepare_c2.py').read_bytes() == c2['packet/prepare.py'], 'C2 preparation helper changed')
    require((packet / 'authority/restore_inputs.py').read_bytes() == Path('.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py').read_bytes(), '119 restorer differs')
    native = Path('.uwz-work/evidence/h2-streaming/combined-native')
    expected = {name.removeprefix('source/current/'): data for name, data in active.items() if name.startswith('source/current/')}
    require({path.name: path.read_bytes() for path in native.glob('*.py')} == expected, 'Accepted native7 changed')
    canonical = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    baseline = {name.removeprefix('reference/combined/'): data for name, data in active.items()
                if name.startswith('reference/combined/') and name.endswith('.py') and name.count('/') == 2}
    baseline['coordinator.py'] = active['source/canonical/coordinator.py']
    require(len(baseline) == 46 and {path.name: path.read_bytes() for path in canonical.glob('*.py')} == baseline, 'Accepted canonical46 changed')
    result = {}
    for name in ('rehydrate.py', 'test_rehydrate.py', 'preflight.py', 'summarize.py'):
        content = (packet / name).read_bytes()
        tree = ast.parse(content)
        require(nesting(tree) <= 3 and not any(isinstance(node, (ast.ClassDef, ast.Assert, ast.Global, ast.Nonlocal)) for node in ast.walk(tree)), 'New helper source structure')
        result[name] = dict(size=len(content), sha256=sha(content), maximum_nesting=nesting(tree))
    return result


def review_package(plan, packet, result):
    parts = ['# C7 source reconstruction review\n', 'BASE/current HEADd87f782bc7fbbf3037bc6b4f8729b604fea80be0.\n',
             'New source/control delta; reused metadata/prepare/restorer bytes independently authenticated.\n']
    paths = [packet / name for name in ('test_rehydrate.py', 'rehydrate.py', 'preflight.py', 'summarize.py')]
    paths.extend(sorted((packet / 'raw').glob('*.sh')))
    paths.append(Path(__file__))
    for path in paths:
        parts.extend(difflib.unified_diff([], path.read_text().splitlines(True), fromfile='/dev/null', tofile=str(path), n=10))
    parts.extend(['\n# Root independent live-export/protection observations\n', json.dumps(result, indent=2), '\n'])
    path = plan / 'task-5e3c7-review-package.diff'
    path.write_text(''.join(parts))
    return dict(path=str(path), size=path.stat().st_size, sha256=sha(path.read_bytes()))


def main(arguments):
    if arguments != ['--audit']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    packet = Path('.uwz-work/evidence/h2-streaming/native_input_rehydration')
    root = Path('/tmp/uwz-h2-native-rehydration-c7')
    fixture = load_archive('m2_h2_combined_fixture', 'combined-fixture.tar.gz', 'c731e84571477286905ed9116fe8f3e6d820d492e6696fb3382947def8cb38c9')
    receipt = json.loads(fixture['builds/uwz-task5e2-Fix1Final2/debug-receipt.json'])
    candidate = actual_export(root / 'candidate', receipt['source_before'], 1031, 103051479)
    require(candidate['ordered_aggregate_sha256'] == 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de', 'Candidate aggregate')
    live = load_archive('m2_h2_metadata_live', 'metadata-live.tar.gz', 'a08dbf448de76b3642816b0eed9388b59d83356b0d3d1fc8a7025b3718ec7d59')
    identity = json.loads(live['inputs/immutable-libxev-input.json'])
    require(identity['files_sha256'] == receipt['override_before'], 'Dependency authority map differs')
    dependency = actual_export(root / 'libxev', identity['files_sha256'], 93, 1347665)
    require(dependency['ordered_aggregate_sha256'] == '4ce6e5ad1a0ae954352ea1e8890cc82c2a57509102c4eaa3cd434735613df6f9', 'Dependency canonical-order aggregate')
    require({path.name for path in root.iterdir()} == {'candidate', 'libxev', 'objects.git', 'inputs', 'evidence', 'controls'}, 'Export-root children')
    c2 = load_archive('m2_h2_native_source_preparation', 'native-source-preparation.tar.gz', '3c6d55ddc6a9d58445d1635a79186135f230c476eaba97257685649f7481e7de')
    active = load_archive('m2_h2_native_active', 'native-active.tar.gz', '6fda8cfaac4b8c866ff352848c12397a9775a7bd09397f1db7c9740707c50b14')
    result = dict(candidate=candidate, dependency=dependency, git=git_checks(root), sources=source_checks(packet, c2, active),
                  preservation=preservation(packet, Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native')),
                  native_executed=False, complete_provider=False, milestone_complete=False)
    (plan / 'task-5e3c7-root-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    package = review_package(plan, packet, result)
    print(json.dumps(dict(candidate=candidate, dependency=dependency, preservation=result['preservation'], review_package=package)))


if __name__ == '__main__':
    main(sys.argv[1:])
