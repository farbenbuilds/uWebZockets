"""Print bounded metadata shapes for the independent source-export audit."""
import json
import sys
from pathlib import Path


def example(value):
    if isinstance(value, list):
        return dict(kind='list', count=len(value), first=value[:1])
    if isinstance(value, dict):
        return dict(kind='dict', count=len(value), first=list(value.items())[:1])
    return value


def main(arguments):
    if arguments != ['--inspect']:
        return
    packet = Path('.uwz-work/evidence/h2-streaming/native_input_rehydration')
    audit = json.loads((packet / 'materialization-audit.json').read_text())
    before = json.loads((packet / 'preservation-before.json').read_text())
    result = dict(audit_keys=list(audit), candidate={key: example(value) for key, value in audit['candidate'].items()},
                  preservation_keys=list(before), closure=example(before['closure_files']),
                  first_scope={key: example(value) for key, value in before['scopes'][0].items()})
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
