Plan a separate, source-only rehydration slice. C6a remains the sole implementation owner; build/vendor guides provenance and isolated Git handling, verification owns focused checks, and Root reviews and releases execution.

Assumptions: Root’s fresh observation that `/tmp/uwz-h2-combined-c2-fix1` is absent is authoritative. Historical receipts remain evidence, not present availability. No product interface, repository vocabulary, ADR, production pin, or network hot path changes.

I read AGENTS, conventions, architect/build_vendor instructions, planning/interface/codebase-design skills, and grill-me→grilling. The brief settles the principal choices: durable supplements, fresh destinations, unchanged identities, and separate native authorization. Skill defaults requesting saved plans, subagents, or an interactive interview conflict with this bounded assignment; no such actions were taken.

**Authorities and observations**

Let `E` mean `/workspaces/uWebZockets/docs/implement-2-2-0/evidence/`.

| Archive | SHA256 |
|---|---|
| `E/m2_h2_native_source_preparation/native-source-preparation.tar.gz` | `3c6d55ddc6a9d58445d1635a79186135f230c476eaba97257685649f7481e7de` |
| `E/m2_h2_combined_input_audit/combined-input-audit.tar.gz` | `4c4d93bdec76e4b302a38e5811062b48100df0b617f479fe17eac1bdaa6105c8` |
| `E/m2_h2_metadata_live/metadata-live.tar.gz` | `a08dbf448de76b3642816b0eed9388b59d83356b0d3d1fc8a7025b3718ec7d59` |
| `E/m2_h2_combined_fixture/combined-fixture.tar.gz` | `c731e84571477286905ed9116fe8f3e6d820d492e6696fb3382947def8cb38c9` |

All four whole-archive hashes matched during this pass. The nine supplement member hashes and embedded bundle hash also matched. The immutable base tree exists; individual base blobs were not re-audited.

Exact metadata:

- C2: `INVENTORY.json`; `packet/{metadata.py,prepare.py,origin-authorities.json,fix1normal-audit.json,fix1normal-origin-ledger.json,packet-manifest-fixround2.json}`; both `evidence/task-5e3c2-fix{1,2}-review-report.md`.
- C1: `packet/{final-candidate-reconstruction.json,dependency-audit.json,final-input-index.json,epoll-registration-rollback.bundle}`.
- Metadata-live: `candidate/delta.json`, `candidate/source/<path>`, `inputs/{restoration-provenance.json,immutable-libxev-input.json}`.
- Fixture: `builds/uwz-task5e2-Fix1Final2/{debug,release}-receipt.json`.

C2’s `reconstruction/supplements/` contains these exact relative paths:

```text
README.md
docs/adr/0008-request-body-streaming.md
docs/deployment.md
docs/implement-2-2-0/README.md
docs/implement-2-2-0/evidence/m2_h1_retirement_v6/README.md
docs/implement-2-2-0/m1_streaming_static_tls.md
docs/implement-2-2-0/m2_loop_callback_adapter.md
docs/implement-2-2-0/m2_request_streaming.md
tests/package_consumer/main.zig
```

**Small ordered plan**

1. **Freeze the authority and preservation contract — C6a, guided by build/vendor.** Authenticate archives before reading members; retain immutable manifest anchors at `cbdadc8bad2a6f1adb2dddb0b416da45caf96125` for C1 and `58bc6d6a525e01380ccc7bf3802e695c07877e89` for metadata/fixture. Validate inventories, member types, duplicate keys/paths, traversal and parent collisions. Select archive bytes explicitly; never substitute current Root files sharing names.

2. **Adapt only location-dependent preparation — C6a.** Use reviewed C2 helpers as the starting authority. Local `metadata.py` and final `prepare.py` matched their recorded hashes. Reuse pure validation, source-inventory checks, Git-object checks, exclusive export, and export auditing unchanged.

   Required adaptations in historical `prepare.py`:
   - Lines 126–154: consume authenticated embedded indexes and explicitly mapped archive locations; remove reliance on local c1 packet copies.
   - Lines 222–231: read `reconstruction/supplements/<path>` instead of the historical absolute snapshot. Preserve original snapshot provenance, size/hash checks, and add actual archive/member identity.
   - Lines 234–241: stage only the authenticated embedded bundle.
   - Lines 301 onward: replace historical availability assumptions and fixed destination/evidence allowlists with the newly released explicit paths and fresh preservation baseline.

   Keep historical helpers/evidence intact. Do not broaden CLI access into arbitrary destinations.

3. **Materialize once, after separate authorization — C6a/build_vendor.** Proposed exclusive root: `/tmp/uwz-h2-native-rehydration-c7/`, with `candidate/`, `libxev/`, `objects.git/`, `inputs/`, `evidence/`, and `controls/`. Require the root absent, including dangling symlinks, and reject symlink ancestors. Existing or partial destinations fail without repair or deletion.

   Root Git is read-only. Initialize the new bare database with an empty template, import only the authenticated local bundle, disable hooks/fsmonitor/config interference/optional locks, and configure no remote. Use immutable base blobs directly; do not replay nine duplicate batch streams or publish another whole-tree archive.

4. **Verify and independently review — verification, then Root.** Record commands, original failures, hashes, origin ledger, declared remappings, and before/after observations. Any Python metadata invocation requires fresh pinned119 restoration and its receipt in that same shell first.

**Acceptance criteria**

- Candidate: exactly **1,031 files**, **103,051,479 bytes**: 982 blobs at `30f27ab80f0471437c34adcdf7b2d42f58227b74`, 40 delta members, nine supplements.
- Ordered aggregate remains `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`, using the existing inventory order and serialization.
- Libxev: **93 files**, **1,347,665 bytes**, commit `c223bd886c6a51d2cd60def39dd9a68d701fea73`, tree `86c6944f53dc009d7503a9ab0bc873aef3cd7b79`; bundle SHA256 `6f9f27199b2cc4bf47e7f04fd3d1862362899be283d84ec1e97c614b69a03580`. Strict Git integrity and every exported blob identity pass.
- Exports contain exactly inferred directories, files 0444 and directories 0555; zero extras.
- Before effects, capture protected regular-file identities/modes and actual directory sets, including empty directories/root entries. Record absent roots explicitly and compare afterward. Coordinate stable scope with active C6a work; exclude private C5 environment originals entirely.
- Preserve original missing directory history as **unproved**. Fresh observations never become retrospective proof.
- Focused normal/optimized tests reject altered/missing supplements, provenance mismatches, malformed paths, pre-existing destinations, and empty-directory additions/removals. A miniature reconstruction must succeed with historical snapshot reads denied. Imports and rejected CLI inputs remain inert.

The existing validation-to-export seam earns its depth: deleting it redistributes archive/Git authenticity, path safety, and export invariants across callers. No new abstraction is needed.

No missing durable authority bytes were identified. No files were edited, sources restored, tests run, or native operations performed. Fresh runtime closure, Zig 0.16.0 builds, actual combined native all40, prescribed formatting/convention/version/test gates, sanitizer/fuzz/package/protocol/platform gates, production adoption, and the original goal remain open.
