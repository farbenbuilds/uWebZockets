"""Publish reconstruction controls and observations, with source exports referenced."""
import hashlib
import json
import runpy
import sys
import tarfile
from pathlib import Path


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def published(plan):
    path = Path('docs/implement-2-2-0/evidence/m2_h2_native_active/native-active.tar.gz')
    require(sha(path.read_bytes()) == '6fda8cfaac4b8c866ff352848c12397a9775a7bd09397f1db7c9740707c50b14', 'Published C6c identity')
    helper = plan / 'task-5e3c6c-publication.py'
    with tarfile.open(path, 'r:gz') as archive:
        require(helper.read_bytes() == archive.extractfile('evidence/' + helper.name).read(), 'Published metadata bridge differs')
    return runpy.run_path(str(helper))['authority'](plan)[1]


def packet_members(packet):
    result = {}
    for path in sorted(packet.rglob('*')):
        require(not path.is_symlink(), 'Packet symlink')
        if path.is_file():
            result['packet/' + path.relative_to(packet).as_posix()] = path.read_bytes()
    require(len(result) == 190, 'Reviewed packet path count differs')
    return result


def root_records(plan):
    names = [
        'task-5e3c7-brief.md', 'task-5e3c7-rehydration-plan-report.md', 'task-5e3c7-report.md',
        'task-5e3c7-review-report.md', 'task-5e3c7-review-package.diff', 'task-5e3c7-root-audit.json',
        'task-5e3c7-root-audit.py', 'task-5e3c7-root-audit-executed.py', 'task-5e3c7-root-audit-code.sha256',
        'task-5e3c7-root-audit-receipt-order.py', 'task-5e3c7-root-receipt-order-audit.json',
        'task-5e3c7-root-audit-final-code.sha256', 'task-5e3c7-root-audit-canonical-code.sha256',
        'task-5e3c7-root-audit-inputs.json', 'task-5e3c7-root-final-audit-inputs.json',
        'task-5e3c7-root-canonical-audit-inputs.json', 'task-5e3c7-inspect-records.py',
        'task-5e3c7-root-record-shapes.json', 'task-5e3c7-root-inspect-inputs.json',
        'task-5e3c7-root-final-graph-inputs.json', 'task-5e3c7-root-final-graph-command.sh',
        'task-5e3c7-publication.py', 'task-5e3c7-publication-executed.py', 'task-5e3c7-publication-code.sha256']
    names.extend('task-5e3c7-' + stem + '.' + suffix for stem in
                 ('root-audit', 'root-final-audit', 'root-canonical-audit', 'root-final-graph')
                 for suffix in ('stdout', 'stderr', 'exit'))
    names.extend('task-5e3c7-root-' + stem + '.' + suffix for stem in
                 ('format', 'conventions', 'version', 'dependencies', 'unit')
                 for suffix in ('stdout', 'stderr', 'exit'))
    return {'evidence/' + name: (plan / name).read_bytes() for name in names}


def verify_packet(packet):
    summary = json.loads((packet / 'review-summary.json').read_text())
    for name, row in summary['hashes'].items():
        data = (packet / name).read_bytes()
        require(len(data) == row['bytes'] and sha(data) == row['sha256'], 'Reviewed packet member differs')
    for label in ('04_normal', '05_optimized', '07_materialize', '08_summarize'):
        require((packet / 'raw' / (label + '.exit')).read_text().strip() == '0', 'Final packet run failed')
    materializer = (packet / 'rehydrate.py').read_bytes()
    test = (packet / 'test_rehydrate.py').read_bytes()
    for label in ('04_normal', '05_optimized', '07_materialize'):
        require((packet / 'snapshots' / label / 'rehydrate.py').read_bytes() == materializer, 'Executed materializer differs')
        require((packet / 'snapshots' / label / 'test_rehydrate.py').read_bytes() == test, 'Executed test source differs')
    return summary


def export_references(packet):
    data = json.loads((packet / 'materialization-audit.json').read_text())
    result = dict(scope='Observed source exports; bytes not embedded; no runtime authority',
                  local_root='/tmp/uwz-h2-native-rehydration-c7', original_materializations=1,
                  historical_directory_state='unproved', native_executed=False,
                  candidate=data['candidate'], libxev=data['libxev'])
    return (json.dumps(result, indent=2) + '\n').encode()


def collect(plan, packet):
    summary = verify_packet(packet)
    result = packet_members(packet)
    result.update(root_records(plan))
    result['EXPORT_REFERENCES.json'] = export_references(packet)
    audit = json.loads((plan / 'task-5e3c7-root-audit.json').read_text())
    require(audit['candidate']['ordered_aggregate_sha256'] == summary['candidate_aggregate'] and
            audit['dependency']['ordered_aggregate_sha256'] == '4ce6e5ad1a0ae954352ea1e8890cc82c2a57509102c4eaa3cd434735613df6f9', 'Independent canonical source identity differs')
    return result, summary, audit


def build(plan, packet, folder):
    bridge = published(plan)
    members, summary, audit = collect(plan, packet)
    api = bridge['published_api'](plan, 'task-5e3c1-build-publication.py')
    safe = {}
    for name, data in members.items():
        api['add'](safe, name, data, {})
    folder.mkdir(parents=True, exist_ok=True)
    output = folder / 'native-rehydration.tar.gz'
    inventory = api['write_archive'](output, safe)
    manifest = dict(scope='C7 authenticated source rehydration; no runtime/native acceptance',
                    base_commit='d87f782bc7fbbf3037bc6b4f8729b604fea80be0', archive=output.name,
                    archive_sha256=sha(output.read_bytes()), archive_bytes=output.stat().st_size,
                    safe_regular_utf8_members=len(safe) + 1, inventory_entries=len(inventory), packet_files=190,
                    candidate=audit['candidate'], dependency=audit['dependency'], actual_materializations=1,
                    exports_embedded=False, export_reference_member='EXPORT_REFERENCES.json',
                    protected_regular_file_rows=44153, closure_physical_files=155,
                    preservation_sha256=summary['hashes']['preservation-before.json']['sha256'],
                    private_originals_read=False, private_originals_included=False,
                    historical_directory_state='unproved', tool_closure_copies_added=0,
                    preflight_source_note='Only unused sys import removed after06/07; executed versions retained',
                    controlled_shell_note='02-08 used env-i; initial01 inherited a shell and set the recorded safe variables',
                    old_batch_stream_bytes_duplicated=0, runtime_closure_established=False,
                    repository_gate_scope='Tracked d87f782 baseline; separate from reconstructed candidate',
                    repository_tests_passed=852,
                    native_candidate_compiled=False, combined_native_executed=False,
                    second_machine_proven=False, milestone_complete=False)
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({key: manifest[key] for key in ('archive_sha256', 'archive_bytes', 'safe_regular_utf8_members', 'packet_files')}))


def audit_publication(plan, packet, folder):
    bridge = published(plan)
    expected, _, _ = collect(plan, packet)
    api = bridge['published_api'](plan, 'task-5e3c1-publication-audit.py')
    manifest = json.loads((folder / 'manifest.json').read_text())
    output = folder / manifest['archive']
    require(output.stat().st_size == manifest['archive_bytes'] and sha(output.read_bytes()) == manifest['archive_sha256'], 'Published archive identity')
    actual = api['read_archive'](output)
    require(actual == expected and len(actual) == manifest['inventory_entries'], 'Complete published member set differs')
    require(len(actual) + 1 == manifest['safe_regular_utf8_members'], 'Published count differs')
    for data in actual.values():
        data.decode('utf-8')
    check = runpy.run_path(str(plan / 'task-5e3c1-prepare-review.py'))['root_check']
    helpers = {name: check((plan / name).resolve()) for name in ('task-5e3c7-root-audit.py', 'task-5e3c7-inspect-records.py', 'task-5e3c7-publication.py')}
    docs = Path('docs/implement-2-2-0')
    files = [docs / 'README.md', docs / 'm2_request_streaming.md', docs / 'm2_h2_native_rehydration.md',
             folder / 'README.md', folder / 'manifest.json', output]
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=output.stat().st_size,
                  safe_regular_utf8_members=len(actual) + 1, inventory_entries=len(actual), packet_files=190,
                  helpers=helpers, local_links_checked=api['verify_links'](files),
                  delivery_files={str(path): dict(size=path.stat().st_size, sha256=sha(path.read_bytes())) for path in files},
                  native_candidate_compiled=False, combined_native_executed=False, milestone_complete=False)
    (plan / 'task-5e3c7-root-publication-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('helpers', 'delivery_files')}))


def main(arguments):
    if arguments not in (['--build'], ['--audit']):
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    packet = Path('.uwz-work/evidence/h2-streaming/native_input_rehydration')
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_native_rehydration')
    if arguments == ['--build']:
        build(plan, packet, folder)
        return
    audit_publication(plan, packet, folder)


if __name__ == '__main__':
    main(sys.argv[1:])
