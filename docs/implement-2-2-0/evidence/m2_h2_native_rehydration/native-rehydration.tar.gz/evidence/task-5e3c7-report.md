# C7 source reconstruction: DONE

Implemented and completed the authorized single source-only materialization at
`/tmp/uwz-h2-native-rehydration-c7/`. This checkpoint does not authorize native
execution or adopt the historical libxev override as a production pin.

## Files and interfaces

New packet: `.uwz-work/evidence/h2-streaming/native_input_rehydration/` (`P`).
`rehydrate.py --prepare` accepts only that exact operation and uses the fixed
exclusive destination. Rejected CLI arguments return 2 without effects.
`metadata.py` is unchanged authenticated C2 validation; `authority/prepare_c2.py`
is the unchanged final C2 helper. The adapter reuses its archive/inventory,
source-inventory, export and export-audit logic. `test_rehydrate.py` supplies
functional miniatures/inert checks; `preflight.py` performs read-only authority
checks; `summarize.py` verifies retained observations. All exercised source and
shell versions precede their runs in `snapshots/`, with code-only authority
copies and SHA controls. No prior evidence/tool closure was copied.

| Source | SHA256 |
|---|---|
| `rehydrate.py` | `5fbf7e737eda8add6ae086bfdd27632c9090bd98ed63ece0a4b64735c3dde484` |
| `metadata.py` | `e02b74fc103ae5ac30318a98f83241ab1b4e469b30301ccbe5c93c1f29067430` |
| `authority/prepare_c2.py` | `406a48d1740e757ebfd124f5b78e0098d06d7a323ecbc384aa4301a77397c92f` |
| `authority/restore_inputs.py` | `aa6d5a881925917f4254f518643e5dbb888ba1d163fafe73d1c857b491c69dea` |
| `test_rehydrate.py` | `687ea5f5553b782e11687ec407e09cb32cd04c155e62c7b3c743b70b420d31a2` |

`review-summary.json` records all other final source/evidence hashes. The sole
post-execution cleanup removed an unused `sys` import from `preflight.py`;
its exact exercised source remains in snapshots 06/07. The materializer/test
sources were unchanged between final tests and the actual materialization.

## Authorities and adaptations

All four archive hashes matched the plan: native-source-preparation
`3c6d55ddc6a9d58445d1635a79186135f230c476eaba97257685649f7481e7de`,
combined-input-audit `4c4d93bdec76e4b302a38e5811062b48100df0b617f479fe17eac1bdaa6105c8`,
metadata-live `a08dbf448de76b3642816b0eed9388b59d83356b0d3d1fc8a7025b3718ec7d59`,
combined-fixture `c731e84571477286905ed9116fe8f3e6d820d492e6696fb3382947def8cb38c9`.
Whole hashes precede member reads; exact inventories, member types, duplicate
keys/paths, traversal and parent collisions are checked. C1 and historical
manifest Git anchors remain `cbdadc8bad2a6f1adb2dddb0b416da45caf96125` and
`58bc6d6a525e01380ccc7bf3802e695c07877e89`.

Nine supplements come exclusively from C2
`reconstruction/supplements/<candidate-path>`. Their original named-snapshot
provenance, size and SHA checks remain; the origin ledger adds actual archive
and member identity. No same-named current Root documentation is substituted.
The adapter consumes embedded authenticated C1 indexes and bundle, immutable
Root base blobs, and current forward preservation observations. The 101,829,106
byte base batch is checked in memory; only its command/input and output
size/hash are retained, avoiding another full stream or complete source archive.

## Commands and results

Runs 02–08 use:
`env -i PATH=/usr/bin:/bin bash P/raw/<name>.sh`.
Those shells check source/interpreter controls. Run 01 used an inherited shell
with explicitly set PATH/PYTHONPATH/PYTHONDONTWRITEBYTECODE; its source and
control versions were preserved before execution. Every shell freshly executes the copied
`task-5e3b8a-restore-inputs.py --restore P/raw/<id>_restore.json`, then runs its
dependent Python in that same shell. Python is exactly
`/home/codespace/.python/current/bin/python3 -B -S`, SHA
`4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`,
with `PYTHONDONTWRITEBYTECODE=1`. The optimized test adds `-O`.
Only the local packet PYTHONPATH is needed: no combined/native helper is imported.
Each restoration checked 118 rows/113 physical sources/42 ordered codecs and
restored zero files. Every stdout/stderr/status is retained alongside its shell.

- `01_red`: exit 1, expected missing materializer interface.
- `02_normal`: exit 1, test cleanup left the export root 0755 after its empty
  directory mutation. The fixture now restores 0555; the rejection was retained.
- `03_normal`, final `04_normal`, `05_optimized`: exit 0. Reconstruct from an
  archived miniature with historical snapshot reads denied; reject changed or
  missing supplements, provenance mismatches, malformed paths/archives,
  existing/dangling destinations, symlink ancestors and empty-directory/mode
  changes. Imports and rejected CLI inputs are guarded before project imports.
- `06_preflight`: exit 0; archive/index/manifest authorities, C6c current native7,
  S46 with accepted canonical coordinator, 25 public projections and fresh
  fixed destination validated.
- `07_materialize`: exit 0, one actual materialization; stderr empty.
- `08_summarize`: exit 0; observations and evidence hashes retained.

## Actual materialization and preservation

Candidate: **1031 files / 103051479 bytes**, comprising 982 immutable base blobs
at `30f27ab80f0471437c34adcdf7b2d42f58227b74`, 40 delta members and nine archived
supplements. Ordered aggregate:
`fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`.
Libxev: **93 files / 1347665 bytes**; commit
`c223bd886c6a51d2cd60def39dd9a68d701fea73`, tree
`86c6944f53dc009d7503a9ab0bc873aef3cd7b79`, bundle SHA
`6f9f27199b2cc4bf47e7f04fd3d1862362899be283d84ec1e97c614b69a03580`.
All blob identities and strict full Git integrity passed. Exports have exactly
inferred directories, regular files 0444/directories 0555, zero extras.
The root contains exactly candidate/libxev/objects.git/inputs/evidence/controls.
The bare database used an empty template, disabled hooks/fsmonitor/system/global
config/optional locks, imported only the authenticated local bundle, and has no
remotes. Root Git was read-only.

Forward snapshots cover **44153 protected regular-file rows**, plus **155**
physical closure/codec entries, and actual directory paths/modes including roots,
empty directories and absent roots. Counts include native public view 22628
files/1815 directories; S46 tree 19926/699; historical C2 809/5; published evidence
661/134; native transport proof 16169 files. Old c2, c2-fix1 and reviewed-libxev
roots were explicitly absent. No tool-reference closure was recopied.

Before and after JSON are byte-identical (16632879 bytes each), SHA
`37fdce0088781b8232faa9ab8e43d31c2aa5f573269bb3d39e860315a4c9aa6b`.
The authenticated 25-entry C5 replacement map was established before native-tree
byte reads; all private originals were excluded entirely. Reviewed replacements
matched their published projected members. C6a/b/c archive bytes and current C6c
native7/S46 coordinator authority remained unchanged.

Key evidence: `materialization-audit.json` SHA
`577cde55f81e5f7e7be77b658e9dddce154939834cfd68b3cc22831a4596e08d`;
`origin-ledger.json` SHA
`111c5ca1245ee7718eac5890f95bc754fd1654ba95e10d89b8a4a3dc6a842738`.

Original historical directory state remains **unproved**. Fresh runtime closure,
Debug/ReleaseSafe rebuilds, real owned provider, actual native all40, production
adoption and every original milestone remain open. No compiler, server, socket,
SSLContext, real clock, native build/install, network, publication, dependency
pin change or Root Git mutation occurred. Root owns fresh review, AST maintenance,
publication, commits/push and later native/project gates; ignored-helper graph
topology remains unproved.
