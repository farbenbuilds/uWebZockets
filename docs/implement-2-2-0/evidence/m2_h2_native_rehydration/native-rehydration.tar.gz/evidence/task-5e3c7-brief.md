# C7: portable authenticated native-source reconstruction

Read task-5e3c7-rehydration-plan-report.md FIRST for exact authorities, member
anchors, adaptations, counts, aggregates and acceptance cases. Its old step
owner labels C6a mean this NEW C7 slice, not a restart or additional C6a work.
BASEd87f782bc7fbbf3037bc6b4f8729b604fea80be0 is clean/pushed after C6c.
This brief explicitly authorizes source reconstruction after focused checks;
no additional user approval is required for the isolated reversible export.

Own a NEW `.uwz-work/evidence/h2-streaming/native_input_rehydration/` source,
tests and evidence packet only. Use minimal named Python modules/functions,
reuse authenticated C2 validation/export logic and adapt only the location
assumptions identified in the plan. Do not edit historical C1/C2/C3/C4/C5/C6
helpers, packets, archives, S46, native7, candidate snapshots, product/build
files, dependency pins or Root Git. You are sole implementer, not alone;
preserve others. No subagents/Git mutations in Root/publication. Root reviews
and commits/pushes. Local bare Git writes below the fresh export root are
explicitly authorized; no network/remote access or new online fork.

Use the four immutable archives and exact SHA/member mappings from the plan.
Authenticate whole archives before members, validate inventory/member types,
duplicate/path collisions and traversal. Preserve original snapshot provenance
while mapping the nine supplements to archived reconstruction/supplements/.
Never read current Root files merely because their paths share those names.
Use the exact authenticated bundle and immutable Root base Git blobs; do not
replay/copy nine 101MB batch streams or publish another complete source tree.

After miniature tests pass, materialize once at the explicit exclusive root:
`/tmp/uwz-h2-native-rehydration-c7/`, with candidate/, libxev/, objects.git/,
inputs/, evidence/, controls/. Before effects prove the root absent, including
dangling symlinks, and reject symlink ancestors. Existing/partial destinations
fail with no deletion/repair; raise to Root if a failed real attempt requires
a newly named destination. Test fixtures use isolated caller-owned temporary
roots; do not expose arbitrary destination writes through the real CLI.

Initialize a new bare object database with empty template and no hooks,
fsmonitor, global/system config interference, optional locks or remotes. Import
only the authenticated local bundle. Root .git stays read-only. No upstream or
maintained-fork writes. The historical c223bd886c6a51d2cd60def39dd9a68d701fea73
override is source evidence, not adoption of a new production pin.

Exact candidate:1031files/103051479B,982base blobs at
30f27ab80f0471437c34adcdf7b2d42f58227b74 +40delta +9supplements;
ordered aggregate fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de
using the existing inventory order and serialization. Libxev:93files/1347665B,
commitc223bd886c6a51d2cd60def39dd9a68d701fea73,
tree86c6944f53dc009d7503a9ab0bc873aef3cd7b79,
bundleSHA6f9f27199b2cc4bf47e7f04fd3d1862362899be283d84ec1e97c614b69a03580.
All exported blobs/Git integrity must match; files0444/dirs0555, exactly inferred
directories and no extra members. Record original failures and origin ledger.

Before effects freeze actual protected regular-file identities/modes AND actual
directory sets (roots/empty directories/absence included), then compare after.
Protect old native/public proof, S46, native-input-preparation809files,
historical119closure/ordered42codecs and published authority bytes. Current
native source authority is the C6c native-active archive SHA
6fda8cfaac4b8c866ff352848c12397a9775a7bd09397f1db7c9740707c50b14;
native7/currentcoordinator6585ad23 stay unchanged. Prior safe transport proof
has16169files; use reviewed public projections for older C5 paths. NEVER read,
copy, hash or print the25 private original native-post environment records.
Exclude those originals entirely from protected regular-file byte receipts;
their reviewed replacement map supplies safe public comparisons. Never claim
fresh observations repair unproved historical directory state.

Exact protected roots under `.uwz-work/evidence/h2-streaming/` are
`combined-native/`, `integration-owned/combined-cases/`, and
`native-input-preparation/`. Native7 are `combined-native/*.py`; safe transport
proof is `combined-native/evidence/native-transport/` (16169 files).
Privacy map is `combined-native/evidence/native-post/privacy-publication-inputs/manifest.json`,
SHA `261fa25fa106d49147bc4d08cd08fd438b42d16090ea91431784e9fd0bc673d3`.
Authenticate it against C5 `native-post.tar.gz` SHA
`d19281da19d04c3afbc3bb97ef614b21efa3746f0dc405dfb982d7cc959fbe92`,
member `native/evidence/native-post/privacy-publication-inputs/manifest.json`.
Its 25 `substitutions` rows map `original_member` (remove `native/` for the
native-root relative path) to `replacement` relative to the privacy-map
directory. Build exclusions before any native-tree byte hashing. Existing
Graphify snapshot regular files remain protected; hash them without recopying.
Root `.superpowers` and runtime caches are not protected scopes. Capture actual
state of historical `/tmp` inputs rather than assuming complete availability.

Additional preservation authorities under `docs/implement-2-2-0/evidence/`:
`m2_h2_native_connection/native-connection.tar.gz` SHA
`c0bdf2032aedfeea034e08edc4b2ab170f122931df10e419bc9f12a57f9f96f9`;
`m2_h2_native_disconnect/native-disconnect.tar.gz` SHA
`a699c83b373b1ed0c4d976a179ac4d2d7c9453344211e87ce1d6b89fc1f4a4b8`;
`m2_h2_native_active/native-active.tar.gz` SHA
`6fda8cfaac4b8c866ff352848c12397a9775a7bd09397f1db7c9740707c50b14`.
Current C6c `source/current/` wins over prior native source versions. Its
`source/canonical/coordinator.py` wins over the older reference coordinator;
the other 45 canonical modules remain equal. Safe transport proof consists of
C6a 3923 embedded raw files plus 2506 local tool-reference files, C6b 5520 raw
files, and C6c 4220 raw files.

TDD miniature normal/-O: altered/missing supplement, provenance mismatch,
malformed paths, pre-existing destination, empty-directory addition/removal;
successful reconstruction while historical absolute snapshot reads are denied.
Inert imports and rejected CLI inputs. Preserve all exercised source/control
versions before runs, exact safe argv/settings, fresh restoration receipts,
complete stdout/stderr/status. Capture code-only dependencies, not old evidence
trees. No ambient environment dump. No new Graphify closure copies. Graphify
before new codebase queries; supplied archive/source paths are located. Root
owns final AST maintenance; ignored-helper topology remains unproved.

Python EXACT /home/codespace/.python/current/bin/python3 -B -S SHA
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601,
PYTHONDONTWRITEBYTECODE=1. EACH dependent Python shell begins with fresh
task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT, then executes in
that SAME controlled shell. It restores/checks119historical source entries,
not the complete candidate. Compose accepted source identities explicitly;
never rewrite historical pins. Use the accepted six-part PYTHONPATH when
dependent project helpers require it; authenticate every additional helper
path/hash before behavior. No project preimports before inert effect guards.

Follow AGENTS/conventions/build_vendor+verification and narrow source-provenance,
API/TDD/debugging skills. No classes/assert/custom errors/global mutable state,
silent errors or new control nesting>3. No speculative wrapper modules.
This is Python verification/source export, not a new product build dependency.
No compiler/server/socket/SSLContext/real clock/process-under-test/native builds
or install operations. Local metadata Git operations only. Runtime closure,
Debug/ReleaseSafe rebuilds, real owned provider, native all40, final adoption
and every original milestone remain required after this source checkpoint.

Write task-5e3c7-report.md here <=1400words preferred with exact files,
interfaces/hashes/commands/results/raw paths/before-after observations/limits.
Return concise DONE|DONE_WITH_CONCERNS|NEEDS_CONTEXT|BLOCKED. Raise actual gaps
early with a minimal proposed resolution; do not weaken counts or substitute
current workspace bytes for missing immutable authority.
