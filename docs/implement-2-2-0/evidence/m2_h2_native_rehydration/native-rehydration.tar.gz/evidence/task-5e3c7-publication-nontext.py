"""Locate non-UTF-8 packet members without printing their contents."""
import hashlib
import json
from pathlib import Path


def main():
    root = Path('.uwz-work/evidence/h2-streaming/native_input_rehydration')
    records = []
    for path in sorted(root.rglob('*')):
        if not path.is_file() or path.is_symlink():
            continue
        data = path.read_bytes()
        try:
            data.decode('utf-8')
        except UnicodeDecodeError:
            records.append(dict(path=path.relative_to(root).as_posix(), size=len(data),
                                sha256=hashlib.sha256(data).hexdigest()))
    print(json.dumps(records, indent=2))


if __name__ == '__main__':
    main()
