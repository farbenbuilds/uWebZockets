"""Source-only C7 reconstruction; importing performs no effects."""
import os
from pathlib import Path
import stat
import subprocess
import sys
import tarfile

import metadata as m
from authority import prepare_c2 as c2
from authority.prepare_c2 import archive_members, audit_export


def fresh_destination(path):
    m.require(path.is_absolute(), "Destination must be absolute")
    m.require(not path.exists() and not path.is_symlink(), "Refusing existing destination")
    for parent in path.parents:
        m.require(not parent.is_symlink(), "Symlink destination ancestor")
        m.require(parent.is_dir(), "Missing/non-directory destination ancestor")


def run_git(root, output, label, arguments, git_dir=None, stdin=b"", retain_stdout=True):
    prefix = ["/usr/bin/git", "--no-optional-locks", "--no-replace-objects", "-c", "core.hooksPath=/dev/null", "-c", "core.fsmonitor=false"]
    location = ["-C", str(root)] if git_dir is None else ["--git-dir=" + str(git_dir)]
    argv = prefix + location + arguments
    environment = dict(PATH="/usr/bin:/bin", GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL="/dev/null",
                       GIT_CONFIG_SYSTEM="/dev/null", GIT_TERMINAL_PROMPT="0", GIT_OPTIONAL_LOCKS="0",
                       GIT_NO_REPLACE_OBJECTS="1", GIT_ATTR_NOSYSTEM="1", LC_ALL="C")
    target = output / "raw" / label
    c2.write_json(target.with_suffix(".command.json"), dict(argv=argv, environment=environment,
                  stdin_sha256=m.digest(stdin), stdin_bytes=len(stdin), stdout_retained=retain_stdout))
    with target.with_suffix(".stdin").open("xb") as stream:
        stream.write(stdin)
    result = subprocess.run(argv, input=stdin, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            env=environment, check=False)
    if retain_stdout:
        target.with_suffix(".stdout").write_bytes(result.stdout)
    else:
        c2.write_json(target.with_suffix(".stdout-identity.json"), dict(bytes=len(result.stdout), sha256=m.digest(result.stdout)))
    target.with_suffix(".stderr").write_bytes(result.stderr)
    target.with_suffix(".exit").write_text(str(result.returncode) + "\n")
    m.require(result.returncode == 0, "Git failed; retained " + str(target))
    return result.stdout


def base_sources(root, output, candidate):
    rows = [row for row in candidate["files"] if row["reconstruction"]["status"] == "available-matching"
            and row["reconstruction"]["source"] == "exact base Git blob" and "supplement" not in row]
    m.require(len(rows) == 982, "Wrong base-origin count")
    raw = run_git(root, output, "base-tree", ["ls-tree", "-r", "-z", candidate["base"], "--", *[r["path"] for r in rows]])
    tree = m.regular_tree(raw)
    m.exact_set(tree, [r["path"] for r in rows])
    object_ids = [tree[row["path"]]["object"] for row in rows]
    raw = run_git(root, output, "base-blobs", ["cat-file", "--batch"],
                  stdin=("\n".join(object_ids) + "\n").encode(), retain_stdout=False)
    blobs = m.batch_blobs(raw, object_ids)
    sources = {}
    for row in rows:
        source = tree[row["path"]]
        m.require(source["object"] == row["base_object"]["object"], "Base tree/object mismatch")
        data = m.check_bytes(blobs[source["object"]], row["expected_sha256"], row["base_object"]["bytes"])
        sources[row["path"]] = (data, dict(kind="base Git blob", commit=candidate["base"], **source))
    return sources


def add_origin(row, members, sources, changes, provenance, supplements, archive_reference):
    path = m.safe_path(row["path"])
    if path in sources:
        return
    if path in changes:
        change = changes[path]
        m.require(change["candidate_sha256"] == row["expected_sha256"], "Delta target differs")
        m.require(change["base_sha256"] == row["base_object"].get("sha256"), "Delta base differs")
        origin = row["reconstruction"]["source"]
        m.require(origin["archive"] == "m2_h2_metadata_live" and origin["member"] == "candidate/source/" + path, "Wrong delta member")
        data = m.check_bytes(members[origin["member"]], row["expected_sha256"], change.get("bytes"))
        sources[path] = (data, dict(kind="metadata delta member", **origin, base=change))
        return
    supplement = row["supplement"]
    authority = supplement["authority"]
    m.require(authority["archive"] == "m2_h2_metadata_live" and authority["member"] == "inputs/restoration-provenance.json", "Wrong snapshot authority")
    m.check_bytes(members[authority["member"]], authority["member_sha256"])
    relative = str(Path(supplement["path"]).relative_to("/workspaces/uWebZockets"))
    m.safe_path(relative)
    m.require(provenance[path] == "preserved-snapshot:" + relative, "Wrong named snapshot origin")
    member = "reconstruction/supplements/" + path
    data = m.check_bytes(supplements[member], row["expected_sha256"], supplement["observed"]["bytes"])
    sources[path] = (data, dict(kind="named snapshot", path=supplement["path"], authority=authority,
                               provenance=provenance[path], materialized_from=dict(archive_reference, member=member,
                               member_sha256=m.digest(data), bytes=len(data))))


def supplemental_sources(candidate, members, sources, supplements, archive_reference):
    delta = m.parse_json(members["candidate/delta.json"])
    m.require(delta["base_commit"] == candidate["base"] and delta["candidate_source_digest"] == candidate["aggregate_sha256"], "Delta identity differs")
    changes = {row["path"]: row for row in delta["files"]}
    m.require(len(changes) == len(delta["files"]) == 40, "Wrong delta count")
    provenance = m.parse_json(members["inputs/restoration-provenance.json"])["provenance"]
    for row in candidate["files"]:
        add_origin(row, members, sources, changes, provenance, supplements, archive_reference)
    m.require(sum(item[1]["kind"] == "metadata delta member" for item in sources.values()) == 40, "Missing delta origins")
    m.require(sum(item[1]["kind"] == "named snapshot" for item in sources.values()) == 9, "Missing snapshot origins")


def dependency_sources(root, output, temporary, dependency, expected, bundle):
    m.check_bytes(bundle, "6f9f27199b2cc4bf47e7f04fd3d1862362899be283d84ec1e97c614b69a03580", 1471282)
    bundle_path = temporary / "inputs/epoll-registration-rollback.bundle"
    with bundle_path.open("xb") as stream:
        stream.write(bundle)
    bundle_path.chmod(0o444)
    database = temporary / "objects.git"
    fresh_destination(database)
    run_git(root, output, "git-init", ["init", "--bare", "--template=", "--initial-branch=source-evidence", str(database)])
    run_git(root, output, "bundle-import", ["bundle", "unbundle", str(bundle_path)], database)
    identity = dependency["identity"]
    commit = identity["commit"]
    actual = run_git(root, output, "commit", ["rev-parse", "--verify", commit + "^{commit}"], database).decode().strip()
    tree = run_git(root, output, "tree", ["rev-parse", "--verify", commit + "^{tree}"], database).decode().strip()
    m.identity(actual, tree, "c223bd886c6a51d2cd60def39dd9a68d701fea73", "86c6944f53dc009d7503a9ab0bc873aef3cd7b79")
    raw_commit = run_git(root, output, "raw-commit", ["cat-file", "commit", commit], database)
    m.require(m.git_object("commit", raw_commit) == commit and raw_commit.startswith(("tree " + tree + "\n").encode()), "Packed commit mismatch")
    raw_tree = run_git(root, output, "raw-tree", ["cat-file", "tree", tree], database)
    m.require(m.git_object("tree", raw_tree) == tree, "Packed tree mismatch")
    run_git(root, output, "fsck", ["fsck", "--full", "--strict", "--no-reflogs", commit], database)
    m.require(run_git(root, output, "remotes", ["remote"], database) == b"", "Unexpected remote")
    raw = run_git(root, output, "libxev-tree", ["ls-tree", "-r", "-z", commit], database)
    listing = m.regular_tree(raw)
    m.exact_set(listing, expected)
    object_ids = [value["object"] for value in listing.values()]
    raw = run_git(root, output, "libxev-blobs", ["cat-file", "--batch"], database, ("\n".join(object_ids) + "\n").encode())
    blobs = m.batch_blobs(raw, object_ids)
    sources = {path: (m.check_bytes(blobs[value["object"]], expected[path]), dict(kind="packed Git blob", commit=commit, tree=tree, **value))
               for path, value in listing.items()}
    return sources, dict(commit=commit, tree=tree, fsck="full strict passed", remotes=[], packed_root_tree_sha1=tree)


def export_sources(destination, sources, expected):
    c2.validate_sources(sources, expected)
    fresh_destination(destination)
    c2.export_sources(destination, sources, expected)


def tree_state(root, excluded):
    if not root.exists() and not root.is_symlink():
        return dict(path=str(root), status="absent", files=[], directories=[])
    m.require(root.is_dir() and not root.is_symlink(), "Nonregular protected root")
    files = []
    directories = []
    for directory, names, leaves in os.walk(root, followlinks=False):
        current = Path(directory)
        directories.append(dict(path=str(current), mode=oct(stat.S_IMODE(current.lstat().st_mode))))
        m.require(not any((current / name).is_symlink() for name in names), "Symlink protected directory")
        for name in leaves:
            path = current / name
            if str(path) in excluded:
                continue
            files.append(c2.observed(path))
    return dict(path=str(root), status="directory", files=sorted(files, key=lambda row: row["path"]),
                directories=sorted(directories, key=lambda row: row["path"]))


def compare_states(expected, actual):
    m.require(expected == actual, "Protected file identities/modes or directory paths/modes changed")


def privacy_exclusions(root):
    path = root / "docs/implement-2-2-0/evidence/m2_h2_native_post/native-post.tar.gz"
    pin = "d19281da19d04c3afbc3bb97ef614b21efa3746f0dc405dfb982d7cc959fbe92"
    m.check_bytes(c2.regular_file(path), pin)
    member = "native/evidence/native-post/privacy-publication-inputs/manifest.json"
    with tarfile.open(path, "r:gz") as archive:
        names = m.tar_members(archive.getmembers())
        m.require(member in names, "Privacy projection authority missing")
        data = archive.extractfile(member).read()
        m.check_bytes(data, "261fa25fa106d49147bc4d08cd08fd438b42d16090ea91431784e9fd0bc673d3")
        substitutions = m.parse_json(data)["substitutions"]
        public_bytes = {row["original_member"]: archive.extractfile(row["original_member"]).read() for row in substitutions}
    m.check_bytes(data, "261fa25fa106d49147bc4d08cd08fd438b42d16090ea91431784e9fd0bc673d3")
    native = root / ".uwz-work/evidence/h2-streaming/combined-native"
    published = native / "evidence/native-post/privacy-publication-inputs/manifest.json"
    m.require(c2.regular_file(published) == data, "Reviewed replacement map changed")
    substitutions = m.parse_json(data)["substitutions"]
    m.require(len(substitutions) == 25, "Wrong privacy substitution count")
    excluded = []
    projections = []
    for row in substitutions:
        original = row["original_member"]
        m.require(original.startswith("native/"), "Wrong privacy original scope")
        relative = m.safe_path(original[len("native/"):])
        excluded.append(str(native / relative))
        replacement = published.parent / m.safe_path(row["replacement"])
        projection = c2.observed(replacement)
        m.require(projection["sha256"] == m.digest(public_bytes[original]), "Reviewed public projection differs")
        projections.append(projection)
    m.require(len(set(excluded)) == 25, "Duplicate privacy originals")
    return frozenset(excluded), projections


def current_source_authorities(root):
    evidence = root / "docs/implement-2-2-0/evidence"
    authorities = (
        ("m2_h2_native_connection/native-connection.tar.gz", "c0bdf2032aedfeea034e08edc4b2ab170f122931df10e419bc9f12a57f9f96f9"),
        ("m2_h2_native_disconnect/native-disconnect.tar.gz", "a699c83b373b1ed0c4d976a179ac4d2d7c9453344211e87ce1d6b89fc1f4a4b8"),
        ("m2_h2_native_active/native-active.tar.gz", "6fda8cfaac4b8c866ff352848c12397a9775a7bd09397f1db7c9740707c50b14"))
    for relative, pin in authorities:
        m.check_bytes(c2.regular_file(evidence / relative), pin)
    relative, pin = authorities[-1]
    members = archive_members(evidence / relative, pin, inventory_name="INVENTORY.json")
    native = root / ".uwz-work/evidence/h2-streaming/combined-native"
    combined = root / ".uwz-work/evidence/h2-streaming/integration-owned/combined-cases"
    current = {name[len("source/current/"):]: data for name, data in members.items() if name.startswith("source/current/")}
    reference = {name[len("reference/combined/"):]: data for name, data in members.items() if name.startswith("reference/combined/")}
    m.require(len(current) == 7 and len(reference) == 46, "Wrong current authority source counts")
    coordinator = members["source/canonical/coordinator.py"]
    m.check_bytes(coordinator, "6585ad2323ce38a75948c7c365ceb7b9589c06e1c6010ae01ba35de0f11e6b32")
    reference["coordinator.py"] = coordinator
    for name, data in current.items():
        m.require(c2.regular_file(native / m.safe_path(name)) == data, "Current native7 drift")
    for name, data in reference.items():
        m.require(c2.regular_file(combined / m.safe_path(name)) == data, "Current combined46 drift")
    return dict(native_files=7, combined_files=46, coordinator_sha256=m.digest(coordinator),
                source_authority_archive=str(evidence / relative), source_authority_sha256=pin)


def preservation(root, excluded):
    base = root / ".uwz-work/evidence/h2-streaming"
    scopes = [base / name for name in ("combined-native", "integration-owned/combined-cases", "native-input-preparation")]
    scopes.append(root / "docs/implement-2-2-0/evidence")
    identity_path = base / "integration-owned/combined-cases/evidence/coordinator-a/immutable-inputs.json"
    identity = m.parse_json(c2.regular_file(identity_path))
    physical = {Path(row["path"]).resolve() for row in identity["identities"]}
    physical.update(Path("/tmp/uwz-h2-client-tooling/packages") / name for name, _ in identity["codec_files"])
    m.require(identity["identity_entries_checked"] == 119 and len(identity["identities"]) == 118 and len(identity["codec_files"]) == 42, "Historical closure count drift")
    temporary_roots = {Path("/tmp") / path.relative_to("/tmp").parts[0] for path in physical if path.is_relative_to("/tmp")}
    scopes.extend(sorted(temporary_roots))
    scopes.extend(Path(name) for name in ("/tmp/uwz-h2-combined-c2", "/tmp/uwz-h2-combined-c2-fix1", "/tmp/uwz-reviewed-libxev-c223-loop-callbacks"))
    states = [tree_state(path, excluded) for path in sorted(set(scopes))]
    return dict(scopes=states, closure_files=[c2.observed(path) for path in sorted(physical) if str(path) not in excluded],
                excluded_private_originals=25, historical_directory_state="unproved; fresh forward observations only")


def load_inputs(root, output):
    evidence = root / "docs/implement-2-2-0/evidence"
    authorities = (
        ("m2_h2_native_source_preparation", "native-source-preparation.tar.gz", "3c6d55ddc6a9d58445d1635a79186135f230c476eaba97257685649f7481e7de", "INVENTORY.json"),
        ("m2_h2_combined_input_audit", "combined-input-audit.tar.gz", "4c4d93bdec76e4b302a38e5811062b48100df0b617f479fe17eac1bdaa6105c8", "INVENTORY.json"),
        ("m2_h2_metadata_live", "metadata-live.tar.gz", "a08dbf448de76b3642816b0eed9388b59d83356b0d3d1fc8a7025b3718ec7d59", "inventory.json"),
        ("m2_h2_combined_fixture", "combined-fixture.tar.gz", "c731e84571477286905ed9116fe8f3e6d820d492e6696fb3382947def8cb38c9", "inventory.json"))
    archives = {name: archive_members(evidence / name / filename, pin, inventory_name=inventory) for name, filename, pin, inventory in authorities}
    native = archives["m2_h2_native_source_preparation"]
    m.check_bytes(native["packet/metadata.py"], "e02b74fc103ae5ac30318a98f83241ab1b4e469b30301ccbe5c93c1f29067430")
    m.check_bytes(native["packet/prepare.py"], "406a48d1740e757ebfd124f5b78e0098d06d7a323ecbc384aa4301a77397c92f")
    c1 = archives["m2_h2_combined_input_audit"]
    candidate, dependency, index = (m.parse_json(c1["packet/" + name]) for name in
                                   ("final-candidate-reconstruction.json", "dependency-audit.json", "final-input-index.json"))
    for name, filename, pin, _ in authorities[1:]:
        anchor = "cbdadc8bad2a6f1adb2dddb0b416da45caf96125" if name == "m2_h2_combined_input_audit" else "58bc6d6a525e01380ccc7bf3802e695c07877e89"
        relative = "docs/implement-2-2-0/evidence/" + name + "/manifest.json"
        raw = run_git(root, output, "anchor-" + name, ["cat-file", "blob", anchor + ":" + relative])
        manifest = m.parse_json(raw)
        m.require(manifest["archive_sha256"] == pin and manifest["archive"] == filename, "Pinned manifest authority differs")
        if name in index["authorities"]:
            m.check_bytes(raw, index["authorities"][name]["manifest_sha256"])
    expected, dependency_expected, _ = c2.source_inventories(candidate, dependency, archives)
    c2_facts = m.parse_json(native["packet/origin-authorities.json"])
    m.require(c2_facts["base"]["commit"] == candidate["base"] and c2_facts["bundle"]["sha256"] == dependency["bundle_sha256"], "C2 origin anchors differ")
    c2_audit = m.parse_json(native["packet/fix1normal-audit.json"])
    m.require(c2_audit["candidate"]["count"] == 1031 and c2_audit["libxev"]["count"] == 93, "Authenticated C2 export counts differ")
    return archives, candidate, dependency, expected, dependency_expected


def execute():
    root = Path("/workspaces/uWebZockets")
    output = root / ".uwz-work/evidence/h2-streaming/native_input_rehydration"
    temporary = Path("/tmp/uwz-h2-native-rehydration-c7")
    fresh_destination(temporary)
    excluded, projections = privacy_exclusions(root)
    source_authorities = current_source_authorities(root)
    before = preservation(root, excluded)
    c2.write_json(output / "preservation-before.json", before)
    c2.write_json(output / "safe-projections.json", projections)
    c2.write_json(output / "current-source-authorities.json", source_authorities)
    archives, candidate, dependency, expected, dependency_expected = load_inputs(root, output)
    sources = base_sources(root, output, candidate)
    reference = dict(archive="m2_h2_native_source_preparation", archive_sha256="3c6d55ddc6a9d58445d1635a79186135f230c476eaba97257685649f7481e7de")
    supplemental_sources(candidate, archives["m2_h2_metadata_live"], sources, archives[reference["archive"]], reference)
    c2.validate_sources(sources, expected)
    m.require(sum(len(data) for data, _ in sources.values()) == 103051479, "Wrong candidate byte total")
    compare_states(before, preservation(root, excluded))
    fresh_destination(temporary)
    temporary.mkdir(mode=0o700)
    for name in ("inputs", "evidence", "controls"):
        (temporary / name).mkdir(mode=0o700)
    dependency_data, packed = dependency_sources(root, output, temporary, dependency, dependency_expected,
                                                archives["m2_h2_combined_input_audit"]["packet/epoll-registration-rollback.bundle"])
    m.require(sum(len(data) for data, _ in dependency_data.values()) == 1347665, "Wrong libxev byte total")
    export_sources(temporary / "candidate", sources, expected)
    export_sources(temporary / "libxev", dependency_data, dependency_expected)
    actual_candidate = audit_export(temporary / "candidate", expected)
    actual_dependency = audit_export(temporary / "libxev", dependency_expected)
    m.require(actual_candidate["ordered_aggregate_sha256"] == candidate["aggregate_sha256"], "Export aggregate differs")
    m.exact_set([path.name for path in temporary.iterdir()], ("candidate", "libxev", "objects.git", "inputs", "evidence", "controls"))
    ledger = dict(candidate=c2.origin_ledger(sources, expected), libxev=c2.origin_ledger(dependency_data, dependency_expected))
    c2.write_json(output / "origin-ledger.json", ledger)
    after = preservation(root, excluded)
    c2.write_json(output / "preservation-after.json", after)
    compare_states(before, after)
    c2.write_json(output / "materialization-audit.json", dict(candidate=actual_candidate, libxev=actual_dependency,
                  packed_dependency=packed, root=str(temporary), protected_unchanged=True,
                  historical_directory_state="unproved", private_originals_read=False, native_executed=False, native_ready=False))
    print("Authenticated C7 candidate: 1031 files / 103051479 bytes; libxev: 93 files / 1347665 bytes; preservation unchanged")


def main(arguments):
    if len(arguments) != 2 or arguments[1] != "--prepare":
        return 2
    execute()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
