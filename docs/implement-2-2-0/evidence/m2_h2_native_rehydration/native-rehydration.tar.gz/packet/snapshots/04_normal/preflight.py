"""Read-only validation before the one exclusive materialization."""
from pathlib import Path
import sys

import rehydrate as p


def main():
    root = Path("/workspaces/uWebZockets")
    output = Path(__file__).parent / "preflight"
    p.fresh_destination(Path("/tmp/uwz-h2-native-rehydration-c7"))
    output.mkdir(mode=0o700)
    (output / "raw").mkdir(mode=0o700)
    excluded, projections = p.privacy_exclusions(root)
    authorities = p.current_source_authorities(root)
    archives, candidate, dependency, expected, dependency_expected = p.load_inputs(root, output)
    p.m.require(len(excluded) == len(projections) == 25, "Privacy count differs")
    p.m.require(len(expected) == 1031 and len(dependency_expected) == 93, "Source count differs")
    p.c2.write_json(output / "audit.json", dict(authorities=authorities, candidate_count=len(expected),
                    libxev_count=len(dependency_expected), privacy_excluded=25, native_executed=False))
    print("Preflight passed: immutable archive/index/manifest/source authorities, 25 safe projections, fresh destination")


if __name__ == "__main__":
    main()
