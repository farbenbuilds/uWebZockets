"""Source-only C7 reconstruction; importing performs no effects."""
