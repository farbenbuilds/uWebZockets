"""Verify retained C7 facts and emit bounded review observations."""
import hashlib
import json
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    packet = Path(__file__).parent
    before_data = (packet / "preservation-before.json").read_bytes()
    after_data = (packet / "preservation-after.json").read_bytes()
    require(before_data == after_data, "Protected forward baseline bytes differ")
    before = json.loads(before_data)
    audit = json.loads((packet / "materialization-audit.json").read_bytes())
    require(audit["candidate"]["count"] == 1031 and audit["libxev"]["count"] == 93, "Export count differs")
    require(sum(row["bytes"] for row in audit["candidate"]["files"]) == 103051479, "Candidate size differs")
    require(sum(row["bytes"] for row in audit["libxev"]["files"]) == 1347665, "Dependency size differs")
    scopes = {row["path"]: dict(status=row["status"], files=len(row["files"]), directories=len(row["directories"])) for row in before["scopes"]}
    base = "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/"
    require(scopes[base + "native-input-preparation"]["files"] == 809, "Historical C2 file count differs")
    native = next(row for row in before["scopes"] if row["path"] == base + "combined-native")
    transport_count = sum(row["path"].startswith(base + "combined-native/evidence/native-transport/") for row in native["files"])
    require(transport_count == 16169, "Historical transport proof count differs")
    hashes = {}
    names = ("rehydrate.py", "metadata.py", "test_rehydrate.py", "preflight.py", "summarize.py",
             "authority/prepare_c2.py", "authority/restore_inputs.py", "preservation-before.json", "preservation-after.json",
             "materialization-audit.json", "origin-ledger.json", "safe-projections.json", "current-source-authorities.json")
    for name in names:
        data = (packet / name).read_bytes()
        hashes[name] = dict(bytes=len(data), sha256=digest(data))
    result = dict(scopes=scopes, protected_regular_file_rows=sum(row["files"] for row in scopes.values()),
                  closure_physical_files=len(before["closure_files"]), transport_proof_files=transport_count,
                  candidate_files=1031, candidate_bytes=103051479, dependency_files=93, dependency_bytes=1347665,
                  candidate_aggregate=audit["candidate"]["ordered_aggregate_sha256"], hashes=hashes,
                  before_after_equal=True, private_originals_read=False, historical_directory_state="unproved",
                  actual_materializations=1, native_executed=False, native_ready=False)
    with (packet / "review-summary.json").open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
