"""Functional miniature reconstruction and rejection checks; no native work."""
import builtins
import importlib.util
import io
import json
from pathlib import Path
import socket
import ssl
import subprocess
import sys
import tarfile
import tempfile
from unittest.mock import patch


def require(condition, message):
    if not condition:
        raise ValueError(message)


def forbidden(*args, **kwargs):
    raise ValueError("Forbidden effect")


def inert_import():
    spec = importlib.util.spec_from_file_location("rehydrate", Path(__file__).with_name("rehydrate.py"))
    module = importlib.util.module_from_spec(spec)
    with patch.object(Path, "read_bytes", forbidden), patch.object(Path, "write_bytes", forbidden), patch.object(Path, "mkdir", forbidden):
        with patch.object(subprocess, "run", forbidden), patch.object(socket, "socket", forbidden), patch.object(ssl, "SSLContext", forbidden):
            spec.loader.exec_module(module)
            for arguments in ([], ["x", "--prepare", "/tmp/other"], ["x", "--prepare", "extra"], ["x", "--audit"]):
                require(module.main(arguments) == 2, "Rejected CLI must be inert")
    return module


def rejected(function, *arguments):
    try:
        function(*arguments)
    except (ValueError, KeyError, FileExistsError, FileNotFoundError):
        return
    raise ValueError("Expected rejection: " + function.__name__)


def miniature(p):
    data = b"archived supplement\n"
    provenance = "preserved-snapshot:.uwz-work/frozen/docs/source.md"
    authority = b'{"provenance": {"docs/source.md": "' + provenance.encode() + b'"}}'
    row = dict(path="docs/source.md", expected_sha256=p.m.digest(data), supplement=dict(
        path="/workspaces/uWebZockets/.uwz-work/frozen/docs/source.md", observed=dict(bytes=len(data)),
        authority=dict(archive="m2_h2_metadata_live", member="inputs/restoration-provenance.json", member_sha256=p.m.digest(authority))))
    members = {"inputs/restoration-provenance.json": authority}
    supplements = {"reconstruction/supplements/docs/source.md": data}
    return row, members, supplements, {"docs/source.md": provenance}


def test_reconstruction(p, root):
    row, members, supplements, provenance = miniature(p)
    sources = {"base.txt": (b"base", dict(kind="base Git blob"))}
    with patch.object(Path, "read_bytes", forbidden), patch.object(builtins, "open", forbidden):
        p.add_origin(row, members, sources, {}, provenance, supplements, dict(archive="mini", archive_sha256="0" * 64))
    sources["delta.txt"] = (b"delta", dict(kind="metadata delta member"))
    expected = {path: p.m.digest(data) for path, (data, _) in sources.items()}
    destination = root / "export"
    p.export_sources(destination, sources, expected)
    result = p.audit_export(destination, expected)
    require(result["count"] == 3 and sum(row["bytes"] for row in result["files"]) == 29, "Miniature exact files/bytes")
    rejected(p.export_sources, destination, sources, expected)
    destination.chmod(0o755)
    (destination / "empty").mkdir()
    rejected(p.audit_export, destination, expected)
    (destination / "empty").rmdir()
    destination.chmod(0o555)
    p.audit_export(destination, expected)


def test_supplements(p, root):
    row, members, supplements, provenance = miniature(p)
    reference = dict(archive="mini", archive_sha256="0" * 64)
    changed = dict(supplements)
    changed[next(iter(changed))] += b"!"
    rejected(p.add_origin, row, members, {}, {}, provenance, changed, reference)
    rejected(p.add_origin, row, members, {}, {}, provenance, {}, reference)
    rejected(p.add_origin, row, members, {}, {}, {row["path"]: "preserved-snapshot:other"}, supplements, reference)
    altered = json.loads(json.dumps(row))
    altered["supplement"]["authority"]["member_sha256"] = "0" * 64
    rejected(p.add_origin, altered, members, {}, {}, provenance, supplements, reference)


def test_paths(p, root):
    for name in ("../escape", "/absolute", "a//b", "a/./b", "a\\b", "a/.git/x", "a:b", "a\nq"):
        rejected(p.m.safe_path, name)
    rejected(p.m.inventory, [dict(path="a", sha256="0" * 64), dict(path="a/b", sha256="0" * 64)], 2)
    rejected(p.m.parse_json, b'{"a":1,"a":2}')
    parent = root / "link"
    parent.symlink_to(root, target_is_directory=True)
    rejected(p.fresh_destination, parent / "new")
    dangling = root / "dangling"
    dangling.symlink_to(root / "missing")
    rejected(p.fresh_destination, dangling)
    rejected(p.fresh_destination, root)
    p.fresh_destination(root / "new")


def test_directories(p, root):
    protected = root / "protected"
    protected.mkdir()
    (protected / "empty").mkdir()
    (protected / "file").write_bytes(b"fixed")
    before = p.tree_state(protected, frozenset())
    (protected / "added").mkdir()
    rejected(p.compare_states, before, p.tree_state(protected, frozenset()))
    (protected / "added").rmdir()
    (protected / "empty").rmdir()
    rejected(p.compare_states, before, p.tree_state(protected, frozenset()))
    (protected / "empty").mkdir()
    p.compare_states(before, p.tree_state(protected, frozenset()))
    (protected / "file").chmod(0o444)
    rejected(p.compare_states, before, p.tree_state(protected, frozenset()))
    absent = p.tree_state(root / "absent", frozenset())
    require(absent["status"] == "absent", "Absent root recorded")
    excluded = frozenset({str(protected / "file")})
    with patch.object(Path, "read_bytes", forbidden):
        require(not p.tree_state(protected, excluded)["files"], "Excluded private originals never read")


def write_tar(path, entries):
    with tarfile.open(path, "w:gz") as archive:
        for name, data, kind in entries:
            member = tarfile.TarInfo(name)
            member.type = kind
            member.size = len(data)
            archive.addfile(member, io.BytesIO(data))


def test_archive(p, root):
    path = root / "mini.tar.gz"
    inventory = json.dumps({"a": dict(size=1, sha256=p.m.digest(b"a"))}).encode()
    entries = [("a", b"a", tarfile.REGTYPE), ("INVENTORY.json", inventory, tarfile.REGTYPE)]
    write_tar(path, entries)
    require(p.archive_members(path, p.m.digest(path.read_bytes()), inventory_name="INVENTORY.json")["a"] == b"a", "Authenticated miniature")
    rejected(p.archive_members, path, "0" * 64, None, "INVENTORY.json")
    for extra in (("a", b"a", tarfile.REGTYPE), ("../x", b"x", tarfile.REGTYPE), ("link", b"", tarfile.SYMTYPE), ("a/b", b"b", tarfile.REGTYPE)):
        write_tar(path, entries + [extra])
        rejected(p.archive_members, path, p.m.digest(path.read_bytes()), None, "INVENTORY.json")


def main():
    p = inert_import()
    tests = (test_reconstruction, test_supplements, test_paths, test_directories, test_archive)
    for test in tests:
        with tempfile.TemporaryDirectory(prefix="uwz-c7-mini-") as directory:
            test(p, Path(directory))
        print(test.__name__ + ": passed")
    print("inert_import_and_rejected_cli: passed; optimization=" + str(sys.flags.optimize))


if __name__ == "__main__":
    main()
