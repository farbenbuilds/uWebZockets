#!/bin/bash
set -eu
export PYTHONDONTWRITEBYTECODE=1
export PATH=/usr/bin:/bin
export PYTHONPATH=/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native_input_rehydration
packet=/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native_input_rehydration
python=/home/codespace/.python/current/bin/python3
sha256sum -c "$packet/snapshots/02_normal/controls.sha256"
"$python" -B -S "$packet/authority/restore_inputs.py" --restore "$packet/raw/02_restore.json"
"$python" -B -S "$packet/test_rehydrate.py"
