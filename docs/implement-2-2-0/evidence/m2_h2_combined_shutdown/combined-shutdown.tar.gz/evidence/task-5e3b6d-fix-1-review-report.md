Original P2: ADDRESSED. Ordinary collections now retain their actual parsed
records/metrics on the context while preserving the None return. The serialized
regression checks wildcard diagnostics, unchanged state/deadlines and retrieval
without additional requests.

New breakage — P2: Protect shutdown's before snapshot from teardown hooks.
adapter.py:393 publishes the capture on the context and returns that same
mutable object to shutdown. Subsequent teardown hooks receive the context,
exposing the comparison baseline that was previously private.

A focused pure in-memory sensitivity check confirmed:

- Parsed active record initially has max_span32.
- Post hook changes current.final_observations.records.shutdown_active.max_span
  to7 and returns a post record with max_span7.
- adapter.run_case succeeds: validation compares altered baseline and result.
- Only the outer test's independently retained application record detects it.

This bypasses preservation of actual observed nonterminal diagnostics. Keep
the shutdown baseline private through teardown hooks and publish the retained
capture afterward, or provide equivalent mutation protection. Preserve immediate
ordinary capture and add an alias-path regression. Snapshot protection must
include attached output/binding observations.

The focused pinned -B -S in-memory check exited successfully with:

    CONFIRMED: run_case accepted max_span 32->7 after post hook rewrote exposed before baseline; only outer test detected capture mutation

Fix-round verdict: SPEC FAIL / QUALITY NEEDS FIXES. Original finding resolved;
new actionable aliasing regression. No other new breakage in the three-file diff.

Root's audit supplies six current covering receipts and42 preceding receipts.
Reviewer did not rerun them or reproduce the identity audit; no files changed.
Default/subset orchestration, combined all40/native/broad gates remain outside
this source re-review. Full focused command remains in the reviewer's tool
transcript; the diagnostic above is the returned receipt, not an invented command.
