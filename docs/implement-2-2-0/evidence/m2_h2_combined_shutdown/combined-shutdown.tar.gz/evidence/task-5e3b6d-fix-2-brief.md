# B6d fix round2/5

Open new P2 from task-5e3b6d-fix-1-review-report.md: immediate publication of
the same shutdown before object exposes the comparison baseline to teardown
hooks. Original ordinary-capture P2 is addressed and must remain addressed.

Root ruling: retain immediate ordinary context capture/None return, but keep
shutdown's actual before records, metrics and attached outputs/binding private
through every teardown hook and validation. Publish the retained shutdown
capture only after successful teardown comparison, or enforce equivalent
mutation protection. One bounded capture need not be exposed early. Root's
earlier single-capture instruction never permits a caller hook to rewrite its
comparison baseline. Preserve existing counts, deadlines, serialization and
caller contracts; no generic framework, extra requests or model substitution.

Before edits preserve the reviewed fix1 sources/report and all42+6 preceding
receipts. Add a focused actual RED reproducing the alias path, including the
observed record diagnostic and output/binding protection. Test that hooks cannot
hide an after change by editing an exposed before object, and that ordinary
retention stays immediate. Do not rely only on an outer independent assertion:
the schedule itself must reject altered post evidence.

Covering tests are test_final.py, test_shutdown.py and test_imports.py in pinned
normal/-O after final edits. Preserve all prior-source proof distinctly; no broad
42 repeat unless a new failure/additional source change warrants it. Append
fix2 APIs/exact commands/raw RED-GREEN/current hashes/self-review to the same
task-5e3b6d-report.md. Refresh current snapshot, keep failed snapshots intact.
Root independently audits and asks the same reviewer to check the new fix diff.

Original ownership and strict source-only restrictions remain: no agents/Git/
public changes, native/probes/core/model/fixture/dependency/budget/deadline edits.
You are not alone; preserve others' work. Return short status/report/checks/
concerns only. Full goal and parent all40 acceptance remain incomplete.
