# Task5e3b6d: active and idle shutdown source schedules

The assigned source slice is implemented and ready for Root's independent review.
Both schedules pass their exact serialized finite contracts. There are now40
implemented source case IDs across35 modules. This is pure in-memory public-codec
verification with caller-supplied synthetic application and teardown facts.
It does not establish default/aggregate acceptance, a two-child all40 execution,
native callbacks, process ownership, socket/TLS close, or native post-deinit output.
No product, core, model, fixture, dependency, budget or deadline was changed.
No native/build/server/socket/SSLContext/real-clock/process operation ran.
No Git write, public documentation edit, subagent or external model CLI was used.

## Ownership, continuity and immutable inputs

The binding requirements are task-5e3b6d-brief.md, task-5e3b-release-addendum.md,
task-5e3b-cases-pending-brief.md and task-5e-combined-architecture.md.
Accepted B6c is95c975e73e376c81fb0caba838659b745b362879; the before33-module
map matches docs/implement-2-2-0/evidence/m2_h2_combined_disconnect_reuse/manifest.json.
Before source, initial serialized test, intermediate sources and every raw
receipt remain under the owned combined-cases/evidence/b6d directory. All paths
below are relative to .uwz-work/evidence/h2-streaming/integration-owned/combined-cases
unless explicitly rooted elsewhere. Root owns review, publication, commit and push.

The actual active source authority was read only at
/tmp/uwz-task5c3-runtime-v2/lifecycle_cases.py220 onward. The idle baseline
was read only from integration-owned/credit/fix1/run_live.py403..447:
final capture, normal client close, owned SIGTERM, successful reap and unchanged
post-deinit records/metrics. None of those old entrypoints or close helpers ran.
Current immutable model/catalogue and fixture supersede older record aliases.

The immutable core remains /tmp/uwz-task5e3a-snapshot-v9/source,26 modules;
model/catalogue remain /tmp/uwz-task5e1-contract-v3; fixture remains
/tmp/uwz-task5e2-Fix1Final2/fixture,25 canonical files. The pinned helper is
integration-client/h2_client.py with SHA256
07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00.
Final audit rehashed every retained input and42 codec files in their retained
order, checked their exact current file set, and reproduced SHA256 of default
json.dumps(rows).encode():
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
The exact file rows and recipe are in evidence/b6d/immutable-inputs.json and
final-audit.command. There are119 retained identity entries:118 file rows,
113 unique resolved file paths, plus one codec aggregate,114 unique entries.
These are not119 distinct files. The pinned Python path, resolved binary,
byte length and SHA256 are in evidence/b6d/python-identity.json.

The published B6c archive was checked against its manifest SHA256, and all472
published raw evidence files matched the current prior evidence byte-for-byte.
The complete comparison is evidence/b6d/preserved-history.json. No historical
source or raw result was replaced. B6d source comparison is2 added,8 changed,
25 unchanged and0 removed modules; evidence/b6d/source.diff is the exact diff.

## Actual interfaces and state ownership

New shutdown_cases.py contains run(context,receive,hooks), active, idle and
concrete validators for supplied teardown facts. The active hooks dictionary
has exactly preconditions,signal,termination,process,post,units_per_second;
idle substitutes close for termination. All except units_per_second must be
callable; units_per_second must be a strictly positive integer and rejects bool.
All hooks receive context; only preconditions receives no deadline argument.
The other hooks receive (context,deadline). They are pure caller operations;
this module never owns a real signal, wait, close or process.

Active preconditions must be exactly {client_open:True,prior_complete:True}.
Idle preconditions must be exactly {client_open:True,fresh_application:True},
and selected_before must be empty. adapter.open_case rejects idle with a prior
selection before startup effects. Global catalogue ordering/unknown/malformed/
duplicate validation remains in place; active must be last and idle first.

Signal evidence is exactly signal=SIGTERM,owned_identity=True,
watcher_installed=True,client_open=True for active orFalse for idle. Strict
scalar types are checked. Process evidence is exactly exit_code=integer0,
reaped=True,forced=False,run_ok=True,deinit_ok=True,key_removed=True. Active
termination is exactly phase=post_signal,outcome=eof|tls_eof,
primary_response=False,frames_valid=True,trailing_bytes=integer0. Idle close
is exactly method=close,client_closed=True,close=normal. This deliberately
uses the idle baseline's normal close fact, without inventing disconnect's
TLS unwrap/TCP EOF experiment.

Post evidence has exactly records,metrics,outputs,binding. model.validate_pre_post
validates all67 persistent records and permits only shutdown_active's one
cancellation, inactive/unpaused state and reason shutdown. Body bytes, digest,
chunks, max_span and every other record remain identical. model.validate_metrics
checks exact before/after totals and inactive post slots. Retained output
observations come from context.output_observations and context.output_binding:
the selected producer/file keys must exactly match selection. Values and binding
are copied before teardown, validated with model.validate_outputs and binding
validation, then compared by model.validate_output_pre_post. Unselected outputs
use exact model defaults. There are no extra output GETs or invented output
responses. Missing retained selected outputs fail before signal.

Grace uses supplied integer units, checked catalogue arithmetic and at most15
seconds, clipped to existing case and whole deadlines. Every hook completion
rechecks the original deadline pair and this grace deadline. Caller time is
monotonic via the existing adapter hook; no real clock is read or extended.

adapter.run_case(context,receive,*,disconnect=None,shutdown=None) is the actual
used dispatch seam. Both shutdown paths return context after exact counts and
terminal cleanup; existing ordinary and disconnect signatures/results remain.
adapter.final_collection(context,receive,*,held=None) now passes held to canonical
wire.enter_final and returns validated records/metrics for the two shutdown
cases. Ordinary calls still require completed state, use no held response and
return None. This preserves the previously released ordinary return contract.

Important remaining parent seam: ordinary final_collection still leaves its
validated records/metrics in local variables and does not retain them on context.
Legitimate subsets without active shutdown will need a separately reviewed
context-owned capture or explicit facts-return seam to perform their later
post-deinit comparison without extra GETs. Shutdown callers have those facts at
context.shutdown_observations.before; that object also retains copied outputs
and binding. This report identifies that parent seam and does not add coordinator
behavior or claim that ordinary subset teardown is complete.

adapter.start and observe reject any observation after the completed shutdown
collection enters context.shutdown_boundary, including while supplied teardown
hooks run. Active additionally uses the immutable stage.signal policy.
check_counts compares case_state.small + final_registered only when the
catalogue says final_included: canonical small counts pre-final responses and
canonical heads already includes final heads. No canonical counter was mutated,
and the68 final registrations are counted once. Root confirmed this accounting.

## Concrete serialization and boundary proof

| Case | Heads J | Small C | Request flow R | Primary |
| --- | ---: | ---: | ---: | ---: |
| shutdown_active |71|70|32|3|
| shutdown_idle |69|69|0|1|

Active sends health1, then exact model POST/target/query/x-case/content-length32
metadata on stream3 with transport/owned_shutdown policy and held=True. It sends
one32-byte canonical payload DATA frame without END and validates the accepted7,
paused record at one finite barrier. It then enters canonical held final collection
and requests67 statuses plus metrics exactly once. The active row must equal the
barrier, including unconstrained-but-bounded callback diagnostics. These68
observations belong inside71/70; no additional collection is appended.

The same stage, raw parser, response records and both credit ledgers survive the
boundary by object identity. The held response has no headers/body/reset/END,
and primary_complete staysFalse until transport termination. Connection debt32
and aggregate stream debt32 remain present at final entry; final_budget is
catalogue.final_budget(64),3065184 bytes. Existing case/whole deadlines30001 and
900001 remain unchanged in supplied integer units. Canonical enter_final and
finish_final enforce exact68 requests, held state, retired auxiliaries and
original parser/byte/read limits. Only afterward is supplied owned signal evidence
validated, output_stage.signal called and wire.begin_termination/finish_termination
paired with policy owned_shutdown and actual phase post_signal. Both eof and
tls_eof positive paths pass. No successful primary response or end callback is
fabricated, and no ordinary stage or ledger is cleared to enter final.

Idle creates a separate local application baseline and codec context with empty
selected_before. Its health stream1 is the completed canonical primary. It then
collects67 all-zero body rows and one metrics response, with buffered count69,
no active slots and no parser/response/credit residue. The supplied normal client
close precedes signal/process/post facts. No active-only signal stage transition
is invented for idle; a direct test confirms output_stage.signal rejects it.
The adapter prevents further observations after collection while validating
teardown facts. All zero records, metrics, default outputs and binding remain
unchanged through the supplied post-deinit comparison.

The test independently decodes outgoing frame headers and pinned HPACK, checks
all metadata and duplicate multiplicity in finite order, actual odd stream IDs,
HEADERS/DATA END flags, exact payload and H32 digest, one settings ACK, exact
heads/status/metrics counts, and empty serialization/response queues at signal.
Each send is at most8192 bytes; each test receive is finite and capped150 calls.
No upload/output bodies or per-DATA history are retained by the schedule.
The test keeps only a rolling request digest and bounded in-memory responses.

Five positive executions run per mode: fresh idle; standalone active; active
with seeded prior empty_headers/reuse; active tls_eof with2000 units/second and
case-clipped grace; active with seeded prior admission/reuse/all five outputs.
The latter retains all three producer observations, file observation and actual
relative B-binding shape (index1,generation18 after producer generation17).
Seeded records and diagnostics are synthetic preconditions. They do not execute
the earlier38 schedules or prove native shared application behavior.

Each final mode rejects75 exact synthetic controls. They include malformed hook
sets/callables/units, typed preconditions/signals/process/close facts, wrong signal,
wrong watcher/client-open/ownership evidence, forced or unreaped/failed teardown,
wrong termination phase/outcome/frames/primary response/trailing bytes, bool0
substitutions, early primary response, changed paused barrier, record/hash/metric
corruptions, deadline and grace expiry, parser residue, post-boundary observations,
post-deinit chunk/record/metric/output/binding changes and missing retained outputs.
These are pure sensitivity controls, not native fault or cancellation experiments.

## RED and complete intermediate history

The actual initial serialized test was saved before implementation at
initial-test_shutdown.py. Initial RED exits1 at unsupported selection before
serialization. It proves missing selection support only, not execution of any
serialized action. Every subsequent command has its exact .command, .stdout,
.stderr and .exit receipt. AttemptN source is in attempt-N-source for1..8;
final-source matches attempt9 and the final matrix. before-source contains the
accepted33-module starting bytes. No failing implementation was rolled back.

- Attempt1: idle harness expected grace recomputation at signal after close's
  time check. Corrected it to verify grace at close and retain the same deadline.
- Attempt2: adapter check_counts compared canonical pre-final small alone.
  Fixed it to add the canonical final registrations exactly once for included
  final cases, without mutating core counters or relaxing limits.
- Attempt3: seeded prior model recipes contained None chunk diagnostics; those
  are expected-value wildcards, not valid observed values. The harness now seeds
  bounded integer diagnostics for its synthetic prior application records.
- Attempt4: output corruption used nonexistent field closes, causing schema
  rejection before the intended value comparison. Corrected it to close_calls.
- Attempt5: parser residue prevents response completion and consumes the finite
  test queue; its actual rejection is finite response missing before final
  collection or signal. Corrected the expected message; parser behavior and
  the finite cap were not weakened.
- Attempt6: early held-primary payload is rejected by canonical raw parsing as
  unexpected closing target payload before the later stage check. Corrected
  that expected error without weakening either check.
- Attempt7: passed five positives and38 negatives. More typed and retained-output
  controls were then added; this is a historical pass, not final evidence.
- Attempt8: its first74 negatives passed; the prior-idle malformed selection is
  rejected by model/catalogue ordering before the intended later precondition,
  and the test's None label then caused TypeError. Corrected its label and exact
  earlier ordering expectation. Adapter also rejects idle with prior selection.
- Attempt9: passed five positives and75 negatives, followed by the final full
  relevant normal/-O matrix after all source edits.

The six inventory-red commands deliberately retain real failures from imports,
selection and four historical unsupported-count assertions. Once both schedules
passed, the exact2->0 corrections and40-case description were applied, preserving
all rejection loops. test_selection now additionally exercises malformed,
unknown, duplicate and active/idle ordering rejections. An empty unsupported set
has not removed general selection validation.

## Verification, scope limits and self-review

All42 final commands (21 test scripts in normal and optimized modes) exited0
with empty stderr. Python is /home/codespace/.python/current/bin/python3,
with -B -S and separately -B -S -O. This is Python optimization mode; no Zig
Debug/Release mode, native sanitizer result or measured performance is claimed.
All35 modules have one main guard, no authored classes/custom exceptions/assert
proof statements, and control depth at most3 (shutdown schedule1,test2).
Actual silent/inert imports under empty and foreign argv pass with rejecting
caller-owned open/socket/SSLContext/process/OS/time/stdout/stderr doubles.
The final changed-seam regressions include ordinary final collection, timing,
request/response credit, large payloads, all prior source families, disconnect
replacement and reuse, selection and imports. Every retained input was rehashed.

Self-review checked ownership and exact diff first: only the two new modules
and eight minimal adapter/selection/import/inventory seams changed. Existing
lifecycle and all25 other unchanged modules match accepted B6c byte identities.
Checked core API usage, strict fact schemas, final68 accounting, held terminal
ordering, inherited debts/deadlines and output snapshots next. Ordinary return
and replacement context contracts remain intact. No parser/codec substitute,
secondary refund, count/budget/deadline relaxation or test exclusion was added.
The root's independent source/spec/quality review remains required.

There is no immutable core/model API gap for this assigned slice. Remaining
parent work includes ordinary final-facts retention, complete default/empty/
subset and child-plan/global aggregate orchestration acceptance, runtime input
closure and a separately released sequential two-child41-connection native
all40 run with actual owned cleanup and post-deinit capture. Full project,
platform, fuzz, package and compliance matrices remain later work. The narrow
source-only release explicitly forbids broad native/build/socket/process gates,
so none of those were run or claimed here. Source coverage40 alone earns none
of those acceptance claims.

## Source snapshot and identities

The full retained input rows are evidence/b6d/immutable-inputs.json, the35 final
source hashes and depth audit are evidence/b6d/snapshot.json, and all472 unchanged
prior raw evidence hashes are evidence/b6d/preserved-history.json. Exact final
source map follows.

```json
{
  "base": "95c975e73e376c81fb0caba838659b745b362879",
  "source_files": {
    "adapter.py": "56550f86a5c4ed19d5ac2115b03c98b7166ef371d71b644712218d27b76f45f0",
    "admission_cases.py": "b4cac4031f9be16bca938f7167bb327f4eae4fd5667b42cb70fc23782f8fbbcf",
    "application_error_cases.py": "9d63d938391f2181205766c3297d9aae5ce6966d9f371251b9fa5aeb152d9e68",
    "cases.py": "f89fe655f8c66c98e67ffd7723b07980234e124b130a8a99a790cb80fc54bcd5",
    "concurrent_cases.py": "a9ab3e7b6f6a362c1c6d33788fa8b7c3ed5961989be1f58d7fd6cc66a998a7c1",
    "continue_quota_cases.py": "da533ef0fde4179c00427d11b689cba1fdf248e41ba01c98a47f37a08ec99e95",
    "control_reset_cases.py": "36b8fe72e24eaf8cb7a30b470ea4c23823f324373ac3d4d90a6cc8a1595979d7",
    "credit_cases.py": "f953e2bacb92c4370904cf2b6e302a215aed9bd28210290406aac965e8d2178d",
    "file_early_cases.py": "90479c670ee1d75c4974704bb6b51d4543142c80c10a8b01963a1a31e0dc9d8c",
    "lifecycle_cases.py": "3aeb930ef537ac4690ba3f0b5deaffd3a1770981e247652f9fb2f77ffd98a92c",
    "metadata_cases.py": "7a48599c53779a2414f4492371174d35030e91d1dd61570408248b7eae12b83c",
    "pause_cases.py": "c7e28527478f3a3e52de22de019e1698083a8d03b4bca3100dd4788e77a8f250",
    "producer_pressure_cases.py": "44cb04ab3eee53c50c8cd508244486ef6693646aa276836e244a9fb18caffbda",
    "shutdown_cases.py": "5e1bb82c571a8dd15f1552524769d5cfbeb63cd3de6fc63053b98af9b5bf658d",
    "test_adapter.py": "ef325e804d454e12a4f8b2d2dfa2e0c778736758cf8618334081c864940aefbf",
    "test_admission.py": "28b88c1b8dcdccc03154cb7472cf14ce0f3819de54b78d72e9fec68608381d9d",
    "test_application_error.py": "221d38b7d31fc419d990df1ce512f9cdc509e7c3a9eb1f9c4ef961a43b82c96c",
    "test_async.py": "bcf31ec8037b3ba4861d25e7983efaeef269df5c084dc3922cc358d8e94ae314",
    "test_continue_quota.py": "71ed633a7d9151dcacc99f4665b1ae45e9423ee7dc589e9607e280a67bdf9914",
    "test_control_reset.py": "7b81f969a0cd5146ac5ac075bd2cc2d25aca890c021db4ab73f828eb04780d67",
    "test_credit.py": "bd03e99dbe6d1297bc96badf870c4be7486ef2524a14befd323bbebb8a9e0a65",
    "test_file_early.py": "8feb6e45339160eb28b19a5635a22eba58cc8206f6f127975739201b0d045604",
    "test_final.py": "bbcd200d37e232ca43fb417b4a757d88fe86bb186319f64bd4bf99e534ded694",
    "test_imports.py": "1e140df0da86cfee854664cbc954842e9d51d346d210744f59057ba693e20353",
    "test_large.py": "5710cb5be11f777f2c0ba4f0b3a647227f75b5955dcf1f8cecd750419b46c7d0",
    "test_lifecycle.py": "7346386e3482a800bfe20b0dc8da8726dc66d6dd8a516ac038de4222a21f535a",
    "test_metadata_concurrency.py": "21708e73da3f401891b975414578ce136ac40a8848cfa730f429e17d9251294d",
    "test_negative.py": "91ae248806c1402bd4219474c3e08e1ef2fcb5994d3e6f7b5e7f40fac4ec47f0",
    "test_pause.py": "86f3faa897d8c278dfeef4f7359194b3eea5e1b284ba46bf012ecc6f569c291e",
    "test_producer_pressure.py": "79dc174853ad5285c37e6f36368199d20d403f3afa488e80a32a04faa036ff51",
    "test_ready.py": "600ec8b0bc072aa4d9a52417425e77c56edc2e02680bdb01d9d288c52001b442",
    "test_selection.py": "eae469c25524ddaa3b02c0474dcebae605ba0d64846d8ae50de57a76b8f57aa3",
    "test_shared.py": "cbd3370c4dd56990c126939503a35dd5eabd8a03ce71195865152510a973b91b",
    "test_shutdown.py": "bd4b62e72fc4d8051104675fed8994a25a51fbc042e0d1fc1f3f7fc755e5a69c",
    "test_time.py": "0e10a1c68bfdd754b67a656bd8f4cc05ca8fcf8c9af63ab66130e2e969edf967"
  },
  "added": [
    "shutdown_cases.py",
    "test_shutdown.py"
  ],
  "changed": [
    "adapter.py",
    "cases.py",
    "test_admission.py",
    "test_continue_quota.py",
    "test_imports.py",
    "test_metadata_concurrency.py",
    "test_pause.py",
    "test_selection.py"
  ],
  "unchanged": [
    "admission_cases.py",
    "application_error_cases.py",
    "concurrent_cases.py",
    "continue_quota_cases.py",
    "control_reset_cases.py",
    "credit_cases.py",
    "file_early_cases.py",
    "lifecycle_cases.py",
    "metadata_cases.py",
    "pause_cases.py",
    "producer_pressure_cases.py",
    "test_adapter.py",
    "test_application_error.py",
    "test_async.py",
    "test_control_reset.py",
    "test_credit.py",
    "test_file_early.py",
    "test_final.py",
    "test_large.py",
    "test_lifecycle.py",
    "test_negative.py",
    "test_producer_pressure.py",
    "test_ready.py",
    "test_shared.py",
    "test_time.py"
  ],
  "removed": [],
  "control_depth": {
    "adapter.py": 3,
    "admission_cases.py": 2,
    "application_error_cases.py": 1,
    "cases.py": 1,
    "concurrent_cases.py": 2,
    "continue_quota_cases.py": 2,
    "control_reset_cases.py": 1,
    "credit_cases.py": 1,
    "file_early_cases.py": 2,
    "lifecycle_cases.py": 2,
    "metadata_cases.py": 1,
    "pause_cases.py": 2,
    "producer_pressure_cases.py": 1,
    "shutdown_cases.py": 1,
    "test_adapter.py": 2,
    "test_admission.py": 3,
    "test_application_error.py": 2,
    "test_async.py": 1,
    "test_continue_quota.py": 3,
    "test_control_reset.py": 2,
    "test_credit.py": 3,
    "test_file_early.py": 3,
    "test_final.py": 1,
    "test_imports.py": 3,
    "test_large.py": 1,
    "test_lifecycle.py": 3,
    "test_metadata_concurrency.py": 3,
    "test_negative.py": 3,
    "test_pause.py": 3,
    "test_producer_pressure.py": 3,
    "test_ready.py": 3,
    "test_selection.py": 1,
    "test_shared.py": 3,
    "test_shutdown.py": 2,
    "test_time.py": 1
  }
}
```

## Exact commands and raw outcomes

The following are retained verbatim from the receipt files. Empty stdout/stderr
are explicitly stated. Native operations are absent.

### initial-red

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 244, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 220, in main
    check('shutdown_idle')
    ~~~~~^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 121, in check
    context = adapter.open_case(case, h2_client.new_protocol(), send, 1, 30001, 900001, selected_before=prior, clock=clock)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 18, in open_case
    cases.select((case,))
    ~~~~~~~~~~~~^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/cases.py", line 10, in select
    raise ValueError('case schedule not implemented')
ValueError: case schedule not implemented
```

### attempt-1

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 244, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 220, in main
    check('shutdown_idle')
    ~~~~~^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 198, in check
    adapter.run_case(context, receive, shutdown=hooks)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 264, in run_case
    shutdown_cases.run(context, receive, shutdown)
    ~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/shutdown_cases.py", line 137, in run
    idle(context, receive, hooks)
    ~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/shutdown_cases.py", line 119, in idle
    signal = hooks['signal'](context, deadline)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 136, in signal
    require(deadline == min(current['now'] + 15 * units, 30001, 900001), 'grace deadline differs')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 17, in require
    raise RuntimeError(message)
RuntimeError: grace deadline differs
```

### attempt-2

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 246, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 222, in main
    check('shutdown_idle')
    ~~~~~^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 200, in check
    adapter.run_case(context, receive, shutdown=hooks)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 265, in run_case
    check_counts(context)
    ~~~~~~~~~~~~^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 371, in check_counts
    raise ValueError('case counts differ')
ValueError: case counts differ
```

### attempt-3

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `1`.

stdout:

```text
shutdown_idle passed: J=69 C=69 R=0 request_sha256=e010c1916e8ddc1a1d9996511a5848c861714acc6d31c325ce6e94f9e9db99a9
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
```

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 246, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 224, in main
    check('shutdown_active', prior=('empty_headers', 'reuse'))
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 200, in check
    adapter.run_case(context, receive, shutdown=hooks)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 264, in run_case
    shutdown_cases.run(context, receive, shutdown)
    ~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/shutdown_cases.py", line 135, in run
    active(context, receive, hooks)
    ~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/shutdown_cases.py", line 81, in active
    before = adapter.final_collection(context, receive, held=stream)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 387, in final_collection
    model.validate_records(selection, 'before', records)
    ~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e1-contract-v3/model.py", line 179, in validate_records
    validate_item(actual[tag],target)
    ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e1-contract-v3/model.py", line 158, in validate_item
    chunks, span = unsigned(actual['chunks']), unsigned(actual['max_span'])
                   ~~~~~~~~^^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e1-contract-v3/model.py", line 60, in unsigned
    require(type(value) is int and 0 <= value <= U64, 'u64 required')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e1-contract-v3/model.py", line 56, in require
    raise ValueError(message)
ValueError: u64 required
```

### attempt-4

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `1`.

stdout:

```text
shutdown_idle passed: J=69 C=69 R=0 request_sha256=e010c1916e8ddc1a1d9996511a5848c861714acc6d31c325ce6e94f9e9db99a9
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
```

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 218, in rejected
    check(case, fault=fault)
    ~~~~~^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 205, in check
    adapter.run_case(context, receive, shutdown=hooks)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 264, in run_case
    shutdown_cases.run(context, receive, shutdown)
    ~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/shutdown_cases.py", line 135, in run
    active(context, receive, hooks)
    ~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/shutdown_cases.py", line 102, in active
    post_deinit(context, hooks, deadline, before, selection)
    ~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/shutdown_cases.py", line 67, in post_deinit
    model.validate_output_pre_post(selection, retained, post['outputs'], binding_before=binding, binding_after=post['binding'])
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e1-contract-v3/model.py", line 384, in validate_output_pre_post
    validate_outputs(selection,after)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e1-contract-v3/model.py", line 318, in validate_outputs
    diagnostic_schema(item,PRODUCER_NUMBERS if tag in PRODUCERS else FILE_NUMBERS,('armed','done') if tag in PRODUCERS else ('transferred','caller_owned'),('tag','sha256') if tag in PRODUCERS else ('tag',))
    ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e1-contract-v3/model.py", line 256, in diagnostic_schema
    require(type(item) is dict and item.keys()==set(numbers+booleans+strings), 'diagnostic schema')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e1-contract-v3/model.py", line 56, in require
    raise ValueError(message)
ValueError: diagnostic schema

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 251, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 240, in main
    rejected(case, fault, message)
    ~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 220, in rejected
    require(str(error) == message, 'wrong rejection for ' + fault + ': ' + str(error))
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 17, in require
    raise RuntimeError(message)
RuntimeError: wrong rejection for post_output: diagnostic schema
```

### attempt-5

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `1`.

stdout:

```text
shutdown_idle passed: J=69 C=69 R=0 request_sha256=e010c1916e8ddc1a1d9996511a5848c861714acc6d31c325ce6e94f9e9db99a9
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
```

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 218, in rejected
    check(case, fault=fault)
    ~~~~~^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 205, in check
    adapter.run_case(context, receive, shutdown=hooks)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 264, in run_case
    shutdown_cases.run(context, receive, shutdown)
    ~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/shutdown_cases.py", line 137, in run
    active(context, receive, hooks)
    ~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/shutdown_cases.py", line 81, in active
    before = adapter.final_collection(context, receive, held=stream)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 388, in final_collection
    observed = metrics(context, receive)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 186, in metrics
    result = get(context, '/metrics', receive)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 169, in get
    return finish(context, start(context, 'GET', path, (), True, primary, limit, middleware), receive)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 146, in finish
    data, now = receive()
                ~~~~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 120, in receive
    require(state['pending'] and state['reads'] <= 150, 'finite response missing')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 17, in require
    raise RuntimeError(message)
RuntimeError: finite response missing

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 251, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 240, in main
    rejected(case, fault, message)
    ~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 220, in rejected
    require(str(error) == message, 'wrong rejection for ' + fault + ': ' + str(error))
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 17, in require
    raise RuntimeError(message)
RuntimeError: wrong rejection for parser_residue: finite response missing
```

### attempt-6

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `1`.

stdout:

```text
shutdown_idle passed: J=69 C=69 R=0 request_sha256=e010c1916e8ddc1a1d9996511a5848c861714acc6d31c325ce6e94f9e9db99a9
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
active_hash rejected: record mismatch: sha256
barrier_changed rejected: shutdown barrier changed before signal
post_chunks rejected: shutdown changed nonterminal evidence
```

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 218, in rejected
    check(case, fault=fault)
    ~~~~~^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 205, in check
    adapter.run_case(context, receive, shutdown=hooks)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 264, in run_case
    shutdown_cases.run(context, receive, shutdown)
    ~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/shutdown_cases.py", line 137, in run
    active(context, receive, hooks)
    ~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/shutdown_cases.py", line 78, in active
    barrier = pause_cases.status(context, receive, 'shutdown_active')
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/pause_cases.py", line 9, in status
    return json.loads(adapter.get(context, '/status/' + tag, receive)['body'])
                      ~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 169, in get
    return finish(context, start(context, 'GET', path, (), True, primary, limit, middleware), receive)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 147, in finish
    observe(context, data, now)
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 100, in observe
    wire.accept(context['protocol'], data, context['records'], context['raw'], context['trace'],
    ~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                credit=context['credit'], request=context['request'], stage=context['stage'])
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e3a-snapshot-v9/source/wire.py", line 151, in accept
    return _accept(protocol, data, records, raw, trace, credit=credit, request=request, stage=stage)
  File "/tmp/uwz-task5e3a-snapshot-v9/source/wire.py", line 161, in _accept
    expected_updates = raw_observer.observe(raw, data, request=request, stage=stage)
  File "/tmp/uwz-task5e3a-snapshot-v9/source/raw_observer.py", line 168, in observe
    require(record is None or record['policy'] not in CLOSE_POLICIES, 'unexpected closing target payload')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e3a-snapshot-v9/source/raw_observer.py", line 14, in require
    raise ValueError(message)
ValueError: unexpected closing target payload

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 251, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 246, in main
    rejected('shutdown_active', fault, message)
    ~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 220, in rejected
    require(str(error) == message, 'wrong rejection for ' + fault + ': ' + str(error))
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 17, in require
    raise RuntimeError(message)
RuntimeError: wrong rejection for early_response: unexpected closing target payload
```

### attempt-7

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `0`.

stdout:

```text
shutdown_idle passed: J=69 C=69 R=0 request_sha256=e010c1916e8ddc1a1d9996511a5848c861714acc6d31c325ce6e94f9e9db99a9
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
active_hash rejected: record mismatch: sha256
barrier_changed rejected: shutdown barrier changed before signal
post_chunks rejected: shutdown changed nonterminal evidence
early_response rejected: unexpected closing target payload
termination rejected: post-signal termination differs
trailing rejected: post-signal termination differs
trailing_bool rejected: post-signal termination differs
primary_response rejected: post-signal termination differs
frames rejected: post-signal termination differs
close rejected: idle close evidence differs
```

stderr: empty.

### attempt-8

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `1`.

stdout:

```text
shutdown_idle passed: J=69 C=69 R=0 request_sha256=e010c1916e8ddc1a1d9996511a5848c861714acc6d31c325ce6e94f9e9db99a9
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
active_hash rejected: record mismatch: sha256
barrier_changed rejected: shutdown barrier changed before signal
post_chunks rejected: shutdown changed nonterminal evidence
early_response rejected: unexpected closing target payload
termination rejected: post-signal termination differs
trailing rejected: post-signal termination differs
trailing_bool rejected: post-signal termination differs
primary_response rejected: post-signal termination differs
frames rejected: post-signal termination differs
close rejected: idle close evidence differs
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
termination_phase rejected: post-signal termination differs
termination_extra rejected: post-signal termination differs
close_method rejected: idle close evidence differs
close_kind rejected: idle close evidence differs
close_extra rejected: idle close evidence differs
retained_missing rejected: retained output observations differ
selected_output rejected: post-deinit output changed
selected_binding rejected: post-deinit binding changed
```

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 263, in rejected
    check(case, fault=fault, prior=prior)
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 39, in check
    app = model.records(selection, 'before')
  File "/tmp/uwz-task5e1-contract-v3/model.py", line 133, in records
    catalogue.schedule(selection)
    ~~~~~~~~~~~~~~~~~~^^^^^^^^^^^
  File "/tmp/uwz-task5e1-contract-v3/catalogue.py", line 67, in schedule
    raise ValueError('idle child must be first')
ValueError: idle child must be first

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 313, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 309, in main
    rejected('shutdown_idle', None, 'shutdown preconditions differ', prior=('empty_headers',))
    ~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 265, in rejected
    require(str(error) == message, 'wrong rejection for ' + fault + ': ' + str(error))
                                   ~~~~~~~~~~~~~~~~~~~~~~~^~~~~~~
TypeError: can only concatenate str (not "NoneType") to str
```

### attempt-9

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `0`.

stdout:

```text
shutdown_idle passed: J=69 C=69 R=0 request_sha256=e010c1916e8ddc1a1d9996511a5848c861714acc6d31c325ce6e94f9e9db99a9
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
active_hash rejected: record mismatch: sha256
barrier_changed rejected: shutdown barrier changed before signal
post_chunks rejected: shutdown changed nonterminal evidence
early_response rejected: unexpected closing target payload
termination rejected: post-signal termination differs
trailing rejected: post-signal termination differs
trailing_bool rejected: post-signal termination differs
primary_response rejected: post-signal termination differs
frames rejected: post-signal termination differs
close rejected: idle close evidence differs
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
termination_phase rejected: post-signal termination differs
termination_extra rejected: post-signal termination differs
close_method rejected: idle close evidence differs
close_kind rejected: idle close evidence differs
close_extra rejected: idle close evidence differs
retained_missing rejected: retained output observations differ
selected_output rejected: post-deinit output changed
selected_binding rejected: post-deinit binding changed
prior_idle rejected: idle child must be first
```

stderr: empty.

### inventory-red-test_imports

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py", line 76, in <module>
    check()
    ~~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py", line 35, in check
    raise RuntimeError('authored source inventory differs')
RuntimeError: authored source inventory differs
```

### inventory-red-test_selection

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_selection.py
```

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_selection.py", line 32, in <module>
    check()
    ~~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_selection.py", line 15, in check
    raise RuntimeError('lifecycle selection inventory differs')
RuntimeError: lifecycle selection inventory differs
```

### inventory-red-test_admission

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_admission.py
```

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_admission.py", line 203, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_admission.py", line 182, in main
    raise RuntimeError('unsupported inventory differs')
RuntimeError: unsupported inventory differs
```

### inventory-red-test_pause

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_pause.py
```

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_pause.py", line 187, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_pause.py", line 158, in main
    raise RuntimeError('unsupported inventory differs')
RuntimeError: unsupported inventory differs
```

### inventory-red-test_continue_quota

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py
```

Exit: `1`.

stdout:

```text
pre-Continue DATA rejected: DATA before Continue or after terminal
```

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py", line 256, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py", line 221, in main
    raise RuntimeError('unsupported inventory differs')
RuntimeError: unsupported inventory differs
```

### inventory-red-test_metadata_concurrency

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py
```

Exit: `1`.

stdout:

```text
metadata helper/overflow contract checked; seven synthetic header oracle controls rejected
metadata_helpers passed: heads=6 small=6 flow=32
concurrent_routes passed: heads=13 small=13 flow=96
helpers_begin rejected: record mismatch: helpers_begin
helpers_end rejected: record mismatch: helpers_end
metadata_middleware rejected: record mismatch: metadata_middleware
metadata_begin rejected: record mismatch: metadata_begin
metadata_end rejected: record mismatch: metadata_end
paused_bytes rejected: record mismatch: bytes
not_paused rejected: record mismatch: paused
early_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
paused_bytes rejected: record mismatch: bytes
not_paused rejected: record mismatch: paused
early_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
refusal_status rejected: wrong final status
refusal_continue rejected: invalid HEADERS
reset_first rejected: reset order
reset_code rejected: wrong reset code
active_count rejected: concurrent active barrier differs
paused_count rejected: concurrent active barrier differs
slot_count rejected: concurrent active barrier differs
resume_prefix rejected: record mismatch: sha256
route_contamination rejected: record mismatch: metadata_begin
```

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py", line 365, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py", line 351, in main
    raise RuntimeError('unsupported inventory differs')
RuntimeError: unsupported inventory differs
```

### final-test_adapter-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_adapter.py
```

Exit: `0`.

stdout:

```text
paired startup and rejection checks passed
```

stderr: empty.

### final-test_adapter-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_adapter.py
```

Exit: `0`.

stdout:

```text
paired startup and rejection checks passed
```

stderr: empty.

### final-test_admission-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_admission.py
```

Exit: `0`.

stdout:

```text
empty_headers passed: heads=3 flow=0
empty_data passed: heads=3 flow=0
empty_declared passed: heads=3 flow=0
limit_declared passed: heads=3 flow=32
limit_undeclared passed: heads=3 flow=32
limit_declared_reject passed: heads=4 flow=32
limit_observed_reject passed: heads=5 flow=65
zero_declared_reject passed: heads=4 flow=0
zero_observed_reject passed: heads=4 flow=1
empty_headers passed: heads=3 flow=0
empty_data passed: heads=3 flow=0
empty_declared passed: heads=3 flow=0
limit_declared passed: heads=3 flow=32
limit_undeclared passed: heads=3 flow=32
limit_declared_reject passed: heads=4 flow=32
limit_observed_reject passed: heads=5 flow=65
zero_declared_reject passed: heads=4 flow=0
zero_observed_reject passed: heads=4 flow=1
reset_first rejected: reset order
continue rejected: invalid HEADERS
refusal_data rejected: response body bound
bad_prefix rejected: record mismatch: bytes
```

stderr: empty.

### final-test_admission-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_admission.py
```

Exit: `0`.

stdout:

```text
empty_headers passed: heads=3 flow=0
empty_data passed: heads=3 flow=0
empty_declared passed: heads=3 flow=0
limit_declared passed: heads=3 flow=32
limit_undeclared passed: heads=3 flow=32
limit_declared_reject passed: heads=4 flow=32
limit_observed_reject passed: heads=5 flow=65
zero_declared_reject passed: heads=4 flow=0
zero_observed_reject passed: heads=4 flow=1
empty_headers passed: heads=3 flow=0
empty_data passed: heads=3 flow=0
empty_declared passed: heads=3 flow=0
limit_declared passed: heads=3 flow=32
limit_undeclared passed: heads=3 flow=32
limit_declared_reject passed: heads=4 flow=32
limit_observed_reject passed: heads=5 flow=65
zero_declared_reject passed: heads=4 flow=0
zero_observed_reject passed: heads=4 flow=1
reset_first rejected: reset order
continue rejected: invalid HEADERS
refusal_data rejected: response body bound
bad_prefix rejected: record mismatch: bytes
```

stderr: empty.

### final-test_application_error-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_application_error.py
```

Exit: `0`.

stdout:

```text
sink_error passed: J=11 C=10 R=48
invalid_progress passed: J=11 C=10 R=48
end_error passed: J=10 C=9 R=65
sink_error passed: J=11 C=10 R=48
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
terminal_cancel rejected: record mismatch: cancels
terminal_ends rejected: record mismatch: ends
terminal_bytes rejected: record mismatch: bytes
terminal_hash rejected: record mismatch: sha256
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
primary_final rejected: unexpected final
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
invalid_progress passed: J=11 C=10 R=48
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
terminal_cancel rejected: record mismatch: cancels
terminal_ends rejected: record mismatch: ends
terminal_bytes rejected: record mismatch: bytes
terminal_hash rejected: record mismatch: sha256
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
primary_final rejected: unexpected final
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
end_error passed: J=10 C=9 R=65
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
terminal_cancel rejected: record mismatch: cancels
terminal_ends rejected: record mismatch: ends
terminal_bytes rejected: record mismatch: bytes
terminal_hash rejected: record mismatch: sha256
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
primary_final rejected: unexpected final
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
preterminal_cancel rejected: record mismatch: cancels
terminal_chunks rejected: failure callback follows accepted prefix
early_final rejected: upload completed before resume
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
preterminal_cancel rejected: record mismatch: cancels
terminal_chunks rejected: failure callback follows accepted prefix
early_final rejected: upload completed before resume
chunk_diagnostic rejected: record mismatch: chunk_errors
progress_diagnostic rejected: record mismatch: invalid_progress
end_diagnostic rejected: record mismatch: end_errors
```

stderr: empty.

### final-test_application_error-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_application_error.py
```

Exit: `0`.

stdout:

```text
sink_error passed: J=11 C=10 R=48
invalid_progress passed: J=11 C=10 R=48
end_error passed: J=10 C=9 R=65
sink_error passed: J=11 C=10 R=48
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
terminal_cancel rejected: record mismatch: cancels
terminal_ends rejected: record mismatch: ends
terminal_bytes rejected: record mismatch: bytes
terminal_hash rejected: record mismatch: sha256
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
primary_final rejected: unexpected final
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
invalid_progress passed: J=11 C=10 R=48
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
terminal_cancel rejected: record mismatch: cancels
terminal_ends rejected: record mismatch: ends
terminal_bytes rejected: record mismatch: bytes
terminal_hash rejected: record mismatch: sha256
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
primary_final rejected: unexpected final
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
end_error passed: J=10 C=9 R=65
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
terminal_cancel rejected: record mismatch: cancels
terminal_ends rejected: record mismatch: ends
terminal_bytes rejected: record mismatch: bytes
terminal_hash rejected: record mismatch: sha256
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
primary_final rejected: unexpected final
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
preterminal_cancel rejected: record mismatch: cancels
terminal_chunks rejected: failure callback follows accepted prefix
early_final rejected: upload completed before resume
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
preterminal_cancel rejected: record mismatch: cancels
terminal_chunks rejected: failure callback follows accepted prefix
early_final rejected: upload completed before resume
chunk_diagnostic rejected: record mismatch: chunk_errors
progress_diagnostic rejected: record mismatch: invalid_progress
end_diagnostic rejected: record mismatch: end_errors
```

stderr: empty.

### final-test_async-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_async.py
```

Exit: `0`.

stdout:

```text
async_delayed codec schedule passed
```

stderr: empty.

### final-test_async-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_async.py
```

Exit: `0`.

stdout:

```text
async_delayed codec schedule passed
```

stderr: empty.

### final-test_continue_quota-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py
```

Exit: `0`.

stdout:

```text
pre-Continue DATA rejected: DATA before Continue or after terminal
continue_ready passed: heads=3 flow=32
continue_paused passed: heads=5 flow=32
quota_refuse passed: heads=11 flow=128
begin_failure_rollback passed: heads=4 flow=32
continue_ready passed: heads=3 flow=32
continue_paused passed: heads=5 flow=32
quota_refuse passed: heads=11 flow=128
begin_failure_rollback passed: heads=4 flow=32
wrong_failure rejected: record mismatch: failures
other_record rejected: record mismatch: middleware
missing_continue rejected: invalid DATA
refusal_continue rejected: invalid HEADERS
refusal_data rejected: response body bound
reset_first rejected: reset order
active_count rejected: quota active barrier differs
paused_bytes rejected: record mismatch: bytes
early_final rejected: invalid terminal
```

stderr: empty.

### final-test_continue_quota-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py
```

Exit: `0`.

stdout:

```text
pre-Continue DATA rejected: DATA before Continue or after terminal
continue_ready passed: heads=3 flow=32
continue_paused passed: heads=5 flow=32
quota_refuse passed: heads=11 flow=128
begin_failure_rollback passed: heads=4 flow=32
continue_ready passed: heads=3 flow=32
continue_paused passed: heads=5 flow=32
quota_refuse passed: heads=11 flow=128
begin_failure_rollback passed: heads=4 flow=32
wrong_failure rejected: record mismatch: failures
other_record rejected: record mismatch: middleware
missing_continue rejected: invalid DATA
refusal_continue rejected: invalid HEADERS
refusal_data rejected: response body bound
reset_first rejected: reset order
active_count rejected: quota active barrier differs
paused_bytes rejected: record mismatch: bytes
early_final rejected: invalid terminal
```

stderr: empty.

### final-test_control_reset-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_control_reset.py
```

Exit: `0`.

stdout:

```text
cancel_ready passed: J=12 C=11 R=40
cancel_paused passed: J=12 C=11 R=65
peer_reset passed: J=11 C=10 R=65
cancel_ready passed: J=12 C=11 R=40
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
early_final rejected: upload completed before resume
primary_final rejected: unexpected final
other_record rejected: record mismatch: middleware
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
early_final rejected: upload completed before resume
primary_final rejected: unexpected final
other_record rejected: record mismatch: middleware
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
early_final rejected: upload completed before resume
primary_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
preterminal_chunks rejected: record mismatch: chunks
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
```

stderr: empty.

### final-test_control_reset-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_control_reset.py
```

Exit: `0`.

stdout:

```text
cancel_ready passed: J=12 C=11 R=40
cancel_paused passed: J=12 C=11 R=65
peer_reset passed: J=11 C=10 R=65
cancel_ready passed: J=12 C=11 R=40
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
early_final rejected: upload completed before resume
primary_final rejected: unexpected final
other_record rejected: record mismatch: middleware
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
early_final rejected: upload completed before resume
primary_final rejected: unexpected final
other_record rejected: record mismatch: middleware
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
early_final rejected: upload completed before resume
primary_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
preterminal_chunks rejected: record mismatch: chunks
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
```

stderr: empty.

### final-test_credit-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_credit.py
```

Exit: `0`.

stdout:

```text
queued_trailers_padding passed
receive_credit passed
paused_record rejected: record mismatch: bytes
missing_stream_credit rejected: missing synthetic response
```

stderr: empty.

### final-test_credit-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_credit.py
```

Exit: `0`.

stdout:

```text
queued_trailers_padding passed
receive_credit passed
paused_record rejected: record mismatch: bytes
missing_stream_credit rejected: missing synthetic response
```

stderr: empty.

### final-test_file_early-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_file_early.py
```

Exit: `0`.

stdout:

```text
producer_reuse passed: J=9 C=8 R=64 output=16777313
stream_file passed: J=7 C=6 R=33 output=24593
early_final_order passed: J=7 C=6 R=32 output=17
stream_file passed: J=7 C=6 R=33 output=24593
early_final_order passed: J=7 C=6 R=32 output=17
body_hash rejected: record mismatch: sha256
output_hash rejected: body length or digest differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
informationals rejected: invalid HEADERS
other_record rejected: record mismatch: middleware
body_hash rejected: record mismatch: sha256
output_hash rejected: file or early checkpoint differs
output_status rejected: wrong final status
missing_end rejected: reset order
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
informationals rejected: invalid HEADERS
other_record rejected: record mismatch: middleware
held_close rejected: file close once
close_twice rejected: file close once
ownership rejected: file ownership
arm_error rejected: file ownership
read_error rejected: file ownership
invalid_span rejected: file ownership
range rejected: file bounded range
requested rejected: file bounded range
no_reads rejected: file bounded range
range_generator rejected: body length or digest differs
sibling rejected: sibling echo differs
missing_sibling rejected: missing finite synthetic response
content_length rejected: InvalidBodyLengthError: Expected 24592 bytes, received 24593
duplicate_length rejected: file content-length differs
missing_length rejected: file content-length differs
holder_admission rejected: record mismatch: attempts
prefix_body_hash rejected: record mismatch: sha256
output_tail rejected: body length or digest differs
prefix_end rejected: invalid terminal
reset_first rejected: reset order
reset_code rejected: wrong reset code
missing_reset rejected: missing finite synthetic response
```

stderr: empty.

### final-test_file_early-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_file_early.py
```

Exit: `0`.

stdout:

```text
producer_reuse passed: J=9 C=8 R=64 output=16777313
stream_file passed: J=7 C=6 R=33 output=24593
early_final_order passed: J=7 C=6 R=32 output=17
stream_file passed: J=7 C=6 R=33 output=24593
early_final_order passed: J=7 C=6 R=32 output=17
body_hash rejected: record mismatch: sha256
output_hash rejected: body length or digest differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
informationals rejected: invalid HEADERS
other_record rejected: record mismatch: middleware
body_hash rejected: record mismatch: sha256
output_hash rejected: file or early checkpoint differs
output_status rejected: wrong final status
missing_end rejected: reset order
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
informationals rejected: invalid HEADERS
other_record rejected: record mismatch: middleware
held_close rejected: file close once
close_twice rejected: file close once
ownership rejected: file ownership
arm_error rejected: file ownership
read_error rejected: file ownership
invalid_span rejected: file ownership
range rejected: file bounded range
requested rejected: file bounded range
no_reads rejected: file bounded range
range_generator rejected: body length or digest differs
sibling rejected: sibling echo differs
missing_sibling rejected: missing finite synthetic response
content_length rejected: InvalidBodyLengthError: Expected 24592 bytes, received 24593
duplicate_length rejected: file content-length differs
missing_length rejected: file content-length differs
holder_admission rejected: record mismatch: attempts
prefix_body_hash rejected: record mismatch: sha256
output_tail rejected: body length or digest differs
prefix_end rejected: invalid terminal
reset_first rejected: reset order
reset_code rejected: wrong reset code
missing_reset rejected: missing finite synthetic response
```

stderr: empty.

### final-test_final-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_final.py
```

Exit: `0`.

stdout:

```text
ready_buffered codec schedule passed
```

stderr: empty.

### final-test_final-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_final.py
```

Exit: `0`.

stdout:

```text
ready_buffered codec schedule passed
```

stderr: empty.

### final-test_imports-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `0`.

stdout:

```text
AST and inert import checks passed
```

stderr: empty.

### final-test_imports-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `0`.

stdout:

```text
AST and inert import checks passed
```

stderr: empty.

### final-test_large-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_large.py
```

Exit: `0`.

stdout:

```text
large_declared codec schedule passed
large_undeclared codec schedule passed
```

stderr: empty.

### final-test_large-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_large.py
```

Exit: `0`.

stdout:

```text
large_declared codec schedule passed
large_undeclared codec schedule passed
```

stderr: empty.

### final-test_lifecycle-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py
```

Exit: `0`.

stdout:

```text
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=798d2d285194944a252568d0d51805fc0e738708be2e662d670d1901a9e7cf95
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=ed8a52e985e735f2801d8f12214e8911633579df5f6e60ebe8887ab5b4f7e93c
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
active_hash rejected: record mismatch: sha256
stale_counter rejected: record mismatch: stale_resume
stale_other rejected: record mismatch: metadata_begin
active_isolation rejected: record mismatch: metadata_begin
control_reply rejected: control result differs
completed_record rejected: record mismatch: metadata_end
early_response rejected: unexpected closing target payload
deadline rejected: deadline expired or invalid
other_record rejected: record mismatch: middleware
active_hash rejected: record mismatch: sha256
stale_counter rejected: record mismatch: stale_resume
stale_other rejected: record mismatch: metadata_begin
active_isolation rejected: record mismatch: metadata_begin
control_reply rejected: control result differs
completed_record rejected: record mismatch: metadata_end
early_response rejected: upload completed before resume
deadline rejected: deadline expired or invalid
other_record rejected: record mismatch: middleware
post_reason rejected: record mismatch: reason
close_eof rejected: strict close evidence differs
close_bool rejected: strict close evidence differs
close_trailing rejected: strict close evidence differs
close_method rejected: strict close evidence differs
close_tls rejected: strict close evidence differs
close_kind rejected: strict close evidence differs
same_codec rejected: replacement facts differ
unowned rejected: replacement facts differ
tls rejected: replacement facts differ
alpn rejected: replacement facts differ
close_trailing_bool rejected: strict close evidence differs
close_extra rejected: strict close evidence differs
replacement_extra rejected: replacement facts differ
null_codec rejected: replacement facts differ
send_hook rejected: replacement facts differ
receive_hook rejected: replacement facts differ
now_bool rejected: replacement facts differ
now_past rejected: replacement facts differ
owned_int rejected: replacement facts differ
missing_hooks rejected: disconnect hooks required
extra_hook rejected: disconnect hooks required
invalid_hook rejected: disconnect hooks required
```

stderr: empty.

### final-test_lifecycle-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py
```

Exit: `0`.

stdout:

```text
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=798d2d285194944a252568d0d51805fc0e738708be2e662d670d1901a9e7cf95
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=ed8a52e985e735f2801d8f12214e8911633579df5f6e60ebe8887ab5b4f7e93c
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
active_hash rejected: record mismatch: sha256
stale_counter rejected: record mismatch: stale_resume
stale_other rejected: record mismatch: metadata_begin
active_isolation rejected: record mismatch: metadata_begin
control_reply rejected: control result differs
completed_record rejected: record mismatch: metadata_end
early_response rejected: unexpected closing target payload
deadline rejected: deadline expired or invalid
other_record rejected: record mismatch: middleware
active_hash rejected: record mismatch: sha256
stale_counter rejected: record mismatch: stale_resume
stale_other rejected: record mismatch: metadata_begin
active_isolation rejected: record mismatch: metadata_begin
control_reply rejected: control result differs
completed_record rejected: record mismatch: metadata_end
early_response rejected: upload completed before resume
deadline rejected: deadline expired or invalid
other_record rejected: record mismatch: middleware
post_reason rejected: record mismatch: reason
close_eof rejected: strict close evidence differs
close_bool rejected: strict close evidence differs
close_trailing rejected: strict close evidence differs
close_method rejected: strict close evidence differs
close_tls rejected: strict close evidence differs
close_kind rejected: strict close evidence differs
same_codec rejected: replacement facts differ
unowned rejected: replacement facts differ
tls rejected: replacement facts differ
alpn rejected: replacement facts differ
close_trailing_bool rejected: strict close evidence differs
close_extra rejected: strict close evidence differs
replacement_extra rejected: replacement facts differ
null_codec rejected: replacement facts differ
send_hook rejected: replacement facts differ
receive_hook rejected: replacement facts differ
now_bool rejected: replacement facts differ
now_past rejected: replacement facts differ
owned_int rejected: replacement facts differ
missing_hooks rejected: disconnect hooks required
extra_hook rejected: disconnect hooks required
invalid_hook rejected: disconnect hooks required
```

stderr: empty.

### final-test_metadata_concurrency-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py
```

Exit: `0`.

stdout:

```text
metadata helper/overflow contract checked; seven synthetic header oracle controls rejected
metadata_helpers passed: heads=6 small=6 flow=32
concurrent_routes passed: heads=13 small=13 flow=96
helpers_begin rejected: record mismatch: helpers_begin
helpers_end rejected: record mismatch: helpers_end
metadata_middleware rejected: record mismatch: metadata_middleware
metadata_begin rejected: record mismatch: metadata_begin
metadata_end rejected: record mismatch: metadata_end
paused_bytes rejected: record mismatch: bytes
not_paused rejected: record mismatch: paused
early_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
paused_bytes rejected: record mismatch: bytes
not_paused rejected: record mismatch: paused
early_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
refusal_status rejected: wrong final status
refusal_continue rejected: invalid HEADERS
reset_first rejected: reset order
reset_code rejected: wrong reset code
active_count rejected: concurrent active barrier differs
paused_count rejected: concurrent active barrier differs
slot_count rejected: concurrent active barrier differs
resume_prefix rejected: record mismatch: sha256
route_contamination rejected: record mismatch: metadata_begin
40 source schedules implemented; general selection validation retained
```

stderr: empty.

### final-test_metadata_concurrency-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py
```

Exit: `0`.

stdout:

```text
metadata helper/overflow contract checked; seven synthetic header oracle controls rejected
metadata_helpers passed: heads=6 small=6 flow=32
concurrent_routes passed: heads=13 small=13 flow=96
helpers_begin rejected: record mismatch: helpers_begin
helpers_end rejected: record mismatch: helpers_end
metadata_middleware rejected: record mismatch: metadata_middleware
metadata_begin rejected: record mismatch: metadata_begin
metadata_end rejected: record mismatch: metadata_end
paused_bytes rejected: record mismatch: bytes
not_paused rejected: record mismatch: paused
early_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
paused_bytes rejected: record mismatch: bytes
not_paused rejected: record mismatch: paused
early_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
refusal_status rejected: wrong final status
refusal_continue rejected: invalid HEADERS
reset_first rejected: reset order
reset_code rejected: wrong reset code
active_count rejected: concurrent active barrier differs
paused_count rejected: concurrent active barrier differs
slot_count rejected: concurrent active barrier differs
resume_prefix rejected: record mismatch: sha256
route_contamination rejected: record mismatch: metadata_begin
40 source schedules implemented; general selection validation retained
```

stderr: empty.

### final-test_negative-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_negative.py
```

Exit: `0`.

stdout:

```text
credit and terminal rejection checks passed
```

stderr: empty.

### final-test_negative-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_negative.py
```

Exit: `0`.

stdout:

```text
credit and terminal rejection checks passed
```

stderr: empty.

### final-test_pause-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_pause.py
```

Exit: `0`.

stdout:

```text
partial_pause passed: heads=7 flow=12289
final_pause passed: heads=6 flow=32
begin_pause_empty passed: heads=6 flow=0
control_rules passed: heads=20 flow=64
partial_pause passed: heads=7 flow=12289
final_pause passed: heads=6 flow=32
wrong tag rejected before control: record mismatch: tag
premature response rejected: invalid terminal
```

stderr: empty.

### final-test_pause-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_pause.py
```

Exit: `0`.

stdout:

```text
partial_pause passed: heads=7 flow=12289
final_pause passed: heads=6 flow=32
begin_pause_empty passed: heads=6 flow=0
control_rules passed: heads=20 flow=64
partial_pause passed: heads=7 flow=12289
final_pause passed: heads=6 flow=32
wrong tag rejected before control: record mismatch: tag
premature response rejected: invalid terminal
```

stderr: empty.

### final-test_producer_pressure-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_producer_pressure.py
```

Exit: `0`.

stdout:

```text
producer_reuse passed: J=9 C=8 R=64 output=16777313
output_pressure_window passed: J=8 C=7 R=33 output=16777313
output_pressure_ready passed: J=6 C=5 R=33 output=16777313
producer_reuse passed: J=9 C=8 R=64 output=16777313
output_pressure_ready passed: J=6 C=5 R=33 output=16777313
body_hash rejected: record mismatch: sha256
diagnostic_hash rejected: producer identity
output_hash rejected: body length or digest differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
body_hash rejected: record mismatch: sha256
diagnostic_hash rejected: producer identity
output_hash rejected: producer checkpoint differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
body_hash rejected: record mismatch: sha256
diagnostic_hash rejected: producer identity
output_hash rejected: body length or digest differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
identity rejected: producer identity changed
counter rejected: producer held state
monotonic rejected: producer counter decreased
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
identity rejected: producer identity changed
counter rejected: producer held state
monotonic rejected: producer counter decreased
prefix_end rejected: invalid terminal
missing_sibling rejected: missing finite synthetic response
binding_generation rejected: relative reuse binding
binding_slot rejected: relative reuse binding
after_reuse rejected: reuse callback missing
sibling rejected: sibling echo differs
sibling rejected: sibling echo differs
```

stderr: empty.

### final-test_producer_pressure-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_producer_pressure.py
```

Exit: `0`.

stdout:

```text
producer_reuse passed: J=9 C=8 R=64 output=16777313
output_pressure_window passed: J=8 C=7 R=33 output=16777313
output_pressure_ready passed: J=6 C=5 R=33 output=16777313
producer_reuse passed: J=9 C=8 R=64 output=16777313
output_pressure_ready passed: J=6 C=5 R=33 output=16777313
body_hash rejected: record mismatch: sha256
diagnostic_hash rejected: producer identity
output_hash rejected: body length or digest differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
body_hash rejected: record mismatch: sha256
diagnostic_hash rejected: producer identity
output_hash rejected: producer checkpoint differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
body_hash rejected: record mismatch: sha256
diagnostic_hash rejected: producer identity
output_hash rejected: body length or digest differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
identity rejected: producer identity changed
counter rejected: producer held state
monotonic rejected: producer counter decreased
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
identity rejected: producer identity changed
counter rejected: producer held state
monotonic rejected: producer counter decreased
prefix_end rejected: invalid terminal
missing_sibling rejected: missing finite synthetic response
binding_generation rejected: relative reuse binding
binding_slot rejected: relative reuse binding
after_reuse rejected: reuse callback missing
sibling rejected: sibling echo differs
sibling rejected: sibling echo differs
```

stderr: empty.

### final-test_ready-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_ready.py
```

Exit: `0`.

stdout:

```text
ready_buffered codec schedule passed
```

stderr: empty.

### final-test_ready-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_ready.py
```

Exit: `0`.

stdout:

```text
ready_buffered codec schedule passed
```

stderr: empty.

### final-test_selection-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_selection.py
```

Exit: `0`.

stdout:

```text
selection and deadline checks passed
```

stderr: empty.

### final-test_selection-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_selection.py
```

Exit: `0`.

stdout:

```text
selection and deadline checks passed
```

stderr: empty.

### final-test_shared-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shared.py
```

Exit: `0`.

stdout:

```text
entry debt connection=1781 stream=1781 budget=3110658; final bytes=28992 reads=69; upload frames=12208
shared schedules and carried final boundary passed
```

stderr: empty.

### final-test_shared-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shared.py
```

Exit: `0`.

stdout:

```text
entry debt connection=1781 stream=1781 budget=3110658; final bytes=28992 reads=69; upload frames=12208
shared schedules and carried final boundary passed
```

stderr: empty.

### final-test_shutdown-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `0`.

stdout:

```text
shutdown_idle passed: J=69 C=69 R=0 request_sha256=e010c1916e8ddc1a1d9996511a5848c861714acc6d31c325ce6e94f9e9db99a9
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
active_hash rejected: record mismatch: sha256
barrier_changed rejected: shutdown barrier changed before signal
post_chunks rejected: shutdown changed nonterminal evidence
early_response rejected: unexpected closing target payload
termination rejected: post-signal termination differs
trailing rejected: post-signal termination differs
trailing_bool rejected: post-signal termination differs
primary_response rejected: post-signal termination differs
frames rejected: post-signal termination differs
close rejected: idle close evidence differs
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
termination_phase rejected: post-signal termination differs
termination_extra rejected: post-signal termination differs
close_method rejected: idle close evidence differs
close_kind rejected: idle close evidence differs
close_extra rejected: idle close evidence differs
retained_missing rejected: retained output observations differ
selected_output rejected: post-deinit output changed
selected_binding rejected: post-deinit binding changed
prior_idle rejected: idle child must be first
```

stderr: empty.

### final-test_shutdown-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `0`.

stdout:

```text
shutdown_idle passed: J=69 C=69 R=0 request_sha256=e010c1916e8ddc1a1d9996511a5848c861714acc6d31c325ce6e94f9e9db99a9
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
active_hash rejected: record mismatch: sha256
barrier_changed rejected: shutdown barrier changed before signal
post_chunks rejected: shutdown changed nonterminal evidence
early_response rejected: unexpected closing target payload
termination rejected: post-signal termination differs
trailing rejected: post-signal termination differs
trailing_bool rejected: post-signal termination differs
primary_response rejected: post-signal termination differs
frames rejected: post-signal termination differs
close rejected: idle close evidence differs
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
termination_phase rejected: post-signal termination differs
termination_extra rejected: post-signal termination differs
close_method rejected: idle close evidence differs
close_kind rejected: idle close evidence differs
close_extra rejected: idle close evidence differs
retained_missing rejected: retained output observations differ
selected_output rejected: post-deinit output changed
selected_binding rejected: post-deinit binding changed
prior_idle rejected: idle child must be first
```

stderr: empty.

### final-test_time-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_time.py
```

Exit: `0`.

stdout:

```text
ready_buffered codec schedule passed
fresh time checks passed
```

stderr: empty.

### final-test_time-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_time.py
```

Exit: `0`.

stdout:

```text
ready_buffered codec schedule passed
fresh time checks passed
```

stderr: empty.

### final-audit

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import ast
import difflib
import hashlib
import json
import cases
import catalogue
import model

def depth(nodes, level=0):
    maximum = level
    for node in nodes:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            maximum = max(maximum, depth(node.body))
        elif isinstance(node, (ast.If, ast.For, ast.While, ast.With, ast.Try)):
            maximum = max(maximum, depth(node.body, level + 1))
            otherwise = getattr(node, 'orelse', [])
            branch_level = level if isinstance(node, ast.If) and len(otherwise) == 1 and isinstance(otherwise[0], ast.If) else level + 1
            maximum = max(maximum, depth(otherwise, branch_level), depth(getattr(node, 'finalbody', []), level + 1))
            for handler in getattr(node, 'handlers', []):
                maximum = max(maximum, depth(handler.body, level + 1))
    return maximum

if __name__ == '__main__':
    root=Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    evidence=root/'evidence/b6d'
    (evidence/'final-source').mkdir(exist_ok=True)
    immutable=json.loads((root/'evidence/b6c/immutable-inputs.json').read_text())
    for item in immutable['identities']:
        data=Path(item['path']).read_bytes()
        if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
            raise RuntimeError('immutable identity differs: '+item['path'])
    rows=immutable['codec_files']
    packages=Path('/tmp/uwz-h2-client-tooling/packages')
    for name,digest in rows:
        if hashlib.sha256((packages/name).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('codec identity differs: '+name)
    present={str(p.relative_to(packages)) for p in packages.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
    if present!={r[0] for r in rows} or len(rows)!=42 or hashlib.sha256(json.dumps(rows).encode()).hexdigest()!=immutable['codec_digest']:
        raise RuntimeError('ordered42 codec identity set or aggregate differs')
    files=immutable['identities']
    unique={str(Path(item['path']).resolve()) for item in files}
    if len(files)!=118 or len(unique)!=113:
        raise RuntimeError('retained identity row count differs')
    (evidence/'immutable-inputs.json').write_text(json.dumps(immutable,indent=2)+'\n')
    before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((evidence/'before-source').glob('*.py'))}
    published=json.loads(Path('docs/implement-2-2-0/evidence/m2_h2_combined_disconnect_reuse/manifest.json').read_text())['current_source_files']
    if before!=published:
        raise RuntimeError('captured before bytes differ from released B6c')
    (evidence/'before-map.json').write_text(json.dumps(before,indent=2)+'\n')
    final={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob('*.py'))}
    if len(before)!=33 or len(final)!=35:
        raise RuntimeError('source module inventory differs')
    added=sorted(final.keys()-before.keys())
    removed=sorted(before.keys()-final.keys())
    changed=sorted(name for name in before.keys() & final.keys() if before[name]!=final[name])
    unchanged=sorted(name for name in before.keys() & final.keys() if before[name]==final[name])
    differences=[]
    depths={}
    for name in final:
        source=(root/name).read_bytes()
        tree=ast.parse(source,filename=name)
        if any(isinstance(n,(ast.ClassDef,ast.Assert)) for n in ast.walk(tree)):
            raise RuntimeError('class or assertion: '+name)
        depths[name]=depth(tree.body)
        if depths[name]>3:
            raise RuntimeError('control depth exceeds3: '+name)
        (evidence/'final-source'/name).write_bytes(source)
        old=(evidence/'before-source'/name).read_text() if name in before else ''
        differences.extend(difflib.unified_diff(old.splitlines(True),source.decode().splitlines(True),fromfile='before/'+name,tofile='after/'+name))
    (evidence/'source.diff').write_text(''.join(differences))
    snapshot=dict(base='95c975e73e376c81fb0caba838659b745b362879',source_files=final,added=added,changed=changed,unchanged=unchanged,removed=removed,control_depth=depths)
    (evidence/'snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
    commands=[]
    for receipt in sorted(evidence.glob('final-test*.exit')):
        if '.pre-last.' in receipt.name:
            continue
        label=receipt.stem
        if receipt.read_text()!='0\n' or (evidence/(label+'.stderr')).read_bytes():
            raise RuntimeError('failed final command: '+label)
        commands.append(dict(command=(evidence/(label+'.command')).read_text(),exit=0,stdout=str(evidence/(label+'.stdout')),stderr=str(evidence/(label+'.stderr'))))
    if len(commands)!=42:
        raise RuntimeError('final command inventory differs')
    (evidence/'final-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    if len(cases.IMPLEMENTED)!=40 or len(model.SPECS)!=67 or len(set(catalogue.CASES)-set(cases.IMPLEMENTED))!=0:
        raise RuntimeError('case or final record inventory differs')
    normal=(evidence/'final-test_shutdown-normal.stdout').read_bytes()
    if normal!=(evidence/'final-test_shutdown-optimized.stdout').read_bytes() or len(normal.splitlines())!=80:
        raise RuntimeError('new normal/O proof differs')
    for p in root.glob('*.py'):
        if hashlib.sha256(p.read_bytes()).hexdigest()!=final[p.name]:
            raise RuntimeError('source changed during snapshot')
    contracts={case:dict(catalogue.case_budget(case)) for case in ('shutdown_active','shutdown_idle')}
    contracts.update(deadlines=[30001,900001],active_primary=3,idle_primary=1,final_requests=68,
                     active_presignal_statuses=68,idle_statuses=67,active_carried_debt=64,outputs_extra_requests=0)
    (evidence/'contracts.json').write_text(json.dumps(contracts,indent=2)+'\n')
    interpreter=Path('/home/codespace/.python/current/bin/python3')
    identity=dict(path=str(interpreter),resolved=str(interpreter.resolve()),bytes=len(interpreter.read_bytes()),sha256=hashlib.sha256(interpreter.read_bytes()).hexdigest())
    (evidence/'python-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
    print('35 modules: %d added, %d changed, %d unchanged, %d removed against released B6c' % (len(added),len(changed),len(unchanged),len(removed)))
    print('119 retained identity rows / 114 unique entries: 118 file rows / 113 unique resolved files plus codec aggregate')
    print('42 ordered codec identities and default-json aggregate match; no extra or missing codec files')
    print('42 final normal/-O commands exit0 with empty stderr; all35-module AST and actual inert empty/foreign argv imports pass')
    print('maximum control depth=%d; shutdown schedule=%d; shutdown test=%d' % (max(depths.values()),depths['shutdown_cases.py'],depths['test_shutdown.py']))
    print('40 source schedules; zero unsupported cases; general malformed/unknown/duplicate/ordering rejection retained')
    print('shutdown test: five positive executions and75 exact synthetic negative rejections per mode')
    print('No native execution, callback/process/close proof, default/aggregate acceptance or combined all40 claim')
PY
```

Exit: `0`.

stdout:

```text
35 modules: 2 added, 8 changed, 25 unchanged, 0 removed against released B6c
119 retained identity rows / 114 unique entries: 118 file rows / 113 unique resolved files plus codec aggregate
42 ordered codec identities and default-json aggregate match; no extra or missing codec files
42 final normal/-O commands exit0 with empty stderr; all35-module AST and actual inert empty/foreign argv imports pass
maximum control depth=3; shutdown schedule=1; shutdown test=2
40 source schedules; zero unsupported cases; general malformed/unknown/duplicate/ordering rejection retained
shutdown test: five positive executions and75 exact synthetic negative rejections per mode
No native execution, callback/process/close proof, default/aggregate acceptance or combined all40 claim
```

stderr: empty.

### history-audit

```sh
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import hashlib
import json
import tarfile

if __name__ == '__main__':
    root=Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    archive_path=Path('docs/implement-2-2-0/evidence/m2_h2_combined_disconnect_reuse/combined-disconnect-reuse.tar.gz')
    manifest=json.loads((archive_path.parent/'manifest.json').read_text())
    if hashlib.sha256(archive_path.read_bytes()).hexdigest()!=manifest['archive_sha256']:
        raise RuntimeError('released B6c archive identity differs')
    identities={}
    with tarfile.open(archive_path,'r:gz') as archive:
        for member in archive.getmembers():
            if not member.name.startswith('raw/'):
                continue
            data=archive.extractfile(member).read()
            target=root/'evidence'/member.name[4:]
            if target.read_bytes()!=data:
                raise RuntimeError('prior evidence differs: '+str(target))
            identities[str(target)]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
    (root/'evidence/b6d/preserved-history.json').write_text(json.dumps(identities,indent=2)+'\n')
    print('Released B6c archive matched; preserved raw evidence files='+str(len(identities)))
PY
```

Exit: `0`.

stdout:

```text
Released B6c archive matched; preserved raw evidence files=472
```

stderr: empty.

### graph-update

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .
```

Exit: `0`.

stdout:

```text
Re-extracting code files in . (no LLM needed)...
[graphify watch] 374 file(s) not classified (no supported extension or shebang), skipped: .dockerignore, .git, .gitattributes, .gitignore, .gitmodules, Dockerfile (+368 more)
[graphify watch] No relevant changes; graphify-out left untouched.
Code graph updated. For doc/paper/image changes run /graphify --update in your AI assistant.
Tip: set GEMINI_API_KEY or GOOGLE_API_KEY to use Gemini for semantic extraction.
```

stderr: empty.

## Graphify initial query

Before the first new codebase source query/search/read, the prescribed prefix
was executed with this exact question. Exit0; graph response reported197 nodes
and650-token truncation. The provided source paths were already located.

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "combined-cases adapter final_collection shutdown active idle test_disconnect wire final termination" --budget 650
```

The initial query raw output is in the tool transcript; its response was read
before any new raw source search. The final AST-only update command/raw output
is retained above; the ignored owned workspace produced no relevant graph
changes and no semantic API operation ran.

## Additional direct idle admission guards

Three actual adapter.open_case calls reject prior ordinary/active/idle selections
before either rejecting send/time hook can run. This supplements the serialized
suite’s earlier model/catalogue ordering rejection; it does not alter source.

### final-guards

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
import adapter
import h2_client


def reject_effect(*_args):
    raise RuntimeError('idle prior-selection guard performed an effect')


if __name__ == '__main__':
    for prior in (('empty_headers',), ('shutdown_active',), ('shutdown_idle',)):
        try:
            adapter.open_case('shutdown_idle', h2_client.new_protocol(), reject_effect, 1, 30001, 900001,
                              selected_before=prior, clock=reject_effect)
        except ValueError as error:
            if str(error) != 'invalid previous selection':
                raise RuntimeError('wrong prior-selection guard: '+str(error))
        else:
            raise RuntimeError('idle accepted a previous application selection')
    print('Three actual idle open-case prior-selection guards reject before send/time hooks')
PY
```

Exit: `0`.

stdout:

```text
Three actual idle open-case prior-selection guards reject before send/time hooks
```

stderr: empty.

### final-guards-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O - <<'PY'
import adapter
import h2_client


def reject_effect(*_args):
    raise RuntimeError('idle prior-selection guard performed an effect')


if __name__ == '__main__':
    for prior in (('empty_headers',), ('shutdown_active',), ('shutdown_idle',)):
        try:
            adapter.open_case('shutdown_idle', h2_client.new_protocol(), reject_effect, 1, 30001, 900001,
                              selected_before=prior, clock=reject_effect)
        except ValueError as error:
            if str(error) != 'invalid previous selection':
                raise RuntimeError('wrong prior-selection guard: '+str(error))
        else:
            raise RuntimeError('idle accepted a previous application selection')
    print('Three actual idle open-case prior-selection guards reject before send/time hooks')
PY
```

Exit: `0`.

stdout:

```text
Three actual idle open-case prior-selection guards reject before send/time hooks
```

stderr: empty.

# Fix round1: retain ordinary validated final facts

This appendix supersedes the earlier report's deferral of ordinary final-facts
retention. That deferral was incorrect: the shared final-collection seam was
already assigned by the original B6d brief. P2 is now implemented for scoped
re-review. The original reviewed35 modules, complete report and preceding42
normal/optimized receipts are separately retained in evidence/b6d/fix-1 under
reviewed-source/, reviewed-report.md and reviewed-receipts/. Their221-file
identity map is reviewed-map.json and was rehashed after the fix. Every preceding
42 command/stdout/stderr/exit file in the original location also matches its
reviewed copy. Those42 receipts describe the pre-fix source version; they are
not represented as a full42 rerun of the current fix.

## Fix API, changed files and exact behavior

adapter.final_collection now stores one bounded dictionary at
context['final_observations'] immediately after all67 parsed records and metrics
validate and canonical wire.finish_final succeeds. It contains the actual
records and observed metrics from that collection, including callback diagnostic
values the expected model recipes leave unconstrained. No model substitution,
extra request, accessor wrapper, deadline/counter/state reset or secondary
collection was introduced. Ordinary callers still receive None. The shutdown
return branches return that same dictionary, so shutdown_observations.before
and final_observations share the one capture rather than duplicate it. Existing
shutdown code adds its bounded output/binding snapshots to that same object.

Only adapter.py, test_final.py and test_shutdown.py changed relative to the
reviewed35-module source. No other source changed. test_final.py retains its
previous ready-buffered final test and adds an independently decoded serialized
ordinary-final regression with synthetic selected-before reuse records. It
observes chunks=2 and max_span=19 on each completed reuse record: these are
valid actual diagnostics where model.record('reuse_0',True,'before')['chunks']
is None. It confirms the saved records and metrics were JSON-parsed objects,
not the supplied synthetic dictionaries, and performs later model pre/post
comparison using that retained capture with no further sends/receives.

The ordinary regression independently checks the exact five-case-request order
plus67 statuses/metrics, odd stream IDs and HEADERS/DATA END flags, declared257
and exact echo payload/hash, one settings ACK and one DATA END. Total heads and
receives stay73, final registrations stay68, and the ordinary return staysNone.
It also checks unchanged stage/parser/request/credit/records object identities,
unchanged30001/900001 deadlines, complete final state and no response/serialization
residue. Synthetic prior reuse diagnostics are test preconditions; this focused
case does not execute reuse or establish a native shared application.

test_shutdown.py now checks both shutdown run_case return identity and that
final_observations is shutdown_observations.before, with the same actual parsed
before records. Its existing five positives,75 typed/sensitivity negatives,
held/fresh-idle ordering, output/binding and post-deinit checks remain in place.
test_imports.py was unchanged and covers all35 current modules, including both
changed tests, with AST/main-guard and actual silent/inert empty/foreign argv
imports using rejecting effect doubles.

## Actual RED and covering GREEN

The new ordinary regression was written before the adapter fix and saved as
fix-1/initial-test_final.py. Its real RED exits1 with
ordinary validated final facts discarded. It reaches the existing ordinary
case and canonical full68-response final collection before failing: the ordinary
None return check passes, then the absent context capture is rejected. This RED
exercises serialization and parsed facts, unlike B6d's initial unsupported-selection
RED. No intermediate failed implementation or corrected test expectation occurred
in this fix round.

After the final edits, the six covering commands test_final.py, test_shutdown.py
and test_imports.py in pinned -B -S normal and -B -S -O modes all exit0 with empty
stderr. The ordinary raw success is:

```text
ready_buffered codec schedule passed
ordinary capture passed: heads=73 final=68 chunks=2 max_span=19 return=None extra_requests=0
```

No full42 rerun was needed or claimed, following the explicit fix brief. Current
six-command receipts are fix-1/final-commands.json. Both modes' ordinary/shutdown
stdout are identical. The source/input audit rechecked all119 retained identity
entries (118 file rows/113 unique resolved files plus ordered codec aggregate),
all42 codec files and the exact default-json digest. No core/model/fixture/helper/
codec/dependency/budget/deadline identity changed. All35 source guards/imports
pass, maximum control depth remains3 and the new ordinary final test depth is2.
No native, socket, TLS/SSLContext, process, real-clock, probe, Git or public-doc
operation ran, and no other agent was started.

## Fix snapshot, self-review and remaining facts

fix-1/reviewed-source and reviewed-report.md preserve the failed-review source
and report unchanged. fix-1/fix.diff is the exact three-file fix delta.
fix-1/final-source and snapshot.json identify all35 current modules; the parent
B6d snapshot.json, source.diff and final-source have been refreshed to the same
current bytes. The original B6d source snapshot/source.diff/audit receipts remain
in reviewed-receipts. Against accepted B6c the current source is2 added,9 changed,
24 unchanged and0 removed modules. No older receipt was silently relabeled as
current evidence.

Self-review checked that capture assignment occurs only after successful model
validation and canonical finish_final; it retains the parsed objects once and
preserves ordinary None and all request/effect accounting. The shutdown branches
reuse that object and tests verify its identity. The new test reaches the reported
failure with valid observed wildcard diagnostics and later consumes the capture
without requests. The exact fix touches only the assigned seam/regressions.
There is no remaining API gap for this finding. Root's same-reviewer scoped
re-review remains required. All original source-only/native/default/aggregate/
two-child all40 acceptance limits remain unchanged; this fix does not claim them.

Current full35-module source hashes and fix ownership:

```json
{
  "base": "95c975e73e376c81fb0caba838659b745b362879",
  "source_files": {
    "adapter.py": "024de25d639a34dfbe1c86695d92a48c25ce0c56259faa80bfc8ff329c696c1c",
    "admission_cases.py": "b4cac4031f9be16bca938f7167bb327f4eae4fd5667b42cb70fc23782f8fbbcf",
    "application_error_cases.py": "9d63d938391f2181205766c3297d9aae5ce6966d9f371251b9fa5aeb152d9e68",
    "cases.py": "f89fe655f8c66c98e67ffd7723b07980234e124b130a8a99a790cb80fc54bcd5",
    "concurrent_cases.py": "a9ab3e7b6f6a362c1c6d33788fa8b7c3ed5961989be1f58d7fd6cc66a998a7c1",
    "continue_quota_cases.py": "da533ef0fde4179c00427d11b689cba1fdf248e41ba01c98a47f37a08ec99e95",
    "control_reset_cases.py": "36b8fe72e24eaf8cb7a30b470ea4c23823f324373ac3d4d90a6cc8a1595979d7",
    "credit_cases.py": "f953e2bacb92c4370904cf2b6e302a215aed9bd28210290406aac965e8d2178d",
    "file_early_cases.py": "90479c670ee1d75c4974704bb6b51d4543142c80c10a8b01963a1a31e0dc9d8c",
    "lifecycle_cases.py": "3aeb930ef537ac4690ba3f0b5deaffd3a1770981e247652f9fb2f77ffd98a92c",
    "metadata_cases.py": "7a48599c53779a2414f4492371174d35030e91d1dd61570408248b7eae12b83c",
    "pause_cases.py": "c7e28527478f3a3e52de22de019e1698083a8d03b4bca3100dd4788e77a8f250",
    "producer_pressure_cases.py": "44cb04ab3eee53c50c8cd508244486ef6693646aa276836e244a9fb18caffbda",
    "shutdown_cases.py": "5e1bb82c571a8dd15f1552524769d5cfbeb63cd3de6fc63053b98af9b5bf658d",
    "test_adapter.py": "ef325e804d454e12a4f8b2d2dfa2e0c778736758cf8618334081c864940aefbf",
    "test_admission.py": "28b88c1b8dcdccc03154cb7472cf14ce0f3819de54b78d72e9fec68608381d9d",
    "test_application_error.py": "221d38b7d31fc419d990df1ce512f9cdc509e7c3a9eb1f9c4ef961a43b82c96c",
    "test_async.py": "bcf31ec8037b3ba4861d25e7983efaeef269df5c084dc3922cc358d8e94ae314",
    "test_continue_quota.py": "71ed633a7d9151dcacc99f4665b1ae45e9423ee7dc589e9607e280a67bdf9914",
    "test_control_reset.py": "7b81f969a0cd5146ac5ac075bd2cc2d25aca890c021db4ab73f828eb04780d67",
    "test_credit.py": "bd03e99dbe6d1297bc96badf870c4be7486ef2524a14befd323bbebb8a9e0a65",
    "test_file_early.py": "8feb6e45339160eb28b19a5635a22eba58cc8206f6f127975739201b0d045604",
    "test_final.py": "830e5fdfb3475b1ab11e2b956f4494abff9e7176f684e166e282b30b1d90b626",
    "test_imports.py": "1e140df0da86cfee854664cbc954842e9d51d346d210744f59057ba693e20353",
    "test_large.py": "5710cb5be11f777f2c0ba4f0b3a647227f75b5955dcf1f8cecd750419b46c7d0",
    "test_lifecycle.py": "7346386e3482a800bfe20b0dc8da8726dc66d6dd8a516ac038de4222a21f535a",
    "test_metadata_concurrency.py": "21708e73da3f401891b975414578ce136ac40a8848cfa730f429e17d9251294d",
    "test_negative.py": "91ae248806c1402bd4219474c3e08e1ef2fcb5994d3e6f7b5e7f40fac4ec47f0",
    "test_pause.py": "86f3faa897d8c278dfeef4f7359194b3eea5e1b284ba46bf012ecc6f569c291e",
    "test_producer_pressure.py": "79dc174853ad5285c37e6f36368199d20d403f3afa488e80a32a04faa036ff51",
    "test_ready.py": "600ec8b0bc072aa4d9a52417425e77c56edc2e02680bdb01d9d288c52001b442",
    "test_selection.py": "eae469c25524ddaa3b02c0474dcebae605ba0d64846d8ae50de57a76b8f57aa3",
    "test_shared.py": "cbd3370c4dd56990c126939503a35dd5eabd8a03ce71195865152510a973b91b",
    "test_shutdown.py": "29f02967c79e1ece295bfe237b93ff725ce6e0ccb6fcec9d49f9304bfd7b458b",
    "test_time.py": "0e10a1c68bfdd754b67a656bd8f4cc05ca8fcf8c9af63ab66130e2e969edf967"
  },
  "added": [
    "shutdown_cases.py",
    "test_shutdown.py"
  ],
  "changed": [
    "adapter.py",
    "cases.py",
    "test_admission.py",
    "test_continue_quota.py",
    "test_final.py",
    "test_imports.py",
    "test_metadata_concurrency.py",
    "test_pause.py",
    "test_selection.py"
  ],
  "unchanged": [
    "admission_cases.py",
    "application_error_cases.py",
    "concurrent_cases.py",
    "continue_quota_cases.py",
    "control_reset_cases.py",
    "credit_cases.py",
    "file_early_cases.py",
    "lifecycle_cases.py",
    "metadata_cases.py",
    "pause_cases.py",
    "producer_pressure_cases.py",
    "test_adapter.py",
    "test_application_error.py",
    "test_async.py",
    "test_control_reset.py",
    "test_credit.py",
    "test_file_early.py",
    "test_large.py",
    "test_lifecycle.py",
    "test_negative.py",
    "test_producer_pressure.py",
    "test_ready.py",
    "test_shared.py",
    "test_time.py"
  ],
  "removed": [],
  "control_depth": {
    "adapter.py": 3,
    "admission_cases.py": 2,
    "application_error_cases.py": 1,
    "cases.py": 1,
    "concurrent_cases.py": 2,
    "continue_quota_cases.py": 2,
    "control_reset_cases.py": 1,
    "credit_cases.py": 1,
    "file_early_cases.py": 2,
    "lifecycle_cases.py": 2,
    "metadata_cases.py": 1,
    "pause_cases.py": 2,
    "producer_pressure_cases.py": 1,
    "shutdown_cases.py": 1,
    "test_adapter.py": 2,
    "test_admission.py": 3,
    "test_application_error.py": 2,
    "test_async.py": 1,
    "test_continue_quota.py": 3,
    "test_control_reset.py": 2,
    "test_credit.py": 3,
    "test_file_early.py": 3,
    "test_final.py": 2,
    "test_imports.py": 3,
    "test_large.py": 1,
    "test_lifecycle.py": 3,
    "test_metadata_concurrency.py": 3,
    "test_negative.py": 3,
    "test_pause.py": 3,
    "test_producer_pressure.py": 3,
    "test_ready.py": 3,
    "test_selection.py": 1,
    "test_shared.py": 3,
    "test_shutdown.py": 2,
    "test_time.py": 1
  },
  "fix_changed": [
    "adapter.py",
    "test_final.py",
    "test_shutdown.py"
  ],
  "covering_commands": "fix-1/final-commands.json"
}
```

## Fix exact commands and raw outcomes

### red

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_final.py
```

Exit: `1`.

stdout:

```text
ready_buffered codec schedule passed
```

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_final.py", line 125, in <module>
    check()
    ~~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_final.py", line 103, in check
    require('final_observations' in context, 'ordinary validated final facts discarded')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_final.py", line 13, in require
    raise RuntimeError(message)
RuntimeError: ordinary validated final facts discarded
```

### final-test_final-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_final.py
```

Exit: `0`.

stdout:

```text
ready_buffered codec schedule passed
ordinary capture passed: heads=73 final=68 chunks=2 max_span=19 return=None extra_requests=0
```

stderr: empty.

### final-test_final-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_final.py
```

Exit: `0`.

stdout:

```text
ready_buffered codec schedule passed
ordinary capture passed: heads=73 final=68 chunks=2 max_span=19 return=None extra_requests=0
```

stderr: empty.

### final-test_imports-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `0`.

stdout:

```text
AST and inert import checks passed
```

stderr: empty.

### final-test_imports-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `0`.

stdout:

```text
AST and inert import checks passed
```

stderr: empty.

### final-test_shutdown-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `0`.

stdout:

```text
shutdown_idle passed: J=69 C=69 R=0 request_sha256=e010c1916e8ddc1a1d9996511a5848c861714acc6d31c325ce6e94f9e9db99a9
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
active_hash rejected: record mismatch: sha256
barrier_changed rejected: shutdown barrier changed before signal
post_chunks rejected: shutdown changed nonterminal evidence
early_response rejected: unexpected closing target payload
termination rejected: post-signal termination differs
trailing rejected: post-signal termination differs
trailing_bool rejected: post-signal termination differs
primary_response rejected: post-signal termination differs
frames rejected: post-signal termination differs
close rejected: idle close evidence differs
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
termination_phase rejected: post-signal termination differs
termination_extra rejected: post-signal termination differs
close_method rejected: idle close evidence differs
close_kind rejected: idle close evidence differs
close_extra rejected: idle close evidence differs
retained_missing rejected: retained output observations differ
selected_output rejected: post-deinit output changed
selected_binding rejected: post-deinit binding changed
prior_idle rejected: idle child must be first
```

stderr: empty.

### final-test_shutdown-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `0`.

stdout:

```text
shutdown_idle passed: J=69 C=69 R=0 request_sha256=e010c1916e8ddc1a1d9996511a5848c861714acc6d31c325ce6e94f9e9db99a9
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
active_hash rejected: record mismatch: sha256
barrier_changed rejected: shutdown barrier changed before signal
post_chunks rejected: shutdown changed nonterminal evidence
early_response rejected: unexpected closing target payload
termination rejected: post-signal termination differs
trailing rejected: post-signal termination differs
trailing_bool rejected: post-signal termination differs
primary_response rejected: post-signal termination differs
frames rejected: post-signal termination differs
close rejected: idle close evidence differs
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
termination_phase rejected: post-signal termination differs
termination_extra rejected: post-signal termination differs
close_method rejected: idle close evidence differs
close_kind rejected: idle close evidence differs
close_extra rejected: idle close evidence differs
retained_missing rejected: retained output observations differ
selected_output rejected: post-deinit output changed
selected_binding rejected: post-deinit binding changed
prior_idle rejected: idle child must be first
```

stderr: empty.

### audit

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import ast
import difflib
import hashlib
import json
import cases
import catalogue
import model

def depth(nodes, level=0):
    maximum = level
    for node in nodes:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            maximum = max(maximum, depth(node.body))
        elif isinstance(node, (ast.If, ast.For, ast.While, ast.With, ast.Try)):
            maximum = max(maximum, depth(node.body, level + 1))
            otherwise = getattr(node, 'orelse', [])
            branch_level = level if isinstance(node, ast.If) and len(otherwise) == 1 and isinstance(otherwise[0], ast.If) else level + 1
            maximum = max(maximum, depth(otherwise, branch_level), depth(getattr(node, 'finalbody', []), level + 1))
            for handler in getattr(node, 'handlers', []):
                maximum = max(maximum, depth(handler.body, level + 1))
    return maximum

if __name__ == '__main__':
    root=Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    evidence=root/'evidence/b6d/fix-1'
    (evidence/'final-source').mkdir(exist_ok=True)
    immutable=json.loads((root/'evidence/b6c/immutable-inputs.json').read_text())
    for item in immutable['identities']:
        data=Path(item['path']).read_bytes()
        if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
            raise RuntimeError('immutable identity differs: '+item['path'])
    rows=immutable['codec_files']
    packages=Path('/tmp/uwz-h2-client-tooling/packages')
    for name,digest in rows:
        if hashlib.sha256((packages/name).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('codec identity differs: '+name)
    present={str(p.relative_to(packages)) for p in packages.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
    if present!={r[0] for r in rows} or len(rows)!=42 or hashlib.sha256(json.dumps(rows).encode()).hexdigest()!=immutable['codec_digest']:
        raise RuntimeError('ordered42 codec identity set or aggregate differs')
    files=immutable['identities']
    unique={str(Path(item['path']).resolve()) for item in files}
    if len(files)!=118 or len(unique)!=113:
        raise RuntimeError('retained identity row count differs')
    (evidence/'immutable-inputs.json').write_text(json.dumps(immutable,indent=2)+'\n')
    before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'evidence/b6d/before-source').glob('*.py'))}
    published=json.loads(Path('docs/implement-2-2-0/evidence/m2_h2_combined_disconnect_reuse/manifest.json').read_text())['current_source_files']
    if before!=published:
        raise RuntimeError('captured before bytes differ from released B6c')
    (evidence/'before-map.json').write_text(json.dumps(before,indent=2)+'\n')
    final={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob('*.py'))}
    if len(before)!=33 or len(final)!=35:
        raise RuntimeError('source module inventory differs')
    added=sorted(final.keys()-before.keys())
    removed=sorted(before.keys()-final.keys())
    changed=sorted(name for name in before.keys() & final.keys() if before[name]!=final[name])
    unchanged=sorted(name for name in before.keys() & final.keys() if before[name]==final[name])
    differences=[]
    depths={}
    for name in final:
        source=(root/name).read_bytes()
        tree=ast.parse(source,filename=name)
        if any(isinstance(n,(ast.ClassDef,ast.Assert)) for n in ast.walk(tree)):
            raise RuntimeError('class or assertion: '+name)
        depths[name]=depth(tree.body)
        if depths[name]>3:
            raise RuntimeError('control depth exceeds3: '+name)
        (evidence/'final-source'/name).write_bytes(source)
        old=(root/'evidence/b6d/before-source'/name).read_text() if name in before else ''
        differences.extend(difflib.unified_diff(old.splitlines(True),source.decode().splitlines(True),fromfile='before/'+name,tofile='after/'+name))
    (evidence/'source.diff').write_text(''.join(differences))
    snapshot=dict(base='95c975e73e376c81fb0caba838659b745b362879',source_files=final,added=added,changed=changed,unchanged=unchanged,removed=removed,control_depth=depths)
    (evidence/'snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
    commands=[]
    for receipt in sorted(evidence.glob('final-test*.exit')):
        if '.pre-last.' in receipt.name:
            continue
        label=receipt.stem
        if receipt.read_text()!='0\n' or (evidence/(label+'.stderr')).read_bytes():
            raise RuntimeError('failed final command: '+label)
        commands.append(dict(command=(evidence/(label+'.command')).read_text(),exit=0,stdout=str(evidence/(label+'.stdout')),stderr=str(evidence/(label+'.stderr'))))
    if len(commands)!=6:
        raise RuntimeError('final command inventory differs')
    (evidence/'final-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    if len(cases.IMPLEMENTED)!=40 or len(model.SPECS)!=67 or len(set(catalogue.CASES)-set(cases.IMPLEMENTED))!=0:
        raise RuntimeError('case or final record inventory differs')
    normal=(evidence/'final-test_shutdown-normal.stdout').read_bytes()
    if normal!=(evidence/'final-test_shutdown-optimized.stdout').read_bytes() or len(normal.splitlines())!=80:
        raise RuntimeError('new normal/O proof differs')
    for p in root.glob('*.py'):
        if hashlib.sha256(p.read_bytes()).hexdigest()!=final[p.name]:
            raise RuntimeError('source changed during snapshot')
    contracts={case:dict(catalogue.case_budget(case)) for case in ('shutdown_active','shutdown_idle')}
    contracts.update(deadlines=[30001,900001],active_primary=3,idle_primary=1,final_requests=68,
                     active_presignal_statuses=68,idle_statuses=67,active_carried_debt=64,outputs_extra_requests=0)
    (evidence/'contracts.json').write_text(json.dumps(contracts,indent=2)+'\n')
    interpreter=Path('/home/codespace/.python/current/bin/python3')
    identity=dict(path=str(interpreter),resolved=str(interpreter.resolve()),bytes=len(interpreter.read_bytes()),sha256=hashlib.sha256(interpreter.read_bytes()).hexdigest())
    (evidence/'python-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
    print('35 modules: %d added, %d changed, %d unchanged, %d removed against released B6c' % (len(added),len(changed),len(unchanged),len(removed)))
    print('119 retained identity rows / 114 unique entries: 118 file rows / 113 unique resolved files plus codec aggregate')
    print('42 ordered codec identities and default-json aggregate match; no extra or missing codec files')
    print('Six current covering normal/-O commands exit0 with empty stderr; all35-module AST and actual inert empty/foreign argv imports pass')
    print('maximum control depth=%d; shutdown schedule=%d; ordinary final test=%d' % (max(depths.values()),depths['shutdown_cases.py'],depths['test_final.py']))
    print('40 source schedules; zero unsupported cases; general malformed/unknown/duplicate/ordering rejection retained')
    print('shutdown test: five positive executions and75 exact synthetic negative rejections per mode')
    reviewed=json.loads((evidence/'reviewed-map.json').read_text())
    for name,item in reviewed.items():
        data=(evidence/name).read_bytes()
        if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
            raise RuntimeError('reviewed source/report/receipts changed: '+name)
    for receipt in (root/'evidence/b6d').glob('final-test*.exit'):
        for suffix in ('.command','.stdout','.stderr','.exit'):
            name=receipt.stem+suffix
            if (root/'evidence/b6d'/name).read_bytes()!=(evidence/'reviewed-receipts'/name).read_bytes():
                raise RuntimeError('preceding42 receipt changed: '+name)
    reviewed_source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (evidence/'reviewed-source').glob('*.py')}
    fix_changed=sorted(name for name in final if final[name]!=reviewed_source[name])
    if fix_changed!=['adapter.py','test_final.py','test_shutdown.py']:
        raise RuntimeError('fix ownership differs')
    fix_diff=[]
    for name in fix_changed:
        fix_diff.extend(difflib.unified_diff((evidence/'reviewed-source'/name).read_text().splitlines(True),(root/name).read_text().splitlines(True),fromfile='reviewed/'+name,tofile='fix-1/'+name))
    (evidence/'fix.diff').write_text(''.join(fix_diff))
    snapshot['fix_changed']=fix_changed
    snapshot['covering_commands']='fix-1/final-commands.json'
    (evidence/'snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
    (root/'evidence/b6d/snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
    (root/'evidence/b6d/source.diff').write_text((evidence/'source.diff').read_text())
    for name in final:
        (root/'evidence/b6d/final-source'/name).write_bytes((root/name).read_bytes())
    print('Reviewed35 modules/report and all42 preceding receipts preserved; fix changes exactly3 modules')
    print('No native execution, callback/process/close proof, default/aggregate acceptance or combined all40 claim')
PY
```

Exit: `0`.

stdout:

```text
35 modules: 2 added, 9 changed, 24 unchanged, 0 removed against released B6c
119 retained identity rows / 114 unique entries: 118 file rows / 113 unique resolved files plus codec aggregate
42 ordered codec identities and default-json aggregate match; no extra or missing codec files
Six current covering normal/-O commands exit0 with empty stderr; all35-module AST and actual inert empty/foreign argv imports pass
maximum control depth=3; shutdown schedule=1; ordinary final test=2
40 source schedules; zero unsupported cases; general malformed/unknown/duplicate/ordering rejection retained
shutdown test: five positive executions and75 exact synthetic negative rejections per mode
Reviewed35 modules/report and all42 preceding receipts preserved; fix changes exactly3 modules
No native execution, callback/process/close proof, default/aggregate acceptance or combined all40 claim
```

stderr: empty.

### graph-update

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .
```

Exit: `0`.

stdout:

```text
Re-extracting code files in . (no LLM needed)...
[graphify watch] 374 file(s) not classified (no supported extension or shebang), skipped: .dockerignore, .git, .gitattributes, .gitignore, .gitmodules, Dockerfile (+368 more)
[graphify watch] No relevant changes; graphify-out left untouched.
Code graph updated. For doc/paper/image changes run /graphify --update in your AI assistant.
Tip: set GEMINI_API_KEY or GOOGLE_API_KEY to use Gemini for semantic extraction.
```

stderr: empty.

Before the first new fix-round source query/read, the prescribed Graphify prefix
ran with this exact question, exit0 (161 nodes,650-token truncation):

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "combined-cases test_ready final_collection ordinary parsed diagnostics test_final" --budget 650
```

The query raw result remains in the tool transcript; the final AST-only update
command/raw result is retained above. It reported no relevant graph changes.

# Fix round2: keep shutdown comparison baselines private through hooks

This appendix supersedes fix1's immediate shutdown publication. The original P2
ordinary-facts omission remains fixed: ordinary final_collection still publishes
its validated parsed capture immediately and returns None. The new aliasing P2
is now addressed for scoped re-review. Root's single-capture instruction was
not permission to expose a mutable shutdown comparison baseline to supplied
teardown hooks.

Before edits, the complete reviewed fix1 source/report and42+6 preceding covering
receipts were preserved under evidence/b6d/fix-2/reviewed-source/,
reviewed-report.md and reviewed-receipts/{b6d,fix-1}/. The253-file reviewed-map.json
was rehashed after the fix. Every original42+6 command/stdout/stderr/exit receipt
also still matches its separate preserved copy. Those48 commands remain proof
of their prior source versions, not a new48-command run. No old evidence or
failed-review snapshot was overwritten.

## Exact fix APIs and source changes

Only adapter.py, shutdown_cases.py and test_shutdown.py changed relative to
reviewed fix1. adapter.final_collection still parses and validates the actual
67 records and metrics, then completes canonical wire.finish_final. It creates
one bounded capture. Ordinary cases immediately retain that object on
context.final_observations and keep their existing None return. Shutdown cases
return the capture locally to their schedule without publishing it on context.
This preserves the assigned actual-capture API while keeping its mutable object
out of every teardown hook's reach.

shutdown_cases.post_deinit publishes that private capture to
context.final_observations only after process and post hooks return, their
deadlines/schemas validate, model.validate_pre_post accepts the persistent
record comparison, metrics validate and model.validate_output_pre_post accepts
output/binding comparison. The same object is retained as
context.shutdown_observations.before. No further teardown hook runs after
publication. The active/idle paths continue to use the existing returned
capture, including the bounded output and binding copies attached before hooks.

The records and metrics were parsed into new local dictionaries. outputs()
already makes separate dictionaries for each retained output and for the binding,
so mutable context.output_observations/context.output_binding are not the private
comparison snapshots. Delaying publication now protects that complete graph:
records, metrics, attached outputs and binding. No generic wrapper or immutable
proxy framework, duplicate capture, extra request, model substitution, parser,
refund, budget/deadline change or coordinator behavior was introduced.

## Actual schedule-level RED and current regression behavior

Before either implementation edit, initial-test_shutdown.py added three alias
controls and a sentinel immediately after adapter.run_case returns, before any
outer retained-app assertions. Each actual serialized active schedule accepted
corrupted post evidence, reaching the sentinel:
shutdown schedule accepted aliased post evidence. Its expected schedule-level
ValueError was absent. All three dedicated RED commands exit1 with that exact
wrong-rejection marker. This reproduces the bypass inside the schedule and does
not rely on the outer application's later independent comparison.

- alias_record changes the observed shutdown_active max_span32 to7 through the
  exposed context capture and returns post max_span7. Both are individually
  valid bounded diagnostics; the change must fail pre/post equality.
- alias_output advances producer pending/invocations/checks/blocked/attempts
  together, preserving valid producer algebra. It changes the exposed before
  output and returned post output together, and also attempts to change the
  context's original retained output observation.
- alias_binding advances the B binding generation and matching producer
  generation together, preserving their required relative generation. It edits
  both the exposed before objects and returned post objects, and attempts to
  mutate the context's original retained output/binding as well. Keeping the
  paired metadata valid avoids a weaker schema/algebra-only rejection.

With the fix, the record alias attempt gets shutdown changed nonterminal evidence
from model.validate_pre_post. Output and paired binding alias attempts get
post-deinit output changed from model.validate_output_pre_post: the private
baseline is unchanged despite edits to the public original observations.
If the schedule ever accepts any of these, the explicit post-run sentinel fails
the test before outer retained-app equality. The alias controls never skip or
weaken the existing observed-record check.

The final test additionally checks that neither final_observations nor
shutdown_observations is published at entry to every precondition, signal,
termination, idle-close, process and post hook. Positive active and idle paths
confirm the one capture is published and shared after successful comparison.
All prior exact serialization/count/debt/deadline/ordering/sensitivity checks
remain. test_final.py was unchanged and still proves ordinary capture is
available immediately after its one successful final_collection, with observed
chunks2/max_span19, None return and no additional requests.

## Current covering checks, identities and self-review

After the last source edits, exactly the requested six pinned checks ran:
test_final.py, test_shutdown.py and test_imports.py, each in normal -B -S and
optimized -B -S -O modes. All exited0 with empty stderr. Each current shutdown
mode has five positive serialized executions and78 exact synthetic negative
rejections, including the three new schedule-level alias controls. The complete
normal/O shutdown output is byte-identical. Ordinary capture and all35-module
AST/main guards/actual silent/inert empty/foreign argv import proofs pass.

Current audit rehashed119 retained input identity entries (118 file rows,
113 unique resolved file paths plus ordered42-codec aggregate), reproduced the
exact default-json digest
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473,
and confirmed the exact codec set. Maximum authored control depth remains3.
All core/model/fixture/helper/dependency/budget/deadline identities remain
unchanged. No native/socket/TLS/SSLContext/process/real-clock/probe/Git/public
operation, extra agent or broad test rerun occurred.

fix-2/fix.diff is the exact three-file delta from reviewed fix1.
fix-2/snapshot.json and final-source/ identify the35 current modules. The parent
B6d current snapshot/source.diff/final-source have been refreshed to these same
bytes; fix1's source/report/receipts remain retained unchanged, and current six
receipts are distinctly listed in fix-2/final-commands.json. Against accepted
B6c the current inventory remains2 added,9 changed,24 unchanged,0 removed.

Self-review followed the actual object ownership graph: the adapter's records
and metrics are local until returned; shutdown retains that capture locally;
attached output/binding dictionaries are copied; hooks receive only context;
publication occurs only after every supplied fact/comparison succeeds. Ordinary
publication remains immediate and ordinary None/state/effects remain intact.
The three genuine initial REDs demonstrate acceptance of valid-but-changed
observations before the fix, and the final controls require rejection by the
schedule's validators after the fix. No threshold or assertion was relaxed.
No other open API gap is identified for this finding. Root's same-reviewer
scoped re-review remains required. Default/aggregate/native/two-child all40
acceptance and broader milestone facts remain unproved as before.

Current exact35-module source map and fix ownership:

```json
{
  "base": "95c975e73e376c81fb0caba838659b745b362879",
  "source_files": {
    "adapter.py": "e03016a847a75fa5ffc03e5ff17ffc6887dff15b3ed0fa5f82f2240713698e7a",
    "admission_cases.py": "b4cac4031f9be16bca938f7167bb327f4eae4fd5667b42cb70fc23782f8fbbcf",
    "application_error_cases.py": "9d63d938391f2181205766c3297d9aae5ce6966d9f371251b9fa5aeb152d9e68",
    "cases.py": "f89fe655f8c66c98e67ffd7723b07980234e124b130a8a99a790cb80fc54bcd5",
    "concurrent_cases.py": "a9ab3e7b6f6a362c1c6d33788fa8b7c3ed5961989be1f58d7fd6cc66a998a7c1",
    "continue_quota_cases.py": "da533ef0fde4179c00427d11b689cba1fdf248e41ba01c98a47f37a08ec99e95",
    "control_reset_cases.py": "36b8fe72e24eaf8cb7a30b470ea4c23823f324373ac3d4d90a6cc8a1595979d7",
    "credit_cases.py": "f953e2bacb92c4370904cf2b6e302a215aed9bd28210290406aac965e8d2178d",
    "file_early_cases.py": "90479c670ee1d75c4974704bb6b51d4543142c80c10a8b01963a1a31e0dc9d8c",
    "lifecycle_cases.py": "3aeb930ef537ac4690ba3f0b5deaffd3a1770981e247652f9fb2f77ffd98a92c",
    "metadata_cases.py": "7a48599c53779a2414f4492371174d35030e91d1dd61570408248b7eae12b83c",
    "pause_cases.py": "c7e28527478f3a3e52de22de019e1698083a8d03b4bca3100dd4788e77a8f250",
    "producer_pressure_cases.py": "44cb04ab3eee53c50c8cd508244486ef6693646aa276836e244a9fb18caffbda",
    "shutdown_cases.py": "2856e200fa463b26c79e4e0b74cc9ead4863f9a1dd6372c0e8249fb9b163e15c",
    "test_adapter.py": "ef325e804d454e12a4f8b2d2dfa2e0c778736758cf8618334081c864940aefbf",
    "test_admission.py": "28b88c1b8dcdccc03154cb7472cf14ce0f3819de54b78d72e9fec68608381d9d",
    "test_application_error.py": "221d38b7d31fc419d990df1ce512f9cdc509e7c3a9eb1f9c4ef961a43b82c96c",
    "test_async.py": "bcf31ec8037b3ba4861d25e7983efaeef269df5c084dc3922cc358d8e94ae314",
    "test_continue_quota.py": "71ed633a7d9151dcacc99f4665b1ae45e9423ee7dc589e9607e280a67bdf9914",
    "test_control_reset.py": "7b81f969a0cd5146ac5ac075bd2cc2d25aca890c021db4ab73f828eb04780d67",
    "test_credit.py": "bd03e99dbe6d1297bc96badf870c4be7486ef2524a14befd323bbebb8a9e0a65",
    "test_file_early.py": "8feb6e45339160eb28b19a5635a22eba58cc8206f6f127975739201b0d045604",
    "test_final.py": "830e5fdfb3475b1ab11e2b956f4494abff9e7176f684e166e282b30b1d90b626",
    "test_imports.py": "1e140df0da86cfee854664cbc954842e9d51d346d210744f59057ba693e20353",
    "test_large.py": "5710cb5be11f777f2c0ba4f0b3a647227f75b5955dcf1f8cecd750419b46c7d0",
    "test_lifecycle.py": "7346386e3482a800bfe20b0dc8da8726dc66d6dd8a516ac038de4222a21f535a",
    "test_metadata_concurrency.py": "21708e73da3f401891b975414578ce136ac40a8848cfa730f429e17d9251294d",
    "test_negative.py": "91ae248806c1402bd4219474c3e08e1ef2fcb5994d3e6f7b5e7f40fac4ec47f0",
    "test_pause.py": "86f3faa897d8c278dfeef4f7359194b3eea5e1b284ba46bf012ecc6f569c291e",
    "test_producer_pressure.py": "79dc174853ad5285c37e6f36368199d20d403f3afa488e80a32a04faa036ff51",
    "test_ready.py": "600ec8b0bc072aa4d9a52417425e77c56edc2e02680bdb01d9d288c52001b442",
    "test_selection.py": "eae469c25524ddaa3b02c0474dcebae605ba0d64846d8ae50de57a76b8f57aa3",
    "test_shared.py": "cbd3370c4dd56990c126939503a35dd5eabd8a03ce71195865152510a973b91b",
    "test_shutdown.py": "5f6a9e929831a97f935cd685e98cf429ff76a9d59a01047c2cdfb2a2d637dad6",
    "test_time.py": "0e10a1c68bfdd754b67a656bd8f4cc05ca8fcf8c9af63ab66130e2e969edf967"
  },
  "added": [
    "shutdown_cases.py",
    "test_shutdown.py"
  ],
  "changed": [
    "adapter.py",
    "cases.py",
    "test_admission.py",
    "test_continue_quota.py",
    "test_final.py",
    "test_imports.py",
    "test_metadata_concurrency.py",
    "test_pause.py",
    "test_selection.py"
  ],
  "unchanged": [
    "admission_cases.py",
    "application_error_cases.py",
    "concurrent_cases.py",
    "continue_quota_cases.py",
    "control_reset_cases.py",
    "credit_cases.py",
    "file_early_cases.py",
    "lifecycle_cases.py",
    "metadata_cases.py",
    "pause_cases.py",
    "producer_pressure_cases.py",
    "test_adapter.py",
    "test_application_error.py",
    "test_async.py",
    "test_control_reset.py",
    "test_credit.py",
    "test_file_early.py",
    "test_large.py",
    "test_lifecycle.py",
    "test_negative.py",
    "test_producer_pressure.py",
    "test_ready.py",
    "test_shared.py",
    "test_time.py"
  ],
  "removed": [],
  "control_depth": {
    "adapter.py": 3,
    "admission_cases.py": 2,
    "application_error_cases.py": 1,
    "cases.py": 1,
    "concurrent_cases.py": 2,
    "continue_quota_cases.py": 2,
    "control_reset_cases.py": 1,
    "credit_cases.py": 1,
    "file_early_cases.py": 2,
    "lifecycle_cases.py": 2,
    "metadata_cases.py": 1,
    "pause_cases.py": 2,
    "producer_pressure_cases.py": 1,
    "shutdown_cases.py": 1,
    "test_adapter.py": 2,
    "test_admission.py": 3,
    "test_application_error.py": 2,
    "test_async.py": 1,
    "test_continue_quota.py": 3,
    "test_control_reset.py": 2,
    "test_credit.py": 3,
    "test_file_early.py": 3,
    "test_final.py": 2,
    "test_imports.py": 3,
    "test_large.py": 1,
    "test_lifecycle.py": 3,
    "test_metadata_concurrency.py": 3,
    "test_negative.py": 3,
    "test_pause.py": 3,
    "test_producer_pressure.py": 3,
    "test_ready.py": 3,
    "test_selection.py": 1,
    "test_shared.py": 3,
    "test_shutdown.py": 2,
    "test_time.py": 1
  },
  "fix_changed": [
    "adapter.py",
    "shutdown_cases.py",
    "test_shutdown.py"
  ],
  "covering_commands": "fix-2/final-commands.json"
}
```

## Fix2 exact commands and raw outcomes

### red-alias_binding

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
import test_shutdown

if __name__ == '__main__':
    test_shutdown.rejected('shutdown_active', 'alias_binding', 'post-deinit output changed', prior=('producer_reuse',))
PY
```

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 292, in rejected
    check(case, fault=fault, prior=prior)
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 275, in check
    raise RuntimeError('shutdown schedule accepted aliased post evidence')
RuntimeError: shutdown schedule accepted aliased post evidence

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "<stdin>", line 4, in <module>
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 294, in rejected
    require(str(error) == message, 'wrong rejection for ' + fault + ': ' + str(error))
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 19, in require
    raise RuntimeError(message)
RuntimeError: wrong rejection for alias_binding: shutdown schedule accepted aliased post evidence
```

### red-alias_output

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
import test_shutdown

if __name__ == '__main__':
    test_shutdown.rejected('shutdown_active', 'alias_output', 'post-deinit output changed', prior=('producer_reuse',))
PY
```

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 292, in rejected
    check(case, fault=fault, prior=prior)
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 275, in check
    raise RuntimeError('shutdown schedule accepted aliased post evidence')
RuntimeError: shutdown schedule accepted aliased post evidence

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "<stdin>", line 4, in <module>
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 294, in rejected
    require(str(error) == message, 'wrong rejection for ' + fault + ': ' + str(error))
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 19, in require
    raise RuntimeError(message)
RuntimeError: wrong rejection for alias_output: shutdown schedule accepted aliased post evidence
```

### red-alias_record

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
import test_shutdown

if __name__ == '__main__':
    test_shutdown.rejected('shutdown_active', 'alias_record', 'shutdown changed nonterminal evidence', prior=())
PY
```

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 292, in rejected
    check(case, fault=fault, prior=prior)
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 275, in check
    raise RuntimeError('shutdown schedule accepted aliased post evidence')
RuntimeError: shutdown schedule accepted aliased post evidence

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "<stdin>", line 4, in <module>
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 294, in rejected
    require(str(error) == message, 'wrong rejection for ' + fault + ': ' + str(error))
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py", line 19, in require
    raise RuntimeError(message)
RuntimeError: wrong rejection for alias_record: shutdown schedule accepted aliased post evidence
```

### final-test_final-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_final.py
```

Exit: `0`.

stdout:

```text
ready_buffered codec schedule passed
ordinary capture passed: heads=73 final=68 chunks=2 max_span=19 return=None extra_requests=0
```

stderr: empty.

### final-test_final-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_final.py
```

Exit: `0`.

stdout:

```text
ready_buffered codec schedule passed
ordinary capture passed: heads=73 final=68 chunks=2 max_span=19 return=None extra_requests=0
```

stderr: empty.

### final-test_imports-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `0`.

stdout:

```text
AST and inert import checks passed
```

stderr: empty.

### final-test_imports-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `0`.

stdout:

```text
AST and inert import checks passed
```

stderr: empty.

### final-test_shutdown-normal

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `0`.

stdout:

```text
shutdown_idle passed: J=69 C=69 R=0 request_sha256=e010c1916e8ddc1a1d9996511a5848c861714acc6d31c325ce6e94f9e9db99a9
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
active_hash rejected: record mismatch: sha256
barrier_changed rejected: shutdown barrier changed before signal
post_chunks rejected: shutdown changed nonterminal evidence
early_response rejected: unexpected closing target payload
termination rejected: post-signal termination differs
trailing rejected: post-signal termination differs
trailing_bool rejected: post-signal termination differs
primary_response rejected: post-signal termination differs
frames rejected: post-signal termination differs
close rejected: idle close evidence differs
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
termination_phase rejected: post-signal termination differs
termination_extra rejected: post-signal termination differs
close_method rejected: idle close evidence differs
close_kind rejected: idle close evidence differs
close_extra rejected: idle close evidence differs
retained_missing rejected: retained output observations differ
selected_output rejected: post-deinit output changed
selected_binding rejected: post-deinit binding changed
prior_idle rejected: idle child must be first
alias_record rejected: shutdown changed nonterminal evidence
alias_output rejected: post-deinit output changed
alias_binding rejected: post-deinit output changed
```

stderr: empty.

### final-test_shutdown-optimized

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py
```

Exit: `0`.

stdout:

```text
shutdown_idle passed: J=69 C=69 R=0 request_sha256=e010c1916e8ddc1a1d9996511a5848c861714acc6d31c325ce6e94f9e9db99a9
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
shutdown_active passed: J=71 C=70 R=32 request_sha256=cd66d6a961cdaddbda3c42c3531eb84fdbb0d3ace9ee50da39d5a0a06bfe7d0a
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
hooks rejected: shutdown hooks required
precondition rejected: shutdown preconditions differ
other_record rejected: record mismatch: middleware
metrics rejected: metrics differ
signal rejected: owned signal evidence differs
process rejected: shutdown process evidence differs
post_record rejected: record mismatch: middleware
post_metrics rejected: metrics differ
post_output rejected: unselected output differs
post_binding rejected: unselected binding differs
deadline rejected: deadline expired or invalid
late_process rejected: shutdown grace deadline expired
parser_residue rejected: finite response missing
late_observation rejected: observation after shutdown
active_hash rejected: record mismatch: sha256
barrier_changed rejected: shutdown barrier changed before signal
post_chunks rejected: shutdown changed nonterminal evidence
early_response rejected: unexpected closing target payload
termination rejected: post-signal termination differs
trailing rejected: post-signal termination differs
trailing_bool rejected: post-signal termination differs
primary_response rejected: post-signal termination differs
frames rejected: post-signal termination differs
close rejected: idle close evidence differs
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
signal_name rejected: owned signal evidence differs
signal_open rejected: owned signal evidence differs
signal_watcher rejected: owned signal evidence differs
signal_extra rejected: owned signal evidence differs
process_reaped rejected: shutdown process evidence differs
process_forced rejected: shutdown process evidence differs
process_run rejected: shutdown process evidence differs
process_deinit rejected: shutdown process evidence differs
process_key rejected: shutdown process evidence differs
process_extra rejected: shutdown process evidence differs
hook_missing rejected: shutdown hooks required
hook_callable rejected: shutdown hooks required
units_bool rejected: shutdown hooks required
units_zero rejected: shutdown hooks required
termination_phase rejected: post-signal termination differs
termination_extra rejected: post-signal termination differs
close_method rejected: idle close evidence differs
close_kind rejected: idle close evidence differs
close_extra rejected: idle close evidence differs
retained_missing rejected: retained output observations differ
selected_output rejected: post-deinit output changed
selected_binding rejected: post-deinit binding changed
prior_idle rejected: idle child must be first
alias_record rejected: shutdown changed nonterminal evidence
alias_output rejected: post-deinit output changed
alias_binding rejected: post-deinit output changed
```

stderr: empty.

### audit

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import ast
import difflib
import hashlib
import json
import cases
import catalogue
import model

def depth(nodes, level=0):
    maximum = level
    for node in nodes:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            maximum = max(maximum, depth(node.body))
        elif isinstance(node, (ast.If, ast.For, ast.While, ast.With, ast.Try)):
            maximum = max(maximum, depth(node.body, level + 1))
            otherwise = getattr(node, 'orelse', [])
            branch_level = level if isinstance(node, ast.If) and len(otherwise) == 1 and isinstance(otherwise[0], ast.If) else level + 1
            maximum = max(maximum, depth(otherwise, branch_level), depth(getattr(node, 'finalbody', []), level + 1))
            for handler in getattr(node, 'handlers', []):
                maximum = max(maximum, depth(handler.body, level + 1))
    return maximum

if __name__ == '__main__':
    root=Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    evidence=root/'evidence/b6d/fix-2'
    (evidence/'final-source').mkdir(exist_ok=True)
    immutable=json.loads((root/'evidence/b6c/immutable-inputs.json').read_text())
    for item in immutable['identities']:
        data=Path(item['path']).read_bytes()
        if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
            raise RuntimeError('immutable identity differs: '+item['path'])
    rows=immutable['codec_files']
    packages=Path('/tmp/uwz-h2-client-tooling/packages')
    for name,digest in rows:
        if hashlib.sha256((packages/name).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('codec identity differs: '+name)
    present={str(p.relative_to(packages)) for p in packages.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
    if present!={r[0] for r in rows} or len(rows)!=42 or hashlib.sha256(json.dumps(rows).encode()).hexdigest()!=immutable['codec_digest']:
        raise RuntimeError('ordered42 codec identity set or aggregate differs')
    files=immutable['identities']
    unique={str(Path(item['path']).resolve()) for item in files}
    if len(files)!=118 or len(unique)!=113:
        raise RuntimeError('retained identity row count differs')
    (evidence/'immutable-inputs.json').write_text(json.dumps(immutable,indent=2)+'\n')
    before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'evidence/b6d/before-source').glob('*.py'))}
    published=json.loads(Path('docs/implement-2-2-0/evidence/m2_h2_combined_disconnect_reuse/manifest.json').read_text())['current_source_files']
    if before!=published:
        raise RuntimeError('captured before bytes differ from released B6c')
    (evidence/'before-map.json').write_text(json.dumps(before,indent=2)+'\n')
    final={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob('*.py'))}
    if len(before)!=33 or len(final)!=35:
        raise RuntimeError('source module inventory differs')
    added=sorted(final.keys()-before.keys())
    removed=sorted(before.keys()-final.keys())
    changed=sorted(name for name in before.keys() & final.keys() if before[name]!=final[name])
    unchanged=sorted(name for name in before.keys() & final.keys() if before[name]==final[name])
    differences=[]
    depths={}
    for name in final:
        source=(root/name).read_bytes()
        tree=ast.parse(source,filename=name)
        if any(isinstance(n,(ast.ClassDef,ast.Assert)) for n in ast.walk(tree)):
            raise RuntimeError('class or assertion: '+name)
        depths[name]=depth(tree.body)
        if depths[name]>3:
            raise RuntimeError('control depth exceeds3: '+name)
        (evidence/'final-source'/name).write_bytes(source)
        old=(root/'evidence/b6d/before-source'/name).read_text() if name in before else ''
        differences.extend(difflib.unified_diff(old.splitlines(True),source.decode().splitlines(True),fromfile='before/'+name,tofile='after/'+name))
    (evidence/'source.diff').write_text(''.join(differences))
    snapshot=dict(base='95c975e73e376c81fb0caba838659b745b362879',source_files=final,added=added,changed=changed,unchanged=unchanged,removed=removed,control_depth=depths)
    (evidence/'snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
    commands=[]
    for receipt in sorted(evidence.glob('final-test*.exit')):
        if '.pre-last.' in receipt.name:
            continue
        label=receipt.stem
        if receipt.read_text()!='0\n' or (evidence/(label+'.stderr')).read_bytes():
            raise RuntimeError('failed final command: '+label)
        commands.append(dict(command=(evidence/(label+'.command')).read_text(),exit=0,stdout=str(evidence/(label+'.stdout')),stderr=str(evidence/(label+'.stderr'))))
    if len(commands)!=6:
        raise RuntimeError('final command inventory differs')
    (evidence/'final-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    if len(cases.IMPLEMENTED)!=40 or len(model.SPECS)!=67 or len(set(catalogue.CASES)-set(cases.IMPLEMENTED))!=0:
        raise RuntimeError('case or final record inventory differs')
    normal=(evidence/'final-test_shutdown-normal.stdout').read_bytes()
    if normal!=(evidence/'final-test_shutdown-optimized.stdout').read_bytes() or len(normal.splitlines())!=83:
        raise RuntimeError('new normal/O proof differs')
    for p in root.glob('*.py'):
        if hashlib.sha256(p.read_bytes()).hexdigest()!=final[p.name]:
            raise RuntimeError('source changed during snapshot')
    contracts={case:dict(catalogue.case_budget(case)) for case in ('shutdown_active','shutdown_idle')}
    contracts.update(deadlines=[30001,900001],active_primary=3,idle_primary=1,final_requests=68,
                     active_presignal_statuses=68,idle_statuses=67,active_carried_debt=64,outputs_extra_requests=0)
    (evidence/'contracts.json').write_text(json.dumps(contracts,indent=2)+'\n')
    interpreter=Path('/home/codespace/.python/current/bin/python3')
    identity=dict(path=str(interpreter),resolved=str(interpreter.resolve()),bytes=len(interpreter.read_bytes()),sha256=hashlib.sha256(interpreter.read_bytes()).hexdigest())
    (evidence/'python-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
    print('35 modules: %d added, %d changed, %d unchanged, %d removed against released B6c' % (len(added),len(changed),len(unchanged),len(removed)))
    print('119 retained identity rows / 114 unique entries: 118 file rows / 113 unique resolved files plus codec aggregate')
    print('42 ordered codec identities and default-json aggregate match; no extra or missing codec files')
    print('Six current covering normal/-O commands exit0 with empty stderr; all35-module AST and actual inert empty/foreign argv imports pass')
    print('maximum control depth=%d; shutdown schedule=%d; ordinary final test=%d' % (max(depths.values()),depths['shutdown_cases.py'],depths['test_final.py']))
    print('40 source schedules; zero unsupported cases; general malformed/unknown/duplicate/ordering rejection retained')
    print('shutdown test: five positive executions and78 exact synthetic negative rejections per mode')
    reviewed=json.loads((evidence/'reviewed-map.json').read_text())
    for name,item in reviewed.items():
        data=(evidence/name).read_bytes()
        if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
            raise RuntimeError('reviewed source/report/receipts changed: '+name)
    preceding=0
    for parent in (root/'evidence/b6d',root/'evidence/b6d/fix-1'):
        for receipt in parent.glob('final-test*.exit'):
            preceding+=1
            for suffix in ('.command','.stdout','.stderr','.exit'):
                name=receipt.stem+suffix
                if (parent/name).read_bytes()!=(evidence/'reviewed-receipts'/parent.name/name).read_bytes():
                    raise RuntimeError('preceding receipt changed: '+name)
    if preceding!=48:
        raise RuntimeError('preceding42+6 receipt inventory differs')
    reviewed_source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (evidence/'reviewed-source').glob('*.py')}
    fix_changed=sorted(name for name in final if final[name]!=reviewed_source[name])
    if fix_changed!=['adapter.py','shutdown_cases.py','test_shutdown.py']:
        raise RuntimeError('fix ownership differs')
    fix_diff=[]
    for name in fix_changed:
        fix_diff.extend(difflib.unified_diff((evidence/'reviewed-source'/name).read_text().splitlines(True),(root/name).read_text().splitlines(True),fromfile='reviewed/'+name,tofile='fix-2/'+name))
    (evidence/'fix.diff').write_text(''.join(fix_diff))
    snapshot['fix_changed']=fix_changed
    snapshot['covering_commands']='fix-2/final-commands.json'
    (evidence/'snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
    (root/'evidence/b6d/snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
    (root/'evidence/b6d/source.diff').write_text((evidence/'source.diff').read_text())
    for name in final:
        (root/'evidence/b6d/final-source'/name).write_bytes((root/name).read_bytes())
    print('Reviewed fix1 modules/report and all42+6 preceding receipts preserved; fix changes exactly3 modules')
    print('No native execution, callback/process/close proof, default/aggregate acceptance or combined all40 claim')
PY
```

Exit: `0`.

stdout:

```text
35 modules: 2 added, 9 changed, 24 unchanged, 0 removed against released B6c
119 retained identity rows / 114 unique entries: 118 file rows / 113 unique resolved files plus codec aggregate
42 ordered codec identities and default-json aggregate match; no extra or missing codec files
Six current covering normal/-O commands exit0 with empty stderr; all35-module AST and actual inert empty/foreign argv imports pass
maximum control depth=3; shutdown schedule=1; ordinary final test=2
40 source schedules; zero unsupported cases; general malformed/unknown/duplicate/ordering rejection retained
shutdown test: five positive executions and78 exact synthetic negative rejections per mode
Reviewed fix1 modules/report and all42+6 preceding receipts preserved; fix changes exactly3 modules
No native execution, callback/process/close proof, default/aggregate acceptance or combined all40 claim
```

stderr: empty.

### graph-update

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .
```

Exit: `0`.

stdout:

```text
Re-extracting code files in . (no LLM needed)...
[graphify watch] 374 file(s) not classified (no supported extension or shebang), skipped: .dockerignore, .git, .gitattributes, .gitignore, .gitmodules, Dockerfile (+368 more)
[graphify watch] No relevant changes; graphify-out left untouched.
Code graph updated. For doc/paper/image changes run /graphify --update in your AI assistant.
Tip: set GEMINI_API_KEY or GOOGLE_API_KEY to use Gemini for semantic extraction.
```

stderr: empty.

Before the first new fix2 codebase source query/read, the prescribed Graphify
prefix ran this exact query, exit0 (204 nodes,650-token truncation):

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "shutdown_cases post_deinit final_observations before outputs binding alias test_shutdown" --budget 650
```

Its raw response is in the tool transcript. The final AST-only update command
and raw result are retained above; it reported no relevant graph changes.
