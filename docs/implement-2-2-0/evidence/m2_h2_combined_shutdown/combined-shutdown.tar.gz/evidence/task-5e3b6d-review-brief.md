# B6d independent shutdown source review

Review spec compliance and code quality for the two shutdown schedules only.
Requirements: task-5e3b6d-brief.md, release addendum, original cases brief and
accepted combined architecture in this plan workspace. Claims:
task-5e3b6d-report.md. Full diff: task-5e3b6d-review-source.diff,45608 bytes,
SHA256 a3ac9745cbdfa465528f4050954f61bf6462e316eab5a9cf782192746631e2f8.
Root receipt/identity audit: task-5e3b6d-root-final-audit.json.
Base95c975e73e376c81fb0caba838659b745b362879; head is the exact ignored
35-module snapshot, no new task commit. Source approval remains pending.

Read the full diff once (tests first, context10). Do not reread changed files
unless a needed function is cut off mid-hunk; identify that gap. Inspect
unchanged code only for a named concrete risk, one focused check per risk.
Do not crawl or rerun Git. Treat reports and Root audit as claims to evaluate.

Binding requirements copied from the brief:

- "Collect all67 statuses and one metrics exactly once before signal, with
  held stream and every prior persistent record intact. Active row equals
  its preceding paused barrier. These68 observations are included in71/70,
  never append another collection."
- "Preserve parser/both ledgers/stage/deadline and carried debt into final capture."
- "Do not fabricate finished primary or clear stage/ledger state to enter final."
- "No observation requests follow signal."
- "Fresh separate child/application baseline, not a main-child teardown relabeled
  as shutdown_idle."
- "Source closes the idle client normally before owned SIGTERM/reap; it does not
  require disconnect's ssl_unwrap/TCP-EOF experiment."
- "output_stage.signal is explicitly active-only; do not mutate core to invent
  an idle-held termination."
- "Seeded model records remain synthetic preconditions, not execution of
  earlier38 cases or all40 acceptance. No callback/native/process proof claim."
- "No product/model/core/fixture/dependency/capacity/budget/deadline changes,
  native/build/server/socket/SSLContext/TLS-close/real-clock/process ownership/
  transfer/descriptor/kernel/fault/cancel/scheduling/race/panic/leak experiments,
  old entrypoints/Git/public changes or other agents. Pure in-memory codecs and
  caller-supplied facts only."

The brief supplies exact budgets, metadata, termination phase, typed supplied
facts, units/grace/deadline rules, pre/post invariants and output/binding
retention. Review literally. Named cross-cutting risks include held final
collection, canonical counter interpretation, common adapter callers,
post-boundary observation rejection, deadline clipping/units, and stable copies
of actual parsed before facts/outputs through caller-supplied teardown hooks.
The report identifies ordinary final-facts retention as a remaining parent
seam; compare this and every other scope statement with the actual requirements.

Root independently checked35 current/frozen hashes,33 baseline archived source
hashes, all42 actual normal/O receipts (21-suite/mode multiset, exit0/emptyerr),
five positive/75 named rejection lines per new-suite mode,472 unchanged prior
published raw files,119 retained identity entries/113unique file paths and all
42 ordered codec files. No tests reran. Initial Root metadata history-path
normalization error was corrected; source and tests did not change.

Do not repeat passed tests. A focused test is appropriate only for a concrete
unanswered doubt and must obey the source-only limits. Broad native/project
gates remain required later. Apply AGENTS/conventions, code-review-and-quality
and the explicitly requested thermo-nuclear structural lens with project
overrides. Graphify before new codebase searches using the release addendum's
exact prefix; provided paths are located. No edits/index/ref/Git/service writes,
subagents/external model CLI or forbidden execution. You are read-only and not
alone. Return full SPEC PASS/FAIL and QUALITY APPROVED/NEEDS FIXES verdicts,
actionable severity/file:line/failure-scenario findings and cannot-verify gaps.
