# B6d fix round1/5

Original task and constraints remain binding. Open finding is the complete P2
in task-5e3b6d-review-report.md, copied from the independent final verdict.
Implement that finding; no broader coordinator implementation is released.

Root ruling: preserve the existing ordinary None return and request/count/
deadline/state behavior, while retaining the validated actual records/metrics
on the caller-owned context for every successful final collection. Use a
single bounded capture in the existing seam; shutdown returns may reuse it.
Do not add requests, substitute model recipes, introduce an accessor wrapper
or discard callback diagnostics that model expectations leave unconstrained.
This resolves the current shared-seam requirement. Root's earlier deferral to
parent work was incorrect; the original brief remains the authority.

Before edits, snapshot the reviewed35 modules and current report/receipts as
the fix base and retain the new regression's actual RED scope. Covering tests:
test_final.py (ordinary parsed capture regression, including valid observed
diagnostics), test_shutdown.py (both shutdown return/retention/ordering), and
test_imports.py (all guards/AST/actual inert imports). Run these in pinned
normal/-O modes after the last edits. No full42 rerun unless a concrete new
failure or additional change warrants it. Keep the42 preceding receipts and
report source version clearly separate from current covering checks.

Append the fix report to task-5e3b6d-report.md with APIs/files, exact commands,
raw RED/GREEN/intermediates, final35-module hashes and input/guard proof.
Refresh current snapshot/source.diff without overwriting the original failed
review source/report evidence. Root generates the scoped fix diff and asks
the same reviewer to re-review only this finding/new breakage in that diff.

Same ownership and no-subagents/Git/public/native/core/model/fixture/budget/
deadline/dependency/probe restrictions. You are not alone; preserve other
edits. Return only status/report path, covering test summary, and concerns.
