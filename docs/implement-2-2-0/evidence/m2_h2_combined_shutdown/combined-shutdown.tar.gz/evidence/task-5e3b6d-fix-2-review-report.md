Alias P2: ADDRESSED. Original ordinary-retention P2: remains ADDRESSED.

adapter.py:393 now returns shutdown's capture privately while retaining
ordinary captures immediately with the existing None return.
shutdown_cases.py:68 publishes shutdown's capture only after all teardown
hooks and record/metric/output/binding validations finish. Parsed records/
metrics and copied output/binding observations remain inaccessible through
the hook context during comparison.

The regressions check every teardown hook's publication boundary and require
schedule-level rejection of record, output and paired-binding alias attempts.
Their post-run sentinel prevents an outer assertion from masking acceptance.

New breakage: No actionable findings in the three-file fix diff. Request
counts, deadlines, state ownership and ordinary capture behavior are preserved
without another capture or abstraction.

Fix-round verdict: SPEC PASS / QUALITY APPROVED, scoped to this fix and the
reviewed B6d findings.

Verification boundaries: Root's audit records three actual alias REDs and six
current normal/optimized covering passes, with preceding receipts preserved
separately. Reviewer read the diff, appended report and audit; no passed checks
reran or identity audit was reproduced. No files changed. Combined all40/
default/subset orchestration, native execution and broader gates remain outside
this approval.
