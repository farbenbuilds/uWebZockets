SPEC: FAIL. QUALITY: NEEDS FIXES. Scope: B6d shutdown source unit only.

P2 — Preserve final facts for ordinary selections. adapter.py:393 returns
validated records/metrics only for the two shutdown IDs. A legitimate subset
ending in ready_buffered, reuse, or another ordinary case completes its sole
68-response collection but loses the actual parsed facts. Its later post-deinit
comparison cannot recover observed chunk diagnostics and other values without
another forbidden collection or substituting model expectations.

The B6d brief explicitly assigns this shared seam the extension to return
validated before records/metrics for later comparison. The implementation
report acknowledges the omission but reclassifies it as parent work; that does
not satisfy the assigned requirement. Return the capture consistently, or
retain it on the context if preserving the existing ordinary None return is
necessary. Add a focused ordinary-final regression proving the actual parsed
facts remain available without further requests.

No additional actionable findings.

Evidence and strengths:

- Read the complete supplied diff once, tests first, against the task brief,
  release addendum, original cases brief, accepted architecture, conventions,
  specialist instructions, and both requested review skills.
- Active shutdown preserves the held primary, parser, ledgers, debt and
  deadlines through canonical final collection and termination. Counter
  handling includes the final 68 responses exactly once.
- Idle uses primary health stream 1, a fresh application precondition, normal
  close before signal, and no invented active-only stage transition.
- Before-output and binding snapshots are copied before teardown hooks;
  canonical model validators check persistent records and output equality.
- Shutdown-specific orchestration resides in a compact dedicated module.
  Structural review found no additional file-size or branching regression.
- Root's audit reports42 successful normal/optimized receipts,35 source
  identities, unchanged prior evidence, and pinned input verification. Tests
  cover exact serialization and numerous typed rejection paths.

Verification boundaries:

- No tests reran; no files, Git state or services changed.
- Root's receipt/identity audit was reviewed, not independently reproduced.
- Synthetic prior records do not establish execution of earlier cases,
  complete default/subset orchestration or combined all40 acceptance.
- Native callbacks/processes/sockets/TLS/real deadlines/post-deinit capture
  and broad project gates remain outside this release and unverified.
