# Task5e3b6d: active and idle shutdown schedules

Released after B6c source/publication review and verified fork push of
95c975e73e376c81fb0caba838659b745b362879. Accepted33-module map is
docs/implement-2-2-0/evidence/m2_h2_combined_disconnect_reuse/manifest.json;
task-5e3b6c-root-commit-audit.json verifies committed/pushed byte identities.
Accepted38/40 source cases, no all40/native acceptance. Read
task-5e3b-release-addendum.md, original cases brief
and accepted task-5e-combined-architecture.md for unchanged all40 requirements.
Own concrete shutdown schedule/tests, minimal actual-used adapter/selection/
import changes, evidence/b6d and task-5e3b6d-report.md. Root owns delivery/Git;
you are not alone, preserve other edits. No agents or external model CLI.

Own new shutdown_cases.py/test_shutdown.py, the minimal used shared seams,
evidence/b6d and this task's report. Preserve the approved lifecycle modules
and all prior raw evidence. B6c adapter.run_case now accepts a disconnect hook
and returns the final context; preserve that replacement context contract and
ordinary callers. Retained output_observations/output_binding remain available.
Current final_collection has the ordinary completion/no-held/None-return
contract described below; inspect its actual implementation before extending.

Nov2 input recovery is recorded in task-5e3b6c-root-publication-resume.json.
All required source inputs/model/core/codecs/fixture/reference files were
restored and rehashed. Historical full candidate/libxev recovery was before
the reset; full trees are not needed or released for this source task. Do not
rebuild missing binaries or run old entrypoints. The exact pinned Python and
ordered codec recipe remain in the release addendum and B6c immutable-inputs.

Exact unsupported assertions2->0 and truthful40-case description are authorized
only when both schedules exist and pass. Keep every unknown/malformed/duplicate/
ordering rejection and all rejection loops; an empty unsupported set after all
40 implementations is not permission to remove general selection validation.
Source coverage40 does not earn full default/aggregate/native acceptance.

| Case | Heads J | Small C | Request flow R |
| --- | ---: | ---: | ---: |
| shutdown_active | 71 | 70 | 32 |
| shutdown_idle | 69 | 69 | 0 |

Source authority: authenticated /tmp/uwz-task5c3-runtime-v2/lifecycle_cases.py
shutdown_active at220 onward; current model/catalogue/fixture and accepted
architecture. Idle baseline source is authenticated credit/fix1/run_live.py
403..447 under .uwz-work/evidence/h2-streaming/integration-owned: final records/
metrics, normal client close, owned SIGTERM, successful reap and unchanged
post-deinit records. Read only; never execute old runner/close/native code.

## Active

Must be last main-child selection, prior cases complete, client open. Initial
health1, primary3 declared32 exact model metadata, role transport/owned_shutdown,
held true; send32 without END, observe accepted7/paused once. Collect all67
statuses and one metrics exactly once before signal, with held stream and every
prior persistent record intact. Active row equals its preceding paused barrier.
These68 observations are included in71/70, never append another collection.

Preserve parser/both ledgers/stage/deadline and carried debt into final capture.
Canonical wire.enter_final(stage,held) and finish_final enforce held state,
exact68 requests and existing byte/read caps. adapter.final_collection currently
requires context.completed, passes no held argument and returns no facts. Extend
that actual phase seam minimally to support held collection and return validated
before records/metrics for later comparison, preserving ordinary-case behavior.
Do not fabricate finished primary or clear stage/ledger state to enter final.

Only after valid final collection, validate supplied owned signal evidence:
SIGTERM, owned_identity/watcher_installed/client_open true, with grace at most15
seconds clipped to existing case/whole deadlines. Use output_stage.signal and
canonical begin_termination/finish_termination actual post_signal policy. No
successful primary response; valid-frame EOF/tls_eof, zero trailing bytes.
Validate supplied normal process outcome exit0/reaped/notforced/run_ok/deinit_ok/
key_removed and post-deinit records/metrics. model.validate_pre_post permits only
shutdown_active cancellation0->1, active/paused false, reason shutdown; its byte/
hash/chunk diagnostics and every other record remain unchanged. No end callback.
Use retained output_observations/output_binding from selected earlier cases for
model output/binding pre/post checks; no extra output GETs beyond exact budgets.

## Idle

Fresh separate child/application baseline, not a main-child teardown relabeled
as shutdown_idle. Health plus67 all-zero body rows and one metrics equals69.
Canonical stage primary is the completed health1/small response; configure that
actual binding instead of default primary5. Complete final collection with no
held response/parser/ledger residue, all slots inactive and buffered count69.

Source closes the idle client normally before owned SIGTERM/reap; it does not
require disconnect's ssl_unwrap/TCP-EOF experiment. Validate caller-supplied idle
close/process/post-deinit facts against that source, preserving zero records and
unchanged metrics. output_stage.signal is explicitly active-only; do not mutate
core to invent an idle-held termination. Idle adapter must enforce completed
canonical collection and reject later observations while validating supplied
teardown facts. Real socket/process/close execution remains unreleased.

## Proof and handoff

Begin actual serialized tests before implementation, retain initial tests/real
RED exact scope and all intermediates. Independently check exact requests/END/
payload/hash/settings, one held primary/no premature terminal, finite paused
barrier, all67+metrics before signal, no post-signal observations, deadlines/
debt carried into final, correct transport outcome and no unexpected post-deinit
changes. Test fresh idle app separately and active shared-state selected-before
behavior. Seeded model records remain synthetic preconditions, not execution
of earlier38 cases or all40 acceptance. No callback/native/process proof claim.

Target typed supplied-fact/selection/ordering/deadline/parser/record/metric/output
corruptions as pure sensitivity controls, not native fault experiments. Unknown
and malformed selection rejection still occurs before effects. Default empty/
subset/child-plan/global aggregate acceptance remains parent follow-up unless
explicitly exercised against its full requirement set.

After last edits capture relevant pinned Python -B -S normal/O commands and raw
stdout/stderr/exits, changed-seam regressions, all-module guards/AST and actual
silent/inert empty/foreign-argv rejecting imports; exact snapshot vs released
B6c. No authored classes/custom exceptions/assert proof/hidden mutable globals/
dead code/deep nesting. Prescribed graphify before first source read/search.
Retain exact42codec/default-json ordered digest and resolved identity counts.

No product/model/core/fixture/dependency/capacity/budget/deadline changes,
native/build/server/socket/SSLContext/TLS-close/real-clock/process ownership/
transfer/descriptor/kernel/fault/cancel/scheduling/race/panic/leak experiments,
old entrypoints/Git/public changes or other agents. Pure in-memory codecs and
caller-supplied facts only. Report smallest actual immutable API gap and continue
independent work. Full report records exact APIs/files/commands/raw/history/
identities/self-review and remaining facts; Root reviews independently.
