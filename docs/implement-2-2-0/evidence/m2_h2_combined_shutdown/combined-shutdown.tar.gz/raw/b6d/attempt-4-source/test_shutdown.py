"""Serialized shutdown schedules with supplied teardown and app facts only."""
import copy
import hashlib
import json
import adapter
import catalogue
import h2_client
import hpack
import model
import output_stage
import test_lifecycle
import test_ready


def require(value, message):
    if not value:
        raise RuntimeError(message)


def check(case, *, prior=(), fault=None, units=1000, outcome='eof'):
    selection = prior + (case,)
    app = model.records(selection, 'before')
    for item in app.values():
        if item.get('chunks', 0) is None:
            item['chunks'] = (item['bytes'] + 8191) // 8192
        if item.get('max_span', 0) is None:
            item['max_span'] = min(item['bytes'], 8192)
    if case == 'shutdown_active':
        app['shutdown_active'].update(chunks=1, max_span=32)
    state = dict(startup=True, buffer=bytearray(), pending=[], heads=0, status=0, metrics=0,
                 data=0, ends=0, settings=0, signal=False, closed=False, reads=0,
                 decoder=hpack.Decoder(), encoder=hpack.Encoder(), digest=hashlib.sha256())
    caller_time = [1]
    paths = ['/health']
    if case == 'shutdown_active':
        paths += ['/limit/shutdown_active?case=shutdown_active', '/status/shutdown_active']
    paths += ['/status/' + tag for tag in model.SPECS] + ['/metrics']
    order = iter(paths)

    def clock():
        caller_time[0] += 1
        if fault == 'deadline' and state['status'] == 3:
            return 30001
        return caller_time[0]

    def response(stream, body):
        block = state['encoder'].encode(((':status', '200'), ('x-middleware', 'retained')))
        state['pending'].append(test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body))

    def packet_received(packet):
        kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
        if kind == 4:
            require(packet == test_ready.frame(4, 1, 0, b''), 'unexpected settings')
            state['settings'] += 1
            return
        if kind == 0:
            require(case == 'shutdown_active' and stream == 3 and flags == 0 and state['data'] == 0, 'request DATA or END differs')
            require(packet[9:] == model.payload_span(32, 0, 32), 'request payload differs')
            state['data'] += len(packet[9:])
            state['ends'] += flags & 1
            require(hashlib.sha256(packet[9:]).hexdigest() == model.H32, 'request hash differs')
            return
        require(kind == 1, 'unexpected outgoing frame')
        entries = list(state['decoder'].decode(packet[9:]))
        path = dict(entries)[':path']
        require(path == next(order, None) and stream == 2 * state['heads'] + 1, 'request ordering differs')
        upload = path.startswith('/limit/')
        expected = [(':method', 'POST' if upload else 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)]
        if upload:
            expected += [('content-length', '32'), ('x-case', 'shutdown_active')]
        require(entries == expected and flags == (4 if upload else 5), 'request metadata or END differs')
        state['digest'].update(json.dumps((stream, entries, flags)).encode())
        state['heads'] += 1
        if upload:
            if fault == 'early_response':
                response(stream, b'')
            return
        if path == '/health':
            response(stream, b'ok')
            return
        if path.startswith('/status/'):
            state['status'] += 1
            tag = path[8:]
            item = dict(app[tag])
            if fault == 'active_hash' and tag == 'shutdown_active':
                item['sha256'] = model.H32
            if fault == 'barrier_changed' and tag == 'shutdown_active' and state['status'] > 1:
                item['max_span'] = 7
            if fault == 'other_record' and tag == 'empty_headers':
                item['middleware'] += 1
            response(stream, json.dumps(item).encode())
            return
        require(path == '/metrics', 'unexpected observation')
        state['metrics'] += 1
        value = model.metrics(selection, 'before')
        value.update(slot0_active=case == 'shutdown_active', slot1_active=False)
        if fault == 'metrics':
            value['buffered_middleware'] += 1
        response(stream, json.dumps(value).encode())

    def send(data):
        require(not state['signal'] and not state['closed'], 'send after shutdown')
        require(type(data) is bytes and len(data) <= 8192, 'send bound differs')
        if state['startup']:
            state['startup'] = False
            require(data[:24] == b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n' and len(data) == 75, 'startup differs')
            return
        state['buffer'].extend(data)
        while len(state['buffer']) >= 9:
            size = int.from_bytes(state['buffer'][:3], 'big')
            if len(state['buffer']) < size + 9:
                return
            packet = bytes(state['buffer'][:size + 9])
            del state['buffer'][:size + 9]
            packet_received(packet)

    def receive():
        require(not state['signal'] and not state['closed'], 'receive after shutdown')
        state['reads'] += 1
        require(state['pending'] and state['reads'] <= 150, 'finite response missing')
        packet = state['pending'].pop(0)
        if fault == 'parser_residue' and state['metrics']:
            packet += b'\x00'
        return packet, clock()

    context = adapter.open_case(case, h2_client.new_protocol(), send, 1, 30001, 900001, selected_before=prior, clock=clock)
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    adapter.observe(context, test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b''), clock())
    identities = {name: context[name] for name in ('stage', 'raw', 'request', 'credit', 'records')}

    def preconditions(current):
        require(current is context and state['heads'] == 0, 'preconditions after effects')
        result = dict(client_open=True, prior_complete=True) if case == 'shutdown_active' else dict(client_open=True, fresh_application=True)
        if fault == 'precondition':
            result['client_open'] = 1
        return result

    def signal(current, deadline):
        require(current['stage']['final_complete'] and state['metrics'] == 1 and state['status'] == (68 if case == 'shutdown_active' else 67), 'signal before final collection')
        require(not state['pending'] and not state['buffer'] and next(order, None) is None, 'signal before finite boundary')
        require(deadline == (state['grace'] if case == 'shutdown_idle' else min(current['now'] + 15 * units, 30001, 900001)), 'grace deadline differs')
        require(all(current[key] is value for key, value in identities.items()), 'final objects replaced')
        require((current['stage']['case_deadline'], current['stage']['whole_deadline']) == (30001, 900001), 'deadline widened')
        if case == 'shutdown_active':
            require(not state['closed'] and set(current['records']) == {3} and not current['stage']['primary_complete'], 'held primary fabricated complete')
            require(current['request']['connection_debt'] == 32 and current['request']['stream_debt_total'] == 32, 'final debt lost')
            require(current['stage']['final_budget'] == catalogue.final_budget(64), 'final debt bound differs')
        else:
            require(state['closed'] and not current['records'] and not current['stage']['active'] and not current['credit']['streams'], 'idle residue or client still open')
        state['signal'] = True
        result = dict(signal='SIGTERM', owned_identity=True, watcher_installed=True, client_open=case == 'shutdown_active')
        if fault == 'signal':
            result['owned_identity'] = 1
        if fault == 'late_observation':
            adapter.get(current, '/health', receive)
        return result

    def termination(current, deadline):
        require(current['stage']['signaled'] and current['raw']['closing']['phase'] == 'post_signal', 'canonical post-signal phase missing')
        result = dict(phase='post_signal', outcome=outcome, primary_response=False, frames_valid=True, trailing_bytes=0)
        field = {'termination': 'outcome', 'trailing': 'trailing_bytes', 'trailing_bool': 'trailing_bytes', 'primary_response': 'primary_response', 'frames': 'frames_valid'}.get(fault)
        if field is not None:
            result[field] = 'reset' if field == 'outcome' else False if fault == 'trailing_bool' else 1 if field == 'trailing_bytes' else True if field == 'primary_response' else 1
        return result

    def close(current, deadline):
        require(current['stage']['final_complete'] and not state['signal'], 'idle close out of order')
        require(deadline == min(current['now'] + 15 * units, 30001, 900001), 'idle grace deadline differs')
        state['grace'] = deadline
        state['closed'] = True
        return dict(method='close', client_closed=1 if fault == 'close' else True, close='normal')

    def process(current, deadline):
        require(state['signal'], 'process before signal')
        result = dict(exit_code=0, reaped=True, forced=False, run_ok=True, deinit_ok=True, key_removed=True)
        if fault == 'process':
            result['exit_code'] = False
        if fault == 'late_process':
            caller_time[0] = deadline
        return result

    def post(current, deadline):
        records = copy.deepcopy(app)
        if case == 'shutdown_active':
            records['shutdown_active'].update(cancels=1, active=False, paused=False, reason='shutdown')
        if fault == 'post_chunks':
            records['shutdown_active']['max_span'] = 7
        if fault == 'post_record':
            records['empty_headers']['middleware'] += 1
        metrics = model.metrics(selection, 'after')
        metrics.update(slot0_active=False, slot1_active=False)
        if fault == 'post_metrics':
            metrics['buffered_middleware'] += 1
        result = dict(records=records, metrics=metrics, outputs=model.default_outputs(), binding=model.default_binding())
        if fault == 'post_output':
            result['outputs']['stream_file']['closes'] = 1
        if fault == 'post_binding':
            result['binding']['binding_generation'] = 1
        return result

    hooks = dict(preconditions=preconditions, signal=signal, process=process, post=post, units_per_second=units)
    hooks['termination' if case == 'shutdown_active' else 'close'] = termination if case == 'shutdown_active' else close
    if fault == 'hooks':
        hooks['extra'] = close
    adapter.run_case(context, receive, shutdown=hooks)
    require(context['completed'] and context['stage']['final_complete'], 'shutdown incomplete')
    expected = (71, 70, 32) if case == 'shutdown_active' else (69, 69, 0)
    require((state['heads'], context['stage']['case_state']['small'] + context['stage']['final_registered'], state['data']) == expected, 'exact J C R differs')
    require(state['ends'] == 0 and state['settings'] == 1 and state['metrics'] == 1, 'END settings collection counts differ')
    require(not state['pending'] and not state['buffer'] and not context['records'] and not context['stage']['active'], 'shutdown response residue')
    test_lifecycle.reject_call(adapter.observe, 'observation after shutdown', context, b'x', clock())
    print(case + ' passed: J=%d C=%d R=%d request_sha256=%s' % (*expected, state['digest'].hexdigest()))
    return context


def rejected(case, fault, message):
    try:
        check(case, fault=fault)
    except (ValueError, RuntimeError) as error:
        require(str(error) == message, 'wrong rejection for ' + fault + ': ' + str(error))
        print(fault + ' rejected: ' + str(error))
        return
    raise RuntimeError('corruption accepted: ' + fault)


def main():
    check('shutdown_idle')
    check('shutdown_active')
    check('shutdown_active', prior=('empty_headers', 'reuse'))
    check('shutdown_active', outcome='tls_eof', units=2000)
    shared = (('hooks', 'shutdown hooks required'), ('precondition', 'shutdown preconditions differ'),
              ('other_record', 'record mismatch: middleware'), ('metrics', 'metrics differ'),
              ('signal', 'owned signal evidence differs'), ('process', 'shutdown process evidence differs'),
              ('post_record', 'record mismatch: middleware'), ('post_metrics', 'metrics differ'),
              ('post_output', 'unselected output differs'), ('post_binding', 'unselected binding differs'),
              ('deadline', 'deadline expired or invalid'), ('late_process', 'shutdown grace deadline expired'),
              ('parser_residue', 'incomplete final collection'), ('late_observation', 'observation after shutdown'))
    for case in ('shutdown_active', 'shutdown_idle'):
        for fault, message in shared:
            rejected(case, fault, message)
    for fault, message in (('active_hash', 'record mismatch: sha256'), ('barrier_changed', 'shutdown barrier changed before signal'),
                           ('post_chunks', 'shutdown changed nonterminal evidence'), ('early_response', 'invalid terminal'),
                           ('termination', 'post-signal termination differs'), ('trailing', 'post-signal termination differs'),
                           ('trailing_bool', 'post-signal termination differs'), ('primary_response', 'post-signal termination differs'),
                           ('frames', 'post-signal termination differs')):
        rejected('shutdown_active', fault, message)
    rejected('shutdown_idle', 'close', 'idle close evidence differs')


if __name__ == '__main__':
    main()
