export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
import adapter
import h2_client


def reject_effect(*_args):
    raise RuntimeError('idle prior-selection guard performed an effect')


if __name__ == '__main__':
    for prior in (('empty_headers',), ('shutdown_active',), ('shutdown_idle',)):
        try:
            adapter.open_case('shutdown_idle', h2_client.new_protocol(), reject_effect, 1, 30001, 900001,
                              selected_before=prior, clock=reject_effect)
        except ValueError as error:
            if str(error) != 'invalid previous selection':
                raise RuntimeError('wrong prior-selection guard: '+str(error))
        else:
            raise RuntimeError('idle accepted a previous application selection')
    print('Three actual idle open-case prior-selection guards reject before send/time hooks')
PY
