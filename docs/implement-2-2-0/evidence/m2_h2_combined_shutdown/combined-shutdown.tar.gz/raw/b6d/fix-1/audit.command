export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import ast
import difflib
import hashlib
import json
import cases
import catalogue
import model

def depth(nodes, level=0):
    maximum = level
    for node in nodes:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            maximum = max(maximum, depth(node.body))
        elif isinstance(node, (ast.If, ast.For, ast.While, ast.With, ast.Try)):
            maximum = max(maximum, depth(node.body, level + 1))
            otherwise = getattr(node, 'orelse', [])
            branch_level = level if isinstance(node, ast.If) and len(otherwise) == 1 and isinstance(otherwise[0], ast.If) else level + 1
            maximum = max(maximum, depth(otherwise, branch_level), depth(getattr(node, 'finalbody', []), level + 1))
            for handler in getattr(node, 'handlers', []):
                maximum = max(maximum, depth(handler.body, level + 1))
    return maximum

if __name__ == '__main__':
    root=Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    evidence=root/'evidence/b6d/fix-1'
    (evidence/'final-source').mkdir(exist_ok=True)
    immutable=json.loads((root/'evidence/b6c/immutable-inputs.json').read_text())
    for item in immutable['identities']:
        data=Path(item['path']).read_bytes()
        if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
            raise RuntimeError('immutable identity differs: '+item['path'])
    rows=immutable['codec_files']
    packages=Path('/tmp/uwz-h2-client-tooling/packages')
    for name,digest in rows:
        if hashlib.sha256((packages/name).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('codec identity differs: '+name)
    present={str(p.relative_to(packages)) for p in packages.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
    if present!={r[0] for r in rows} or len(rows)!=42 or hashlib.sha256(json.dumps(rows).encode()).hexdigest()!=immutable['codec_digest']:
        raise RuntimeError('ordered42 codec identity set or aggregate differs')
    files=immutable['identities']
    unique={str(Path(item['path']).resolve()) for item in files}
    if len(files)!=118 or len(unique)!=113:
        raise RuntimeError('retained identity row count differs')
    (evidence/'immutable-inputs.json').write_text(json.dumps(immutable,indent=2)+'\n')
    before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'evidence/b6d/before-source').glob('*.py'))}
    published=json.loads(Path('docs/implement-2-2-0/evidence/m2_h2_combined_disconnect_reuse/manifest.json').read_text())['current_source_files']
    if before!=published:
        raise RuntimeError('captured before bytes differ from released B6c')
    (evidence/'before-map.json').write_text(json.dumps(before,indent=2)+'\n')
    final={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob('*.py'))}
    if len(before)!=33 or len(final)!=35:
        raise RuntimeError('source module inventory differs')
    added=sorted(final.keys()-before.keys())
    removed=sorted(before.keys()-final.keys())
    changed=sorted(name for name in before.keys() & final.keys() if before[name]!=final[name])
    unchanged=sorted(name for name in before.keys() & final.keys() if before[name]==final[name])
    differences=[]
    depths={}
    for name in final:
        source=(root/name).read_bytes()
        tree=ast.parse(source,filename=name)
        if any(isinstance(n,(ast.ClassDef,ast.Assert)) for n in ast.walk(tree)):
            raise RuntimeError('class or assertion: '+name)
        depths[name]=depth(tree.body)
        if depths[name]>3:
            raise RuntimeError('control depth exceeds3: '+name)
        (evidence/'final-source'/name).write_bytes(source)
        old=(root/'evidence/b6d/before-source'/name).read_text() if name in before else ''
        differences.extend(difflib.unified_diff(old.splitlines(True),source.decode().splitlines(True),fromfile='before/'+name,tofile='after/'+name))
    (evidence/'source.diff').write_text(''.join(differences))
    snapshot=dict(base='95c975e73e376c81fb0caba838659b745b362879',source_files=final,added=added,changed=changed,unchanged=unchanged,removed=removed,control_depth=depths)
    (evidence/'snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
    commands=[]
    for receipt in sorted(evidence.glob('final-test*.exit')):
        if '.pre-last.' in receipt.name:
            continue
        label=receipt.stem
        if receipt.read_text()!='0\n' or (evidence/(label+'.stderr')).read_bytes():
            raise RuntimeError('failed final command: '+label)
        commands.append(dict(command=(evidence/(label+'.command')).read_text(),exit=0,stdout=str(evidence/(label+'.stdout')),stderr=str(evidence/(label+'.stderr'))))
    if len(commands)!=6:
        raise RuntimeError('final command inventory differs')
    (evidence/'final-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    if len(cases.IMPLEMENTED)!=40 or len(model.SPECS)!=67 or len(set(catalogue.CASES)-set(cases.IMPLEMENTED))!=0:
        raise RuntimeError('case or final record inventory differs')
    normal=(evidence/'final-test_shutdown-normal.stdout').read_bytes()
    if normal!=(evidence/'final-test_shutdown-optimized.stdout').read_bytes() or len(normal.splitlines())!=80:
        raise RuntimeError('new normal/O proof differs')
    for p in root.glob('*.py'):
        if hashlib.sha256(p.read_bytes()).hexdigest()!=final[p.name]:
            raise RuntimeError('source changed during snapshot')
    contracts={case:dict(catalogue.case_budget(case)) for case in ('shutdown_active','shutdown_idle')}
    contracts.update(deadlines=[30001,900001],active_primary=3,idle_primary=1,final_requests=68,
                     active_presignal_statuses=68,idle_statuses=67,active_carried_debt=64,outputs_extra_requests=0)
    (evidence/'contracts.json').write_text(json.dumps(contracts,indent=2)+'\n')
    interpreter=Path('/home/codespace/.python/current/bin/python3')
    identity=dict(path=str(interpreter),resolved=str(interpreter.resolve()),bytes=len(interpreter.read_bytes()),sha256=hashlib.sha256(interpreter.read_bytes()).hexdigest())
    (evidence/'python-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
    print('35 modules: %d added, %d changed, %d unchanged, %d removed against released B6c' % (len(added),len(changed),len(unchanged),len(removed)))
    print('119 retained identity rows / 114 unique entries: 118 file rows / 113 unique resolved files plus codec aggregate')
    print('42 ordered codec identities and default-json aggregate match; no extra or missing codec files')
    print('Six current covering normal/-O commands exit0 with empty stderr; all35-module AST and actual inert empty/foreign argv imports pass')
    print('maximum control depth=%d; shutdown schedule=%d; ordinary final test=%d' % (max(depths.values()),depths['shutdown_cases.py'],depths['test_final.py']))
    print('40 source schedules; zero unsupported cases; general malformed/unknown/duplicate/ordering rejection retained')
    print('shutdown test: five positive executions and75 exact synthetic negative rejections per mode')
    reviewed=json.loads((evidence/'reviewed-map.json').read_text())
    for name,item in reviewed.items():
        data=(evidence/name).read_bytes()
        if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
            raise RuntimeError('reviewed source/report/receipts changed: '+name)
    for receipt in (root/'evidence/b6d').glob('final-test*.exit'):
        for suffix in ('.command','.stdout','.stderr','.exit'):
            name=receipt.stem+suffix
            if (root/'evidence/b6d'/name).read_bytes()!=(evidence/'reviewed-receipts'/name).read_bytes():
                raise RuntimeError('preceding42 receipt changed: '+name)
    reviewed_source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (evidence/'reviewed-source').glob('*.py')}
    fix_changed=sorted(name for name in final if final[name]!=reviewed_source[name])
    if fix_changed!=['adapter.py','test_final.py','test_shutdown.py']:
        raise RuntimeError('fix ownership differs')
    fix_diff=[]
    for name in fix_changed:
        fix_diff.extend(difflib.unified_diff((evidence/'reviewed-source'/name).read_text().splitlines(True),(root/name).read_text().splitlines(True),fromfile='reviewed/'+name,tofile='fix-1/'+name))
    (evidence/'fix.diff').write_text(''.join(fix_diff))
    snapshot['fix_changed']=fix_changed
    snapshot['covering_commands']='fix-1/final-commands.json'
    (evidence/'snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
    (root/'evidence/b6d/snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
    (root/'evidence/b6d/source.diff').write_text((evidence/'source.diff').read_text())
    for name in final:
        (root/'evidence/b6d/final-source'/name).write_bytes((root/name).read_bytes())
    print('Reviewed35 modules/report and all42 preceding receipts preserved; fix changes exactly3 modules')
    print('No native execution, callback/process/close proof, default/aggregate acceptance or combined all40 claim')
PY
