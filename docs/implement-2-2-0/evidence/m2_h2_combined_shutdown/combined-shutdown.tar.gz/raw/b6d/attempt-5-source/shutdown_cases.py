"""Held active and fresh idle shutdown schedules over supplied teardown facts."""
import adapter
import catalogue
import model
import output_stage
import pause_cases
import wire


def validate_hooks(case, hooks):
    fields = {'preconditions', 'signal', 'process', 'post', 'units_per_second',
              'termination' if case == 'shutdown_active' else 'close'}
    if (type(hooks) is not dict or set(hooks) != fields or type(hooks['units_per_second']) is not int or
            hooks['units_per_second'] <= 0 or not all(callable(hooks[key]) for key in fields - {'units_per_second'})):
        raise ValueError('shutdown hooks required')


def grace(context, units):
    adapter.tick(context)
    duration = catalogue.mul_u64(15, units)
    return min(catalogue.add_u64(context['now'], duration), context['stage']['case_deadline'], context['stage']['whole_deadline'])


def within_grace(context, deadline):
    adapter.tick(context)
    if context['now'] >= deadline:
        raise ValueError('shutdown grace deadline expired')


def validate_signal(actual, client_open):
    expected = dict(signal='SIGTERM', owned_identity=True, watcher_installed=True, client_open=client_open)
    if type(actual) is not dict or actual != expected or any(type(actual[key]) is not type(value) for key, value in expected.items()):
        raise ValueError('owned signal evidence differs')


def validate_process(actual):
    expected = dict(exit_code=0, reaped=True, forced=False, run_ok=True, deinit_ok=True, key_removed=True)
    if type(actual) is not dict or actual != expected or any(type(actual[key]) is not type(value) for key, value in expected.items()):
        raise ValueError('shutdown process evidence differs')


def outputs(context, selection):
    retained = context.get('output_observations', {})
    selected = set(selection) & set(model.PRODUCERS + ('stream_file',))
    if type(retained) is not dict or set(retained) != selected:
        raise ValueError('retained output observations differ')
    before = model.default_outputs()
    before.update(retained)
    model.validate_outputs(selection, before)
    binding = context.get('output_binding')
    model.validate_binding_pre_post(selection, binding, model.default_binding() if binding is None else binding,
                                    before['producer_reuse'] if 'producer_reuse' in selection else None)
    return before, binding


def post_deinit(context, hooks, deadline, before, selection):
    result = hooks['process'](context, deadline)
    within_grace(context, deadline)
    validate_process(result)
    post = hooks['post'](context, deadline)
    within_grace(context, deadline)
    if type(post) is not dict or set(post) != {'records', 'metrics', 'outputs', 'binding'}:
        raise ValueError('post-deinit evidence fields differ')
    model.validate_pre_post(selection, before['records'], post['records'])
    model.validate_metrics(selection, 'after', post['metrics'])
    retained, binding = outputs(context, selection)
    model.validate_output_pre_post(selection, retained, post['outputs'], binding_before=binding, binding_after=post['binding'])
    context['shutdown_observations'] = dict(before=before, after=post, process=result, deadline=deadline)


def active(context, receive, hooks):
    adapter.health(context, receive)
    contract = model.request_contract('shutdown_active')
    stream = adapter.start(context, contract['method'], contract['target'],
                           [('content-length', str(contract['declared'])), ('x-case', contract['x-case'])],
                           False, True, 0, held=True, role='transport', policy='owned_shutdown')
    adapter.send_data(context, stream, model.payload_span(32, 0, 32), False)
    barrier = pause_cases.status(context, receive, 'shutdown_active')
    model.validate_item(barrier, model.record('shutdown_active', True, 'before'))
    pause_cases.pending(context, stream)
    before = adapter.final_collection(context, receive, held=stream)
    if before['records']['shutdown_active'] != barrier:
        raise ValueError('shutdown barrier changed before signal')
    selection = context['selected_before'] + ('shutdown_active',)
    outputs(context, selection)
    context['shutdown_boundary'] = True
    deadline = grace(context, hooks['units_per_second'])
    signal = hooks['signal'](context, deadline)
    within_grace(context, deadline)
    validate_signal(signal, True)
    output_stage.signal(context['stage'])
    wire.begin_termination(context['records'], context['raw'], stream, 'owned_shutdown', 'post_signal', stage=context['stage'])
    termination = hooks['termination'](context, deadline)
    within_grace(context, deadline)
    if (type(termination) is not dict or set(termination) != {'phase', 'outcome', 'primary_response', 'frames_valid', 'trailing_bytes'} or
            termination['phase'] != 'post_signal' or termination['outcome'] not in ('eof', 'tls_eof') or
            termination['primary_response'] is not False or termination['frames_valid'] is not True or
            type(termination['trailing_bytes']) is not int or termination['trailing_bytes'] != 0):
        raise ValueError('post-signal termination differs')
    terminal = wire.finish_termination(context['records'], context['raw'], stream, 'owned_shutdown', 'post_signal', termination['outcome'],
                                       request=context['request'], credit=context['credit'], stage=context['stage'])
    context['shutdown_closed'] = True
    post_deinit(context, hooks, deadline, before, selection)
    context['shutdown_observations'].update(signal=signal, termination=termination, transport=terminal)


def idle(context, receive, hooks):
    result = adapter.get(context, '/health', receive, primary=True, limit=2)
    if result['body'] != b'ok':
        raise ValueError('health response differs')
    context['completed'] = True
    before = adapter.final_collection(context, receive)
    context['shutdown_boundary'] = True
    deadline = grace(context, hooks['units_per_second'])
    close = hooks['close'](context, deadline)
    within_grace(context, deadline)
    expected = dict(method='close', client_closed=True, close='normal')
    if type(close) is not dict or close != expected or type(close['client_closed']) is not bool:
        raise ValueError('idle close evidence differs')
    context['shutdown_closed'] = True
    signal = hooks['signal'](context, deadline)
    within_grace(context, deadline)
    validate_signal(signal, False)
    post_deinit(context, hooks, deadline, before, ('shutdown_idle',))
    context['shutdown_observations'].update(signal=signal, close=close)


def run(context, receive, hooks):
    case = context['stage']['case']
    validate_hooks(case, hooks)
    expected = dict(client_open=True, prior_complete=True) if case == 'shutdown_active' else dict(client_open=True, fresh_application=True)
    preconditions = hooks['preconditions'](context)
    if (type(preconditions) is not dict or preconditions != expected or
            any(preconditions[key] is not True for key in expected) or case == 'shutdown_idle' and context['selected_before']):
        raise ValueError('shutdown preconditions differ')
    if case == 'shutdown_active':
        active(context, receive, hooks)
    else:
        idle(context, receive, hooks)


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned hooks')
