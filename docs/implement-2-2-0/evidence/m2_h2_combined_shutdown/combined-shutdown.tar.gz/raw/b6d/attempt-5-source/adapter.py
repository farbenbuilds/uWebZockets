"""Caller-owned bounded I/O hooks paired to the reviewed codec seam."""
import cases
import catalogue
import json
import hashlib
import model
import output_stage
import raw_observer
import request_credit
import response_credit
import wire

ADMISSION_CASES = ('empty_headers', 'empty_data', 'empty_declared', 'limit_declared', 'limit_undeclared',
                   'limit_declared_reject', 'limit_observed_reject', 'zero_declared_reject', 'zero_observed_reject')


def open_case(case, protocol, send, now, case_deadline, whole_deadline, selected_before=(), *, clock):
    cases.select((case,))
    catalogue.schedule(selected_before)
    if case in selected_before or 'shutdown_idle' in selected_before or 'shutdown_active' in selected_before:
        raise ValueError('invalid previous selection')
    if not callable(send) or not callable(clock):
        raise ValueError('send and time hooks required')
    primary = 7 if case == 'early_final_order' else 3 if case in ('async_delayed', 'partial_pause', 'final_pause', 'begin_pause_empty', 'control_rules') or case in ('queued_trailers_padding', 'receive_credit', 'metadata_helpers', 'concurrent_routes') or case in ADMISSION_CASES or case in ('continue_ready', 'continue_paused', 'begin_failure_rollback', 'producer_reuse', 'disconnect', 'reuse', 'shutdown_active') else 1 if case == 'shutdown_idle' else 5
    case_state = output_stage.new_case(case)
    stage = output_stage.new_stage(case_state, primary, 2 if case in catalogue.OUTPUT_CASES else 1, case_deadline, whole_deadline)
    output_stage.remaining(stage, now)
    request = request_credit.new_state(request_credit.new_case(case))
    credit = response_credit.new_state()
    raw, records = raw_observer.new_state(), {}
    wire.bind_connection(stage, protocol, raw, request, credit, records)
    context = {'stage': stage, 'protocol': protocol, 'request': request, 'credit': credit,
               'raw': raw, 'records': records, 'trace': {}, 'send': send, 'now': now, 'selected_before': tuple(selected_before), 'completed': False, 'clock': clock}
    tick(context)
    startup = wire.startup(stage)
    tick(context)
    send(startup)
    return context


def replace_connection(context, supplied):
    stage = context['stage']
    if (stage['case'] != 'disconnect' or stage['connection_index'] != 1 or
            not stage['case_state']['transport_finished'] or not context['raw']['closed'] or
            not context['request']['transport_closed'] or stage['active'] or context['records'] or
            context['credit']['streams']):
        raise ValueError('replacement before transport terminal')
    fields = {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'}
    if (type(supplied) is not dict or set(supplied) != fields or supplied['protocol'] is None or
            supplied['protocol'] is context['protocol'] or supplied['owned'] is not True or
            supplied['tls'] != 'TLSv1.3' or supplied['alpn'] != 'h2' or
            not callable(supplied['send']) or not callable(supplied['receive']) or
            type(supplied['now']) is not int or supplied['now'] < context['now']):
        raise ValueError('replacement facts differ')
    replacement_stage = output_stage.new_stage(stage['case_state'], 17, 1, stage['case_deadline'], stage['whole_deadline'])
    output_stage.remaining(replacement_stage, supplied['now'])
    request = request_credit.new_state(context['request']['case'])
    credit, raw, records = response_credit.new_state(), raw_observer.new_state(), {}
    wire.bind_connection(replacement_stage, supplied['protocol'], raw, request, credit, records)
    replacement = dict(stage=replacement_stage, protocol=supplied['protocol'], request=request, credit=credit,
                       raw=raw, records=records, trace={}, send=supplied['send'], now=supplied['now'],
                       selected_before=context['selected_before'], completed=False, clock=context['clock'])
    tick(replacement)
    startup = wire.startup(replacement_stage)
    tick(replacement)
    replacement['send'](startup)
    return replacement


def tick(context):
    now = context['clock']()
    output_stage.remaining(context['stage'], now)
    if now < context['now']:
        raise ValueError('monotonic time moved backwards')
    context['now'] = now


def flush(context):
    while True:
        tick(context)
        data = wire.drain(context['stage'])
        if not data:
            return
        tick(context)
        context['send'](data)


def observe(context, data, now):
    if context.get('shutdown_boundary') or context['stage']['signaled']:
        raise ValueError('observation after shutdown')
    if context['request']['transport_closed']:
        raise ValueError('observation after transport terminal')
    output_stage.remaining(context['stage'], now)
    if now < context['now']:
        raise ValueError('monotonic time moved backwards')
    context['now'] = now
    if type(data) is not bytes or not 0 < len(data) <= 8192:
        raise ValueError('invalid bounded read')
    tick(context)
    wire.accept(context['protocol'], data, context['records'], context['raw'], context['trace'],
                credit=context['credit'], request=context['request'], stage=context['stage'])
    stage, credit = context['stage'], context['credit']
    if stage['case'] == 'reuse' and credit['connection'] <= 32767:
        amount = credit['flow_bytes'] - stage['grants']['connection_replenished']
        wire.grant(context['protocol'], credit, stage['grants'], stage, 0, amount, 'replenish')
    flush(context)


def start(context, method, path, headers, end_stream, primary, limit, middleware='required', held=False, *, status=200, policy='healthy', info=0, role='small', mode='small_body', expected_sha256=None):
    stage = context['stage']
    if context.get('shutdown_boundary') or stage['signaled']:
        raise ValueError('observation after shutdown')
    tick(context)
    stream, chunks = wire.start_request(stage, method, 'localhost', path, headers, end_stream,
                                        role=role, primary=primary, held=held, body_limit=limit,
                                        final_status=status, info_count=info, policy=policy, mode=mode,
                                        expected_sha256=expected_sha256, middleware_policy=middleware)
    for chunk in chunks:
        tick(context)
        context['send'](chunk)
    if stage['grants'] is not None and role == 'small' and context['credit']['initial'] == 0:
        tick(context)
        wire.grant(context['protocol'], context['credit'], stage['grants'], stage, stream, 65535, 'auxiliary')
        flush(context)
    return stream


def response_finished(context, stream):
    record, raw = context['records'][stream], context['raw']
    observed = raw['streams'][stream]
    if record['policy'] in ('public_cancel', 'peer_reset', 'application_failure') and (record['headers'] is not None or record['ended']):
        raise ValueError('unexpected final')
    if raw['header'] or raw['frame'] is not None or raw['remaining']:
        return False
    if record['policy'] in ('public_cancel', 'application_failure'):
        return observed['reset'] and record['reset_event']
    if record['policy'] == 'peer_reset':
        return observed['peer_reset']
    return record['ended'] and (record['policy'] != 'refusal_after_final' or observed['reset'])


def finish(context, stream, receive, *, keep=False):
    records = context['records']
    while not response_finished(context, stream):
        tick(context)
        data, now = receive()
        observe(context, data, now)
    tick(context)
    wire.complete(records, context['raw'], stream)
    record = records[stream]
    result = {'bytes': record['bytes'], 'sha256': record['hash'].hexdigest(),
              'headers': None if record['headers'] is None else [(name, value) for name, value in record['headers']],
              'ended': record['ended'], 'reset': {'public_cancel': 8, 'peer_reset': 8, 'application_failure': 2, 'refusal_after_final': 0}.get(record['policy']),
              'trailers': None, 'informationals': record['informationals']}
    if record['mode'] == 'small_body':
        result['body'] = bytes(record['body'])
    if not keep:
        retire(context, stream)
    return result


def retire(context, stream):
    tick(context)
    wire.retire(context['records'], context['raw'], stream, request=context['request'], credit=context['credit'],
                stage=context['stage'])


def get(context, path, receive, primary=False, limit=4095, middleware='required'):
    return finish(context, start(context, 'GET', path, (), True, primary, limit, middleware), receive)


def send_data(context, stream, data, end_stream, *, padding=None):
    tick(context)
    wire.send_data(context['protocol'], context['records'], context['request'], stream, data,
                   stage=context['stage'], end_stream=end_stream, pad_length=padding)
    flush(context)


def health(context, receive):
    result = get(context, '/health', receive, limit=2)
    if result['body'] != b'ok':
        raise ValueError('health response differs')


def metrics(context, receive):
    result = get(context, '/metrics', receive)
    value = json.loads(result['body'])
    fields = set(model.metrics((), 'before')) | {'slot0_active', 'slot1_active'}
    if type(value) is not dict or value.keys() != fields:
        raise ValueError('metrics schema differs')
    for name, item in value.items():
        if name.startswith('slot'):
            if type(item) is not bool:
                raise ValueError('metrics slot type differs')
        elif type(item) is not int or item < 0:
            raise ValueError('metrics counter differs')
    return value


def verify_metrics(context, actual, completed):
    selected = context['selected_before'] + ((context['stage']['case'],) if completed else ())
    expected = model.metrics(selected, 'before')
    prior = context['selected_before']
    prior_metrics = model.metrics(prior, 'before')
    prior_heads = sum(catalogue.case_budget(case)['heads'] for case in prior)
    current_middleware = expected['middleware'] - prior_metrics['middleware']
    expected['buffered_middleware'] = (prior_heads - prior_metrics['middleware'] +
                                       context['stage']['case_state']['heads'] - current_middleware)
    for key, value in expected.items():
        if type(actual[key]) is not type(value) or actual[key] != value:
            raise ValueError('metrics mismatch: ' + key)
    if actual['slot0_active'] or actual['slot1_active']:
        raise ValueError('unexpected active slot')


def large_upload(context, receive):
    case = context['stage']['case']
    health(context, receive)
    before = metrics(context, receive)
    verify_metrics(context, before, False)
    contract = model.request_contract(case)
    headers = () if contract['declared'] is None else (('content-length', str(contract['declared'])),)
    stream = start(context, contract['method'], contract['target'], headers, False, True, 4095)
    count = 0
    digest = hashlib.sha256()
    while count < model.MAX_PAYLOAD:
        outbound = context['request']
        item = request_credit.stream(outbound, stream)
        available = min(8192, model.MAX_PAYLOAD - count, outbound['connection'], item['window'],
                        65535 - outbound['stream_debt_total'])
        if available == 0:
            tick(context)
            data, now = receive()
            observe(context, data, now)
            continue
        block = model.payload_span(model.MAX_PAYLOAD, count, available)
        digest.update(block)
        count += len(block)
        send_data(context, stream, block, count == model.MAX_PAYLOAD)
    if digest.hexdigest() != model.LARGE_HASH:
        raise ValueError('upload digest differs')
    result = finish(context, stream, receive)
    model.validate_item(json.loads(result['body']), model.record(case, True, 'after'))
    after = metrics(context, receive)
    verify_metrics(context, after, True)
    expected = model.record(case, True, 'after')
    for field in model.COMMON_COUNTERS + ('bytes',):
        if after[field] != before[field] + expected[field]:
            raise ValueError('upload metrics differ: ' + field)
    if after['active'] != 0 or after['paused'] != 0 or after['buffered_middleware'] != before['buffered_middleware'] + 1:
        raise ValueError('upload metrics state differs')
    health(context, receive)
    if context['stage']['case_state']['heads'] != context['stage']['limits']['heads'] or context['request']['case']['sent'] != model.MAX_PAYLOAD:
        raise ValueError('upload counts differ')


def run_case(context, receive, *, disconnect=None, shutdown=None):
    stage = context['stage']
    if context['completed'] or stage['initial_settings'] != 1 or stage['acks'] != 1:
        raise ValueError('invalid case start')
    case = stage['case']
    if case in ('shutdown_active', 'shutdown_idle'):
        import shutdown_cases
        shutdown_cases.run(context, receive, shutdown)
        check_counts(context)
        context['completed'] = True
        return context
    if case in ('disconnect', 'reuse'):
        import lifecycle_cases
        result = lifecycle_cases.run(context, receive, disconnect)
        check_counts(result)
        result['completed'] = True
        return result
    if case in ('stream_file', 'early_final_order'):
        import file_early_cases
        file_early_cases.run(context, receive)
        check_counts(context)
        context['completed'] = True
        return
    if case in ('producer_reuse', 'output_pressure_window', 'output_pressure_ready'):
        import producer_pressure_cases
        producer_pressure_cases.run(context, receive)
        check_counts(context)
        context['completed'] = True
        return
    if case in ('sink_error', 'invalid_progress', 'end_error'):
        import application_error_cases
        application_error_cases.run(context, receive)
        check_counts(context)
        context['completed'] = True
        return
    if case in ('cancel_ready', 'cancel_paused', 'peer_reset'):
        import control_reset_cases
        control_reset_cases.run(context, receive)
        check_counts(context)
        context['completed'] = True
        return
    if case == 'concurrent_routes':
        import concurrent_cases
        concurrent_cases.run(context, receive)
        check_counts(context)
        context['completed'] = True
        return
    if case == 'metadata_helpers':
        import metadata_cases
        metadata_cases.run(context, receive)
        check_counts(context)
        context['completed'] = True
        return
    if case in ('queued_trailers_padding', 'receive_credit'):
        import credit_cases
        credit_cases.run(context, receive)
        check_counts(context)
        context['completed'] = True
        return
    if case in ('continue_ready', 'continue_paused', 'quota_refuse', 'begin_failure_rollback'):
        import continue_quota_cases
        continue_quota_cases.run(context, receive)
        check_counts(context)
        context['completed'] = True
        return
    if case in ADMISSION_CASES:
        import admission_cases
        admission_cases.run(context, receive)
        check_counts(context)
        context['completed'] = True
        return
    if case in ('partial_pause', 'final_pause', 'begin_pause_empty', 'control_rules'):
        import pause_cases
        pause_cases.run(context, receive)
        check_counts(context)
        context['completed'] = True
        return
    if case in ('large_declared', 'large_undeclared'):
        large_upload(context, receive)
        check_counts(context)
        context['completed'] = True
        return
    if case == 'async_delayed':
        health(context, receive)
        result = get(context, '/delayed', receive, primary=True, limit=10, middleware='optional')
        model.validate_core_response(case, result)
        health(context, receive)
        check_counts(context)
        context['completed'] = True
        return
    if case != 'ready_buffered':
        raise ValueError('case schedule not yet implemented')
    health(context, receive)
    before = metrics(context, receive)
    verify_metrics(context, before, False)
    contract = model.core_request(case)
    stream = start(context, contract['method'], contract['path'], contract['headers'], False, True, 257)
    send_data(context, stream, contract['body'], True)
    model.validate_core_response(case, finish(context, stream, receive))
    after = metrics(context, receive)
    verify_metrics(context, after, False)
    if any(before[key] != after[key] for key in before if key != 'buffered_middleware'):
        raise ValueError('buffered request changed sink totals')
    if after['buffered_middleware'] != before['buffered_middleware'] + 2:
        raise ValueError('buffered middleware count differs')
    health(context, receive)
    check_counts(context)
    context['completed'] = True


def check_counts(context):
    stage, request = context['stage'], context['request']
    limits, state = stage['limits'], stage['case_state']
    small = state['small'] + (stage['final_registered'] if limits['final_included'] else 0)
    if (state['heads'], small, request['case']['sent']) != (limits['heads'], limits['small'], limits['request_flow']):
        raise ValueError('case counts differ')
    if stage['active'] or context['records']:
        raise ValueError('unfinished responses')


def final_collection(context, receive, *, held=None):
    if not context['completed'] and not (context['stage']['case'] == 'shutdown_active' and held is not None):
        raise ValueError('case not complete')
    selection = context['selected_before'] + (context['stage']['case'],)
    tick(context)
    wire.enter_final(context['stage'], held)
    records = {}
    for tag, _family, _length, _terminal in model.BODY_SPECS:
        result = get(context, '/status/' + tag, receive)
        records[tag] = json.loads(result['body'])
    model.validate_records(selection, 'before', records)
    observed = metrics(context, receive)
    model.validate_metrics(selection, 'before', observed)
    tick(context)
    wire.finish_final(context['stage'])
    if context['stage']['case'] in ('shutdown_active', 'shutdown_idle'):
        return dict(records=records, metrics=observed)


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned hooks')
