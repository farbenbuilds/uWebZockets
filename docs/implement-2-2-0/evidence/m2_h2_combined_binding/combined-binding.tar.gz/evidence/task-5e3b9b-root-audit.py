"""Independently bind the coordinator binding candidate to its exact covering receipts."""
import ast
import hashlib
import json
import sys
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def nesting(node, depth=0):
    control = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.With, ast.AsyncWith,
               ast.Try, ast.TryStar, ast.Match)
    level = depth + int(isinstance(node, control))
    return max([level] + [nesting(child, level) for child in ast.iter_child_nodes(node)])


def verify_source(source, unit):
    baseline = read_json(unit / 'baseline.json')
    manifest = Path('docs/implement-2-2-0/evidence/m2_h2_combined_wire_oracle/manifest.json')
    published = read_json(manifest)
    if baseline['source'] != published['current_source_files'] or sha(manifest.read_bytes()) != baseline['authority_sha256'] or Path(baseline['authority']).resolve() != manifest.resolve():
        raise ValueError('Frozen published baseline differs')
    if (unit / 'baseline-inputs.json').read_bytes() != (source / 'evidence/coordinator-a/immutable-inputs.json').read_bytes():
        raise ValueError('Frozen input authority differs')
    current = {path.name: sha(path.read_bytes()) for path in sorted(source.glob('*.py'))}
    added = sorted(current.keys() - baseline['source'].keys())
    changed = sorted(name for name, digest in baseline['source'].items() if current.get(name) != digest)
    if len(current) != 45 or added != ['test_all40.py', 'test_all40_descriptors.py'] or changed != ['test_imports.py']:
        raise ValueError('Source ownership differs')
    for name, digest in baseline['source'].items():
        if sha((unit / 'baseline-source' / name).read_bytes()) != digest:
            raise ValueError('Frozen source bytes differ')
    for name, digest in baseline['history'].items():
        path = source / 'evidence' / name
        if path.is_symlink() or sha(path.read_bytes()) != digest:
            raise ValueError('Prior evidence differs: ' + name)
    return current, len(baseline['history'])


def verify_inventory(folder, current, source):
    data = read_json(folder / 'inventory.json')
    expected_path = '/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'
    expected_interpreter = '4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601'
    if data['source'] != current or data['pythonpath'] != expected_path or data['dontwritebytecode'] != '1':
        raise ValueError('Covering source/environment differs')
    if data['interpreter_sha256'] != expected_interpreter or sha(Path(data['interpreter']).read_bytes()) != expected_interpreter:
        raise ValueError('Covering interpreter differs')
    if Path(data['cwd']).resolve() != source.resolve():
        raise ValueError('Covering cwd differs')
    for name, digest in current.items():
        if sha((folder / name).read_bytes()) != digest:
            raise ValueError('Captured source text differs')
    for name, digest in data['helpers'].items():
        if sha((folder / 'helpers' / (name + '.txt')).read_bytes()) != digest:
            raise ValueError('Captured helper text differs')
    helpers = source / 'evidence/all40-binding-a/helpers'
    if data['helpers'] != {path.name: sha(path.read_bytes()) for path in helpers.iterdir() if path.is_file()}:
        raise ValueError('Final captured helpers differ from current live helpers')
    return data


def verify_receipt(unit, name, current):
    folder = unit / name
    if Path(name).is_absolute() or '..' in Path(name).parts or not folder.resolve().is_relative_to(unit.resolve()):
        raise ValueError('Receipt must remain within the owned unit')
    argv = (folder / 'argv.txt').read_text().splitlines()
    if argv[:3] != ['/home/codespace/.python/current/bin/python3', '-B', '-S']:
        raise ValueError('Covering argv prefix differs')
    optimized = len(argv) > 3 and argv[3] == '-O'
    tail = argv[4:] if optimized else argv[3:]
    if tail not in (['test_all40.py'], ['test_imports.py']):
        raise ValueError('Covering target differs')
    before = verify_inventory(folder / 'before', current, unit.parents[1])
    after = verify_inventory(folder / 'after', current, unit.parents[1])
    if before != after:
        raise ValueError('Covering identities changed during check')
    if (folder / 'exit.txt').read_text() != '0\n' or (folder / 'stderr.txt').read_bytes():
        raise ValueError('Covering command failed or emitted stderr')
    restored = read_json(folder / 'restoration.json')
    if not restored['all_inputs_verified_in_this_command'] or restored['authority_entries'] != 119:
        raise ValueError('Same-shell input restoration differs')
    if (restored['physical_rows_checked'], restored['unique_resolved_files'], restored['ordered_codec_files_checked']) != (118, 113, 42):
        raise ValueError('Restored input inventory differs')
    return dict(module=tail[0], optimized=optimized, argv=argv, cwd=before['cwd'],
                source_before_after_exact=True, exit_code=0, stderr_empty=True,
                stdout_sha256=sha((folder / 'stdout.txt').read_bytes()),
                restoration_sha256=sha((folder / 'restoration.json').read_bytes()))


def verify_helpers(unit, plan, source):
    paths = sorted((unit / 'helpers').glob('*.py'))
    paths += [plan / ('task-5e3b9b-' + name + '.py') for name in
              ('root-audit', 'build-publication', 'publication-audit') if (plan / ('task-5e3b9b-' + name + '.py')).exists()]
    paths += [source / name for name in ('test_all40_descriptors.py', 'test_all40.py')]
    result = {}
    for path in paths:
        tree = ast.parse(path.read_text(), filename=str(path))
        depth = nesting(tree)
        if depth > 3 or any(isinstance(node, (ast.ClassDef, ast.Assert)) for node in ast.walk(tree)):
            raise ValueError('Current helper/source structure differs: ' + str(path))
        scope = {'__name__': 'root_metadata', '__file__': str(path)}
        previous_path = sys.path[:]
        try:
            sys.path.insert(0, str(path.parent.resolve()))
            exec(compile(tree, str(path), 'exec'), scope)
        finally:
            sys.path[:] = previous_path
        result[str(path)] = dict(sha256=sha(path.read_bytes()), max_nesting=depth, metadata_import_inert=True)
    return result


def verify_compositions(unit):
    normal = (unit / 'final-01-focused/stdout.txt').read_bytes()
    optimized = (unit / 'final-02-focused-optimized/stdout.txt').read_bytes()
    if normal != optimized:
        raise ValueError('Normal and optimized observed facts differ')
    rows = [json.loads(line) for line in normal.decode().splitlines() if line.startswith('{')]
    selections = [('shutdown_idle', 'producer_reuse', 'stream_file', 'disconnect', 'shutdown_active'),
                  ('producer_reuse', 'stream_file', 'disconnect'),
                  ('shutdown_idle', 'async_delayed', 'ready_buffered'), ('early_final_order',)]
    if [tuple(row['selection']) for row in rows] != selections:
        raise ValueError('Actual composition selection differs')
    result = []
    for row in rows:
        receipts, observed = row['receipts'], row['observed']
        identities = [tuple(receipt['identity']) for receipt in receipts]
        if len(set(identities)) != len(identities) or row['actual_dispatch'] != row['selection']:
            raise ValueError('Actual connection identities or dispatch differ')
        totals = composition_totals(receipts)
        if any(observed[key] != value for key, value in totals.items()):
            raise ValueError('Recorded receipt aggregation differs')
        result.append(dict(selection=row['selection'], children=len({item[0] for item in identities}),
                           actual_connection_identities=identities, observed=observed,
                           receipt_arithmetic_exact=True))
    return result


def composition_totals(receipts):
    fields = dict(heads='heads', small='small', request_flow='flow', settings='settings',
                  informationals='informationals', final_collections='final_collections')
    values = {key: sum(receipt[field] for receipt in receipts) for key, field in fields.items()}
    values['connections'] = len(receipts)
    values['incoming_resets'] = sum(count for receipt in receipts for _code, count in receipt['incoming_resets'])
    return values


def main(argv):
    if len(argv) != 5 or argv[0] != '--audit':
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    unit = source / 'evidence/all40-binding-a'
    current, history_count = verify_source(source, unit)
    receipts = {name: verify_receipt(unit, name, current) for name in argv[1:]}
    expected = {(module, optimized) for module in ('test_all40.py', 'test_imports.py') for optimized in (False, True)}
    if {(row['module'], row['optimized']) for row in receipts.values()} != expected:
        raise ValueError('Four-check coverage differs')
    result = dict(base_commit='46f97a1353297fe2dbf3f0f12307ef01ad32c3ff',
                  current_source_sha256=current, changed_modules=['test_imports.py'],
                  added_modules=['test_all40.py', 'test_all40_descriptors.py'], unchanged_modules=42,
                  prior_evidence_hashes_verified=history_count,
                  focused_receipts=receipts, observed_compositions=verify_compositions(unit),
                  current_helpers=verify_helpers(unit, plan, source),
                  native_executed=False, actual_all40_executed=False, milestone_complete=False)
    output = plan / 'task-5e3b9b-root-final-audit.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(source_modules=len(current), prior_evidence_hashes_verified=history_count,
                          focused_receipts=len(receipts), result=str(output)), indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
