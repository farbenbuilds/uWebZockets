# Fresh task-scoped source review: first binding

Read task-5e3b9b-brief.md, task-5e3b9b-report.md and the complete
task-5e3b9b-review-source.diff once. BASE46f97a1353297fe2dbf3f0f12307ef01ad32c3ff;
uncommitted candidate45 is bound by task-5e3b9b-root-final-audit.json.
These inputs and linked architect/observer contracts bind this slice.

Independent spec compliance and task quality review, including Root explicitly
requested thermo-nuclear structural lens with AGENTS overrides. Read applicable
reviewer/project/convention/code-review skill instructions. Report actionable
Critical/Important/Minor findings with file:line and scenario, both verdicts and
cannot-verify limits. No emojis/edits/Git/network/native/build/subagents.

Global constraints verbatim from the brief:

The canonical coordinator.run is the sole dispatcher through existing adapter
handlers. Build a standalone provider using the existing child/connect/close/
signal/termination/process/post-validation hook contracts, not by calling or
wrapping test_coordinator_shutdown.run_selection, family check(), or another
dispatcher. Return unchanged seven-key connections, wrapped exactly once with
the accepted test_wire_oracle. Constructor-only availability is not execution.

Only after successful coordinator.run has completed and validated all relevant
hooks may finish_binding check failure and seal each expected observer once.
Missing/duplicate/wrong identity, poisoned state or failed run rejects accepted
aggregate; do not patch missing receipts with catalogue/model totals. Preserve
transport-abandon stream and debt on disconnect1 and active shutdown; do not
manufacture request END, response terminal or zero credit. Partial reset/refund
tails cannot be waived by teardown. Synthetic supplied close/process facts are
not native close or ownership observations.

Separately compare ACTUAL retained client output/binding/final observations,
using the canonical returned captures and existing immutable snapshots. The
architect report names exact seams in adapter/shutdown_cases/coordinator.
Snapshots of provider app facts must reflect actual traffic, captured before
signal changes active shutdown and after relevant post hook. Do not regenerate
observations via model.records(selection,...), add diagnostic GETs or substitute
wire-equivalent data for actual retained values. Client/canonical counters are
comparison operands only; independent byte receipts are the observed totals.

Read all diff hunks, not changed files again unless required context is cut off.
Inspect unchanged source only for a named concrete risk, with scope/reference
in report. Graphify before a NEW codebase question/search/read; supplied/diff
paths are located. Root-owned original source/base archives and input restorer
may supply exact missing source reads, same shell/new receipt, no test execution.

Four covering commands already ran normally/optimized on exactcandidate45; no
suite reruns or broader crawling. For an unanswered doubt, report a focused
test need to Root rather than running native/family suites. The report's four
actual compositions, transmitted-byte/debt facts and actual retained comparisons
need source/evidence scrutiny;12 supported is not12 actuallycompleted IDs.
Full all40/default/native/adoption/project/platform/milestone gates remain open.

Root independently verified current45 vs published43,42unchanged,exactinventory+
two additions; all16227history hashes;119/118/113/42 restoration; currenthelper
bytes and before/after source; allfour exits0/emptyerr. Root also compared
normal/O stdout and recomputed available perconnection receipt arithmetic for
four actual compositions. Source provenance of those receipts is for review,
not inferred from that metadata audit. Root publication helpers do not yet exist
and are outside this source diff; later publication accuracy is a separate gate.

Return the full report as final; Root retains it. No self-dispatched reviewers.
