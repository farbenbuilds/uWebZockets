# First canonical coordinator / passive observer binding

Read this first: requirements for one serial source-only binding slice.
BASE46f97a1353297fe2dbf3f0f12307ef01ad32c3ff, feat/implement-2-2-0.
Preceding9a source/fix/publication reviews approved and commit immediately pushed;
Root post-push audit is task-5e3b9a-root-commit-audit.json.
Baseline43 authority:
docs/implement-2-2-0/evidence/m2_h2_combined_wire_oracle/manifest.json.
Read task-5e3b9b-binding-plan-report.md and exact observer interface report in
this workspace. Do not restart completed mechanism/interface/receipt reviews.

Own exactly NEW test_all40_descriptors.py and test_all40.py beneath
/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases,
plus test_imports.py's exact necessary two-name inventory addition. Own NEW
evidence/all40-binding-a and full report
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b9b-report.md.
Baseline43 -> current45: two new, one existing inventory edit,42 unchanged.
No accepted peer/oracle/canonical coordinator/adapter/model/client/core/handler/
fixture/product/pin/limit changes. Report a concrete contract defect before any
ownership expansion. You are not alone: preserve other work and prior evidence.
No agents/Git/publication/native/network/external model CLI. Root owns review,
publication, commit and immediate authorized fork push before next source unit.

Implement the architect's small explicit surface:
connection_descriptor(child,case,connection_index,*,final) -> ConnectionDescriptor;
new_provider(*,clock) -> (ChildFactory,BindingState);
finish_binding(state,result) -> tuple[ConnectionReceipt,...].
Use named documented types/flat explicit state consistent with accepted oracle.
Plain functions/data, no classes/customexceptions/assert/modulemutablecontainers/
generic registration framework or forwarding wrappers. Protocol/control/clock/
parser/ledger identities and all supplied deadlines/caps/debt remain unchanged.

This first binding supports core four cases, producer/pressure three, file/early
two, disconnect, shutdown_idle and shutdown_active (12 IDs). Lifecycle reuse and
all other families are a following binding slice. Do not claim default/all40
acceptance from this support set or use a family driver's check as execution.
A scoped entry wrapper may validate this partial support set before effects;
it does not replace the canonical coordinator's selection validation or sole
dispatch. First slice rejects unsupported selection before starting its private
provider. The later omitted-selection/default acceptance remains mandatory.

The canonical coordinator.run is the sole dispatcher through existing adapter
handlers. Build a standalone provider using the existing child/connect/close/
signal/termination/process/post-validation hook contracts, not by calling or
wrapping test_coordinator_shutdown.run_selection, family check(), or another
dispatcher. Return unchanged seven-key connections, wrapped exactly once with
the accepted test_wire_oracle. Constructor-only availability is not execution.

Each child owns one fresh test_core_peer.new_app, completed case prefix, current
peer, bounded lifecycle evidence and ordered observer identities/states. Advance
prefix after ordinary close; never between disconnect connections. One lifecycle
case-evidence object is shared across its two distinct connections and compared
once. Every connection receipt is counted once; never sum cumulative case facts
once per connection. Retain at most41 bounded observer states to the canonical
successful return; no client contexts or payload/frame/read histories.

Use immutable expectations from reviewed pure peer paths/schedule/order and
model payload contracts, not canonical registrations/ledger state or selected
model totals as observed receipts. Do not construct pretend state for a mutable
request-path handler. Existing output constants/hashes, methods/paths/ordinals,
request END mode, actual transmitted flow/hash, exceptional response role and
terminal policy are exact descriptor authority. Accepted versus transmitted
bytes differ for early/refusal/open cases; do not guess from accepted counters.
No whole100MB bodies. Final tags are exact ordered model.BODY_SPECS only on the
child's actual last connection; disconnect1 never final, replacement final when
case ends child; shutdown always has its required final collection.

Only after successful coordinator.run has completed and validated all relevant
hooks may finish_binding check failure and seal each expected observer once.
Missing/duplicate/wrong identity, poisoned state or failed run rejects accepted
aggregate; do not patch missing receipts with catalogue/model totals. Preserve
transport-abandon stream and debt on disconnect1 and active shutdown; do not
manufacture request END, response terminal or zero credit. Partial reset/refund
tails cannot be waived by teardown. Synthetic supplied close/process facts are
not native close or ownership observations.

Separately compare ACTUAL retained client output/binding/final observations,
using the canonical returned captures and existing immutable snapshots. The
architect report names exact seams in adapter/shutdown_cases/coordinator.
Snapshots of provider app facts must reflect actual traffic, captured before
signal changes active shutdown and after relevant post hook. Do not regenerate
observations via model.records(selection,...), add diagnostic GETs or substitute
wire-equivalent data for actual retained values. Client/canonical counters are
comparison operands only; independent byte receipts are the observed totals.

Primary ACTUAL canonical composition:
('shutdown_idle','producer_reuse','stream_file','disconnect','shutdown_active').
It must dispatch two fresh children/six distinct wrapped connections, preserve
caller main order, retain producer/file facts through replacement, collect both
final observations and complete both synthetic shutdown hook boundaries.
Also actual focused compositions ending in disconnect, an ordinary core case
and early_final_order, proving replacement final tags, ordinary teardown and
17-byte output exclusion. Report exact dispatched IDs/connections/observed
heads/small/flow/settings/info/reset/final facts from sealed receipts, clearly
separate12 supported IDs from actually executed compositions. Descriptor-only
checks may validate other supported contracts, not claim their traffic.

Meaningful negative tests: empty selection zero child/connect/clock/wire effects;
invalid/duplicate/invalid-order/unsupported selection preeffect; idle/main caller
order; each operation once/no extraGET; missing/duplicate connection receipt
reject; actual retained output/binding corruption reject; failed post/termination
hooks prevent acceptance; authorized open debt retained; required reset/refund
tail incomplete rejects. Keep the actual original source/error semantics and
restore any test instrumentation on failure. Preserve real discovered REDs
before fixes; APIabsence alone is only a preeffect RED. No weakened bound,
threshold, assertion, test or copied model success recipe.

Before editing read actual AGENTS.md/CODING_CONVENTION.md, narrow local
incremental/TDD/API and applicable specialist instructions. Graphify query
before NEW codebase questions/search/read; supplied/previously located paths
may be read. Freeze exact published43 bytes/hashes,119-input identity and a
fresh exhaustive prior-evidence hash map excluding only this new unit. Preserve
all failed/intermediate command/source/raws. Retain old helper bytes before any
correction and explicit mappings; no live helper is exempt as historical.

After final source edit FOUR covering commands: test_all40.py and test_imports.py,
normal and-O. Other suites only for an actual dependency or unresolved concern.
Every check records actual before/after45 source inventories/text, exact argv/
cwd/PYTHONPATH/PYTHONDONTWRITEBYTECODE/interpreter identity, separate stdout/
stderr/exit and same-shell restoration. All45 source AST/import guards; new
source and all current unit helpers max3/no classes/asserts/globalmutable state;
current helper imports and EMPTY/FOREIGN CLI inert (explicit flags/arity for
metadata helpers and shell runner); ownership/input/history integrity audited.
Do not apply a new audit policy to unchanged historical source as a shortcut.
No need copy/rerun all historical suites; integrity maps and published references
suffice. Final report/audit bookkeeping is part of finishing this assigned slice.

Each dependent Python proof/audit/check SHELL starts set-e and runs exact pinned
restorer with a NEW absolute receipt, then operation in THAT SAME SHELL:
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT
TMP can reset across continuations; never infer future persistence. Interpreter
SHA4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
All direct Python including edits uses that interpreter -B-S, optional-O.
PYTHONDONTWRITEBYTECODE=1; exact PYTHONPATH:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
Graphify query command:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650
Root owns final AST-only graph update. Known missing generic DoD documentation
reference was already ruled not a missing transitive SKILL.md; explicit project
gates/brief apply, no vendored edits. Do not reopen that resolved context issue.

Only pinned in-memory codecs and supplied synthetic app/transport/process facts.
No build/native/server/socket/SSLContext/TLSclose/realclock/processownership/
kernel/race/fault-scheduling/install/network/oldruntime execution. Actualdefault/
all40 still requires2children41connections802heads789smallR20009189946clientSETTINGS
2info13incomingresets2collections, childsubtotals/hashes/debt/deadlines/ceilings
RX5288609050/refundframes400183798. Full native/project/platform/adoption/all
original milestones remain mandatory later, not waived by partial binding.

Write full report with exact changedfiles/interfaces, actual dispatch and
retained comparisons vs expectation sources, commands/raw/results, RED/GREEN,
audits/selfreview/limitations/real unresolved questions. Return<=15lines status
DONE|DONE_WITH_CONCERNS|NEEDS_CONTEXT|BLOCKED, no commits, tests/concerns/report.
Root dispatches fresh independent source review, then publication accuracy,
commit and immediate push. Do not dispatch your own reviewer or other agents.
