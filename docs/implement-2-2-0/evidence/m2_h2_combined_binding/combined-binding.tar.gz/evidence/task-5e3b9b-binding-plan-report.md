# Read-only next binding plan

Architect /root/architect_h2_receipt_inventory recommends a bounded9b vertical
binding slice, then remaining descriptors and actual default/all40 acceptance.
No edits/tests/execution; no coordinator/adapter/peer/observer API change needed.
9a must be reviewed/committed/pushed before implementation release.

P=.uwz-work/evidence/h2-streaming/integration-owned/combined-cases;
M=/tmp/uwz-task5e1-contract-v3.

## Existing seams

- coordinator.py296-320 validates selection before effects, handles empty,
  partitions fresh idle child from caller-ordered main; catalogue.py145-149.
- coordinator.py327 child_factory(run_identity,child_index,child_selection,
  ready,whole) constructs fresh app.
- coordinator.py338 descriptor['connect'](case,1,case_deadline,whole);
  coordinator.py141 same callback receives disconnect,2 for replacement.
- coordinator.py354-359 existing adapter.run_case branches remain sole dispatcher.
- coordinator.py375-390 ordinary final collection/teardown; shutdown_cases.py56-69
  completes shutdown lifecycle and coordinator.py268-284 publishes observations.
- Existing provider example is nested test_coordinator_shutdown.run_selection,
  contracts at test_coordinator_shutdown.py34-133, not reusable standaloneprovider.
  Implement a private provider, never call that driver or familycheck functions.

Each child owns test_core_peer.new_app(), completedprefix,currentpeer,bounded
observations,lifecyclecaseevidence. Advanceprefixafterordinaryclose, neverbetween
disconnectconnections. Share one lifecycleevidence percase across replacement
(test_lifecycle.py101-106).

## Owned surface

Initially two new private files test_all40_descriptors.py and test_all40.py plus
separately serialized necessary importinventory amendment after9a.

connection_descriptor(child:int,case:str,connection_index:int,*,final:bool)
-> ConnectionDescriptor

new_provider(*,clock:Clock) -> (ChildFactory,BindingState)

ChildFactory(run_identity,child_index,child_selection,ready_deadline,whole_deadline)
-> ChildDescriptor

connect(case,connection_index,case_deadline,whole_deadline) -> Connection

finish_binding(state:BindingState,result:dict) -> tuple[ConnectionReceipt,...]

BindingState explicitplain childrecords/currentpeer/orderedobserveridentitiesand
states/detachedclientprovidersnapshots/boundedcaseevidence. No retainedclient
contexts,payload/framehistories orregistrationframework. connect constructs
existingpeer,immutableexpectation,wrapsonce,recordsidentityandreturns connection7.
Preserve supplied clock/deadlines; observer samples none.

finish_binding only after successful coordinator.run return: canonical hooks
already finished/validated. Check failure/seal everyexpectedidentity once,
rejectmissing/duplicate,aggregate detached receipts. Failedruns cannotaccept.
Retain atmost41 bounded observers until boundary, avoiding newretirementprotocol.
Seam: bindingconstruction/comparison,observerwirefacts,coordinatorexecution.
Deletion test: remove two files, existing execution works unchanged.

## Immutable expectations

Use pure sources, neverclientregistration/ledger/peercursors/modelselectedtotals
as actualobservations. All-family ordinals/roles from acceptedinterface report.

| Family | Exact reusable source |
| --- | --- |
| Core | test_core_peer.primary_contract39, ordinaryorder48; model.core_request405 |
| Pause/admission/Continue/credit | respective schedule13/13/25/13; admission/Continue header_contract138/194; model.request_contract206 |
| Metadata/producer/file/terminal | respective paths32/16/19/11 |
| Lifecycle | test_lifecycle.order76,pair65 |
| Shutdown | fixed three/one requests test_shutdown94-145 |

Never call state-dependentrequestpath handler orpretendstate toproduceexpectation.
Where no purefunction, encode resolved immutableordinarysequence only.
Payload expectation uses model.payload_span/digest64-87 or exactconstants;
accepted_hash90 only ifaccepted==transmitted. Preserve rejectionwirebytes,
paddedflow/openhelduploads/restarted7+8prefix. Producer TOTAL/model.PRODUCER_HASH
test_producer_pressure13,32; file FILE_LENGTH/HASH/EARLY test_file_early14-16.
Roles unaffected bylength; diagnostichelper never earnscompletion.

Finaltags exact orderedmodel.BODY_SPECS only on child'sfinalconnection.
Disconnectconn1 neverfinal; replacementfinal ifcaseendschild. Shutdown always
requiredfinalcollection. No requesttotal derived fromthese expectationlengths
can substitute for successful wireobservation.

## Actual retained observations

- adapter.py378-400 ordinary context.final_observations/shutdownreturncapture.
- shutdown_cases.py42-53 actual retainedoutput/binding validation+copy.
- coordinator.py161-166,343,362-380 carries between cases/replacement.
- coordinator.py409-412 each returnedchild detachedfinalobservations/teardown.

Compare returnedactualobservations with detached actualprovider app snapshots
and retainedclientoutput/binding snapshots. Providersnapshot before signal
mutatesactive state; postsnapshot inexistingposthook pattern
(test_coordinator_shutdown.py84-119). Never rebuild observations via
model.records(selection,...). No additionaladapterwrapper orGET needed for
returnedfinalobservations. Canonicalcounters comparisonoperands only.
Sum connectionreceipts once; sharedlifecyclecaseevidence once afterbothconns.

## First vertical binding slice

Core,producer,file/early,disconnect,shutdown descriptors/provider/checks.
Primary actualcomposition:
shutdown_idle,producer_reuse,stream_file,disconnect,shutdown_active.
This is twofreshchildren,sixwrappedconnections,retainedproducer/file,replacement,
bothshutdownboundaries. Otherfocusedchains enddisconnect,ordinarycore,earlyfinal
toverify replacementfinaltags,ordinaryteardown,17byteoutputexclusion.

Checks: empties/invalid/duplicates/badorder preeffectinclclock; callerorder after
idlepartition; originalonce/noextraGET/no driverdispatch; allidentitiessealed/
dropduplicate reject; retainedoutputbindingcorruptionreject; failedpost/termination
preventsacceptance; authorizedopen debt retained; requiredreset/refundtails never
waived. Normal/O scopedchecks then independentreview.

Following binding adds pause/admission/Continue/credit/metadata/reuse/terminal
descriptors/criticalcompositions; subsetendinglarge; explicitall40 AND omitted
selection default coordinator.run invocation. All40 original2children41connections
802heads789smallR20009189946clientSETTINGS2info13incomingresets2collections,
childsubtotals/hashes/debt/deadline/ceilings and allnative/adoption/platform/full
milestone gates unchanged. No execution/coverage/nativeclaim from this report.
