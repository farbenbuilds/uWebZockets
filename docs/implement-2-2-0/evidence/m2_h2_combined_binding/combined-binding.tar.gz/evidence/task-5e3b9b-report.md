# First canonical coordinator/passive observer binding

Status: DONE for the assigned source-only binding slice. Fresh independent review,
publication accuracy review, graph update, commit and immediate push remain Root-owned.
No Git command, agent, publication, native/server/socket/TLS/process-ownership test,
network access, external model CLI, install, or production change was performed.

Base supplied by the brief: 46f97a1353297fe2dbf3f0f12307ef01ad32c3ff.
The brief, architect binding plan, accepted observer interface report, actual
AGENTS.md/CODING_CONVENTION.md, applicable specialist instructions and narrow
implementation/TDD/interface/design/review workflows supplied this slice's scope.
The specific source-only task overrides native/full-project execution for this unit;
those gates remain open and mandatory later.

## Exact files and interface

P = `/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases`.
U = `P/evidence/all40-binding-a`.
All source paths in this report are relative to P unless stated otherwise.

- NEW `test_all40_descriptors.py`, 324 lines, SHA256
  `9cebf12f8e17a705cf0240e55927688b974d5e8914aec27df6499bab1fd25d3b`.
- NEW `test_all40.py`, 302 lines, SHA256
  `2a4e4a0c0989c9b2ed578913c8e7e8334defc26243aaffd8820236f1960e11ef`.
- CHANGED `test_imports.py`, exact addition of the preceding two names to the
  existing inventory, SHA256
  `8fd690f0070bf7d34772fc01f4503361ae4a58eae34eae308842004b6629f08c`.
- NEW U evidence, including frozen inputs/history/source, current helpers,
  all intermediate and final test snapshots and separate command raws.
- This full report:
  `/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b9b-report.md`.

Published baseline43 -> current45: 42 modules unchanged, one exact inventory edit,
two new modules. No accepted peer, oracle, coordinator, adapter, model, handler,
client, core, fixture, product, pin or capacity changed.

The implemented interface is:

```text
connection_descriptor(child, case, connection_index, *, final) -> ConnectionDescriptor
new_provider(*, clock) -> (ChildFactory, BindingState)
finish_binding(state, result) -> tuple[ConnectionReceipt, ...]
```

Named documented tuple aliases retain the observer's exact positional contract;
plain explicit dictionaries hold provider/child state. The additional scoped
`run_selection(selection, *, clock)` validates the partial support set before
constructing the provider, then calls the canonical `coordinator.run`. It has no
omitted-selection default and does not replace canonical selection validation.
Only the canonical coordinator dispatches through existing adapter handlers.
No family driver/check or `test_coordinator_shutdown.run_selection` is called.

Each child starts one fresh `test_core_peer.new_app`, retains one current peer,
completed prefix, bounded shared lifecycle evidence, detached retained snapshots,
ordered releases/hooks/deadlines, and pre/post provider snapshots. Each connection
has one new observer; at most41 ordered observer states are retained. No client
context or payload/frame/read history is retained by the binding. Ordinary close
advances the prefix; disconnect close keeps it unchanged until replacement close.
One shared disconnect evidence object spans both distinct connections and is
compared once against their combined observed heads/DATA/frame/END facts.

The seven-key connection contract is preserved. Wrapping changes only send/receive;
protocol, now, owned, TLS and ALPN retain exact identities. Existing peers receive
the supplied clock and canonical deadlines remain unchanged. The observer does
not sample the clock, drive reads, add diagnostics, or schedule requests.

The caller supplies the successful canonical return only after all hooks validate.
`finish_binding` verifies expected ordered identities, completion of hooks and
observer failures before consuming the proof. It seals each observer once and
compares each child and aggregate count with the canonical returned counters.
Counts are summed from immutable sealed receipts, never selected catalogue/model
totals or cumulative lifecycle facts counted once per connection. Rejected
post-seal comparison consumes the finish boundary and cannot be repaired/retried
against already sealed observations.

## Expectation authority and actual comparisons

Descriptor order is derived from reviewed pure peer contracts:

- Core primary paths: `test_core_peer.primary_contract`; ordinary health/metrics
  sequence is explicit, matching its reviewed cursor schedule. Buffered/async
  bodies use `model.core_request` or exact small response constants.
- Producer order: `test_producer_pressure.paths`; output length16777313 and
  `model.PRODUCER_HASH`; sibling request/response exactly `b's'`.
- File/early order: `test_file_early.paths`, FILE_LENGTH24593, FILE_HASH, EARLY.
  Early refusal transmits no request DATA and has open request END mode, output
  role, status403 and required END plus incoming NO_ERROR reset. Its17 bytes
  never earn small-response completion.
- Disconnect order: pure `test_lifecycle.order`; first upload transmits32 bytes
  with H32 and remains open despite accepted application progress7. Replacement
  upload transmits the full32-byte split7+25 body and ends normally.
- Shutdown ordinary sequence is explicit health or health/held-upload/status.
  Active upload transmits32 bytes with H32, has no request END or response
  terminal, and retains stream3/debt32 through synthetic termination.
- Large contracts use fixed100000000 and LARGE_HASH, without constructing a whole
  body. Final tags are exactly the ordered67 `model.BODY_SPECS` names, on the
  actual child's last connection only. Disconnect1 can never be final; shutdown
  always requires its collection.

No mutable request-path handler is called with pretend state. Accepted counters,
client registrations, client ledgers and selected model totals are not observation
sources. Shared pinned hpack/hyperframe primitives remain a codec dependency;
this is not an independent codec implementation claim.

Provider snapshots are taken from the app actually updated by decoded traffic.
`signal` captures pre-shutdown app facts before mutating active shutdown state;
`post` captures post-hook facts. The binding compares returned canonical
`child.final_observations` and `child.teardown.post` with those detached snapshots.
Ordinary/disconnect close and signal also validate and copy actual retained
`output_observations`/`output_binding` through the existing `shutdown_cases.outputs`
seam and compare with the provider's current output/binding facts. This adds no
GETs. It never regenerates observations with `model.records(selection, ...)`.

Canonical counters and returned observations are comparison operands only.
Observed byte/head/small/flow/settings/info/reset/final totals come from receipts.
Synthetic close, signal, process and application diagnostics remain supplied
facts; they are not native close or ownership observations.

## Actual successful execution

Twelve supported IDs:
`ready_buffered`, `async_delayed`, `large_declared`, `large_undeclared`,
`producer_reuse`, `output_pressure_ready`, `output_pressure_window`, `stream_file`,
`early_final_order`, `disconnect`, `shutdown_idle`, `shutdown_active`.

The following four complete compositions were actually dispatched and sealed.
Eight distinct IDs completed successfully. The two large and two pressure IDs
received descriptor validation only; large_declared additionally began real
traffic in the intentionally failing partial-refund-tail negative. That negative
is not a completed large case. No constructor/family-check availability is claimed
as execution, and no default/all40 acceptance is claimed.

| Actual selection in dispatch order | Children | Connections | Heads | Small | Request flow | Client SETTINGS | Info | Incoming reset | Final collections | RX bytes | RX calls |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| shutdown_idle, producer_reuse, stream_file, disconnect, shutdown_active | 2 | 6 | 181 | 177 | 193 | 8 | 0 | 0 | 2 | 16890888 | 2240 |
| producer_reuse, stream_file, disconnect | 1 | 4 | 109 | 106 | 161 | 6 | 0 | 0 | 1 | 16861299 | 2167 |
| shutdown_idle, async_delayed, ready_buffered | 2 | 3 | 145 | 145 | 257 | 3 | 0 | 0 | 2 | 59080 | 148 |
| early_final_order | 1 | 1 | 75 | 74 | 32 | 2 | 0 | 1 (code0) | 1 | 31042 | 79 |

The primary six receipts, in actual connection order:

| Identity child/case/index | Heads | Small | Flow | SETTINGS | Final requests/responses/collections | Connection/stream debt |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| 0/shutdown_idle/1 | 69 | 69 | 0 | 1 | 68/68/1 | 0/0 |
| 1/producer_reuse/1 | 9 | 8 | 64 | 2 | 0/0/0 | 64/64 |
| 1/stream_file/1 | 7 | 6 | 33 | 2 | 0/0/0 | 33/33 |
| 1/disconnect/1 | 3 | 2 | 32 | 1 | 0/0/0 | 32/32 |
| 1/disconnect/2 | 22 | 22 | 32 | 1 | 0/0/0 | 32/32 |
| 1/shutdown_active/1 | 71 | 70 | 32 | 1 | 68/68/1 | 32/32 |

Primary child subtotals are idle69heads/69small and main112heads/108small.
Both abandoned streams retain streamID3, request_end=False, response_end=False,
no incoming/outgoing reset, terminal_complete=False and32 bytes of debt in both
request scopes. No transport teardown is used to invent END or zero credit.

The disconnect-ending composition earns the final68 only on replacement:
connection1 is3heads/2small, replacement90heads/90small. Ordinary-core teardown
preserves ready_buffered debt257/257. The early response has exactly17 output
bytes, SHA256 `d826bcf95ee8850cecb39accdeb84b32336a0415411938da42da7edcac891da7`,
one code0 reset and74 small completions including its final68.

Primary producer output is16777313 bytes, SHA256
`e5b7e8c5bbad59c7bc86f18236a37661571e972f65c707d7dc1902386ec5e91d`.
File output is24593 bytes, SHA256
`8cacc49e5f9553369e25a67f4e0e9a799b38c07245a6da92a54ffb58c3ebc2ac`.
Actual returned producer/file output diagnostics and binding generation18 survive
through disconnect replacement into active shutdown and its pre/post comparisons.

Test instrumentation checks actual adapter dispatch order, unique wrapper/state
identities, exact underlying send/receive call counts against receipts, and one
lifecycle comparison. It restores every mock on success or exception. Exact
request identities/ordinals and final cursors rule out extra diagnostics.
The idle child remains first; main async-before-ready proves caller main ordering.

## Negative coverage and real RED/GREEN

- Empty selection creates no child or connection and samples no clock or wire.
  Invalid sequence, unknown/duplicate IDs, idle/active ordering and unsupported
  selections reject before provider construction.
- Missing, duplicated and wrong connection identities reject before sealing.
  Duplicate successful finish rejects.
- An actual original receive call after shutdown raises unchanged, poisons the
  observer, and makes a previously returned successful result unacceptable.
- Actual retained context output hash/binding corruption blocks replacement.
  Corruption of canonical returned output/binding/final record also fails the
  detached provider comparison.
- Supplied termination/post failures propagate the exact exception object and
  prevent accepted receipts. Failed runs have no successful result to finish.
- Actual early-response reset and large-upload refund packets are truncated at
  twelve bytes of their13-byte frame. Before the next supplied receive failure,
  sealing the partial observer rejects. The canonical run cannot complete and
  teardown cannot waive those required tails. The original receive failure wins.
- Authorized disconnect/active open streams retain transmitted32/H32 and debt,
  without manufacturing wire terminals.

`red-004-api` is only an API-absence pre-effect RED (new module did not exist).
The real behavioral RED is `red-007-seal-once`: after successful ready-buffered
execution, corrupting returned aggregate heads caused comparison rejection, but
repairing that operand allowed a second finish to reseal and accept the same
observers. Its original source/raws are retained. The fix marks the one-shot
finish consumed immediately before the first seal; `green-009-seal-once` and all
final checks prove rejected acceptance cannot be retried. No assertion, bound,
threshold or existing gate was weakened.

## Frozen authority, exact receipts and live helper metadata

`U/baseline.json` contains `source` (43 hashes), `history` (16227 prior evidence
file hashes), `authority` and `authority_sha256`. The authority is the published
`docs/implement-2-2-0/evidence/m2_h2_combined_wire_oracle/manifest.json`.
`U/baseline-source/*.py` are exact43 pre-edit byte copies.
`U/baseline-inputs.json` is an exact copy of
`P/evidence/coordinator-a/immutable-inputs.json`.
The exhaustive prior-history map covers every existing file beneath P/evidence,
excluding only this new U subtree; old live helpers are included and preserved.

Each recorded runner folder contains:

```text
before/inventory.json, after/inventory.json
before/<actual source files>.py, after/<actual source files>.py
before/helpers/<helper name>.txt, after/helpers/<helper name>.txt
argv.txt, stdout.txt, stderr.txt, exit.txt
restoration.json, restoration.stdout, restoration.stderr
```

Inventory JSON fields are `source`, `helpers`, `cwd`, `interpreter`,
`interpreter_sha256`, `pythonpath`, `dontwritebytecode`. Source and helper maps
contain SHA256. Final audit verifies actual snapshot bytes, not just manifest
agreement. The current45 before/after maps are identical for all final checks
and match the current files. Current helpers match the helpers captured by each
final check.

Current helpers and their SHA256:

| Path relative to U | SHA256 |
| --- | --- |
| helpers/capture.py | e556b4e79645ff119f556c04dd351532d1cf134e8b1aa232df2c1a652ce29a5b |
| helpers/freeze.py | 7cfc2bce5fbb8bf9ba59f774936deed600ed2c9e7a685951ed88a6abb22c8a23 |
| helpers/audit.py | badc2b81d07983e291b75c8140cb0096c2dba771bfb368631c8a05dffdcdd20a |
| helpers/run.sh | ce1ef2e7badcb09596b6203840170ee633b45e9a3958b0c3b2eb23235bcd776c |

The initial live audit helper was strengthened to bind the published authority,
input copy, actual captured source/helper bytes and shell runner inertness.
Its preceding bytes are explicitly retained at `U/audit-before-strengthening.py.txt`
and `U/intermediate-012-depth/{before,after}/helpers/audit.py.txt`; current bytes
map to all four final checks. No live helper is exempted as historical.

## Commands actually run and results

Every direct Python used `/home/codespace/.python/current/bin/python3 -B -S`,
optionally `-O`. Interpreter SHA256 is
`4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`.
Dependent check shells begin `set -e` and run the exact restorer with a new
absolute receipt before the dependent operation in that same shell:

```text
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT
```

The runner exports `PYTHONDONTWRITEBYTECODE=1` and this exact PYTHONPATH:

```text
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
```

Runner invocation from repository cwd:

```text
sh .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/all40-binding-a/helpers/run.sh --run NAME PYTHON_ARGUMENTS
```

It then changes cwd to P, captures bytes/inventory, records exact argv, executes
Python with separate stdout/stderr/exit, and captures again even when the target
fails. Every restoration verified119 authority entries,118 physical rows,
113 unique files,42 ordered codecs and pinned interpreter. Zero inputs needed
restoration in this run. Codec digest is
`0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`.

| Folder under U | Actual target after `-B -S` | Exit / meaning |
| --- | --- | --- |
| freeze-003 | `evidence/all40-binding-a/helpers/freeze.py --freeze <absolute U>/baseline.json` | 0; froze43 sources and16227 history hashes |
| red-004-api | `test_all40.py` | 1; missing new module, pre-effect only |
| intermediate-005-primary | `test_all40.py` | 0; actual primary six-connection composition |
| red-007-seal-once | `-c 'import test_all40 as t; t.check_rejected_finish_consumes_boundary()'` | 1; real reseal defect |
| green-009-seal-once | `-c 'import test_all40 as t; t.check_rejected_finish_consumes_boundary(); print("Rejected finish cannot reseal")'` | 0; regression fixed |
| intermediate-010-compositions | `test_all40.py` | 0; four actual compositions and initial negative set |
| intermediate-012-depth | exact AST helper-loading `-c` retained in argv.txt | 0; new source/helpers max3 |
| intermediate-014-poison | `-c 'import test_all40 as t; t.check_poisoned_binding()'` | 0; actual receive failure rejects binding |
| intermediate-015-audit | exact source/history/strict/inert helper-loading `-c` retained in argv.txt | 0; current helpers and prior history |
| final-01-focused | `test_all40.py` | 0 |
| final-02-focused-optimized | `-O test_all40.py` | 0 |
| final-03-imports | `test_imports.py` | 0 |
| final-04-imports-optimized | `-O test_imports.py` | 0 |
| final-audit | `evidence/all40-binding-a/helpers/audit.py --audit <absolute U>/final-audit.json` | 0 |

The final four are the covering tests after the last source/helper edit. Their
stderr files are empty. Full JSON composition summaries and per-connection facts
are in both final focused stdout files. `U/final-audit.json` is the final metadata
result; `U/final-audit/` contains its exact invocation and captured bytes/raws.
No extra historical suite was run.

Additional pinned restoration receipts for read/edit shells are `restore-001.json`,
`restore-002.json`, `restore-006-read.json`, `restore-008-edit.json`,
`restore-011-edit.json`, and `restore-013-edit.json`. The first read attempted a
nonexistent `/tmp/.../coordinator.py`; it exited1 after successful restoration.
`U/initial-read-transcript.txt` explicitly preserves the original tool transcript,
not a fabricated redirected raw or behavioral RED. Subsequent reads used the
supplied owned coordinator path. Graphify queries preceded new code questions;
Root owns the eventual AST-only graph update.

## Final audits and self-review

Final audit output:

```text
45 current AST; 42 unchanged + inventory-only + 2 new; prior history: 16227
Strict max-three nesting, inert empty/foreign argv and live helper identities: 3
```

All45 source modules pass established AST/main-guard/import-effect checks normally
and optimized. Only the two new sources and three current Python helpers receive
this unit's additional no-global/nonlocal/module-mutable-container/max3 audit;
unchanged historical source is not forced through a new policy. Maximum control
nesting is2 for the provider and3 for its checks; helper maxima are1/2/2.
The current Python helpers have explicit CLI flags/arity and were executed under
inert import and direct-main empty/foreign argv effect guards. The shell runner
was checked under five empty/foreign/incomplete argument combinations, with zero
output, exit0 and unchanged file inventory. Each final run is byte-bound to those
current helpers. Published43 source authority, the119-entry input authority and
all16227 historical evidence hashes remain intact.

Self-review checked descriptor/source independence, transmitted versus accepted
bytes, exceptional output roles, final tags on replacement, request debt,
shared lifecycle counting, exact operation counts, pre/post snapshot timing,
retained client comparison seams, failure propagation, restored test patches,
one-shot sealing, bounded retention, source ownership and evidence identity.
No unresolved interface/contract defect or ownership expansion is identified.
The provider is private and deliberately partial; its name is not an all40 claim.

Default/all40 execution remains mandatory later:2 children,41 connections,
802 heads,789 small,R200091899,46 client SETTINGS,2 informationals,13 incoming
resets,2 final collections; child subtotals/hashes/debt/deadlines/ceilings including
RX5288609050/refundframes400183798 remain unchanged. Lifecycle reuse and all other
families remain for the following binding slice. Full native/project/platform,
production adoption and all original milestone gates remain open. This report
claims neither native behavior nor milestone completion.
