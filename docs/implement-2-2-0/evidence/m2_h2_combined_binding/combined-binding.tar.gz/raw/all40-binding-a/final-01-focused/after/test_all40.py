"""Actual scoped canonical compositions, retained observations and rejection seams."""
import json
from functools import partial
from unittest import mock
import adapter
import coordinator
import model
import test_all40_descriptors as binding
import test_wire_oracle as oracle

PRIMARY = ('shutdown_idle', 'producer_reuse', 'stream_file', 'disconnect', 'shutdown_active')
COMPOSITIONS = (PRIMARY, ('producer_reuse', 'stream_file', 'disconnect'),
                ('shutdown_idle', 'async_delayed', 'ready_buffered'), ('early_final_order',))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def rejected(operation, expected):
    try:
        operation()
    except ValueError as error:
        require(str(error) == expected, 'wrong rejection: ' + str(error))
        return
    raise ValueError('invalid binding accepted: ' + expected)


def count_operation(counters, direction, operation, *args):
    result = operation(*args)
    counters[direction] += 1
    return result


def instrument_wrap(original, evidence, connection, descriptor):
    counters = dict(send=0, receive=0)
    instrumented = dict(connection, send=partial(count_operation, counters, 'send', connection['send']),
                        receive=partial(count_operation, counters, 'receive', connection['receive']))
    wrapped, observer = original(instrumented, descriptor)
    require(set(wrapped) == set(connection) and all(wrapped[key] is connection[key] for key in ('protocol', 'now', 'owned', 'tls', 'alpn')), 'wrapper altered connection contract')
    evidence['wrapped'].append((descriptor[0], observer, counters))
    return wrapped, observer


def instrument_dispatch(original, evidence, context, receive, **kwargs):
    evidence['dispatch'].append(context['stage']['case'])
    return original(context, receive, **kwargs)


def instrument_lifecycle(original, evidence, child, receipts):
    evidence['lifecycle'].append(child['identity'])
    return original(child, receipts)


def execute(selection):
    evidence = dict(dispatch=[], wrapped=[], lifecycle=[])
    with mock.patch.object(adapter, 'run_case', partial(instrument_dispatch, adapter.run_case, evidence)), mock.patch.object(oracle, 'wrap_connection', partial(instrument_wrap, oracle.wrap_connection, evidence)), mock.patch.object(binding, 'compare_lifecycle', partial(instrument_lifecycle, binding.compare_lifecycle, evidence)):
        result, state = binding.run_selection(selection, clock=lambda: 2)
        receipts = binding.finish_binding(state, result)
    require(evidence['dispatch'] == list(selection), 'canonical dispatch order differs')
    require(len(evidence['wrapped']) == len(receipts), 'connection wrapped more than once')
    require(len({id(row[1]) for row in evidence['wrapped']}) == len(receipts), 'observer reused')
    require(len(evidence['lifecycle']) == int('disconnect' in selection), 'cumulative lifecycle facts compared more than once')
    for (identity, observer, counters), receipt in zip(evidence['wrapped'], receipts):
        require(identity == receipt[0] and counters == dict(send=receipt[2][0], receive=receipt[3][0]), 'underlying operation duplicated')
        require(observer['sealed'] and oracle.failure(observer) is None, 'expected observer not sealed')
    return result, state, receipts


def check_open(receipt):
    require(receipt[13] == (3,) and receipt[11:13] == (32, 32), 'transport debt discarded')
    held = receipt[14][1]
    require(held[3:6] == (32, 32, bytes.fromhex(model.H32)) and held[9:13] == (False, False, None, None) and held[-1] is False,
            'transport abandonment manufactured terminal')


def receipt_report(receipt):
    output = tuple(dict(ordinal=item[0], bytes=item[6], sha256=item[8].hex()) for item in receipt[14] if item[2] == 'output')
    return dict(identity=receipt[0], heads=receipt[2][3], small=receipt[6], flow=receipt[2][7], settings=receipt[2][9],
                informationals=receipt[4], incoming_resets=receipt[3][11], final_requests=receipt[8],
                final_responses=receipt[9], final_collections=receipt[10], debt=receipt[11:13],
                transport_incomplete=receipt[13], outputs=output)


def check_composition(selection):
    result, state, receipts = execute(selection)
    require(len(state['children']) == len(result['children']), 'child count differs')
    require(all(child['before'] is not child['after'] for child in state['children']), 'provider snapshots alias')
    for receipt in receipts:
        last = next(child['selection'][-1] for child in state['children'] if child['identity'][1] == receipt[0][0])
        final = receipt[0][1] == last and receipt[0][1:] != ('disconnect', 1)
        require(receipt[8:11] == ((68, 68, 1) if final else (0, 0, 0)), 'final collection assigned to wrong connection')
        if receipt[0][1:] in (('disconnect', 1), ('shutdown_active', 1)):
            check_open(receipt)
    if selection == PRIMARY:
        require(len(receipts) == 6 and len(state['children']) == 2, 'primary topology differs')
        main = result['children'][1]
        require(main['final_observations']['outputs']['producer_reuse']['offset'] == 16777313 and
                main['final_observations']['outputs']['stream_file']['returned'] == 24593 and
                main['final_observations']['binding']['binding_generation'] == 18, 'retained output lost through replacement')
        require(state['children'][0]['hooks'] == ['preconditions', 'close', 'signal', 'process', 'post'] and
                state['children'][1]['hooks'][-5:] == ['preconditions', 'signal', 'termination', 'process', 'post'], 'shutdown boundary ordering differs')
    if selection == ('early_final_order',):
        require(receipts[0][5:8] == (74, 74, 1) and receipts[0][14][3][6] == 17, '17-byte output counted as small')
    print(json.dumps(dict(selection=selection, actual_dispatch=selection, observed=binding.receipt_counts(receipts),
                         receipts=tuple(receipt_report(item) for item in receipts)), sort_keys=True))


def forbidden(*args, **kwargs):
    raise RuntimeError('pre-effect violation')


def check_preeffect():
    factory, state = binding.new_provider(clock=forbidden)
    with mock.patch.object(binding, 'new_child', forbidden), mock.patch.object(binding, 'connect', forbidden):
        result = coordinator.run((), run_identity='empty', now=1, units_per_second=1000, clock=forbidden, child_factory=factory)
        require(binding.finish_binding(state, result) == () and not state['children'], 'empty run effects')
    invalid = ((None, 'case IDs must be a sequence'), (('unknown',), 'unknown or duplicate case'),
               (('ready_buffered', 'ready_buffered'), 'unknown or duplicate case'),
               (('ready_buffered', 'shutdown_idle'), 'idle child must be first'),
               (('shutdown_active', 'ready_buffered'), 'active shutdown must be last'),
               (('reuse',), 'unsupported binding selection'), (('partial_pause',), 'unsupported binding selection'))
    with mock.patch.object(binding, 'new_provider', forbidden):
        for selection, message in invalid:
            rejected(partial(binding.run_selection, selection, clock=forbidden), message)
    print('Empty/invalid/duplicate/order/unsupported selection: zero child/connect/clock/wire effects')


def check_descriptors():
    require(len(binding.SUPPORTED) == 12, 'support set changed')
    for case in binding.SUPPORTED:
        number = 2 if case == 'disconnect' else 1
        descriptor = binding.connection_descriptor(1, case, number, final=True)
        require(descriptor[2] == tuple(row[0] for row in model.BODY_SPECS), 'final tags differ')
    first = binding.connection_descriptor(1, 'disconnect', 1, final=False)
    require(first[2] == () and first[1][1][2] == 'open', 'disconnect first descriptor final')
    for case in ('large_declared', 'large_undeclared'):
        item = binding.connection_descriptor(1, case, 1, final=False)[1][2]
        require(item[3] == (100000000, 100000000, bytes.fromhex(model.LARGE_HASH)), 'large descriptor guessed body')
    rejected(partial(binding.connection_descriptor, 1, 'shutdown_active', 1, final=False), 'shutdown requires final collection')
    print('Twelve descriptor contracts validated; descriptor validation is not traffic execution')


def check_receipt_identity():
    result, state = binding.run_selection(('ready_buffered',), clock=lambda: 2)
    original = list(state['observers'])
    for replacement in ([], original + original, [((0, 'async_delayed', 1), original[0][1])]):
        state['observers'] = replacement
        rejected(partial(binding.finish_binding, state, result), 'binding missing duplicate or wrong receipt')
        require(not original[0][1]['sealed'], 'invalid identity sealed a receipt')
    state['observers'] = original
    binding.finish_binding(state, result)
    rejected(partial(binding.finish_binding, state, result), 'binding successful return required')
    print('Missing/duplicate/wrong identities reject before seal; successful receipt consumed once')


def check_rejected_finish_consumes_boundary():
    result, state = binding.run_selection(('ready_buffered',), clock=lambda: 2)
    result['totals']['heads'] += 1
    rejected(partial(binding.finish_binding, state, result), 'binding aggregate client counters differ')
    result['totals']['heads'] -= 1
    rejected(partial(binding.finish_binding, state, result), 'binding successful return required')
    print('Rejected acceptance cannot reseal observers after repairing a comparison operand')


def check_returned_corruption(field):
    result, state = binding.run_selection(('producer_reuse', 'stream_file', 'disconnect'), clock=lambda: 2)
    actual = result['children'][0]['final_observations']
    if field == 'output':
        actual['outputs']['stream_file']['returned'] += 1
    elif field == 'binding':
        actual['binding']['binding_generation'] += 1
    else:
        actual['records']['disconnect']['stale_resume'] += 1
    rejected(partial(binding.finish_binding, state, result), 'binding final client observations differ')
    print('Actual returned retained ' + field + ' corruption rejected')


def corrupt_retained(original, field, child, context, deadline):
    if context['stage']['case'] == 'producer_reuse':
        if field == 'output':
            context['output_observations']['producer_reuse']['sha256'] = model.EMPTY_HASH
        else:
            context['output_binding']['binding_generation'] += 1
    return original(child, context, deadline)


def check_retained_corruption(field):
    factory, state = binding.new_provider(clock=lambda: 2)
    with mock.patch.object(binding, 'close', partial(corrupt_retained, binding.close, field)):
        try:
            coordinator.run(('producer_reuse', 'disconnect'), run_identity='corruption', now=1,
                            units_per_second=1000, clock=lambda: 2, child_factory=factory)
        except ValueError:
            require(len(state['observers']) == 1 and not state['children'][0]['posted'], 'retained corruption reached replacement')
        else:
            raise ValueError('retained corruption accepted')
    rejected(partial(binding.finish_binding, state, None), 'binding successful return required')
    print('Actual retained context ' + field + ' corruption blocks replacement')


def fail_hook(error, *args):
    raise error


def check_failed_hook(phase):
    factory, state = binding.new_provider(clock=lambda: 2)
    error = RuntimeError('supplied ' + phase + ' failure')
    with mock.patch.object(binding, phase, partial(fail_hook, error)):
        try:
            coordinator.run(('shutdown_active',), run_identity='failed', now=1, units_per_second=1000,
                            clock=lambda: 2, child_factory=factory)
        except RuntimeError as actual:
            require(actual is error, 'hook exception identity changed')
        else:
            raise ValueError('failed hook accepted')
    rejected(partial(binding.finish_binding, state, None), 'binding successful return required')
    require(not state['observers'][0][1]['sealed'], 'failed run sealed a receipt')
    print('Failed ' + phase + ' prevents acceptance and preserves supplied exception')


def truncate_receive(fault, original):
    if fault['cut']:
        rejected(partial(oracle.seal, fault['observer']), 'oracle_unsealed')
        fault['rejected_partial'] = True
        raise fault['error']
    data, timestamp = original()
    position = data.find(fault['needle'])
    if position < 0:
        return data, timestamp
    fault['cut'] = True
    return data[:position + 12], timestamp


def truncate_wrap(original, fault, connection, descriptor):
    supplied = dict(connection, receive=partial(truncate_receive, fault, connection['receive']))
    wrapped, observer = original(supplied, descriptor)
    fault['observer'] = observer
    return wrapped, observer


def check_partial_tail(kind):
    reset = kind == 'reset'
    case = 'early_final_order' if reset else 'large_declared'
    needle = bytes.fromhex('00000403000000000700000000' if reset else '00000408000000000000002000')
    fault = dict(needle=needle, cut=False, rejected_partial=False, error=RuntimeError('supplied missing ' + kind + ' tail'), observer=None)
    factory, state = binding.new_provider(clock=lambda: 2)
    with mock.patch.object(oracle, 'wrap_connection', partial(truncate_wrap, oracle.wrap_connection, fault)):
        try:
            coordinator.run((case,), run_identity='partial', now=1, units_per_second=1000, clock=lambda: 2, child_factory=factory)
        except RuntimeError as actual:
            require(actual is fault['error'], 'partial tail changed original error')
        else:
            raise ValueError('incomplete tail accepted')
    require(fault['cut'] and fault['rejected_partial'] and not state['children'][0]['posted'], 'partial tail did not block teardown')
    rejected(partial(binding.finish_binding, state, None), 'binding successful return required')
    print('Actual partial ' + kind + ' tail blocks seal and canonical acceptance')


def capture_connection(original, captured, connection, descriptor):
    wrapped, observer = original(connection, descriptor)
    captured.append(wrapped)
    return wrapped, observer


def check_poisoned_binding():
    captured = []
    with mock.patch.object(oracle, 'wrap_connection', partial(capture_connection, oracle.wrap_connection, captured)):
        result, state = binding.run_selection(('shutdown_idle',), clock=lambda: 2)
    try:
        captured[0]['receive']()
    except RuntimeError as error:
        require(str(error) == 'receive after shutdown', 'underlying error changed')
    else:
        raise ValueError('late receive unexpectedly succeeded')
    require(oracle.failure(state['observers'][0][1])[0] == 'receive_exception', 'late failure not retained')
    rejected(partial(binding.finish_binding, state, result), 'binding observer poisoned or wrong identity')
    require(not state['observers'][0][1]['sealed'], 'poisoned state sealed')
    print('Actual original receive failure poisons the binding and rejects returned success')


def main():
    check_preeffect()
    check_descriptors()
    for selection in COMPOSITIONS:
        check_composition(selection)
    check_receipt_identity()
    check_poisoned_binding()
    check_rejected_finish_consumes_boundary()
    for field in ('output', 'binding', 'record'):
        check_returned_corruption(field)
    for field in ('output', 'binding'):
        check_retained_corruption(field)
    for phase in ('termination', 'post'):
        check_failed_hook(phase)
    for kind in ('reset', 'refund'):
        check_partial_tail(kind)


if __name__ == '__main__':
    main()
