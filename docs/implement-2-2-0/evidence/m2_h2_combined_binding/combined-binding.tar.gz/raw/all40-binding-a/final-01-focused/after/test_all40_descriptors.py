"""Partial canonical binding; immutable expectations never earn wire receipts.

Children retain one current peer, bounded observer states and detached facts.
The caller must pass the successful canonical return to finish_binding.
"""
import copy
import hashlib
from functools import partial
from typing import Callable
import cases
import coordinator
import model
import shutdown_cases
import test_core_peer
import test_file_early
import test_lifecycle
import test_producer_pressure
import test_shutdown
import test_wire_oracle as oracle

# Supplied monotonic clock; sampled by canonical execution and existing peers only.
Clock = Callable[[], int]
# Existing canonical seven-hook descriptor with selection-dependent hooks.
ChildDescriptor = dict
ChildFactory = Callable[[str, int, tuple[str, ...], int, int], ChildDescriptor]
# clock, children<=2, ordered (identity, observer)<=41, one-shot finish flag.
BindingState = dict
# Fresh app, completed prefix, current peer, bounded lifecycle/retained/hook facts.
ChildState = dict
ConnectionDescriptor = oracle.ConnectionDescriptor
ConnectionReceipt = oracle.ConnectionReceipt
PayloadExpectation = oracle.PayloadExpectation
RequestExpectation = oracle.RequestExpectation
SUPPORTED = ('ready_buffered', 'async_delayed', 'large_declared', 'large_undeclared',
             'producer_reuse', 'output_pressure_ready', 'output_pressure_window',
             'stream_file', 'early_final_order', 'disconnect', 'shutdown_idle', 'shutdown_active')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def payload(data: bytes) -> PayloadExpectation:
    return len(data), len(data), hashlib.sha256(data).digest()


def ordinary_paths(case, number):
    if case in model.PRODUCERS:
        return tuple(test_producer_pressure.paths(case))
    if case in ('stream_file', 'early_final_order'):
        return tuple(test_file_early.paths(case))
    if case == 'disconnect':
        return tuple(test_lifecycle.order(case, number))
    if case == 'shutdown_idle':
        return ('/health',)
    if case == 'shutdown_active':
        return '/health', '/limit/shutdown_active?case=shutdown_active', '/status/shutdown_active'
    path = test_core_peer.primary_contract(case)[0]
    if case == 'async_delayed':
        return '/health', path, '/health'
    return '/health', '/metrics', path, '/metrics', '/health'


def request_expectation(case, target) -> RequestExpectation:
    empty = payload(b'')
    if target == '/delayed':
        return 'GET', target, 'headers', empty, 'small', 'end', 200, (), payload(b'delayed-ok')
    if target == '/echo':
        body = model.core_request(case)['body'] if case == 'ready_buffered' else b's'
        return 'POST', target, 'data', payload(body), 'small', 'end', 200, (), payload(body)
    if not target.startswith(('/limit/', '/upload/')):
        response = payload(b'ok') if target == '/health' else None
        return 'GET', target, 'headers', empty, 'small', 'end', 200, (), response
    tag = target.split('/')[-1].split('?')[0]
    body = (model.MAX_PAYLOAD, model.MAX_PAYLOAD, bytes.fromhex(model.LARGE_HASH)) if tag.startswith('large_') else payload(model.payload_span(32, 0, 32))
    if tag in ('disconnect', 'shutdown_active'):
        return 'POST', target, 'open', body, 'transport', 'transport_abandon', None, (), None
    if tag == 'early_final_order':
        return 'POST', target, 'open', empty, 'output', 'end_reset_0', 403, (), payload(test_file_early.EARLY)
    if tag == 'stream_file':
        output = (test_file_early.FILE_LENGTH, test_file_early.FILE_LENGTH, bytes.fromhex(test_file_early.FILE_HASH))
        return 'POST', target, 'data', body, 'output', 'end', 200, (), output
    if tag in model.PRODUCERS:
        output = (test_producer_pressure.TOTAL, test_producer_pressure.TOTAL, bytes.fromhex(model.PRODUCER_HASH))
        return 'POST', target, 'data', body, 'output', 'end', 200, (), output
    return 'POST', target, 'data', body, 'small', 'end', 200, (), None


def connection_descriptor(child: int, case: str, connection_index: int, *, final: bool) -> ConnectionDescriptor:
    """Resolved peer order and transmitted payloads, independent of client state."""
    require(type(case) is str and case in SUPPORTED and type(final) is bool, 'unsupported binding descriptor')
    require(type(connection_index) is int and connection_index in ((1, 2) if case == 'disconnect' else (1,)), 'binding connection index')
    require(not (case == 'disconnect' and connection_index == 1 and final), 'disconnect first cannot be final')
    require(case not in ('shutdown_idle', 'shutdown_active') or final, 'shutdown requires final collection')
    ordinary = tuple(request_expectation(case, target) for target in ordinary_paths(case, connection_index))
    tags = tuple(row[0] for row in model.BODY_SPECS) if final else ()
    result = (child, case, connection_index), ordinary, tags
    oracle.validate_descriptor(result)
    return result


def app_snapshot(child: ChildState, *, after: bool) -> dict:
    app = child['app']
    metrics = test_core_peer.metrics(app)
    metrics['slot0_active'] = bool(app['records']['shutdown_active']['active'])
    binding = app['binding']
    if after and binding is None:
        binding = model.default_binding()
    return copy.deepcopy(dict(records=app['records'], metrics=metrics, outputs=app['outputs'], binding=binding))


def retained_snapshot(child, context, selection):
    outputs, binding = shutdown_cases.outputs(context, selection)
    actual = dict(outputs=outputs, binding=binding)
    expected = dict(outputs=copy.deepcopy(child['app']['outputs']), binding=copy.deepcopy(child['app']['binding']))
    require(actual == expected, 'retained client output or binding differs from provider')
    require(len(child['retained']) < 41, 'retained snapshot bound')
    child['retained'].append(copy.deepcopy(actual))


def new_provider(*, clock: Clock) -> tuple[ChildFactory, BindingState]:
    """No clock/effects until the canonical coordinator invokes the factory."""
    require(callable(clock), 'binding clock')
    state = dict(clock=clock, children=[], observers=[], finished=False)
    return partial(new_child, state), state


def new_child(state, identity, index, selection, ready, whole):
    require(index == len(state['children']) and index < 2 and all(case in SUPPORTED for case in selection), 'binding child order')
    require(not index or state['children'][-1]['posted'], 'binding prior child not posted')
    child = dict(identity=(identity, index), selection=selection, app=test_core_peer.new_app(), prior=(),
                 peer=None, current=None, evidence=test_lifecycle.new_case_evidence(), retained=[],
                 posted=False, signaled=False, processed=False, terminated=False, closed=False,
                 before=None, after=None, hooks=[], deadlines=[], released=[])
    state['children'].append(child)
    descriptor = dict(identity=(identity, index), ready=True, fresh_application=True,
                      connect=partial(connect, state, child), signal=partial(signal, child),
                      process=partial(process, child), post=partial(post, child))
    if any(case != 'shutdown_active' for case in selection):
        descriptor['close'] = partial(close, child)
    if 'disconnect' in selection:
        descriptor['disconnect_close'] = partial(disconnect_close, child)
    if any(case in ('shutdown_idle', 'shutdown_active') for case in selection):
        descriptor['preconditions'] = partial(preconditions, child)
    if 'shutdown_active' in selection:
        descriptor['termination'] = partial(termination, child)
    return descriptor


def make_peer(case, number, child, args):
    if case in ('shutdown_idle', 'shutdown_active'):
        args.pop('final')
        return test_shutdown.new_peer(case, **args)
    if case == 'disconnect':
        return test_lifecycle.new_peer(case, number, case_evidence=child['evidence'], **args)
    if case in model.PRODUCERS:
        return test_producer_pressure.new_peer(case, **args)
    if case in ('stream_file', 'early_final_order'):
        return test_file_early.new_peer(case, **args)
    return test_core_peer.new_peer(case, **args)


def connect(state, child, case, number, deadline, whole):
    require(not child['signaled'] and case == child['selection'][len(child['prior'])], 'binding connect order')
    require(number == 1 and child['current'] is None or number == 2 and child['current'] == ('disconnect', 1) and child['closed'], 'binding replacement order')
    final = case == child['selection'][-1] and not (case == 'disconnect' and number == 1)
    descriptor = connection_descriptor(child['identity'][1], case, number, final=final)
    require(len(state['observers']) < 41, 'binding observer bound')
    args = dict(app=child['app'], prior=child['prior'], now=state['clock'](), clock=state['clock'], final=final)
    peer = make_peer(case, number, child, args)
    wrapped, observer = oracle.wrap_connection(peer['connection'], descriptor)
    require(all(wrapped[key] is peer['connection'][key] for key in ('protocol', 'now', 'owned', 'tls', 'alpn')), 'binding changed connection identity')
    child.update(peer=peer, current=(case, number), closed=False)
    child['deadlines'].append((case, number, deadline, whole))
    state['observers'].append((descriptor[0], observer))
    return wrapped


def preconditions(child, context):
    require(child['prior'] == context['selected_before'], 'binding prefix differs')
    child['hooks'].append('preconditions')
    if child['selection'][-1] == 'shutdown_active':
        return dict(client_open=True, prior_complete=True)
    return dict(client_open=True, fresh_application=True)


def close(child, context, deadline):
    require(not child['closed'] and not child['signaled'], 'binding duplicate close')
    case = context['stage']['case']
    retained_snapshot(child, context, child['prior'] + (case,))
    child['peer']['state']['closed'] = True
    child['closed'] = True
    child['released'].append(child['current'])
    child['current'] = None
    child['prior'] += (case,)
    child['hooks'].append('close')
    return dict(method='close', client_closed=True, close='normal')


def disconnect_close(child, context):
    require(child['current'] == ('disconnect', 1) and not child['closed'] and context['raw']['closing']['phase'] == 'pre_unwrap', 'binding strict close order')
    retained_snapshot(child, context, child['prior'])
    child['peer']['state']['closed'] = True
    child['closed'] = True
    child['released'].append(child['current'])
    child['app']['records']['disconnect'] = test_lifecycle.terminal('disconnect')
    child['app']['records']['disconnect'].update(stale_resume=0, stale_cancel=0)
    child['hooks'].append('disconnect_close')
    return dict(method='ssl_unwrap', tls_shutdown='success', tcp_eof=True, trailing_bytes=0, close='normal')


def signal(child, context, deadline):
    active = child['selection'][-1] == 'shutdown_active'
    require(not child['signaled'] and context['stage']['final_complete'], 'binding signal before collection')
    require(active or child['closed'], 'binding signal before close')
    require(not child['peer']['state']['pending'] and not child['peer']['state']['buffer'], 'binding signal wire residue')
    retained_snapshot(child, context, child['selection'])
    child['before'] = app_snapshot(child, after=False)
    child['signaled'] = True
    child['peer']['state']['signal'] = True
    if active:
        child['app']['records']['shutdown_active'].update(cancels=1, active=False, paused=False, reason='shutdown')
    child['hooks'].append('signal')
    return dict(signal='SIGTERM', owned_identity=True, watcher_installed=True, client_open=active)


def termination(child, context, deadline):
    require(child['signaled'] and not child['terminated'] and context['raw']['closing']['phase'] == 'post_signal', 'binding termination order')
    child['terminated'] = True
    child['released'].append(child['current'])
    child['hooks'].append('termination')
    return dict(phase='post_signal', outcome='eof', primary_response=False, frames_valid=True, trailing_bytes=0)


def process(child, context, deadline):
    require(child['signaled'] and not child['processed'], 'binding process order')
    require(child['selection'][-1] != 'shutdown_active' or child['terminated'], 'binding process before termination')
    child['processed'] = True
    child['hooks'].append('process')
    return dict(exit_code=0, reaped=True, forced=False, run_ok=True, deinit_ok=True, key_removed=True)


def post(child, context, deadline):
    require(child['processed'] and not child['posted'], 'binding post order')
    child['after'] = app_snapshot(child, after=True)
    child['posted'] = True
    child['hooks'].append('post')
    return copy.deepcopy(child['after'])


def receipt_counts(receipts):
    """Observed totals only; canonical counters are separate comparison operands."""
    return dict(heads=sum(item[2][3] for item in receipts), small=sum(item[6] for item in receipts),
                request_flow=sum(item[2][7] for item in receipts), connections=len(receipts),
                settings=sum(item[2][9] for item in receipts), informationals=sum(item[4] for item in receipts),
                incoming_resets=sum(count for item in receipts for code, count in item[3][11]),
                final_collections=sum(item[10] for item in receipts),
                receive_bytes=sum(item[3][1] for item in receipts), receive_calls=sum(item[3][0] for item in receipts))


def compare_child(child, actual, receipts):
    require(child['posted'] and child['processed'] and child['signaled'], 'binding hooks incomplete')
    require(actual['identity'] == child['identity'] and actual['selection'] == child['selection'], 'binding result child identity')
    require(actual['final_observations'] == child['before'], 'binding final client observations differ')
    require(actual['teardown']['post'] == child['after'], 'binding post client observations differ')
    require(actual['counts'] == receipt_counts(receipts), 'binding client counters differ')
    require(tuple((row[0][1], row[0][2]) for row in receipts) == tuple(child['released']), 'binding connection release missing')
    require(len(receipts) == len(actual['connections']), 'binding connection summaries missing')
    for receipt, summary in zip(receipts, actual['connections']):
        observed = (receipt[2][9], receipt[4], receipt[3][1], receipt[3][0], receipt[11], receipt[12])
        expected = tuple(summary[key] for key in ('settings', 'informationals', 'receive_bytes', 'receive_calls', 'connection_debt', 'stream_debt_total'))
        require(observed == expected, 'binding connection client facts differ')
    if 'disconnect' in child['selection']:
        compare_lifecycle(child, receipts)


def compare_lifecycle(child, receipts):
    rows = tuple(item for item in receipts if item[0][1] == 'disconnect')
    totals = child['evidence']['totals']
    require(len(rows) == 2 and totals['heads'] == sum(row[2][3] for row in rows), 'binding shared lifecycle heads differ')
    require(totals['data'] == sum(row[2][6] for row in rows) and totals['frames'] == sum(row[2][5] for row in rows), 'binding shared lifecycle DATA differs')
    require(totals['ends'] == sum(stream[9] for row in rows for stream in row[14] if stream[3]), 'binding shared lifecycle END differs')


def expected_identities(child):
    result = []
    for case in child['selection']:
        numbers = (1, 2) if case == 'disconnect' else (1,)
        result.extend((child['identity'][1], case, number) for number in numbers)
    return tuple(result)


def finish_binding(state: BindingState, result: dict) -> tuple[ConnectionReceipt, ...]:
    """Seal once after the successful canonical return and compare retained facts."""
    require(type(result) is dict and not state['finished'], 'binding successful return required')
    require(len(result['children']) == len(state['children']), 'binding children missing')
    expected = tuple(identity for child in state['children'] for identity in expected_identities(child))
    actual = tuple(identity for identity, observer in state['observers'])
    require(expected == actual and len(set(actual)) == len(actual), 'binding missing duplicate or wrong receipt')
    require(all(child['posted'] for child in state['children']), 'binding hooks incomplete')
    require(all(oracle.failure(observer) is None and observer['descriptor'][0] == identity for identity, observer in state['observers']), 'binding observer poisoned or wrong identity')
    # A rejected comparison cannot be retried against already consumed observations.
    state['finished'] = True
    receipts = tuple(oracle.seal(observer) for identity, observer in state['observers'])
    for child, actual_child in zip(state['children'], result['children']):
        local = tuple(row for row in receipts if row[0][0] == child['identity'][1])
        compare_child(child, actual_child, local)
    require(result['totals'] == receipt_counts(receipts), 'binding aggregate client counters differ')
    return receipts


def run_selection(selection, *, clock: Clock) -> tuple[dict, BindingState]:
    """Validate partial support pre-effect; coordinator.run alone dispatches."""
    selected = cases.select(selection)
    require(all(case in SUPPORTED for case in selected), 'unsupported binding selection')
    factory, state = new_provider(clock=clock)
    result = coordinator.run(selected, run_identity='binding_a', now=1, units_per_second=1000,
                             clock=clock, child_factory=factory)
    return result, state


if __name__ == '__main__':
    raise SystemExit('Import explicit canonical binding functions')
