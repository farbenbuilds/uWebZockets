"""Verify fix source scope and retained input identities."""
import importlib.util
import json
from pathlib import Path


def main():
    evidence = Path(__file__).resolve().parent
    root = evidence.parents[2]
    spec = importlib.util.spec_from_file_location('audit', root / 'evidence/core-peer/audit.py')
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    audit.immutable(root, evidence)
    accepted = json.loads(Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_capacity/manifest.json').read_text())['current_source_files']
    current = {p.name: audit.sha(p) for p in sorted(root.glob('*.py'))}
    if len(current) != 38 or set(current) != set(accepted):
        raise RuntimeError('source inventory differs')
    if {name for name in current if current[name] != accepted[name]} != {'test_producer_pressure.py'}:
        raise RuntimeError('source scope differs')
    reviewed = json.loads((evidence.parent / 'current-source.json').read_text())
    frozen = {p.name: audit.sha(p) for p in sorted((evidence.parent / 'current-source').glob('*.py'))}
    if reviewed != frozen or {name for name in current if current[name] != reviewed[name]} != {'test_producer_pressure.py'}:
        raise RuntimeError('reviewed source differs')
    history = json.loads((root / 'evidence/lifecycle-peer/prior-evidence-map.json').read_text())
    for name, digest in history.items():
        if audit.sha(root / name) != digest:
            raise RuntimeError('prior evidence differs: ' + name)
    audit.structure(root, evidence)
    audit.inert_helpers(evidence)
    audit.snapshot(root, evidence, 'current-source')
    print('accepted=38 reviewed=38 changed=test_producer_pressure.py prior_history=%d current=%s' %
          (len(history), current['test_producer_pressure.py']))


if __name__ == '__main__':
    main()
