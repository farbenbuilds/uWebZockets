"""Audit pinned inputs, accepted source and retained evidence."""
import importlib.util
import json
from pathlib import Path


def main():
    root = Path(__file__).resolve().parents[2]
    evidence = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location('audit', root / 'evidence/core-peer/audit.py')
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    audit.immutable(root, evidence)
    manifest = Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_capacity/manifest.json')
    accepted = json.loads(manifest.read_text())['current_source_files']
    current = {p.name: audit.sha(p) for p in sorted(root.glob('*.py'))}
    if len(current) != 38 or set(current) != set(accepted):
        raise RuntimeError('source inventory differs')
    if {name for name in current if current[name] != accepted[name]} != {'test_producer_pressure.py'}:
        raise RuntimeError('source ownership differs')
    if audit.sha(evidence / 'before-source.py') != accepted['test_producer_pressure.py']:
        raise RuntimeError('before source differs')
    history = json.loads((root / 'evidence/lifecycle-peer/prior-evidence-map.json').read_text())
    for name, digest in history.items():
        if audit.sha(root / name) != digest:
            raise RuntimeError('prior evidence differs: ' + name)
    audit.structure(root, evidence)
    audit.inert_helpers(evidence)
    audit.snapshot(root, evidence, 'current-source')
    (evidence / 'accepted-manifest.json').write_bytes(manifest.read_bytes())
    print('accepted=38 changed=test_producer_pressure.py prior_history=%d current=%s' %
          (len(history), current['test_producer_pressure.py']))


if __name__ == '__main__':
    main()
