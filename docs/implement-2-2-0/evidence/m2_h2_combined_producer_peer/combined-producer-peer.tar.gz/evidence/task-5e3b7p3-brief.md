# Task5e3b7p3: producer and pressure peer construction

Released after reviewed/pushed P2 and capacityfollowup at85e0ef5af56fce43821a50c374d958f02fe31c4c.
BASE is this commit. Exact38-module accepted source map is
docs/implement-2-2-0/evidence/m2_h2_combined_core_capacity/manifest.json, bound
by task-5e3b7p1b-root-commit-audit.json. Preserve this baseline.
Requirements: task-5e3b-peer-extraction-addendum.md P3 and binding phase2
composition contract. This is peer preparation for actual coordinator output
composition, not coordinator/default/all40/native/fullmilestone acceptance.

Own only combined-cases/test_producer_pressure.py, new evidence/producer-peer,
and task-5e3b7p3-report.md. No other modules/immutable core/model/fixture/helper/
codec/product/dependency/capacity/deadline edits; specific API gaps to Root before
shared edits. You are not alone; preserve others' changes and every raw/source
receipt. Root owns independent review/publication/commits/refs/pushes. No agents,
external model CLI, public edits, Git writes or native/runtime experiments.

Promote actual peer construction as
new_peer(case, *, app, prior, now, clock, final=False, fault=None,
slot=1, generation=17, echo_order='middle'). Return exact {connection,state};
connection exact protocol,send,receive,now,owned,tls,alpn with initiated pinned
protocol/queued startup SETTINGS+ACK/supplied synthetic owned/TLSv1.3/h2 facts.
Document family-specific bounded state fields, counters/cursors/grants/hashes.
No adapter dispatch/observe/finalization/client context in constructor or peer.
Existing check() stays an actual standalone driver with unchanged interface.

Use persistent child app exact records,heads,outputs,binding from reviewed core
peer; defaults at empty start, no observed binding until actual producer-reuse
B-binding, absent None. prior validates earned app facts, never seeds a selected
record/diagnostic. Both standalone check and later coordinator factory use this
single peer implementation; remove moved serialization bodies from the driver.
Keep distinct producer serialization/oracle ownership, no generic packet-loop
framework or callback registry, no opaque **kwargs/forwarding abstraction.

Resolve existing oracle coupling: move receive-time context['records'] checks
to driver-side wrappers around actual original adapter/receive calls, exactly
once and preserving results/errors. Peer must choose transitions solely from
serialized requests, credit/control and explicit finite state. Store independent
peer diagnostics/B-binding in app when those synthetic facts are actually
serialized; compare client-parsed facts against separate copies. Never assign
app outputs/binding from client observations to establish peer truth. Constructor
must not consume clock/app actions or return model-manufactured completion.

Preserve actual three-producer sequence, alternate slot/generation and sibling
echo order, every output/hash/credit/identity/deadline negative, canonical grants,
fair paired completion, binding generation/order and retained producer/file
observations without extra output GETs. Preserve inherited cumulative counters,
parser/connection/request/response ledgers, expiry and final collection behavior.
Hash outputs incrementally; bounded chunks/packets/state, no entire output or
request/frame/read histories. final permits existing finite final68 only after
case schedule, not completion. No immutable source/pin/threshold relaxation.

Add meaningful construction/no-dispatch/no-clock/no-seed/independence and
independent-peer-truth controls in owned driver. Actual parsed client changes
must not rewrite peer diagnostic truth. Preserve all existing positive/negative
checks; genuine new behavior failures before fix, accurate RED scope. This is
primarily extraction, so do not fabricate serialized RED if only missing API.
Retain baseline/source/raw/history and every intermediate outcome separately.

After final source edit run test_producer_pressure.py and test_imports.py normal/
-O with pinned Python -B -S. An unchanged covering suite only for demonstrated
cross-module dependency, not broad matrix repetition. All38 AST/oneguard/actual
inert empty+foreignargv imports; no classes/assert/customexceptions/hidden mutable
globals/deadcode/camelCase/ignored errors/nesting>3. Every authored helper guarded
and inert, including recorders. Snapshot accepted source/preserved prior hashes,
then current frozen source/input identities. Root audits independently.

Pinned Python /home/codespace/.python/current/bin/python3 SHA
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
Use existing exact PYTHONPATH: model /tmp/uwz-task5e1-contract-v3,core26
/tmp/uwz-task5e3a-snapshot-v9/source,codecs /tmp/uwz-h2-client-tooling/packages,
integration-client helper and combined-cases. Currentauthority119retained entries
=118physical rows/113resolved filepaths+ordered42codecaggregate SHA
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Keep original roworder/JSONencodings; current authority byte-identical original
coordinator-a unless Root explicitly changes it with provenance.

Before new codebase question/search/source read use graphify query first:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650
Provided paths located. Read AGENTS/CODING/role/narrow skills without unrelated
tooling/interviews. No native/build/server/socket/SSLContext/TLS-close/realclock/
process ownership/transfer/kernel/fault/cancel/schedule/interleaving/race/resource/
panic/crash/leak execution, oldruntime entrypoints, installs or network. Only
pinned in-memory codecs and supplied synthetic application/transport/process
facts; whole native/build/compliance/fullmilestone requirements remain later.

Report actual construction/driver/oracle APIs, bounded state and fact ownership,
files, baseline/newfailures/current exact commands/raw paths, immutable/source/
frozen maps, self-review/concerns and all remaining parent boundaries. Return
status/reportpath/one-line checks/concerns under15lines; no commits.
