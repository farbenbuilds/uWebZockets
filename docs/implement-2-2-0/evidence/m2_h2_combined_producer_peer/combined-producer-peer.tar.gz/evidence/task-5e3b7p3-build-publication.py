"""Package reviewed independent producer peer construction and fixes."""
import hashlib
import json
import runpy
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    provenance = Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_peer/combined-core-peer.tar.gz')
    if sha(provenance.read_bytes()) != 'dbcd7a01a56a3c80600aa39fa7b61dec00060976c14a82e2bd4a712a2520d25d':
        raise ValueError('Writer provenance differs')
    builder = plan / 'task-5e3b7p1-build-publication.py'
    with tarfile.open(provenance, 'r:gz') as previous:
        if previous.extractfile('evidence/' + builder.name).read() != builder.read_bytes():
            raise ValueError('Published writer source differs')
    writer = runpy.run_path(str(builder))['load_writer'](plan)
    baseline = Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_capacity/combined-core-capacity.tar.gz')
    if sha(baseline.read_bytes()) != '0f7073bed19ee514ee7c534ffe7be6bf8114d538ad0318149a331a2cadd8a845':
        raise ValueError('Baseline archive differs')
    members, latest_raw = {}, {}
    with tarfile.open(baseline, 'r:gz') as previous:
        inventory = json.loads(previous.extractfile('INVENTORY.json').read())
        for member in previous:
            if not member.isfile():
                raise ValueError('Nonregular baseline member')
            if member.name == 'INVENTORY.json':
                continue
            data = previous.extractfile(member).read()
            if inventory[member.name] != dict(size=len(data), sha256=sha(data)):
                raise ValueError('Baseline inventory differs')
            if member.name.startswith('reference/') or member.name.startswith('history/') and member.name.endswith('map.json'):
                writer['add'](members, member.name, data)
            if member.name.startswith('source/current/'):
                writer['add'](members, member.name.replace('source/current/', 'history/core-capacity-source/', 1), data)
            if member.name.startswith('raw/core-peer-capacity/'):
                latest_raw[member.name] = inventory[member.name]
    writer['add'](members, 'history/core-capacity-published-raw-map.json', (json.dumps(latest_raw, indent=2) + '\n').encode())
    audit = json.loads((plan / 'task-5e3b7p3-root-fix-1-audit.json').read_text())
    current = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if current != audit['current_source_sha256']:
        raise ValueError('Approved source differs')
    for path in sorted(source.glob('*.py')):
        writer['add'](members, 'source/current/' + path.name, path.read_bytes())
    raw = source / 'evidence/producer-peer'
    for path in sorted(raw.rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink in evidence')
        if path.is_file():
            writer['add'](members, 'raw/producer-peer/' + path.relative_to(raw).as_posix(), path.read_bytes())
    names = ('task-5e3b7p3-brief.md', 'task-5e3b7p3-report.md', 'task-5e3b7p3-review-brief.md',
             'task-5e3b7p3-review-report.md', 'task-5e3b7p3-review-source.diff',
             'task-5e3b7p3-root-final-audit.json', 'task-5e3b7p3-fix-1-brief.md',
             'task-5e3b7p3-fix-1-review-brief.md', 'task-5e3b7p3-fix-1-review-report.md',
             'task-5e3b7p3-fix-1-review.diff', 'task-5e3b7p3-root-fix-1-audit.json',
             'task-5e3b7p3-build-publication.py', 'task-5e3b-peer-extraction-addendum.md',
             'task-5e3b-coordinator-composition-plan-report.md')
    for name in names:
        writer['add'](members, 'evidence/' + name, (plan / name).read_bytes())
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_combined_producer_peer')
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'combined-producer-peer.tar.gz'
    inventory = writer['write_archive'](archive, members)
    manifest = dict(scope='Pure producer/pressure peer construction with independent diagnostic truth',
                    base_commit='85e0ef5af56fce43821a50c374d958f02fe31c4c', baseline_archive_sha256=sha(baseline.read_bytes()),
                    archive=archive.name, archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
                    safe_regular_text_members=len(members), inventory_entries=len(inventory), current_source_files=current,
                    changed_files=['test_producer_pressure.py'], added_files=[], unchanged_core_capacity_modules=37,
                    current_normal_optimized_commands=6, preceding_reviewed_normal_optimized_commands=6,
                    current_ast_inert_import_files=38, earlier_recorded_evidence_hashes_checked=4412,
                    latest_published_raw_files_checked={'lifecycle-peer': 308, 'core-peer-capacity': 83},
                    exhaustive_fresh_later_history_map_captured=False, retained_identity_entries=119,
                    physical_identity_rows=118, unique_file_paths=113, ordered_codec_files=42,
                    observed_case_J_C_R={'producer_reuse': [9,8,64], 'output_pressure_window': [8,7,33], 'output_pressure_ready': [6,5,33]},
                    producer_output_bytes=16777313, parser_buffer_limit=8201, generated_output_chunk_limit=8192,
                    pending_deferred_echo_packets_limit=12, output_read_limit=2049, total_read_limit=2400,
                    auxiliary_streams_finite_and_earned_before_mutation=True, receive_wrapper_once_result_error_identity=True,
                    independent_peer_diagnostics_binding_earned_at_serialization=True,
                    initial_red_scope='Missing constructor API, not serialized behavior', actual_behavioral_red_exits=[1,1],
                    source_review='Spec and quality approved after two review findings fixed', supplied_transport_lifecycle_facts=True,
                    coordinator_supported_nonempty_selections=[['ready_buffered']], explicit_empty_supported=True,
                    default_supported=False, combined_all40_executed=False, native_executed=False, milestone_complete=False,
                    remaining=['File/early peer construction', 'All37 ordinary coordinator composition',
                               'Disconnect/shutdown children and actual default/all40 aggregate',
                               'Broad review, runtime/native/full gates and production adoption'])
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
                  regular_members=len(members), inventory_entries=len(inventory), source_modules=len(current),
                  all_reopened_member_bytes_exact=True, native_executed=False)
    (plan / 'task-5e3b7p3-root-archive-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
