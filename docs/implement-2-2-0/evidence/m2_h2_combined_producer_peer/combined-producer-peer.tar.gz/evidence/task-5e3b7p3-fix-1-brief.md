# P3 round1 fixes

Read full task-5e3b7p3-review-report.md. Bothfindingsbinding; originalbrief,
onefileownership/source-only restrictions unchanged. Sameowner, Rootreadfixloop
before dispatch. Preserve reviewed4033Breport/current-source/6currentraws and
everyintermediateoutcome, appendfixreport and currentfrozen/sourceidentities.

Finding1: canonicalfiniteeligible auxiliaryWINDOW_UPDATE streamIDs andcapacity
must be validated BEFORE counters/setmutation. Actualbefore-fixpureRED: after
constructor/startup with0heads, unsolicitedoddIDs101..139 amounts65535 were
accepted/retained20. Rejectunearned/out-ofschedule updates withoutstatechange,
repeatto proveboundedness. Preserve all legitimatelyearnedgrant/stream/order
cases/alternates/finalcollection; deriveeligibility fromactualserializedstate
andimmutablecontract, not guessednewcap or relaxedfinaltotalassertion.

Finding2: wrapperexactonce/errorpreservationcontract has no exception forbad
client-body observation. Capture any requiredpre-observationfact, calloriginal
receiveexactlyonce; originalexceptionpropagatesunchanged. Onlyafter original
returns mayrejectbadobservation; validpathreturnsexactsameobject/result. Pure
before-fixcallcountRED and afterfixcallcount/resultidentity/erroridentity checks,
includinginvalidpre-observation plusoriginalerror. Keep peer callbacks freeof
clientcontext; no genericregistry/unusedwrapper/framework. A helperaddingthis
actualinvariant is justified ifneeded fordirecttests.

Afterlastsourceedit run covering producer/import/file-earlyconsumer normal/-O
(sixactualchecks), no broaderprecedingmatrix. Append actualcommands/rawpaths/
RED/GREEN/snapshots/identities/selfreview. Report before/fix/current counts
honestly, no freshcompletehistorycaptureclaim whenonlyoldmap+publishedarchives
authority. No othermodule/immutable/public/Git/native edits or agents/external
modelCLI. Rootaudits, then same-reviewer scopedfixgate; default/all40/native/
adoption/fullmilestones remainopen.
