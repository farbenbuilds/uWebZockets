# P3 round1 scoped review

Originalfindings task-5e3b7p3-review-report.md andfixrequirements fix-1-brief.md.
Appendedreport task-5e3b7p3-report.md. Reviewonlytwofindings and8652Bfixdiff
task-5e3b7p3-fix-1-review.diff SHA256
a7647cb5e6769c56e6d2df13621ce070f831f3df655804a3ac111de6008edfe3.
Fixbase reviewedproducer1c896b0b/current-source; fixed7e7e6c08/fix1-audit/current-
source. Exact38maps in task-5e3b7p3-root-fix-1-audit.json; no taskcommit.

Finding1 unsolicited65535WINDOW_UPDATE arbitraryIDs retainedunboundedauxset at
0heads; mustvalidatefiniteearnedeligibility/capacity beforecounter/setmutation.
Finding2 bodyobservationguard skipsoriginalreceive/masksits error; capturepre-
observation, invokeonce/originalerrorpriority, thenrequireorreturnexactresult.

Rootread7041Bappendedreport/original4033Bprefixunchanged.38live/fixfrozen/map
equal/37reviewedmodulesunchanged; old38frozen/sixrawstdoutidentities unchanged.
6actualcurrentnormalO0-emptyerr and4412oldhashes verified. TwoactualRED1s before
fix, finalGREEN0s preserved:20unsolicitedIDs repeatedlyrejectwithoutstatechange;
wrappercallcount/resultidentity/erroridentity includingcallbackclearsbadbody and
originalerrorwhilebadobservation. Intermediaterunbeforeregressionstrengthening
remainsdistinctfromfinal6. No freshlaterwholehistorymapclaim.

Verdicteachfinding ADDRESSED/NOTADDRESSED, newbreakageinfixdiffonly; no broad
repeatunchangedsource/passedsuites. Outsideobservationsseparate/notloopextension.
Originalread-only/noagents/Git/services/native/fullmatrix/graphifyprefix rules
binding. ReturnfullSPEC/QUALITY/scopedfindings/boundaries; Root savesverdict.
