# Producer peer construction source review

Review task-5e3b7p3-brief.md and peer-extraction-addendum P3. Claims
task-5e3b7p3-report.md; Rootfinalaudit task-5e3b7p3-root-final-audit.json binds
currentfrozen/source/raw and full task-5e3b7p3-review-source.diff. BASE pushed
85e0ef5af56fce43821a50c374d958f02fe31c4c; no taskcommit. Ignoredpreparation
source is archived afterreview; productadoption/fullmilestones stillrequired.

Bindingrequirements:
- Ownonlytest_producer_pressure.py/newraw/report. No othermodule/immutable/
  product/pin/capacity/deadline edit without Root'sspecificrelease.
- Actual new_peer(case,*,app,prior,now,clock,final=False,fault=None,slot=1,
  generation=17,echo_order='middle') construction separatefromdrivercheck().
  Exact {connection,state}; sevenconnectionkeys/pinnedinitiatedprotocol/queued
  initialSETTINGS+ACK. No clock/client/adapterdispatch/app action inconstruction.
- Persistentapp records,heads,outputs,binding; absentobservedbindingNone; prior
  validates earnedstate, no undispatchedseed/modelmanufacturedcompletion.
- "Store independent peer diagnostics/B-binding in app when those synthetic
  facts are actually serialized; compare client-parsed facts against separate
  copies. Never assign app outputs/binding from client observations to establish
  peer truth."
- Move contextrecords checks into driver wrappers thatinvokeoriginalonce and
  preserve results/errors. Peer decisions deriveonlyactualserialized progress/
  grants/finite state, notclientcontext.
- Preserve3producersequence/alternateslotgen/echoordering/allhash-credit-identity-
  deadline controls, canonicalgrants/fairpairedcompletion/binding/retainedfacts.
  Boundedhash/cursor/packetstorage, no wholeoutput/request/frame/readhistories;
  finalpermitsfinal68onlyafterfinitecase, notcompletion.

Namedrisks: exactfactory/priorapp/no-dispatch ownership; independentpeertruth/
diagnostic timing and alias separation; callback wrapper once/error propagation;
canonicalgrants/fairpair/binding generations/order; sharedparser/debt/counters/
deadlines and pre-mutationbounds; originalnegative/alternates retained; existing
file/early consumer check() compatibility (onefocusedread/check if needed).

Read full diffonce/testsfirst/context10. No separate changed-file reread unless
neededhunkcutoff; identifyit. Outside-diffread onlyconcretenamedrisk/onefocused
check. No broadcrawl/Git/passedsuite repeat. Assess report/audit asclaims.
ApplyAGENTS/CODING/code-review-and-quality andexplicitRoot-requested
thermo-nuclearstructurallens underprojectoverrides. Do notmechanicallysplit.

Read-only/noagents/externalCLI/Git/file/servicewrites/native/build/server/socket/
SSLContext/TLS-close/realclock/processownership/transfer/kernel/fault/cancel/
schedule/race/panic/leak execution. Originalgraphifyprefixbefore newquestion/
search; providedpaths located. Onlyfocusedpure sensitivity for unansweredrisk.
ReturnfullSPEC/QUALITY/actionablefileline/scenariofindings, strengths and
cannot-verifyboundaries. Root savesfullverdict; no source fixes yourself.
