"""Audit the completion snapshot without altering earlier receipts."""
import ast
import importlib.util
import json
from pathlib import Path


def main():
    evidence = Path(__file__).resolve().parent
    root = evidence.parents[1]
    spec = importlib.util.spec_from_file_location('prior_audit', root / 'evidence/core-peer/audit.py')
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    audit.immutable(root, evidence)
    baseline = json.loads((evidence / 'baseline-source-hashes.json').read_text())
    current = {p.name: audit.sha(p) for p in sorted(root.glob('*.py'))}
    if {k for k in baseline if current.get(k) != baseline[k]} != {'coordinator.py', 'test_coordinator.py', 'test_imports.py'}:
        raise RuntimeError('changed source scope differs')
    if set(current) - set(baseline) != {'test_coordinator_composition.py'} or len(current) != 39:
        raise RuntimeError('source inventory differs')
    for name, digest in baseline.items():
        if audit.sha(evidence / 'before-source' / name) != digest:
            raise RuntimeError('baseline source differs')
    previous = json.loads((evidence / 'current2-source.json').read_text())
    for name, digest in previous.items():
        if audit.sha(evidence / 'current2-source' / name) != digest:
            raise RuntimeError('previous frozen source differs')
    history = json.loads((evidence / 'prior-evidence-hashes.json').read_text())
    for name, digest in history.items():
        if audit.sha(root / name) != digest:
            raise RuntimeError('prior evidence differs: ' + name)
    depths = {}
    for path in sorted(root.glob('*.py')):
        tree = ast.parse(path.read_text())
        if any(isinstance(node, (ast.ClassDef, ast.Assert, ast.Global)) for node in ast.walk(tree)):
            raise RuntimeError('invalid AST in ' + path.name)
        depths[path.name] = audit.nesting(tree)
        if depths[path.name] > 3:
            raise RuntimeError('control nesting in ' + path.name)
    (evidence / 'completion-structure.json').write_text(json.dumps(depths, indent=2) + '\n')
    audit.inert_helpers(evidence)
    audit.snapshot(root, evidence, 'completion-source')
    print('modules=39 max_nesting=%d prior_evidence=%d prior_current2=preserved' % (max(depths.values()), len(history)))


if __name__ == '__main__':
    main()
