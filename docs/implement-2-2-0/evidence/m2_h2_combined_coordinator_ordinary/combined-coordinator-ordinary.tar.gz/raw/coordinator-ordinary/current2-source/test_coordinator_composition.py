"""Actual ordered coordinator dispatch against bounded serialized peers."""
import json
from unittest import mock
import adapter
import coordinator
import catalogue
import model
import test_core_peer
import test_lifecycle
import test_producer_pressure
import test_file_early


def require(value, message):
    if not value:
        raise ValueError(message)


def run_core(selection, control=None):
    app = test_core_peer.new_app()
    state = dict(prior=[], connections=[], closes=0, clock=2)

    def clock():
        return state['clock']

    def connect(case, index, case_deadline, whole_deadline):
        require(index == 1 and case == selection[len(state['connections'])], 'connect order differs')
        args = dict(app=app, prior=tuple(state['prior']), now=2, clock=clock,
                    final=len(state['connections']) == len(selection) - 1)
        if case == 'reuse':
            peer = test_lifecycle.new_peer(case, index, case_evidence=test_lifecycle.new_case_evidence(), **args)
        elif case in ('producer_reuse', 'output_pressure_window', 'output_pressure_ready'):
            peer = test_producer_pressure.new_peer(case, **args)
        elif case in ('stream_file', 'early_final_order'):
            peer = test_file_early.new_peer(case, **args)
        else:
            peer = test_core_peer.new_peer(case, **args)
        state['connections'].append(peer['state'])
        return peer['connection']

    def close(context, deadline):
        state['closes'] += 1
        if control is not None:
            control('close', state, context)
        if state['closes'] < len(selection):
            state['prior'].append(selection[state['closes'] - 1])
        return dict(method='close', client_closed=True, close='normal')

    def signal(context, deadline):
        return dict(signal='SIGTERM', owned_identity=True, watcher_installed=True, client_open=False)

    def process(context, deadline):
        return dict(exit_code=0, reaped=True, forced=False, run_ok=True, deinit_ok=True, key_removed=True)

    def post(context, deadline):
        return dict(records=json.loads(json.dumps(app['records'])), metrics=test_core_peer.metrics(app),
                    outputs=json.loads(json.dumps(app['outputs'])),
                    binding=model.default_binding() if app['binding'] is None else dict(app['binding']))

    def factory(identity, index, selected, ready, whole):
        require(selected == selection, 'factory selection differs')
        descriptor = dict(identity=(identity, index), ready=True, fresh_application=True, connect=connect,
                          close=close, signal=signal, process=process, post=post)
        if control is not None:
            control('factory', state, descriptor)
        return descriptor

    original_collection = adapter.final_collection
    collections = []

    def collect(context, receive):
        require(context['selected_before'] == selection[:-1] and context['completed'] and
                context['stage']['case'] == selection[-1] and context['stage']['final_registered'] == 0,
                'final entry did not inherit actual case state')
        collections.append(context['now'])
        return original_collection(context, receive)

    with mock.patch.object(adapter, 'final_collection', collect):
        result = coordinator.run(selection, run_identity='composition', now=1, units_per_second=1,
                                 clock=clock, child_factory=factory)
    require(len(collections) == 1, 'final collection count differs')
    require(state['closes'] == len(selection), 'close count differs')
    require(result['totals']['final_collections'] == 1 and len(result['children'][0]['connections']) == len(selection),
            'observed collection or connection count differs')
    summaries = result['children'][0]['connections']
    fields = {'case', 'case_connection', 'ordinal', 'case_deadline', 'settings', 'informationals',
              'receive_bytes', 'receive_calls', 'connection_debt', 'stream_debt_total', 'release'}
    for index, summary in enumerate(summaries):
        require(set(summary) == fields and summary['case'] == selection[index] and
                summary['case_connection'] == 1 and summary['ordinal'] == index + 1 and
                summary['release'] == dict(method='close', client_closed=True, close='normal'),
                'connection summary differs')
    if selection in (('reuse', 'ready_buffered'), ('ready_buffered', 'reuse')):
        require(result['totals']['heads'] == 462 and result['totals']['small'] == 462 and
                result['totals']['request_flow'] == 545, 'reuse totals differ')
    if selection == ('producer_reuse', 'ready_buffered'):
        require(result['totals']['heads'] == 82 and result['totals']['small'] == 81, 'producer totals differ')
    if set(selection) in ({'ready_buffered', 'large_declared'}, {'ready_buffered', 'large_undeclared'}):
        require(result['totals']['heads'] == 78 and result['totals']['small'] == 78 and
                result['totals']['request_flow'] == 100000257, 'observed totals differ')
    return result


def check_selection_boundary():
    ordinary = tuple(case for case in catalogue.CASES if case not in ('disconnect', 'shutdown_idle', 'shutdown_active'))
    require(len(ordinary) == 37, 'ordinary inventory differs')
    selections = [(case,) for case in ordinary] + [ordinary, tuple(reversed(ordinary))]
    for selection in selections:
        calls = []

        def factory(*args):
            calls.append(args)
            raise RuntimeError('factory boundary')

        try:
            coordinator.run(selection, run_identity='a', now=1, units_per_second=1,
                            clock=lambda: 2, child_factory=factory)
        except RuntimeError as error:
            require(str(error) == 'factory boundary' and len(calls) == 1 and calls[0][2] == selection,
                    'ordinary selection rejected before factory')
        else:
            raise ValueError('factory boundary silently succeeded')


def check_failed_close():
    original = RuntimeError('intermediate close failure')
    seen = []

    def control(phase, state, value):
        if phase == 'close':
            seen.append(len(state['connections']))
            raise original

    try:
        run_core(('ready_buffered', 'large_declared'), control)
    except RuntimeError as error:
        require(error is original and seen == [1], 'failure advanced to next connection')
    else:
        raise ValueError('failed close silently succeeded')


def check_sealed_callbacks_and_outputs():
    held = {}

    def control(phase, state, value):
        if phase == 'factory':
            held['descriptor'] = value
        elif state['closes'] == 1:
            held['descriptor']['connect'] = None
            held['descriptor']['signal'] = None
            value['output_observations']['producer_reuse']['checks'] = 999
            value['stage']['case_state']['heads'] = 999

    result = run_core(('producer_reuse', 'ready_buffered'), control)
    child = result['children'][0]
    require(child['counts']['heads'] == 82 and
            child['final_observations']['outputs']['producer_reuse']['checks'] != 999,
            'intermediate callback changed sealed facts')


def check_missing_output_and_expiry():
    original = adapter.run_case
    calls = []

    def remove_output(context, receive, **kwargs):
        result = original(context, receive, **kwargs)
        calls.append(context['stage']['case'])
        context['output_observations'].pop('producer_reuse')
        return result

    with mock.patch.object(adapter, 'run_case', remove_output):
        try:
            run_core(('producer_reuse', 'ready_buffered'))
        except ValueError as error:
            require('retained output observations differ' in str(error) and calls == ['producer_reuse'],
                    'missing output advanced dispatch')
        else:
            raise ValueError('missing output silently succeeded')

    seen = []

    def expire(phase, state, context):
        if phase == 'close':
            seen.append(len(state['connections']))
            state['clock'] = context['stage']['case_deadline']

    try:
        run_core(('ready_buffered', 'large_declared'), expire)
    except ValueError as error:
        require(seen == [1] and 'expired' in str(error), 'expired close advanced dispatch')
    else:
        raise ValueError('expired close silently succeeded')


if __name__ == '__main__':
    check_selection_boundary()
    check_failed_close()
    check_sealed_callbacks_and_outputs()
    check_missing_output_and_expiry()
    run_core(('ready_buffered', 'large_declared'))
    run_core(('large_declared', 'ready_buffered'))
    run_core(('ready_buffered', 'large_undeclared'))
    run_core(('reuse', 'ready_buffered'))
    run_core(('ready_buffered', 'reuse'))
    for case in ('producer_reuse', 'output_pressure_window', 'output_pressure_ready', 'stream_file', 'early_final_order'):
        run_core((case, 'ready_buffered'))
    print('ordered core and lifecycle compositions passed')
