"""Audit frozen P5 inputs, source scope, and retained evidence."""
import importlib.util
import json
from pathlib import Path


def main():
    evidence = Path(__file__).resolve().parent
    root = evidence.parents[1]
    spec = importlib.util.spec_from_file_location('prior_audit', root / 'evidence/core-peer/audit.py')
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    audit.immutable(root, evidence)
    before = json.loads((evidence / 'baseline-source-hashes.json').read_text())
    current = {p.name: audit.sha(p) for p in sorted(root.glob('*.py'))}
    if {k for k in before if current.get(k) != before[k]} != {'coordinator.py', 'test_coordinator.py', 'test_imports.py'}:
        raise RuntimeError('changed source scope differs')
    if set(current) - set(before) != {'test_coordinator_composition.py'} or len(current) != 39:
        raise RuntimeError('new source scope differs')
    for name, digest in before.items():
        if audit.sha(evidence / 'before-source' / name) != digest:
            raise RuntimeError('before source differs: ' + name)
    history = json.loads((evidence / 'prior-evidence-hashes.json').read_text())
    for name, digest in history.items():
        if audit.sha(root / name) != digest:
            raise RuntimeError('prior evidence differs: ' + name)
    audit.structure(root, evidence)
    audit.inert_helpers(evidence)
    audit.snapshot(root, evidence, 'current-source')
    print('accepted=38 current=39 scoped=3 added=1 prior_evidence=%d' % len(history))


if __name__ == '__main__':
    main()
