"""Check fix scope against the reviewed completion snapshot."""
import importlib.util
import json
from pathlib import Path


def main():
    evidence = Path(__file__).resolve().parent
    root = evidence.parents[1]
    spec = importlib.util.spec_from_file_location('prior_audit', root / 'evidence/core-peer/audit.py')
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    previous = json.loads((evidence / 'completion-source.json').read_text())
    current = json.loads((evidence / 'fix1-current-source.json').read_text())
    if set(previous) != set(current) or {name for name in previous if previous[name] != current[name]} != {
            'coordinator.py', 'test_coordinator_composition.py'}:
        raise RuntimeError('fix source scope differs')
    for name in current:
        if audit.sha(root / name) != current[name]:
            raise RuntimeError('current source differs')
    audit.inert_helpers(evidence)
    print('reviewed completion modules=39; changed coordinator.py and test_coordinator_composition.py; other 37 unchanged')


if __name__ == '__main__':
    main()
