"""Package actual ordinary coordinator composition and its deadline regression."""
import hashlib
import json
import runpy
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    provenance = Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_peer/combined-core-peer.tar.gz')
    if sha(provenance.read_bytes()) != 'dbcd7a01a56a3c80600aa39fa7b61dec00060976c14a82e2bd4a712a2520d25d':
        raise ValueError('Writer provenance differs')
    builder = plan / 'task-5e3b7p1-build-publication.py'
    with tarfile.open(provenance, 'r:gz') as previous:
        if previous.extractfile('evidence/' + builder.name).read() != builder.read_bytes():
            raise ValueError('Published writer source differs')
    writer = runpy.run_path(str(builder))['load_writer'](plan)
    baseline = Path('docs/implement-2-2-0/evidence/m2_h2_combined_file_peer/combined-file-peer.tar.gz')
    if sha(baseline.read_bytes()) != '935b5fb7011970d5ddb39fd6d8009a4917cdf82ddeca7880bd7c6e84fa533bb7':
        raise ValueError('Baseline archive differs')
    members = {}
    with tarfile.open(baseline, 'r:gz') as previous:
        inventory = json.loads(previous.extractfile('INVENTORY.json').read())
        for member in previous:
            if not member.isfile():
                raise ValueError('Nonregular baseline member')
            if member.name == 'INVENTORY.json':
                continue
            data = previous.extractfile(member).read()
            if inventory[member.name] != dict(size=len(data), sha256=sha(data)):
                raise ValueError('Baseline inventory differs')
            if member.name.startswith('reference/'):
                writer['add'](members, member.name, data)
            if member.name.startswith('source/current/'):
                writer['add'](members, member.name.replace('source/current/', 'history/file-peer-source/', 1), data)
    audit = json.loads((plan / 'task-5e3b7p5-root-fix-1-audit.json').read_text())
    current = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if current != audit['current_source_sha256']:
        raise ValueError('Approved source differs')
    for path in sorted(source.glob('*.py')):
        writer['add'](members, 'source/current/' + path.name, path.read_bytes())
    raw = source / 'evidence/coordinator-ordinary'
    for path in sorted(raw.rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink in evidence')
        if path.is_file():
            writer['add'](members, 'raw/coordinator-ordinary/' + path.relative_to(raw).as_posix(), path.read_bytes())
    names = ('task-5e3b7p5-brief.md', 'task-5e3b7p5-report.md', 'task-5e3b7p5-review-brief.md',
             'task-5e3b7p5-review-report.md', 'task-5e3b7p5-review-source.diff',
             'task-5e3b7p5-proof-completion-brief.md', 'task-5e3b7p5-root-candidate-audit.json',
             'task-5e3b7p5-root-final-audit.json', 'task-5e3b7p5-fix-1-brief.md',
             'task-5e3b7p5-fix-1-review-brief.md', 'task-5e3b7p5-fix-1-review-report.md',
             'task-5e3b7p5-fix-1-review.diff', 'task-5e3b7p5-root-fix-1-audit.json',
             'task-5e3b7p5-build-publication.py', 'task-5e3b-peer-extraction-addendum.md',
             'task-5e3b-coordinator-composition-plan-report.md', 'task-5e3b-aggregate-acceptance-notes.md')
    for name in names:
        writer['add'](members, 'evidence/' + name, (plan / name).read_bytes())
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_combined_coordinator_ordinary')
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'combined-coordinator-ordinary.tar.gz'
    inventory = writer['write_archive'](archive, members)
    examples = [['ready_buffered','large_declared'], ['large_declared','ready_buffered'],
                ['ready_buffered','large_undeclared'], ['reuse','ready_buffered'], ['ready_buffered','reuse'],
                ['producer_reuse','ready_buffered'], ['output_pressure_window','ready_buffered'],
                ['output_pressure_ready','ready_buffered'], ['stream_file','ready_buffered'],
                ['early_final_order','ready_buffered']]
    summary_keys = ['case','case_connection','ordinal','case_deadline','settings','informationals',
                    'receive_bytes','receive_calls','connection_debt','stream_debt_total','release']
    manifest = dict(scope='Actual caller-ordered ordinary coordinator composition using bounded synthetic peers',
                    base_commit='41fa29645882ac3faf67396e976cca60504e2a48', baseline_archive_sha256=sha(baseline.read_bytes()),
                    archive=archive.name, archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
                    safe_regular_text_members=len(members), inventory_entries=len(inventory), current_source_files=current,
                    changed_files=['coordinator.py','test_coordinator.py','test_imports.py'],
                    added_files=['test_coordinator_composition.py'], unchanged_file_peer_modules=35,
                    current_normal_optimized_commands=6, preceding_completion_commands=6, preceding_candidate_final2_commands=6,
                    current_ast_inert_import_files=39, fresh_pre_edit_evidence_hashes_checked=5111,
                    retained_identity_entries=119, physical_identity_rows=118, unique_file_paths=113, ordered_codec_files=42,
                    supported_ordinary_case_count=37, unsupported_cases=['disconnect','shutdown_idle','shutdown_active'],
                    explicit_empty_supported=True, default_supported=False, actual_all37_execution_verified=False,
                    actual_representative_selections=examples, connection_summary_keys=summary_keys,
                    observed_examples={'ready_large_either_order': {'heads':78,'small':78,'request_flow':100000257},
                                       'reuse_ready': {'heads':462,'small':462,'request_flow':545},
                                       'producer_reuse_ready': {'heads':82,'small':81}},
                    one_final_collection_per_nonempty_child=True, intermediate_positive_debt_preserved=True,
                    retained_output_binding_and_private_returned_facts=True, original_private_close_time_bounds=True,
                    actual_deadline_mutation_red_exit=1, actual_deadline_red_has_frozen_source=True,
                    initial_red_scope='Unsupported selection before factory/wire', attempt1_intermediate_source_frozen=False,
                    intermediate_structure_json_preserved=False,
                    source_review='Spec and quality approved after intermediate-close deadline fix',
                    supplied_transport_lifecycle_facts=True, combined_all40_executed=False, native_executed=False,
                    milestone_complete=False,
                    remaining=['Disconnect replacement composition', 'Idle/active shutdown child composition',
                               'Actual default/all40 aggregate and broad combined-client review',
                               'Runtime/native/full gates and production adoption'])
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
                  regular_members=len(members), inventory_entries=len(inventory), source_modules=len(current),
                  all_reopened_member_bytes_exact=True, native_executed=False)
    (plan / 'task-5e3b7p5-root-archive-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
