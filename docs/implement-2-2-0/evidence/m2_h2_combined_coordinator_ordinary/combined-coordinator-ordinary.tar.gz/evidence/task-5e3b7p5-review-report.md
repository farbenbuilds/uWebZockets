SPEC REQUEST CHANGES
QUALITY no additional actionable structural findings
Independent /root/review_h2_ordinary_coordinator,Astra/high,read-only.

P2 — Preserveprivate deadline state across intermediateclose.
coordinator.py:180 uses adapter.tick(context) after context exposedtoclose.
Hookcanchange stage.case_deadline/context.now/context.clock; originaldeadline/
monotonic contract notenforced. Actualpure ready->large run firstclose widens
case towhole andadvancesclocktooriginaldeadline32; runreturns2connections,
deadlines[32,212], shouldreject before2. Captureprivatepreclose timestamp and
validate originalcallerclock againstit/local min(case_deadline,whole), carry
validatedtimeforward. Regressionmutation+equalityexpiry required.

Remainderfollowsphase2A: canonicaldispatch/freshstate/actualcheckedcounts/
positivecloseddebt/copiedretainedoutputs-binding/frozensummaries/descriptorcopy/
onefinal/privatefinalobservations.37ordinaryselectionexpansionauthorized;
default/unsupportedlifecycle stillreject. No unjustifiedabstraction/file-size/
missedsimplification issue; canonicaldispatch/validators/count/finalization reused.

Fullbounddiff/completionmapping/Rootaudit/sixcompletionoutputs inspected0-emptyerr.
Onlyfocusedpuresensitivityran, no suitesrepeated. Representativeactuals/static
37support noteverysubset/default/all40/disco/shutdown/native/project gates.
Missingattempt1source/oldstructure provenancegaps explicit. No source writes.
