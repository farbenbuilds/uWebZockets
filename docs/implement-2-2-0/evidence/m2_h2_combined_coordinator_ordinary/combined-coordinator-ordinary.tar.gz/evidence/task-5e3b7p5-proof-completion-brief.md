# P5 proof completion before initial independent review

Same original task/ownership/owner, not a new narrower task. Root read the
non-DONE handling reference and your reported limitations. Concrete gaps below
concern explicit P5 invariants and must be resolved before source review. This
does not require every permutation or a broad old matrix.

Preserve original report prefix, final2 six results/current2-source, prior5111
map and all receipts. Root candidate audit binds them. Append completion report;
new proofs/structure/snapshots use DISTINCT names. Do not overwrite any earlier
structure.json/snapshot/result. Qualify missing attempt1 source/overwritten old
structure honestly; do not reconstruct and label it original.

Add concrete actual-coordinator controls/assertions for:

1. Intermediate raw/request/response-credit/protocol independence between fresh
   ordinary contexts, and same parser/ledgers retained through final68 on the
   final connection. Observe real original calls/contexts, not a fake run_case.
   Assert actual nonzero permitted debt survives intermediate close and final
   entry where applicable; no zero-debt quiescence requirement.
2. Returned connection summary exact schema, case-local index1 vs childordinal,
   actual local receive bytes/reads and debt at release; original per-case/whole
   deadlines. Capture values from real contexts before exposed close hooks can
   mutate them, then compare independent frozen results. Cover both upload orders
   and selected-output->ordinary final, without retaining large bodies/history.
3. Specific retained fact loss: producer/file selected output removal and absent
   required producer-reuse B binding must reject rather than fabricate defaults.
   Existing output-removal proof may already cover one; add only missing distinct
   boundary. Preserve successful retained binding across fresh contexts and
   copied-result/privacy checks.
4. Actual inter-case timestamp propagation: a receiver advances context time,
   then a later clock rollback rejects before later case dispatch. A successful
   advanced clock gives the next case its proper deadline and final grace within
   unchanged whole time. Keep equality expiry at intermediate close; no fresh
   whole/final deadline or discarded checked clock. Existing single-ready
   rollback alone is insufficient for this new handoff.

Map each required proof to a named check and raw output in the report. If a
case is already explicitly covered, cite it rather than duplicate it. Any actual
implementation defect exposed gets retained RED before source fix; passing new
assertions are current verification, not fabricated historical REDs. Original
error/callback semantics and all37 support remain. No other modules/core changes.

After last test/source edit run the same six covering composition/coordinator/
imports normal/-O checks, exact commands/raw/current frozen/input/prior map audit.
No unrelated family/native/build/socket/process/race/fault experiments or agents.
Append actual limitations and concise final contract; Root then dispatches fresh
source reviewer. No publication/Git changes until all current P5 requirements are
verified; default/all40/native/adoption/fullmilestones remain later.
