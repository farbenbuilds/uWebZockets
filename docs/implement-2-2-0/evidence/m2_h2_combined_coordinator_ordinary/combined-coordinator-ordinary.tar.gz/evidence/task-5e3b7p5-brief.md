# Ordinary HTTP/2 coordinator composition

Released after reviewed/pushed P4 at41fa29645882ac3faf67396e976cca60504e2a48.
BASE is this commit. Exact38-module source authority is
docs/implement-2-2-0/evidence/m2_h2_combined_file_peer/manifest.json, bound by
task-5e3b7p4-root-commit-audit.json. Preserve this baseline. This implements
phase2A of task-5e3b-coordinator-composition-plan-report.md. Read that exact
contract first (ordinary scope), then task-5e3b-peer-extraction-addendum.md P5.
These bind all values/interfaces below. This is actual coordinator composition,
not a union of standalone checks. The full original default/all40/native/
adoption/milestone objective remains mandatory after this slice.

## Ownership and selection

Own combined-cases/coordinator.py, test_coordinator.py, new
test_coordinator_composition.py and minimal test_imports.py inventory; new
evidence/coordinator-ordinary and task-5e3b7p5-report.md. No other module/core/
model/fixture/helper/codec/product/dependency/capacity/deadline edits. A concrete
shared API gap or additional internal module requires Root release before edit.
You are not alone; preserve others and all source/raw/history. No agents,
external model CLI, public edits, Git writes or native operations. Root reviews,
publishes, commits and immediately pushes each checkpoint.

Support ANY valid caller-ordered subset of all37 ordinary cases, including
reuse, producer/pressure, file and early-final. Exclude only disconnect,
shutdown_idle and shutdown_active in this slice. Keep explicit empty no-effect
behavior. Omitted/default catalogue.CASES still rejects before clock/factory
because it contains the three unsupported lifecycle cases; explicit None stays
malformed. Do not change the default to cases.IMPLEMENTED (different order).
Static malformed/unknown/duplicate/order/type/overflow checks remain before
effects. No handler injection or selected-family-only production dispatcher.

Update existing tests that deliberately rejected now-supported valid ordinary
selections: test their acceptance with the appropriate factory boundary; retain
zero-effect rejection for genuinely malformed/unsupported input. This changes
the intended support contract, not a weakened check. All old ready lifecycle,
67 typed controls, clock handoff, callback error/privacy and empty proofs remain.

## Actual lifecycle and clocks

Reuse coordinator read_time, validate_connection, copy_facts, finish_child,
COUNT_FIELDS and snapshot_counts, generalizing only as the composition contract
requires. Ordinary child descriptor remains exact identity/ready/fresh_application/
connect/close/signal/process/post. Validate callbacks before connect, then copy
descriptor so factory-map mutation cannot rewire hooks. Existing exact run-ID
grammar, seven connection facts and strict close/signal/process/post schemas
remain. Logical ownership/TLS/process facts are synthetic, not native identity.

One child/app for the ordinary selection. Connect each case with
connect(case,1,case_deadline,whole_deadline). Connection evidence ordinals increase
1..actualconnections; the connect index is case-local1 each time. No global
Python-ID/FD/address uniqueness set. Canonical fresh adapter state and startup
must be used, with queued peer SETTINGS/ACK consumed through real observe.

Invoke actual adapter.run_case exactly once per selected case. None retains
input context/receiver; reuse's returned context is retained without replacing
its receiver. No family check() may substitute for coordinator dispatch. Commit
completed IDs only after actual success and intermediate release; never seed
undispatched or prior-case completion from model expectations.

For every nonterminal case: actual completion/quiescence/count checks, copy
earned output/binding/counts, set observation boundary, call normal close with
min(original case,whole), validate/copy result and recheck original deadline,
then dispatch next case. Quiescent means no partial raw frame, active response/
stage records or pending SETTINGS; streams satisfy existing terminal policy.
Positive late request debt is permitted and retained, not fabricated refunded.
No intermediate final collection, health/output GET, signal/deinit or new grace.

Only the final ordinary case appends canonical final68 and complete finish_child
close->signal->process->post. Exactly one final collection for a nonempty child.
No shutdown_idle case is earned by ordinary teardown. Original case timing starts
before connect; startup/actions/finalization/close all consume it. One whole900,
one child ready15, per-case catalogue timeout, one clipped final grace15; checked
u64 units and exact-int/nonbool time. Carry actual context/callback timestamps
monotonically to the next handoff. No fresh final/read/debt/deadline reset.

Failure stops before next connection/dispatch and returns no successful result.
Preserve callback exception identity and already-earned bounded caller-observable
facts. Do not invent a generic cleanup/result/exception/progress framework.

## Counts, retained facts and results

Snapshot actual cumulative case counts once, checked-add case->child->run; include
final registrations exactly once. Ordinary connections share no request/raw/
response-credit state. Freeze counts before exposed-context close/teardown hooks
can mutate them. Settings/informationals are connection-local. Preserve existing
request DATA, reset, bytes/read accounting; do not derive observed totals merely
by adding catalogue expectations.

Child owns copied latest actual output observations and binding across fresh
contexts. Attach copies before dispatch, copy earned updates after success,
protect them from later hooks, and validate selected/unselected defaults using
existing contracts. Never rebuild selected facts from model recipes or client-
seeded peer success. Preserve finish_child's private actual parsed final baseline
and sealed callback facts through every hook; no baseline alias exposure.

Keep top-level result meanings and add child.connections tuple uniformly,
including ready-only. Each bounded owned summary has EXACT keys:

case,case_connection,ordinal,case_deadline,settings,informationals,receive_bytes,
receive_calls,connection_debt,stream_debt_total,release.

Bytes/reads are actual connection-local counts; debts are observed at release;
release is copied validated normal-close fact. No context/protocol/callback or
frame/read/stream history in results. Length equals actual connection count.
child.deadlines.case is the final case deadline; ready/whole/final-grace meanings
remain. Ordinary teardown retains close,signal,process,post. Update exact result
schema assertions explicitly; returned graphs must not alias supplied facts.

## Real composition proof

Build caller-owned child factory/lifecycle facts around the REVIEWED constructors:
test_core_peer.new_app/new_peer, test_lifecycle.new_case_evidence/new_peer,
test_producer_pressure.new_peer and test_file_early.new_peer. Consult their actual
signatures/state fields; no copied byte peers, generic success oracle or check()
that runs a separate client. A fresh empty-start app retains only serialized
earned records/outputs/binding across its connections. Peers use pinned codecs,
bounded packets/cursors/hashes; no whole large body/output or request histories.

Actual coordinator.run proofs must include:
- ready_buffered and large_declared in both caller orders; large_undeclared too.
- reuse preceded and followed by ordinary cases on fresh contexts.
- producer_reuse and both pressure cases followed by an ordinary final collector,
  retaining independently earned output/binding facts across contexts.
- stream_file followed by an ordinary final collector; early_final_order followed
  by ordinary completion so reset/debt retirement survives intermediate release.
- Intermediate normal closes, exactly one final68, inherited parser/ledger/time
  at final entry, and independent response/request scopes.
- Failed intermediate close blocks the next connect/dispatch; missing retained
  facts, callback mutation, malformed descriptors, rollback/expiry and final/post
  privacy/error paths. Preserve the original ready-only and empty proofs.

Examples from immutable contracts (derive test expectations there, not new
production magic totals): ready+large_declared eitherorder78heads/78small/R100000257;
reuse+ready462/462/R545; producer_reuse+ready82/81. Actual dispatched traffic and
parsed observations must establish these values. Other selected proof counts
derive from actual existing case contracts. These representative subsets do not
claim actual all37/default/all40 execution; that global proof remains later.

## Evidence and verification

Before edits capture exact accepted source map and a fresh exhaustive prior
evidence-file SHA map (exclude only this new unit directory), plus frozen before
source. If existing evidence exists, preserve it, verify provenance first and
use distinct attempt names. Do not overwrite recorded history or falsely relabel
later capture as pre-edit. Write the actual multi-case acceptance test first and
retain its RED before implementation; unsupported selection is a pre-effect RED
and must not be described as wire execution. Once dispatch exists, retain any
actual schedule failures and fix them with genuine regressions. Do not fabricate
a wire RED. Any discovered bug gets a real failing regression before fix. Keep all
failures/intermediate versions/current proof distinct.

After final source edit run test_coordinator_composition.py, test_coordinator.py
and test_imports.py pinned Python -B -S normal/-O (six covering commands). Add an
unchanged suite only for a concrete demonstrated dependency, not broad repeats.
Current39 inventory/AST/oneguard/actual inert empty+foreignargv imports; every
authored recorder guarded/inert too. No classes/assert/custom exceptions/hidden
mutable globals/dead code/camelCase/ignored errors/nesting>3. No speculative
abstractions; helpers must add a real invariant/bound/type guarantee.

Pinned interpreter /home/codespace/.python/current/bin/python3 SHA
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601; existing
model/core26/helper/42codecs PYTHONPATH and immutable119 entries remain. Ordered
codec aggregate0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Exact commands/stdout/stderr/exit, current/frozen source and input identities,
new storage/result bounds, self-review and remaining scope belong in report.

Before new codebase question/search/source read use graphify query first:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650
Provided paths located. Read project/role/narrow skills. No native/build/server/
socket/SSLContext/TLS-close/realclock/processownership/transfer/kernel/fault/
cancel/scheduling/interleaving/race/resource/panic/crash/leak/oldruntime execution,
installs or network. Only pinned in-memory codecs and supplied synthetic facts.
Broad native/project gates, actualdefault/all40/broadreview/runtime/twochildnative
and adoption/fullmilestones remain required later. Return under15lines status/
reportpath/checks/concerns; Root independently reviews and owns Git/publication.
