# Ordinary coordinator composition review

Review task-5e3b7p5-brief.md and exact
task-5e3b-coordinator-composition-plan-report.md phase2A; peer interfaces in
task-5e3b-peer-extraction-addendum.md P5. Claims task-5e3b7p5-report.md;
Rootfinalaudit task-5e3b7p5-root-final-audit.json binds full
task-5e3b7p5-review-source.diff and exact current/baseline/frozen/raw identities.
BASE pushed41fa29645882ac3faf67396e976cca60504e2a48; no taskcommit.

Binding focus: ALL37ordinary validcallerorderedsubsets (onlydisconnect/idle/
activeshutdown unsupportedhere), staticmalformed/unsupportedbeforeeffects,
defaultcatalogue unchanged/rejectsuntil2C, emptyzeroeffects. Actualrun_case and
canonicalstartup/observe/finalization, no handlerinjection/familycheck()/model
completion. New resultchild.connections exact11keys/types/scalars/ownedcopies,
ordinal1..actualconnections vsconnectcaseindex1. Actualcountsfreezeonce/case,
checkedtotals/finalregs/settings/bytes/reads, notcatalogue-summedobservations.

Perordinarycase freshcanonicalstate; actualcompletion/quiescence permitspositive
closed debt, no fabricatedrefund. Intermediateboundary/close(originalcasewhole)/
factvalidation/timecheck before nextdispatch, no intermediatecollection/grace/
signal/deinit. Lastonlyfinal68+finish_child; ordinaryteardown earnsnoidleID.
Onewhole900/ready15/casetimeout beforeconnect/finalgrace15clipped; allactualtime
handoffsmonotonic/originalcase and parser/readcaps preserved. Callbackerroridentity
and failurestopbefore nextcase, no cleanup/progressframework.

ChildprivatecompletedIDs/outputbinding facts retained acrossfreshctx andsealed
againsthookmutation. Onlyserializedearnedfacts; defaultsvalidatedunselectedonly.
Finalactualparsed67records+metrics privatebaseline/callbackfacts sealed through
hooks. Resultgraphindependentfrompubliccontext/callbackgraphs. No liveobjects/
frame/read/streamhistories inresult. Existingreadytyped/privacy/clock/error/empty
proofs retained; intentionalnewordinarysupport/schema assertionsupdatedhonestly.

Representativeactualcoordinator proofs use reviewedboundedpeerconstructors:
ready/large bothorders/undeclared; reusebefore+afterordinary; producerreuse/both
pressures->ordinaryfinal withretainedfacts; file/early->ordinary; intermediate
failureblocksnextconnect; onefinal/inheritedstate/debt/time/privacy/alias/error
controls. Supportedall37 isdistinctfromactualrepresentatives andfutureactual
default/all40/41connectionnativeacceptance. Inspectexactcases/commandsinthebrief
andreport, not assumedcoverage. InitialunsupportedselectionRED ispre-effect,
notwireexecution; actualschedulefailures mustremain separatelypreserved.

Read difffileonce/testsfirst/context10; no separatechangedfile unlessneeded
functioncutoff, identifyit. Outside-diff reads onlyconcretenamedrisk/onefocused
check. ApplyAGENTS/CODING/code-review-and-quality andexplicitRoot-requested
thermo-nuclearstructurallens underprojectoverrides. Sourcecoupling/bounds/privacy/
counting/time ordering prioritized; don't mechanicallysplit atlineflag.

Read-only/noagents/externalCLI/Git/file/servicewrites/native/build/server/socket/
SSLContext/TLS-close/realclock/processownership/transfer/kernel/fault/cancel/
schedule/race/panic/leak execution. Originalgraphifyprefixbefore newquestion/
search; providedpaths located. Do notrerunpassedchecks absentconcreteunanswered
source doubt; anyfocusedcheckpurepinnedonly. ReturnfullSPEC/QUALITY/actionable
severity/fileline/scenariofindings, strengths/cannotverify. No broadwhole-branch
review or sourcefix; Root integrates andsavesfullverdict.
