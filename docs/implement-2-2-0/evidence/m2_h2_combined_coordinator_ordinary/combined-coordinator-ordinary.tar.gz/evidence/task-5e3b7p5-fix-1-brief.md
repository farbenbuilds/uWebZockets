# P5 fix round1: original intermediate-close time boundary

Read task-5e3b7p5-review-report.md. Sameoriginalowner/task/source-only constraints.
Rootreadfixloopbeforethisround. Ownonly coordinator.py and relevant owned
test_coordinator_composition.py forfix; other37 currentmodules unchanged. No
core/model/fixture/peer/public/Git/native edits/agents/externalmodelCLI.

Replace post-close validation based on mutable context clock/now/stage deadlines
with validation against private original values. Capture newest checked pre-close
timestamp AFTER any existing pre-close clock observations, preserve local
min(original case_deadline,whole_deadline), invoke supplied close, validate its
facts, then use the ORIGINAL caller clock with those private bounds. Carry that
validated timestamp into next case. No discarded checked time, refreshed whole/
case/final deadline or broader cleanup/context-freezing framework. Preserve
callback errors, summary/output copies and ordinary positive closed debt.

Actual before-fix RED: ready->large firstclose widens stage.case_deadline towhole
andsets callerclock to originalcaseDeadline32; oldrun incorrectly succeeds with
2connections/[32,212]. Require rejection before connection2. Include controls
that rewrite context.now to hide rollback and context.clock to mask true caller
time, so enforcement cannot use callback-mutated fields. Correctly within-bound
close with contextfieldmutation must not alter next timestamp/deadline/summary.
Avoid unrelated faultmatrix; this is pure caller-fact sensitivity, not native.

Retain actual RED/source beforefix and covering green. Preserve reviewed8399B
report prefix/completion39frozen/sixcurrentreceipts/fresh5111prior map, allolder
snapshots/knownhistoricalgaps. Newstructure/audits/attempts have DISTINCT names.
Append fixreport/exactcommands/raw/currentfrozen/input/historyidentities and
selfreview. Afterlastsource/testedit run same6 composition/coordinator/import
normal/-O checks, no broad precedingmatrix. Rootscopedaudit then same-reviewer
fixreview; all37/currentcontracts andfullparentdefault/native/adoptionremain.
