"""Pinned source identity and frozen evidence checks; no client execution."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import sys


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def immutable(root, evidence):
    path = root / 'evidence/coordinator-a/immutable-inputs.json'
    identity = json.loads(path.read_text())
    rows = identity['identities']
    require(len(rows) == 119, 'identity row count')
    files = [row for row in rows if 'bytes' in row]
    for row in files:
        item = Path(row['path'])
        require(item.stat().st_size == row['bytes'] and sha(item) == row['sha256'], 'immutable differs: ' + str(item))
    codecs = identity['codec_files']
    for name, digest in codecs:
        require(sha(Path('/tmp/uwz-h2-client-tooling/packages') / name) == digest, 'codec differs: ' + name)
    require(len(codecs) == 42 and hashlib.sha256(json.dumps(codecs).encode()).hexdigest() == identity['codec_digest'], 'ordered codec identity')
    require(sha(Path(sys.executable)) == '4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601', 'interpreter identity')
    if not (evidence / 'immutable-inputs.json').exists():
        (evidence / 'immutable-inputs.json').write_bytes(path.read_bytes())
    require((evidence / 'immutable-inputs.json').read_bytes() == path.read_bytes(), 'authority changed')
    print('immutable rows=%d file_rows=%d unique_paths=%d ordered_codecs=%d digest=%s interpreter=%s' %
          (len(rows), len(files), len({row['path'] for row in files}), len(codecs), identity['codec_digest'], sha(Path(sys.executable))))


def snapshot(root, evidence, name):
    target = evidence / name
    target.mkdir()
    inventory = {}
    for path in sorted(root.glob('*.py')):
        inventory[path.name] = sha(path)
        (target / path.name).write_bytes(path.read_bytes())
    (evidence / (name + '.json')).write_text(json.dumps(inventory, indent=2) + '\n')
    return inventory


def check():
    evidence = Path(__file__).resolve().parent
    root = evidence.parents[1]
    immutable(root, evidence)
    mode = sys.argv[1]
    if mode == 'before':
        manifest = Path('docs/implement-2-2-0/evidence/m2_h2_combined_coordinator_ready/manifest.json')
        accepted = json.loads(manifest.read_text())['current_source_files']
        current = snapshot(root, evidence, 'before-source')
        require(current == accepted and len(current) == 37, 'accepted37 differs')
        (evidence / 'accepted-manifest.json').write_bytes(manifest.read_bytes())
        history = {str(path.relative_to(root)): sha(path) for path in sorted((root / 'evidence').rglob('*'))
                   if path.is_file() and evidence not in path.parents}
        (evidence / 'prior-evidence-map.json').write_text(json.dumps(history, indent=2) + '\n')
        print('accepted source=37 prior evidence files=%d' % len(history))
        return
    history = json.loads((evidence / 'prior-evidence-map.json').read_text())
    for name, digest in history.items():
        require(sha(root / name) == digest, 'prior evidence changed: ' + name)
    before = json.loads((evidence / 'before-source.json').read_text())
    current = snapshot(root, evidence, mode)
    changed = {name for name in before if current.get(name) != before[name]}
    require(changed == {'test_shared.py', 'test_coordinator.py', 'test_imports.py'} and
            set(current) - set(before) == {'test_core_peer.py'} and len(current) == 38, 'source scope differs')
    differences = []
    for name in sorted(changed | {'test_core_peer.py'}):
        old = (evidence / 'before-source' / name)
        differences.extend(difflib.unified_diff(old.read_text().splitlines(True) if old.exists() else [],
                                               (root / name).read_text().splitlines(True), fromfile='before/' + name, tofile='current/' + name))
    (evidence / (mode + '.diff')).write_text(''.join(differences))
    print('source=38 unchanged accepted=34 scoped changed=3 new=1 prior evidence preserved=%d frozen=%s' % (len(history), mode))


if __name__ == '__main__':
    check()
