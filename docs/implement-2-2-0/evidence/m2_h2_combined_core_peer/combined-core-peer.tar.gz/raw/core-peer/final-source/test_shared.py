"""Shared peer factories, actual schedules and carried-debt final boundaries."""
import json
import adapter
import catalogue
import model
import hpack
import test_core_peer


def require(value, message):
    if not value:
        raise RuntimeError(message)


def check_factory():
    def clock():
        raise RuntimeError('factory invoked clock')

    app = test_core_peer.new_app()
    baseline = json.dumps(app, sort_keys=True)
    first = test_core_peer.new_peer('ready_buffered', app=app, prior=(), now=1, clock=clock)
    second = test_core_peer.new_peer('large_declared', app=app, prior=(), now=1, clock=clock, final=True)
    require(set(app) == {'records', 'heads', 'outputs', 'binding'} and len(app['records']) == 67 and
            app['heads'] == 0 and app['outputs'] == model.default_outputs() and app['binding'] is None,
            'new app defaults differ')
    require(json.dumps(app, sort_keys=True) == baseline, 'factory dispatched or seeded records')
    for result in (first, second):
        require(set(result) == {'connection', 'state'} and set(result['connection']) ==
                {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'}, 'factory schema differs')
        state = result['state']
        require(set(state) == {'case', 'final', 'path', 'method', 'headers', 'startup', 'buffer', 'pending', 'body',
                              'heads', 'cursor', 'count', 'data', 'frames', 'max_span', 'ends', 'settings', 'acks',
                              'received', 'received_bytes', 'last', 'digest', 'decoder', 'encoder',
                              'max_buffer', 'max_body', 'max_pending', 'max_pending_bytes'}, 'explicit peer state differs')
        require(state['startup'] and state['heads'] == 0 and state['received'] == 0 and state['count'] == 0 and
                len(state['pending']) == 1 and not state['buffer'], 'constructor advanced peer')
        test_core_peer.check_storage(state)
    require(first['connection']['protocol'] is not second['connection']['protocol'], 'protocol shared')
    for field in ('buffer', 'pending', 'body', 'digest', 'decoder', 'encoder'):
        require(first['state'][field] is not second['state'][field], 'fresh peer field shared: ' + field)
    other = test_core_peer.new_app()
    require(other == app and other is not app and other['records'] is not app['records'] and
            other['outputs'] is not app['outputs'], 'application defaults shared')
    for tag in app['records']:
        require(app['records'][tag] is not other['records'][tag], 'record default shared')
    for prior in (('ready_buffered',), ('large_declared',), ('ready_buffered', 'large_declared')):
        try:
            test_core_peer.new_peer('large_undeclared', app=app, prior=prior, now=1, clock=lambda: 2)
        except ValueError:
            require(json.dumps(app, sort_keys=True) == baseline, 'invalid prior mutated app')
        else:
            raise RuntimeError('undispatched prior accepted')
    print('empty-start factories: exact schema/defaults, no dispatch/seeding, independent state and earned prior passed')



def expect_rejection(operation, message):
    try:
        operation()
    except ValueError as error:
        require(message in str(error), 'wrong peer rejection: ' + str(error))
        return
    raise RuntimeError('malformed peer input silently succeeded: ' + message)


def started_peer(case='ready_buffered', final=False):
    result = test_core_peer.new_peer(case, app=test_core_peer.new_app(), prior=(), now=1, clock=lambda: 2, final=final)
    connection = result['connection']
    connection['send'](connection['protocol'].data_to_send())
    initial, _now = connection['receive']()
    connection['protocol'].receive_data(initial)
    connection['send'](connection['protocol'].data_to_send())
    return result


def send_head(result, encoder, path, stream, *, primary=False):
    state = result['state']
    fields = [(':method', state['method'] if primary else 'GET'), (':scheme', 'https'),
              (':authority', 'localhost'), (':path', path)]
    if primary:
        fields.extend(state['headers'])
    result['connection']['send'](test_core_peer.frame(1, 4 if primary else 5, stream, encoder.encode(fields)))


def check_serialized_rejections():
    fresh = test_core_peer.new_peer('ready_buffered', app=test_core_peer.new_app(), prior=(), now=1, clock=lambda: 2)
    expect_rejection(fresh['connection']['receive'], 'finite peer input missing')
    expect_rejection(lambda: fresh['connection']['send'](b'x' * 75), 'startup bytes differ')
    require(fresh['state']['startup'] and fresh['state']['settings'] == 0, 'invalid startup advanced state')
    expect_rejection(lambda: fresh['connection']['send'](b'x' * 8193), 'send span differs')
    malformed = (
        (test_core_peer.frame(4, 1, 0, b''), 'settings ACK differs'),
        (test_core_peer.frame(8, 0, 0, b'\0\0\0\1'), 'request before preceding response'),
        (b'\0\x20\x01' + b'\0' * 6, 'frame payload bound differs'),
    )
    for packet, message in malformed:
        result = started_peer()
        expect_rejection(lambda: result['connection']['send'](packet), message)
        require(result['state']['cursor'] == 0, 'invalid frame advanced request cursor')
    fields = [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', '/health')]
    corruptions = ((fields + [(':path', '/health')], 1, 5), (fields, 3, 5), (fields, 1, 4),
                   (fields[:-1] + [(':path', '/metrics')], 1, 5), (list(reversed(fields)), 1, 5))
    for entries, stream, flags in corruptions:
        result = started_peer()
        packet = test_core_peer.frame(1, flags, stream, hpack.Encoder().encode(entries))
        expect_rejection(lambda: result['connection']['send'](packet), 'request contract differs')
        require(result['state']['heads'] == 0, 'invalid metadata counted as head')
    for case in ('ready_buffered', 'large_declared', 'large_undeclared'):
        result, encoder = started_peer(case, final=True), hpack.Encoder()
        for index, path in enumerate(('/health', '/metrics')):
            send_head(result, encoder, path, 2 * index + 1)
            result['connection']['receive']()
        send_head(result, encoder, result['state']['path'], 5, primary=True)
        expect_rejection(lambda: send_head(result, encoder, '/metrics', 7), 'request before primary terminal')
        payload = model.core_request(case)['body'] if case == 'ready_buffered' else model.payload_span(model.MAX_PAYLOAD, 0, 8192)
        flags = 0 if case == 'ready_buffered' else 1
        packet = test_core_peer.frame(0, flags, 5, payload)
        if len(packet) > 8192:
            result['connection']['send'](packet[:8192])
            packet = packet[8192:]
        expect_rejection(lambda: result['connection']['send'](packet),
                         'echo DATA differs' if case == 'ready_buffered' else 'upload DATA terminal differs')
        expect_rejection(lambda: result['connection']['send'](test_core_peer.frame(0, 1, 5, b'bad')),
                         'echo DATA differs' if case == 'ready_buffered' else 'upload payload differs')
        require(result['state']['ends'] == 0 and result['state']['count'] == 0, 'invalid DATA earned completion')
    result, encoder = started_peer(final=False), hpack.Encoder()
    for index, path in enumerate(('/health', '/metrics', '/echo', '/metrics', '/health')):
        send_head(result, encoder, path, 2 * index + 1, primary=index == 2)
        if index == 2:
            result['connection']['send'](test_core_peer.frame(0, 1, 5, model.core_request('ready_buffered')['body']))
        result['connection']['receive']()
    expect_rejection(lambda: send_head(result, encoder, '/status/large_declared', 11), 'final before finite schedule completion')
    require(result['state']['cursor'] == 5, 'unpermitted final advanced cursor')
    print('serialized sensitivity: startup, parser bounds, duplicate metadata/order/stream/END, premature terminal/final and payload rejected')


def final_boundary(context, receive, state):
    stage, request = context['stage'], context['request']
    boundary = {name: context[name] for name in ('stage', 'raw', 'request', 'credit', 'records')}
    boundary.update(bytes=stage['bytes'], reads=stage['reads'], received=state['received'],
                    received_bytes=state['received_bytes'], connection_debt=request['connection_debt'],
                    stream_debt=request['stream_debt_total'], deadlines=(stage['case_deadline'], stage['whole_deadline']))
    debt = boundary['connection_debt'] + boundary['stream_debt']
    large = stage['case'].startswith('large_')
    if large:
        require(boundary['connection_debt'] > 0 and boundary['stream_debt'] > 0 and state['last'] is not None,
                'missing earned carried debt')
    final_reads, final_bytes = 0, 0

    def read():
        nonlocal final_reads, final_bytes
        require(stage['final'] and stage['final_budget'] == catalogue.final_budget(debt), 'final budget differs')
        require(all(context[name] is boundary[name] for name in ('stage', 'raw', 'request', 'credit', 'records')),
                'connection identity changed')
        require((stage['case_deadline'], stage['whole_deadline']) == boundary['deadlines'], 'deadlines changed')
        if final_reads == 0:
            require(stage['bytes'] == boundary['bytes'] and stage['reads'] == boundary['reads'], 'entry counters changed')
            require(request['connection_debt'] == boundary['connection_debt'] and
                    request['stream_debt_total'] == boundary['stream_debt'], 'entry debt changed')
        if large and final_reads == 1:
            require(len(context['raw']['header']) == 5 and request['connection_debt'] == 0 and
                    request['stream_debt_total'] == boundary['stream_debt'], 'split refund state differs')
        data, now = receive()
        final_reads += 1
        final_bytes += len(data)
        return data, now

    value = adapter.final_collection(context, read)
    require(value is None and stage['final_complete'] and stage['final_registered'] == 68, 'final return/count differs')
    require(stage['bytes'] == boundary['bytes'] + final_bytes and stage['reads'] == boundary['reads'] + final_reads and
            stage['final_bytes'] == final_bytes, 'cumulative accounting differs')
    require(state['received'] == boundary['received'] + final_reads and
            state['received_bytes'] == boundary['received_bytes'] + final_bytes, 'receive counters differ')
    require((stage['case_deadline'], stage['whole_deadline']) == boundary['deadlines'] and
            stage['case_state']['bytes'] == stage['bytes'] and stage['case_state']['reads'] == stage['reads'], 'final state differs')
    remaining = 0 if large else 257
    require(request['connection_debt'] == remaining and request['stream_debt_total'] == remaining and
            not state['pending'] and state['last'] is None and not context['raw']['header'] and
            context['raw']['frame'] is None, 'refund or parser remains')
    print('entry debt connection=%d stream=%d budget=%d; final bytes=%d reads=%d; upload frames=%d' %
          (boundary['connection_debt'], boundary['stream_debt'], stage['final_budget'], final_bytes, final_reads, state['frames']))


def run_schedules(selection):
    app = test_core_peer.new_app()
    contexts = []
    peers = []
    for index, case in enumerate(selection):
        prior = tuple(selection[:index])
        final = index == len(selection) - 1
        unchanged = json.dumps(app, sort_keys=True)
        result = test_core_peer.new_peer(case, app=app, prior=prior, now=1, clock=lambda: 2, final=final)
        require(json.dumps(app, sort_keys=True) == unchanged, 'factory changed earned app')
        connection, state = result['connection'], result['state']
        context = adapter.open_case(case, connection['protocol'], connection['send'], connection['now'], 30001, 900001,
                                    selected_before=prior, clock=lambda: 2)
        require(context['request']['connection_debt'] == 0 and context['request']['stream_debt_total'] == 0, 'new ledger inherited debt')
        for previous in contexts:
            require(all(context[name] is not previous[name] for name in ('protocol', 'request', 'raw', 'credit')), 'connection state shared')
        for previous in peers:
            require(all(state[name] is not previous[name] for name in ('pending', 'buffer', 'body', 'digest', 'decoder', 'encoder')),
                    'peer state shared')
        for previous in contexts:
            if previous['stage']['case'] == 'ready_buffered':
                require(previous['request']['connection_debt'] == 257 and previous['request']['stream_debt_total'] == 257, 'prior debt changed')
        contexts.append(context)
        peers.append(state)
        data, now = connection['receive']()
        adapter.observe(context, data, now)
        adapter.run_case(context, connection['receive'])
        require(state['heads'] == 5 and state['cursor'] == 5, 'case request order differs')
        expected = 257 if case == 'ready_buffered' else model.MAX_PAYLOAD
        require((context['stage']['case_state']['heads'], context['stage']['case_state']['small'], context['request']['case']['sent']) ==
                (5, 5, expected), 'case J/C/R differs')
        if case == 'ready_buffered':
            require(bytes(state['body']) == model.core_request(case)['body'], 'echo payload differs')
            require(context['request']['connection_debt'] == 257 and context['request']['stream_debt_total'] == 257, 'ready debt differs')
        else:
            require(state['count'] == model.MAX_PAYLOAD and state['digest'].hexdigest() == model.LARGE_HASH and
                    state['frames'] == 12208 and state['ends'] == 1, 'upload differs')
        model.validate_records(prior + (case,), 'before', app['records'])
        if final:
            final_boundary(context, connection['receive'], state)
            require(state['heads'] == 73 and state['cursor'] == 73, 'final order differs')
        test_core_peer.check_storage(state)
        print('peer bounds case=%s parser=%d echo=%d pending=%d pending_bytes=%d' %
              (case, state['max_buffer'], state['max_body'], state['max_pending'], state['max_pending_bytes']))
    for context in contexts:
        if context['stage']['case'] == 'ready_buffered':
            require(context['request']['connection_debt'] == 257 and context['request']['stream_debt_total'] == 257, 'prior ready debt changed')
    model.validate_records(tuple(selection), 'before', app['records'])
    require(app['heads'] == 5 * len(selection) + 68 and app['outputs'] == model.default_outputs() and app['binding'] is None,
            'persistent app facts differ')
    print('shared actual caller order ' + '->'.join(selection) + ' passed')


def check():
    check_factory()
    check_serialized_rejections()
    run_schedules(('ready_buffered', 'large_declared'))
    run_schedules(('large_declared', 'ready_buffered'))
    run_schedules(('large_undeclared',))
    print('shared schedules and carried final boundary passed')


if __name__ == '__main__':
    check()
