"""Bounded serialized ready/large peer with caller-owned persistent facts."""
import hashlib
import json
import catalogue
import h2_client
import hpack
import model


def require(value, message):
    if not value:
        raise ValueError(message)


def frame(kind, flags, stream, payload):
    return len(payload).to_bytes(3, 'big') + bytes((kind, flags)) + stream.to_bytes(4, 'big') + payload


def new_app():
    return dict(records=model.records((), 'before'), heads=0, outputs=model.default_outputs(), binding=None)


def check_storage(state):
    state['max_buffer'] = max(state['max_buffer'], len(state['buffer']))
    state['max_body'] = max(state['max_body'], len(state['body']))
    state['max_pending'] = max(state['max_pending'], len(state['pending']))
    state['max_pending_bytes'] = max(state['max_pending_bytes'], sum(map(len, state['pending'])))
    require(len(state['buffer']) <= 8201 and len(state['body']) <= 257, 'parser/echo storage bound differs')
    require(len(state['pending']) <= 10 and sum(map(len, state['pending'])) <= 16384, 'pending storage bound differs')
    require(all(type(packet) is bytes and 0 < len(packet) <= 8192 for packet in state['pending']), 'pending packet bound differs')
    require(state['last'] is None or tuple(map(len, state['last'])) == (13, 13), 'late credit storage bound differs')
    require(0 <= state['cursor'] <= (73 if state['final'] else 5) and state['heads'] == state['cursor'], 'finite cursor differs')
    require(state['count'] <= model.MAX_PAYLOAD and state['frames'] <= 12208 and state['ends'] <= 1 and
            state['settings'] <= 1 and state['acks'] <= 1 and state['received'] <= 12288, 'finite action bound differs')
    require(state['decoder'].max_allowed_table_size == 4096 and state['encoder'].header_table_size == 4096,
            'HPACK table bound differs')


def primary_contract(case):
    if case == 'ready_buffered':
        item = model.core_request(case)
        return item['path'], item['method'], tuple(item['headers'])
    item = model.request_contract(case)
    headers = () if item['declared'] is None else (('content-length', str(item['declared'])),)
    return item['target'], item['method'], headers


def request_path(state):
    cursor = state['cursor']
    if cursor < 5:
        return ('/health', '/metrics', state['path'], '/metrics', '/health')[cursor]
    require(state['final'] and state['acks'] == 1 and state['ends'] == 1, 'final before finite schedule completion')
    require(cursor < 73, 'request beyond final collection')
    if cursor == 72:
        return '/metrics'
    return '/status/' + model.BODY_SPECS[cursor - 5][0]


def metrics(app):
    fields = model.COMMON_COUNTERS + ('bytes',)
    values = {name: sum(item[name] for item in app['records'].values()) for name in fields}
    values.update(active=sum(int(item['active']) for item in app['records'].values()),
                  paused=sum(int(item['paused']) for item in app['records'].values()),
                  buffered_middleware=app['heads'] - values['middleware'], slot0_active=False, slot1_active=False)
    return values


def respond(state, app, path, stream):
    if path == '/health':
        body = b'ok'
    elif path == '/echo':
        body = bytes(state['body'])
    elif path == state['path']:
        body = json.dumps(app['records'][state['case']]).encode()
    elif path.startswith('/status/'):
        body = json.dumps(app['records'][path[8:]]).encode()
    else:
        require(path == '/metrics', 'unexpected observation')
        body = json.dumps(metrics(app)).encode()
    block = state['encoder'].encode(((':status', '200'), ('x-middleware', 'retained')))
    packet = frame(1, 4, stream, block) + frame(0, 1, stream, body)
    if state['cursor'] == 6 and state['last'] is not None:
        connection, stream_update = state['last']
        state['pending'].append(connection + stream_update[:5])
        state['pending'].append(stream_update[5:] + packet)
        state['last'] = None
        return
    state['pending'].append(packet)


def upload_data(state, app, packet):
    payload, flags, stream = packet[9:], packet[4], int.from_bytes(packet[5:9], 'big')
    count = state['count']
    require(state['cursor'] == 3 and stream == 5 and state['ends'] == 0 and 0 < len(payload) <= 8192,
            'upload DATA order/span differs')
    require(count + len(payload) <= model.MAX_PAYLOAD and payload == model.payload_span(model.MAX_PAYLOAD, count, len(payload)),
            'upload payload differs')
    terminal = count + len(payload) == model.MAX_PAYLOAD
    require(flags == int(terminal), 'upload DATA terminal differs')
    state['count'] += len(payload)
    state['data'] += len(payload)
    state['digest'].update(payload)
    state['frames'] += 1
    state['max_span'] = max(state['max_span'], len(payload))
    item = app['records'][state['case']]
    item.update(bytes=state['count'], chunks=state['frames'], max_span=state['max_span'])
    increment = len(payload).to_bytes(4, 'big')
    updates = (frame(8, 0, 0, increment), frame(8, 0, stream, increment))
    if terminal and state['final']:
        state['last'] = updates
    else:
        state['pending'].append(b''.join(updates))
    if not terminal:
        return
    state['ends'] += 1
    item.update(ends=1, sha256=state['digest'].hexdigest())
    require(state['digest'].hexdigest() == model.LARGE_HASH and state['frames'] == 12208, 'upload digest/frame count differs')
    respond(state, app, state['path'], stream)


def echo_data(state, app, packet):
    payload = model.core_request('ready_buffered')['body']
    require(state['cursor'] == 3 and state['ends'] == 0 and packet[4] == 1 and
            int.from_bytes(packet[5:9], 'big') == 5 and packet[9:] == payload, 'echo DATA differs')
    state['body'].extend(packet[9:])
    state['data'] += len(packet[9:])
    state['ends'] += 1
    state['digest'].update(packet[9:])
    respond(state, app, state['path'], 5)


def packet_received(state, app, packet):
    kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
    if kind == 4:
        require(packet == frame(4, 1, 0, b'') and state['acks'] == 0 and state['cursor'] == 0,
                'settings ACK differs')
        state['acks'] += 1
        return
    if kind == 0:
        if state['case'] == 'ready_buffered':
            echo_data(state, app, packet)
        else:
            upload_data(state, app, packet)
        return
    require(kind == 1 and state['acks'] == 1 and not state['pending'], 'request before preceding response')
    require(state['cursor'] < 3 or state['ends'] == 1, 'request before primary terminal')
    path = request_path(state)
    primary = state['cursor'] == 2
    expected = [(':method', state['method'] if primary else 'GET'), (':scheme', 'https'),
                (':authority', 'localhost'), (':path', path)]
    if primary:
        expected.extend(state['headers'])
    entries = list(state['decoder'].decode(packet[9:]))
    require(entries == expected and stream == 2 * state['cursor'] + 1 and flags == (4 if primary else 5),
            'request contract differs')
    state['heads'] += 1
    state['cursor'] += 1
    app['heads'] += 1
    if primary and state['case'] != 'ready_buffered':
        app['records'][state['case']].update(middleware=1, attempts=1, begins=1)
    if not primary:
        respond(state, app, path, stream)


def send_bytes(state, app, data):
    require(type(data) is bytes and 0 < len(data) <= 8192, 'send span differs')
    if state['startup']:
        expected = b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n'
        expected += frame(4, 0, 0, b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                                        ((1, 4096), (2, 1), (4, 65535), (5, 16384), (8, 0), (3, 100), (6, 65536))))
        require(data == expected, 'startup bytes differ')
        state['startup'] = False
        state['settings'] += 1
        return
    state['buffer'].extend(data)
    check_storage(state)
    while len(state['buffer']) >= 9:
        size = int.from_bytes(state['buffer'][:3], 'big')
        require(size <= 8192, 'frame payload bound differs')
        if len(state['buffer']) < size + 9:
            return
        packet = bytes(state['buffer'][:size + 9])
        del state['buffer'][:size + 9]
        packet_received(state, app, packet)
        check_storage(state)


def new_peer(case, *, app, prior, now, clock, final=False):
    """State: fixed parser<=8201, echo<=257, <=10 queued packets/16384 bytes,
    two held 13-byte refunds, bounded HPACK tables, scalar cursor/counters,
    one rolling upload digest and immutable primary metadata; no histories.
    owned/TLS/ALPN are supplied synthetic facts, never transport observations.
    """
    require(type(case) is str and case in ('ready_buffered', 'large_declared', 'large_undeclared'), 'unsupported core peer')
    require(type(app) is dict and set(app) == {'records', 'heads', 'outputs', 'binding'}, 'app fields differ')
    catalogue.schedule(prior)
    require(case not in prior and type(final) is bool and type(now) is int and 0 <= now < catalogue.U64 and callable(clock),
            'peer arguments differ')
    model.validate_records(prior, 'before', app['records'])
    model.validate_outputs(prior, app['outputs'])
    require(type(app['heads']) is int and app['heads'] >= sum(catalogue.case_budget(item)['heads'] for item in prior),
            'prior heads not earned')
    if not prior:
        require(app['heads'] == 0 and app['binding'] is None, 'empty prior app differs')
    path, method, headers = primary_contract(case)
    settings = b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    initial = frame(4, 0, 0, settings) + frame(4, 1, 0, b'')
    state = dict(case=case, final=final, path=path, method=method, headers=headers,
                 startup=True, buffer=bytearray(), pending=[initial], body=bytearray(),
                 heads=0, cursor=0, count=0, data=0, frames=0, max_span=0, ends=0,
                 settings=0, acks=0, received=0, received_bytes=0, last=None,
                 max_buffer=0, max_body=0, max_pending=0, max_pending_bytes=0,
                 digest=hashlib.sha256(), decoder=hpack.Decoder(max_header_list_size=8192), encoder=hpack.Encoder())

    def send(data):
        send_bytes(state, app, data)

    def receive():
        require(not state['startup'] and bool(state['pending']), 'finite peer input missing')
        check_storage(state)
        data = state['pending'].pop(0)
        state['received'] += 1
        state['received_bytes'] += len(data)
        return data, clock()

    check_storage(state)
    connection = dict(protocol=h2_client.new_protocol(), send=send, receive=receive, now=now,
                      owned=True, tls='TLSv1.3', alpn='h2')
    return dict(connection=connection, state=state)


if __name__ == '__main__':
    raise SystemExit('Import explicit caller-owned core peer factories')
