"""Shared peer factories, actual schedules and carried-debt final boundaries."""
import json
import adapter
import catalogue
import model
import test_core_peer


def require(value, message):
    if not value:
        raise RuntimeError(message)


def check_factory():
    app = test_core_peer.new_app()
    baseline = json.dumps(app, sort_keys=True)
    first = test_core_peer.new_peer('ready_buffered', app=app, prior=(), now=1, clock=lambda: 2)
    second = test_core_peer.new_peer('large_declared', app=app, prior=(), now=1, clock=lambda: 2, final=True)
    require(set(app) == {'records', 'heads', 'outputs', 'binding'} and len(app['records']) == 67 and
            app['heads'] == 0 and app['outputs'] == model.default_outputs() and app['binding'] is None,
            'new app defaults differ')
    require(json.dumps(app, sort_keys=True) == baseline, 'factory dispatched or seeded records')
    for result in (first, second):
        require(set(result) == {'connection', 'state'} and set(result['connection']) ==
                {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'}, 'factory schema differs')
        state = result['state']
        require(state['startup'] and state['heads'] == 0 and state['received'] == 0 and state['count'] == 0 and
                len(state['pending']) == 1 and not state['buffer'], 'constructor advanced peer')
        test_core_peer.check_storage(state)
    require(first['connection']['protocol'] is not second['connection']['protocol'], 'protocol shared')
    for field in ('buffer', 'pending', 'body', 'digest', 'decoder', 'encoder'):
        require(first['state'][field] is not second['state'][field], 'fresh peer field shared: ' + field)
    other = test_core_peer.new_app()
    require(other == app and other is not app and other['records'] is not app['records'] and
            other['outputs'] is not app['outputs'], 'application defaults shared')
    for tag in app['records']:
        require(app['records'][tag] is not other['records'][tag], 'record default shared')
    for prior in (('large_declared',), ('ready_buffered', 'large_declared')):
        try:
            test_core_peer.new_peer('large_undeclared', app=app, prior=prior, now=1, clock=lambda: 2)
        except ValueError:
            require(json.dumps(app, sort_keys=True) == baseline, 'invalid prior mutated app')
        else:
            raise RuntimeError('undispatched prior accepted')
    print('empty-start factories: exact schema/defaults, no dispatch/seeding, independent state and earned prior passed')


def final_boundary(context, receive, state):
    stage, request = context['stage'], context['request']
    boundary = {name: context[name] for name in ('stage', 'raw', 'request', 'credit', 'records')}
    boundary.update(bytes=stage['bytes'], reads=stage['reads'], received=state['received'],
                    received_bytes=state['received_bytes'], connection_debt=request['connection_debt'],
                    stream_debt=request['stream_debt_total'], deadlines=(stage['case_deadline'], stage['whole_deadline']))
    debt = boundary['connection_debt'] + boundary['stream_debt']
    large = stage['case'].startswith('large_')
    if large:
        require(boundary['connection_debt'] > 0 and boundary['stream_debt'] > 0 and state['last'] is not None,
                'missing earned carried debt')
    final_reads, final_bytes = 0, 0

    def read():
        nonlocal final_reads, final_bytes
        require(stage['final'] and stage['final_budget'] == catalogue.final_budget(debt), 'final budget differs')
        require(all(context[name] is boundary[name] for name in ('stage', 'raw', 'request', 'credit', 'records')),
                'connection identity changed')
        require((stage['case_deadline'], stage['whole_deadline']) == boundary['deadlines'], 'deadlines changed')
        if final_reads == 0:
            require(stage['bytes'] == boundary['bytes'] and stage['reads'] == boundary['reads'], 'entry counters changed')
            require(request['connection_debt'] == boundary['connection_debt'] and
                    request['stream_debt_total'] == boundary['stream_debt'], 'entry debt changed')
        if large and final_reads == 1:
            require(len(context['raw']['header']) == 5 and request['connection_debt'] == 0 and
                    request['stream_debt_total'] == boundary['stream_debt'], 'split refund state differs')
        data, now = receive()
        final_reads += 1
        final_bytes += len(data)
        return data, now

    value = adapter.final_collection(context, read)
    require(value is None and stage['final_complete'] and stage['final_registered'] == 68, 'final return/count differs')
    require(stage['bytes'] == boundary['bytes'] + final_bytes and stage['reads'] == boundary['reads'] + final_reads and
            stage['final_bytes'] == final_bytes, 'cumulative accounting differs')
    require(state['received'] == boundary['received'] + final_reads and
            state['received_bytes'] == boundary['received_bytes'] + final_bytes, 'receive counters differ')
    require((stage['case_deadline'], stage['whole_deadline']) == boundary['deadlines'] and
            stage['case_state']['bytes'] == stage['bytes'] and stage['case_state']['reads'] == stage['reads'], 'final state differs')
    remaining = 0 if large else 257
    require(request['connection_debt'] == remaining and request['stream_debt_total'] == remaining and
            not state['pending'] and state['last'] is None and not context['raw']['header'] and
            context['raw']['frame'] is None, 'refund or parser remains')
    print('entry debt connection=%d stream=%d budget=%d; final bytes=%d reads=%d; upload frames=%d' %
          (boundary['connection_debt'], boundary['stream_debt'], stage['final_budget'], final_bytes, final_reads, state['frames']))


def run_schedules(selection):
    app = test_core_peer.new_app()
    contexts = []
    peers = []
    for index, case in enumerate(selection):
        prior = tuple(selection[:index])
        final = index == len(selection) - 1
        unchanged = json.dumps(app, sort_keys=True)
        result = test_core_peer.new_peer(case, app=app, prior=prior, now=1, clock=lambda: 2, final=final)
        require(json.dumps(app, sort_keys=True) == unchanged, 'factory changed earned app')
        connection, state = result['connection'], result['state']
        context = adapter.open_case(case, connection['protocol'], connection['send'], connection['now'], 30001, 900001,
                                    selected_before=prior, clock=lambda: 2)
        require(context['request']['connection_debt'] == 0 and context['request']['stream_debt_total'] == 0, 'new ledger inherited debt')
        for previous in contexts:
            require(all(context[name] is not previous[name] for name in ('protocol', 'request', 'raw', 'credit')), 'connection state shared')
        for previous in peers:
            require(all(state[name] is not previous[name] for name in ('pending', 'buffer', 'body', 'digest', 'decoder', 'encoder')),
                    'peer state shared')
        for previous in contexts:
            if previous['stage']['case'] == 'ready_buffered':
                require(previous['request']['connection_debt'] == 257 and previous['request']['stream_debt_total'] == 257, 'prior debt changed')
        contexts.append(context)
        peers.append(state)
        data, now = connection['receive']()
        adapter.observe(context, data, now)
        adapter.run_case(context, connection['receive'])
        require(state['heads'] == 5 and state['cursor'] == 5, 'case request order differs')
        expected = 257 if case == 'ready_buffered' else model.MAX_PAYLOAD
        require((context['stage']['case_state']['heads'], context['stage']['case_state']['small'], context['request']['case']['sent']) ==
                (5, 5, expected), 'case J/C/R differs')
        if case == 'ready_buffered':
            require(bytes(state['body']) == model.core_request(case)['body'], 'echo payload differs')
            require(context['request']['connection_debt'] == 257 and context['request']['stream_debt_total'] == 257, 'ready debt differs')
        else:
            require(state['count'] == model.MAX_PAYLOAD and state['digest'].hexdigest() == model.LARGE_HASH and
                    state['frames'] == 12208 and state['ends'] == 1, 'upload differs')
        model.validate_records(prior + (case,), 'before', app['records'])
        if final:
            final_boundary(context, connection['receive'], state)
            require(state['heads'] == 73 and state['cursor'] == 73, 'final order differs')
        test_core_peer.check_storage(state)
    for context in contexts:
        if context['stage']['case'] == 'ready_buffered':
            require(context['request']['connection_debt'] == 257 and context['request']['stream_debt_total'] == 257, 'prior ready debt changed')
    model.validate_records(tuple(selection), 'before', app['records'])
    require(app['heads'] == 5 * len(selection) + 68 and app['outputs'] == model.default_outputs() and app['binding'] is None,
            'persistent app facts differ')
    print('shared actual caller order ' + '->'.join(selection) + ' passed')


def check():
    check_factory()
    run_schedules(('ready_buffered', 'large_declared'))
    run_schedules(('large_declared', 'ready_buffered'))
    run_schedules(('large_undeclared',))
    print('shared schedules and carried final boundary passed')


if __name__ == '__main__':
    check()
