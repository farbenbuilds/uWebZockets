# Shared core peer source review

Review one source preparation task against task-5e3b7p1-brief.md and
task-5e3b-peer-extraction-addendum.md P1. Claims/evidence are in
task-5e3b7p1-report.md and Root's task-5e3b7p1-root-final-audit.json. Full source
diff task-5e3b7p1-review-source.diff (identity in Root audit). BASE pushed
7dc7d7722a27ad2d992a01716b3773790cee0711; no task commit yet. Ignored source is
published as an evidence archive after review; product adoption remains open.

Read diff once, tests first with context10. Do not separately reread changed
files unless a function required for judgment is cut mid-hunk; identify it.
Outside-diff reads only for concrete named risks, one focused check per risk.
No broad codebase crawl/Git repetition or passed test rerun. Treat report/audit
as claims, verify source against binding requirements. Diff includes one shared
peer and changed drivers/inventory; this is not a broad parent acceptance gate.

Binding excerpts:
- "Own only ... new test_core_peer.py; test_shared.py; test_coordinator.py;
  minimal test_imports.py inventory. ... No other existing37 module ... edit."
- "Extract serialization genuinely shared by both drivers, not a forwarding
  module or generic model-success peer."
- "Persistent app exact records,heads,outputs,binding; fresh default67 records/
  default outputs/heads0/bindingNone. prior validates earned prior state, never
  populates selected results."
- "No adapter import/client context/client dispatch in peer; all dispatch/
  finalization remains existing drivers."
- "No request/frame/read histories, accumulated paths/headers or whole100000000-
  byte payload. Incremental upload hash/count/frame/maxspan ..."
- "Keep test_coordinator.peer(control) return(state,clock,factory) and every
  existing ready lifecycle/fault/preflight/schema/privacy/timing/error identity
  assertion. ... It must not duplicate byte-peer implementation."
- "Move context-dependent final-entry and second-read split checks into driver
  wrappers ... original invoked exactly once/result and errors preserved."
- "These driver proofs are preparation and must not be described as coordinator
  multi-case execution."

Named risks: online exact startup/frame/HPACK/metadata/order and payload checks;
app truth independent from client observations; construction/prior cannot seed
undispatched work; independent fresh protocol/raw/request/credit state; original
debt/counters/deadlines through split late refund; bounded parser/packets/state;
original negative/fact/privacy/time controls preserved; no serialization copies
left in consumers; truthful final-vs-historical proof/native limitations.

Apply project AGENTS/CODING, code-review-and-quality and Root explicitly requests
thermo-nuclear structural lens under project overrides (threshold a flag, not
mechanical split). No agents or external model CLI. Read-only: no file/index/ref/
service/Git writes. No native/build/server/socket/SSLContext/TLS-close/realclock/
process ownership/transfer/kernel/fault/cancel/schedule/race/panic/leak execution;
only focused pure input sensitivity for a concrete unanswered doubt. Graphify
before new codebase questions/search, exact prefix in implementation brief;
provided paths already located.

Return full SPEC PASS/FAIL and QUALITY APPROVED/NEEDS FIXES verdicts, strengths,
only actionable severity/file:line/concrete failure findings and cannot-verify
boundaries. Root saves report. No source fix/repeated whole-matrix run.
