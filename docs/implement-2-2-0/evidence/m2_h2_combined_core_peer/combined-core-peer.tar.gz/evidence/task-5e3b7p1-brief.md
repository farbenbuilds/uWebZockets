# Task5e3b7p1: shared core peer preparation

Read task-5e3b-peer-extraction-addendum.md first, P1 only. This is a concrete
dependency of phase2A arbitrary37 ordinary-case composition, not a replacement
for phase2A/default/all40/native/adoption/full milestones. BASE is pushed
7dc7d7722a27ad2d992a01716b3773790cee0711. Source scope stays pure pinned in-memory
client + synthetic peer/caller facts. Coordinator API/support unchanged here.

Own only these combined-cases files: new test_core_peer.py; test_shared.py;
test_coordinator.py; minimal test_imports.py inventory. Also own new evidence/
core-peer and this workspace task-5e3b7p1-report.md. No other existing37 module,
immutable core/model/fixture/helper/codec, product/dependency/capacity/deadline
edit. Raise specific API gaps to Root before shared edits. You are not alone;
preserve other edits and all raw/history/source proof. Root owns publication,
review, commits/refs/pushes. No agents, external model CLI or public edits.

Extract serialization genuinely shared by both drivers, not a forwarding module
or generic model-success peer. Interfaces exact new_app() and
new_peer(case, *, app, prior, now, clock, final=False), exact {connection,state}
return. Persistent app exact records,heads,outputs,binding; fresh default67
records/default outputs/heads0/bindingNone. prior validates earned prior state,
never populates selected results. Exact seven connection fields protocol,send,
receive,now,owned,tls,alpn, pinned initiated helper protocol, supplied synthetic
TLSv1.3/h2/owned facts. Initial server SETTINGS+ACK queued in bounded pending
storage for ordinary receive. No adapter import/client context/client dispatch
in peer; all dispatch/finalization remains existing drivers. Explicit state
fields documented in constructor. No **kwargs/callback registry/hidden state.

Support actual ready_buffered,large_declared,large_undeclared schedules with
exact canonical metadata/payload/order and final68 when permitted; derive
immutable expected schemas from model/catalogue instead of guessing. Final
allowed only after schedule cursor completes, never mark completion. Decode
actual serialized HPACK/frames; validate order, duplicate multiplicity, stream
IDs, END flags, metadata and bounded startup/parser. No request/frame/read
histories, accumulated paths/headers or whole100000000-byte payload. Incremental
upload hash/count/frame/maxspan, bounded257 echo and small packets. Update app
records only from actual concrete actions. Counters and finite cursor prove
sequence. Retain exact late-refund split at final entry for large transfers,
and unrefunded ready257+257 debt. Both positive debt and normal final paths valid.

Keep test_coordinator.peer(control) return(state,clock,factory) and every existing
ready lifecycle/fault/preflight/schema/privacy/timing/error identity assertion.
Obtain byte serialization from shared peer; lifecycle harness adds readiness,
single connection argument/teardown invariants and fault controls. It must not
duplicate byte-peer implementation. Preserve ready actual73heads/73small/R257,
oneSETTINGS/oneACK/onefinal68 and74reads (existing framing) unless a justified
necessary fragmentation adjustment is explicitly reported, never quietly
weakened. Existing factory failure controls must still show no startup send.

Keep shared driver actual ready->large_declared and independent raw/request/
credit/protocol state with prior debt unchanged; actual100000000 bytes/hash;
large final68 carries original parser, both debt ledgers, read/byte counters,
deadlines and final_budget. Move context-dependent final-entry and second-read
split checks into driver wrappers around original adapter.final_collection or
receive, original invoked exactly once/result and errors preserved. Peer must
not use context records or stage to choose truth/timing. Use finite serialized
request cursor for large late-credit packet selection.

Meaningful new factory proof in owned driver(s): buffered/large declared both
caller orders on one empty-start app, canonical undeclared, factory creation
does not dispatch or advance app, no undispatched seed, independent fresh peer
state and default outputs/binding, exact bounded state/storage online validation.
These driver proofs are preparation and must not be described as coordinator
multi-case execution. Preserve every existing shared/coordinator check; no
standalone check() called instead of actual coordinator.run in coordinator test.

Before extraction snapshot accepted37 from latest coordinator-ready manifest,
full prior evidence SHA map and relevant immutable identities. This is primarily
refactoring: retain actual baseline covering proof; add meaningful new interface/
independence controls first and record real RED scope truthfully (missing API
alone is not serialized behavioral RED). Do not force fabricated REDs or weaken
checks. Actual failures/intermediate source/proofs remain separate from final.

After final edits run test_shared.py,test_coordinator.py,test_imports.py pinned
Python -B -S normal/-O; include actual large_undeclared and reverse order via
owned driver entrypoint. No broad preceding matrix repeat without cause.
All38 modules AST/oneguard/inert imports with empty+foreignargv, no class/assert/
customexceptions/hidden mutableglobals/deadcode/deepnest>3. No OS/native/socket/
SSLContext/process/realclock/build/server/TLS-close/fault/cancel/schedule/race/
kernel/resource/panic/leak probes, oldruntime entrypoints, installs or network.
Pure sensitivity inputs to codecs and supplied fact callbacks only.

Pinned interpreter /home/codespace/.python/current/bin/python3 SHA
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
Latest authority evidence/coordinator-a/immutable-inputs.json:119 entries,
118file rows/113unique filepaths and ordered42codecs aggregate SHA
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Preserve actual row order/encodings and before/after current source snapshots.

Before new codebase questions/search/source reads use graphify query first:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650
Provided paths are located. Read AGENTS/CODING_CONVENTION/role and narrow applicable
skills, no unrelated tooling/interview. Generic fullnative role matrices remain
required later, not authorized source-only operations here.

Report actual changed APIs/files, baseline/new RED/failures/current exact raw
commands/stdout/stderr/exit, immutable identities/current38/frozen snapshot,
self-review/storage bounds and remaining parent limitations. Main-guard every
authored executable helper (including temporary recorders) and prove inert.
Return under15lines status/report path/one-line test summary/concerns; no commit.
