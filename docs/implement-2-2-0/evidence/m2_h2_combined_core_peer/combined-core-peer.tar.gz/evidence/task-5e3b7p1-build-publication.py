"""Package the reviewed source checkpoint without executing client code."""
import hashlib
import json
import runpy
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load_writer(plan):
    helper = plan / 'task-5e3b6c-build-publication.py'
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_combined_disconnect_reuse/combined-disconnect-reuse.tar.gz')
    if sha(archive.read_bytes()) != '7c27d1a23dc616ce1b4f62afb64c2a65cc106de7d62647b9d38e3da4fb77de14':
        raise ValueError('Writer provenance archive differs')
    with tarfile.open(archive, 'r:gz') as source:
        stored = source.extractfile('evidence/' + helper.name).read()
    if helper.read_bytes() != stored:
        raise ValueError('Writer source differs from published evidence')
    return runpy.run_path(str(helper))


def inherit(members, add):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_combined_coordinator_ready/combined-coordinator-ready.tar.gz')
    if sha(archive.read_bytes()) != 'd52789f0f0ab40d1461505457866f7951b273bb1f2662ac8e4b792fe223922fc':
        raise ValueError('Baseline archive differs')
    with tarfile.open(archive, 'r:gz') as source:
        inventory = json.loads(source.extractfile('INVENTORY.json').read())
        for member in source:
            if not member.isfile():
                raise ValueError('Nonregular baseline member')
            if member.name == 'INVENTORY.json':
                continue
            data = source.extractfile(member).read()
            if inventory[member.name] != dict(size=len(data), sha256=sha(data)):
                raise ValueError('Baseline inventory mismatch')
            if member.name.startswith('reference/'):
                add(members, member.name, data)
            if member.name.startswith('source/current/'):
                add(members, member.name.replace('source/current/', 'history/coordinator-ready-source/', 1), data)


def collect(members, writer, source, plan):
    for path in sorted(source.glob('*.py')):
        writer['add'](members, 'source/current/' + path.name, path.read_bytes())
    raw = source / 'evidence/core-peer'
    for path in sorted(raw.rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink in source evidence')
        if path.is_file():
            writer['add'](members, 'raw/core-peer/' + path.relative_to(raw).as_posix(), path.read_bytes())
    names = ('task-5e3b7p1-brief.md', 'task-5e3b7p1-report.md', 'task-5e3b7p1-review-brief.md',
             'task-5e3b7p1-review-report.md', 'task-5e3b7p1-review-source.diff',
             'task-5e3b7p1-root-final-audit.json', 'task-5e3b7p1-root-input-preflight.json',
             'task-5e3b7p1-build-publication.py', 'task-5e3b7p1-root-builder-import-history.json',
             'task-5e3b-peer-extraction-addendum.md',
             'task-5e3b-coordinator-composition-plan-report.md', 'task-5e3b-release-addendum.md',
             'task-5e3b-cases-pending-brief.md', 'task-5e-combined-architecture.md',
             'task-5e-barrier-source-handoff.md', 'task-5e3b-aggregate-acceptance-notes.md')
    for name in names:
        writer['add'](members, 'evidence/' + name, (plan / name).read_bytes())


def main():
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    audit = json.loads((plan / 'task-5e3b7p1-root-final-audit.json').read_text())
    current = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if current != audit['current_source_sha256']:
        raise ValueError('Reviewed source changed')
    writer = load_writer(plan)
    members = {}
    inherit(members, writer['add'])
    collect(members, writer, source, plan)
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_peer')
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'combined-core-peer.tar.gz'
    inventory = writer['write_archive'](archive, members)
    summary = json.loads((source / 'evidence/core-peer/summary.json').read_text())
    manifest = dict(scope='Shared pure-codec ready/large peer preparation; coordinator composition unchanged',
                    base_commit=audit['base_commit'], archive=archive.name, archive_bytes=archive.stat().st_size,
                    archive_sha256=sha(archive.read_bytes()), safe_regular_text_members=len(members),
                    inventory_entries=len(inventory), current_source_files=current, added_files=audit['added'],
                    changed_files=audit['changed'], unchanged_coordinator_ready_modules=34,
                    current_normal_optimized_commands=6, preceding_final_normal_optimized_commands=6,
                    baseline_commands=3, current_ast_inert_import_files=38,
                    prior_evidence_hashes_preserved=4170, retained_identity_entries=119,
                    physical_identity_rows=118, unique_file_paths=113, ordered_codec_files=42,
                    observed_ready=summary['ready'], observed_large=summary['declared_and_undeclared'],
                    storage_bounds=summary['storage_bounds'], initial_red_scope='Missing shared peer API only',
                    behavioral_red_scope='Constructor accepted forged prior head count; not a serialized-stream RED',
                    source_review='Spec and quality approved, no actionable findings',
                    driver_orders=[['ready_buffered', 'large_declared'], ['large_declared', 'ready_buffered'], ['large_undeclared']],
                    driver_orders_are_coordinator_composition=False, concrete_source_handlers=40,
                    coordinator_supported_nonempty_selections=[['ready_buffered']], default_supported=False,
                    explicit_empty_supported=True, supplied_transport_lifecycle_facts=True,
                    native_executed=False, combined_all40_executed=False, milestone_complete=False,
                    remaining=['Lifecycle/producer/file peer construction', 'All37 ordinary coordinator composition',
                               'Disconnect/shutdown children and actual default/all40 aggregate',
                               'Broad review, runtime/native/project gates and production adoption'])
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
                  regular_members=len(members), inventory_entries=len(inventory), source_modules=len(current),
                  all_reopened_member_bytes_exact=True, native_executed=False)
    (plan / 'task-5e3b7p1-root-archive-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
