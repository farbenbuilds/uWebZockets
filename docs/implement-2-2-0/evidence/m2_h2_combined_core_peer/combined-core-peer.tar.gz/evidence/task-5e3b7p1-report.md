# Task5e3b7p1: shared core peer preparation

P1 is implemented and the scoped source-only proof passes. Root independent review, publication and integration remain pending. BASE: `7dc7d7722a27ad2d992a01716b3773790cee0711`.

All source paths below are relative to `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/`; raw artifacts are under `evidence/core-peer/`.

## Changes and API

`test_core_peer.py` owns genuine shared serialization for `ready_buffered`, `large_declared` and `large_undeclared`. Exact entrypoints are `new_app()` and `new_peer(case, *, app, prior, now, clock, final=False)`. Returns exact `{connection,state}`; connection has exactly `protocol,send,receive,now,owned,tls,alpn`. Protocol is the pinned already-initiated helper. Owned/TLSv1.3/h2 are synthetic supplied facts. Startup SETTINGS+ACK are queued and returned through ordinary receive. Construction neither invokes clock/client dispatch nor changes app.

The persistent app has exactly `records,heads,outputs,binding`: 67 unselected records, 0 heads, fresh default outputs, binding None. Constructor validates prior records/outputs/binding and exact earned catalogue head counts; it never populates selected records. `final` grants permission after the finite five-request schedule; it does not mark completion. Actual decoded requests and DATA update app facts. Ordered HPACK entries preserve duplicate multiplicity; exact streams, flags, startup bytes, payload spans and terminal actions are checked online. The peer has no adapter import, client context/stage, dispatch, callback registry, request histories or whole large payload.

`test_shared.py` now drives the shared peer through actual adapter calls, keeps parser/debt/deadline/final-budget checks in driver receive/final wrappers, and checks both ready/declared caller orders plus actual undeclared upload. Original final_collection is invoked once, its None return checked, and errors are not caught/replaced. Earlier ready debt stays 257+257 on independent raw/request/response-credit/protocol state. New controls cover exact state/schema/defaults, fresh identities, absent dispatched seed, constructor clock inertness, forged prior counts, malformed startup/metadata/order/stream/END/payload/parser bounds and forbidden premature finalization.

`test_coordinator.py` retains `peer(control=None)` returning `(state,clock,factory)` and actual `coordinator.run`. Byte serialization comes only from the shared peer. Lifecycle/readiness/fault wrappers enforce single factory/connection and existing typed arguments, close ordering, teardown and privacy checks. Post records/metrics/outputs derive from app; absent binding becomes the default only for the post validator. All old 67 typed rejection, preflight, schema, timing, error identity, private baseline and frozen-return checks remain. `test_imports.py` adds only the new module inventory entry. No coordinator API/support change or other source edit.

## Baseline and RED history

Before source edits, `before-source/` and `before-source.json` matched all 37 hashes from the latest coordinator-ready manifest, copied as `accepted-manifest.json`. `prior-evidence-map.json` retains all 4170 existing evidence-file hashes. Three focused baseline commands passed, retained as `baseline-test_shared`, `baseline-test_coordinator`, `baseline-test_imports` `.command/.stdout/.stderr/.exit`. Baseline raw highlights:

```text
entry debt connection=1781 stream=1781 budget=3110658; final bytes=28992 reads=69; upload frames=12208
ready coordinator serialized lifecycle passed: heads=73 small=73 flow=257 settings=1 final=68 reads=74 bytes=29903
AST and inert import checks passed
```

New factory/interface checks were authored first. `interface-red-test_shared.py` and `interface-red.*` retain exit 1: `ModuleNotFoundError: No module named 'test_core_peer'`. This is missing-interface RED, not serialized behavioral RED. No fabricated serialized failure is claimed.

Self-review added a real factory-state RED: an empty app claiming six heads for prior ready was accepted by the initial lower-bound check. `prior-heads-red-source/` and `prior-heads-red.*` retain the exact test/source and exit 1: `RuntimeError: malformed peer input silently succeeded: prior heads not earned`. The fix requires the exact catalogue-earned total. This is a constructor-state behavioral RED, not a serialized-stream RED. The current normal and optimized runs include it and pass.

Intermediate passing receipts remain in `attempt-1-*`, `attempt-2-*`, `attempt-2-source/`, and `final-*`/`final-source/`; `current-*`/`current-source/` are the accepted self-reviewed candidate. No raw evidence was discarded. Two evidence-recorder mistakes are separately retained: `audit-initial.*` assumed 119 physical rows instead of 118 plus the aggregate; `audit-nesting-initial.*` counted same-indent Python elif as additional nesting. Corrected traversal retains the <=3 threshold and counts lexical elif as the same branch level. `audit.py`, its initial versions, raw failures and inert-import proof are retained. Baseline audit printed 114 textual paths; resolving the relative/absolute duplicate yields 113 actual filepaths.

## Current exact commands and raw results

All Python proof uses `/home/codespace/.python/current/bin/python3`, SHA-256 `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`, with `-B -S`; optimized runs also use `-O`. These are Python normal/optimized modes; no Zig optimization/native execution is claimed. Each command below has an exact retained `.command`, unmodified `.stdout/.stderr`, and `.exit` under the matching current prefix. All six stderr files are empty and all exits are 0.

```sh
env PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py
env PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S -O /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py
env PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
env PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S -O /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
env PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shared.py
env PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S -O /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shared.py
```

Current raw stdout (normal and -O are identical per suite):

```text
empty-start factories: exact schema/defaults, no dispatch/seeding, independent state and earned prior passed
serialized sensitivity: startup, parser bounds, duplicate metadata/order/stream/END, premature terminal/final and payload rejected
peer bounds case=ready_buffered parser=266 echo=257 pending=1 pending_bytes=287
entry debt connection=1781 stream=1781 budget=3110658; final bytes=28992 reads=69; upload frames=12208
peer bounds case=large_declared parser=8201 echo=0 pending=8 pending_bytes=567
shared actual caller order ready_buffered->large_declared passed
peer bounds case=large_declared parser=8201 echo=0 pending=9 pending_bytes=593
entry debt connection=257 stream=257 budget=3071034; final bytes=28966 reads=68; upload frames=0
peer bounds case=ready_buffered parser=266 echo=257 pending=1 pending_bytes=485
shared actual caller order large_declared->ready_buffered passed
entry debt connection=1781 stream=1781 budget=3110658; final bytes=28992 reads=69; upload frames=12208
peer bounds case=large_undeclared parser=8201 echo=0 pending=8 pending_bytes=569
shared actual caller order large_undeclared passed
shared schedules and carried final boundary passed
empty and malformed/unsupported/default/static preflight passed without effects
ready coordinator serialized lifecycle passed: heads=73 small=73 flow=257 settings=1 final=68 reads=74 bytes=29903
typed descriptor/connection/close/signal/process rejections passed: 67
rollback/equality-expiry and callback-error identity/order boundaries passed
pre-open clock observation retained across adapter handoff
non-dict hook returns and every pre-start clock handoff reject before later effects
selection frozen; ready whole clipping, inherited case grace and checked ready overflow passed
post validators, private baseline, duplicate/observation boundary and sealed returned facts passed
AST and inert import checks passed
```

Current audit exact command:

```sh
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-peer/audit.py current-source
```

Raw stdout, empty stderr, exit 0:

```text
immutable rows=118 file_rows=118 unique_paths=113 ordered_codecs=42 digest=0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473 interpreter=4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601
AST modules=38 maximum control nesting=3; no class/assert/custom exception/module mutable containers
evidence helpers inert under empty and foreign argv: 3
source=38 unchanged accepted=34 scoped changed=3 new=1 prior evidence preserved=4170 frozen=current-source
```

`immutable-inputs.json` is byte-identical to latest coordinator-a authority. All 118 physical rows/113 resolved filepaths plus the ordered 42-codec aggregate were rehashed; the authority retains 119 identity entries. Codecs retain original row order and JSON encoding; aggregate SHA-256 `0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`. Every prior evidence hash still matches. Current38 SHA map is `current-source.json`; `current-source/` is a read-only source copy and `current-source.diff` compares against accepted37. Exactly 34 accepted modules remain byte-identical, three changed, one new. AST/one-main-guard/inert import with empty and foreign argv covers all38 in both modes. No class/assert/custom exceptions/module mutable containers; maximum lexical control nesting is3. Manual self-review found no unused new imports/functions, dead blocks, camelCase, error swallowing or hidden mutable module state. Evidence helpers also import inertly under both argv shapes.

## State bounds and self-review

Constructor state fields are explicitly enumerated and exact-tested: `case,final,path,method,headers,startup,buffer,pending,body,heads,cursor,count,data,frames,max_span,ends,settings,acks,received,received_bytes,last,digest,decoder,encoder,max_buffer,max_body,max_pending,max_pending_bytes`. Scalar fields, immutable primary metadata and one rolling digest replace histories. Parser<=8201 bytes; echo<=257; pending<=10 packets and16384 bytes total, each<=8192; held late refund exactly two13-byte frames; HPACK tables4096; cursor<=5 or73. Bounds are validated after each concrete frame and before receive. These are bounded Python source fixtures, not zero-allocation/native performance claims.

Observed maxima from actual schedules: ready parser266/echo257/pending1; declared and undeclared parser8201/echo0; upload pending peaks8 for held-final refund and9 when terminal refund is delivered normally. Largest observed queued bytes593. Final large cursor6 chooses the split refund packet using serialized order alone. Entry debt1781+1781, split header5 with connection debt0/stream debt1781 on the second final read, final budget3110658, final bytes28992/reads69 are preserved. Ready remains unrefunded257+257 with normal final68 collection. Both large uploads verify actual count100000000, rolling SHA-256 `190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2`,12208frames and bounded span8192.

Graph update exact command and raw receipt are `graph-update.*`; AST-only update exited0 and reported no relevant changes because these workspace evidence sources are ignored by graph discovery. No graph source claim is inferred. `commands.json` retains all recorded command/output identities; `summary.json` gives the current source/checkpoint inventory.

## Remaining parent limitations

This is P1 constructor preparation. Driver ready/large order proofs are not coordinator multi-case execution. P2-P4 family extraction, P5 arbitrary37 ordinary coordinator composition, phase2B disconnect, phase2C shutdown, actual default/all40, independent review, native/runtime/adoption/full milestones remain. Generic native/sanitizer/compliance matrices were not executed: this task authorizes only pinned in-memory source proof. No installs/network, native build/server/socket/SSLContext/realclock/process/fault/cancel/schedule/race/kernel/resource/panic/leak probes or old runtime entrypoint execution. Synthetic lifecycle callback facts remain synthetic. No public edits or Git writes; Root owns publication/review/commit/push. No unresolved P1 API gap identified.
