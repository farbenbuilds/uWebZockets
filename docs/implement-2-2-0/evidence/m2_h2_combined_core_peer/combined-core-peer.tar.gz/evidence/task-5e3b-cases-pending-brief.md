# Task 5e3b combined finite case schedules — pending

NOT RELEASED. Task5e3a must first finish all five gaps, pass independent
source/spec/quality review, and be published with its exact current identities.
Root will bind those identities and the reviewed action API before dispatch.
This brief preserves the next accepted preparation scope; it does not authorize
a second implementer, a runner, a native operation or new protocol policy.

## Purpose and ownership

Implement all40 combined case schedules against the reviewed Task5e3a earned
action/observation seam. Use a new combined-cases source directory, new small
task-specific temporary evidence, and this plan's task5e3b report. Preserve
existing family sources, prior clients, immutable core/model/fixture and public
evidence. One implementer at a time, no agents/commits/pushes. Root supplies
the final owned directory and immutable core path in the release addendum.

The main child contains39 case IDs with a fresh H2 connection per case and one
extra replacement for disconnect. The separate idle child contributes its one
case/connection. One combined run identity, two sequential fresh children and41
connections remain required. This source preparation executes none of them.

## Binding requirements

- Import the unchanged reviewed catalogue/model; do not create a second model
  or duplicate its case, tag, subset, counter or byte-budget constants.
- Implement all40 named IDs, preserving67 persistent independent body records,
  two reusable application slots and separate producer/file/B-binding checks.
  Cover full default selection and legitimate partial selections; reject
  duplicates, unknowns and active shutdown except last. Idle runs first.
- Use the current compiled/reviewed combined fixture's routes and schemas.
  Retain exact method/path/query/header/metadata/helper contracts from the
  final published family inputs. Initial family copies are not authoritative
  when corrected final successors exist.
- Use only the reviewed single raw-order/public-codec/both-ledger path.
  Every HEADERS, DATA, trailer, SETTINGS, grant, reset, final and retirement
  action must be paired exactly once. No alternate parser or duplicate refund
  aggregation; no legacy unbounded request or receive helper.
- Preserve the accepted exact per-case head/small/DATA/reset/SETTINGS counts
  and checked byte/read/deadline bounds. A source contradiction goes to Root
  before any changed count, allowance, capacity or deadline is adopted.
- Large_declared, large_undeclared and receive_credit each have one
  DATA-bearing upload stream; their other observation requests have no DATA.
  This preserves the accepted aggregate outstanding stream-debt bound65535.
  Other cases' entire DATA flow is below that bound. Do not spend a connection
  refund as permission to violate the independent aggregate stream-debt bound.
- Apply task-5e-barrier-source-handoff.md literally: flush preceding actions,
  send one same-connection observation, fail on mismatch, no retries/polls.
  Continue100 precedes positive DATA. Receive-credit waits add no heads.
- Disconnect replacement is forbidden until the later close adapter proves
  successful TLS unwrap AND plain TCP EOF. A supplied pure test record proves
  only adapter ordering. Preserve separate old debt and cumulative case counts.
- Collect67 statuses plus one metrics response exactly once before active
  shutdown signal, preserving the held request. Partial main selection without
  active shutdown also appends this collection under the existing deadline.
  It does not earn shutdown_idle. No observation requests follow signal.
- Retain aggregate counts/hashes/metadata only: no whole upload/output bodies,
  per-DATA histories or unbounded per-read evidence. Bounded small observation
  bodies and exact public echo/delayed literals remain necessary.

## Proof and delivery

Preparation is caller-owned pure data and the pinned in-memory public codec
only. No socket, SSLContext, certificate/file setup, native build/server,
process-ownership/close-adapter execution, transfer, descriptor, kernel or
fault/cancel/schedule/race/panic/leak experiment is released here.

Prove the actual serialized case action order and exact counts. Focus negative
tests on the named barriers, Continue, paused EOF, late credit, reset ordering,
replacement boundary, stale controls/reuse, final68 and held shutdown. Exercise
default and subsets; a synthetic response is not native fixture evidence.
Retain new-behavior RED/GREEN, normal/-O outcomes and complete source identities.
All authored reusable helpers have main guards and actual inert import proof;
no classes/inheritance/custom exception classes/assert proof statements.

Report changed files/APIs, exact commands/raw outcomes, source bindings,
intermediate failures, final snapshot and remaining facts. Native runtime
closure, independent review and the separately released two-child all40 run
remain subsequent required work. Full milestone scope is unchanged.
