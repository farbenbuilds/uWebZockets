# Combined40 finite barriers: focused source handoff

Originalarchitect /root/architect_h2_live_acceptance, read-only followup. No edits,
imports, tests, builds or native operations. Frozenproduction locators below are
under /tmp/uwz-task4d-fix1-frozen (fc69). Source supports proposed finite
barriers: no J/C/budget/deadline changes and no new async observation route needed.
These are source-order facts, NOT a new runtime measurement.

## Required caller ordering

Finish serializing preceding HEADERS/DATA/trailer/RST action; flush all queued
bytes with bounded data_to_send(amount=8192) BEFORE enqueueing observation;
send ONE status/metrics GET on SAME connection; require exact expected record,
mismatch fails immediately. No polling/retry/extra requests. sendall alone does
not prove server processing; receiving later observation proves preceding frame
processing through synchronous parser/driver order, even with fragmentation.

Source chain:
- core/tcp.zig511-525 routes successfulSSL_read synchronously.
- http2/server.zig754-802 completes/processesframe before advancingnextframe.
- server1095-1130 completesentireheaderblockbeforereturn.
- server1390-1402 selectsstreaming/start_body1557-1593 invokesheadcallbacksync.
- core/http2_upload.zig120-162 admission/reserve/begin/commit-or-rollback sync.
- tcp802-840/926-940 laterbufferedstatusGET dispatches synchronously.

## Exact replacements

| Case/barrier | Serialized action before ONE observation | Exact observation/count |
| --- | --- | --- |
| quota holders | BothholderHEADERS/noEND | Metricsactive2, firstof4metrics |
| quota holdercompletion | BothP32+END, receivebothfinals | Metricsactive0, second |
| quota recoveryadmission | BothrecoveryHEADERS/noEND | Metricsactive2, third |
| quota recoverycompletion | BothP32+END, receivebothfinals | Metricsactive0, fourth |
| observedlimitprefix | Unpadded32/noEND | Statusaccepted32/end0/cancel0/readyactive, THENoffendingbyte33 |
| partialpausefirst | First8192 | Statusaccepted7/paused |
| partialpausequeuedEOF | Remaining4097+END | Secondstatus equalsfirstcompleterecord |
| finalpause | P32+END | Statusaccepted32/paused/end0, THENresume |
| beginpauseempty | HEADERSnoEND thenemptyDATAEND | Begun/paused/accepted0/chunks0/end0, THENresume |

Retainedcorrectedfixture/helper locators:
admission/fix1/cases.py78-82metricswait,64-70prefixwait;
pause-control/fix1/run_live.py244-253pausechecks. They are under existing
integration-owned. Use actual final published sources when schemas differ from
initial top-level files. Counts stayquota11/11, observedlimit5/5,
partialpause7/7, finalpause/beginpauseempty6/6.

Reservationrelease: http2_upload201-221 callsfixtureterminal, finishesBodyState,
releasesrouterreservationbefore returning. Failedbeginrollback154-158 before
refusalemission. LaterrecoveryHEADERS onthatconnection cannotrace release.

## DATA, EOF, resume and Continue

server1596-1634 separatespadding, callsdata, validatesprogress, queuesremaining,
recordsEOF, drainseligibleinput andattemptscreditpublication synchronously.
http2_upload165-181 observesfreshlogicalinput/callschunkinline. Exceptions are
explicitpausedreadiness/pendingContinue/existingqueuedprefix. server1637-1680
drainsuntil emptyorpaused; endonlywhenEOFknownandready. LaterGET seesestablished
pause/EOFstate evenifresponse/WINDOW_UPDATE stillpending.

request_body.zig80-85 publicresume changesreadiness/callstargetdirectly;
tcp660-674 callsSession.resume_body; server1481-1488 drains/publishescreditbefore
return. Fixturecontrolresponse follows token call (admission/fix1/profile242-250).
After successfulresume response one laterstatus isenough; this doesnotpromise
allcreditframes reachedclient.

Continuecases MUST receive the singlevalid100 beforepositiveDATA. Otherwise
server1642-1649 maykeepcontinue_pending wheninformationaloutputWouldBlock;
the alternateorderingdoesnotestablishsame barrier. No additionalExpectheaders.

Otherfinite sequences retained:
- Queuedtrailers/padding: first8192->oneaccepted7pausedstatus; padded4097+trailer
  END->oneunchangedstatus. TrailerEOF/drainsyncserver1256-1297, pausedguardnoend.
- Receivecredit: all65535permittedbytes->existinghealth+oneaccepted0pausedstatus;
  resume->oneaccepted65535readystatus; waitonlylegitimaterefundframes forpublic/
  independentcredit, THENsendbyte65536. J/C7/7, zeroextraheadsforrefundwait.
- Concurrentroutes: holderstatusafterDATA16, metricsafterotherrouteHEADERS,
  holderstatusafterothercompletion, holderstatusafterresume. credit/fix1/cases84-104
  alreadyfinite/J/C13/13.
- Metadata: eachserializedDATA/trailerstep->onepausedstatus.
- Publiccancel/peerreset: subsequent sameconnectionstatus followssyncterminal;
  incomingRSTserver1045-1056 notifiesbefore return; localcancel send_reset2148-2164
  notifies/retiresbefore return.
- Sinkerror/invalidprogress/enderror: server1683-1717 terminalbeforefailedDATA/
  EOFreturn; subsequentstatus seesfinalcountersevenifRSToutputpending.
- Reuse/control: eachstatus follows earlier sameconnectioncallback/control,
  retainallstaleoperationsequences.
- Activeshutdown: DATA32->oneaccepted7pausedstatus; 67statuses+metricsBEFOREsignal,
  no observationrequestafter signal.

Incoming-onlywaits forresponsecompletion/100/refundframes/EOF remainboundedby
existingbyte/read/deadlinecontracts; they are notrequest-producingpoll loops.

## Credit implication limits

server1628 releasesdirectacceptedbytesaftercallback/progressvalidation;
1667-1670 releasesqueuedcapacityafteracceptedconsumption;1732-1754 publishes/
commitspositivecredit separatelyperconnection/stream. Forunpaddedstill-open,
non-resetrequestwithnootherstreamcreditsource, fullstreamrefundofsentprefix
provesstorage releasedbyacceptedconsumption. It doesNOTproveSHA/callbackcount/
metadata/end/quota release. Paddingrefundablebeforelogicaldelivery1598-1599;
reset/error/discard returnsconnectioncapacitywithoutacceptance; occupiedblock
prefixcanremainunrefunded; final-bytepausedcanrefundacceptedbyteswithoutend.
Keepobservedlimitstatusbarrier; refundwaitoptionalcorroboration, notJ/Cchange.

## Disconnect cross-connection boundary

TLSunwrapaloneinsufficient: serverclose_notify mayprecede H2terminalization.
Requireexistingfullsequence: originalsend32->oneaccepted7pausedstatus;
strict_close.unwrap_eof successfullyunwraps AND plainrecv(8192)==EOF, closes;
ONLYTHEN replacementTLS/h2+health; one replacementstatuscancel1/end0/peer_closed/
inactive; retainstalecontrols/recovery. OriginalJ/C3/2,replacement22/22.

Source: tcp546-551 stampspeer_closed;2416-2436 TLSshutdown/drainedclose;
3212-3228 H2close_body_inputs BEFOREsocketteardown; server1502-1533 synchronous
terminalnotifications; tcp3282-3289 laternativesocketclose. Retained
strict_close.py15-29 requiresunwrapsuccessANDsubsequentTCP EOF, so serverEOF
follows H2cancelcallback. No crossconnectionstatuspoll required.

## Preparation acceptance and ruling

Newcombinedclient tests mustprove actualserializedactionorder/oneGETperbarrier/
failonmismatchwithnoretry/100prerequisite andnoreplacementbeforeunwrap+EOF. Do not
addasyncobservationtoken: no remaining source-order gap justifies it.
Root adopts these source-supported finite sequences as the existing combined
schedulecontract. No new productAPI/requestsemantics/quotas/metadata assumptions
orbudgets/deadlines/capacity changes. Actualfull40 execution remainsfuture.
