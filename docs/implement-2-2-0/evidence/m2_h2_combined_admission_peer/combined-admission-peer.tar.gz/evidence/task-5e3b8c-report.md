# Shared independent admission peer: unit 8c

Implemented remaining-peer plan unit 3 for the nine admission schedules. This is pure in-memory client/codec evidence with supplied synthetic application and transport facts. It does not establish actual default/all40 execution, native fixture behavior, product adoption, or M2 completion.

Released BASE: `a4c347845b79a313e0d09fa91cf783b5434397e7` (provided by Root; this worker ran no Git command). The pre-edit source inventory exactly matched `docs/implement-2-2-0/evidence/m2_h2_combined_pause_peer/manifest.json`.

## Ownership and files

Changed only this source module:

`/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_admission.py`

Final SHA256: `1364d2fc6e732b6cbb3fc10b7fb5a8948fb954848616824e01d6af2b3f121fed`.

Added only the authorized evidence directory and this report:

- `/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/admission-peer/`
- `/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8c-report.md`

The evidence directory contains three current Python helpers: `capture.py`, `proofs.py`, `audit.py`. Recorder and audit originate from the accepted pause-peer pattern, adapted inside this unit. Historical helper/source versions remain as text snapshots. No helper is exempted from current-depth or inertness checks. `evidence-inventory.json` hashes 367 other files at inventory generation; it excludes itself. `commands-summary.json` indexes all 24 captured check commands with exact command metadata, exit status, raw file hashes and restoration receipt hashes.

Inventory remains 40 modules: one changed and 39 unchanged. No handler, model, core peer, catalogue, codec, fixture, capacity, dependency pin or shared import inventory was edited. Graphify reported no relevant changes and left graph output untouched.

## Context and initial freeze

Read the actual AGENTS/CODING_CONVENTION, developer role, accepted remaining-peer shared contract/unit 3, aggregate handoff, and narrow incremental/TDD/interface-design/codebase-design workflows. Used the phase-routing, code-review and debugging workflows as relevant. Some initial batched tool displays were truncated; focused reads recovered the relevant text, with the phase-router full-read repeated during self-review. The already-known generic DoD-reference qualification in the brief remains unchanged.

Graphify preceded new codebase questions. The supplied source, prior evidence helper and immutable model paths supplied the concrete implementation context. No external model CLI or new agents were used.

Before editing test_admission.py or executing acceptance RED, `restore-setup.json` established the immutable input identities and `capture.py --freeze` retained:

- exact accepted source40 map plus all 40 source bytes under `baseline/`;
- fresh exhaustive `baseline/prior_history.json`, excluding only this new unit: 10,118 prior evidence files;
- exact copied 119-entry authority in `baseline/immutable-inputs.json`.

Restoration independently checked 118 physical identity rows, 113 unique resolved files, 42 ordered codecs, and the pinned interpreter. Every dependent Python proof/check/audit shell began with `set -e` and the Root restorer, using a unique absolute `restore-*.json` receipt in this directory. Temporary restoration persisted only within each command; no later command inferred persistence.

## Implementation and independent facts

`new_peer(case, *, app, prior, now, clock, final=False, fault=None)` returns exactly `{connection,state}`. Connection has exactly protocol/send/receive/now/owned/tls/alpn, initialized through the pinned protocol factory, with supplied owned=True/TLSv1.3/h2 facts. Startup SETTINGS and ACK are queued for ordinary receive. Construction never calls clock, adapter dispatch/observe/final, or mutates the app.

The constructor validates supported case, prior selection, exact canonical app shape, final/clock/time/fault inputs, persistent records, outputs, binding and earned prior head totals before state setup. It reuses `test_core_peer.new_app()` for default drivers. There is no legacy two-key app adapter or competing application constructor. The app reference, output observations and relative binding survive all schedules.

The former nested peer and model-selected `completed()` recipe are deleted. Peer state comes from decoded validated requests:

- HEADERS validates exact method, target, pseudo-header order, content-length, expect, stream ID and END distinction before earning middleware/admission/begin facts. Successful nonterminal metadata still has zero accepted bytes, chunks and terminal counters.
- Declared refusal is earned at HEADERS without a begin or DATA. Observed refusal requires the offending non-END DATA.
- The 32-byte observed prefix earns actual byte/hash/chunk facts while remaining active and uncancelled. The status response must be delivered, not merely queued, before byte 33; every barrier is checked before changing payload counters/digests/app facts.
- The zero observed refusal has one offending non-END byte and accepts none. Successful limit/recovery bodies have exactly 32 END bytes. Empty HEADERS END remains distinct from empty DATA END.
- Refusal final HEADERS precedes its separate NO_ERROR reset. Normal refusals generate no informational response or response DATA. The four finite faults modify their named serialized observation only.
- Metrics aggregate actual persistent records and head totals. The peer never reads client context/capture to manufacture truth.

Online path and DATA cursors replace histories. State retains at most two upload summaries and incremental digests, parser <=8201 bytes, input/frame payload <=8192, <=2 pending packets/16384 bytes with each packet <=8192, HPACK table/list bounds, and scalar highwaters/receipts. Receive cap is head_limit+2 (startup plus at most one additional separate refusal reset); byte cap is that count times 8192. Queued and delivered response/reset counters are distinct. Delivered HEADERS/reset receipts count actual returned frame bytes; fault-mode informational HEADERS remain malformed observation controls, not normal aggregate claims.

Final permission does not execute or select completion. Final68 requires ordinary request order, completed required uploads/recovery and delivered prior responses on the same protocol/parser/request/response ledgers, debt, receive accounting and deadlines.

## RED/GREEN and correction chronology

Every captured directory has exact argv/env/cwd/restoration reference, source-before and source-after maps, current source bytes, helper/check bytes and AST, separate stdout/stderr and exit JSON. Every captured before/after pair matched exactly.

| Captured command directory | Exit | Meaning |
| --- | ---: | --- |
| red-constructor | 1 | Frozen baseline lacks new_peer; pre-effect interface RED only, not a behavioral defect |
| red-metadata | 1 | Frozen baseline leaves middleware/attempts/begins zero before first DATA; behavioral RED |
| green-constructor | 0 | Shared constructor interface/pre-effect proof |
| green-metadata | 0 | HEADERS metadata before DATA proof after extraction |
| green-schedules | 0 | All original standalones, shared chain and negatives |
| red-delivery | 1 | Initial extracted implementation deferred delivered HEADERS receipt until the reset packet; direct RED preserved before fix |
| green-direct | 0 | Per-returned-frame delivery accounting fix and direct acceptance |
| cover-admission-normal / cover-admission-optimized | 0 / 0 | Four required covering checks, with next row |
| cover-imports-normal / cover-imports-optimized | 0 / 0 | All 40 AST/main-guard/inert-import checks |
| final-direct-normal / final-direct-optimized | 0 / 0 | Initial complete direct proofs; retained as historical after proof-only review corrections |
| audit-normal / audit-optimized | 0 / 0 | Initial audits using accepted visual elif nesting convention |
| red-metadata-priority | 1 | Corrected original-call/error-priority probe still reproduces metadata defect against exact frozen baseline source bytes |
| current-direct-normal / current-direct-optimized | 0 / 0 | Corrected probe plus explicit original-error identity/call-count/restoration proof |
| current-audit-normal / current-audit-optimized | 0 / 0 | Intermediate audits, retained; not substituted for the final strict helper audit |
| strict-direct-normal / strict-direct-optimized | 0 / 0 | FINAL current helper direct proofs |
| strict-audit-normal / strict-audit-optimized | 0 / 0 | FINAL strict current-helper, source/input/history and covering-receipt audits |

Self-review corrected the metadata proof wrapper: it now snapshots pre-DATA facts, calls the original operation exactly once, and only then asserts on the earlier snapshot. Original exceptions take priority and instrumentation is restored in finally. An explicit failing original-operation probe verifies exception identity, one invocation and restoration. The corrected probe's retained legacy RED executes only the archived Python test source through the pinned in-memory codecs, not any old native runtime or binary.

Root's independent pre-review metadata check then identified that the helper's opt-in if/elif dispatch reached depth four under its strict AST counter. Root retains its failed metadata audit. The worker preserved `proofs-before-flat-dispatch.txt` and `audit-before-strict-depth.txt`, replaced the dispatch with early returns, and added the strict recursive depth counter alongside the accepted auditor. Neither auditor was weakened; all three live helpers now satisfy both counters at maximum three. The strict direct/audit pairs were rerun with fresh same-shell receipts. No source module changed during either helper correction, so the exact-source-bound four module covering checks remain current.

## Exact command and environment contract

For every captured check, the shell first ran:

```sh
set -e
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore ABSOLUTE_UNIQUE_RECEIPT
```

It then invoked this unit's `capture.py --run NAME ABSOLUTE_MODULE normal|optimized [ARGS]` using the pinned interpreter with `-B -S`, `PYTHONDONTWRITEBYTECODE=1`, and the exact PYTHONPATH below. Capture launches the child with the same pinned interpreter, `-B -S`, optional `-O`, absolute module and explicit arguments. Exact expanded argv, environment and cwd for every invocation are retained in each `command.json` and `commands-summary.json`; those records are the command authority.

```text
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
cwd=/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
interpreter_sha256=4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601
ordered_codec_digest=0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473
```

Final required children are absolute `test_admission.py` and `test_imports.py`, each normal and optimized. Final direct children are absolute `evidence/admission-peer/proofs.py --check`, each normal and optimized. Final audit children are absolute `evidence/admission-peer/audit.py --audit ABSOLUTE_STRICT_AUDITED_DIRECTORY`, each normal and optimized. All eight final executions exit zero with empty stderr.

Process qualification: one inline pathlib-only helper edit (`restore-edit-probe-priority.json` shell) accidentally omitted the integration-client component from its PYTHONPATH. It imported only pathlib and edited proof/audit text; it ran no candidate check. All executable proofs/checks/audits used the exact required path, including every subsequent correction and final execution. This deviation is disclosed rather than represented as an exact-environment check.

Graphify's supplied command was used for scoped queries. `graphify update .`, with its supplied PYTHONDONTWRITEBYTECODE/PYTHONPATH launcher, exited zero after same-shell `restore-graphify.json`; separate `graphify.stdout.txt`, `graphify.stderr.txt`, `graphify.exit.txt` are retained. It reported no relevant code changes and left graph output untouched. No model/API extraction was run.

## Observed acceptance and self-review

Final ordinary observations, identical to existing printed counts:

| Case | Heads | Request DATA bytes |
| --- | ---: | ---: |
| empty_headers | 3 | 0 |
| empty_data | 3 | 0 |
| empty_declared | 3 | 0 |
| limit_declared | 3 | 32 |
| limit_undeclared | 3 | 32 |
| limit_declared_reject | 4 | 32 |
| limit_observed_reject | 5 | 65 |
| zero_declared_reject | 4 | 0 |
| zero_observed_reject | 4 | 1 |

The actual nine-case shared chain earns 32 ordinary heads plus final68 = 100 heads. The final-case ordinary print remains 4 as before; it is not mislabeled as the aggregate count. Exact negatives remain `reset order`, `invalid HEADERS`, `response body bound`, and `record mismatch: bytes`.

Direct proofs cover constructor inertness/exact shape, invalid case/prior/app/fault/final/time/clock rejection, independent metadata and terminal timing, received prefix barrier before offending byte, empty-END distinctions, malformed headers/streams/flags/DATA, repeated invalid-input no-growth, parser/pending/packet/receive/HPACK bounds, actual shared prior cases, independent fresh connection ledgers, final identities/debt/deadlines/cumulative receive caps and early/unpermitted final rejection. A copied historical producer fixture separately proves retained output/binding references and bytes across admission/final; it is explicitly supplied synthetic prior state and does not claim producer traffic was executed here.

Self-review checked correctness against the shared contract, preserved diagnostics/counts/hashes/ordinals/recoveries, app ownership and no context-oracle coupling, bounded storage, error propagation, dead nested code/import removal, and exact source/evidence scope. The only discovered implementation defect was the delivered-HEADERS receipt timing, reproduced and fixed. Proof instrumentation and strict dispatch-depth corrections are recorded above. No unresolved implementation API/ownership gap was found. Root's fresh source/spec/quality review remains independent and required.

Final audits establish source40, one changed/39 unchanged, all 40 AST/import guards, all three current helpers guarded and inert under import and main empty/foreign argv, maximum helper nesting three under both counters, all 119/118/113/42 input identities, and all 10,118 frozen prior-evidence hashes unchanged. All failures and intermediate source/helper/raw receipts remain retained.

No Git, publication, server, socket/TLS operation, real clock, native/build/runtime, install, network, external model CLI, or worker delegation was performed. Import effect guards import socket/ssl modules only to reject effects. Python subprocesses ran only the recorded pinned pure-client checks. Formatting, conventions, release-version, Zig tests and the full native/platform/compliance gates were not run because this release explicitly prohibits native/build execution; they remain mandatory at Root's later released phase, not waived.

The slice is ready for Root's independent review, publication accuracy pass, commit and immediate push. Actual default/all40, broader combined acceptance, runtime closure/native acceptance, production adoption and full milestone completion remain later gates. The full goal remains active.
