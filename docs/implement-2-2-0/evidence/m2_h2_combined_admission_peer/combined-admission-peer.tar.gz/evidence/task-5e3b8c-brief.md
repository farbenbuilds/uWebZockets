# Shared independent admission peer

Released after 8b review, publication and push. BASE:
a4c347845b79a313e0d09fa91cf783b5434397e7.
Accepted source40 manifest:
docs/implement-2-2-0/evidence/m2_h2_combined_pause_peer/manifest.json.
Root commit audit: task-5e3b8b-root-commit-audit.json in this directory.

This implements remaining-peer plan unit 3 in
task-5e3b-all40-peer-plan-report.md. Read that unit and its shared contract,
plus task-5e3b-aggregate-acceptance-notes.md. This prepares nine peer cases;
actual coordinator/default/all40, native, adoption and M2 remain later gates.

Own ONLY
/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_admission.py,
NEW evidence/admission-peer under that same directory, and
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8c-report.md.
Inventory stays 40: one changed, 39 unchanged. No other module, model, core,
handler, fixture, codec, pin, product or limit edit. Report an exact additional
ownership/API gap before editing. You are not alone: preserve others' work and
all historical source/raw evidence. No agents/Git/publication/native/network.

Promote new_peer(case, *, app, prior, now, clock, final=False, fault=None) for
empty_headers, empty_data, empty_declared, limit_declared, limit_undeclared,
limit_declared_reject, limit_observed_reject, zero_declared_reject,
zero_observed_reject. Return exactly {connection,state}; connection exactly
protocol/send/receive/now/owned/tls/alpn, with pinned initialized protocol and
supplied owned=True/TLSv1.3/h2 facts. Queue startup SETTINGS and ACK for ordinary
receive. Constructor never calls clock, adapter dispatch/observe/final, mutates
application state, or installs selected completion.

Accept exactly the canonical app from test_core_peer.new_app(): records, heads,
outputs, binding. Validate case/prior/final/fault/app before mutation. Prior
validates independently earned persistent state; never seed it. Preserve parsed
output/binding. Keep check(case, *, app=None, prior=(), final=False, fault=None)
and same app-reference return, existing printed counts and negatives. Default
driver app upgrades old records/heads shape to the canonical four-key shape;
do not add a legacy adapter without an actual caller requiring it. Delete the
old nested peer, dead imports and unbounded path/request/frame/read histories.

Earn facts independently from decoded validated serialized traffic. HEADERS
earns metadata/middleware/admission/begin state where applicable, with accepted
bytes still zero. Exact declared refusal can terminate at HEADERS. Observed
refusal waits for the offending DATA. DATA earns logical byte count, accepted
prefix, hash/chunks/ordinal and END facts; do not install future cancellation,
terminal, stale or recovery facts. Use immutable contracts for validation, not
model.record(selected=True) as an observation recipe.

Preserve exact header order, method/target/content-length, expect on declared
refusals, HEADERS-END versus empty DATA-END distinction and all recovery
requests. limit_observed_reject receives 32 non-END bytes, exposes accepted
prefix status, then receives the offending 33rd byte; enforce that barrier
before mutating on the offending byte. zero_observed_reject receives one
non-END offending byte. Successful limit bodies are 32-byte END. Preserve all
original frame counts, incremental payload hashes, and empty-body cases.

Refusal final HEADERS precedes NO_ERROR reset with no informational response or
response DATA allowance. Preserve finite faults and exact diagnostics:
reset_first -> reset order; continue -> invalid HEADERS;
refusal_data -> response body bound; bad_prefix -> record mismatch: bytes.
Faults change only their named serialized observation; normal peers remain
independent and strict. Existing main's nine standalones and actual nine-case
shared app sequence with final68 must continue crossing this shared peer.

Use bounded online cursors, finite stream summaries and incremental hashes;
parser cap 8201, frame/payload cap 8192, HPACK bound and finite pending/packet/
receive limits derived from concrete schedules and existing policies. Reject
before growth and on repeated invalid input. Retain highwater and distinguish
queued versus delivered response/grants. Final permission requires the actual
ordinary schedule first, then final68 on the same protocol/parser/ledgers/debt/
read cap/deadlines. Metrics derive actual app records/heads, not model-selected
metrics. Peer truth never reads client context/capture. Any needed driver-side
assertion wrapper calls original once, preserves result/error priority and
restores instrumentation on failure.

Before editing: read actual AGENTS.md, CODING_CONVENTION.md, developer role and
narrow incremental/TDD/API/codebase-design workflows plus accepted context.
Use Graphify before a NEW codebase question/search/read; supplied paths are
located. Freeze the exact accepted current 40 sources and 119-input identity,
and a fresh exhaustive prior-evidence hash map excluding only this new unit.
Freeze before actual acceptance RED; constructor absence is a pre-effect RED,
not a behavioral defect. Each discovered defect needs the real source/RED
before its fix; preserve every failed/intermediate command/source/raw artifact.

After last source edit retain FOUR focused checks: test_admission.py and
test_imports.py, each normal and -O. Other suites only for an identified
dependency or unanswered concern. Add meaningful direct constructor/prior/
metadata-vs-DATA/refusal-order/final/bounds/retention proofs as needed. Actual
shared prior cases must be earned from traffic; supplied fixtures remain
explicitly synthetic. Every check has exact argv/env/cwd, 40-source before and
after maps, separate stdout/stderr/exit and same-shell restoration receipt.
All 40 source AST/import guards, all CURRENT unit helper nesting <=3 and inert
import/empty/foreign argv, 119 authority/118 physical/113 resolved/42 ordered
codecs, frozen source and prior-history preservation must be audited. No live
helper is exempt as historical; preserve old bytes before correcting it. No
classes/assert/custom exceptions/global mutable containers/dead code/camelCase/
silenced errors/forwarding wrappers or weakened bounds, tests or lint.

Temporary inputs reset across continuations. EACH dependent Python proof,
audit or check exec_command shell must start with set -e and run the Root
restorer below, with a NEW absolute receipt, then its operation IN THAT SAME
SHELL. Never infer persistence from a prior Root command.

/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT

Pinned interpreter SHA256:
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
All direct Python, including source edits, uses this interpreter with -B -S;
optional -O for optimized. Exact PYTHONPATH:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases

Graphify invocation:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650

No native/build/server/socket/SSLContext/TLS-close/real-clock/process ownership/
kernel/fault scheduling/race/panic/crash/leak/old-runtime/install/network runs.
Only pinned in-memory codecs and supplied synthetic app/transport/process
facts. No additional named-skill drift is established by the known missing
generic DoD reference: explicit project gates/exact scope remain authoritative,
full native/project/platform gates mandatory later, not waived.

Write the full report at the owned report path: exact files/commands/raw/exits,
RED/GREEN chronology, all current source/check/input/history/helper audits,
self-review and actual gaps. Return concise DONE or specific concerns/context/
blocker under 15 lines. Remaining work alone is not missing context. Root owns
fresh source review, publication accuracy, commit and immediate push before
releasing the next serial peer unit. Full goal remains active.
