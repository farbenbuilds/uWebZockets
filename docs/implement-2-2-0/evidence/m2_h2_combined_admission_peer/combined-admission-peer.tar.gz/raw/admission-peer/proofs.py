"""Explicit direct admission peer proofs using supplied synthetic facts."""
import copy
import catalogue
import hashlib
from pathlib import Path
import sys
import adapter
import hpack
import model
import test_admission as peer
from test_core_peer import frame, new_app, require


def constructor():
    app = new_app()
    before = copy.deepcopy(app)

    def no_clock():
        raise RuntimeError('constructor called clock')

    result = peer.new_peer('empty_data', app=app, prior=(), now=1, clock=no_clock)
    require(set(result) == {'connection', 'state'}, 'peer shape differs')
    require(set(result['connection']) == {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'}, 'connection shape differs')
    require(app == before, 'constructor changed app')
    require(result['state']['cursor'] == 0 and result['state']['pending'], 'constructor selected completion')
    print('constructor is pre-effect and uses canonical app')


def metadata(driver=None):
    app = new_app()
    original = adapter.send_data
    seen = []

    def send(context, stream, data, end):
        item = dict(app['records']['limit_declared'])
        result = original(context, stream, data, end)
        seen.append(stream)
        require((item['middleware'], item['attempts'], item['begins'], item['bytes'], item['ends']) == (1, 1, 1, 0, 0),
                'HEADERS did not earn metadata before DATA')
        return result

    adapter.send_data = send
    try:
        (peer.check if driver is None else driver)('limit_declared', app=app)
    finally:
        adapter.send_data = original
    require(len(seen) == 1, 'metadata proof missed DATA')
    print('HEADERS metadata and DATA completion are causally separate')


def probe_error_priority():
    original = adapter.send_data
    failure, calls = ValueError('original DATA error'), []

    def fail(_context, _stream, _data, _end):
        calls.append(1)
        raise failure

    def driver(_case, *, app):
        require(app['records']['limit_declared']['begins'] == 0, 'priority proof needs invalid metadata')
        adapter.send_data(None, 3, b'x', False)

    adapter.send_data = fail
    try:
        try:
            metadata(driver)
        except ValueError as exc:
            require(exc is failure, 'probe replaced original error')
        else:
            raise ValueError('probe swallowed original error')
        require(calls == [1] and adapter.send_data is fail, 'probe call count or failure restoration differs')
    finally:
        adapter.send_data = original
    print('metadata probe calls original once, preserves its error identity and restores instrumentation on failure')


def open_peer(case, final=False, *, app=None, prior=(), health=True):
    app = new_app() if app is None else app
    result = peer.new_peer(case, app=app, prior=prior, now=1, clock=lambda: 2, final=final)
    connection = result['connection']
    context = adapter.open_case(case, connection['protocol'], connection['send'], 1, 30001, 900001, selected_before=prior, clock=lambda: 2)
    adapter.observe(context, *connection['receive']())
    if health:
        adapter.health(context, connection['receive'])
    return app, result, context


def start_upload(context, tag, end=False):
    contract = model.request_contract(tag)
    headers = [] if contract['declared'] is None else [('content-length', str(contract['declared']))]
    if tag in ('limit_declared_reject', 'zero_declared_reject'):
        headers.append(('expect', '100-continue'))
    return adapter.start(context, contract['method'], contract['target'], headers, end, True,
                         0 if tag.endswith('_reject') else 4095, status=413 if tag.endswith('_reject') else 200,
                         policy='refusal_after_final' if tag.endswith('_reject') else 'healthy')


def delivery():
    app, result, context = open_peer('limit_declared_reject')
    state, connection = result['state'], result['connection']
    start_upload(context, 'limit_declared_reject')
    before = state['responses_delivered']
    packet, _ = connection['receive']()
    require(packet[3:5] == bytes((1, 5)), 'refusal first frame differs')
    require(state['responses_delivered'] == before + 1 and state['resets_delivered'] == 0,
            'delivered refusal HEADERS receipt missing')
    packet, _ = connection['receive']()
    require(packet == frame(3, 0, 3, bytes(4)) and state['resets_delivered'] == 1, 'NO_ERROR reset delivery differs')
    require(app['records']['limit_declared_reject']['begins'] == 0, 'declared refusal began')
    print('final refusal HEADERS delivered before NO_ERROR reset, no informational or body')


def final_boundary(peer, context):
    state, stage = peer['state'], context['stage']
    identities = {name: context[name] for name in ('protocol', 'raw', 'request', 'credit', 'records', 'stage')}
    deadlines = stage['case_deadline'], stage['whole_deadline']
    reads, size = stage['reads'], stage['bytes']
    debt = context['request']['connection_debt'], context['request']['stream_debt_total']
    seen = [0, 0]

    def receive():
        require(all(context[name] is value for name, value in identities.items()), 'final changed connection identities')
        require((stage['case_deadline'], stage['whole_deadline']) == deadlines, 'final refreshed deadlines')
        require(stage['reads'] == reads + seen[0] and stage['bytes'] == size + seen[1], 'final reset cumulative receive cap')
        result = peer['connection']['receive']()
        seen[0] += 1
        seen[1] += len(result[0])
        return result

    require(adapter.final_collection(context, receive) is None, 'ordinary final return changed')
    require(state['final_requests'] == stage['final_registered'] == 68 and stage['final_complete'], 'final count differs')
    require((context['request']['connection_debt'], context['request']['stream_debt_total']) == debt, 'final erased debt')
    require(stage['reads'] == reads + seen[0] and stage['bytes'] == size + seen[1], 'final receive accounting')
    require('final_observations' in context, 'missing retained actual final capture')


def retained_supplied_fixture():
    # Explicit historical supplied facts; this does not execute producer_reuse.
    app = new_app()
    app['records'] = model.records(('producer_reuse',), 'before')
    for tag in ('producer_reuse', 'producer_reuse_next'):
        app['records'][tag].update(chunks=1, max_span=32)
    producer = app['outputs']['producer_reuse']
    producer.update(offset=16777313, invocations=2051, attempts=4099, writes=2049, blocked=2050,
                    pending=2050, terminal_attempts=1, terminals=1, checks=2051, after_reuse=1,
                    binding_index=0, binding_generation=7, armed=True, done=True, sha256=model.PRODUCER_HASH)
    app['binding'] = dict(tag='producer_reuse_next', binding_index=0, binding_generation=8)
    app['heads'] = catalogue.case_budget('producer_reuse')['heads']
    copied = copy.deepcopy(app)
    outputs, binding = copied['outputs'], copied['binding']
    supplied, peer, context = open_peer('empty_data', app=copied, prior=('producer_reuse',), final=True, health=False)
    adapter.run_case(context, peer['connection']['receive'])
    final_boundary(peer, context)
    require(supplied is copied and copied['outputs'] is outputs and copied['binding'] is binding, 'retained references replaced')
    require(outputs == app['outputs'] and binding == app['binding'], 'supplied retained output or binding mutated')
    require(app['records']['empty_data']['middleware'] == 0, 'copied application mutated original')
    print('explicit supplied historical producer fixture: copied retained outputs/binding preserved; no prior producer traffic claim')


def rejects(action, expected=None):
    try:
        action()
    except ValueError as exc:
        require(expected is None or str(exc) == expected, 'unexpected rejection: ' + str(exc))
        return
    raise ValueError('invalid action accepted')


def constructor_rejections():
    changes = ({'case': 'ready_buffered'}, {'case': []}, {'prior': ('limit_declared',)}, {'prior': ('unknown',)},
               {'prior': ('empty_data', 'empty_data')}, {'final': 1}, {'fault': 'unknown'}, {'fault': []},
               {'fault': 'bad_prefix'}, {'now': True}, {'now': -1}, {'clock': None})
    for changed in changes:
        app = new_app()
        before = copy.deepcopy(app)
        args = dict(case='empty_headers', app=app, prior=(), now=1, clock=lambda: 2)
        args.update(changed)
        rejects(lambda: peer.new_peer(**args))
        require(app == before, 'invalid constructor mutated application')
    for key in ('records', 'heads', 'outputs', 'binding'):
        app = new_app()
        del app[key]
        before = copy.deepcopy(app)
        rejects(lambda: peer.new_peer('empty_headers', app=app, prior=(), now=1, clock=lambda: 2), 'app fields differ')
        require(app == before, 'shape rejection mutated application')
    app = new_app()
    app['heads'] = 3
    rejects(lambda: peer.new_peer('empty_data', app=app, prior=(), now=1, clock=lambda: 2), 'prior heads not earned')
    print('case, prior, final, faults, shape and unearned head totals reject before mutation')


def summary(state):
    return {tag: (item['count'], item['frames'], item['ends'], item['terminal'], item['digest'].hexdigest())
            for tag, item in state['uploads'].items()}


def observed_timing():
    app, result, context = open_peer('limit_observed_reject')
    state, connection = result['state'], result['connection']
    stream = start_upload(context, 'limit_observed_reject')
    item = app['records']['limit_observed_reject']
    require(item['begins'] == 1 and item['active'] and item['bytes'] == item['cancels'] == 0, 'observed metadata claimed future facts')
    adapter.send_data(context, stream, model.payload_span(32, 0, 32), False)
    require(item['bytes'] == 32 and item['sha256'] == model.H32 and item['active'] and item['cancels'] == 0, 'prefix facts differ')
    before, counts = copy.deepcopy(app), summary(state)
    for _ in range(2):
        rejects(lambda: connection['send'](frame(0, 0, stream, b'x')), 'offending byte preceded status barrier')
        require(app == before and summary(state) == counts and state['data'] == 32, 'early offending byte mutated facts')
    status = adapter.start(context, 'GET', '/status/limit_observed_reject', (), True, False, 4095)
    require(state['prefix_queued'] and not state['prefix_delivered'], 'prefix queue treated as delivery')
    rejects(lambda: connection['send'](frame(0, 0, stream, b'x')), 'DATA stream or response barrier differs')
    require(app == before | {'heads': before['heads'] + 1} and summary(state) == counts, 'queued barrier accepted offending byte')
    adapter.finish(context, status, connection['receive'])
    require(state['prefix_delivered'], 'prefix delivery not earned')
    adapter.send_data(context, stream, b'x', False)
    require(item['cancels'] == 1 and item['bytes'] == 32 and not item['active'] and item['reason'] == 'body_too_large', 'observed refusal timing differs')
    require(state['data'] == 33 and state['frames'] == 2 and state['ends'] == 0, 'logical request count differs')
    require(state['uploads']['limit_observed_reject']['digest'].hexdigest() == hashlib.sha256(model.payload_span(32, 0, 32) + b'x').hexdigest(), 'request digest differs')
    app, result, context = open_peer('zero_observed_reject')
    stream = start_upload(context, 'zero_observed_reject')
    require(app['records']['zero_observed_reject']['cancels'] == 0, 'zero observed refused at HEADERS')
    adapter.send_data(context, stream, b'x', False)
    item = app['records']['zero_observed_reject']
    require(item['bytes'] == item['chunks'] == 0 and item['sha256'] == model.EMPTY_HASH and item['cancels'] == 1, 'zero observed accepted offending byte')
    print('accepted32 barrier must be delivered before byte33; early/repeated invalid DATA leaves facts unchanged; zero observed refusal follows DATA')


def empty_timing():
    for case in ('empty_headers', 'empty_declared', 'empty_data'):
        app, result, context = open_peer(case)
        stream = start_upload(context, case, case != 'empty_data')
        item = app['records'][case]
        require(item['ends'] == int(case != 'empty_data') and result['state']['frames'] == 0, 'HEADERS END distinction differs')
        if case == 'empty_data':
            adapter.send_data(context, stream, b'', True)
            require(item['ends'] == result['state']['frames'] == result['state']['ends'] == 1, 'empty DATA END not earned')
        require(item['bytes'] == item['chunks'] == 0 and item['sha256'] == model.EMPTY_HASH, 'empty body facts differ')
    print('empty HEADERS END, declared zero and separate empty DATA END remain distinct')


def send_head(result, entries, flags=5, stream=None):
    state = result['state']
    stream = 2 * state['cursor'] + 1 if stream is None else stream
    result['connection']['send'](frame(1, flags, stream, hpack.Encoder().encode(entries)))


def malformed():
    fields = [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', '/health')]
    for entries in (fields + [(':path', '/health')], fields[:-1], list(reversed(fields)), fields + [('x-extra', 'v')]):
        app, result, _context = open_peer('empty_data', health=False)
        before = copy.deepcopy(app)
        for _ in range(2):
            rejects(lambda: send_head(result, entries), 'request contract differs')
            require(app == before and result['state']['cursor'] == 0 and not result['state']['buffer'], 'invalid HEADERS earned facts')
    for stream, flags in ((3, 5), (1, 4), (1, 13), (0x80000001, 5)):
        app, result, _context = open_peer('empty_data', health=False)
        rejects(lambda: send_head(result, fields, flags, stream), 'request contract differs')
        require(app['heads'] == 0, 'bad stream or flags earned head')
    for payload, flags in ((b'x' * 32, 1), (model.payload_span(32, 0, 32), 0), (b'', 1)):
        app, result, context = open_peer('limit_declared')
        stream = start_upload(context, 'limit_declared')
        before, counts = copy.deepcopy(app), summary(result['state'])
        for _ in range(2):
            rejects(lambda: result['connection']['send'](frame(0, flags, stream, payload)))
            require(app == before and summary(result['state']) == counts, 'invalid DATA earned facts')
    print('exact pseudo-header order, multiplicity, flags, stream and DATA ordinal/payload rejection passed twice')


def bounds():
    _app, result, _context = open_peer('empty_data')
    state, send = result['state'], result['connection']['send']
    for _ in range(2):
        rejects(lambda: send(b'x' * 8193), 'send span differs')
        rejects(lambda: send((8193).to_bytes(3, 'big') + bytes(6)), 'frame payload bound differs')
        require(not state['buffer'], 'oversize grew parser')
    packet = frame(0, 0, 3, b'x' * 8192)
    send(packet[:8192])
    send(packet[8192:8200])
    before = bytes(state['buffer'])
    for _ in range(2):
        rejects(lambda: send(b'xx'), 'parser storage bound differs')
        require(bytes(state['buffer']) == before and state['max_buffer'] == 8200, 'parser overflow changed storage')
    _app, result, _context = open_peer('empty_data')
    state = result['state']
    state['pending'][:] = [b'a' * 8192, b'b' * 8192]
    for _ in range(2):
        rejects(lambda: peer.respond(state, 1, b'c'), 'response queue or body bound differs')
        require(len(state['pending']) == 2 and sum(map(len, state['pending'])) == 16384, 'pending overflow')
    state['pending'][:] = [b'a' * 8193]
    rejects(result['connection']['receive'], 'pending packet bound differs')
    state['pending'][:] = [b'a']
    state['received'] = state['head_limit'] + 2
    for _ in range(2):
        rejects(result['connection']['receive'], 'receive bound differs')
        require(state['pending'] == [b'a'], 'read cap consumed pending')
    state['received'] = 0
    state['received_bytes'] = (state['head_limit'] + 2) * 8192
    rejects(result['connection']['receive'], 'receive byte bound differs')
    require(state['pending'] == [b'a'], 'byte cap consumed pending')
    print('parser8201, frame/payload8192, pending2/16384 and finite receive caps reject before growth repeatedly')


def hpack_limits():
    for payload in (hpack.Encoder().encode(((':path', 'a' * 4097),)), b'\x3f\xe2\x1f'):
        app, result, _context = open_peer('empty_data', health=False)
        before = copy.deepcopy(app)
        for _ in range(2):
            try:
                result['connection']['send'](frame(1, 5, 1, payload))
            except hpack.HPACKError:
                require(app == before and result['state']['cursor'] == 0, 'HPACK earned facts')
                continue
            raise ValueError('HPACK overflow accepted')
    print('HPACK table/header-list bounds reject before facts twice')


def actual_chain():
    app, selection = new_app(), adapter.ADMISSION_CASES
    previous = None
    for index, case in enumerate(selection):
        supplied, result, context = open_peer(case, app=app, prior=selection[:index], final=index == 8, health=False)
        require(supplied is app, 'application reference changed')
        if previous is not None:
            require(all(context[name] is not previous[name] for name in ('protocol', 'raw', 'request', 'credit')), 'new connection shared ledger')
        adapter.run_case(context, result['connection']['receive'])
        model.validate_records(selection[:index + 1], 'before', app['records'])
        require(result['state']['final_requests'] == 0, 'final permission executed final early')
        if index == 8:
            final_boundary(result, context)
        require(result['state']['responses_queued'] == result['state']['responses_delivered'], 'response receipts differ')
        require(result['state']['resets_queued'] == result['state']['resets_delivered'] == int(case.endswith('_reject')), 'reset receipts differ')
        previous = context
    require(app['heads'] == 100, 'nine-case plus final head total differs')
    _app, result, context = open_peer('empty_data', health=False)
    adapter.run_case(context, result['connection']['receive'])
    rejects(lambda: adapter.final_collection(context, result['connection']['receive']), 'request beyond finite schedule')
    _app, result, context = open_peer('empty_data', final=True, health=False)
    rejects(lambda: adapter.final_collection(context, result['connection']['receive']))
    require(result['state']['cursor'] == 0, 'early final earned request')
    print('actual nine-case shared app sequence, independent connections, final68 retained identities/debt/deadlines/caps, early/unpermitted final rejection')


def main():
    if sys.argv[1:] == ['--constructor']:
        constructor()
        return
    if sys.argv[1:] == ['--metadata']:
        metadata()
        return
    if sys.argv[1:] == ['--baseline-metadata']:
        path = Path(__file__).resolve().parent / 'baseline/test_admission.py.txt'
        namespace = dict(__name__='frozen_baseline')
        exec(compile(path.read_text(), str(path), 'exec'), namespace)
        metadata(namespace['check'])
        return
    if sys.argv[1:] == ['--delivery']:
        delivery()
        return
    if sys.argv[1:] == ['--check']:
        constructor()
        metadata()
        probe_error_priority()
        delivery()
        constructor_rejections()
        observed_timing()
        empty_timing()
        malformed()
        bounds()
        hpack_limits()
        actual_chain()
        retained_supplied_fixture()


if __name__ == '__main__':
    main()
