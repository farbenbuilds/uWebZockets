# Initial independent source review

Reviewer: /root/review_h2_wire_oracle. Full returned report follows.

Spec Compliance: Request changes. Task Quality: Request changes.

One Important finding; no Critical or Minor findings.

Important — decoded HPACK bounds are enforced after growth. At
test_wire_oracle.py:252, Decoder.decode() fully decodes headers before the
observer's size check at line255. The pinned codec similarly checks
max_header_list_size only after decoding and appending each header.

A Huffman-compressed literal containing6000 repeated a bytes fits within the
4096-byte encoded-section limit, but its decoded buffer grows to6000 bytes
before rejection. Static trace: pinned hpack.py:640,653 calls decode_huffman;
huffman_table.py:114,124 appends without a bound; hpack.py:542-546 subsequently
checks inflated size. This violates explicit decoded-section bound-before-growth,
although sticky poisoning prevents a successful receipt.

Enforce remaining decoded-section budget before materializing oversized literals
or appending headers, retaining pinned codec boundary and existing valid-input
contract. Add focused regression checking growth boundary rather than eventual
rejection. Existing header-bound test establishes only eventual poisoning.

Evidence checked:

- Complete1676-line review diff, SHA256
  d2d0d4c81ddb20684b21ba9ca0698f39f74d3dc341d5a91eb94c8b72bf844021.
- Task brief/report, binding interface/design, project conventions, reviewer/
  specialist instructions and both required review skills.
- Three current source hashes match report and Root audit.
- Root audit, worker final-audit-normal/optimized JSON and command results,
  four covering argv/stdout/stderr/exit. Exits0/empty stderr, equal before/after,
  stdout/restoration hashes match Root audit.
- Two codec files match immutable authority hashes.
- Root's two failed metadata audits/corrected helper qualifications concern
  audit assumptions, not failed implementation tests.
- Structural lens finds no additional actionable regression: implementation/
  checks separate, files<1000lines, existing sharedsource only inventorychanges.
  No clear simplification justifies expanding slice.

Verification limits:

- No tests/builds/native/network/Git/edits/subagents ran. Static finding needs
  focused regression.
- Retained ownership/history audits inspected; not independently rehashing13038.
- No factoryadoption/defaultall40/aggregate/lifecycle/native/codeccorrectness/
  project/platform/milestone proof. All remain required.
- Publication helpers reviewed as source only; no successful publication or
  delivery-artifact verification yet.
