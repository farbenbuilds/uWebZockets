# Private passive HTTP/2 wire oracle

BASE934f5618d6e313d335b0a1aac152936033451972, feat/implement-2-2-0.
Read this first: requirements for one source-only verification slice.
Exact interface and behavior authority: task-5e3b-oracle-interface-report.md and
task-5e3b-oracle-doubt-artifact.md in this plan workspace. They are binding;
report actual contradiction before implementing. Mechanism passed bounded
design review; do not restart design/inventory/adversarial review.

Own only NEW test_wire_oracle.py and test_wire_oracle_checks.py beneath
/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases,
plus test_imports.py's exact necessary two-name inventory addition. Own NEW
evidence/wire-oracle beneath that source directory, and full report
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b9a-report.md.
Baseline41 -> current43, one existing changed/two new/40 unchanged. No peer,
canonical client/model/core/adapter/coordinator/handler/product/pin/limit edits.
No all40 descriptor builder or execution in this slice. You are not alone;
preserve other work and historical bytes. No agents/Git/publication/native/
network/external CLI. Root handles review, publication and commit+push.

Implement wrap_connection, failure, seal with the exact named tuple field
contracts in the interface report. Explicit miniature test descriptors only.
Immutable tuples/named type aliases and documented field order; explicit
caller-owned dictionaries internally. No classes/customexceptions/asserts/
mutable file containers, hidden globalstate or speculative framework. Use
pinned external hyperframe/hpack primitives with fresh test-owned state; never
canonical wire/raw_observer/output_stage/ledger machinery as independent truth.
Accepted peers remain unchanged. Reject unsupported general CONTINUATION rather
than expanding this into a second HTTP/2 client. Transport fragmentation and
coalescing of the current complete-HEADERS contract remain supported.

No operation at construction; same seven connectionkeys, preserve all original
values except wrapped send/receive. Original exactlyonce FIRST, exact returned
object or exact exception/priority. Full-sendNone contract, ambiguous return
poisons. Underlyingfailure or observerdecode/bounds/internalfailure permanently
poisons completeness without replacing original result/error. No arbitrary
exceptiontext/traceback; later operations pass through. Reentrancy/postseal
attempts poison. Only explicit healthy seal after caller-owned lifecycle window
returns detached immutable receipt; repeated seal never resets/erases anything.
No clock/scheduling/traffic/credit/canonicalstate modification.

Observe actual serialized requestidentity/ordinals, initialheads vs trailers,
DATA logical/flow/padding/hash, SETTINGS vsACK, decodedinfo, resetdirection/code,
creditframes+bytes inbothdirections/scopes+lateclosedgrants. Track independent
debt without treating outgoing response grants as requestrefund. Every complete
frame counts once, successful operation bytes count evenpartialprefixes. Bound
beforegrowth: parser8201/frame8192/HPACKtable+encoded+decodedsections4096,
active8/retained802/u64counters; no payload/frame/read histories. Small END and
complete refusalEND+reset separate.17byte output never small. Distinct final
request/response cursors from descriptor67tags+metrics, allactualordered68
terminalresponses earncollection. Ordinaryterminalpolicy beforefinal and exact
authorized open transportexceptions/debt retention follow interface report.

Focused TDD tests must cover all contract dimensions in that report, especially
original-errorpriority and unknown-prefixpoison, malformed/truncated/coalesced/
split frame bounds, paddedpayload, settingsACK, real100, bothresetdirections,
refusalENDbeforeNO_ERRORreset,17byteoutputexclusion, lateclosedcredit, final
ordering/completion vspermission, transportabandon versuswireterminal and
postseal/reseal. Use external codecs for real byte sequences and explicit
miniature operations for the boundary; no real sockets/process/server/clock.
Test actual behavior, not only constructor presence. Keep smallest readable
implementation; if scope grows beyond a focused helper, report concrete issue.

Before editing read actual AGENTS.md/CODING_CONVENTION.md and relevant local
incremental/TDD/API workflows. Source baseline authority is
docs/implement-2-2-0/evidence/m2_h2_combined_terminal_peer/manifest.json
current_source_files41. Freeze exact41 bytes/hashes and119input identity and
fresh prior-evidence hash map excluding only newunit. Preserve all failed and
intermediate command/source/raws; do not overwrite corrections. New API absence
is pre-effect RED, not behavioral defect. Capture real failing behavior before
fixing discovered logic errors; no fabrication of unavailable pre-edit evidence.

After final source edit FOUR covering commands only: new focused checks and
test_imports, normal and-O. No historical suites absent identified dependency
or unresolved gap. Use exact argv/env/cwd, actual source inventory before/after,
separate stdout/stderr/exit, and same-shell restoration receipt for every run.
Current source AST/import and all CURRENT newunit helper strictmax3/inertimport/
empty+foreignargv, baseline40unchanged/oneinventorychange/twonew,119authority/
118physical113resolved42orderedcodec, priorhistory hashes need final audit.
Do not exempt a live helper as historical or weaken lint/test/assertions.
No need re-copy all prior raw history into newunit; retain integrity map and
reference already published baselines. Root will independently bind receipts.

Every dependent Python proof/audit/check SHELL begins set-e and exact pinned
restorer with NEW absolute receipt, then runs operation in THAT SAME SHELL:
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT
TMP may reset between continuations; never infer future persistence.
InterpreterSHA4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
All direct Python, edits included, pinned interpreter -B-S, optional-O.
Exact PYTHONPATH:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
PYTHONDONTWRITEBYTECODE=1. No installs, network, native/build/server/socket/
SSLContext/TLSclose/realclock/ownership/kernel/race/fault-scheduling/oldruntime.
Full native/project/platform/all40/adoption/milestone gates remain later
mandatory requirements, not waived or claimed by this source slice.

Graphify before NEW codebase question/search/read; located paths already may
be read. Invocation:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650

Full report: exactfiles/interfaces/commands/results/raw paths; genuine RED/GREEN
chronology; source/input/history/helper audits; self-review/findings/limitations.
Return <=15lines status DONE|DONE_WITH_CONCERNS|NEEDS_CONTEXT|BLOCKED, no commits,
test summary, concerns, report path. Root handles fresh source review before
acceptance, accuracy review and commit with immediate push. Do not stop merely
because remaining final report/audit bookkeeping is unfinished.
