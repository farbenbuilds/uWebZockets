# Fresh task-scoped source review: 9a

Read task-5e3b9a-brief.md first, then task-5e3b9a-report.md and the complete
task-5e3b9a-review-source.diff once. BASE934f5618d6e313d335b0a1aac152936033451972;
candidate source is not committed, represented by Root audit's exact43hash map.
These three inputs and linked exact interface/design contracts bind this task.

Return independent Spec Compliance and Task Quality verdicts, actionable
Critical/Important/Minor findings with file:line and concrete scenario, and
explicit cannot-verify items. Read relevant reviewer/project/convention and
code-review-and-quality skill instructions. Root explicitly requests the
thermo-nuclear-code-quality-review structural lens, with AGENTS overrides.
No emojis. Read-only: no source/metadata/Git/network/native/build/process/socket
edits or subagents. Root owns all publication and commits.

Global constraints verbatim from the requirements:

No operation at construction; same seven connectionkeys, preserve all original
values except wrapped send/receive. Original exactlyonce FIRST, exact returned
object or exact exception/priority. Full-sendNone contract, ambiguous return
poisons. Underlyingfailure or observerdecode/bounds/internalfailure permanently
poisons completeness without replacing original result/error. No arbitrary
exceptiontext/traceback; later operations pass through. Reentrancy/postseal
attempts poison. Only explicit healthy seal after caller-owned lifecycle window
returns detached immutable receipt; repeated seal never resets/erases anything.
No clock/scheduling/traffic/credit/canonicalstate modification.

Observe actual serialized requestidentity/ordinals, initialheads vs trailers,
DATA logical/flow/padding/hash, SETTINGS vsACK, decodedinfo, resetdirection/code,
creditframes+bytes inbothdirections/scopes+lateclosedgrants. Track independent
debt without treating outgoing response grants as requestrefund. Every complete
frame counts once, successful operation bytes count evenpartialprefixes. Bound
beforegrowth: parser8201/frame8192/HPACKtable+encoded+decodedsections4096,
active8/retained802/u64counters; no payload/frame/read histories. Small END and
complete refusalEND+reset separate.17byte output never small. Distinct final
request/response cursors from descriptor67tags+metrics, allactualordered68
terminalresponses earncollection. Ordinaryterminalpolicy beforefinal and exact
authorized open transportexceptions/debt retention follow interface report.

Proof/evidence paths are in the report. Independently inspect Root's
task-5e3b9a-root-final-audit.json and worker final-audit-normal/optimized JSON
and relevant actual command/source/raws. Four covering tests already ran on
this exact source; do not rerun them. No broad/historical suites. For a specific
unanswered code doubt, prefer a precise static trace and report its test need;
new execution needs Root's scoped ruling. No evidence gap can be resolved by
assuming source tests prove actualall40/native/adoption.

Root's first two independent metadata invocations failed due its own path-base
and unrequired test-CLI assumption. Original Root helper versions and failure
qualifications are retained; corrected third audit succeeds without source edits
or repeating suites. Assess the actual evidence and current helper quality.

Codebase question rule: Graphify query before a new codebase search/read; supplied
and diff-located paths may be read for named concrete risks. Read the complete
diff; do not reread changed files unless needed hunk context is actually absent.
No whole-branch review here. Full default/all40, native/runtime/adoption/project/
platform/allmilestone requirements remain future mandatory gates.

If pinned TMP source reads are missing, Root restorer may copy exact source
bytes only, with a NEW receipt in this workspace, then reads in SAME shell.
Do not execute restored tests. Report full verdict as final; Root retains it.
