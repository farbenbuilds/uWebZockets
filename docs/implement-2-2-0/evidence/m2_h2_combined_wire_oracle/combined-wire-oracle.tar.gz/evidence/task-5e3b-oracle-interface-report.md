# Concrete observer interface, architect report

Read-only report from /root/architect_h2_receipt_inventory. No edits or tests.
Root retains the implementable contract and all-family source boundaries here.

Immutable request identities and ordinals suffice for every current family.
No dynamic role or final-phase marker is needed. The observer remains wire-only;
later binding supplies expectations from reviewed peer contracts. Seal timing
remains the harness's responsibility after lifecycle hooks.

## Interface and data

`wrap_connection(connection: Connection, descriptor: ConnectionDescriptor)
-> tuple[Connection, ObserverState]` validates before invoking any operation.
Return a fresh seven-key connection: protocol/send/receive/now/owned/tls/alpn.
Only send/receive are replaced; preserve all other identities/values.
`failure(state) -> FailureReceipt | None`; `seal(state) -> ConnectionReceipt`.

Plain dictionaries hold explicit mutable state; immutable tuples hold named,
documented descriptors and detached receipts. No authored classes/custom
exceptions/generic registration framework. Integer fields reject bool and use
unsigned 64-bit bounds. Tuple field order:

- ConnectionIdentity: child:int, case:str, connection_index:int.
- PayloadExpectation: logical_bytes:int, flow_bytes:int, sha256:bytes[32].
- RequestExpectation: method:GET|POST, target:str,
  request_end:headers|data|trailers|open, request_payload:PayloadExpectation,
  response_role:small|output|reset|transport,
  terminal:end|end_reset_0|incoming_reset_8|incoming_reset_2|outgoing_reset_8|transport_abandon,
  final_status:int|None, informationals:tuple[int,...],
  response_payload:PayloadExpectation|None.
- ConnectionDescriptor: identity:ConnectionIdentity,
  ordinary:tuple[RequestExpectation,...], final_tags:tuple[str,...].

At most802 total expected initial requests including final observations.
Targets/header sections fit4096. Expected streamID=2*one-based ordinal-1.
Informationals empty or(100,). Output requires response payload expectation;
small optional payload and actual body<=4095. Reset/transport permit no final
status/info/responseDATA. Validate compatible role/terminal combinations.
Transport abandonment binding is restricted to disconnect conn1/shutdown-active
held upload. Finaltags empty or exact67ordered tags, producing actual next67
GET/status/tag plusGET/metrics, status200/small/END. Expectations earn nothing.
Request hashes cover actual transmitted bytes, including application-rejected
bytes; sink/progress wirehash concatenates7prefix and separately restarted8prefix,
not accepted7hash (test_terminal_peer.py280-299,310-323).

## Family request and final boundaries

All paths below are current combined-cases sources. N is ordinary initial
requests; optional final starts at ordinal N+1. Stable pure schedule/path/order
functions may construct expectations, but drivers or lengths never earn traffic.

| Family | Ordinary requests and special roles | Source |
| --- | --- | --- |
| Core | ready/large N5, async N3; all small | test_core_peer.py39-59,138-169 |
| Pause | partial7,final6,begin-empty6,control20; all small | test_pause.py13-22,91-99 |
| Admission | five non-refusals3; declared/zero-declared/zero-observed4; observed-limit5. Refused upload small413/end_reset_0 | test_admission.py13-32,50-68,116-123,138-149 |
| Continue/quota | ready3,paused5,quota11,begin-fail4. Continue upload(100,) then200; quota ordinal5/begin-fail ordinal2 small503/end_reset_0 | test_continue_quota.py17-37,63-80,99-128,163-170 |
| Credit | queued trailers6,receivecredit7; all small; padded12289logical/12297flow | test_credit.py13-17,125-131,160-166,210-245 |
| Metadata | metadata6,concurrency13; all small; concurrency ordinal4 small503/end_reset_0 | test_metadata_concurrency.py32-39,146-164,190-196,266-287 |
| Lifecycle | disconnect conn1 N3/ordinal2 transport_abandon/no final; conn2 N22 all small/final23; reuse N389 all small/final390 | test_lifecycle.py65-98,172-190 |
| Producer | reuse9/output-window8/output-ready6; reuse ordinal2 or pressure ordinal3 output200/end; others small | test_producer_pressure.py16-24,65-89,144-168 |
| File | both N7; file ordinal3 output200/end; early ordinal4 output403/end_reset_0 even17bytes | test_file_early.py19-25,54-60,91-104,296-317 |
| Terminal | cancellation12;peer-reset/sink/invalid11;end-error10. Ordinal3 reset: incoming8 cancellation/outgoing8 peer-reset/incoming2 failure | test_terminal_peer.py11-19,115-129,233-259,338-355 |
| Shutdown | idle N1 health/final2; active N3 health,held upload,pre-status/final4. Ordinal2 transport_abandon. Required final yields69/71heads | test_shutdown.py94-108,115-145,152-170 |

Final transition requires every ordinary request actually decoded/matched and
every ordinary small/output/reset required terminal observed; only authorized
transport-abandon may remain incomplete. Actual next request matches firsttag.
Separate finalrequest/deliveredresponse cursors; ordered68terminal responses earn
one collection. Ordinary status/metrics cannot satisfy final cursors.

## State and receipt bounds

Explicit descriptor, stickyfailure/sealed/reentrancyflags/opordinals; two
directional parsers<=8201/payload8192; fresh HPACK contexts/table/encoded/decoded
sections4096; active8/retained802 request-debt summaries. Scalars/cursors/rolling
hashes only, no payload/frame/read histories. Process before growth. Current
contracts use complete HEADERS HPACK sections; support transport fragmentation
without a general CONTINUATION implementation. Use external hyperframe and
hpack directly; no canonical wire/raw_observer/output_stage state. Count
WINDOW_UPDATE bothdirections/scopes/lateclosed; requestrefund/debt distinct from
outgoing bootstrap/auxiliary response grants.

Tuple receipt fields:

- FailureReceipt: code:str, direction:send|receive|none, operation:int,
  wire_offset:int, stream_id:int|None.
- CreditReceipt: frames,bytes,late_closed_frames,late_closed_bytes:int.
- DirectionReceipt: calls,wire_bytes,frames,initial_heads,trailers,data_frames,
  logical_bytes,flow_bytes,padding_bytes,settings,acks:int;
  resets:tuple[(code:int,count:int),...]; connection_credit,stream_credit:CreditReceipt.
- StreamReceipt: ordinal,stream_id:int;role:str;
  request_bytes,request_flow:int;request_sha256:bytes;
  response_bytes,response_flow:int;response_sha256:bytes;
  request_end,response_end:bool;incoming_reset,outgoing_reset:int|None;
  request_stream_debt:int;terminal_complete:bool.
- ConnectionReceipt: identity;started:bool;sent,received:DirectionReceipt;
  informationals,small_ends,small_complete,output_ends,final_requests,
  final_responses,final_collections,request_connection_debt,
  request_stream_debt_total:int;transport_incomplete:tuple[int,...];
  streams:tuple[StreamReceipt,...].

Detached immutable copies, max802stream summaries. Smallends earns delivered
small END; smallcomplete additionally requires refusal NO_ERROR reset. Output
never small. Actual decoded1xx earns info; completeframes commitonce. Successful
operation wirebytes count even incompleteframe prefixes.

## Failure, retirement and seal

Original operations exactlyonce, preserve exact result object/exception.
Existing fullsend returnsNone; otherresults preserve but poison as ambiguous.
Receive exact(bytes,timestamp)shape/object, no clockcall. Underlyingexception
propagates unchanged and poisons even ifcaller catches. Post-success observer
failure storesfirstboundedfailure without replacingresult, stops parsing and
future calls pass through. Postseal attempts poison/preserve original behavior.

Codes: descriptor,connection_shape,send_exception,receive_exception,
ambiguous_send,receive_shape,reentrant,after_seal,bound,frame,hpack,
request_identity,settings,payload,credit,terminal,final_order,incomplete,internal.
Argumentvalidation raisesfixed ValueError(code) preeffect; seal poison/incomplete
raises ValueError("oracle_unsealed"); failure suppliesbounded detail. No arbitrary
exceptionstrings/tracebacks.

Leave active only after required observedterminal; retain802bound summaries and
latecredit/debt, never manufacture END/reset/zerodebt. Seal requires nofailure/
inprogress/partialframe/unfinishedheaders; all expected actualrequests/payloads/
hashes/ordinary-finalterminals, requiredfinalcollection exactlyonce ornone.
Harness has finished hooks/closed operation ownership before consumption.

Disconnect conn1 ordinal2 transmits32 without requestEND/responseterminal;
auxiliaries complete. Sealafter successfulclose/replacementhooks retains
transport_incomplete anddebt, doesnotmark wireclosed (test_lifecycle.py304-336).
Shutdown active held32 likewise noENDS, preliminary/finalresponses complete;
sealafter signal/termination/process/postvalidation hooks, retain incomplete
anddebt (test_shutdown.py264-280,288-338). These prove complete observation of
authorized synthetic window, not nativeclose. Splitreset/refundtail blocks seal;
missingrequiredreset blocks; unreceivedgrant earnsnothing. Seal neverdrains or
requiresunearned zerodebt. Repeatedhealthy seal identicalfreshcopy; postsealattempt
makeslaterseal fail. Oldcopy cannotjustify ignoringlaterpoison.

## Ordered slices and unchanged acceptance

1. Private helper+focused checks only, explicit miniature descriptors, no40case
   builder orpeer edits. Cover exactonce/result/errorpriority/stickypoison/bounds/
   splitcoalesced/padding/SETTINGSACK/info/17byteoutput/refusalENDreset/latecredit/
   finalordering/transportabandon/postseal; normal/O then freshsource review.
2. Later narrow descriptorbinding wraps everyfactory/replacement while coordinator
   alone dispatches; sealafterappropriatehooks, connectiononce/caseonceaggregate.
   Compareactualretained outputs/binding/final separately. Thenactualdefault/all40.

Required2children/41connections/802heads/789small/R200091899/46clientSETTINGS/
2info/13incomingresets/2collections; main733/720,idle69/69. All selection/order/
hash/deadline/debt/RX5288609050/refundframes400183798 ceilings/native/adoption/
fullproject/fullmilestone gates remain required. No implementation released by
architect report alone.
