- Medium — Wrapper observation: underlying operation may succeed, then decoding/bounds checking raises. Propagating the observer error replaces success; swallowing it can leave apparently valid incomplete evidence. Repair: bounded sticky observer failure, preserve original result, fail independent harness acceptance.
- Medium — Operation-failure seam: send may transmit a prefix then raise. Ignoring the prefix can desynchronize observation if later operations continue. Repair: prove exact-prefix/atomic-failure seam or permanently mark that connection incomplete while preserving original exception.

Fresh isolated reviewer /root/doubt_h2_wire_oracle_design; no implementation or execution release.
