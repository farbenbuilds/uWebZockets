"""Independently bind the observer candidate to its exact covering receipts."""
import ast
import hashlib
import json
import sys
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def nesting(node, depth=0):
    control = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.With, ast.AsyncWith,
               ast.Try, ast.TryStar, ast.Match)
    level = depth + int(isinstance(node, control))
    return max([level] + [nesting(child, level) for child in ast.iter_child_nodes(node)])


def verify_source(source, unit):
    baseline = read_json(unit / 'baseline.json')
    manifest = Path('docs/implement-2-2-0/evidence/m2_h2_combined_terminal_peer/manifest.json')
    published = read_json(manifest)
    if baseline['source'] != published['current_source_files'] or sha(manifest.read_bytes()) != baseline['manifest_sha256']:
        raise ValueError('Frozen published baseline differs')
    current = {path.name: sha(path.read_bytes()) for path in sorted(source.glob('*.py'))}
    added = sorted(current.keys() - baseline['source'].keys())
    changed = sorted(name for name, digest in baseline['source'].items() if current.get(name) != digest)
    if len(current) != 43 or added != ['test_wire_oracle.py', 'test_wire_oracle_checks.py'] or changed != ['test_imports.py']:
        raise ValueError('Source ownership differs')
    for name, digest in baseline['source'].items():
        if sha((unit / 'baseline-source' / name).read_bytes()) != digest:
            raise ValueError('Frozen source bytes differ')
    for name, digest in baseline['history'].items():
        path = source / 'evidence' / name
        if path.is_symlink() or sha(path.read_bytes()) != digest:
            raise ValueError('Prior evidence differs: ' + name)
    return current, len(baseline['history'])


def verify_fix_baseline(source, unit, plan):
    root = unit / 'fix1'
    frozen = read_json(root / 'freeze.json')
    reviewed = read_json(plan / 'task-5e3b9a-root-first-reviewed-audit.json')
    if frozen['source'] != reviewed['current_source_sha256']:
        raise ValueError('Fix baseline differs from independently reviewed source')
    for name, digest in frozen['source'].items():
        if sha((root / 'reviewed-source' / name).read_bytes()) != digest:
            raise ValueError('Frozen reviewed source differs')
    if sha((root / 'reviewed-report.md').read_bytes()) != frozen['report_sha256']:
        raise ValueError('Frozen reviewed report differs')
    for name, digest in frozen['history'].items():
        path = source / 'evidence' / name
        if path.is_symlink() or sha(path.read_bytes()) != digest:
            raise ValueError('Pre-fix evidence differs: ' + name)
    return len(frozen['history'])


def verify_inventory(folder, current, source):
    data = read_json(folder / 'inventory.json')
    expected_path = '/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'
    expected_interpreter = '4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601'
    if data['source'] != current or data['pythonpath'] != expected_path or data['dontwritebytecode'] != '1':
        raise ValueError('Covering source/environment differs')
    if data['interpreter_sha256'] != expected_interpreter or sha(Path(data['interpreter']).read_bytes()) != expected_interpreter:
        raise ValueError('Covering interpreter differs')
    if Path(data['cwd']).resolve() != source.resolve():
        raise ValueError('Covering cwd differs')
    for name, digest in current.items():
        if sha((folder / name).read_bytes()) != digest:
            raise ValueError('Captured source text differs')
    for name, digest in data['helpers'].items():
        if sha((folder / 'helpers' / (name + '.txt')).read_bytes()) != digest:
            raise ValueError('Captured helper text differs')
    return data


def verify_receipt(unit, name, current):
    folder = unit / name
    if Path(name).is_absolute() or '..' in Path(name).parts or not folder.resolve().is_relative_to(unit.resolve()):
        raise ValueError('Receipt must remain within the owned unit')
    argv = (folder / 'argv.txt').read_text().splitlines()
    if argv[:3] != ['/home/codespace/.python/current/bin/python3', '-B', '-S']:
        raise ValueError('Covering argv prefix differs')
    optimized = len(argv) > 3 and argv[3] == '-O'
    tail = argv[4:] if optimized else argv[3:]
    if tail not in (['test_wire_oracle_checks.py'], ['test_imports.py']):
        raise ValueError('Covering target differs')
    before = verify_inventory(folder / 'before', current, unit.parents[1])
    after = verify_inventory(folder / 'after', current, unit.parents[1])
    if before != after:
        raise ValueError('Covering identities changed during check')
    if (folder / 'exit.txt').read_text() != '0\n' or (folder / 'stderr.txt').read_bytes():
        raise ValueError('Covering command failed or emitted stderr')
    restored = read_json(folder / 'restoration.json')
    if not restored['all_inputs_verified_in_this_command'] or restored['authority_entries'] != 119:
        raise ValueError('Same-shell input restoration differs')
    if (restored['physical_rows_checked'], restored['unique_resolved_files'], restored['ordered_codec_files_checked']) != (118, 113, 42):
        raise ValueError('Restored input inventory differs')
    return dict(module=tail[0], optimized=optimized, argv=argv, cwd=before['cwd'],
                source_before_after_exact=True, exit_code=0, stderr_empty=True,
                stdout_sha256=sha((folder / 'stdout.txt').read_bytes()),
                restoration_sha256=sha((folder / 'restoration.json').read_bytes()))


def verify_helpers(unit, plan, source):
    paths = sorted((unit / 'helpers').glob('*.py'))
    paths += [plan / ('task-5e3b9a-' + name + '.py') for name in
              ('root-audit', 'build-publication', 'publication-audit')]
    paths += [source / name for name in ('test_wire_oracle.py', 'test_wire_oracle_checks.py')]
    result = {}
    for path in paths:
        tree = ast.parse(path.read_text(), filename=str(path))
        depth = nesting(tree)
        if depth > 3 or any(isinstance(node, (ast.ClassDef, ast.Assert)) for node in ast.walk(tree)):
            raise ValueError('Current helper/source structure differs: ' + str(path))
        scope = {'__name__': 'root_metadata', '__file__': str(path)}
        previous_path = sys.path[:]
        try:
            sys.path.insert(0, str(path.parent.resolve()))
            exec(compile(tree, str(path), 'exec'), scope)
        finally:
            sys.path[:] = previous_path
        result[str(path)] = dict(sha256=sha(path.read_bytes()), max_nesting=depth, metadata_import_inert=True)
    return result


def main(argv):
    if len(argv) != 5 or argv[0] != '--audit':
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    unit = source / 'evidence/wire-oracle'
    current, history_count = verify_source(source, unit)
    fix_history_count = verify_fix_baseline(source, unit, plan)
    receipts = {name: verify_receipt(unit, name, current) for name in argv[1:]}
    expected = {(module, optimized) for module in ('test_wire_oracle_checks.py', 'test_imports.py') for optimized in (False, True)}
    if {(row['module'], row['optimized']) for row in receipts.values()} != expected:
        raise ValueError('Four-check coverage differs')
    result = dict(base_commit='934f5618d6e313d335b0a1aac152936033451972',
                  current_source_sha256=current, changed_modules=['test_imports.py'],
                  added_modules=['test_wire_oracle.py', 'test_wire_oracle_checks.py'], unchanged_modules=40,
                  prior_evidence_hashes_verified=history_count, fix_prior_evidence_hashes_verified=fix_history_count,
                  focused_receipts=receipts,
                  current_helpers=verify_helpers(unit, plan, source),
                  native_executed=False, actual_all40_executed=False, milestone_complete=False)
    output = plan / 'task-5e3b9a-root-final-audit.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(source_modules=len(current), prior_evidence_hashes_verified=history_count,
                          focused_receipts=len(receipts), result=str(output)), indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
