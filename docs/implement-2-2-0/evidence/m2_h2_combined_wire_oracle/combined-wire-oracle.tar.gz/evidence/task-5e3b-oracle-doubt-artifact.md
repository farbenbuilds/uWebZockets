# Artifact

Add one private passive TEST helper that observes both directions of the existing
serialized connection seam using fresh pinned hyperframe/hpack state, without
reading canonical client ledgers/registrations/handlers. Wrappers first call
the underlying operation exactly once and preserve its exact result/exception.
An operation failure permanently poisons completeness and stops subsequent
observation because unknown consumed/sent prefixes cannot be reconstructed.
After success, observer decode/bounds/internal failures also become a bounded
sticky failure rather than replacing the result; later calls remain pass-through.
Only an unpoisoned explicit seal may return an accepted copied receipt, after
the harness has completed all relevant connection/lifecycle hooks; raw counters
are never an acceptance substitute. Successful returned bytes/accepted sends
earn bounded wire counters and hashes without altering bytes or timestamps.
A small immutable test-owned descriptor matches actual decoded request identity
to exceptional response roles, terminal policy, payload/output expectations and
final-phase eligibility/ordered67-status-plus-metrics; metadata grants permission
but earns no observations. The harness separately compares actual retained
client output/binding/final observations, and only proven necessary dynamic
markers get separately scoped peer changes. If this requires reproducing family
dispatch or canonical ledger machinery, use bounded peer-local instrumentation
instead; the accepted peers stay unchanged during this helper experiment.

# Contract

- No second PRODUCTION parser/client: helper is private test code, uses existing
  pinned codec primitives, emits no traffic and never drives scheduling, credit,
  handlers, canonical state, clocks, deadlines or completion.
- Independent means actual serialized truth from successful operations and
  test-owned state, not client ledger totals, catalogue sums, queued bytes or
  selected model results. Sharing the pinned external codec is not a proof of
  codec correctness and must be qualified.
- Bound framing before growth: frame payload8192/parser8201, encoded/decoded
  header sections and HPACK4096, two directional decoder contexts per connection;
  active8/debt-bearing summaries at most the existing parent802-request ceiling.
  No whole payloads, frame/read histories or unbounded retained stream IDs.
- Distinguish initialheads/trailers, SETTINGS/ACK, actual1xx, logical/paddedflow,
  incoming/outgoing resets+code, both credit scopes/directions including late
  closed-stream grants, responseEND versus required refusalreset, delivered
  terminalsmall versus streamedoutput even17-byte output, finalrequests versus
  deliveredfinalresponses/collections. Partial/coalescedframes count once.
- Descriptors come from reviewed TEST-peer contracts and match decoded request
  identity; never derive from canonical registrations/stage/counters. Final
  permission cannot relabel ordinary status/metrics; finalordering/completion
  must actually happen. Distinct disconnect transports/countonce/caseonce.
- Preserve originalonce/result/exception identity+priority, bytes/timestamps,
  protocol/parser/ledger identity, receivecaps/deadlines/debt/finalhandoff.
- No swallowed observer failure: retain a fixed failure code/offset/identity
  within bounds (not arbitrary exception text/tracebacks), stop parsing after
  poison, and make seal fail. Underlying operation exceptions propagate unchanged
  and poison even if a caller later catches them; do not assume send/read failure
  is atomic. This experiment targets the existing full-send source seam; partial
  send results/ambiguous consumption must poison unless an explicit accepted-byte
  contract is supplied and tested. Completeness after an expected native EOF/error
  is not inferred or released here.
- Seal is after all relevant teardown hooks, returns copied immutable facts and
  never resets counters/buffers/debt. Subsequent operation attempts poison the
  observer; repeated seal cannot conceal failure. Harness consumes sealed copies
  only after its operation window is closed, with no retained callback ownership.
- Subsequent actual default/all40 proof still requires2children/41connections/
  802heads/789small/R200091899/46clientSETTINGS/2info/13incomingresets/
  2collections; main733/720,idle69/69 firstfreshchild then39callerorder.
  Preserveall empty/subset/invalidpreeffect/debt/largehash/retainedactualfacts
  requirements and RX5288609050/refundframe400183798 ceilings.
- No native/build/network/production change in this experiment. Normal/O tests,
  bounds/fragmentation/error-priority/specialoutput/final/latecredit proofs and
  independent source review precede aggregate binding/execution. Native/runtime/
  adoption/platform/fullmilestone gates remain mandatory later.
