# Slice 9a: private passive HTTP/2 wire oracle

Status: DONE for the assigned source-only slice, pending Root's fresh independent
source/accuracy reviews. No commit, push, publication, native execution, network,
real socket, process lifecycle, server, TLS close, or aggregate case execution.

Base supplied by the brief: 934f5618d6e313d335b0a1aac152936033451972,
feat/implement-2-2-0. No Git command was run by this worker.

## Exact ownership and resulting files

All source paths below are relative to:
`/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases`.

- NEW `test_wire_oracle.py`: 473 lines; passive observer implementation.
  SHA256 `97b89f4e6b5c358f8ad20e9a47cf5674e21bf1ee74daafa6f9e5762ce3a566a0`.
- NEW `test_wire_oracle_checks.py`: 574 lines; explicit miniature descriptors,
  real external-codec bytes, deterministic caller-owned operations.
  SHA256 `133ff3e9bc0c48a74d9c6f395c0807f784122857bfaf8c718435263ef43493dd`.
- CHANGED `test_imports.py`: exact addition of `test_wire_oracle` and
  `test_wire_oracle_checks` to its existing source inventory, no other change.
  SHA256 `29e7f6a384b45bc7fa091113406813b8a0d1fa71ae943750750277054bcff0a2`.
- NEW evidence tree `evidence/wire-oracle/`, including frozen baselines,
  intermediate/failing/final snapshots and raw commands/results, and current
  `helpers/capture.py`, `helpers/audit.py`, `helpers/run.sh`.
- This report at
  `/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b9a-report.md`.

The 41-source manifest authority is
`docs/implement-2-2-0/evidence/m2_h2_combined_terminal_peer/manifest.json`,
`current_source_files`. Current inventory is 43: 40 original modules unchanged,
one exact inventory addition, two new modules. No peer, canonical client/model,
core/adapter/coordinator/handler/product/pin/limit source was edited.

## Interface and implementation

The accepted interface and doubt artifact were read before implementation:
`task-5e3b-oracle-interface-report.md` and `task-5e3b-oracle-doubt-artifact.md`.
Their descriptor and receipt positional field order is documented with named
immutable tuple aliases in the new module. Mutable state is an explicit,
returned caller-owned dictionary. No authored classes, custom exceptions,
assert statements, module-level mutable containers, canonical ledger imports,
traffic scheduling, clocks, or I/O appear in the observer.

The three consumer entry points are:

- `wrap_connection(connection, descriptor) -> (connection, state)`: validates
  before effects and returns a fresh seven-key connection with only send and
  receive replaced. All other values preserve identity. The original operation
  executes exactly once and retains its exact return object or exception.
- `failure(state) -> FailureReceipt | None`: first bounded sticky failure,
  containing fixed code, direction, operation ordinal, wire offset and stream ID
  where available. Arbitrary exception text/tracebacks are not retained.
- `seal(state) -> ConnectionReceipt`: detached immutable facts only after all
  required observations and explicit caller-owned lifecycle completion. Seal
  never drains traffic, manufactures END/reset/debt refunds, or clears failure.
  Repeated healthy seals return equal fresh copies. A later operation attempt
  poisons subsequent seals while preserving original operation behavior.

The helper uses fresh pinned `hpack.Decoder` contexts and `hyperframe.frame.Frame`
primitives directly, not the canonical wire/raw_observer/output_stage machinery.
It supports fragmented/coalesced transport with complete HEADERS sections and
rejects general CONTINUATION/PUSH_PROMISE. Complete frames count once; successful
wire bytes count even when only an incomplete prefix has arrived. Request
identity comes from actual decoded method/path and odd stream ordinals.

It distinguishes initial heads/trailers, DATA logical/flow/padding/hash facts,
SETTINGS/ACK, decoded informational 100, incoming/outgoing reset codes, both
credit scopes and directions, and late closed-stream grants. Incoming grants
reduce independent request debt; outgoing response grants do not. Request
hashing covers transmitted DATA bytes rather than application-accepted progress.

Parser storage is bounded to 8201 bytes, frame payload to 8192, encoded/decoded
header sections and HPACK table to 4096, active streams to eight, retained
summaries to 802, and counters to unsigned 64-bit values. No payload/frame/read
histories are retained. The descriptor bounds the complete request schedule;
this slice contains no all40 descriptor builder.

Small response END and completed small refusal are separate counters; refusal
completion requires its subsequently received NO_ERROR reset. Output remains
output even for a 17-byte body. Reset/transport roles prohibit final response
status/informationals/DATA. Ordinary completion gates final entry. Separate
actual request and delivered terminal-response cursors require all ordered 67
`/status/<tag>` requests plus `/metrics` before earning one final collection.
Ordinary status/metrics cannot earn these cursors.

Root clarified that final tags are binding-supplied 67 unique bounded ASCII
names; this helper does not import the model to generate them. Authorized
transport-abandon identities are disconnect connection 1 and shutdown_active
connection 1, ordinary ordinal 2, their actual held-upload path. The descriptor
supplies payload expectations; no case-specific transmitted amount is hardcoded.
Transport receipts retain open wire state and outstanding debt. Caller hooks
remain a prerequisite, not something this wire helper proves.

## Frozen evidence and identities

All evidence paths in the remainder of this report are relative to
`.../combined-cases/evidence/wire-oracle/` unless absolute.

- `baseline.json`: freshly captured exact 41 source hashes, manifest hash, and
  13,038 prior evidence-file hashes; excludes only this new evidence subtree.
- `baseline-source/<name>.py`: exact 41 pre-edit source byte copies.
- `freeze-restoration.json`: pre-edit same-shell restoration proof of 119
  authority entries, 118 physical rows, 113 unique resolved sources, 42 ordered
  codec files, and the pinned interpreter. No files needed restoration.
- The authority's existing `evidence/coordinator-a/immutable-inputs.json` bytes
  were covered by the frozen prior-history hash map before editing.
  `baseline-inputs.json` is an additional later byte copy of that unchanged
  authority, not a claim that a separate input copy existed earlier.
- Each test/audit run directory preserves `before/` and `after/` actual source
  bytes plus `inventory.json`, `argv.txt`, `stdout.txt`, `stderr.txt`, `exit.txt`,
  `restoration.json`, `restoration.stdout`, `restoration.stderr`.
- Current captures also preserve each live helper's bytes/hash under
  `before/helpers/` and `after/helpers/`. Earlier helper snapshots and the two
  explicit `intermediate-08-audit/*.py.txt` copies remain historical artifacts.
  Current live helper files alone reside under `helpers/`; none is exempted
  from the final strict audit.

Initial freeze stdout was observed directly in the tool result: pinned
restoration verified 118 rows/113 files/42 codecs, restored zero; then frozen
41 source and 13,038 historical evidence files. The retained pre-edit freeze
receipt and baseline files are authoritative; no unrecorded pre-edit behavioral
failure is claimed.

## Exact execution environment and command form

All direct Python execution used
`/home/codespace/.python/current/bin/python3 -B -S`, optionally `-O`.
Interpreter SHA256:
`4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`.

`PYTHONDONTWRITEBYTECODE=1` and exact `PYTHONPATH`:

```text
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
```

Each dependent runner invocation begins `set -e`, exports that environment,
creates a fresh absolute run directory/receipt, and executes this restorer
before dependent Python in that same shell:

```text
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore <absolute-run-directory>/restoration.json
```

The runner then changes cwd to the absolute combined-cases source directory,
captures the actual source inventory, executes the recorded Python argv with
separate stdout/stderr/exit files, and captures the actual inventory again.
Its current invocation from the repository cwd is:

```text
sh .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/wire-oracle/helpers/run.sh --run <run-name> <Python arguments>
```

Historical invocations before the helper CLI correction omitted `--run`;
those unchanged runner versions remain in retained snapshots. Current capture
requires `--capture DEST`; current audit requires `--audit DEST`.

## Actual RED/GREEN and audit chronology

Every row names its retained run directory; `argv.txt`, raw stdout/stderr and
exit files contain the actual command/result. A test success is not evidence
of a preceding behavioral failure unless explicitly stated here.

| Run directory | Python arguments after `-B -S` | Exit and actual meaning |
| --- | --- | --- |
| `red-01-api` | `test_wire_oracle_checks.py` | 1; missing new module, API-absence RED only |
| `green-01-boundary` | `test_wire_oracle_checks.py` | 0; initial wrapper, serialized small response and reseal |
| `intermediate-02-contracts` | `test_wire_oracle_checks.py` | 0; expanded contract checks; temporary duplicate main guard ran the initial boundary check twice, removed before final inventory proof |
| `red-03-operation-bound` | `test_wire_oracle_checks.py` | 1; actual operation counter saturated without poisoning |
| `red-04-location` | `-c 'import test_wire_oracle_checks as t; t.check_failure_location()'` | 1; actual failure receipt omitted parsed stream ID |
| `red-05-debt-bound` | `-c 'import test_wire_oracle_checks as t; t.check_retained_debt_overflow()'` | 1; actual total retained stream debt had no independent u64 check |
| `green-06-counter-location` | `test_wire_oracle_checks.py` | 0; all three behavior fixes verified |
| `intermediate-07-expanded` | `test_wire_oracle_checks.py` | 0; header bounds, retained802, final incompleteness and error-priority expansion |
| `intermediate-08-audit` | `evidence/wire-oracle/helpers/audit.py <absolute-unit>/intermediate-audit.json` | 1; strict AST nesting found dispatcher depth six |
| `inspect-09-depth` | exact `-c` AST inspection retained in `argv.txt` | 0; localized excess to `consume_frame` |
| `intermediate-10-audit` | `evidence/wire-oracle/helpers/audit.py <absolute-unit>/intermediate-audit-10.json` | 1; audit mistakenly applied new-code nonlocal ban to unchanged `test_shared.py` |
| `intermediate-11-audit` | `evidence/wire-oracle/helpers/audit.py <absolute-unit>/intermediate-audit-11.json` | 0; corrected audit scope, unchanged established class/assert gate retained for all source |
| `intermediate-12-cli-audit` | `evidence/wire-oracle/helpers/audit.py --audit <absolute-unit>/intermediate-audit-12.json` | 0; explicit CLI flags plus inert direct-main and import argv checks |

Behavior fixes add operation-overflow poison after preserving original priority,
record the current parsed stream ID, and check total retained stream debt before
increasing it. The dispatcher became a flat `match` instead of nested `elif`.
No lint threshold was raised or existing check disabled. Historical source is
unchanged; all new source and current Python helpers receive the stricter
no-global/nonlocal/container/max-three checks.

Root identified the helper's old `len(argv)==2` guard as a concrete source-level
foreign-argument effect risk. Both Python helpers now require named flags;
the shell runner requires `--run` and valid arity. This finding was corrected
from source review; no pre-fix behavioral RED is claimed. Its old source is
preserved. The final audit executes current helpers as imports and as direct
main programs under empty, one-name, single-foreign and multi-foreign argv with
file/socket/process/clock effects guarded.

## Final four covering commands

After the final source edit, exactly these four covering test commands ran.
No unrelated historical suite or aggregate schedule was run.

| Receipt directory | Exact target argv after `-B -S` | Exit |
| --- | --- | --- |
| `final-01-focused` | `test_wire_oracle_checks.py` | 0 |
| `final-02-focused-optimized` | `-O test_wire_oracle_checks.py` | 0 |
| `final-03-imports` | `test_imports.py` | 0 |
| `final-04-imports-optimized` | `-O test_imports.py` | 0 |

All stderr files are empty. Each before/after inventory is equal and matches
current source hashes. Metadata includes actual cwd, exact two Python
environment variables, interpreter path/hash, and argv. The full same-shell
restoration receipt is distinct for every run.

The focused checks exercise construction pre-effects/shape/identity, original
once/results/errors, unknown-prefix poison, ambiguous send, malformed receive,
reentrancy, postseal/reseal, observer internal failures and exception priority;
fragmented preface and byte-split 8192-byte frames, coalesced frames, malformed
framing/CONTINUATION/HPACK, partial reset/refund tails; padded hashes and
flow/debt, both trailer directions, SETTINGS/ACK and real 100; reset direction
and codes, refusal END then reset, 17-byte output exclusion; late credits in
both directions/scopes, independent request debt; authorized transport open
windows; final ordering/ordinary exclusion/permission-versus-delivery;
encoded/decoded/table4096, active8, retained802, u64 overflow and descriptor
pre-effect rejection. The total-debt and counter overflow checks inject bounded
state at the limit rather than attempting infeasible exabyte traffic.

`test_imports` checks all current 43 modules for authored classes/asserts and
inert imports under empty/foreign argv with guarded filesystem/network/process/
clock effects. The normal/-O focused checks use explicit `require` functions,
so optimized mode retains assertions of behavior.

## Final audits and helper CLI proof

Both commands ran through the current same-shell runner, exit zero:

```text
--run final-audit-normal evidence/wire-oracle/helpers/audit.py --audit /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/wire-oracle/final-audit-normal.json
--run final-audit-optimized -O evidence/wire-oracle/helpers/audit.py --audit /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/wire-oracle/final-audit-optimized.json
```

These are audits, not additional covering suites. Their JSON outputs prove:

- 43 current AST-checked source modules; 41-file byte/hash baseline; 40 unchanged,
  one exact inventory edit and two new modules.
- All 13,038 prior evidence hashes still match.
- Both new source files have lexical/local control depth three; current
  `audit.py` depth two and `capture.py` depth one. All current Python helpers
  are strict-audited and tested inert for import/direct-main empty/foreign argv.
- All four final check receipts match actual current source before/after,
  exact argv/cwd/environment/interpreter, exit zero, empty stderr, and distinct
  pinned 119/118/113/42 restoration receipts.

The receipt-binding function was added only to the audit helper after the four
covering checks. No source, capture helper, or shell runner changed. Its actual
current bytes are included in both final audit snapshots and strict checks.

`shell-cli-inert/` retains a further same-shell pinned restoration receipt,
before/after source/helper inventory, separate stdout/stderr/exit for:

```text
sh ../helpers/run.sh
sh ../helpers/run.sh foreign
sh ../helpers/run.sh foreign --run unexpected
```

Cwd was that absolute owned `shell-cli-inert` directory. All three exit zero
without output; a pinned inline Python audit checked the exact directory
inventory and unchanged before/after metadata, then wrote `result.json`.
No unexpected file/directory was created.

## Self-review, qualifications and remaining gates

Self-review checked the fixed tuple field order against the interface report,
wrapper exception priority, sticky poison, absence of traffic/clock ownership,
parser/table/stream/counter bounds, detached receipts, retained late credit and
transport debt, and final permission-versus-observation semantics. No known
unresolved implementation defect remains in the assigned slice. Root owns the
required fresh independent reviewer; this self-review is not its substitute.

The first combined instruction read exited 1 because
`.agents/references/definition-of-done.md`, referenced by using-agent-skills,
does not exist. Root explicitly ruled this known generic documentation-reference
drift, not a missing transitive SKILL.md: the slice brief and project gates
control; no vendored file was created or edited. Applicable local incremental,
TDD, API, codebase-design and debugging workflows were read/applied. Relevant
specialist instructions were read. The prescribed graphify query executed
successfully before exploration; located peer files supplied final path and
transport identity context. Root explicitly owns the final AST-only graphify
update after publication; it is not an omitted worker gate.

This private helper shares pinned codecs with existing tooling; it is not an
independent correctness proof of those codecs. It does not prove real close,
EOF prefix consumption, scheduling races, native transport behavior, lifecycle
hooks, or correct binding across every peer factory. Expected native operation
errors still poison, even if a caller catches them. CONTINUATION is explicitly
unsupported. Caller-owned state is not protected against arbitrary external
mutation, and a receipt consumer must close its operation ownership window
before relying on seal; an old receipt cannot erase later poison.

No all40 descriptors, peer wrapping/adoption, retained-output comparisons,
default/all40 execution, aggregate 2-child/41-connection/802-head/789-small/
R200091899/46-client-SETTINGS/2-info/13-incoming-reset/2-collection proof was
attempted. Native/runtime/platform/adoption/full-project/full-milestone gates,
including the project Zig formatting/convention/release-version/test commands,
remain mandatory later and are neither waived nor claimed passed here.
Root retains review, publication, assignment/labels if applicable, and commit
with immediate push. This worker performed none of those operations.

# Fix round 1 of 5: decoded HPACK growth boundary

This appendix supersedes the initial report's decoded-growth sufficiency
assessment. The initial report above and all original receipts remain unchanged.
The independent review correctly found that eventual poisoning did not enforce
the promised bound before literal materialization. The initial review is retained
verbatim below, followed by the focused fix and new evidence.

# Initial independent source review

Reviewer: /root/review_h2_wire_oracle. Full returned report follows.

Spec Compliance: Request changes. Task Quality: Request changes.

One Important finding; no Critical or Minor findings.

Important — decoded HPACK bounds are enforced after growth. At
test_wire_oracle.py:252, Decoder.decode() fully decodes headers before the
observer's size check at line255. The pinned codec similarly checks
max_header_list_size only after decoding and appending each header.

A Huffman-compressed literal containing6000 repeated a bytes fits within the
4096-byte encoded-section limit, but its decoded buffer grows to6000 bytes
before rejection. Static trace: pinned hpack.py:640,653 calls decode_huffman;
huffman_table.py:114,124 appends without a bound; hpack.py:542-546 subsequently
checks inflated size. This violates explicit decoded-section bound-before-growth,
although sticky poisoning prevents a successful receipt.

Enforce remaining decoded-section budget before materializing oversized literals
or appending headers, retaining pinned codec boundary and existing valid-input
contract. Add focused regression checking growth boundary rather than eventual
rejection. Existing header-bound test establishes only eventual poisoning.

Evidence checked:

- Complete1676-line review diff, SHA256
  d2d0d4c81ddb20684b21ba9ca0698f39f74d3dc341d5a91eb94c8b72bf844021.
- Task brief/report, binding interface/design, project conventions, reviewer/
  specialist instructions and both required review skills.
- Three current source hashes match report and Root audit.
- Root audit, worker final-audit-normal/optimized JSON and command results,
  four covering argv/stdout/stderr/exit. Exits0/empty stderr, equal before/after,
  stdout/restoration hashes match Root audit.
- Two codec files match immutable authority hashes.
- Root's two failed metadata audits/corrected helper qualifications concern
  audit assumptions, not failed implementation tests.
- Structural lens finds no additional actionable regression: implementation/
  checks separate, files<1000lines, existing sharedsource only inventorychanges.
  No clear simplification justifies expanding slice.

Verification limits:

- No tests/builds/native/network/Git/edits/subagents ran. Static finding needs
  focused regression.
- Retained ownership/history audits inspected; not independently rehashing13038.
- No factoryadoption/defaultall40/aggregate/lifecycle/native/codeccorrectness/
  project/platform/milestone proof. All remain required.
- Publication helpers reviewed as source only; no successful publication or
  delivery-artifact verification yet.

## Fix scope and preserved reviewed state

Only `test_wire_oracle.py` and `test_wire_oracle_checks.py` changed in this round.
The other 41 reviewed source modules, including `test_imports.py`, are unchanged.
The original three live evidence helpers remain byte-identical. A new
`evidence/wire-oracle/helpers/fix1_audit.py` audits the fix and its preserved
history. New round evidence is under `evidence/wire-oracle/fix1/`.

Before editing, same-shell pinned restoration and an inline pinned-Python freeze
verified all 43 current hashes against the initial final audit, then retained:

- `fix1/reviewed-source/<name>.py`: all 43 exact reviewed source files.
- `fix1/reviewed-report.md`: exact pre-fix report bytes, also retained as the
  unchanged prefix of this report.
- `fix1/freeze.json`: the reviewed43 source hashes, old-report hash, and a fresh
  map of 15,055 prior evidence-file hashes, excluding only the new fix1 subtree.
  This covers the original receipts, sources in historical snapshots, helper
  bytes, prior audits and initial evidence; no old receipt was overwritten.
- `fix1/freeze-restoration.json`: pinned 119 authority / 118 physical /
  113 resolved / 42 ordered codec restoration proof; zero sources restored.

Final source hashes and sizes after the fix:

| File | Lines | SHA256 |
| --- | --- | --- |
| `test_wire_oracle.py` | 542 | `6401a1d42ca15a3e9cea830586f233edd294cad712064d540eb083f432cffc2f` |
| `test_wire_oracle_checks.py` | 677 | `2d5eaadf309cfb87ad7281c60fdfff28220df439aa5285a4cf2a39f8ae2af06d` |
| `helpers/fix1_audit.py` | audit helper | `76253d7413754befb9a2434d32a51be7d7c269da9d6688e3729134a66a7a7b85` |

## Narrow correction

`bounded_header_decode` now preflights one representation against the remaining
4096-byte decoded-section budget, including each field's 32-byte overhead,
before asking the pinned decoder to materialize it or append a header.

The preflight uses pinned `decode_integer`, existing indexed-table lookups and
a count-only walk of the pinned Huffman DFA. That walk retains only state,
flags and an emitted-byte count; it emits no decoded string. Raw literals check
their encoded length directly before decoding. An oversized name is rejected
before name creation; a value receives the budget left after its name and field
overhead. Indexed fields are likewise charged before their HeaderTuple is
constructed. Already accepted fields consume the section's remaining budget.

After preflight, pinned `Decoder.decode` handles that exact representation,
including actual Huffman decoding, field construction and dynamic-table updates.
The result's one-field shape and size must agree with the preflight before it
joins the bounded accumulated header list. No dependency was edited and no
module/global monkeypatch was introduced. This remains a private test helper,
not a replacement production decoder or HTTP/2 client. The external tuple
interface, descriptor schema and encoded4096 limit are unchanged.

Whole-block semantics remain explicit: table-size updates are allowed only
before any header field, even though codec calls are now per representation.
Dynamic references resolve against codec state updated by preceding accepted
representations, including earlier fields in the same block. The pinned codec
continues to validate its table-size contract. General CONTINUATION remains
unsupported; no new frame support or peer behavior was added.

## Genuine failing behavior and growth measurement

The new regression instruments only the fresh test-owned Decoder instance's
`_decode_literal` and `_decode_indexed` entry points. Each wrapper invokes the
original pinned codec function and records the actual field size after it has
been constructed. It does not replace the codec implementation, change globals,
store header payload histories, or infer growth merely from final poison.

`fix1/red-01-growth` failed on the unmodified reviewed implementation with:

```text
RuntimeError: oversized literal materialized before rejection: {'fields': 2, 'literals': 1, 'decoded': 6075}
```

This was a real 6000-byte repeated-a Huffman literal whose complete encoded
section is smaller than 4096. The recorded6075 includes the status field and
per-field overhead. The underlying wrapped receive still returned its exact
original result; eventual hpack poison existed but was insufficient.

`fix1/red-02-remaining-budget` also failed on the reviewed implementation:

```text
RuntimeError: remaining budget +1 materialized
```

The accepted exact4096 decoded case ran first; the following4097-byte section
showed that the next literal was constructed before rejection. Both REDs retain
actual old implementation/new regression source snapshots and raw stderr.

After the fix, the tests verify that oversized Huffman names and values never
reach literal materialization. For cumulative two-field overflow, only the
status and first bounded field materialize:2075 total charged bytes, two fields,
one literal. The overflowing second literal or indexed field is not created.
The exact remaining-budget-plus-one case leaves only the42-byte status field.

Compatibility controls cover exact4096 decoded sections with ordinary,
never-indexed, raw and Huffman strings; valid encoded sections of exactly4096
bytes; legitimate leading table-size changes; dynamic indexed fields within
and across blocks; indexed names in never-indexed literals; and rejection of a
table-size change after the first header. No accepted byte limit was reduced.

## Actual fix commands, results and receipts

Every command below used the same pinned interpreter, exact environment and
same-shell fresh restoration workflow documented above. Source cwd remains
`/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases`.
No source/helper edit was performed after the final four checks.

From repository cwd the command form was:

```text
sh .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/wire-oracle/helpers/run.sh --run <run-name> <Python arguments>
```

| Run name | Exact arguments after `python3 -B -S` | Exit |
| --- | --- | --- |
| `fix1/red-01-growth` | `-c 'import test_wire_oracle_checks as t; t.check_decoded_growth_boundary()'` | 1, real6075-byte materialization |
| `fix1/red-02-remaining-budget` | `-c 'import test_wire_oracle_checks as t; t.check_hpack_boundary_compatibility()'` | 1, remaining budget +1 materialized |
| `fix1/green-03-growth` | `-c 'import test_wire_oracle_checks as t; t.check_decoded_growth_boundary(); t.check_hpack_boundary_compatibility()'` | 0 |
| `fix1/inspect-04-encoded-boundary` | exact bounded pinned-encoder fixture search in `argv.txt` | 0, returned `(1256, 10)` |
| `fix1/green-05-boundary-compatibility` | `-c 'import test_wire_oracle_checks as t; t.check_decoded_growth_boundary(); t.check_hpack_boundary_compatibility()'` | 0 |
| `fix1/final-01-focused` | `test_wire_oracle_checks.py` | 0 |
| `fix1/final-02-focused-optimized` | `-O test_wire_oracle_checks.py` | 0 |
| `fix1/final-03-imports` | `test_imports.py` | 0 |
| `fix1/final-04-imports-optimized` | `-O test_imports.py` | 0 |

The fixture search used the pinned encoder to identify the exact encoded4096
case, then retained the explicit bytes recipe in the test. Its full argv is
preserved; it did not run peer families, network or native code.

All new run directories retain original `before/` and `after/` source and helper
bytes, actual `inventory.json`, exact `argv.txt`, `stdout.txt`, `stderr.txt`,
`exit.txt`, and their own `restoration.json` plus restoration stdout/stderr.
All four final stderr files are empty. New growth checks print:

```text
actual codec growth boundary: oversized Huffman name/value and cumulative literal/indexed fields never materialize
exact4096 accepted, +1 preflight rejected; dynamic references and whole-block table-update ordering preserved
```

The full focused suite retains all earlier tests and prints its other successful
contract checks; both inventory/import runs print
`AST and inert import checks passed`.

Two final audits ran, both exit zero with empty stderr:

```text
--run fix1/final-audit-normal evidence/wire-oracle/helpers/fix1_audit.py --audit-fix1 /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/wire-oracle/fix1/final-audit-normal.json
--run fix1/final-audit-optimized -O evidence/wire-oracle/helpers/fix1_audit.py --audit-fix1 /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/wire-oracle/fix1/final-audit-optimized.json
```

Their outputs confirm:

```text
Fix scope: two source files, 41 reviewed modules unchanged; prior evidence: 15055
Original 41-source/history authority, current43 AST, fixed-source four receipts and live strict/inert helpers: 3
```

The audits check both original baseline41/history13038 and reviewed43/history15055,
all current43 ASTs, the old report's preserved prefix, all three current Python
helpers for strict nesting and inert import/direct-main empty/foreign argv,
and the four new final receipts against actual current source, exact
argv/environment/cwd/interpreter, and pinned119/118/113/42 restoration receipts.
The unchanged shell runner's earlier inert-argv proof remains byte-bound by
these history audits; it was not needlessly rerun.

## Fix self-review and remaining limitations

Self-review concentrated on the reported growth defect and risks introduced by
representation-at-a-time codec calls: literal names as well as values,
remaining rather than per-field budget, indexed field costs, dynamic indices
created earlier in a block, indexed literal names, never-indexed/raw strings,
exact accepted limits and table-update ordering. These all have focused
behavioral controls. The count-only traversal uses the same pinned DFA table as
the codec; this is still not an independent proof of codec correctness.

No additional finding or ownership change was introduced. The reviewed helper's
public interface and other protocol behavior remain unchanged. All original
aggregate/native/adoption/platform/full-project/full-milestone limitations and
gates remain in force. Root owns the fix-only independent re-review, final
accuracy check, publication, graph refresh, and Git operations. This worker
performed no commit, push or publication.
