1. **Response-ledger residue and missing active terminal flags — ADDRESSED.** [coordinator.py:290](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/coordinator.py:290) rejects nonempty response-credit streams. [coordinator.py:276](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/coordinator.py:276) requires both canonical closed flags to be exactly `True` for active shutdown. These checks reject corruption without clearing state or requiring legitimate request debt to be zero.

2. **Ordinary final teardown bypasses post-callback quiescence — ADDRESSED.** [coordinator.py:390](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/coordinator.py:390) checks quiescence immediately after `finish_child()` returns, before child publication. Parser and response-ledger mutations from teardown callbacks now fail.

**New breakage in the fix diff:** None found.

**Verification:** Inspected the scoped diff, appended report, Root’s fix audit, six retained pre-fix RED tracebacks, and final shutdown stdout. The new tests verify rejection boundaries and preservation of injected corruption. Healthy controls preserve canonical flags and request debts of 0/257/32. Root’s audit binds all eight passing normal/optimized checks to the current 40-module source, with empty stderr. The corrected `dispatched` observer expectation matches the existing instrumentation and does not weaken rejection checks. No tests were rerun or files changed.

**Out-of-scope observations:** None newly identified. Actual all40 execution, aggregate review, native acceptance, adoption, and project gates remain outside this approval.

**Fix round: All findings addressed, no new Critical/Important breakage.**
