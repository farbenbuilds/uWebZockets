# P8 capability escalation, same full phase2C scope

Read task-5e3b7p8-brief.md FIRST; it remains complete requirements. One prior
implementer stopped on confidence before coordinator edits. No missingAPI or
ownershipgap was identified; source/core architecture remains accepted. You
own the entire same P8 task now on a stronger model. No task scope/gate is
dropped. Read task-5e3b7p8-first-attempt-report.md (2594B SHA256
f5720646f75deb66c7d6db1b6ac4feee88d0a795093533a1b8a3cdc45a945fcf)
and task-5e3b7p8-root-reassignment-audit.json for exactly what was done.

Root verified all39 accepted sources stillbyteexact at5072cda. Only new
test_coordinator_shutdown.py exists beyondbaseline and matches retained
acceptance-red-source.py. The existing real idle-selectionRED exits1 at
unsupportedguard beforefactory/wire. Preserve this ratherthanrepeat/fabricate
anotherinitialRED. Existing before-source/baseline-source-hashes andfresh6136
pre-edit evidence hashes are authoritative; verify them beforedependentwork.
Do not overwrite. Append to task-5e3b7p8-report.md preserving first2594B and
keep firstattempt report explicit, notclaimimplemented/GREEN/native.

Ruling on a discovered evidence-helper gap: the first baseline-capture.py is a
top-level one-shot script; its output files were interactive transcription,
not redirected raw command receipts. Preserve original script bytes and the
entire first-attempt evidence in a distinct immutable snapshot before changing
that current script into a guarded/inert helper. This recorder-only guard fix
is within existing evidence ownership, no sourceownership expansion. Do not
rerun baseline capture or relabel transcripts as raw; report old/new helper
identity and initialcapture qualification. Check all CURRENT authored helpers
inert under empty/foreign argv; historical source snapshots are evidence,
not executable current helpers. Preserve their original bytes/paths within
the snapshot and bind the mapping explicitly.

Implement incrementally using accepted canonical handlers and focused local
hooks: private originalclock/newesttime/originalcasewholegrace across callbacks;
validated copied facts beforelaterhooks; counters sealed beforeteardown;
actual parsed retained outputs/binding vs model seeds; completeidlebeforemain;
canonicalactive transport termination/no duplicatecollection. Focused helpers
withincoordinator.py are authorized. Any specific additionalmodulegap toRoot
beforeedit. No generic freeze/cleanup framework/handlerreplacement. Ordinary/
disconnect and allvaliddefaultselection semantics stay; actualall40aggregate
is later separateproof.

Same exactownership/40moduleinventory/eight normalOchecks/pinnedimmutable/
source-only/no native/Git/agents constraints. No fresh review seat until a full
report and audits. Returnconcise status/fullreportpath/commandsummary/concerns;
Root owns review andallpublicGit operations. No userpermission needed for
scoped reversible implementation. Originalfull2.2goal remainsACTIVE.
