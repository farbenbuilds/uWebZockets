# P8 fix round1: final-state validation

Same P8 v2 owner and exactoriginalownership/BASE. Read full
task-5e3b7p8-review-report.md: TWO ImportantP2 findings. No additional review
or unrelated change. Root read fix-loop before this round.

1. check_quiescent omits response credit streams and active canonical transport
   closure. Idle post injects credit.streams[999] residue, yet mainfactory runs;
   active post resets request.transport_closed/raw.closedFalse, yet succeeds.
2. Ordinary final finish_child callbacks run AFTER its onlyquiescence check;
   idle+ready mainpost raw.header+=b'x' still returns twochildsuccess.

Freeze exact reviewed40/map andallcurrentunit evidence/report before edits.
Add actualfailing regressions, retain frozen reviewedcoordinator SHA and complete
source/commands/redirected stdout/stderr/exits BEFORE fix. Test exposedpost
responseledgerresidue/eachactiveclosedflag/bothflags andordinaryfinalparser
residue withsuccessfulhealthy controls. Idle corruption stopsbeforemainfactory;
ordinary corrupted finalchild mustnotpublishsuccessfulresult. Repeat existing
intermediate/positive-debt/large/retention/time/strictreplacement tests unchanged.

Extend focused final validation and apply it after ordinaryfinish as well as
canonicalshutdown. Reject corruption, neverclearledgers/reconstructcanonical
terminalstate orzero legitimateclosedrequestdebt. Read unchangedcanonicalactive
termination contract for exactclosedfields; do notinvent activetransportflags
foridle/ordinary suppliednormalclose paths. Preserveprivateclock/facts/counts,
originalcallbackexceptions, all exactschemas andonefinalcollection semantics.
Onlycoordinator.py/newshutdowncompositiontest edits expected; any specificother
modulegap toRootbeforeedit. No core/handler/model/peer/pin/limit changes.

Afterlastedit run eight covering shutdowncomposition/ordinarycomposition/
coordinator/import normalO withdistinctfix1 labels, new40frozen/maps/structure/
identity119/prior6136/firstattempt51/currenthelperinert audit. Preserve old
final2eight/maps andallhistory/report17123Bprefix. Append exactfix report
findings/actualRED/code/currentGREEN/commands/results/frozen/current/gaps,
then concise status. Rootaudits then SAMEreviewer scopedfixdiff verdict each.

All originalpurepinned syntheticconstraints/no native/Git/subagents/services/
network/currenthelperguard/history/graphifyprefix apply. No futureunit release
oractualall40/native/adoption completion claim. Root owns allpublicoperations.
