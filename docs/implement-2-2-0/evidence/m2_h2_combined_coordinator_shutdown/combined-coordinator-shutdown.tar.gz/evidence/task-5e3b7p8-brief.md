# Idle/active shutdown coordinator composition

Released after P7 review/push at5072cda3a1862472a5326e34841744244dee79c4 (BASE).
Accepted39 source manifest docs/implement-2-2-0/evidence/m2_h2_combined_shutdown_peer/manifest.json; task-5e3b7p7-root-commit-audit.json binds publishedbytes.
Original accepted phase2C authority:
task-5e3b-coordinator-composition-plan-report.md and
task-5e3b-peer-extraction-addendum.md; full parent acceptance remains
task-5e3b-aggregate-acceptance-notes.md. No new product/native scope here.

## Ownership and supported behavior

Own coordinator.py, new test_coordinator_shutdown.py, necessary
test_coordinator.py/test_coordinator_composition.py/test_imports.py updates,
new evidence/coordinator-shutdown and task-5e3b7p8-report.md. Reuse accepted
test_shutdown.new_peer and other reviewed family constructors unchanged.
No model/core/handlers/fixture/helper/codecs/product/dependencies/limits edits.
Source39 becomes40 only for focused shutdown composition test; no generic
cleanup framework/registry/handler injection or speculative helper. If a
specific boundary requires additional ownership, report exact gap before edit.
You are not alone; preserve all others' edits/source/evidence. No subagents/
externalmodelCLI/Git/public/native execution. Root owns review/commit/push.

Support every valid catalogue selection, including idle-only, idle+main,
active-only, main ending active and omitted/default all40. Remove the artificial
unsupported-selection refusal. Preserve explicit empty without clock/factory/
child/connection/collection effects, exact identity grammar, static type/u64/
selection/duplicate/shutdown-order rejection before effects. Do not fabricate
actual all40 execution from static support: the independent actual default/
aggregate phase remains mandatory after this task.

Use catalogue.child_plan in full: optional fresh idle child completely finishes
before main child_factory, main retains caller order. Child logical identity
(run_identity,zero-based child index) stays; each child gets independent app/
context/completed IDs/output/binding/counts/connection ordinals. Whole deadline
is shared900units from original now; each child has its own ready interval
clipped to whole. Advance monotonic handoff from previous actual callback time,
not initial now/previous case start. Fresh main never inherits idle state or
earns idle through ordinary teardown.

## Exact descriptor and canonical hooks

For actual child_selection exact common keys:
identity,ready,fresh_application,connect,signal,process,post
+close iff any selected case !=shutdown_active
+disconnect_close iff disconnect selected
+preconditions iff shutdown_idle or shutdown_active selected
+termination iff shutdown_active selected.

Active-only has no unused close callback; main endingactive with preceding
ordinary/disconnect requiresclose. Validate keys/types/callables beforeconnect
and copy descriptor before callbacks. Existing connect(case,case_connection_index,
case_deadline,whole_deadline) exact7facts/strict types remains unchanged; percase
index1 or disconnect1then2 vs actual childordinal1..N. Reuse canonical
disconnect hooks and returned replacement receive. No newready/casedeadline on
replacement. Preserve all P5/P6 private time/debt/count/retention proofs.

Invoke actual adapter.run_case(...,shutdown=hooks) with the canonical hook map
including units_per_second only for selected shutdown case. Preconditions:
active client_openTrue/prior_completeTrue; idle client_openTrue/fresh_applicationTrue.
Normalclose,signal,process,post facts/signatures remain canonical. Signal
client_openTrue active andFalse idle/ordinary. Active termination exact canonical
post_signal/eof|tls_eof/primary_responseFalse/frames_validTrue/int0trailing schema.
Read unchanged shutdown validators for exact fields and types; reuse them.

Wrap supplied hooks so each result is validated/copied BEFORE another exposed
hook can mutate its returned dictionary. Keep private caller clock/newest
checked timestamp/original case+whole deadlines and final grace throughout ALL
preconditions/close/signal/termination/process/post callbacks. Callback edits to
context.now/clock/stage deadlines must not weaken expiry/rollback checks or feed
forged time to next hook/child. Existing core helper may require authoritative
time restoration; use only checked private facts, not genericcontext freezing.
Propagate original callback exceptions unchanged.

## Shutdown finalization, counters and results

Active/idle handlers collect their own final67status+metrics exactly once;
do not invoke another final_collection/finish_child, issue output GETs or read
after signal/close. Active holds its32-byte primary without END/response through
final observation, then canonical transport termination. Only handler-earned
completion is accepted; do not manufacture from model recipes or prior seeds.

Preserve private actual before records/metrics/output/binding through hooks.
Restore child-retained actual output/binding before dispatch/capture. Seal copied
canonical preconditions/release/signal/termination/process/post facts; returned
facts independent of hook-owned graphs/context. The handler's private before
comparison remains authoritative. No selected defaults replace retained facts.

Capture actual case counters and local summaries before exposed teardown hooks
can mutate them, retaining terminal canonical release facts. Count each case
once, final registrations once, disconnect shared case once plus only oldlocal
SETTINGS/informationals. Checked adds case->child->run, total finalcollections
one per nonemptychild. Ordinary subsets retain final68/finish_child and positive
late debt; no cleared parser/ledger/cumulativecaps or fakecredit at final.

Keep top-level/count/scope/child meanings. child.deadlines.case = final case,
ready/whole/grace exact original/clipped facts. child.connections exact11-key
bounded summaries case,case_connection,ordinal,case_deadline,settings,
informationals,receive_bytes,receive_calls,connection_debt,stream_debt_total,release.
Local bytes/reads not shared cumulative values; summaries length actualconncount.
Active release is canonical termination facts; no invented normalclose.
Ordinary/idle teardown exact close,signal,process,post. Active teardown exact
signal,termination,transport,process,post; transport is actual canonical result.
No live contexts/codecs/callbacks/perstream/frame/read histories in result.

## Actual proofs and scoped evidence

Use persistent independently earned app + reviewed constructors with actual
coordinator dispatch (never family check()). Fresh idle app independent ofmain;
idle teardown completes before mainfactory and no idle/postsignal wire reads.
Required actual schedules: idle-only; idle+ready; active-only; ready+active;
producer_reuse+active; idle+main including producer_reuse,disconnect,active.
Also ordinary main afteridle withoutactive and retained file output/binding
where applicable. Validate exact actual counters and derive expectations from
immutable contracts in tests, not production constants. Examples idle+ready
142heads/142small/2connections/2children/2collections; ready+active76/75/
2connections/1child/1collection. Active-only71/70/R32; idle69/69/R0.

Check descriptor missing/extra/noncallable, active-only no close, mixed main
close required, all canonical typedfact corruptions, strict/active release,
private before/fact aliases afterlaterhooks, retained selectedoutput/binding
loss, old/new contextmutation, signal/close/parser/residue beforelaterfactory,
expiry/equality/rollback across every hook andidle->main, whole notreset/grace
notextended, no duplicate final/postsignal reads, child app/counter/ordinal
independence and ordinary/disconnect regressions. Original callback errors
propagate. Static all40/default factory-boundary acceptance stays distinct
from actual representative schedules and later actual all40 run.

Before edits exactfreeze accepted baseline and FRESH exhaustive prior evidence
SHA map excluding newunitdirectory. Real acceptanceRED before implementation,
qualify unsupported preeffect rejection; every discovered bug actualRED/frozen
source beforefix. Distinct snapshot/structure/command names, no overwrites or
fabricated missing history. Afterlastedit run eight normal/-O checks for new
shutdowncomposition, ordinarycomposition, coordinator, imports; unchanged
shutdown suite only for concrete affecteddependency. All40 AST/main guards/
actual inertempty+foreignargv andauthoredrecorders; pinnedPython -B-S, immutable
119authority/118physical113resolved/42orderedcodec unchanged. No assertions/
classes/hiddenmutableglobals/deadcode/camelCase/silencederrors/nesting>3.

Source-only pinned in-memory codecs and supplied synthetic app/transport/
ownership facts. No native/build/server/socket/SSLContext/TLSclose/realclock/
processownership/transfer/kernel/fault/race/cancel/schedule/panic/crash/leak/
oldruntime/network/installs. Required fullproject/native gates remainlater.
Pinned interpreter /home/codespace/.python/current/bin/python3 resolves
/usr/local/python/3.14.2/bin/python3.14 SHA256
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
Execute every direct Python -B -S; optional -O only optimized checks.
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
Immutable identity authority evidence/coordinator-a/immutable-inputs.json,
119entries/118physical113resolved and42orderedcodec defaultJSON digest
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Graphify before NEW codebasequestion/search/source read:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650
Provided paths located. Read applicable project/role/narrow skill instructions;
no need unrelated Zig build skills for this pure Python source slice.
Fullreport exact changes/commands/raw/source/red/green/inputs/history/selfreview/
gaps then concise status; Root freshreview/qualifiedpublication/commit+push.
Actualdefault/all40 aggregate/broadcombinedreview/runtime/native/twochild/
adoption/everyoriginalmilestone remains mandatory after this slice.
