# Phase2C shutdown coordinator source review

One full P8 source task, not native/aggregate approval. Requirements
task-5e3b7p8-brief.md + accepted
task-5e3b-coordinator-composition-plan-report.md phase2C; reassignment/helper
preservation ruling task-5e3b7p8-reassignment-brief.md. Claims
task-5e3b7p8-report.md 17123B SHA256
57647d4d516926d8b7212748babe32f33d1120f6dff724008b0e95c95c29a6ed.
Full diff task-5e3b7p8-review-source.diff 56943B SHA256
003e85980f5342f6067bef699ed9d6fc7f39e24f74b795b5a7b026c8400e192e.
BASE/HEAD5072cda3a1862472a5326e34841744244dee79c4/no taskcommit; ignored
source40 vsaccepted39. Rootfinalaudit task-5e3b7p8-root-final-audit.json:
3changed coordinator/test_coordinator/test_imports,1newtest_coordinator_shutdown,
36unchanged including ordinarycomposition/ALL peers/handlers/core/model/codec.

Exact parent/globalconstraints in originalbrief remain authority. Bindingfocus:
- FULLvalid40/default selection support distinctfromactual8representatives,
  lateractualdefault/all40aggregate; emptyzeroeffects/malformedorder/static
  identity/u64 validation beforeeffects. cataloguechildplan optionalfreshidle
  fullyfinishesbeforemainfactory, callerorderedmain; separateapp/counts/IDs/
  observations/ordinals/ready perchild, oneoriginalwhole900.
- Exactconditionaldescriptor common7 +close iffany!=active +strict iffdisco
  +preconditions iffshutdown +termination iffactive. Activeonlynoclose, mixed
  requiresclose; mapsvalidated/copiedbeforeconnect. Canonicalactualrun_case
  hooks/units onlyforselectedlifecycle, nohandlerinjection/genericcleanup.
- Idle/active handler ownsfinal68/canonicalcompletion once; no duplicateGET/
  collection/finish orpostsignalreads. Activeheld32bytes/noEND/noresponse until
  canonicalpostsignaltermination. Ordinaryfinal68/privatefinish andP6strict
  replacement/time/debt/accounting preserved; no earnedidle viaordinaryteardown.
- PRIVATEoriginalcallerclock/newestcheckedtime/originalcasewhole/oneclipped
  grace acrosspreconditions/close/signal/termination/process/post ANDidle-main.
  Exposednow/clock/deadline rewrites cannotforgeauthority/expiry/rollback.
  Exacttypedcanonicalfacts copied beforelaterhookcanmutate. Callbackexception
  object/priority preserved. No refreshedgrace/receivebudget/debtreset.
- Actualcounter/local11-keysummarycapture beforeteardownexposure; restoration
  ONLYalreadyobservedscalar accounting neededforcanonicalcountcheck, never
  manufacturecompletion/clearparser/debt/canonicaltransporttransition. Count
  case+finalonce/disconnectsharedcaseonce +oldlocalSETTINGS/infoonly. Preserve
  localbytes/reads/positivecloseddebt/finalactualcontexts+receiver.
- Privateactualbefore/output/binding retainedthroughpreconditions/teardown and
  fresh/replacementcontext; no modelseed/defaultselectedfacts. Canonicalhandler
  beforecomparison staysprivate. Returnedgraphs copied/finite/noliveobjects.
  Activeexactteardown signal,termination,transport,process,post; ordinary/idle
  close,signal,process,post. Activerelease actualterminationfacts/nofakeclose.
- Finalcanonicalterminal/quiescence beforechildreturn/nextfactory, including
  exposedhook parserresidue/mutation, without weakeningheldprimary semantics.

Named cross-boundaryrisks: new shared helper calls acrossordinaryfinish/
disconnect; scalarrestore accidentally masks realterminaldebt/parser/state
corruption; time authority at everyhook/nextchild; copiedfact andprivatebefore
graphs surviving laterhook/oldcontext mutation; exactactivecanonicaltransport
result vsaliases; summarycapturetiming/localvscasecumulative; retainedactual
outputs beforeprecondition andafterreplacement. Outside-diffchecks onlyneeded
foroneconcretenamedrisk/explicitcanonicalseam, not broadcrawl.

Actual8observedselectiontotals inRootaudit/report: idle69/69/R0/1conn;
idle+ready142/142/R257/2conn/2collections; active71/70/R32;
ready+active76/75/R289/2conn; producer+active80/78/R96;
idle+producer+disco+active174/171/R160/5conn/2collections;
idle+producer+ready151/150/R321/3conn/2collections;
file+active78/76/R65/2conn. ActualSettings etc rawstdout inunit evidence.
Reported86descriptor/75typedfact/40hooktime controls/receiver/scopes/aliases/
residue/wholeclip/loss/tls_eof. Verifytests actuallyinvokeassertions.

Root independently verified baseline39/current40 and EIGHTfinal2 snapshots/
maps/flags/exit0/emptyerr/stdouthashes. audit.py check runpy executes module in
the SAME pinned interpreter optimization mode. Prior6136hashes/first51mapped
files/report2594Bprefix unchanged;119authority118physical113resolved+42ordered
codecs verified. Firstattempt confidenceBLOCKED superseded byappendedcandidate,
notmissingAPI. Originalbaselinehelper/top-levelbytes preserved; currentguarded
helpernotcapture-executed. Initialbaselineoutputs explicitlyinteractive
transcription, notraw. InitialacceptanceREDpre-effects; actualshutdownhooksRED
startupbeforebodyschedule; genuineintermediateterminalresidueRED1 beforefix;
earlierfinal8 distinctfromcurrentfinal2eight. Current2helpers inertimport/main
emptyforeignargv; historicalfrozen source artifacts notcurrentexecutables.

ApplyAGENTS/CODING/code-review-and-quality andexplicitRoot-requested
thermo-nuclearstructural lens/projectoverride. Read diffonce/testsfirst/context10;
changedfile rereadonlycutoff withreason. No passed-suite repeats; focusedpinned
purecodec sensitivityonly forunansweredconcretedoubt. Read-only/noagents/
files/Git/services/native/server/socket/SSLContext/TLSclose/realclock/process/
build/oldruntime/network/fault/race/schedule/cancel/panic/leak execution.
Suppliedsyntheticfaultswitches andpurein-memorybytes allowed; no nativeprobes.
ExactpinnedPython/PYTHONPATH/graphifyprefix inbrief, providedpaths located;
graphify beforeNEWcodebasequestion/search. ReturnFULLSPEC/QUALITY/strengths/
actionable severity/fileline/scenariofindings andcannotverifyboundaries.
No codefix yourself;Root savesverdict/routesfixlooptoP8v2owner. All40aggregate/
broadreview/runtime/native/twochild/adoption/fullmilestones remainmandatory.
