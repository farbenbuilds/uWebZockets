# Phase 2C implementation handoff: blocked

No coordinator implementation has been made. The 39 current source hashes matched the accepted `docs/implement-2-2-0/evidence/m2_h2_combined_shutdown_peer/manifest.json` before edits. `evidence/coordinator-shutdown/before-source/` and `baseline-source-hashes.json` freeze that source, and `prior-evidence-hashes.json` contains a fresh map of 6,136 existing evidence files excluding the new unit directory. The pinned Python resolved SHA-256 was `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`. The baseline command and script are retained in `baseline-capture.command` and `baseline-capture.py`; output was captured interactively and transcribed to the adjacent stdout, stderr, and exit files, not redirected during the command.

Added `test_coordinator_shutdown.py` containing one factory-boundary idle selection acceptance check. Its frozen test source is `evidence/coordinator-shutdown/acceptance-red-source.py`. The exact command and raw output are retained in `acceptance-red.command`, `.stdout`, `.stderr`, and `.exit`. Exit 1 ends with `ValueError: coordinator selection not yet supported` from coordinator.py line 160. This is an actual pre-effect unsupported-selection RED, not a wire execution, child construction, or proof of shutdown behavior.

The requested implementation remains blocked on implementer confidence, not on an identified missing API or ownership boundary. The interaction between handler-owned final collection, mutable callback-exposed context, private monotonic time and retained output snapshots requires a complete design and exhaustive proof together. I cannot currently establish that an incremental change would preserve all of those invariants and the required ordinary/disconnect behavior; the implementer workflow directs escalation rather than an uncertain partial implementation. Root should reassign or split the implementation under the accepted plan. No extra source ownership is requested.

No GREEN, post-edit focused suite, AST/import/identity audit, all40 actual execution, runtime/native gate, or full project check was run. The new test is intentionally failing and has not been added to the import inventory. No source outside the new test and evidence/report paths was edited. No Git, native, network, real clock, server, socket, TLS-close, build, or process-ownership operation was executed. No commits were created. Self-review: baseline source identity and the limited RED are supported by their retained artifacts; all requested behavior and verification remain outstanding.

## Reassigned implementation continuation: complete candidate for Root review

The first 2,594 bytes above are unchanged historical first-attempt reporting. This continuation supersedes its implementation status, not its evidence qualifications. BASE remains `5072cda3a1862472a5326e34841744244dee79c4`. No Git operation, commit, push, external model, subagent, native build, server, socket, SSLContext, real clock, TLS close, or process-ownership execution occurred.

Implemented the full accepted phase 2C coordinator slice. The unchanged catalogue child plan now drives optional idle and main children serially; idle post-deinit finishes before the main factory. Each child owns independent completed IDs, observations, counts, connection ordinals, and application/transport facts. Main retains caller order. Explicit empty stays effect-free; malformed static/selection/order/identity inputs still reject before effects. Explicit all40 and omitted default now reach their first factory boundary. Those checks are static support evidence, not actual all40 execution.

The descriptor uses the exact case-dependent key set: active-only omits close, mixed main requires it, disconnect adds its canonical strict-close hook, and shutdown adds preconditions plus active termination as appropriate. Validated descriptor callbacks are copied before connect. Shutdown invokes the actual unchanged adapter/handler with canonical hook keys and units only for shutdown cases. Active/idle handlers own their final collection and canonical completion; coordinator never appends another collection or ordinary finish. Active preserves the held 32-byte request through final observations and then returns the actual canonical transport result. Ordinary subsets preserve final68, positive late debt, and existing disconnect replacement semantics.

Focused coordinator helpers preserve original clock, original case/whole deadlines, one clipped grace deadline, and newest checked callback time. Callback edits to exposed now/clock/deadlines cannot widen expiry or roll back the handoff. Hook results are validated and copied before another exposed hook runs. Actual counters and bounded local connection summaries are sealed before teardown; only already-observed scalar accounting is restored for the canonical handler's later count check, with terminal state remaining handler-owned. The existing private handler before comparison stays authoritative. Child-retained parsed outputs/binding are restored before shutdown preconditions complete and before fresh/replacement dispatch; selected facts are never reconstructed from recipes. Published result graphs contain copied observations and exact bounded summaries, with no live contexts, codecs, or callbacks.

Changed source files under `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/`:

- `coordinator.py`: child-plan orchestration, canonical shutdown hook adapters, private callback time/count/fact retention, shutdown result capture, shared local-summary/retained-observation helpers, and post-shutdown quiescence validation.
- `test_coordinator_shutdown.py`: new focused actual composition and adversarial suite using the reviewed peer constructors unchanged.
- `test_coordinator.py`: removed obsolete expected refusal of valid shutdown/default selections from static rejection checks. The new suite explicitly proves their factory acceptance; malformed/order/empty/static checks remain.
- `test_imports.py`: added the new module to the exact 40-module inventory.

`test_coordinator_composition.py` and all reviewed family peers/handlers/core/model/codecs remain unchanged. The final audit proves 36 of the accepted39 source files unchanged, three changed, one new, 40 total. All evidence edits are under the newly owned `evidence/coordinator-shutdown/`; this report is the sole edited report.

### Preserved history and RED/GREEN evidence

Before dependent edits, pinned Python verified all39 accepted current and before-source hashes, the fresh6136 prior-evidence map, the new test against the frozen acceptance RED, and the report's 2,594-byte SHA-256. These checks were an interactive tool invocation; `reassignment-preservation.json` is its written hash/mapping result, not a redirected stdout receipt. No baseline capture was rerun. Fifty-one first-attempt evidence files plus the original report were copied into `first-attempt-preserved/`, then made read-only. The explicit mapping is in `reassignment-preservation.json`; `preserved-report-identity.json` separately binds the report copy. Existing baseline stdout/stderr/exit remain explicitly interactive transcription, never relabeled raw.

Original baseline helper SHA-256: `526c2d3c8ae3f37cd4715eb78b17a04e4dde4c634adfb322505da0f9da63e37d`. Its original bytes remain in that preserved mapping. Current guarded helper SHA-256: `6217f29910665e4df2524063417020bce519735effd96c6928d743f15abac5f1`. The current helper requires explicit `--capture`; it was not executed in capture mode. Both current authored helpers (`baseline-capture.py`, `audit.py`) are proven inert on import AND as main under empty and foreign argv. Historical source snapshots are evidence, not current executable helpers.

Retained progression, with no overwritten attempts:

- Original `acceptance-red.*`: exit1, unsupported idle selection before factory/wire effects. Reused as authorized; not repeated or fabricated.
- `child-loop.*`: exit0, idle selection reached the factory boundary after child-plan extraction.
- `actual-shutdown-red.*`: exit1 at canonical `shutdown hooks required`, after real coordinator connection/startup but before a shutdown body schedule. Source and structure are frozen separately.
- `shutdown-hooks.*`: exit0 for all eight representative actual schedules after canonical hook integration.
- `ordinary-regression.*`, `composition-regression.*`: exit0 for existing coordinator and ordinary/disconnect behavior.
- `adversarial-first.*`: exit0 for the initial descriptor/fact/time/privacy/error matrix.
- `terminal-residue-red.*`: actual exit1 regression exposing success despite a teardown hook inserting parser residue; idle could otherwise advance to main. Frozen source precedes the fix. The fix reuses a focused quiescence predicate after canonical shutdown completion, before child return/main creation.
- `terminal-residue-green.*`: exit0 after the residue fix, including retained-output and whole-clipping checks.
- `final-*`: eight passing covering checks before the final exact local-summary/scope assertions were added. Preserved as intermediate evidence.
- `final2-*`: the eight final covering checks below, after the last source edit. `covering-receipts.json` independently matches all eight source maps to current40 and confirms exit0 and empty stderr for every check.

Each check driven by `audit.py check` saves its own source directory, source-hash JSON, AST-structure JSON, command/environment JSON, redirected stdout/stderr, and exit file. The three earlier direct test commands and the standalone audits/Graphify commands have separately named `*.command-metadata.json` recorded after execution; those metadata files accurately identify their already-retained redirected receipts. They do not claim contemporaneous command-metadata capture.

### Actual results and final verification

All direct Python execution used `/home/codespace/.python/current/bin/python3 -B -S`, with `-O` only for optimized checks. Resolved interpreter `/usr/local/python/3.14.2/bin/python3.14` SHA-256 remains `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`. Test/audit environment:

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
```

The executed command form was `/home/codespace/.python/current/bin/python3 -B -S` (plus `-O` for optimized rows), followed by `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/coordinator-shutdown/audit.py check LABEL MODULE`:

| LABEL | MODULE | Mode | Exit |
| --- | --- | --- | --- |
| final2-shutdown-normal | test_coordinator_shutdown | normal | 0 |
| final2-shutdown-optimized | test_coordinator_shutdown | -O | 0 |
| final2-test_coordinator_composition-normal | test_coordinator_composition | normal | 0 |
| final2-test_coordinator_composition-optimized | test_coordinator_composition | -O | 0 |
| final2-test_coordinator-normal | test_coordinator | normal | 0 |
| final2-test_coordinator-optimized | test_coordinator | -O | 0 |
| final2-test_imports-normal | test_imports | normal | 0 |
| final2-test_imports-optimized | test_imports | -O | 0 |

Actual coordinator schedules use empty-start persistent apps and unchanged constructors, with actual coordinator dispatch, no family `check()` calls, no seeded prior completions, and no handler replacement. Tests instrument the original dispatcher and final collector exactly once per invocation. Observed heads/small/flow/connections/collections:

| Selection | Heads | Small | Flow | Connections | Collections |
| --- | ---: | ---: | ---: | ---: | ---: |
| idle | 69 | 69 | 0 | 1 | 1 |
| idle, ready | 142 | 142 | 257 | 2 | 2 |
| active | 71 | 70 | 32 | 1 | 1 |
| ready, active | 76 | 75 | 289 | 2 | 1 |
| producer_reuse, active | 80 | 78 | 96 | 2 | 1 |
| idle, producer_reuse, disconnect, active | 174 | 171 | 160 | 5 | 2 |
| idle, producer_reuse, ready | 151 | 150 | 321 | 3 | 2 |
| stream_file, active | 78 | 76 | 65 | 2 | 1 |

The full printed results also check actual SETTINGS/informational/reset totals. Every connection summary has the exact11-key schema and matches pre-release local bytes/reads/settings/informationals/debts, case-local indices, child ordinals, and original deadlines. Fresh transport scopes are independent. Tests cover 86 descriptor failures before connect, 75 canonical typed/non-dict fact corruptions, every idle freshness/strict-close field's missing/wrong type, 40 shutdown-hook expiry/equality/rollback/type cases, original callback exception identity, copied fact aliases, private before/output/binding forgeries, missing retained producer/file observations, old idle-context mutation, positive time/count mutation, idle-main actual last-callback handoff, whole clipping, late observation/duplicate-final rejection, parser residue, and canonical `tls_eof`. Ordinary/disconnect regressions remain independently covered by their unchanged suite.

Executed `audit.py verify prefinal-audit` and, after the final source edit, `audit.py verify final-audit`: both exit0, redirected stderr empty. The final audit uses the unchanged reviewed `evidence/core-peer/audit.py` identity/structure routines. It verifies authority119 entries =118 physical identity rows plus the ordered-codec aggregate; 114 textual paths resolve to113 files. It separately rehashes all42 ordered codec files and the interpreter. Codec digest remains `0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`. `final-audit/immutable-inputs.json` is byte-identical to the immutable authority. AST checks cover all40 modules, maximum control nesting3, no class/assert/global or mutable module containers. The two final import runs cover exact inventory, main guards, and actual inert imports under empty/foreign argv with forbidden effects intercepted. Current helpers also pass import/main inertness under both argv forms. Prior6136 evidence, preserved51 first-attempt files, and frozen report prefix all verify unchanged.

Graphify queries used the required isolated tool environment before new codebase searches. Executed twice (the second after the final source edit):

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .
```

Both exited0, reported AST-only/no LLM and no relevant changes; ignored working source did not change the graph. `graphify-update.*` and `graphify-final.*` retain separate raw receipts. Broad query output was budget-truncated; provided paths and already-located canonical code supplied the implementation context.

### Self-review and remaining scope

Self-review applied incremental implementation, TDD, codebase-design, debugging/error recovery, and code-review-and-quality. The residue defect was reproduced and frozen before its focused fix. The final diff keeps module ownership, original adapters/handlers, unchanged catalogue/model/codecs, bounded result schemas, callback error identity, checked aggregation, and mandatory acceptance boundaries. Scalar counter restoration is based only on actual already-completed wire observations; it does not manufacture completion, erase debt, reset parsers, or replace canonical transport transitions. No generic freezing framework, cleanup registry, handler injection, or new dependency was added. The scoped unified diff is `final-audit/scoped.diff`; exact final source identities are in `covering-receipts.json`.

Inherited skill-reference drift remains documented: `using-agent-skills` references absent `.agents/references/definition-of-done.md`. Root confirmed this was already recorded, is not a missing named skill, and project rules plus exact P8 acceptance govern this slice. No skill file or missing document was invented or installed.

No unresolved implementation ownership/API gap is identified. Root's independent review, integration, publication qualifications, and Git actions remain required. Actual default/all40 aggregate execution, broad combined review, runtime/strict-close/owned-process preparation, sequential two-child native acceptance, adoption, and every original milestone remain mandatory later phases. This candidate establishes only `pure_client_synthetic_peer` results.

UNRUN by the explicit source-only release: `zig fmt src builds examples tests fuzz`, `sh scripts/check_conventions.sh`, `sh scripts/check_release_version.sh`, `zig build test`, and all broader native/platform/sanitizer/compliance/fuzz/build/runtime gates. No gate was weakened or claimed passed. The unchanged standalone shutdown suite was not rerun because no handler/core/peer dependency changed; real coordinator shutdown schedules exercise those unchanged handlers through the new wrappers. No performance, native TLS/process, kernel, race, scheduling, cancellation, panic, crash, leak, or full2.2 completion claim is made.

## P8 fix round 1: both final-state findings addressed

This append preserves the full previously reviewed 17,123-byte report prefix. Scope is exactly the two Important/P2 findings in `task-5e3b7p8-review-report.md`; no future unit or broader milestone is released.

Before edits, pinned Python matched current40 against the reviewed `covering-receipts.json`, verified the report identity, and froze all40 source files, all1,278 current unit evidence files, and the report under read-only `fix1-preserved/`. `fix1-preservation.json` binds that complete map. This includes the prior final2 eight receipts, prior RED/GREEN attempts, first-attempt preservation, and earlier audit outputs. `fix1-history-audit.json` subsequently verified every mapped current and preserved evidence file unchanged, the report17123B unchanged before append, and only the two assigned source files changed relative to the reviewed40. These preservation/hash checks were interactive pinned-Python tool invocations producing written JSON audit results; their console output is not claimed as redirected raw receipts.

Finding 1 is addressed by rejecting nonempty response-credit streams in the existing quiescence predicate and checking canonical active `request.transport_closed is True` and `raw.closed is True` before publishing shutdown results. The active check uses the private child selection. The unchanged canonical `wire.finish_termination`, `request_credit.transport_end`, and `raw_observer.finish_termination` establish those two fields. Idle and ordinary normal-close paths are not required to have active transport flags.

Finding 2 is addressed by invoking the quiescence predicate immediately after ordinary `finish_child()` returns, before the child is published. This covers mutations made by its close/signal/process/post callbacks. No additional collection, wire read, clock read, state clearing, or transport transition is introduced.

Only these source files changed this round:

- `coordinator.py`: two strict active-closed flag checks, response-ledger emptiness in quiescence, and the post-ordinary-finish quiescence call. SHA-256 `75ccc55642de0733108c15838e9dce2a3770ae0144f652f9e2960c0d3acaac53`.
- `test_coordinator_shutdown.py`: six exposed-post mutation regressions and healthy final-state controls. SHA-256 `fd25ee747d7ad478b3ee295a2136abaf8981be72c39262bf2edf8bfcfd5e97c4`.

The focused reviewed-to-fix diff is `evidence/coordinator-shutdown/fix1-scoped.diff`. All other38 reviewed source files and both current evidence helpers remain unchanged. No core, canonical handler, peer, model, codec, pin, or limit changed.

### Actual REDs and the corrected test observation

After adding the tests but before changing coordinator, `audit.py snapshot fix1-red` froze all40 modules and structure. Reviewed coordinator SHA-256 was still `22cb10c287e084e51f9673d056d12fbf5527fee9ca211b4653f2cc05d679145d`; `fix1-red-verified.json` and each RED command receipt verify that identity.

Using the exact PYTHONPATH above, the command for each mode was:

```sh
/home/codespace/.python/current/bin/python3 -B -S -c 'import sys; import test_coordinator_shutdown as test; test.check_final_state_corruption(sys.argv[1])' MODE
```

All six modes independently exited1 with `ValueError: final-state corruption accepted: MODE`: `idle_response_ledger`, `active_request_closed`, `active_raw_closed`, `active_both_closed`, `ordinary_parser`, and `ordinary_response_ledger`. The actual coordinator returned success despite the injected corruption in each run. Raw redirected stdout/stderr and exit files are `fix1-red-MODE.*`; separately named command JSON, recorded after execution, identifies exact argv/environment and frozen source. These are new actual pure-codec REDs, not a restatement of the reviewer's observations.

The first post-fix normal and optimized runs, `fix1-final-shutdown-normal.*` and `fix1-final-shutdown-optimized.*`, correctly rejected idle ledger residue but exposed a test observer-order mistake: canonical shutdown returns through the original-dispatch instrumentation, which emits `dispatched` after `post` and before coordinator validation. Both exit1 attempts and their complete source/structure/command/raw receipts are retained. The test now expects `dispatched` for handler-owned shutdown and `post` for ordinary finalization; rejection messages, injected-state preservation, and the ban on later main-factory creation remain mandatory. No production check was relaxed for this correction.

The six tests also verify that the offending response ledger/parser bytes/closed flags remain corrupted after rejection. The coordinator therefore rejects the corruption rather than clearing ledgers or reconstructing terminal state. Healthy idle/ordinary/active controls verify exact canonical flags, empty response-credit streams, and legitimate request debts of0/257/32 respectively, including the published connection summaries.

### Final covering evidence

After the last source edit, all eight following checks passed with exit0 and empty stderr. Each command used the pinned interpreter with `-B -S`, adding `-O` only for optimized rows, and the exact supplied PYTHONPATH. Command form:

```text
/home/codespace/.python/current/bin/python3 -B -S [-O] .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/coordinator-shutdown/audit.py check LABEL MODULE
```

| LABEL | MODULE | Mode | Exit |
| --- | --- | --- | --- |
| fix1-covering-shutdown-normal | test_coordinator_shutdown | normal | 0 |
| fix1-covering-shutdown-optimized | test_coordinator_shutdown | -O | 0 |
| fix1-covering-test_coordinator_composition-normal | test_coordinator_composition | normal | 0 |
| fix1-covering-test_coordinator_composition-optimized | test_coordinator_composition | -O | 0 |
| fix1-covering-test_coordinator-normal | test_coordinator | normal | 0 |
| fix1-covering-test_coordinator-optimized | test_coordinator | -O | 0 |
| fix1-covering-test_imports-normal | test_imports | normal | 0 |
| fix1-covering-test_imports-optimized | test_imports | -O | 0 |

`fix1-covering-receipts.json` independently matches all eight frozen source maps to current40 and binds their command/source/structure/raw stdout/stderr identities. Final shutdown stdout starts with the healthy debt/flag control and six rejection messages, then retains every previous representative schedule and adversarial check. The unchanged ordinary/disconnect suite repeats intermediate release, positive debt, large uploads, retained outputs/binding, private time, and strict replacement checks. The unchanged coordinator and import suites pass in both modes.

Executed `/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/coordinator-shutdown/audit.py verify fix1-final-audit`: exit0, empty redirected stderr. Its distinct output directory and receipts prove authority119/118 physical rows/113 resolved files plus42 ordered codecs and the unchanged interpreter hash; all40 AST modules with maximum nesting3 and no class/assert/global/mutable module containers; both current helpers inert on import and main under empty/foreign argv; prior6136 evidence, first-attempt51 preservation and the original report2594B prefix unchanged. The separate fix1 history audit extends preservation to all1,278 reviewed unit files and the report17123B prefix. Both final import runs check exact inventory, main guards, and actual inert imports under empty/foreign argv.

Executed the required isolated Graphify `query` before the new codebase read, then the unchanged prescribed `graphify update .` command after the final edit. Update exited0 with AST-only/no relevant changes; distinct raw receipts are `fix1-graphify.stdout`, `.stderr`, and `.exit`. No semantic model or network operation ran.

Self-review: both reported paths now fail before successful child publication; idle residue stops before main factory. Active closed-state validation is restricted to canonical active shutdown. The added response-ledger check does not require outbound request debt to be zero, and healthy controls plus unchanged composition tests preserve that distinction. Final validation is pure and does not change callbacks, time, counters, observations, result schema, or collection ownership. Both findings are addressed without extra source ownership or a known remaining gap.

No Git operation or commit was made. Native/build/full-project checks remain UNRUN under the original source-only release, including `zig fmt src builds examples tests fuzz`, convention/release checks, and `zig build test`. Actual all40 aggregate execution, native TLS/process/two-child proof, adoption, and all remaining original milestones remain pending. Root owns audit and the same reviewer's focused per-finding verdict on this fix diff.
