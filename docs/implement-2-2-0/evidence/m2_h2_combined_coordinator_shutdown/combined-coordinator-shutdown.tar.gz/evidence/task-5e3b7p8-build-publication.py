"""Package reviewed idle/active coordinator composition and its actual evidence."""
import hashlib
import json
import runpy
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    provenance = Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_peer/combined-core-peer.tar.gz')
    if sha(provenance.read_bytes()) != 'dbcd7a01a56a3c80600aa39fa7b61dec00060976c14a82e2bd4a712a2520d25d':
        raise ValueError('Writer provenance differs')
    builder = plan / 'task-5e3b7p1-build-publication.py'
    with tarfile.open(provenance, 'r:gz') as previous:
        if previous.extractfile('evidence/' + builder.name).read() != builder.read_bytes():
            raise ValueError('Published writer source differs')
    writer = runpy.run_path(str(builder))['load_writer'](plan)
    baseline = Path('docs/implement-2-2-0/evidence/m2_h2_combined_shutdown_peer/combined-shutdown-peer.tar.gz')
    if sha(baseline.read_bytes()) != 'd8d2f3a5b78668539bbdc995a5d071cbe1bd9acd3f635542afe09bbc9e2c6f24':
        raise ValueError('Baseline archive differs')
    members = {}
    with tarfile.open(baseline, 'r:gz') as previous:
        inventory = json.loads(previous.extractfile('INVENTORY.json').read())
        for member in previous:
            if not member.isfile():
                raise ValueError('Nonregular baseline member')
            if member.name == 'INVENTORY.json':
                continue
            data = previous.extractfile(member).read()
            if inventory[member.name] != dict(size=len(data), sha256=sha(data)):
                raise ValueError('Baseline inventory differs')
            if member.name.startswith('reference/'):
                writer['add'](members, member.name, data)
            if member.name.startswith('source/current/'):
                writer['add'](members, member.name.replace('source/current/', 'history/shutdown-peer-source/', 1), data)
    audit = json.loads((plan / 'task-5e3b7p8-root-fix-1-audit.json').read_text())
    current = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if current != audit['current_source_sha256']:
        raise ValueError('Approved source differs')
    for path in sorted(source.glob('*.py')):
        writer['add'](members, 'source/current/' + path.name, path.read_bytes())
    raw = source / 'evidence/coordinator-shutdown'
    for path in sorted(raw.rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink in evidence')
        if path.is_file():
            writer['add'](members, 'raw/coordinator-shutdown/' + path.relative_to(raw).as_posix(), path.read_bytes())
    names = ('task-5e3b7p8-brief.md', 'task-5e3b7p8-report.md', 'task-5e3b7p8-reassignment-brief.md',
             'task-5e3b7p8-first-attempt-report.md', 'task-5e3b7p8-root-reassignment-audit.json',
             'task-5e3b7p8-review-brief.md', 'task-5e3b7p8-review-report.md',
             'task-5e3b7p8-review-source.diff', 'task-5e3b7p8-root-final-audit.json',
             'task-5e3b7p8-fix-1-brief.md', 'task-5e3b7p8-fix-1-review-brief.md',
             'task-5e3b7p8-fix-1-review-report.md', 'task-5e3b7p8-fix-1-review.diff',
             'task-5e3b7p8-root-fix-1-audit.json', 'task-5e3b7p8-build-publication.py',
             'task-5e3b-peer-extraction-addendum.md', 'task-5e3b-coordinator-composition-plan-report.md',
             'task-5e3b-aggregate-acceptance-notes.md')
    for name in names:
        writer['add'](members, 'evidence/' + name, (plan / name).read_bytes())
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_combined_coordinator_shutdown')
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'combined-coordinator-shutdown.tar.gz'
    inventory = writer['write_archive'](archive, members)
    original = json.loads((plan / 'task-5e3b7p8-root-final-audit.json').read_text())
    summary_keys = ['case', 'case_connection', 'ordinal', 'case_deadline', 'settings', 'informationals',
                    'receive_bytes', 'receive_calls', 'connection_debt', 'stream_debt_total', 'release']
    manifest = dict(scope='Idle/active child coordinator composition with bounded synthetic peers',
                    base_commit=original['base_commit'], baseline_archive_sha256=sha(baseline.read_bytes()),
                    archive=archive.name, archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
                    safe_regular_text_members=len(members), inventory_entries=len(inventory), current_source_files=current,
                    changed_files=original['changed'], added_files=original['added'], unchanged_baseline_modules=36,
                    supported_case_count=40, explicit_empty_supported=True, default_supported=True,
                    actual_all40_executed=False, observed_actual_schedules=original['observed_actual_schedules'],
                    current_normal_optimized_commands=8, preceding_final2_commands=8, preceding_final_commands=8,
                    current_ast_inert_import_files=40, current_guarded_evidence_helpers=2,
                    fresh_pre_edit_evidence_hashes_checked=6136, first_attempt_preserved_files=51,
                    reviewed_pre_fix_unit_files_preserved=1278, actual_final_state_review_red_count=6,
                    preserved_initial_report_bytes=2594, retained_identity_entries=119, physical_identity_rows=118,
                    unique_resolved_paths=113, ordered_codec_files=42, connection_summary_keys=summary_keys,
                    handler_owned_collection_and_termination=True, idle_finishes_before_main_factory=True,
                    private_callback_time_facts_and_observed_counters=True, retained_actual_outputs_binding=True,
                    final_response_ledger_and_active_terminal_validation=True, ordinary_post_teardown_validation=True,
                    actual_intermediate_parser_residue_red=True, actual_final_state_review_reds=True,
                    initial_red_scope='Unsupported idle selection before effects',
                    initial_baseline_receipts='Interactive transcription; original helper preserved, current helper guarded',
                    source_review='Spec and quality approved after two final-state validation fixes',
                    supplied_transport_lifecycle_facts=True, native_executed=False, milestone_complete=False,
                    remaining=['Remaining family peer extraction and actual default/all40 aggregate',
                               'Broad combined-client review and runtime/native/full gates', 'Production adoption'])
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
                  regular_members=len(members), inventory_entries=len(inventory), source_modules=len(current),
                  all_reopened_member_bytes_exact=True, native_executed=False)
    (plan / 'task-5e3b7p8-root-archive-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
