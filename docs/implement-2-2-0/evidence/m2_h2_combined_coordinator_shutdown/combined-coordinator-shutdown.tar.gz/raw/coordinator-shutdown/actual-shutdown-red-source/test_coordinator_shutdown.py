"""Shutdown composition over independently earned persistent synthetic apps."""
import copy
import json
from unittest import mock
import adapter
import catalogue
import coordinator
import model
import test_core_peer
import test_file_early
import test_lifecycle
import test_producer_pressure
import test_shutdown


def require(value, message):
    if not value:
        raise ValueError(message)


def run_selection(selection, control=None, *, start=2, units=1000, outcome='eof'):
    state = dict(clock=start, children=[], events=[], facts=[], collections=[], dispatches=[])

    def clock():
        return state['clock']

    def event(phase, child, context=None, fact=None, deadline=None):
        state['events'].append((phase, child['index']))
        if fact is not None:
            state['facts'].append(fact)
        if control is not None:
            control(phase, state, child, context, fact, deadline)

    def factory(identity, index, selected, ready, whole):
        require(index == len(state['children']) and (index == 0 or state['children'][-1]['posted']),
                'main factory before idle post')
        child = dict(index=index, selection=selected, app=test_core_peer.new_app(), prior=[], peers=[],
                     posted=False, signaled=False, closed=False, contexts=[], releases=[], ready=ready, whole=whole,
                     case_evidence=test_lifecycle.new_case_evidence(), deadlines=[])
        state['children'].append(child)
        app = child['app']

        def connect(case, number, case_deadline, whole_deadline):
            require(case == selected[len(child['prior'])] and not child['signaled'], 'connect ordering differs')
            args = dict(app=app, prior=tuple(child['prior']), now=clock(), clock=clock)
            if case in ('shutdown_idle', 'shutdown_active'):
                peer = test_shutdown.new_peer(case, **args)
            else:
                args['final'] = case == selected[-1]
                peer = ordinary_peer(case, number, child['case_evidence'], args)
            child['peers'].append(peer)
            child['deadlines'].append((case, number, case_deadline, whole_deadline, clock()))
            event('connect', child, fact=peer['connection'], deadline=case_deadline)
            return peer['connection']

        def preconditions(context):
            require(tuple(child['prior']) == context['selected_before'], 'prior was not earned')
            facts = dict(client_open=True, prior_complete=True) if selected[-1] == 'shutdown_active' else dict(client_open=True, fresh_application=True)
            event('preconditions', child, context, facts, context['stage']['case_deadline'])
            return facts

        def close(context, deadline):
            require(not child['signaled'], 'close after signal')
            child['contexts'].append(context)
            child['releases'].append(local_summary(context))
            child['peers'][-1]['state']['closed'] = True
            child['closed'] = True
            child['prior'].append(context['stage']['case'])
            facts = dict(method='close', client_closed=True, close='normal')
            event('close', child, context, facts, deadline)
            return facts

        def disconnect_close(context):
            require(context['raw']['closing']['phase'] == 'pre_unwrap', 'strict close phase missing')
            child['peers'][-1]['state']['closed'] = True
            app['records']['disconnect'] = test_lifecycle.terminal('disconnect')
            app['records']['disconnect'].update(stale_resume=0, stale_cancel=0)
            facts = dict(method='ssl_unwrap', tls_shutdown='success', tcp_eof=True, trailing_bytes=0, close='normal')
            event('disconnect_close', child, context, facts, context['stage']['case_deadline'])
            return facts

        def signal(context, deadline):
            active = selected[-1] == 'shutdown_active'
            require(context['stage']['final_complete'] and len([item for item in state['collections'] if item[0] == index]) == 1,
                    'signal before one final collection')
            require(not active or not context['completed'] and not context['stage']['primary_complete'] and
                    set(context['records']) == {3} and context['request']['connection_debt'] == 32,
                    'active held request lost before signal')
            require(active or child['closed'], 'idle signal before close')
            require(not child['peers'][-1]['state']['pending'] and not child['peers'][-1]['state']['buffer'], 'wire residue before signal')
            child['signaled'] = True
            child['peers'][-1]['state']['signal'] = True
            if active:
                app['records']['shutdown_active'].update(cancels=1, active=False, paused=False, reason='shutdown')
            facts = dict(signal='SIGTERM', owned_identity=True, watcher_installed=True, client_open=active)
            event('signal', child, context, facts, deadline)
            return facts

        def termination(context, deadline):
            require(context['stage']['signaled'] and context['raw']['closing']['phase'] == 'post_signal', 'active termination phase differs')
            child['releases'].append(local_summary(context))
            facts = dict(phase='post_signal', outcome=outcome, primary_response=False, frames_valid=True, trailing_bytes=0)
            event('termination', child, context, facts, deadline)
            return facts

        def process(context, deadline):
            require(child['signaled'], 'process before signal')
            facts = dict(exit_code=0, reaped=True, forced=False, run_ok=True, deinit_ok=True, key_removed=True)
            event('process', child, context, facts, deadline)
            return facts

        def post(context, deadline):
            facts = dict(records=copy.deepcopy(app['records']), metrics=test_core_peer.metrics(app),
                         outputs=copy.deepcopy(app['outputs']), binding=model.default_binding() if app['binding'] is None else dict(app['binding']))
            event('post', child, context, facts, deadline)
            child['posted'] = True
            return facts

        descriptor = dict(identity=(identity, index), ready=True, fresh_application=True, connect=connect,
                          signal=signal, process=process, post=post)
        if any(case != 'shutdown_active' for case in selected):
            descriptor['close'] = close
        if 'disconnect' in selected:
            descriptor['disconnect_close'] = disconnect_close
        if any(case in ('shutdown_idle', 'shutdown_active') for case in selected):
            descriptor['preconditions'] = preconditions
        if 'shutdown_active' in selected:
            descriptor['termination'] = termination
        event('factory', child, fact=descriptor, deadline=ready)
        return descriptor

    original_collection, original_case = adapter.final_collection, adapter.run_case

    def collection(context, receive, **kwargs):
        index = len(state['children']) - 1
        child = state['children'][index]
        require(not child['signaled'] and context['selected_before'] == child['selection'][:-1], 'collection after signal or wrong selection')
        require(context['stage']['final_registered'] == 0, 'duplicate final collection')
        result = original_collection(context, receive, **kwargs)
        capture = context['final_observations'] if result is None else result
        state['collections'].append((index, copy.deepcopy(capture), local_summary(context)))
        event('collected', child, context)
        return result

    def dispatch(context, receive, **kwargs):
        child = state['children'][-1]
        state['dispatches'].append(context['stage']['case'])
        result = original_case(context, receive, **kwargs)
        event('dispatched', child, context if result is None else result)
        return result

    with mock.patch.object(adapter, 'final_collection', collection), mock.patch.object(adapter, 'run_case', dispatch):
        result = coordinator.run(selection, run_identity='shutdown', now=1, units_per_second=units,
                                 clock=clock, child_factory=factory)
    return result, state


def ordinary_peer(case, number, evidence, args):
    if case in ('reuse', 'disconnect'):
        return test_lifecycle.new_peer(case, number, case_evidence=evidence, **args)
    if case in ('producer_reuse', 'output_pressure_ready', 'output_pressure_window'):
        return test_producer_pressure.new_peer(case, **args)
    if case in ('stream_file', 'early_final_order'):
        return test_file_early.new_peer(case, **args)
    return test_core_peer.new_peer(case, **args)


def local_summary(context):
    return dict(settings=context['request']['client_settings'], informationals=context['trace'].get('InformationalResponseReceived', 0),
                receive_bytes=context['stage']['bytes'], receive_calls=context['stage']['reads'],
                connection_debt=context['request']['connection_debt'], stream_debt_total=context['request']['stream_debt_total'])


def check_success(selection):
    result, state = run_selection(selection)
    plan = catalogue.child_plan(selection)
    require(state['dispatches'] == list(selection) and len(state['collections']) == len(plan), 'actual schedule differs')
    heads = sum(catalogue.case_budget(case)['heads'] for case in selection)
    small = sum(catalogue.case_budget(case)['small'] for case in selection)
    ordinary_final = sum(part[-1] not in ('shutdown_idle', 'shutdown_active') for part in plan)
    expected = dict(heads=heads + 68 * ordinary_final, small=small + 68 * ordinary_final,
                    request_flow=sum(catalogue.case_budget(case)['request_flow'] for case in selection),
                    connections=len(selection) + int('disconnect' in selection), final_collections=len(plan))
    require(all(result['totals'][key] == value for key, value in expected.items()), 'actual aggregate differs')
    require(sum(item['app']['heads'] for item in state['children']) == expected['heads'], 'peer heads differ')
    for index, child in enumerate(result['children']):
        observed = state['children'][index]
        require(child['identity'] == ('shutdown', index) and child['selection'] == plan[index], 'child scope differs')
        require(child['final_observations']['records'] == state['collections'][index][1]['records'], 'private parsed before capture differs')
        require(child['counts']['connections'] == len(child['connections']), 'summary count differs')
        require([item['ordinal'] for item in child['connections']] == list(range(1, len(child['connections']) + 1)), 'ordinals differ')
        require(child['counts']['receive_bytes'] == sum(item['receive_bytes'] for item in child['connections']) and
                child['counts']['receive_calls'] == sum(item['receive_calls'] for item in child['connections']), 'local read totals differ')
        require(child['counts']['settings'] == sum(item['settings'] for item in child['connections']), 'local settings differ')
        active = child['selection'][-1] == 'shutdown_active'
        require(set(child['teardown']) == ({'signal', 'termination', 'transport', 'process', 'post'} if active else {'close', 'signal', 'process', 'post'}), 'teardown schema differs')
        require(child['connections'][-1]['release'] == child['teardown']['termination' if active else 'close'], 'release differs')
        require(child['final_observations']['binding'] == observed['app']['binding'], 'binding lost')
        for tag in set(child['selection']) & set(model.PRODUCERS + ('stream_file',)):
            require(child['final_observations']['outputs'][tag] == observed['app']['outputs'][tag], 'parsed output lost')
    frozen = json.dumps(result, sort_keys=True)
    for facts in state['facts']:
        facts.clear()
    for child in state['children']:
        child['app']['records'].clear()
        child['app']['outputs'].clear()
    require(json.dumps(result, sort_keys=True) == frozen, 'result aliases callback graph')
    print('actual selection', ','.join(selection), json.dumps(expected, sort_keys=True))


def check_factory_boundaries():
    for selection in (('shutdown_idle',), ('shutdown_active',), catalogue.CASES, None):
        calls = []

        def factory(*args):
            calls.append(args)
            raise RuntimeError('factory boundary')

        kwargs = dict(run_identity='shutdown', now=1, units_per_second=1, clock=lambda: 2, child_factory=factory)
        try:
            if selection is None:
                coordinator.run(**kwargs)
            else:
                coordinator.run(selection, **kwargs)
        except RuntimeError as error:
            expected = catalogue.child_plan(catalogue.CASES if selection is None else selection)[0]
            require(str(error) == 'factory boundary' and len(calls) == 1 and calls[0][2] == expected, 'factory boundary differs')
        else:
            raise ValueError('factory boundary silently succeeded')
    print('idle, active, explicit all40 and omitted default reach factory; no aggregate execution claimed')


def main():
    check_factory_boundaries()
    for selection in (('shutdown_idle',), ('shutdown_idle', 'ready_buffered'), ('shutdown_active',),
                      ('ready_buffered', 'shutdown_active'), ('producer_reuse', 'shutdown_active'),
                      ('shutdown_idle', 'producer_reuse', 'disconnect', 'shutdown_active'),
                      ('shutdown_idle', 'producer_reuse', 'ready_buffered'), ('stream_file', 'shutdown_active')):
        check_success(selection)


if __name__ == '__main__':
    main()
