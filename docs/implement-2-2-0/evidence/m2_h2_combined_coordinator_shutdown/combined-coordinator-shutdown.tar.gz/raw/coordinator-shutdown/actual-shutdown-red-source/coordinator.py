"""Ordered bounded children over caller-owned synthetic peer and teardown facts."""
import adapter
import cases
import catalogue
import model
import request_credit
import shutdown_cases

COUNT_FIELDS = ('heads', 'small', 'request_flow', 'connections', 'settings', 'informationals',
                'incoming_resets', 'final_collections', 'receive_bytes', 'receive_calls')


def read_time(clock, previous, deadline):
    value = clock()
    if type(value) is not int or value < previous or value >= deadline:
        raise ValueError('monotonic time expired or invalid')
    return value


def validate_descriptor(value, identity, selection):
    fields = {'identity', 'ready', 'fresh_application', 'connect', 'signal', 'process', 'post'}
    if any(case != 'shutdown_active' for case in selection):
        fields.add('close')
    if any(case in ('shutdown_idle', 'shutdown_active') for case in selection):
        fields.add('preconditions')
    if 'shutdown_active' in selection:
        fields.add('termination')
    if 'disconnect' in selection:
        fields.add('disconnect_close')
    if type(value) is not dict or set(value) != fields:
        raise ValueError('child descriptor fields differ')
    actual = value['identity']
    if (type(actual) is not tuple or len(actual) != 2 or type(actual[0]) is not str or
            type(actual[1]) is not int or actual != identity or value['ready'] is not True or
            value['fresh_application'] is not True or
            not all(callable(value[key]) for key in fields - {'identity', 'ready', 'fresh_application'})):
        raise ValueError('child descriptor facts differ')


def validate_connection(value, previous, deadline):
    fields = {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'}
    if (type(value) is not dict or set(value) != fields or value['protocol'] is None or
            not callable(value['send']) or not callable(value['receive']) or value['owned'] is not True or
            type(value['tls']) is not str or value['tls'] != 'TLSv1.3' or
            type(value['alpn']) is not str or value['alpn'] != 'h2' or
            type(value['now']) is not int or value['now'] < previous or value['now'] >= deadline):
        raise ValueError('connection facts differ')


def copy_facts(facts):
    # The model validators establish fixed keys and scalar leaves before copying.
    return dict(records={tag: dict(item) for tag, item in facts['records'].items()},
                metrics=dict(facts['metrics']), outputs={tag: dict(item) for tag, item in facts['outputs'].items()},
                binding=None if facts['binding'] is None else dict(facts['binding']))


def finish_child(context, descriptor, selection, units):
    capture = context['final_observations']
    model.validate_records(selection, 'before', capture['records'])
    model.validate_metrics(selection, 'before', capture['metrics'])
    outputs, binding = shutdown_cases.outputs(context, selection)
    before = copy_facts(dict(capture, outputs=outputs, binding=binding))
    context['shutdown_boundary'] = True
    deadline = shutdown_cases.grace(context, units)
    close = descriptor['close'](context, deadline)
    shutdown_cases.within_grace(context, deadline)
    expected = dict(method='close', client_closed=True, close='normal')
    if (type(close) is not dict or close != expected or
            any(type(close[key]) is not type(value) for key, value in expected.items())):
        raise ValueError('ordinary close evidence differs')
    close = dict(close)
    signal = descriptor['signal'](context, deadline)
    shutdown_cases.within_grace(context, deadline)
    shutdown_cases.validate_signal(signal, False)
    signal = dict(signal)

    def process_facts(current, grace_deadline):
        result = descriptor['process'](current, grace_deadline)
        shutdown_cases.validate_process(result)
        return dict(result)

    def post_facts(current, grace_deadline):
        result = descriptor['post'](current, grace_deadline)
        if type(result) is not dict or set(result) != {'records', 'metrics', 'outputs', 'binding'}:
            raise ValueError('post-deinit evidence fields differ')
        model.validate_pre_post(selection, before['records'], result['records'])
        model.validate_metrics(selection, 'after', result['metrics'])
        model.validate_output_pre_post(selection, before['outputs'], result['outputs'],
                                       binding_before=before['binding'], binding_after=result['binding'])
        return copy_facts(result)

    shutdown_cases.post_deinit(context, dict(process=process_facts, post=post_facts), deadline, before, selection)
    observed = context['shutdown_observations']
    return copy_facts(before), dict(close=close, signal=signal, process=dict(observed['process']),
                                    post=copy_facts(observed['after'])), deadline


def snapshot_counts(context):
    stage = context['stage']
    state = stage['case_state']
    counts = dict(heads=state['heads'], small=catalogue.add_u64(state['small'], stage['final_registered']),
                  request_flow=context['request']['case']['sent'], connections=state['connections'],
                  settings=context['request']['client_settings'], informationals=context['trace'].get('InformationalResponseReceived', 0),
                  incoming_resets=state['resets'], final_collections=int(stage['final_complete']),
                  receive_bytes=state['bytes'], receive_calls=state['reads'])
    for value in counts.values():
        catalogue.add_u64(value, 0)
    return counts


def disconnect_hooks(descriptor, clock, case_deadline, whole, connections, old):
    deadline = min(case_deadline, whole)

    def close(context):
        previous = context['now']
        stage, request = context['stage'], context['request']
        old.update(settings=request['client_settings'],
                   informationals=context['trace'].get('InformationalResponseReceived', 0),
                   receive_bytes=stage['bytes'], receive_calls=stage['reads'],
                   connection_debt=request['connection_debt'], stream_debt_total=request['stream_debt_total'])
        result = descriptor['disconnect_close'](context)
        expected = dict(method='ssl_unwrap', tls_shutdown='success', tcp_eof=True, trailing_bytes=0, close='normal')
        if (type(result) is not dict or result != expected or
                any(type(result[key]) is not type(value) for key, value in expected.items())):
            raise ValueError('strict close evidence differs')
        old['release'] = dict(result)
        context['now'] = read_time(clock, previous, deadline)
        context['clock'] = clock
        context['stage']['case_deadline'] = case_deadline
        context['stage']['whole_deadline'] = whole
        return dict(result)

    def replacement(context):
        stage = context['stage']
        connections.append(dict(case='disconnect', case_connection=1, ordinal=len(connections) + 1,
                                case_deadline=case_deadline, settings=old['settings'],
                                informationals=old['informationals'], receive_bytes=old['receive_bytes'],
                                receive_calls=old['receive_calls'], connection_debt=old['connection_debt'],
                                stream_debt_total=old['stream_debt_total'], release=dict(old['release'])))
        previous = context['now']
        supplied = descriptor['connect']('disconnect', 2, case_deadline, whole)
        validate_connection(supplied, previous, deadline)
        context['now'] = read_time(clock, supplied['now'], deadline)
        context['clock'] = clock
        stage['case_deadline'], stage['whole_deadline'] = case_deadline, whole
        supplied = dict(supplied)
        supplied['now'] = context['now']
        return supplied

    return dict(close=close, replacement=replacement)


def run(selection=catalogue.CASES, *, run_identity, now, units_per_second, clock, child_factory):
    selection = cases.select(selection)
    if (type(run_identity) is not str or not 1 <= len(run_identity) <= 32 or
            any(character not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_' for character in run_identity)):
        raise ValueError('run identity differs')
    if (type(now) is not int or now < 0 or type(units_per_second) is not int or units_per_second <= 0 or
            not callable(clock) or not callable(child_factory)):
        raise ValueError('coordinator static inputs differ')
    whole = catalogue.add_u64(now, catalogue.mul_u64(900, units_per_second))
    ready_duration = catalogue.mul_u64(15, units_per_second)
    for case in selection:
        catalogue.mul_u64(catalogue.case_budget(case)['timeout_seconds'], units_per_second)
    totals = dict.fromkeys(COUNT_FIELDS, 0)
    if not selection:
        return dict(run_identity=run_identity, selection=selection, children=(), totals=totals, scope='pure_client_synthetic_peer')
    children = []
    current = now
    for index, child_selection in enumerate(catalogue.child_plan(selection)):
        child, current = run_child(child_selection, run_identity, index, current, units_per_second,
                                   clock, child_factory, whole, ready_duration)
        children.append(child)
        for key in COUNT_FIELDS:
            totals[key] = catalogue.add_u64(totals[key], child['counts'][key])
    return dict(run_identity=run_identity, selection=selection, children=tuple(children), totals=totals,
                scope='pure_client_synthetic_peer')


def run_child(child_selection, run_identity, child_index, now, units_per_second, clock, child_factory, whole, ready_duration):
    ready_start = read_time(clock, now, whole)
    ready = min(whole, catalogue.add_u64(ready_start, ready_duration))
    identity = (run_identity, child_index)
    descriptor = child_factory(run_identity, child_index, child_selection, ready, whole)
    current = read_time(clock, ready_start, ready)
    validate_descriptor(descriptor, identity, child_selection)
    descriptor = dict(descriptor)
    completed_cases = ()
    retained_outputs, retained_binding = {}, None
    counts = dict.fromkeys(COUNT_FIELDS, 0)
    connections = []
    for position, case in enumerate(child_selection):
        case_start = read_time(clock, current, whole)
        case_deadline, whole = cases.deadlines(case, case_start, whole, units_per_second)
        connection = descriptor['connect'](case, 1, case_deadline, whole)
        validate_connection(connection, case_start, case_deadline)
        opened_at = read_time(clock, connection['now'], case_deadline)
        context = adapter.open_case(case, connection['protocol'], connection['send'], opened_at,
                                    case_deadline, whole, selected_before=completed_cases, clock=clock)
        context['output_observations'] = {tag: dict(item) for tag, item in retained_outputs.items()}
        if retained_binding is not None:
            context['output_binding'] = dict(retained_binding)
        receive = connection['receive']
        while context['stage']['initial_settings'] != 1 or context['stage']['acks'] != 1:
            adapter.tick(context)
            data, received_at = receive()
            adapter.observe(context, data, received_at)
        old = {}
        if case == 'disconnect':
            hooks = disconnect_hooks(descriptor, clock, case_deadline, whole, connections, old)
            result = adapter.run_case(context, receive, disconnect=hooks)
        else:
            result = adapter.run_case(context, receive)
        if result is not None:
            context = result
        if case == 'disconnect':
            receive = context['receive']
            context['output_observations'] = {tag: dict(item) for tag, item in retained_outputs.items()}
            if retained_binding is not None:
                context['output_binding'] = dict(retained_binding)
        adapter.check_counts(context)
        if position == len(child_selection) - 1:
            adapter.final_collection(context, receive)
        raw, stage = context['raw'], context['stage']
        if (not context['completed'] or raw['header'] or raw['frame'] is not None or raw['remaining'] or
                raw['streams'] or stage['active'] or context['records'] or context['credit']['pending'] is not None or
                any(not item['retired'] or not request_credit.closed(item) for item in context['request']['streams'].values())):
            raise ValueError('ordinary connection not quiescent')
        outputs, binding = shutdown_cases.outputs(context, completed_cases + (case,))
        selected_outputs = set(completed_cases + (case,)) & set(model.PRODUCERS + ('stream_file',))
        retained_outputs = {tag: dict(outputs[tag]) for tag in selected_outputs}
        retained_binding = None if binding is None else dict(binding)
        snapshot = snapshot_counts(context)
        if old:
            snapshot['settings'] = catalogue.add_u64(snapshot['settings'], old['settings'])
            snapshot['informationals'] = catalogue.add_u64(snapshot['informationals'], old['informationals'])
        summary = dict(case=case, case_connection=2 if old else 1, ordinal=len(connections) + 1, case_deadline=case_deadline,
                       settings=context['request']['client_settings'], informationals=context['trace'].get('InformationalResponseReceived', 0),
                       receive_bytes=stage['bytes'], receive_calls=stage['reads'],
                       connection_debt=context['request']['connection_debt'],
                       stream_debt_total=context['request']['stream_debt_total'])
        if position == len(child_selection) - 1:
            before, teardown, grace_deadline = finish_child(context, descriptor, child_selection, units_per_second)
            release = teardown['close']
        else:
            adapter.tick(context)
            pre_close_time = context['now']
            close_deadline = min(case_deadline, whole)
            context['shutdown_boundary'] = True
            release = descriptor['close'](context, close_deadline)
            expected = dict(method='close', client_closed=True, close='normal')
            if (type(release) is not dict or release != expected or
                    any(type(release[key]) is not type(value) for key, value in expected.items())):
                raise ValueError('ordinary close evidence differs')
            release = dict(release)
            current = read_time(clock, pre_close_time, close_deadline)
        summary['release'] = dict(release)
        connections.append(summary)
        for key in COUNT_FIELDS:
            counts[key] = catalogue.add_u64(counts[key], snapshot[key])
        completed_cases += (case,)
    child = dict(identity=identity, selection=child_selection, counts=counts, connections=tuple(connections),
                 deadlines=dict(ready=ready, case=case_deadline, whole=whole, grace=grace_deadline),
                 final_observations=before, teardown=teardown)
    return child, context['now']


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned synthetic hooks')
