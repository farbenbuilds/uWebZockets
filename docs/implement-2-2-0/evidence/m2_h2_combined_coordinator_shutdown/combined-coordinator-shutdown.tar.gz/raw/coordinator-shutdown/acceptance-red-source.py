"""Shutdown coordinator acceptance against supplied synthetic boundaries."""
import coordinator


def check_idle_factory_boundary():
    calls = []

    def factory(*args):
        calls.append(args)
        raise RuntimeError('factory boundary')

    try:
        coordinator.run(('shutdown_idle',), run_identity='shutdown', now=1, units_per_second=1,
                        clock=lambda: 2, child_factory=factory)
    except RuntimeError as error:
        if str(error) != 'factory boundary' or len(calls) != 1 or calls[0][2] != ('shutdown_idle',):
            raise ValueError('shutdown factory boundary differs') from error
        return
    raise ValueError('shutdown factory boundary did not stop')


def main():
    check_idle_factory_boundary()
    print('idle selection reaches factory boundary')


if __name__ == '__main__':
    main()
