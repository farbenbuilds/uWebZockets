import hashlib, json, pathlib, shutil, sys

def capture():
    root = pathlib.Path('/workspaces/uWebZockets')
    base = root / '.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'
    manifest = json.loads((root / 'docs/implement-2-2-0/evidence/m2_h2_combined_shutdown_peer/manifest.json').read_text())['current_source_files']
    def sha(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()
    actual = {name: sha(base / name) for name in manifest}
    if actual != manifest or len(actual) != 39:
        raise RuntimeError('baseline source differs from accepted manifest')
    evidence = base / 'evidence'
    prior = {str(path.relative_to(evidence)): sha(path) for path in sorted(evidence.rglob('*')) if path.is_file()}
    out = evidence / 'coordinator-shutdown'
    if out.exists():
        raise RuntimeError('new evidence directory already exists')
    out.mkdir()
    snapshot = out / 'before-source'
    snapshot.mkdir()
    for name in manifest:
        shutil.copyfile(base / name, snapshot / name)
    (out / 'baseline-source-hashes.json').write_text(json.dumps(actual, sort_keys=True, indent=2) + '\n')
    (out / 'prior-evidence-hashes.json').write_text(json.dumps(prior, sort_keys=True, indent=2) + '\n')
    print('baseline source files:', len(actual), 'mismatches: []')
    print('prior evidence files:', len(prior))
    print('interpreter:', sha(pathlib.Path(sys.executable).resolve()))


def main():
    if sys.argv[1:] == ["--capture"]:
        capture()


if __name__ == '__main__':
    main()
