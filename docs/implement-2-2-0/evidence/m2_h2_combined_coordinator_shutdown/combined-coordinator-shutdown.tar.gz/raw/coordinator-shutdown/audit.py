"""Explicit source/evidence receipts; inert unless a named operation is supplied."""
import ast
import hashlib
import json
import pathlib
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot(label):
    out = pathlib.Path(__file__).parent
    base = out.parent.parent
    target = out / (label + '-source')
    target.mkdir()
    hashes = {}
    for path in sorted(base.glob('*.py')):
        data = path.read_bytes()
        (target / path.name).write_bytes(data)
        hashes[path.name] = sha(path)
    (out / (label + '-source.json')).write_text(json.dumps(hashes, sort_keys=True, indent=2) + '\n')
    structures = {}
    for path in sorted(base.glob('*.py')):
        tree = ast.parse(path.read_text())
        structures[path.name] = dict(functions=sum(isinstance(n, ast.FunctionDef) for n in ast.walk(tree)),
                                    classes=sum(isinstance(n, ast.ClassDef) for n in ast.walk(tree)),
                                    assertions=sum(isinstance(n, ast.Assert) for n in ast.walk(tree)))
    (out / (label + '-structure.json')).write_text(json.dumps(structures, sort_keys=True, indent=2) + '\n')
    print('source snapshot:', label, len(hashes))


def check(label, module):
    import contextlib
    import os
    import runpy
    import traceback
    out = pathlib.Path(__file__).parent
    snapshot(label)
    command = [sys.executable, '-B', '-S'] + (['-O'] if sys.flags.optimize else []) + [str(pathlib.Path(__file__).resolve()), 'check', label, module]
    (out / (label + '.command.json')).write_text(json.dumps(dict(argv=command, pythonpath=os.environ.get('PYTHONPATH'), cwd=str(pathlib.Path.cwd())), indent=2) + '\n')
    code = 0
    with (out / (label + '.stdout')).open('x') as stdout, (out / (label + '.stderr')).open('x') as stderr:
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            try:
                runpy.run_module(module, run_name='__main__')
            except Exception:
                traceback.print_exc()
                code = 1
    (out / (label + '.exit')).write_text(str(code) + '\n')
    print(label, 'exit', code)
    return code


def require(value, message):
    if not value:
        raise RuntimeError(message)


def inert_current(out):
    import builtins
    import contextlib
    import datetime
    import os
    import shutil
    import socket
    import ssl
    import subprocess
    import time
    from unittest import mock
    helpers = tuple(out / name for name in ('audit.py', 'baseline-capture.py'))
    codes = [(path, compile(path.read_text(), str(path), 'exec')) for path in helpers]
    replacements = [(builtins, 'open'), (pathlib.Path, 'read_bytes'), (pathlib.Path, 'read_text'),
                    (pathlib.Path, 'write_bytes'), (pathlib.Path, 'write_text'), (pathlib.Path, 'mkdir'),
                    (shutil, 'copyfile'), (socket, 'socket'), (socket, 'socketpair'), (socket, 'create_connection'),
                    (socket, 'create_server'), (ssl, 'SSLContext'), (subprocess, 'Popen'), (subprocess, 'run'),
                    (os, 'system'), (os, 'popen'), (os, 'open'), (os, 'write'), (time, 'time'),
                    (time, 'monotonic'), (time, 'perf_counter'), (time, 'sleep'), (datetime, 'datetime')]

    def reject(*args, **kwargs):
        raise RuntimeError('current helper invoked a forbidden effect')

    def execute(path, code, argv, name):
        stdout, stderr = mock.Mock(), mock.Mock()
        stdout.write.side_effect, stderr.write.side_effect = reject, reject
        with contextlib.ExitStack() as stack:
            for module, field in replacements:
                stack.enter_context(mock.patch.object(module, field, reject))
            stack.enter_context(mock.patch.object(sys, 'argv', argv))
            stack.enter_context(mock.patch.object(sys, 'stdout', stdout))
            stack.enter_context(mock.patch.object(sys, 'stderr', stderr))
            exec(code, {'__name__': name, '__file__': str(path)})

    for path, code in codes:
        for argv in ([], ['foreign', '--run', 'unexpected']):
            for name in ('inert_helper', '__main__'):
                execute(path, code, argv, name)
    print('current authored helpers inert on import AND main under empty/foreign argv:', len(helpers))


def verify(label):
    import difflib
    import runpy
    out = pathlib.Path(__file__).parent
    base = out.parent.parent
    destination = out / label
    destination.mkdir()
    helper = runpy.run_path(str(base / 'evidence/core-peer/audit.py'), run_name='reviewed_audit')
    helper['immutable'](base, destination)
    helper['structure'](base, destination)
    inert_current(out)
    baseline = json.loads((out / 'baseline-source-hashes.json').read_text())
    current = {path.name: sha(path) for path in base.glob('*.py')}
    changed = {name for name in baseline if current[name] != baseline[name]}
    require(changed == {'coordinator.py', 'test_coordinator.py', 'test_imports.py'} and
            set(current) - set(baseline) == {'test_coordinator_shutdown.py'} and len(current) == 40, 'source ownership differs')
    prior = json.loads((out / 'prior-evidence-hashes.json').read_text())
    require(len(prior) == 6136 and all(sha(base / 'evidence' / name) == value for name, value in prior.items()), 'prior evidence differs')
    preservation = json.loads((out / 'reassignment-preservation.json').read_text())
    require(all(sha(out / item['snapshot']) == item['sha256'] for item in preservation['mapping'].values()), 'first attempt snapshot changed')
    report = pathlib.Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b7p8-report.md')
    require(hashlib.sha256(report.read_bytes()[:2594]).hexdigest() == 'f5720646f75deb66c7d6db1b6ac4feee88d0a795093533a1b8a3cdc45a945fcf', 'report prefix differs')
    differences = []
    for name in sorted(changed | {'test_coordinator_shutdown.py'}):
        old = out / 'before-source' / name
        differences.extend(difflib.unified_diff(old.read_text().splitlines(True) if old.exists() else [],
                                               (base / name).read_text().splitlines(True), fromfile='before/' + name, tofile='current/' + name))
    (destination / 'scoped.diff').write_text(''.join(differences))
    facts = dict(source_count=40, changed=sorted(changed), new=['test_coordinator_shutdown.py'], unchanged_accepted=36,
                 prior_evidence_files=6136, first_attempt_files=len(preservation['mapping']), report_prefix_preserved=True,
                 current_helpers={path.name:sha(path) for path in (out/'audit.py',out/'baseline-capture.py')},
                 original_baseline_helper=preservation['mapping']['baseline-capture.py']['sha256'], native_executed=False)
    (destination / 'verified.json').write_text(json.dumps(facts, indent=2, sort_keys=True)+'\n')
    print('source ownership40/changed3/new1, preserved prior6136/first-attempt51/report2594 verified')


def main():
    if len(sys.argv) == 3 and sys.argv[1] == 'snapshot':
        snapshot(sys.argv[2])
    if len(sys.argv) == 4 and sys.argv[1] == 'check':
        raise SystemExit(check(sys.argv[2], sys.argv[3]))
    if len(sys.argv) == 3 and sys.argv[1] == 'verify':
        verify(sys.argv[2])


if __name__ == '__main__':
    main()
