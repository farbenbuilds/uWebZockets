/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import ast
import difflib
import hashlib
import json

if __name__ == '__main__':
    root = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    evidence = root / 'evidence/coordinator-a'
    before = json.loads((evidence / 'before-map.json').read_text())
    published = json.loads(Path('docs/implement-2-2-0/evidence/m2_h2_combined_shutdown/manifest.json').read_text())['current_source_files']
    if before != published or len(before) != 35:
        raise RuntimeError('accepted starting map changed')
    immutable = json.loads((evidence / 'immutable-inputs.json').read_text())
    for item in immutable['identities']:
        data = Path(item['path']).read_bytes()
        if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
            raise RuntimeError('immutable input changed: ' + item['path'])
    rows = immutable['codec_files']
    packages = Path('/tmp/uwz-h2-client-tooling/packages')
    for name, digest in rows:
        if hashlib.sha256((packages / name).read_bytes()).hexdigest() != digest:
            raise RuntimeError('codec input changed: ' + name)
    present = {str(path.relative_to(packages)) for path in packages.rglob('*') if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc'}
    digest = hashlib.sha256(json.dumps(rows).encode()).hexdigest()
    if len(rows) != 42 or present != {row[0] for row in rows} or digest != '0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473':
        raise RuntimeError('ordered codec set or aggregate differs')
    interpreter = Path('/home/codespace/.python/current/bin/python3')
    identity = dict(path=str(interpreter), resolved=str(interpreter.resolve()), bytes=len(interpreter.read_bytes()), sha256=hashlib.sha256(interpreter.read_bytes()).hexdigest())
    if identity['sha256'] != '4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601':
        raise RuntimeError('pinned interpreter changed')
    (evidence / 'python-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    history = json.loads((evidence / 'before-history.json').read_text())
    for name, expected in history.items():
        if hashlib.sha256((root / name).read_bytes()).hexdigest() != expected:
            raise RuntimeError('prior evidence changed: ' + name)
    final, depths, differences = {}, {}, []
    (evidence / 'final-source').mkdir(exist_ok=True)
    for path in sorted(root.glob('*.py')):
        data = path.read_bytes()
        final[path.name] = hashlib.sha256(data).hexdigest()
        (evidence / 'final-source' / path.name).write_bytes(data)
        old = (evidence / 'before-source' / path.name).read_text() if path.name in before else ''
        differences.extend(difflib.unified_diff(old.splitlines(True), data.decode().splitlines(True), fromfile='before/' + path.name, tofile='after/' + path.name))
        tree = ast.parse(data, filename=path.name)
        if any(isinstance(node, (ast.ClassDef, ast.Assert)) for node in ast.walk(tree)):
            raise RuntimeError('authored class/assert: ' + path.name)
        guards = [node for node in tree.body if isinstance(node, ast.If) and ast.unparse(node.test) == "__name__ == '__main__'"]
        if len(guards) != 1:
            raise RuntimeError('main guard count differs: ' + path.name)
        maximum, pending = 0, [(tree, 0)]
        while pending:
            node, level = pending.pop()
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                level = 0
            if isinstance(node, (ast.If, ast.For, ast.While, ast.With, ast.Try)):
                level += 1
                maximum = max(maximum, level)
            for child in ast.iter_child_nodes(node):
                child_level = level - 1 if isinstance(node, ast.If) and child in node.orelse and isinstance(child, ast.If) else level
                pending.append((child, child_level))
        depths[path.name] = maximum
    changed = sorted(name for name in before if final.get(name) != before[name])
    added = sorted(final.keys() - before.keys())
    if changed != ['test_imports.py'] or added != ['coordinator.py', 'test_coordinator.py'] or len(final) != 37:
        raise RuntimeError('source ownership differs')
    if max(depths.values()) > 3:
        raise RuntimeError('control depth exceeds3: ' + repr(depths))
    commands = []
    for receipt in sorted(evidence.glob('final-test*.exit')):
        if '.pre-self-review' in receipt.name:
            continue
        label = receipt.stem
        if receipt.read_text() != '0\n' or (evidence / (label + '.stderr')).read_bytes():
            raise RuntimeError('final command failed: ' + label)
        commands.append(dict(command=(evidence / (label + '.command')).read_text(), exit=0, stdout=str(evidence / (label + '.stdout')), stderr=str(evidence / (label + '.stderr'))))
    if len(commands) != 4:
        raise RuntimeError('final command inventory differs')
    for script in ('test_coordinator', 'test_imports'):
        if (evidence / ('final-' + script + '-normal.stdout')).read_bytes() != (evidence / ('final-' + script + '-optimized.stdout')).read_bytes():
            raise RuntimeError('normal/O raw output differs')
    unique = {str(Path(item['path']).resolve()) for item in immutable['identities']}
    if len(immutable['identities']) != 118 or len(unique) != 113:
        raise RuntimeError('immutable row inventory differs')
    snapshot = dict(base='322784dea07fd7693b8dba57969636e3e6ed3639', current_source_files=final, added=added, changed=changed,
                    unchanged=sorted(name for name in before if name not in changed), removed=sorted(before.keys() - final.keys()),
                    control_depth=depths, immutable_file_rows=118, immutable_unique_files=113, codec_files=42, codec_digest=digest,
                    preserved_history_files=len(history), commands=commands)
    (evidence / 'snapshot.json').write_text(json.dumps(snapshot, indent=2) + '\n')
    (evidence / 'source.diff').write_text(''.join(differences))
    (evidence / 'final-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    print('37 modules: 2 added, 1 inventory-only changed, 34 unchanged; main guards/no authored classes/asserts; maximum depth=%d' % max(depths.values()))
    print('118 identity file rows / 113 unique files plus ordered42-codec aggregate unchanged; pinned Python SHA256 matches')
    print('Prior evidence files preserved: %d' % len(history))
    print('Four final normal/-O coordinator/import commands exit0, empty stderr, identical per-script stdout')
PY
