"""Serialized ready child and hostile synthetic lifecycle inputs."""
import hashlib
import json
from unittest import mock
import adapter
import catalogue
import coordinator
import h2_client
import hpack
import model
import test_ready


def require(value, message):
    if not value:
        raise RuntimeError(message)


def peer(control=None):
    settings = b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    initial = test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b'')
    state = dict(startup=True, buffer=bytearray(), pending=initial, heads=0, received=0, received_bytes=0,
                 data=0, ends=0, settings=0, acks=0, digest=hashlib.sha256(), clock=2, clocks=0,
                 factory=0, connected=0, lifecycle=[], decoder=hpack.Decoder(), encoder=hpack.Encoder(),
                 records=model.records(('ready_buffered',), 'before'), context=None, result=None, control=control)
    paths = ('/health', '/metrics', '/echo', '/metrics', '/health')
    paths += tuple('/status/' + tag for tag in model.SPECS) + ('/metrics',)

    def response(stream, body):
        require(not state['pending'], 'response before prior read')
        block = state['encoder'].encode(((':status', '200'), ('x-middleware', 'retained')))
        state['pending'] = test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body)

    def respond(path, stream):
        if path == '/health':
            response(stream, b'ok')
            return
        if path.startswith('/status/'):
            response(stream, json.dumps(state['records'][path[8:]]).encode())
            return
        require(path == '/metrics', 'unexpected observation')
        values = model.metrics((), 'before')
        values.update(buffered_middleware=state['heads'], slot0_active=False, slot1_active=False)
        response(stream, json.dumps(values).encode())

    def packet_received(packet):
        kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
        if kind == 4:
            require(packet == test_ready.frame(4, 1, 0, b''), 'settings ACK differs')
            state['acks'] += 1
            return
        if kind == 0:
            payload = model.core_request('ready_buffered')['body']
            require(state['heads'] == 3 and stream == 5 and flags == 1 and packet[9:] == payload, 'echo DATA differs')
            state['data'] += len(packet[9:])
            state['ends'] += 1
            state['digest'].update(packet[9:])
            response(stream, payload)
            return
        require(kind == 1 and state['heads'] < len(paths) and not state['pending'], 'request before preceding response')
        entries = list(state['decoder'].decode(packet[9:]))
        path = paths[state['heads']]
        echo = path == '/echo'
        expected = [(':method', 'POST' if echo else 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)]
        if echo:
            expected += [('content-length', '257')]
        require(entries == expected and stream == 2 * state['heads'] + 1 and flags == (4 if echo else 5), 'request contract differs')
        state['heads'] += 1
        if not echo:
            respond(path, stream)

    def send(data):
        require(type(data) is bytes and 0 < len(data) <= 8192, 'send span differs')
        if state['startup']:
            state['startup'] = False
            expected = b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n'
            expected += test_ready.frame(4, 0, 0, b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                                        ((1, 4096), (2, 1), (4, 65535), (5, 16384), (8, 0), (3, 100), (6, 65536))))
            require(data == expected, 'startup bytes differ')
            state['settings'] += 1
            return
        state['buffer'].extend(data)
        require(len(state['buffer']) <= 8192, 'serialized parser bound differs')
        while len(state['buffer']) >= 9:
            size = int.from_bytes(state['buffer'][:3], 'big')
            if len(state['buffer']) < size + 9:
                return
            packet = bytes(state['buffer'][:size + 9])
            del state['buffer'][:size + 9]
            packet_received(packet)

    def receive():
        require(bool(state['pending']) and state['received'] < 74, 'finite peer input missing')
        data = state['pending']
        state['pending'] = b''
        state['received'] += 1
        state['received_bytes'] += len(data)
        return data, state['clock']

    def clock():
        state['clocks'] += 1
        return state['clock']

    def close(context, deadline):
        state['lifecycle'].append('close')
        state['context'] = context
        require(context['shutdown_boundary'] and context['completed'] and state['heads'] == 73 and
                not state['pending'] and not state['buffer'], 'close before complete collection')
        require(deadline == min(context['now'] + 15, context['stage']['case_deadline'], context['stage']['whole_deadline']), 'grace differs')
        state['close'] = dict(method='close', client_closed=True, close='normal')
        if control is not None:
            control('close', state, state['close'])
        return state['close']

    def signal(context, deadline):
        state['lifecycle'].append('signal')
        require(state['lifecycle'] == ['close', 'signal'] and context is state['context'], 'signal order differs')
        state['signal'] = dict(signal='SIGTERM', owned_identity=True, watcher_installed=True, client_open=False)
        if control is not None:
            control('signal', state, state['signal'])
        return state['signal']

    def process(context, deadline):
        state['lifecycle'].append('process')
        require(state['lifecycle'] == ['close', 'signal', 'process'] and context is state['context'], 'process order differs')
        state['process'] = dict(exit_code=0, reaped=True, forced=False, run_ok=True, deinit_ok=True, key_removed=True)
        if control is not None:
            control('process', state, state['process'])
        return state['process']

    def post(context, deadline):
        state['lifecycle'].append('post')
        require(state['lifecycle'] == ['close', 'signal', 'process', 'post'] and context is state['context'], 'post order differs')
        state['post'] = dict(records=json.loads(json.dumps(state['records'])), metrics=model.metrics(('ready_buffered',), 'after'),
                             outputs=model.default_outputs(), binding=model.default_binding())
        state['post']['metrics'].update(slot0_active=False, slot1_active=False)
        if control is not None:
            control('post', state, state['post'])
        return state['post']

    def connect(case, index, case_deadline, whole_deadline):
        state['connected'] += 1
        require((case, index, case_deadline, whole_deadline) == ('ready_buffered', 1, 32, 901), 'connect arguments differ')
        value = dict(protocol=h2_client.new_protocol(), send=send, receive=receive, now=state['clock'], owned=True, tls='TLSv1.3', alpn='h2')
        if control is not None:
            control('connect', state, value)
        return value

    def factory(identity, index, selection, ready_deadline, whole_deadline):
        state['factory'] += 1
        require((identity, index, selection, ready_deadline, whole_deadline) == ('ready_0', 0, ('ready_buffered',), 17, 901), 'factory arguments differ')
        value = dict(identity=(identity, index), ready=True, fresh_application=True, connect=connect,
                     close=close, signal=signal, process=process, post=post)
        if control is not None:
            control('factory', state, value)
        return value

    return state, clock, factory


def run_peer(control=None):
    state, clock, factory = peer(control)
    original = adapter.final_collection
    boundary = {}

    def collect(context, receive):
        require(not boundary and state['heads'] == 5 and context['completed'], 'final collection count differs')
        boundary.update({name: context[name] for name in ('stage', 'raw', 'request', 'credit', 'records')})
        boundary['bytes'], boundary['reads'] = context['stage']['bytes'], context['stage']['reads']
        boundary['received'], boundary['received_bytes'] = state['received'], state['received_bytes']
        require(context['selected_before'] == () and context['request']['connection_debt'] == 257 and
                context['request']['stream_debt_total'] == 257, 'final inherited debt differs')
        value = original(context, receive)
        require(value is None and context['stage']['final_registered'] == 68, 'ordinary return or collection differs')
        require(all(context[name] is boundary[name] for name in ('stage', 'raw', 'request', 'credit', 'records')), 'final state replaced')
        require(context['stage']['bytes'] == boundary['bytes'] + state['received_bytes'] - boundary['received_bytes'] and
                context['stage']['reads'] == boundary['reads'] + state['received'] - boundary['received'], 'cumulative final counters differ')
        require(context['stage']['final_budget'] == catalogue.final_budget(514) and
                (context['stage']['case_deadline'], context['stage']['whole_deadline']) == (32, 901), 'final bounds changed')
        require(context['request']['connection_debt'] == 257 and context['request']['stream_debt_total'] == 257, 'unrefunded debt erased')
        return value

    with mock.patch.object(adapter, 'final_collection', collect):
        result = coordinator.run(('ready_buffered',), run_identity='ready_0', now=1, units_per_second=1, clock=clock, child_factory=factory)
    state['result'] = result
    return state, result


def check_success():
    state, result = run_peer()
    child = result['children'][0]
    require(set(result) == {'run_identity', 'selection', 'children', 'totals', 'scope'} and
            result['scope'] == 'pure_client_synthetic_peer' and result['selection'] == ('ready_buffered',) and
            result['run_identity'] == 'ready_0', 'result schema differs')
    require(set(child) == {'identity', 'selection', 'counts', 'deadlines', 'final_observations', 'teardown'} and
            child['identity'] == ('ready_0', 0) and child['selection'] == ('ready_buffered',), 'child schema differs')
    expected = dict(heads=73, small=73, request_flow=257, connections=1, settings=1, informationals=0,
                    incoming_resets=0, final_collections=1, receive_bytes=state['received_bytes'], receive_calls=74)
    require(child['counts'] == expected and result['totals'] == expected and result['totals'] is not child['counts'], 'actual totals differ')
    require(child['deadlines'] == dict(ready=17, case=32, whole=901, grace=17), 'retained deadlines differ')
    require(state['heads'] == 73 and state['received'] == 74 and state['data'] == 257 and state['ends'] == 1 and
            state['settings'] == 1 and state['acks'] == 1 and state['digest'].hexdigest() == model.CORE_RESPONSES['ready_buffered'][2], 'serialized action totals differ')
    require(state['lifecycle'] == ['close', 'signal', 'process', 'post'] and state['factory'] == 1 and state['connected'] == 1, 'complete lifecycle differs')
    before = child['final_observations']
    require(set(before) == {'records', 'metrics', 'outputs', 'binding'} and before['records'] == state['records'] and
            before['metrics']['buffered_middleware'] == 73 and before['binding'] is None, 'observed baseline differs')
    model.validate_pre_post(('ready_buffered',), before['records'], child['teardown']['post']['records'])
    model.validate_output_pre_post(('ready_buffered',), before['outputs'], child['teardown']['post']['outputs'],
                                   binding_before=before['binding'], binding_after=child['teardown']['post']['binding'])
    retained = json.dumps(result, sort_keys=True)
    state['post']['records']['empty_headers']['middleware'] = 99
    state['post']['metrics']['buffered_middleware'] = 99
    state['post']['outputs']['stream_file']['close_calls'] = 99
    state['post']['binding']['binding_index'] = 99
    state['process']['exit_code'] = 99
    state['signal']['signal'] = 'wrong'
    state['close']['client_closed'] = False
    state['context']['final_observations']['records']['empty_headers']['middleware'] = 99
    require(json.dumps(result, sort_keys=True) == retained, 'returned evidence aliases callback graphs')
    print('ready coordinator serialized lifecycle passed: heads=73 small=73 flow=257 settings=1 final=68 reads=74 bytes=%d' % expected['receive_bytes'])


def check_preflight():
    effects = []

    def reject(*args):
        effects.append(args)
        raise RuntimeError('preflight invoked callback')

    arguments = dict(run_identity='ready_0', now=1, units_per_second=1, clock=reject, child_factory=reject)
    result = coordinator.run((), **arguments)
    require(result == dict(run_identity='ready_0', selection=(), children=(), totals=dict.fromkeys(
            ('heads', 'small', 'request_flow', 'connections', 'settings', 'informationals', 'incoming_resets', 'final_collections', 'receive_bytes', 'receive_calls'), 0),
            scope='pure_client_synthetic_peer') and not effects, 'empty selection had effects or facts')
    selections = (None, 'ready_buffered', {}, ('unknown',), ('ready_buffered', 'ready_buffered'),
                  ('shutdown_active', 'ready_buffered'), ('ready_buffered', 'shutdown_idle'), ('async_delayed',), catalogue.CASES)
    for selection in selections:
        expect_failure(lambda: coordinator.run(selection, **arguments), 'preflight', effects)
    expect_failure(lambda: coordinator.run(**arguments), 'default', effects)
    bad = dict(run_identity=('', 'a-b', 'x' * 33, 'é', True, 3, None), now=(-1, True, 1.0, catalogue.U64),
               units_per_second=(0, -1, True, 1.0, catalogue.U64), clock=(None,), child_factory=(None,))
    for field, values in bad.items():
        for value in values:
            supplied = dict(arguments, **{field: value})
            expect_failure(lambda: coordinator.run((), **supplied), field, effects)
    require(not effects, 'preflight callback effect')
    print('empty and malformed/unsupported/default/static preflight passed without effects')


def expect_failure(operation, name, effects=None, message=None):
    try:
        operation()
    except (ValueError, RuntimeError) as error:
        if message is not None:
            require(message in str(error), name + ' wrong rejection: ' + str(error))
        require(effects is None or not effects, name + ' invoked callback')
        return
    raise RuntimeError(name + ' silently succeeded')


if __name__ == '__main__':
    check_preflight()
    check_success()
