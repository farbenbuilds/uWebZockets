"""One bounded ordinary child over caller-owned synthetic peer and teardown facts."""
import adapter
import cases
import catalogue
import model
import shutdown_cases

COUNT_FIELDS = ('heads', 'small', 'request_flow', 'connections', 'settings', 'informationals',
                'incoming_resets', 'final_collections', 'receive_bytes', 'receive_calls')


def read_time(clock, previous, deadline):
    value = clock()
    if type(value) is not int or value < previous or value >= deadline:
        raise ValueError('monotonic time expired or invalid')
    return value


def validate_descriptor(value, identity):
    fields = {'identity', 'ready', 'fresh_application', 'connect', 'close', 'signal', 'process', 'post'}
    if type(value) is not dict or set(value) != fields:
        raise ValueError('child descriptor fields differ')
    actual = value['identity']
    if (type(actual) is not tuple or len(actual) != 2 or type(actual[0]) is not str or
            type(actual[1]) is not int or actual != identity or value['ready'] is not True or
            value['fresh_application'] is not True or
            not all(callable(value[key]) for key in ('connect', 'close', 'signal', 'process', 'post'))):
        raise ValueError('child descriptor facts differ')


def validate_connection(value, previous, deadline):
    fields = {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'}
    if (type(value) is not dict or set(value) != fields or value['protocol'] is None or
            not callable(value['send']) or not callable(value['receive']) or value['owned'] is not True or
            type(value['tls']) is not str or value['tls'] != 'TLSv1.3' or
            type(value['alpn']) is not str or value['alpn'] != 'h2' or
            type(value['now']) is not int or value['now'] < previous or value['now'] >= deadline):
        raise ValueError('connection facts differ')


def copy_facts(facts):
    # The model validators establish fixed keys and scalar leaves before copying.
    return dict(records={tag: dict(item) for tag, item in facts['records'].items()},
                metrics=dict(facts['metrics']), outputs={tag: dict(item) for tag, item in facts['outputs'].items()},
                binding=None if facts['binding'] is None else dict(facts['binding']))


def finish_child(context, descriptor, selection, units):
    capture = context['final_observations']
    model.validate_records(selection, 'before', capture['records'])
    model.validate_metrics(selection, 'before', capture['metrics'])
    outputs, binding = shutdown_cases.outputs(context, selection)
    before = copy_facts(dict(capture, outputs=outputs, binding=binding))
    context['shutdown_boundary'] = True
    deadline = shutdown_cases.grace(context, units)
    close = descriptor['close'](context, deadline)
    shutdown_cases.within_grace(context, deadline)
    expected = dict(method='close', client_closed=True, close='normal')
    if (type(close) is not dict or close != expected or
            any(type(close[key]) is not type(value) for key, value in expected.items())):
        raise ValueError('ordinary close evidence differs')
    close = dict(close)
    signal = descriptor['signal'](context, deadline)
    shutdown_cases.within_grace(context, deadline)
    shutdown_cases.validate_signal(signal, False)
    signal = dict(signal)

    def process_facts(current, grace_deadline):
        result = descriptor['process'](current, grace_deadline)
        shutdown_cases.validate_process(result)
        return dict(result)

    def post_facts(current, grace_deadline):
        result = descriptor['post'](current, grace_deadline)
        if type(result) is not dict or set(result) != {'records', 'metrics', 'outputs', 'binding'}:
            raise ValueError('post-deinit evidence fields differ')
        model.validate_pre_post(selection, before['records'], result['records'])
        model.validate_metrics(selection, 'after', result['metrics'])
        model.validate_output_pre_post(selection, before['outputs'], result['outputs'],
                                       binding_before=before['binding'], binding_after=result['binding'])
        return copy_facts(result)

    shutdown_cases.post_deinit(context, dict(process=process_facts, post=post_facts), deadline, before, selection)
    observed = context['shutdown_observations']
    return copy_facts(before), dict(close=close, signal=signal, process=dict(observed['process']),
                                    post=copy_facts(observed['after'])), deadline


def snapshot_counts(context):
    stage = context['stage']
    state = stage['case_state']
    counts = dict(heads=state['heads'], small=catalogue.add_u64(state['small'], stage['final_registered']),
                  request_flow=context['request']['case']['sent'], connections=state['connections'],
                  settings=context['request']['client_settings'], informationals=context['trace'].get('InformationalResponseReceived', 0),
                  incoming_resets=state['resets'], final_collections=int(stage['final_complete']),
                  receive_bytes=state['bytes'], receive_calls=state['reads'])
    for value in counts.values():
        catalogue.add_u64(value, 0)
    return counts


def run(selection=catalogue.CASES, *, run_identity, now, units_per_second, clock, child_factory):
    selection = cases.select(selection)
    if (type(run_identity) is not str or not 1 <= len(run_identity) <= 32 or
            any(character not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_' for character in run_identity)):
        raise ValueError('run identity differs')
    if (type(now) is not int or now < 0 or type(units_per_second) is not int or units_per_second <= 0 or
            not callable(clock) or not callable(child_factory)):
        raise ValueError('coordinator static inputs differ')
    whole = catalogue.add_u64(now, catalogue.mul_u64(900, units_per_second))
    ready_duration = catalogue.mul_u64(15, units_per_second)
    catalogue.mul_u64(30, units_per_second)
    if selection not in ((), ('ready_buffered',)):
        raise ValueError('coordinator selection not yet supported')
    totals = dict.fromkeys(COUNT_FIELDS, 0)
    if not selection:
        return dict(run_identity=run_identity, selection=selection, children=(), totals=totals, scope='pure_client_synthetic_peer')
    ready_start = read_time(clock, now, whole)
    ready = min(whole, catalogue.add_u64(ready_start, ready_duration))
    child_selection = catalogue.child_plan(selection)[0]
    identity = (run_identity, 0)
    descriptor = child_factory(run_identity, 0, child_selection, ready, whole)
    current = read_time(clock, ready_start, ready)
    validate_descriptor(descriptor, identity)
    case_start = read_time(clock, current, whole)
    case_deadline, whole = cases.deadlines(child_selection[0], case_start, whole, units_per_second)
    connection = descriptor['connect'](child_selection[0], 1, case_deadline, whole)
    validate_connection(connection, case_start, case_deadline)
    opened_at = read_time(clock, connection['now'], case_deadline)
    context = adapter.open_case(child_selection[0], connection['protocol'], connection['send'], opened_at,
                                case_deadline, whole, selected_before=(), clock=clock)
    receive = connection['receive']
    while context['stage']['initial_settings'] != 1 or context['stage']['acks'] != 1:
        adapter.tick(context)
        data, received_at = receive()
        adapter.observe(context, data, received_at)
    completed = adapter.run_case(context, receive)
    if completed is not None:
        context = completed
    adapter.final_collection(context, receive)
    counts = snapshot_counts(context)
    before, teardown, grace_deadline = finish_child(context, descriptor, child_selection, units_per_second)
    for key in COUNT_FIELDS:
        totals[key] = catalogue.add_u64(totals[key], counts[key])
    child = dict(identity=identity, selection=child_selection, counts=counts,
                 deadlines=dict(ready=ready, case=case_deadline, whole=whole, grace=grace_deadline),
                 final_observations=before, teardown=teardown)
    return dict(run_identity=run_identity, selection=selection, children=(child,), totals=totals, scope='pure_client_synthetic_peer')


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned synthetic hooks')
