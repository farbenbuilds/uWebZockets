"""Serialized ready child and hostile synthetic lifecycle inputs."""
import hashlib
import json
from unittest import mock
import adapter
import catalogue
import coordinator
import h2_client
import hpack
import model
import test_ready


def require(value, message):
    if not value:
        raise RuntimeError(message)


def peer(control=None):
    settings = b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    initial = test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b'')
    state = dict(startup=True, buffer=bytearray(), pending=initial, heads=0, received=0, received_bytes=0,
                 data=0, ends=0, settings=0, acks=0, digest=hashlib.sha256(), clock=2, clocks=0,
                 factory=0, connected=0, lifecycle=[], decoder=hpack.Decoder(), encoder=hpack.Encoder(),
                 records=model.records(('ready_buffered',), 'before'), context=None, result=None, control=control)
    paths = ('/health', '/metrics', '/echo', '/metrics', '/health')
    paths += tuple('/status/' + tag for tag in model.SPECS) + ('/metrics',)

    def response(stream, body):
        require(not state['pending'], 'response before prior read')
        block = state['encoder'].encode(((':status', '200'), ('x-middleware', 'retained')))
        state['pending'] = test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body)

    def respond(path, stream):
        if path == '/health':
            response(stream, b'ok')
            return
        if path.startswith('/status/'):
            response(stream, json.dumps(state['records'][path[8:]]).encode())
            return
        require(path == '/metrics', 'unexpected observation')
        values = model.metrics((), 'before')
        values.update(buffered_middleware=state['heads'], slot0_active=False, slot1_active=False)
        response(stream, json.dumps(values).encode())

    def packet_received(packet):
        kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
        if kind == 4:
            require(packet == test_ready.frame(4, 1, 0, b''), 'settings ACK differs')
            state['acks'] += 1
            return
        if kind == 0:
            payload = model.core_request('ready_buffered')['body']
            require(state['heads'] == 3 and stream == 5 and flags == 1 and packet[9:] == payload, 'echo DATA differs')
            state['data'] += len(packet[9:])
            state['ends'] += 1
            state['digest'].update(packet[9:])
            response(stream, payload)
            return
        require(kind == 1 and state['heads'] < len(paths) and not state['pending'], 'request before preceding response')
        entries = list(state['decoder'].decode(packet[9:]))
        path = paths[state['heads']]
        echo = path == '/echo'
        expected = [(':method', 'POST' if echo else 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)]
        if echo:
            expected += [('content-length', '257')]
        require(entries == expected and stream == 2 * state['heads'] + 1 and flags == (4 if echo else 5), 'request contract differs')
        state['heads'] += 1
        if not echo:
            respond(path, stream)

    def send(data):
        require(type(data) is bytes and 0 < len(data) <= 8192, 'send span differs')
        if state['startup']:
            state['startup'] = False
            expected = b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n'
            expected += test_ready.frame(4, 0, 0, b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                                        ((1, 4096), (2, 1), (4, 65535), (5, 16384), (8, 0), (3, 100), (6, 65536))))
            require(data == expected, 'startup bytes differ')
            state['settings'] += 1
            return
        state['buffer'].extend(data)
        require(len(state['buffer']) <= 8192, 'serialized parser bound differs')
        while len(state['buffer']) >= 9:
            size = int.from_bytes(state['buffer'][:3], 'big')
            if len(state['buffer']) < size + 9:
                return
            packet = bytes(state['buffer'][:size + 9])
            del state['buffer'][:size + 9]
            packet_received(packet)

    def receive():
        require(bool(state['pending']) and state['received'] < 74, 'finite peer input missing')
        data = state['pending']
        state['pending'] = b''
        state['received'] += 1
        state['received_bytes'] += len(data)
        return data, state['clock']

    def clock():
        state['clocks'] += 1
        return state['clock']

    def close(context, deadline):
        state['lifecycle'].append('close')
        state['context'] = context
        require(context['shutdown_boundary'] and context['completed'] and state['heads'] == 73 and
                not state['pending'] and not state['buffer'], 'close before complete collection')
        require(deadline == min(context['now'] + 15, context['stage']['case_deadline'], context['stage']['whole_deadline']), 'grace differs')
        state['close'] = dict(method='close', client_closed=True, close='normal')
        if control is not None:
            control('close', state, state['close'])
        return state['close']

    def signal(context, deadline):
        state['lifecycle'].append('signal')
        require(state['lifecycle'] == ['close', 'signal'] and context is state['context'], 'signal order differs')
        state['signal'] = dict(signal='SIGTERM', owned_identity=True, watcher_installed=True, client_open=False)
        if control is not None:
            control('signal', state, state['signal'])
        return state['signal']

    def process(context, deadline):
        state['lifecycle'].append('process')
        require(state['lifecycle'] == ['close', 'signal', 'process'] and context is state['context'], 'process order differs')
        state['process'] = dict(exit_code=0, reaped=True, forced=False, run_ok=True, deinit_ok=True, key_removed=True)
        if control is not None:
            control('process', state, state['process'])
        return state['process']

    def post(context, deadline):
        state['lifecycle'].append('post')
        require(state['lifecycle'] == ['close', 'signal', 'process', 'post'] and context is state['context'], 'post order differs')
        state['post'] = dict(records=json.loads(json.dumps(state['records'])), metrics=model.metrics(('ready_buffered',), 'after'),
                             outputs=model.default_outputs(), binding=model.default_binding())
        state['post']['metrics'].update(slot0_active=False, slot1_active=False)
        if control is not None:
            control('post', state, state['post'])
        return state['post']

    def connect(case, index, case_deadline, whole_deadline):
        state['connected'] += 1
        require((case, index, case_deadline, whole_deadline) == ('ready_buffered', 1, 32, 901), 'connect arguments differ')
        value = dict(protocol=h2_client.new_protocol(), send=send, receive=receive, now=state['clock'], owned=True, tls='TLSv1.3', alpn='h2')
        if control is not None:
            control('connect', state, value)
        return value

    def factory(identity, index, selection, ready_deadline, whole_deadline):
        state['factory'] += 1
        require((identity, index, selection, ready_deadline, whole_deadline) == ('ready_0', 0, ('ready_buffered',), 17, 901), 'factory arguments differ')
        value = dict(identity=(identity, index), ready=True, fresh_application=True, connect=connect,
                     close=close, signal=signal, process=process, post=post)
        if control is not None:
            control('factory', state, value)
        return value

    return state, clock, factory


def run_peer(control=None):
    state, clock, factory = peer(control)
    original = adapter.final_collection
    boundary = {}

    def collect(context, receive):
        require(not boundary and state['heads'] == 5 and context['completed'], 'final collection count differs')
        boundary.update({name: context[name] for name in ('stage', 'raw', 'request', 'credit', 'records')})
        boundary['bytes'], boundary['reads'] = context['stage']['bytes'], context['stage']['reads']
        boundary['received'], boundary['received_bytes'] = state['received'], state['received_bytes']
        require(context['selected_before'] == () and context['request']['connection_debt'] == 257 and
                context['request']['stream_debt_total'] == 257, 'final inherited debt differs')
        value = original(context, receive)
        require(value is None and context['stage']['final_registered'] == 68, 'ordinary return or collection differs')
        require(all(context[name] is boundary[name] for name in ('stage', 'raw', 'request', 'credit', 'records')), 'final state replaced')
        require(context['stage']['bytes'] == boundary['bytes'] + state['received_bytes'] - boundary['received_bytes'] and
                context['stage']['reads'] == boundary['reads'] + state['received'] - boundary['received'], 'cumulative final counters differ')
        require(context['stage']['final_budget'] == catalogue.final_budget(514) and
                (context['stage']['case_deadline'], context['stage']['whole_deadline']) == (32, 901), 'final bounds changed')
        require(context['request']['connection_debt'] == 257 and context['request']['stream_debt_total'] == 257, 'unrefunded debt erased')
        return value

    with mock.patch.object(adapter, 'final_collection', collect):
        result = coordinator.run(('ready_buffered',), run_identity='ready_0', now=1, units_per_second=1, clock=clock, child_factory=factory)
    state['result'] = result
    return state, result


def check_success():
    state, result = run_peer()
    child = result['children'][0]
    require(set(result) == {'run_identity', 'selection', 'children', 'totals', 'scope'} and
            result['scope'] == 'pure_client_synthetic_peer' and result['selection'] == ('ready_buffered',) and
            result['run_identity'] == 'ready_0', 'result schema differs')
    require(set(child) == {'identity', 'selection', 'counts', 'deadlines', 'final_observations', 'teardown'} and
            child['identity'] == ('ready_0', 0) and child['selection'] == ('ready_buffered',), 'child schema differs')
    expected = dict(heads=73, small=73, request_flow=257, connections=1, settings=1, informationals=0,
                    incoming_resets=0, final_collections=1, receive_bytes=state['received_bytes'], receive_calls=74)
    require(child['counts'] == expected and result['totals'] == expected and result['totals'] is not child['counts'], 'actual totals differ')
    require(child['deadlines'] == dict(ready=17, case=32, whole=901, grace=17), 'retained deadlines differ')
    require(state['heads'] == 73 and state['received'] == 74 and state['data'] == 257 and state['ends'] == 1 and
            state['settings'] == 1 and state['acks'] == 1 and state['digest'].hexdigest() == model.CORE_RESPONSES['ready_buffered'][2], 'serialized action totals differ')
    require(state['lifecycle'] == ['close', 'signal', 'process', 'post'] and state['factory'] == 1 and state['connected'] == 1, 'complete lifecycle differs')
    before = child['final_observations']
    require(set(before) == {'records', 'metrics', 'outputs', 'binding'} and before['records'] == state['records'] and
            before['metrics']['buffered_middleware'] == 73 and before['binding'] is None, 'observed baseline differs')
    model.validate_pre_post(('ready_buffered',), before['records'], child['teardown']['post']['records'])
    model.validate_output_pre_post(('ready_buffered',), before['outputs'], child['teardown']['post']['outputs'],
                                   binding_before=before['binding'], binding_after=child['teardown']['post']['binding'])
    retained = json.dumps(result, sort_keys=True)
    state['post']['records']['empty_headers']['middleware'] = 99
    state['post']['metrics']['buffered_middleware'] = 99
    state['post']['outputs']['stream_file']['close_calls'] = 99
    state['post']['binding']['binding_index'] = 99
    state['process']['exit_code'] = 99
    state['signal']['signal'] = 'wrong'
    state['close']['client_closed'] = False
    state['context']['final_observations']['records']['empty_headers']['middleware'] = 99
    require(json.dumps(result, sort_keys=True) == retained, 'returned evidence aliases callback graphs')
    print('ready coordinator serialized lifecycle passed: heads=73 small=73 flow=257 settings=1 final=68 reads=74 bytes=%d' % expected['receive_bytes'])


def check_preflight():
    effects = []

    def reject(*args):
        effects.append(args)
        raise RuntimeError('preflight invoked callback')

    arguments = dict(run_identity='ready_0', now=1, units_per_second=1, clock=reject, child_factory=reject)
    result = coordinator.run((), **arguments)
    require(result == dict(run_identity='ready_0', selection=(), children=(), totals=dict.fromkeys(
            ('heads', 'small', 'request_flow', 'connections', 'settings', 'informationals', 'incoming_resets', 'final_collections', 'receive_bytes', 'receive_calls'), 0),
            scope='pure_client_synthetic_peer') and not effects, 'empty selection had effects or facts')
    selections = (None, 'ready_buffered', {}, ('unknown',), ('ready_buffered', 'ready_buffered'),
                  ('shutdown_active', 'ready_buffered'), ('ready_buffered', 'shutdown_idle'), ('async_delayed',), catalogue.CASES)
    for selection in selections:
        expect_failure(lambda: coordinator.run(selection, **arguments), 'preflight', effects)
    expect_failure(lambda: coordinator.run(**arguments), 'default', effects)
    bad = dict(run_identity=('', 'a-b', 'x' * 33, 'é', True, 3, None), now=(-1, True, 1.0, catalogue.U64),
               units_per_second=(0, -1, True, 1.0, catalogue.U64), clock=(None,), child_factory=(None,))
    for field, values in bad.items():
        for value in values:
            supplied = dict(arguments, **{field: value})
            expect_failure(lambda: coordinator.run((), **supplied), field, effects)
    require(not effects, 'preflight callback effect')
    print('empty and malformed/unsupported/default/static preflight passed without effects')


def expect_failure(operation, name, effects=None, message=None):
    try:
        operation()
    except (ValueError, RuntimeError) as error:
        if message is not None:
            require(message in str(error), name + ' wrong rejection: ' + str(error))
        require(effects is None or not effects, name + ' invoked callback')
        return
    raise RuntimeError(name + ' silently succeeded')


def check_rejections():
    controls = []
    for key in ('identity', 'ready', 'fresh_application', 'connect', 'close', 'signal', 'process', 'post'):
        controls.append(('factory_missing_' + key, 'factory', lambda value, key=key: value.pop(key), 'child descriptor fields', []))
    for key in ('connect', 'close', 'signal', 'process', 'post'):
        controls.append(('factory_callable_' + key, 'factory', lambda value, key=key: value.update({key: None}), 'child descriptor facts', []))
    for value in (['ready_0', 0], ('other', 0), ('ready_0', False), ('ready_0', True), ('ready_0', 1), ('ready_0', 0, 0)):
        controls.append(('identity_' + repr(value), 'factory', lambda fact, value=value: fact.update(identity=value), 'child descriptor facts', []))
    for key in ('ready', 'fresh_application'):
        for value in (False, 1, None):
            controls.append((key + repr(value), 'factory', lambda fact, key=key, value=value: fact.update({key: value}), 'child descriptor facts', []))
    controls.append(('factory_extra', 'factory', lambda fact: fact.update(extra=True), 'child descriptor fields', []))
    for key in ('protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'):
        controls.append(('connection_missing_' + key, 'connect', lambda value, key=key: value.pop(key), 'connection facts', []))
    for key, value in (('protocol', None), ('send', None), ('receive', None), ('now', True), ('now', 1), ('now', 32),
                       ('now', 2.0), ('owned', 1), ('owned', False), ('tls', 'TLSv1.2'), ('alpn', 'http/1.1')):
        controls.append(('connection_' + key + repr(value), 'connect', lambda fact, key=key, value=value: fact.update({key: value}), 'connection facts', []))
    controls.append(('connection_extra', 'connect', lambda fact: fact.update(extra=True), 'connection facts', []))
    for key, value in (('method', 'unwrap'), ('client_closed', False), ('client_closed', 1), ('close', 'error')):
        controls.append(('close_' + key, 'close', lambda fact, key=key, value=value: fact.update({key: value}), 'ordinary close evidence', ['close']))
    controls.append(('close_extra', 'close', lambda fact: fact.update(extra=True), 'ordinary close evidence', ['close']))
    for key, value in (('signal', 'SIGKILL'), ('owned_identity', False), ('owned_identity', 1), ('watcher_installed', False),
                       ('watcher_installed', 1), ('client_open', True), ('client_open', 0)):
        controls.append(('signal_' + key + repr(value), 'signal', lambda fact, key=key, value=value: fact.update({key: value}), 'owned signal evidence', ['close', 'signal']))
    for key, value in (('exit_code', False), ('exit_code', 1), ('reaped', False), ('reaped', 1), ('forced', True), ('forced', 0),
                       ('run_ok', False), ('deinit_ok', False), ('key_removed', False)):
        controls.append(('process_' + key + repr(value), 'process', lambda fact, key=key, value=value: fact.update({key: value}), 'shutdown process evidence', ['close', 'signal', 'process']))
    controls.append(('process_extra', 'process', lambda fact: fact.update(extra=True), 'shutdown process evidence', ['close', 'signal', 'process']))
    for name, phase, mutate, message, expected in controls:
        state, clock, factory = peer(lambda actual, _state, value, phase=phase, mutate=mutate: mutate(value) if actual == phase else None)
        expect_failure(lambda: coordinator.run(('ready_buffered',), run_identity='ready_0', now=1, units_per_second=1,
                                               clock=clock, child_factory=factory), name, message=message)
        require(state['lifecycle'] == expected, name + ' continued after invalid fact')
        if phase in ('factory', 'connect'):
            require(state['startup'] and state['heads'] == 0, name + ' sent bytes before validation')
        if phase == 'factory':
            require(state['connected'] == 0, name + ' connected before descriptor validation')
    print('typed descriptor/connection/close/signal/process rejections passed: %d' % len(controls))


def check_boundaries():
    for phase, value, expected in (('factory', 1, []), ('factory', True, []), ('factory', 17, []), ('factory', 901, []),
                                   ('connect', 1, []), ('connect', 32, []), ('close', 17, ['close']),
                                   ('signal', 17, ['close', 'signal']), ('process', 17, ['close', 'signal', 'process']),
                                   ('post', 17, ['close', 'signal', 'process', 'post'])):
        def control(actual, state, _fact, phase=phase, value=value):
            if actual == phase:
                state['clock'] = value
        state, clock, factory = peer(control)
        expect_failure(lambda: coordinator.run(('ready_buffered',), run_identity='ready_0', now=1, units_per_second=1,
                                               clock=clock, child_factory=factory), 'time ' + phase)
        require(state['lifecycle'] == expected, 'time failure continued hooks')
    for phase in ('factory', 'connect', 'close', 'signal', 'process', 'post'):
        original = RuntimeError('caller failure ' + phase)

        def control(actual, _state, _fact, phase=phase):
            if actual == phase:
                raise original
        state, clock, factory = peer(control)
        try:
            coordinator.run(('ready_buffered',), run_identity='ready_0', now=1, units_per_second=1, clock=clock, child_factory=factory)
        except RuntimeError as error:
            require(error is original, 'callback error was replaced')
        else:
            raise RuntimeError('callback failure silently succeeded')
        if phase == 'close':
            require(state['lifecycle'] == ['close'], 'failed close invoked signal')
        if phase == 'signal':
            require(state['lifecycle'] == ['close', 'signal'], 'failed signal invoked process')
    for bad in (None, [], True):
        state, clock, _factory = peer()
        expect_failure(lambda: coordinator.run(('ready_buffered',), run_identity='ready_0', now=1, units_per_second=1,
                                               clock=clock, child_factory=lambda *_args: bad), 'descriptor type', message='child descriptor fields')
        require(state['connected'] == 0 and state['startup'], 'bad descriptor had effects')
    print('rollback/equality-expiry and callback-error identity/order boundaries passed')


def check_post_privacy():
    corruptions = (
        ('schema', lambda fact: fact.update(extra=True), 'post-deinit evidence fields'),
        ('record', lambda fact: fact['records']['empty_headers'].update(middleware=1), 'record mismatch'),
        ('metrics', lambda fact: fact['metrics'].update(buffered_middleware=74), 'metrics differ'),
        ('slots', lambda fact: fact['metrics'].update(slot0_active=1), 'binding slot activity'),
        ('outputs', lambda fact: fact['outputs']['stream_file'].update(close_calls=1), 'unselected output differs'),
        ('binding', lambda fact: fact['binding'].update(binding_index=1), 'unselected binding differs'))
    for name, mutate, message in corruptions:
        def control(phase, _state, fact, mutate=mutate):
            if phase == 'post':
                mutate(fact)
        expect_failure(lambda: run_peer(control), 'post ' + name, message=message)
    original_final = adapter.final_collection

    def duplicate(phase, state, _fact):
        if phase == 'close':
            original_final(state['context'], lambda: (b'forbidden', 2))
    expect_failure(lambda: run_peer(duplicate), 'duplicate finalization', message='invalid final boundary')

    def late_observation(phase, state, _fact):
        if phase == 'signal':
            adapter.observe(state['context'], b'forbidden', 2)
    expect_failure(lambda: run_peer(late_observation), 'post-boundary observation', message='observation after shutdown')

    def public_mutation(phase, state, _fact):
        if phase == 'close':
            capture = state['context']['final_observations']
            capture['records']['empty_headers']['middleware'] = 1
            capture['metrics']['buffered_middleware'] = 999
            state['context']['output_observations'] = model.default_outputs()
            state['context']['output_binding'] = dict(binding_index=999)
    state, result = run_peer(public_mutation)
    require(result['children'][0]['final_observations']['records']['empty_headers']['middleware'] == 0 and
            result['children'][0]['final_observations']['metrics']['buffered_middleware'] == 73 and
            result['children'][0]['final_observations']['outputs'] == model.default_outputs() and
            result['children'][0]['final_observations']['binding'] is None, 'private baseline changed through public capture')

    def coherent_forgery(phase, state, fact):
        public_mutation(phase, state, fact)
        if phase == 'post':
            fact['records']['empty_headers']['middleware'] = 1
    expect_failure(lambda: run_peer(coherent_forgery), 'coherent public/post forgery', message='record mismatch')

    def retained_mutation(phase, state, _fact):
        if phase == 'post':
            state['close']['client_closed'] = False
            state['signal']['client_open'] = True
            state['process']['exit_code'] = 77
    state, result = run_peer(retained_mutation)
    teardown = result['children'][0]['teardown']
    require(teardown['close']['client_closed'] is True and teardown['signal']['client_open'] is False and
            teardown['process']['exit_code'] == 0, 'earlier validated facts were not sealed before later hooks')
    print('post validators, private baseline, duplicate/observation boundary and sealed returned facts passed')


def check_clock_handoff():
    state, _clock, factory = peer()
    times = iter((2, 2, 2, 3, 2))

    def clock():
        return next(times, 2)

    expect_failure(lambda: coordinator.run(('ready_buffered',), run_identity='ready_0', now=1, units_per_second=1,
                                           clock=clock, child_factory=factory), 'pre-open clock rollback', message='monotonic time moved backwards')
    require(state['startup'] and state['heads'] == 0, 'rollback emitted startup bytes')
    print('pre-open clock observation retained across adapter handoff')


if __name__ == '__main__':
    check_preflight()
    check_success()
    check_rejections()
    check_boundaries()
    check_clock_handoff()
    check_post_privacy()
