# Task5e3b7a: first complete pure coordinator child lifecycle

Implemented and ready for Root's independent review. `coordinator.run` now executes explicit empty or one complete `('ready_buffered',)` child using the unchanged actual dispatcher and canonical startup/observe/final-collection path. The selected case's five real serialized requests, exact257-byte echo/hash,67 statuses and one final metrics request all execute. The ordinary close -> SIGTERM -> supplied process/reap -> protected post-deinit comparison completes. This checkpoint deliberately rejects every other valid nonempty selection, including omitted/default all40, before clock/factory effects. It does not satisfy parent all40/default/aggregate or native acceptance.

The final four relevant commands pass in pinned Python normal and `-O` modes, all exits0, stderr empty. These are Python optimization modes; no Zig optimization mode, sanitizer result or performance measurement is claimed. Serialized peer counters are73 heads,73 small responses,257 request-flow bytes,one connection,one actual client SETTINGS,zero informational responses,zero incoming resets,one final collection,74 actual canonical receive calls and29903 received bytes. Receive counts include the startup SETTINGS/ACK read. The independent peer validates the outbound settings ACK separately.

## Contract, ownership and unchanged baseline

Authority is `task-5e3b7a-brief.md`, `task-5e3b-all40-first-slice-contract.md`, accepted `task-5e3b-all40-plan-report.md`, original cases brief/release addendum, combined architecture, finite barrier handoff and aggregate acceptance notes. The initial35-module byte map exactly matched `docs/implement-2-2-0/evidence/m2_h2_combined_shutdown/manifest.json`, bound to released parent commit322784dea07fd7693b8dba57969636e3e6ed3639. This task did not run Git; Root's prior audit supplies the pushed identity. The captured baseline is `evidence/coordinator-a/before-source/` and `before-map.json`.

Only new `coordinator.py`, new `test_coordinator.py`, the minimal actual-used two-name inventory addition to `test_imports.py`, `evidence/coordinator-a/` and this report were authored. Of the existing35 source modules,34 are byte-identical; only the import inventory changed. All3962 prior evidence files captured before implementation still match their SHA256 identities. No handler/helper/model/core/fixture/product/pin/capacity/deadline was edited. No shared existing API gap was found or shared edit requested. Root was told this before implementation.

The project/role context and narrow TDD/API/review/verification/constraint/debugging skill guidance were consulted. Existing written contract and explicit source-only scope supersede generic skill interviews, installs, broad gates and delegation. No agent, external model CLI, Git write, public edit, native build/server/socket/SSLContext/TLS-close/real-clock/process ownership/descriptor/kernel/probe experiment ran. The old runtime constructors and live entrypoints were neither imported nor executed. Only pinned public codecs, pure caller callbacks and supplied synthetic facts were exercised.

Before new codebase searches the exact release prefix ran:

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "combined-cases ready_buffered shutdown_cases adapter test_imports coordinator" --budget 650
```

It exited0 and reported16941 graph nodes,137 traversal nodes,18 shown/119 cut by650-token budget. Further narrowly scoped queries were `output_stage initial_settings informationals resets case_state reads` and `wire trace informationals settings`; both exited0 with650-token truncation. Their raw outputs remain in the tool transcript. Supplied paths and graph/earlier-read locators scoped subsequent reads. Both AST-only update receipts are retained below: the first reports the sandbox parallel-extraction fallback and25 files with no symbols, and the final reports no relevant changes. Neither establishes a topology refresh for ignored source.

## Actual API and control flow

`run(selection=catalogue.CASES, *, run_identity, now, units_per_second, clock, child_factory)` calls `cases.select` to validate/freeze caller order before any callback. `None`, malformed/unknown/duplicate/order-invalid selections fail. Identity is exact str1..32 ASCII alphanumeric/underscore; hyphens and the old1..64 runtime grammar fail. Exact nonnegative integer `now`, positive integer units, callable hooks and checked u64 whole/ready/case arithmetic are required; bool is rejected. Empty returns exact zero totals, frozen selection and no children/final/teardown facts without clock/factory effects. Every other nonempty selection except ready fails before effects.

Whole is now+900*units. The supplied monotonic ready start precedes whole expiry; ready is min(whole,ready_start+15*units). Factory is called as `(run_identity,0,child_selection,ready_deadline,whole_deadline)`. After factory, readiness is checked again with equality expired. A separate monotonic case start establishes the unchanged `cases.deadlines` pair before connect. No setup time or new final deadline is invented.

Factory descriptor exact keys are identity,ready,fresh_application,connect,close,signal,process,post. Identity must be exact `(str,int)` matching `(run_identity,0)`; False cannot replace index0. Readiness/freshness are exactlyTrue and the five hooks callable. `connect(case,1,case_deadline,whole_deadline)` supplies exact protocol,send,receive,now,owned,tls,alpn fields, with nonnull already-initiated helper-shaped codec, callable send/receive, strict monotonic integer time, ownedTrue,TLSv1.3,h2. Canonical `wire.startup` additionally checks exact helper startup bytes/settings. Supplied connection time and the caller clock are checked before open; the latter observation is retained as `opened_at` across the adapter handoff.

`adapter.open_case(...,selected_before=(),clock=clock)` owns fresh parser/request+response ledgers/response records/stage. Coordinator receives startup through `adapter.observe` until initial SETTINGS and ACK are complete, invokes actual `adapter.run_case(context,receive)`, retains ordinaryNone input context and normalizes only non-None results. It calls ordinary `adapter.final_collection` exactly once and immediately consumes its actual parsed `context.final_observations`; ordinaryNone is unchanged. No check() helper or model-generated completion replaces dispatcher execution.

Cumulative case state is snapshotted once after final: heads already include68; small=pre-final small+final_registered. Actual request-flow/connections/client_settings/trace informational count/incoming resets/canonical bytes+reads/final-complete counters supply counts; each counter is checked through catalogue.add_u64. Totals own a separate dict. No separate final snapshot is added.

`shutdown_cases.outputs` validates/copys ready's unselected output defaults and absent before binding. These defaults are not observed output-case execution. All67 parsed records, parsed metrics, copied outputs and binding are copied into a private bounded baseline before exposing context to any teardown hook. Original public final capture remains separate. Ordinary observation boundary is set; `shutdown_cases.grace` runs once and clips15 supplied seconds to original case/whole. `within_grace` checks after each hook; no grace recomputation or active-only stage.signal occurs.

Close schema is locally exact method=close,client_closed=True,close=normal with strict scalar types. Signal reuses `shutdown_cases.validate_signal(actual,False)`. Both are copied before subsequent hooks. Existing `shutdown_cases.post_deinit` performs process -> post, inherited deadline/grace checks, process validation, exact post schema, model record/metric/output/binding comparisons and protected capture publication. Coordinator callback adapters add bounded ownership: process is validated and copied immediately before post can mutate its original dictionary; post facts pass actual model pre/post validators before copying. The shared seam validates those copies again and publishes only after success. Result copies before/process/post graphs after comparison with no later hook. A later mutation of hook-owned dictionaries cannot rewrite returned evidence, and mutated originals are not later relabeled as checked values; the saved facts represent their validated callback-return snapshots.

Exact top-level result is run_identity,selection,children,totals,scope=`pure_client_synthetic_peer`. Child fields are identity,selection,counts,deadlines,final_observations,teardown; deadlines are ready,case,whole,grace; final facts are records,metrics,outputs,binding; teardown close,signal,process,post. Empty children is tuple(); ready children is a one-element tuple. Count/totals keys exactly heads,small,request_flow,connections,settings,informationals,incoming_resets,final_collections,receive_bytes,receive_calls.

## Independent serialized and hostile-input proof

`test_coordinator.py` calls coordinator.run itself, with the actual adapter dispatcher intact. It uses pinned HPACK to decode outbound frame bytes; exact routes are `/health`,`/metrics`,`/echo`,`/metrics`,`/health`, then catalogue/model-ordered67 `/status/<tag>` requests and `/metrics`. Every header list, duplicate multiplicity, odd stream ID and END flag is checked at the current finite cursor. Echo is stream5 POST,content-length257; one terminal DATA frame carries the exact canonical257 bytes and SHA256a2c6cad2ffa699b14538231fef914f45d30440389e6f8d79091efba836165a2b. Exact75-byte startup preface/SETTINGS and one settings ACK are checked. Each next request requires the prior response to have been consumed. One pending bounded response, one<=8192 serialization buffer, finite head/receive cursors and incremental hash replace request/frame/read histories; no large bodies exist.

The sole test wrapper around final_collection calls its original implementation. It verifies five completed case heads at entry, ordinaryNone return,68 final registrations, same stage/raw/request/response-credit/record identities, cumulative bytes/reads, original32/901 deadlines and final_budget(514). Both unrefunded request scopes stay257 across final; no zero-debt requirement is invented. Final metrics have buffered_middleware73 and inactive slots; all67 unselected records validate. No extra health/collection/output GET, idle ID or signal-stage action occurs.

Controls cover all39 other individually valid IDs plus default and malformed/order/duplicate input before effects; empty list freezing and valid fixture identity boundaries; static bool/overflow inputs;67 exact descriptor/connection/close/signal/process controls; descriptor indexFalse/True and wrong tuple shape; non-dict hook returns; readiness/case/preopen timestamp rollback and exact expiry; post-hook grace expiry; original callback error object propagation and close/signal failure stopping later hooks. Ready whole clipping, case-clipped grace, checked ready-add overflow before factory, and caller selection-list mutation are covered.

Post controls use actual unchanged model validators for schema, record/bool field, metrics/slot type, output and binding corruption. Duplicate finalization is rejected at canonical `invalid final boundary`; observation after boundary is rejected by adapter. Mutating public before records/metrics/output fields/binding during close does not alter the private baseline; matching forged post records still fail actual record validation. Later post mutations of earlier close/signal/process dictionaries cannot change already sealed returned facts. Mutating all hook-owned and public context graphs after successful return cannot rewrite the result. These are pure sensitivity controls, not native fault probes.

## Genuine RED/GREEN and intermediate history

Initial35-module normal/-O inert import checks passed before source implementation. Actual initial test bytes are `initial-test_coordinator.py`; initial RED exits1 at ModuleNotFoundError for coordinator, proving absence only, not serialization or lifecycle rejection. Attempt1 then passed the initial empty/preflight and actual serialized full lifecycle checks. Attempt2 expanded schema/time/privacy controls,67 typed rejections, and passed. No failing earlier check was removed.

Self-review found a clock-handoff concern. A new behavioral regression used supplied clock observations2,2,2,3,2. Before the fix, the coordinator discarded observation3 immediately before open and adapter accepted2 against the older connection time; `clock-red` exits1 because rollback silently succeeded. This is a genuine uncovered new implementation behavior failure, preserved with exact source and traceback. The coordinator now passes checked `opened_at` to open_case; attempt3 passes the same regression. Attempt4 adds selection freezing, clipping/ready overflow and post-schema controls and passes. Further non-dict-return and pre-start clock controls were added before the final four normal/O checks. Every source attempt/RED and raw result remains saved; final-source is current37 modules. There are no unreported intermediate test failures. Final self-review replaced the duplicate ordinary30 timeout literal with the immutable catalogue timeout and removed unused peer fields; the first final four-command matrix/source/audit are preserved with pre-self-review labels. Only the same four relevant checks were repeated after those final edits, and all passed again. The snapshot/audit were regenerated and AST-only graph update repeated; the earlier update receipt is preserved too.

## Current source/input identities and retained proof

`evidence/coordinator-a/snapshot.json` is the current37-module SHA256 map/control-depth/ownership snapshot. `source.diff` is the exact diff from accepted35. The two new modules and one inventory-only change are the entire source delta. All37 have one main guard, no authored classes/custom exceptions/assert proofs and maximum control depth3. Actual imports with empty/foreign argv, rejecting open/socket/SSLContext/process/OS/time/stdout/stderr doubles pass in both modes.

Immutable core remains `/tmp/uwz-task5e3a-snapshot-v9/source` (26 modules), model/catalogue `/tmp/uwz-task5e1-contract-v3`, compiled-only fixture `/tmp/uwz-task5e2-Fix1Final2/fixture` (25 canonical files), helper integration-client/h2_client.py SHA25607a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00. No immutable code was copied into a second model. All retained inputs were rehashed against B6d fix2's exact list, copied unchanged at `immutable-inputs.json`:118 file rows/113 unique resolved files, plus the ordered42-codec aggregate, hence119 retained identity entries/114 unique entries. Codec file set is exactly unchanged and default-json ordered aggregate is0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473. Pinned interpreter `/home/codespace/.python/current/bin/python3` was rehashed, SHA2564c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601; resolved path and size are `python-identity.json`.

Final source SHA256 values:

| Module | SHA256 |
| --- | --- |
| adapter.py | e03016a847a75fa5ffc03e5ff17ffc6887dff15b3ed0fa5f82f2240713698e7a |
| admission_cases.py | b4cac4031f9be16bca938f7167bb327f4eae4fd5667b42cb70fc23782f8fbbcf |
| application_error_cases.py | 9d63d938391f2181205766c3297d9aae5ce6966d9f371251b9fa5aeb152d9e68 |
| cases.py | f89fe655f8c66c98e67ffd7723b07980234e124b130a8a99a790cb80fc54bcd5 |
| concurrent_cases.py | a9ab3e7b6f6a362c1c6d33788fa8b7c3ed5961989be1f58d7fd6cc66a998a7c1 |
| continue_quota_cases.py | da533ef0fde4179c00427d11b689cba1fdf248e41ba01c98a47f37a08ec99e95 |
| control_reset_cases.py | 36b8fe72e24eaf8cb7a30b470ea4c23823f324373ac3d4d90a6cc8a1595979d7 |
| coordinator.py | 4c66b1da5e55203ea67bd8fedecdaf073bc4864c0e8d8253fb26f61f364f2703 |
| credit_cases.py | f953e2bacb92c4370904cf2b6e302a215aed9bd28210290406aac965e8d2178d |
| file_early_cases.py | 90479c670ee1d75c4974704bb6b51d4543142c80c10a8b01963a1a31e0dc9d8c |
| lifecycle_cases.py | 3aeb930ef537ac4690ba3f0b5deaffd3a1770981e247652f9fb2f77ffd98a92c |
| metadata_cases.py | 7a48599c53779a2414f4492371174d35030e91d1dd61570408248b7eae12b83c |
| pause_cases.py | c7e28527478f3a3e52de22de019e1698083a8d03b4bca3100dd4788e77a8f250 |
| producer_pressure_cases.py | 44cb04ab3eee53c50c8cd508244486ef6693646aa276836e244a9fb18caffbda |
| shutdown_cases.py | 2856e200fa463b26c79e4e0b74cc9ead4863f9a1dd6372c0e8249fb9b163e15c |
| test_adapter.py | ef325e804d454e12a4f8b2d2dfa2e0c778736758cf8618334081c864940aefbf |
| test_admission.py | 28b88c1b8dcdccc03154cb7472cf14ce0f3819de54b78d72e9fec68608381d9d |
| test_application_error.py | 221d38b7d31fc419d990df1ce512f9cdc509e7c3a9eb1f9c4ef961a43b82c96c |
| test_async.py | bcf31ec8037b3ba4861d25e7983efaeef269df5c084dc3922cc358d8e94ae314 |
| test_continue_quota.py | 71ed633a7d9151dcacc99f4665b1ae45e9423ee7dc589e9607e280a67bdf9914 |
| test_control_reset.py | 7b81f969a0cd5146ac5ac075bd2cc2d25aca890c021db4ab73f828eb04780d67 |
| test_coordinator.py | 54f8ed7b924b7141175ca35c05095f9544ea0854503e05e17698c5ca5f707844 |
| test_credit.py | bd03e99dbe6d1297bc96badf870c4be7486ef2524a14befd323bbebb8a9e0a65 |
| test_file_early.py | 8feb6e45339160eb28b19a5635a22eba58cc8206f6f127975739201b0d045604 |
| test_final.py | 830e5fdfb3475b1ab11e2b956f4494abff9e7176f684e166e282b30b1d90b626 |
| test_imports.py | 3e20e5a9a62e4b2dce814ad50320303e630d648bbac1b3cb14994ccb64f7ac69 |
| test_large.py | 5710cb5be11f777f2c0ba4f0b3a647227f75b5955dcf1f8cecd750419b46c7d0 |
| test_lifecycle.py | 7346386e3482a800bfe20b0dc8da8726dc66d6dd8a516ac038de4222a21f535a |
| test_metadata_concurrency.py | 21708e73da3f401891b975414578ce136ac40a8848cfa730f429e17d9251294d |
| test_negative.py | 91ae248806c1402bd4219474c3e08e1ef2fcb5994d3e6f7b5e7f40fac4ec47f0 |
| test_pause.py | 86f3faa897d8c278dfeef4f7359194b3eea5e1b284ba46bf012ecc6f569c291e |
| test_producer_pressure.py | 79dc174853ad5285c37e6f36368199d20d403f3afa488e80a32a04faa036ff51 |
| test_ready.py | 600ec8b0bc072aa4d9a52417425e77c56edc2e02680bdb01d9d288c52001b442 |
| test_selection.py | eae469c25524ddaa3b02c0474dcebae605ba0d64846d8ae50de57a76b8f57aa3 |
| test_shared.py | cbd3370c4dd56990c126939503a35dd5eabd8a03ce71195865152510a973b91b |
| test_shutdown.py | 5f6a9e929831a97f935cd685e98cf429ff76a9d59a01047c2cdfb2a2d637dad6 |
| test_time.py | 0e10a1c68bfdd754b67a656bd8f4cc05ca8fcf8c9af63ab66130e2e969edf967 |

## Self-review and remaining facts

Self-review checked exact ownership/source diff, failure propagation, private baseline alias boundaries, strict schemas/bool handling, canonical dispatcher/startup/final68 use, counts once, caller time handoffs, inherited deadlines/debt/read accounting and bounded retained graphs. It found and fixed the clock rollback only after retaining its failing test. No test, baseline, bound, assertion or pin was weakened. All source edits precede the final normal/O checks; only evidence/report generation and AST-only graph maintenance followed.

This is synthetic prepared-child/readiness/logical identity/freshness/owned/TLS evidence only. It proves no actual native application, PID/start/listener identity, process ownership/reap/key cleanup, socket/TLS close, readiness/build/certificate setup or post-deinit native callback behavior. All40 source handlers remain unchanged and selected-before is empty here; default/all40 coordinator dispatch, multiple cases/children, idle child, replacement, selected output retention, parent aggregate proof and later runtime closure remain open. Native two-child acceptance, product adoption, M2/2.2.0 and project/platform/compliance/performance/fork/release gates remain open. Broad Zig/unit/sanitizer/build/fuzz/package/protocol gates were not run because the exact task prohibits native/build/probe execution. MSan would cover only the C boundary, not Zig code, and cannot combine with ASan; no sanitizer claim is made.

## Exact commands and raw results

Each command below is retained with separate `.command`,`.stdout`,`.stderr`,`.exit` files under evidence/coordinator-a. Initial capture and source edits are in the tool transcript; executable evidence recorders use guarded inline Python, with no separately authored unguarded helper module. The public all37-module import inventory covers every authored source helper.

### initial-imports-normal

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `0`.

stdout:

```text
AST and inert import checks passed
```

stderr: empty.

### initial-imports-optimized

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `0`.

stdout:

```text
AST and inert import checks passed
```

stderr: empty.

### initial-red

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py
```

Exit: `1`.

stdout:

empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py", line 7, in <module>
    import coordinator
ModuleNotFoundError: No module named 'coordinator'
```

### attempt-1

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py
```

Exit: `0`.

stdout:

```text
empty and malformed/unsupported/default/static preflight passed without effects
ready coordinator serialized lifecycle passed: heads=73 small=73 flow=257 settings=1 final=68 reads=74 bytes=29903
```

stderr: empty.

### attempt-2

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py
```

Exit: `0`.

stdout:

```text
empty and malformed/unsupported/default/static preflight passed without effects
ready coordinator serialized lifecycle passed: heads=73 small=73 flow=257 settings=1 final=68 reads=74 bytes=29903
typed descriptor/connection/close/signal/process rejections passed: 67
rollback/equality-expiry and callback-error identity/order boundaries passed
post validators, private baseline, duplicate/observation boundary and sealed returned facts passed
```

stderr: empty.

### clock-red

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py
```

Exit: `1`.

stdout:

```text
empty and malformed/unsupported/default/static preflight passed without effects
ready coordinator serialized lifecycle passed: heads=73 small=73 flow=257 settings=1 final=68 reads=74 bytes=29903
typed descriptor/connection/close/signal/process rejections passed: 67
rollback/equality-expiry and callback-error identity/order boundaries passed
```

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py", line 413, in <module>
    check_clock_handoff()
    ~~~~~~~~~~~~~~~~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py", line 402, in check_clock_handoff
    expect_failure(lambda: coordinator.run(('ready_buffered',), run_identity='ready_0', now=1, units_per_second=1,
    ~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                           clock=clock, child_factory=factory), 'pre-open clock rollback', message='monotonic time moved backwards')
                                           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py", line 259, in expect_failure
    raise RuntimeError(name + ' silently succeeded')
RuntimeError: pre-open clock rollback silently succeeded
```

### attempt-3

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py
```

Exit: `0`.

stdout:

```text
empty and malformed/unsupported/default/static preflight passed without effects
ready coordinator serialized lifecycle passed: heads=73 small=73 flow=257 settings=1 final=68 reads=74 bytes=29903
typed descriptor/connection/close/signal/process rejections passed: 67
rollback/equality-expiry and callback-error identity/order boundaries passed
pre-open clock observation retained across adapter handoff
post validators, private baseline, duplicate/observation boundary and sealed returned facts passed
```

stderr: empty.

### attempt-4

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py
```

Exit: `0`.

stdout:

```text
empty and malformed/unsupported/default/static preflight passed without effects
ready coordinator serialized lifecycle passed: heads=73 small=73 flow=257 settings=1 final=68 reads=74 bytes=29903
typed descriptor/connection/close/signal/process rejections passed: 67
rollback/equality-expiry and callback-error identity/order boundaries passed
pre-open clock observation retained across adapter handoff
selection frozen; ready whole clipping, inherited case grace and checked ready overflow passed
post validators, private baseline, duplicate/observation boundary and sealed returned facts passed
```

stderr: empty.

### final-test_coordinator-normal.pre-self-review

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py
```

Exit: `0`.

stdout:

```text
empty and malformed/unsupported/default/static preflight passed without effects
ready coordinator serialized lifecycle passed: heads=73 small=73 flow=257 settings=1 final=68 reads=74 bytes=29903
typed descriptor/connection/close/signal/process rejections passed: 67
rollback/equality-expiry and callback-error identity/order boundaries passed
pre-open clock observation retained across adapter handoff
non-dict hook returns and every pre-start clock handoff reject before later effects
selection frozen; ready whole clipping, inherited case grace and checked ready overflow passed
post validators, private baseline, duplicate/observation boundary and sealed returned facts passed
```

stderr: empty.

### final-test_coordinator-optimized.pre-self-review

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py
```

Exit: `0`.

stdout:

```text
empty and malformed/unsupported/default/static preflight passed without effects
ready coordinator serialized lifecycle passed: heads=73 small=73 flow=257 settings=1 final=68 reads=74 bytes=29903
typed descriptor/connection/close/signal/process rejections passed: 67
rollback/equality-expiry and callback-error identity/order boundaries passed
pre-open clock observation retained across adapter handoff
non-dict hook returns and every pre-start clock handoff reject before later effects
selection frozen; ready whole clipping, inherited case grace and checked ready overflow passed
post validators, private baseline, duplicate/observation boundary and sealed returned facts passed
```

stderr: empty.

### final-test_imports-normal.pre-self-review

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `0`.

stdout:

```text
AST and inert import checks passed
```

stderr: empty.

### final-test_imports-optimized.pre-self-review

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `0`.

stdout:

```text
AST and inert import checks passed
```

stderr: empty.

### final-audit.pre-self-review

```sh
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import ast
import difflib
import hashlib
import json

if __name__ == '__main__':
    root = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    evidence = root / 'evidence/coordinator-a'
    before = json.loads((evidence / 'before-map.json').read_text())
    published = json.loads(Path('docs/implement-2-2-0/evidence/m2_h2_combined_shutdown/manifest.json').read_text())['current_source_files']
    if before != published or len(before) != 35:
        raise RuntimeError('accepted starting map changed')
    immutable = json.loads((evidence / 'immutable-inputs.json').read_text())
    for item in immutable['identities']:
        data = Path(item['path']).read_bytes()
        if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
            raise RuntimeError('immutable input changed: ' + item['path'])
    rows = immutable['codec_files']
    packages = Path('/tmp/uwz-h2-client-tooling/packages')
    for name, digest in rows:
        if hashlib.sha256((packages / name).read_bytes()).hexdigest() != digest:
            raise RuntimeError('codec input changed: ' + name)
    present = {str(path.relative_to(packages)) for path in packages.rglob('*') if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc'}
    digest = hashlib.sha256(json.dumps(rows).encode()).hexdigest()
    if len(rows) != 42 or present != {row[0] for row in rows} or digest != '0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473':
        raise RuntimeError('ordered codec set or aggregate differs')
    interpreter = Path('/home/codespace/.python/current/bin/python3')
    identity = dict(path=str(interpreter), resolved=str(interpreter.resolve()), bytes=len(interpreter.read_bytes()), sha256=hashlib.sha256(interpreter.read_bytes()).hexdigest())
    if identity['sha256'] != '4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601':
        raise RuntimeError('pinned interpreter changed')
    (evidence / 'python-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    history = json.loads((evidence / 'before-history.json').read_text())
    for name, expected in history.items():
        if hashlib.sha256((root / name).read_bytes()).hexdigest() != expected:
            raise RuntimeError('prior evidence changed: ' + name)
    final, depths, differences = {}, {}, []
    (evidence / 'final-source').mkdir(exist_ok=True)
    for path in sorted(root.glob('*.py')):
        data = path.read_bytes()
        final[path.name] = hashlib.sha256(data).hexdigest()
        (evidence / 'final-source' / path.name).write_bytes(data)
        old = (evidence / 'before-source' / path.name).read_text() if path.name in before else ''
        differences.extend(difflib.unified_diff(old.splitlines(True), data.decode().splitlines(True), fromfile='before/' + path.name, tofile='after/' + path.name))
        tree = ast.parse(data, filename=path.name)
        if any(isinstance(node, (ast.ClassDef, ast.Assert)) for node in ast.walk(tree)):
            raise RuntimeError('authored class/assert: ' + path.name)
        guards = [node for node in tree.body if isinstance(node, ast.If) and ast.unparse(node.test) == "__name__ == '__main__'"]
        if len(guards) != 1:
            raise RuntimeError('main guard count differs: ' + path.name)
        maximum, pending = 0, [(tree, 0)]
        while pending:
            node, level = pending.pop()
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                level = 0
            if isinstance(node, (ast.If, ast.For, ast.While, ast.With, ast.Try)):
                level += 1
                maximum = max(maximum, level)
            for child in ast.iter_child_nodes(node):
                child_level = level - 1 if isinstance(node, ast.If) and child in node.orelse and isinstance(child, ast.If) else level
                pending.append((child, child_level))
        depths[path.name] = maximum
    changed = sorted(name for name in before if final.get(name) != before[name])
    added = sorted(final.keys() - before.keys())
    if changed != ['test_imports.py'] or added != ['coordinator.py', 'test_coordinator.py'] or len(final) != 37:
        raise RuntimeError('source ownership differs')
    if max(depths.values()) > 3:
        raise RuntimeError('control depth exceeds3: ' + repr(depths))
    commands = []
    for receipt in sorted(evidence.glob('final-test*.exit')):
        label = receipt.stem
        if receipt.read_text() != '0\n' or (evidence / (label + '.stderr')).read_bytes():
            raise RuntimeError('final command failed: ' + label)
        commands.append(dict(command=(evidence / (label + '.command')).read_text(), exit=0, stdout=str(evidence / (label + '.stdout')), stderr=str(evidence / (label + '.stderr'))))
    if len(commands) != 4:
        raise RuntimeError('final command inventory differs')
    for script in ('test_coordinator', 'test_imports'):
        if (evidence / ('final-' + script + '-normal.stdout')).read_bytes() != (evidence / ('final-' + script + '-optimized.stdout')).read_bytes():
            raise RuntimeError('normal/O raw output differs')
    unique = {str(Path(item['path']).resolve()) for item in immutable['identities']}
    if len(immutable['identities']) != 118 or len(unique) != 113:
        raise RuntimeError('immutable row inventory differs')
    snapshot = dict(base='322784dea07fd7693b8dba57969636e3e6ed3639', current_source_files=final, added=added, changed=changed,
                    unchanged=sorted(name for name in before if name not in changed), removed=sorted(before.keys() - final.keys()),
                    control_depth=depths, immutable_file_rows=118, immutable_unique_files=113, codec_files=42, codec_digest=digest,
                    preserved_history_files=len(history), commands=commands)
    (evidence / 'snapshot.json').write_text(json.dumps(snapshot, indent=2) + '\n')
    (evidence / 'source.diff').write_text(''.join(differences))
    (evidence / 'final-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    print('37 modules: 2 added, 1 inventory-only changed, 34 unchanged; main guards/no authored classes/asserts; maximum depth=%d' % max(depths.values()))
    print('118 identity file rows / 113 unique files plus ordered42-codec aggregate unchanged; pinned Python SHA256 matches')
    print('Prior evidence files preserved: %d' % len(history))
    print('Four final normal/-O coordinator/import commands exit0, empty stderr, identical per-script stdout')
PY
```

Exit: `0`.

stdout:

```text
37 modules: 2 added, 1 inventory-only changed, 34 unchanged; main guards/no authored classes/asserts; maximum depth=3
118 identity file rows / 113 unique files plus ordered42-codec aggregate unchanged; pinned Python SHA256 matches
Prior evidence files preserved: 3962
Four final normal/-O coordinator/import commands exit0, empty stderr, identical per-script stdout
```

stderr: empty.

### graph-update.pre-self-review

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .
```

Exit: `0`.

stdout:

```text
Re-extracting code files in . (no LLM needed)...
[graphify watch] 375 file(s) not classified (no supported extension or shebang), skipped: .dockerignore, .git, .gitattributes, .gitignore, .gitmodules, Dockerfile (+369 more)
  AST cache: 685/728 files served from cache (94%); 43 to extract
  warning: parallel extraction unavailable ([Errno 1] Operation not permitted); falling back to sequential.
  AST extraction: 43/43 uncached files (100%)
[graphify watch] No code-graph topology changes detected; outputs left untouched.
Code graph updated. For doc/paper/image changes run /graphify --update in your AI assistant.
Tip: set GEMINI_API_KEY or GOOGLE_API_KEY to use Gemini for semantic extraction.
```

stderr:

```text
  warning: 25 code file(s) yielded no symbols (0.12 MB) — a data file, or source this extractor models no symbols for: docs/implement-2-2-0/evidence/m1_static_sidecars/focused_launcher.py, docs/implement-2-2-0/evidence/m1_static_sidecars/stat_name_probe.zig, docs/implement-2-2-0/evidence/m1_woff2/focused_launcher.py, src/c.h, src/c_api.zig (+20 more)
```

### final-test_coordinator-normal

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py
```

Exit: `0`.

stdout:

```text
empty and malformed/unsupported/default/static preflight passed without effects
ready coordinator serialized lifecycle passed: heads=73 small=73 flow=257 settings=1 final=68 reads=74 bytes=29903
typed descriptor/connection/close/signal/process rejections passed: 67
rollback/equality-expiry and callback-error identity/order boundaries passed
pre-open clock observation retained across adapter handoff
non-dict hook returns and every pre-start clock handoff reject before later effects
selection frozen; ready whole clipping, inherited case grace and checked ready overflow passed
post validators, private baseline, duplicate/observation boundary and sealed returned facts passed
```

stderr: empty.

### final-test_coordinator-optimized

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_coordinator.py
```

Exit: `0`.

stdout:

```text
empty and malformed/unsupported/default/static preflight passed without effects
ready coordinator serialized lifecycle passed: heads=73 small=73 flow=257 settings=1 final=68 reads=74 bytes=29903
typed descriptor/connection/close/signal/process rejections passed: 67
rollback/equality-expiry and callback-error identity/order boundaries passed
pre-open clock observation retained across adapter handoff
non-dict hook returns and every pre-start clock handoff reject before later effects
selection frozen; ready whole clipping, inherited case grace and checked ready overflow passed
post validators, private baseline, duplicate/observation boundary and sealed returned facts passed
```

stderr: empty.

### final-test_imports-normal

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `0`.

stdout:

```text
AST and inert import checks passed
```

stderr: empty.

### final-test_imports-optimized

```sh
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `0`.

stdout:

```text
AST and inert import checks passed
```

stderr: empty.

### final-audit

```sh
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import ast
import difflib
import hashlib
import json

if __name__ == '__main__':
    root = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    evidence = root / 'evidence/coordinator-a'
    before = json.loads((evidence / 'before-map.json').read_text())
    published = json.loads(Path('docs/implement-2-2-0/evidence/m2_h2_combined_shutdown/manifest.json').read_text())['current_source_files']
    if before != published or len(before) != 35:
        raise RuntimeError('accepted starting map changed')
    immutable = json.loads((evidence / 'immutable-inputs.json').read_text())
    for item in immutable['identities']:
        data = Path(item['path']).read_bytes()
        if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
            raise RuntimeError('immutable input changed: ' + item['path'])
    rows = immutable['codec_files']
    packages = Path('/tmp/uwz-h2-client-tooling/packages')
    for name, digest in rows:
        if hashlib.sha256((packages / name).read_bytes()).hexdigest() != digest:
            raise RuntimeError('codec input changed: ' + name)
    present = {str(path.relative_to(packages)) for path in packages.rglob('*') if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc'}
    digest = hashlib.sha256(json.dumps(rows).encode()).hexdigest()
    if len(rows) != 42 or present != {row[0] for row in rows} or digest != '0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473':
        raise RuntimeError('ordered codec set or aggregate differs')
    interpreter = Path('/home/codespace/.python/current/bin/python3')
    identity = dict(path=str(interpreter), resolved=str(interpreter.resolve()), bytes=len(interpreter.read_bytes()), sha256=hashlib.sha256(interpreter.read_bytes()).hexdigest())
    if identity['sha256'] != '4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601':
        raise RuntimeError('pinned interpreter changed')
    (evidence / 'python-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    history = json.loads((evidence / 'before-history.json').read_text())
    for name, expected in history.items():
        if hashlib.sha256((root / name).read_bytes()).hexdigest() != expected:
            raise RuntimeError('prior evidence changed: ' + name)
    final, depths, differences = {}, {}, []
    (evidence / 'final-source').mkdir(exist_ok=True)
    for path in sorted(root.glob('*.py')):
        data = path.read_bytes()
        final[path.name] = hashlib.sha256(data).hexdigest()
        (evidence / 'final-source' / path.name).write_bytes(data)
        old = (evidence / 'before-source' / path.name).read_text() if path.name in before else ''
        differences.extend(difflib.unified_diff(old.splitlines(True), data.decode().splitlines(True), fromfile='before/' + path.name, tofile='after/' + path.name))
        tree = ast.parse(data, filename=path.name)
        if any(isinstance(node, (ast.ClassDef, ast.Assert)) for node in ast.walk(tree)):
            raise RuntimeError('authored class/assert: ' + path.name)
        guards = [node for node in tree.body if isinstance(node, ast.If) and ast.unparse(node.test) == "__name__ == '__main__'"]
        if len(guards) != 1:
            raise RuntimeError('main guard count differs: ' + path.name)
        maximum, pending = 0, [(tree, 0)]
        while pending:
            node, level = pending.pop()
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                level = 0
            if isinstance(node, (ast.If, ast.For, ast.While, ast.With, ast.Try)):
                level += 1
                maximum = max(maximum, level)
            for child in ast.iter_child_nodes(node):
                child_level = level - 1 if isinstance(node, ast.If) and child in node.orelse and isinstance(child, ast.If) else level
                pending.append((child, child_level))
        depths[path.name] = maximum
    changed = sorted(name for name in before if final.get(name) != before[name])
    added = sorted(final.keys() - before.keys())
    if changed != ['test_imports.py'] or added != ['coordinator.py', 'test_coordinator.py'] or len(final) != 37:
        raise RuntimeError('source ownership differs')
    if max(depths.values()) > 3:
        raise RuntimeError('control depth exceeds3: ' + repr(depths))
    commands = []
    for receipt in sorted(evidence.glob('final-test*.exit')):
        if '.pre-self-review' in receipt.name:
            continue
        label = receipt.stem
        if receipt.read_text() != '0\n' or (evidence / (label + '.stderr')).read_bytes():
            raise RuntimeError('final command failed: ' + label)
        commands.append(dict(command=(evidence / (label + '.command')).read_text(), exit=0, stdout=str(evidence / (label + '.stdout')), stderr=str(evidence / (label + '.stderr'))))
    if len(commands) != 4:
        raise RuntimeError('final command inventory differs')
    for script in ('test_coordinator', 'test_imports'):
        if (evidence / ('final-' + script + '-normal.stdout')).read_bytes() != (evidence / ('final-' + script + '-optimized.stdout')).read_bytes():
            raise RuntimeError('normal/O raw output differs')
    unique = {str(Path(item['path']).resolve()) for item in immutable['identities']}
    if len(immutable['identities']) != 118 or len(unique) != 113:
        raise RuntimeError('immutable row inventory differs')
    snapshot = dict(base='322784dea07fd7693b8dba57969636e3e6ed3639', current_source_files=final, added=added, changed=changed,
                    unchanged=sorted(name for name in before if name not in changed), removed=sorted(before.keys() - final.keys()),
                    control_depth=depths, immutable_file_rows=118, immutable_unique_files=113, codec_files=42, codec_digest=digest,
                    preserved_history_files=len(history), commands=commands)
    (evidence / 'snapshot.json').write_text(json.dumps(snapshot, indent=2) + '\n')
    (evidence / 'source.diff').write_text(''.join(differences))
    (evidence / 'final-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    print('37 modules: 2 added, 1 inventory-only changed, 34 unchanged; main guards/no authored classes/asserts; maximum depth=%d' % max(depths.values()))
    print('118 identity file rows / 113 unique files plus ordered42-codec aggregate unchanged; pinned Python SHA256 matches')
    print('Prior evidence files preserved: %d' % len(history))
    print('Four final normal/-O coordinator/import commands exit0, empty stderr, identical per-script stdout')
PY
```

Exit: `0`.

stdout:

```text
37 modules: 2 added, 1 inventory-only changed, 34 unchanged; main guards/no authored classes/asserts; maximum depth=3
118 identity file rows / 113 unique files plus ordered42-codec aggregate unchanged; pinned Python SHA256 matches
Prior evidence files preserved: 3962
Four final normal/-O coordinator/import commands exit0, empty stderr, identical per-script stdout
```

stderr: empty.

### graph-update

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .
```

Exit: `0`.

stdout:

```text
Re-extracting code files in . (no LLM needed)...
[graphify watch] 375 file(s) not classified (no supported extension or shebang), skipped: .dockerignore, .git, .gitattributes, .gitignore, .gitmodules, Dockerfile (+369 more)
[graphify watch] No relevant changes; graphify-out left untouched.
Code graph updated. For doc/paper/image changes run /graphify --update in your AI assistant.
Tip: set GEMINI_API_KEY or GOOGLE_API_KEY to use Gemini for semantic extraction.
```

stderr: empty.
