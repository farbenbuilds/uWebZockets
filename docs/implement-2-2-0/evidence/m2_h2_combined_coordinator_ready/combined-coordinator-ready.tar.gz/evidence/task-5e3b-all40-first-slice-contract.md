# Concrete first coordinator slice

Architect refinement, no code/tests/operations run. Implement explicit empty
and one complete ('ready_buffered',) pure child lifecycle. Other valid
selections, including omitted default all40, fail explicitly before effects
at this checkpoint. Parent default/subset/aggregate acceptance stays required.

## Identity

run_identity is exact str,1..32 ASCII[A-Za-z0-9_], matching current immutable
fixture log_bounds.zig9..12/profile.zig239. Coordinator generates no randomness.
Old output-runtime process_setup.py accepts[A-Za-z0-9_-]{1,64}; that grammar is
incompatible and must not be reused. Logical child identity is
(run_identity,child_index), zero-based ordinal from catalogue.child_plan;
this slice has(run_identity,0). It is not native PID/start/listener identity
or native freshness/ownership proof. Supplied fresh_applicationTrue is synthetic.

## Entry/preflight

    run(selection=catalogue.CASES, *, run_identity, now,
        units_per_second, clock, child_factory)

Before callbacks: validate/freeze selection with existing catalogue/cases;
validate identity, exact integer now>=0/units_per_second>0 (reject bool),
callable clock/factory; check required arithmetic with catalogue u64 helpers;
reject not-yet-supported nonempty selections; return explicit empty without
clock/factory effects. ExplicitNone is malformed, never default. Omitted
selection remains catalogue.CASES and is unsupported before effects until the
later default implementation is released.

## Exact factory/descriptor

    child_factory(run_identity, child_index, child_selection,
                  ready_deadline, whole_deadline)

Exact dict keys: identity,ready,fresh_application,connect,close,signal,process,post.
identity is exact matching tuple; ready/fresh_application are exactlyTrue;
remaining five values are callable. Every field is exercised in this slice.

connect(case,connection_index,case_deadline,whole_deadline) returns exact keys
protocol,send,receive,now,owned,tls,alpn. Existing replacement-fact semantics:
nonnull fresh already-initiated helper-shaped protocol, callable send/receive,
exact integer monotonic now, ownedTrue,TLSv1.3,h2. Connection index1. These are
supplied synthetic facts, not socket/TLS execution.

close(context,grace_deadline) returns exactly
{method:close,client_closed:True,close:normal}.

signal(context,grace_deadline) returns exactly
{signal:SIGTERM,owned_identity:True,watcher_installed:True,client_open:False}.

process(context,grace_deadline) returns exactly
{exit_code:0,reaped:True,forced:False,run_ok:True,deinit_ok:True,key_removed:True}.
exit_code is exact int; the others exact bool.

post(context,grace_deadline) returns exactly records,metrics,outputs,binding;
values satisfy unchanged model post/pre-post validators.

Do not add release,disconnect/replacement,active-termination/output factories,
handler injection,native PID records,cleanup frameworks or unused precondition
callbacks. Later fields need concrete later work.

## Deadlines

Whole = add_u64(now,mul_u64(900,units_per_second)). After preflight read
ready_start from clock, require monotonic and strictly before whole expiry;
ready=min(whole,add_u64(ready_start,mul_u64(15,units_per_second))). Check again
after factory; equality with deadline is expired.

Factory supplies a prepared pure child/readiness fact, not hidden native
certificate/build/process setup. Old runtime starts readiness after process
setup; integrating that setup is a separate release and must retain distinction.

After readiness obtain monotonic case_start and use cases.deadlines for
ready_buffered before connect. Connection setup/startup,case actions,final68
and teardown consume the same case/whole pair. Check returned connection now
and caller clock before open_case. Never restart bounds.

After final collection/private baseline use shutdown_cases.grace(context,units)
once; within_grace after close/signal/process/post. Grace<=15 supplied seconds
clipped to original case/whole; do not recompute between hooks.

## Complete lifecycle

1. Fresh descriptor and one connection.
2. adapter.open_case selected_before=(); initial SETTINGS/ACK through observe.
3. Actual adapter.run_case(context,receive). OrdinaryNone keeps input context;
   normalize only non-None results. Later replacement also switches receiver.
4. final_collection once, ordinaryNone, consume final_observations.
5. Private bounded copy of parsed records/metrics. shutdown_cases.outputs
   obtains copied outputs/binding; ready uses validated unselected defaults,
   not observed output-case execution. Hooks receive no baseline aliases.
6. Set ordinary observation boundary; obtain clipped grace; normal close;
   then signal with client_openFalse.
7. Reuse shutdown_cases.validate_signal(signal,False). No named close validator
   exists; keep the exact idle normal-close schema check local.
8. Reuse shutdown_cases.post_deinit(context,descriptor,deadline,private_before,
   selection): process->post, deadline/schema checks, validate_process, exact
   post fields, model pre/post/metrics/output comparison and protected capture
   publication. No shutdown_cases.idle (would add health/collection/selection)
   or output_stage.signal (active-only). No shutdown_idle case earned.
9. Result after comparison; no later hook. Copy bounded teardown result graphs
   so hook-owned dictionaries cannot rewrite returned evidence.

## Exact result

Top-level keys: run_identity,selection,children,totals,scope. selection is frozen
tuple; children tuple length0/1; scope='pure_client_synthetic_peer'.

Child keys: identity,selection,counts,deadlines,final_observations,teardown.
deadlines keys ready,case,whole,grace. final_observations keys
records,metrics,outputs,binding with protected validated facts. teardown keys
close,signal,process,post with bounded copied validated synthetic facts.

counts/totals exact keys:
heads,small,request_flow,connections,settings,informationals,incoming_resets,
final_collections,receive_bytes,receive_calls. All checked nonnegative integers.

Ready success: heads73,small73,request_flow257,connections1,settings1,
informationals0,incoming_resets0,final_collections1. Receive bytes/calls are
actual canonical counters within inherited caps. SETTINGS actual client
accounting, informational/reset actual observed canonical state, not limits.

Snapshot cumulative case once after final: heads already includes68, small
is pre-final small+final_registered. Do not add a separate final snapshot.
Empty returns zero counters/no children/no fabricated final or teardown facts.

## Acceptance/claims

Independent serialized proof: actual ready_buffered+final68; exact257-byte echo/
hash;67 unselected default records; buffered middleware73; slots inactive;
normal close->SIGTERM->successful supplied process/reap->protected post check.

Controls: empty/rejected selections before effects; malformed descriptor/
connection/hooks; timestamp rollback/exact expiry; failed close prevents signal;
failed signal prevents process; incorrect post; duplicate finalization; public
capture mutation cannot rewrite private baseline. Every failure propagates.

Actual normal/O, inert imports/main guards, true RED/GREEN scope and unchanged
inputs required. Default/all40,multiple-case, idle child, replacement,selected
outputs,parent aggregates and every runtime/native/project gate remain open.
