# Focused combined coordinator completion plan

Read-only architect task. All40 concrete source schedule IDs were reviewed and
saved at pushed commit322784dea07fd7693b8dba57969636e3e6ed3639. The complete
35-module map is docs/implement-2-2-0/evidence/m2_h2_combined_shutdown/manifest.json;
task-5e3b6d-root-commit-audit.json verifies HEAD/fork and committed bytes. Parent
all40/default/empty/subset/aggregate orchestration and native acceptance are
not implemented/proved by that source coverage.

This is completion planning against the existing accepted architecture, not a
new feature scope or a repository architecture scan. Requirements are
task-5e3b-cases-pending-brief.md, its explicit task-5e3b-release-addendum.md,
task-5e-combined-architecture.md, task-5e-barrier-source-handoff.md and
task-5e3b-aggregate-acceptance-notes.md. Immutable catalogue/model and actual
canonical core APIs remain authority. Do not redo the whole architecture,
interview about settled requirements, invent another model or weaken any count,
bound, ownership rule or gate. Surface an actual contradiction if found.

Inspect the current used interfaces in the combined-cases source at
.uwz-work/evidence/h2-streaming/integration-owned/combined-cases, especially
adapter/cases and lifecycle/shutdown handoffs. The immutable model is
/tmp/uwz-task5e1-contract-v3; core /tmp/uwz-task5e3a-snapshot-v9/source;
codecs /tmp/uwz-h2-client-tooling/packages. The latest B6d report and fix2
appendix document the earned API; do not read its large raw appendices unless
you need a concrete receipt. Old family live runners are read-only references,
not released entrypoints. No source or public file changes.

Plan the smallest actual coordinator and serialized acceptance proof that:

- Calls all40 existing concrete handlers through the canonical bound
  wire/codec/parser/both ledgers/stage; no generic success handler, catalogue
  summation alone, checkpoint union or seeded prior state substitutes for
  actual default execution. Supplied synthetic peer app/process facts remain
  explicitly synthetic even when client dispatch is actually exercised.
- Preserves idle-first fresh separate child state,39 main IDs in caller
  order,40 main connections including disconnect replacement,41 total,
  exact aggregate budgets/counters from the notes and immutable model.
- Implements explicit empty with no effects, idle-only, arbitrary valid
  caller-ordered subsets, malformed/unknown/duplicate/shutdown-order rejection
  before effects, subsets without active shutdown and subsets ending with
  large outstanding debt. Final68 is once and within inherited caps/deadlines;
  no unearned debt zero, duplicate final collection or fresh final deadline.
- Preserves actual parsed final_observations, latest output observations and
  binding across fresh contexts. Ordinary final capture is immediate/None-
  compatible; shutdown baseline stays private through teardown hooks and is
  published afterward. Future ordinary teardown comparison must also protect
  its before baseline from hooks. Do not use model recipes as observed facts.
- Retains bounded rolling counters/digests/metadata, exact generated large
  payloads/hashes and independent serialized proof. No per-frame/read histories
  or whole upload/output buffers. Actual settings/informational/reset direction
  and counts must be observed/accounted rather than assumed from limits.

Return assumptions, ownership/file boundaries, exact used caller-owned factory/
hook/return contracts, small ordered implementation/proof slices with concrete
acceptance criteria and focused checks, reuse opportunities in existing pure
test peers, risks and unresolved source API gaps. Include a deletion test for
the coordinator seam and which domain specialist should own each slice. Keep
every original parent requirement and the later broad combined-client review.
Name what must remain unclaimed after each checkpoint.

You are read-only and not alone. No edits/Git/service writes, other agents or
external model CLI. No native/build/server/socket/SSLContext/TLS-close/real-
clock/process ownership/transfer/fault/cancel/scheduling/descriptor/kernel/
race/panic/leak experiments or old entrypoint execution. No tests are needed
to plan from the fixed contracts; use existing source/evidence. Before new
codebase queries/searches/source reads use exactly:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650

Read applicable project/role/narrow skill instructions. Return your complete
focused plan as the final response. Root will save it at
task-5e3b-all40-plan-report.md and release concrete work after assessing it.
Do not create tasks/plan.md or alter the existing plan workspace/ledger.
