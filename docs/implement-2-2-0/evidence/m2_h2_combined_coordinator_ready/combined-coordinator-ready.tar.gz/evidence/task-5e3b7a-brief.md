# Task5e3b7a: first complete coordinator lifecycle

Released after all40 source handlers were reviewed and pushed at
322784dea07fd7693b8dba57969636e3e6ed3639. Accepted35-module source map is
docs/implement-2-2-0/evidence/m2_h2_combined_shutdown/manifest.json and
task-5e3b6d-root-commit-audit.json binds saved/pushed bytes. Parent aggregate
acceptance and every native/adoption/full-milestone requirement remain open.

Read task-5e3b-all40-first-slice-contract.md first: it is the exact interface,
identity, fact schemas, arithmetic, ordering, results and acceptance contract.
Also read task-5e3b-all40-plan-report.md and original cases/release/accepted
architecture/barrier/aggregate-acceptance notes. The first contract explicitly
allows only empty and ('ready_buffered',); other valid selections/default must
fail before effects at this checkpoint. Do not alter existing40-handler
coverage, caller ordering or parent requirements to disguise this boundary.

Own new coordinator.py and test_coordinator.py in the existing combined-cases
directory, minimal actual-used test_imports.py inventory changes, evidence/
coordinator-a and task-5e3b7a-report.md. Do not edit other35 source modules,
family tests, immutable model/core/fixture/helper/codecs, product/dependencies/
capacities/deadlines. A specific existing API gap goes to Root before a shared
edit; continue independent work. Root owns review/publication/Git. You are
not alone; preserve others' edits and all prior raw/source evidence. No agents
or external model CLI, public edits, commits/refs/pushes.

Actual constants and APIs are in the concrete contract; never substitute a
generic successful handler or direct model-generated completion. The new test
must invoke coordinator.run, whose actual path invokes adapter.run_case and
canonical startup/observe/final_collection. Existing test check() helpers run
their own context and cannot substitute for coordinator execution. Reuse pure
decoder/peer primitives where actually suitable; no broad peer extraction.
Preserve exact ready-buffered routes/metadata/payload/hash from its real handler
and existing tests, rather than guessing them from the case name.

The result and teardown evidence must be owned bounded copies of actual parsed/
validated facts, not model recipes or mutable hook-owned dictionaries. Preserve
ordinary None return/immediate capture. Private before baseline includes all
records/metrics/output/binding; no hook receives its aliases. Existing
shutdown_cases.post_deinit stores context.shutdown_observations with keys
before,after,process,deadline. If reusing that handoff, seal only actual facts
that remain valid after later hooks; a post hook may retain/mutate an earlier
process dictionary. Do not label mutated unchecked data as validated. Cover
returned-evidence independence and public-capture mutation in focused tests,
using actual model validators and truthful failure scope.

Implement exact callback/static schemas and all no-effect preflight checks.
Child identity tuple item types are exact too (bool cannot substitute index0).
All callback times are caller-supplied monotonic integers. Ready limit is for
the prepared pure child, not hidden certificate/build/process setup. Case
deadline begins before connect and remains through final68/teardown. No extra
health/collection, output GET, fresh final/grace deadline or signal-stage call
for this ordinary case. No shutdown_idle ID is earned by normal main teardown.

Run identity follows current fixture ASCII grammar1..32 alnum/underscore;
the old runtime's1..64/hyphen grammar is incompatible. Do not import or execute
old live/runtime constructors/close helpers. Logical identity/freshness/owned/
TLS facts are supplied synthetic inputs, never native ownership evidence.

Before implementation preserve accepted35-module map and actual initial test/
RED scope plus every intermediate outcome. Prove actual serialized five case
requests plus67 statuses/metrics,257-byte echo/hash, startup SETTINGS, counts,
finite observation order, inherited parser/ledgers/debts/deadlines and complete
normal close->SIGTERM->process/reap fact->protected post comparison. Retain
bounded counters/digests/cursors, not request/frame/read histories or whole
large bodies. Bounded small responses/257 echo are allowed.

Target negatives at exact malformed/unsupported selections and identities
before callbacks; descriptor/connection/fact schemas and bool substitutions;
rollback/equality-expiry/overflow; failed close preventing signal; failed signal
preventing process; duplicate finalization/post-boundary observations; bad post
facts and alias mutation. Pure sensitivity cases are not native fault probes.
Reject failure without a successful result; never swallow callback errors.

After last edits run relevant test_coordinator.py and test_imports.py in pinned
Python -B -S normal/-O, retaining exact commands/stdout/stderr/exits. Do not
rerun all preceding suites without a concrete concern/change. Actual all-module
guards/AST and silent/inert empty/foreign argv imports must include all37 source
modules. No classes/custom exceptions/assert proof/hidden mutable globals/dead
code/deep nesting or speculative wrapper/cleanup framework. Each authored
executable helper, including temporary recorders, has its guard/import proof.

Pinned Python /home/codespace/.python/current/bin/python3, SHA256
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
Use existing immutable model /tmp/uwz-task5e1-contract-v3,26-module v9 core
/tmp/uwz-task5e3a-snapshot-v9/source,42codecs /tmp/uwz-h2-client-tooling/packages,
and helper integration-client/h2_client.py from the release addendum. B6d fix2
immutable-inputs.json supplies119retained identity entries/113unique files plus
ordered codec aggregate (114unique entries). Exact default-json codec SHA256
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.

No native/build/server/socket/SSLContext/TLS-close/real-clock/process ownership/
transfer/descriptor/kernel/fault/cancel/scheduling/race/panic/leak experiments,
old entrypoints, installs/network fetches or other agents. Pure public codecs
and supplied facts only; broad role matrices do not release forbidden gates.
Before new codebase query/search/source reads use exact graphify prefix from
the release addendum. Provided paths are located. Read project/role/narrow
skills without adding unrelated tooling or an approval interview.

Full report: actual APIs/files/commands/raw history/new-behavior RED/GREEN scope,
current source/input identities/snapshot/self-review and remaining parent/native
facts. Return only status/report path, one-line checks and concerns. Root reviews
independently, publishes, commits and immediately pushes each saved checkpoint.
