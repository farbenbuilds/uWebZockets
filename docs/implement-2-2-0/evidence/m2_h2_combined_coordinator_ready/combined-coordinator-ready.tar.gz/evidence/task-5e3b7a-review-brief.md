# Task7a independent coordinator source review

Review spec compliance and task quality for this first coordinator slice.
Requirements: task-5e3b7a-brief.md and task-5e3b-all40-first-slice-contract.md,
with accepted parent plan/architecture/aggregate notes. Full claims:
task-5e3b7a-report.md. Root independent raw/source/input/history audit:
task-5e3b7a-root-final-audit.json.

Full diff task-5e3b7a-review-source.diff,41022 bytes, SHA256
bd3c802dd2d3d1f7523cfba96e688343f8a922bea0f31dc27b911af15bce4bbc.
Base322784dea07fd7693b8dba57969636e3e6ed3639/35 archived modules; current37
ignored modules, no task commit. Two new modules plus test_imports inventory
only;34 prior modules unchanged, none removed.

Read the diff once, tests first/context10. Do not separately reread changed
files unless a needed function is cut off mid-hunk; name that gap. Inspect
unchanged code only for a concrete named risk, one focused check per risk.
Do not crawl or rerun Git. Treat reports/Root audit as claims to evaluate.

Binding contract excerpts:

- "Implement explicit empty and one complete ('ready_buffered',) pure child
  lifecycle. Other valid selections, including omitted default all40, fail
  explicitly before effects at this checkpoint. Parent default/subset/aggregate
  acceptance stays required."
- "No handler injection"; coordinator must invoke the existing actual dispatcher
  and canonical startup/observe/final_collection, not a check() helper or
  model-generated completion.
- "Start that case deadline before invoking connect; connection setup/startup,
  concrete actions, final68 and teardown all consume the same remaining
  case/whole time."
- "Privately copy the bounded parsed records and metrics" and copied output/
  binding facts; hooks receive no baseline aliases. Preserve ordinaryNone.
- "Copy these bounded results before returning so retained hook-owned
  dictionaries cannot subsequently rewrite evidence."
- "No output_stage.signal for an ordinary case. Normal teardown does not earn
  shutdown_idle."
- "No native/build/server/socket/SSLContext/TLS-close/real-clock/process
  ownership/transfer/descriptor/kernel/fault/cancel/scheduling/race/panic/leak
  experiments, old entrypoints, installs/network fetches or other agents."

Exact descriptor/connection/hook/result schemas, fixture identity grammar,
logical-child identity, units/arithmetic and finite order are in the first
contract. Review literally. Named cross-cutting risks: pre-effect preflight,
whole/ready/case/grace time and clock handoffs, actual once-only canonical
counts, private baseline through hooks, sealed process/post return ownership,
callback error propagation/order, observation/finalization boundaries, and
truthful supported-selection/synthetic/native claims.

Root read substantive report and actual final stdout/RED. All37live/frozen/
snapshot hashes,35before archive bytes,3962captured prior evidence hashes,
four actual coordinator/import normalO exits0-emptyerr/test-mode multiset and
119retained identities/113unique file paths/42orderedcodecs checked. Actual
clock sequence2,2,2,3,2 RED shows discarded pre-open observation before fix;
initial missing-module RED is separately qualified. Current observed counts:
heads73/small73/flow257/connections1/SETTINGS1/final68/reads74/bytes29903.
Four pre-self-review checks remain historical, not relabeled current.

Do not rerun passed checks absent a concrete unanswered doubt; any focused
check must stay pure/source-only. Apply AGENTS/CODING/code-review-and-quality
and explicitly requested thermo-nuclear structural lens with project overrides.
Graphify before new codebase queries/searches using release's exact prefix;
provided paths located. No edits/index/ref/Git/service writes, agents/external
model CLI or forbidden execution. You are read-only and not alone. Return
SPEC PASS/FAIL and QUALITY APPROVED/NEEDS FIXES, actionable severity/file:line/
failure-scenario findings, strengths and cannot-verify boundaries. Root saves it.
