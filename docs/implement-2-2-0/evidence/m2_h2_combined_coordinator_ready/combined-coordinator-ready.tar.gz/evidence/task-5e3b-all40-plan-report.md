# Focused combined coordinator completion plan

Read-only architect output, recorded by Root. No tests, imports, builds, native
operations or writes were performed by the architect. Complete the existing
client with one coordinator owning selection, sequential child orchestration,
retained observations and aggregate accounting. Keep concrete handlers and the
canonical wire/codec/parser/ledger path unless a focused regression establishes
a specific gap.

## Assumptions and scope

Baseline322784dea07fd7693b8dba57969636e3e6ed3639 has35 modules. Source map is
docs/implement-2-2-0/evidence/m2_h2_combined_shutdown/manifest.json. Root's
commit audit supplies pushed identity; this planning pass did not reproduce it.
Immutable catalogue/model/core/helper/codecs/compiled-only fixture remain
authority; import rather than duplicate their constants or model.

Default is catalogue.CASES. cases.IMPLEMENTED has a different order, including
idle last, and cannot provide default order. Explicit empty stays empty;
explicit None/malformed values cannot silently become default. Preparation
remains pure caller operations and pinned codecs; application/child/TLS-close/
signal/process facts remain synthetic. No vocabulary, ADR, product, dependency,
capacity or native policy change is needed.

Manual deepening scan is inapplicable. Architect read grill-me/grilling to
stress-test settled decisions from source rather than conduct an interview or
delegate, honoring the explicit task scope. Planning's default tasks/plan.md
path is superseded by the root-owned report. Its linked
.agents/references/definition-of-done.md was absent; project conventions and
explicit gates remain binding. The specialist's stale h1spec project-patch
wording does not override AGENTS maintained-fork policy; no local patch.

## Existing interfaces

- cases.select validates catalogue.schedule list/tuple input, preserves order,
  rejects malformed/unknown/duplicate IDs and invalid shutdown order. Call
  before any factory, clock or transport hook.
- catalogue.child_plan yields selected idle first then caller-ordered main;
  empty creates no child.
- cases.deadlines(case,now,whole_deadline,units_per_second) uses checked
  integers: ordinary30s/large180s clipped to whole. Replacement and final
  collection inherit that pair.
- adapter.open_case(case,protocol,send,now,case_deadline,whole_deadline,
  selected_before=(),*,clock) creates fresh parser/ledgers/records/stage,
  binds wire and consumes already-initiated helper-shaped startup. Do not
  initiate twice.
- send spans are bounded; receive returns nonempty bytes<=8192 and integer
  now; clock provides monotonic consistent units. Observe through adapter.
- run_case(context,receive,*,disconnect=None,shutdown=None) returns final
  context for lifecycle/shutdown, None for ordinary. Explicit result-is-None
  normalization preserves old returns.
- Disconnect hooks are exactly close(context),replacement(context). Close
  requires successful ssl_unwrap/TLS shutdown/plain TCP EOF, zero trailing
  bytes, normal close; replacement only after canonical transport completion.
- Replacement supplies exactly protocol/send/receive/now/owned/tls/alpn,
  fresh protocol, ownedTrue/TLSv1.3/h2 and monotonic time. Returned context
  carries replacement receive; use it for later final collection.
- Shutdown hooks: preconditions/signal/termination/process/post/units_per_second;
  idle uses close instead of termination. Preconditions get context; others
  (context,deadline). Existing exact fact schemas unchanged.
- Ordinary final_collection retains parsed context.final_observations and
  returnsNone. Shutdown returns capture privately and publishes only after
  teardown validation. Never collect again to obtain a return value.

Finish ordinary initial SETTINGS/ACK through bound adapter before dispatch;
additional output SETTINGS belong to concrete handlers. Disconnect shares
cumulative case objects only; two protocols/parsers/ledgers/record stores remain
independent. Preserve old debt evidence; never transfer or erase it.

## Proposed interface and ownership

Add coordinator.py in combined-cases, with one proposed entry:

    run(selection=catalogue.CASES, *, run_identity, now,
        units_per_second, clock, child_factory) -> bounded result

Preflight selection/static schemas first. Empty returns zero totals without
clock/factory/connection/hook/collection effects. Nonempty establishes one whole
deadline with checked catalogue arithmetic.

Proposed child_factory(run_identity,child_index,child_selection,ready_deadline,
whole_deadline) returns an explicit fresh child descriptor with identity/fact
provenance, connect(case,connection_index,case_deadline,whole_deadline) returning
replacement-shaped facts, release(context,deadline) for ordinary connections
with normal-close evidence, disconnect close hook, active/idle hooks and
ordinary-main close/signal/process/post teardown hooks under inherited bounds.
Factory supplies dependencies/facts, never a replacement successful-handler
callback. Coordinator must call adapter.run_case. Caller owns real resources;
only synthetic descriptors are exercised now. Later runtime ownership needs
separate review/release. Exact descriptor schemas need Root's concrete release.

Result contains bounded selection/child/case summaries, actual counters/digests,
final captures/output/binding/teardown facts and evidence scope. No historical
context collection, per-frame/read history or whole bodies. Failure stops
dispatch and propagates original error; cleanup cannot turn failure into success.

Ownership: coordinator owns selection/deadlines/progression/handoffs/retention/
aggregation; existing adapter owns HTTP actions/barriers/validation/pairing;
immutable core owns framing/binding/credits/terminal accounting; caller peer/
runtime supplies facts; independent verifier decodes bytes. Root owns shared
edit serialization, review/release, publication and Git.

## State and accounting

Idle and main get distinct fresh application state. Main selected_before has
only actually successful main IDs, never idle or seeded undispatched completion.
Retain latest validated three producer/file observations and relative B binding.
Merge only completed-handler observations. Replacement does not automatically
carry arbitrary parent fields; restore retained child observations on returned
context before later finalization.

Before ordinary teardown hooks, copy bounded observed records/metrics and copied
output/binding into a private baseline; hooks get no aliases. Preserve immediate
ordinary capture/None. Report protected observations after comparison, not hook
substitutes.

Count cumulative case state once, including disconnect; count connection-local
SETTINGS/info/etc once for each transport, capturing old disconnect context in
the close handoff. Small totals are pre-final small plus final registrations
once. Ordinary subset final68 is appended once; active/idle include it already.
Request flow comes from case state once. Incoming resets are separate from
outgoing peer reset. Checked catalogue arithmetic; preserve debt and parser/
ledger identities through final.

trace.WindowUpdated misses valid late closed-stream refunds consumed by raw
accounting. It cannot prove a complete raw refund-frame count. Independent
serialized proof must count raw frames; do not add a second production parser.

Default required totals:

| Quantity | Required |
| --- | --- |
| IDs/children/connections |40/2/41|
| main IDs/connections |39/40|
| heads/small/request flow |802/789/200091899|
| main heads/small; idle heads/small |733/720;69/69|
| client SETTINGS/informationals/incoming resets |46/2/13|
| final collections |2|
| post middleware/attempts/begins/ends/cancels |67/62/61/52/9|
| accepted bytes/buffered middleware |200091500/666|
| failures/end_errors/chunk_errors/invalid_progress/errors |1/1/1/1/0|

Pre-signal cancels8 with held active row; post active/paused0. Whole receive
5288609050/refund400183798 are ceilings. Final allowance is3064352+13*actual
remaining debt: default bound3065184, large-ending subset bound4768262. Preserve
cumulative reads and original deadlines; no final reset.

## Ordered slices

1. Selection and first real ordinary subset: developer/http_protocol, proof by
   verification. coordinator.py plus focused test. Empty/rejections before
   effects, omitted default catalogue order, actual ready_buffered through
   dispatcher and final68, consumed ordinary capture without extra GET. Claim
   only this subset/preflight, not default/native/full lifecycle composition.
2. Fresh contexts/lifecycle composition: developer with http_protocol and
   transport_io. Child progression, release, replacement, output/binding and
   private ordinary teardown baseline. Verify actual caller order/selected-
   before, returned receiver/context, no duplicate/lost disconnect counts,
   real parsed diagnostics and untouched defaults. Include output->ordinary,
   output->disconnect-final, disconnect->ordinary, idle-only, idle+ordinary,
   active-only and nondefault ordering. Claim tested subsets/supplied facts.
3. One default execution: verification with protocol/transport review. Extract
   small reusable bounded pure peer factories serially. Reuse test_shared
   app/late refunds, lifecycle two transports/stale controls, shutdown schemas/
   privacy, final observed diagnostics and family serialization/payload peers.
   Existing check() functions create/run their own context: calling them is
   not coordinator proof. Peer factories cannot bypass dispatch. Replace
   unnecessary histories with bounded cursors/counters/hashes. One default
   run actually invokes40 handlers, idle finishes before main creation,41
   connections serialize actions, no prior seeded completion. Both100000000
   uploads use SHA190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2;
   separate producer/file/body hashes, lengths/range/sentinel/relative binding.
   Claim actual client dispatch against synthetic facts, not native evidence.
4. Independent aggregate/boundaries: verification with protocol/reviewer. A
   bounded independent frame/HPACK oracle compares actual metadata/order/
   payload/counts to coordinator totals:46 actual client SETTINGS, two100
   before DATA,13 incoming resets separate from outgoing, final68 once,
   startup bytes, flush-before-single-observation barriers without retries.
   Cover large final debt, fragmented late refunds, inherited cap/deadline
   exhaustion, duplicate collection, post-signal observation, pause/EOF/resume,
   zero/8192/remainder pressure, reset ordering, missing outputs and aliases of
   record/output/binding baselines. Claim pure serialized default/subset/
   aggregate acceptance only; synthetic negatives are not native probes.
5. Freeze/review/later release: Root/integrator/source-spec-quality reviewer
   and broad final combined-client review, structural lens as appropriate.
   Retain all RED/GREEN/intermediates/raw commands/results/normal-O/identities/
   source maps, actual inert imports/main guards. No classes/custom exceptions/
   assert proof/hidden effects/unbounded histories. Only after approval release
   runtime closure/strict-close/owned-runner preparation, then native two-child
   one-identity exact-input run and real callbacks/post-deinit/cleanup/reap.

## Risks and deletion test

No immutable-core gap currently justified. Ordinary-main teardown is new;
reusing idle's full handler would add an invalid case/collection. Reuse exact
fact validators and ordering only. Capture old disconnect connection counters
in its hook, not duplicated shared case state. Peer extraction is the main
size risk: retain family-specific serialized oracles, not generic model-success.
Expected records can validate/supply synthetic facts, never prove handlers ran.
Wildcard callback diagnostics remain parsed values. Normal close/empty registry
does not mean late debt refunded. A future durable complete raw refund count
needs Root review of that exact instrumentation gap before any core change.

Seam: coordinator.run enforces selection/fresh-child ordering/inherited bounds/
observations/once-only aggregation over explicit dependencies. Deletion should
force these rules into both the pure acceptance caller and owned runtime caller.
If deletion removes only forwarding, the abstraction is unearned.

All explicit project unit/sanitizer/compile/platform/fuzz/package/protocol/
performance/fork/release gates remain mandatory at their released phase.
Source-only work does not run or satisfy native/build gates. HTTP/3/multipart
composition, native combined acceptance, adoption, M2 and2.2.0 remain unclaimed.
