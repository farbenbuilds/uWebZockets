# 8b shared pause/control peer

Status: DONE_WITH_CONCERNS for the assigned pure-codec slice. All current
checks pass. The concerns are retained historical evidence corrections below;
there is no known current implementation blocker or missing interface context.
Root's fresh independent review, publication, commit and immediate push remain
required. This is not all40/coordinator, native, adoption or milestone acceptance.

BASE: `872aa6b451f2cb4dfc20a9e7aadc43a5ef771a4c` (supplied by the brief; no Git
command was run).

## Exact ownership and source

Changed existing source:

- `/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_pause.py`
- SHA256: `53c2836ada78d47879122203597068e82a58a5406c329fd0125f2c4b277144a6`

New current helpers, all under the new directory
`/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/pause-peer/`:

- `capture.py`: explicit opt-in source/command/raw/result recorder.
- `proofs.py`: explicit opt-in direct pure-codec acceptance proofs.
- `audit.py`: explicit opt-in identity/source/history/helper/receipt auditor.

New report: this file. All other new files are retained evidence under that
same `pause-peer` directory. `evidence-inventory.json` lists their exact paths
and SHA256 values, excluding that inventory itself. There are still exactly40
top-level source modules: one changed,39 unchanged. No other module, immutable
handler/model/core, codec, fixture, pin, product, limit or historical file was
edited. Graphify's required AST-only update reported no relevant indexed
changes and left `graphify-out` untouched.

The exact current40 source map is `covered-normal/source.json`, independently
rechecked at `covered-optimized/source.json`. The retained full diff is
`covered-normal/test_pause.diff`. The pre-edit accepted map and all40 original
source texts are under `baseline/`, with `.txt` extensions for frozen sources.

## Context, freeze and immutable inputs

Read the brief, AGENTS.md, CODING_CONVENTION.md, developer and verification role
instructions, accepted all40 peer plan/shared contract/unit2, and aggregate
acceptance notes. Applied the narrow using-agent-skills, incremental
implementation, TDD, interface design, codebase design, debugging and
code-review workflows with project overrides. The initial oversized context
read was truncated; required convention/workflow/architect content was read
in smaller visible reads. No generic missing DoD reference was treated as an
approval requirement. Graphify queries preceded the new codebase questions.

Before changing `test_pause.py`, the Root source-only restorer ran and verified
the pinned inputs in the same shell as `capture.py --freeze`.
`restore-freeze.json` records119 authority entries,118 physical rows,113 unique
resolved files,42 ordered codec files and the interpreter identity. The freeze
compared every current source against the accepted 8a manifest before copying
the40 sources. `baseline/prior_history.json` is a fresh exhaustive SHA256 map
of9,727 existing evidence files, excluding only the new unit directory.
`baseline/immutable-inputs.json` is the unchanged authority copy.

The freeze precedes `red-constructor`, the first acceptance RED. It is not a
post-GREEN reconstruction. Final audits independently re-read all physical
inputs, ordered codecs, sources and9,727 history hashes. No missing temporary
input blocked this slice. Each dependent check shell began with the exact Root
restorer and a unique receipt, followed by the dependent operation in that
same shell.

Interpreter SHA256:
`4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`.
Ordered codec default-JSON digest:
`0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`.
All direct Python execution used the pinned interpreter with `-B -S`, adding
`-O` for optimized checks. The one scripted source replacement used that same
pinned interpreter; remaining edits used apply_patch. No system Python was
used for edits or checks.

## Resulting shared interface and earned facts

`new_peer(case, *, app, prior, now, clock, final=False, fault=None)` supports
partial_pause, final_pause, begin_pause_empty and control_rules. Its return is
exactly `{connection,state}`; the connection has exactly protocol/send/receive/
now/owned/tls/alpn. Ownership, TLSv1.3 and h2 remain supplied synthetic facts.
Construction initializes the pinned protocol and queues initial SETTINGS/ACK,
without calling the clock, client dispatch/observation, or changing app facts.
It validates the strict canonical four-key app and earned prior records,
outputs, binding and head totals before creating mutable peer state.

The original nested byte peer and its completion recipe were removed. The
driver keeps its signature and returns the same caller app reference; its
default is `test_core_peer.new_app()`. Optional wrong-tag path diagnostics
derive at most the first three validated paths from the bounded cursor. There
is no retained path/request/frame/read history or client-context observer in
the peer. `premature` and `wrong_tag` map to the two explicit bounded faults.

Metadata earns middleware/attempt/begin/active/callback facts only.
begin_pause_empty additionally earns its canonical begin pause before empty
END. DATA validates exact stream, flags, ordinal, span and payload before
incrementing the wire digest/count. Partial pause accepts only seven bytes
after8192 non-END bytes, remains unchanged after the4097-byte END, and finishes
only after the actual resume. The32-byte final pause similarly waits for
resume; empty END carries no accepted bytes. Completion derives the final
bytes/digest/chunk/span and terminal checks from the validated upload state.
Control rules follow the exact20-head sequence: active-not-paused, successful
DATA completion and stale replies are earned by the actual requests. Stale
counts are peer scalar receipts; the pause-family body schema correctly stays
unchanged by stale controls. No `model.record(selected=True)` recipe installs
normal peer completion facts.

Final68 is disabled by default and only follows the ordinary sequence on the
same connection. Metrics reuse the actual-record/head aggregation helper.
App outputs and relative binding remain untouched. Direct proofs validate
retention using explicitly supplied copied historical producer facts; those
facts are not claimed as producer wire execution. Separately, the four-case
shared-app chain starts unselected and earns every prior pause/control case
through actual serialized canonical dispatch, without family-check substitutes.

## Bounds and self-review

Reviewed every changed source line and all three current helpers against the
brief, unchanged model/handlers and project conventions. Findings were fixed
with the preserved attempts below. No known current correctness, ownership,
error-integrity or gate-integrity finding remains.

- Parser capacity8201; frame payload8192; each send span8192. Checks precede
  growth, and repeated rejected continuations preserve buffer/highwater.
- At most two queued packets, each at most8192 bytes, total at most16384.
  Normal resume needs two responses. Queued bytes do not satisfy the next
  request's delivered-response barrier; the explicit premature fault permits
  just its original status boundary so the canonical client catches it.
- One upload summary for pause cases, two for control_rules. Only scalar
  counts, max spans and rolling hashes are retained; no whole payloads.
- HPACK table and header-list caps4096. Oversized header-list and table-update
  inputs are rejected repeatedly before application facts.
- Cursor/head caps derive from the finite7/6/6/20-head schedules plus optional68.
  Receive count is at most heads+1, including initial SETTINGS/ACK; receive
  bytes are bounded by that count times8192. Caps precede queue consumption.
- Exact pseudo-header order/multiplicity, request stream, flags and path are
  checked before head/metadata facts. DATA order is checked before hashing or
  accepted counters. Partial status barriers are enforced before/after END.
- Final proof retains protocol, parser, request/response ledgers, records,
  stage, deadlines, outstanding debt and cumulative read/byte counts; it
  consumes retained actual final observations and issues no extra collection.
- The complete current40 AST has no class/assert/global/container-state
  violations and maximum nesting3. All three current unit helpers are guarded,
  max3, and inert both on import and when executed as main with empty/foreign
  argv. No current unit helper is excluded as historical.

Helper depths: audit2, capture1, proofs3. Hashes and exact inventory are in
`covered-normal/helper-depths.json` and `covered-optimized/helper-depths.json`.
Full source nesting is in the corresponding `structure.json`; immutable and
history results are `immutable-inputs.json` and `history.json`. This is a
self-review, not Root's required independent review.

## Exact checks, commands and results

Evidence prefix for every relative path below:
`/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/pause-peer/`.

Every check directory contains exact `command.json` (argv, complete child env,
cwd, restoration receipt), `source-before.json`, `source-after.json`, frozen
candidate `test_pause.py.txt`, `check-source.txt`, `capture-source.txt`,
`structure.txt`, separate `stdout.txt`/`stderr.txt`, and `exit.json`.
`commands-summary.json` indexes all27 captured invocations and outcomes.
No exit was inferred from stdout. All successful final checks below have
empty stderr and identical before/after40-source bindings.

The final four covering checks, run after the last current helper/source edit:

| Receipt directory | Exact target | Mode | Exit |
|---|---|---|---|
| `cover-pause-normal` | `combined-cases/test_pause.py` | `-B -S` | 0 |
| `cover-pause-optimized` | `combined-cases/test_pause.py` | `-B -S -O` | 0 |
| `cover-imports-normal` | `combined-cases/test_imports.py` | `-B -S` | 0 |
| `cover-imports-optimized` | `combined-cases/test_imports.py` | `-B -S -O` | 0 |

Additional final direct proofs: `final-direct-normal` and
`final-direct-optimized`, running the exact `proofs.py --check` target in their
command.json, both exit0. Current strict audits: `cover-audit-normal` and
`cover-audit-optimized`, running `audit.py --audit` with distinct `covered-normal`
and `covered-optimized` output directories, both exit0. They verify the exact
four covering and two direct receipts in `covering-receipts.json`.

For concreteness, the final normal pause check used this same-shell closure:

```sh
set -e
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/pause-peer/restore-cover-pause-normal.json
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/pause-peer/capture.py --run cover-pause-normal .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_pause.py normal
```

The recorder executed the exact absolute target with cwd
`/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases`
and exactly this child environment:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
```

Other exact argv/env/cwd/restoration combinations are in each receipt and the
command summary; each shell used a fresh `restore-<receipt-name>.json` except
the explicitly corrected intermediate driver receipt below. The frozen
baseline diagnostic target was `baseline/test_pause.py.txt`, deliberately
executed as Python to establish the original actual diagnostic.

Final driver stdout preserves:

```text
partial_pause passed: heads=7 flow=12289
final_pause passed: heads=6 flow=32
begin_pause_empty passed: heads=6 flow=0
control_rules passed: heads=20 flow=64
partial_pause passed: heads=7 flow=12289
final_pause passed: heads=6 flow=32
wrong tag rejected before control: record mismatch: tag
premature response rejected: invalid terminal
```

Direct proofs additionally cover constructor purity/rejection, metadata versus
DATA versus resume timing, active/stale control timing, wrong metadata,
stream/flag/order multiplicity, payload/hash/ordinal/empty END, missing partial
status barrier, premature/unexpected final, repeated parser/pending/read/byte
cap rejection, exact four-case chain with107 heads including final68, retained
copied output/binding facts, send span and HPACK limits. The inventory/import
checks cover all40 current modules in normal and optimized modes.

## Preserved REDs, intermediate attempts and evidence concerns

All attempts remain under unique names with source and check snapshots:

- `red-constructor` exit1: missing constructor AttributeError before effects.
  `green-constructor` exit0. This RED does not establish a wire failure.
- `red-timing` exit1: the newly exposed constructor's send hook reached the
  not-yet-implemented `send_bytes`; no metadata transition occurred.
  `green-timing` exit0 after serialized handling was implemented.
- `driver-first` exit0: converted driver first passed. Its recorder initially
  inferred the nonexistent default `restore-driver-first.json`; the actual
  same-shell receipt is `restore-edit-driver.json`. Original metadata is
  preserved, with an additive `driver-first/restoration-correction.json`.
- `red-premature` exit1 exposed the new peer's premature response being caught
  by its own pending-response guard, rather than the original client boundary.
  The first test incorrectly expected `upload completed before resume`.
  `green-premature` still exited1: the peer fix reached `invalid terminal`.
  `baseline-diagnostic` exit0 then executed the frozen accepted driver and
  established that `invalid terminal` was the original actual diagnostic.
  The test expectation was corrected to that observed baseline, preserving
  both failed versions; `green-premature-corrected` exited0. This is an explicit
  test-expectation correction, not a weakened canonical gate.
- `direct-expanded` exit0 established the first expanded adversarial/chain
  proofs. `red-send-span` exit1 demonstrated acceptance of an8201-byte send
  carrying8192 DATA bytes. The parent send limit was restored to8192 before
  growth; `green-send-span` exited0 with fragmented frame proofs retained.
- `audit-normal` exit1 found the reused immutable audit assumed repository cwd,
  whereas check cwd is combined-cases. The audit now scopes cwd to the repo
  only for that authoritative routine and restores it in finally.
  `audit-corrected-normal` and `audit-optimized` exited0.
- Earlier `final-pause-*` and `final-imports-*` checks passed. The final four
  `cover-*` checks were rerun after the audit-helper correction; their strict
  audits pass. No successful unrelated suite was rerun.

The AST-only Graphify command was:

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .
```

It followed `restore-graphify.json` in the same shell, exited0, and reported
no relevant indexed changes. Raw streams and status are `graphify.stdout.txt`,
`graphify.stderr.txt`, and `graphify.exit.txt`.

## Remaining boundaries

No subagent, external model CLI, Git mutation, network, server, socket, native
build/runtime, TLS construction/close, real clock, process ownership or original
native fault/cancel/scheduling/race/panic/crash/leak probe was executed. The
recorder's subprocesses execute only the authorized pinned Python source checks.

The peer/application/callback facts are supplied synthetic facts constrained by
validated serialized traffic and the immutable contracts. The historical
producer fixture is explicitly supplied, while the actual pause/control prior
chain is independently earned. Neither substitutes for the future actual
default/all40 coordinator proof or native fixture correctness.

Root must independently review before publication/commit/push. Remaining peer
units, actual all40/default aggregation and broad combined review, runtime
closure, sequential two-child native acceptance, adoption, and every original
milestone remain required. Formatting/conventions/release-version/Zig tests,
sanitizer/compile/fuzz/library/package-consumer, applicable protocol/platform
and compliance gates were not run in this source-only slice and remain
mandatory at their released phase; no gate was waived or weakened.
