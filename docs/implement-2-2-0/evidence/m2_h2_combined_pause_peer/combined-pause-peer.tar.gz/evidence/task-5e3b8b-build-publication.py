"""Package the reviewed pause/control peer and its retained source evidence."""
import hashlib
import json
import runpy
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load_writer(plan):
    provenance = Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_peer/combined-core-peer.tar.gz')
    if sha(provenance.read_bytes()) != 'dbcd7a01a56a3c80600aa39fa7b61dec00060976c14a82e2bd4a712a2520d25d':
        raise ValueError('Writer provenance differs')
    builder = plan / 'task-5e3b7p1-build-publication.py'
    with tarfile.open(provenance, 'r:gz') as previous:
        if previous.extractfile('evidence/' + builder.name).read() != builder.read_bytes():
            raise ValueError('Published writer differs')
    return runpy.run_path(str(builder))['load_writer'](plan)


def add_baseline(writer, members, baseline):
    if sha(baseline.read_bytes()) != '8d4742d533c692424648850d87b0fb2e2319338ed6c4cb33ff0c2835e14f3c63':
        raise ValueError('Baseline archive differs')
    with tarfile.open(baseline, 'r:gz') as previous:
        inventory = json.loads(previous.extractfile('INVENTORY.json').read())
        for member in previous:
            if not member.isfile():
                raise ValueError('Nonregular baseline member')
            if member.name == 'INVENTORY.json':
                continue
            data = previous.extractfile(member).read()
            if inventory[member.name] != dict(size=len(data), sha256=sha(data)):
                raise ValueError('Baseline inventory differs')
            if member.name.startswith('reference/'):
                writer['add'](members, member.name, data)
            if member.name.startswith('source/current/'):
                name = member.name.replace('source/current/', 'history/core-async-source/', 1)
                writer['add'](members, name, data)


def add_files(writer, members, source, plan):
    for path in sorted(source.glob('*.py')):
        writer['add'](members, 'source/current/' + path.name, path.read_bytes())
    raw = source / 'evidence/pause-peer'
    for path in sorted(raw.rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink in evidence')
        if path.is_file():
            name = 'raw/pause-peer/' + path.relative_to(raw).as_posix()
            writer['add'](members, name, path.read_bytes())
    names = ('task-5e3b8b-brief.md', 'task-5e3b8b-report.md',
             'task-5e3b8b-review-brief.md', 'task-5e3b8b-review-report.md',
             'task-5e3b8b-review-source.diff', 'task-5e3b8b-root-final-audit.json',
             'task-5e3b8b-root-final-audit-inputs.json',
             'task-5e3b8b-root-final-audit-inputs-2.json',
             'task-5e3b8b-root-audit-attempt1.json', 'task-5e3b8b-root-audit.py',
             'task-5e3b8b-root-final-audit-inputs-3.json',
             'task-5e3b8b-root-first-final-audit.json',
             'task-5e3b8b-publication-audit.py',
             'task-5e3b8b-root-final-audit-inputs-4.json',
             'task-5e3b8b-root-second-final-audit.json',
             'task-5e3b8b-build-publication.py', 'task-5e3b8a-restore-inputs.py',
             'task-5e3b1-root-source-restoration.json',
             'task-5e3b-all40-peer-plan-report.md',
             'task-5e3b-aggregate-acceptance-notes.md')
    for name in names:
        writer['add'](members, 'evidence/' + name, (plan / name).read_bytes())


def main(argv):
    if argv != ['--build']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    writer = load_writer(plan)
    baseline = Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_async_peer/combined-core-async-peer.tar.gz')
    audit = json.loads((plan / 'task-5e3b8b-root-final-audit.json').read_text())
    current = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if current != audit['current_source_sha256']:
        raise ValueError('Approved current source differs')
    members = {}
    add_baseline(writer, members, baseline)
    add_files(writer, members, source, plan)
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_combined_pause_peer')
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'combined-pause-peer.tar.gz'
    inventory = writer['write_archive'](archive, members)
    manifest = dict(scope='Shared pause/control peer with synthetic application and transport facts',
                    base_commit=audit['base_commit'],
                    baseline_archive_sha256=sha(baseline.read_bytes()),
                    archive=archive.name, archive_bytes=archive.stat().st_size,
                    archive_sha256=sha(archive.read_bytes()),
                    safe_regular_text_members=len(members), inventory_entries=len(inventory),
                    current_source_files=current, changed_files=['test_pause.py'],
                    added_files=[], unchanged_modules=39,
                    shared_peer_cases=['partial_pause', 'final_pause', 'begin_pause_empty', 'control_rules'],
                    peer_constructor='new_peer(case, *, app, prior, now, clock, final=False, fault=None)',
                    standalone_driver_shared_peer=True, actual_four_case_chain_heads_with_final=107,
                    observed_ordinary=dict(partial_pause=dict(heads=7, request_data=12289),
                                           final_pause=dict(heads=6, request_data=32),
                                           begin_pause_empty=dict(heads=6, request_data=0),
                                           control_rules=dict(heads=20, request_data=64)),
                    current_normal_optimized_covering_commands=4,
                    current_normal_optimized_direct_commands=2,
                    current_normal_optimized_audit_commands=2,
                    source_ast_inert_import_modules=40, current_guarded_inert_unit_helpers=3,
                    current_helper_max_nesting=3, prior_evidence_hashes_checked=9727,
                    retained_identity_entries=119, physical_identity_rows=118,
                    unique_resolved_files=113, ordered_codec_files=42,
                    fresh_pre_edit_source_identity_freeze=True,
                    atomic_source_restoration_before_checks=True,
                    copied_historical_producer_fixture_is_supplied=True,
                    premature_diagnostic_baseline_verified='invalid terminal',
                    initial_driver_restoration_reference_corrected_additively=True,
                    root_metadata_invocation_failure_qualified=True,
                    source_review='Spec and quality approved',
                    coordinator_composition_accepted=False, actual_all40_executed=False,
                    native_executed=False, milestone_complete=False,
                    remaining=['Admission/Continue/credit/metadata/terminal peer extractions',
                               'Actual default/all40 aggregate and broad combined review',
                               'Runtime/native/full gates and production adoption'])
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
                  regular_members=len(members), inventory_entries=len(inventory),
                  source_modules=len(current), native_executed=False)
    (plan / 'task-5e3b8b-root-archive-build.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
