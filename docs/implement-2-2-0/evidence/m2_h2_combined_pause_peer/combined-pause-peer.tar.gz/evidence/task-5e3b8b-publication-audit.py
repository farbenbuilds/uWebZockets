"""Reopen the pause archive and bind the six reviewable delivery files."""
import ast
import hashlib
import json
import re
import sys
import tarfile
from pathlib import Path, PurePosixPath
from urllib.parse import unquote


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_archive(archive):
    contents = {}
    with tarfile.open(archive, 'r:gz') as stream:
        for member in stream:
            name = PurePosixPath(member.name)
            if not member.isfile() or name.is_absolute() or '..' in name.parts or member.name in contents:
                raise ValueError('Unsafe or duplicate archive member')
            data = stream.extractfile(member).read()
            data.decode('utf-8')
            contents[member.name] = data
    inventory = json.loads(contents.pop('INVENTORY.json'))
    if inventory.keys() != contents.keys():
        raise ValueError('Inventory coverage differs')
    for name, data in contents.items():
        if inventory[name] != dict(size=len(data), sha256=sha(data)):
            raise ValueError('Member differs: ' + name)
    return contents


def verify_live(contents, source, plan, manifest):
    current = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if current != manifest['current_source_files'] or len(current) != 40:
        raise ValueError('Current source differs')
    for name in current:
        if contents['source/current/' + name] != (source / name).read_bytes():
            raise ValueError('Archived source differs')
    raw = source / 'evidence/pause-peer'
    expected = {'raw/pause-peer/' + path.relative_to(raw).as_posix(): path.read_bytes()
                for path in raw.rglob('*') if path.is_file()}
    archived = {name: data for name, data in contents.items() if name.startswith('raw/pause-peer/')}
    if archived != expected:
        raise ValueError('Archived raw evidence differs')
    for name, data in contents.items():
        if name.startswith('evidence/') and data != (plan / name[len('evidence/'):]).read_bytes():
            raise ValueError('Archived Root evidence differs')
    return len(expected)


def verify_links(files):
    count = 0
    for path in files:
        if path.suffix != '.md':
            continue
        for link in re.findall(r'\]\(([^)]+)\)', path.read_text()):
            target = link.split('#', 1)[0].strip('<>')
            if not target or re.match(r'[A-Za-z][A-Za-z0-9+.-]*:', target):
                continue
            if not (path.parent / unquote(target)).exists():
                raise ValueError('Missing local link: ' + str(path) + ': ' + link)
            count += 1
    return count


def verify_root_helpers(plan):
    result = {}
    auditor = plan / 'task-5e3b8b-root-audit.py'
    scope = {'__name__': 'publication_metadata', '__file__': str(auditor)}
    exec(compile(auditor.read_text(), str(auditor), 'exec'), scope)
    names = ('task-5e3b8b-root-audit.py', 'task-5e3b8b-build-publication.py',
             'task-5e3b8b-publication-audit.py')
    for name in names:
        path = plan / name
        tree = ast.parse(path.read_text(), filename=str(path))
        depth = scope['nesting'](tree)
        if depth > 3:
            raise ValueError('Root helper nesting differs')
        namespace = {'__name__': 'publication_metadata', '__file__': str(path)}
        exec(compile(tree, str(path), 'exec'), namespace)
        namespace['main']([])
        namespace['main'](['foreign'])
        result[name] = dict(sha256=sha(path.read_bytes()), nesting=depth, inert_import_empty_foreign=True)
    return result


def main(argv):
    if argv != ['--audit']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    docs = Path('docs/implement-2-2-0')
    folder = docs / 'evidence/m2_h2_combined_pause_peer'
    archive = folder / 'combined-pause-peer.tar.gz'
    manifest = json.loads((folder / 'manifest.json').read_text())
    if sha(archive.read_bytes()) != manifest['archive_sha256'] or archive.stat().st_size != manifest['archive_bytes']:
        raise ValueError('Archive identity differs')
    contents = read_archive(archive)
    if len(contents) != manifest['inventory_entries'] or len(contents) + 1 != manifest['safe_regular_text_members']:
        raise ValueError('Archive counts differ')
    raw_count = verify_live(contents, source, plan, manifest)
    files = [docs / 'README.md', docs / 'm2_request_streaming.md', docs / 'm2_h2_combined_pause_peer.md',
             folder / 'README.md', folder / 'manifest.json', archive]
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
                  safe_regular_utf8_members=len(contents) + 1, inventory_entries=len(contents),
                  current_source_modules=40, raw_files_exact=raw_count,
                  local_links_checked=verify_links(files), root_helpers=verify_root_helpers(plan),
                  delivery_files={str(path): dict(size=path.stat().st_size, sha256=sha(path.read_bytes())) for path in files},
                  all_archived_current_source_raw_and_root_evidence_exact=True, native_executed=False)
    (plan / 'task-5e3b8b-root-publication-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('delivery_files', 'root_helpers')}, indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
