# Shared independent pause/control peer

Released after8areview/push BASE872aa6b451f2cb4dfc20a9e7aadc43a5ef771a4c.
Current40 source map docs/implement-2-2-0/evidence/m2_h2_combined_core_async_peer/manifest.json;
Rootcommit audit task-5e3b8a-root-commit-audit.json. Read accepted
task-5e3b-all40-peer-plan-report.md sharedcontract/unit2 and
task-5e3b-aggregate-acceptance-notes.md. Thispreparesfourpeer cases, notactual
coordinator/defaultall40/native/adoption/milestone acceptance.

## Ownership and interface

Own ONLY
/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_pause.py,
new evidence/pause-peer underthatsamedirectory and task-5e3b8b-report.md in
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan. Inventorystays40,
onechanged39unchanged. No other module/helper/model/core/handler/fixture/codec/
pin/product/limit edits. ExactadditionalAPI/ownershipgap toRoot BEFORE edit.
Youarenotalone/preserveothers/allsource/raw/history; no agents/Git/public/
externalmodelCLI/native execution. Root owns freshreview/commit+immediatepush.

Promote single shared constructor:
new_peer(case,*,app,prior,now,clock,final=False,fault=None)
for partial_pause,final_pause,begin_pause_empty,control_rules. Exactreturn
{connection,state}, connection7keysprotocol/send/receive/now/owned/tls/alpn;
initiatedpinnedprotocol/suppliedtimestamp/ownedTrue/TLSv1.3/h2 syntheticfacts.
QueueinitialSETTINGS+ACK fornormalreceive, no constructorclock/clientdispatch/
observe/apptransition orselectedcompletion. Validateapp/prior/case/final/fault
beforemutation. Exactappshape records,heads,outputs,binding via existing
test_core_peer.new_app; validateprior againstearnedpersistentfacts, neverseed.

Keep check(case,premature=False,app=None,prior=(),final=False,wrong_tag=False,
paths=None) signature andreturnapp reference, existingpositive/negs/messages/
printedcounts. Driver now usesnew_peer; deleteoldnestedbytepeer, deadimports,
accumulatedpeerpath/requesthistories. Rootruling: driver's defaultapp upgrades
fromrecords/heads tocanonical4keys andreturns sameappobject; existinglocal
sharedcaller remainscompatible. No speculativelegacy2-keyadapter unlessactual
externalcallerrequiresit/reportexactgap. Constructorpubliccontract4keysstrict.
Preservepaths optionaldiagnostic for existingwrong_tag caller: exactfirst3
validatedrequests beforecontrol. Useboundedcursor/fixedvalidatedprefix orother
boundeddriver evidence; no unboundedpeerhistory/arbitraryobservercallback.
Premature/wrong_tag driverflags translate toexplicitboundedfaultmodes only.

## Actual independently earned facts and bounded storage

Peertruth derivesonlyfromdecodedvalidatedheaders/DATA/control/END actions,
neverclientcontext/capture or model.record(selected=True) completion recipes.
Useimmutablemodel/handlers ascontractvalidators, notseededobservations. All67
records initiallyunselected. Atactualuploadmetadata earnmiddleware/begin/active
facts; begin_pause_empty maypause onbegin beforezero-byteEND bycanonicalpolicy.
DATA earnslogicalwirebytes/hash/ordinal andactualacceptedprefix/chunk facts;
latercontrol/resume/terminalaction earnscompletion/stale counters. No future
stale/resume/terminal facts installed early. Preserveheld/pausedmetadata fields
andexactcallback/check/hash/count contracts; derivefromunchangedcanonical code.

partial_pause requiresDATA8192(nonEND),4097(END), exactpausedprefix/status
barriers before/aftersecondDATA, actualresume beforecompletion. Othernormal
bodycases32END; begin_pause_empty zeroDATAEND. control_rules owns control_one/
control_two andits20-headexactstate/control order; stale/active/paused replies
earned byactualcontrolrequest, notrequestedcataloguecase alone. Hashrawpayload
incrementally; recordacceptedprefix andfinalbytes independently. Do notstore
wholepayload/request/frame/readhistories. Preserveoutputs/binding untouched.

Onlineexactpseudo/header/stream/flag/order multiplicity checks beforefacts;
boundedparser8201/frame8192/HPACK/finitependingpackets/packetbytes/reads/stream
maps andscalarcursors. CheckBEFOREgrowth andonrepeatinvalidinput; no huge
unearnedstreamsets or losthighwater. Derivefamilylimits fromfiniteconcrete
schedule/sharedpolicies, preserveallparentceilings. Queuedresponses/grants not
yetdelivered cannotestablishclientobservation. Driver-side contextassertions
allowed onlyoutsidepeer; anywrapperoriginalonce/resultidentity/errorpriority.

## Required proofs and workflow

Preserveexistingmain's4standalones, actualpartial->final_pause sharedapp/final68,
wrong-tag rejects record mismatch: tag withpaths exactlyhealth/upload/status
beforecontrol, prematurecompletionnegative andallDATAframe/hash assertions.
DefaultfinalFalse no final68; finalTrue permits itonlyafteractualordinary
sequence using sameconnection/parser/ledgers/debt/deadline/readcap. Metrics
deriveactualapprecordcounters+appheads (reuseexistingmetricshelper ifapplicable),
no model-generatedselectedmetrics. Actualpriorchain proof neverfamilycheck
substituteforcoordinator; allstandalonefacts remainexplicit.

Newchecksconstructornoeffects/strictshape/priorrejectbeforemutation, independent
recordtiming(metadata vsDATA vsresume), DATAordinals/emptyEND, wrongtag/no
earlycontrol, unexpected/prematurefinal, invalidframe/parser/pending/readcaps
beforegrowth/repeatednogrowth, copiedretainedoutputbinding whereapplicable.
Anyhistoricalpriorfixtures explicitlysupplied, notpriorwireexecution. Actual
sharedchain mustearneverypriorcase from traffic. No fabricatedmodelcompletion.

Beforeedit atomicrestore thenverify119identity AND accepted40/freezeexactsource,
captureFRESH exhaustiveprior-evidenceSHAmap excludingonlynewunitdir. Freeze
BEFOREactualacceptanceRED (missingconstructor ispre-effect, qualify). Each
discoveredbug realRED/source BEFOREfix; everyattempt distinctraw/source/command/
structure paths. Readactualrequiredproject/role/narrowworkflowtext beforeedit,
notconcatenatedunreadtempfile. AllPythonpinned-B-S, never systemPythonforedits.

Afterlastedit FOURfocusedchecks: test_pause.py andtest_imports.py normal/-O,
plusdirectnewproofs asneeded. Otherpassed suites onlyactualspecificdependency.
Everycheck needs exactargv/env/cwd, before/after40source maps, SEPARATEstdout/
stderr/exit andsame-shellrestorationreceipt. DoNOTcapturestdoutonly andinfer
exit/stderr. Keepper-checkrecordssointerruptionresumesunfinishedonly. Current
40AST/guards/inertimports/allCURRENTunithelpermaxnest3/guard/inertemptyforeign,
119authority118physical113resolved+42orderedcodecs/oldhistory audit mandatory.
No currentlivehelper exempt as"historical"; preserveoldversionthenfixit ifneeded.
No classes/assert/customexception/globalmutablecontainers/deadcode/camelCase/
silencederrors/forwardingabstractions orweakenedtest/lint/limits.

## Exact execution closure

TMPresets acrosscontinuations. EACHdependentproof/audit/checkexec_command
SHELL MUST starttheRootrestorer thenoperation IN SAMEshell (set-e), usingNEW
uniqueJSONreceiptfilename:
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT
ThiscopiesonlyexactpinnedUTF8sourcesfromcommittedarchives, verifies119/118/113/
42/interpreter, no compiledbinaries/install/network/native. Emptyforeignargs
inert. Do notassumeRoot'spreviousTMPpersists. ExactPYTHONPATH:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
Pinned/home/codespace/.python/current/bin/python3 SHA256
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601; everydirect
Python-B-S, optional-O foroptimized. OrderedcodecdefaultJSONdigest
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Authority evidence/coordinator-a/immutable-inputs.json unchanged. Genericmissing
DoDreference alreadyruledexplicitprojectgates/exactscope, no newfile/search/
approvalflow. Readapplicableproject/developer/verification/narrowskills. Before
NEWcodebasequestion/search/readGraphify:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650
Providedpaths located. No native/build/server/socket/SSLContext/TLSclose/
realclock/processownership/kernel/fault/cancel/schedule/race/panic/crash/leak/
oldruntime/network/Git/agents/externalmodelCLI. Onlypinnedpurecodecs/supplied
facts; fullnative/project/platformgates remainmandatorylater, nowaiver.

Fullreport exactfiles/commands/raw/exits/RED/GREEN/currentfrozen/input/history/
helperbounds/selfreview/gaps to task-5e3b8b-report.md. ReturnconciseDONE or
specificDONE_WITH_CONCERNS/NEEDS_CONTEXT/BLOCKED; askactualmissingcontextearly,
remainingtodoalone isnotblocker. Rootfreshreview/pubaccuracy/commitpush then
nextpeerunit; actualall40/broadreview/runtime/native/twochild/adoption/every
originalmilestone remainmandatory. Do notclaimbroadercompletion.
