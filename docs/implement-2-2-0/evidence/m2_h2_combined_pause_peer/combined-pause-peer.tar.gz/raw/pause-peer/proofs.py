"""Opt-in pure-codec pause peer acceptance; synthetic supplied peer facts."""
import copy
import sys
import adapter
import catalogue
import hpack
import model
import pause_cases
import test_core_peer
import test_pause


def require(value, message):
    if not value:
        raise ValueError(message)


def constructor():
    app = test_core_peer.new_app()
    before = copy.deepcopy(app)

    def forbidden():
        raise RuntimeError('constructor called clock')

    peer = test_pause.new_peer('partial_pause', app=app, prior=(), now=17, clock=forbidden)
    require(set(peer) == {'connection', 'state'}, 'peer shape')
    connection = peer['connection']
    require(set(connection) == {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'}, 'connection shape')
    require(connection['now'] == 17 and connection['owned'] is True and connection['tls'] == 'TLSv1.3' and connection['alpn'] == 'h2', 'supplied facts')
    require(app == before, 'constructor mutated application')
    print('constructor side effects and exact interface passed')


def open_peer(case, *, app=None, prior=(), final=False):
    app = test_core_peer.new_app() if app is None else app
    peer = test_pause.new_peer(case, app=app, prior=prior, now=1, clock=lambda: 2, final=final)
    connection = peer['connection']
    context = adapter.open_case(case, connection['protocol'], connection['send'], 1, 30001, 900001,
                                selected_before=prior, clock=lambda: 2)
    adapter.observe(context, *connection['receive']())
    return app, peer, context


def timing():
    app, peer, context = open_peer('partial_pause')
    receive = peer['connection']['receive']
    adapter.health(context, receive)
    stream = pause_cases.upload(context, 'partial_pause', True, held=True)
    item = app['records']['partial_pause']
    require(item['middleware'] == item['attempts'] == item['begins'] == 1 and item['active'], 'metadata not earned')
    require(item['bytes'] == item['chunks'] == item['ends'] == item['terminal_checks'] == 0 and not item['paused'], 'metadata earned future data')
    adapter.send_data(context, stream, model.payload_span(12289, 0, 8192), False)
    require(item['bytes'] == 7 and item['sha256'] == model.H7 and item['paused'], 'accepted prefix not earned')
    before = dict(item)
    pause_cases.status(context, receive, 'partial_pause')
    adapter.send_data(context, stream, model.payload_span(12289, 8192, 4097), True)
    require(item == before and peer['state']['data'] == 12289, 'queued END changed accepted record')
    pause_cases.status(context, receive, 'partial_pause')
    require(item['ends'] == 0 and peer['state']['resumes'] == 0, 'completion before resume')
    pause_cases.control(context, receive, 'resume', 'partial_pause', 'ok', resume_stream=stream)
    pause_cases.complete(context, receive, stream, 'partial_pause')
    adapter.health(context, receive)
    model.validate_records(('partial_pause',), 'before', app['records'])
    require(peer['state']['resumes'] == 1 and item['bytes'] == 12289 and item['ends'] == 1, 'completion not earned')
    print('metadata, prefix, queued END, actual resume timing passed')


def premature_diagnostic():
    try:
        test_pause.check('final_pause', premature=True)
    except ValueError as exc:
        require(str(exc) == 'invalid terminal', 'premature diagnostic changed: ' + str(exc))
    else:
        raise ValueError('premature accepted')
    print('premature original diagnostic passed')


def rejects(action, expected=None):
    try:
        action()
    except ValueError as exc:
        require(expected is None or str(exc) == expected, 'unexpected rejection: ' + str(exc))
        return
    raise ValueError('invalid action accepted')


def constructor_rejections():
    changes = ({'case': 'ready_buffered'}, {'prior': ('partial_pause',)}, {'prior': ('unknown',)},
               {'prior': ('final_pause', 'final_pause')}, {'final': 1}, {'fault': 'unknown'},
               {'fault': []}, {'now': True}, {'now': -1}, {'clock': None})
    for changed in changes:
        app = test_core_peer.new_app()
        before = copy.deepcopy(app)
        args = dict(case='final_pause', app=app, prior=(), now=1, clock=lambda: 2)
        args.update(changed)
        rejects(lambda: test_pause.new_peer(**args))
        require(app == before, 'rejected constructor mutated app')
    for key in ('records', 'heads', 'outputs', 'binding'):
        app = test_core_peer.new_app()
        del app[key]
        before = copy.deepcopy(app)
        rejects(lambda: test_pause.new_peer('partial_pause', app=app, prior=(), now=1, clock=lambda: 2), 'app fields differ')
        require(app == before, 'shape rejection mutated app')
    print('constructor shape, prior, final, fault and clock rejection before mutation passed')


def send_head(peer, path, *, stream=None, flags=5, entries=None):
    state = peer['state']
    headers = [(':method', 'POST' if path.startswith('/upload/') else 'GET'), (':scheme', 'https'),
               (':authority', 'localhost'), (':path', path)] if entries is None else entries
    stream = 2 * state['cursor'] + 1 if stream is None else stream
    peer['connection']['send'](test_core_peer.frame(1, flags, stream, hpack.Encoder().encode(headers)))


def malformed_headers():
    fields = [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', '/health')]
    corruptions = (fields + [(':path', '/health')], fields[:-1], list(reversed(fields)),
                   fields + [('x-extra', 'value')], fields[:2] + [(':authority', 'foreign')] + fields[3:])
    for entries in corruptions:
        app, peer, _context = open_peer('final_pause')
        before = copy.deepcopy(app)
        for _ in range(2):
            rejects(lambda: send_head(peer, '/health', entries=entries), 'request contract differs')
            require(app == before and peer['state']['cursor'] == 0 and not peer['state']['buffer'], 'bad header earned state')
    for stream, flags in ((3, 5), (1, 4), (1, 13), (0x80000001, 5)):
        app, peer, _context = open_peer('final_pause')
        rejects(lambda: send_head(peer, '/health', stream=stream, flags=flags), 'request contract differs')
        require(app['heads'] == 0 and peer['state']['uploads'] == {}, 'bad stream/flags earned state')
    app, peer, _context = open_peer('final_pause', final=True)
    rejects(lambda: send_head(peer, '/status/large_declared'), 'request contract differs')
    send_head(peer, '/health')
    rejects(lambda: send_head(peer, '/upload/final_pause', flags=4), 'request before preceding response')
    require(app['heads'] == 1 and app['records']['final_pause']['begins'] == 0, 'queued response credited as delivered')
    print('pseudo-header order/multiplicity/flags/streams, premature final and delivered-response barriers passed')


def bad_data():
    for tag, payload, flags in (('partial_pause', b'x' * 8192, 0), ('partial_pause', model.payload_span(12289, 0, 8192), 1),
                                ('begin_pause_empty', b'x', 1), ('begin_pause_empty', b'', 0),
                                ('final_pause', model.payload_span(32, 0, 32), 9)):
        app, peer, context = open_peer(tag)
        adapter.health(context, peer['connection']['receive'])
        stream = pause_cases.upload(context, tag, True, held=True)
        before = copy.deepcopy(app)
        for _ in range(2):
            packet = test_core_peer.frame(0, flags, stream, payload)
            if len(packet) > 8192:
                peer['connection']['send'](packet[:8192])
                packet = packet[8192:]
            rejects(lambda: peer['connection']['send'](packet))
            require(app == before and peer['state']['frames'] == 0, 'invalid DATA earned facts')
    app, peer, context = open_peer('partial_pause')
    receive = peer['connection']['receive']
    adapter.health(context, receive)
    stream = pause_cases.upload(context, 'partial_pause', True, held=True)
    adapter.send_data(context, stream, model.payload_span(12289, 0, 8192), False)
    before = copy.deepcopy(app)
    packet = test_core_peer.frame(0, 1, stream, model.payload_span(12289, 8192, 4097))
    rejects(lambda: peer['connection']['send'](packet), 'DATA ordinal contract differs')
    require(app == before and peer['state']['data'] == 8192, 'missing status barrier accepted')
    print('DATA hash, ordinal, END/empty END, flags and partial status barrier rejection passed')


def bounds():
    _app, peer, _context = open_peer('final_pause')
    send, state = peer['connection']['send'], peer['state']
    for packet in (test_core_peer.frame(6, 0, 0, b'12345678'), test_core_peer.frame(4, 1, 0, b'')):
        rejects(lambda: send(packet))
    for _ in range(2):
        rejects(lambda: send((8193).to_bytes(3, 'big') + bytes(6)), 'frame payload bound differs')
        require(not state['buffer'], 'oversize frame grew parser')
    packet = test_core_peer.frame(0, 0, 3, b'x' * 8192)
    send(packet[:8192])
    send(packet[8192:8200])
    before, highwater = bytes(state['buffer']), state['max_buffer']
    for _ in range(2):
        rejects(lambda: send(b'xx'), 'parser storage bound differs')
        require(bytes(state['buffer']) == before and state['max_buffer'] == highwater == 8200, 'overflow changed parser/highwater')
    _app, peer, _context = open_peer('final_pause')
    state = peer['state']
    state['pending'][:] = [b'a' * 8192, b'b' * 8192]
    for _ in range(2):
        rejects(lambda: test_pause.respond(state, 1, b'c'), 'pending storage bound differs')
        require(len(state['pending']) == 2 and sum(map(len, state['pending'])) == 16384, 'queue grew beyond cap')
    state['pending'][:] = [b'a' * 8193]
    rejects(peer['connection']['receive'], 'pending packet bound differs')
    state['pending'][:] = [b'a']
    state['received'] = state['head_limit'] + 1
    for _ in range(2):
        rejects(peer['connection']['receive'], 'receive bound differs')
        require(state['pending'] == [b'a'] and state['received'] == state['head_limit'] + 1, 'read cap consumed packet')
    state['received'] = 0
    state['received_bytes'] = (state['head_limit'] + 1) * 8192
    rejects(peer['connection']['receive'], 'receive byte bound differs')
    require(state['pending'] == [b'a'], 'byte cap consumed packet')
    print('invalid frames, parser/pending/packet/read/byte caps reject before growth and repeated no-growth passed')


def final_boundary(peer, context):
    state, stage = peer['state'], context['stage']
    identities = {name: context[name] for name in ('protocol', 'raw', 'request', 'credit', 'records', 'stage')}
    deadlines = stage['case_deadline'], stage['whole_deadline']
    reads, size = stage['reads'], stage['bytes']
    debt = context['request']['connection_debt'], context['request']['stream_debt_total']
    seen = [0, 0]

    def receive():
        require(all(context[name] is value for name, value in identities.items()), 'final changed connection identities')
        require((stage['case_deadline'], stage['whole_deadline']) == deadlines, 'final refreshed deadlines')
        require(stage['reads'] == reads + seen[0] and stage['bytes'] == size + seen[1], 'final reset cumulative receive cap')
        result = peer['connection']['receive']()
        seen[0] += 1
        seen[1] += len(result[0])
        return result

    require(adapter.final_collection(context, receive) is None, 'ordinary final return changed')
    require(state['final_requests'] == stage['final_registered'] == 68 and stage['final_complete'], 'final count differs')
    require((context['request']['connection_debt'], context['request']['stream_debt_total']) == debt, 'final erased debt')
    require(stage['reads'] == reads + seen[0] and stage['bytes'] == size + seen[1], 'final receive accounting')
    require('final_observations' in context, 'missing retained actual final capture')


def actual_chain():
    app = test_core_peer.new_app()
    selection = ('partial_pause', 'final_pause', 'begin_pause_empty', 'control_rules')
    previous = None
    for index, case in enumerate(selection):
        supplied, peer, context = open_peer(case, app=app, prior=selection[:index], final=index == 3)
        require(supplied is app, 'application reference changed')
        if previous is not None:
            require(all(context[name] is not previous[name] for name in ('protocol', 'raw', 'request', 'credit')), 'connection ledgers shared')
        adapter.run_case(context, peer['connection']['receive'])
        model.validate_records(selection[:index + 1], 'before', app['records'])
        require(peer['state']['final_requests'] == 0, 'unrequested final occurred')
        if index == 3:
            require((peer['state']['controls'], peer['state']['not_paused'], peer['state']['stale_resume'], peer['state']['stale_cancel']) == (7, 1, 3, 3), 'earned control outcomes differ')
            final_boundary(peer, context)
        previous = context
    require(app['heads'] == 107, 'actual chain heads differ')
    _app, peer, context = open_peer('final_pause')
    adapter.run_case(context, peer['connection']['receive'])
    rejects(lambda: send_head(peer, '/status/large_declared'), 'request beyond finite schedule')
    require(peer['state']['cursor'] == 6 and peer['state']['final_requests'] == 0, 'default final allowed')
    print('actual four-case chain, finite 20-head controls, final68 identities/debt/deadlines/caps, final=False rejection passed')


def begin_and_controls():
    app, peer, context = open_peer('begin_pause_empty')
    receive = peer['connection']['receive']
    adapter.health(context, receive)
    stream = pause_cases.upload(context, 'begin_pause_empty', True, held=True)
    item = app['records']['begin_pause_empty']
    require(item['active'] and item['paused'] and item['bytes'] == item['ends'] == 0 and item['callback_checks'] == 2, 'begin pause metadata')
    before = dict(item)
    adapter.send_data(context, stream, b'', True)
    require(item == before and peer['state']['frames'] == peer['state']['ends'] == 1, 'empty END earned premature completion')
    app, peer, context = open_peer('control_rules')
    receive, state = peer['connection']['receive'], peer['state']
    adapter.health(context, receive)
    stream = pause_cases.upload(context, 'control_one', True)
    require(state['controls'] == state['stale_resume'] == state['stale_cancel'] == state['resumes'] == 0, 'metadata seeded future controls')
    before = dict(app['records']['control_one'])
    pause_cases.status(context, receive, 'control_one')
    pause_cases.control(context, receive, 'resume', 'control_one', 'BodyNotPaused')
    require(app['records']['control_one'] == before and state['not_paused'] == 1 and state['controls'] == 1, 'active control mutated records')
    pause_cases.status(context, receive, 'control_one')
    adapter.send_data(context, stream, model.payload_span(32, 0, 32), True)
    require(app['records']['control_one']['ends'] == 1 and state['stale_resume'] == state['stale_cancel'] == 0, 'END seeded future stale controls')
    print('begin pause before empty END and independent active/control/terminal timing passed')


def retained_supplied_fixture():
    # Explicit historical supplied facts; this does not execute producer_reuse.
    app = test_core_peer.new_app()
    app['records'] = model.records(('producer_reuse',), 'before')
    for tag in ('producer_reuse', 'producer_reuse_next'):
        app['records'][tag].update(chunks=1, max_span=32)
    producer = app['outputs']['producer_reuse']
    producer.update(offset=16777313, invocations=2051, attempts=4099, writes=2049, blocked=2050,
                    pending=2050, terminal_attempts=1, terminals=1, checks=2051, after_reuse=1,
                    binding_index=0, binding_generation=7, armed=True, done=True, sha256=model.PRODUCER_HASH)
    app['binding'] = dict(tag='producer_reuse_next', binding_index=0, binding_generation=8)
    app['heads'] = catalogue.case_budget('producer_reuse')['heads']
    copied = copy.deepcopy(app)
    outputs, binding = copied['outputs'], copied['binding']
    supplied, peer, context = open_peer('final_pause', app=copied, prior=('producer_reuse',), final=True)
    adapter.run_case(context, peer['connection']['receive'])
    final_boundary(peer, context)
    require(supplied is copied and copied['outputs'] is outputs and copied['binding'] is binding, 'retained references replaced')
    require(outputs == app['outputs'] and binding == app['binding'], 'supplied retained output or binding mutated')
    require(app['records']['final_pause']['middleware'] == 0, 'copied application mutated original')
    print('explicit supplied historical producer fixture: copied retained outputs/binding preserved; no prior producer traffic claim')


def send_span_limit():
    app, peer, context = open_peer('partial_pause')
    adapter.health(context, peer['connection']['receive'])
    stream = pause_cases.upload(context, 'partial_pause', True, held=True)
    packet = test_core_peer.frame(0, 0, stream, model.payload_span(12289, 0, 8192))
    before = copy.deepcopy(app)
    rejects(lambda: peer['connection']['send'](packet), 'send span differs')
    require(app == before and not peer['state']['buffer'], 'oversized send earned facts')
    print('parent 8192 send span rejected before growth')


def hpack_limits():
    for payload in (hpack.Encoder().encode(((':path', 'a' * 4097),)), b'\x3f\xe2\x1f'):
        app, peer, _context = open_peer('final_pause')
        before = copy.deepcopy(app)
        for _ in range(2):
            try:
                peer['connection']['send'](test_core_peer.frame(1, 5, 1, payload))
            except hpack.HPACKError:
                require(app == before and peer['state']['cursor'] == 0, 'invalid HPACK earned facts')
                continue
            raise ValueError('oversized HPACK accepted')
    print('HPACK header-list and table-update caps reject twice before application facts')


def main():
    if sys.argv[1:] != ['--check']:
        return
    constructor()
    timing()
    premature_diagnostic()
    constructor_rejections()
    malformed_headers()
    bad_data()
    bounds()
    actual_chain()
    begin_and_controls()
    retained_supplied_fixture()
    send_span_limit()
    hpack_limits()


if __name__ == '__main__':
    main()
