# C6c: active shutdown, failure cleanup and live transport receipts

Read task-5e3c6c-plan-report.md FIRST: it defines the exact APIs, ordering,
accounting and acceptance cases. Read task-5e3c6-plan-report.md and its addendum
for accepted C4 composition, then the C6b context-seam plan/current source.
BASE37d056f7e31bf29e845f5d960d8cc36134703981 is clean and immediately pushed.
This is the next required source slice; real provider/runtime/native execution
and every remaining original milestone stay required afterwards.

Own only combined-native/native_transport.py, test_native_transport.py and
minimal new c6c-* controls/raw proof under evidence/native-transport/. Prefix
.uwz-work/evidence/h2-streaming/. Sole implementer, not alone: preserve all
other work. No subagents/Git/publication; Root integrates and independently
reviews. No new module or inventory edit absent a concrete invariant. No C4,
canonical S46, codec, fixture, candidate, dependency, product or pin edits.
Raise a real contract gap before expanding scope; do not fake a missing seam.

Implement the planned signal(state, owned_signal, context, deadline),
termination(state, context, deadline), fail_transport(state, primary_error)
and transport_receipt(state, connection_identity), with named flat contracts.
Keep exact seven-key connections and accepted conditional unwrap ops schema.
Reuse the accepted bounded state/history, primitives and C4 callbacks.

C6b introduced canonical optional child-descriptor bind_context callback.
Native execution must supply partial(native_transport.bind_context, state).
The coordinator passes its actual initialized adapter.open_case return once,
after startup send and before retained facts/receive loop/case handling.
Transport retains exact context/stage/raw/request/credit/records/binding
identities; use these anchors for active hooks. Never first-bind at signal,
termination or close. No notification for disconnect replacement2 was added.
Do not mistake retained original TLS callback anchors for the current cleanup
handle after successful strict unwrap transferred ownership to a raw token.

At signal entry validate exact current active identity, context/callbacks and
original clipped grace/case/whole deadlines. Freeze canonical counts and C4
checkpoint BEFORE signal effects. OwnedSignal is an explicit external effect
callback receiving retained child/exact open handle/deadline; named returned
evidence must bind PID/start/listener/installed watcher/open client and actual
operation prerequisites/result. Successful-looking caller booleans alone do
not establish authorization. Source tests inject scripted operation evidence;
real ownership/watcher/signal authenticity is still a later provider conjunct.
Retain actual signal result, exact canonical signal facts and time/capture
health before return. No retry, even after effects followed by invalid result.

Before signal, preparation checks live PID/start/listener and capture. After
successful signal, C4 activation/closing preparation use retained authorization,
identities, original deadlines and capture; NEVER require continued live PID,
/proc or listener existence. Legitimate immediate process/listener disappearance
must permit closing. Primitive receive performs ONLY the actual bound recv;
preparation/clock/parser/capture failures cannot gain receive-origin TLS EOF.
Canonical shutdown handler alone marks/begins/finishes termination. Preserve
C4 limits: 8192/read,65536 closing bytes,4096 frames,residual case/final budgets,
one terminal-only probe, sticky observer poison and ordinary-seal failure.

Demonstrate a real caller boundary around coordinator.run that calls
fail_transport(state, primary) then bare-reraises. It must clean active
pre-signal recv/preparation/clock/parser failures and post-signal failures;
merely exporting a helper is insufficient. Retain exact first exception and
cleanup exceptions separately; one-shot cleanup prevents repeated close and
unbounded errors when inner and outer boundaries both run. Never manufacture
release/acceptance from failure cleanup. Successful terminal observation still
requires normal close of the retained client handle, exact None, mark closed
before postchecks, capture/time under unchanged grace. No extra send/recv/
unwrap; no live ownership after signal; failed close/check permanently fails.

Live receipt resolves unique actual history identity and requires successful
resource release/no transport failure. Ordinary/disconnect seal original
observer once and revalidate bindings/health/operation anchor on consumption.
Active requires canonical finish and normal closure; return original immutable
checkpoint plus FRESH C4 local_receipt, never seal poisoned active observer.
Prove final aggregation calls live validation again, ordered expected identity
set/no missing/duplicates and canonical totals = ordinary seals +active prefix.
Closing counters/attempts/returns/bytes/frames and debt-before/after stay separate;
no closing counts added to frozen totals, resets, refunds or debt conflation.

TDD through the real canonical shutdown handler/scripted accepted peer: EOF/
qualified receive SSL EOF versus other origins, signal failure, immediate exit
with zero closing live-ownership calls, pre-signal error cleanup, primary/
cleanup identity, normal-close failure, duplicate/postterminal I/O, stale live
receipts, original deadlines/budgets and single begin/finish/accounting. Retain
true behavioral REDs separately from API-absence or fixture errors. Focused
normal/-O, inert and preservation only; no old C4/C5/S46/all40 reruns without
a named changed coverage gap. No compiler/server/socket/SSLContext/real clock/
process-under-test/network/install operations. Scripted opaque handles only.

Freeze approved seven native sources, current S46 and prior safe transport
proof before edits. C6b archive docs/implement-2-2-0/evidence/
m2_h2_native_disconnect/native-disconnect.tar.gz SHA
a699c83b373b1ed0c4d976a179ac4d2d7c9453344211e87ce1d6b89fc1f4a4b8
contains current7 and source/canonical/coordinator.py plus SOURCE_AUTHORITY.
Current hashes: nativee09b73926fbd87ff4bb278f0952acb61fcdd93d2da1af9c3ec3ebdd97774a02e,
teste90ab753b524e8d6ef906ad856938b2f0630c43f7e6e6d36696b008276e73cdb,
coordinator6585ad2323ce38a75948c7c365ceb7b9589c06e1c6010ae01ba35de0f11e6b32.
Compose the unchanged historical119-entry restorer with this accepted canonical
extension and pending native/test hashes. Restore first, verify executed source
paths/bytes, snapshot code-only dependencies, then execute in SAME controlled
shell. Verify imported coordinator path/hash before test behavior. No new
Graphify closure copies; retain existing hash references. Root final AST update.

Old public C5 packet has6482paths/25 private original environments. NEVER read,
copy, hash or print those originals. Use reviewed safe projections only. No
ambient environment dump; env-i/new controls only. Existing evidence immutable;
new c6c-* labels, source/code-only snapshots, never whole evidence trees. Retain
every exercised code/control version before runs, safe argv/settings, fresh
restoration receipt and complete target stdout/stderr/status. Baselines remain
historical; never repair an old attempt by replaying it or invent missing data.

Python EXACT: /home/codespace/.python/current/bin/python3 -B -S SHA
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601;
PYTHONDONTWRITEBYTECODE=1, fresh task-5e3b8a-restore-inputs.py --restore
NEW_ABSOLUTE_RECEIPT immediately before EACH dependent Python shell operation,
same shell. Six-part PYTHONPATH:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native

Follow AGENTS/conventions and transport/TLS/verification/TDD/API skills. No
classes/assert/custom errors/global mutable state/hidden OOP, no silent errors,
new control nesting<=3. Explicit named flat aliases, no speculative wrappers.
Graphify query before NEW codebase question/search/read; supplied paths located.
Use retained local Graphify tool; AST maintenance does not prove ignored topology.

Write task-5e3c6c-report.md here <=1400words preferred: exact changed files,
interfaces/hashes/commands/results/raw paths/concerns/remaining scope. Return
concise DONE|DONE_WITH_CONCERNS|NEEDS_CONTEXT|BLOCKED. No fake completion of
provider exit/reap/listener/capture/C5post/key cleanup/build/native/full gates.
