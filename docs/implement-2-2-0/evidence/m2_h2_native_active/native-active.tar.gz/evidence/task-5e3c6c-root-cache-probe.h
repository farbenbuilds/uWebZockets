typedef unsigned int uwz_cache_probe;
