"""Verify the inert-controller correction without repeating transport tests."""
import difflib
import hashlib
import json
import runpy
import sys
from pathlib import Path


def main(arguments):
    if arguments != ['--audit']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/combined-native')
    api = runpy.run_path(str(plan / 'task-5e3c6c-root-audit-initial.py'))
    parent = api['archive']('m2_h2_native_disconnect', 'native-disconnect.tar.gz', 'a699c83b373b1ed0c4d976a179ac4d2d7c9453344211e87ce1d6b89fc1f4a4b8')
    earlier = api['archive']('m2_h2_native_connection', 'native-connection.tar.gz', 'c0bdf2032aedfeea034e08edc4b2ab170f122931df10e419bc9f12a57f9f96f9')
    _, _, changed = api['sources'](source, parent)
    previous = json.loads((plan / 'task-5e3c6c-root-before-fix1-audit.json').read_text())
    if changed != previous['sources']:
        raise ValueError('Source changed during control-only fix')
    result = dict(preservation=api['preserve'](source, parent, earlier), sources=changed,
                  unchanged_native_sources=5, canonical=api['canonical'](parent),
                  native_pair_unchanged_since_source_review=True, native_executed=False,
                  complete_provider=False, milestone_complete=False)
    (plan / 'task-5e3c6c-root-fix1-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    raw = source / 'evidence/native-transport'
    before = {path.name: path.read_bytes() for path in (raw / 'c6c-terminal-inert-normal').glob('c6c-*')
              if path.suffix in ('.py', '.sh')}
    after = {path.name: path.read_bytes() for path in (raw / 'control').glob('c6c-*')
             if path.suffix in ('.py', '.sh')}
    if not before.keys() <= after.keys():
        raise ValueError('Prior control file removed')
    changed_controls = {name for name, data in after.items() if data != before.get(name)}
    if not changed_controls:
        raise ValueError('No controller correction')
    parts = ['# C6c fix1 inert-controller scoped diff\n', 'Native pair unchanged, same GitBASE37d056f.\n']
    for name in sorted(changed_controls):
        parts.extend(difflib.unified_diff(before.get(name, b'').decode().splitlines(True), after[name].decode().splitlines(True),
                     fromfile='C6c-reviewed-control/' + name, tofile=str(raw / 'control' / name), n=10))
    summary = dict(result)
    summary['preservation'] = {key: value for key, value in result['preservation'].items() if key != 'new_paths'}
    parts.extend(['\n# Root unchanged-source/preservation audit\n', json.dumps(summary, indent=2), '\n'])
    output = plan / 'task-5e3c6c-fix1-review-package.diff'
    output.write_text(''.join(parts))
    print(json.dumps(dict(sources=changed, controls=sorted(changed_controls), review_package=str(output),
                         bytes=output.stat().st_size, sha256=hashlib.sha256(output.read_bytes()).hexdigest())))


if __name__ == '__main__':
    main(sys.argv[1:])
