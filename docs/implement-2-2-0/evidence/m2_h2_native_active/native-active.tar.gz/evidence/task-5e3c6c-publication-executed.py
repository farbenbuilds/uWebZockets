"""Publish the reviewed active-shutdown source delta and bounded evidence."""
import hashlib
import json
import runpy
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def authority(plan):
    path = Path('docs/implement-2-2-0/evidence/m2_h2_native_disconnect/native-disconnect.tar.gz')
    require(sha(path.read_bytes()) == 'a699c83b373b1ed0c4d976a179ac4d2d7c9453344211e87ce1d6b89fc1f4a4b8', 'Published C6b identity')
    with tarfile.open(path, 'r:gz') as archive:
        parent = {member.name: archive.extractfile(member).read() for member in archive if member.isfile()}
    helper = plan / 'task-5e3c6b-publication.py'
    require(helper.read_bytes() == parent['evidence/' + helper.name], 'Published bridge differs')
    bridge = runpy.run_path(str(helper))['authority'](plan)[1]
    return parent, bridge


def sources(source, parent, audit):
    baseline = {name.removeprefix('source/current/'): data for name, data in parent.items() if name.startswith('source/current/')}
    actual = {path.name: path.read_bytes() for path in source.glob('*.py')}
    require(actual.keys() == baseline.keys() and len(actual) == 7, 'Native module inventory')
    result = {}
    for name, data in actual.items():
        row = dict(size=len(data), sha256=sha(data))
        if name in audit['sources']:
            require(row == {key: audit['sources'][name][key] for key in ('size', 'sha256')}, 'Reviewed source differs')
        else:
            require(data == baseline[name], 'Unchanged source differs')
        result[name] = row
    return actual, baseline, result


def environment(data, file):
    path = '/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native'
    controls = ('PYTHONDONTWRITEBYTECODE=1\0PYTHONHASHSEED=0\0PYTHONPATH=' + path + '\0').encode()
    pending = ('UWZ_PENDING_SOURCE_MANIFEST=' + str(file.parent.resolve() / 'c6c-pending.sha256') + '\0').encode()
    require(data in (controls, controls + pending), 'Unexpected new environment controls')


def verify_runs(source, current):
    raw = source / 'evidence/native-transport'
    for label in ('c6c-final-normal', 'c6c-final-optimized', 'c6c-fix1-inert-normal', 'c6c-fix1-inert-optimized'):
        run = raw / label
        require((run / 'status').read_text().strip() == '0', 'Terminal source run failed')
        for name in ('native_transport.py', 'test_native_transport.py'):
            require(sha((run / 'source' / name).read_bytes()) == current[name]['sha256'], 'Executed native source differs')
        rows = [json.loads(line) for line in (run / 'stdout').read_text().splitlines() if line.startswith('{')]
        if 'inert' in label:
            require(len(rows) == 1 and len(rows[0]['helper_dependency_closure']) == 31 and rows[0]['shared_canonical_identity'] is True, 'Guarded cold-import evidence differs')
            require(set(rows[0]['native_inventory']) == {name.removesuffix('.py') for name in current} and
                    max(rows[0]['nesting'].values()) <= 3 and rows[0]['import_empty_foreign_inert'] is True, 'Inert inventory or bounds differ')
        else:
            require(len(rows) == 2 and rows[0]['groups'] == 32 and rows[1]['c6c_groups'] == 19, 'Focused source groups differ')
            require(all(row['source_only'] is True and row['native_executed'] is False for row in rows), 'Source-run qualification differs')


def root_records(plan):
    names = [
        'task-5e3c6c-brief.md', 'task-5e3c6c-plan-report.md', 'task-5e3c6c-report.md',
        'task-5e3c6c-review-report.md', 'task-5e3c6c-fix1-review-report.md',
        'task-5e3c6c-review-package.diff', 'task-5e3c6c-fix1-review-package.diff',
        'task-5e3c6c-root-audit.py', 'task-5e3c6c-root-audit-executed.py', 'task-5e3c6c-root-audit-code.sha256',
        'task-5e3c6c-root-audit.json', 'task-5e3c6c-root-before-fix1-audit.json',
        'task-5e3c6c-fix1-audit.py', 'task-5e3c6c-fix1-audit-executed.py', 'task-5e3c6c-fix1-audit-code.sha256',
        'task-5e3c6c-root-fix1-audit.json', 'task-5e3c6c-root-audit-inputs.json', 'task-5e3c6c-root-fix1-inputs.json',
        'task-5e3c6c-root-repository-gates.md', 'task-5e3c6c-root-runtime-cache-created.txt',
        'task-5e3c6c-root-cache-probe.h', 'task-5e3c6c-root-cache-probe-input.sha256',
        'task-5e3c6c-root-final-graph-inputs.json', 'task-5e3c6c-root-final-graph-command.sh',
        'task-5e3c6c-publication.py', 'task-5e3c6c-publication-executed.py',
        'task-5e3c6c-publication-code.sha256', 'task-5e3b8a-restore-inputs.py']
    stems = ('root-audit', 'root-fix1-audit', 'root-format', 'root-conventions', 'root-version', 'root-docs',
             'root-dependencies', 'root-dependencies-online', 'root-unit', 'root-unit-online', 'root-unit-final',
             'root-cache-probe', 'root-cache-probe-online', 'root-final-graph')
    names.extend('task-5e3c6c-' + stem + '.' + suffix for stem in stems for suffix in ('stdout', 'stderr', 'exit'))
    return {'evidence/' + name: (plan / name).read_bytes() for name in names}


def collect(plan, source, parent, audit):
    actual, baseline, current = sources(source, parent, audit)
    members = {name: data for name, data in parent.items() if name.startswith('reference/')}
    members.update({'source/current/' + name: data for name, data in actual.items()})
    members.update({'baseline/' + name: data for name, data in baseline.items()})
    coordinator = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/coordinator.py').read_bytes()
    require(coordinator == parent['source/canonical/coordinator.py'], 'Accepted coordinator changed')
    members['source/canonical/coordinator.py'] = coordinator
    record = json.loads(parent['SOURCE_AUTHORITY.json'])
    record.update(scope='C6c active hooks and live receipts; source authority only', native_sources=current,
                  canonical_sources_unchanged=46, native_runtime_authority=False)
    members['SOURCE_AUTHORITY.json'] = (json.dumps(record, indent=2) + '\n').encode()
    raw = source / 'evidence/native-transport'
    for name in audit['preservation']['new_paths']:
        require(name.startswith(('c6c-', 'control/c6c-')), 'New raw evidence scope')
        path = raw / name
        require(path.is_file() and not path.is_symlink(), 'Raw evidence type')
        data = path.read_bytes()
        if path.name == 'environment.nul':
            environment(data, path)
        members['raw/native-transport/' + name] = data
    members.update(root_records(plan))
    verify_runs(source, current)
    require((plan / 'task-5e3c6c-root-unit-final.exit').read_text().strip() == '0', 'Repository unit gate failed')
    require('Build Summary: 22/22 steps succeeded; 852/852 tests passed' in
            (plan / 'task-5e3c6c-root-unit-final.stderr').read_text(), 'Repository unit count differs')
    return members, current


def build(plan, source, folder):
    parent, bridge = authority(plan)
    audit = json.loads((plan / 'task-5e3c6c-root-fix1-audit.json').read_text())
    members, current = collect(plan, source, parent, audit)
    api = bridge['published_api'](plan, 'task-5e3c1-build-publication.py')
    safe = {}
    for name, data in members.items():
        api['add'](safe, name, data, {})
    folder.mkdir(parents=True, exist_ok=True)
    output = folder / 'native-active.tar.gz'
    inventory = api['write_archive'](output, safe)
    manifest = dict(scope='C6c active shutdown, failure cleanup and live receipts; source-only delta',
                    base_commit='37d056f7e31bf29e845f5d960d8cc36134703981', archive=output.name,
                    archive_bytes=output.stat().st_size, archive_sha256=sha(output.read_bytes()),
                    safe_regular_utf8_members=len(safe) + 1, inventory_entries=len(inventory), current_native_sources=current,
                    parent_archive_sha256='a699c83b373b1ed0c4d976a179ac4d2d7c9453344211e87ce1d6b89fc1f4a4b8',
                    raw_files_embedded=len(audit['preservation']['new_paths']), prior_safe_transport_paths_preserved=11949,
                    canonical_sources_unchanged=46, historical119_restoration_authority_unchanged=True,
                    private_original_environments_included=False, tool_snapshot_copies_added=0,
                    focused_groups=51, original_groups=32, new_active_groups=19, guarded_initial_helper_closure=31,
                    prior_inert_evidence_superseded='Earlier coordinator preimport reduced guarded closure to10; fix1 cold-import regression and two modes supersede it',
                    repository_unit_tests_passed=852, repository_build_steps=22, repository_gate_scope='Tracked HEAD37d056f, not reconstructed native candidate',
                    repository_gate_limits='Expected negative diagnostics retained; filesystem and missing temporary cache target repaired without source/test changes',
                    reconstructed_candidate_compiled=False, combined_native_executed=False,
                    repository_native_compiled=True, repository_native_tests_executed=True,
                    complete_provider=False, milestone_complete=False)
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({key: manifest[key] for key in ('archive_sha256', 'archive_bytes', 'safe_regular_utf8_members', 'raw_files_embedded')}))


def audit_publication(plan, source, folder):
    parent, bridge = authority(plan)
    audit = json.loads((plan / 'task-5e3c6c-root-fix1-audit.json').read_text())
    expected, current = collect(plan, source, parent, audit)
    api = bridge['published_api'](plan, 'task-5e3c1-publication-audit.py')
    manifest = json.loads((folder / 'manifest.json').read_text())
    output = folder / manifest['archive']
    require(output.stat().st_size == manifest['archive_bytes'] and sha(output.read_bytes()) == manifest['archive_sha256'], 'Archive identity')
    contents = api['read_archive'](output)
    require(contents == expected and len(contents) == manifest['inventory_entries'], 'Complete published delta differs')
    require(current == manifest['current_native_sources'] and len(contents) + 1 == manifest['safe_regular_utf8_members'], 'Manifest source/count differs')
    for data in contents.values():
        data.decode('utf-8')
    check = runpy.run_path(str(plan / 'task-5e3c1-prepare-review.py'))['root_check']
    helpers = {name: check((plan / name).resolve()) for name in ('task-5e3c6c-root-audit.py', 'task-5e3c6c-fix1-audit.py', 'task-5e3c6c-publication.py')}
    docs = Path('docs/implement-2-2-0')
    files = [docs / 'README.md', docs / 'm2_request_streaming.md', docs / 'm2_h2_native_active.md', folder / 'README.md', folder / 'manifest.json', output]
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=output.stat().st_size,
                  safe_regular_utf8_members=len(contents) + 1, inventory_entries=len(contents), raw_files_embedded=manifest['raw_files_embedded'],
                  helpers=helpers, local_links_checked=api['verify_links'](files),
                  delivery_files={str(path): dict(size=path.stat().st_size, sha256=sha(path.read_bytes())) for path in files},
                  combined_native_executed=False, complete_provider=False, milestone_complete=False)
    (plan / 'task-5e3c6c-root-publication-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('helpers', 'delivery_files')}))


def main(arguments):
    if arguments not in (['--build'], ['--audit']):
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/combined-native')
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_native_active')
    if arguments == ['--build']:
        build(plan, source, folder)
        return
    audit_publication(plan, source, folder)


if __name__ == '__main__':
    main(sys.argv[1:])
