DONE_WITH_CONCERNS. The assigned C6c source slice is implemented and frozen for Root's independent review. Real provider/native acceptance remains required.

Only `native_transport.py` and `test_native_transport.py` changed under `.uwz-work/evidence/h2-streaming/combined-native/` (`N`). New controls/proof are exclusively `c6c-*` under `N/evidence/native-transport/` (`E`), plus this requested report. No C4, canonical S46, inventory, product, dependency, Git or publication edits.

Terminal source SHA256:

```text
1ed1d45eab45820ba5e619aaa10525ad5e77e092ac3478c131bc15682e113d1b  native_transport.py
09232d07d0701239b9f3b1284ce89a869225ef7b13dd18a80f4ca886b3479094  test_native_transport.py
```

`E/c6c-terminal.sha256` records both sources and all six final controls/manifests. Baseline source authentication is `E/c6c-freeze-before`: seven sources match accepted C6b archive `a699c83b373b1ed0c4d976a179ac4d2d7c9453344211e87ce1d6b89fc1f4a4b8`; coordinator remains `6585ad2323ce38a75948c7c365ceb7b9589c06e1c6010ae01ba35de0f11e6b32`.

The four interfaces are:

```text
signal(state, owned_signal, context, deadline) -> SignalFacts
termination(state, context, deadline) -> TerminationFacts
fail_transport(state, primary_error) -> None
transport_receipt(state, connection_identity) -> TransportReceipt
```

`OwnedSignal` receives the exact retained child, client handle and original deadline. Its named tuple result is `(facts, child, handle, prerequisites, operation, returned_tick)`. Prerequisites bind `(pid, start_identity, listener, watcher, open_handle, observed_tick)`; operation binds `('SIGTERM', pid, start_identity, watcher, open_handle, operation_tick, result)`, requiring exact `None` result and ordered bounded ticks. A facts-only dictionary rejects. The callback must supply authentic fresh prerequisite observations and actual operation evidence; source tuples do not independently prove OS authenticity or watcher installation.

Active hooks require the earlier canonical post-open `bind_context` registration and retain context/component/callback identities. Signal freezes canonical counts and C4 checkpoint before effects, checks live ownership/capture before the operation, retains actual evidence and immutable canonical facts, then validates capture/time. One-shot signal failure never permits retry. Closing uses retained authorization; no PID, `/proc` or listener observation occurs after successful signaling. Primitive receive remains only the originally bound receive operation, including valid flattened `partial` bindings.

Canonical shutdown alone marks signal and begins/finishes termination. C4 activation/drain retain original deadlines, 8192/read, 65536 closing bytes, 4096 frames, case/final residual bounds and one terminal-only probe. Successful local terminal observation requires normal handle close with exact `None`, closure marked before postchecks, and capture/time checks under unchanged grace. Cleanup is one-shot, keeps first exception and secondary cleanup exceptions separately, and never creates release facts.

`execute_active` demonstrates the actual caller boundary around `coordinator.run`: call `fail_transport` then bare-reraise. Its real serialized shutdown peer exercises pre-signal receive/preparation/clock/parser failures and post-signal failures. The future runtime provider must install the same boundary.

Receipts resolve unique actual history identities and reject transport failure or missing normal release. Ordinary/disconnect seal the original observer once, then revalidate live health, operation, counters and exact objects. Strict disconnect keeps original TLS callback anchors separate from transferred raw ownership. Active receipts require canonical finish plus normal close and fetch C4 `local_receipt` afresh; they never seal the poisoned active observer. `aggregate_live` calls these validators again, rejects missing/duplicate/reordered identities and compares successful canonical totals with ordinary seals plus the active checkpoint prefix. EOF/TLS closing deltas, bytes/frames and debt remain separate; canonical transport abandonment preserves outstanding debt rather than refunding/resetting it.

Four genuine behavioral RED runs exited 1 before fixes:

- `c6c-red-cleanup`: repeated cleanup retried close and duplicated secondary errors.
- `c6c-red-receipt-anchor`: copied ordinary connection dictionaries escaped identity validation.
- `c6c-red-signal-anchor`: mutated receive keywords permitted signaling before rejection.
- `c6c-red-signal-reentrancy`: swallowed prerequisite receive failure permitted signaling.

All raw failures and exercised versions remain. Other failures are explicitly separate: `c6c-api-absence` lacked new APIs; `c6c-green-active-1` used wrong canonical summary key; `c6c-expanded-2` contained an overstrict primitive-partial validator; `c6c-expanded-3` wrongly expected a new ValueError rather than the retained primary; `c6c-expanded-4` wrongly expected canonical abandonment to reset debt. Corrected tests require exact primary identity and preserved debt. No threshold or accepted test was weakened.

Define from repository root:

```sh
N=.uwz-work/evidence/h2-streaming/combined-native
C=$N/evidence/native-transport/control
R=$C/c6c-run.sh
X=$C/c6c-execute.py
P=/home/codespace/.python/current/bin/python3
```

Exact final commands:

```sh
env -i PATH=/usr/bin:/bin bash "$R" c6c-final-normal "$P" -B -S "$X" "$N/test_native_transport.py" --check
env -i PATH=/usr/bin:/bin bash "$R" c6c-final-optimized "$P" -B -S -O "$X" "$N/test_native_transport.py" --check
env -i PATH=/usr/bin:/bin bash "$R" c6c-terminal-inert-normal "$P" -B -S "$X" "$N/test_native_imports.py" --check
env -i PATH=/usr/bin:/bin bash "$R" c6c-terminal-inert-optimized "$P" -B -S -O "$X" "$N/test_native_imports.py" --check
env -i PATH=/usr/bin:/bin bash "$R" c6c-preservation "$P" -B -S "$X" "$C/c6c-preserve.py" --after
env -i PATH=/usr/bin:/bin bash "$R" c6c-freeze-terminal "$P" -B -S "$X" "$C/c6c-freeze.py" --after
```

All six statuses are `0`; raw stdout/stderr/status, argv, explicit safe settings, interpreter hash, fresh restoration receipt and code/control snapshots are in identically named `E` directories. Focused normal and `-O` each retain:

```text
{"groups": 32, "source_only": true, "native_executed": false, "c6b_c6c_complete": false}
{"c6c_groups": 19, "source_only": true, "native_executed": false}
Exit status: 0
```

Preservation:

```text
{"public_paths": 6482, "private_paths_never_read": 25, "exact_additive_inventory": true}
{"native_sources": 7, "canonical_sources": 46, "safe_proof_paths": 11949, "private_originals_read": 0}
```

Both terminal inert runs retain seven sources, nesting at most three, shared canonical identity and empty/foreign import/main inertness. Earlier `c6c-final-inert-*` controls preimported native modules for authentication; terminal controls instead authenticate their resolved source paths without preimport and verify imported coordinator before behavior, preserving the original effect-guarded dependency import coverage. All control versions remain available.

Every dependent Python operation used pinned `-B -S` interpreter SHA `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`, exact six-part PYTHONPATH, bytecode disabled, seed 0 and fresh unchanged 119-entry restoration before snapshots/execution in the same controlled shell. Accepted extension and pending pair hashes remain separate authority. No ambient environment dump or private-original read/copy/hash occurred. Graphify query is retained at `c6c-query`; existing tool closure is hash-referenced, never recopied. Root owns final AST update.

Self-review: transport 671 lines; tests 1473 lines. The existing 32 groups remain intact; 19 active groups share one explicit scripted fixture and focused fault controls. A mechanical split would add inventory/authority coupling without removing concepts, so no new module was proposed. Independent review remains mandatory.

No compiler/server/socket/SSLContext/real clock/process-under-test/network/install operations or old C4/C5/S46/all40 reruns occurred in this slice. Root's parallel repository gates are separate evidence. Real signal/watcher authenticity, exit/reap/listener disappearance, completed capture/C5 post-validation, file/key cleanup, runtime-provider integration, rebuilt native candidates, native all40 and all remaining milestones remain REQUIRED.

Fix round 1/5 — Important1 corrected, DONE_WITH_CONCERNS pending scoped re-review.

The review finding is valid: `c6c-execute.py` still imported coordinator before the inert target installed its effect guards. My preceding claim that terminal controls preserved guarded dependency imports was incorrect. Those runs retained only ten initially cold helper modules; their raw records remain immutable and are superseded for inert coverage by the fix-round runs below.

Only `control/c6c-execute.py` changed. It now authenticates all three resolved paths/hashes using `find_spec` without importing any project module, rejects preloaded project modules for the inert target, executes the unchanged guarded target, then validates actual `sys.modules` paths/hashes afterward. Coordinator is never imported by the wrapper. The frozen native pair retains the hashes above; all seven native sources and 46 canonical sources are unchanged. `test_native_imports.py` is unchanged.

Before editing, `c6c-fix1-freeze-before` retained identities for 53 sources and 3,321 prior C6c paths. The original control is preserved verbatim as `control/c6c-fix1-original-execute.py` (SHA `78e8d1567de63787537a9f8fcabff0d66e1f5cc15477a151aeb2a373aa540c1d`). The new cold-import regression intercepts both import routes and rejects cold project imports unless the actual inert socket guard is installed; it performs no socket operation. Against the original control, `c6c-fix1-red-cold-import` exited 1 with:

```text
RuntimeError: unguarded cold project import: coordinator
Exit status: 1
```

Using the variables above, exact regression and terminal commands were:

```sh
env -i PATH=/usr/bin:/bin bash "$R" c6c-fix1-red-cold-import "$P" -B -S "$C/c6c-fix1-cold-import.py"
env -i PATH=/usr/bin:/bin bash "$R" c6c-fix1-green-cold-import "$P" -B -S "$C/c6c-fix1-cold-import.py"
env -i PATH=/usr/bin:/bin bash "$R" c6c-fix1-inert-normal "$P" -B -S "$X" "$N/test_native_imports.py" --check
env -i PATH=/usr/bin:/bin bash "$R" c6c-fix1-inert-optimized "$P" -B -S -O "$X" "$N/test_native_imports.py" --check
env -i PATH=/usr/bin:/bin bash "$R" c6c-fix1-preservation "$P" -B -S "$X" "$C/c6c-fix1-preserve.py" --after
```

The four post-fix statuses are `0`. Both inert modes report the complete 31-module initial helper closure, seven-source inventory, nesting at most three and shared canonical identity, followed by:

```text
actual_imported_source_identity: PASS (3 modules)
Exit status: 0
```

The regression reports guarded cold imports for adapter, cases, catalogue, coordinator, model, native_closing, native_transport, request_credit and shutdown_cases. Preservation reports:

```text
{"unchanged_source_files": 53, "retained_prior_c6c_paths": 3321, "allowed_control_changes": 1, "private_originals_read": 0}
```

Full output, status, argv/settings, restoration receipts and exercised control versions are under the identically named `E/c6c-fix1-*` directories. Each operation used the unchanged controlled runner and fresh pinned restoration before snapshots/execution. New control SHA is `6881f73e960b2b60644234b5914f3fee7ee26a83790535af833882dfd3b13528`; all final code/control hashes are in `E/c6c-fix1-terminal.sha256`.

No source tests, old C4/C5/S46/all40 suites, native operations, Git or publication work were repeated. Source boundaries remained cold until the existing effect guards were active. Real provider/native concerns remain unchanged.
