### Spec compliance

**Issues found.** The terminal inert checks do not preserve the claimed guarded dependency-import coverage.

- **Important — [c6c-execute.py:31](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native/evidence/native-transport/control/c6c-execute.py:31):** The wrapper imports `coordinator` before [test_native_imports.py:59](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native/test_native_imports.py:59) installs its effect guards. Coordinator imports `adapter`, `cases`, `catalogue`, `model`, `request_credit`, and `shutdown_cases`, along with their transitive dependencies, outside those guards. An import-time socket, process, clock, or file effect in that closure could therefore escape the inert check while it reports success. Authenticate the resolved coordinator source without importing it before the guard, validate the actual imported module during or after guarded execution, and rerun both terminal inert modes.

### Task quality

**Needs fixes** because the required inert-import evidence has a coverage gap. The active transport implementation separates primitive receive provenance, signal authorization, closing, and normal release; no additional actionable source finding was identified.

The review package output was truncated mid-function, so the affected source was read directly to complete the review. No tests were rerun. Real provider ownership and signal authenticity, process exit and reap, capture completion, runtime integration, and native acceptance remain unverified by this source-only slice.
