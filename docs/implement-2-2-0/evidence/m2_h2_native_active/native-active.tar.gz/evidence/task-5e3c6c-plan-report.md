C6c should remain in `native_transport.py`, its focused tests and evidence controls. Use accepted C6a plus C6b’s declared unwrap contract; no new parser, client, observer module or C4 changes.

**Minimal interfaces and state**

Add:

```text
signal(state, owned_signal, context, deadline) -> SignalFacts
termination(state, context, deadline) -> TerminationFacts
fail_transport(state, primary_error) -> None
transport_receipt(state, connection_identity) -> TransportReceipt
```

Bind the first two with `partial` for existing coordinator hooks. Keep the seven-key connection unchanged and preserve C6b’s conditional `unwrap` operation schema.

Define `OwnedSignal` as an explicitly supplied callback accepting the retained child binding, exact client handle and deadline. It returns named `SignalEvidence`: canonical signal facts plus bounded authorization evidence tying the operation to the child/PID/start/listener, installed watcher and open client. Its contract requires fresh prerequisite observations immediately before the actual signal operation. A caller-created `owned=True` or successful-looking fact dictionary is insufficient evidence of that operation.

Extend each active connection record with signal evidence/deadline, frozen canonical counts, terminal facts, normal-close facts and receipt-validation anchors. Add a one-shot failure-cleanup latch so inner cleanup and the outer caller boundary cannot repeatedly close or accumulate unbounded errors.

**Signal ordering**

At active signal entry, validate current connection/context identities and the supplied clipped grace deadline. Retain canonical pre-teardown counts, then call unchanged C4 `freeze_checkpoint` before signaling effects.

Revalidate live ownership/capture health and invoke `owned_signal`. Retain its actual result and authorization evidence, validate exact canonical signal facts, then check capture health and time before returning. Never require continued process/listener existence after successful signaling. A signal exception, malformed result or post-operation expiry permanently fails transport acceptance; actual signal effects do not authorize a retry.

The canonical shutdown handler alone validates facts, marks the stage and calls `wire.begin_termination`.

**Termination and preparation phases**

`termination` requires the retained successful signal, identical deadline/context/connection/observer and canonical post-signal state. Call unchanged C4 `activate`, then `drain_closing` through the exact wrapped receive callback.

Extend the existing `prepare` helper with two explicit branches:

- Ordinary: existing live PID/start/listener and capture checks.
- Authorized closing: retained child/socket/callback identities, successful signal authorization, C4 lifecycle predicates, capture health and unchanged grace/case/whole deadlines. Never call ordinary live ownership here.

Retain the exact primitive receive partial. It performs only `recv`; preparation, ownership, capture and clock exceptions must remain outside receive-origin provenance. Extend `read_clock` to respect the active effective deadline without adding effects or fresh budgets.

Keep C4’s 8192-byte primitive reads, 65536 closing bytes, 4096 frames, residual read allowance and terminal-probe rules unchanged. Qualified receive-origin TLS EOF remains local evidence with ordinary observer poison/seal failure intact.

**Failure and successful socket closure**

The provider/caller must place a failure boundary around canonical execution:

```python
try:
    result = coordinator.run(...)
except BaseException as primary:
    fail_transport(state, primary)
    raise
```

`fail_transport` retains the exact first exception and performs one-shot cleanup of the currently owned handle, retaining exact cleanup exceptions separately. It must cover active pre-signal receive failures, preparation/clock/parser failures and exceptions after successful signaling. It does not replace C4 callbacks or add policy inside primitive receive. Cleanup never creates release or acceptance facts. Provider integration and tests must demonstrate this boundary; merely exposing the helper is insufficient.

After accepted terminal EOF/TLS EOF, `termination` normally closes the retained client handle using the existing supplied close operation—without another send, receive or unwrap. Require `None`, mark actual closure before subsequent checks, and recheck capture/time under the original grace deadline. Only then retain normal-close facts and return C4’s narrow termination facts. A close/check failure makes outer transport acceptance permanently false even if C4’s local terminal receipt remains valid.

The canonical handler alone subsequently calls `wire.finish_termination`. No normal-close success may be inferred from failure cleanup.

**Receipts and accounting**

Reuse C6a’s bounded `history/current`, original/wrapped connections, observer and separate `receive_state`. Reuse `sample`, `residual`, `owned`, `capture`, `remember_failure` and `cleanup`; extend cleanup only for its one-shot latch. C6b continues owning strict-disconnect release facts.

`transport_receipt` must resolve one unique actual history identity and require successful resource release and no outer failure:

- Ordinary/disconnect: seal the original observer once, retain its immutable receipt and operation anchor, and revalidate live observer health, bindings and unchanged operation count on later consumption.
- Active: require normal closure and completed canonical termination; return the original checkpoint plus a freshly fetched `native_closing.local_receipt`. Never seal the poisoned active observer or treat a cached closing tuple as current acceptance.

Final provider aggregation must call this live validator again for every expected connection, reject missing/duplicate identities, and compare ordered identities against the successful canonical result.

Compare canonical published counts against ordinary sealed receipts plus the active **checkpoint prefix**. Keep closing wrapped attempts, primitive attempts/returns, boundary returns, bytes, frames and debt-before/debt-after separate. Do not add closing deltas to frozen coordinator totals, reset counters, refund abandoned debt or confuse pre-finish debt observations with canonical abandonment.

**Acceptance tests and remaining scope**

Use the real shutdown handler with scripted operations: EOF and qualified TLS EOF; identical exceptions from preparation/clock/parser; failed signal; immediate legitimate process/listener disappearance with zero closing live-ownership calls; pre-signal receive cleanup; exact primary/cleanup identities; normal-close failure; duplicate activation and postterminal I/O; stale receipt rejection; original deadlines/budgets; one canonical begin/finish; and frozen-prefix versus closing-count algebra.

Run focused normal/`-O`, additive inert checks and preservation only. Real ownership authenticity, watcher installation, exit/reap, listener disappearance, completed capture/C5 validation and file/key cleanup remain external conjuncts. Forced cleanup always prevents overall acceptance. No implementation or tests were performed in this planning pass.
