"""Audit active-transport source changes against the pushed source authorities."""
import ast
import difflib
import hashlib
import json
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def archive(folder, filename, digest):
    path = Path('docs/implement-2-2-0/evidence') / folder / filename
    require(sha(path.read_bytes()) == digest, 'Published archive identity: ' + filename)
    with tarfile.open(path, 'r:gz') as stream:
        return {member.name: stream.extractfile(member).read() for member in stream if member.isfile()}


def nesting(node, depth=0):
    controls = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.With,
                ast.AsyncWith, ast.Try, ast.TryStar, ast.Match)
    level = depth + int(isinstance(node, controls))
    return max([level] + [nesting(child, level) for child in ast.iter_child_nodes(node)])


def preserve(source, parent, earlier):
    raw = source / 'evidence/native-transport'
    expected = {}
    for authority in (earlier, parent):
        expected.update({name.removeprefix('raw/native-transport/'): dict(size=len(data), sha256=sha(data))
                         for name, data in authority.items() if name.startswith('raw/native-transport/')})
    references = json.loads(earlier['TOOL_SNAPSHOT_REFERENCES.json'])['omitted_members']
    expected.update({name.removeprefix('raw/native-transport/'): dict(size=row['size'], sha256=row['sha256'])
                     for name, row in references.items()})
    require(len(expected) == 11949, 'Prior safe transport authority count')
    for name, row in expected.items():
        path = raw / name
        require(not path.is_symlink(), 'Prior evidence symlink')
        data = path.read_bytes()
        require(len(data) == row['size'] and sha(data) == row['sha256'], 'Prior evidence changed: ' + name)
    paths = list(raw.rglob('*'))
    require(not any(path.is_symlink() for path in paths), 'Evidence symlink')
    actual = {path.relative_to(raw).as_posix() for path in paths if path.is_file()}
    added = actual - expected.keys()
    require(expected.keys() <= actual, 'Prior evidence missing')
    require(all(name.startswith(('c6c-', 'control/c6c-')) for name in added), 'New evidence scope')
    return dict(prior_safe_transport_paths=len(expected), unchanged=True,
                private_original_environments_read=0, new_evidence_paths=len(added), new_paths=sorted(added))


def sources(source, parent):
    baseline = {name.removeprefix('source/current/'): data for name, data in parent.items()
                if name.startswith('source/current/')}
    actual = {path.name: path.read_bytes() for path in source.glob('*.py')}
    require(actual.keys() == baseline.keys() and len(actual) == 7, 'Native module inventory')
    changed = {name for name in actual if actual[name] != baseline[name]}
    require(changed == {'native_transport.py', 'test_native_transport.py'}, 'Native change scope')
    rows = {}
    for name in changed:
        tree = ast.parse(actual[name])
        require(nesting(tree) <= 3, 'Changed native source nesting')
        require(not any(isinstance(node, (ast.ClassDef, ast.Assert, ast.Global, ast.Nonlocal)) for node in ast.walk(tree)), 'Changed native source structure')
        rows[name] = dict(size=len(actual[name]), sha256=sha(actual[name]), maximum_nesting=nesting(tree))
    return actual, baseline, rows


def canonical(parent):
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    expected = {name.removeprefix('reference/combined/'): data for name, data in parent.items()
                if name.startswith('reference/combined/') and name.endswith('.py') and name.count('/') == 2}
    expected['coordinator.py'] = parent['source/canonical/coordinator.py']
    actual = {path.name: path.read_bytes() for path in source.glob('*.py')}
    require(len(expected) == 46 and actual == expected, 'Accepted canonical source differs')
    return dict(modules=46, unchanged=True, coordinator_sha256=sha(actual['coordinator.py']))


def review(plan, source, actual, baseline, result):
    parts = ['# C6c active shutdown / cleanup / live receipts source review\n',
             'BASE/current HEAD37d056f7e31bf29e845f5d960d8cc36134703981.\n',
             'Ignored source delta, Root commits after independent review/publication.\n']
    for name in ('test_native_transport.py', 'native_transport.py'):
        parts.extend(difflib.unified_diff(baseline[name].decode().splitlines(True), actual[name].decode().splitlines(True),
                     fromfile='C6b/' + name, tofile=str(source / name), n=10))
    controls = source / 'evidence/native-transport/control'
    paths = sorted(path for path in controls.glob('c6c-*') if path.suffix in ('.py', '.sh'))
    paths.append(Path(__file__))
    for path in paths:
        parts.extend(difflib.unified_diff([], path.read_text().splitlines(True), fromfile='/dev/null', tofile=str(path), n=10))
    summary = dict(result)
    summary['preservation'] = {key: value for key, value in result['preservation'].items() if key != 'new_paths'}
    parts.extend(['\n# Root preservation/structure\n', json.dumps(summary, indent=2), '\n'])
    output = plan / 'task-5e3c6c-review-package.diff'
    output.write_text(''.join(parts))
    return dict(path=str(output), bytes=output.stat().st_size, sha256=sha(output.read_bytes()))


def main(arguments):
    if arguments != ['--audit']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/combined-native')
    parent = archive('m2_h2_native_disconnect', 'native-disconnect.tar.gz', 'a699c83b373b1ed0c4d976a179ac4d2d7c9453344211e87ce1d6b89fc1f4a4b8')
    earlier = archive('m2_h2_native_connection', 'native-connection.tar.gz', 'c0bdf2032aedfeea034e08edc4b2ab170f122931df10e419bc9f12a57f9f96f9')
    actual, baseline, changed = sources(source, parent)
    result = dict(preservation=preserve(source, parent, earlier), sources=changed,
                  unchanged_native_sources=5, canonical=canonical(parent),
                  native_executed=False, complete_provider=False, milestone_complete=False)
    (plan / 'task-5e3c6c-root-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    package = review(plan, source, actual, baseline, result)
    print(json.dumps(dict(sources=changed, preserved=result['preservation']['prior_safe_transport_paths'],
                         new_evidence=result['preservation']['new_evidence_paths'], review_package=package)))


if __name__ == '__main__':
    main(sys.argv[1:])
