# Repository gates during C6c source implementation

Scope: the tracked branch at `37d056f7e31bf29e845f5d960d8cc36134703981`.
Formatting produced no tracked source changes. The private C6c Python transport
is implemented and source-tested separately. These repository commands do not
compile the reconstructed C2 candidate or establish combined native acceptance.

```sh
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig version
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig fmt src builds examples tests fuzz
sh scripts/check_conventions.sh
sh scripts/check_release_version.sh
sh scripts/check_docs.sh
sh scripts/check_dependency_forks.sh
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig build test -j2 --cache-dir /tmp/uwz-c6c-repository-gates/cache --global-cache-dir /tmp/uwz-c6c-repository-gates/global --summary all
```

Each command has separate `task-5e3c6c-root-{format,conventions,version,docs,
dependencies,dependencies-online,unit}.{stdout,stderr,exit}` records. The first
default dependency check could not resolve the existing public libxev pin in
the sandbox. The same unchanged command then passed with network access; no
pin, ledger or gate changed. This is the default provenance check, without an
additional `--exact-mirrors` claim.

The existing `.zig-cache` symlink targets `/tmp/uwz-original-zig-cache`; default
build help reported `NotDir`. The explicit cache flags avoid changing that
historical path and keep compilation off the workspace filesystem. Separate
pre-use absence proof was not captured for the new cache paths; this record is
not an empty-cache or second-machine reproduction claim.

Zig version is `0.16.0`; release metadata remains `2.1.6`. Sanitizer, MSan,
fuzz, package, protocol, platform, native candidate and final release evidence
remain required at their appropriate later gates. Inspect each terminal status
before claiming its command passed.

The first unit attempt completed with one failing `translate-c` step and
14/22 successful build steps. A separate one-line typedef probe reproduced the
same cache `ReadOnlyFileSystem` error in the sandbox, then succeeded unchanged
outside it. The original probe input is retained with SHA-256
`191513e0fd3346d2a6939c10b44e025519d45eb6f40523dfae472517ec196a2a`.
The unchanged full unit command is retried in `unit-online.*`; no generated C
binding, source, pin or gate is substituted. Zig binary SHA-256 is
`2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c`.

The second attempt compiled all required code, but 105/852 tests crashed while
`std.testing.tmpDir` followed the dangling workspace `.zig-cache` symlink.
Inspection confirmed its `/tmp/uwz-original-zig-cache` target was absent.
Creating only that directory restored the existing link without changing any
tracked file, test, source, pin or threshold.

The third unchanged command (`unit-final.*`) completed with status 0:
22/22 build steps succeeded and 852/852 tests passed, including C API smoke
and the C/C++ checks. Expected negative-path TLS, accept-error and worker-start
diagnostics remain in the raw output; this is not a pristine-stderr claim.
The earlier failures and probe records remain separate and are not rewritten.
