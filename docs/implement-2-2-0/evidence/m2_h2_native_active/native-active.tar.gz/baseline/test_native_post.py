"""Serialized fixture contracts and canonical post facts; no native execution."""
import copy
import json
import sys
import catalogue
import model
import native_post as native
import test_model

NONCE = 'C5_native_7'
CAPACITY = ('config={"max_connections":8,"stream_request_bodies":true,"max_request_line_size":512,'
            '"max_header_size":4096,"max_header_count":80,"max_body_size":256,"max_h2_body_size":4096,'
            '"max_h2_header_block_size":8192,"max_h2_response_header_size":4096,'
            '"max_h2_response_header_count":32,"max_route_params":24,"write_queue_size":65536,'
            '"enable_dev_log":false} request_stride=4608 h2_bytes=123456 h2_stride=123456 slab=987654 router=7654')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def rejects(callback, label):
    try:
        callback()
    except ValueError:
        return
    raise RuntimeError('invalid input accepted: ' + label)


def facts(selection=(), phase='after', *, blocked=3, generation=71, slot=1):
    outputs = model.default_outputs()
    for tag in model.PRODUCERS:
        if tag in selection:
            outputs[tag].update(armed=True, done=True, offset=16777313, sha256=model.PRODUCER_HASH,
                                writes=2049, attempts=2049 + blocked, blocked=blocked, pending=blocked,
                                terminal_attempts=1, terminals=1, invocations=blocked + 1,
                                checks=blocked + 1, after_reuse=int(tag == 'producer_reuse'),
                                binding_index=slot, binding_generation=generation)
    if 'stream_file' in selection:
        outputs['stream_file'].update(reads=4, requested=24593, returned=24593, close_calls=1,
                                      closed_files=1, min_offset=37, max_end=24630, arms=1,
                                      transferred=True, caller_owned=False)
    metrics = model.metrics(selection, phase)
    metrics.update(slot0_active=bool(metrics['active']) and slot == 0,
                   slot1_active=bool(metrics['active']) and slot == 1)
    binding = dict(tag='producer_reuse_next', binding_index=slot, binding_generation=generation + 1)
    if 'producer_reuse' not in selection:
        binding = model.default_binding() if phase == 'after' else None
    return dict(records=test_model.observed(model.records(selection, phase)), metrics=metrics,
                outputs=outputs, binding=binding)


def encoded(value):
    return json.dumps(value, separators=(',', ':'), ensure_ascii=False)


def lines(after, nonce=NONCE, capacity=CAPACITY):
    binding = after['binding']
    result = ['info: H2_CAPACITY ' + capacity, 'info: H2_READY ' + nonce,
              'info: H2_BINDING ' + nonce + ' tag=producer_reuse_next index=' + str(binding['binding_index']) +
              ' generation=' + str(binding['binding_generation'])]
    result.extend('info: H2_RECORD ' + nonce + ' ' + encoded(after['records'][tag]) for tag, *_ in model.BODY_SPECS)
    result.extend('info: H2_OUTPUT ' + nonce + ' ' + encoded(after['outputs'][tag]) for tag in model.PRODUCERS + ('stream_file',))
    result.append('info: H2_DEINIT ' + nonce + ' ' + encoded(after['metrics']))
    return result


def capture(entries):
    return dict(bytes=('\n'.join(entries) + '\n').encode(), overflow=False, error=None, finished=True)


def parse(entries, nonce=NONCE, capacity=CAPACITY):
    return native.parse_capture(capture(entries), nonce, capacity)


def check_valid():
    selections = ((), ('shutdown_idle',), ('empty_headers',), ('shutdown_active',), catalogue.CASES)
    for selection in selections:
        before, after = facts(selection, 'before'), facts(selection)
        original = copy.deepcopy(before)
        parsed = parse(lines(after))
        require(parsed == after, 'serialized fixture changed facts')
        require(native.validate_post(selection, before, parsed) is None, 'comparison result')
        require(before == original, 'comparison mutated before')
    for slot, generation, blocked in ((0, 1, 0), (1, 17, 9), (0, 999999, 23)):
        selection = ('producer_reuse', 'output_pressure_window', 'output_pressure_ready', 'stream_file', 'shutdown_active')
        before = facts(selection, 'before', slot=slot, generation=generation, blocked=blocked)
        after = facts(selection, slot=slot, generation=generation, blocked=blocked)
        native.validate_post(selection, before, parse(lines(after)))
    base = facts()
    noisy = ['bounded diagnostic'] + lines(base)[:2] + ['warning: ordinary'] + lines(base)[2:] + ['done']
    require(parse(noisy) == base, 'bounded unrelated diagnostics')
    for nonce in ('a', 'N' * 32, 'a_B09'):
        require(parse(lines(base, nonce), nonce) == base, 'nonce boundary')
    owned = capture(lines(base))
    snapshot = copy.deepcopy(owned)
    parsed = native.parse_capture(owned, NONCE, CAPACITY)
    parsed['records']['empty_data']['bytes'] = 1
    require(owned == snapshot and base['records']['empty_data']['bytes'] == 0, 'detached parse result')


def check_diagnostics():
    after = facts()
    original = lines(after)
    for diagnostic in ('warning: retrying H2_stream', 'warning: H2_connection',
                       'info: retrying H2_stream', 'warning: preH2_streamSuffix',
                       'H2_stream H2_diagnostics'):
        for index in range(76):
            entries = original[:index] + [diagnostic] + original[index:]
            require(parse(entries) == after, 'unrelated diagnostic at ' + str(index) + ': ' + diagnostic)
    for marker in ('warning: retrying H2_STREAM', 'warning: H2_123', 'warning: H2_',
                   'warning: H2_READYfoo', 'warning: H2_UNKNOWN', 'info: H2_stream',
                   'warning: example info: H2_bad payload',
                   'warning: embeddedH2_RECORD ' + NONCE, 'warning: H2__bad'):
        rejects(lambda: parse(original + [marker]), 'reserved fixture marker: ' + marker)


def check_capture():
    good = capture(lines(facts()))
    for key, value in (('overflow', True), ('overflow', 0), ('error', ''), ('error', 'read failed'),
                       ('finished', False), ('finished', 1), ('bytes', bytearray(good['bytes'])),
                       ('bytes', good['bytes'].decode()), ('bytes', b''), ('bytes', good['bytes'][:-1]),
                       ('bytes', b'\xff\n' + good['bytes']), ('bytes', b'x' * 65537),
                       ('bytes', good['bytes'].replace(b'\n', b'\r\n'))):
        rejects(lambda: native.parse_capture(dict(good, **{key: value}), NONCE, CAPACITY), key + repr(value)[:40])
    for key in good:
        changed = dict(good)
        del changed[key]
        rejects(lambda: native.parse_capture(changed, NONCE, CAPACITY), 'missing capture ' + key)
    rejects(lambda: native.parse_capture(dict(good, extra=0), NONCE, CAPACITY), 'capture extra')
    for nonce in ('', 'x' * 33, 'a b', 'a-b', 'é', 'a\n', None, True):
        rejects(lambda: native.parse_capture(good, nonce, CAPACITY), 'invalid nonce')
    padding = 65536 - len(good['bytes'])
    at_limit = dict(good, bytes=good['bytes'] + b'x' * (padding - 1) + b'\n')
    require(native.parse_capture(at_limit, NONCE, CAPACITY) == facts(), '65536 complete bound')
    rejects(lambda: native.parse_capture(dict(at_limit, bytes=at_limit['bytes'] + b'\n'), NONCE, CAPACITY), '65537')


def check_markers():
    original = lines(facts())
    for index in range(75):
        missing = original[:index] + original[index + 1:]
        duplicate = original[:index] + [original[index]] + original[index:]
        embedded = list(original)
        embedded[index] = 'diagnostic ' + embedded[index]
        rejects(lambda: parse(missing), 'missing ' + str(index))
        rejects(lambda: parse(duplicate), 'duplicate ' + str(index))
        rejects(lambda: parse(embedded), 'embedded ' + str(index))
    for index in range(74):
        changed = list(original)
        changed[index], changed[index + 1] = changed[index + 1], changed[index]
        rejects(lambda: parse(changed), 'reordered ' + str(index))
    for index in range(1, 75):
        changed = list(original)
        changed[index] = changed[index].replace(NONCE, 'wrong', 1)
        rejects(lambda: parse(changed), 'wrong nonce ' + str(index))
    for extra in ('info: H2_UNKNOWN ' + NONCE, 'H2_READY ' + NONCE, 'notice: H2_RECORD ' + NONCE,
                  'info: H2_READY ' + NONCE + ' extra', 'info: H2_DEINITED ' + NONCE):
        rejects(lambda: parse(original + [extra]), 'unknown or extra marker')
    for index in (3, 70):
        changed = list(original)
        changed[index] = changed[index + 1]
        rejects(lambda: parse(changed), 'duplicate tag')

    for tail in ('index=2 generation=0', 'index=true generation=0', 'index=-1 generation=0',
                 'index=0 generation=-1', 'index=0 generation=01',
                 'index=0 generation=18446744073709551616', 'generation=0 index=0'):
        changed = list(original)
        changed[2] = 'info: H2_BINDING ' + NONCE + ' tag=producer_reuse_next ' + tail
        if tail == 'index=2 generation=0':
            rejects(lambda: native.validate_post((), facts((), 'before'), parse(changed)), 'binding slot')
            continue
        rejects(lambda: parse(changed), 'binding grammar')


def replace_json(entries, index, payload):
    changed = list(entries)
    changed[index] = ' '.join(changed[index].split(' ', 3)[:3]) + ' ' + payload
    return changed


def check_json():
    original = lines(facts())
    for index, key in ((3, 'bytes'), (70, 'offset'), (74, 'bytes')):
        payload = original[index].split(' ', 3)[3]
        for bad in ('[]', 'null', '0', 'true', payload + '{}', '{"tag":"x","tag":"y"}',
                    payload[:-1] + ',"' + key + '":0}', '{', '{"x":1.0}', '{"x":NaN}',
                    '{"x":Infinity}', '{"x":-Infinity}', '{"x":-1}', '{"x":18446744073709551616}'):
            rejects(lambda: parse(replace_json(original, index, bad)), 'JSON ' + str(index) + bad[:50])
        value = json.loads(payload)
        for bad in (True, '0', None, [], {}, 0.5):
            changed = dict(value, **{key: bad})
            rejects(lambda: parse(replace_json(original, index, encoded(changed))), 'numeric type')
        for changed in (dict(value, extra=1), {key: item for key, item in value.items() if key != next(iter(value))}):
            rejects(lambda: parse(replace_json(original, index, encoded(changed))), 'exact schema')
    for index, key, bad in ((3, 'active', 0), (3, 'reason', False), (3, 'sha256', 0),
                            (70, 'armed', 0), (73, 'caller_owned', 1), (74, 'slot0_active', 0)):
        value = json.loads(original[index].split(' ', 3)[3])
        value[key] = bad
        rejects(lambda: parse(replace_json(original, index, encoded(value))), 'primitive type')
    for index, limit in ((3, 768), (70, 1024), (74, 1024)):
        payload = original[index].split(' ', 3)[3]
        exact = payload + ' ' * (limit - len(payload.encode()))
        require(parse(replace_json(original, index, exact)) == facts(), 'payload inclusive limit')
        rejects(lambda: parse(replace_json(original, index, exact + ' ')), 'payload over limit')
        multibyte = payload[:-1] + ',"extra":"' + 'é' * limit + '"}'
        rejects(lambda: parse(replace_json(original, index, multibyte)), 'UTF-8 byte bound')


def check_capacity():
    original = lines(facts())
    changes = (('max_connections":8', 'max_connections":9'), ('request_stride=4608', 'request_stride=4609'),
               ('h2_bytes=123456', 'h2_bytes=123455'), ('h2_stride=123456', 'h2_stride=123455'),
               ('slab=987654', 'slab=987655'), ('router=7654', 'router=7655'))
    for old, new in changes:
        changed = list(original)
        changed[0] = changed[0].replace(old, new)
        rejects(lambda: parse(changed), 'authenticated capacity ' + old)
    for bad in ('', CAPACITY + ' extra=1', CAPACITY.replace('h2_bytes=123456 ', ''),
                CAPACITY.replace('request_stride=4608', 'request_stride=true'),
                CAPACITY.replace('router=7654', 'router=18446744073709551616'),
                CAPACITY.replace('config={', 'config={"max_connections":8,'),
                CAPACITY.replace('config={', 'config={"f":1.5,'),
                CAPACITY.replace('config={', 'config={"f":NaN,'),
                CAPACITY.replace('config={', 'config={"f":-1,')):
        rejects(lambda: parse(lines(facts(), capacity=bad), capacity=bad), 'invalid authenticated grammar')
    for expected in (None, True, b'bytes', 'info: H2_CAPACITY ' + CAPACITY, CAPACITY + '\n'):
        rejects(lambda: parse(original, capacity=expected), 'expectation contract')
    oversized = CAPACITY.replace('"max_connections":8', '"padding":"' + 'p' * 1400 + '","max_connections":8')
    rejects(lambda: parse(lines(facts(), capacity=oversized), capacity=oversized), 'combined overhead allowance')


def check_comparisons():
    selection = ('producer_reuse', 'output_pressure_window', 'output_pressure_ready', 'stream_file', 'shutdown_active')
    before, after = facts(selection, 'before'), facts(selection)
    native.validate_post(selection, before, after)
    for area, tag, key, bad in (('records', 'shutdown_active', 'chunks', before['records']['shutdown_active']['chunks'] + 1),
                                ('records', 'shutdown_active', 'cancels', 0),
                                ('records', 'shutdown_active', 'active', True),
                                ('records', 'shutdown_active', 'paused', True),
                                ('records', 'shutdown_active', 'reason', None),
                                ('records', 'empty_data', 'bytes', 1),
                                ('outputs', 'producer_reuse', 'attempts', 2059),
                                ('outputs', 'producer_reuse', 'writes', 2048),
                                ('outputs', 'producer_reuse', 'binding_generation', 18),
                                ('outputs', 'stream_file', 'close_calls', 2)):
        changed = copy.deepcopy(after)
        changed[area][tag][key] = bad
        original = copy.deepcopy(before)
        rejects(lambda: native.validate_post(selection, before, changed), 'post delta ' + key)
        require(before == original, 'rejection mutated before')
    for phase in ('before', 'after'):
        changed = copy.deepcopy(before if phase == 'before' else after)
        changed['metrics']['cancels'] += 1
        rejects(lambda: native.validate_post(selection, changed if phase == 'before' else before,
                                             changed if phase == 'after' else after), 'both metrics phases')
    for key, bad in (('binding_generation', 18), ('binding_generation', 71), ('binding_index', 0), ('binding_index', True)):
        changed = copy.deepcopy(after)
        changed['binding'][key] = bad
        rejects(lambda: native.validate_post(selection, before, changed), 'actual binding unchanged')
        changed_before = copy.deepcopy(before)
        changed_before['binding'][key] = bad
        rejects(lambda: native.validate_post(selection, changed_before, changed), 'relative binding')
    for phase in ('before', 'after'):
        changed = copy.deepcopy(before if phase == 'before' else after)
        changed['extra'] = 1
        rejects(lambda: native.validate_post(selection, changed if phase == 'before' else before,
                                             changed if phase == 'after' else after), 'fact keys')
    rejects(lambda: native.validate_post((), facts((), 'before'), facts(('empty_data',))), 'unselected defaults')


def changed_scalar(value):
    if type(value) is bool:
        return not value
    if type(value) is int:
        return value + 1
    return 'changed'


def check_fields():
    selection = catalogue.CASES
    before, after = facts(selection, 'before'), facts(selection)
    original = copy.deepcopy(before)
    count = 0
    for area in ('records', 'outputs'):
        for tag, item in after[area].items():
            for key, value in item.items():
                changed = copy.deepcopy(after)
                changed[area][tag][key] = changed_scalar(value)
                rejects(lambda: native.validate_post(selection, before, changed), area + ':' + tag + ':' + key)
                count += 1
    require(before == original, 'field rejection mutated before')
    for phase in ('before', 'after'):
        base = before if phase == 'before' else after
        for key, value in base['metrics'].items():
            changed = copy.deepcopy(base)
            changed['metrics'][key] = changed_scalar(value)
            rejects(lambda: native.validate_post(selection, changed if phase == 'before' else before,
                                                 changed if phase == 'after' else after), 'metric field ' + key)
            count += 1
    changed_fields = {key for key, value in before['records']['shutdown_active'].items()
                      if value != after['records']['shutdown_active'][key]}
    require(changed_fields == {'cancels', 'active', 'paused', 'reason'}, 'exact shutdown delta')
    print('Rejected semantic-field mutations: ' + str(count))


def check_bounds():
    after = facts()
    ordinary = lines(after)
    allowance = sum(len(ordinary[index].encode()) + 1 for index in (0, 1, 2, 74))
    prefix = 'config={"padding":"'
    suffix = '",' + CAPACITY[len('config={'):]
    padded = prefix + 'p' * (2048 - allowance - len(prefix + suffix) + len(CAPACITY)) + suffix
    entries = lines(after, capacity=padded)
    require(sum(len(entries[index].encode()) + 1 for index in (0, 1, 2, 74)) == 2048, 'test allowance boundary')
    require(parse(entries, capacity=padded) == after, '2048 inclusive allowance')
    larger = padded.replace('"padding":"', '"padding":"p')
    rejects(lambda: parse(lines(after, capacity=larger), capacity=larger), '2049 allowance')
    maximal = lines(after, nonce='n' * 32)
    for index in range(3, 75):
        limit = 768 if index < 70 else 1024
        payload = maximal[index].split(' ', 3)[3]
        maximal[index] += ' ' * (limit - len(payload.encode()))
    overhead = sum(len(maximal[index].encode()) + 1 for index in (0, 1, 2, 74))
    capacity_room = 2048 - overhead
    maximal_capacity = prefix + 'p' * (capacity_room - len(prefix + suffix) + len(CAPACITY)) + suffix
    maximal[0] = 'info: H2_CAPACITY ' + maximal_capacity
    require(parse(maximal, 'n' * 32, maximal_capacity) == after, 'all serialized component maxima')
    total = sum(len(line.encode()) + 1 for line in maximal)
    require(total <= 62144, 'conservative fixture bound')
    print('Maximal legal serialized fixture bytes: ' + str(total) + '; conservative bound: 62144')
    deep_config = 'config={"x":' + '[' * 1000 + '0' + ']' * 1000 + '}' + CAPACITY[CAPACITY.index(' request_stride='):]
    rejects(lambda: parse(lines(after, capacity=deep_config), capacity=deep_config), 'bounded decoder nesting')


def main(group):
    checks = dict(valid=check_valid, diagnostics=check_diagnostics, capture=check_capture, markers=check_markers, json=check_json,
                  capacity=check_capacity, comparisons=check_comparisons, fields=check_fields, bounds=check_bounds)
    selected = checks if group == 'all' else {group: checks[group]}
    for name, check in selected.items():
        check()
        print(name + ': PASS')
    print('Native post pure checks passed: ' + str(len(selected)))


if __name__ == '__main__':
    if len(sys.argv) in (2, 3) and sys.argv[1] == '--check':
        main(sys.argv[2] if len(sys.argv) == 3 else 'all')
