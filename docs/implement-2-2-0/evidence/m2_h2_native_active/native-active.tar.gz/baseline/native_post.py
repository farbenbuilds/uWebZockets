"""Pure complete-capture parsing; provider authenticates process and capacity."""
import json
import re
import sys
import model

CaptureFacts = dict[str, bytes | bool | str | None]
RecordFacts = dict[str, object]
TaggedFacts = dict[str, RecordFacts]
PostFacts = dict[str, TaggedFacts | RecordFacts]
PreFacts = dict[str, TaggedFacts | RecordFacts | None]
CaseSelection = tuple[str, ...] | list[str]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def object_pairs(pairs: list[tuple[str, object]]) -> RecordFacts:
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def reject_number(value: str) -> None:
    raise ValueError('non-integer JSON number: ' + value)


def unsigned_decimal(value: str) -> int:
    require(re.fullmatch(r'0|[1-9][0-9]{0,19}', value) is not None, 'unsigned decimal')
    return model.unsigned(int(value))


def json_object(payload: str, limit: int) -> RecordFacts:
    require(len(payload.encode('utf-8')) <= limit, 'JSON payload bound')
    value = json.loads(payload, object_pairs_hook=object_pairs, parse_int=unsigned_decimal,
                       parse_float=reject_number, parse_constant=reject_number)
    require(type(value) is dict, 'JSON object required')
    return value


def capacity_payload(payload: str) -> None:
    require(type(payload) is str, 'capacity expectation required')
    pattern = (r'config=(.+) request_stride=([0-9]+) h2_bytes=([0-9]+) '
               r'h2_stride=([0-9]+) slab=([0-9]+) router=([0-9]+)')
    match = re.fullmatch(pattern, payload)
    require(match is not None, 'capacity grammar')
    json_object(match[1], 2048)
    for field in match.groups()[1:]:
        unsigned_decimal(field)


def primitive_schema(value: RecordFacts, expected: RecordFacts) -> None:
    require(value.keys() == expected.keys(), 'fixture JSON schema')
    for key, target in expected.items():
        if key == 'reason':
            require(value[key] is None or type(value[key]) is str, 'record reason type')
            continue
        require(type(value[key]) is type(target), 'fixture JSON type: ' + key)


def payload_line(line: str, marker: str, nonce: str, limit: int) -> str:
    prefix = 'info: ' + marker + ' ' + nonce + ' '
    require(line.startswith(prefix), 'fixture marker or nonce')
    require(len(prefix.encode()) + 1 <= 64, 'nonce overhead bound')
    payload = line[len(prefix):]
    require(len(payload.encode('utf-8')) <= limit, 'JSON payload bound')
    return payload


def tagged_items(entries: list[str], marker: str, nonce: str,
                 defaults: TaggedFacts, limit: int) -> TaggedFacts:
    items = []
    seen = set()
    for line, (tag, expected) in zip(entries, defaults.items(), strict=True):
        value = json_object(payload_line(line, marker, nonce, limit), limit)
        require(type(value.get('tag')) is str and value['tag'] not in seen, 'duplicate or absent fixture tag')
        require(value['tag'] == tag, 'fixture tag order')
        primitive_schema(value, expected)
        seen.add(tag)
        items.append((tag, value))
    return dict(items)


def binding_line(line: str, nonce: str) -> RecordFacts:
    payload = payload_line(line, 'H2_BINDING', nonce, 2048)
    match = re.fullmatch(r'tag=producer_reuse_next index=([0-9]+) generation=([0-9]+)', payload)
    require(match is not None, 'binding grammar')
    return dict(tag='producer_reuse_next', binding_index=unsigned_decimal(match[1]),
                binding_generation=unsigned_decimal(match[2]))


def fixture_lines(capture: CaptureFacts) -> list[str]:
    require(type(capture) is dict and capture.keys() == {"bytes", "overflow", "error", "finished"}, "capture schema")
    require(type(capture["bytes"]) is bytes and len(capture["bytes"]) <= 65536, "capture byte bound")
    require(capture["overflow"] is False and capture["error"] is None and capture["finished"] is True, "incomplete collector capture")
    require(capture["bytes"].endswith(b"\n") and b"\r" not in capture["bytes"], "complete LF lines required")
    text = capture['bytes'].decode('utf-8')
    entries = []
    for line in text.split('\n')[:-1]:
        # Reserve literal fixture prefixes and uppercase marker names.
        if 'info: H2_' in line or re.search(r'H2_(?:[A-Z0-9_]|(?=\s|$))', line):
            require(line.startswith('info: H2_'), 'embedded fixture marker')
            entries.append(line)
    require(len(entries) == 75, 'fixture marker count')
    sizes = tuple(len(line.encode("utf-8")) + 1 for line in entries)
    require(sum(sizes) <= 62144, "fixture total bound")
    require(sum(sizes[index] for index in (0, 1, 2, 74)) <= 2048, "fixture overhead allowance")
    return entries


def parse_capture(capture: CaptureFacts, nonce: str, expected_capacity: str) -> PostFacts:
    """Return detached semantic facts; expected_capacity excludes prefix and LF."""
    require(type(nonce) is str and re.fullmatch(r'[A-Za-z0-9_]{1,32}', nonce) is not None, 'nonce')
    capacity_payload(expected_capacity)
    entries = fixture_lines(capture)
    require(entries[0] == 'info: H2_CAPACITY ' + expected_capacity, 'authenticated capacity differs')
    require(entries[1] == 'info: H2_READY ' + nonce, 'ready marker')
    binding = binding_line(entries[2], nonce)
    records = tagged_items(entries[3:70], 'H2_RECORD', nonce, model.records((), 'after'), 768)
    outputs = tagged_items(entries[70:74], 'H2_OUTPUT', nonce, model.default_outputs(), 1024)
    metrics = json_object(payload_line(entries[74], 'H2_DEINIT', nonce, 1024), 1024)
    expected_metrics = dict(model.metrics((), 'after'), slot0_active=False, slot1_active=False)
    primitive_schema(metrics, expected_metrics)
    return dict(records=records, metrics=metrics, outputs=outputs, binding=binding)


def fact_schema(facts: PreFacts | PostFacts, pre: bool) -> None:
    require(type(facts) is dict and facts.keys() == {'records', 'metrics', 'outputs', 'binding'}, 'post fact schema')
    require(all(type(facts[key]) is dict for key in ('records', 'metrics', 'outputs')), 'post fact mappings')
    require(type(facts['binding']) is dict or pre and facts['binding'] is None, 'post binding mapping')


def validate_post(selection: CaseSelection, before: PreFacts, after: PostFacts) -> None:
    """Compare canonical records, metrics, outputs and actual relative binding."""
    fact_schema(before, True)
    fact_schema(after, False)
    model.validate_pre_post(selection, before['records'], after['records'])
    model.validate_metrics(selection, 'before', before['metrics'])
    model.validate_metrics(selection, 'after', after['metrics'])
    model.validate_output_pre_post(selection, before['outputs'], after['outputs'],
                                   binding_before=before['binding'], binding_after=after['binding'])


if __name__ == '__main__':
    if sys.argv[1:] == ['--contract']:
        print('Pure fixture capture and canonical post-shutdown comparison; no native authenticity claim.')
