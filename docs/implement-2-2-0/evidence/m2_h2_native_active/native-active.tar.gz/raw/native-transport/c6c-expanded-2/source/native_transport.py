"""Source transport seam: bounded I/O, owned shutdown and live local receipts.

Real provider authenticity, exit/reap and capture completion remain external.
Injected operations own OS effects; wrap consumes raw ownership on success
and leaves raw ownership with the caller on failure. A successful close returns
None and releases its handle. Failed cleanup is retained, never a close receipt.
Public unwrap transfers ownership to its non-None opaque returned handle;
an absent return or raised exception leaves the TLS cleanup target identifiable.
"""
from functools import partial
from typing import Callable
import cases
import catalogue
import coordinator
import h2_client
import native_closing
import shutdown_cases
import test_all40_descriptors as descriptors
import test_wire_oracle as oracle

Clock = Callable[[], int]
Handle = object
Address = tuple[str, int]
# Exact keys validated below; frozen copy prevents later caller fact substitution.
ChildBinding = dict
# pid:int, running:bool, start_identity:str, listeners:tuple[Address, ...].
OwnershipFacts = dict
# tls/alpn/hostname:str, check_hostname/certificate_verified/suppress_ragged_eofs:bool,
# certificate_sha256: lowercase hexadecimal SHA256 of the verified peer certificate.
TlsFacts = dict
# overflow:bool, error:None|BaseException, complete:bool (completion is not exit proof).
CaptureFacts = dict
Dial = Callable[[Address, float], Handle]
Wrap = Callable[[Handle, str, bool, float], Handle]
Inspect = Callable[[Handle], TlsFacts]
SetTimeout = Callable[[Handle, float], None]
FullSend = Callable[[Handle, bytes], None]
PrimitiveRecv = Callable[[Handle, int], bytes]
Unwrap = Callable[[Handle], Handle]
CloseHandle = Callable[[Handle], None]
ObserveOwnership = Callable[[], OwnershipFacts]
ObserveCapture = Callable[[], CaptureFacts]
NewProtocol = Callable[[], h2_client.h2.connection.H2Connection]
# dial:Dial, wrap:Wrap, inspect:Inspect, set_timeout:SetTimeout, send:FullSend,
# recv:PrimitiveRecv, close:CloseHandle, ownership:ObserveOwnership,
# capture:ObserveCapture, new_protocol:NewProtocol (canonical factory identity).
# unwrap:Unwrap is required exactly when the child selection has disconnect.
TransportOps = dict
# child/child_anchor, clock, ops, now, history<=41, current, failure, cleanup_errors<=2, busy.
TransportState = dict
# identity, case_deadline, whole_deadline, entry, handle, closed, original,
# wrapped, observer, receive_state (distinct C4 state or None), release, context_binding.
ConnectionRecord = dict
Connection = dict
Context = dict
# Actual context, stage, raw, request, credit, records and stage-binding identities.
ContextBinding = tuple[dict, dict, dict, dict, dict, dict, dict]
BindContext = Callable[[Context], None]
CloseFacts = dict
StrictCloseFacts = dict
# Exact canonical signal facts plus retained child/client, fresh prerequisites,
# actual operation result, and returned tick. Providers authenticate OS evidence.
SignalFacts = dict
SignalPrerequisites = tuple[int, str, Address, Handle, Handle, int]
SignalOperation = tuple[str, int, str, Handle, Handle, int, None]
SignalEvidence = tuple[SignalFacts, ChildBinding, Handle, SignalPrerequisites, SignalOperation, int]
OwnedSignal = Callable[[ChildBinding, Handle, int], SignalEvidence]
TerminationFacts = dict
# identity, kind, original immutable seal/checkpoint, fresh local closing receipt.
TransportReceipt = tuple[oracle.ConnectionIdentity, str, oracle.ConnectionReceipt | oracle.CheckpointReceipt, native_closing.ClosingReceipt | None]
# original/wrapped objects and key-ordered values, observer/descriptor, TLS handle.
CallbackAnchor = tuple[Connection, Connection, tuple[object, ...], tuple[object, ...], dict, oracle.ConnectionDescriptor, Handle]
CONNECTION_KEYS = ('protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn')
UNITS = 1000000000
U64 = (1 << 64) - 1


def require(value: bool, code: str) -> None:
    if not value:
        raise ValueError(code)


def uint(value: int) -> bool:
    return type(value) is int and 0 <= value <= U64


def validate_child(child: ChildBinding) -> None:
    fields = {'identity', 'selection', 'ready_start', 'ready_at', 'ready_deadline', 'whole_start',
              'whole_deadline', 'pid', 'start_identity', 'listener', 'address', 'certificate_sha256'}
    require(type(child) is dict and set(child) == fields, 'child_fields')
    identity = child['identity']
    require(type(identity) is tuple and len(identity) == 2 and type(identity[0]) is str and
            1 <= len(identity[0]) <= 32 and all(char in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_' for char in identity[0]) and
            uint(identity[1]) and identity[1] < 2, 'child_identity')
    selection = child['selection']
    require(type(selection) is tuple and bool(selection) and cases.select(selection) == selection and
            catalogue.child_plan(selection) == (selection,), 'child_selection')
    values = tuple(child[key] for key in ('whole_start', 'ready_start', 'ready_at', 'ready_deadline', 'whole_deadline'))
    require(all(uint(value) for value in values), 'child_deadline_type')
    whole_start, ready_start, ready_at, ready_deadline, whole = values
    require(whole_start <= ready_start <= ready_at < ready_deadline <= whole, 'child_readiness')
    require(ready_deadline <= catalogue.add_u64(ready_start, 15 * UNITS) and
            whole <= catalogue.add_u64(whole_start, 900 * UNITS), 'child_deadline_bound')
    require(type(child['pid']) is int and 0 < child['pid'] <= 2147483647 and
            type(child['start_identity']) is str and 1 <= len(child['start_identity']) <= 128, 'child_process')
    address = child['address']
    require(type(address) is tuple and len(address) == 2 and address[0] == '127.0.0.1' and
            type(address[1]) is int and 0 < address[1] <= 65535 and child['listener'] == address and
            type(child['listener']) is tuple, 'child_address')
    digest = child['certificate_sha256']
    require(type(digest) is str and len(digest) == 64 and all(char in '0123456789abcdef' for char in digest), 'child_certificate')


def new_transport(child: ChildBinding, *, clock: Clock, ops: TransportOps) -> TransportState:
    """No effects: retain validated child readiness once and caller-owned state."""
    validate_child(child)
    names = {'dial', 'wrap', 'inspect', 'set_timeout', 'send', 'recv', 'close', 'ownership', 'capture', 'new_protocol'}
    if 'disconnect' in child['selection']:
        names.add('unwrap')
    require(callable(clock) and type(ops) is dict and set(ops) == names and
            all(callable(callback) for callback in ops.values()) and ops['new_protocol'] is h2_client.new_protocol, 'transport_ops')
    return dict(child=dict(child), child_anchor=tuple(child.items()), clock=clock, ops=dict(ops), now=child['ready_at'], history=[],
                current=None, failure=None, cleanup_errors=[], busy=False)


def sample(state: TransportState, deadline: int) -> int:
    require(uint(deadline), 'deadline_type')
    tick = state['clock']()
    require(uint(tick) and state['now'] <= tick < deadline, 'transport_time')
    state['now'] = tick
    return tick


def residual(state: TransportState, deadline: int) -> float:
    return (deadline - sample(state, deadline)) / UNITS


def capture(state: TransportState, deadline: int) -> None:
    result = state['ops']['capture']()
    require(type(result) is dict and set(result) == {'overflow', 'error', 'complete'} and
            result['overflow'] is False and result['error'] is None and type(result['complete']) is bool, 'capture_health')
    sample(state, deadline)


def owned(state: TransportState, deadline: int) -> None:
    child = state['child']
    result = state['ops']['ownership']()
    require(type(result) is dict and set(result) == {'pid', 'running', 'start_identity', 'listeners'} and
            type(result['pid']) is int and result['pid'] == child['pid'] and result['running'] is True and
            type(result['start_identity']) is str and result['start_identity'] == child['start_identity'] and
            type(result['listeners']) is tuple and result['listeners'] == (child['listener'],), 'live_ownership')
    sample(state, deadline)
    capture(state, deadline)


def remember_failure(state: TransportState, error: BaseException) -> None:
    if state['failure'] is None:
        state['failure'] = error


def cleanup(state: TransportState, row: ConnectionRecord, error: BaseException) -> None:
    remember_failure(state, error)
    if row['cleanup_started']:
        return
    row['cleanup_started'] = True
    if row['handle'] is None or row['closed']:
        return
    try:
        result = state['ops']['close'](row['handle'])
        require(result is None, 'cleanup_close_shape')
        row['closed'] = True
    except BaseException as secondary:
        require(len(state['cleanup_errors']) < 2, 'cleanup_error_bound')
        state['cleanup_errors'].append(secondary)


def validate_connect(state: TransportState, case: str, number: int, case_deadline: int, whole_deadline: int) -> oracle.ConnectionDescriptor:
    require(state['failure'] is None and not state['busy'], 'transport_failed_or_busy')
    child, history, previous = state['child'], state['history'], state['current']
    require(type(case) is str and case in child['selection'] and type(number) is int and
            number in ((1, 2) if case == 'disconnect' else (1,)), 'connection_identity')
    require(uint(case_deadline) and uint(whole_deadline) and whole_deadline == child['whole_deadline'] and
            state['now'] < case_deadline <= whole_deadline, 'connection_deadlines')
    require(len(history) < 41 and (previous is None or previous['closed'] and previous['release'] is not None), 'connection_open_or_bound')
    if previous is None:
        require((case, number) == (child['selection'][0], 1), 'connection_order')
    else:
        validate_next(child, previous, case, number, case_deadline)
    final = case == child['selection'][-1] and not (case == 'disconnect' and number == 1)
    return descriptors.connection_descriptor(child['identity'][1], case, number, final=final)


def validate_next(child: ChildBinding, previous: ConnectionRecord, case: str, number: int, deadline: int) -> None:
    prior_case, prior_number = previous['identity'][1:]
    if prior_case == 'disconnect' and prior_number == 1:
        expected = dict(method='ssl_unwrap', tls_shutdown='success', tcp_eof=True, trailing_bytes=0, close='normal')
        release = previous['release']
        require(case == prior_case and number == 2 and deadline == previous['case_deadline'] and
                type(release) is dict and release == expected and
                all(type(release[key]) is type(value) for key, value in expected.items()), 'replacement_order')
        return
    position = child['selection'].index(prior_case) + 1
    require(position < len(child['selection']) and (case, number) == (child['selection'][position], 1), 'connection_order')


def inspect_tls(state: TransportState, row: ConnectionRecord, deadline: int) -> None:
    facts = state['ops']['inspect'](row['handle'])
    expected = dict(tls='TLSv1.3', alpn='h2', hostname='localhost', check_hostname=True,
                    certificate_verified=True, certificate_sha256=state['child']['certificate_sha256'], suppress_ragged_eofs=False)
    require(type(facts) is dict and facts == expected and
            all(type(facts[key]) is type(value) for key, value in expected.items()), 'tls_policy')
    sample(state, deadline)


def build_connection(state: TransportState, row: ConnectionRecord, descriptor: oracle.ConnectionDescriptor) -> Connection:
    child, deadline = state['child'], min(row['case_deadline'], row['whole_deadline'])
    owned(state, deadline)
    row['handle'] = state['ops']['dial'](child['address'], residual(state, deadline))
    require(row['handle'] is not None, 'dial_handle')
    sample(state, deadline)
    wrapped_handle = state['ops']['wrap'](row['handle'], 'localhost', False, residual(state, deadline))
    require(wrapped_handle is not None, 'wrap_handle')
    row['handle'] = wrapped_handle
    sample(state, deadline)
    inspect_tls(state, row, deadline)
    owned(state, deadline)
    protocol = state['ops']['new_protocol']()
    require(type(protocol) is h2_client.h2.connection.H2Connection, 'canonical_protocol')
    now = sample(state, deadline)
    connection = dict(protocol=protocol, send=partial(bounded_send, state, row), receive=partial(bounded_receive, state, row),
                      now=now, owned=True, tls='TLSv1.3', alpn='h2')
    if row['identity'][1] == 'shutdown_active':
        receive_state = native_closing.new_receive_state(row['identity'], now, UNITS,
            (child['ready_start'], child['ready_deadline'], row['entry'], row['case_deadline'], child['whole_start'], child['whole_deadline']), ready_at=child['ready_at'])
        row['receive_state'] = receive_state
        binding = (partial(prepare, state, row), partial(state['ops']['recv'], row['handle']), partial(read_clock, state, row))
        connection['receive'] = partial(native_closing.receive_once, receive_state, binding)
        connection['send'] = partial(native_closing.send_once, receive_state, connection['send'])
    wrapped, observer = oracle.wrap_connection(connection, descriptor)
    row.update(original=connection, wrapped=wrapped, observer=observer)
    if row['receive_state'] is not None:
        native_closing.bind_observer(row['receive_state'], connection, wrapped, observer)
    row['callback_anchor'] = (connection, wrapped, tuple(connection[key] for key in CONNECTION_KEYS),
                              tuple(wrapped[key] for key in CONNECTION_KEYS), observer, descriptor, row['handle'])
    return wrapped


def connect(state: TransportState, case: str, number: int, case_deadline: int, whole_deadline: int) -> Connection:
    descriptor = validate_connect(state, case, number, case_deadline, whole_deadline)
    entry = sample(state, min(case_deadline, whole_deadline))
    require(case_deadline <= catalogue.add_u64(entry, catalogue.mul_u64(catalogue.case_budget(case)['timeout_seconds'], UNITS)), 'case_deadline_bound')
    row = dict(identity=descriptor[0], case_deadline=case_deadline, whole_deadline=whole_deadline, entry=entry,
               handle=None, closed=False, original=None, wrapped=None, observer=None, receive_state=None, release=None,
               context_binding=None, callback_anchor=None, cleanup_started=False, signal_started=False,
               signal_evidence=None, signal_facts=None, signal_deadline=None, signal_return=None,
               frozen_counts=None, termination_started=False, terminal_facts=None, receipt=None, receipt_operation=None)
    state['history'].append(row)
    state['current'], state['busy'] = row, True
    try:
        return build_connection(state, row, descriptor)
    except BaseException as error:
        cleanup(state, row, error)
        raise
    finally:
        state['busy'] = False


def read_clock(state: TransportState, row: ConnectionRecord) -> int:
    deadline = row['signal_deadline']
    return sample(state, min(row['case_deadline'], row['whole_deadline']) if deadline is None else deadline)


def prepare(state: TransportState, row: ConnectionRecord, deadline: int) -> None:
    require(state['failure'] is None and state['current'] is row and not row['closed'] and
            row['wrapped'] is not None and not state['busy'], 'io_lifecycle')
    require(row['observer']['failure'] is None and not row['observer']['sealed'] and
            row['observer']['busy'], 'io_observer')
    closing = row['signal_facts'] is not None
    expected = row['signal_deadline'] if closing else min(row['case_deadline'], row['whole_deadline'])
    require(uint(deadline) and deadline == expected, 'io_deadline')
    sample(state, deadline)
    if closing:
        validate_active_bindings(state, row, row['context_binding'][0])
        receive_state = row['receive_state']
        require(receive_state['phase'] == 'closing' and receive_state['draining'] and
                receive_state['authorization'] == row['signal_facts'], 'closing_preparation')
        capture(state, deadline)
    else:
        owned(state, deadline)
    result = state['ops']['set_timeout'](row['handle'], residual(state, deadline))
    require(result is None, 'timeout_shape')
    sample(state, deadline)


def bounded_send(state: TransportState, row: ConnectionRecord, data: bytes) -> None:
    try:
        require(type(data) is bytes and 0 < len(data) <= 65536, 'send_shape')
        deadline = min(row['case_deadline'], row['whole_deadline'])
        prepare(state, row, deadline)
        state['busy'] = True
        result = state['ops']['send'](row['handle'], data)
        require(result is None, 'full_send_shape')
        sample(state, deadline)
    except BaseException as error:
        cleanup(state, row, error)
        raise
    finally:
        state['busy'] = False


def bounded_receive(state: TransportState, row: ConnectionRecord) -> tuple[bytes, int]:
    try:
        deadline = min(row['case_deadline'], row['whole_deadline'])
        prepare(state, row, deadline)
        state['busy'] = True
        data = state['ops']['recv'](row['handle'], 8192)
        require(type(data) is bytes and 0 < len(data) <= 8192, 'ordinary_receive_shape_or_eof')
        return data, sample(state, deadline)
    except BaseException as error:
        cleanup(state, row, error)
        raise
    finally:
        state['busy'] = False


def validate_close(state: TransportState, context: Context, deadline: int) -> ConnectionRecord:
    row = state['current']
    require(row is not None and not row['closed'] and not state['busy'] and state['failure'] is None, 'close_lifecycle')
    require(row['identity'][1] != 'shutdown_active' and row['identity'][1:] != ('disconnect', 1), 'ordinary_close_policy')
    require(type(context) is dict and context['protocol'] is row['original']['protocol'] and
            context['send'] is row['wrapped']['send'] and context['stage']['case'] == row['identity'][1] and
            context['stage']['connection_index'] == row['identity'][2], 'close_context')
    require((context['stage']['case_deadline'], context['stage']['whole_deadline']) ==
            (row['case_deadline'], row['whole_deadline']) and uint(context['now']) and context['now'] >= row['entry'], 'close_time_binding')
    limit = min(row['case_deadline'], row['whole_deadline'])
    if row['identity'][1] == state['child']['selection'][-1]:
        limit = min(limit, catalogue.add_u64(context['now'], 15 * UNITS))
    require(uint(deadline) and max(context['now'], state['now']) < deadline <= limit, 'close_deadline')
    return row


def close(state: TransportState, context: Context, deadline: int) -> CloseFacts:
    row = validate_close(state, context, deadline)
    state['now'] = max(state['now'], context['now'])
    state['busy'] = True
    try:
        sample(state, deadline)
        owned(state, deadline)
        result = state['ops']['close'](row['handle'])
        require(result is None, 'close_shape')
        row['closed'] = True
        sample(state, deadline)
        capture(state, deadline)
        row['release'] = dict(method='close', client_closed=True, close='normal')
        return dict(row['release'])
    except BaseException as error:
        cleanup(state, row, error)
        raise
    finally:
        state['busy'] = False


def bind_context(state: TransportState, context: Context) -> None:
    """Trusted coordinator post-open registration; never defer first binding to close."""
    row = state['current']
    require(row is not None and not row['closed'] and not state['busy'] and state['failure'] is None and
            row['release'] is None and row['context_binding'] is None and row['identity'][2] == 1 and
            row['identity'][0] == state['child']['identity'][1], 'context_bind_lifecycle')
    require(type(context) is dict and context.get('protocol') is row['original']['protocol'] and
            context.get('send') is row['wrapped']['send'] and context.get('clock') is state['clock'], 'context_bind_connection')
    stage, raw, request, credit, records = (context.get(key) for key in ('stage', 'raw', 'request', 'credit', 'records'))
    require(all(type(value) is dict for value in (stage, raw, request, credit, records)) and
            stage.get('case') == row['identity'][1] and type(stage.get('connection_index')) is int and
            stage['connection_index'] == 1 and stage.get('failed') is False and context.get('completed') is False and
            raw.get('closed') is False and raw.get('closing') is None and request.get('transport_closed') is False, 'context_bind_initial')
    binding = stage.get('binding')
    require(type(binding) is dict and set(binding) == {'protocol', 'raw', 'request', 'credit', 'records'} and
            all(binding[key] is context[key] for key in binding), 'context_bind_canonical_binding')
    require((stage.get('case_deadline'), stage.get('whole_deadline')) == (row['case_deadline'], row['whole_deadline']) and
            uint(context.get('now')) and row['entry'] <= context['now'] < min(row['case_deadline'], row['whole_deadline']), 'context_bind_time')
    observer = row['observer']
    require(observer['descriptor'][0] == row['identity'] and observer['failure'] is None and
            not observer['busy'] and not observer['sealed'], 'context_bind_observer')
    row['context_binding'] = (context, stage, raw, request, credit, records, binding)


def validate_disconnect(state: TransportState, context: Context) -> ConnectionRecord:
    row = state['current']
    require(row is not None and not row['closed'] and not state['busy'] and state['failure'] is None and
            row['release'] is None and row['identity'] == (state['child']['identity'][1], 'disconnect', 1), 'disconnect_lifecycle')
    anchor = row['context_binding']
    require(anchor is not None and context is anchor[0] and
            all(context.get(key) is component for key, component in zip(('stage', 'raw', 'request', 'credit', 'records'), anchor[1:6])) and
            context['stage'].get('binding') is anchor[6], 'disconnect_context_anchor')
    require(type(context) is dict and context.get('protocol') is row['original']['protocol'] and
            context.get('send') is row['wrapped']['send'] and context.get('clock') is state['clock'], 'disconnect_context')
    stage, raw = context.get('stage'), context.get('raw')
    require(type(stage) is dict and type(raw) is dict and stage.get('case') == 'disconnect' and
            type(stage.get('connection_index')) is int and stage['connection_index'] == 1 and
            not stage.get('failed') and raw.get('closed') is False, 'disconnect_stage')
    binding, closing = stage.get('binding'), raw.get('closing')
    require(type(binding) is dict and all(binding.get(key) is context.get(key) for key in
            ('protocol', 'raw', 'request', 'credit', 'records')) and
            type(closing) is dict and closing.get('phase') == 'pre_unwrap' and
            closing.get('policy') == 'clean_disconnect', 'disconnect_binding_or_phase')
    require((stage.get('case_deadline'), stage.get('whole_deadline')) == (row['case_deadline'], row['whole_deadline']) and
            uint(context.get('now')) and row['entry'] <= context['now'] < min(row['case_deadline'], row['whole_deadline']), 'disconnect_time_binding')
    observer = row['observer']
    require(observer['descriptor'][0] == row['identity'] and observer['failure'] is None and
            not observer['busy'] and not observer['sealed'], 'disconnect_observer')
    return row


def disconnect_tick(state: TransportState, deadline: int) -> int:
    if state['failure'] is not None:
        raise state['failure']
    require(state['busy'], 'disconnect_operation_binding')
    return sample(state, deadline)


def disconnect_close(state: TransportState, context: Context) -> StrictCloseFacts:
    """Canonical handlers own begin/finish; only complete strict release permits replacement."""
    row = validate_disconnect(state, context)
    deadline = min(row['case_deadline'], row['whole_deadline'])
    state['now'] = max(state['now'], context['now'])
    state['busy'] = True
    try:
        disconnect_tick(state, deadline)
        owned(state, deadline)
        disconnect_tick(state, deadline)
        result = state['ops']['set_timeout'](row['handle'], residual(state, deadline))
        require(result is None, 'timeout_shape')
        disconnect_tick(state, deadline)
        raw = state['ops']['unwrap'](row['handle'])
        if raw is not None:
            if raw is not row['handle']:
                row['closed'] = False
            row['handle'] = raw
        disconnect_tick(state, deadline)
        require(raw is not None, 'unwrap_handle')
        owned(state, deadline)
        disconnect_tick(state, deadline)
        result = state['ops']['set_timeout'](raw, residual(state, deadline))
        require(result is None, 'timeout_shape')
        disconnect_tick(state, deadline)
        data = state['ops']['recv'](raw, 8192)
        require(type(data) is bytes and data == b'', 'disconnect_raw_eof')
        disconnect_tick(state, deadline)
        capture(state, deadline)
        disconnect_tick(state, deadline)
        result = state['ops']['close'](raw)
        require(result is None, 'close_shape')
        row['closed'] = True
        disconnect_tick(state, deadline)
        capture(state, deadline)
        disconnect_tick(state, deadline)
        row['release'] = dict(method='ssl_unwrap', tls_shutdown='success', tcp_eof=True, trailing_bytes=0, close='normal')
        return dict(row['release'])
    except BaseException as error:
        primary = error if state['failure'] is None else state['failure']
        cleanup(state, row, primary)
        raise primary
    finally:
        state['busy'] = False


def fail_transport(state: TransportState, primary_error: BaseException) -> None:
    """Caller boundary retains the first exception; cleanup never earns release."""
    require(isinstance(primary_error, BaseException), 'transport_failure_type')
    remember_failure(state, primary_error)
    if state['current'] is not None:
        cleanup(state, state['current'], primary_error)


def validate_callbacks(row: ConnectionRecord) -> None:
    anchor = row['callback_anchor']
    require(anchor is not None and row['original'] is anchor[0] and row['wrapped'] is anchor[1] and
            row['observer'] is anchor[4] and row['observer']['descriptor'] is anchor[5], 'transport_observer_binding')
    require(set(row['original']) == set(row['wrapped']) == set(CONNECTION_KEYS) and
            all(row['original'][key] is old for key, old in zip(CONNECTION_KEYS, anchor[2])) and
            all(row['wrapped'][key] is old for key, old in zip(CONNECTION_KEYS, anchor[3])), 'transport_callback_binding')
    for name in ('send', 'receive'):
        wrapped, original = row['wrapped'][name], row['original'][name]
        require(isinstance(wrapped, partial) and wrapped.func is oracle.invoke and not wrapped.keywords and
                len(wrapped.args) == 3 and wrapped.args[0] is row['observer'] and wrapped.args[1] == name and
                wrapped.args[2] is original and isinstance(original, partial) and not original.keywords, 'transport_partial_binding')


def validate_active_bindings(state: TransportState, row: ConnectionRecord, context: Context) -> None:
    validate_callbacks(row)
    anchor = row['context_binding']
    require(anchor is not None and context is anchor[0] and
            all(context.get(key) is value for key, value in zip(('stage', 'raw', 'request', 'credit', 'records'), anchor[1:6])) and
            context['stage'].get('binding') is anchor[6], 'active_context_anchor')
    require(context.get('protocol') is row['original']['protocol'] and context.get('send') is row['wrapped']['send'] and
            context.get('clock') is state['clock'] and row['handle'] is row['callback_anchor'][6] and
            tuple(state['child'].items()) == state['child_anchor'], 'active_connection_binding')
    require(all(anchor[6].get(key) is context.get(key) for key in ('protocol', 'raw', 'request', 'credit', 'records')) and
            context['stage'].get('case') == 'shutdown_active' and type(context['stage'].get('connection_index')) is int and
            context['stage']['connection_index'] == 1 and context['stage'].get('failed') is False, 'active_stage_binding')
    receive_state = row['receive_state']
    require(receive_state is not None and receive_state['connection'] is row['original'] and
            receive_state['wrapped'] is row['wrapped'] and receive_state['observer'] is row['observer'] and
            receive_state['identity'] == row['identity'], 'active_receive_binding')
    binding = receive_state['binding']
    send = row['original']['send'].args[1]
    require(row['original']['receive'].args[1] is binding and
            all(isinstance(callback, partial) and not callback.keywords for callback in binding) and
            binding[0].func is prepare and len(binding[0].args) == 2 and binding[0].args[0] is state and binding[0].args[1] is row and
            binding[2].func is read_clock and len(binding[2].args) == 2 and binding[2].args[0] is state and binding[2].args[1] is row and
            len(binding[1].args) == 1 and binding[1].args[0] is row['handle'] and
            isinstance(send, partial) and send.func is bounded_send and not send.keywords and
            len(send.args) == 2 and send.args[0] is state and send.args[1] is row, 'active_primitive_binding')
    require((context['stage']['case_deadline'], context['stage']['whole_deadline']) ==
            (row['case_deadline'], row['whole_deadline']) == (receive_state['deadlines'][3], receive_state['deadlines'][5]), 'active_deadline_binding')


def active_entry(state: TransportState, context: Context, deadline: int) -> ConnectionRecord:
    row = state['current']
    require(state['failure'] is None and not state['busy'] and row is not None and not row['closed'] and
            row['identity'] == (state['child']['identity'][1], 'shutdown_active', 1) and row['release'] is None, 'active_lifecycle')
    validate_active_bindings(state, row, context)
    require(uint(context['now']) and uint(deadline) and row['entry'] <= context['now'] and
            max(context['now'], state['now']) < deadline <= min(row['case_deadline'], row['whole_deadline']), 'active_time')
    state['now'] = max(state['now'], context['now'])
    return row


def validate_signal_evidence(state: TransportState, row: ConnectionRecord, evidence: SignalEvidence, start: int) -> SignalFacts:
    require(type(evidence) is tuple and len(evidence) == 6, 'signal_evidence_shape')
    facts, child, handle, prerequisites, operation, returned = evidence
    require(child is state['child'] and handle is row['handle'] and type(prerequisites) is tuple and
            len(prerequisites) == 6 and type(operation) is tuple and len(operation) == 7, 'signal_evidence_binding')
    pid, identity, listener, watcher, opened, observed = prerequisites
    require(type(pid) is int and pid == child['pid'] and type(identity) is str and identity == child['start_identity'] and
            type(listener) is tuple and listener == child['listener'] and watcher is not None and opened is handle,
            'signal_prerequisites')
    require(operation[:3] == ('SIGTERM', pid, identity) and type(operation[1]) is int and
            operation[3] is watcher and operation[4] is handle and operation[6] is None, 'signal_operation_result')
    require(all(uint(tick) for tick in (observed, operation[5], returned)) and
            start <= observed <= operation[5] <= returned < row['signal_deadline'], 'signal_operation_time')
    shutdown_cases.validate_signal(facts, True)
    state['now'] = max(state['now'], returned)
    return dict(facts)


def signal(state: TransportState, owned_signal: OwnedSignal, context: Context, deadline: int) -> SignalFacts:
    try:
        row = active_entry(state, context, deadline)
        require(not row['signal_started'] and callable(owned_signal), 'signal_one_shot')
        row['signal_started'] = True
        require(deadline == min(catalogue.add_u64(context['now'], 15 * UNITS), row['case_deadline'], row['whole_deadline']), 'signal_grace')
        row['signal_deadline'] = deadline
        row['frozen_counts'] = tuple(coordinator.snapshot_counts(context).items())
        native_closing.freeze_checkpoint(context, row['wrapped'], row['observer'], row['receive_state'], deadline)
        state['busy'] = True
        owned(state, deadline)
        start = sample(state, deadline)
        evidence = owned_signal(state['child'], row['handle'], deadline)
        row['signal_evidence'] = evidence
        facts = validate_signal_evidence(state, row, evidence, start)
        row['signal_facts'] = tuple(sorted(facts.items()))
        validate_active_bindings(state, row, context)
        require(state['failure'] is None, 'signal_nested_failure')
        capture(state, deadline)
        row['signal_return'] = sample(state, deadline)
        require(state['failure'] is None, 'signal_postcheck_failure')
        return facts
    except BaseException as error:
        primary = error if state['failure'] is None else state['failure']
        fail_transport(state, primary)
        raise primary
    finally:
        state['busy'] = False


def termination(state: TransportState, context: Context, deadline: int) -> TerminationFacts:
    try:
        row = active_entry(state, context, deadline)
        require(row['signal_facts'] is not None and row['signal_return'] is not None and
                deadline == row['signal_deadline'] and not row['termination_started'], 'termination_authorization')
        row['termination_started'] = True
        capture(state, deadline)
        require(state['failure'] is None, 'activation_capture_failure')
        native_closing.activate(context, row['wrapped'], row['observer'], row['receive_state'], dict(row['signal_facts']), deadline)
        facts, receipt = native_closing.drain_closing(context, row['wrapped']['receive'], row['observer'], row['receive_state'], deadline)
        row['terminal_facts'] = tuple(sorted(facts.items()))
        validate_active_bindings(state, row, context)
        state['busy'] = True
        result = state['ops']['close'](row['handle'])
        require(result is None, 'active_close_shape')
        row['closed'] = True
        require(state['failure'] is None, 'active_close_nested_failure')
        sample(state, deadline)
        capture(state, deadline)
        require(state['failure'] is None, 'active_close_postcheck_failure')
        validate_active_bindings(state, row, context)
        require(native_closing.local_receipt(row['receive_state']) is receipt, 'active_terminal_changed')
        row['release'] = dict(method='close', client_closed=True, close='normal')
        return dict(facts)
    except BaseException as error:
        primary = error if state['failure'] is None else state['failure']
        fail_transport(state, primary)
        raise primary
    finally:
        state['busy'] = False


def active_receipt(state: TransportState, row: ConnectionRecord) -> TransportReceipt:
    context = row['context_binding'][0]
    validate_active_bindings(state, row, context)
    require(row['terminal_facts'] is not None and context['request']['transport_closed'] is True and
            context['raw']['closed'] is True and not context['records'] and not context['stage']['active'] and
            context['stage']['signaled'] is True, 'active_canonical_finish')
    receive_state = row['receive_state']
    receipt = native_closing.local_receipt(receive_state)
    require(row['observer']['operation'] == receipt[3][0] and not row['observer']['busy'] and
            not row['observer']['sealed'] and row['observer']['failure'] == receipt[4] and
            native_closing.counts(receive_state) == receipt[2][1], 'active_receipt_stale')
    require(receipt[0] is receive_state['checkpoint'] and
            dict(row['frozen_counts']) == descriptors.receipt_counts((receipt[0][0],)), 'active_prefix_accounting')
    return row['identity'], 'active', receive_state['checkpoint'], receipt


def transport_receipt(state: TransportState, connection_identity: oracle.ConnectionIdentity) -> TransportReceipt:
    """Validate current health on every consumption; a saved tuple is not authority."""
    try:
        require(state['failure'] is None and not state['busy'], 'receipt_transport_failed')
        matches = [row for row in state['history'] if row['identity'] == connection_identity]
        require(len(matches) == 1, 'receipt_unique_identity')
        row = matches[0]
        require(row['closed'] and row['release'] is not None and not row['cleanup_started'], 'receipt_release')
        expected = dict(method='close', client_closed=True, close='normal')
        if row['identity'][1:] == ('disconnect', 1):
            expected = dict(method='ssl_unwrap', tls_shutdown='success', tcp_eof=True, trailing_bytes=0, close='normal')
        require(type(row['release']) is dict and row['release'] == expected and
                all(type(row['release'][key]) is type(value) for key, value in expected.items()), 'receipt_release_facts')
        validate_callbacks(row)
        if row['receive_state'] is not None:
            return active_receipt(state, row)
        observer = row['observer']
        require(observer['failure'] is None and not observer['busy'], 'receipt_observer_health')
        if row['receipt'] is None:
            require(not observer['sealed'], 'receipt_already_sealed')
            row['receipt'] = oracle.seal(observer)
            row['receipt_operation'] = observer['operation']
        require(observer['sealed'] and observer['operation'] == row['receipt_operation'] and
                oracle.connection_receipt(observer) == row['receipt'], 'receipt_observer_stale')
        return row['identity'], 'ordinary', row['receipt'], None
    except BaseException as error:
        fail_transport(state, error)
        raise


if __name__ == '__main__':
    pass
