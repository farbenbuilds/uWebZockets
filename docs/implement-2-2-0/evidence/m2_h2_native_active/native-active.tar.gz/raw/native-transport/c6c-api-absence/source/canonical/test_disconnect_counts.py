"""Disconnect shares case counters while keeping connection stages separate."""
import output_stage


def done(stage, stream):
    output_stage.frame(stage, 0, 1, 5, stream, False)
    output_stage.finished(stage, 1, 5, stream)
    output_stage.retire(stage, stream)


def check():
    case = output_stage.new_case('disconnect')
    first = output_stage.new_stage(case, 3, 1, 10, 100)
    output_stage.frame(first, 30, 4, 0, 0, False)
    output_stage.register(first, 1, 'small')
    done(first, 1)
    output_stage.register(first, 3, 'transport', primary=True)
    output_stage.register(first, 5, 'small')
    done(first, 5)
    try:
        output_stage.new_stage(case, 1, 1, 10, 100)
    except ValueError as error:
        if str(error) != 'replacement before transport terminal':
            raise
    else:
        raise RuntimeError('premature replacement accepted')
    output_stage.transport_ended(first, 3, {'closed': True, 'streams': {}})
    second = output_stage.new_stage(case, 1, 1, 10, 100)
    output_stage.frame(second, 30, 4, 0, 0, False)
    for stream in range(1, 44, 2):
        output_stage.register(second, stream, 'small', primary=(stream == 1))
        done(second, stream)
    if case['heads'] != 25 or case['small'] != 24 or case['connections'] != 2:
        raise RuntimeError('disconnect totals differ')
    output_stage.read(first, b'a')
    for _ in range(4095):
        output_stage.read(second, b'b')
    try:
        output_stage.read(second, b'c')
    except ValueError as error:
        if str(error) != 'read cap exceeded':
            raise
    else:
        raise RuntimeError('cumulative disconnect read cap missed')
    if first['high_water'] != 5 or second['high_water'] != 43:
        raise RuntimeError('connection identity lost')
    print('disconnect case counters passed')


if __name__ == '__main__':
    check()
