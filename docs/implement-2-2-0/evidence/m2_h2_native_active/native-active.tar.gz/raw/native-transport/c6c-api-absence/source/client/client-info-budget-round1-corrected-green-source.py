"""Bounded owned HTTP/2 client helpers; live use requires Root source approval."""

import hashlib
import json
import socket
import ssl
import sys

import h2.config
import h2.connection
import h2.events

BOUND = 8192
CAPTURE = 65536
INFO_COUNT_LIMIT = 16
INFO_HEADER_BUDGET = 16384
SENTINEL = b"final-upload-sentinel!"


def require(condition, detail):
    if not condition:
        raise RuntimeError(detail)


def payload_block(total, offset, count):
    require(0 <= offset <= total and 0 <= count <= min(BOUND, total - offset), "invalid payload bounds")
    pattern = bytes(range(1, 252))
    start = offset % len(pattern)
    block = bytearray((pattern * ((start + count + 250) // 251))[start:start + count])
    marker_start = total - len(SENTINEL)
    marker = max(offset, marker_start)
    end = offset + count
    if marker < end:
        block[marker - offset:end - offset] = SENTINEL[marker - marker_start:end - marker_start]
    require(len(block) == count, "payload generator exceeded its offered window")
    return bytes(block)


def new_protocol():
    protocol = h2.connection.H2Connection(config=h2.config.H2Configuration(
        client_side=True, header_encoding="utf-8", validate_inbound_headers=True,
        validate_outbound_headers=True))
    protocol.initiate_connection()
    return protocol


def new_trace():
    return {"sent_wire_bytes": 0, "received_wire_bytes": 0,
            "received_flow_bytes": 0, "received_payload_bytes": 0,
            "window_updates": {}, "window_samples": [], "events": {},
            "connection_terminal": None}


def register_response(responses, stream_id, capture_limit=CAPTURE):
    require(stream_id not in responses and 0 <= capture_limit <= CAPTURE,
            "duplicate stream or invalid capture limit")
    responses[stream_id] = {"headers": [], "trailers": [], "informational": [],
                            "informational_bytes": 0,
                            "bytes": 0, "digest": hashlib.sha256(), "prefix": bytearray(),
                            "capture_limit": capture_limit, "ended": False, "reset": None}


def accept_bytes(protocol, data, responses, trace):
    trace["received_wire_bytes"] += len(data)
    for event in protocol.receive_data(data):
        name = type(event).__name__
        trace["events"][name] = trace["events"].get(name, 0) + 1
        if isinstance(event, h2.events.WindowUpdated):
            key = str(event.stream_id)
            trace["window_updates"][key] = trace["window_updates"].get(key, 0) + event.delta
            if len(trace["window_samples"]) < 32:
                trace["window_samples"].append({"stream": event.stream_id, "delta": event.delta})
            continue
        if isinstance(event, h2.events.ConnectionTerminated):
            trace["connection_terminal"] = {"error": int(event.error_code), "last_stream": event.last_stream_id}
            continue
        if not isinstance(event, (h2.events.InformationalResponseReceived,
                                  h2.events.ResponseReceived, h2.events.TrailersReceived,
                                  h2.events.DataReceived, h2.events.StreamEnded, h2.events.StreamReset)):
            continue
        require(event.stream_id in responses, "response on an unopened client stream")
        record = responses[event.stream_id]
        if isinstance(event, h2.events.InformationalResponseReceived):
            require(len(record["informational"]) < INFO_COUNT_LIMIT,
                    "informational response count limit exceeded")
            header_bytes = sum(32 + len(name.encode("utf-8")) + len(value.encode("utf-8"))
                               for name, value in event.headers)
            require(header_bytes <= INFO_HEADER_BUDGET - record["informational_bytes"],
                    "informational response header budget exceeded")
            record["informational"].append(list(event.headers))
            record["informational_bytes"] += header_bytes
        elif isinstance(event, h2.events.TrailersReceived):
            record["trailers"].extend(event.headers)
        elif isinstance(event, h2.events.ResponseReceived):
            require(not record["headers"], "duplicate final response headers")
            record["headers"] = list(event.headers)
        elif isinstance(event, h2.events.DataReceived):
            require(not record["ended"], "DATA after stream end")
            record["bytes"] += len(event.data)
            record["digest"].update(event.data)
            room = record["capture_limit"] - len(record["prefix"])
            record["prefix"].extend(event.data[:room])
            trace["received_payload_bytes"] += len(event.data)
            trace["received_flow_bytes"] += event.flow_controlled_length
            protocol.acknowledge_received_data(event.flow_controlled_length, event.stream_id)
        elif isinstance(event, h2.events.StreamEnded):
            require(not record["ended"], "duplicate stream end")
            record["ended"] = True
        elif isinstance(event, h2.events.StreamReset):
            record["reset"] = int(event.error_code)


def response_summary(record):
    return {"headers": record["headers"], "trailers": record["trailers"],
            "informational": record["informational"],
            "informational_bytes": record["informational_bytes"], "bytes": record["bytes"],
            "sha256": record["digest"].hexdigest(), "prefix_hex": bytes(record["prefix"]).hex(),
            "captured_bytes": len(record["prefix"]), "ended": record["ended"], "reset": record["reset"]}


def start_request(protocol, responses, authority, path, *, method="GET", headers=(), end_stream=True):
    stream_id = protocol.get_next_available_stream_id()
    register_response(responses, stream_id)
    fields = [(":method", method), (":scheme", "https"), (":authority", authority), (":path", path)]
    fields.extend(headers)
    protocol.send_headers(stream_id, fields, end_stream=end_stream)
    return stream_id


def flush(sock, protocol, trace):
    pending = protocol.data_to_send()
    if pending:
        sock.sendall(pending)
        trace["sent_wire_bytes"] += len(pending)


def receive(sock, protocol, responses, trace):
    data = sock.recv(65536)
    require(data, "TLS EOF before requested HTTP/2 stream completion")
    accept_bytes(protocol, data, responses, trace)
    flush(sock, protocol, trace)


def wait_response(sock, protocol, responses, trace, stream_id):
    while not responses[stream_id]["ended"]:
        require(responses[stream_id]["reset"] is None, "stream reset before response completion")
        require(trace["connection_terminal"] is None, "connection ended before response completion")
        receive(sock, protocol, responses, trace)
    return response_summary(responses[stream_id])


def send_upload(sock, protocol, responses, trace, stream_id, total, *, trailers=None):
    count = 0
    digest = hashlib.sha256()
    while count < total:
        require(responses[stream_id]["reset"] is None and not responses[stream_id]["ended"],
                "upload terminated before all logical bytes were sent")
        require(trace["connection_terminal"] is None, "connection ended before upload completion")
        available = min(protocol.local_flow_control_window(stream_id), protocol.max_outbound_frame_size,
                        BOUND, total - count)
        if available <= 0:
            receive(sock, protocol, responses, trace)
            continue
        block = payload_block(total, count, available)
        final = count + available == total and trailers is None
        protocol.send_data(stream_id, block, end_stream=final)
        flush(sock, protocol, trace)
        digest.update(block)
        count += len(block)
    if trailers is not None:
        protocol.send_headers(stream_id, trailers, end_stream=True)
        flush(sock, protocol, trace)
    elif total == 0:
        protocol.send_data(stream_id, b"", end_stream=True)
        flush(sock, protocol, trace)
    return {"bytes": count, "sha256": digest.hexdigest()}


def connect_tls(port, certificate):
    context = ssl.create_default_context(cafile=str(certificate))
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    context.maximum_version = ssl.TLSVersion.TLSv1_3
    context.set_alpn_protocols(["h2"])
    raw = socket.create_connection(("127.0.0.1", port), timeout=30)
    sock = None
    try:
        sock = context.wrap_socket(raw, server_hostname="localhost", suppress_ragged_eofs=False)
        sock.settimeout(120)
        require(sock.selected_alpn_protocol() == "h2" and sock.version() == "TLSv1.3", "TLS/ALPN differs")
    except BaseException:
        if sock is not None:
            sock.close()
        else:
            raw.close()
        raise
    return sock


def self_check():
    client = new_protocol()
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False))
    server.initiate_connection()
    responses, trace = {}, new_trace()
    server.receive_data(client.data_to_send())
    accept_bytes(client, server.data_to_send(), responses, trace)
    stream_id = start_request(client, responses, "localhost", "/self-check")
    server.receive_data(client.data_to_send())
    server.send_headers(stream_id, [(":status", "100")])
    server.send_headers(stream_id, [(":status", "200"), ("content-length", "9")])
    server.send_data(stream_id, b"body-part", pad_length=7)
    server.send_headers(stream_id, [("x-trailer", "retained")], end_stream=True)
    wire = server.data_to_send()
    for start in range(0, len(wire), 3):
        accept_bytes(client, wire[start:start + 3], responses, trace)
    value = response_summary(responses[stream_id])
    require(value["ended"] and value["bytes"] == 9 and value["reset"] is None, "self-check body/end differs")
    require(value["sha256"] == hashlib.sha256(b"body-part").hexdigest(), "self-check body digest differs")
    require(value["informational"] == [[(":status", "100")]], "informational status lost")
    require(value["trailers"] == [("x-trailer", "retained")], "trailer lost")
    require(trace["received_flow_bytes"] == 17 and trace["received_payload_bytes"] == 9,
            "padding was omitted from receive-credit acknowledgement")
    expected = bytes(range(1, 11)) + b"final-upload-sentinel!"
    for split in range(33):
        actual = payload_block(32, 0, split) + payload_block(32, split, 32 - split)
        require(actual == expected, "flow-window split changes the final payload sentinel")
    count, digest = 0, hashlib.sha256()
    for offset in range(0, 100000000, BOUND):
        block = payload_block(100000000, offset, min(BOUND, 100000000 - offset))
        count += len(block)
        digest.update(block)
    require(count == 100000000 and digest.hexdigest() ==
            "190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2",
            "bounded upload generator differs from reviewed logical payload")
    return {"pure_protocol_pair": "hyper-h2 only", "uWebZockets_tested": False,
            "network_contact": False, "fragment_bytes": 3, "response": value,
            "padding_flow_bytes": trace["received_flow_bytes"], "payload_bytes": count,
            "payload_sha256": digest.hexdigest()}


if __name__ == "__main__":
    require(sys.argv[1:] == ["--self-check"], "only --self-check is prepared; live runner is separate")
    print(json.dumps(self_check(), indent=2))
