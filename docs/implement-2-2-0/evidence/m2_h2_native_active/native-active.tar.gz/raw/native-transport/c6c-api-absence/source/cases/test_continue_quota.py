"""Bounded serialized Continue/quota peer with independent application facts."""
import hashlib
import json
import adapter
import cases
import catalogue
import h2_client
import hpack
import model
import test_ready
from test_core_peer import frame, metrics, new_app, require


NAMES = ('continue_ready', 'continue_paused', 'quota_refuse', 'begin_failure_rollback')


def tags(case):
    if case == 'quota_refuse':
        return ('quota_holder_one', 'quota_holder_two', 'quota_refuse', 'quota_recovery_one', 'quota_recovery_two')
    if case == 'begin_failure_rollback':
        return ('begin_failure', 'begin_recovery')
    return (case,)


def schedule(case):
    paths = ('/health',)
    for tag in tags(case):
        if tag == 'quota_refuse':
            paths += ('/metrics',)
        paths += (model.request_contract(tag)['target'],)
        if tag == 'continue_paused':
            paths += ('/status/continue_paused', '/resume/continue_paused')
        if tag == 'quota_refuse':
            paths += ('/metrics',)
        if tag == 'quota_recovery_two':
            paths += ('/metrics', '/metrics')
    return paths + ('/health',)


def check_storage(state):
    require(len(state['buffer']) <= 8201, 'parser storage bound differs')
    require(len(state['pending']) <= 2 and sum(map(len, state['pending'])) <= 16384, 'pending storage bound differs')
    require(all(type(packet) is bytes and 0 < len(packet) <= 8192 for packet in state['pending']), 'pending packet bound differs')
    require(len(state['uploads']) <= len(tags(state['case'])) and len(state['slots']) == 2, 'upload or slot bound differs')
    require(0 <= state['cursor'] <= state['head_limit'] and state['heads'] == state['cursor'], 'finite cursor differs')
    require(0 <= state['received'] <= state['head_limit'] + 2 and state['received_bytes'] <= (state['head_limit'] + 2) * 8192,
            'receive bound differs')
    require(state['decoder'].max_allowed_table_size == 4096 and state['encoder'].header_table_size == 4096,
            'HPACK table bound differs')
    state['max_buffer'] = max(state['max_buffer'], len(state['buffer']))
    state['max_pending'] = max(state['max_pending'], len(state['pending']))
    state['max_pending_bytes'] = max(state['max_pending_bytes'], sum(map(len, state['pending'])))


def queue(state, packets):
    require(len(state['pending']) + len(packets) <= 2 and
            sum(map(len, state['pending'])) + sum(map(len, packets)) <= 16384, 'pending storage bound differs')
    require(all(type(packet) is bytes and 0 < len(packet) <= 8192 for packet in packets), 'pending packet bound differs')
    state['pending'].extend(packets)
    check_storage(state)


def respond(state, stream, body, refusal=False):
    require(len(body) <= 4095 and len(state['pending']) < 2, 'response queue or body bound differs')
    block = state['encoder'].encode(((':status', '503' if refusal else '200'), ('x-middleware', 'retained')))
    if not refusal:
        packets = (frame(1, 4, stream, block) + frame(0, 1, stream, body),)
    else:
        end, reset = frame(1, 5, stream, block), frame(3, 0, stream, bytes(4))
        packets = (end, reset)
        if state['fault'] == 'reset_first':
            packets = (reset + end,)
        if state['fault'] == 'refusal_continue':
            info = state['encoder'].encode(((':status', '100'),))
            packets = (frame(1, 4, stream, info) + end + reset,)
        if state['fault'] == 'refusal_data':
            packets = (frame(1, 4, stream, block) + frame(0, 1, stream, b'x') + reset,)
    queue(state, packets)
    state['responses_queued'] += 1
    state['resets_queued'] += int(refusal)


def release_slot(state, tag):
    require(tag in state['slots'], 'release without slot')
    state['slots'][state['slots'].index(tag)] = None
    state['released'] += 1


def finish(state, app, tag):
    upload, item = state['uploads'][tag], app['records'][tag]
    require(not upload['terminal'] and upload['ends'] == 1 and upload['count'] == 32, 'terminal before body END')
    release_slot(state, tag)
    item.update(bytes=upload['count'], sha256=upload['digest'].hexdigest(), chunks=upload['frames'], max_span=32,
                ends=1, active=False, paused=False)
    upload['terminal'] = True
    respond(state, upload['stream'], json.dumps(item).encode())


def upload_headers(state, app, tag, stream):
    upload = dict(stream=stream, count=0, frames=0, ends=0, terminal=False, digest=hashlib.sha256(),
                  info_queued=False, info_delivered=False)
    state['uploads'][tag] = upload
    item = app['records'][tag]
    item['middleware'] = 1
    if tag == 'quota_refuse':
        upload['terminal'] = True
        respond(state, stream, b'', True)
        return
    state['slots'][state['slots'].index(None)] = tag
    state['allocated'] += 1
    item['attempts'] = 1
    if tag == 'begin_failure':
        item['failures'] = 1
        release_slot(state, tag)
        state['rollbacks'] += 1
        upload['terminal'] = True
        respond(state, stream, b'', True)
        return
    item.update(begins=1, active=True)
    if not tag.startswith('continue_'):
        return
    if state['fault'] == 'missing_continue':
        respond(state, stream, b'')
        return
    block = state['encoder'].encode(((':status', '100'),))
    queue(state, (frame(1, 4, stream, block),))
    upload['info_queued'] = True
    state['informationals_queued'] += 1


def data_received(state, app, packet):
    stream, payload, flags = int.from_bytes(packet[5:9], 'big'), packet[9:], packet[4]
    found = tuple(tag for tag, upload in state['uploads'].items() if upload['stream'] == stream)
    require(len(found) == 1, 'DATA stream differs')
    tag = found[0]
    upload = state['uploads'][tag]
    if tag.startswith('continue_'):
        require(upload['info_delivered'], 'DATA before delivered Continue')
    require(not upload['terminal'] and upload['frames'] == 0 and flags == 1 and len(payload) == 32,
            'DATA ordinal differs')
    require(payload == model.payload_span(32, 0, 32), 'request body differs')
    if state['case'] == 'quota_refuse':
        expected = ('quota_holder_one', 'quota_holder_two', 'quota_recovery_one', 'quota_recovery_two')[state['frames']]
        require(tag == expected and state['cursor'] == (5 if state['frames'] < 2 else 9) and
                state['metric_delivered'] == (1 if state['frames'] < 2 else 3), 'quota DATA barrier differs')
        require(state['frames'] >= 2 or state['resets_delivered'] == 1, 'quota refusal not delivered')
    else:
        require(state['cursor'] == (3 if tag == 'begin_recovery' else 2), 'DATA schedule differs')
    require(len(state['pending']) < 2, 'response queue or body bound differs')
    upload['digest'].update(payload)
    upload.update(count=32, frames=1, ends=1)
    state['data'] += 32
    state['frames'] += 1
    state['ends'] += 1
    if tag == 'continue_paused':
        app['records'][tag]['paused'] = True
        if state['fault'] == 'early_final':
            respond(state, stream, b'')
        return
    finish(state, app, tag)


def request_path(state):
    paths, cursor = schedule(state['case']), state['cursor']
    if cursor < len(paths):
        return paths[cursor]
    require(state['final'] and cursor < len(paths) + 68, 'request beyond finite schedule')
    require(len(state['uploads']) == len(tags(state['case'])) and all(upload['terminal'] for upload in state['uploads'].values()),
            'final before ordinary completion')
    return '/metrics' if cursor - len(paths) == 67 else '/status/' + model.BODY_SPECS[cursor - len(paths)][0]


def request_barrier(state, path):
    cursor = state['cursor']
    if cursor <= 1:
        return
    if state['case'] == 'quota_refuse' and cursor < 10:
        expected = {2: 1, 3: 2, 4: 2, 5: 0, 6: 0, 7: 1, 8: 2, 9: 0}[cursor]
        require(sum(tag is not None for tag in state['slots']) == expected, 'quota slot barrier differs')
        require(state['metric_delivered'] == {2: 0, 3: 0, 4: 1, 5: 1, 6: 2, 7: 2, 8: 2, 9: 3}[cursor],
                'quota metric delivery differs')
        return
    if state['case'] == 'continue_paused' and cursor in (2, 3):
        upload = state['uploads']['continue_paused']
        require(upload['ends'] == 1 and not upload['terminal'], 'pause status before DATA END')
        require(cursor == 2 or state['pause_delivered'], 'resume before delivered paused status')
        return
    require(all(upload['terminal'] for upload in state['uploads'].values()) and state['slots'] == [None, None],
            'request before terminal or rollback')
    if path == '/health' or cursor >= len(schedule(state['case'])):
        require(len(state['uploads']) == len(tags(state['case'])), 'recovery missing')


def header_contract(path):
    auxiliary = path.startswith(('/health', '/status/', '/metrics', '/resume/'))
    tag = None if auxiliary else path.split('/')[-1]
    contract = None if auxiliary else model.request_contract(tag)
    expected = [(':method', 'GET' if auxiliary else contract['method']), (':scheme', 'https'),
                (':authority', 'localhost'), (':path', path)]
    if not auxiliary:
        expected.append(('content-length', str(contract['declared'])))
    if tag in ('continue_ready', 'continue_paused', 'quota_refuse', 'begin_failure'):
        expected.append(('expect', '100-continue'))
    return tag, expected, 5 if auxiliary else 4


def auxiliary(state, app, path, stream):
    if path == '/resume/continue_paused':
        require(not state['resumed'], 'duplicate resume')
        state['resumed'] = True
        respond(state, stream, b'ok')
        finish(state, app, 'continue_paused')
        return
    if path.startswith('/status/'):
        item = dict(app['records'][path[8:]])
        if state['cursor'] == 3 and state['case'] == 'continue_paused':
            state['pause_queued'] = True
            if state['fault'] == 'paused_bytes':
                item['bytes'] = 1
        if state['fault'] == 'wrong_failure' and path == '/status/begin_failure':
            item['failures'] = 0
        if state['fault'] == 'other_record' and path == '/status/empty_headers':
            item['middleware'] = 1
        respond(state, stream, json.dumps(item).encode())
        return
    if path == '/health':
        respond(state, stream, b'ok')
        return
    require(path == '/metrics', 'unexpected request')
    item = metrics(app)
    item.update(slot0_active=state['slots'][0] is not None, slot1_active=state['slots'][1] is not None)
    if state['case'] == 'quota_refuse' and state['cursor'] <= len(schedule(state['case'])):
        require(state['metric_cursor'] < 4 and item['active'] == (2, 0, 2, 0)[state['metric_cursor']], 'quota metrics order differs')
        state['metric_cursor'] += 1
        if state['fault'] == 'active_count' and state['metric_cursor'] == 1:
            item['active'] = 1
    respond(state, stream, json.dumps(item).encode())


def request_received(state, app, packet):
    early_final_status = state['fault'] == 'early_final' and state['case'] == 'continue_paused' and state['cursor'] == 2
    require(state['acks'] == 1 and (not state['pending'] or early_final_status), 'request before preceding response')
    path = request_path(state)
    request_barrier(state, path)
    tag, expected, flags = header_contract(path)
    entries = list(state['decoder'].decode(packet[9:]))
    stream = int.from_bytes(packet[5:9], 'big')
    require(entries == expected and stream == 2 * state['cursor'] + 1 and packet[4] == flags, 'request contract differs')
    require(state['cursor'] < state['head_limit'], 'request beyond finite schedule')
    if tag is not None:
        require(tag not in state['uploads'] and len(state['uploads']) < len(tags(state['case'])), 'upload map bound differs')
        require((None not in state['slots']) if tag == 'quota_refuse' else (None in state['slots']), 'admission slot barrier differs')
    state['heads'] += 1
    state['cursor'] += 1
    app['heads'] += 1
    if state['cursor'] > len(schedule(state['case'])):
        state['final_requests'] += 1
    if tag is not None:
        upload_headers(state, app, tag, stream)
        return
    auxiliary(state, app, path, stream)


def packet_received(state, app, packet):
    if packet[3] == 4:
        require(packet == frame(4, 1, 0, b'') and state['acks'] == 0 and state['cursor'] == 0, 'settings ACK differs')
        state['acks'] += 1
        return
    if packet[3] == 0:
        data_received(state, app, packet)
        return
    require(packet[3] == 1, 'unexpected frame type')
    request_received(state, app, packet)


def send_bytes(state, app, data):
    check_storage(state)
    require(type(data) is bytes and 0 < len(data) <= 8192, 'send span differs')
    if state['startup']:
        expected = b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n'
        expected += frame(4, 0, 0, b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                                        ((1, 4096), (2, 1), (4, 65535), (5, 16384), (8, 0), (3, 100), (6, 65536))))
        require(data == expected, 'startup bytes differ')
        state['startup'] = False
        state['settings'] += 1
        return
    require(len(data) <= 8201 - len(state['buffer']), 'parser storage bound differs')
    prefix = bytes(state['buffer'][:9]) + data[:max(0, 9 - len(state['buffer']))]
    require(len(prefix) < 3 or int.from_bytes(prefix[:3], 'big') <= 8192, 'frame payload bound differs')
    state['buffer'].extend(data)
    check_storage(state)
    while len(state['buffer']) >= 9:
        size = int.from_bytes(state['buffer'][:3], 'big')
        require(size <= 8192, 'frame payload bound differs')
        if len(state['buffer']) < size + 9:
            return
        packet = bytes(state['buffer'][:size + 9])
        del state['buffer'][:size + 9]
        packet_received(state, app, packet)
        check_storage(state)


def delivered(state, data):
    offset = 0
    while offset < len(data):
        size, kind = int.from_bytes(data[offset:offset + 3], 'big'), data[offset + 3]
        stream = int.from_bytes(data[offset + 5:offset + 9], 'big')
        informational = False
        for upload in state['uploads'].values():
            if kind == 1 and upload['stream'] == stream and upload['info_queued'] and not upload['info_delivered']:
                upload['info_delivered'] = True
                informational = True
        state['informationals_delivered'] += int(informational)
        state['responses_delivered'] += int(kind == 1 and not informational)
        state['resets_delivered'] += int(kind == 3)
        offset += 9 + size


def new_peer(case, *, app, prior, now, clock, final=False, fault=None):
    """Caller-owned facts; <=8201 parser bytes, <=2 packets/16384 bytes,
    <=5 upload summaries/two slots, bounded HPACK and scalar read/schedule receipts.
    Ownership, TLS and ALPN are supplied synthetic transport facts.
    """
    require(type(case) is str and case in NAMES, 'unsupported Continue peer')
    require(type(app) is dict and set(app) == {'records', 'heads', 'outputs', 'binding'}, 'app fields differ')
    catalogue.schedule(prior)
    require(case not in prior and type(final) is bool and type(now) is int and 0 <= now < catalogue.U64 and callable(clock), 'peer arguments differ')
    require(fault is None or type(fault) is str and fault in ('wrong_failure', 'other_record', 'missing_continue', 'refusal_continue', 'refusal_data', 'reset_first', 'active_count', 'paused_bytes', 'early_final'), 'peer fault differs')
    allowed = {'wrong_failure': ('begin_failure_rollback',), 'other_record': ('begin_failure_rollback',),
               'missing_continue': ('continue_ready', 'continue_paused'), 'refusal_continue': ('quota_refuse', 'begin_failure_rollback'),
               'refusal_data': ('quota_refuse', 'begin_failure_rollback'), 'reset_first': ('quota_refuse', 'begin_failure_rollback'),
               'active_count': ('quota_refuse',), 'paused_bytes': ('continue_paused',), 'early_final': ('continue_paused',)}
    require(fault is None or case in allowed[fault], 'fault case differs')
    model.validate_records(prior, 'before', app['records'])
    model.validate_outputs(prior, app['outputs'])
    model.validate_binding_pre_post(prior, app['binding'], model.default_binding() if app['binding'] is None else app['binding'],
                                    app['outputs']['producer_reuse'] if 'producer_reuse' in prior else None)
    require(type(app['heads']) is int and app['heads'] == sum(catalogue.case_budget(item)['heads'] for item in prior), 'prior heads not earned')
    if not prior:
        require(app['heads'] == 0 and app['binding'] is None, 'empty prior app differs')
    settings = b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    state = dict(case=case, final=final, fault=fault, startup=True, buffer=bytearray(),
                 pending=[frame(4, 0, 0, settings) + frame(4, 1, 0, b'')], uploads={},
                 cursor=0, heads=0, head_limit=len(schedule(case)) + 68 * int(final), settings=0, acks=0,
                 received=0, received_bytes=0, data=0, frames=0, ends=0, final_requests=0,
                 slots=[None, None], allocated=0, released=0, rollbacks=0, resumed=False,
                 pause_queued=False, pause_delivered=False, metric_cursor=0, metric_delivered=0,
                 informationals_queued=0, informationals_delivered=0, responses_queued=0, responses_delivered=0,
                 resets_queued=0, resets_delivered=0, max_buffer=0, max_pending=0, max_pending_bytes=0,
                 decoder=hpack.Decoder(max_header_list_size=4096), encoder=hpack.Encoder())

    def send(data):
        send_bytes(state, app, data)

    def receive():
        require(not state['startup'] and bool(state['pending']), 'finite peer input missing')
        check_storage(state)
        require(state['received'] < state['head_limit'] + 2, 'receive bound differs')
        data = state['pending'][0]
        require(len(data) <= (state['head_limit'] + 2) * 8192 - state['received_bytes'], 'receive byte bound differs')
        stamp = clock()
        state['pending'].pop(0)
        state['received'] += 1
        state['received_bytes'] += len(data)
        delivered(state, data)
        if not state['pending']:
            state['pause_delivered'] = state['pause_queued']
            state['metric_delivered'] = state['metric_cursor']
        return data, stamp

    check_storage(state)
    connection = dict(protocol=h2_client.new_protocol(), send=send, receive=receive, now=now, owned=True, tls='TLSv1.3', alpn='h2')
    return dict(connection=connection, state=state)


def check(case, *, app=None, prior=(), final=False, fault=None):
    app = new_app() if app is None else app
    peer = new_peer(case, app=app, prior=prior, now=1, clock=lambda: 2, final=final, fault=fault)
    connection, state = peer['connection'], peer['state']
    context = adapter.open_case(case, connection['protocol'], connection['send'], 1, 30001, 900001,
                                selected_before=prior, clock=lambda: 2)
    adapter.observe(context, *connection['receive']())
    adapter.run_case(context, connection['receive'])
    if final:
        adapter.final_collection(context, connection['receive'])
    require(state['cursor'] == state['head_limit'] and not state['pending'] and not state['buffer'], 'request order differs')
    require(state['slots'] == [None, None] and state['allocated'] == state['released'], 'slots not released')
    if case == 'quota_refuse':
        require(state['metric_cursor'] == state['metric_delivered'] == 4, 'quota metrics order differs')
    for tag, upload in state['uploads'].items():
        body = b'' if tag in ('quota_refuse', 'begin_failure') else model.payload_span(32, 0, 32)
        require(upload['frames'] == upload['ends'] == int(bool(body)) and upload['count'] == len(body) and
                upload['digest'].digest() == hashlib.sha256(body).digest(), 'request body differs')
    model.validate_records(prior + (case,), 'before', app['records'])
    print(case + ' passed: heads=%d flow=%d' % (context['stage']['limits']['heads'], context['request']['case']['sent']))
    return app


def before_continue():
    context = adapter.open_case('continue_ready', h2_client.new_protocol(), lambda _data: None,
                                1, 30001, 900001, clock=lambda: 2)
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    adapter.observe(context, test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b''), 2)
    adapter.start(context, 'GET', '/health', (), True, False, 2)
    stream = adapter.start(context, 'POST', '/limit/continue_ready',
                           (('content-length', '32'), ('expect', '100-continue')), False, True, 4095, info=1)
    try:
        adapter.send_data(context, stream, model.payload_span(32, 0, 32), True)
    except ValueError as exc:
        if str(exc) != 'DATA before Continue or after terminal':
            raise
        print('pre-Continue DATA rejected: ' + str(exc))
    else:
        raise RuntimeError('pre-Continue DATA accepted')


def main():
    before_continue()
    if len([case for case in catalogue.CASES if case not in cases.IMPLEMENTED]) != 0:
        raise RuntimeError('unsupported inventory differs')
    for case in NAMES:
        check(case)
    app, prior = None, ()
    for case in NAMES:
        app = check(case, app=app, prior=prior, final=case == NAMES[-1])
        prior += (case,)
    for fault, message in (('wrong_failure', 'record mismatch: failures'),
                           ('other_record', 'record mismatch: middleware')):
        try:
            check('begin_failure_rollback', final=True, fault=fault)
        except ValueError as exc:
            if str(exc) != message:
                raise RuntimeError('final fault rejected for wrong reason: ' + fault) from exc
            print(fault + ' rejected: ' + str(exc))
        else:
            raise RuntimeError('final fault accepted: ' + fault)
    for fault, case, message in (('missing_continue', 'continue_ready', 'invalid DATA'),
                                 ('refusal_continue', 'begin_failure_rollback', 'invalid HEADERS'),
                                 ('refusal_data', 'quota_refuse', 'response body bound'),
                                 ('reset_first', 'begin_failure_rollback', 'reset order'),
                                 ('active_count', 'quota_refuse', 'quota active barrier differs'),
                                 ('paused_bytes', 'continue_paused', 'record mismatch: bytes'),
                                 ('early_final', 'continue_paused', 'invalid terminal')):
        try:
            check(case, fault=fault)
        except ValueError as exc:
            if str(exc) != message:
                raise RuntimeError('fault rejected for wrong reason: ' + fault) from exc
            print(fault + ' rejected: ' + str(exc))
        else:
            raise RuntimeError('fault accepted: ' + fault)


if __name__ == '__main__':
    main()
