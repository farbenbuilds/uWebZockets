"""Exercise final diagnostic requests through public in-memory HTTP/2 codecs."""
import h2_client
import json
import hpack
import model
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def frame(kind, flags, stream, payload):
    return len(payload).to_bytes(3, 'big') + bytes((kind, flags)) + stream.to_bytes(4, 'big') + payload


def run_response(protocol, stage, request, response, raw, records, trace, encoder, stream, path, primary, body=None):
    actual, chunks = wire.start_request(stage, 'GET', 'localhost', path, (), True,
                                        role='small', primary=primary, held=False, body_limit=0 if body is None else len(body),
                                        final_status=200, info_count=0, policy='healthy',
                                        mode='small_body', expected_sha256=None, middleware_policy='required')
    if actual != stream or not chunks or any(len(chunk) > 8192 for chunk in chunks):
        raise RuntimeError('request serialization differs')
    block = encoder.encode([(':status', '200'), ('x-middleware', 'retained')])
    packet = frame(1, 5 if body is None else 4, stream, block)
    if body is not None:
        packet += frame(0, 1, stream, body)
    for chunk in (packet[:4], packet[4:]):
        wire.accept(protocol, chunk, records, raw, trace, credit=response, request=request, stage=stage)
    wire.complete(records, raw, stream)
    result = bytes(records[stream]['body'])
    wire.retire(records, raw, stream, request=request, credit=response, stage=stage)
    return result


def check():
    protocol = h2_client.new_protocol()
    request = request_credit.new_state(request_credit.new_case('shutdown_idle'))
    response = response_credit.new_state()
    stage = output_stage.new_stage(output_stage.new_case('shutdown_idle'), 1, 1, 10, 100)
    raw, records, trace = raw_observer.new_state(), {}, {}
    wire.bind_connection(stage, protocol, raw, request, response, records)
    if len(wire.startup(stage)) != 75:
        raise RuntimeError('missing startup')
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    packet = frame(4, 0, 0, settings) + frame(4, 1, 0, b'')
    wire.accept(protocol, packet, records, raw, trace, credit=response, request=request, stage=stage)
    wire.drain(stage)
    encoder = hpack.Encoder()
    run_response(protocol, stage, request, response, raw, records, trace, encoder, 1, '/health', True)
    reads = stage['reads']
    wire.enter_final(stage)
    if stage['reads'] != reads:
        raise RuntimeError('read cap reset')
    paths = ['/status/' + row[0] for row in model.BODY_SPECS] + ['/metrics']
    if len(paths) != 68:
        raise RuntimeError('model record inventory differs')
    expected = model.records(('shutdown_idle',), 'before')
    seen = {}
    for index, path in enumerate(paths):
        value = model.metrics(('shutdown_idle',), 'before') if path == '/metrics' else expected[path[8:]]
        if path == '/metrics':
            value.update(slot0_active=False, slot1_active=False)
        body = json.dumps(value, separators=(',', ':')).encode('utf-8')
        result = run_response(protocol, stage, request, response, raw, records, trace, encoder,
                              3 + index * 2, path, False, body)
        decoded = json.loads(result)
        if path == '/metrics':
            model.validate_metrics(('shutdown_idle',), 'before', decoded)
        else:
            seen[path[8:]] = decoded
    model.validate_records(('shutdown_idle',), 'before', seen)
    wire.finish_final(stage)
    if stage['final_registered'] != len(paths) or stage['reads'] <= reads:
        raise RuntimeError('final observations differ')
    print('public codec final 68 checks passed')


def check_held():
    protocol = h2_client.new_protocol()
    request = request_credit.new_state(request_credit.new_case('shutdown_active'))
    response = response_credit.new_state()
    stage = output_stage.new_stage(output_stage.new_case('shutdown_active'), 3, 1, 10, 100)
    raw, records, trace = raw_observer.new_state(), {}, {}
    wire.bind_connection(stage, protocol, raw, request, response, records)
    if len(wire.startup(stage)) != 75:
        raise RuntimeError('missing startup')
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    wire.accept(protocol, frame(4, 0, 0, settings) + frame(4, 1, 0, b''),
                records, raw, trace, credit=response, request=request, stage=stage)
    wire.drain(stage)
    encoder = hpack.Encoder()
    run_response(protocol, stage, request, response, raw, records, trace, encoder, 1, '/health', False)
    stream, chunks = wire.start_request(stage, 'POST', 'localhost', '/upload/shutdown_active', (), False,
                                        role='transport', primary=True, held=True, body_limit=0,
                                        final_status=200, info_count=0, policy='owned_shutdown', mode='small_body',
                                        expected_sha256=None, middleware_policy='required')
    if stream != 3 or not chunks:
        raise RuntimeError('held request serialization differs')
    wire.send_data(protocol, records, request, 3, bytes(32), stage=stage, end_stream=True, pad_length=None)
    wire.drain(stage)
    run_response(protocol, stage, request, response, raw, records, trace, encoder, 5, '/status/shutdown_active', False)
    reads = stage['reads']
    wire.enter_final(stage, 3)
    paths = ['/status/' + row[0] for row in model.BODY_SPECS] + ['/metrics']
    expected = model.records(('shutdown_active',), 'before')
    expected['shutdown_active']['chunks'] = 1
    expected['shutdown_active']['max_span'] = 7
    seen = {}
    for index, path in enumerate(paths):
        value = model.metrics(('shutdown_active',), 'before') if path == '/metrics' else expected[path[8:]]
        if path == '/metrics':
            value.update(slot0_active=True, slot1_active=False)
        body = json.dumps(value, separators=(',', ':')).encode('utf-8')
        result = run_response(protocol, stage, request, response, raw, records, trace, encoder,
                              7 + index * 2, path, False, body)
        decoded = json.loads(result)
        if path == '/metrics':
            model.validate_metrics(('shutdown_active',), 'before', decoded)
        else:
            seen[path[8:]] = decoded
    model.validate_records(('shutdown_active',), 'before', seen)
    wire.finish_final(stage)
    if stage['reads'] <= reads or set(records) != {3} or set(response['streams']) != {3}:
        raise RuntimeError('held request or inherited count lost')
    output_stage.signal(stage)
    try:
        output_stage.register(stage, 143, 'small')
    except ValueError as error:
        if str(error) != 'observation after signal':
            raise
    else:
        raise RuntimeError('observation after signal accepted')
    wire.begin_termination(records, raw, 3, 'owned_shutdown', 'post_signal', stage=stage)
    result = wire.finish_termination(records, raw, 3, 'owned_shutdown', 'post_signal', 'eof',
                                     request=request, credit=response, stage=stage)
    if result['response_terminal'] != 'transport' or not raw['closed']:
        raise RuntimeError('held transport retirement differs')
    print('public codec held final 68 checks passed')


if __name__ == '__main__':
    check()
    check_held()
