"""Bounded serialized admission peer and canonical standalone schedule checks."""
import hashlib
import json
import adapter
import cases
import catalogue
import h2_client
import hpack
import model
from test_core_peer import frame, metrics, new_app, require


def schedule(case):
    paths = ('/health', model.request_contract(case)['target'])
    if case == 'limit_observed_reject':
        paths += ('/status/' + case,)
    if case.endswith('_reject'):
        paths += (model.request_contract(case.replace('_reject', '_recovery'))['target'],)
    return paths + ('/health',)


def data_schedule(tag):
    if tag in ('empty_headers', 'empty_declared', 'zero_declared_recovery', 'zero_observed_recovery',
               'limit_declared_reject', 'zero_declared_reject'):
        return ()
    if tag == 'empty_data':
        return ((0, 1),)
    if tag == 'limit_observed_reject':
        return ((32, 0), (1, 0))
    if tag == 'zero_observed_reject':
        return ((1, 0),)
    return ((32, 1),)


def check_storage(state):
    require(len(state['buffer']) <= 8201, 'parser storage bound differs')
    require(len(state['pending']) <= 2 and sum(map(len, state['pending'])) <= 16384, 'pending storage bound differs')
    require(all(type(packet) is bytes and 0 < len(packet) <= 8192 for packet in state['pending']), 'pending packet bound differs')
    require(len(state['uploads']) <= (2 if state['case'].endswith('_reject') else 1), 'upload map bound differs')
    require(0 <= state['cursor'] <= state['head_limit'] and state['heads'] == state['cursor'], 'finite cursor differs')
    require(0 <= state['received'] <= state['head_limit'] + 2 and state['received_bytes'] <= (state['head_limit'] + 2) * 8192,
            'receive bound differs')
    require(state['decoder'].max_allowed_table_size == 4096 and state['encoder'].header_table_size == 4096,
            'HPACK table bound differs')
    state['max_buffer'] = max(state['max_buffer'], len(state['buffer']))
    state['max_pending'] = max(state['max_pending'], len(state['pending']))
    state['max_pending_bytes'] = max(state['max_pending_bytes'], sum(map(len, state['pending'])))


def respond(state, stream, body, refusal=False):
    require(not state['pending'] and len(body) <= 4095, 'response queue or body bound differs')
    block = state['encoder'].encode(((':status', '413' if refusal else '200'), ('x-middleware', 'retained')))
    if not refusal:
        packets = (frame(1, 4, stream, block) + frame(0, 1, stream, body),)
    else:
        end, reset = frame(1, 5, stream, block), frame(3, 0, stream, bytes(4))
        packets = (end, reset)
        if state['fault'] == 'reset_first':
            packets = (reset + end,)
        elif state['fault'] == 'continue':
            info = state['encoder'].encode(((':status', '100'),))
            packets = (frame(1, 4, stream, info) + end + reset,)
        elif state['fault'] == 'refusal_data':
            packets = (frame(1, 4, stream, block) + frame(0, 1, stream, b'x') + reset,)
    require(len(packets) <= 2 and all(len(packet) <= 8192 for packet in packets), 'pending packet bound differs')
    state['pending'].extend(packets)
    state['responses_queued'] += 1
    state['resets_queued'] += int(refusal)
    check_storage(state)


def finish(state, app, tag, refusal=False):
    upload, item = state['uploads'][tag], app['records'][tag]
    require(not upload['terminal'], 'duplicate terminal')
    upload['terminal'] = True
    if refusal:
        if item['begins']:
            item.update(cancels=1, active=False, reason='body_too_large')
    else:
        item.update(ends=1, active=False)
    respond(state, upload['stream'], b'' if refusal else json.dumps(item).encode(), refusal)


def data_received(state, app, packet):
    stream, payload, flags = int.from_bytes(packet[5:9], 'big'), packet[9:], packet[4]
    tags = tuple(tag for tag, upload in state['uploads'].items() if upload['stream'] == stream)
    require(len(tags) == 1 and not state['pending'], 'DATA stream or response barrier differs')
    tag = tags[0]
    upload, item = state['uploads'][tag], app['records'][tag]
    spans, ordinal = data_schedule(tag), upload['frames']
    require(not upload['terminal'] and ordinal < len(spans), 'DATA ordinal differs')
    require((len(payload), flags) == spans[ordinal], 'DATA ordinal differs')
    expected_cursor = 3 if tag == 'limit_observed_reject' and ordinal == 1 else schedule(state['case']).index(model.request_contract(tag)['target']) + 1
    require(state['cursor'] == expected_cursor, 'offending byte preceded status barrier')
    offending = tag == 'zero_observed_reject' or tag == 'limit_observed_reject' and ordinal == 1
    expected = b'x' if offending else model.payload_span(32, 0, 32) if payload else b''
    require(payload == expected, 'request body differs')
    if tag == 'limit_observed_reject' and ordinal == 1:
        require(state['prefix_delivered'], 'offending byte preceded status barrier')
    upload['digest'].update(payload)
    upload['count'] += len(payload)
    upload['frames'] += 1
    upload['ends'] += flags
    state['data'] += len(payload)
    state['frames'] += 1
    state['ends'] += flags
    if offending:
        finish(state, app, tag, True)
        return
    if payload:
        item.update(bytes=upload['count'], sha256=upload['digest'].hexdigest(), chunks=ordinal + 1, max_span=len(payload))
    if flags:
        finish(state, app, tag)


def request_path(state):
    paths, cursor = schedule(state['case']), state['cursor']
    if cursor < len(paths):
        return paths[cursor]
    require(state['final'] and cursor < len(paths) + 68, 'request beyond finite schedule')
    require(all(upload['terminal'] for upload in state['uploads'].values()), 'final before ordinary completion')
    index = cursor - len(paths)
    return '/metrics' if index == 67 else '/status/' + model.BODY_SPECS[index][0]


def request_barrier(state, path):
    if state['cursor'] <= 1:
        return
    if state['case'] == 'limit_observed_reject' and state['cursor'] == 2:
        upload = state['uploads'][state['case']]
        require(upload['frames'] == 1 and upload['count'] == 32 and not upload['terminal'], 'status before accepted prefix')
        return
    require(all(upload['terminal'] for upload in state['uploads'].values()), 'request before required terminal')
    if path == '/health' or state['cursor'] >= len(schedule(state['case'])):
        require(len(state['uploads']) == (2 if state['case'].endswith('_reject') else 1), 'recovery missing')


def header_contract(path):
    upload = not path.startswith(('/health', '/status/', '/metrics'))
    tag = path.split('/')[-1] if upload else None
    contract = model.request_contract(tag) if upload else None
    expected = [(':method', contract['method'] if upload else 'GET'), (':scheme', 'https'),
                (':authority', 'localhost'), (':path', path)]
    if upload and contract['declared'] is not None:
        expected.append(('content-length', str(contract['declared'])))
    if tag in ('limit_declared_reject', 'zero_declared_reject'):
        expected.append(('expect', '100-continue'))
    end = not upload or tag in ('empty_headers', 'empty_declared', 'zero_declared_recovery', 'zero_observed_recovery')
    return tag, expected, 5 if end else 4


def request_received(state, app, packet):
    require(state['acks'] == 1 and not state['pending'], 'request before preceding response')
    path = request_path(state)
    request_barrier(state, path)
    tag, expected, flags = header_contract(path)
    entries = list(state['decoder'].decode(packet[9:]))
    stream = int.from_bytes(packet[5:9], 'big')
    require(entries == expected and stream == 2 * state['cursor'] + 1 and packet[4] == flags, 'request contract differs')
    require(state['cursor'] < state['head_limit'], 'request beyond finite schedule')
    if tag is not None:
        require(tag not in state['uploads'] and len(state['uploads']) < (2 if state['case'].endswith('_reject') else 1), 'upload map bound differs')
    state['heads'] += 1
    state['cursor'] += 1
    app['heads'] += 1
    if state['cursor'] > len(schedule(state['case'])):
        state['final_requests'] += 1
    if tag is not None:
        state['uploads'][tag] = dict(stream=stream, count=0, frames=0, ends=0, terminal=False, digest=hashlib.sha256())
        refused = tag in ('limit_declared_reject', 'zero_declared_reject')
        app['records'][tag].update(middleware=1, attempts=int(not refused), begins=int(not refused), active=not refused)
        if refused or flags == 5:
            finish(state, app, tag, refused)
        return
    if path.startswith('/status/'):
        item = dict(app['records'][path[8:]])
        if state['case'] == 'limit_observed_reject' and state['cursor'] == 3:
            state['prefix_queued'] = True
            if state['fault'] == 'bad_prefix':
                item['bytes'] = 31
        body = json.dumps(item).encode()
    else:
        body = b'ok' if path == '/health' else json.dumps(metrics(app)).encode()
    respond(state, stream, body)


def packet_received(state, app, packet):
    if packet[3] == 4:
        require(packet == frame(4, 1, 0, b'') and state['acks'] == 0 and state['cursor'] == 0, 'settings ACK differs')
        state['acks'] += 1
        return
    if packet[3] == 0:
        data_received(state, app, packet)
        return
    require(packet[3] == 1, 'unexpected frame type')
    request_received(state, app, packet)


def send_bytes(state, app, data):
    check_storage(state)
    require(type(data) is bytes and 0 < len(data) <= 8192, 'send span differs')
    if state['startup']:
        expected = b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n'
        expected += frame(4, 0, 0, b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                                        ((1, 4096), (2, 1), (4, 65535), (5, 16384), (8, 0), (3, 100), (6, 65536))))
        require(data == expected, 'startup bytes differ')
        state['startup'] = False
        state['settings'] += 1
        return
    require(len(data) <= 8201 - len(state['buffer']), 'parser storage bound differs')
    prefix = bytes(state['buffer'][:9]) + data[:max(0, 9 - len(state['buffer']))]
    require(len(prefix) < 3 or int.from_bytes(prefix[:3], 'big') <= 8192, 'frame payload bound differs')
    state['buffer'].extend(data)
    check_storage(state)
    while len(state['buffer']) >= 9:
        size = int.from_bytes(state['buffer'][:3], 'big')
        require(size <= 8192, 'frame payload bound differs')
        if len(state['buffer']) < size + 9:
            return
        packet = bytes(state['buffer'][:size + 9])
        del state['buffer'][:size + 9]
        packet_received(state, app, packet)
        check_storage(state)


def delivered(state, data):
    offset = 0
    while offset < len(data):
        size, kind = int.from_bytes(data[offset:offset + 3], 'big'), data[offset + 3]
        state['responses_delivered'] += int(kind == 1)
        state['resets_delivered'] += int(kind == 3)
        offset += 9 + size


def new_peer(case, *, app, prior, now, clock, final=False, fault=None):
    """Caller-owned facts; <=8201 parser bytes, <=2 packets/16384 bytes,
    <=2 upload summaries, bounded HPACK and scalar read/schedule receipts.
    Ownership, TLS and ALPN are supplied synthetic transport facts.
    """
    require(type(case) is str and case in adapter.ADMISSION_CASES, 'unsupported admission peer')
    require(type(app) is dict and set(app) == {'records', 'heads', 'outputs', 'binding'}, 'app fields differ')
    catalogue.schedule(prior)
    require(case not in prior and type(final) is bool and type(now) is int and 0 <= now < catalogue.U64 and callable(clock), 'peer arguments differ')
    require(fault is None or type(fault) is str and fault in ('reset_first', 'continue', 'refusal_data', 'bad_prefix'), 'peer fault differs')
    require(fault is None or (case == 'limit_observed_reject' if fault == 'bad_prefix' else case.endswith('_reject')), 'fault case differs')
    model.validate_records(prior, 'before', app['records'])
    model.validate_outputs(prior, app['outputs'])
    model.validate_binding_pre_post(prior, app['binding'], model.default_binding() if app['binding'] is None else app['binding'],
                                    app['outputs']['producer_reuse'] if 'producer_reuse' in prior else None)
    require(type(app['heads']) is int and app['heads'] == sum(catalogue.case_budget(item)['heads'] for item in prior), 'prior heads not earned')
    if not prior:
        require(app['heads'] == 0 and app['binding'] is None, 'empty prior app differs')
    settings = b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    state = dict(case=case, final=final, fault=fault, startup=True, buffer=bytearray(),
                 pending=[frame(4, 0, 0, settings) + frame(4, 1, 0, b'')], uploads={},
                 cursor=0, heads=0, head_limit=len(schedule(case)) + 68 * int(final), settings=0, acks=0,
                 received=0, received_bytes=0, data=0, frames=0, ends=0, final_requests=0,
                 prefix_queued=False, prefix_delivered=False, responses_queued=0, responses_delivered=0,
                 resets_queued=0, resets_delivered=0, max_buffer=0, max_pending=0, max_pending_bytes=0,
                 decoder=hpack.Decoder(max_header_list_size=4096), encoder=hpack.Encoder())

    def send(data):
        send_bytes(state, app, data)

    def receive():
        require(not state['startup'] and bool(state['pending']), 'finite peer input missing')
        check_storage(state)
        require(state['received'] < state['head_limit'] + 2, 'receive bound differs')
        data = state['pending'][0]
        require(len(data) <= (state['head_limit'] + 2) * 8192 - state['received_bytes'], 'receive byte bound differs')
        stamp = clock()
        state['pending'].pop(0)
        state['received'] += 1
        state['received_bytes'] += len(data)
        delivered(state, data)
        if not state['pending']:
            state['prefix_delivered'] = state['prefix_queued']
        return data, stamp

    check_storage(state)
    connection = dict(protocol=h2_client.new_protocol(), send=send, receive=receive, now=now, owned=True, tls='TLSv1.3', alpn='h2')
    return dict(connection=connection, state=state)


def check(case, *, app=None, prior=(), final=False, fault=None):
    app = new_app() if app is None else app
    peer = new_peer(case, app=app, prior=prior, now=1, clock=lambda: 2, final=final, fault=fault)
    connection, state = peer['connection'], peer['state']
    context = adapter.open_case(case, connection['protocol'], connection['send'], 1, 30001, 900001,
                                selected_before=prior, clock=lambda: 2)
    adapter.observe(context, *connection['receive']())
    adapter.run_case(context, connection['receive'])
    if final:
        adapter.final_collection(context, connection['receive'])
    require(state['cursor'] == state['head_limit'] and not state['pending'] and not state['buffer'], 'request order differs')
    for tag, upload in state['uploads'].items():
        expected = model.payload_span(32, 0, 32) + b'x' if tag == 'limit_observed_reject' else (
            b'x' if tag == 'zero_observed_reject' else model.payload_span(32, 0, 32) if tag.startswith('limit_') and not tag.endswith('_reject') else b'')
        require(upload['frames'] == len(data_schedule(tag)) and upload['count'] == len(expected) and
                upload['digest'].digest() == hashlib.sha256(expected).digest(), 'request body differs')
    model.validate_records(prior + (case,), 'before', app['records'])
    print(case + ' passed: heads=%d flow=%d' % (context['stage']['limits']['heads'], context['request']['case']['sent']))
    return app


def main():
    names = adapter.ADMISSION_CASES
    if len([case for case in catalogue.CASES if case not in cases.IMPLEMENTED]) != 0:
        raise RuntimeError('unsupported inventory differs')
    for case in names:
        check(case)
    app, prior = None, ()
    for case in names:
        app = check(case, app=app, prior=prior, final=case == names[-1])
        prior += (case,)
    expected = {'reset_first': 'reset order', 'continue': 'invalid HEADERS',
                'refusal_data': 'response body bound', 'bad_prefix': 'record mismatch: bytes'}
    for fault, message in expected.items():
        try:
            check('limit_observed_reject' if fault == 'bad_prefix' else 'limit_declared_reject', fault=fault)
        except ValueError as exc:
            if str(exc) != message:
                raise RuntimeError('fault rejected for wrong reason: ' + fault) from exc
            print(fault + ' rejected: ' + str(exc))
        else:
            raise RuntimeError('fault accepted: ' + fault)


if __name__ == '__main__':
    main()
