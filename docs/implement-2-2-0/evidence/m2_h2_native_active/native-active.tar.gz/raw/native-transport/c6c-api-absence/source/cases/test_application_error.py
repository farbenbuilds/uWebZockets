"""Serialized terminal driver using the shared independent peer."""
import hashlib
import adapter
import model
from test_core_peer import new_app, require
from test_terminal_peer import new_peer
from test_control_reset import run_with_retention


def check(case, *, app=None, prior=(), final=False, fault=None):
    app = new_app() if app is None else app
    caller_time = [1]

    def clock():
        caller_time[0] += 1
        return caller_time[0]

    peer = new_peer(case, app=app, prior=prior, now=1, clock=clock, final=final, fault=fault)
    connection, state = peer['connection'], peer['state']
    context = adapter.open_case(case, connection['protocol'], connection['send'], 1, 30001, 900001,
                                selected_before=prior, clock=clock)
    require(context['stage']['primary'] == 5, 'primary binding differs')
    adapter.observe(context, *connection['receive']())
    run_with_retention(context, connection['receive'], state)
    budget = (10, 9, 65) if case == 'end_error' else (11, 10, 48)
    actual = (state['heads'], context['stage']['case_state']['small'], context['request']['case']['sent'])
    if actual != budget or state['heads'] != state['ordinary'] or state['settings'] != 1 or state['resets'] != 1 or state['pending'] or state['buffer']:
        raise RuntimeError('exact J C R settings reset or pending count differs')
    for stream, item in state['payloads'].items():
        tag = state['streams'][stream]
        expected = b's' if tag == 'sibling' else model.payload_span(32, 0, 32)
        if tag == case and case != 'end_error':
            expected = model.payload_span(32, 0, 7) + model.payload_span(32, 0, 8)
        if item['frames'] != (2 if tag == case and case != 'end_error' else 1) or item['count'] != len(expected) or item['digest'].hexdigest() != hashlib.sha256(expected).hexdigest():
            raise RuntimeError('final upload count or hash differs')
    require(state['complete'] and state['stale_delivered'] == 4 and state['refunded'] and
            state['refund_bytes'] == state['primary_length'] and
            state['resets_delivered'] == int(case != 'peer_reset') and
            state['outgoing_resets'] == int(case == 'peer_reset') and not state['delivered_buffer'],
            'terminal delivery receipts differ')
    selection = prior + (case,)
    if final:
        adapter.final_collection(context, connection['receive'])
        if state['heads'] != state['head_limit'] or state['final_requests'] != 68 or state['pending'] or state['buffer']:
            raise RuntimeError('shared final collection differs')
    model.validate_records(selection, 'before', app['records'])
    print(case + ' passed: J=%d C=%d R=%d' % actual)
    return app


def rejected(case, fault, message, *, final=False):
    try:
        check(case, fault=fault, final=final)
    except (ValueError, RuntimeError) as exc:
        if str(exc) != message:
            raise RuntimeError('control rejected for wrong reason: ' + fault) from exc
        print(fault + ' rejected: ' + str(exc))
        return
    raise RuntimeError('control accepted: ' + fault)


def main():
    app, prior = None, ()
    for case in ('sink_error', 'invalid_progress', 'end_error'):
        app = check(case, app=app, prior=prior, final=case == 'end_error')
        prior += (case,)
    for case in ('sink_error', 'invalid_progress', 'end_error'):
        check(case, fault='split_reset')
        for fault, message in (('terminal_reason', 'record mismatch: reason'), ('terminal_metadata', 'record mismatch: metadata_begin'),
                               ('terminal_cancel', 'record mismatch: cancels'), ('terminal_ends', 'record mismatch: ends'),
                               ('terminal_bytes', 'record mismatch: bytes'), ('terminal_hash', 'record mismatch: sha256'),
                               ('stale_reply', 'control result differs'), ('missing_refund', 'missing finite synthetic response'),
                               ('excess_refund', 'invalid connection refund'), ('sibling_echo', 'sibling echo differs'),
                               ('recovery_record', 'record mismatch: metadata_end'), ('stale_counter', 'record mismatch: stale_resume'),
                               ('primary_final', 'unexpected final'), ('reset_code', 'wrong reset code'),
                               ('duplicate_reset', 'invalid reset'), ('missing_reset', 'missing finite synthetic response')):
            rejected(case, fault, message, final=fault == 'stale_counter')
        rejected(case, 'other_record', 'record mismatch: middleware', final=True)
    for case in ('sink_error', 'invalid_progress'):
        for fault, message in (('preterminal_bytes', 'record mismatch: bytes'), ('preterminal_pause', 'record mismatch: paused'),
                               ('preterminal_cancel', 'record mismatch: cancels'), ('terminal_chunks', 'failure callback follows accepted prefix'),
                               ('early_final', 'upload completed before resume')):
            rejected(case, fault, message)
    rejected('sink_error', 'chunk_diagnostic', 'record mismatch: chunk_errors')
    rejected('invalid_progress', 'progress_diagnostic', 'record mismatch: invalid_progress')
    rejected('end_error', 'end_diagnostic', 'record mismatch: end_errors')


if __name__ == '__main__':
    main()
