"""Public response END is forbidden while the case remains paused."""
import h2_client
import hpack
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def make():
    protocol = h2_client.new_protocol()
    request = request_credit.new_state(request_credit.new_case('final_pause'))
    credit = response_credit.new_state()
    stage = output_stage.new_stage(output_stage.new_case('final_pause'), 1, 1, 10, 100)
    raw, records, trace = raw_observer.new_state(), {}, {}
    wire.bind_connection(stage, protocol, raw, request, credit, records)
    wire.startup(stage)
    pairs = ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1))
    payload = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in pairs)
    settings = len(payload).to_bytes(3, 'big') + b'\4\0\0\0\0\0' + payload + b'\0\0\0\4\1\0\0\0\0'
    wire.accept(protocol, settings, records, raw, trace, credit=credit, request=request, stage=stage)
    wire.drain(stage)
    stream, chunks = wire.start_request(stage, 'POST', 'localhost', '/upload/final_pause', (), False,
                                        role='small', primary=True, held=True, body_limit=0, final_status=200,
                                        info_count=0, policy='healthy', mode='small_body', expected_sha256=None,
                                        middleware_policy='required')
    wire.send_data(protocol, records, request, stream, bytes(32), stage=stage, end_stream=True, pad_length=None)
    wire.drain(stage)
    block = hpack.Encoder().encode([(':status', '200'), ('x-middleware', 'retained')])
    packet = len(block).to_bytes(3, 'big') + b'\1\5\0\0\0\1' + block
    if stream != 1 or not chunks:
        raise RuntimeError('request setup differs')
    return protocol, request, credit, stage, raw, records, trace, packet


def check():
    protocol, request, credit, stage, raw, records, trace, packet = make()
    try:
        wire.accept(protocol, packet, records, raw, trace, credit=credit, request=request, stage=stage)
    except ValueError as error:
        if str(error) != 'invalid terminal':
            raise
    else:
        raise RuntimeError('END before resume accepted')
    if not stage['failed']:
        raise RuntimeError('malformed input did not close action path')
    protocol, request, credit, stage, raw, records, trace, packet = make()
    output_stage.resume(stage, 1)
    wire.accept(protocol, packet, records, raw, trace, credit=credit, request=request, stage=stage)
    wire.retire(records, raw, 1, request=request, credit=credit, stage=stage)
    print('no END before resume checks passed')


if __name__ == '__main__':
    check()
