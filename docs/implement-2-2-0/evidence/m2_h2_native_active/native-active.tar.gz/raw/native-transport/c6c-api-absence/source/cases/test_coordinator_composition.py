"""Actual ordered coordinator dispatch against bounded serialized peers."""
import json
from unittest import mock
import adapter
import coordinator
import catalogue
import model
import test_core_peer
import test_lifecycle
import test_producer_pressure
import test_file_early


def require(value, message):
    if not value:
        raise ValueError(message)


def run_core(selection, control=None):
    app = test_core_peer.new_app()
    state = dict(prior=[], connections=[], closes=0, clock=2, scopes=[], releases=[], connects=[])

    case_evidence = test_lifecycle.new_case_evidence()

    def clock():
        return state['clock']

    def connect(case, index, case_deadline, whole_deadline):
        require(index in (1, 2) and case == selection[len(state['prior'])], 'connect order differs')
        state['connects'].append((case, index, case_deadline, whole_deadline, state['clock']))
        args = dict(app=app, prior=tuple(state['prior']), now=state['clock'], clock=clock,
                    final=len(state['prior']) == len(selection) - 1)
        if case in ('reuse', 'disconnect'):
            peer = test_lifecycle.new_peer(case, index, case_evidence=case_evidence, **args)
        elif case in ('producer_reuse', 'output_pressure_window', 'output_pressure_ready'):
            peer = test_producer_pressure.new_peer(case, **args)
        elif case in ('stream_file', 'early_final_order'):
            peer = test_file_early.new_peer(case, **args)
        else:
            peer = test_core_peer.new_peer(case, **args)
        state['connections'].append(peer['state'])
        connection = peer['connection']
        original_receive = connection['receive']

        def receive():
            data, now = original_receive()
            if control is not None:
                control('receive', state, None)
                now = state['clock']
            return data, now

        connection['receive'] = receive
        if control is not None:
            control('connect', state, connection)
        return connection

    def close(context, deadline):
        state['closes'] += 1
        stage, request = context['stage'], context['request']
        state['releases'].append(dict(case=stage['case'], case_connection=stage['connection_index'],
                                      ordinal=state['closes'], case_deadline=stage['case_deadline'],
                                      settings=request['client_settings'],
                                      informationals=context['trace'].get('InformationalResponseReceived', 0),
                                      receive_bytes=stage['bytes'], receive_calls=stage['reads'],
                                      connection_debt=request['connection_debt'],
                                      stream_debt_total=request['stream_debt_total'],
                                      release=dict(method='close', client_closed=True, close='normal')))
        if control is not None:
            control('close', state, context)
        if state['closes'] < len(selection):
            state['prior'].append(selection[state['closes'] - 1])
        return dict(method='close', client_closed=True, close='normal')

    def disconnect_close(context):
        peer = state['connections'][-1]
        require(context['raw']['closing']['phase'] == 'pre_unwrap', 'strict termination not started')
        peer['closed'] = True
        app['records']['disconnect'] = test_lifecycle.terminal('disconnect')
        app['records']['disconnect'].update(stale_resume=0, stale_cancel=0)
        facts = dict(method='ssl_unwrap', tls_shutdown='success', tcp_eof=True, trailing_bytes=0, close='normal')
        if control is not None:
            control('disconnect_close', state, context)
            control('disconnect_facts', state, facts)
        return facts

    def signal(context, deadline):
        return dict(signal='SIGTERM', owned_identity=True, watcher_installed=True, client_open=False)

    def process(context, deadline):
        return dict(exit_code=0, reaped=True, forced=False, run_ok=True, deinit_ok=True, key_removed=True)

    def post(context, deadline):
        return dict(records=json.loads(json.dumps(app['records'])), metrics=test_core_peer.metrics(app),
                    outputs=json.loads(json.dumps(app['outputs'])),
                    binding=model.default_binding() if app['binding'] is None else dict(app['binding']))

    def factory(identity, index, selected, ready, whole):
        require(selected == selection, 'factory selection differs')
        descriptor = dict(identity=(identity, index), ready=True, fresh_application=True, connect=connect,
                          close=close, signal=signal, process=process, post=post)
        if 'disconnect' in selected:
            descriptor['disconnect_close'] = disconnect_close
        if control is not None:
            control('factory', state, descriptor)
        return descriptor

    original_case = adapter.run_case

    def dispatch(context, receive, **kwargs):
        result = original_case(context, receive, **kwargs)
        current = context if result is None else result
        state['scopes'].append(tuple(current[key] for key in ('raw', 'request', 'credit', 'protocol')))
        return result

    original_collection = adapter.final_collection
    collections = []

    def collect(context, receive):
        require(context['selected_before'] == selection[:-1] and context['completed'] and
                context['stage']['case'] == selection[-1] and context['stage']['final_registered'] == 0,
                'final entry did not inherit actual case state')
        scopes = tuple(context[key] for key in ('raw', 'request', 'credit', 'protocol'))
        require(all(a is b for a, b in zip(scopes, state['scopes'][-1])), 'final entry replaced parser or ledgers')
        collections.append((context['now'], context['request']['connection_debt'],
                            context['request']['stream_debt_total']))
        result = original_collection(context, receive)
        require(all(context[key] is value for key, value in zip(('raw', 'request', 'credit', 'protocol'), scopes)),
                'final collection replaced parser or ledgers')
        return result

    with mock.patch.object(adapter, 'final_collection', collect), mock.patch.object(adapter, 'run_case', dispatch):
        result = coordinator.run(selection, run_identity='composition', now=1, units_per_second=1,
                                 clock=clock, child_factory=factory)
    require(len(collections) == 1, 'final collection count differs')
    require(state['closes'] == len(selection), 'close count differs')
    require(result['totals']['final_collections'] == 1 and len(result['children'][0]['connections']) == len(selection) + int('disconnect' in selection),
            'observed collection or connection count differs')
    require(len(state['scopes']) == len(selection), 'dispatch scope count differs')
    if len(selection) > 1:
        require(all(a is not b for a, b in zip(state['scopes'][0], state['scopes'][1])),
                'fresh connection reused parser or ledgers')
    summaries = result['children'][0]['connections']
    if 'disconnect' not in selection:
        require(summaries == tuple(state['releases']), 'summary differs from pre-hook local facts')
    require(all(item[2] == summaries[i]['case_deadline'] and item[3] == 901 and
                (item[1] == 2 or item[2] == min(item[3], item[4] + catalogue.case_budget(item[0])['timeout_seconds']))
                for i, item in enumerate(state['connects'])), 'connect deadlines differ from release')
    fields = {'case', 'case_connection', 'ordinal', 'case_deadline', 'settings', 'informationals',
              'receive_bytes', 'receive_calls', 'connection_debt', 'stream_debt_total', 'release'}
    for index, summary in enumerate(summaries):
        require(set(summary) == fields and summary['case'] == state['connects'][index][0] and
                summary['case_connection'] == state['connects'][index][1] and summary['ordinal'] == index + 1,
                'connection summary differs')
    if selection in (('ready_buffered', 'large_declared'), ('large_declared', 'ready_buffered')):
        ready = summaries[selection.index('ready_buffered')]
        require(ready['connection_debt'] == 257 and ready['stream_debt_total'] == 257,
                'ready debt was erased at release')
        if selection[0] == 'ready_buffered':
            request = state['scopes'][0][1]
            require(request['connection_debt'] == 257 and request['stream_debt_total'] == 257,
                    'intermediate close erased debt')
        else:
            require(collections[0][1:] == (257, 257), 'ready debt missing at final entry')
    if 'producer_reuse' in selection:
        require(app['binding'] is not None and result['children'][0]['final_observations']['binding'] == app['binding'] and
                result['children'][0]['final_observations']['binding'] is not app['binding'],
                'earned binding was lost or aliased')
    if selection in (('reuse', 'ready_buffered'), ('ready_buffered', 'reuse')):
        require(result['totals']['heads'] == 462 and result['totals']['small'] == 462 and
                result['totals']['request_flow'] == 545, 'reuse totals differ')
    if selection == ('producer_reuse', 'ready_buffered'):
        require(result['totals']['heads'] == 82 and result['totals']['small'] == 81, 'producer totals differ')
    if set(selection) in ({'ready_buffered', 'large_declared'}, {'ready_buffered', 'large_undeclared'}):
        require(result['totals']['heads'] == 78 and result['totals']['small'] == 78 and
                result['totals']['request_flow'] == 100000257, 'observed totals differ')
    return result


def check_selection_boundary():
    ordinary = tuple(case for case in catalogue.CASES if case not in ('shutdown_idle', 'shutdown_active'))
    require(len(ordinary) == 38, 'ordinary inventory differs')
    selections = [(case,) for case in ordinary] + [ordinary, tuple(reversed(ordinary))]
    for selection in selections:
        calls = []

        def factory(*args):
            calls.append(args)
            raise RuntimeError('factory boundary')

        try:
            coordinator.run(selection, run_identity='a', now=1, units_per_second=1,
                            clock=lambda: 2, child_factory=factory)
        except RuntimeError as error:
            require(str(error) == 'factory boundary' and len(calls) == 1 and calls[0][2] == selection,
                    'ordinary selection rejected before factory')
        else:
            raise ValueError('factory boundary silently succeeded')


def check_failed_close():
    original = RuntimeError('intermediate close failure')
    seen = []

    def control(phase, state, value):
        if phase == 'close':
            seen.append(len(state['connections']))
            raise original

    try:
        run_core(('ready_buffered', 'large_declared'), control)
    except RuntimeError as error:
        require(error is original and seen == [1], 'failure advanced to next connection')
    else:
        raise ValueError('failed close silently succeeded')


def check_sealed_callbacks_and_outputs():
    held = {}

    def control(phase, state, value):
        if phase == 'factory':
            held['descriptor'] = value
        elif phase == 'close' and state['closes'] == 1:
            held['descriptor']['connect'] = None
            held['descriptor']['signal'] = None
            value['output_observations']['producer_reuse']['checks'] = 999
            value['stage']['case_state']['heads'] = 999

    result = run_core(('producer_reuse', 'ready_buffered'), control)
    child = result['children'][0]
    require(child['counts']['heads'] == 82 and
            child['final_observations']['outputs']['producer_reuse']['checks'] != 999,
            'intermediate callback changed sealed facts')


def check_missing_output_and_expiry():
    original = adapter.run_case
    calls = []

    def remove_output(context, receive, **kwargs):
        result = original(context, receive, **kwargs)
        calls.append(context['stage']['case'])
        context['output_observations'].pop('producer_reuse')
        return result

    with mock.patch.object(adapter, 'run_case', remove_output):
        try:
            run_core(('producer_reuse', 'ready_buffered'))
        except ValueError as error:
            require('retained output observations differ' in str(error) and calls == ['producer_reuse'],
                    'missing output advanced dispatch')
        else:
            raise ValueError('missing output silently succeeded')

    seen = []

    def expire(phase, state, context):
        if phase == 'close':
            seen.append(len(state['connections']))
            state['clock'] = context['stage']['case_deadline']

    try:
        run_core(('ready_buffered', 'large_declared'), expire)
    except ValueError as error:
        require(seen == [1] and 'expired' in str(error), 'expired close advanced dispatch')
    else:
        raise ValueError('expired close silently succeeded')


def check_file_and_binding_loss():
    for case, field in (('stream_file', 'output_observations'), ('producer_reuse', 'output_binding')):
        original = adapter.run_case
        dispatched = []

        def remove(context, receive, **kwargs):
            result = original(context, receive, **kwargs)
            dispatched.append(context['stage']['case'])
            if field == 'output_observations':
                context[field].pop(case)
            else:
                context.pop(field)
            return result

        with mock.patch.object(adapter, 'run_case', remove):
            try:
                run_core((case, 'ready_buffered'))
            except ValueError as error:
                expected = 'retained output observations differ' if field == 'output_observations' else 'diagnostic schema'
                require(dispatched == [case] and expected in str(error), 'missing fact advanced dispatch or wrong rejection')
            else:
                raise ValueError('missing fact silently succeeded')


def check_receiver_time_handoff():
    events = []

    def advance(phase, state, context):
        if phase == 'receive' and not events:
            state['clock'] = 3
            events.append('receive')
        if phase == 'close' and state['closes'] == 1:
            events.append('close')

    result = run_core(('ready_buffered', 'large_declared'), advance)
    child = result['children'][0]
    expected = min(901, 3 + catalogue.case_budget('large_declared')['timeout_seconds'])
    require(events == ['receive', 'close'] and child['connections'][0]['case_deadline'] == 32 and
            child['connections'][1]['case_deadline'] == expected and
            child['deadlines'] == dict(ready=17, case=expected, whole=901, grace=min(18, expected)),
            'advanced time did not reach next deadline and grace')

    observed = []

    def rollback(phase, state, context):
        if phase == 'receive' and not observed:
            state['clock'] = 3
            observed.append('receive')
        if phase == 'close' and state['closes'] == 1:
            observed.append(len(state['connections']))
            state['clock'] = 2

    try:
        run_core(('ready_buffered', 'large_declared'), rollback)
    except ValueError as error:
        require(observed == ['receive', 1] and str(error) == 'monotonic time expired or invalid', 'receiver rollback advanced dispatch')
    else:
        raise ValueError('receiver rollback silently succeeded')


def check_private_close_time():
    for mode in ('deadline', 'now', 'clock'):
        seen = []

        def corrupt(phase, state, context):
            if phase != 'close' or state['closes'] != 1:
                return
            seen.append(len(state['connections']))
            if mode == 'deadline':
                context['stage']['case_deadline'] = context['stage']['whole_deadline']
                state['clock'] = 32
            elif mode == 'now':
                context['now'] = 1
                state['clock'] = 1
            else:
                context['stage']['case_deadline'] = context['stage']['whole_deadline']
                context['clock'] = lambda: 2
                state['clock'] = 32

        try:
            result = run_core(('ready_buffered', 'large_declared'), corrupt)
        except ValueError as error:
            require(seen == [1] and ('expired' in str(error) or 'backwards' in str(error)),
                    'private close boundary wrong rejection')
        else:
            deadlines = [item['case_deadline'] for item in result['children'][0]['connections']]
            raise ValueError('mutated close bypassed private time boundary: %s connections=%d deadlines=%s' %
                             (mode, len(deadlines), deadlines))

    def valid_mutation(phase, state, context):
        if phase == 'close' and state['closes'] == 1:
            context['stage']['case_deadline'] = context['stage']['whole_deadline']
            context['now'] = 0
            context['clock'] = lambda: 901
            state['clock'] = 3

    result = run_core(('ready_buffered', 'large_declared'), valid_mutation)
    child = result['children'][0]
    require(child['connections'][0]['case_deadline'] == 32 and child['connections'][1]['case_deadline'] == 183 and
            child['deadlines'] == dict(ready=17, case=183, whole=901, grace=18),
            'valid close mutation changed private time or summaries')


def check_disconnect_boundaries():
    for mode in ('bad_close', 'deadline', 'rollback', 'bad_connection', 'replacement_expiry'):
        seen = []

        def control(phase, state, value):
            if phase == 'disconnect_close':
                seen.append(len(state['connections']))
                if mode == 'deadline':
                    value['stage']['case_deadline'] = 901
                    value['clock'] = lambda: 2
                    state['clock'] = 32
                if mode == 'rollback':
                    value['now'] = 0
                    state['clock'] = 1
            if phase == 'disconnect_facts' and mode == 'bad_close':
                value['trailing_bytes'] = False
            if phase == 'connect' and len(state['connections']) == 2:
                seen.append(2)
                if mode == 'bad_connection':
                    value['tls'] = 'wrong'
                if mode == 'replacement_expiry':
                    value['now'] = 32

        try:
            run_core(('disconnect', 'ready_buffered'), control)
        except ValueError:
            expected = [1, 2] if mode in ('bad_connection', 'replacement_expiry') else [1]
            require(seen == expected, 'disconnect failure advanced beyond boundary')
        else:
            raise ValueError('disconnect boundary silently succeeded: ' + mode)

    def valid_mutation(phase, state, context):
        if phase == 'disconnect_close':
            context['stage']['case_deadline'] = 901
            context['stage']['whole_deadline'] = 999
            context['clock'] = lambda: 999
            context['now'] = 0
            state['clock'] = 3

    result = run_core(('disconnect', 'ready_buffered'), valid_mutation)
    connections = result['children'][0]['connections']
    require([item['case_connection'] for item in connections] == [1, 2, 1] and
            [item['ordinal'] for item in connections] == [1, 2, 3] and
            connections[0]['case_deadline'] == connections[1]['case_deadline'] == 32 and
            connections[0]['connection_debt'] == 32 and connections[0]['stream_debt_total'] == 32 and
            connections[0]['settings'] == connections[1]['settings'] == 1 and
            connections[0]['release'] == dict(method='ssl_unwrap', tls_shutdown='success', tcp_eof=True,
                                               trailing_bytes=0, close='normal'),
            'disconnect summary or private time differs')


def check_disconnect_descriptor_and_isolation():
    for mode in ('missing', 'extra', 'noncallable'):
        seen = []

        def corrupt(phase, state, value):
            if phase == 'factory':
                if mode == 'missing':
                    value.pop('disconnect_close')
                elif mode == 'extra':
                    value['extra'] = lambda: None
                else:
                    value['disconnect_close'] = None
            if phase == 'connect':
                seen.append(phase)

        try:
            run_core(('disconnect',), corrupt)
        except ValueError as error:
            require('descriptor' in str(error) and not seen, 'descriptor failure allowed connect')
        else:
            raise ValueError('invalid disconnect descriptor accepted')

    held = {}

    def inspect(phase, state, value):
        if phase == 'disconnect_close':
            held['old'] = value
            held['local'] = tuple((value['request']['client_settings'], value['trace'].get('InformationalResponseReceived', 0),
                                   value['stage']['bytes'], value['stage']['reads'], value['request']['connection_debt'],
                                   value['request']['stream_debt_total']))
        if phase == 'connect' and len(state['connections']) == 2:
            require(held['old']['request']['transport_closed'], 'old transport still open')
            try:
                adapter.observe(held['old'], b'x', state['clock'])
            except ValueError as error:
                require('transport terminal' in str(error), 'old credit rejection differs')
            else:
                raise ValueError('old transport accepted late credit')
        if phase == 'close':
            old = held['old']
            require(all(old[key] is not value[key] for key in ('raw', 'request', 'credit', 'protocol')),
                    'replacement shares connection state')
            require(old['stage']['case_state'] is value['stage']['case_state'] and
                    old['request']['case'] is value['request']['case'], 'case accounting not shared')

    result = run_core(('disconnect',), inspect)
    first = result['children'][0]['connections'][0]
    require(tuple(first[key] for key in ('settings', 'informationals', 'receive_bytes', 'receive_calls',
                                          'connection_debt', 'stream_debt_total')) == held['local'],
            'old connection summary differs from observed local facts')


if __name__ == '__main__':
    check_disconnect_descriptor_and_isolation()
    check_disconnect_boundaries()
    run_core(('disconnect',))
    run_core(('ready_buffered', 'disconnect', 'large_declared'))
    run_core(('disconnect', 'reuse'))
    result = run_core(('producer_reuse', 'disconnect'))
    require((result['totals']['heads'], result['totals']['small'], result['totals']['connections'],
             result['totals']['settings'], result['totals']['request_flow']) == (102, 100, 3, 4, 128),
            'producer disconnect totals differ')
    check_private_close_time()
    check_selection_boundary()
    check_failed_close()
    check_sealed_callbacks_and_outputs()
    check_missing_output_and_expiry()
    check_file_and_binding_loss()
    check_receiver_time_handoff()
    run_core(('ready_buffered', 'large_declared'))
    run_core(('large_declared', 'ready_buffered'))
    run_core(('ready_buffered', 'large_undeclared'))
    run_core(('reuse', 'ready_buffered'))
    run_core(('ready_buffered', 'reuse'))
    for case in ('producer_reuse', 'output_pressure_window', 'output_pressure_ready', 'stream_file', 'early_final_order'):
        run_core((case, 'ready_buffered'))
    print('private close deadline, now, clock mutation and valid handoff passed')
    print('scope identity, debt, local summaries and deadline proofs passed')
    print('selected output and binding loss, copied binding and receiver time proofs passed')
    print('ordered core and lifecycle compositions passed')
