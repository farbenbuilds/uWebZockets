"""Explicit miniature serialized operations for the private passive oracle."""
import hashlib
import hpack
from hyperframe.frame import DataFrame, HeadersFrame, SettingsFrame, RstStreamFrame, WindowUpdateFrame
import test_wire_oracle as oracle


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def payload(data=b'', padding=0):
    return (len(data), len(data) + padding, hashlib.sha256(data).digest())


def request(target='/health', *, method='GET', end='headers', body=b'', padding=0,
            role='small', terminal='end', status=200, info=(), response=None):
    return (method, target, end, payload(body, padding), role, terminal, status, info, response)


def fixture(ordinary=None, *, identity=(1, 'miniature', 1), tags=()):
    boundary = dict(sent=[], reads=[], result=None, send_error=None, receive_error=None, calls=[0, 0])

    def send(data):
        boundary['calls'][0] += 1
        boundary['sent'].append(data)
        if boundary['send_error'] is not None:
            raise boundary['send_error']
        return boundary['result']

    def receive():
        boundary['calls'][1] += 1
        if boundary['receive_error'] is not None:
            raise boundary['receive_error']
        return boundary['reads'].pop(0)

    connection = dict(protocol=object(), send=send, receive=receive, now=object(), owned=True, tls='TLSv1.3', alpn='h2')
    descriptor = (identity, (request(),) if ordinary is None else ordinary, tags)
    wrapped, state = oracle.wrap_connection(connection, descriptor)
    return connection, wrapped, state, boundary


def head(encoder, stream=1, target='/health', *, method='GET', end=True, status=None):
    entries = ((':method', method), (':scheme', 'https'), (':authority', 'localhost'), (':path', target))
    if status is not None:
        entries = ((':status', str(status)),)
    frame = HeadersFrame(stream)
    frame.data = encoder.encode(entries)
    frame.flags.add('END_HEADERS')
    if end:
        frame.flags.add('END_STREAM')
    return frame.serialize()


def received(wrapped, boundary, data):
    result = (data, object())
    boundary['reads'].append(result)
    require(wrapped['receive']() is result, 'receive result identity changed')


def start(wrapped):
    packet = b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n' + SettingsFrame().serialize()
    require(wrapped['send'](packet) is None, 'full send result changed')
    return len(packet)


def check_boundary():
    connection, wrapped, state, boundary = fixture()
    require(boundary['calls'] == [0, 0], 'constructor invoked boundary')
    require(set(wrapped) == set(connection) and wrapped is not connection, 'connection shape changed')
    for key in ('protocol', 'now', 'owned', 'tls', 'alpn'):
        require(wrapped[key] is connection[key], 'connection value changed')
    sent = start(wrapped)
    packet = head(hpack.Encoder())
    wrapped['send'](packet)
    received(wrapped, boundary, head(hpack.Encoder(), status=200))
    result = oracle.seal(state)
    require(result[1] is True and result[2][1] == sent + len(packet), 'successful bytes missing')
    require(result[5:7] == (1, 1) and result[-1][0][-1] is True, 'small terminal not earned')
    require(result == oracle.seal(state) and result is not oracle.seal(state), 'reseal copy differs')
    require(oracle.failure(state) is None, 'healthy boundary poisoned')
    print('boundary construction, exact identities, serialized small terminal and reseal passed')


def rejected(operation, code):
    try:
        operation()
    except ValueError as error:
        require(error.args == (code,), 'wrong rejection: ' + repr(error.args))
        return
    raise RuntimeError('accepted invalid operation: ' + code)


def poisoned(state, code):
    value = oracle.failure(state)
    require(value is not None and value[0] == code, 'wrong poison: ' + repr(value))
    rejected(lambda: oracle.seal(state), 'oracle_unsealed')
    require(oracle.failure(state) == value, 'seal replaced original poison')


def data_packet(body, stream=1, *, end=True, padding=None):
    frame = DataFrame(stream)
    frame.data = body
    if end:
        frame.flags.add('END_STREAM')
    if padding is not None:
        frame.flags.add('PADDED')
        frame.pad_length = padding
    return frame.serialize()


def reset_packet(code=8, stream=1):
    frame = RstStreamFrame(stream)
    frame.error_code = code
    return frame.serialize()


def credit_packet(amount, stream=0):
    frame = WindowUpdateFrame(stream)
    frame.window_increment = amount
    return frame.serialize()


def check_exceptions():
    for direction in ('send', 'receive'):
        connection, wrapped, state, boundary = fixture()
        original = OSError('untrusted detail must never enter receipt')
        boundary[direction + '_error'] = original
        try:
            wrapped[direction](b'partial') if direction == 'send' else wrapped[direction]()
        except OSError as error:
            require(error is original, 'original exception replaced')
        else:
            raise RuntimeError('original error swallowed')
        value = oracle.failure(state)
        require(value == (direction + '_exception', direction, 1, 0, None), 'failure leaked arbitrary details')
        boundary[direction + '_error'] = None
        boundary['result'] = object()
        result = boundary['result'] if direction == 'send' else (b'unknown-prefix-tail', object())
        boundary['reads'].append(result)
        returned = wrapped[direction](b'tail') if direction == 'send' else wrapped[direction]()
        require(returned is result and oracle.failure(state) == value, 'poisoned pass-through changed result')
        require(boundary['calls'][0 if direction == 'send' else 1] == 2, 'original invoked more than once')
        poisoned(state, direction + '_exception')
    connection, wrapped, state, boundary = fixture()
    marker = object()
    boundary['result'] = marker
    require(wrapped['send'](b'unknown prefix') is marker, 'ambiguous send result replaced')
    poisoned(state, 'ambiguous_send')
    for bad in (b'wire', [b'wire', 1], (bytearray(b'wire'), 1), (b'wire',), None):
        connection, wrapped, state, boundary = fixture()
        boundary['reads'].append(bad)
        require(wrapped['receive']() is bad, 'malformed return identity changed')
        poisoned(state, 'receive_shape')
    print('original exception priority, unknown prefixes, ambiguous send and receive shapes passed')


def check_reentrancy_and_seal():
    connection, wrapped, state, boundary = fixture()
    start(wrapped)
    wrapped['send'](head(hpack.Encoder()))
    received(wrapped, boundary, head(hpack.Encoder(), status=200))
    saved = oracle.seal(state)
    wrapped['send'](b'')
    require(boundary['sent'][-1] == b'' and saved[5:7] == (1, 1), 'post-seal original or saved copy changed')
    poisoned(state, 'after_seal')
    owner = dict(wrapped=None, calls=0)

    def send(data):
        owner['calls'] += 1
        if owner['calls'] == 1:
            owner['wrapped']['send'](b'inner')
        return None

    connection['send'] = send
    wrapped, state = oracle.wrap_connection(connection, ((1, 'miniature', 1), (request(),), ()))
    owner['wrapped'] = wrapped
    wrapped['send'](b'outer')
    require(owner['calls'] == 2, 'reentrant original call skipped or repeated')
    poisoned(state, 'reentrant')
    print('post-seal immutable copies, reseal poison and reentrant original behavior passed')


def check_padding_trailers_and_credit():
    body = b'logical bytes'
    item = request('/upload', method='POST', end='trailers', body=body, padding=4, response=payload(b'ok', 3))
    connection, wrapped, state, boundary = fixture((item,))
    start(wrapped)
    encoder = hpack.Encoder()
    wrapped['send'](head(encoder, target='/upload', method='POST', end=False))
    wrapped['send'](data_packet(body, end=False, padding=3))
    trailer = HeadersFrame(1)
    trailer.data = encoder.encode((('x-trailer', 'done'),))
    trailer.flags.add('END_HEADERS')
    trailer.flags.add('END_STREAM')
    wrapped['send'](trailer.serialize())
    response = head(hpack.Encoder(), end=False, status=200) + data_packet(b'ok', padding=2)
    for cut in (response[:1], response[1:8], response[8:13], response[13:]):
        received(wrapped, boundary, cut)
    wrapped['send'](credit_packet(500) + credit_packet(7, 1))
    received(wrapped, boundary, credit_packet(len(body) + 4) + credit_packet(len(body) + 4, 1))
    receipt = oracle.seal(state)
    require(receipt[2][3:9] == (1, 1, 1, len(body), len(body) + 4, 4), 'request logical/padding/trailer facts differ')
    require(receipt[3][6:9] == (2, 5, 3), 'response logical/padding differs')
    require(receipt[2][12] == (1, 500, 0, 0) and receipt[2][13] == (1, 7, 1, 7), 'outgoing grants lost')
    require(receipt[3][13] == (1, len(body) + 4, 1, len(body) + 4), 'late stream refunds lost')
    require(receipt[11:13] == (0, 0), 'independent request debt not refunded')
    require(receipt[-1][0][5] == hashlib.sha256(body).digest(), 'request hash includes padding')
    print('split/coalesced framing, padded logical/flow hashes, trailers and both credit scopes passed')


def check_settings_and_informationals():
    item = request(info=(100,))
    connection, wrapped, state, boundary = fixture((item,))
    start(wrapped)
    ack = SettingsFrame()
    ack.flags.add('ACK')
    wrapped['send'](ack.serialize())
    wrapped['send'](head(hpack.Encoder()))
    encoder = hpack.Encoder()
    received(wrapped, boundary, SettingsFrame().serialize() + ack.serialize() + head(encoder, status=100, end=False))
    require(state['informationals'] == 1 and state['small_ends'] == 0, 'informational earned terminal')
    received(wrapped, boundary, head(encoder, status=200))
    receipt = oracle.seal(state)
    require(receipt[2][9:11] == (1, 1) and receipt[3][9:11] == (1, 1) and receipt[4] == 1, 'SETTINGS/ACK/info conflated')
    print('actual decoded 100 and separate bidirectional SETTINGS/ACK passed')


def check_terminals():
    for terminal, direction, code in (('incoming_reset_8', 'receive', 8), ('incoming_reset_2', 'receive', 2), ('outgoing_reset_8', 'send', 8)):
        item = request('/upload', method='POST', end='open', body=b'abc', role='reset', terminal=terminal, status=None)
        connection, wrapped, state, boundary = fixture((item,))
        start(wrapped)
        wrapped['send'](head(hpack.Encoder(), target='/upload', method='POST', end=False))
        wrapped['send'](data_packet(b'abc', end=False))
        packet = reset_packet(code)
        wrapped['send'](packet) if direction == 'send' else received(wrapped, boundary, packet)
        receipt = oracle.seal(state)
        require(receipt[5:8] == (0, 0, 0) and receipt[11:13] == (3, 3), 'reset manufactured small/debt refund')
        require(receipt[2 if direction == 'send' else 3][11] == ((code, 1),), 'reset direction/code lost')
    for role in ('small', 'output'):
        item = request(role=role, terminal='end_reset_0', status=403, response=payload(b'x' * 17))
        connection, wrapped, state, boundary = fixture((item,))
        start(wrapped)
        wrapped['send'](head(hpack.Encoder()))
        received(wrapped, boundary, head(hpack.Encoder(), status=403, end=False) + data_packet(b'x' * 17))
        require(state['small_complete'] == 0 and not state['streams'][1]['complete'], 'END alone completed refusal')
        received(wrapped, boundary, reset_packet(0))
        receipt = oracle.seal(state)
        expected = (1, 1, 0) if role == 'small' else (0, 0, 1)
        require(receipt[5:8] == expected, '17 byte output relabeled small')
    print('incoming/outgoing reset policies, retained debt, refusal END-before-reset and 17-byte output passed')


def check_transport():
    for case in ('disconnect', 'shutdown_active'):
        path = '/limit/' + case + '?case=' + case
        items = (request(), request(path, method='POST', end='open', body=b'x' * 32, role='transport', terminal='transport_abandon', status=None))
        connection, wrapped, state, boundary = fixture(items, identity=(1, case, 1))
        start(wrapped)
        encoder = hpack.Encoder()
        wrapped['send'](head(encoder))
        received(wrapped, boundary, head(hpack.Encoder(), status=200))
        wrapped['send'](head(encoder, 3, path, method='POST', end=False))
        wrapped['send'](data_packet(b'x' * 32, 3, end=False))
        wrapped['send'](credit_packet(32))
        receipt = oracle.seal(state)
        require(receipt[11:14] == (32, 32, (3,)), 'transport abandonment lost request debt')
        require(receipt[-1][1][9:13] == (False, False, None, None) and receipt[-1][1][-1] is False, 'transport manufactured wire terminal')
    print('authorized open transport windows retain incompleteness and outgoing grants do not refund request debt')


def final_fixture():
    tags = tuple('tag_' + str(index) for index in range(67))
    connection, wrapped, state, boundary = fixture((request('/metrics'),), tags=tags)
    start(wrapped)
    encoder, response_encoder = hpack.Encoder(), hpack.Encoder()
    wrapped['send'](head(encoder, target='/metrics'))
    received(wrapped, boundary, head(response_encoder, status=200))
    return wrapped, state, boundary, encoder, response_encoder, tags


def check_final():
    wrapped, state, boundary, encoder, responses, tags = final_fixture()
    require(state['final_requests'] == state['final_responses'] == 0, 'ordinary metrics earned final permission')
    for index, target in enumerate(tuple('/status/' + tag for tag in tags) + ('/metrics',)):
        stream = 2 * index + 3
        wrapped['send'](head(encoder, stream, target))
        require(state['final_requests'] == index + 1 and state['final_responses'] == index, 'final request earned response')
        received(wrapped, boundary, head(responses, stream, status=200))
    receipt = oracle.seal(state)
    require(receipt[8:11] == (68, 68, 1) and receipt[5:7] == (69, 69), 'actual ordered collection not earned')
    wrapped, state, boundary, encoder, responses, tags = final_fixture()
    wrapped['send'](head(encoder, 3, '/status/' + tags[0]))
    wrapped['send'](head(encoder, 5, '/status/' + tags[1]))
    received(wrapped, boundary, head(responses, 5, status=200))
    poisoned(state, 'final_order')
    wrapped, state, boundary, encoder, responses, tags = final_fixture()
    wrapped['send'](head(encoder, 3, '/metrics'))
    poisoned(state, 'request_identity')
    print('distinct final request/response cursors, ordinary metric exclusion and ordered 68-response collection passed')


def check_malformed_and_incomplete():
    packets = (b'\x00\x20\x01\x00\x00\x00\x00\x00\x01',
               b'\x00\x00\x01\x03\x00\x00\x00\x00\x01x',
               b'\x00\x00\x00\x09\x04\x00\x00\x00\x01',
               b'\x00\x00\x01\x01\x04\x00\x00\x00\x01\xff')
    for packet, code in zip(packets, ('bound', 'frame', 'frame', 'hpack')):
        connection, wrapped, state, boundary = fixture()
        start(wrapped)
        wrapped['send'](packet)
        poisoned(state, code)
        require(len(state['send']['buffer']) <= 8201, 'parser bound exceeded')
    for tail in (b'\x00', b'\x00\x00\x04\x08\x00\x00\x00\x00\x00\x00'):
        connection, wrapped, state, boundary = fixture()
        start(wrapped)
        wrapped['send'](head(hpack.Encoder()))
        response = head(hpack.Encoder(), status=200)
        received(wrapped, boundary, response + tail)
        require(state['receive']['wire_bytes'] == len(response) + len(tail), 'successful partial prefix not counted')
        rejected(lambda: oracle.seal(state), 'oracle_unsealed')
        poisoned(state, 'incomplete')
    connection, wrapped, state, boundary = fixture((request(terminal='end_reset_0'),))
    start(wrapped)
    wrapped['send'](head(hpack.Encoder()))
    received(wrapped, boundary, head(hpack.Encoder(), status=200) + reset_packet(0)[:8])
    rejected(lambda: oracle.seal(state), 'oracle_unsealed')
    poisoned(state, 'incomplete')
    print('malformed, oversized, unsupported CONTINUATION, HPACK and split reset/refund tails rejected')


def check_bounds_and_fragmentation():
    body = b'x' * 8192
    item = request('/upload', method='POST', end='data', body=body, response=payload(body), role='output')
    connection, wrapped, state, boundary = fixture((item,))
    start(wrapped)
    encoder = hpack.Encoder()
    packet = head(encoder, target='/upload', method='POST', end=False) + data_packet(body)
    for byte in packet:
        wrapped['send'](bytes((byte,)))
    received(wrapped, boundary, head(hpack.Encoder(), status=200, end=False) + data_packet(body))
    result = oracle.seal(state)
    require(result[2][5:8] == (1, 8192, 8192) and result[3][5:8] == (1, 8192, 8192), '8192 split/coalesced frame count differs')
    items = tuple(request('/' + str(index)) for index in range(9))
    connection, wrapped, state, boundary = fixture(items)
    start(wrapped)
    encoder = hpack.Encoder()
    for index in range(9):
        wrapped['send'](head(encoder, index * 2 + 1, '/' + str(index)))
    poisoned(state, 'bound')
    require(len(state['streams']) == 8, 'ninth active stream retained')
    connection, wrapped, state, boundary = fixture()
    start(wrapped)
    state['send']['wire_bytes'] = oracle.U64
    wrapped['send'](b'x')
    poisoned(state, 'bound')
    require(state['send']['wire_bytes'] == oracle.U64, 'u64 counter overflowed')
    print('8192 payloads, byte fragmentation, coalescing, active-eight and unsigned counter bounds passed')


def check_descriptors():
    connection, wrapped, state, boundary = fixture()
    base = ((1, 'miniature', 1), (request(),), ())
    invalid = (None, (), ((True, 'miniature', 1), base[1], ()), ((1, 'miniature', 0), base[1], ()),
               (base[0], [request()], ()), (base[0], base[1], ('one',)),
               (base[0], (request(role='output'),), ()),
               (base[0], (request(role='transport', terminal='transport_abandon', status=None, end='open'),), ()),
               (base[0], tuple(request() for unused in range(803)), ()),
               (base[0], base[1], ('duplicate',) * 67))
    for descriptor in invalid:
        rejected(lambda: oracle.wrap_connection(connection, descriptor), 'descriptor')
    rejected(lambda: oracle.wrap_connection({}, base), 'connection_shape')
    require(boundary['calls'] == [0, 0], 'invalid constructor invoked original')
    print('immutable descriptor schemas, bool rejection, bounds and compatible role validation passed')


def check_operation_overflow():
    connection, wrapped, state, boundary = fixture()
    state['operation'] = oracle.U64
    wrapped['send'](b'')
    require(boundary['calls'] == [1, 0], 'overflow skipped original')
    poisoned(state, 'bound')


def check_failure_location():
    connection, wrapped, state, boundary = fixture()
    size = start(wrapped)
    wrapped['send'](head(hpack.Encoder(), stream=3))
    value = oracle.failure(state)
    require(value == ('request_identity', 'send', 2, size, 3), 'frame failure location missing: ' + repr(value))


def check_retained_debt_overflow():
    item = request('/upload', method='POST', end='data', body=b'x')
    connection, wrapped, state, boundary = fixture((item,))
    start(wrapped)
    wrapped['send'](head(hpack.Encoder(), target='/upload', method='POST', end=False))
    state['request_stream_debt_total'] = oracle.U64
    wrapped['send'](data_packet(b'x'))
    poisoned(state, 'bound')
    require(state['request_stream_debt_total'] == oracle.U64, 'total retained debt exceeded u64')


def check_internal_and_error_priority():
    connection, wrapped, state, boundary = fixture()
    start(wrapped)
    state['send']['buffer'] = None
    packet = b'original success'
    require(wrapped['send'](packet) is None and boundary['sent'][-1] is packet, 'observer failure replaced original result')
    poisoned(state, 'internal')
    original = KeyboardInterrupt('original priority')
    boundary['send_error'] = original
    try:
        wrapped['send'](b'after poison')
    except KeyboardInterrupt as error:
        require(error is original, 'poison replaced later original exception')
    else:
        raise RuntimeError('poison swallowed later original exception')
    poisoned(state, 'internal')
    connection, wrapped, state, boundary = fixture()
    start(wrapped)
    wrapped['send'](head(hpack.Encoder()))
    received(wrapped, boundary, head(hpack.Encoder(), status=200))
    oracle.seal(state)
    boundary['receive_error'] = original
    try:
        wrapped['receive']()
    except KeyboardInterrupt as error:
        require(error is original, 'post-seal observer replaced original exception')
    else:
        raise RuntimeError('post-seal original exception swallowed')
    poisoned(state, 'receive_exception')
    print('observer internal failures preserve success; later and post-seal original exceptions retain priority')


def check_header_bounds():
    connection, wrapped, state, boundary = fixture()
    start(wrapped)
    frame = HeadersFrame(1)
    frame.flags.add('END_HEADERS')
    frame.flags.add('END_STREAM')
    frame.data = b'x' * 4097
    wrapped['send'](frame.serialize())
    poisoned(state, 'bound')
    for entries in (((b':status', b'200'), (b'x-big', b'a' * 4096)), ((b':status', b'200'),) * 2):
        connection, wrapped, state, boundary = fixture()
        start(wrapped)
        wrapped['send'](head(hpack.Encoder()))
        frame.data = hpack.Encoder().encode(entries)
        received(wrapped, boundary, frame.serialize())
        poisoned(state, 'hpack' if len(entries[1][1]) > 100 else 'request_identity')
    connection, wrapped, state, boundary = fixture()
    start(wrapped)
    wrapped['send'](head(hpack.Encoder()))
    encoder = hpack.Encoder()
    encoder.header_table_size = 4097
    received(wrapped, boundary, head(encoder, status=200))
    poisoned(state, 'hpack')
    connection, wrapped, state, boundary = fixture()
    start(wrapped)
    frame.data = hpack.Encoder().encode(((':method', 'GET'), (':path', '/health')))
    frame.flags.discard('END_HEADERS')
    wrapped['send'](frame.serialize())
    poisoned(state, 'frame')
    print('encoded and decoded header/table4096 bounds, duplicate pseudo-fields and unfinished HEADERS rejected')


def track_materialization(decoder):
    """Measure actual pinned codec field creation, using only this fresh instance."""
    stats = dict(fields=0, literals=0, decoded=0)
    literal, indexed = decoder._decode_literal, decoder._decode_indexed

    def decode_literal(data, should_index):
        result = literal(data, should_index)
        stats['literals'] += 1
        record_materialization(stats, result)
        return result

    def decode_indexed(data):
        result = indexed(data)
        record_materialization(stats, result)
        return result

    decoder._decode_literal = decode_literal
    decoder._decode_indexed = decode_indexed
    return stats


def record_materialization(stats, result):
    header = result[0]
    stats['fields'] += 1
    stats['decoded'] += len(header[0]) + len(header[1]) + 32


def observed_header_block(block):
    connection, wrapped, state, boundary = fixture()
    start(wrapped)
    wrapped['send'](head(hpack.Encoder()))
    stats = track_materialization(state['receive']['decoder'])
    frame = HeadersFrame(1)
    frame.flags.add('END_HEADERS')
    frame.flags.add('END_STREAM')
    frame.data = block
    received(wrapped, boundary, frame.serialize())
    return state, stats


def check_decoded_growth_boundary():
    entries = ((b':status', b'200'), (b'x', b'a' * 6000))
    block = hpack.Encoder().encode(entries)
    require(len(block) < 4096, 'compressed overflow fixture exceeds encoded limit')
    state, stats = observed_header_block(block)
    poisoned(state, 'hpack')
    require(stats['decoded'] <= 4096 and stats['literals'] == 0,
            'oversized literal materialized before rejection: ' + repr(stats))
    block = hpack.Encoder().encode(((b':status', b'200'), (b'a' * 6000, b'')))
    require(len(block) < 4096, 'compressed oversized name fixture exceeds encoded limit')
    state, stats = observed_header_block(block)
    poisoned(state, 'hpack')
    require(stats['decoded'] == 42 and stats['literals'] == 0, 'oversized literal name materialized')
    for entries in (((b':status', b'200'), (b'x', b'a' * 2000), (b'y', b'a' * 2000)),
                    ((b':status', b'200'), (b'x', b'a' * 2000), (b'x', b'a' * 2000))):
        state, stats = observed_header_block(hpack.Encoder().encode(entries))
        poisoned(state, 'hpack')
        require(stats['decoded'] == 2075 and stats['fields'] == 2 and stats['literals'] == 1,
                'cumulative remaining budget exceeded before field append: ' + repr(stats))
    print('actual codec growth boundary: oversized Huffman name/value and cumulative literal/indexed fields never materialize')


def check_hpack_boundary_compatibility():
    entries = ((b':status', b'200'), (b'x', b'a' * 4021))
    encoder = hpack.Encoder()
    state, stats = observed_header_block(encoder.encode(entries))
    require(stats['decoded'] == 4096 and oracle.seal(state)[5:7] == (1, 1), 'exact4096 decoded section rejected')
    for huffman in (False, True):
        block = hpack.Encoder().encode(((b':status', b'200'), (b'x', b'a' * 4021, True)), huffman=huffman)
        state, stats = observed_header_block(block)
        require(stats['decoded'] == 4096 and oracle.seal(state)[5:7] == (1, 1), 'raw/never-indexed exact4096 rejected')
    block = hpack.Encoder().encode(((b':status', b'200'), (b'x', b'\xff' * 1256 + b'a' * 10)))
    require(len(block) == 4096, 'encoded boundary fixture differs')
    state, stats = observed_header_block(block)
    require(oracle.seal(state)[5:7] == (1, 1), 'encoded4096 valid input rejected')
    state, stats = observed_header_block(hpack.Encoder().encode(((b':status', b'200'), (b'x', b'a' * 4022))))
    poisoned(state, 'hpack')
    require(stats['decoded'] == 42 and stats['literals'] == 0, 'remaining budget +1 materialized')
    connection, wrapped, state, boundary = fixture((request(), request(), request()))
    start(wrapped)
    requests, responses = hpack.Encoder(), hpack.Encoder()
    responses.header_table_size = 2048
    repeated = ((b':status', b'200'), (b'x', b'a' * 1500), (b'x', b'a' * 1500))
    for stream in (1, 3, 5):
        wrapped['send'](head(requests, stream))
        frame = HeadersFrame(stream)
        frame.flags.add('END_HEADERS')
        frame.flags.add('END_STREAM')
        fields = repeated if stream != 5 else ((b':status', b'200'), (b'x', b'b' * 1500, True))
        frame.data = responses.encode(fields)
        received(wrapped, boundary, frame.serialize())
    require(oracle.seal(state)[5:7] == (3, 3), 'valid leading update or intra-/inter-block dynamic indices changed')
    resize = hpack.Encoder()
    resize.header_table_size = 128
    block = hpack.Encoder().encode(((b':status', b'200'),)) + resize.encode(())
    state, stats = observed_header_block(block)
    poisoned(state, 'hpack')
    require(stats['decoded'] == 42, 'late table update changed decoded fields')
    print('exact4096 accepted, +1 preflight rejected; dynamic references and whole-block table-update ordering preserved')


def check_semantic_rejections():
    cases = ((request(response=payload(b'right')), data_packet(b'wrong'), 'payload'),
             (request(info=(100,)), head(hpack.Encoder(), status=200), 'terminal'),
             (request(terminal='end_reset_0'), reset_packet(0), 'terminal'),
             (request(), reset_packet(8), 'terminal'))
    for item, packet, code in cases:
        connection, wrapped, state, boundary = fixture((item,))
        start(wrapped)
        wrapped['send'](head(hpack.Encoder()))
        if code == 'payload':
            received(wrapped, boundary, head(hpack.Encoder(), end=False, status=200))
        received(wrapped, boundary, packet)
        poisoned(state, code)
    connection, wrapped, state, boundary = fixture()
    start(wrapped)
    wrapped['send'](head(hpack.Encoder()))
    received(wrapped, boundary, credit_packet(1, 3))
    poisoned(state, 'credit')
    connection, wrapped, state, boundary = fixture()
    start(wrapped)
    setting = SettingsFrame()
    setting.settings[4] = 0x80000000
    received(wrapped, boundary, setting.serialize())
    poisoned(state, 'settings')
    print('payload hashes, missing informationals, premature/wrong resets, unknown credits and SETTINGS rejected')


def check_response_trailers_and_preface():
    connection, wrapped, state, boundary = fixture((request(response=payload(b'ok')),))
    for byte in b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n':
        wrapped['send'](bytes((byte,)))
    wrapped['send'](SettingsFrame().serialize() + head(hpack.Encoder()))
    encoder = hpack.Encoder()
    trailer = HeadersFrame(1)
    trailer.data = encoder.encode((('x-complete', 'yes'),))
    trailer.flags.add('END_HEADERS')
    trailer.flags.add('END_STREAM')
    received(wrapped, boundary, head(encoder, end=False, status=200) + data_packet(b'ok', end=False) + trailer.serialize())
    receipt = oracle.seal(state)
    require(receipt[3][3:6] == (1, 1, 1) and receipt[5:7] == (1, 1), 'response trailers not terminal')
    print('fragmented startup and delivered response trailers passed')


def check_retained_capacity():
    ordinary = tuple(request('/' + str(index)) for index in range(802))
    connection, wrapped, state, boundary = fixture(ordinary)
    start(wrapped)
    encoder, responses = hpack.Encoder(), hpack.Encoder()
    for index in range(802):
        stream = 2 * index + 1
        wrapped['send'](head(encoder, stream, '/' + str(index)))
        received(wrapped, boundary, head(responses, stream, status=200))
    received(wrapped, boundary, credit_packet(1, 1))
    receipt = oracle.seal(state)
    require(len(receipt[-1]) == 802 and state['active'] == 0 and receipt[3][13] == (1, 1, 1, 1), 'retained802/late credit bound differs')
    print('802 sequential retained summaries with retired active slots and late oldest-stream credit passed')


def check_final_incomplete_and_premature():
    wrapped, state, boundary, encoder, responses, tags = final_fixture()
    rejected(lambda: oracle.seal(state), 'oracle_unsealed')
    poisoned(state, 'incomplete')
    tags = tuple('tag_' + str(index) for index in range(67))
    connection, wrapped, state, boundary = fixture(tags=tags)
    start(wrapped)
    encoder = hpack.Encoder()
    wrapped['send'](head(encoder))
    wrapped['send'](head(encoder, 3, '/status/' + tags[0]))
    poisoned(state, 'final_order')
    wrapped, state, boundary, encoder, responses, tags = final_fixture()
    for index, target in enumerate(tuple('/status/' + tag for tag in tags) + ('/metrics',)):
        wrapped['send'](head(encoder, index * 2 + 3, target))
        if index < 67:
            received(wrapped, boundary, head(responses, index * 2 + 3, status=200))
    require(state['final_requests'] == 68 and state['final_responses'] == 67, 'permission earned undelivered response')
    rejected(lambda: oracle.seal(state), 'oracle_unsealed')
    poisoned(state, 'incomplete')
    print('final permission earns nothing; premature transition and missing delivered final terminal reject seal')


def check():
    check_boundary()
    check_descriptors()
    check_exceptions()
    check_reentrancy_and_seal()
    check_padding_trailers_and_credit()
    check_settings_and_informationals()
    check_terminals()
    check_transport()
    check_final()
    check_malformed_and_incomplete()
    check_bounds_and_fragmentation()
    check_operation_overflow()
    check_failure_location()
    check_retained_debt_overflow()
    check_internal_and_error_priority()
    check_header_bounds()
    check_decoded_growth_boundary()
    check_hpack_boundary_compatibility()
    check_semantic_rejections()
    check_response_trailers_and_preface()
    check_retained_capacity()
    check_final_incomplete_and_premature()


if __name__ == '__main__':
    check()
