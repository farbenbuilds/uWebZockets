"""Authenticate pending source identity before executing source-only checks."""
import hashlib
import os
from pathlib import Path
import runpy
import sys

ROOT = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming')


def main():
    manifest = Path(os.environ['UWZ_PENDING_SOURCE_MANIFEST'])
    expected = {ROOT / 'integration-owned/combined-cases/coordinator.py',
                ROOT / 'combined-native/native_transport.py', ROOT / 'combined-native/test_native_transport.py'}
    rows = [line.split('  ', 1) for line in manifest.read_text().splitlines()]
    hashes = {Path(path): digest for digest, path in rows}
    if len(rows) != 3 or set(hashes) != expected:
        raise ValueError('pending source manifest fields')
    for path, digest in hashes.items():
        if path.resolve() != path or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError('pending source drift: ' + str(path))
    import coordinator
    path = Path(coordinator.__file__).resolve()
    wanted = ROOT / 'integration-owned/combined-cases/coordinator.py'
    if path != wanted or hashlib.sha256(path.read_bytes()).hexdigest() != hashes[wanted]:
        raise ValueError('imported coordinator source identity')
    print('pending_source_identity: PASS')
    sys.argv = sys.argv[1:]
    runpy.run_path(sys.argv[0], run_name='__main__')


if __name__ == '__main__':
    main()
