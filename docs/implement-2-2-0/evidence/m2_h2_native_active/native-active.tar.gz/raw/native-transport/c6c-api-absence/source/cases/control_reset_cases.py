"""Public cancellation and peer reset with ordered stale/refund/sibling barriers."""
import json
import adapter
import model
import pause_cases
import wire


def start(context, tag, primary):
    contract = model.request_contract(tag)
    policy = ('peer_reset' if tag == 'peer_reset' else 'public_cancel') if primary else 'healthy'
    return adapter.start(context, contract['method'], contract['target'],
                         [('content-length', str(contract['declared'])), ('x-case', contract['x-case'])],
                         False, primary, 4095, role='reset' if primary else 'small', policy=policy)


def preterminal(context, receive, stream, tag):
    observed = pause_cases.status(context, receive, tag)
    pause_cases.pending(context, stream)
    raw = context['raw']['streams'][stream]
    if raw['end'] or raw['reset'] or raw['peer_reset']:
        raise ValueError('primary terminal before control')
    if tag != 'cancel_ready':
        model.validate_checkpoint(tag, observed, 'paused')
        return
    expected = model.record(tag, True, 'after')
    expected.update(cancels=0, active=True, reason=None, stale_resume=0, stale_cancel=0)
    model.validate_item(observed, expected)


def stale(context, receive, tag):
    for action in ('resume', 'cancel'):
        pause_cases.control(context, receive, action, tag, 'BodyControlExpired')


def refund(context, receive, target):
    state = context['request']
    if state['sent'] != target or state['connection_debt'] > target:
        raise ValueError('primary refund accounting differs')
    while state['connection_debt']:
        adapter.tick(context)
        data, now = receive()
        adapter.observe(context, data, now)
    if state['connection'] != 65535 or context['protocol'].outbound_flow_control_window != 65535:
        raise ValueError('primary refund window differs')


def run(context, receive):
    tag = context['stage']['case']
    adapter.health(context, receive)
    sibling = adapter.start(context, 'POST', '/echo', [('content-length', '1')], False, False, 1)
    primary = start(context, tag, True)
    length = 7 if tag == 'cancel_ready' else 32
    adapter.send_data(context, primary, model.payload_span(32, 0, length), False)
    preterminal(context, receive, primary, tag)
    if tag == 'peer_reset':
        adapter.tick(context)
        wire.send_peer_reset(context['protocol'], context['records'], context['raw'], context['request'],
                             context['credit'], primary, stage=context['stage'])
        adapter.flush(context)
    else:
        pause_cases.control(context, receive, 'cancel', tag, 'ok')
    terminal = pause_cases.status(context, receive, tag)
    expected = model.record(tag, True, 'after')
    expected.update(stale_resume=0, stale_cancel=0)
    model.validate_item(terminal, expected)
    result = adapter.finish(context, primary, receive)
    if result['headers'] is not None or result['ended'] or result['bytes'] or result['reset'] != 8:
        raise ValueError('primary reset response differs')
    stale(context, receive, tag)
    refund(context, receive, length)
    adapter.send_data(context, sibling, b's', True)
    result = adapter.finish(context, sibling, receive)
    if result['body'] != b's' or result['bytes'] != 1:
        raise ValueError('sibling echo differs')
    recovery_tag = tag + '_recovery'
    recovery = start(context, recovery_tag, False)
    adapter.send_data(context, recovery, model.payload_span(32, 0, 32), True)
    result = json.loads(adapter.finish(context, recovery, receive)['body'])
    model.validate_item(result, model.record(recovery_tag, True, 'after'))
    stale(context, receive, tag)
    adapter.health(context, receive)


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned hooks')
