"""Stream the catalogue large upload through the actual public codec without retaining its body."""
import h2_client
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def update(stream, amount):
    return b'\0\0\4\10\0' + stream.to_bytes(4, 'big') + amount.to_bytes(4, 'big')


def check():
    protocol = h2_client.new_protocol()
    request = request_credit.new_state(request_credit.new_case('large_declared'))
    response = response_credit.new_state()
    stage = output_stage.new_stage(output_stage.new_case('large_declared'), 1, 1, 180, 900)
    raw, records, trace = raw_observer.new_state(), {}, {}
    wire.bind_connection(stage, protocol, raw, request, response, records)
    wire.startup(stage)
    pairs = ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1))
    payload = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in pairs)
    settings = len(payload).to_bytes(3, 'big') + b'\4\0\0\0\0\0' + payload + b'\0\0\0\4\1\0\0\0\0'
    wire.accept(protocol, settings, records, raw, trace, credit=response, request=request, stage=stage)
    wire.drain(stage)
    stream, chunks = wire.start_request(stage, 'POST', 'localhost', '/upload/large_declared', (('content-length', '100000000'),), False,
                                        role='small', primary=True, held=False, body_limit=0, final_status=200,
                                        info_count=0, policy='healthy', mode='small_body', expected_sha256=None,
                                        middleware_policy='required')
    if stream != 1 or not chunks:
        raise RuntimeError('large request headers differ')
    block = bytes(8192)
    remaining = 100000000
    frames = 0
    while remaining:
        available = min(remaining, len(block), request['connection'], request['streams'][1]['window'])
        if available == 0:
            connection_debt = request['connection_debt']
            stream_debt = request['streams'][1]['debt']
            if connection_debt == 0 or stream_debt == 0:
                raise RuntimeError('credit stalled without debt')
            packet = update(0, connection_debt) + update(1, stream_debt)
            wire.accept(protocol, packet, records, raw, trace, credit=response, request=request, stage=stage)
            continue
        wire.send_data(protocol, records, request, 1, block[:available], stage=stage,
                       end_stream=available == remaining, pad_length=None)
        while wire.drain(stage):
            pass
        remaining -= available
        frames += 1
    if request['case']['sent'] != 100000000 or request['case']['positive_frames'] != frames:
        raise RuntimeError('large action accounting differs')
    if records[1]['body'] or records[1]['bytes'] != 0:
        raise RuntimeError('large request body retained')
    print('public codec large flow checks passed bytes=%d frames=%d' % (request['case']['sent'], frames))


if __name__ == '__main__':
    check()
