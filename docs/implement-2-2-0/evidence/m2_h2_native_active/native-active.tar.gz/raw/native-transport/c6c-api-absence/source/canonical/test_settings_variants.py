"""Every output case uses exactly two paired client SETTINGS actions."""
import catalogue
import h2_client
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def check():
    for case in sorted(catalogue.OUTPUT_CASES):
        protocol = h2_client.new_protocol()
        request = request_credit.new_state(request_credit.new_case(case))
        credit = response_credit.new_state()
        stage = output_stage.new_stage(output_stage.new_case(case), 1, 2, 10, 100)
        raw, records, trace = raw_observer.new_state(), {}, {}
        wire.bind_connection(stage, protocol, raw, request, credit, records)
        if len(wire.startup(stage)) != 75:
            raise RuntimeError('client startup differs')
        pairs = ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1))
        payload = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in pairs)
        server = len(payload).to_bytes(3, 'big') + b'\4\0\0\0\0\0' + payload
        ack = b'\0\0\0\4\1\0\0\0\0'
        wire.accept(protocol, server + ack, records, raw, trace, credit=credit, request=request, stage=stage)
        if wire.drain(stage) != ack:
            raise RuntimeError('server settings ACK differs')
        value = 33554432 if case == 'output_pressure_ready' else 0
        wire.update_settings(stage, value)
        update = wire.drain(stage)
        expected = b'\0\0\6\4\0\0\0\0\0\0\4' + value.to_bytes(4, 'big')
        if update != expected:
            raise RuntimeError('second settings serialization differs')
        wire.accept(protocol, ack, records, raw, trace, credit=credit, request=request, stage=stage)
        if request['client_settings'] != 2 or stage['acks'] != 2 or credit['initial'] != value:
            raise RuntimeError('settings accounting differs')
    print('all output settings variants passed')


if __name__ == '__main__':
    check()
