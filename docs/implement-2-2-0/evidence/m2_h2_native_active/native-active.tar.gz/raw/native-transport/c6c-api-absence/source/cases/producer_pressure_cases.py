"""Finite producer reuse and response-pressure schedules over the bound codec."""
import json
import adapter
import model
import wire

TOTAL = 16777313


def grant(context, stream, amount, purpose):
    adapter.tick(context)
    wire.grant(context['protocol'], context['credit'], context['stage']['grants'],
               context['stage'], stream, amount, purpose)
    adapter.flush(context)


def configure(context, receive):
    adapter.tick(context)
    wire.update_settings(context['stage'], 33554432 if context['stage']['case'] == 'output_pressure_ready' else 0)
    adapter.flush(context)
    while context['stage']['acks'] != 2:
        adapter.tick(context)
        data, now = receive()
        adapter.observe(context, data, now)
    adapter.tick(context)
    wire.new_grants(context['stage'])
    grant(context, 0, 33554432 - context['credit']['connection'], 'bootstrap')


def upload(context, tag, primary):
    contract = model.request_contract(tag)
    return adapter.start(context, contract['method'], contract['target'],
                         [('content-length', str(contract['declared'])), ('x-case', contract['x-case'])],
                         False, primary, TOTAL if primary else 4095, role='special' if primary else 'small',
                         held=primary and context['stage']['case'] != 'output_pressure_ready',
                         mode='hash_only' if primary else 'small_body',
                         expected_sha256=model.PRODUCER_HASH if primary else None)


def body_status(context, receive, tag):
    value = json.loads(adapter.get(context, '/status/' + tag, receive)['body'])
    model.validate_item(value, model.record(tag, True, 'after'))


def output_status(context, receive, offset, *, held=False, after_reuse=False):
    tag = context['stage']['case']
    item = json.loads(adapter.get(context, '/output/' + tag, receive)['body'])
    if item.get('tag') != tag:
        raise ValueError('producer diagnostic tag differs')
    model.validate_producer(item, offset, held=held, after_reuse=after_reuse)
    return item


def checkpoint(context, receive, stream, size):
    record, raw = context['records'][stream], context['raw']
    while record['headers'] is None or record['bytes'] < size or raw['header'] or raw['frame'] is not None or raw['remaining']:
        adapter.tick(context)
        data, now = receive()
        adapter.observe(context, data, now)
    observed = raw['streams'][stream]
    if (record['bytes'] != size or record['hash'].hexdigest() != model.digest(TOTAL, 0, size) or
            record['ended'] or observed['end'] or observed['reset'] or observed['peer_reset']):
        raise ValueError('producer checkpoint differs')


def complete(context, receive, stream):
    result = adapter.finish(context, stream, receive)
    if ('body' in result or result['bytes'] != TOTAL or result['sha256'] != model.PRODUCER_HASH or
            not result['ended'] or result['reset'] is not None):
        raise ValueError('producer completion differs')


def echo(context, receive, stream):
    result = adapter.finish(context, stream, receive)
    if result['body'] != b's' or result['bytes'] != 1:
        raise ValueError('sibling echo differs')


def reuse(context, receive, primary):
    body_status(context, receive, 'producer_reuse')
    before = output_status(context, receive, 0, held=True)
    checkpoint(context, receive, primary, 0)
    next_stream = upload(context, 'producer_reuse_next', False)
    adapter.send_data(context, next_stream, model.payload_span(32, 0, 32), True)
    value = json.loads(adapter.finish(context, next_stream, receive)['body'])
    model.validate_item(value, model.record('producer_reuse_next', True, 'after'))
    held = output_status(context, receive, 0, held=True)
    model.validate_progress(before, held)
    checkpoint(context, receive, primary, 0)
    binding = json.loads(adapter.get(context, '/output/producer_reuse_next', receive)['body'])
    model.validate_reuse_binding(before, binding)
    context['output_binding'] = binding
    grant(context, primary, TOTAL, 'special')
    complete(context, receive, primary)
    final = output_status(context, receive, TOTAL, after_reuse=True)
    model.validate_progress(held, final)
    context.setdefault('output_observations', {})['producer_reuse'] = final


def window(context, receive, primary, sibling):
    body_status(context, receive, 'output_pressure_window')
    held = output_status(context, receive, 0, held=True)
    checkpoint(context, receive, primary, 0)
    adapter.send_data(context, sibling, b's', True)
    echo(context, receive, sibling)
    grant(context, primary, 8192, 'special')
    checkpoint(context, receive, primary, 8192)
    prefix = output_status(context, receive, 8192, held=True)
    model.validate_progress(held, prefix)
    grant(context, primary, TOTAL - 8192, 'special')
    complete(context, receive, primary)
    final = output_status(context, receive, TOTAL)
    model.validate_progress(prefix, final)
    context.setdefault('output_observations', {})['output_pressure_window'] = final


def ready(context, receive, primary, sibling):
    adapter.send_data(context, sibling, b's', True)
    while not (adapter.response_finished(context, sibling) and adapter.response_finished(context, primary)):
        adapter.tick(context)
        data, now = receive()
        adapter.observe(context, data, now)
    echo(context, receive, sibling)
    complete(context, receive, primary)
    body_status(context, receive, 'output_pressure_ready')
    final = output_status(context, receive, TOTAL)
    context.setdefault('output_observations', {})['output_pressure_ready'] = final


def run(context, receive):
    case = context['stage']['case']
    configure(context, receive)
    adapter.health(context, receive)
    sibling = None
    if case != 'producer_reuse':
        sibling = adapter.start(context, 'POST', '/echo', [('content-length', '1')], False, False, 1)
    primary = upload(context, case, True)
    adapter.send_data(context, primary, model.payload_span(32, 0, 32), True)
    if case == 'producer_reuse':
        reuse(context, receive, primary)
    elif case == 'output_pressure_window':
        window(context, receive, primary, sibling)
    else:
        ready(context, receive, primary, sibling)
    adapter.health(context, receive)


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned hooks')
