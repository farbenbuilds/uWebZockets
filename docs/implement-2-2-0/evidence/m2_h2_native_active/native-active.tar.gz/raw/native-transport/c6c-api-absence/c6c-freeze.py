"""Freeze authenticated C6b source and safe transport proof only."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path('/workspaces/uWebZockets')
BASE = ROOT / '.uwz-work/evidence/h2-streaming/combined-native'
PROOF = BASE / 'evidence/native-transport'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    before = sys.argv[1:] == ['--before']
    archive_path = ROOT / 'docs/implement-2-2-0/evidence/m2_h2_native_disconnect/native-disconnect.tar.gz'
    if digest(archive_path) != 'a699c83b373b1ed0c4d976a179ac4d2d7c9453344211e87ce1d6b89fc1f4a4b8':
        raise ValueError('accepted C6b archive drift')
    sources = {path.name: digest(path) for path in BASE.glob('*.py')}
    canonical = {path.name: digest(path) for path in (BASE.parent / 'integration-owned/combined-cases').glob('*.py')}
    with tarfile.open(archive_path, 'r:gz') as archive:
        for name, value in sources.items():
            expected = hashlib.sha256(archive.extractfile('source/current/' + name).read()).hexdigest()
            if value != expected and (before or name not in ('native_transport.py', 'test_native_transport.py')):
                raise ValueError('source authority drift: ' + name)
        if canonical['coordinator.py'] != hashlib.sha256(archive.extractfile('source/canonical/coordinator.py').read()).hexdigest():
            raise ValueError('accepted coordinator drift')
    retained = {str(path.relative_to(PROOF)): digest(path) for path in PROOF.rglob('*')
                if path.is_file() and not str(path.relative_to(PROOF)).startswith(('c6c-', 'control/c6c-'))}
    current = dict(sources=sources, canonical=canonical, proof=retained)
    if not before:
        old = json.loads((PROOF / 'c6c-before.json').read_text())
        if old['canonical'] != canonical or old['proof'] != retained:
            raise ValueError('retained canonical/proof changed')
    (PROOF / ('c6c-before.json' if before else 'c6c-after.json')).write_text(json.dumps(current, sort_keys=True, indent=2) + '\n')
    print(json.dumps(dict(native_sources=len(sources), canonical_sources=len(canonical), safe_proof_paths=len(retained), private_originals_read=0)))


if __name__ == '__main__':
    main()
