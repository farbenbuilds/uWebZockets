"""Public-codec synthetic pause and control schedule checks."""
import hashlib
import json
import adapter
import cases
import catalogue
import h2_client
import hpack
import model
from test_core_peer import frame, metrics, new_app, require


def schedule(case):
    if case == 'control_rules':
        return ('/health', '/upload/control_one', '/status/control_one', '/control/resume/control_one',
                '/status/control_one', '/status/control_one', '/upload/control_two', '/status/control_two',
                '/control/resume/control_one', '/control/cancel/control_one', '/status/control_one', '/status/control_two',
                '/status/control_two', '/control/resume/control_one', '/control/cancel/control_one',
                '/control/resume/control_two', '/control/cancel/control_two', '/status/control_one', '/status/control_two', '/health')
    status = '/status/' + case
    return ('/health', '/upload/' + case, status) + ((status,) if case == 'partial_pause' else ()) + (
        '/control/resume/' + case, status, '/health')


def check_storage(state):
    require(len(state['buffer']) <= 8201, 'parser storage bound differs')
    require(len(state['pending']) <= 2 and sum(map(len, state['pending'])) <= 16384, 'pending storage bound differs')
    require(all(type(packet) is bytes and 0 < len(packet) <= 8192 for packet in state['pending']), 'pending packet bound differs')
    require(len(state['uploads']) <= (2 if state['case'] == 'control_rules' else 1), 'upload map bound differs')
    require(0 <= state['cursor'] <= state['head_limit'] and state['heads'] == state['cursor'], 'finite cursor differs')
    require(0 <= state['received'] <= state['head_limit'] + 1 and state['received_bytes'] <= (state['head_limit'] + 1) * 8192,
            'receive bound differs')
    require(state['decoder'].max_allowed_table_size == 4096 and state['encoder'].header_table_size == 4096,
            'HPACK table bound differs')
    state['max_buffer'] = max(state['max_buffer'], len(state['buffer']))
    state['max_pending'] = max(state['max_pending'], len(state['pending']))
    state['max_pending_bytes'] = max(state['max_pending_bytes'], sum(map(len, state['pending'])))


def respond(state, stream, body):
    require(len(state['pending']) < 2, 'pending storage bound differs')
    block = state['encoder'].encode(((':status', '200'), ('x-middleware', 'retained')))
    packet = frame(1, 4, stream, block) + frame(0, 1, stream, body)
    require(len(packet) <= 8192 and len(packet) <= 16384 - sum(map(len, state['pending'])), 'pending packet bound differs')
    state['pending'].append(packet)
    check_storage(state)


def finish(state, app, tag):
    upload, item = state['uploads'][tag], app['records'][tag]
    require(upload['ends'] == 1 and item['active'], 'completion before DATA END')
    count, chunks = upload['count'], upload['frames'] if upload['count'] else 0
    item.update(bytes=count, sha256=upload['digest'].hexdigest(), chunks=chunks,
                max_span=upload['max_span'], callback_checks=2 + 2 * chunks,
                ends=1, active=False, paused=False, terminal_checks=2)
    respond(state, upload['stream'], json.dumps(item).encode())


def data_received(state, app, packet):
    stream, payload, flags = int.from_bytes(packet[5:9], 'big'), packet[9:], packet[4]
    tags = tuple(tag for tag, upload in state['uploads'].items() if upload['stream'] == stream)
    require(len(tags) == 1 and not state['pending'], 'DATA stream or response barrier differs')
    tag = tags[0]
    upload, item = state['uploads'][tag], app['records'][tag]
    ordinal = upload['frames']
    spans = ((8192, 0, 2), (4097, 1, 3)) if tag == 'partial_pause' else ((0, 1, 2),) if tag == 'begin_pause_empty' else (
        (32, 1, 5 if tag == 'control_one' else 12 if tag == 'control_two' else 2),)
    require(ordinal < len(spans), 'DATA ordinal contract differs')
    size, terminal, cursor = spans[ordinal]
    require((len(payload), flags, state['cursor']) == (size, terminal, cursor), 'DATA ordinal contract differs')
    total = 12289 if tag == 'partial_pause' else 0 if tag == 'begin_pause_empty' else 32
    require(payload == (model.payload_span(total, upload['count'], size) if size else b''), 'upload payload differs')
    upload['digest'].update(payload)
    upload['count'] += size
    upload['frames'] += 1
    upload['ends'] += terminal
    upload['max_span'] = max(upload['max_span'], size)
    state['data'] += size
    state['frames'] += 1
    state['ends'] += terminal
    if tag in ('partial_pause', 'final_pause') and ordinal == 0:
        accepted = payload[:7] if tag == 'partial_pause' else payload
        item.update(bytes=len(accepted), sha256=hashlib.sha256(accepted).hexdigest(), chunks=1,
                    max_span=len(accepted), callback_checks=4, paused=True)
    if tag.startswith('control_'):
        finish(state, app, tag)
    elif state['fault'] == 'premature':
        respond(state, stream, json.dumps(item).encode())


def request_path(state):
    paths = schedule(state['case'])
    cursor = state['cursor']
    if cursor < len(paths):
        return paths[cursor]
    require(state['final'] and cursor < len(paths) + 68, 'request beyond finite schedule')
    require(all(upload['ends'] == 1 for upload in state['uploads'].values()), 'final before DATA END')
    index = cursor - len(paths)
    return '/metrics' if index == 67 else '/status/' + model.BODY_SPECS[index][0]


def request_barrier(state):
    cursor = state['cursor']
    if state['case'] == 'control_rules':
        frames = 0 if cursor <= 4 else 1 if cursor <= 11 else 2
    elif state['case'] == 'partial_pause':
        frames = 0 if cursor < 2 else 1 if cursor == 2 else 2
    else:
        frames = int(cursor >= 2)
    require(state['frames'] == frames, 'request before required DATA ordinal')


def control_received(state, app, path, stream):
    _, _, action, tag = path.split('/')
    item = app['records'][tag]
    state['controls'] += 1
    if not item['active']:
        state['stale_' + action] += 1
        respond(state, stream, b'BodyControlExpired')
        return
    if not item['paused']:
        state['not_paused'] += 1
        respond(state, stream, b'BodyNotPaused')
        return
    require(action == 'resume' and state['uploads'][tag]['ends'] == 1, 'resume before queued END')
    state['resumes'] += 1
    respond(state, stream, b'ok')
    finish(state, app, tag)


def request_received(state, app, packet):
    premature_status = state['fault'] == 'premature' and state['cursor'] == 2 and len(state['pending']) == 1
    require(state['acks'] == 1 and (not state['pending'] or premature_status), 'request before preceding response')
    check_storage(state)
    path = request_path(state)
    request_barrier(state)
    upload = path.startswith('/upload/')
    expected = [(':method', 'POST' if upload else 'GET'), (':scheme', 'https'),
                (':authority', 'localhost'), (':path', path)]
    entries = list(state['decoder'].decode(packet[9:]))
    stream = int.from_bytes(packet[5:9], 'big')
    require(entries == expected and stream == 2 * state['cursor'] + 1 and packet[4] == (4 if upload else 5), 'request contract differs')
    require(state['cursor'] < state['head_limit'], 'request beyond finite schedule')
    if upload:
        tag = path[8:]
        require(tag not in state['uploads'] and len(state['uploads']) < (2 if state['case'] == 'control_rules' else 1), 'upload map bound differs')
    state['heads'] += 1
    state['cursor'] += 1
    app['heads'] += 1
    if state['cursor'] > len(schedule(state['case'])):
        state['final_requests'] += 1
    if upload:
        state['uploads'][tag] = dict(stream=stream, count=0, frames=0, ends=0, max_span=0, digest=hashlib.sha256())
        app['records'][tag].update(middleware=1, attempts=1, begins=1, active=True,
                                   paused=tag == 'begin_pause_empty', callback_checks=2)
        return
    if path.startswith('/control/'):
        control_received(state, app, path, stream)
        return
    if path.startswith('/status/'):
        item = dict(app['records'][path[8:]])
        if state['fault'] == 'wrong_tag' and path == '/status/' + state['case']:
            item['tag'] = 'control_one'
        body = json.dumps(item).encode()
    else:
        body = b'ok' if path == '/health' else json.dumps(metrics(app)).encode()
    respond(state, stream, body)


def packet_received(state, app, packet):
    if packet[3] == 4:
        require(packet == frame(4, 1, 0, b'') and state['acks'] == 0 and state['cursor'] == 0, 'settings ACK differs')
        state['acks'] += 1
        return
    if packet[3] == 0:
        data_received(state, app, packet)
        return
    require(packet[3] == 1, 'unexpected frame type')
    request_received(state, app, packet)


def send_bytes(state, app, data):
    check_storage(state)
    require(type(data) is bytes and 0 < len(data) <= 8192, 'send span differs')
    if state['startup']:
        expected = b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n'
        expected += frame(4, 0, 0, b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                                        ((1, 4096), (2, 1), (4, 65535), (5, 16384), (8, 0), (3, 100), (6, 65536))))
        require(data == expected, 'startup bytes differ')
        state['startup'] = False
        state['settings'] += 1
        return
    require(len(data) <= 8201 - len(state['buffer']), 'parser storage bound differs')
    prefix = bytes(state['buffer'][:9]) + data[:max(0, 9 - len(state['buffer']))]
    require(len(prefix) < 3 or int.from_bytes(prefix[:3], 'big') <= 8192, 'frame payload bound differs')
    state['buffer'].extend(data)
    check_storage(state)
    while len(state['buffer']) >= 9:
        size = int.from_bytes(state['buffer'][:3], 'big')
        require(size <= 8192, 'frame payload bound differs')
        if len(state['buffer']) < size + 9:
            return
        packet = bytes(state['buffer'][:size + 9])
        del state['buffer'][:size + 9]
        packet_received(state, app, packet)
        check_storage(state)


def new_peer(case, *, app, prior, now, clock, final=False, fault=None):
    """Caller-owned facts; <=8201 parser bytes, <=2 packets/16384 bytes,
    <=2 uploads, scalar schedule/read cursors and incremental digests.
    Transport ownership/TLS/ALPN are supplied synthetic facts.
    """
    require(type(case) is str and case in ('partial_pause', 'final_pause', 'begin_pause_empty', 'control_rules'), 'unsupported pause peer')
    require(type(app) is dict and set(app) == {'records', 'heads', 'outputs', 'binding'}, 'app fields differ')
    catalogue.schedule(prior)
    require(case not in prior and type(final) is bool and type(now) is int and 0 <= now < catalogue.U64 and callable(clock),
            'peer arguments differ')
    require(fault is None or type(fault) is str and fault in ('premature', 'wrong_tag'), 'peer fault differs')
    require(fault is None or case != 'control_rules', 'fault case differs')
    model.validate_records(prior, 'before', app['records'])
    model.validate_outputs(prior, app['outputs'])
    model.validate_binding_pre_post(prior, app['binding'], model.default_binding() if app['binding'] is None else app['binding'],
                                    app['outputs']['producer_reuse'] if 'producer_reuse' in prior else None)
    require(type(app['heads']) is int and app['heads'] == sum(catalogue.case_budget(item)['heads'] for item in prior),
            'prior heads not earned')
    if not prior:
        require(app['heads'] == 0 and app['binding'] is None, 'empty prior app differs')
    settings = b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    state = dict(case=case, final=final, fault=fault, startup=True, buffer=bytearray(),
                 pending=[frame(4, 0, 0, settings) + frame(4, 1, 0, b'')], uploads={},
                 cursor=0, heads=0, head_limit=len(schedule(case)) + 68 * int(final), settings=0, acks=0,
                 received=0, received_bytes=0, data=0, frames=0, ends=0, controls=0, resumes=0,
                 stale_resume=0, stale_cancel=0, not_paused=0, final_requests=0,
                 max_buffer=0, max_pending=0, max_pending_bytes=0,
                 decoder=hpack.Decoder(max_header_list_size=4096), encoder=hpack.Encoder())

    def send(data):
        send_bytes(state, app, data)

    def receive():
        require(not state['startup'] and bool(state['pending']), 'finite peer input missing')
        check_storage(state)
        require(state['received'] < state['head_limit'] + 1, 'receive bound differs')
        data = state['pending'][0]
        require(len(data) <= (state['head_limit'] + 1) * 8192 - state['received_bytes'], 'receive byte bound differs')
        stamp = clock()
        state['pending'].pop(0)
        state['received'] += 1
        state['received_bytes'] += len(data)
        return data, stamp

    check_storage(state)
    connection = dict(protocol=h2_client.new_protocol(), send=send, receive=receive, now=now,
                      owned=True, tls='TLSv1.3', alpn='h2')
    return dict(connection=connection, state=state)



def check(case, premature=False, app=None, prior=(), final=False, wrong_tag=False, paths=None):
    app = new_app() if app is None else app
    require(not (premature and wrong_tag), 'conflicting peer faults')
    fault = 'premature' if premature else 'wrong_tag' if wrong_tag else None
    peer = new_peer(case, app=app, prior=prior, now=1, clock=lambda: 2, final=final, fault=fault)
    connection, state = peer['connection'], peer['state']
    try:
        context = adapter.open_case(case, connection['protocol'], connection['send'], 1, 30001, 900001,
                                    selected_before=prior, clock=lambda: 2)
        adapter.observe(context, *connection['receive']())
        adapter.run_case(context, connection['receive'])
        if final:
            adapter.final_collection(context, connection['receive'])
            model.validate_records(prior + (case,), 'before', app['records'])
    finally:
        if paths is not None:
            paths.extend(schedule(case)[:min(3, state['cursor'])])
    if premature:
        raise RuntimeError('premature completion accepted')
    if state['cursor'] != state['head_limit'] or state['pending'] or state['buffer']:
        raise RuntimeError('request order differs')
    for tag, upload in state['uploads'].items():
        count = upload['count']
        frames = 2 if tag == 'partial_pause' else 1
        if upload['frames'] != frames or upload['ends'] != 1:
            raise RuntimeError('DATA framing differs')
        if upload['digest'].hexdigest() != model.accepted_hash(count):
            raise RuntimeError('payload differs')
    print(case + ' passed: heads=%d flow=%d' % (len(schedule(case)), context['request']['case']['sent']))
    return app


def main():
    unsupported = [case for case in catalogue.CASES if case not in cases.IMPLEMENTED]
    if len(unsupported) != 0:
        raise RuntimeError('unsupported inventory differs')
    for case in unsupported:
        try:
            cases.select((case,))
        except ValueError:
            continue
        raise RuntimeError('unsupported case selected')
    for case in ('partial_pause', 'final_pause', 'begin_pause_empty', 'control_rules'):
        check(case)
    app = check('partial_pause')
    check('final_pause', app=app, prior=('partial_pause',), final=True)
    paths = []
    try:
        check('final_pause', wrong_tag=True, paths=paths)
    except ValueError as exc:
        if str(exc) != 'record mismatch: tag' or paths != ['/health', '/upload/final_pause', '/status/final_pause']:
            raise RuntimeError('wrong-tag rejection differs') from exc
        print('wrong tag rejected before control: ' + str(exc))
    else:
        raise RuntimeError('wrong tag accepted')
    try:
        check('final_pause', premature=True)
    except ValueError as exc:
        print('premature response rejected: ' + str(exc))
    else:
        raise RuntimeError('premature response was accepted')


if __name__ == '__main__':
    main()
