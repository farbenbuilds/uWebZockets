"""Serialized file/early-final schedules with supplied synthetic diagnostics."""
import hashlib
import json
import adapter
import catalogue
import test_core_peer
import h2_client
from h2.exceptions import FlowControlError, InvalidBodyLengthError
import hpack
import model
import test_ready
import test_producer_pressure

FILE_LENGTH = 24593
FILE_HASH = '8cacc49e5f9553369e25a67f4e0e9a799b38c07245a6da92a54ffb58c3ebc2ac'
EARLY = b'early-final-order'


def paths(case):
    if case == 'stream_file':
        return ['/health', '/echo', '/limit/stream_file?case=stream_file', '/status/stream_file',
                '/output/stream_file', '/output/stream_file', '/health']
    return ['/health', '/limit/early_final_recovery?case=early_final_recovery',
            '/status/early_final_recovery', '/limit/early_final_order?case=early_final_order',
            '/status/early_final_order', '/status/early_final_order', '/health']


def file_diagnostic(done):
    return dict(tag='stream_file', reads=4 if done else 0, requested=FILE_LENGTH if done else 0,
                returned=FILE_LENGTH if done else 0, read_errors=0, close_calls=int(done),
                closed_files=int(done), invalid_spans=0, min_offset=37 if done else 24630,
                max_end=24630 if done else 0, arms=1, arm_errors=0, transferred=True, caller_owned=False)


def new_peer(case, *, app, prior, now, clock, final=False, fault=None):
    """Build an independent bounded synthetic peer without dispatching work."""
    if type(case) is not str or case not in ('stream_file', 'early_final_order'):
        raise ValueError('unsupported file peer')
    if type(app) is not dict or set(app) != {'records', 'heads', 'outputs', 'binding'}:
        raise ValueError('app fields differ')
    catalogue.schedule(prior)
    prior = tuple(prior)
    if fault is not None and type(fault) is not str:
        raise ValueError('peer fault differs')
    if case in prior or type(final) is not bool or type(now) is not int or not 0 <= now < catalogue.U64 or not callable(clock):
        raise ValueError('peer arguments differ')
    model.validate_records(prior, 'before', app['records'])
    model.validate_outputs(prior, app['outputs'])
    model.validate_binding_pre_post(prior, app['binding'], model.default_binding() if app['binding'] is None else app['binding'],
                                    app['outputs']['producer_reuse'] if 'producer_reuse' in prior else None)
    if type(app['heads']) is not int or app['heads'] != sum(catalogue.case_budget(item)['heads'] for item in prior):
        raise ValueError('prior heads not earned')
    decoder, encoder = hpack.Decoder(max_header_list_size=8192), hpack.Encoder()
    primary = 5 if case == 'stream_file' else 7
    length = FILE_LENGTH if case == 'stream_file' else len(EARLY)
    order = paths(case)
    ordinary_count = len(order)
    if final:
        order.extend('/status/' + tag for tag in model.SPECS)
        order.append('/metrics')
    pairs = ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1))
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in pairs)
    initial = test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b'')
    state = dict(startup=True, buffer=bytearray(), pending=[initial], deferred={}, heads=0, streams={},
                 payloads={}, settings=0, acks=0, bootstrap=0, auxiliary=set(), special=0,
                 allowance=0, offset=0, output_headers=False, output_ended=False, reset=False,
                 output_digest=hashlib.sha256(), output_frames=0, reads=0, statuses=0,
                 diagnostics=0, sibling=False, holder_active=False, final=final)

    def queue(packet, *, front=False):
        if type(packet) is not bytes or len(packet) > 8201 or len(state['pending']) + len(state['deferred']) >= 12:
            raise RuntimeError('pending packet capacity differs')
        if front:
            state['pending'].insert(0, packet)
        else:
            state['pending'].append(packet)

    def defer(stream, packet):
        if stream in state['deferred'] or len(state['pending']) + len(state['deferred']) >= 12 or len(packet) > 8201:
            raise RuntimeError('deferred packet capacity differs')
        state['deferred'][stream] = packet

    def response(stream, body):
        block = encoder.encode(((':status', '200'), ('x-middleware', 'retained')))
        packet = test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body)
        if stream in state['auxiliary']:
            queue(packet)
        else:
            defer(stream, packet)

    def output_headers():
        entries = [(':status', '403' if case == 'early_final_order' else '200'), ('x-middleware', 'retained')]
        if fault == 'output_status':
            entries[0] = (':status', '500')
        if case == 'stream_file':
            entries.append(('content-length', '24592' if fault == 'content_length' else str(FILE_LENGTH)))
        if fault == 'duplicate_length':
            entries.append(('content-length', str(FILE_LENGTH)))
        if fault == 'missing_length':
            entries = [entry for entry in entries if entry[0] != 'content-length']
        if fault == 'informationals':
            queue(test_ready.frame(1, 4, primary, encoder.encode(((':status', '100'),))))
        queue(test_ready.frame(1, 4, primary, encoder.encode(entries)))
        state['output_headers'] = True
        if fault == 'early_data':
            queue(test_ready.frame(0, 0, primary, b'x'))
        if fault == 'early_end':
            queue(test_ready.frame(0, 1, primary, b''))

    def observation(path, stream):
        if path == '/health':
            if state['heads'] == ordinary_count and (not state['output_ended'] or state['holder_active']):
                raise RuntimeError('end health before terminal responses')
            response(stream, b'ok')
            return
        if path.startswith('/status/'):
            tag = path[8:]
            if state['heads'] <= ordinary_count:
                state['statuses'] += 1
                if tag == 'early_final_recovery' and (not state['holder_active'] or state['offset']):
                    raise RuntimeError('holder status ordering differs')
                if tag == case and state['offset'] != (8 if state['statuses'] == 3 else 0):
                    raise RuntimeError('body status ordering differs')
            item = dict(app['records'][tag])
            if tag == case and (fault == 'body_hash' or fault == 'prefix_body_hash' and state['statuses'] == 3):
                item['sha256'] = model.LARGE_HASH
            if fault == 'holder_admission' and tag == 'early_final_recovery':
                item['attempts'] = 0
            response(stream, json.dumps(item).encode())
            return
        if path.startswith('/output/'):
            state['diagnostics'] += 1
            if (state['diagnostics'], state['offset']) not in ((1, 0), (2, FILE_LENGTH)):
                raise RuntimeError('file diagnostic order differs')
            item = file_diagnostic(state['output_ended'])
            field = {'held_close': 'close_calls', 'close_twice': 'closed_files', 'read_error': 'read_errors',
                     'invalid_span': 'invalid_spans', 'ownership': 'caller_owned', 'arm_error': 'arm_errors'}.get(fault)
            if field is not None and (fault != 'close_twice' or state['output_ended']):
                item[field] = True if field == 'caller_owned' else 2 if fault == 'close_twice' else 1
            if fault == 'range' and state['output_ended']:
                item['min_offset'] = 36
            if fault == 'requested' and state['output_ended']:
                item['requested'] = item['returned'] - 1
            if fault == 'no_reads' and state['output_ended']:
                item['reads'] = 0
            if state['output_ended']:
                app['outputs'][case] = dict(item)
            response(stream, json.dumps(item).encode())
            return
        if path != '/metrics' or not state['final']:
            raise RuntimeError('unexpected observation')
        values = model.metrics(prior + (case,), 'before')
        values.update(buffered_middleware=app['heads'] - values['middleware'], slot0_active=False, slot1_active=False)
        response(stream, json.dumps(values).encode())

    def headers(packet, stream, flags):
        entries = list(decoder.decode(packet[9:]))
        path = dict(entries)[':path']
        index = state['heads']
        if index >= len(order) or stream != 2 * index + 1 or path != order[index]:
            raise RuntimeError('request order or stream binding differs')
        state['heads'] += 1
        app['heads'] += 1
        upload = path == '/echo' or path.startswith('/limit/')
        expected = [(':method', 'POST' if upload else 'GET'), (':scheme', 'https'),
                    (':authority', 'localhost'), (':path', path)]
        tag = 'sibling' if path == '/echo' else path.split('/')[-1].split('?')[0]
        if upload:
            contract = None if tag == 'sibling' else model.request_contract(tag)
            expected += [('content-length', '1' if contract is None else str(contract['declared']))]
            if contract is not None:
                if contract['method'] != 'POST' or contract['target'] != path:
                    raise RuntimeError('model request differs')
                expected.append(('x-case', tag))
            if tag == 'early_final_order':
                expected.append(('expect', '100-continue'))
        if entries != expected or flags != (4 if upload else 5):
            raise RuntimeError('request header multiplicity order or END differs')
        if not upload:
            observation(path, stream)
            return
        if stream in state['streams'] or len(state['streams']) >= ordinary_count or len(state['payloads']) >= ordinary_count:
            raise RuntimeError('upload capacity differs')
        state['streams'][stream] = tag
        state['payloads'][stream] = dict(count=0, frames=0, digest=hashlib.sha256())
        if tag == 'early_final_recovery':
            item = model.record(tag, True, 'after')
            item.update(bytes=0, sha256=model.EMPTY_HASH, chunks=0, max_span=0, ends=0, metadata_end=0, active=True)
            app['records'][tag] = item
            state['holder_active'] = True
        if tag == 'early_final_order':
            if not state['holder_active'] or state['statuses'] != 1 or stream != primary:
                raise RuntimeError('refusal before actual holder barrier')
            app['records'][tag] = model.record(tag, True, 'after')
            output_headers()

    def data(packet, stream, flags):
        tag, payload = state['streams'][stream], packet[9:]
        item = state['payloads'][stream]
        expected = b's' if tag == 'sibling' else model.payload_span(32, 0, 32)
        if tag == 'early_final_order' or payload != expected or flags != 1 or item['frames']:
            raise RuntimeError('request DATA span END or ordinal differs')
        item['frames'] += 1
        item['count'] += len(payload)
        item['digest'].update(payload)
        if tag == 'sibling':
            if (state['diagnostics'], state['special']) != (1, 0):
                raise RuntimeError('sibling before held diagnostic or after grant')
            state['sibling'] = True
            if fault != 'missing_sibling':
                response(stream, b'x' if fault == 'sibling' else b's')
            return
        completed = model.record(tag, True, 'after')
        completed.update(chunks=1, max_span=32)
        app['records'][tag] = completed
        if fault == 'other_record':
            app['records']['empty_headers']['middleware'] = 1
        if tag == 'early_final_recovery':
            if not state['output_ended'] or not state['reset']:
                raise RuntimeError('holder DATA before refusal END and reset')
            state['holder_active'] = False
            response(stream, json.dumps(completed).encode())
        else:
            if stream != primary:
                raise RuntimeError('actual file primary differs')
            output_headers()

    def grant(stream, amount):
        if stream == 0:
            state['bootstrap'] += 1
            if amount != 33554432 - 65535 or state['bootstrap'] != 1 or state['heads']:
                raise RuntimeError('bootstrap amount once-only or order differs')
            return
        if stream != primary:
            if (amount != 65535 or stream % 2 != 1 or stream > 2 * state['heads'] - 1 or
                    stream in state['auxiliary'] or len(state['auxiliary']) >= len(order) - 1):
                raise RuntimeError('auxiliary grant differs')
            state['auxiliary'].add(stream)
            if stream in state['deferred']:
                queue(state['deferred'].pop(stream))
            return
        sequence = (FILE_LENGTH,) if case == 'stream_file' else (8, 9)
        index = state['special']
        if index >= len(sequence) or amount != sequence[index]:
            raise RuntimeError('special grant sequence differs')
        if case == 'stream_file' and (not state['sibling'] or state['diagnostics'] != 1):
            raise RuntimeError('file grant before diagnostic and sibling')
        if case == 'early_final_order' and (state['statuses'], state['offset']) != (index + 2, 8 if index else 0):
            raise RuntimeError('early grant before body barrier or exact prefix')
        state['special'] += 1
        state['allowance'] += amount

    def packet_received(packet):
        kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
        if kind == 1:
            headers(packet, stream, flags)
            return
        if kind == 0:
            data(packet, stream, flags)
            return
        if kind == 8 and flags == 0 and len(packet) == 13:
            grant(stream, int.from_bytes(packet[9:], 'big'))
            return
        if kind != 4 or stream:
            raise RuntimeError('unexpected outgoing frame')
        if flags == 1 and len(packet) == 9:
            state['acks'] += 1
            return
        if flags or packet[9:] != b'\x00\x04\x00\x00\x00\x00' or state['settings']:
            raise RuntimeError('output SETTINGS differs')
        state['settings'] += 1
        if fault != 'missing_ack':
            queue(test_ready.frame(4, 1, 0, b''))

    def send(data_bytes):
        if type(data_bytes) is not bytes or len(data_bytes) > 8192:
            raise RuntimeError('send bound differs')
        if state['startup']:
            state['startup'] = False
            if data_bytes[:24] != b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n' or len(data_bytes) != 75:
                raise RuntimeError('already-initiated startup differs')
            return
        if len(data_bytes) > 8201 - len(state['buffer']):
            raise RuntimeError('parser capacity differs')
        state['buffer'].extend(data_bytes)
        while len(state['buffer']) >= 9:
            size = int.from_bytes(state['buffer'][:3], 'big')
            if size > 8192:
                raise RuntimeError('frame payload bound differs')
            if len(state['buffer']) < size + 9:
                return
            packet = bytes(state['buffer'][:size + 9])
            del state['buffer'][:size + 9]
            packet_received(packet)

    def output_packet():
        offset = state['offset']
        count = min(8192, state['allowance'] - offset)
        body = model.payload_span(24659, 37 + offset, count) if case == 'stream_file' else EARLY[offset:offset + count]
        if fault == 'output_hash' and offset == 0 or fault == 'output_tail' and offset == 8:
            body = b'x' + body[1:]
        if fault == 'range_generator' and case == 'stream_file':
            body = model.payload_span(FILE_LENGTH, offset, count)
        state['output_digest'].update(body)
        state['offset'] += count
        state['output_frames'] += 1
        end = state['offset'] == length
        state['output_ended'] = end
        if end and case == 'early_final_order':
            reset = test_ready.frame(3, 0, primary, (8 if fault == 'reset_code' else 0).to_bytes(4, 'big'))
            if fault == 'reset_first':
                return reset + test_ready.frame(0, 1, primary, body)
            if fault != 'missing_reset':
                queue(reset)
                state['reset'] = True
        terminal = end and fault != 'missing_end' or fault == 'prefix_end' and state['offset'] == 8
        return test_ready.frame(0, int(terminal), primary, body)

    def receive():
        state['reads'] += 1
        if state['reads'] > 200:
            raise RuntimeError('finite synthetic read limit exceeded')
        result = bytearray()
        while len(result) < 8192:
            if state['pending']:
                packet = state['pending'].pop(0)
            elif state['output_headers'] and state['offset'] < state['allowance']:
                packet = output_packet()
            else:
                break
            size = min(8192 - len(result), len(packet))
            result.extend(packet[:size])
            if size < len(packet):
                queue(packet[size:], front=True)
        if not result:
            raise RuntimeError('missing finite synthetic response')
        return bytes(result), clock()

    connection = dict(protocol=h2_client.new_protocol(), send=send, receive=receive, now=now,
                      owned=True, tls='TLSv1.3', alpn='h2')
    return dict(connection=connection, state=state)


def checked_receive(context, primary, receive):
    retained_body = primary in context['records'] and bool(context['records'][primary]['body'])
    result = receive()
    if retained_body:
        raise RuntimeError('hash-only response retained body')
    return result


def check(case, *, app=None, prior=(), final=False, fault=None):
    if app is None:
        app = test_core_peer.new_app()
    caller_time = [1]
    peer_state = [None]

    def clock():
        if fault == 'deadline' and peer_state[0]['special']:
            return 30001
        if fault == 'backwards_time' and peer_state[0]['special']:
            return caller_time[0] - 1
        caller_time[0] += 1
        return caller_time[0]

    peer = new_peer(case, app=app, prior=prior, now=1, clock=clock, final=final, fault=fault)
    state, connection = peer['state'], peer['connection']
    peer_state[0] = state
    primary = 5 if case == 'stream_file' else 7
    length = FILE_LENGTH if case == 'stream_file' else len(EARLY)
    expected_hash = FILE_HASH if case == 'stream_file' else hashlib.sha256(EARLY).hexdigest()
    order = paths(case)
    context = adapter.open_case(case, connection['protocol'], connection['send'], connection['now'], 30001, 900001,
                                selected_before=prior, clock=clock)
    preserved_outputs = {tag: dict(item) for tag, item in app['outputs'].items()}
    context['output_observations'] = {tag: dict(item) for tag, item in app['outputs'].items()}
    context['output_binding'] = None if app['binding'] is None else dict(app['binding'])

    def receive():
        return checked_receive(context, primary, connection['receive'])

    startup, timestamp = receive()
    adapter.observe(context, startup, timestamp)
    adapter.run_case(context, receive)
    actual = (state['heads'], context['stage']['case_state']['small'], context['request']['case']['sent'])
    expected = (7, 6, 33 if case == 'stream_file' else 32)
    if actual != expected or context['stage']['primary'] != primary or state['heads'] != len(order):
        raise RuntimeError('exact J C R or primary binding differs')
    if (state['settings'], state['acks'], context['stage']['acks'], state['bootstrap'], len(state['auxiliary']), state['special']) != (1, 1, 2, 1, 6, 1 if case == 'stream_file' else 2):
        raise RuntimeError('SETTINGS ACK or grant counts differ')
    if state['offset'] != length or state['allowance'] != length or not state['output_ended'] or state['output_digest'].hexdigest() != expected_hash:
        raise RuntimeError('output length grant END or hash differs')
    if state['output_frames'] != (4 if case == 'stream_file' else 2) or state['reset'] != (case == 'early_final_order'):
        raise RuntimeError('output DATA count or terminal reset differs')
    for stream, item in state['payloads'].items():
        tag = state['streams'][stream]
        body = b's' if tag == 'sibling' else b'' if tag == 'early_final_order' else model.payload_span(32, 0, 32)
        if item['count'] != len(body) or item['frames'] != int(bool(body)) or item['digest'].digest() != hashlib.sha256(body).digest():
            raise RuntimeError('final request body count or hash differs')
    if context['records'] or context['stage']['active'] or context['raw']['streams'] or state['pending'] or state['deferred'] or state['buffer']:
        raise RuntimeError('paired retirement or drained input differs')
    if (context['request']['connection_debt'], context['request']['stream_debt_total']) != (expected[2], expected[2]):
        raise RuntimeError('request carried debt differs')
    if context['output_binding'] != app['binding']:
        raise RuntimeError('unrelated binding replaced')
    for tag, item in preserved_outputs.items():
        if tag != case and (context['output_observations'][tag] != item or app['outputs'][tag] != item):
            raise RuntimeError('existing output observation replaced')
    if case == 'stream_file':
        observed = context['output_observations'][case]
        model.validate_file(observed, True)
        if app['outputs'][case] != observed or app['outputs'][case] is observed:
            raise RuntimeError('peer and client file observations differ')
        saved = observed['reads']
        observed['reads'] += 1
        if app['outputs'][case]['reads'] != saved:
            raise RuntimeError('client observation changed peer truth')
        observed['reads'] = saved
    retained = {tag: dict(item) for tag, item in app['outputs'].items()}
    if final:
        adapter.final_collection(context, receive)
        if state['heads'] != expected[0] + 68 or not context['stage']['final_complete']:
            raise RuntimeError('final67 plus metrics differs')
    model.validate_output_pre_post(prior + (case,), retained, app['outputs'], binding_before=app['binding'] if 'producer_reuse' in prior else None, binding_after=app['binding'] if app['binding'] is not None else model.default_binding())
    model.validate_records(prior + (case,), 'before', app['records'])
    print(case + ' passed: J=%d C=%d R=%d output=%d' % (*actual, state['offset']))
    return app


def construction_checks():
    def forbidden_clock():
        raise RuntimeError('constructor consumed clock')

    for case in ('stream_file', 'early_final_order'):
        app = test_core_peer.new_app()
        before = json.dumps(app, sort_keys=True)
        peer = new_peer(case, app=app, prior=(), now=1, clock=forbidden_clock, final=True)
        connection, state = peer['connection'], peer['state']
        if set(peer) != {'connection', 'state'} or set(connection) != {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'}:
            raise RuntimeError('factory fields differ')
        if json.dumps(app, sort_keys=True) != before or not state['startup'] or state['heads'] or state['offset']:
            raise RuntimeError('constructor dispatched or seeded facts')
        if len(state['pending']) != 1 or connection['now'] != 1 or connection['owned'] is not True or connection['tls'] != 'TLSv1.3' or connection['alpn'] != 'h2':
            raise RuntimeError('startup or supplied facts differ')
        other = new_peer(case, app=app, prior=(), now=1, clock=forbidden_clock)
        if other['state'] is state or other['connection']['protocol'] is connection['protocol']:
            raise RuntimeError('peer state shared')
        try:
            new_peer(case, app=app, prior=('ready_buffered',), now=1, clock=forbidden_clock)
        except ValueError:
            pass
        else:
            raise RuntimeError('unearned prior accepted')
    print('file factories preserve app, clock and independent peer state')


def auxiliary_eligibility_check():
    peer = new_peer('stream_file', app=test_core_peer.new_app(), prior=(), now=1, clock=lambda: 2)
    connection, state = peer['connection'], peer['state']
    connection['send'](connection['protocol'].data_to_send())
    before = (set(state['auxiliary']), dict(state['deferred']), bytes(state['buffer']), list(state['pending']), state['heads'])
    for stream in range(101, 140, 2):
        try:
            connection['send'](test_ready.frame(8, 0, stream, (65535).to_bytes(4, 'big')))
        except RuntimeError as exc:
            if str(exc) != 'auxiliary grant differs':
                raise
        else:
            raise RuntimeError('unsolicited auxiliary grant accepted')
        after = (state['auxiliary'], state['deferred'], bytes(state['buffer']), state['pending'], state['heads'])
        if before != after:
            raise RuntimeError('rejected auxiliary grant changed state')
    print('unsolicited grants rejected without state growth')


def receive_contract_check():
    result = (b'wire', 12)
    calls = [0]
    context = {'records': {5: {'body': b'invalid'}}}

    def receive():
        calls[0] += 1
        context['records'][5]['body'] = b''
        return result

    try:
        checked_receive(context, 5, receive)
    except RuntimeError as exc:
        if str(exc) != 'hash-only response retained body':
            raise
    else:
        raise RuntimeError('invalid client body accepted')
    if calls[0] != 1 or checked_receive(context, 5, receive) is not result or calls[0] != 2:
        raise RuntimeError('receive result identity or call count differs')
    marker = RuntimeError('original receive failure')
    context['records'][5]['body'] = b'invalid'

    def fail():
        calls[0] += 1
        raise marker

    try:
        checked_receive(context, 5, fail)
    except RuntimeError as exc:
        if exc is not marker:
            raise RuntimeError('original receive error identity differs') from exc
    else:
        raise RuntimeError('original receive error suppressed')
    if calls[0] != 3:
        raise RuntimeError('failed receive call count differs')
    print('receive preserves call count, result and error identity')


def rejected(case, fault, message, *, final=False):
    try:
        check(case, fault=fault, final=final)
    except (ValueError, RuntimeError, FlowControlError, InvalidBodyLengthError) as exc:
        if str(exc) != message:
            raise RuntimeError('wrong negative-control rejection: ' + fault + ': ' + str(exc)) from exc
        print(fault + ' rejected: ' + str(exc))
        return
    raise RuntimeError('negative control accepted: ' + fault)


def main():
    construction_checks()
    auxiliary_eligibility_check()
    receive_contract_check()
    app = test_producer_pressure.check('producer_reuse')
    app = check('stream_file', app=app, prior=('producer_reuse',))
    check('early_final_order', app=app, prior=('producer_reuse', 'stream_file'), final=True)
    check('stream_file', final=True)
    check('early_final_order', final=True)
    for case in ('stream_file', 'early_final_order'):
        rejected(case, 'body_hash', 'record mismatch: sha256')
        rejected(case, 'output_hash', 'file or early checkpoint differs' if case == 'early_final_order' else 'body length or digest differs')
        rejected(case, 'output_status', 'wrong final status')
        rejected(case, 'missing_end', 'reset order' if case == 'early_final_order' else 'missing finite synthetic response')
        rejected(case, 'deadline', 'deadline expired or invalid')
        rejected(case, 'backwards_time', 'monotonic time moved backwards')
        rejected(case, 'missing_ack', 'missing finite synthetic response')
        rejected(case, 'early_data', 'Flow control window shrunk below 0')
        rejected(case, 'early_end', 'invalid terminal')
        rejected(case, 'informationals', 'invalid HEADERS')
        rejected(case, 'other_record', 'record mismatch: middleware', final=True)
    for fault, message in (('held_close', 'file close once'), ('close_twice', 'file close once'),
                           ('ownership', 'file ownership'), ('arm_error', 'file ownership'),
                           ('read_error', 'file ownership'), ('invalid_span', 'file ownership'),
                           ('range', 'file bounded range'), ('requested', 'file bounded range'),
                           ('no_reads', 'file bounded range'), ('range_generator', 'body length or digest differs'),
                           ('sibling', 'sibling echo differs'), ('missing_sibling', 'missing finite synthetic response'),
                           ('content_length', 'InvalidBodyLengthError: Expected 24592 bytes, received 24593'),
                           ('duplicate_length', 'file content-length differs'), ('missing_length', 'file content-length differs')):
        rejected('stream_file', fault, message)
    for fault, message in (('holder_admission', 'record mismatch: attempts'), ('prefix_body_hash', 'record mismatch: sha256'),
                           ('output_tail', 'body length or digest differs'), ('prefix_end', 'invalid terminal'),
                           ('reset_first', 'reset order'), ('reset_code', 'wrong reset code'),
                           ('missing_reset', 'missing finite synthetic response')):
        rejected('early_final_order', fault, message)


if __name__ == '__main__':
    main()
