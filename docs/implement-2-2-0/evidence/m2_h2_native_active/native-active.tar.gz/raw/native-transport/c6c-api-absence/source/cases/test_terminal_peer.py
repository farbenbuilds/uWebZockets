"""Independent bounded terminal peer shared by cancellation and callback failures."""
import hashlib
import json
import catalogue
import h2_client
import hpack
import model
from test_core_peer import frame, metrics, require


def paths(case):
    result = ['/health', '/echo', '/limit/' + case + '?case=' + case]
    if case != 'end_error':
        result.append('/status/' + case)
    if case in ('cancel_ready', 'cancel_paused'):
        result.append('/control/cancel/' + case)
    return result + ['/status/' + case, '/control/resume/' + case, '/control/cancel/' + case,
                     '/limit/' + case + '_recovery?case=' + case + '_recovery',
                     '/control/resume/' + case, '/control/cancel/' + case, '/health']


def new_peer(case, *, app, prior, now, clock, final=False, fault=None):
    """Synthetic owned TLS facts; parser8201, frames8192, pending4/16384,
    three upload summaries, HPACK4096, reads200 and bounded scalar receipts.
    No dispatcher, observer, clock or application effects during construction.
    """
    require(type(case) is str and case in ('cancel_ready', 'cancel_paused', 'peer_reset',
                                          'sink_error', 'invalid_progress', 'end_error'), 'unsupported terminal peer')
    require(type(app) is dict and set(app) == {'records', 'heads', 'outputs', 'binding'}, 'app fields differ')
    catalogue.schedule(prior)
    require(case not in prior and type(final) is bool and type(now) is int and 0 <= now < catalogue.U64 and callable(clock),
            'peer arguments differ')
    faults = ('preterminal_bytes', 'preterminal_pause', 'preterminal_chunks', 'preterminal_cancel',
              'terminal_reason', 'terminal_metadata', 'terminal_cancel', 'terminal_ends', 'terminal_bytes',
              'terminal_hash', 'terminal_chunks', 'chunk_diagnostic', 'progress_diagnostic', 'end_diagnostic',
              'stale_reply', 'stale_counter', 'missing_refund', 'excess_refund', 'sibling_echo',
              'recovery_record', 'other_record', 'early_final', 'primary_final', 'reset_code',
              'duplicate_reset', 'missing_reset', 'split_reset')
    require(fault is None or type(fault) is str and fault in faults, 'peer fault differs')
    model.validate_records(prior, 'before', app['records'])
    model.validate_outputs(prior, app['outputs'])
    model.validate_binding_pre_post(prior, app['binding'], model.default_binding() if app['binding'] is None else app['binding'],
                                    app['outputs']['producer_reuse'] if 'producer_reuse' in prior else None)
    require(type(app['heads']) is int and app['heads'] == sum(catalogue.case_budget(item)['heads'] for item in prior),
            'prior heads not earned')
    if not prior:
        require(app['heads'] == 0 and app['binding'] is None, 'empty prior app differs')
    settings = b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    length = 7 if case == 'cancel_ready' else 15 if case in ('sink_error', 'invalid_progress') else 32
    state = dict(case=case, fault=fault, final=final, startup=True, buffer=bytearray(), delivered_buffer=bytearray(),
                 pending=[frame(4, 0, 0, settings) + frame(4, 1, 0, b'')], heads=0,
                 ordinary=len(paths(case)), head_limit=len(paths(case)) + 68 * int(final),
                 streams={}, payloads={}, statuses=0, statuses_delivered=0, stale=0, stale_delivered=0,
                 deliveries={}, terminated=False, resets=0, resets_queued=0, resets_delivered=0,
                 outgoing_resets=0, settings=0, refunded=False, refund_queued=False, refund_bytes=0,
                 sibling_done=False, sibling_delivered=False, recovery_done=False, recovery_delivered=False,
                 complete=False, final_requests=0, reads=0, received_bytes=0, sent_bytes=0,
                 primary_length=length, preterminal=int(case != 'end_error'),
                 max_buffer=0, max_pending=1, max_pending_bytes=48,
                 decoder=hpack.Decoder(max_header_list_size=4096), encoder=hpack.Encoder())

    def send(data):
        send_bytes(state, app, data)

    def receive():
        return receive_bytes(state, clock)

    connection = dict(protocol=h2_client.new_protocol(), send=send, receive=receive, now=now,
                      owned=True, tls='TLSv1.3', alpn='h2')
    return dict(connection=connection, state=state)


def check_storage(state):
    require(len(state['buffer']) <= 8201 and len(state['delivered_buffer']) <= 8201, 'parser storage bound differs')
    require(len(state['pending']) <= 4 and sum(map(len, state['pending'])) <= 16384, 'pending storage bound differs')
    require(all(type(packet) is bytes and 0 < len(packet) <= 8192 for packet in state['pending']), 'pending packet bound differs')
    require(0 <= state['heads'] <= state['head_limit'] and state['final_requests'] <= 68, 'finite cursor differs')
    require(0 <= state['reads'] <= 200 and state['received_bytes'] <= 200 * 8192 and
            state['sent_bytes'] <= 200 * 8192, 'finite byte/read bound differs')
    require(len(state['streams']) <= 3 and len(state['payloads']) <= 3 and len(state['deliveries']) <= 2,
            'upload or delivery retention bound differs')
    require(state['stale'] <= 4 and state['stale_delivered'] <= state['stale'] and
            state['statuses'] <= state['preterminal'] + 1 and state['statuses_delivered'] <= state['statuses'],
            'terminal cursor bound differs')
    require(state['settings'] <= 1 and state['outgoing_resets'] <= 1 and state['resets_queued'] <= 2 and
            state['resets_delivered'] <= state['resets_queued'], 'control count bound differs')
    require(state['decoder'].max_allowed_table_size == 4096 and state['encoder'].header_table_size == 4096,
            'HPACK table bound differs')
    for item in state['payloads'].values():
        require(0 <= item['count'] <= 32 and 0 <= item['frames'] <= 2 and
                0 <= item['accepted'] <= item['count'], 'upload receipt bound differs')
    state['max_buffer'] = max(state['max_buffer'], len(state['buffer']))
    state['max_pending'] = max(state['max_pending'], len(state['pending']))
    state['max_pending_bytes'] = max(state['max_pending_bytes'], sum(map(len, state['pending'])))


def queue(state, packets):
    require(len(state['pending']) + len(packets) <= 4 and
            sum(map(len, state['pending'])) + sum(map(len, packets)) <= 16384, 'pending storage bound differs')
    require(all(type(packet) is bytes and 0 < len(packet) <= 8192 for packet in packets), 'pending packet bound differs')
    state['pending'].extend(packets)
    check_storage(state)


def response(state, stream, body, receipt=None):
    require(len(body) <= 4095 and len(state['pending']) < 4, 'response queue or body bound differs')
    block = state['encoder'].encode(((':status', '200'), ('x-middleware', 'retained')))
    queue(state, (frame(1, 4, stream, block) + frame(0, 1, stream, body),))
    if receipt is not None:
        require(stream not in state['deliveries'] and len(state['deliveries']) < 2, 'response receipt bound differs')
        state['deliveries'][stream] = receipt


def reset(state):
    fault = state['fault']
    code = 8 if state['case'] in ('cancel_ready', 'cancel_paused') else 2
    if fault == 'reset_code':
        code = 2 if code == 8 else 8
    packet = frame(3, 0, 5, code.to_bytes(4, 'big'))
    state['resets'] += 1
    if fault == 'primary_final':
        response(state, 5, b'')
        return
    if fault == 'missing_reset':
        return
    state['resets_queued'] += 1 + int(fault == 'duplicate_reset')
    if fault == 'split_reset':
        queue(state, (packet[:11], packet[11:]))
        return
    queue(state, (packet + (packet if fault == 'duplicate_reset' else b''),))


def terminate(state, app):
    require(not state['terminated'] and state['statuses_delivered'] == state['preterminal'], 'terminal action ordinal differs')
    state['terminated'] = True
    case = state['case']
    item = app['records'][case]
    item.update(active=False, paused=False)
    if case == 'end_error':
        item.update(ends=1, end_errors=1, metadata_end=1)
        return
    item.update(cancels=1, reason='reset' if case == 'peer_reset' else
                'sink_failure' if case in ('sink_error', 'invalid_progress') else 'cancelled')
    if case in ('sink_error', 'invalid_progress'):
        item['chunk_errors' if case == 'sink_error' else 'invalid_progress'] += 1


def observed(state, app, tag):
    item = dict(app['records'][tag])
    fault, case = state['fault'], state['case']
    if tag == 'empty_headers' and fault == 'other_record':
        item['middleware'] = 1
    if tag == case + '_recovery' and fault == 'recovery_record':
        item['metadata_end'] = 0
    if tag != case:
        return item
    if fault == 'stale_counter':
        item.update(stale_resume=0, stale_cancel=0)
    if not state['terminated']:
        changes = {'preterminal_bytes': ('bytes', 8 if case in ('sink_error', 'invalid_progress') else 1),
                   'preterminal_pause': ('paused', not item['paused']),
                   'preterminal_chunks': ('chunks', 1), 'preterminal_cancel': ('cancels', 1)}
    else:
        changes = {'terminal_reason': ('reason', 'sink_failure' if case in ('cancel_ready', 'cancel_paused', 'peer_reset') else 'reset'),
                   'terminal_metadata': ('metadata_begin', 0), 'terminal_cancel': ('cancels', 1 if case == 'end_error' else 2),
                   'terminal_ends': ('ends', 0 if case == 'end_error' else 1), 'terminal_bytes': ('bytes', 15),
                   'terminal_hash': ('sha256', model.EMPTY_HASH), 'terminal_chunks': ('chunks', 1),
                   'chunk_diagnostic': ('chunk_errors', 0), 'progress_diagnostic': ('invalid_progress', 0),
                   'end_diagnostic': ('end_errors', 0)}
    if fault in changes:
        key, value = changes[fault]
        item[key] = value
    return item


def status(state, app, stream, tag):
    receipt = None
    if state['heads'] <= state['ordinary']:
        require(tag == state['case'] and state['statuses'] < state['preterminal'] + 1 and not state['stale'],
                'status count tag or stale ordinal differs')
        require(state['terminated'] == (state['statuses'] == state['preterminal']), 'status terminal ordinal differs')
        length = state['primary_length']
        if not state['terminated'] and state['case'] in ('sink_error', 'invalid_progress'):
            length = 7
        require(state['payloads'][5]['count'] == length, 'status DATA barrier differs')
        state['statuses'] += 1
        receipt = 'status'
    response(state, stream, json.dumps(observed(state, app, tag)).encode(), receipt)


def control(state, app, stream, path):
    _, _, action, tag = path.split('/')
    require(tag == state['case'] and action in ('resume', 'cancel'), 'control binding differs')
    if not state['terminated']:
        require(action == 'cancel' and tag in ('cancel_ready', 'cancel_paused'), 'public cancellation action differs')
        terminate(state, app)
        response(state, stream, b'ok')
        reset(state)
        return
    require(state['statuses_delivered'] == state['preterminal'] + 1 and state['stale'] < 4 and
            action == ('resume' if state['stale'] % 2 == 0 else 'cancel'), 'stale control ordinal differs')
    require((state['stale'] >= 2) == state['recovery_delivered'], 'stale recovery barrier differs')
    state['stale'] += 1
    app['records'][tag]['stale_' + action] += 1
    response(state, stream, b'ok' if state['fault'] == 'stale_reply' else b'BodyControlExpired', 'stale')
    if state['stale'] != 2:
        return
    require(not state['refund_queued'], 'primary refund ordinal differs')
    state['refund_queued'] = True
    if state['fault'] != 'missing_refund':
        amount = state['payloads'][5]['count'] + int(state['fault'] == 'excess_refund')
        queue(state, (frame(8, 0, 0, amount.to_bytes(4, 'big')),))


def request(state, app, path, stream):
    if path.startswith('/status/'):
        status(state, app, stream, path[8:])
        return
    if path.startswith('/control/'):
        control(state, app, stream, path)
        return
    if path == '/health':
        if state['heads'] == state['ordinary']:
            require(state['stale_delivered'] == 4 and state['sibling_delivered'] and state['recovery_delivered'],
                    'final health barrier differs')
        response(state, stream, b'ok', 'health' if state['heads'] == state['ordinary'] else None)
        return
    require(path == '/metrics' and state['heads'] > state['ordinary'], 'unexpected auxiliary request')
    response(state, stream, json.dumps(metrics(app)).encode())


def upload_headers(state, app, entries, stream, flags, tag):
    target = '/echo' if tag == 'sibling' else '/limit/' + tag + '?case=' + tag
    fields = [('content-length', '1')] if tag == 'sibling' else [('content-length', '32'), ('x-case', tag)]
    expected = [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'), (':path', target)] + fields
    require(entries == expected and flags == 4, 'upload headers or initial END differ')
    require(not (tag == 'sibling' and stream != 3 or tag == state['case'] and stream != 5), 'primary sibling binding differs')
    require(stream not in state['streams'] and len(state['streams']) < 3, 'upload count bound differs')
    if tag not in ('sibling', state['case']):
        require((state['stale_delivered'], state['sibling_delivered'], state['refunded']) == (2, True, True),
                'recovery isolation barrier differs')
    state['streams'][stream] = tag
    state['payloads'][stream] = dict(count=0, frames=0, accepted=0, digest=hashlib.sha256())
    if tag == 'sibling':
        return
    item = app['records'][tag]
    item.update(middleware=1, attempts=1, begins=1, metadata_middleware=1, metadata_begin=1,
                active=True, paused=tag == 'peer_reset')


def request_path(state):
    index = state['heads']
    if index < state['ordinary']:
        return paths(state['case'])[index]
    require(state['final'] and state['complete'] and index < state['head_limit'], 'final before finite schedule completion')
    if index == state['ordinary'] + 67:
        return '/metrics'
    return '/status/' + model.BODY_SPECS[index - state['ordinary']][0]


def headers(state, app, packet, stream, flags):
    path = request_path(state)
    entries = list(state['decoder'].decode(packet[9:]))
    require(stream == 2 * state['heads'] + 1 and dict(entries).get(':path') == path, 'request order or stream binding differs')
    if path == '/echo' or path.startswith('/limit/'):
        tag = 'sibling' if path == '/echo' else path.split('/')[-1].split('?')[0]
        upload_headers(state, app, entries, stream, flags, tag)
    else:
        require(entries == [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)] and flags == 5,
                'auxiliary headers differ')
    state['heads'] += 1
    app['heads'] += 1
    if state['heads'] > state['ordinary']:
        state['final_requests'] += 1
    if path != '/echo' and not path.startswith('/limit/'):
        request(state, app, path, stream)


def primary_contract(state, item, payload, flags):
    case, ordinal = state['case'], item['frames']
    callback = case in ('sink_error', 'invalid_progress')
    length = (7 if ordinal == 0 else 8) if callback else state['primary_length']
    require(not state['terminated'] and ordinal <= int(callback) and
            payload == model.payload_span(32, 0, length) and flags == int(case == 'end_error'),
            'primary DATA bytes END or ordinal differs')
    require(not callback or ordinal == 0 or state['statuses_delivered'] == 1, 'missing accepted-prefix barrier')
    return length


def primary_data(state, app, stream, payload):
    case = state['case']
    item = app['records'][case]
    summary = state['payloads'][stream]
    accepted = 0 if case == 'peer_reset' else 7 if case != 'end_error' else 32
    if summary['frames'] == 1:
        summary['accepted'] = accepted
        item.update(bytes=accepted, sha256=hashlib.sha256(payload[:accepted]).hexdigest(),
                    chunks=int(accepted > 0), max_span=accepted, paused=case in ('cancel_paused', 'peer_reset'))
    if case in ('sink_error', 'invalid_progress') and summary['frames'] == 2:
        item.update(chunks=2, max_span=8)
    if case == 'end_error' or case in ('sink_error', 'invalid_progress') and summary['frames'] == 2:
        terminate(state, app)
        reset(state)
        return
    if state['fault'] == 'early_final':
        response(state, stream, b'')


def data(state, app, packet, stream, flags):
    require(stream in state['streams'], 'DATA stream differs')
    tag, payload = state['streams'][stream], packet[9:]
    item = state['payloads'][stream]
    if tag == state['case']:
        primary_contract(state, item, payload, flags)
    else:
        expected = b's' if tag == 'sibling' else model.payload_span(32, 0, 32)
        require(payload == expected and flags == 1 and item['frames'] == 0, 'sibling recovery DATA bytes END or ordinal differs')
        require(state['stale_delivered'] == 2 and state['refunded'], 'sibling DATA before stale and actual refund barrier')
        require(tag == 'sibling' or state['sibling_delivered'], 'recovery DATA ordinal differs')
    item['frames'] += 1
    item['count'] += len(payload)
    item['digest'].update(payload)
    if tag == state['case']:
        primary_data(state, app, stream, payload)
        return
    item['accepted'] += len(payload)
    if tag == 'sibling':
        state['sibling_done'] = True
        response(state, stream, b'x' if state['fault'] == 'sibling_echo' else b's', 'sibling')
        return
    state['recovery_done'] = True
    app['records'][tag].update(bytes=item['count'], sha256=item['digest'].hexdigest(), chunks=item['frames'],
                               max_span=len(payload), ends=1, metadata_end=1, active=False)
    response(state, stream, json.dumps(observed(state, app, tag)).encode(), 'recovery')


def packet_received(state, app, packet):
    kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
    if kind == 4:
        require(packet == frame(4, 1, 0, b'') and state['settings'] == 0 and state['heads'] == 0, 'unexpected frame or settings ACK')
        state['settings'] += 1
        return
    require(state['settings'] == 1, 'request before settings ACK')
    if kind == 1:
        headers(state, app, packet, stream, flags)
        return
    if kind == 0:
        data(state, app, packet, stream, flags)
        return
    require(state['case'] == 'peer_reset' and packet == frame(3, 0, 5, (8).to_bytes(4, 'big')) and
            state['outgoing_resets'] == 0, 'canonical outgoing CANCEL8 differs')
    terminate(state, app)
    state['outgoing_resets'] += 1
    state['resets'] += 1
    if state['fault'] == 'primary_final':
        response(state, 5, b'')


def send_bytes(state, app, data_bytes):
    require(type(data_bytes) is bytes and 0 < len(data_bytes) <= 8192, 'send bound differs')
    require(len(data_bytes) <= 200 * 8192 - state['sent_bytes'], 'send byte bound differs')
    if state['startup']:
        expected = b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n' + frame(4, 0, 0, b''.join(
            key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
            ((1, 4096), (2, 1), (4, 65535), (5, 16384), (8, 0), (3, 100), (6, 65536))))
        require(data_bytes == expected, 'startup differs')
        state['startup'] = False
        state['sent_bytes'] += len(data_bytes)
        return
    require(len(data_bytes) <= 8201 - len(state['buffer']), 'parser storage bound differs')
    state['buffer'].extend(data_bytes)
    state['sent_bytes'] += len(data_bytes)
    check_storage(state)
    while len(state['buffer']) >= 9:
        size = int.from_bytes(state['buffer'][:3], 'big')
        require(size <= 8192, 'frame payload bound differs')
        if len(state['buffer']) < size + 9:
            return
        packet = bytes(state['buffer'][:size + 9])
        del state['buffer'][:size + 9]
        packet_received(state, app, packet)
        check_storage(state)


def delivered_frame(state, packet):
    kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
    if kind == 3:
        state['resets_delivered'] += 1
        return
    if kind == 8:
        require(state['stale_delivered'] == 2 and not state['refunded'] and stream == 0, 'refund read ordinal differs')
        state['refunded'] = True
        state['refund_bytes'] += int.from_bytes(packet[9:], 'big')
        return
    if kind != 0 or not flags & 1 or stream not in state['deliveries']:
        return
    receipt = state['deliveries'].pop(stream)
    if receipt in ('status', 'stale'):
        state[receipt + ('es_delivered' if receipt == 'status' else '_delivered')] += 1
        return
    if receipt == 'health':
        state['complete'] = True
        return
    state[receipt + '_delivered'] = True


def receive_bytes(state, clock):
    require(not state['startup'] and bool(state['pending']) and state['reads'] < 200, 'missing finite synthetic response')
    check_storage(state)
    packet = state['pending'][0]
    require(len(packet) <= 200 * 8192 - state['received_bytes'] and
            len(packet) <= 8201 - len(state['delivered_buffer']), 'receive byte bound differs')
    stamp = clock()
    state['pending'].pop(0)
    state['reads'] += 1
    state['received_bytes'] += len(packet)
    state['delivered_buffer'].extend(packet)
    while len(state['delivered_buffer']) >= 9:
        size = int.from_bytes(state['delivered_buffer'][:3], 'big')
        require(size <= 8192, 'delivered frame bound differs')
        if len(state['delivered_buffer']) < size + 9:
            break
        current = bytes(state['delivered_buffer'][:size + 9])
        del state['delivered_buffer'][:size + 9]
        delivered_frame(state, current)
    check_storage(state)
    return packet, stamp


if __name__ == '__main__':
    pass
