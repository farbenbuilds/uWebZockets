"""Metadata helper schedule with initial headers separated from terminal trailers."""
import json
import adapter
import credit_cases
import model
import wire


def run(context, receive):
    tag = 'metadata_helpers'
    adapter.health(context, receive)
    contract = model.request_contract(tag)
    stream = adapter.start(context, contract['method'], contract['target'], contract['header_entries'],
                           False, True, 4095, held=True)
    adapter.send_data(context, stream, model.payload_span(32, 0, 16), False)
    observed = credit_cases.barrier(context, receive, stream, tag)
    adapter.send_data(context, stream, model.payload_span(32, 16, 16), False)
    adapter.tick(context)
    chunks = wire.send_trailers(context['stage'], stream,
                                [('x-h62', 'changed'), ('x-trailer-only', 'discarded')])
    for chunk in chunks:
        adapter.tick(context)
        context['send'](chunk)
    if credit_cases.barrier(context, receive, stream, tag) != observed:
        raise ValueError('metadata trailers changed paused record')
    credit_cases.resume(context, receive, stream, tag)
    model.validate_item(json.loads(adapter.finish(context, stream, receive)['body']), model.record(tag, True, 'after'))
    adapter.health(context, receive)


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned hooks')
