"""Ordinary final collection retains actual parsed facts without extra requests."""
import hashlib
import json
import adapter
import h2_client
import hpack
import model
import test_ready


def require(value, message):
    if not value:
        raise RuntimeError(message)


def check():
    prior = ('reuse',)
    selection = prior + ('ready_buffered',)
    supplied = model.records(selection, 'before')
    for tag in model.SPECS:
        if tag.startswith('reuse_'):
            supplied[tag].update(chunks=2, max_span=19)
    model.validate_records(selection, 'before', supplied)
    paths = ['/health', '/metrics', '/echo', '/metrics', '/health']
    paths += ['/status/' + tag for tag in model.SPECS] + ['/metrics']
    state = dict(startup=True, buffer=bytearray(), pending=[], heads=0, data=0, ends=0,
                 settings=0, received=0, digest=hashlib.sha256(), final_metrics=None,
                 decoder=hpack.Decoder(), encoder=hpack.Encoder())

    def response(stream, body):
        block = state['encoder'].encode(((':status', '200'), ('x-middleware', 'retained')))
        state['pending'].append(test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body))

    def respond(path, stream):
        if path == '/health':
            response(stream, b'ok')
            return
        if path.startswith('/status/'):
            response(stream, json.dumps(supplied[path[8:]]).encode())
            return
        require(path == '/metrics', 'unexpected final observation')
        values = model.metrics(selection, 'before')
        values.update(buffered_middleware=389 + state['heads'] - values['middleware'], slot0_active=False, slot1_active=False)
        if state['heads'] == 73:
            state['final_metrics'] = values
        response(stream, json.dumps(values).encode())

    def packet_received(packet):
        kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
        if kind == 4:
            require(packet == test_ready.frame(4, 1, 0, b''), 'settings differ')
            state['settings'] += 1
            return
        if kind == 0:
            payload = model.core_request('ready_buffered')['body']
            require(stream == 5 and flags == 1 and packet[9:] == payload, 'echo DATA differs')
            state['data'] += len(packet[9:])
            state['ends'] += 1
            state['digest'].update(packet[9:])
            response(stream, payload)
            return
        require(kind == 1 and state['heads'] < len(paths), 'unexpected request')
        entries = list(state['decoder'].decode(packet[9:]))
        path = paths[state['heads']]
        echo = path == '/echo'
        expected = [(':method', 'POST' if echo else 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)]
        if echo:
            expected += [('content-length', '257')]
        require(entries == expected and stream == 2 * state['heads'] + 1 and flags == (4 if echo else 5), 'request contract differs')
        state['heads'] += 1
        if not echo:
            respond(path, stream)

    def send(data):
        require(type(data) is bytes and len(data) <= 8192, 'send bound differs')
        if state['startup']:
            state['startup'] = False
            require(len(data) == 75 and data[:24] == b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n', 'startup differs')
            return
        state['buffer'].extend(data)
        while len(state['buffer']) >= 9:
            size = int.from_bytes(state['buffer'][:3], 'big')
            if len(state['buffer']) < size + 9:
                return
            packet = bytes(state['buffer'][:size + 9])
            del state['buffer'][:size + 9]
            packet_received(packet)

    def receive():
        require(state['pending'] and state['received'] < 73, 'unexpected receive')
        state['received'] += 1
        return state['pending'].pop(0), 2

    context = adapter.open_case('ready_buffered', h2_client.new_protocol(), send, 1, 30001, 900001,
                                selected_before=prior, clock=lambda: 2)
    settings = b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    adapter.observe(context, test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b''), 2)
    adapter.run_case(context, receive)
    require('final_observations' not in context and state['heads'] == 5, 'premature final capture')
    identities = {name: context[name] for name in ('stage', 'raw', 'request', 'credit', 'records')}
    require(adapter.final_collection(context, receive) is None, 'ordinary final return changed')
    require('final_observations' in context, 'ordinary validated final facts discarded')
    capture = context['final_observations']
    require(set(capture) == {'records', 'metrics'} and capture['records'] == supplied and capture['metrics'] == state['final_metrics'], 'parsed final facts differ')
    require(capture['records']['reuse_0']['chunks'] == 2 and capture['records']['reuse_0']['max_span'] == 19,
            'observed callback diagnostics discarded')
    require(model.record('reuse_0', True, 'before')['chunks'] is None, 'diagnostics no longer exercise unconstrained observations')
    require(capture['records']['reuse_0'] is not supplied['reuse_0'] and capture['metrics'] is not state['final_metrics'], 'capture substituted supplied objects')
    counts = state['heads'], state['received'], context['stage']['final_registered']
    model.validate_pre_post(selection, capture['records'], json.loads(json.dumps(capture['records'])))
    model.validate_metrics(selection, 'before', capture['metrics'])
    require(context['final_observations'] is capture and counts == (73, 73, 68), 'capture retrieval issued requests')
    require((state['heads'], state['received'], context['stage']['final_registered']) == counts, 'comparison issued requests')
    require(all(context[key] is value for key, value in identities.items()), 'final collection replaced state')
    require((context['stage']['case_deadline'], context['stage']['whole_deadline']) == (30001, 900001), 'final collection changed deadlines')
    require(not state['pending'] and not state['buffer'] and not context['records'] and not context['stage']['active'], 'ordinary final residue')
    require(state['data'] == 257 and state['ends'] == 1 and state['settings'] == 1 and
            state['digest'].hexdigest() == model.CORE_RESPONSES['ready_buffered'][2], 'ordinary action counts differ')
    print('ordinary capture passed: heads=73 final=68 chunks=2 max_span=19 return=None extra_requests=0')


if __name__ == '__main__':
    test_ready.check('ready_buffered', final=True)
    check()
