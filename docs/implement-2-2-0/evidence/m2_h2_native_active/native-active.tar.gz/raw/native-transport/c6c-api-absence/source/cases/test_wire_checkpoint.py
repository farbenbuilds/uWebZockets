"""Serialized source-only proofs for the nonterminal passive checkpoint."""
import ssl
import sys
import hpack
import test_wire_oracle as oracle
import test_wire_oracle_checks as checks


def active_fixture(*, case='shutdown_active', index=1, held=True, final=True, missing_response=False, short_upload=False):
    tags = tuple('tag_' + str(number) for number in range(67)) if final else ()
    target = '/limit/' + case + '?case=' + case
    ordinary = (checks.request('/metrics'),)
    if held:
        ordinary += (checks.request(target, method='POST', end='open', body=b'x' * 32,
                                   role='transport', terminal='transport_abandon', status=None),)
    connection, wrapped, state, boundary = checks.fixture(ordinary, identity=(7, case, index), tags=tags)
    checks.start(wrapped)
    encoder, responses = hpack.Encoder(), hpack.Encoder()
    wrapped['send'](checks.head(encoder, target='/metrics'))
    checks.received(wrapped, boundary, checks.head(responses, status=200))
    if held:
        wrapped['send'](checks.head(encoder, 3, target, method='POST', end=False))
        wrapped['send'](checks.data_packet(b'x' * (31 if short_upload else 32), 3, end=False))
    if short_upload:
        return wrapped, state, boundary
    for number, target in enumerate(tuple('/status/' + tag for tag in tags) + (('/metrics',) if final else ())):
        stream = 2 * (len(ordinary) + number) + 1
        wrapped['send'](checks.head(encoder, stream, target))
        if not missing_response or number < 67:
            checks.received(wrapped, boundary, checks.head(responses, stream, status=200))
    return wrapped, state, boundary


def reject_checkpoint(state, code):
    operation = state['operation']
    previous = oracle.failure(state)
    checks.rejected(lambda: oracle.checkpoint(state), code)
    checks.require(state['operation'] == operation and not state['busy'], 'rejection changed operation or busy')
    first = oracle.failure(state)
    checks.require(first == previous if previous is not None else first[0] == code, 'checkpoint replaced first poison')
    checks.rejected(lambda: oracle.seal(state), 'oracle_unsealed')
    checks.require(oracle.failure(state) == first, 'ordinary seal erased checkpoint failure')


def immutable(value):
    if type(value) is tuple:
        for item in value:
            immutable(item)
        return
    checks.require(type(value) in (int, bool, str, bytes, type(None)), 'mutable receipt member')


def check_prefix_and_refunds():
    wrapped, state, boundary = active_fixture()
    operations, calls = state['operation'], tuple(boundary['calls'])
    frozen = oracle.checkpoint(state)
    receipt, operation = frozen
    immutable(frozen)
    checks.require(operation == operations == 141 and tuple(boundary['calls']) == calls == (72, 69), 'checkpoint performed or counted an operation')
    checks.require(not state['sealed'] and oracle.failure(state) is None, 'checkpoint sealed or poisoned')
    checks.require(receipt[0] == (7, 'shutdown_active', 1) and receipt[1] is True, 'checkpoint identity')
    checks.require(receipt[8:14] == (68, 68, 1, 32, 32, (3,)), 'final collection/debt/incomplete mismatch')
    checks.require(receipt[2][0] == 72 and receipt[3][0] == 69, 'success counters differ')
    checks.require(len(receipt[-1]) == 70 and receipt[-1][1][9:15] == (False, False, None, None, 32, False), 'held stream terminal manufactured')
    checks.require(receipt[2][1] == sum(map(len, boundary['sent'])) and receipt[2][2] == 72, 'send byte/frame accounting')
    checks.require(receipt[3][2:4] == (69, 69) and receipt[5:7] == (69, 69), 'response accounting')
    packet = checks.credit_packet(7) + checks.credit_packet(11, 3)
    for fragment in (packet[:1], packet[1:10], packet[10:]):
        checks.received(wrapped, boundary, fragment)
    live = oracle.seal(state)
    checks.require(live[11:14] == (25, 21, (3,)) and frozen == (receipt, operations), 'refund mutated prefix or debt')
    checks.require(live[3][0] == receipt[3][0] + 3 and live[3][1] == receipt[3][1] + len(packet), 'live counters lost fragmented returns')
    checks.require(live[3][2] == receipt[3][2] + 2 and state['operation'] == operations + 3, 'live frames/operations differ')
    checks.require(live[2] == receipt[2], 'checkpoint reset live send counters')
    checks.require(live == oracle.seal(state) and live is not oracle.seal(state), 'ordinary reseal semantics changed')
    checks.require(receipt[11:14] == (32, 32, (3,)), 'detached prefix mutated')
    print('serialized final67+metrics/held transport, immutable operation141 prefix, fragmented refunds and ordinary reseal passed')


def check_terminal_exceptions():
    for original in (ssl.SSLEOFError(8, 'unexpected EOF'), OSError('read failed')):
        wrapped, state, boundary = active_fixture()
        frozen = oracle.checkpoint(state)
        boundary['receive_error'] = original
        try:
            wrapped['receive']()
        except OSError as error:
            checks.require(error is original, 'terminal exception identity replaced')
        else:
            raise RuntimeError('terminal exception suppressed')
        first = oracle.failure(state)
        checks.require(first == ('receive_exception', 'receive', 142, frozen[0][3][1], None), 'exception failure location differs')
        checks.require(state['receive']['calls'] == 69 and boundary['calls'][1] == 70, 'failed receive counted as success or skipped effect')
        reject_checkpoint(state, 'checkpoint_poisoned')
        boundary['receive_error'] = None
        checks.received(wrapped, boundary, b'untrusted tail')
        checks.require(oracle.failure(state) is first and state['operation'] == 142, 'first failure or poison pass-through changed')
        checks.require(boundary['calls'][1] == 71 and frozen[1] == 141 and frozen[0][11:14] == (32, 32, (3,)), 'effects/prefix changed after failure')
    print('actual SSLEOFError/OSError identity, exact attempts, sticky first poison and failed ordinary seal passed')


def check_prior_refunds():
    for amount in (1, 32):
        wrapped, state, boundary = active_fixture()
        checks.received(wrapped, boundary, checks.credit_packet(amount) + checks.credit_packet(amount, 3))
        receipt, operation = oracle.checkpoint(state)
        checks.require(receipt[11:14] == (32 - amount, 32 - amount, (3,)), 'checkpoint fabricated or erased actual debt')
        checks.require(operation == 142 and receipt[3][0] == 70, 'prior refund accounting lost')
        checks.require(oracle.seal(state) == receipt, 'checkpoint changed live prefix')
    print('partial and complete observed pre-checkpoint refunds retain exact bounded debt and held incompleteness')


def check_duplicate_and_sealed():
    wrapped, state, boundary = active_fixture()
    frozen = oracle.checkpoint(state)
    reject_checkpoint(state, 'checkpoint_duplicate')
    checks.require(frozen[1] == 141 and frozen[0][11:14] == (32, 32, (3,)), 'duplicate changed prefix')
    wrapped, state, boundary = active_fixture()
    sealed = oracle.seal(state)
    reject_checkpoint(state, 'checkpoint_sealed')
    checks.require(state['sealed'] and sealed[8:11] == (68, 68, 1), 'rejected checkpoint unsealed state')
    wrapped, state, boundary = active_fixture()
    frozen = oracle.checkpoint(state)
    oracle.seal(state)
    wrapped['send'](b'')
    checks.poisoned(state, 'after_seal')
    checks.require(boundary['sent'][-1] == b'' and frozen[1] == 141, 'after-seal original effect lost')
    print('duplicate/after-seal checkpoints poison; prior checkpoint preserves ordinary after-seal effect and poison')


def check_phase_and_incomplete():
    options = (dict(case='shutdown_idle', held=False), dict(index=2, held=False), dict(held=False),
               dict(final=False), dict(case='disconnect', final=False))
    for arguments in options:
        wrapped, state, boundary = active_fixture(**arguments)
        reject_checkpoint(state, 'checkpoint_phase')
    for arguments in (dict(missing_response=True), dict(short_upload=True)):
        wrapped, state, boundary = active_fixture(**arguments)
        reject_checkpoint(state, 'checkpoint_incomplete')
    print('wrong descriptor/case/index, absent held stream/tags, incomplete upload and missing final metrics response reject')


def check_known_tails():
    packet = checks.credit_packet(1)
    for direction in ('send', 'receive'):
        for cut in range(1, len(packet)):
            wrapped, state, boundary = active_fixture()
            if direction == 'send':
                wrapped['send'](packet[:cut])
            else:
                checks.received(wrapped, boundary, packet[:cut])
            checks.require(bytes(state[direction]['buffer']) == packet[:cut], 'tail trigger missing')
            reject_checkpoint(state, 'checkpoint_incomplete')
    print('all24 nonempty partial WINDOW_UPDATE header/payload tails reject in both directions')


def check_prior_poison():
    wrapped, state, boundary = active_fixture()
    checks.received(wrapped, boundary, checks.credit_packet(1, 999))
    checks.require(oracle.failure(state)[0] == 'credit', 'real invalid credit did not poison')
    reject_checkpoint(state, 'checkpoint_poisoned')
    print('real invalid-credit prior poison cannot be cleared by checkpoint')


def check_reentrant():
    wrapped, state, boundary = active_fixture()
    calls = []

    def original():
        calls.append('receive')
        checks.rejected(lambda: oracle.checkpoint(state), 'checkpoint_busy')
        return (b'', None)

    result = oracle.invoke(state, 'receive', original)
    checks.require(result == (b'', None) and calls == ['receive'], 'reentrant attempt changed original effect/result')
    checks.require(oracle.failure(state) == ('checkpoint_busy', 'none', 142, 0, None), 'reentrant checkpoint failure differs')
    checks.require(not state['busy'] and state['receive']['calls'] == 69, 'reentrant checkpoint counted a successful observation')
    checks.poisoned(state, 'checkpoint_busy')
    print('checkpoint during actual wrapped operation rejects and preserves original effect/result')


def check():
    checks.require(callable(oracle.checkpoint), 'checkpoint API missing')
    check_prefix_and_refunds()
    check_terminal_exceptions()
    check_prior_refunds()
    check_duplicate_and_sealed()
    check_phase_and_incomplete()
    check_known_tails()
    check_prior_poison()
    check_reentrant()


if __name__ == '__main__':
    if len(sys.argv) == 2 and sys.argv[1] == '--check':
        check()
