"""Synthetic in-memory public-codec proof of the buffered schedule."""
import adapter
import model
from test_core_peer import frame, new_app, new_peer


def check(case='ready_buffered', final=False, *, clock=lambda: 2, after_case=None):
    app = new_app()
    peer = new_peer(case, app=app, prior=(), now=1, clock=lambda: 2, final=final)
    connection, state = peer['connection'], peer['state']
    context = adapter.open_case(case, connection['protocol'], connection['send'], 1, 30001, 900001, clock=clock)
    adapter.observe(context, *connection['receive']())
    adapter.run_case(context, connection['receive'])
    if after_case is not None:
        after_case(context, connection['receive'])
    if final:
        adapter.final_collection(context, connection['receive'])
    expected = (3 if case == 'async_delayed' else 5) + (68 if final else 0)
    if state['heads'] != expected or context['stage']['case_state']['heads'] != expected:
        raise RuntimeError('case totals differ')
    sent = 257 if case == 'ready_buffered' else 0 if case == 'async_delayed' else 100000000
    if context['request']['case']['sent'] != sent:
        raise RuntimeError('case totals differ')
    if case == 'ready_buffered' and (bytes(state['body']) != model.core_request(case)['body'] or state['frames'] != 0 or state['ends'] != 1):
        raise RuntimeError('echo request body differs')
    if case == 'async_delayed' and (state['data'] != 0 or state['ends'] != 0):
        raise RuntimeError('delayed request DATA differs')
    if case.startswith('large_'):
        if state['frames'] != 12208 or state['ends'] != 1:
            raise RuntimeError('upload DATA actions differ')
        if state['digest'].hexdigest() != model.LARGE_HASH or state['count'] != 100000000:
            raise RuntimeError('large payload differs')
    print(case + ' codec schedule passed')


if __name__ == '__main__':
    check()
