import ast
import contextlib
import importlib.util
import io
import pathlib
import sys


def main():
    root = pathlib.Path(__file__).parent
    for name in ('catalogue.py', 'model.py', 'test_catalogue.py', 'test_model.py', 'test_structure.py'):
        tree = ast.parse((root / name).read_text())
        if any(isinstance(node, (ast.ClassDef, ast.Assert)) for node in ast.walk(tree)):
            raise ValueError('class or assert in ' + name)
    previous = sys.argv
    try:
        for args in ([], ['foreign', '--unknown']):
            sys.argv = args
            for name in ('catalogue','model','test_catalogue','test_model','test_structure'):
                spec = importlib.util.spec_from_file_location(name+'_inert',root/(name+'.py'))
                module = importlib.util.module_from_spec(spec)
                captured = io.StringIO()
                with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
                    spec.loader.exec_module(module)
                if captured.getvalue():
                    raise ValueError('import produced output: '+name)
    finally:
        sys.argv = previous
    print('AST and inert import checks passed')


if __name__ == '__main__':
    main()
