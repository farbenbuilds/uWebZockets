"""Actual public-codec rejection of malformed credit and response frames."""
import adapter
import h2_client
import hpack
import test_ready
import wire


def setup():
    sent = []
    context = adapter.open_case('ready_buffered', h2_client.new_protocol(), sent.append,
                                1, 30, 90, clock=lambda: 2)
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    adapter.observe(context, test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b''), 2)
    stream = adapter.start(context, 'POST', '/echo', (), False, False, 257)
    adapter.send_data(context, stream, b'abc', True)
    return context, stream


def rejected(context, stream, packet, reason):
    try:
        adapter.observe(context, packet, 2)
    except ValueError as error:
        if reason not in str(error):
            raise RuntimeError('unexpected rejection: ' + str(error)) from error
    else:
        raise RuntimeError('malformed packet accepted')
    if not context['stage']['failed'] or context['records'][stream]['ended']:
        raise RuntimeError('failed observation left successful state')
    for call in (lambda: adapter.flush(context), lambda: wire.complete(context['records'], context['raw'], stream)):
        try:
            call()
        except ValueError:
            continue
        raise RuntimeError('failed stage continued or completed')


def update(stream, amount):
    return test_ready.frame(8, 0, stream, amount.to_bytes(4, 'big'))


def check():
    for scope, amount, reason in ((0, 0, 'invalid integer'), (0, 4, 'invalid connection refund'),
                                  (1, 0, 'invalid integer'), (1, 4, 'invalid stream refund')):
        context, stream = setup()
        rejected(context, stream, update(stream if scope else 0, amount), reason)
    for scope, reason in ((0, 'invalid connection refund'), (1, 'invalid stream refund')):
        context, stream = setup()
        target = stream if scope else 0
        adapter.observe(context, update(target, 3), 2)
        rejected(context, stream, update(target, 1), reason)
    context, stream = setup()
    adapter.observe(context, update(0, 3) + update(stream, 3), 2)
    if context['request']['connection_debt'] != 0 or context['request']['stream_debt_total'] != 0:
        raise RuntimeError('valid credit control differs')
    headers = hpack.Encoder().encode(((':status', '200'), ('x-middleware', 'retained')))
    packets = [test_ready.frame(1, 4, stream, headers) + test_ready.frame(0, 1, stream, b'abc')]
    result = adapter.finish(context, stream, lambda: (packets.pop(), 2))
    if result['body'] != b'abc' or not result['ended']:
        raise RuntimeError('valid response control differs')
    for kind, flags, payload, reason in ((0, 1, b'x', 'invalid DATA'), (3, 0, b'\0\0\0\x08', 'invalid reset')):
        context, stream = setup()
        rejected(context, stream, test_ready.frame(kind, flags, stream, payload), reason)
    for kind, payload, reason in ((0, b'x', 'invalid terminal'), (3, b'\0\0\0\x08', 'invalid reset')):
        context, stream = setup()
        headers = hpack.Encoder().encode(((':status', '200'), ('x-middleware', 'retained')))
        adapter.observe(context, test_ready.frame(1, 4, stream, headers) + test_ready.frame(0, 1, stream, b'abc'), 2)
        try:
            adapter.observe(context, test_ready.frame(kind, 1 if kind == 0 else 0, stream, payload), 2)
        except ValueError as error:
            if reason not in str(error):
                raise RuntimeError('unexpected terminal rejection') from error
        else:
            raise RuntimeError('duplicate terminal accepted')
        try:
            adapter.finish(context, stream, lambda: (b'', 2))
        except ValueError:
            pass
        else:
            raise RuntimeError('failed terminal completed')
    context, stream = setup()
    wrong = hpack.Encoder().encode(((':status', '500'), ('x-middleware', 'retained')))
    rejected(context, stream, test_ready.frame(1, 5, stream, wrong), 'wrong final status')
    print('credit and terminal rejection checks passed')


if __name__ == '__main__':
    check()
