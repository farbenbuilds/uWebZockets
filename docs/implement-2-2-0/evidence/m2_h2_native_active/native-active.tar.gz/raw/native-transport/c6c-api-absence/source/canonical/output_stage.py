"""Catalogue-bound response stage accounting with an inherited final boundary."""
import catalogue
import model
import request_credit
from types import MappingProxyType

MAX_STREAM = 2147483647
SPECIAL_LIMIT = MappingProxyType({'producer_reuse': 2050, 'output_pressure_window': 2050,
                                 'output_pressure_ready': 2050, 'stream_file': 24594,
                                 'early_final_order': 2})


def require(condition, message):
    if not condition:
        raise ValueError(message)


def new_case(case):
    return {'case': case, 'limits': catalogue.case_budget(case), 'connections': 0,
            'heads': 0, 'small': 0, 'resets': 0, 'bytes': 0, 'reads': 0, 'deadlines': None,
            'transport_finished': False, 'codecs': [], 'request_case': None}


def new_stage(case_state, primary, expected_acks, case_deadline, whole_deadline):
    require(type(case_state) is dict and type(case_state.get('case')) is str, 'invalid case state')
    case = case_state['case']
    limits = case_state['limits']
    if case == 'disconnect' and case_state['connections'] == 1:
        require(case_state['transport_finished'], 'replacement before transport terminal')
    require(type(primary) is int and 0 < primary <= MAX_STREAM and primary & 1 and
            type(expected_acks) is int and expected_acks == (2 if case in catalogue.OUTPUT_CASES else 1) and
            type(case_deadline) is int and type(whole_deadline) is int and
            0 < case_deadline <= whole_deadline and case_state['connections'] < limits['connections'] and
            case_state['deadlines'] in (None, (case_deadline, whole_deadline)), 'invalid stage')
    case_state['connections'] += 1
    case_state['deadlines'] = (case_deadline, whole_deadline)
    return {'case_state': case_state, 'connection_index': case_state['connections'], 'case': case, 'limits': limits, 'primary': primary, 'budget': limits['receive_bytes'],
            'bytes': 0, 'reads': 0, 'case_deadline': case_deadline, 'whole_deadline': whole_deadline,
            'active': {}, 'auxiliary': 0, 'initial_settings': 0, 'acks': 0,
            'expected_acks': expected_acks, 'resets': 0, 'final': False, 'high_water': 0,
            'primary_complete': False, 'final_registered': 0, 'final_bytes': 0,
            'final_budget': 0, 'held': None, 'final_complete': False, 'signaled': False,
            'small_registered': 0, 'final_paths': set(), 'binding': None, 'grants': None,
            'failed': False, 'blocked_outbound': b''}


def register(stage, stream_id, role, primary=False, held=False, path=None):
    require(not stage['failed'], 'failed stage')
    require(not stage['signaled'], 'observation after signal')
    require(type(stream_id) is int and stage['high_water'] < stream_id <= MAX_STREAM and stream_id & 1 and
            type(primary) is bool and type(held) is bool and type(role) is str and len(stage['active']) < 8, 'invalid stage registration')
    require(primary == (not stage['final'] and stream_id == stage['primary']), 'invalid primary')
    if primary:
        expected_role = ('small' if stage['case'] == 'disconnect' and stage['connection_index'] == 2 else
                         'special' if stage['case'] in catalogue.OUTPUT_CASES else
                         'transport' if (stage['case'] == 'shutdown_active' or
                                         stage['case'] == 'disconnect' and stage['connection_index'] == 1) else
                         'reset' if stage['limits']['heads'] > stage['limits']['small'] else 'small')
        require(role == expected_role, 'invalid primary role')
    else:
        require(role == 'small', 'invalid auxiliary role')
    case = stage['case_state']
    small_limit = stage['limits']['small'] - (68 if stage['limits']['final_included'] else 0)
    if not stage['final'] and role == 'small':
        require(case['small'] < small_limit, 'small response bound')
    head_limit = stage['limits']['heads'] + (68 if stage['final'] and not stage['limits']['final_included'] else 0)
    require(case['heads'] < head_limit, 'case head bound')
    held_outputs = ('producer_reuse', 'output_pressure_window', 'stream_file', 'early_final_order')
    held_uploads = ('shutdown_active', 'partial_pause', 'final_pause', 'begin_pause_empty', 'continue_paused',
                    'queued_trailers_padding', 'receive_credit', 'concurrent_routes', 'metadata_helpers')
    require(not held or (primary and stage['case'] in held_uploads + held_outputs), 'invalid held stream')
    require(not primary or stage['case'] not in held_uploads + held_outputs or held, 'missing required hold')
    if stage['final']:
        tags = model.SPECS
        require(type(path) is str and path not in stage['final_paths'] and
                ((path.startswith('/status/') and path[8:] in tags) or
                 (path == '/metrics' and len(stage['final_paths']) == len(tags))), 'invalid final observation')
        require(stage['final_registered'] < len(tags) + 1, 'final response count')
    else:
        require(path is None, 'unexpected final path')
    if not stage['final'] and not primary:
        require(stage['auxiliary'] < stage['limits']['heads'] - 1, 'auxiliary bound')
    if stage['final']:
        stage['final_registered'] += 1
        stage['final_paths'].add(path)
    elif not primary:
        stage['auxiliary'] += 1
    if not stage['final'] and role == 'small':
        case['small'] += 1
        stage['small_registered'] += 1
    case['heads'] += 1
    stage['active'][stream_id] = {'headers': 0, 'data': 0, 'primary': primary,
                                  'terminal': False, 'held': held, 'role': role}
    stage['high_water'] = stream_id




def transport_ended(stage, stream_id, raw):
    require(stream_id in stage['active'] and stage['active'][stream_id]['role'] == 'transport' and
            not stage['active'][stream_id]['terminal'] and raw.get('closed') is True and
            raw.get('streams') == {}, 'invalid transport terminal')
    stage['active'][stream_id]['terminal'] = True
    stage['case_state']['transport_finished'] = True
    retire(stage, stream_id)

def resume(stage, stream_id):
    require(stream_id in stage['active'] and stage['active'][stream_id]['held'] and
            stage['active'][stream_id]['role'] != 'special' and not stage['final'], 'invalid resume')
    stage['active'][stream_id]['held'] = False

def retire(stage, stream_id):
    require(stream_id in stage['active'], 'unknown stage stream')
    record = stage['active'][stream_id]
    require(record['terminal'], 'stage response incomplete')
    if record['primary']:
        stage['primary_complete'] = True
    del stage['active'][stream_id]


def enter_final(stage, raw, request, response_credit, held=None):
    require(not stage['final'] and response_credit['initial_acked'] and response_credit['pending'] is None and
            stage['acks'] == stage['expected_acks'] and stage['initial_settings'] == 1 and
            stage['case_state']['resets'] == stage['limits']['resets'] and
            stage['case_state']['small'] == stage['limits']['small'] - (68 if stage['limits']['final_included'] else 0) and
            stage['case_state']['heads'] == stage['limits']['heads'] - (68 if stage['limits']['final_included'] else 0),
            'invalid final boundary')
    if held is None:
        require(stage['primary_complete'] and not stage['active'] and not raw['streams'], 'unfinished primary')
    else:
        require(stage['case'] == 'shutdown_active' and set(stage['active']) == {held} and
                set(raw['streams']) == {held} and stage['active'][held]['held'] and
                not stage['active'][held]['terminal'], 'invalid held request')
    expected_active = set() if held is None else {held}
    require(set(response_credit['streams']) == expected_active and expected_active <= set(request['streams']),
            'ledger final boundary differs')
    for stream_id, record in request['streams'].items():
        if stream_id not in expected_active:
            require(record['retired'] and request_credit.closed(record), 'unretired request at final boundary')
    connection_debt = request['connection_debt']
    require(type(connection_debt) is int and 0 <= connection_debt <= 65535, 'invalid carried debt')
    stream_debt = 0
    for item in request['streams'].values():
        value = item['debt']
        require(type(value) is int and 0 <= value <= 65535, 'invalid carried debt')
        stream_debt = catalogue.add_u64(stream_debt, value)
    require(type(request['stream_debt_total']) is int and request['stream_debt_total'] == stream_debt,
            'stream debt counter differs')
    debt = catalogue.add_u64(connection_debt, stream_debt)
    require(debt <= (64 if stage['case'] == 'shutdown_active' else 131070), 'invalid carried debt')
    stage['final_budget'] = catalogue.final_budget(debt)
    stage['held'] = held
    stage['final'] = True
    request['final'] = True



def remaining(stage, now):
    require(type(now) is int and now >= 0 and now < stage['case_deadline'] and
            now < stage['whole_deadline'], 'deadline expired or invalid')
    return min(stage['case_deadline'] - now, stage['whole_deadline'] - now)

def read(stage, data):
    require(type(data) is bytes and len(data) <= 8192, 'invalid read')
    if not data:
        return
    next_reads = stage['reads'] + 1
    cap = stage['limits']['receive_calls']
    if stage['final'] and stage['limits']['legacy_receive_cap'] is None and not stage['limits']['final_included']:
        cap += stage['final_budget']
    require(stage['case_state']['reads'] + 1 <= cap, 'read cap exceeded')
    if stage['final']:
        require(stage['final_bytes'] + len(data) <= stage['final_budget'], 'final byte budget exceeded')
        if stage['limits']['final_included']:
            require(stage['case_state']['bytes'] + len(data) <= stage['budget'], 'case byte budget exceeded')
        stage['final_bytes'] += len(data)
    else:
        require(stage['case_state']['bytes'] + len(data) <= stage['budget'], 'case byte budget exceeded')
    stage['bytes'] += len(data)
    stage['case_state']['bytes'] += len(data)
    stage['reads'] = next_reads
    stage['case_state']['reads'] += 1


def frame(stage, length, kind, flags, stream_id, reserved):
    require(type(length) is int and 0 <= length <= 16384 and type(kind) is int and 0 <= kind <= 255 and
            type(flags) is int and 0 <= flags <= 255 and type(stream_id) is int and 0 <= stream_id <= MAX_STREAM and
            type(reserved) is bool and not reserved, 'invalid frame')
    if kind == 4:
        require(not stage['final'] and stream_id == 0, 'invalid settings')
        if flags == 0:
            require(length == 30 and stage['initial_settings'] == 0, 'invalid initial settings')
            stage['initial_settings'] += 1
        else:
            require(flags == 1 and length == 0 and stage['initial_settings'] == 1 and stage['acks'] < stage['expected_acks'], 'invalid settings ACK')
            stage['acks'] += 1
        return
    require(stage['initial_settings'] == 1, 'missing initial settings')
    if kind == 8:
        require(flags == 0 and length == 4, 'invalid WINDOW_UPDATE')
        return
    if kind == 3:
        require(not stage['final'] and flags == 0 and length == 4 and stream_id in stage['active'] and
                stage['case_state']['resets'] < stage['limits']['resets'], 'invalid reset')
        stage['resets'] += 1
        stage['case_state']['resets'] += 1
        return
    require(kind in (0, 1) and stream_id in stage['active'], 'invalid response frame')
    record = stage['active'][stream_id]
    require(not record['terminal'] and not (record['held'] and flags & 1), 'invalid terminal')
    if kind == 1:
        info = int(record['primary'] and stage['case'] in ('continue_ready', 'continue_paused'))
        require(flags in (4, 5) and length <= 4096 and record['headers'] < 1 + info and
                (not info or record['headers'] > 0 or flags == 4), 'invalid HEADERS')
        record['headers'] += 1
        return
    info = int(record['primary'] and stage['case'] in ('continue_ready', 'continue_paused'))
    require(flags in (0, 1) and record['headers'] == 1 + info, 'invalid DATA')
    limit = SPECIAL_LIMIT.get(stage['case'], 4096) if record['primary'] else 4096
    require(record['data'] < limit, 'DATA frame count exceeded')
    record['data'] += 1


def finish_final(stage, raw):
    held = set() if stage['held'] is None else {stage['held']}
    require(stage['final'] and stage['final_registered'] == len(model.SPECS) + 1 and '/metrics' in stage['final_paths'] and
            set(stage['active']) == held and
            set(raw['streams']) == held and not raw['header'] and raw['frame'] is None and raw['remaining'] == 0,
            'incomplete final collection')
    stage['final_complete'] = True


def signal(stage):
    require(stage['case'] == 'shutdown_active' and stage['held'] is not None and
            stage['final_complete'] and not stage['signaled'], 'invalid shutdown signal')
    stage['signaled'] = True


def finished(stage, kind, flags, stream_id):
    if (kind in (0, 1) and flags & 1) or kind == 3:
        require(stream_id in stage['active'], 'unknown terminal stream')
        stage['active'][stream_id]['terminal'] = True
