"""Compare the reviewed C5 public view without reading private originals."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path('/workspaces/uWebZockets')
NATIVE = ROOT / '.uwz-work/evidence/h2-streaming/combined-native'
PROOF = NATIVE / 'evidence/native-transport'
ARCHIVE = ROOT / 'docs/implement-2-2-0/evidence/m2_h2_native_post/native-post.tar.gz'


def require(value, message):
    if not value:
        raise ValueError(message)


def main():
    require(hashlib.sha256(ARCHIVE.read_bytes()).hexdigest() == 'd19281da19d04c3afbc3bb97ef614b21efa3746f0dc405dfb982d7cc959fbe92', 'archive drift')
    public = NATIVE / 'evidence/native-post/privacy-publication-inputs'
    manifest = json.loads((public / 'manifest.json').read_text())
    substitutions = {row['original_member']: public / row['replacement'] for row in manifest['substitutions']}
    require(len(substitutions) == 25, 'projection count')
    result = {}
    with tarfile.open(ARCHIVE, 'r:gz') as archive:
        for member in archive.getmembers():
            if not member.name.startswith('native/') or not member.isfile():
                continue
            relative = member.name.removeprefix('native/')
            data = substitutions.get(member.name, NATIVE / relative).read_bytes()
            expected = archive.extractfile(member).read()
            if relative == 'test_native_imports.py' and sys.argv[1:] == ['--after']:
                expected = expected.replace(b"'test_native_post')", b"'test_native_post', 'native_transport', 'test_native_transport')")
            require(data == expected, 'public view drift: ' + relative)
            result[relative] = hashlib.sha256(data).hexdigest()
    require(len(result) == 6482, 'native public count')
    expected_paths = set(result) | {'native_transport.py', 'test_native_transport.py'}
    current_paths = {str(path.relative_to(NATIVE)) for path in NATIVE.rglob('*')
                     if path.is_file() and not path.is_relative_to(PROOF)}
    require(current_paths == expected_paths, 'native path set drift')
    (PROOF / ('c6c-public-final.json' if sys.argv[1:] == ['--after'] else 'c6c-public-before.json')).write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps(dict(public_paths=len(result), private_paths_never_read=25, exact_additive_inventory=sys.argv[1:] == ['--after'])))


if __name__ == '__main__':
    main()

