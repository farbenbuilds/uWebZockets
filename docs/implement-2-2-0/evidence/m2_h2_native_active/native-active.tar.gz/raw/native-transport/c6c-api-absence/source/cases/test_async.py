"""Delayed response without retained middleware."""
import test_ready


if __name__ == '__main__':
    test_ready.check('async_delayed')
