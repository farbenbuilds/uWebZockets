"""Public codec and raw ordered refund/reset accounting in one input."""
import h2_client
import hpack
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def frame(kind, stream, payload):
    return len(payload).to_bytes(3, 'big') + bytes((kind, 0)) + stream.to_bytes(4, 'big') + payload


def check():
    protocol = h2_client.new_protocol()
    protocol.data_to_send(amount=8192)
    response = response_credit.new_state()
    response_credit.settings_sent(response, 65535, initial=True)
    request = request_credit.new_state(request_credit.new_case('cancel_ready'))
    stage = output_stage.new_stage(output_stage.new_case('cancel_ready'), 1, 1, 10, 100)
    raw = raw_observer.new_state()
    records, trace = {}, {}
    wire.bind_connection(stage, protocol, raw, request, response, records)
    request_credit.client_settings_sent(request)
    payload = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                       ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    settings = frame(4, 0, payload)
    ack = b'\0\0\0\4\1\0\0\0\0'
    wire.accept(protocol, settings + ack, records, raw, trace, credit=response, request=request, stage=stage)
    protocol.data_to_send(amount=8192)
    protocol.send_headers(1, [(':method', 'POST'), (':scheme', 'https'),
                              (':authority', 'localhost'), (':path', '/upload/x')])
    request_credit.open_stream(request, 1)
    response_credit.open_stream(response, 1)
    output_stage.register(stage, 1, 'reset', primary=True)
    wire.register(records, raw, 1, 0, 200, 0, 'public_cancel', stage=stage, credit_policy='manual')
    wire.send_data(protocol, records, request, 1, b'abcdefgh', stage=stage, end_stream=False, pad_length=None)
    protocol.data_to_send(amount=8192)
    update = (4).to_bytes(4, 'big')
    reset = (8).to_bytes(4, 'big')
    packet = frame(8, 0, update) + frame(8, 1, update) + frame(3, 1, reset) + frame(8, 1, update)
    for chunk in (packet[:11], packet[11:]):
        wire.accept(protocol, chunk, records, raw, trace, credit=response, request=request, stage=stage)
    if response['streams'][1]['terminal'] != 'incoming_reset':
        raise RuntimeError('response reset not paired')
    if request['connection_debt'] != 4 or request['streams'][1]['debt'] != 0:
        raise RuntimeError('refund accounting')
    wire.retire(records, raw, 1, request=request, credit=response, stage=stage)
    protocol = h2_client.new_protocol()
    protocol.data_to_send(amount=8192)
    response = response_credit.new_state()
    response_credit.settings_sent(response, 65535, initial=True)
    request = request_credit.new_state(request_credit.new_case('peer_reset'))
    stage = output_stage.new_stage(output_stage.new_case('peer_reset'), 1, 1, 10, 100)
    raw = raw_observer.new_state()
    records, trace = {}, {}
    wire.bind_connection(stage, protocol, raw, request, response, records)
    request_credit.client_settings_sent(request)
    wire.accept(protocol, settings + ack, records, raw, trace, credit=response, request=request, stage=stage)
    protocol.data_to_send(amount=8192)
    protocol.send_headers(1, [(':method', 'POST'), (':scheme', 'https'),
                              (':authority', 'localhost'), (':path', '/upload/x')])
    request_credit.open_stream(request, 1)
    response_credit.open_stream(response, 1)
    output_stage.register(stage, 1, 'reset', primary=True)
    wire.register(records, raw, 1, 0, 200, 0, 'peer_reset', stage=stage, credit_policy='manual')
    wire.send_data(protocol, records, request, 1, b'abcdefgh', stage=stage, end_stream=False, pad_length=None)
    protocol.data_to_send(amount=8192)
    wire.send_peer_reset(protocol, records, raw, request, response, 1, stage=stage)
    serialized = protocol.data_to_send(amount=8192)
    if serialized != frame(3, 1, reset) or response['streams'][1]['terminal'] != 'outgoing_reset':
        raise RuntimeError('outgoing reset differs')
    wire.accept(protocol, frame(8, 1, update), records, raw, trace, credit=response, request=request, stage=stage)
    if request['streams'][1]['debt'] != 4:
        raise RuntimeError('late peer reset refund')
    wire.retire(records, raw, 1, request=request, credit=response, stage=stage)
    protocol = h2_client.new_protocol()
    protocol.data_to_send(amount=8192)
    response = response_credit.new_state()
    response_credit.settings_sent(response, 65535, initial=True)
    request = request_credit.new_state(request_credit.new_case('continue_ready'))
    stage = output_stage.new_stage(output_stage.new_case('continue_ready'), 1, 1, 10, 100)
    raw = raw_observer.new_state()
    records, trace = {}, {}
    wire.bind_connection(stage, protocol, raw, request, response, records)
    request_credit.client_settings_sent(request)
    wire.accept(protocol, settings + ack, records, raw, trace, credit=response, request=request, stage=stage)
    protocol.data_to_send(amount=8192)
    protocol.send_headers(1, [(':method', 'POST'), (':scheme', 'https'),
                              (':authority', 'localhost'), (':path', '/upload/x'), ('expect', '100-continue')])
    request_credit.open_stream(request, 1)
    response_credit.open_stream(response, 1)
    output_stage.register(stage, 1, 'small', primary=True)
    wire.register(records, raw, 1, 0, 200, 1, 'healthy', stage=stage, credit_policy='manual')
    protocol.data_to_send(amount=8192)
    try:
        wire.send_data(protocol, records, request, 1, b'x', stage=stage, end_stream=False, pad_length=None)
    except ValueError as error:
        if str(error) != 'DATA before Continue or after terminal':
            raise
    else:
        raise RuntimeError('sent before Continue')
    if request['sent'] != 0 or protocol.data_to_send(amount=8192):
        raise RuntimeError('rejected action mutated state')
    block = hpack.Encoder().encode([(':status', '100')])
    info = len(block).to_bytes(3, 'big') + b'\x01\x04\0\0\0\x01' + block
    wire.accept(protocol, info, records, raw, trace, credit=response, request=request, stage=stage)
    wire.send_data(protocol, records, request, 1, b'x', stage=stage, end_stream=False, pad_length=None)
    if request['sent'] != 1 or not protocol.data_to_send(amount=8192):
        raise RuntimeError('Continue action missing')
    print('ordered codec reset/refund checks passed')


if __name__ == '__main__':
    check()
