"""Public codec grants follow the finite special-output schedules."""
import h2_client
import hpack
import model
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def frame(kind, flags, stream, payload):
    return len(payload).to_bytes(3, 'big') + bytes((kind, flags)) + stream.to_bytes(4, 'big') + payload


def check_case(case, sequence):
    protocol = h2_client.new_protocol()
    request = request_credit.new_state(request_credit.new_case(case))
    credit = response_credit.new_state()
    stage = output_stage.new_stage(output_stage.new_case(case), 1, 2, 10, 100)
    raw, records, trace = raw_observer.new_state(), {}, {}
    wire.bind_connection(stage, protocol, raw, request, credit, records)
    wire.startup(stage)
    pairs = ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1))
    payload = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in pairs)
    wire.accept(protocol, frame(4, 0, 0, payload) + frame(4, 1, 0, b''), records, raw, trace,
                credit=credit, request=request, stage=stage)
    wire.drain(stage)
    window = 33554432 if case == 'output_pressure_ready' else 0
    wire.update_settings(stage, window)
    wire.drain(stage)
    wire.accept(protocol, frame(4, 1, 0, b''), records, raw, trace, credit=credit, request=request, stage=stage)
    mode = 'hash_only'
    limit = 24593 if case == 'stream_file' else 16777313
    digest = ('8cacc49e5f9553369e25a67f4e0e9a799b38c07245a6da92a54ffb58c3ebc2ac'
              if case == 'stream_file' else model.PRODUCER_HASH)
    stream, chunks = wire.start_request(stage, 'POST', 'localhost', '/limit/' + case, (), True,
                                        role='special', primary=True, held=case != 'output_pressure_ready', body_limit=limit,
                                        final_status=200, info_count=0, policy='healthy', mode=mode,
                                        expected_sha256=digest, middleware_policy='required')
    if case != 'output_pressure_ready':
        if not stage['active'][stream]['held']:
            raise RuntimeError('missing initial output hold')
        try:
            output_stage.frame(stage, 0, 1, 5, stream, False)
        except ValueError as error:
            if str(error) != 'invalid terminal':
                raise
        else:
            raise RuntimeError('special END before grant accepted')
        try:
            output_stage.resume(stage, stream)
        except ValueError as error:
            if str(error) != 'invalid resume':
                raise
        else:
            raise RuntimeError('manual special output resume accepted')
    grants = wire.new_grants(stage)
    wire.grant(protocol, credit, grants, stage, 0, 33554432 - credit['connection'], 'bootstrap')
    wire.drain(stage)
    for index, amount in enumerate(sequence):
        wire.grant(protocol, credit, grants, stage, stream, amount, 'special')
        if stage['active'][stream]['held'] != (index + 1 < len(sequence)):
            raise RuntimeError('special output hold differs')
        wire.drain(stage)
        if case == 'output_pressure_window' and index == 0:
            block = hpack.Encoder().encode([(':status', '200'), ('x-middleware', 'retained')])
            wire.accept(protocol, frame(1, 4, stream, block), records, raw, trace,
                        credit=credit, request=request, stage=stage)
            data = frame(0, 0, stream, bytes(8192))
            for part in (data[:8192], data[8192:]):
                wire.accept(protocol, part, records, raw, trace, credit=credit, request=request, stage=stage)
            if credit['streams'][stream]['flow_bytes'] != 8192 or records[stream]['body']:
                raise RuntimeError('special prefix accounting differs')
    try:
        wire.grant(protocol, credit, grants, stage, stream, 1, 'special')
    except ValueError as error:
        if str(error) != 'invalid special grant':
            raise
    else:
        raise RuntimeError('extra special grant accepted')
    if not chunks or credit['stream_granted'] != sum(sequence):
        raise RuntimeError('special grant total differs')


def check():
    check_case('producer_reuse', (16777313,))
    check_case('output_pressure_window', (8192, 16769121))
    check_case('output_pressure_ready', ())
    check_case('stream_file', (24593,))
    print('special output grant schedules passed')


if __name__ == '__main__':
    check()
