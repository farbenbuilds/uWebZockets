"""The staged small-response bound is independent of response storage mode."""
import hashlib
import h2_client
import hpack
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def frame(kind, flags, stream, payload):
    return len(payload).to_bytes(3, 'big') + bytes((kind, flags)) + stream.to_bytes(4, 'big') + payload


def check():
    protocol = h2_client.new_protocol()
    request = request_credit.new_state(request_credit.new_case('ready_buffered'))
    credit = response_credit.new_state()
    stage = output_stage.new_stage(output_stage.new_case('ready_buffered'), 1, 1, 10, 100)
    raw, records, trace = raw_observer.new_state(), {}, {}
    wire.bind_connection(stage, protocol, raw, request, credit, records)
    wire.startup(stage)
    pairs = ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1))
    payload = b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in pairs)
    ack = frame(4, 1, 0, b'')
    wire.accept(protocol, frame(4, 0, 0, payload) + ack, records, raw, trace,
                credit=credit, request=request, stage=stage)
    if wire.drain(stage) != ack:
        raise RuntimeError('initial acknowledgement differs')
    before = (request['high_water'], request['sent'], request['connection_debt'],
              credit['high_water'], credit['connection'], raw['high_water'], bytes(raw['header']),
              stage['high_water'], stage['case_state']['heads'], stage['case_state']['small'],
              stage['case_state']['bytes'], stage['case_state']['reads'], dict(trace))
    digest = hashlib.sha256(bytes(4096)).hexdigest()
    args = ('GET', 'localhost', '/health', (), True)
    options = dict(role='small', primary=True, held=False, body_limit=4096, final_status=200,
                   info_count=0, policy='healthy', mode='hash_only', expected_sha256=digest,
                   middleware_policy='required')
    try:
        wire.start_request(stage, *args, **options)
    except ValueError as error:
        if str(error) != 'small response bound':
            raise
    else:
        raise RuntimeError('4096-byte hash-only small response accepted')
    after = (request['high_water'], request['sent'], request['connection_debt'],
             credit['high_water'], credit['connection'], raw['high_water'], bytes(raw['header']),
             stage['high_water'], stage['case_state']['heads'], stage['case_state']['small'],
             stage['case_state']['bytes'], stage['case_state']['reads'], dict(trace))
    if (before != after or protocol.get_next_available_stream_id() != 1 or wire.drain(stage) or request['streams'] or
            credit['streams'] or raw['streams'] or records or stage['active'] or stage['high_water'] != 0 or
            stage['case_state']['heads'] != 0 or stage['case_state']['small'] != 0 or stage['failed']):
        raise RuntimeError('rejected request mutated codec or registration state')
    body = bytes(4095)
    options['body_limit'] = len(body)
    options['expected_sha256'] = hashlib.sha256(body).hexdigest()
    stream, chunks = wire.start_request(stage, *args, **options)
    if stream != 1 or not chunks:
        raise RuntimeError('valid small request did not serialize')
    block = hpack.Encoder().encode([(':status', '200'), ('x-middleware', 'retained')])
    packet = frame(1, 4, stream, block) + frame(0, 1, stream, body)
    wire.accept(protocol, packet, records, raw, trace, credit=credit, request=request, stage=stage)
    if records[stream]['bytes'] != len(body) or records[stream]['body']:
        raise RuntimeError('hash-only small response differs')
    wire.retire(records, raw, stream, request=request, credit=credit, stage=stage)
    if records or raw['streams'] or request['streams'] or credit['streams'] or stage['active']:
        raise RuntimeError('paired retirement left stream state')
    print('small response role bound checks passed')


if __name__ == '__main__':
    check()
