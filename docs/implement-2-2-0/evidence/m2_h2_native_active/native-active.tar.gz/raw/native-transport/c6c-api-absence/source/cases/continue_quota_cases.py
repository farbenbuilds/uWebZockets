"""Continue, admission quota and failed-begin recovery schedules."""
import json
import adapter
import model
import output_stage
import pause_cases


def start(context, tag, primary=False, *, expect=False, refusal=False, held=False):
    contract = model.request_contract(tag)
    headers = [('content-length', str(contract['declared']))]
    if expect:
        headers.append(('expect', '100-continue'))
    return adapter.start(context, contract['method'], contract['target'], headers, False, primary,
                         0 if refusal else 4095, held=held, status=503 if refusal else 200,
                         policy='refusal_after_final' if refusal else 'healthy', info=int(expect and not refusal))


def wait_continue(context, receive, stream):
    record = context['records'][stream]
    while record['informationals'] == 0:
        if record['headers'] is not None or record['ended'] or record['reset_event']:
            raise ValueError('final before Continue')
        adapter.tick(context)
        data, now = receive()
        adapter.observe(context, data, now)
    if record['informationals'] != 1 or record['headers'] is not None or record['ended'] or record['reset_event']:
        raise ValueError('invalid Continue barrier')


def complete(context, receive, stream, tag):
    result = json.loads(adapter.finish(context, stream, receive)['body'])
    model.validate_item(result, model.record(tag, True, 'after'))


def active(context, receive, finished, running, refused):
    value = adapter.metrics(context, receive)
    items = model.records(context['selected_before'], 'before')
    for tag in finished + running + refused:
        items[tag] = model.record(tag, True, 'after')
    for tag in running:
        items[tag].update(bytes=0, sha256=model.EMPTY_HASH, chunks=0, max_span=0, ends=0, active=True)
    for field in model.COMMON_COUNTERS + ('bytes',):
        if value[field] != sum(item[field] for item in items.values()):
            raise ValueError('quota metrics mismatch: ' + field)
    count = len(running)
    if (value['active'] != count or value['paused'] != 0 or
            int(value['slot0_active']) + int(value['slot1_active']) != count or
            value['buffered_middleware'] != context['stage']['case_state']['heads'] +
            sum(adapter.catalogue.case_budget(case)['heads'] for case in context['selected_before']) - value['middleware']):
        raise ValueError('quota active barrier differs')


def resume(context, receive, stream):
    control = adapter.start(context, 'GET', '/resume/continue_paused', (), True, False, 64)
    output_stage.resume(context['stage'], stream)
    if adapter.finish(context, control, receive)['body'] != b'ok':
        raise ValueError('admission resume differs')


def continuation(context, receive, case):
    stream = start(context, case, True, expect=True, held=case == 'continue_paused')
    wait_continue(context, receive, stream)
    adapter.send_data(context, stream, model.payload_span(32, 0, 32), True)
    if case == 'continue_paused':
        observed = pause_cases.status(context, receive, case)
        pause_cases.pending(context, stream)
        model.validate_checkpoint(case, observed, 'paused')
        resume(context, receive, stream)
    complete(context, receive, stream, case)


def quota(context, receive):
    holders = [start(context, tag, tag == 'quota_holder_two') for tag in ('quota_holder_one', 'quota_holder_two')]
    active(context, receive, (), ('quota_holder_one', 'quota_holder_two'), ())
    refused = start(context, 'quota_refuse', expect=True, refusal=True)
    adapter.finish(context, refused, receive, keep=True)
    for stream in holders:
        adapter.send_data(context, stream, model.payload_span(32, 0, 32), True)
    for stream, tag in zip(holders, ('quota_holder_one', 'quota_holder_two')):
        complete(context, receive, stream, tag)
    active(context, receive, ('quota_holder_one', 'quota_holder_two'), (), ('quota_refuse',))
    recoveries = [start(context, tag) for tag in ('quota_recovery_one', 'quota_recovery_two')]
    active(context, receive, ('quota_holder_one', 'quota_holder_two'), ('quota_recovery_one', 'quota_recovery_two'), ('quota_refuse',))
    for stream in recoveries:
        adapter.send_data(context, stream, model.payload_span(32, 0, 32), True)
    for stream, tag in zip(recoveries, ('quota_recovery_one', 'quota_recovery_two')):
        complete(context, receive, stream, tag)
    active(context, receive, ('quota_holder_one', 'quota_holder_two', 'quota_recovery_one', 'quota_recovery_two'), (), ('quota_refuse',))
    adapter.retire(context, refused)


def failure(context, receive):
    refused = start(context, 'begin_failure', True, expect=True, refusal=True)
    adapter.finish(context, refused, receive, keep=True)
    recovery = start(context, 'begin_recovery')
    adapter.send_data(context, recovery, model.payload_span(32, 0, 32), True)
    complete(context, receive, recovery, 'begin_recovery')
    adapter.retire(context, refused)


def run(context, receive):
    case = context['stage']['case']
    adapter.health(context, receive)
    if case.startswith('continue_'):
        continuation(context, receive, case)
    elif case == 'quota_refuse':
        quota(context, receive)
    elif case == 'begin_failure_rollback':
        failure(context, receive)
    else:
        raise ValueError('unsupported schedule')
    adapter.health(context, receive)


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned hooks')
