"""Serialized terminal driver using the shared independent peer."""
import hashlib
import adapter
import model
from test_core_peer import new_app, require
from test_terminal_peer import new_peer


def retained_control(original, context, method, path, state, args, kwargs):
    """Snapshot before the first serialized stale control; original errors win."""
    original_send = context['send']
    snapshot = {}

    def send(data):
        if state['stale'] == 0:
            outgoing = context['request']['streams'][5]
            snapshot.update(retained=tuple(5 in mapping for mapping in
                            (context['records'], context['raw']['streams'], context['stage']['active'], context['credit']['streams'])),
                            terminal=(outgoing['retired'], outgoing['reset'], outgoing['response_end']))
        return original_send(data)

    context['send'] = send
    try:
        result = original(context, method, path, *args, **kwargs)
    finally:
        context['send'] = original_send
    require(snapshot.get('retained') == (False, False, False, False) and
            snapshot.get('terminal') == (True, True, True), 'paired primary retirement differs')
    return result


def run_with_retention(context, receive, state):
    original_start, original_data = adapter.start, adapter.send_data

    def start(current, method, path, *args, **kwargs):
        if current is context and state['stale'] == 0 and path == '/control/resume/' + state['case']:
            return retained_control(original_start, current, method, path, state, args, kwargs)
        return original_start(current, method, path, *args, **kwargs)

    def send_data(current, stream, data, end_stream, *, padding=None):
        result = original_data(current, stream, data, end_stream, padding=padding)
        if current is context and stream == 3:
            require(current['request']['connection_debt'] == 1, 'sibling DATA before stale and actual refund barrier')
        return result

    adapter.start, adapter.send_data = start, send_data
    try:
        result = adapter.run_case(context, receive)
    finally:
        adapter.start, adapter.send_data = original_start, original_data
    return result


def check(case, *, app=None, prior=(), final=False, fault=None):
    app = new_app() if app is None else app
    caller_time = [1]

    def clock():
        caller_time[0] += 1
        return caller_time[0]

    peer = new_peer(case, app=app, prior=prior, now=1, clock=clock, final=final, fault=fault)
    connection, state = peer['connection'], peer['state']
    primary_length = state['primary_length']
    context = adapter.open_case(case, connection['protocol'], connection['send'], 1, 30001, 900001,
                                selected_before=prior, clock=clock)
    require(context['stage']['primary'] == 5, 'primary binding differs')
    adapter.observe(context, *connection['receive']())
    run_with_retention(context, connection['receive'], state)
    budget = (12, 11, 40) if case == 'cancel_ready' else (12, 11, 65) if case == 'cancel_paused' else (11, 10, 65)
    actual = (state['heads'], context['stage']['case_state']['small'], context['request']['case']['sent'])
    if actual != budget or state['heads'] != state['ordinary'] or state['settings'] != 1 or state['resets'] != 1 or state['pending'] or state['buffer']:
        raise RuntimeError('exact J C R settings reset or pending count differs')
    for stream, item in state['payloads'].items():
        tag = state['streams'][stream]
        length = 1 if tag == 'sibling' else primary_length if tag == case else 32
        payload = b's' if tag == 'sibling' else model.payload_span(32, 0, length)
        if item['frames'] != 1 or item['count'] != length or item['digest'].hexdigest() != hashlib.sha256(payload).hexdigest():
            raise RuntimeError('final upload count or hash differs')
    require(state['complete'] and state['stale_delivered'] == 4 and state['refunded'] and
            state['refund_bytes'] == state['primary_length'] and
            state['resets_delivered'] == int(case != 'peer_reset') and
            state['outgoing_resets'] == int(case == 'peer_reset') and not state['delivered_buffer'],
            'terminal delivery receipts differ')
    selection = prior + (case,)
    if final:
        adapter.final_collection(context, connection['receive'])
        if state['heads'] != state['head_limit'] or state['final_requests'] != 68 or state['pending'] or state['buffer']:
            raise RuntimeError('shared final collection differs')
    model.validate_records(selection, 'before', app['records'])
    print(case + ' passed: J=%d C=%d R=%d' % actual)
    return app


def rejected(case, fault, message, *, final=False):
    try:
        check(case, fault=fault, final=final)
    except (ValueError, RuntimeError) as exc:
        if str(exc) != message:
            raise RuntimeError('control rejected for wrong reason: ' + fault) from exc
        print(fault + ' rejected: ' + str(exc))
        return
    raise RuntimeError('control accepted: ' + fault)


def main():
    app = None
    prior = ()
    for case in ('cancel_ready', 'cancel_paused', 'peer_reset'):
        app = check(case, app=app, prior=prior, final=case == 'peer_reset')
        prior += (case,)
    check('cancel_ready', fault='split_reset')
    for case in ('cancel_ready', 'cancel_paused', 'peer_reset'):
        for fault, message in (('preterminal_bytes', 'record mismatch: bytes'), ('preterminal_pause', 'record mismatch: paused'),
                               ('terminal_reason', 'record mismatch: reason'), ('terminal_metadata', 'record mismatch: metadata_begin'),
                               ('stale_reply', 'control result differs'), ('missing_refund', 'missing finite synthetic response'),
                               ('excess_refund', 'invalid connection refund'), ('sibling_echo', 'sibling echo differs'),
                               ('recovery_record', 'record mismatch: metadata_end'), ('stale_counter', 'record mismatch: stale_resume'),
                               ('early_final', 'upload completed before resume'), ('primary_final', 'invalid terminal' if case == 'peer_reset' else 'unexpected final')):
            rejected(case, fault, message, final=fault == 'stale_counter')
        rejected(case, 'other_record', 'record mismatch: middleware', final=True)
    rejected('peer_reset', 'preterminal_chunks', 'record mismatch: chunks')
    for fault, message in (('reset_code', 'wrong reset code'), ('duplicate_reset', 'invalid reset'),
                           ('missing_reset', 'missing finite synthetic response')):
        rejected('cancel_ready', fault, message)


if __name__ == '__main__':
    main()
