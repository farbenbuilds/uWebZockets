"""Pure encoded hyper-h2 regression for retained informational limits."""

import copy
import hashlib
import json

import h2.config
import h2.connection

import h2_client as client


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def peer_pair():
    protocol = client.new_protocol()
    server = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False))
    server.initiate_connection()
    responses, trace = {}, client.new_trace()
    server.receive_data(protocol.data_to_send())
    client.accept_bytes(protocol, server.data_to_send(), responses, trace)
    stream_id = client.start_request(protocol, responses, "localhost", "/info-budget")
    server.receive_data(protocol.data_to_send())
    return protocol, server, responses, trace, stream_id


def send_info(pair, headers):
    protocol, server, responses, trace, stream_id = pair
    server.send_headers(stream_id, headers)
    wire = server.data_to_send()
    for offset in range(0, len(wire), 3):
        client.accept_bytes(protocol, wire[offset:offset + 3], responses, trace)


def retained_bytes(record):
    return sum(32 + len(name.encode("utf-8")) + len(value.encode("utf-8"))
               for headers in record["informational"] for name, value in headers)


def refuse_unchanged(pair, headers, diagnostic):
    record = pair[2][pair[4]]
    before = client.response_summary(record)
    before = copy.deepcopy(before)
    before_bytes = retained_bytes(record)
    try:
        send_info(pair, headers)
    except RuntimeError as error:
        check(str(error) == diagnostic, "unstable rejection diagnostic: " + str(error))
    else:
        raise AssertionError("over-budget informational response retained: count=" +
                             str(len(record["informational"])) + ", bytes=" + str(retained_bytes(record)))
    check(client.response_summary(record) == before, "rejection changed retained response summary")
    check(retained_bytes(record) == before_bytes, "rejection changed retained field bytes")
    return {"retained_count": len(record["informational"]), "retained_bytes": before_bytes,
            "diagnostic": diagnostic}


def count_boundary():
    pair = peer_pair()
    for _ in range(16):
        send_info(pair, [(":status", "100")])
    record = pair[2][pair[4]]
    check(len(record["informational"]) == 16 and retained_bytes(record) == 672,
          "sixteen ordinary informational responses not retained")
    return refuse_unchanged(pair, [(":status", "100")], "informational response count limit exceeded")


def byte_over_boundary():
    pair = peer_pair()
    send_info(pair, [(":status", "100")])
    return refuse_unchanged(pair, [(":status", "103"), ("x", "a" * 16268)],
                            "informational response header budget exceeded")


def byte_boundary_and_final():
    pair = peer_pair()
    send_info(pair, [(":status", "100")])
    # The non-ASCII value proves accounting uses UTF-8 bytes, not character count.
    send_info(pair, [(":status", "103"), ("x", "é" * 8133 + "a")])
    protocol, server, responses, trace, stream_id = pair
    record = responses[stream_id]
    check(len(record["informational"]) == 2 and retained_bytes(record) == 16384,
          "exact aggregate byte budget not accepted")
    refusal = refuse_unchanged(pair, [(":status", "103"), ("x", "")],
                               "informational response header budget exceeded")
    server.send_headers(stream_id, [(":status", "200"), ("content-length", "4")])
    server.send_data(stream_id, b"body", pad_length=3)
    server.send_headers(stream_id, [("x-trailer", "kept")], end_stream=True)
    client.accept_bytes(protocol, server.data_to_send(), responses, trace)
    summary = client.response_summary(record)
    check(summary["ended"] and summary["reset"] is None and summary["bytes"] == 4,
          "normal final response unusable after informational boundary")
    check(summary["sha256"] == hashlib.sha256(b"body").hexdigest() and
          summary["trailers"] == [("x-trailer", "kept")] and trace["received_flow_bytes"] == 8,
          "body/trailer/padding behavior changed")
    return refusal


def entry_overhead():
    pair = peer_pair()
    send_info(pair, [(":status", "100")])
    return refuse_unchanged(pair, [(":status", "103")] + [("x", "")] * 494,
                            "informational response header budget exceeded")


def main():
    results, failures = {}, []
    for test in (count_boundary, byte_over_boundary, byte_boundary_and_final, entry_overhead):
        try:
            results[test.__name__] = test()
        except (AssertionError, RuntimeError) as error:
            failures.append({"test": test.__name__, "failure": str(error)})
    print(json.dumps({"scope": "Pure encoded hyper-h2 pair only; no sockets or uWebZockets",
                      "fragment_bytes": 3, "passed": results, "failures": failures}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
