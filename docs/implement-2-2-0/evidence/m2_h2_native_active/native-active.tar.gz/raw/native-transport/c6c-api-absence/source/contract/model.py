"""Pure proposed combined record boundary; no fixture or protocol execution."""
import hashlib
from types import MappingProxyType
import catalogue

U64 = (1 << 64) - 1
SENTINEL = b'final-upload-sentinel!'
EMPTY_HASH = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
H32 = '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5'
H7 = '32bbe378a25091502b2baf9f7258c19444e7a43ee4593b08030acd790bd66e6a'
LARGE_HASH = '190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2'
MAX_PAYLOAD = 100000000
EARLY_RESPONSE = MappingProxyType(dict(bytes=17,sha256='d826bcf95ee8850cecb39accdeb84b32336a0415411938da42da7edcac891da7',end=True,reset=True))
PRODUCER_HASH = 'e5b7e8c5bbad59c7bc86f18236a37661571e972f65c707d7dc1902386ec5e91d'
COMMON_COUNTERS = ('middleware','attempts','begins','ends','cancels','failures','end_errors','chunk_errors','invalid_progress','errors')
COMMON_RECORD = COMMON_COUNTERS + ('tag','bytes','sha256','chunks','max_span','active','paused','reason')
PAUSE_EVIDENCE = ('callback_checks','terminal_checks')
CREDIT_EVIDENCE = ('metadata_begin','metadata_end')
METADATA_EVIDENCE = ('metadata_middleware','helpers_begin','helpers_end','metadata_begin','metadata_end')
CONTROL_EVIDENCE = ('metadata_middleware','metadata_begin','metadata_end','stale_resume','stale_cancel')
FAMILY_EVIDENCE = MappingProxyType(dict(core=(),pause=PAUSE_EVIDENCE,admission=(),credit=CREDIT_EVIDENCE,metadata=METADATA_EVIDENCE,cancellation=CONTROL_EVIDENCE,application=CONTROL_EVIDENCE,lifecycle=CONTROL_EVIDENCE,output=CONTROL_EVIDENCE))
# The independent body inventory encodes accepted length and terminal semantics.
BODY_SPECS = (
    ('large_declared','core',100000000,'complete'),('large_undeclared','core',100000000,'complete'),
    ('partial_pause','pause',12289,'complete'),('final_pause','pause',32,'complete'),('begin_pause_empty','pause',0,'complete'),('control_one','pause',32,'complete'),('control_two','pause',32,'complete'),
    ('empty_headers','admission',0,'complete'),('empty_data','admission',0,'complete'),('empty_declared','admission',0,'complete'),('limit_declared','admission',32,'complete'),('limit_undeclared','admission',32,'complete'),
    ('limit_declared_reject','admission',0,'refused'),('limit_declared_recovery','admission',32,'complete'),('limit_observed_reject','admission',32,'body_too_large'),('limit_observed_recovery','admission',32,'complete'),
    ('zero_declared_reject','admission',0,'refused'),('zero_declared_recovery','admission',0,'complete'),('zero_observed_reject','admission',0,'body_too_large'),('zero_observed_recovery','admission',0,'complete'),
    ('continue_ready','admission',32,'complete'),('continue_paused','admission',32,'complete'),('quota_holder_one','admission',32,'complete'),('quota_holder_two','admission',32,'complete'),('quota_refuse','admission',0,'refused'),('quota_recovery_one','admission',32,'complete'),('quota_recovery_two','admission',32,'complete'),('begin_failure','admission',0,'failed_begin'),('begin_recovery','admission',32,'complete'),
    ('queued_trailers_padding','credit',12289,'complete'),('receive_credit','credit',65536,'complete'),('concurrent_hold','credit',32,'complete'),('concurrent_refused','credit',0,'refused'),('concurrent_upload','credit',32,'complete'),('concurrent_recovery','credit',32,'complete'),
    ('metadata_helpers','metadata',32,'complete'),
    ('cancel_ready','cancellation',7,'cancelled'),('cancel_ready_recovery','cancellation',32,'complete'),('cancel_paused','cancellation',7,'cancelled'),('cancel_paused_recovery','cancellation',32,'complete'),('peer_reset','cancellation',0,'reset'),('peer_reset_recovery','cancellation',32,'complete'),
    ('sink_error','application',7,'sink_failure'),('sink_error_recovery','application',32,'complete'),('invalid_progress','application',7,'sink_failure'),('invalid_progress_recovery','application',32,'complete'),('end_error','application',32,'end_failure'),('end_error_recovery','application',32,'complete'),
    ('disconnect','lifecycle',7,'peer_closed'),('disconnect_recovery','lifecycle',32,'complete'),
) + tuple(('reuse_' + str(n),'lifecycle',32,'complete') for n in range(9)) + (
    ('shutdown_active','lifecycle',7,'shutdown'),('producer_reuse','output',32,'complete'),('producer_reuse_next','output',32,'complete'),('output_pressure_window','output',32,'complete'),('output_pressure_ready','output',32,'complete'),('stream_file','output',32,'complete'),('early_final_order','output',0,'refused'),('early_final_recovery','output',32,'complete'),
)
SPECS = MappingProxyType({row[0]: row[1:] for row in BODY_SPECS})
LEGACY_NAMES = MappingProxyType(dict(accepted='bytes',begin='begins',end='ends',cancel='cancels',failure='failures'))
LEGACY_BASE = ('tag','middleware','attempts','begin','end','cancel','failure','accepted','sha256','active','paused','reason','errors','chunks','max_span')
LEGACY_SCHEMAS = MappingProxyType(dict(
    core=('tag','accepted','sha256','begin','end','cancel','max_span'),
    pause=('tag','accepted','sha256','attempts','begin','end','cancel','chunks','max_span','active','paused','callback_checks','terminal_checks','errors'),
    admission=LEGACY_BASE, credit=LEGACY_BASE+CREDIT_EVIDENCE, metadata=LEGACY_BASE+METADATA_EVIDENCE,
    cancellation=LEGACY_BASE+('end_errors',)+CONTROL_EVIDENCE,
    application=LEGACY_BASE+('end_errors','chunk_errors','invalid_progress')+CONTROL_EVIDENCE,
    lifecycle=LEGACY_BASE+('end_errors','chunk_errors','invalid_progress')+CONTROL_EVIDENCE,
    output=LEGACY_BASE+('end_errors','chunk_errors','invalid_progress')+CONTROL_EVIDENCE))
PRODUCER_NUMBERS = ('offset','invocations','attempts','writes','blocked','pending','terminal_attempts','terminals','checks','after_reuse','errors','binding_index','binding_generation')
FILE_NUMBERS = ('reads','requested','returned','read_errors','close_calls','closed_files','invalid_spans','min_offset','max_end','arms','arm_errors')
PRODUCERS = ('producer_reuse','output_pressure_window','output_pressure_ready')


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def unsigned(value: int) -> int:
    require(type(value) is int and 0 <= value <= U64, 'u64 required')
    return value


def payload_span(total: int, offset: int, length: int) -> bytes:
    for value in (total,offset,length):
        unsigned(value)
    require(len(SENTINEL) <= total <= MAX_PAYLOAD and length <= 8192 and offset <= total and length <= total-offset, 'payload bounds')
    pattern = bytes(range(1,252))
    start = offset % 251
    block = bytearray((pattern*((start+length+250)//251))[start:start+length])
    marker = max(offset,total-len(SENTINEL))
    if marker < offset+length:
        block[marker-offset:] = SENTINEL[marker-(total-len(SENTINEL)):offset+length-(total-len(SENTINEL))]
    return bytes(block)


def digest(total: int, offset: int, length: int) -> str:
    for value in (total,offset,length):
        unsigned(value)
    require(len(SENTINEL) <= total <= MAX_PAYLOAD and offset <= total and length <= total-offset, 'digest bounds')
    value = hashlib.sha256()
    end = offset+length
    while offset < end:
        count = min(8192,end-offset)
        value.update(payload_span(total,offset,count))
        offset += count
    return value.hexdigest()


def accepted_hash(length: int) -> str:
    unsigned(length)
    if not length:
        return EMPTY_HASH
    if length == 7:
        return H7
    if length == 32:
        return H32
    if length == 100000000:
        return LARGE_HASH
    return digest(length,0,length)


def record(tag: str, touched: bool, phase: str) -> dict:
    require(type(tag) is str and tag in SPECS and type(touched) is bool and type(phase) is str and phase in ('before','after'), 'record inputs')
    family, length, terminal = SPECS[tag]
    item = dict.fromkeys(COMMON_COUNTERS + FAMILY_EVIDENCE[family],0)
    item.update(tag=tag,bytes=0,sha256=EMPTY_HASH,chunks=0,max_span=0,active=False,paused=False,reason=None)
    if not touched:
        return item
    attempted = terminal != 'refused'
    began = attempted and terminal != 'failed_begin'
    ended = terminal in ('complete','end_failure')
    active = tag == 'shutdown_active' and phase == 'before'
    cancelled = began and not ended and not active
    item.update(middleware=1,attempts=int(attempted),begins=int(began),ends=int(ended),cancels=int(cancelled),failures=int(terminal=='failed_begin'),end_errors=int(terminal=='end_failure'),chunk_errors=int(tag=='sink_error'),invalid_progress=int(tag=='invalid_progress'),bytes=length,sha256=accepted_hash(length),chunks=None if length else 0,max_span=None if length else 0,active=active,paused=active,reason=terminal if cancelled else None)
    for field in FAMILY_EVIDENCE[family]:
        if field in ('metadata_middleware',):
            item[field] = 1
        elif field in ('metadata_begin','helpers_begin'):
            item[field] = int(began)
        elif field in ('metadata_end','helpers_end'):
            item[field] = int(ended)
        elif field.startswith('stale_'):
            item[field] = 8-int(tag[-1]) if tag.startswith('reuse_') else 2 if terminal in ('cancelled','reset','sink_failure','end_failure','peer_closed') else 0
        elif field == 'callback_checks':
            item[field] = None if length else 2*int(began)
        elif field == 'terminal_checks':
            item[field] = 2*int(ended)
    return item


def records(selection: tuple | list, phase: str) -> dict:
    catalogue.schedule(selection)
    require(type(phase) is str and phase in ('before','after'), 'invalid phase')
    touched = {tag for case in selection for tag in catalogue.TAGS[case]}
    return {tag:record(tag,tag in touched,phase) for tag in SPECS}


def totals(items: dict) -> tuple:
    require(type(items) is dict, 'record mapping required')
    fields = ('middleware','attempts','begins','ends','cancels','bytes','active')
    result = []
    for field in fields:
        total = 0
        for item in items.values():
            value = int(item[field]) if field=='active' and type(item[field]) is bool else item[field]
            total = catalogue.add_u64(total,unsigned(value))
        result.append(total)
    return tuple(result)


def validate_item(actual: dict, expected: dict) -> None:
    require(type(actual) is dict and actual.keys()==expected.keys(), 'record schema')
    for key, value in expected.items():
        if value is not None or key not in ('chunks','max_span','callback_checks'):
            require(type(actual[key]) is type(value) and actual[key]==value, 'record mismatch: '+key)
    if 'chunks' in actual:
        chunks, span = unsigned(actual['chunks']), unsigned(actual['max_span'])
        family = SPECS[actual['tag']][0]
        require(span <= 8192, 'callback span')
        if family in ('admission','output'):
            require(span <= actual['bytes'], 'family callback span')
        if actual['bytes']:
            require(chunks>0 and span>0 and chunks<=catalogue.add_u64(actual['bytes'],actual.get('chunk_errors',0)+actual.get('invalid_progress',0)) and actual['bytes']<=catalogue.mul_u64(chunks,span), 'bounded callback observations')
            if actual.get('chunk_errors',0) or actual.get('invalid_progress',0):
                require(chunks>=2, 'failure callback follows accepted prefix')
        else:
            require(chunks==0 and span==0, 'empty callbacks')
        if 'callback_checks' in actual:
            require(unsigned(actual['callback_checks'])==2*(actual['begins']+chunks), 'pause callback checks')
    elif 'max_span' in actual:
        require(type(actual['max_span']) is int and (0<actual['max_span']<=8192 if actual['bytes'] else actual['max_span']==0), 'core span')


def validate_records(selection: tuple | list, phase: str, actual: dict) -> None:
    expected = records(selection,phase)
    require(type(actual) is dict and actual.keys()==expected.keys(), 'record identities')
    for tag, target in expected.items():
        validate_item(actual[tag],target)


def normalize_legacy(family: str, raw: dict) -> dict:
    require(type(family) is str and family in LEGACY_SCHEMAS, 'legacy family')
    require(type(raw) is dict and raw.keys()==set(LEGACY_SCHEMAS[family]), 'legacy schema')
    for key,value in raw.items():
        if key in ('active','paused'):
            require(type(value) is bool, 'legacy boolean')
        elif key in ('tag','reason','sha256'):
            require(type(value) is str, 'legacy string')
        else:
            unsigned(value)
    result = {LEGACY_NAMES.get(key,key):value for key,value in raw.items()}
    if result.get('reason') == 'none':
        result['reason'] = None
    return result


def validate_legacy(selection: tuple | list, phase: str, family: str, raw: dict) -> None:
    actual = normalize_legacy(family,raw)
    tag = actual['tag']
    require(type(tag) is str and tag in SPECS and SPECS[tag][0]==family, 'legacy tag family')
    target = records(selection,phase)[tag]
    validate_item(actual,{key:target[key] for key in actual})


def request_contract(tag: str) -> dict:
    require(type(tag) is str and tag in SPECS, 'unknown body tag')
    family, length, terminal = SPECS[tag]
    route = 'upload' if family in ('core','pause') or tag.startswith('quota_') or tag in ('queued_trailers_padding','receive_credit','concurrent_upload') else 'empty' if tag.startswith(('empty_','zero_')) else 'limit'
    declared = 32 if family in ('cancellation','application','lifecycle','output','metadata') or tag in ('limit_declared','limit_declared_recovery','limit_observed_recovery','begin_failure','begin_recovery','continue_ready','continue_paused') or tag.startswith('quota_holder') or tag.startswith('quota_recovery') else None
    if family == 'credit':
        declared = 1 if tag=='concurrent_refused' else length
    declared = {'large_declared':100000000,'limit_declared_reject':33,'zero_declared_reject':1,'empty_declared':0,'quota_refuse':1}.get(tag,declared)
    result = dict(method='POST',path='/'+route+'/'+tag,query='',tag=tag,declared=declared,headers=None,captures=1,protocol='')
    if family in ('cancellation','application','lifecycle','output'):
        result['query'] = 'case='+tag
        result['x-case'] = tag
    if family == 'credit':
        query, metadata, initial = {'queued_trailers_padding':('case=qtp','initial-qtp','initial-only'),'concurrent_hold':('case=hold','hold-metadata',None),'concurrent_upload':('case=upload','upload-metadata',None)}.get(tag,('',None,None))
        result.update(query=query,metadata=metadata,initial_only=initial,trailer_only=None)
    if tag == 'metadata_helpers':
        result.update(path='/meta/metadata_helpers/'+ '/'.join('a%02d'%n for n in range(1,17)),query='q=alpha&n=17',headers=66,captures=17,body_helpers=('json','validate_json','validate_json_detailed','form','multipart'),helper_error='BodyNotBuffered',text=b'',bytes=b'',issue=('untouched','too_deep','same_pointer','same_length'),allocator_used=0,trailer_only=None,query_values=(('q','alpha'),('n','17')))
    if tag == 'metadata_helpers':
        result['header_entries'] = (('content-length','32'),('x-mode','begin_paused'))+tuple(('x-h%02d'%n,'v%02d'%n) for n in range(63))+(('host','localhost'),)
        result['capture_entries'] = (('tag',tag),)+tuple(('p%02d'%n,'a%02d'%n) for n in range(1,17))
        result['header_storage'] = (64,2)
        result['capture_storage'] = (16,1)
        result['missing_capture'] = 'P16'
    result['target'] = result['path'] + ('?'+result['query'] if result['query'] else '')
    return result


def checkpoint(tag: str, stage: str) -> dict:
    require(type(tag) is str and tag in SPECS, 'checkpoint tag')
    case = next(case for case in catalogue.CASES if tag in catalogue.TAGS[case])
    item = records((case,),'after')[tag]
    if stage == 'complete':
        return item
    paused_bytes = {'partial_pause':7,'final_pause':32,'begin_pause_empty':0,'queued_trailers_padding':7,'receive_credit':0,'concurrent_hold':0,'metadata_helpers':0,'continue_paused':0,'cancel_paused':7,'peer_reset':0,'shutdown_active':7}
    require(stage=='paused' and tag in paused_bytes, 'unsupported checkpoint')
    length = paused_bytes[tag]
    item.update(bytes=length,sha256=accepted_hash(length),chunks=None if length else 0,max_span=None if length else 0,ends=0,cancels=0,active=True,paused=True,reason=None)
    for field in ('metadata_end','helpers_end','terminal_checks','stale_resume','stale_cancel'):
        if field in item:
            item[field] = 0
    if 'callback_checks' in item:
        item['callback_checks'] = None if length else 2
    return item


def validate_checkpoint(tag: str, actual: dict, stage: str) -> None:
    validate_item(actual,checkpoint(tag,stage))


def diagnostic_schema(item: dict, numbers: tuple, booleans: tuple, strings: tuple) -> None:
    require(type(item) is dict and item.keys()==set(numbers+booleans+strings), 'diagnostic schema')
    for key in numbers:
        unsigned(item[key])
    for key in booleans:
        require(type(item[key]) is bool, 'diagnostic boolean')
    for key in strings:
        require(type(item[key]) is str, 'diagnostic string')


def validate_producer(item: dict, offset: int, *, held: bool=False, after_reuse: bool=False) -> None:
    diagnostic_schema(item,PRODUCER_NUMBERS,('armed','done'),('tag','sha256'))
    require(type(offset) is int and offset in (0,8192,16777313) and type(held) is bool and type(after_reuse) is bool, 'producer checkpoint')
    require(item['tag'] in PRODUCERS and item['armed'] and item['offset']==offset and item['sha256']==(PRODUCER_HASH if offset==16777313 else digest(16777313,0,offset)), 'producer identity')
    require(item['errors']==0 and item['checks']==item['invocations'] and item['blocked']==item['pending'] and item['attempts']>=item['writes'] and item['blocked']==item['attempts']-item['writes']+item['terminal_attempts']-item['terminals'] and item['binding_index'] in (0,1) and item['binding_generation']>=1, 'producer algebra or metadata checks')
    if held:
        require(not item['done'] and item['blocked']>=1 and item['pending']>=1 and item['terminals']==0, 'producer held state')
    if offset==16777313:
        require(item['done'] and item['writes']==2049 and item['terminals']==1 and item['pending']+1==item['invocations'], 'producer final')
    if after_reuse:
        require(item['after_reuse']>=1, 'reuse callback missing')


def validate_progress(before: dict, after: dict) -> None:
    for item in (before,after):
        diagnostic_schema(item,PRODUCER_NUMBERS,('armed','done'),('tag','sha256'))
    require(all(before[key]==after[key] for key in ('tag','binding_index','binding_generation')), 'producer identity changed')
    require(all(after[key]>=before[key] for key in PRODUCER_NUMBERS if key not in ('binding_index','binding_generation')), 'producer counter decreased')


def validate_reuse_binding(producer: dict, binding: dict) -> None:
    diagnostic_schema(producer,PRODUCER_NUMBERS,('armed','done'),('tag','sha256'))
    diagnostic_schema(binding,('binding_index','binding_generation'),(),('tag',))
    require(producer['armed'] and producer['binding_index'] in (0,1) and producer['binding_generation']>=1, 'producer binding identity')
    require(producer['tag']=='producer_reuse' and binding['tag']=='producer_reuse_next' and binding['binding_index']==producer['binding_index'] and binding['binding_generation']==catalogue.add_u64(producer['binding_generation'],1), 'relative reuse binding')


def validate_file(item: dict, complete: bool) -> None:
    diagnostic_schema(item,FILE_NUMBERS,('transferred','caller_owned'),('tag',))
    require(type(complete) is bool and item['tag']=='stream_file' and item['arms']==1 and item['arm_errors']==0 and item['transferred'] and not item['caller_owned'] and item['read_errors']==0 and item['invalid_spans']==0, 'file ownership')
    require(item['close_calls']==int(complete) and item['closed_files']==int(complete), 'file close once')
    if complete:
        require(item['reads']>=1 and item['requested']>=item['returned']>=1 and 37<=item['min_offset']<item['max_end']<=24630, 'file bounded range')


def default_outputs() -> dict:
    result = {}
    for tag in PRODUCERS:
        item = dict.fromkeys(PRODUCER_NUMBERS,0)
        item.update(tag=tag,armed=False,done=False,sha256=EMPTY_HASH)
        result[tag] = item
    file = dict.fromkeys(FILE_NUMBERS,0)
    file.update(tag='stream_file',min_offset=24630,transferred=False,caller_owned=True)
    result['stream_file'] = file
    return result


def validate_outputs(selection: tuple | list, actual: dict) -> None:
    catalogue.schedule(selection)
    defaults = default_outputs()
    require(type(actual) is dict and actual.keys()==defaults.keys(), 'output identities')
    for tag, item in actual.items():
        if tag not in selection:
            diagnostic_schema(item,PRODUCER_NUMBERS if tag in PRODUCERS else FILE_NUMBERS,('armed','done') if tag in PRODUCERS else ('transferred','caller_owned'),('tag','sha256') if tag in PRODUCERS else ('tag',))
            require(item==defaults[tag], 'unselected output differs')
        elif tag in PRODUCERS:
            require(item['tag']==tag, 'output tag')
            validate_producer(item,16777313,after_reuse=tag=='producer_reuse')
        else:
            validate_file(item,True)


def validate_stale_control(action: str, reply: str, before: dict, after: dict, active_before: dict | None, active_after: dict | None) -> None:
    require(type(action) is str and action in ('resume','cancel') and reply=='BodyControlExpired', 'stale control result')
    require(type(before) is dict and type(after) is dict and 'stale_'+action in before, 'stale control records')
    expected = dict(before)
    expected['stale_'+action] = catalogue.add_u64(unsigned(before['stale_'+action]),1)
    require(after==expected and all(type(after[key]) is type(value) for key,value in expected.items()), 'stale control changed other fields')
    require(active_after==active_before and type(active_after) is type(active_before), 'stale control changed sibling')
    if active_before is not None:
        require(type(active_before) is dict and all(type(active_after[key]) is type(value) for key,value in active_before.items()), 'sibling types changed')


def validate_unchanged_control(reply: str, expected_reply: str, before: dict, after: dict) -> None:
    require(type(expected_reply) is str and expected_reply in ('BodyNotPaused','BodyControlExpired','BodyCallbackActive') and reply==expected_reply, 'control refusal differs')
    require(type(before) is dict and type(after) is dict and before==after and all(type(after[key]) is type(value) for key,value in before.items()), 'control refusal mutated state')


def validate_pre_post(selection: tuple | list, before: dict, after: dict) -> None:
    validate_records(selection,'before',before)
    validate_records(selection,'after',after)
    for tag in SPECS:
        if tag=='shutdown_active' and tag in selection:
            expected = dict(before[tag],cancels=1,active=False,paused=False,reason='shutdown')
            require(after[tag]==expected, 'shutdown changed nonterminal evidence')
        else:
            require(before[tag]==after[tag], 'post-deinit record changed')


def validate_output_response(tag: str, actual: dict) -> None:
    if type(tag) is str and tag in CORE_REQUESTS:
        validate_core_response(tag,actual)
        return
    require(type(tag) is str and tag in PRODUCERS+('stream_file','early_final_order'), 'output response tag')
    expected = dict(EARLY_RESPONSE) if tag=='early_final_order' else dict(bytes=24593 if tag=='stream_file' else 16777313,sha256='8cacc49e5f9553369e25a67f4e0e9a799b38c07245a6da92a54ffb58c3ebc2ac' if tag=='stream_file' else PRODUCER_HASH,end=True,reset=False)
    if tag=='stream_file':
        expected['content_length'] = 24593
    require(type(actual) is dict and actual.keys()==expected.keys() and all(type(actual[key]) is type(value) and actual[key]==value for key,value in expected.items()), 'output response differs')


def metrics(selection: tuple | list, phase: str) -> dict:
    items = records(selection,phase)
    idle_only = bool(selection) and tuple(selection)==('shutdown_idle',)
    selected = tuple(case for case in selection if case!='shutdown_idle')
    heads = 69 if idle_only else catalogue.schedule(selected)[0]
    result = {}
    for field in COMMON_COUNTERS+('bytes',):
        total = 0
        for item in items.values():
            total = catalogue.add_u64(total,item[field])
        result[field] = total
    result['active'] = sum(int(item['active']) for item in items.values())
    result['paused'] = sum(int(item['paused']) for item in items.values())
    result['buffered_middleware'] = heads-result['middleware']
    return result


def validate_output_pre_post(selection: tuple | list, before: dict, after: dict, *, binding_before: dict | None, binding_after: dict) -> None:
    validate_outputs(selection,before)
    validate_outputs(selection,after)
    require(before==after, 'post-deinit output changed')
    validate_binding_pre_post(selection,binding_before,binding_after,before['producer_reuse'] if 'producer_reuse' in selection else None)


def validate_metrics(selection: tuple | list, phase: str, actual: dict) -> None:
    expected = metrics(selection,phase)
    require(type(actual) is dict and actual.keys()==expected.keys()|{'slot0_active','slot1_active'}, 'metrics schema')
    require(all(type(actual[key]) is type(value) and actual[key]==value for key,value in expected.items()), 'metrics differ')
    require(type(actual['slot0_active']) is bool and type(actual['slot1_active']) is bool and int(actual['slot0_active'])+int(actual['slot1_active'])==expected['active'], 'binding slot activity differs')


READY_BUFFERED_PAYLOAD = bytes(index%251 for index in range(257))
READY_BUFFERED_REQUEST = MappingProxyType(dict(method='POST',path='/echo',headers=(('content-length','257'),),body=READY_BUFFERED_PAYLOAD,end_stream=False,data_end_stream=True,response_limit=257))
ASYNC_DELAYED_REQUEST = MappingProxyType(dict(method='GET',path='/delayed',headers=(),body=b'',end_stream=True,data_end_stream=None,response_limit=10))
CORE_REQUESTS = MappingProxyType(dict(ready_buffered=READY_BUFFERED_REQUEST,async_delayed=ASYNC_DELAYED_REQUEST))
CORE_RESPONSES = MappingProxyType(dict(ready_buffered=(READY_BUFFERED_PAYLOAD,257,'a2c6cad2ffa699b14538231fef914f45d30440389e6f8d79091efba836165a2b'),async_delayed=(b'delayed-ok',10,'5235430cff06281ef23fabd775a3493bf34fd508219d31ed270ac65ac631ce52')))
CORE_RESPONSE_FIELDS = ('body','bytes','sha256','headers','ended','reset','trailers','informationals')
CORE_SINK_COUNTERS = ('begin','end','cancel','active')


def core_request(case: str) -> dict:
    require(type(case) is str and case in CORE_REQUESTS, 'core case')
    return dict(CORE_REQUESTS[case])


def validate_core_response(case: str, actual: dict) -> None:
    require(type(case) is str and case in CORE_RESPONSES, 'core case')
    require(type(actual) is dict and actual.keys()==set(CORE_RESPONSE_FIELDS), 'core response schema')
    payload,length,digest_value = CORE_RESPONSES[case]
    require(type(actual['body']) is bytes and actual['body']==payload and type(actual['bytes']) is int and actual['bytes']==length and type(actual['sha256']) is str and actual['sha256']==digest_value, 'core response payload')
    require(actual['ended'] is True and actual['reset'] is None and actual['trailers'] is None and type(actual['informationals']) is int and actual['informationals']==0, 'core response terminal')
    headers = actual['headers']
    require(type(headers) in (tuple,list) and 1<=len(headers)<=32, 'core response headers')
    for entry in headers:
        require(type(entry) in (tuple,list) and len(entry)==2 and all(type(value) is str for value in entry), 'core header entry')
    require([value for name,value in headers if name==':status']==['200'], 'core response status multiplicity')
    if case=='async_delayed':
        require([value for name,value in headers if name.lower()=='content-type']==['text/plain'], 'delayed content type multiplicity')


def validate_core_sink(case: str, before: dict, after: dict) -> None:
    require(type(case) is str and case in CORE_REQUESTS, 'core case')
    for item in (before,after):
        diagnostic_schema(item,CORE_SINK_COUNTERS,(),())
        require(item['active']==0, 'core case active sink')
    require(before==after, 'core case changed sink totals')


BINDING_OBSERVATION = ('tag','binding_index','binding_generation')


def default_binding() -> dict:
    return dict(tag='producer_reuse_next',binding_index=0,binding_generation=0)


def validate_binding_pre_post(selection: tuple | list, before: dict | None, after: dict, producer: dict | None) -> None:
    catalogue.schedule(selection)
    diagnostic_schema(after,BINDING_OBSERVATION[1:],(),BINDING_OBSERVATION[:1])
    require(after['tag']=='producer_reuse_next', 'binding tag')
    if 'producer_reuse' not in selection:
        require(before is None and producer is None and after==default_binding(), 'unselected binding differs')
        return
    validate_reuse_binding(producer,before)
    require(after==before, 'post-deinit binding changed')
