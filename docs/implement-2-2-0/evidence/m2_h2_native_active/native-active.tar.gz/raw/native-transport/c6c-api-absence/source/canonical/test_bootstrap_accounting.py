"""Bootstrap connection credit must not refund the same received bytes twice."""
import h2_client
import hpack
import output_stage
import raw_observer
import request_credit
import response_credit
import wire


def frame(kind, flags, stream, payload):
    return len(payload).to_bytes(3, 'big') + bytes((kind, flags)) + stream.to_bytes(4, 'big') + payload


def check():
    protocol = h2_client.new_protocol()
    request = request_credit.new_state(request_credit.new_case('output_pressure_window'))
    credit = response_credit.new_state()
    stage = output_stage.new_stage(output_stage.new_case('output_pressure_window'), 3, 2, 10, 100)
    raw, records, trace = raw_observer.new_state(), {}, {}
    wire.bind_connection(stage, protocol, raw, request, credit, records)
    wire.startup(stage)
    pairs = ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1))
    payload = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in pairs)
    wire.accept(protocol, frame(4, 0, 0, payload) + frame(4, 1, 0, b''), records, raw, trace,
                credit=credit, request=request, stage=stage)
    wire.drain(stage)
    stream, chunks = wire.start_request(stage, 'GET', 'localhost', '/health', (), True,
                                        role='small', primary=False, held=False, body_limit=2, final_status=200,
                                        info_count=0, policy='healthy', mode='small_body', expected_sha256=None,
                                        middleware_policy='required')
    block = hpack.Encoder().encode([(':status', '200'), ('x-middleware', 'retained')])
    wire.accept(protocol, frame(1, 4, stream, block) + frame(0, 1, stream, b'ok'), records, raw, trace,
                credit=credit, request=request, stage=stage)
    wire.retire(records, raw, stream, request=request, credit=credit, stage=stage)
    wire.update_settings(stage, 0)
    wire.drain(stage)
    wire.accept(protocol, frame(4, 1, 0, b''), records, raw, trace, credit=credit, request=request, stage=stage)
    grants = wire.new_grants(stage)
    wire.grant(protocol, credit, grants, stage, 0, 33554432 - credit['connection'], 'bootstrap')
    wire.drain(stage)
    try:
        wire.grant(protocol, credit, grants, stage, 0, 1, 'replenish')
    except ValueError as error:
        if str(error) != 'unearned connection grant':
            raise
    else:
        raise RuntimeError('bootstrap refunded previously consumed bytes twice')
    if not chunks:
        raise RuntimeError('health request missing')
    print('bootstrap credit accounting checks passed')


if __name__ == '__main__':
    check()
