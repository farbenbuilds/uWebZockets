"""Bounded independent queued-trailer and receive-credit serialized peer."""
import hashlib
import json
import adapter
import h2_client
import hpack
import model
import catalogue
from test_core_peer import frame, metrics, new_app, require



def schedule(case):
    target = model.request_contract(case)['target']
    if case == 'queued_trailers_padding':
        return ('/health', target, '/status/' + case, '/status/' + case, '/resume/' + case, '/health')
    return ('/health', target, '/health', '/status/' + case, '/resume/' + case, '/status/' + case, '/health')


def new_peer(case, *, app, prior, now, clock, final=False, fault=None):
    """Synthetic caller-owned transport: parser8201, send8192, pending4/16384.
    One upload summary; reads <= heads+3; HPACK4096. No constructor dispatch.
    """
    require(type(case) is str and case in ('queued_trailers_padding', 'receive_credit'), 'unsupported credit peer')
    require(type(app) is dict and set(app) == {'records', 'heads', 'outputs', 'binding'}, 'app fields differ')
    catalogue.schedule(prior)
    require(case not in prior and type(final) is bool and type(now) is int and 0 <= now < catalogue.U64 and callable(clock),
            'peer arguments differ')
    require(fault is None or type(fault) is str and fault in ('paused_record', 'missing_stream_credit'), 'peer fault differs')
    require(fault != 'missing_stream_credit' or case == 'receive_credit', 'fault case differs')
    model.validate_records(prior, 'before', app['records'])
    model.validate_outputs(prior, app['outputs'])
    model.validate_binding_pre_post(prior, app['binding'], model.default_binding() if app['binding'] is None else app['binding'],
                                    app['outputs']['producer_reuse'] if 'producer_reuse' in prior else None)
    require(type(app['heads']) is int and app['heads'] == sum(catalogue.case_budget(item)['heads'] for item in prior), 'prior heads not earned')
    if not prior:
        require(app['heads'] == 0 and app['binding'] is None, 'empty prior app differs')
    settings = b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    state = dict(case=case, final=final, fault=fault, startup=True, buffer=bytearray(),
                 pending=[frame(4, 0, 0, settings) + frame(4, 1, 0, b'')], cursor=0, heads=0,
                 head_limit=len(schedule(case)) + 68 * int(final), settings=0, acks=0,
                 received=0, received_bytes=0, stream=None, frames=0, logical=0, flow=0, padding=0,
                 hash=hashlib.sha256(), accepted_hash=hashlib.sha256(), accepted=0, trailers=0,
                 ends=0, resumed=False, terminal=False, final_requests=0, statuses=0, statuses_delivered=0,
                 responses_queued=0, responses_delivered=0, connection_queued=0, stream_queued=0,
                 connection_delivered=0, stream_delivered=0, max_buffer=0, max_pending=1, max_pending_bytes=48,
                 decoder=hpack.Decoder(max_header_list_size=4096), encoder=hpack.Encoder())

    def send(data):
        send_bytes(state, app, data)

    def receive():
        return receive_bytes(state, clock)

    connection = dict(protocol=h2_client.new_protocol(), send=send, receive=receive, now=now, owned=True, tls='TLSv1.3', alpn='h2')
    return dict(connection=connection, state=state)


def check_storage(state):
    require(len(state['buffer']) <= 8201, 'parser storage bound differs')
    require(len(state['pending']) <= 4 and sum(map(len, state['pending'])) <= 16384, 'pending storage bound differs')
    require(all(type(packet) is bytes and 0 < len(packet) <= 8192 for packet in state['pending']), 'pending packet bound differs')
    require(0 <= state['cursor'] <= state['head_limit'] and state['heads'] == state['cursor'], 'finite cursor differs')
    require(0 <= state['received'] <= state['head_limit'] + 3 and
            state['received_bytes'] <= (state['head_limit'] + 3) * 8192, 'receive bound differs')
    require(state['decoder'].max_allowed_table_size == 4096 and state['encoder'].header_table_size == 4096, 'HPACK table bound differs')
    require(0 <= state['frames'] <= 9 and 0 <= state['logical'] <= 65536 and 0 <= state['flow'] <= 65536 and
            0 <= state['padding'] <= 8 and 0 <= state['accepted'] <= state['logical'], 'body receipt bound differs')
    state['max_buffer'] = max(state['max_buffer'], len(state['buffer']))
    state['max_pending'] = max(state['max_pending'], len(state['pending']))
    state['max_pending_bytes'] = max(state['max_pending_bytes'], sum(map(len, state['pending'])))


def queue(state, packets):
    require(len(state['pending']) + len(packets) <= 4 and
            sum(map(len, state['pending'])) + sum(map(len, packets)) <= 16384, 'pending storage bound differs')
    require(all(type(packet) is bytes and 0 < len(packet) <= 8192 for packet in packets), 'pending packet bound differs')
    state['pending'].extend(packets)
    check_storage(state)


def respond(state, stream, body):
    require(len(body) <= 4095 and len(state['pending']) < 4, 'response queue or body bound differs')
    block = state['encoder'].encode(((':status', '200'), ('x-middleware', 'retained')))
    queue(state, (frame(1, 4, stream, block) + frame(0, 1, stream, body),))
    state['responses_queued'] += 1


def accept_buffered(state, app):
    state['accepted'] = state['logical']
    state['accepted_hash'] = state['hash'].copy()
    app['records'][state['case']].update(bytes=state['accepted'], sha256=state['accepted_hash'].hexdigest(),
                                       chunks=state['frames'], max_span=8192, paused=False)


def complete(state, app):
    require(state['resumed'] and not state['terminal'] and state['ends'] == 1, 'completion before resume or END')
    require(state['accepted'] == state['logical'], 'completion before acceptance')
    state['terminal'] = True
    item = app['records'][state['case']]
    item.update(ends=1, active=False, paused=False, metadata_end=1)
    respond(state, state['stream'], json.dumps(item).encode())


def resume(state, app, stream):
    require(not state['resumed'], 'duplicate resume')
    require(len(state['pending']) == 0, 'resume response pending')
    state['resumed'] = True
    accept_buffered(state, app)
    respond(state, stream, b'ok')
    if state['case'] == 'queued_trailers_padding':
        complete(state, app)
        return
    amount = state['accepted']
    increment = amount.to_bytes(4, 'big')
    packets = (frame(8, 0, 0, increment),)
    state['connection_queued'] = amount
    if state['fault'] != 'missing_stream_credit':
        packets += (frame(8, 0, state['stream'], increment),)
        state['stream_queued'] = amount
    queue(state, packets)


def request_path(state):
    paths, cursor = schedule(state['case']), state['cursor']
    if cursor < len(paths):
        return paths[cursor]
    require(state['final'] and cursor < len(paths) + 68, 'request beyond finite schedule')
    require(state['terminal'], 'final before ordinary completion')
    return '/metrics' if cursor - len(paths) == 67 else '/status/' + model.BODY_SPECS[cursor - len(paths)][0]


def request_barrier(state):
    cursor = state['cursor']
    if cursor <= 1:
        return
    if state['case'] == 'queued_trailers_padding' and cursor < 5:
        require(state['frames'] == (1 if cursor == 2 else 2) and state['trailers'] == int(cursor > 2), 'status barrier ordinal differs')
        require(state['statuses_delivered'] == cursor - 2, 'paused status delivery differs')
        return
    if state['case'] == 'receive_credit' and cursor < 6:
        require(state['frames'] == 8 and state['logical'] == 65535 and state['ends'] == 0, 'credit barrier ordinal differs')
        require(state['statuses_delivered'] == int(cursor >= 4), 'paused status delivery differs')
        require(state['resumed'] == (cursor == 5), 'resume barrier differs')
        return
    require(state['terminal'], 'request before completion')


def header_contract(state, path):
    upload = path == model.request_contract(state['case'])['target']
    expected = [(':method', 'POST' if upload else 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)]
    if upload:
        expected.append(('content-length', str(12289 if state['case'] == 'queued_trailers_padding' else 65536)))
        if state['case'] == 'queued_trailers_padding':
            expected += [('x-metadata', 'initial-qtp'), ('x-initial-only', 'initial-only')]
    return upload, expected


def trailers_received(state, packet):
    require(state['case'] == 'queued_trailers_padding' and state['cursor'] == 3 and state['frames'] == 2 and
            state['trailers'] == 0 and state['statuses_delivered'] == 1 and not state['resumed'], 'trailer ordinal differs')
    entries = list(state['decoder'].decode(packet[9:]))
    require(packet[4] == 5 and entries == [('x-metadata', 'trailer-qtp'), ('x-trailer-only', 'discarded')], 'trailer metadata differs')
    state['trailers'] = 1
    state['ends'] = 1


def auxiliary(state, app, path, stream):
    if path.startswith('/resume/'):
        resume(state, app, stream)
        return
    if path.startswith('/status/'):
        item = dict(app['records'][path[8:]])
        if state['cursor'] <= len(schedule(state['case'])):
            state['statuses'] += 1
            state['status_stream'] = stream
            if state['fault'] == 'paused_record' and not state['resumed']:
                item['bytes'] += 1
        respond(state, stream, json.dumps(item).encode())
        return
    respond(state, stream, b'ok' if path == '/health' else json.dumps(metrics(app)).encode())


def headers_received(state, app, packet):
    stream = int.from_bytes(packet[5:9], 'big')
    if stream == state['stream']:
        trailers_received(state, packet)
        return
    require(state['acks'] == 1 and state['responses_queued'] == state['responses_delivered'], 'request before preceding response')
    path = request_path(state)
    request_barrier(state)
    upload, expected = header_contract(state, path)
    entries = list(state['decoder'].decode(packet[9:]))
    require(entries == expected and stream == 2 * state['cursor'] + 1 and packet[4] == (4 if upload else 5), 'request contract differs')
    require(state['cursor'] < state['head_limit'] and len(state['pending']) < 4, 'request or pending bound differs')
    state['cursor'] += 1
    state['heads'] += 1
    app['heads'] += 1
    if state['cursor'] > len(schedule(state['case'])):
        state['final_requests'] += 1
    if upload:
        state['stream'] = stream
        app['records'][state['case']].update(middleware=1, attempts=1, begins=1, metadata_begin=1,
                                           active=True, paused=state['case'] == 'receive_credit')
        return
    auxiliary(state, app, path, stream)


def data_contract(state, packet):
    require(state['stream'] is not None and int.from_bytes(packet[5:9], 'big') == state['stream'], 'DATA stream differs')
    ordinal, flags, payload = state['frames'], packet[4], packet[9:]
    if state['case'] == 'queued_trailers_padding':
        require(ordinal < 2 and (len(payload), flags) == ((8192, 0), (4105, 8))[ordinal], 'DATA ordinal differs')
        require(state['cursor'] == 2 + ordinal and state['statuses_delivered'] == ordinal and not state['resumed'], 'DATA delivery barrier differs')
        if ordinal == 1:
            require(payload[0] == 7 and payload[-7:] == bytes(7), 'padding differs')
            payload = payload[1:-7]
    else:
        require(ordinal < 9 and (len(payload), flags) == ((8192, 0) if ordinal < 7 else (8191, 0) if ordinal == 7 else (1, 1)), 'DATA ordinal differs')
        require(state['cursor'] == (2 if ordinal < 8 else 6), 'DATA schedule differs')
        require(ordinal < 8 or state['resumed'] and state['statuses_delivered'] == 2 and
                state['connection_delivered'] == state['stream_delivered'] == 65535, 'DATA before delivered connection and stream credit')
    total = 12289 if state['case'] == 'queued_trailers_padding' else 65536
    require(payload == model.payload_span(total, state['logical'], len(payload)), 'request body differs')
    require(not state['terminal'] and state['ends'] == 0 and len(state['pending']) < 4, 'DATA terminal or pending bound differs')
    return payload


def data_received(state, app, packet):
    payload = data_contract(state, packet)
    state['hash'].update(payload)
    state['logical'] += len(payload)
    state['flow'] += len(packet) - 9
    state['padding'] += len(packet) - 9 - len(payload)
    state['frames'] += 1
    item = app['records'][state['case']]
    if state['case'] == 'queued_trailers_padding' and state['frames'] == 1:
        state['accepted_hash'].update(payload[:7])
        state['accepted'] = 7
        item.update(bytes=7, sha256=state['accepted_hash'].hexdigest(), chunks=1, max_span=7, paused=True)
    if packet[4] & 1:
        state['ends'] = 1
        accept_buffered(state, app)
        complete(state, app)


def packet_received(state, app, packet):
    if packet[3] == 4:
        require(packet == frame(4, 1, 0, b'') and state['acks'] == 0 and state['cursor'] == 0, 'settings ACK differs')
        state['acks'] = 1
        return
    if packet[3] == 0:
        data_received(state, app, packet)
        return
    require(packet[3] == 1, 'unexpected frame type')
    headers_received(state, app, packet)


def send_bytes(state, app, data):
    check_storage(state)
    require(type(data) is bytes and 0 < len(data) <= 8192, 'send span differs')
    if state['startup']:
        expected = b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n'
        expected += frame(4, 0, 0, b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                                        ((1, 4096), (2, 1), (4, 65535), (5, 16384), (8, 0), (3, 100), (6, 65536))))
        require(data == expected, 'startup bytes differ')
        state['startup'] = False
        state['settings'] = 1
        return
    require(len(data) <= 8201 - len(state['buffer']), 'parser storage bound differs')
    prefix = bytes(state['buffer'][:9]) + data[:max(0, 9 - len(state['buffer']))]
    require(len(prefix) < 3 or int.from_bytes(prefix[:3], 'big') <= 8192, 'frame payload bound differs')
    state['buffer'].extend(data)
    check_storage(state)
    while len(state['buffer']) >= 9:
        size = int.from_bytes(state['buffer'][:3], 'big')
        require(size <= 8192, 'frame payload bound differs')
        if len(state['buffer']) < size + 9:
            return
        packet = bytes(state['buffer'][:size + 9])
        del state['buffer'][:size + 9]
        packet_received(state, app, packet)
        check_storage(state)


def delivered(state, packet):
    offset = 0
    while offset < len(packet):
        size, kind = int.from_bytes(packet[offset:offset + 3], 'big'), packet[offset + 3]
        stream = int.from_bytes(packet[offset + 5:offset + 9], 'big')
        if kind == 8:
            amount = int.from_bytes(packet[offset + 9:offset + 13], 'big')
            field = 'connection_delivered' if stream == 0 else 'stream_delivered'
            state[field] += amount
        if kind == 1:
            state['responses_delivered'] += 1
            if stream == state.get('status_stream'):
                state['statuses_delivered'] += 1
        offset += size + 9


def receive_bytes(state, clock):
    require(not state['startup'] and bool(state['pending']), 'missing synthetic response')
    check_storage(state)
    require(state['received'] < state['head_limit'] + 3, 'receive bound differs')
    packet = state['pending'][0]
    require(len(packet) <= (state['head_limit'] + 3) * 8192 - state['received_bytes'], 'receive byte bound differs')
    stamp = clock()
    state['pending'].pop(0)
    state['received'] += 1
    state['received_bytes'] += len(packet)
    delivered(state, packet)
    return packet, stamp


def check(case, app=None, prior=(), final=False, fault=None):
    app = new_app() if app is None else app
    peer = new_peer(case, app=app, prior=prior, now=1, clock=lambda: 2, final=final, fault=fault)
    connection, state = peer['connection'], peer['state']
    context = adapter.open_case(case, connection['protocol'], connection['send'], 1, 30001, 900001,
                                selected_before=prior, clock=lambda: 2)
    adapter.observe(context, *connection['receive']())
    adapter.run_case(context, connection['receive'])
    if final:
        adapter.final_collection(context, connection['receive'])
    require(state['cursor'] == state['head_limit'] and not state['pending'] and not state['buffer'] and
            state['frames'] == (2 if case == 'queued_trailers_padding' else 9), 'request order or DATA count differs')
    size = 12289 if case == 'queued_trailers_padding' else 65536
    require(state['logical'] == state['accepted'] == size and state['flow'] == size + (8 if size == 12289 else 0) and
            state['hash'].hexdigest() == model.accepted_hash(size), 'upload digest or flow differs')
    require(state['trailers'] == int(size == 12289), 'trailers differ')
    model.validate_records(prior + (case,), 'before', app['records'])
    print(case + ' passed')
    return app


def main():
    app = check('queued_trailers_padding')
    check('receive_credit', app=app, prior=('queued_trailers_padding',), final=True)
    for case, fault in (('queued_trailers_padding', 'paused_record'), ('receive_credit', 'missing_stream_credit')):
        try:
            check(case, fault=fault)
        except (ValueError, RuntimeError) as exc:
            expected = 'record mismatch: bytes' if fault == 'paused_record' else 'missing synthetic response'
            if str(exc) != expected:
                raise RuntimeError('fault rejected for wrong reason') from exc
            print(fault + ' rejected: ' + str(exc))
        else:
            raise RuntimeError('fault accepted: ' + fault)


if __name__ == '__main__':
    main()
