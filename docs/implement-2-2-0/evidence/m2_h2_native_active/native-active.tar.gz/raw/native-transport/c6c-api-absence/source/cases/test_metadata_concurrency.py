"""Bounded independent metadata and concurrent-route serialized peer."""
import hashlib
import json
import adapter
import cases
import catalogue
import h2_client
import hpack
import model
from test_core_peer import frame, metrics, new_app, require


def expected_headers(tag):
    if tag == 'metadata_helpers':
        return [('content-length', '32'), ('x-mode', 'begin_paused')] + [
            ('x-h%02d' % n, 'v%02d' % n) for n in range(63)] + [('host', 'localhost')]
    extra = {'concurrent_hold': [('x-metadata', 'hold-metadata')],
             'concurrent_refused': [('expect', '100-continue')],
             'concurrent_upload': [('x-metadata', 'upload-metadata')], 'concurrent_recovery': []}
    return [('content-length', '1' if tag == 'concurrent_refused' else '32')] + extra[tag]


def target(tag):
    if tag == 'metadata_helpers':
        return '/meta/metadata_helpers/' + '/'.join('a%02d' % n for n in range(1, 17)) + '?q=alpha&n=17'
    return {'concurrent_hold': '/limit/concurrent_hold?case=hold',
            'concurrent_refused': '/limit/concurrent_refused',
            'concurrent_upload': '/upload/concurrent_upload?case=upload',
            'concurrent_recovery': '/limit/concurrent_recovery'}[tag]


def paths(case):
    if case == 'metadata_helpers':
        return ['/health', target(case), '/status/' + case, '/status/' + case,
                '/resume/' + case, '/health']
    return ['/health', target('concurrent_hold'), '/status/concurrent_hold',
            target('concurrent_refused'), target('concurrent_upload'), '/metrics', '/health',
            '/status/concurrent_hold', '/resume/concurrent_hold', '/status/concurrent_hold',
            target('concurrent_recovery'), '/health', '/health']


def validate_upload(entries, flags, tag):
    expected = [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'), (':path', target(tag))]
    if entries != expected + expected_headers(tag) or flags != 4:
        raise RuntimeError('upload header multiplicity or target differs')


def contract_and_oracle_checks():
    contract = model.request_contract('metadata_helpers')
    expected = dict(method='POST', target=target('metadata_helpers'), query='q=alpha&n=17',
                    declared=32, headers=66, captures=17, header_entries=tuple(expected_headers('metadata_helpers')),
                    capture_entries=(('tag', 'metadata_helpers'),) + tuple(('p%02d' % n, 'a%02d' % n) for n in range(1, 17)),
                    header_storage=(64, 2), capture_storage=(16, 1), missing_capture='P16',
                    body_helpers=('json', 'validate_json', 'validate_json_detailed', 'form', 'multipart'),
                    helper_error='BodyNotBuffered', text=b'', bytes=b'', issue=('untouched', 'too_deep', 'same_pointer', 'same_length'),
                    allocator_used=0, trailer_only=None, query_values=(('q', 'alpha'), ('n', '17')))
    if any(contract[key] != value for key, value in expected.items()):
        raise RuntimeError('metadata helper or overflow contract differs')
    entries = [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'),
               (':path', target('metadata_helpers'))] + expected_headers('metadata_helpers')
    validate_upload(entries, 4, 'metadata_helpers')
    variants = (('host omitted', entries[:-1], 4), ('duplicate host', entries + [('host', 'localhost')], 4),
                ('initial trailer contamination', entries + [('x-trailer-only', 'discarded')], 4),
                ('initial END', entries, 5), ('method', [(':method', 'GET')] + entries[1:], 4),
                ('target query', entries[:3] + [(':path', target('metadata_helpers') + '&n=18')] + entries[4:], 4),
                ('declaration', entries[:4] + [('content-length', '31')] + entries[5:], 4))
    for name, supplied, flags in variants:
        try:
            validate_upload(supplied, flags, 'metadata_helpers')
        except RuntimeError as exc:
            if str(exc) != 'upload header multiplicity or target differs':
                raise
        else:
            raise RuntimeError('synthetic oracle control accepted: ' + name)
    print('metadata helper/overflow contract checked; seven synthetic header oracle controls rejected')


def new_peer(case, *, app, prior, now, clock, final=False, fault=None):
    """Supplied synthetic transport; parser8201, send8192, pending4/16384.
    At most four upload summaries; HPACK4096; reads <= heads+4.
    """
    require(type(case) is str and case in ('metadata_helpers', 'concurrent_routes'), 'unsupported metadata peer')
    require(type(app) is dict and set(app) == {'records', 'heads', 'outputs', 'binding'}, 'app fields differ')
    catalogue.schedule(prior)
    require(case not in prior and type(final) is bool and type(now) is int and 0 <= now < catalogue.U64 and callable(clock),
            'peer arguments differ')
    faults = ('helpers_begin', 'helpers_end', 'metadata_middleware', 'metadata_begin', 'metadata_end',
              'paused_bytes', 'not_paused', 'early_final', 'other_record', 'refusal_status', 'refusal_continue',
              'reset_first', 'reset_code', 'active_count', 'paused_count', 'slot_count', 'resume_prefix', 'route_contamination')
    require(fault is None or type(fault) is str and fault in faults, 'peer fault differs')
    require(fault is None or fault in faults[5:9] or
            (fault in faults[:5]) == (case == 'metadata_helpers'), 'fault case differs')
    model.validate_records(prior, 'before', app['records'])
    model.validate_outputs(prior, app['outputs'])
    model.validate_binding_pre_post(prior, app['binding'], model.default_binding() if app['binding'] is None else app['binding'],
                                    app['outputs']['producer_reuse'] if 'producer_reuse' in prior else None)
    require(type(app['heads']) is int and app['heads'] == sum(catalogue.case_budget(item)['heads'] for item in prior), 'prior heads not earned')
    if not prior:
        require(app['heads'] == 0 and app['binding'] is None, 'empty prior app differs')
    settings = b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    state = dict(case=case, fault=fault, final=final, startup=True, buffer=bytearray(),
                 pending=[frame(4, 0, 0, settings) + frame(4, 1, 0, b'')], cursor=0, heads=0,
                 head_limit=len(paths(case)) + 68 * int(final), settings=0, acks=0,
                 streams={}, resumed=False, statuses=0, statuses_delivered=0, status_stream=None,
                 trailers=0, metrics=0, resets=0, resets_delivered=0, final_requests=0,
                 responses_queued=0, responses_delivered=0, received=0, received_bytes=0,
                 max_buffer=0, max_pending=1, max_pending_bytes=48,
                 decoder=hpack.Decoder(max_header_list_size=4096), encoder=hpack.Encoder())

    def send(data):
        send_bytes(state, app, data)

    def receive():
        return receive_bytes(state, clock)

    connection = dict(protocol=h2_client.new_protocol(), send=send, receive=receive, now=now, owned=True, tls='TLSv1.3', alpn='h2')
    return dict(connection=connection, state=state)


def check_storage(state):
    require(len(state['buffer']) <= 8201, 'parser storage bound differs')
    require(len(state['pending']) <= 4 and sum(map(len, state['pending'])) <= 16384, 'pending storage bound differs')
    require(all(type(packet) is bytes and 0 < len(packet) <= 8192 for packet in state['pending']), 'pending packet bound differs')
    require(0 <= state['cursor'] <= state['head_limit'] and state['heads'] == state['cursor'], 'finite cursor differs')
    require(0 <= state['received'] <= state['head_limit'] + 4 and
            state['received_bytes'] <= (state['head_limit'] + 4) * 8192, 'receive bound differs')
    require(state['decoder'].max_allowed_table_size == 4096 and state['encoder'].header_table_size == 4096, 'HPACK table bound differs')
    require(len(state['streams']) <= (1 if state['case'] == 'metadata_helpers' else 4), 'upload count bound differs')
    for item in state['streams'].values():
        require(0 <= item['count'] <= 32 and 0 <= item['frames'] <= 2 and
                0 <= item['accepted'] <= item['count'] and 0 <= item['ends'] <= 1, 'upload receipt bound differs')
    state['max_buffer'] = max(state['max_buffer'], len(state['buffer']))
    state['max_pending'] = max(state['max_pending'], len(state['pending']))
    state['max_pending_bytes'] = max(state['max_pending_bytes'], sum(map(len, state['pending'])))


def queue(state, packets):
    require(len(state['pending']) + len(packets) <= 4 and
            sum(map(len, state['pending'])) + sum(map(len, packets)) <= 16384, 'pending storage bound differs')
    require(all(type(packet) is bytes and 0 < len(packet) <= 8192 for packet in packets), 'pending packet bound differs')
    state['pending'].extend(packets)
    check_storage(state)


def response(state, stream, body, refusal=False):
    require(len(body) <= 4095 and len(state['pending']) <= (1 if refusal else 3), 'response queue or body bound differs')
    status = '503' if refusal and state['fault'] != 'refusal_status' else '200'
    block = state['encoder'].encode(((':status', status), ('x-middleware', 'retained')))
    if not refusal:
        queue(state, (frame(1, 4, stream, block) + frame(0, 1, stream, body),))
        state['responses_queued'] += 1
        return
    end = frame(1, 5, stream, block)
    rst = frame(3, 0, stream, (2 if state['fault'] == 'reset_code' else 0).to_bytes(4, 'big'))
    packets = (end, rst)
    if state['fault'] == 'reset_first':
        packets = (rst + end,)
    if state['fault'] == 'refusal_continue':
        info = state['encoder'].encode(((':status', '100'),))
        packets = (frame(1, 4, stream, info) + end + rst,)
    queue(state, packets)
    state['resets'] += 1
    state['responses_queued'] += 1 + int(state['fault'] == 'refusal_continue')


def accept_body(app, item):
    item['accepted'] = item['count']
    app['records'][item['tag']].update(bytes=item['accepted'], sha256=item['digest'].hexdigest(),
                                     chunks=item['frames'], max_span=item['max_span'], paused=False)


def complete(state, app, stream):
    item = state['streams'][stream]
    require(item['ends'] == 1 and item['accepted'] == item['count'] == 32 and not item['terminal'], 'completion before accepted END')
    item['terminal'] = True
    record = app['records'][item['tag']]
    record.update(ends=1, active=False, paused=False, metadata_end=1)
    if item['tag'] == 'metadata_helpers':
        record['helpers_end'] = 1
    if state['fault'] in ('helpers_begin', 'helpers_end', 'metadata_middleware', 'metadata_begin', 'metadata_end') and item['tag'] == 'metadata_helpers':
        record[state['fault']] = 0
    if state['fault'] == 'route_contamination' and item['tag'] == 'concurrent_upload':
        app['records']['concurrent_hold']['metadata_begin'] = 0
    if state['fault'] == 'other_record':
        app['records']['empty_headers']['middleware'] = 1
    response(state, stream, json.dumps(record).encode())


def request_path(state):
    order, cursor = paths(state['case']), state['cursor']
    if cursor < len(order):
        return order[cursor]
    require(state['final'] and cursor < len(order) + 68, 'request beyond finite schedule')
    require(all(item['terminal'] for item in state['streams'].values()), 'final before ordinary completion')
    return '/metrics' if cursor - len(order) == 67 else '/status/' + model.BODY_SPECS[cursor - len(order)][0]


def request_barrier(state):
    cursor = state['cursor']
    if cursor <= 1 or cursor >= len(paths(state['case'])):
        return
    holder = state['streams'][3]
    if state['case'] == 'metadata_helpers':
        expected = ((1, 0, 0), (2, 1, 1), (2, 1, 2), (2, 1, 2))[cursor - 2]
        require((holder['frames'], state['trailers'], state['statuses_delivered']) == expected, 'metadata barrier ordinal differs')
        require(holder['terminal'] == (cursor == 5), 'metadata completion barrier differs')
        return
    required_status = 0 if cursor == 2 else 1 if cursor < 8 else 2 if cursor == 8 else 3
    if cursor == 9:
        required_status = 2
    require(state['statuses_delivered'] == required_status, 'concurrent status barrier differs')
    require(holder['frames'] == (2 if cursor >= 10 else 1), 'holder DATA barrier differs')
    require(holder['terminal'] == (cursor >= 10) and state['resumed'] == (cursor >= 9), 'holder completion barrier differs')
    if cursor >= 4:
        require(state['resets_delivered'] == 1, 'request before refused reset delivery')
    if cursor >= 6:
        require(state['streams'][9]['terminal'], 'request before upload completion')
    if cursor >= 11:
        require(state['streams'][21]['terminal'], 'request before recovery completion')


def status_record(state, app, tag):
    record = dict(app['records'][tag])
    if state['cursor'] > len(paths(state['case'])):
        return record
    state['statuses'] += 1
    if state['fault'] == 'paused_bytes' and not state['resumed']:
        record['bytes'] = 1
    if state['fault'] == 'not_paused' and not state['resumed']:
        record['paused'] = False
    if state['fault'] == 'resume_prefix' and state['resumed']:
        record['sha256'] = model.EMPTY_HASH
    if state['fault'] == 'helpers_begin' and tag == 'metadata_helpers':
        record['helpers_begin'] = 0
    return record


def auxiliary(state, app, path, stream):
    if path == '/health':
        response(state, stream, b'ok')
        return
    if path.startswith('/status/'):
        if state['cursor'] <= len(paths(state['case'])):
            state['status_stream'] = stream
        response(state, stream, json.dumps(status_record(state, app, path[8:])).encode())
        return
    if path == '/metrics':
        state['metrics'] += 1
        values = metrics(app)
        values.update(slot0_active=values['active'] > 0, slot1_active=values['active'] > 1)
        active_barrier = state['cursor'] <= len(paths(state['case']))
        if active_barrier and state['fault'] in ('active_count', 'paused_count', 'slot_count'):
            field, value = {'active_count': ('active', 1), 'paused_count': ('paused', 0), 'slot_count': ('slot1_active', False)}[state['fault']]
            values[field] = value
        response(state, stream, json.dumps(values).encode())
        return
    require(path.startswith('/resume/') and not state['resumed'] and state['statuses_delivered'] == 2, 'resume ordinal differs')
    state['resumed'] = True
    response(state, stream, b'ok')
    accept_body(app, state['streams'][3])
    if state['case'] == 'metadata_helpers':
        complete(state, app, 3)


def upload_headers(state, app, tag, stream):
    require(len(state['streams']) < (1 if state['case'] == 'metadata_helpers' else 4), 'upload count bound differs')
    item = dict(tag=tag, count=0, frames=0, accepted=0, max_span=0, digest=hashlib.sha256(), ends=0, terminal=False)
    state['streams'][stream] = item
    record = app['records'][tag]
    record['middleware'] = 1
    if tag == 'concurrent_refused':
        item['terminal'] = True
        response(state, stream, b'', refusal=True)
        return
    record.update(attempts=1, begins=1, metadata_begin=1, active=True, paused=tag in ('metadata_helpers', 'concurrent_hold'))
    if tag == 'metadata_helpers':
        record.update(metadata_middleware=1, helpers_begin=1)


def trailers_received(state, packet):
    require(state['case'] == 'metadata_helpers' and state['cursor'] == 3 and state['streams'][3]['frames'] == 2 and
            state['trailers'] == 0 and state['statuses_delivered'] == 1 and not state['resumed'], 'trailer ordinal differs')
    entries = list(state['decoder'].decode(packet[9:]))
    require(packet[4] == 5 and entries == [('x-h62', 'changed'), ('x-trailer-only', 'discarded')], 'trailer fields differ')
    state['trailers'] = 1
    state['streams'][3]['ends'] = 1


def headers_received(state, app, packet):
    stream = int.from_bytes(packet[5:9], 'big')
    if stream in state['streams']:
        require(stream == 3, 'unexpected upload trailers')
        trailers_received(state, packet)
        return
    early = int(state['fault'] == 'early_final' and state['cursor'] == 2)
    require(state['acks'] == 1 and state['responses_queued'] == state['responses_delivered'] + early, 'request before preceding response')
    path = request_path(state)
    request_barrier(state)
    tags = ('metadata_helpers',) if state['case'] == 'metadata_helpers' else ('concurrent_hold', 'concurrent_refused', 'concurrent_upload', 'concurrent_recovery')
    tag = next((tag for tag in tags if path == target(tag)), None)
    entries = list(state['decoder'].decode(packet[9:]))
    require(stream == 2 * state['cursor'] + 1, 'stream request-order binding differs')
    if tag is not None:
        validate_upload(entries, packet[4], tag)
    else:
        require(entries == [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)] and
                packet[4] == 5, 'auxiliary headers differ')
    require(state['cursor'] < state['head_limit'] and len(state['pending']) <= 1, 'request or pending bound differs')
    state['cursor'] += 1
    state['heads'] += 1
    app['heads'] += 1
    state['final_requests'] += int(state['cursor'] > len(paths(state['case'])))
    if tag is not None:
        upload_headers(state, app, tag, stream)
        return
    auxiliary(state, app, path, stream)


def data_received(state, app, packet):
    stream, flags, payload = int.from_bytes(packet[5:9], 'big'), packet[4], packet[9:]
    require(stream in state['streams'], 'DATA stream differs')
    item = state['streams'][stream]
    tag, ordinal = item['tag'], item['frames']
    split = tag in ('metadata_helpers', 'concurrent_hold')
    expected_flags = 0 if tag == 'metadata_helpers' or tag == 'concurrent_hold' and ordinal == 0 else 1
    length = 16 if split else 32
    require(not item['terminal'] and item['ends'] == 0 and ordinal < (2 if split else 1) and tag != 'concurrent_refused' and
            len(payload) == length and flags == expected_flags, 'DATA length END or ordinal differs')
    expected_cursor = (2 + ordinal if tag == 'metadata_helpers' else 2 if ordinal == 0 else 10) if split else (6 if tag == 'concurrent_upload' else 11)
    require(state['cursor'] == expected_cursor and state['responses_queued'] == state['responses_delivered'], 'DATA delivery barrier differs')
    require(not split or ordinal == 0 or state['statuses_delivered'] == (1 if tag == 'metadata_helpers' else 3), 'DATA status barrier differs')
    require(payload == model.payload_span(32, item['count'], length), 'DATA payload differs')
    require(len(state['pending']) < 4, 'DATA pending bound differs')
    item['frames'] += 1
    item['count'] += length
    item['max_span'] = max(item['max_span'], length)
    item['digest'].update(payload)
    item['ends'] = int(bool(flags & 1))
    if state['fault'] == 'early_final' and split and ordinal == 0:
        response(state, stream, b'{}')
        return
    if not app['records'][tag]['paused']:
        accept_body(app, item)
    if flags & 1:
        complete(state, app, stream)


def packet_received(state, app, packet):
    if packet[3] == 4:
        require(packet == frame(4, 1, 0, b'') and state['acks'] == 0 and state['cursor'] == 0, 'settings ACK differs')
        state['acks'] = 1
        return
    if packet[3] == 0:
        data_received(state, app, packet)
        return
    require(packet[3] == 1, 'unexpected frame type')
    headers_received(state, app, packet)


def send_bytes(state, app, data):
    check_storage(state)
    require(type(data) is bytes and 0 < len(data) <= 8192, 'send span differs')
    if state['startup']:
        expected = b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n'
        expected += frame(4, 0, 0, b''.join(key.to_bytes(2, 'big') + value.to_bytes(4, 'big') for key, value in
                                        ((1, 4096), (2, 1), (4, 65535), (5, 16384), (8, 0), (3, 100), (6, 65536))))
        require(data == expected, 'startup bytes differ')
        state['startup'] = False
        state['settings'] = 1
        return
    require(len(data) <= 8201 - len(state['buffer']), 'parser storage bound differs')
    prefix = bytes(state['buffer'][:9]) + data[:max(0, 9 - len(state['buffer']))]
    require(len(prefix) < 3 or int.from_bytes(prefix[:3], 'big') <= 8192, 'frame payload bound differs')
    state['buffer'].extend(data)
    check_storage(state)
    while len(state['buffer']) >= 9:
        size = int.from_bytes(state['buffer'][:3], 'big')
        require(size <= 8192, 'frame payload bound differs')
        if len(state['buffer']) < size + 9:
            return
        packet = bytes(state['buffer'][:size + 9])
        del state['buffer'][:size + 9]
        packet_received(state, app, packet)
        check_storage(state)


def delivered(state, packet):
    offset = 0
    while offset < len(packet):
        size, kind = int.from_bytes(packet[offset:offset + 3], 'big'), packet[offset + 3]
        stream = int.from_bytes(packet[offset + 5:offset + 9], 'big')
        if kind == 3:
            state['resets_delivered'] += 1
        if kind == 1:
            state['responses_delivered'] += 1
            if stream == state['status_stream']:
                state['statuses_delivered'] += 1
        offset += size + 9


def receive_bytes(state, clock):
    require(not state['startup'] and bool(state['pending']), 'missing synthetic response')
    check_storage(state)
    require(state['received'] < state['head_limit'] + 4, 'receive bound differs')
    packet = state['pending'][0]
    require(len(packet) <= (state['head_limit'] + 4) * 8192 - state['received_bytes'], 'receive byte bound differs')
    stamp = clock()
    state['pending'].pop(0)
    state['received'] += 1
    state['received_bytes'] += len(packet)
    delivered(state, packet)
    return packet, stamp


def retained_health(original, context, receive, state):
    """Capture the original serialized health boundary; original errors win."""
    original_send = context['send']
    snapshot = {}

    def send(data):
        head = state['heads'] + 1
        if head in (7, 12, 13):
            snapshot.update(head=head, retained=tuple(7 in mapping for mapping in
                            (context['records'], context['stage']['active'], context['raw']['streams'])))
        return original_send(data)

    context['send'] = send
    try:
        result = original(context, receive)
    finally:
        context['send'] = original_send
    if snapshot:
        keep = snapshot['head'] != 13
        require(snapshot['retained'] == (keep, keep, keep), 'refused retention or retirement order differs')
    return result


def run_with_retention(context, receive, state):
    original = adapter.health

    def health(current, incoming):
        if current is not context or state['case'] != 'concurrent_routes':
            return original(current, incoming)
        return retained_health(original, current, incoming, state)

    adapter.health = health
    try:
        result = adapter.run_case(context, receive)
    finally:
        adapter.health = original
    return result


def check(case, *, app=None, prior=(), final=False, fault=None):
    app = new_app() if app is None else app
    caller_time = [1]

    def clock():
        caller_time[0] += 1
        return caller_time[0]

    peer = new_peer(case, app=app, prior=prior, now=1, clock=clock, final=final, fault=fault)
    connection, state = peer['connection'], peer['state']
    context = adapter.open_case(case, connection['protocol'], connection['send'], 1, 30001, 900001,
                                selected_before=prior, clock=clock)
    require(context['stage']['primary'] == 3, 'primary request-order binding differs')
    adapter.observe(context, *connection['receive']())
    run_with_retention(context, connection['receive'], state)
    require(state['heads'] == len(paths(case)) and state['settings'] == state['acks'] == 1 and
            state['resets'] == state['resets_delivered'] == int(case == 'concurrent_routes') and
            not state['pending'] and not state['buffer'], 'case count or pending bytes differ')
    for item in state['streams'].values():
        refused = item['tag'] == 'concurrent_refused'
        require(item['count'] == item['accepted'] == (0 if refused else 32) and
                item['digest'].hexdigest() == (model.EMPTY_HASH if refused else model.H32), 'payload hash or flow differs')
    require(state['trailers'] == int(case == 'metadata_helpers'), 'trailer count differs')
    if final:
        adapter.final_collection(context, connection['receive'])
        require(state['heads'] == state['head_limit'] and state['final_requests'] == 68 and not state['pending'], 'final observations differ')
    model.validate_records(prior + (case,), 'before', app['records'])
    print(case + ' passed: heads=%d small=%d flow=%d' % (context['stage']['limits']['heads'], context['stage']['limits']['small'], context['request']['case']['sent']))
    return app


def rejected(case, fault, message, *, final=False):
    try:
        check(case, fault=fault, final=final)
    except (ValueError, RuntimeError) as exc:
        if str(exc) != message:
            raise RuntimeError('fault rejected for wrong reason: ' + fault) from exc
        print(fault + ' rejected: ' + str(exc))
        return
    raise RuntimeError('fault accepted: ' + fault)


def main():
    contract_and_oracle_checks()
    app = check('metadata_helpers')
    check('concurrent_routes', app=app, prior=('metadata_helpers',), final=True)
    for fault in ('helpers_begin', 'helpers_end', 'metadata_middleware', 'metadata_begin', 'metadata_end'):
        rejected('metadata_helpers', fault, 'record mismatch: ' + fault)
    for case in ('metadata_helpers', 'concurrent_routes'):
        rejected(case, 'paused_bytes', 'record mismatch: bytes')
        rejected(case, 'not_paused', 'record mismatch: paused')
        rejected(case, 'early_final', 'invalid terminal')
        rejected(case, 'other_record', 'record mismatch: middleware', final=True)
    for fault, message in (('refusal_status', 'wrong final status'), ('refusal_continue', 'invalid HEADERS'),
                           ('reset_first', 'reset order'), ('reset_code', 'wrong reset code'),
                           ('active_count', 'concurrent active barrier differs'),
                           ('paused_count', 'concurrent active barrier differs'),
                           ('slot_count', 'concurrent active barrier differs'),
                           ('resume_prefix', 'record mismatch: sha256'),
                           ('route_contamination', 'record mismatch: metadata_begin')):
        rejected('concurrent_routes', fault, message)
    remaining = [case for case in catalogue.CASES if case not in cases.IMPLEMENTED]
    if len(remaining) != 0:
        raise RuntimeError('unsupported inventory differs')
    for case in remaining:
        try:
            adapter.open_case(case, h2_client.new_protocol(), lambda _data: (_ for _ in ()).throw(RuntimeError('unsupported case acted')),
                              1, 30001, 900001, clock=lambda: 2)
        except ValueError as exc:
            if str(exc) != 'case schedule not implemented':
                raise
        else:
            raise RuntimeError('unsupported selection accepted')
    print('40 source schedules implemented; general selection validation retained')


if __name__ == '__main__':
    main()
