"""Bounded credit and queued-trailer schedules on the canonical wire."""
import json
import adapter
import model
import output_stage
import pause_cases
import request_credit
import wire


def start(context, tag):
    contract = model.request_contract(tag)
    headers = [('content-length', str(contract['declared']))]
    if tag == 'queued_trailers_padding':
        headers += [('x-metadata', 'initial-qtp'), ('x-initial-only', 'initial-only')]
    return adapter.start(context, contract['method'], contract['target'], headers, False, True, 4095, held=True)


def barrier(context, receive, stream, tag):
    observed = pause_cases.status(context, receive, tag)
    pause_cases.pending(context, stream)
    model.validate_checkpoint(tag, observed, 'paused')
    return observed


def resume(context, receive, stream, tag):
    control = adapter.start(context, 'GET', '/resume/' + tag, (), True, False, 64)
    output_stage.resume(context['stage'], stream)
    if adapter.finish(context, control, receive)['body'] != b'ok':
        raise ValueError('credit resume differs')


def queued(context, receive):
    tag = 'queued_trailers_padding'
    stream = start(context, tag)
    adapter.send_data(context, stream, model.payload_span(12289, 0, 8192), False)
    observed = barrier(context, receive, stream, tag)
    adapter.send_data(context, stream, model.payload_span(12289, 8192, 4097), False, padding=7)
    adapter.tick(context)
    chunks = wire.send_trailers(context['stage'], stream, [('x-metadata', 'trailer-qtp'), ('x-trailer-only', 'discarded')])
    for chunk in chunks:
        adapter.tick(context)
        context['send'](chunk)
    if barrier(context, receive, stream, tag) != observed:
        raise ValueError('queued trailer changed paused record')
    item = request_credit.stream(context['request'], stream)
    if 12297 - context['request']['connection_debt'] > 15 or 12297 - item['debt'] > 15:
        raise ValueError('early refund exceeds bound')
    resume(context, receive, stream, tag)
    model.validate_item(json.loads(adapter.finish(context, stream, receive)['body']), model.record(tag, True, 'after'))


def credit(context, receive):
    tag = 'receive_credit'
    stream = start(context, tag)
    state = context['request']
    item = request_credit.stream(state, stream)
    if (state['connection'], item['window'], state['connection_debt'], state['stream_debt_total']) != (65535, 65535, 0, 0):
        raise ValueError('initial credit differs')
    for offset in range(0, 65535, 8192):
        length = min(8192, 65535 - offset)
        adapter.send_data(context, stream, model.payload_span(65536, offset, length), False)
    adapter.health(context, receive)
    barrier(context, receive, stream, tag)
    if (state['connection'], item['window'], state['connection_debt'], state['stream_debt_total']) != (0, 0, 65535, 65535):
        raise ValueError('exhausted credit differs')
    resume(context, receive, stream, tag)
    actual = pause_cases.status(context, receive, tag)
    expected = model.record(tag, True, 'after')
    expected.update(bytes=65535, sha256=model.digest(65536, 0, 65535), chunks=None, max_span=None,
                    ends=0, active=True, paused=False, metadata_end=0)
    model.validate_item(actual, expected)
    pause_cases.pending(context, stream)
    while state['connection_debt'] or item['debt']:
        adapter.tick(context)
        data, now = receive()
        adapter.observe(context, data, now)
    if (state['connection'], item['window'], state['stream_debt_total']) != (65535, 65535, 0):
        raise ValueError('settled credit differs')
    adapter.send_data(context, stream, model.payload_span(65536, 65535, 1), True)
    model.validate_item(json.loads(adapter.finish(context, stream, receive)['body']), model.record(tag, True, 'after'))


def run(context, receive):
    adapter.health(context, receive)
    if context['stage']['case'] == 'queued_trailers_padding':
        queued(context, receive)
    else:
        credit(context, receive)
    adapter.health(context, receive)


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned hooks')
