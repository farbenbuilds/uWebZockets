"""Shutdown composition over independently earned persistent synthetic apps."""
import copy
import json
from unittest import mock
import adapter
import catalogue
import coordinator
import model
import test_core_peer
import test_file_early
import test_lifecycle
import test_producer_pressure
import test_shutdown


def require(value, message):
    if not value:
        raise ValueError(message)


def run_selection(selection, control=None, *, start=2, units=1000, outcome='eof'):
    state = dict(clock=start, children=[], events=[], facts=[], collections=[], dispatches=[])

    def clock():
        return state['clock']

    def event(phase, child, context=None, fact=None, deadline=None):
        state['events'].append((phase, child['index']))
        if fact is not None:
            state['facts'].append(fact)
        if control is not None:
            control(phase, state, child, context, fact, deadline)

    def factory(identity, index, selected, ready, whole):
        require(index == len(state['children']) and (index == 0 or state['children'][-1]['posted']),
                'main factory before idle post')
        child = dict(index=index, selection=selected, app=test_core_peer.new_app(), prior=[], peers=[],
                     posted=False, signaled=False, closed=False, contexts=[], releases=[], ready=ready, whole=whole,
                     case_evidence=test_lifecycle.new_case_evidence(), deadlines=[])
        state['children'].append(child)
        app = child['app']

        def connect(case, number, case_deadline, whole_deadline):
            require(case == selected[len(child['prior'])] and not child['signaled'], 'connect ordering differs')
            args = dict(app=app, prior=tuple(child['prior']), now=clock(), clock=clock)
            if case in ('shutdown_idle', 'shutdown_active'):
                peer = test_shutdown.new_peer(case, **args)
            else:
                args['final'] = case == selected[-1]
                peer = ordinary_peer(case, number, child['case_evidence'], args)
            child['peers'].append(peer)
            child['deadlines'].append((case, number, case_deadline, whole_deadline, clock()))
            event('connect', child, fact=peer['connection'], deadline=case_deadline)
            return peer['connection']

        def preconditions(context):
            require(tuple(child['prior']) == context['selected_before'], 'prior was not earned')
            facts = dict(client_open=True, prior_complete=True) if selected[-1] == 'shutdown_active' else dict(client_open=True, fresh_application=True)
            event('preconditions', child, context, facts, context['stage']['case_deadline'])
            return facts

        def close(context, deadline):
            require(not child['signaled'], 'close after signal')
            child['contexts'].append(context)
            child['releases'].append(local_summary(context))
            child['peers'][-1]['state']['closed'] = True
            child['closed'] = True
            child['prior'].append(context['stage']['case'])
            facts = dict(method='close', client_closed=True, close='normal')
            event('close', child, context, facts, deadline)
            return facts

        def disconnect_close(context):
            require(context['raw']['closing']['phase'] == 'pre_unwrap', 'strict close phase missing')
            child['contexts'].append(context)
            child['releases'].append(local_summary(context))
            child['peers'][-1]['state']['closed'] = True
            app['records']['disconnect'] = test_lifecycle.terminal('disconnect')
            app['records']['disconnect'].update(stale_resume=0, stale_cancel=0)
            facts = dict(method='ssl_unwrap', tls_shutdown='success', tcp_eof=True, trailing_bytes=0, close='normal')
            event('disconnect_close', child, context, facts, context['stage']['case_deadline'])
            return facts

        def signal(context, deadline):
            active = selected[-1] == 'shutdown_active'
            require(context['stage']['final_complete'] and len([item for item in state['collections'] if item[0] == index]) == 1,
                    'signal before one final collection')
            require(not active or not context['completed'] and not context['stage']['primary_complete'] and
                    set(context['records']) == {3} and context['request']['connection_debt'] == 32,
                    'active held request lost before signal')
            require(active or child['closed'], 'idle signal before close')
            require(not child['peers'][-1]['state']['pending'] and not child['peers'][-1]['state']['buffer'], 'wire residue before signal')
            child['signaled'] = True
            child['peers'][-1]['state']['signal'] = True
            if active:
                app['records']['shutdown_active'].update(cancels=1, active=False, paused=False, reason='shutdown')
            facts = dict(signal='SIGTERM', owned_identity=True, watcher_installed=True, client_open=active)
            event('signal', child, context, facts, deadline)
            return facts

        def termination(context, deadline):
            require(context['stage']['signaled'] and context['raw']['closing']['phase'] == 'post_signal', 'active termination phase differs')
            child['contexts'].append(context)
            child['releases'].append(local_summary(context))
            facts = dict(phase='post_signal', outcome=outcome, primary_response=False, frames_valid=True, trailing_bytes=0)
            event('termination', child, context, facts, deadline)
            return facts

        def process(context, deadline):
            require(child['signaled'], 'process before signal')
            facts = dict(exit_code=0, reaped=True, forced=False, run_ok=True, deinit_ok=True, key_removed=True)
            event('process', child, context, facts, deadline)
            return facts

        def post(context, deadline):
            facts = dict(records=copy.deepcopy(app['records']), metrics=test_core_peer.metrics(app),
                         outputs=copy.deepcopy(app['outputs']), binding=model.default_binding() if app['binding'] is None else dict(app['binding']))
            event('post', child, context, facts, deadline)
            child['posted'] = True
            return facts

        descriptor = dict(identity=(identity, index), ready=True, fresh_application=True, connect=connect,
                          signal=signal, process=process, post=post)
        if any(case != 'shutdown_active' for case in selected):
            descriptor['close'] = close
        if 'disconnect' in selected:
            descriptor['disconnect_close'] = disconnect_close
        if any(case in ('shutdown_idle', 'shutdown_active') for case in selected):
            descriptor['preconditions'] = preconditions
        if 'shutdown_active' in selected:
            descriptor['termination'] = termination
        event('factory', child, fact=descriptor, deadline=ready)
        return descriptor

    original_collection, original_case = adapter.final_collection, adapter.run_case

    def collection(context, receive, **kwargs):
        index = len(state['children']) - 1
        child = state['children'][index]
        require(not child['signaled'] and context['selected_before'] == child['selection'][:-1], 'collection after signal or wrong selection')
        require(context['stage']['final_registered'] == 0, 'duplicate final collection')
        result = original_collection(context, receive, **kwargs)
        capture = context['final_observations'] if result is None else result
        state['collections'].append((index, copy.deepcopy(capture), local_summary(context)))
        event('collected', child, context)
        return result

    def dispatch(context, receive, **kwargs):
        child = state['children'][-1]
        state['dispatches'].append(context['stage']['case'])
        result = original_case(context, receive, **kwargs)
        event('dispatched', child, context if result is None else result)
        return result

    with mock.patch.object(adapter, 'final_collection', collection), mock.patch.object(adapter, 'run_case', dispatch):
        result = coordinator.run(selection, run_identity='shutdown', now=1, units_per_second=units,
                                 clock=clock, child_factory=factory)
    return result, state


def ordinary_peer(case, number, evidence, args):
    if case in ('reuse', 'disconnect'):
        return test_lifecycle.new_peer(case, number, case_evidence=evidence, **args)
    if case in ('producer_reuse', 'output_pressure_ready', 'output_pressure_window'):
        return test_producer_pressure.new_peer(case, **args)
    if case in ('stream_file', 'early_final_order'):
        return test_file_early.new_peer(case, **args)
    return test_core_peer.new_peer(case, **args)


def local_summary(context):
    return dict(settings=context['request']['client_settings'], informationals=context['trace'].get('InformationalResponseReceived', 0),
                receive_bytes=context['stage']['bytes'], receive_calls=context['stage']['reads'],
                connection_debt=context['request']['connection_debt'], stream_debt_total=context['request']['stream_debt_total'])


def check_success(selection):
    result, state = run_selection(selection)
    plan = catalogue.child_plan(selection)
    require(state['dispatches'] == list(selection) and len(state['collections']) == len(plan), 'actual schedule differs')
    heads = sum(catalogue.case_budget(case)['heads'] for case in selection)
    small = sum(catalogue.case_budget(case)['small'] for case in selection)
    ordinary_final = sum(part[-1] not in ('shutdown_idle', 'shutdown_active') for part in plan)
    expected = dict(heads=heads + 68 * ordinary_final, small=small + 68 * ordinary_final,
                    request_flow=sum(catalogue.case_budget(case)['request_flow'] for case in selection),
                    connections=len(selection) + int('disconnect' in selection), final_collections=len(plan),
                    settings=sum(catalogue.case_budget(case)['settings'] for case in selection),
                    informationals=sum(catalogue.case_budget(case)['informationals'] for case in selection),
                    incoming_resets=sum(catalogue.case_budget(case)['resets'] for case in selection))
    require(all(result['totals'][key] == value for key, value in expected.items()), 'actual aggregate differs')
    require(sum(item['app']['heads'] for item in state['children']) == expected['heads'], 'peer heads differ')
    for index, child in enumerate(result['children']):
        observed = state['children'][index]
        require(child['identity'] == ('shutdown', index) and child['selection'] == plan[index], 'child scope differs')
        require(child['final_observations']['records'] == state['collections'][index][1]['records'], 'private parsed before capture differs')
        require(child['counts']['connections'] == len(child['connections']), 'summary count differs')
        check_connection_summaries(child, observed)
        require([item['ordinal'] for item in child['connections']] == list(range(1, len(child['connections']) + 1)), 'ordinals differ')
        require(child['counts']['receive_bytes'] == sum(item['receive_bytes'] for item in child['connections']) and
                child['counts']['receive_calls'] == sum(item['receive_calls'] for item in child['connections']), 'local read totals differ')
        require(child['counts']['settings'] == sum(item['settings'] for item in child['connections']), 'local settings differ')
        active = child['selection'][-1] == 'shutdown_active'
        require(set(child['teardown']) == ({'signal', 'termination', 'transport', 'process', 'post'} if active else {'close', 'signal', 'process', 'post'}), 'teardown schema differs')
        require(child['connections'][-1]['release'] == child['teardown']['termination' if active else 'close'], 'release differs')
        require(child['final_observations']['binding'] == observed['app']['binding'], 'binding lost')
        for tag in set(child['selection']) & set(model.PRODUCERS + ('stream_file',)):
            require(child['final_observations']['outputs'][tag] == observed['app']['outputs'][tag], 'parsed output lost')
    frozen = json.dumps(result, sort_keys=True)
    for facts in state['facts']:
        facts.clear()
    for child in state['children']:
        child['app']['records'].clear()
        child['app']['outputs'].clear()
    require(json.dumps(result, sort_keys=True) == frozen, 'result aliases callback graph')
    print('actual selection', ','.join(selection), json.dumps(expected, sort_keys=True))


def check_connection_summaries(child, observed):
    fields = {'case', 'case_connection', 'ordinal', 'case_deadline', 'settings', 'informationals',
              'receive_bytes', 'receive_calls', 'connection_debt', 'stream_debt_total', 'release'}
    require(len(observed['contexts']) == len(child['connections']), 'actual connection scope count differs')
    for index, summary in enumerate(child['connections']):
        require(set(summary) == fields and all(summary[key] == value for key, value in observed['releases'][index].items()),
                'exact local summary differs from pre-release observation')
        connection = observed['deadlines'][index]
        require((summary['case'], summary['case_connection'], summary['case_deadline']) == connection[:3],
                'summary case/deadline identity differs')
        for earlier in observed['contexts'][:index]:
            require(all(earlier[key] is not observed['contexts'][index][key] for key in ('raw', 'request', 'credit', 'protocol')),
                    'fresh connection shares parser or ledgers')


def check_factory_boundaries():
    for selection in (('shutdown_idle',), ('shutdown_active',), catalogue.CASES, None):
        calls = []

        def factory(*args):
            calls.append(args)
            raise RuntimeError('factory boundary')

        kwargs = dict(run_identity='shutdown', now=1, units_per_second=1, clock=lambda: 2, child_factory=factory)
        try:
            if selection is None:
                coordinator.run(**kwargs)
            else:
                coordinator.run(selection, **kwargs)
        except RuntimeError as error:
            expected = catalogue.child_plan(catalogue.CASES if selection is None else selection)[0]
            require(str(error) == 'factory boundary' and len(calls) == 1 and calls[0][2] == expected, 'factory boundary differs')
        else:
            raise ValueError('factory boundary silently succeeded')
    print('idle, active, explicit all40 and omitted default reach factory; no aggregate execution claimed')


def reject_selection(selection, control, message=None):
    try:
        run_selection(selection, control)
    except ValueError as error:
        require(message is None or message in str(error), 'wrong rejection: ' + str(error))
        return
    raise ValueError('invalid shutdown schedule silently succeeded')


def check_descriptors():
    selections = (('shutdown_active',), ('shutdown_idle',), ('ready_buffered', 'shutdown_active'),
                  ('shutdown_idle', 'ready_buffered'), ('disconnect', 'shutdown_active'))
    checked = 0
    for selection in selections:
        fields = {'identity', 'ready', 'fresh_application', 'connect', 'signal', 'process', 'post', 'preconditions'}
        if selection != ('shutdown_active',):
            fields.add('close')
        if 'shutdown_active' in selection:
            fields.add('termination')
        if 'disconnect' in selection:
            fields.add('disconnect_close')
        recipes = [('missing', key) for key in fields] + [('extra', 'extra')]
        recipes += [('callable', key) for key in fields - {'identity', 'ready', 'fresh_application'}]
        for mode, key in recipes:
            seen = []

            def corrupt(phase, state, child, context, fact, deadline):
                seen.append(phase)
                if phase != 'factory':
                    return
                if mode == 'missing':
                    fact.pop(key)
                else:
                    fact[key] = None

            reject_selection(selection, corrupt, 'child descriptor')
            require(seen == ['factory'], 'bad descriptor reached connection')
            checked += 1
    print('exact shutdown descriptors rejected before connect:', checked)


def check_fact_corruptions():
    schemas = dict(preconditions=dict(client_open=True, prior_complete=True),
                   close=dict(method='close', client_closed=True, close='normal'),
                   signal=dict(signal='SIGTERM', owned_identity=True, watcher_installed=True, client_open=True),
                   termination=dict(phase='post_signal', outcome='eof', primary_response=False, frames_valid=True, trailing_bytes=0),
                   process=dict(exit_code=0, reaped=True, forced=False, run_ok=True, deinit_ok=True, key_removed=True))
    checked = 0
    for phase, schema in schemas.items():
        selection = ('shutdown_idle',) if phase == 'close' else ('shutdown_active',)
        recipes = [(key, None) for key in schema] + [('extra', True)]
        recipes += [(key, 1 if type(value) is bool and value else 0 if type(value) is bool else False if type(value) is int else 'wrong')
                    for key, value in schema.items()]
        for key, invalid in recipes:
            seen = []

            def corrupt(actual, state, child, context, fact, deadline):
                seen.append(actual)
                if actual == phase:
                    fact[key] = invalid

            reject_selection(selection, corrupt)
            require(seen[-1] == phase, 'invalid fact reached a later exposed hook')
            checked += 1
    for selection in (('shutdown_idle',), ('shutdown_active',)):
        phases = ('preconditions', 'signal', 'process', 'post', 'close' if selection[0] == 'shutdown_idle' else 'termination')
        for phase in phases:
            for invalid in (None, [], True):
                seen = []

                def replace(actual, state, child, context, fact, deadline):
                    seen.append(actual)
                    if actual == 'factory':
                        original = fact[phase]

                        def bad(*args):
                            original(*args)
                            return invalid

                        fact[phase] = bad

                reject_selection(selection, replace)
                require(seen[-1] == phase, 'non-dict fact advanced teardown')
                checked += 1
    print('typed canonical teardown corruptions rejected:', checked)


def check_hook_time():
    checked = 0
    for selection in (('shutdown_idle', 'ready_buffered'), ('shutdown_active',)):
        phases = ('preconditions', 'signal', 'process', 'post', 'close' if selection[0] == 'shutdown_idle' else 'termination')
        for phase in phases:
            for mode in ('equal', 'expired', 'rollback', 'bool'):
                seen = []

                def corrupt(actual, state, child, context, fact, deadline):
                    seen.append((actual, child['index']))
                    if actual != phase or child['index'] != 0:
                        return
                    state['clock'] = {'equal': deadline, 'expired': deadline + 1, 'rollback': 1, 'bool': True}[mode]
                    context['now'] = 0
                    context['clock'] = lambda: 2
                    context['stage']['case_deadline'] = 9999999
                    context['stage']['whole_deadline'] = 9999999

                reject_selection(selection, corrupt, 'monotonic time')
                require(seen[-1] == (phase, 0), 'expired hook reached next hook/child')
                checked += 1
    print('private clock equality/expiry/rollback/types across shutdown hooks:', checked)


def check_valid_time_and_counters():
    seen = []

    def mutate(phase, state, child, context, fact, deadline):
        if context is None or phase in ('collected', 'dispatched'):
            return
        require(context['clock']() == state['clock'] and context['now'] == state['clock'], 'forged time reached next hook')
        require(context['stage']['whole_deadline'] == 900001 and context['stage']['case_deadline'] == child['deadlines'][-1][2],
                'forged deadlines reached next hook')
        seen.append((phase, child['index'], deadline))
        context['now'] = 0
        context['clock'] = lambda: 9999999
        context['stage']['case_deadline'] = 9999999
        context['stage']['whole_deadline'] = 9999999
        if phase != 'preconditions':
            context['stage']['case_state']['heads'] = 999
            context['stage']['case_state']['small'] = 999
            context['stage']['bytes'] = 999
            context['stage']['reads'] = 999
            context['request']['client_settings'] = 999
        state['clock'] += 1

    result, state = run_selection(('shutdown_idle', 'shutdown_active'), mutate)
    require((result['totals']['heads'], result['totals']['small'], result['totals']['settings']) == (140, 139, 2), 'teardown mutation changed counts')
    first, second = result['children']
    require(first['deadlines']['grace'] == 15003 and second['deadlines']['ready'] == 15007 and
            second['connections'][0]['case_deadline'] == 30007 and second['deadlines']['whole'] == 900001,
            'child handoff reset whole or ignored final callback time')
    require(first['connections'][0]['receive_bytes'] == state['collections'][0][2]['receive_bytes'], 'local counts captured after mutation')
    print('valid callback mutation preserves original time, sealed counts, local summaries and next-child handoff')


def check_callback_errors():
    for selection in (('shutdown_idle', 'ready_buffered'), ('shutdown_active',)):
        phases = ('preconditions', 'signal', 'process', 'post', 'close' if selection[0] == 'shutdown_idle' else 'termination')
        for phase in phases:
            original = RuntimeError('supplied ' + phase)
            seen = []

            def fail(actual, state, child, context, fact, deadline):
                seen.append((actual, child['index']))
                if actual == phase:
                    raise original

            try:
                run_selection(selection, fail)
            except RuntimeError as error:
                require(error is original and seen[-1] == (phase, 0), 'callback exception replaced or advanced')
            else:
                raise ValueError('callback failure succeeded')
    print('original shutdown callback exceptions preserved')


def check_private_facts():
    aliases = []

    def mutate(phase, state, child, context, fact, deadline):
        if phase == 'factory':
            aliases.append(fact)
        if phase == 'preconditions':
            aliases[0]['signal'] = None
        if phase == 'post':
            for earlier in state['facts'][:-1]:
                earlier.clear()
            context['output_observations'] = {}
            context['output_binding'] = None
        if phase in ('close', 'signal', 'termination', 'process', 'post'):
            require('final_observations' not in context and 'shutdown_observations' not in context,
                    'handler private before facts exposed')

    result, state = run_selection(('shutdown_active',), mutate)
    require(result['children'][0]['teardown']['signal']['client_open'] is True and
            result['children'][0]['teardown']['termination']['outcome'] == 'eof', 'earlier callback fact alias leaked')
    for mode in ('record', 'output', 'binding'):
        def forge(phase, state, child, context, fact, deadline):
            if phase != 'post':
                return
            if mode == 'record':
                fact['records']['shutdown_active']['max_span'] = 7
            elif mode == 'output':
                fact['outputs']['producer_reuse']['checks'] += 1
                context['output_observations']['producer_reuse']['checks'] += 1
            else:
                fact['binding']['binding_generation'] += 1
                fact['outputs']['producer_reuse']['binding_generation'] += 1
                context['output_binding']['binding_generation'] += 1
                context['output_observations']['producer_reuse']['binding_generation'] += 1

        reject_selection(('producer_reuse', 'shutdown_active'), forge)
    print('private handler before records, actual outputs/binding and copied fact aliases retained')


def check_no_late_wire():
    for case in ('shutdown_idle', 'shutdown_active'):
        for operation in ('observe', 'collection'):
            seen = []

            def late(phase, state, child, context, fact, deadline):
                if phase != 'signal':
                    return
                seen.append(phase)
                if operation == 'observe':
                    adapter.observe(context, b'x', state['clock'])
                else:
                    adapter.final_collection(context, lambda: (b'x', state['clock']))

            reject_selection((case,), late)
            require(seen == ['signal'], 'late operation did not exercise signal')
    result, state = run_selection(('shutdown_active',), outcome='tls_eof')
    require(result['children'][0]['teardown']['transport']['outcome'] == 'tls_eof', 'canonical transport outcome lost')
    print('late wire and duplicate final rejected; canonical tls_eof accepted')


def check_idle_handoff_expiry():
    for mode in ('rollback', 'equal'):
        seen = []

        def corrupt(phase, state, child, context, fact, deadline):
            seen.append((phase, child['index']))
            if phase == 'post' and child['index'] == 0:
                state['clock'] = 10
            if phase == 'factory' and child['index'] == 1:
                require(deadline == 15010 and child['whole'] == 900001, 'handoff deadline differs')
                state['clock'] = 9 if mode == 'rollback' else deadline

        reject_selection(('shutdown_idle', 'ready_buffered'), corrupt, 'monotonic time')
        require(seen[-1] == ('factory', 1), 'main ready failure connected')
    print('idle-main actual last callback handoff and ready equality/rollback rejected')


def check_terminal_residue():
    for selection, phase in ((('shutdown_idle', 'ready_buffered'), 'close'),
                             (('shutdown_active',), 'post')):
        seen = []

        def corrupt(actual, state, child, context, fact, deadline):
            seen.append((actual, child['index']))
            if actual == phase and child['index'] == 0:
                context['raw']['header'].extend(b'x')

        reject_selection(selection, corrupt, 'not quiescent')
        require(('factory', 1) not in seen, 'residue reached later child')
    print('post-teardown parser residue stops before later child')


def check_retention_and_children():
    def corrupt_close(phase, state, child, context, fact, deadline):
        if phase == 'close' and context['stage']['case'] == 'producer_reuse':
            context['output_observations'].clear()
            context.pop('output_binding')

    result, state = run_selection(('shutdown_idle', 'producer_reuse', 'disconnect', 'shutdown_active'), corrupt_close)
    idle, main = result['children']
    require(state['children'][0]['app'] is not state['children'][1]['app'] and
            idle['final_observations']['binding'] is None and main['final_observations']['binding'] == state['children'][1]['app']['binding'],
            'child retained binding leaked or was lost')
    summaries = main['connections']
    require([item['case_connection'] for item in summaries] == [1, 1, 2, 1] and
            summaries[1]['case_deadline'] == summaries[2]['case_deadline'] and summaries[1]['connection_debt'] == 32,
            'disconnect local identity/deadline/debt lost')
    for case, field in (('producer_reuse', 'output_binding'), ('stream_file', 'output_observations')):
        seen = []

        def remove(phase, state, child, context, fact, deadline):
            if phase == 'connect':
                seen.append(child['deadlines'][-1][0])
            if phase == 'dispatched' and context['stage']['case'] == case:
                context.pop(field)

        reject_selection((case, 'shutdown_active'), remove)
        require(seen == [case], 'missing retained observation reached active case')
    result, state = run_selection(('shutdown_idle', 'shutdown_active'), start=900000)
    require(all(child['deadlines'] == dict(ready=900001, case=900001, whole=900001, grace=900001)
                for child in result['children']), 'whole-clipped child deadline reset')
    print('independent idle/main apps, retained producer/file losses, disconnect and whole clipping checked')


def check_idle_and_strict_facts():
    groups = ((('shutdown_idle',), 'preconditions', ('client_open', 'fresh_application')),
              (('disconnect', 'shutdown_active'), 'disconnect_close', ('method', 'tls_shutdown', 'tcp_eof', 'trailing_bytes', 'close')))
    for selection, phase, keys in groups:
        for key in keys:
            for mode in ('missing', 'wrong_type'):
                seen = []

                def corrupt(actual, state, child, context, fact, deadline):
                    seen.append(actual)
                    if actual != phase:
                        return
                    if mode == 'missing':
                        fact.pop(key)
                    else:
                        value = fact[key]
                        fact[key] = 1 if type(value) is bool else False if type(value) is int else b'wrong'

                reject_selection(selection, corrupt)
                require(seen[-1] == phase, 'invalid strict/idle fact advanced hooks')
    print('idle freshness and every strict-close field reject missing/wrong types')


def check_old_child_mutation():
    held = []

    def mutate(phase, state, child, context, fact, deadline):
        if phase == 'post' and child['index'] == 0:
            held.append(context)
        if phase == 'factory' and child['index'] == 1:
            old = held[0]
            old['now'] = 0
            old['clock'] = lambda: 9999999
            old['stage']['case_deadline'] = 9999999
            old['stage']['case_state']['heads'] = 999
            old['final_observations']['records']['empty_headers']['middleware'] = 999
            old['shutdown_observations']['after']['metrics']['buffered_middleware'] = 999

    result, state = run_selection(('shutdown_idle', 'shutdown_active'), mutate)
    require(result['totals']['heads'] == 140 and result['children'][0]['final_observations']['records']['empty_headers']['middleware'] == 0 and
            result['children'][0]['teardown']['post']['metrics']['buffered_middleware'] == 69 and
            result['children'][1]['deadlines']['case'] == 30002, 'old child graph mutation leaked into result or main')
    print('old idle context mutation cannot change captured child or fresh main')


def check_final_state_corruption(mode):
    active = mode.startswith('active_')
    selection = ('shutdown_active',) if active else ('shutdown_idle', 'ready_buffered')
    target = 1 if mode.startswith('ordinary_') else 0
    seen, held = [], []

    def corrupt(phase, state, child, context, fact, deadline):
        seen.append((phase, child['index']))
        if phase != 'post' or child['index'] != target:
            return
        held.append(context)
        if mode.endswith('response_ledger'):
            context['credit']['streams'][999] = {'residue': True}
        if mode == 'ordinary_parser':
            context['raw']['header'].extend(b'x')
        if mode in ('active_request_closed', 'active_both_closed'):
            context['request']['transport_closed'] = False
        if mode in ('active_raw_closed', 'active_both_closed'):
            context['raw']['closed'] = False

    try:
        run_selection(selection, corrupt)
    except ValueError as error:
        expected = 'active transport not closed' if active else 'not quiescent'
        final_event = 'post' if mode.startswith('ordinary_') else 'dispatched'
        require(expected in str(error) and len(held) == 1 and seen[-1] == (final_event, target),
                'final-state corruption failed at wrong boundary: ' + str(error))
        if mode == 'idle_response_ledger':
            require(('factory', 1) not in seen, 'idle residue reached main factory')
        current = held[0]
        require(not mode.endswith('response_ledger') or current['credit']['streams'][999] == {'residue': True},
                'response ledger was cleared to pass final validation')
        require(mode != 'ordinary_parser' or bytes(current['raw']['header']) == b'x', 'parser residue was cleared')
        require(mode not in ('active_request_closed', 'active_both_closed') or current['request']['transport_closed'] is False,
                'request terminal flag was reconstructed')
        require(mode not in ('active_raw_closed', 'active_both_closed') or current['raw']['closed'] is False,
                'raw terminal flag was reconstructed')
        print('final-state corruption rejected:', mode)
        return
    raise ValueError('final-state corruption accepted: ' + mode)


def check_final_state_healthy():
    for selection in (('shutdown_idle', 'ready_buffered'), ('shutdown_active',)):
        held = []

        def capture(phase, state, child, context, fact, deadline):
            if phase == 'post':
                held.append(context)

        result, state = run_selection(selection, capture)
        require(len(held) == len(result['children']), 'healthy final child count differs')
        for context, child in zip(held, result['children']):
            active = child['selection'][-1] == 'shutdown_active'
            expected_debt = 32 if active else 257 if child['selection'][-1] == 'ready_buffered' else 0
            require(context['request']['transport_closed'] is active and context['raw']['closed'] is active,
                    'normal-close path invented active transport flags')
            require(not context['credit']['streams'] and context['request']['connection_debt'] == expected_debt and
                    context['request']['stream_debt_total'] == expected_debt and
                    child['connections'][-1]['connection_debt'] == expected_debt,
                    'healthy closed request debt or response ledger differs')
    print('healthy idle/ordinary/active preserve canonical flags and legitimate 0/257/32 request debt')


def main():
    check_final_state_healthy()
    for mode in ('idle_response_ledger', 'active_request_closed', 'active_raw_closed', 'active_both_closed',
                 'ordinary_parser', 'ordinary_response_ledger'):
        check_final_state_corruption(mode)
    check_idle_and_strict_facts()
    check_old_child_mutation()
    check_terminal_residue()
    check_retention_and_children()
    check_factory_boundaries()
    check_descriptors()
    check_fact_corruptions()
    check_hook_time()
    check_valid_time_and_counters()
    check_callback_errors()
    check_private_facts()
    check_no_late_wire()
    check_idle_handoff_expiry()
    for selection in (('shutdown_idle',), ('shutdown_idle', 'ready_buffered'), ('shutdown_active',),
                      ('ready_buffered', 'shutdown_active'), ('producer_reuse', 'shutdown_active'),
                      ('shutdown_idle', 'producer_reuse', 'disconnect', 'shutdown_active'),
                      ('shutdown_idle', 'producer_reuse', 'ready_buffered'), ('stream_file', 'shutdown_active')):
        check_success(selection)


if __name__ == '__main__':
    main()
