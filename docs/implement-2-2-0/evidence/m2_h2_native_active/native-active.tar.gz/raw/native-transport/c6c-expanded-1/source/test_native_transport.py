"""Focused source-only C6a and C6b checks over injected operations and canonical codecs."""
import json
import sys
import ssl
import test_lifecycle
import copy
import model
import test_shutdown
import test_all40_descriptors as descriptors
import wire
from functools import partial
from unittest import mock
import adapter
import coordinator
import h2_client
import native_closing
import native_transport as transport
import test_core_peer
import test_wire_oracle as oracle


def require(value, message):
    if not value:
        raise RuntimeError(message)


def raises(callback, kind=ValueError, exact=None):
    try:
        callback()
    except kind as error:
        require(exact is None or error is exact, 'primary exception replaced')
        return error
    raise RuntimeError('missing rejection')


def initial_settings():
    payload = b"".join(key.to_bytes(2, "big") + value.to_bytes(4, "big") for key, value in
                       ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    return test_core_peer.frame(4, 0, 0, payload) + test_core_peer.frame(4, 1, 0, b"")


def fixture(selection=('ready_buffered',), tick=3):
    script = dict(tick=tick, events=[], failures={}, responses=[initial_settings()],
                  raw=object(), tls=object(), unwrapped=object(), sent=[], timeout=[], state=None, results={}, tick_after={}, clock_calls=0, clock_steps={})
    child = dict(identity=('transport_test', 0), selection=selection, ready_start=1, ready_at=2,
                 ready_deadline=15000000001, whole_start=0, whole_deadline=900000000000,
                 pid=123, start_identity='start-1', listener=('127.0.0.1', 4433),
                 address=('127.0.0.1', 4433), certificate_sha256='a' * 64)

    def clock():
        script["clock_calls"] += 1
        step = script["clock_steps"].get(script["clock_calls"])
        if isinstance(step, BaseException):
            raise step
        if step is not None:
            return step
        error = script['failures'].get('clock')
        if error is not None:
            raise error
        return script['tick']

    def operation(name, *args):
        script['events'].append((name, args))
        error = script['failures'].get(name)
        if error is not None:
            raise error
        result = script['results'][name] if name in script['results'] else perform(script, child, name, args)
        if name in script['tick_after']:
            script['tick'] = script['tick_after'][name]
        return result

    ops = {name: partial(operation, name) for name in
           ('dial', 'wrap', 'inspect', 'set_timeout', 'send', 'recv', 'close', 'ownership', 'capture')}
    ops['new_protocol'] = h2_client.new_protocol
    if 'disconnect' in selection:
        ops['unwrap'] = partial(operation, 'unwrap')
    return script, child, clock, ops


def perform(script, child, name, args):
    if name == 'dial':
        return script['raw']
    if name == 'wrap':
        require(args[0] is script['raw'] and args[1:3] == ('localhost', False), 'TLS policy arguments')
        return script['tls']
    if name == 'unwrap':
        script['raw_phase'] = True
        return script['unwrapped']
    if name == 'inspect':
        return dict(tls='TLSv1.3', alpn='h2', hostname='localhost', check_hostname=True,
                    certificate_verified=True, certificate_sha256=child['certificate_sha256'], suppress_ragged_eofs=False)
    if name == 'ownership':
        return dict(pid=child['pid'], running=True, start_identity=child['start_identity'], listeners=(child['listener'],))
    if name == 'capture':
        return dict(overflow=False, error=None, complete=False)
    if name == 'set_timeout':
        script['timeout'].append(args[1])
    if name == 'send':
        state = script['state']
        require(state is not None and state['current']['observer']['operation'] > 0, 'unwrapped startup send')
        script['sent'].append(args[1])
    if name == 'recv':
        require(args[1] == 8192, 'receive size')
        return script['responses'].pop(0)
    return None


def opened(selection=('ready_buffered',), tick=3):
    script, child, clock, ops = fixture(selection, tick)
    state = transport.new_transport(child, clock=clock, ops=ops)
    script['state'] = state
    case = selection[0]
    connection = transport.connect(state, case, 1, tick + 30000000000, child['whole_deadline'])
    return script, state, connection


def context(state, connection):
    row = state['current']
    return adapter.open_case(row['identity'][1], connection['protocol'], connection['send'], connection['now'],
                             row['case_deadline'], state['child']['whole_deadline'], clock=state['clock'])


def shape_and_startup():
    script, state, connection = opened()
    coordinator.validate_connection(connection, 3, 30000000003)
    require(not script['sent'] and all(name != 'recv' for name, args in script['events']), 'startup traffic before bind')
    current = context(state, connection)
    require(script['sent'] and state['current']['observer']['operation'] > 0, 'startup not observed')
    data, tick = connection['receive']()
    adapter.observe(current, data, tick)
    require(current['stage']['initial_settings'] == 1, 'canonical receive state absent')
    facts = transport.close(state, current, 10000000000)
    require(facts == dict(method='close', client_closed=True, close='normal'), 'close schema')
    require([args[0] for name, args in script['events'] if name == 'close'] == [script['tls']], 'wrong socket closure')
    raises(lambda: transport.close(state, current, 10000000000))


def invalid_inputs():
    mutations = (('identity', ('bad space', 0)), ('identity', ('run', True)), ('selection', ('missing',)),
                 ('selection', ('shutdown_active', 'shutdown_idle')), ('ready_at', True), ('ready_at', 15000000001),
                 ('ready_deadline', 15000000002), ('whole_deadline', 1 << 64), ('pid', True),
                 ('certificate_sha256', 'z' * 64), ('address', ('elsewhere', 4433)))
    for key, value in mutations:
        script, child, clock, ops = fixture()
        child[key] = value
        raises(lambda: transport.new_transport(child, clock=clock, ops=ops))
        require(not script['events'], 'invalid child caused effects')
    for args in (('missing', 1, 100, 900000000000), ('ready_buffered', True, 100, 900000000000),
                 ('ready_buffered', 2, 100, 900000000000), ('ready_buffered', 1, True, 900000000000),
                 ('ready_buffered', 1, 3, 900000000000), ('ready_buffered', 1, 30000000004, 900000000000),
                 ('ready_buffered', 1, 100, 900000000001)):
        script, child, clock, ops = fixture()
        state = transport.new_transport(child, clock=clock, ops=ops)
        raises(lambda: transport.connect(state, *args))
        require(not script['events'], 'invalid connection caused effects')


def late_readiness():
    script, state, connection = opened(('ready_buffered', 'async_delayed'))
    current = context(state, connection)
    transport.close(state, current, min(current['stage']['case_deadline'], current['stage']['whole_deadline']))
    script['tick'] = 20000000000
    later = transport.connect(state, 'async_delayed', 1, 50000000000, 900000000000)
    require(later['now'] == 20000000000 and len(state['history']) == 2, 'per-connection ready budget')
    require(state['child']['ready_deadline'] == 15000000001, 'readiness changed')


def active_binding():
    with mock.patch.object(oracle, 'wrap_connection', wraps=oracle.wrap_connection) as wrap:
        with mock.patch.object(native_closing, 'bind_observer', wraps=native_closing.bind_observer) as bind:
            script, state, connection = opened(('shutdown_active',), tick=20000000000)
            require(wrap.call_count == bind.call_count == 1, 'not exactly one wrap/bind')
    row, receive_state = state['current'], state['current']['receive_state']
    require(receive_state is not state and receive_state['wrapped'] is connection, 'C4 state identity')
    original = row['original']
    require(original['receive'].func is native_closing.receive_once and original['receive'].args ==
            (receive_state, receive_state['binding']), 'C4 receive partial')
    require(original['send'].func is native_closing.send_once and original['send'].args[0] is receive_state, 'C4 send partial')
    current = context(state, connection)
    data, tick = connection['receive']()
    adapter.observe(current, data, tick)
    require(receive_state['counts']['attempts'] == receive_state['counts']['boundary_returns'] == 1, 'C4 accounting')
    require(receive_state['ready'] == (0, 1, 2, 15000000001), 'C4 ready observation')
    require(receive_state['deadlines'][2] == 20000000000, 'C4 observed entry time')
    require(current['stage']['initial_settings'] == 1, 'active canonical I/O')


def clock_boundaries():
    for tick in (True, -1, 1, 100, 1 << 64):
        script, child, clock, ops = fixture()
        state = transport.new_transport(child, clock=clock, ops=ops)
        script['tick'] = tick
        raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline']))
        require(not script['events'], 'invalid entry clock caused effects')
    for operation in ('ownership', 'capture', 'dial', 'wrap', 'inspect'):
        script, child, clock, ops = fixture()
        original = ops[operation]
        def expire(*args):
            result = original(*args)
            script['tick'] = 100
            return result
        ops[operation] = expire
        state = transport.new_transport(child, clock=clock, ops=ops)
        raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline']))
        require(state['failure'] is not None and state['current']['release'] is None, 'late construction accepted')
    script, child, clock, ops = fixture()
    child.update(whole_start=transport.U64 - 10, ready_start=transport.U64 - 9, ready_at=transport.U64 - 8,
                 ready_deadline=transport.U64 - 7, whole_deadline=transport.U64)
    raises(lambda: transport.new_transport(child, clock=clock, ops=ops))
    require(not script['events'], 'overflow caused effects')


def observation_failures():
    fields = (('ownership', 'pid', 456), ('ownership', 'pid', True), ('ownership', 'running', False),
              ('ownership', 'start_identity', 'replaced'), ('ownership', 'listeners', (('127.0.0.1', 4434),)),
              ('inspect', 'tls', 'TLSv1.2'), ('inspect', 'alpn', 'http/1.1'), ('inspect', 'hostname', 'other'),
              ('inspect', 'check_hostname', False), ('inspect', 'certificate_verified', False),
              ('inspect', 'certificate_sha256', 'b' * 64), ('inspect', 'suppress_ragged_eofs', True),
              ('capture', 'overflow', True), ('capture', 'error', RuntimeError('capture')), ('capture', 'complete', 1))
    for name, key, value in fields:
        script, child, clock, ops = fixture()
        facts = perform(script, child, name, ())
        facts[key] = value
        script['results'][name] = facts
        state = transport.new_transport(child, clock=clock, ops=ops)
        raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline']))
        require(state['current']['release'] is None, 'bad observations earned success')
    script, child, clock, ops = fixture()
    script['results']['ownership'] = dict(owned=True)
    state = transport.new_transport(child, clock=clock, ops=ops)
    raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline']))


def construction_failures():
    for stage in ('ownership', 'capture', 'dial', 'wrap', 'inspect'):
        script, child, clock, ops = fixture()
        primary, secondary = RuntimeError(stage), RuntimeError('cleanup')
        script['failures'].update({stage: primary, 'close': secondary})
        state = transport.new_transport(child, clock=clock, ops=ops)
        raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline']), RuntimeError, primary)
        require(state['failure'] is primary, 'construction failure lost')
        expected = [secondary] if stage in ('wrap', 'inspect') else []
        require(state['cleanup_errors'] == expected, 'construction cleanup failure lost')
        handles = [args[0] for name, args in script['events'] if name == 'close']
        require(handles == ([script['raw']] if stage == 'wrap' else [script['tls']] if stage == 'inspect' else []), 'construction cleanup handle')
    for module, name in ((h2_client, 'new_protocol'), (oracle, 'wrap_connection'), (native_closing, 'bind_observer')):
        script, child, clock, ops = fixture(('shutdown_active',))
        primary, secondary = RuntimeError(name), RuntimeError('cleanup')
        script['failures']['close'] = secondary
        with mock.patch.object(module, name, side_effect=primary) as callback:
            ops['new_protocol'] = h2_client.new_protocol
            state = transport.new_transport(child, clock=clock, ops=ops)
            raises(lambda: transport.connect(state, 'shutdown_active', 1, 100, child['whole_deadline']), RuntimeError, primary)
        require(callback.call_count == 1 and state['failure'] is primary and state['cleanup_errors'] == [secondary], 'binding stage cleanup')
        require([args[0] for name, args in script['events'] if name == 'close'] == [script['tls']], 'bound handle cleanup')


def io_shapes_and_failures():
    for selection in (('ready_buffered',), ('shutdown_active',)):
        for value in (None, bytearray(b'x'), (b'x', 3), b'', b'x' * 8193):
            script, state, connection = opened(selection)
            script['results']['recv'] = value
            raises(connection['receive'])
            require(state['current']['observer']['failure'] is not None, 'bad receive not poisoned')
        for value in (b'', bytearray(b'x'), 'x', b'x' * 65537):
            script, state, connection = opened(selection)
            raises(lambda: connection['send'](value))
            require(not script['sent'], 'invalid send entered primitive')
        for name in ('send', 'recv', 'set_timeout', 'ownership', 'capture'):
            script, state, connection = opened(selection)
            primary, secondary = RuntimeError(name), RuntimeError('cleanup')
            script['failures'].update({name: primary, 'close': secondary})
            action = partial(connection['send'], b'x') if name == 'send' else connection['receive']
            raises(action, RuntimeError, primary)
            require(state['current']['observer']['failure'] is not None, 'I/O failure not poisoned')
            if selection == ('ready_buffered',) or name == 'send':
                require(state['failure'] is primary and state['cleanup_errors'] == [secondary], 'I/O cleanup failure identity')
    script, state, connection = opened()
    script['results']['send'] = 1
    raises(lambda: connection['send'](b'x'))
    require(state['failure'] is not None, 'short/full send shape accepted')


def active_origin_boundary():
    for name in ('recv', 'ownership', 'capture', 'set_timeout'):
        script, state, connection = opened(('shutdown_active',))
        primary = RuntimeError(name)
        script['failures'][name] = primary
        raises(connection['receive'], RuntimeError, primary)
        receive_state = state['current']['receive_state']
        require(receive_state['phase'] == 'failed', 'active ordinary failure not sticky')
        if name == 'recv':
            require(receive_state['provenance'][4] == 'recv_raised' and receive_state['provenance'][6] is primary, 'primitive origin lost')
        else:
            require(receive_state['provenance'] is None and receive_state['counts']['attempts'] == 0, 'preparation attributed to recv')
    script, state, connection = opened(('shutdown_active',))
    before = len(script['events'])
    script['tick'] = True
    raises(connection['receive'])
    require(len(script['events']) == before and state['current']['receive_state']['provenance'] is None, 'clock attributed to recv')


def close_failures():
    for stage in ('ownership', 'capture', 'close'):
        script, state, connection = opened()
        current = context(state, connection)
        primary, secondary = RuntimeError(stage), RuntimeError('close cleanup')
        script['failures'][stage] = primary
        if stage != 'close':
            script['failures']['close'] = secondary
        raises(lambda: transport.close(state, current, 100), RuntimeError, primary)
        require(state['failure'] is primary and state['current']['release'] is None, 'failed close success')
        require(state['cleanup_errors'] == [primary if stage == 'close' else secondary], 'close cleanup errors lost')
    script, state, connection = opened()
    current = context(state, connection)
    original = state['ops']['close']
    def late_close(handle):
        original(handle)
        script['tick'] = 100
    state['ops']['close'] = late_close
    raises(lambda: transport.close(state, current, 100))
    require(state['current']['closed'] and state['current']['release'] is None, 'late close receipt')
    require(sum(name == 'close' for name, args in script['events']) == 1, 'already closed handle closed twice')
    for deadline in (True, 3, 15000000004):
        script, state, connection = opened()
        current = context(state, connection)
        before = len(script['events'])
        raises(lambda: transport.close(state, current, deadline))
        require(len(script['events']) == before, 'invalid close had effects')


def poisoned_observer_blocks_io():
    script, state, connection = opened()
    state['current']['observer']['failure'] = ('external_poison', 'receive', 0, 0, None)
    before = len(script['events'])
    raises(connection['receive'])
    require(all(name == 'close' for name, args in script['events'][before:]), 'poisoned observer entered I/O')



def residual_and_postoperation_time():
    script, state, connection = opened()
    context(state, connection)
    require(all(value == 30.0 for value in script['timeout']), 'timeout conversion changed units')
    for selection in (('ready_buffered',), ('shutdown_active',)):
        for name in ('send', 'recv', 'set_timeout'):
            script, state, connection = opened(selection)
            script['tick_after'][name] = state['current']['case_deadline']
            action = partial(connection['send'], b'x') if name == 'send' else connection['receive']
            raises(action)
            require(state['current']['observer']['failure'] is not None, 'expired operation accepted')
    script, child, clock, ops = fixture(tick=99)
    state = transport.new_transport(child, clock=clock, ops=ops)
    script['state'] = state
    connection = transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline'])
    connection['receive']()
    require(script['timeout'] == [1e-9], 'one-ns residual lost')


def successful_cleanup_and_bounds():
    for stage in ('wrap', 'inspect'):
        script, child, clock, ops = fixture()
        primary = RuntimeError(stage)
        script['failures'][stage] = primary
        state = transport.new_transport(child, clock=clock, ops=ops)
        raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline']), RuntimeError, primary)
        require(state['current']['closed'] and not state['cleanup_errors'] and state['current']['release'] is None, 'cleanup fabricated close facts')
    script, child, clock, ops = fixture()
    state = transport.new_transport(child, clock=clock, ops=ops)
    state['history'].extend([None] * 41)
    raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline']))
    require(not script['events'], 'history bound allowed effects')
    script, state, connection = opened()
    before = len(script['events'])
    raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, 900000000000))
    require(len(script['events']) == before, 'duplicate connect caused effects')
    for name in ('close', 'set_timeout', 'send'):
        script, state, connection = opened()
        script['results'][name] = True
        action = partial(transport.close, state, context(state, connection), 100) if name == 'close' else partial(connection['send'], b'x')
        raises(action)
        require(state['current']['release'] is None, 'invalid operation result earned receipt')



def close_after_send_clock_advance():
    script, state, connection = opened()
    script['tick_after']['send'] = 4
    current = context(state, connection)
    require(current['now'] == 3 and state['now'] == 4, 'clock advancement fixture')
    facts = transport.close(state, current, 100)
    require(facts == dict(method='close', client_closed=True, close='normal') and state['now'] == 4,
            'valid transport clock advance rejected or rewound')



def canonical_intermediate_close():
    script, child, clock, ops = fixture(('ready_buffered', 'async_delayed'))
    observed = dict(state=None, peer=None, close_deadline=None, second=False)
    reached_second = RuntimeError('canonical second connection reached')

    def connect_case(case, number, case_deadline, whole_deadline):
        if case == 'async_delayed':
            observed['second'] = True
            raise reached_second
        peer = test_core_peer.new_peer(case, app=test_core_peer.new_app(), prior=(), now=clock(), clock=clock)
        observed['peer'] = peer
        ops_send = observed['state']['ops']['send']
        def send(handle, data):
            ops_send(handle, data)
            return peer['connection']['send'](data)
        observed['state']['ops']['send'] = send
        observed['state']['ops']['recv'] = lambda handle, size: peer['connection']['receive']()[0]
        return transport.connect(observed['state'], case, number, case_deadline, whole_deadline)

    def close_case(current, deadline):
        observed['close_deadline'] = deadline
        require(current['shutdown_boundary'] is True and deadline == min(current['stage']['case_deadline'],
                current['stage']['whole_deadline']), 'canonical intermediate-close boundary')
        return transport.close(observed['state'], current, deadline)

    def unexpected_final_hook(*args):
        raise RuntimeError('final hook before second connection')

    def child_factory(run, index, selection, ready, whole):
        child.update(identity=(run, index), selection=selection, ready_start=clock(), ready_at=clock(),
                     ready_deadline=ready, whole_deadline=whole)
        observed['state'] = transport.new_transport(child, clock=clock, ops=ops)
        script['state'] = observed['state']
        return dict(identity=(run, index), ready=True, fresh_application=True, connect=connect_case,
                    close=close_case, signal=unexpected_final_hook, process=unexpected_final_hook, post=unexpected_final_hook)

    raises(lambda: coordinator.run(child['selection'], run_identity='transport_test', now=0,
           units_per_second=transport.UNITS, clock=clock, child_factory=child_factory), RuntimeError, reached_second)
    require(observed['second'] and observed['close_deadline'] == 30000000003, 'original intermediate deadline changed')
    require([args[0] for name, args in script['events'] if name == 'close'] == [script['tls']], 'intermediate socket not closed')
    require(observed['state']['current']['release'] == dict(method='close', client_closed=True, close='normal'), 'intermediate close facts')





def canonical_disconnect(action=None, *, binder='native', expected_error=None):
    script, child, clock, ops = fixture(('disconnect',))
    observed = dict(state=None, connection=None, context=None, replacement=None)
    boundary = RuntimeError('canonical disconnect boundary reached')
    replacement = RuntimeError('canonical replacement connection reached')
    app = test_core_peer.new_app()
    evidence = test_lifecycle.new_case_evidence()

    def connect_case(case, number, case_deadline, whole_deadline):
        state = observed['state']
        if number == 2:
            observed['replacement'] = transport.connect(state, case, number, case_deadline, whole_deadline)
            raise replacement
        peer = test_lifecycle.new_peer(case, number, app=app, prior=(), now=clock(), clock=clock,
                                       case_evidence=evidence, final=True)
        original_send, original_recv = state['ops']['send'], state['ops']['recv']
        def send(handle, data):
            original_send(handle, data)
            return peer['connection']['send'](data)
        def receive(handle, size):
            if script.get('raw_phase'):
                return original_recv(handle, size)
            script['events'].append(('recv', (handle, size)))
            return peer['connection']['receive']()[0]
        state['ops'].update(send=send, recv=receive)
        observed['connection'] = transport.connect(state, case, number, case_deadline, whole_deadline)
        return observed['connection']

    def close_case(current):
        observed['context'] = current
        require(current['raw']['closing']['phase'] == 'pre_unwrap', 'canonical pre_unwrap missing')
        script['responses'] = [b'']
        if action is None:
            raise boundary
        return action(script, observed['state'], current)

    def unexpected(*args):
        raise RuntimeError('unexpected final hook before replacement')

    def child_factory(run, index, selection, ready, whole):
        child.update(identity=(run, index), ready_start=clock(), ready_at=clock(), ready_deadline=ready, whole_deadline=whole)
        observed['state'] = transport.new_transport(child, clock=clock, ops=ops)
        script['state'] = observed['state']
        descriptor = dict(identity=(run, index), ready=True, fresh_application=True, connect=connect_case,
                          disconnect_close=close_case, close=unexpected, signal=unexpected, process=unexpected, post=unexpected)
        if binder == 'native':
            descriptor['bind_context'] = partial(transport.bind_context, observed['state'])
        elif binder is not None:
            descriptor['bind_context'] = binder
        return descriptor

    expected = expected_error if expected_error is not None else boundary if action is None else replacement
    raises(lambda: coordinator.run(child['selection'], run_identity='transport_test', now=0,
           units_per_second=transport.UNITS, clock=clock, child_factory=child_factory), type(expected), expected)
    return script, observed['state'], observed


def strict_context():
    script, state, observed = canonical_disconnect()
    return script, state, observed['context']


def strict_facts():
    return dict(method='ssl_unwrap', tls_shutdown='success', tcp_eof=True, trailing_bytes=0, close='normal')


def strict_success_and_replacement():
    def action(script, state, current):
        script['tick'] = 20000000000
        result = transport.disconnect_close(state, current)
        require(result == strict_facts() and all(type(result[key]) is type(value) for key, value in strict_facts().items()), 'strict facts schema')
        require(current['raw']['closed'] is False and current['request']['transport_closed'] is False, 'transport stole lifecycle finish')
        return result
    with mock.patch.object(wire, 'begin_termination', wraps=wire.begin_termination) as begin, mock.patch.object(transport, 'bind_context', wraps=transport.bind_context) as bind:
        with mock.patch.object(wire, 'finish_termination', wraps=wire.finish_termination) as finish:
            script, state, observed = canonical_disconnect(action)
            require(begin.call_count == finish.call_count == 1, 'canonical lifecycle ownership changed')
            require(bind.call_count == 1, 'initial context notification not exactly once')
    first, second = state['history']
    require(first['identity'] == (0, 'disconnect', 1) and second['identity'] == (0, 'disconnect', 2), 'replacement descriptor identity')
    require(first['case_deadline'] == second['case_deadline'] == 30000000003 and first['whole_deadline'] == second['whole_deadline'] == 900000000000, 'replacement deadlines changed')
    require(first['release'] == strict_facts() and first['closed'] and observed['context']['raw']['closed'], 'strict release not finished canonically')
    require(second['original']['protocol'] is not first['original']['protocol'] and observed['replacement'] is second['wrapped'], 'replacement protocol binding')
    require(first['context_binding'][0] is observed['context'] and second['context_binding'] is None, 'replacement context notification invented')
    before = len(script['events'])
    raises(lambda: transport.bind_context(state, observed['context']))
    require(len(script['events']) == before and second['context_binding'] is None, 'old context rebound to replacement')
    closes = [args[0] for name, args in script['events'] if name == 'close']
    require(closes == [script['unwrapped']] and script['unwrapped'] is not script['tls'], 'returned handle not closed')
    require(script['timeout'][-2:] == [10.000000003, 10.000000003], 'strict residual gained cap or budget')


def strict_operation_schema():
    for selection in (('ready_buffered',), ('disconnect',), ('ready_buffered', 'disconnect')):
        script, child, clock, ops = fixture(selection)
        expected = 'disconnect' in selection
        require(('unwrap' in ops) is expected, 'fixture conditional unwrap')
        transport.new_transport(child, clock=clock, ops=ops)
        if expected:
            del ops['unwrap']
        else:
            ops['unwrap'] = lambda handle: handle
        raises(lambda: transport.new_transport(child, clock=clock, ops=ops))
        require(not script['events'], 'invalid operation schema caused effects')


def strict_invalid_context():
    changes = ('protocol', 'send', 'clock', 'case', 'index', 'deadline', 'whole', 'phase', 'policy', 'binding',
               'observer', 'identity', 'busy', 'failed', 'now', 'closed_raw')
    for change in changes:
        script, state, current = strict_context()
        row = state['current']
        if change in ('protocol', 'send', 'clock'):
            current[change] = object()
        if change in ('case', 'index', 'deadline', 'whole', 'binding'):
            key = dict(case='case', index='connection_index', deadline='case_deadline', whole='whole_deadline', binding='binding')[change]
            current['stage'][key] = None
        if change in ('phase', 'policy'):
            current['raw']['closing'][change] = 'wrong'
        if change == 'observer':
            row['observer']['failure'] = ('poison',)
        if change == 'identity':
            row['identity'] = (1, 'disconnect', 1)
        if change == 'busy':
            state['busy'] = True
        if change == 'failed':
            state['failure'] = RuntimeError('sticky prior failure')
        if change == 'now':
            current['now'] = True
        if change == 'closed_raw':
            current['raw']['closed'] = True
        before = len(script['events'])
        raises(lambda: transport.disconnect_close(state, current))
        require(len(script['events']) == before, 'invalid strict boundary caused effects: ' + change)
    script, state, connection = opened()
    current = context(state, connection)
    before = len(script['events'])
    raises(lambda: transport.disconnect_close(state, current))
    require(len(script['events']) == before, 'ordinary connection entered strict close')


def reject_replacement(state, script):
    row = state['current']
    before = len(script['events'])
    raises(lambda: transport.connect(state, 'disconnect', 2, row['case_deadline'], row['whole_deadline']))
    require(len(script['events']) == before and row['release'] is None, 'failed strict step authorized replacement')


def strict_failures_and_shapes():
    for stage in ('ownership', 'capture', 'set_timeout', 'unwrap', 'recv', 'close'):
        script, state, current = strict_context()
        primary, secondary = RuntimeError(stage), RuntimeError('cleanup')
        script['failures'][stage] = primary
        if stage != 'close':
            script['failures']['close'] = secondary
        raises(lambda: transport.disconnect_close(state, current), RuntimeError, primary)
        require(state['failure'] is primary and state['cleanup_errors'] == [primary if stage == 'close' else secondary], 'strict error identity')
        target = script['unwrapped'] if stage in ('recv', 'close') else script['tls']
        require(all(args[0] is target for name, args in script['events'] if name == 'close'), 'strict cleanup target')
        reject_replacement(state, script)
    for value in (None, b'x', b'\x00\x00', bytearray(), '', (b'', 3), False):
        script, state, current = strict_context()
        script['results']['recv'] = value
        raises(lambda: transport.disconnect_close(state, current))
        require(state['current']['closed'] and state['current']['handle'] is script['unwrapped'], 'raw rejection lost ownership')
        reject_replacement(state, script)
    for error in (TimeoutError('raw timeout'), ssl.SSLEOFError('raw TLS EOF')):
        script, state, current = strict_context()
        script['failures']['recv'] = error
        raises(lambda: transport.disconnect_close(state, current), type(error), error)
        reject_replacement(state, script)
    script, state, current = strict_context()
    script['results']['unwrap'] = None
    raises(lambda: transport.disconnect_close(state, current))
    require(state['current']['handle'] is script['tls'] and [args[0] for name, args in script['events'] if name == 'close'] == [script['tls']], 'absent raw lost TLS cleanup target')
    reject_replacement(state, script)
    for name in ('set_timeout', 'close'):
        script, state, current = strict_context()
        script['results'][name] = False
        raises(lambda: transport.disconnect_close(state, current))
        reject_replacement(state, script)


def strict_time_boundaries():
    for stage in ('ownership', 'capture', 'set_timeout', 'unwrap', 'recv', 'close'):
        for tick in (2, 30000000003, True, 1 << 64):
            script, state, current = strict_context()
            script['tick_after'][stage] = tick
            raises(lambda: transport.disconnect_close(state, current))
            target = script['unwrapped'] if stage in ('unwrap', 'recv', 'close') else script['tls']
            require(state['current']['handle'] is target and state['current']['closed'], 'expired stage lost cleanup ownership')
            require([args[0] for name, args in script['events'] if name == 'close'] == [target], 'expired stage closed wrong handle or retried success')
            reject_replacement(state, script)
    script, state, current = strict_context()
    current['now'], state['now'], script['tick'] = 10, 11, 10
    raises(lambda: transport.disconnect_close(state, current))
    require(state['now'] == 11 and state['current']['closed'], 'strict context rewound transport time')
    script, state, current = strict_context()
    current['now'], script['tick'] = 12, 12
    transport.disconnect_close(state, current)
    require(state['now'] == 12, 'strict context observed time lost')
    script, state, current = strict_context()
    script['tick'] = 30000000002
    transport.disconnect_close(state, current)
    require(script['timeout'][-2:] == [1e-9, 1e-9], 'strict one-ns residual lost')


def strict_same_handle_and_postchecks():
    script, state, current = strict_context()
    script['unwrapped'] = script['tls']
    facts = transport.disconnect_close(state, current)
    require(facts == strict_facts() and state['current']['handle'] is script['tls'], 'valid same-token ownership transfer rejected')
    before = len(script['events'])
    raises(lambda: transport.disconnect_close(state, current))
    require(len(script['events']) == before, 'duplicate strict close had effects')
    script, state, current = strict_context()
    original = state['ops']['capture']
    def post_capture():
        if state['current']['closed']:
            raise RuntimeError('capture after close')
        return original()
    state['ops']['capture'] = post_capture
    primary = raises(lambda: transport.disconnect_close(state, current), RuntimeError)
    require(state['failure'] is primary and sum(name == 'close' for name, args in script['events']) == 1, 'post-close capture retried closed resource')
    reject_replacement(state, script)
    script, state, current = strict_context()
    original = state['ops']['unwrap']
    def reentrant(handle):
        before = len(script['events'])
        raises(lambda: transport.disconnect_close(state, current))
        require(len(script['events']) == before, 'reentrant strict close had effects')
        return original(handle)
    state['ops']['unwrap'] = reentrant
    transport.disconnect_close(state, current)
    require(sum(name == 'unwrap' for name, args in script['events']) == 1, 'unwrap repeated')


def strict_swallowed_reentrant_failure():
    script, state, current = strict_context()
    original = state['ops']['set_timeout']
    seen = []
    def timeout(handle, seconds):
        seen.append(raises(state['current']['wrapped']['receive']))
        return original(handle, seconds)
    state['ops']['set_timeout'] = timeout
    raises(lambda: transport.disconnect_close(state, current), ValueError)
    require(len(seen) == 1 and state['failure'] is seen[0] and state['current']['release'] is None,
            'swallowed reentrant I/O failure earned strict success')
    require(not any(name == 'unwrap' for name, args in script['events']), 'unwrap after reentrant failure')
    reject_replacement(state, script)


def nth_strict_operation(script, state, name, index, mode, primary):
    original = state['ops'][name]
    calls = [0]
    def operation(*args):
        result = original(*args)
        calls[0] += 1
        if calls[0] != index:
            return result
        if mode == 'raise':
            raise primary
        if mode == 'expire':
            script['tick'] = state['current']['case_deadline']
        if mode == 'regress':
            script['tick'] = 2
        if mode == 'shape':
            return False
        return result
    state['ops'][name] = operation


def strict_late_operations():
    positions = (('ownership', 2), ('capture', 2), ('capture', 3), ('capture', 4), ('set_timeout', 2))
    for name, index in positions:
        for mode in ('raise', 'expire', 'regress', 'shape'):
            script, state, current = strict_context()
            primary = RuntimeError('late ' + name)
            nth_strict_operation(script, state, name, index, mode, primary)
            if mode == 'raise':
                raises(lambda: transport.disconnect_close(state, current), RuntimeError, primary)
            else:
                raises(lambda: transport.disconnect_close(state, current))
            require(state['current']['closed'] and state['current']['handle'] is script['unwrapped'], 'late strict operation lost raw cleanup')
            require([args[0] for event, args in script['events'] if event == 'close'] == [script['unwrapped']], 'late operation retried successful raw close')
            reject_replacement(state, script)
    for name in ('unwrap', 'recv'):
        for error in (TimeoutError(name), ssl.SSLEOFError(name), KeyboardInterrupt(name)):
            script, state, current = strict_context()
            script['failures'][name] = error
            raises(lambda: transport.disconnect_close(state, current), BaseException, error)
            require(state['failure'] is error, 'TLS/timeout primary identity lost')
            reject_replacement(state, script)


def strict_every_clock_sample():
    script, state, current = strict_context()
    start = script['clock_calls']
    transport.disconnect_close(state, current)
    samples = script['clock_calls'] - start
    require(samples > 10, 'strict clock sample fixture incomplete')
    for offset in range(1, samples + 1):
        for invalid in (RuntimeError('clock'), 2, 30000000003, True, 1 << 64):
            script, state, current = strict_context()
            script['clock_steps'][script['clock_calls'] + offset] = invalid
            error = raises(lambda: transport.disconnect_close(state, current), (ValueError, RuntimeError))
            require(state['failure'] is error and state['current']['closed'], 'clock failure not retained or cleaned')
            if isinstance(invalid, BaseException):
                require(error is invalid, 'clock exception replaced')
            require(sum(name == 'close' for name, args in script['events']) == 1, 'clock failure double close')
            reject_replacement(state, script)


def strict_replacement_fact_types():
    invalids = (dict(method='ssl_unwrap'), dict(strict_facts(), tcp_eof=1),
                dict(strict_facts(), trailing_bytes=False), dict(strict_facts(), extra=True),
                dict(strict_facts(), tls_shutdown='failure'), dict(strict_facts(), close='forced'),
                dict(method='close', client_closed=True, close='normal'))
    for facts in invalids:
        script, state, connection = opened(('disconnect',))
        row = state['current']
        row.update(closed=True, release=facts)
        before = len(script['events'])
        raises(lambda: transport.connect(state, 'disconnect', 2, row['case_deadline'], row['whole_deadline']))
        require(len(script['events']) == before, 'noncanonical release authorized replacement')
    script, state, current = strict_context()
    facts = transport.disconnect_close(state, current)
    facts['tcp_eof'] = False
    require(state['current']['release'] == strict_facts(), 'caller substituted retained release')


def strict_raw_close_error_identity():
    script, state, current = strict_context()
    primary, secondary = RuntimeError('raw close'), RuntimeError('raw cleanup close')
    errors = [primary, secondary]
    def close(handle):
        script['events'].append(('close', (handle,)))
        raise errors.pop(0)
    state['ops']['close'] = close
    raises(lambda: transport.disconnect_close(state, current), RuntimeError, primary)
    require(state['failure'] is primary and state['cleanup_errors'] == [secondary] and not errors, 'raw close error identity lost')
    require([args[0] for name, args in script['events'] if name == 'close'] == [script['unwrapped'], script['unwrapped']], 'raw close failure targeted TLS')
    before = len(script['events'])
    raises(lambda: transport.disconnect_close(state, current))
    require(len(script['events']) == before and state['failure'] is primary, 'failed strict call was retried')
    reject_replacement(state, script)


def strict_foreign_context_rejected():
    script, state, connection = opened(('disconnect',))
    original = context(state, connection)
    require(original['raw']['closing'] is None, 'genuine context already closing')
    transport.bind_context(state, original)
    forged = dict(original)
    forged['raw'] = dict(original['raw'], closing=dict(phase='pre_unwrap', policy='clean_disconnect'))
    forged['stage'] = dict(original['stage'])
    forged['stage']['binding'] = {key: forged[key] for key in ('protocol', 'raw', 'request', 'credit', 'records')}
    require(forged['protocol'] is original['protocol'] and forged['send'] is original['send'] and
            forged['clock'] is original['clock'] and forged['stage']['binding']['raw'] is forged['raw'], 'foreign fixture binding')
    script['responses'] = [b'']
    before = len(script['events'])
    raises(lambda: transport.disconnect_close(state, forged))
    require(len(script['events']) == before and original['raw']['closing'] is None and state['current']['release'] is None,
            'foreign context entered actual strict release')


def post_open_notification():
    notified = []
    def bind(current):
        require(current['raw']['closing'] is None and current['stage']['initial_settings'] == 0 and
                current['stage']['acks'] == 0 and 'output_observations' not in current, 'notification ordering')
        require(current['protocol'] is current['stage']['binding']['protocol'] and
                current['raw'] is current['stage']['binding']['raw'], 'notification fabricated context')
        require(current['send'].args[0]['send']['calls'] > 0, 'notification preceded open-case startup send')
        notified.append(current)
    script, state, observed = canonical_disconnect(binder=bind)
    require(notified == [observed['context']] and notified[0] is observed['context'], 'missing post-open binding notification')
    require(bool(script['sent']), 'post-open was misrepresented as pretraffic')


def optional_context_callback_contract():
    callback = lambda *args: None
    descriptor = dict(identity=('transport_test', 0), ready=True, fresh_application=True,
                      connect=callback, close=callback, signal=callback, process=callback, post=callback,
                      disconnect_close=callback)
    coordinator.validate_descriptor(descriptor, descriptor['identity'], ('disconnect',))
    coordinator.validate_descriptor(dict(descriptor, bind_context=callback), descriptor['identity'], ('disconnect',))
    for value in (None, False, 1):
        raises(lambda: coordinator.validate_descriptor(dict(descriptor, bind_context=value), descriptor['identity'], ('disconnect',)))
    raises(lambda: coordinator.validate_descriptor(dict(descriptor, unknown=callback), descriptor['identity'], ('disconnect',)))
    primary = RuntimeError('post-open callback')
    def fail(current):
        raise primary
    canonical_disconnect(binder=fail, expected_error=primary)
    raises(lambda: canonical_disconnect(binder=lambda current: False))


def context_binding_identity_and_lifecycle():
    script, state, observed = canonical_disconnect(binder=None)
    current = observed['context']
    before = len(script['events'])
    raises(lambda: transport.disconnect_close(state, current))
    raises(lambda: transport.bind_context(state, current))
    require(state['current']['context_binding'] is None and len(script['events']) == before, 'late first binding or unbound close had effects')
    script, state, connection = opened(('disconnect',))
    current = context(state, connection)
    before = len(script['events'])
    transport.bind_context(state, current)
    anchor = state['current']['context_binding']
    require(anchor == (current, current['stage'], current['raw'], current['request'], current['credit'], current['records'], current['stage']['binding']), 'actual binding identities not retained')
    raises(lambda: transport.disconnect_close(state, current))
    raises(lambda: transport.bind_context(state, current))
    raises(lambda: transport.bind_context(state, dict(current)))
    require(state['current']['context_binding'] is anchor and len(script['events']) == before, 'premature close/rebind changed binding or had effects')
    for key in ('context', 'stage', 'raw', 'request', 'credit', 'records', 'binding'):
        script, state, current = strict_context()
        supplied = current
        if key == 'context':
            supplied = dict(current)
        elif key == 'binding':
            current['stage']['binding'] = dict(current['stage']['binding'])
        else:
            current[key] = dict(current[key])
            current['stage']['binding'] = {part: current[part] for part in ('protocol', 'raw', 'request', 'credit', 'records')}
        before = len(script['events'])
        raises(lambda: transport.disconnect_close(state, supplied))
        require(len(script['events']) == before and state['current']['release'] is None, 'replaced retained component caused effects: ' + key)


def context_binding_connection_and_time():
    for key in ('protocol', 'send', 'clock', 'case', 'deadline', 'now', 'completed'):
        script, state, connection = opened(('disconnect',))
        current = context(state, connection)
        if key in ('protocol', 'send', 'clock'):
            current[key] = object()
        if key == 'case':
            current['stage']['case'] = 'ready_buffered'
        if key == 'deadline':
            current['stage']['case_deadline'] += 1
        if key == 'now':
            current['now'] = True
        if key == 'completed':
            current['completed'] = True
        before = len(script['events'])
        raises(lambda: transport.bind_context(state, current))
        require(state['current']['context_binding'] is None and len(script['events']) == before, 'invalid context binding had effects')
    script, state, connection = opened(('ready_buffered', 'async_delayed'))
    old = context(state, connection)
    transport.bind_context(state, old)
    transport.close(state, old, state['current']['case_deadline'])
    following = transport.connect(state, 'async_delayed', 1, 30000000003, 900000000000)
    before = len(script['events'])
    raises(lambda: transport.bind_context(state, old))
    require(state['current']['context_binding'] is None and len(script['events']) == before, 'cross-connection context bound')
    current = context(state, following)
    transport.bind_context(state, current)
    require(state['current']['context_binding'][0] is current, 'fresh initial connection did not bind')

def strict_replacement_gate():
    script, state, connection = opened(('disconnect',))
    row = state['current']
    row.update(closed=True, release=dict(method='ssl_unwrap'))
    before = len(script['events'])
    raises(lambda: transport.connect(state, 'disconnect', 2, row['case_deadline'], row['whole_deadline']))
    require(len(script['events']) == before, 'incomplete strict facts authorized replacement')

def cleanup_is_one_shot():
    script, state, connection = opened(('shutdown_active',))
    primary, secondary = RuntimeError('active receive'), RuntimeError('cleanup close')
    script['failures']['close'] = secondary
    transport.cleanup(state, state['current'], primary)
    transport.cleanup(state, state['current'], RuntimeError('outer failure'))
    require(state['failure'] is primary and state['cleanup_errors'] == [secondary], 'cleanup repeated or primary replaced')
    require(sum(name == 'close' for name, args in script['events']) == 1, 'failure cleanup repeated effects')


def active_fixture(chunks=(b'',), *, selection=('shutdown_active',), control=None):
    script, child, clock, ops = fixture(selection)
    script.update(chunks=list(chunks), signaled=False, watcher=object(), contexts=[], signal_calls=0,
                  closing_ownership=0, app=test_core_peer.new_app(), result=None, receipts=None)

    def phase(name):
        if control is not None:
            control(script, name)

    def connect_case(case, number, case_deadline, whole_deadline):
        prior = selection[:selection.index(case)]
        factory = test_shutdown.new_peer if case == 'shutdown_active' else test_core_peer.new_peer
        peer = factory(case, app=script['app'], prior=prior, now=clock(), clock=clock)
        script['peer'] = peer
        state = script['state']
        state['ops']['send'] = lambda handle, data: (ops['send'](handle, data), peer['connection']['send'](data))[1]
        state['ops']['recv'] = partial(active_receive, script, peer)
        result = transport.connect(state, case, number, case_deadline, whole_deadline)
        phase('connected')
        return result

    def ownership():
        if script['signaled']:
            script['closing_ownership'] += 1
            raise RuntimeError('ownership after immediate process/listener exit')
        return ops['ownership']()

    def bind(current):
        transport.bind_context(script['state'], current)
        script['contexts'].append(current)
        phase('bound')

    def signal_case(current, deadline):
        script['deadline'] = deadline
        phase('signal_entry')
        return transport.signal(script['state'], partial(scripted_signal, script, phase), current, deadline)

    def terminate(current, deadline):
        phase('termination_entry')
        result = transport.termination(script['state'], current, deadline)
        phase('terminal')
        return result

    def process(current, deadline):
        phase('finished')
        return dict(exit_code=0, reaped=True, forced=False, run_ok=True, deinit_ok=True, key_removed=True)

    def post(current, deadline):
        return dict(records=copy.deepcopy(script['app']['records']), metrics=test_core_peer.metrics(script['app']),
                    outputs=copy.deepcopy(script['app']['outputs']), binding=model.default_binding())

    def child_factory(run, index, selected, ready, whole):
        child.update(identity=(run, index), ready_start=clock(), ready_at=clock(), ready_deadline=ready, whole_deadline=whole)
        script['state'] = transport.new_transport(child, clock=clock, ops=dict(ops, ownership=ownership))
        result = dict(identity=(run, index), ready=True, fresh_application=True, connect=connect_case,
                      bind_context=bind, signal=signal_case, termination=terminate, process=process, post=post,
                      preconditions=lambda current: dict(client_open=True, prior_complete=True))
        if len(selection) > 1:
            result['close'] = partial(transport.close, script['state'])
        return result

    script['execute'] = partial(execute_active, script, selection, clock, child_factory)
    return script


def active_receive(script, peer, handle, size):
    require(size == 8192 and handle is script['state']['current']['handle'], 'primitive receive binding')
    script['events'].append(('recv', (handle, size)))
    error = script['failures'].get('recv')
    if error is not None:
        raise error
    if not script['signaled']:
        return peer['connection']['receive']()[0]
    result = script['chunks'].pop(0)
    if isinstance(result, BaseException):
        raise result
    return result


def scripted_signal(script, phase, child, handle, deadline):
    script['signal_calls'] += 1
    require(child is script['state']['child'] and handle is script['tls'] and deadline == script['deadline'], 'owned signal arguments')
    phase('signal_effect')
    script['signaled'] = True
    script['peer']['state']['signal'] = True
    script['app']['records']['shutdown_active'].update(cancels=1, active=False, paused=False, reason='shutdown')
    facts = dict(signal='SIGTERM', owned_identity=True, watcher_installed=True, client_open=True)
    observed = (child['pid'], child['start_identity'], child['listener'], script['watcher'], handle, script['tick'])
    operation = ('SIGTERM', child['pid'], child['start_identity'], script['watcher'], handle, script['tick'], None)
    result = (facts, child, handle, observed, operation, script['tick'])
    script['signal_evidence'] = result
    phase('signal_return')
    return script.get('signal_result', result)


def execute_active(script, selection, clock, factory):
    try:
        result = coordinator.run(selection, run_identity='transport_test', now=0, units_per_second=transport.UNITS,
                                 clock=clock, child_factory=factory)
        script['result'] = result
        script['receipts'] = aggregate_live(script['state'], result)
        return result
    except BaseException as primary:
        transport.fail_transport(script['state'], primary)
        raise


def aggregate_live(state, result):
    expected = tuple((child['identity'][1], summary['case'], summary['case_connection'])
                     for child in result['children'] for summary in child['connections'])
    actual = tuple(row['identity'] for row in state['history'])
    require(actual == expected and len(set(actual)) == len(actual), 'missing duplicate or unordered transport identity')
    receipts = tuple(transport.transport_receipt(state, identity) for identity in expected)
    prefixes = tuple(item[2][0] if item[1] == 'active' else item[2] for item in receipts)
    require(descriptors.receipt_counts(prefixes) == result['totals'], 'frozen canonical totals differ')
    return receipts


def canonical_active_success():
    for terminal in (b'', ssl.SSLEOFError('actual primitive TLS EOF')):
        script = active_fixture((test_core_peer.frame(8, 0, 0, (1).to_bytes(4, 'big')), terminal),
                                selection=('ready_buffered', 'shutdown_active'))
        with mock.patch.object(wire, 'begin_termination', wraps=wire.begin_termination) as begin, mock.patch.object(wire, 'finish_termination', wraps=wire.finish_termination) as finish:
            script['execute']()
        require(begin.call_count == finish.call_count == 1 and script['closing_ownership'] == 0, 'canonical ownership or closing live process check')
        row = script['state']['current']
        require(row['closed'] and row['release'] is not None and script['signal_calls'] == 1, 'normal active release missing')
        require(script['deadline'] == 15000000003 and row['case_deadline'] == 30000000003, 'original grace or case widened')
        require(sum(name == 'close' for name, args in script['events']) == 2, 'normal client closure count')
        require(script['result']['totals'] == descriptors.receipt_counts((script['receipts'][0][2], script['receipts'][1][2][0])), 'closing leaked into totals')


def check_failed_active(script, primary=None, kind=BaseException):
    error = raises(script['execute'], kind, primary)
    state, row = script['state'], script['state']['current']
    require(state['failure'] is error and row['release'] is None and row['cleanup_started'], 'active failure lost primary or earned release')
    before = sum(name == 'close' for name, args in script['events'])
    transport.fail_transport(state, RuntimeError('outer repeated cleanup'))
    require(before == sum(name == 'close' for name, args in script['events']), 'outer cleanup repeated')
    raises(lambda: transport.transport_receipt(state, row['identity']))
    return error


def active_pre_signal_cleanup():
    for origin in ('recv', 'capture', 'clock', 'parser'):
        primary, secondary = ssl.SSLEOFError('same presignal exception'), RuntimeError('cleanup')
        def control(script, phase):
            if phase == 'bound' and origin != 'parser':
                script['failures'][origin] = primary
            if phase == 'bound':
                script['failures']['close'] = secondary
        script = active_fixture(control=control)
        original = wire.accept
        callback = partial(raise_exact, primary) if origin == 'parser' else original
        with mock.patch.object(wire, 'accept', callback):
            check_failed_active(script, primary)
        require(script['state']['cleanup_errors'] == [secondary] and script['signal_calls'] == 0, 'presignal error cleanup identity')
        receive_state = script['state']['current']['receive_state']
        require(receive_state['receipt'] is None, 'presignal failure minted closing receipt')


def raise_exact(error, *args, **kwargs):
    raise error


def active_wrong_eof_origins():
    primary = ssl.SSLEOFError('identical exception at every origin')
    for origin in ('recv', 'capture', 'set_timeout', 'clock', 'parser'):
        def control(script, phase):
            if phase == 'termination_entry' and origin not in ('parser', 'recv'):
                script['failures'][origin] = primary
        chunks = (primary,) if origin == 'recv' else (test_core_peer.frame(8, 0, 0, (1).to_bytes(4, 'big')), b'')
        script = active_fixture(chunks, control=control)
        original = wire.accept
        def accept(*args, **kwargs):
            if script['signaled'] and origin == 'parser':
                raise primary
            return original(*args, **kwargs)
        with mock.patch.object(wire, 'accept', accept):
            run_origin_case(script, origin, primary)


def run_origin_case(script, origin, primary):
    if origin != 'recv':
        check_failed_active(script, primary)
        return
    script['execute']()
    row = script['state']['current']
    receipt = transport.transport_receipt(script['state'], row['identity'])
    require(receipt[3][3][2] == 'tls_eof' and receipt[3][-4:] == ('local_transport_only', False, 'not_established', 'unknown'), 'receive TLS terminal qualification')
    require(row['receive_state']['provenance'][-1] is primary and row['observer']['failure'] is not None, 'TLS EOF poison/provenance lost')
    raises(lambda: oracle.seal(row['observer']))


def active_signal_rejections():
    for mode in ('raise', 'facts_only', 'wrong_pid', 'no_watcher', 'operation_result', 'operation_handle', 'late', 'post_capture'):
        primary = RuntimeError('owned signal failed')
        def control(script, phase):
            if phase == 'signal_effect' and mode == 'raise':
                raise primary
            if phase == 'signal_return':
                corrupt_signal(script, mode)
        script = active_fixture(control=control)
        error = check_failed_active(script, primary if mode == 'raise' else None)
        row = script['state']['current']
        require(script['signal_calls'] == 1 and row['receive_state']['authorization'] is None, 'failed signal activated closing')
        before = len(script['events'])
        raises(lambda: transport.signal(script['state'], partial(raise_exact, primary), script['contexts'][-1], script['deadline']))
        require(len(script['events']) == before and script['state']['failure'] is error, 'signal retried effects')


def corrupt_signal(script, mode):
    evidence = script['signal_evidence']
    facts, child, handle, prerequisites, operation, returned = evidence
    if mode == 'facts_only':
        script['signal_result'] = facts
    if mode == 'wrong_pid':
        script['signal_result'] = (facts, child, handle, (124,) + prerequisites[1:], operation, returned)
    if mode == 'no_watcher':
        script['signal_result'] = (facts, child, handle, prerequisites[:3] + (None,) + prerequisites[4:], operation, returned)
    if mode == 'operation_result':
        script['signal_result'] = (facts, child, handle, prerequisites, operation[:-1] + (False,), returned)
    if mode == 'operation_handle':
        script['signal_result'] = (facts, child, handle, prerequisites, operation[:4] + (object(),) + operation[5:], returned)
    if mode == 'late':
        script['tick'] = script['deadline']
    if mode == 'post_capture':
        script['results']['capture'] = dict(overflow=True, error=None, complete=True)


def active_pre_signal_authority():
    for field, value in (('pid', 124), ('start_identity', 'reused'), ('listeners', ()), ('running', False)):
        def control(script, phase):
            if phase == 'signal_entry':
                child = script['state']['child']
                facts = dict(pid=child['pid'], start_identity=child['start_identity'], listeners=(child['listener'],), running=True)
                facts[field] = value
                script['results']['ownership'] = facts
        script = active_fixture(control=control)
        check_failed_active(script)
        require(script['signal_calls'] == 0, 'wrong live owner signaled')


def active_normal_close_failures():
    for mode in ('raise', 'shape', 'post_capture', 'post_clock'):
        primary, secondary = RuntimeError('normal close'), RuntimeError('cleanup close')
        def control(script, phase):
            if phase == 'termination_entry':
                install_close_failure(script, mode, primary, secondary)
        script = active_fixture(control=control)
        check_failed_active(script, primary if mode == 'raise' else None)
        row = script['state']['current']
        require(row['receive_state']['receipt'] is not None and not script['contexts'][-1]['raw']['closed'], 'closure failure manufactured canonical finish')
        require(sum(name == 'close' for name, args in script['events']) == (2 if mode in ('raise', 'shape') else 1), 'close failure cleanup count')
        if mode == 'raise':
            require(script['state']['cleanup_errors'] == [secondary], 'close/cleanup exception identities')


def install_close_failure(script, mode, primary, secondary):
    original = script['state']['ops']['close']
    calls = []
    def close(handle):
        calls.append(handle)
        if mode == 'raise':
            script['events'].append(('close', (handle,)))
            raise primary if len(calls) == 1 else secondary
        result = original(handle)
        if mode == 'shape':
            return False
        if mode == 'post_capture':
            script['results']['capture'] = dict(overflow=True, error=None, complete=True)
        if mode == 'post_clock':
            script['tick'] = script['deadline']
        return result
    script['state']['ops']['close'] = close


def active_live_receipt_revalidation():
    script = active_fixture(selection=('ready_buffered', 'shutdown_active'))
    script['execute']()
    state, result = script['state'], script['result']
    with mock.patch.object(native_closing, 'local_receipt', wraps=native_closing.local_receipt) as live, mock.patch.object(oracle, 'seal', wraps=oracle.seal) as seal:
        first = aggregate_live(state, result)
        second = aggregate_live(state, result)
    require(first == second and live.call_count == 2 and seal.call_count == 0, 'aggregation reused cached local verdict or resealed ordinary')
    for kind in ('missing', 'duplicate', 'order', 'totals'):
        changed = copy.deepcopy(result)
        if kind == 'missing':
            changed['children'][0]['connections'] = changed['children'][0]['connections'][:-1]
        if kind == 'duplicate':
            changed['children'][0]['connections'] += (changed['children'][0]['connections'][0],)
        if kind == 'order':
            changed['children'][0]['connections'] = tuple(reversed(changed['children'][0]['connections']))
        if kind == 'totals':
            changed['totals']['receive_calls'] += 1
        raises(lambda: aggregate_live(state, changed), RuntimeError)
    saved = script['receipts']
    raises(state['current']['wrapped']['receive'])
    raises(lambda: aggregate_live(state, result))
    require(script['receipts'] is saved and state['failure'] is not None, 'saved receipt remained live after forbidden I/O')


def active_binding_rejections():
    for key in ('stage', 'raw', 'request', 'credit', 'records', 'binding', 'send', 'receive', 'deadline'):
        def control(script, phase):
            if phase != 'signal_entry':
                return
            current, row = script['contexts'][-1], script['state']['current']
            if key in ('stage', 'raw', 'request', 'credit', 'records'):
                current[key] = dict(current[key])
            if key == 'binding':
                current['stage']['binding'] = dict(current['stage']['binding'])
            if key in ('send', 'receive'):
                row['wrapped'][key] = lambda *args: None
            if key == 'deadline':
                current['stage']['case_deadline'] += 1
        script = active_fixture(control=control)
        check_failed_active(script)
        require(script['signal_calls'] == 0, 'changed active binding signaled')


def active_duplicate_and_postterminal():
    for operation in ('signal', 'termination', 'send', 'receive'):
        script = active_fixture()
        script['execute']()
        state, row = script['state'], script['state']['current']
        current, deadline = script['contexts'][-1], script['deadline']
        before = len(script['events'])
        callbacks = dict(signal=lambda: transport.signal(state, lambda *args: None, current, deadline),
                         termination=lambda: transport.termination(state, current, deadline),
                         send=lambda: row['wrapped']['send'](b'x'), receive=row['wrapped']['receive'])
        raises(callbacks[operation])
        require(len(script['events']) == before, 'postterminal operation had OS effects')
        raises(lambda: aggregate_live(state, script['result']))


def run_active():
    groups = (cleanup_is_one_shot, canonical_active_success, active_pre_signal_cleanup, active_wrong_eof_origins,
              active_signal_rejections, active_pre_signal_authority, active_normal_close_failures,
              active_live_receipt_revalidation, active_binding_rejections, active_duplicate_and_postterminal)
    for check in groups:
        check()
        print(check.__name__ + ': PASS')
    print(json.dumps(dict(c6c_groups=len(groups), source_only=True, native_executed=False)))


def run():
    groups = (post_open_notification, optional_context_callback_contract, context_binding_identity_and_lifecycle,
              context_binding_connection_and_time, strict_foreign_context_rejected, strict_raw_close_error_identity, strict_late_operations, strict_every_clock_sample, strict_replacement_fact_types, strict_swallowed_reentrant_failure, strict_operation_schema, strict_replacement_gate, strict_success_and_replacement, strict_invalid_context,
              strict_failures_and_shapes, strict_time_boundaries, strict_same_handle_and_postchecks, shape_and_startup, invalid_inputs, late_readiness, active_binding, clock_boundaries,
              observation_failures, construction_failures, io_shapes_and_failures, active_origin_boundary,
              close_failures, poisoned_observer_blocks_io, residual_and_postoperation_time,
              successful_cleanup_and_bounds, close_after_send_clock_advance, canonical_intermediate_close)
    for check in groups:
        check()
        print(check.__name__ + ': PASS')
    print(json.dumps(dict(groups=len(groups), source_only=True, native_executed=False, c6b_c6c_complete=False)))


if __name__ == '__main__':
    if sys.argv[1:] == ['--active-check']:
        run_active()
    if sys.argv[1:] == ['--cleanup-check']:
        cleanup_is_one_shot()
    if sys.argv[1:] == ['--check']:
        run()
    if sys.argv[1:] == ['--notification-check']:
        post_open_notification()
