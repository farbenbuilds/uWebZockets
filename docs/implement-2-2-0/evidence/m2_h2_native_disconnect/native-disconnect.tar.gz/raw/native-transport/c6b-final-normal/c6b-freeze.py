"""Freeze only C6a native sources and prior safe transport proof bytes."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path('/workspaces/uWebZockets')
NATIVE = ROOT / '.uwz-work/evidence/h2-streaming/combined-native'
PROOF = NATIVE / 'evidence/native-transport'
NAMES = ('native_closing', 'test_native_closing', 'test_native_imports', 'native_post', 'test_native_post', 'native_transport', 'test_native_transport')


def require(value, message):
    if not value:
        raise ValueError(message)


def main():
    before = sys.argv[1:] == ['--before']
    require(before or sys.argv[1:] == ['--after'], 'freeze mode')
    archive_path = ROOT / 'docs/implement-2-2-0/evidence/m2_h2_native_connection/native-connection.tar.gz'
    require(hashlib.sha256(archive_path.read_bytes()).hexdigest() == 'c0bdf2032aedfeea034e08edc4b2ab170f122931df10e419bc9f12a57f9f96f9', 'C6a archive drift')
    sources = {name + '.py': hashlib.sha256((NATIVE / (name + '.py')).read_bytes()).hexdigest() for name in NAMES}
    with tarfile.open(archive_path, 'r:gz') as archive:
        for name in sources:
            prefix = 'source/current/' if name in ('native_transport.py', 'test_native_transport.py') else 'raw/native-transport/fix1-preservation/source/'
            expected = hashlib.sha256(archive.extractfile(prefix + name).read()).hexdigest()
            require(not before and name in ('native_transport.py', 'test_native_transport.py') or sources[name] == expected, 'C6a source drift: ' + name)
    prior = {str(path.relative_to(PROOF)): hashlib.sha256(path.read_bytes()).hexdigest() for path in PROOF.rglob('*')
             if path.is_file() and not str(path.relative_to(PROOF)).startswith('c6b-') and
             not str(path.relative_to(PROOF)).startswith('control/c6b-')}
    value = dict(sources=sources, prior_proof=prior)
    if not before:
        original = json.loads((PROOF / 'c6b-freeze-before.json').read_text())
        require(original['prior_proof'] == prior, 'prior transport evidence changed')
    (PROOF / ('c6b-freeze-before.json' if before else 'c6b-freeze-after.json')).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    print(json.dumps(dict(native_sources=len(sources), prior_safe_proof_paths=len(prior), private_originals_read=0)))


if __name__ == '__main__':
    main()
