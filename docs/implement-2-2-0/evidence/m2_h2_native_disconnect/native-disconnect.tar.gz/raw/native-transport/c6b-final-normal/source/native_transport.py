"""Source transport seam: bounded connection I/O and strict disconnect.

No signal, termination or native-provider acceptance lives here.
Injected operations own OS effects; wrap consumes raw ownership on success
and leaves raw ownership with the caller on failure. A successful close returns
None and releases its handle. Failed cleanup is retained, never a close receipt.
Public unwrap transfers ownership to its non-None opaque returned handle;
an absent return or raised exception leaves the TLS cleanup target identifiable.
"""
from functools import partial
from typing import Callable
import cases
import catalogue
import h2_client
import native_closing
import test_all40_descriptors as descriptors
import test_wire_oracle as oracle

Clock = Callable[[], int]
Handle = object
Address = tuple[str, int]
# Exact keys validated below; frozen copy prevents later caller fact substitution.
ChildBinding = dict
# pid:int, running:bool, start_identity:str, listeners:tuple[Address, ...].
OwnershipFacts = dict
# tls/alpn/hostname:str, check_hostname/certificate_verified/suppress_ragged_eofs:bool,
# certificate_sha256: lowercase hexadecimal SHA256 of the verified peer certificate.
TlsFacts = dict
# overflow:bool, error:None|BaseException, complete:bool (completion is not exit proof).
CaptureFacts = dict
Dial = Callable[[Address, float], Handle]
Wrap = Callable[[Handle, str, bool, float], Handle]
Inspect = Callable[[Handle], TlsFacts]
SetTimeout = Callable[[Handle, float], None]
FullSend = Callable[[Handle, bytes], None]
PrimitiveRecv = Callable[[Handle, int], bytes]
Unwrap = Callable[[Handle], Handle]
CloseHandle = Callable[[Handle], None]
ObserveOwnership = Callable[[], OwnershipFacts]
ObserveCapture = Callable[[], CaptureFacts]
NewProtocol = Callable[[], h2_client.h2.connection.H2Connection]
# dial:Dial, wrap:Wrap, inspect:Inspect, set_timeout:SetTimeout, send:FullSend,
# recv:PrimitiveRecv, close:CloseHandle, ownership:ObserveOwnership,
# capture:ObserveCapture, new_protocol:NewProtocol (canonical factory identity).
# unwrap:Unwrap is required exactly when the child selection has disconnect.
TransportOps = dict
# child, clock, ops, now, history<=41, current, failure, cleanup_errors<=2, busy.
TransportState = dict
# identity, case_deadline, whole_deadline, entry, handle, closed, original,
# wrapped, observer, receive_state (distinct C4 state or None), release.
ConnectionRecord = dict
Connection = dict
Context = dict
CloseFacts = dict
StrictCloseFacts = dict
UNITS = 1000000000
U64 = (1 << 64) - 1


def require(value: bool, code: str) -> None:
    if not value:
        raise ValueError(code)


def uint(value: int) -> bool:
    return type(value) is int and 0 <= value <= U64


def validate_child(child: ChildBinding) -> None:
    fields = {'identity', 'selection', 'ready_start', 'ready_at', 'ready_deadline', 'whole_start',
              'whole_deadline', 'pid', 'start_identity', 'listener', 'address', 'certificate_sha256'}
    require(type(child) is dict and set(child) == fields, 'child_fields')
    identity = child['identity']
    require(type(identity) is tuple and len(identity) == 2 and type(identity[0]) is str and
            1 <= len(identity[0]) <= 32 and all(char in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_' for char in identity[0]) and
            uint(identity[1]) and identity[1] < 2, 'child_identity')
    selection = child['selection']
    require(type(selection) is tuple and bool(selection) and cases.select(selection) == selection and
            catalogue.child_plan(selection) == (selection,), 'child_selection')
    values = tuple(child[key] for key in ('whole_start', 'ready_start', 'ready_at', 'ready_deadline', 'whole_deadline'))
    require(all(uint(value) for value in values), 'child_deadline_type')
    whole_start, ready_start, ready_at, ready_deadline, whole = values
    require(whole_start <= ready_start <= ready_at < ready_deadline <= whole, 'child_readiness')
    require(ready_deadline <= catalogue.add_u64(ready_start, 15 * UNITS) and
            whole <= catalogue.add_u64(whole_start, 900 * UNITS), 'child_deadline_bound')
    require(type(child['pid']) is int and 0 < child['pid'] <= 2147483647 and
            type(child['start_identity']) is str and 1 <= len(child['start_identity']) <= 128, 'child_process')
    address = child['address']
    require(type(address) is tuple and len(address) == 2 and address[0] == '127.0.0.1' and
            type(address[1]) is int and 0 < address[1] <= 65535 and child['listener'] == address and
            type(child['listener']) is tuple, 'child_address')
    digest = child['certificate_sha256']
    require(type(digest) is str and len(digest) == 64 and all(char in '0123456789abcdef' for char in digest), 'child_certificate')


def new_transport(child: ChildBinding, *, clock: Clock, ops: TransportOps) -> TransportState:
    """No effects: retain validated child readiness once and caller-owned state."""
    validate_child(child)
    names = {'dial', 'wrap', 'inspect', 'set_timeout', 'send', 'recv', 'close', 'ownership', 'capture', 'new_protocol'}
    if 'disconnect' in child['selection']:
        names.add('unwrap')
    require(callable(clock) and type(ops) is dict and set(ops) == names and
            all(callable(callback) for callback in ops.values()) and ops['new_protocol'] is h2_client.new_protocol, 'transport_ops')
    return dict(child=dict(child), clock=clock, ops=dict(ops), now=child['ready_at'], history=[],
                current=None, failure=None, cleanup_errors=[], busy=False)


def sample(state: TransportState, deadline: int) -> int:
    require(uint(deadline), 'deadline_type')
    tick = state['clock']()
    require(uint(tick) and state['now'] <= tick < deadline, 'transport_time')
    state['now'] = tick
    return tick


def residual(state: TransportState, deadline: int) -> float:
    return (deadline - sample(state, deadline)) / UNITS


def capture(state: TransportState, deadline: int) -> None:
    result = state['ops']['capture']()
    require(type(result) is dict and set(result) == {'overflow', 'error', 'complete'} and
            result['overflow'] is False and result['error'] is None and type(result['complete']) is bool, 'capture_health')
    sample(state, deadline)


def owned(state: TransportState, deadline: int) -> None:
    child = state['child']
    result = state['ops']['ownership']()
    require(type(result) is dict and set(result) == {'pid', 'running', 'start_identity', 'listeners'} and
            type(result['pid']) is int and result['pid'] == child['pid'] and result['running'] is True and
            type(result['start_identity']) is str and result['start_identity'] == child['start_identity'] and
            type(result['listeners']) is tuple and result['listeners'] == (child['listener'],), 'live_ownership')
    sample(state, deadline)
    capture(state, deadline)


def remember_failure(state: TransportState, error: BaseException) -> None:
    if state['failure'] is None:
        state['failure'] = error


def cleanup(state: TransportState, row: ConnectionRecord, error: BaseException) -> None:
    remember_failure(state, error)
    if row['handle'] is None or row['closed']:
        return
    try:
        result = state['ops']['close'](row['handle'])
        require(result is None, 'cleanup_close_shape')
        row['closed'] = True
    except BaseException as secondary:
        require(len(state['cleanup_errors']) < 2, 'cleanup_error_bound')
        state['cleanup_errors'].append(secondary)


def validate_connect(state: TransportState, case: str, number: int, case_deadline: int, whole_deadline: int) -> oracle.ConnectionDescriptor:
    require(state['failure'] is None and not state['busy'], 'transport_failed_or_busy')
    child, history, previous = state['child'], state['history'], state['current']
    require(type(case) is str and case in child['selection'] and type(number) is int and
            number in ((1, 2) if case == 'disconnect' else (1,)), 'connection_identity')
    require(uint(case_deadline) and uint(whole_deadline) and whole_deadline == child['whole_deadline'] and
            state['now'] < case_deadline <= whole_deadline, 'connection_deadlines')
    require(len(history) < 41 and (previous is None or previous['closed'] and previous['release'] is not None), 'connection_open_or_bound')
    if previous is None:
        require((case, number) == (child['selection'][0], 1), 'connection_order')
    else:
        validate_next(child, previous, case, number, case_deadline)
    final = case == child['selection'][-1] and not (case == 'disconnect' and number == 1)
    return descriptors.connection_descriptor(child['identity'][1], case, number, final=final)


def validate_next(child: ChildBinding, previous: ConnectionRecord, case: str, number: int, deadline: int) -> None:
    prior_case, prior_number = previous['identity'][1:]
    if prior_case == 'disconnect' and prior_number == 1:
        expected = dict(method='ssl_unwrap', tls_shutdown='success', tcp_eof=True, trailing_bytes=0, close='normal')
        release = previous['release']
        require(case == prior_case and number == 2 and deadline == previous['case_deadline'] and
                type(release) is dict and release == expected and
                all(type(release[key]) is type(value) for key, value in expected.items()), 'replacement_order')
        return
    position = child['selection'].index(prior_case) + 1
    require(position < len(child['selection']) and (case, number) == (child['selection'][position], 1), 'connection_order')


def inspect_tls(state: TransportState, row: ConnectionRecord, deadline: int) -> None:
    facts = state['ops']['inspect'](row['handle'])
    expected = dict(tls='TLSv1.3', alpn='h2', hostname='localhost', check_hostname=True,
                    certificate_verified=True, certificate_sha256=state['child']['certificate_sha256'], suppress_ragged_eofs=False)
    require(type(facts) is dict and facts == expected and
            all(type(facts[key]) is type(value) for key, value in expected.items()), 'tls_policy')
    sample(state, deadline)


def build_connection(state: TransportState, row: ConnectionRecord, descriptor: oracle.ConnectionDescriptor) -> Connection:
    child, deadline = state['child'], min(row['case_deadline'], row['whole_deadline'])
    owned(state, deadline)
    row['handle'] = state['ops']['dial'](child['address'], residual(state, deadline))
    require(row['handle'] is not None, 'dial_handle')
    sample(state, deadline)
    wrapped_handle = state['ops']['wrap'](row['handle'], 'localhost', False, residual(state, deadline))
    require(wrapped_handle is not None, 'wrap_handle')
    row['handle'] = wrapped_handle
    sample(state, deadline)
    inspect_tls(state, row, deadline)
    owned(state, deadline)
    protocol = state['ops']['new_protocol']()
    require(type(protocol) is h2_client.h2.connection.H2Connection, 'canonical_protocol')
    now = sample(state, deadline)
    connection = dict(protocol=protocol, send=partial(bounded_send, state, row), receive=partial(bounded_receive, state, row),
                      now=now, owned=True, tls='TLSv1.3', alpn='h2')
    if row['identity'][1] == 'shutdown_active':
        receive_state = native_closing.new_receive_state(row['identity'], now, UNITS,
            (child['ready_start'], child['ready_deadline'], row['entry'], row['case_deadline'], child['whole_start'], child['whole_deadline']), ready_at=child['ready_at'])
        row['receive_state'] = receive_state
        binding = (partial(prepare, state, row), partial(state['ops']['recv'], row['handle']), partial(read_clock, state, row))
        connection['receive'] = partial(native_closing.receive_once, receive_state, binding)
        connection['send'] = partial(native_closing.send_once, receive_state, connection['send'])
    wrapped, observer = oracle.wrap_connection(connection, descriptor)
    row.update(original=connection, wrapped=wrapped, observer=observer)
    if row['receive_state'] is not None:
        native_closing.bind_observer(row['receive_state'], connection, wrapped, observer)
    return wrapped


def connect(state: TransportState, case: str, number: int, case_deadline: int, whole_deadline: int) -> Connection:
    descriptor = validate_connect(state, case, number, case_deadline, whole_deadline)
    entry = sample(state, min(case_deadline, whole_deadline))
    require(case_deadline <= catalogue.add_u64(entry, catalogue.mul_u64(catalogue.case_budget(case)['timeout_seconds'], UNITS)), 'case_deadline_bound')
    row = dict(identity=descriptor[0], case_deadline=case_deadline, whole_deadline=whole_deadline, entry=entry,
               handle=None, closed=False, original=None, wrapped=None, observer=None, receive_state=None, release=None)
    state['history'].append(row)
    state['current'], state['busy'] = row, True
    try:
        return build_connection(state, row, descriptor)
    except BaseException as error:
        cleanup(state, row, error)
        raise
    finally:
        state['busy'] = False


def read_clock(state: TransportState, row: ConnectionRecord) -> int:
    return sample(state, min(row['case_deadline'], row['whole_deadline']))


def prepare(state: TransportState, row: ConnectionRecord, deadline: int) -> None:
    require(state['failure'] is None and state['current'] is row and not row['closed'] and
            row['wrapped'] is not None and not state['busy'], 'io_lifecycle')
    require(row['observer']['failure'] is None and not row['observer']['sealed'] and
            row['observer']['busy'], 'io_observer')
    require(uint(deadline) and deadline == min(row['case_deadline'], row['whole_deadline']), 'io_deadline')
    sample(state, deadline)
    owned(state, deadline)
    result = state['ops']['set_timeout'](row['handle'], residual(state, deadline))
    require(result is None, 'timeout_shape')
    sample(state, deadline)


def bounded_send(state: TransportState, row: ConnectionRecord, data: bytes) -> None:
    try:
        require(type(data) is bytes and 0 < len(data) <= 65536, 'send_shape')
        deadline = min(row['case_deadline'], row['whole_deadline'])
        prepare(state, row, deadline)
        state['busy'] = True
        result = state['ops']['send'](row['handle'], data)
        require(result is None, 'full_send_shape')
        sample(state, deadline)
    except BaseException as error:
        cleanup(state, row, error)
        raise
    finally:
        state['busy'] = False


def bounded_receive(state: TransportState, row: ConnectionRecord) -> tuple[bytes, int]:
    try:
        deadline = min(row['case_deadline'], row['whole_deadline'])
        prepare(state, row, deadline)
        state['busy'] = True
        data = state['ops']['recv'](row['handle'], 8192)
        require(type(data) is bytes and 0 < len(data) <= 8192, 'ordinary_receive_shape_or_eof')
        return data, sample(state, deadline)
    except BaseException as error:
        cleanup(state, row, error)
        raise
    finally:
        state['busy'] = False


def validate_close(state: TransportState, context: Context, deadline: int) -> ConnectionRecord:
    row = state['current']
    require(row is not None and not row['closed'] and not state['busy'] and state['failure'] is None, 'close_lifecycle')
    require(row['identity'][1] != 'shutdown_active' and row['identity'][1:] != ('disconnect', 1), 'ordinary_close_policy')
    require(type(context) is dict and context['protocol'] is row['original']['protocol'] and
            context['send'] is row['wrapped']['send'] and context['stage']['case'] == row['identity'][1] and
            context['stage']['connection_index'] == row['identity'][2], 'close_context')
    require((context['stage']['case_deadline'], context['stage']['whole_deadline']) ==
            (row['case_deadline'], row['whole_deadline']) and uint(context['now']) and context['now'] >= row['entry'], 'close_time_binding')
    limit = min(row['case_deadline'], row['whole_deadline'])
    if row['identity'][1] == state['child']['selection'][-1]:
        limit = min(limit, catalogue.add_u64(context['now'], 15 * UNITS))
    require(uint(deadline) and max(context['now'], state['now']) < deadline <= limit, 'close_deadline')
    return row


def close(state: TransportState, context: Context, deadline: int) -> CloseFacts:
    row = validate_close(state, context, deadline)
    state['now'] = max(state['now'], context['now'])
    state['busy'] = True
    try:
        sample(state, deadline)
        owned(state, deadline)
        result = state['ops']['close'](row['handle'])
        require(result is None, 'close_shape')
        row['closed'] = True
        sample(state, deadline)
        capture(state, deadline)
        row['release'] = dict(method='close', client_closed=True, close='normal')
        return dict(row['release'])
    except BaseException as error:
        cleanup(state, row, error)
        raise
    finally:
        state['busy'] = False


def validate_disconnect(state: TransportState, context: Context) -> ConnectionRecord:
    row = state['current']
    require(row is not None and not row['closed'] and not state['busy'] and state['failure'] is None and
            row['release'] is None and row['identity'] == (state['child']['identity'][1], 'disconnect', 1), 'disconnect_lifecycle')
    require(type(context) is dict and context.get('protocol') is row['original']['protocol'] and
            context.get('send') is row['wrapped']['send'] and context.get('clock') is state['clock'], 'disconnect_context')
    stage, raw = context.get('stage'), context.get('raw')
    require(type(stage) is dict and type(raw) is dict and stage.get('case') == 'disconnect' and
            type(stage.get('connection_index')) is int and stage['connection_index'] == 1 and
            not stage.get('failed') and raw.get('closed') is False, 'disconnect_stage')
    binding, closing = stage.get('binding'), raw.get('closing')
    require(type(binding) is dict and all(binding.get(key) is context.get(key) for key in
            ('protocol', 'raw', 'request', 'credit', 'records')) and
            type(closing) is dict and closing.get('phase') == 'pre_unwrap' and
            closing.get('policy') == 'clean_disconnect', 'disconnect_binding_or_phase')
    require((stage.get('case_deadline'), stage.get('whole_deadline')) == (row['case_deadline'], row['whole_deadline']) and
            uint(context.get('now')) and row['entry'] <= context['now'] < min(row['case_deadline'], row['whole_deadline']), 'disconnect_time_binding')
    observer = row['observer']
    require(observer['descriptor'][0] == row['identity'] and observer['failure'] is None and
            not observer['busy'] and not observer['sealed'], 'disconnect_observer')
    return row


def disconnect_tick(state: TransportState, deadline: int) -> int:
    if state['failure'] is not None:
        raise state['failure']
    require(state['busy'], 'disconnect_operation_binding')
    return sample(state, deadline)


def disconnect_close(state: TransportState, context: Context) -> StrictCloseFacts:
    """Canonical handlers own begin/finish; only complete strict release permits replacement."""
    row = validate_disconnect(state, context)
    deadline = min(row['case_deadline'], row['whole_deadline'])
    state['now'] = max(state['now'], context['now'])
    state['busy'] = True
    try:
        disconnect_tick(state, deadline)
        owned(state, deadline)
        disconnect_tick(state, deadline)
        result = state['ops']['set_timeout'](row['handle'], residual(state, deadline))
        require(result is None, 'timeout_shape')
        disconnect_tick(state, deadline)
        raw = state['ops']['unwrap'](row['handle'])
        if raw is not None:
            if raw is not row['handle']:
                row['closed'] = False
            row['handle'] = raw
        disconnect_tick(state, deadline)
        require(raw is not None, 'unwrap_handle')
        owned(state, deadline)
        disconnect_tick(state, deadline)
        result = state['ops']['set_timeout'](raw, residual(state, deadline))
        require(result is None, 'timeout_shape')
        disconnect_tick(state, deadline)
        data = state['ops']['recv'](raw, 8192)
        require(type(data) is bytes and data == b'', 'disconnect_raw_eof')
        disconnect_tick(state, deadline)
        capture(state, deadline)
        disconnect_tick(state, deadline)
        result = state['ops']['close'](raw)
        require(result is None, 'close_shape')
        row['closed'] = True
        disconnect_tick(state, deadline)
        capture(state, deadline)
        disconnect_tick(state, deadline)
        row['release'] = dict(method='ssl_unwrap', tls_shutdown='success', tcp_eof=True, trailing_bytes=0, close='normal')
        return dict(row['release'])
    except BaseException as error:
        primary = error if state['failure'] is None else state['failure']
        cleanup(state, row, primary)
        raise primary
    finally:
        state['busy'] = False


if __name__ == '__main__':
    pass
