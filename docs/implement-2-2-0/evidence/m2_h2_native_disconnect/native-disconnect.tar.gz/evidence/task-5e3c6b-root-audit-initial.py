"""Audit the strict-disconnect delta without opening private environments."""
import ast
import difflib
import hashlib
import json
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def nesting(node, depth=0):
    controls = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.With,
                ast.AsyncWith, ast.Try, ast.TryStar, ast.Match)
    level = depth + int(isinstance(node, controls))
    return max([level] + [nesting(child, level) for child in ast.iter_child_nodes(node)])


def authority():
    path = Path('docs/implement-2-2-0/evidence/m2_h2_native_connection/native-connection.tar.gz')
    require(sha(path.read_bytes()) == 'c0bdf2032aedfeea034e08edc4b2ab170f122931df10e419bc9f12a57f9f96f9', 'C6a archive identity')
    with tarfile.open(path, 'r:gz') as archive:
        return {member.name: archive.extractfile(member).read()
                for member in archive if member.isfile()}


def preserve(source, parent):
    raw = source / 'evidence/native-transport'
    expected = {name.removeprefix('raw/native-transport/'): dict(size=len(data), sha256=sha(data))
                for name, data in parent.items() if name.startswith('raw/native-transport/')}
    references = json.loads(parent['TOOL_SNAPSHOT_REFERENCES.json'])['omitted_members']
    expected.update({name.removeprefix('raw/native-transport/'): dict(size=row['size'], sha256=row['sha256'])
                     for name, row in references.items()})
    for name, row in expected.items():
        path = raw / name
        require(not path.is_symlink(), 'Prior evidence symlink: ' + name)
        data = path.read_bytes()
        require(len(data) == row['size'] and sha(data) == row['sha256'], 'Prior evidence changed: ' + name)
    actual = {path.relative_to(raw).as_posix() for path in raw.rglob('*') if path.is_file()}
    added = actual - expected.keys()
    require(expected.keys() <= actual, 'Prior evidence missing')
    require(all(name.startswith(('c6b-', 'control/c6b-')) for name in added), 'New evidence scope')
    require(not any(path.is_symlink() for path in raw.rglob('*')), 'Evidence symlink')
    return dict(prior_safe_transport_paths=len(expected), unchanged=True,
                new_evidence_paths=len(added), new_paths=sorted(added),
                private_original_environments_read=0)


def sources(source, parent):
    baseline = {name.removeprefix('source/current/'): data for name, data in parent.items()
                if name.startswith('source/current/')}
    actual = {path.name: path.read_bytes() for path in source.glob('*.py')}
    require(actual.keys() == baseline.keys() and len(actual) == 7, 'Native module set')
    changed = {name for name, data in actual.items() if data != baseline[name]}
    require(changed == {'native_transport.py', 'test_native_transport.py'}, 'Native change scope')
    result = {}
    for name in changed:
        tree = ast.parse(actual[name])
        require(nesting(tree) <= 3, 'Source nesting: ' + name)
        require(not any(isinstance(node, (ast.ClassDef, ast.Assert, ast.Global, ast.Nonlocal))
                        for node in ast.walk(tree)), 'Source structure: ' + name)
        result[name] = dict(size=len(actual[name]), sha256=sha(actual[name]), maximum_nesting=nesting(tree))
    return actual, baseline, result


def review(plan, source, parent, result, actual, baseline):
    parts = ['# C6b strict disconnect source review\n',
             'BASE/current HEAD 9e2b536e002aac168fefe28771e975cf9e073f6e.\n',
             'Uncommitted ignored source delta; Root commits only after review/publication.\n']
    for name in ('test_native_transport.py', 'native_transport.py'):
        parts.extend(difflib.unified_diff(baseline[name].decode().splitlines(True),
                     actual[name].decode().splitlines(True), fromfile='C6a/' + name,
                     tofile=str(source / name), n=10))
    controls = source / 'evidence/native-transport/control'
    paths = sorted(path for path in controls.glob('c6b-*') if path.suffix in ('.py', '.sh'))
    paths.append(Path(__file__))
    for path in paths:
        parts.extend(difflib.unified_diff([], path.read_text().splitlines(True),
                     fromfile='/dev/null', tofile=str(path), n=10))
    summary = dict(result)
    summary['preservation'] = {key: value for key, value in result['preservation'].items() if key != 'new_paths'}
    parts.extend(['\n# Root preservation and touched-source structure\n', json.dumps(summary, indent=2), '\n'])
    package = plan / 'task-5e3c6b-review-package.diff'
    package.write_text(''.join(parts))
    return dict(path=str(package), bytes=package.stat().st_size, sha256=sha(package.read_bytes()))


def main(arguments):
    if arguments != ['--audit']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/combined-native')
    parent = authority()
    actual, baseline, changed = sources(source, parent)
    result = dict(preservation=preserve(source, parent), sources=changed,
                  unchanged_native_sources=5, native_executed=False,
                  complete_transport=False, milestone_complete=False)
    (plan / 'task-5e3c6b-root-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    package = review(plan, source, parent, result, actual, baseline)
    print(json.dumps(dict(sources=changed, preserved=result['preservation']['prior_safe_transport_paths'],
                         new_evidence=result['preservation']['new_evidence_paths'], review_package=package)))


if __name__ == '__main__':
    main(sys.argv[1:])
