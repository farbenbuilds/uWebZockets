"""Publish only the reviewed strict-disconnect source/evidence delta."""
import hashlib
import json
import runpy
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def authority(plan):
    path = Path('docs/implement-2-2-0/evidence/m2_h2_native_connection/native-connection.tar.gz')
    require(sha(path.read_bytes()) == 'c0bdf2032aedfeea034e08edc4b2ab170f122931df10e419bc9f12a57f9f96f9', 'C6a archive identity')
    with tarfile.open(path, 'r:gz') as archive:
        contents = {member.name: archive.extractfile(member).read() for member in archive if member.isfile()}
    helper = plan / 'task-5e3c6a-publication.py'
    require(helper.read_bytes() == contents['evidence/' + helper.name], 'Published bridge differs')
    bridge = runpy.run_path(str(helper))['parent'](plan)[1]
    return contents, bridge


def sources(source, parent, audit):
    baseline = {name.removeprefix('source/current/'): data for name, data in parent.items()
                if name.startswith('source/current/')}
    actual = {path.name: path.read_bytes() for path in source.glob('*.py')}
    require(actual.keys() == baseline.keys() and len(actual) == 7, 'Native source inventory')
    result = {}
    for name, data in actual.items():
        row = dict(size=len(data), sha256=sha(data))
        if name in audit['sources']:
            require(row == {key: audit['sources'][name][key] for key in ('size', 'sha256')}, 'Reviewed source differs')
        else:
            require(data == baseline[name], 'Unchanged source differs')
        result[name] = row
    return actual, baseline, result


def environment(data):
    path = '/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native'
    expected = ('PYTHONDONTWRITEBYTECODE=1\0PYTHONHASHSEED=0\0PYTHONPATH=' + path + '\0').encode()
    require(data == expected, 'New environment contains unexpected controls')


def all40(source, extension):
    raw = source / 'evidence/native-transport'
    text = (raw / 'c6b-fix1-all40-summary/stdout').read_text()
    rows = [json.loads(line) for line in text.splitlines() if line.startswith('{')]
    require(len(rows) == 2, 'All40 summary count')
    expected = dict(connections=41, final_collections=2, heads=802, incoming_resets=13,
                    informationals=2, receive_bytes=51312051, receive_calls=31433,
                    request_flow=200091899, settings=46, small=789)
    for row, invocation, positional in zip(rows, ('explicit', 'omitted_default'), (1, 0), strict=True):
        require(row['invocation'] == invocation and row['invocation_calls'] == [dict(positional=positional, selection_keyword=False)], 'All40 invocation differs')
        require(row['observed'] == expected and (row['children'], row['dispatched'], row['receipts']) == (2, 40, 41), 'All40 observations differ')
        run = raw / row['run']
        require((run / 'status').read_text().strip() == '0', 'All40 status differs')
        require(sha((run / 'source/cases/coordinator.py').read_bytes()) == extension['sha256'], 'All40 coordinator snapshot differs')
    return rows


def collect(plan, source, parent, audit):
    actual, baseline, current = sources(source, parent, audit)
    members = {name: data for name, data in parent.items() if name.startswith('reference/')}
    members.update({'source/current/' + name: data for name, data in actual.items()})
    members.update({'baseline/' + name: data for name, data in baseline.items()})
    extension = audit['canonical_extension']
    coordinator = Path(extension['path']).read_bytes()
    require(len(coordinator) == extension['size'] and sha(coordinator) == extension['sha256'], 'Reviewed coordinator differs')
    members['source/canonical/coordinator.py'] = coordinator
    members['baseline/canonical/coordinator.py'] = parent['reference/combined/coordinator.py']
    authority = dict(scope='Additive source authority; historical119-entry restorer remains unchanged',
                     canonical_extension=extension, native_sources=current,
                     canonical_extension_member='source/canonical/coordinator.py',
                     historical_canonical_reference='reference/combined/coordinator.py',
                     provider_requirement='Supply bind_context callback; register only actual post-open context',
                     native_runtime_authority=False)
    members['SOURCE_AUTHORITY.json'] = (json.dumps(authority, indent=2) + '\n').encode()
    all40(source, extension)
    raw = source / 'evidence/native-transport'
    for name in audit['preservation']['new_paths']:
        require(name.startswith(('c6b-', 'control/c6b-')), 'Raw delta scope')
        path = raw / name
        require(not path.is_symlink() and path.is_file(), 'Raw delta type')
        data = path.read_bytes()
        if path.name == 'environment.nul':
            environment(data)
        members['raw/native-transport/' + name] = data
    names = (
        'task-5e3c6b-brief.md', 'task-5e3c6b-plan-report.md', 'task-5e3c6b-report.md',
        'task-5e3c6b-review-report.md', 'task-5e3c6b-review-package.diff',
        'task-5e3c6b-root-audit.py', 'task-5e3c6b-root-audit-initial.py', 'task-5e3c6b-root-audit.json',
        'task-5e3c6b-root-before-fix1-audit.json', 'task-5e3c6b-fix1-audit.py',
        'task-5e3c6b-fix1-audit-initial.py', 'task-5e3c6b-root-fix1-audit-initial.stderr',
        'task-5e3c6b-root-fix1-audit-initial.exit', 'task-5e3c6b-root-structure.stdout',
        'task-5e3c6b-root-structure.stderr', 'task-5e3c6b-root-structure.exit',
        'task-5e3c6b-root-structure-inputs.json', 'task-5e3c6b-root-final-fix1-inputs.json',
        'task-5e3c6b-root-fix1-audit.json', 'task-5e3c6b-root-fix1-audit.stdout',
        'task-5e3c6b-root-fix1-audit.stderr', 'task-5e3c6b-root-fix1-audit.exit',
        'task-5e3c6b-fix1-review-report.md', 'task-5e3c6b-fix1-review-package.diff',
        'task-5e3c6b-context-seam-assessment.md', 'task-5e3c6b-context-seam-plan.md',
        'task-5e3c6b-root-audit.stdout', 'task-5e3c6b-root-audit.stderr', 'task-5e3c6b-root-audit.exit',
        'task-5e3c6b-root-review.stdout', 'task-5e3c6b-root-review.stderr', 'task-5e3c6b-root-review.exit',
        'task-5e3c6b-root-audit-restore.json', 'task-5e3c6b-root-review-restore.json',
        'task-5e3c6b-root-graph-inputs.json', 'task-5e3c6b-root-graph.stdout',
        'task-5e3c6b-root-graph.stderr', 'task-5e3c6b-root-graph.exit',
        'task-5e3c6b-root-final-graph-inputs.json', 'task-5e3c6b-root-final-graph.stdout',
        'task-5e3c6b-root-final-graph.stderr', 'task-5e3c6b-root-final-graph.exit',
        'task-5e3c6b-publication.py', 'task-5e3b8a-restore-inputs.py')
    for name in names:
        members['evidence/' + name] = (plan / name).read_bytes()
    return members, current


def build(plan, source, folder):
    parent, bridge = authority(plan)
    audit = json.loads((plan / 'task-5e3c6b-root-fix1-audit.json').read_text())
    members, current = collect(plan, source, parent, audit)
    api = bridge['published_api'](plan, 'task-5e3c1-build-publication.py')
    safe = {}
    for name, data in members.items():
        api['add'](safe, name, data, {})
    folder.mkdir(parents=True, exist_ok=True)
    output = folder / 'native-disconnect.tar.gz'
    inventory = api['write_archive'](output, safe)
    manifest = dict(scope='C6b strict disconnect and replacement gating; source-only delta',
                    base_commit='9e2b536e002aac168fefe28771e975cf9e073f6e',
                    archive=output.name, archive_bytes=output.stat().st_size, archive_sha256=sha(output.read_bytes()),
                    safe_regular_utf8_members=len(safe) + 1, inventory_entries=len(inventory),
                    current_native_sources=current, parent_archive_sha256='c0bdf2032aedfeea034e08edc4b2ab170f122931df10e419bc9f12a57f9f96f9',
                    canonical_extension=audit['canonical_extension'], unchanged_canonical_modules=45,
                    source_authority_member='SOURCE_AUTHORITY.json', historical119_restoration_authority_unchanged=True,
                    raw_files_embedded=len(audit['preservation']['new_paths']),
                    prior_safe_transport_paths_preserved=6429, private_original_environments_included=False,
                    tool_snapshot_copies_added=0, collector_restore_precedes_dependency_snapshot=True,
                    focused_groups=32, all40_source_runs=all40(source, audit['canonical_extension']),
                    canonical_transition_proven='Strict release permits actual replacement connect; expected second-connection sentinel',
                    completed_native_run=False, native_compiled=False, native_executed=False,
                    complete_transport=False, milestone_complete=False)
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({key: manifest[key] for key in ('archive_sha256', 'archive_bytes', 'safe_regular_utf8_members', 'raw_files_embedded')}))


def audit_publication(plan, source, folder):
    parent, bridge = authority(plan)
    audit = json.loads((plan / 'task-5e3c6b-root-fix1-audit.json').read_text())
    expected, current = collect(plan, source, parent, audit)
    api = bridge['published_api'](plan, 'task-5e3c1-publication-audit.py')
    manifest = json.loads((folder / 'manifest.json').read_text())
    output = folder / manifest['archive']
    require(output.stat().st_size == manifest['archive_bytes'] and sha(output.read_bytes()) == manifest['archive_sha256'], 'Archive identity')
    contents = api['read_archive'](output)
    require(contents == expected and len(contents) == manifest['inventory_entries'], 'Complete published delta differs')
    require(current == manifest['current_native_sources'], 'Manifest source identity')
    require(len(contents) + 1 == manifest['safe_regular_utf8_members'], 'Archive member count')
    for data in contents.values():
        data.decode('utf-8')
    check = runpy.run_path(str(plan / 'task-5e3c1-prepare-review.py'))['root_check']
    helpers = {name: check((plan / name).resolve()) for name in ('task-5e3c6b-root-audit.py', 'task-5e3c6b-fix1-audit.py', 'task-5e3c6b-publication.py')}
    docs = Path('docs/implement-2-2-0')
    files = [docs / 'README.md', docs / 'm2_request_streaming.md', docs / 'm2_h2_native_disconnect.md',
             folder / 'README.md', folder / 'manifest.json', output]
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=output.stat().st_size,
                  safe_regular_utf8_members=len(contents) + 1, inventory_entries=len(contents),
                  raw_files_embedded=manifest['raw_files_embedded'], helpers=helpers,
                  local_links_checked=api['verify_links'](files),
                  delivery_files={str(path): dict(size=path.stat().st_size, sha256=sha(path.read_bytes())) for path in files},
                  native_executed=False, complete_transport=False, milestone_complete=False)
    (plan / 'task-5e3c6b-root-publication-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('helpers', 'delivery_files')}))


def main(arguments):
    if arguments not in (['--build'], ['--audit']):
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/combined-native')
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_native_disconnect')
    if arguments == ['--build']:
        build(plan, source, folder)
        return
    audit_publication(plan, source, folder)


if __name__ == '__main__':
    main(sys.argv[1:])
