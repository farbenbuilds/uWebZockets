C6b should extend only `native_transport.py`, its focused tests, and new evidence controls.

- Add `Unwrap = Callable[[Handle], Handle]` and `disconnect_close(state, context) -> StrictCloseFacts`. Require an `unwrap` operation only when the child selection contains `disconnect`; preserve the existing exact operation set otherwise. Existing `set_timeout`, `recv`, and `close` can serve both TLS and raw opaque handles. Document that successful public unwrap transfers ownership to its returned raw handle; failure leaves the TLS handle available for cleanup.

- Before effects, require the current open connection to be `(child, 'disconnect', 1)`, the original protocol/send/context bindings, unchanged case/whole deadlines, canonical `pre_unwrap` phase, and no prior failure or concurrent operation. Reconcile observed time with `max(state['now'], context['now'])`. Use exactly `min(case_deadline, whole_deadline)` throughout—no ordinary-close grace cap or fresh budget.

- Check live ownership/capture health and set the TLS timeout from the positive residual. Call public unwrap once. Immediately retain the returned raw handle before subsequent checks so post-unwrap expiry cleans up the correct resource. Recheck time, validate the returned-handle contract, set its residual timeout, and require direct `ops['recv'](raw, 8192)` to return exactly `b''`. Reject trailing bytes, malformed results, timeout and TLS EOF exceptions. Close that returned handle successfully, mark it closed before post-operation checks, then retain and return exactly:
  ```python
  dict(method='ssl_unwrap', tls_shutdown='success',
       tcp_eof=True, trailing_bytes=0, close='normal')
  ```
  Do not use ordinary `bounded_receive`, which correctly rejects EOF.

- Reuse sticky first-failure and cleanup-error retention. Preserve the exact primary exception; cleanup targets TLS before successful unwrap and returned raw afterward. Successful cleanup after any failed acceptance step must leave `release=None`, preventing replacement. Never close an already successfully closed handle again. Canonical handlers retain exclusive begin/finish ownership.

Focused TDD should cover the real canonical disconnect hook and replacement boundary, exact facts and original deadlines; wrong identity/context/phase with no effects; unwrap failure/invalid return; raw EOF versus trailing or malformed bytes; ownership/capture/timeout failures; expiry/regression after each operation; returned-handle identity; close failures and cleanup-error identity; duplicate/reentrant calls; and replacement permitted only after successful strict release. Use accepted serialized fixtures, injected operations/clocks, normal/`-O`, inert imports and preservation checks.

For future evidence runs, move restoration before dependency copying: restore authenticated inputs, snapshot and hash those restored bytes, then execute the dependent operation in the same controlled shell. Retain restoration receipts and exact argv/settings/results. Any required final restoration must be checked for changed bytes and trigger resnapshotting before execution. Reference the existing retained Graphify closure by hashes; do not copy it again.

No C4 changes, signal/termination hooks, active-receive cleanup, provider acceptance, or native execution belong in C6b.
