Proceed with one additive coordinator notification and native identity retention. No overlay is necessary for the currently declared restoration authority.

**Changed files**

1. `integration-owned/combined-cases/coordinator.py`: optional descriptor callback validation and one post-open invocation.
2. `combined-native/native_transport.py`: named context-binding contract, one-shot `bind_context`, and retained-identity checks in strict disconnect.
3. `combined-native/test_native_transport.py`: focused descriptor, ordering and foreign-context regressions.
4. Existing C6b evidence controls: pending-source authority manifest/check, restored-source snapshots and new raw runs. Historical sources, archives, C4 and protocol/lifecycle implementations remain unchanged.

**Descriptor contract and ordering**

Add a named `BindContext = Callable[[Context], None]` contract for optional child-descriptor key `bind_context`.

`validate_descriptor` accepts precisely the existing required fields, optionally plus that key. If present, it must be callable; `None`, unknown fields and missing existing hooks still fail. Existing source descriptors omit it without fabricated no-op callbacks. The native provider must supply `partial(native_transport.bind_context, state)`.

Invoke it immediately after the actual `adapter.open_case(...)` return and before `restore_retained`, the receive loop or case handler. Require a `None` return and propagate its original exception. Startup send already occurs inside `open_case`; describe this accurately as **post-open**, not pretraffic notification.

Scope this notification to the initial connection created by `open_case`. C6b's strict close concerns disconnect connection 1; do not add replacement-context notifications speculatively.

**Native binding**

`bind_context(state, context)` validates the current connection, canonical binding and initial nonclosing lifecycle state, then retains the actual context plus identities of `stage`, `raw`, `request`, `credit`, `records` and the canonical stage-binding object. Bind once per connection; retain identities, not mutable dictionary copies.

`disconnect_close` requires that established binding and exact component identities before evaluating current canonical `pre_unwrap` state. Reject an unbound call, copied context, replaced components, rebinding or cross-connection binding before transport effects.

The authority comes from the coordinator's call site receiving the actual factory return. The binding function alone is not authentication against arbitrary Python callers; the provider must not expose an alternate first-binding path at close.

**Restoration and source-authority transition**

Inspection found that `immutable-inputs.json` contains **no** `combined-cases` paths, `coordinator.py`, or this `adapter.py`. The sole `coordinator.py` across the prescribed six import directories is the regular file at `integration-owned/combined-cases/coordinator.py`.

Furthermore, `task-5e3b8a-restore-inputs.py` refuses mismatched existing pinned bytes; it does not silently overwrite them. It restores only missing eligible `/tmp/uwz-*` files. Therefore:

- Preserve that restorer and its historical 119-entry authority unchanged.
- Retain the current coordinator baseline bytes, their hash and existing archive provenance, plus the minimal pending diff.
- Create a separate pending-source manifest covering the reviewed coordinator/native/test bytes and their exact paths.
- In each controlled shell, run the old restorer, verify pending hashes, snapshot the restored dependencies and pending sources, then execute the check. Before test behavior, verify `coordinator.__file__` resolves to the manifested path and its bytes match. Abort on drift.
- After review, publish a new additive source-authority record/archive for the coordinator extension. Future runners compose the unchanged historical restoration authority with that reviewed extension; do not rewrite historical pins.

If subsequent work actually changes a pinned input, stop and introduce the explicitly reviewed overlay/authority transition then. That conflict is not present here.

**Covering checks**

Retain REDs proving missing notification and rejection failure for self-consistent foreign contexts. Cover optional absence, invalid callback, exact once/order/return, exception identity, unbound/premature close, replaced retained components and successful real canonical disconnect/replacement.

Run focused normal/`-O`, inert-import and preservation checks. Because coordinator behavior changes, also run required **all40 source recomposition**, including explicit selection and genuinely omitted default, through existing canonical source harnesses. Reconcile expected identities/counts and prove unchanged descriptors still work. This is source recomposition, not native acceptance.

No implementation or tests were performed in this planning pass.
