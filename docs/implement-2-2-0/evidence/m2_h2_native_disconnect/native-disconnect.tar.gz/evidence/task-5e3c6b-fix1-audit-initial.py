"""Audit the first strict-disconnect correction and build its scoped diff."""
import ast
import difflib
import hashlib
import json
import runpy
import sys
from pathlib import Path


def main(arguments):
    if arguments != ['--audit']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/combined-native')
    api = runpy.run_path(str(plan / 'task-5e3c6b-root-audit-initial.py'))
    parent = api['authority']()
    actual, baseline, changed = api['sources'](source, parent)
    canonical = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    old_canonical = {name.removeprefix('reference/combined/'): data for name, data in parent.items()
                     if name.startswith('reference/combined/') and name.endswith('.py') and name.count('/') == 2}
    current_canonical = {path.name: path.read_bytes() for path in canonical.glob('*.py')}
    if len(old_canonical) != 46 or current_canonical.keys() != old_canonical.keys():
        raise ValueError('Canonical module inventory differs')
    delta = {name for name in old_canonical if old_canonical[name] != current_canonical[name]}
    if delta != {'coordinator.py'}:
        raise ValueError('Canonical change scope differs')
    coordinator = current_canonical['coordinator.py']
    tree = ast.parse(coordinator)
    if api['nesting'](tree) > 3 or any(isinstance(node, (ast.ClassDef, ast.Assert, ast.Global, ast.Nonlocal)) for node in ast.walk(tree)):
        raise ValueError('Coordinator source structure differs')
    canonical_source = dict(path=str(canonical / 'coordinator.py'), size=len(coordinator),
                            sha256=hashlib.sha256(coordinator).hexdigest(), unchanged_modules=45,
                            maximum_nesting=api['nesting'](tree),
                            baseline_sha256=hashlib.sha256(old_canonical['coordinator.py']).hexdigest())
    result = dict(preservation=api['preserve'](source, parent), sources=changed,
                  canonical_extension=canonical_source,
                  unchanged_native_sources=5, native_executed=False,
                  complete_transport=False, milestone_complete=False)
    (plan / 'task-5e3c6b-root-fix1-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    old_hashes = dict(native_transport='dea1806babcc58eb80f0e7a16b64b0735e6e9996cb945b678aef34d7549803c1',
                      test_native_transport='06eddcb1d4dc1ed739eec019ffbfe330f0d7c9eb457805e704cd915eb07a4467')
    parts = ['# C6b fix round1 scoped review\n', 'Same Git BASE9e2b536; reviewed uncommitted source to corrected source.\n']
    for module in ('test_native_transport', 'native_transport'):
        name = module + '.py'
        prior = source / 'evidence/native-transport/c6b-final2-normal/source' / name
        before = prior.read_bytes()
        if hashlib.sha256(before).hexdigest() != old_hashes[module]:
            raise ValueError('Reviewed source baseline differs')
        parts.extend(difflib.unified_diff(before.decode().splitlines(True), actual[name].decode().splitlines(True),
                     fromfile='C6b-reviewed/' + name, tofile=str(source / name), n=10))
    parts.extend(difflib.unified_diff(old_canonical['coordinator.py'].decode().splitlines(True),
                 coordinator.decode().splitlines(True), fromfile='C6a-canonical/coordinator.py',
                 tofile=str(canonical / 'coordinator.py'), n=10))
    summary = dict(result)
    summary['preservation'] = {key: value for key, value in result['preservation'].items() if key != 'new_paths'}
    parts.extend(['\n# Root scoped preservation\n', json.dumps(summary, indent=2), '\n'])
    package = plan / 'task-5e3c6b-fix1-review-package.diff'
    package.write_text(''.join(parts))
    print(json.dumps(dict(sources=changed, preserved=result['preservation']['prior_safe_transport_paths'],
                         new_evidence=result['preservation']['new_evidence_paths'], review_package=str(package),
                         diff_bytes=package.stat().st_size, diff_sha256=hashlib.sha256(package.read_bytes()).hexdigest())))


if __name__ == '__main__':
    main(sys.argv[1:])
