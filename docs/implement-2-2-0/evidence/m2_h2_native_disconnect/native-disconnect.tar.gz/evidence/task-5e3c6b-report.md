# C6b strict disconnect source slice

DONE_WITH_CONCERNS: strict disconnect and the replacement gate are implemented and source-tested. C6c/provider/native acceptance remain required. Source is frozen for Root's independent review.

Under `.uwz-work/evidence/h2-streaming/combined-native/` (`N`), only `native_transport.py` and `test_native_transport.py` changed. No inventory change. Additive controls/proof are under `N/evidence/native-transport/` (`E`); exact changed code/control paths and SHA256 values are retained in `E/c6b-terminal.sha256`.

```text
dea1806babcc58eb80f0e7a16b64b0735e6e9996cb945b678aef34d7549803c1  native_transport.py
06eddcb1d4dc1ed739eec019ffbfe330f0d7c9eb457805e704cd915eb07a4467  test_native_transport.py
9a6c52547138be2fec0dc7c8d408d54d4c849fb28f717523f268c6fa04bc57b9  control/c6b-run.sh
685c63ae6766a4b467af2af7ada6af0ceccdb123ea65fdbe1190158e568f8777  control/c6b-freeze.py
d670a645772959082602141a7f1456a87eb44ceadef1ca2e07e0eac01384635c  control/c6b-preserve.py
```

The new interface is `disconnect_close(state, context) -> StrictCloseFacts`; `Unwrap = Callable[[Handle], Handle]` names the injected public unwrap operation. Its exact operation key is required only for selections containing `disconnect`. Other selections retain C6a's exact schema.

Before effects, the hook requires open `(child, 'disconnect', 1)`, original protocol/send/clock and canonical context bindings, unchanged deadlines, `clean_disconnect/pre_unwrap`, healthy observer and no failure/busy state. It reconciles `max(state['now'], context['now'])`, retains integer monotonic nanoseconds, and uses the original case/whole minimum throughout. No ordinary-close cap or new budget.

After ownership/capture and positive-residual TLS timeout checks, public unwrap runs once. Its non-None opaque returned token becomes the cleanup target before time/health checks; same-token transfer is valid. An absent return retains TLS for cleanup. Raw timeout and direct `recv(raw, 8192)` must yield exactly `b''`; successful returned-handle close precedes the exact five facts:

```python
dict(method='ssl_unwrap', tls_shutdown='success', tcp_eof=True,
     trailing_bytes=0, close='normal')
```

Successful closure is marked before postchecks. Failed acceptance never creates release proof; successful cleanup cannot authorize replacement. First exception and cleanup exception identities survive. Strict checkpoints also reject a swallowed reentrant ordinary-I/O failure. The replacement gate now checks every strict fact and scalar type. Canonical handlers alone own begin/finish. Constructor/ordinary I/O, EOF rejection, ordinary close, and exact C4 partial binding remain intact.

The canonical regression uses the accepted serialized lifecycle peer through real `coordinator.run` and `lifecycle_cases.disconnect`, proves exactly one canonical begin/finish, actual strict release, unchanged `30000000003/900000000000` deadlines and an actual replacement `transport.connect`. It ends at the exact expected second-connection sentinel; it does not claim a completed native run.

Two behavioral REDs exited 1 before their fixes:

- `E/c6b-red-replacement-facts`: incomplete `{'method':'ssl_unwrap'}` authorized connection2; raw failure was `RuntimeError: missing rejection`.
- `E/c6b-red-swallowed-reentrant`: caught reentrant I/O failure still allowed strict success; same raw failure.

Every run retains `argv.nul`, explicit safe `environment.nul`, exercised controls, restored source-only dependency snapshots/hashes, interpreter hash, fresh restoration receipt/stdout/stderr, and target stdout/stderr/status. Define these shell variables from repository root:

```sh
N=.uwz-work/evidence/h2-streaming/combined-native
R=$N/evidence/native-transport/control/c6b-run.sh
P=/home/codespace/.python/current/bin/python3
```

Exact terminal commands:

```sh
env -i PATH=/usr/bin:/bin bash "$R" c6b-final2-normal "$P" -B -S "$N/test_native_transport.py" --check
env -i PATH=/usr/bin:/bin bash "$R" c6b-final2-optimized "$P" -B -S -O "$N/test_native_transport.py" --check
env -i PATH=/usr/bin:/bin bash "$R" c6b-final2-inert-normal "$P" -B -S "$N/test_native_imports.py" --check
env -i PATH=/usr/bin:/bin bash "$R" c6b-final2-inert-optimized "$P" -B -S -O "$N/test_native_imports.py" --check
env -i PATH=/usr/bin:/bin bash "$R" c6b-preservation-final "$P" -B -S "$N/evidence/native-transport/control/c6b-preserve.py" --after
env -i PATH=/usr/bin:/bin bash "$R" c6b-freeze-terminal "$P" -B -S "$N/evidence/native-transport/control/c6b-freeze.py" --after
```

All six statuses are `0`; raw files are in the identically named `E` directories. Normal and `-O` focused summaries:

```text
{"groups": 27, "source_only": true, "native_executed": false, "c6b_c6c_complete": false}
Exit status: 0
```

Coverage includes wrong identity/context/phase with no effects; unwrap/return/EOF/trailing/malformed/timeout/TLS EOF failures; distinct/same returned tokens; ownership/capture/timeout errors at later repeated stages; invalid time at every clock sample; exact close/cleanup exception identities; duplicate/reentrant calls; strict replacement acceptance/rejection. Inert checks retain shared canonical identity, empty/foreign import/main inertness, transport/test nesting 3. Python optimization modes are normal and `-O`; no Zig optimization mode ran.

Preservation raw outputs:

```text
{"public_paths": 6482, "private_paths_never_read": 25, "exact_additive_inventory": true}
{"native_sources": 7, "prior_safe_proof_paths": 6429, "private_originals_read": 0}
```

`c6b-freeze-valid` authenticated seven pre-edit sources against C6a archive SHA `c0bdf2032aedfeea034e08edc4b2ab170f122931df10e419bc9f12a57f9f96f9`; terminal freeze permits exactly the two assigned source edits and preserves 6,429 old safe proof files. C5 comparisons use all 25 reviewed public projections; private originals were never read/copied/hashed/printed. The initial `c6b-freeze` archive-prefix check counted zero and is invalid C6a proof; `c6b-freeze-valid` corrected it before source edits. Its C5 comparison remains valid.

Collector ordering is corrected in the new controller: fresh same-shell restoration precedes dependency snapshots/hashing and execution. Exact six-part PYTHONPATH, `PYTHONDONTWRITEBYTECODE=1`, seed 0, pinned `-B -S` interpreter SHA `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601` are retained. Original controller is preserved as `control/c6b-old-run.sh`; old restore logs remain zero-change history, without retrospective snapshot-authentication claims. `c6b-query` retains the bounded Graphify result; tool closure is hash-referenced, never recopied. Root owns final AST-only update; ignored-helper topology is unproved.

No compiler/server/socket/SSLContext/real clock/process-under-test/network/install/Git/publication operations ran. No old C4/C5/S46/all40 suites were repeated. Real signal authorization/watcher, active receive cleanup, termination/live receipts, provider/process/capture/cleanup acceptance, full build/gates, native all40 and adoption remain REQUIRED downstream.

## Fix round 1/5 diagnosis: canonical context anchor

The Important1 review finding reproduces. `strict_foreign_context_rejected` creates a genuine `adapter.open_case` context whose `raw['closing']` is `None`, then supplies a copied context with independent raw/stage and self-consistent binding claiming `clean_disconnect/pre_unwrap`. Original protocol/send/clock/deadlines remain exact. Existing `disconnect_close` incorrectly issues release; the regression fails `RuntimeError: missing rejection`.

Before adding the regression, `E/c6b-fix1-before` froze seven native sources and 9,299 prior safe transport proof/control paths (status 0, private originals read 0). Exact RED command:

```sh
env -i PATH=/usr/bin:/bin bash "$R" c6b-fix1-red-foreign "$P" -B -S "$N/test_native_transport.py" --check
```

Raw stdout/stderr/status and preserved source/control versions are at `E/c6b-fix1-red-foreign`; status 1. No production fix has been applied yet. A trusted canonical binding identity is unavailable to `connect`: canonical context creation occurs later inside `coordinator.run_child`, and existing operations/callbacks carry no context. Root was sent a narrow proposed one-time `bind_context(state, context)` registration contract, invoked after canonical context creation and before lifecycle execution. Additional self-consistency checks would not address the missing anchor. Root's contract ruling is pending before any interface/canonical/schema broadening.

## Fix round 1/5 terminal result

DONE_WITH_CONCERNS, pending scoped re-review. Root approved `task-5e3c6b-context-seam-plan.md`, resolving the preceding diagnosis and authorizing exactly one additional canonical source: `integration-owned/combined-cases/coordinator.py`. This supersedes the initial report's unchanged-coordinator limit. Historical archives, restoration authority, other 45 S46 sources, C4 and lifecycle/protocol code remain unchanged.

The coordinator names `BindContext = Callable[[Context], None]`. Existing descriptors may omit `bind_context`; present values must be callable and return exactly `None`. Unknown keys/missing existing hooks still fail. Original callback exceptions propagate. Invocation is once immediately after actual `adapter.open_case` returns its initialized clock/deadlines, before retained-output restoration, receives or handlers. Startup send already occurred inside `open_case`; this is post-open notification. Replacement contexts receive no speculative notification.

Native providers must supply `partial(native_transport.bind_context, state)`. The new native function validates initial nonclosing state and binds once, retaining actual context/stage/raw/request/credit/records/stage-binding object identities. Strict disconnect requires these identities before phase checks or effects. The trusted coordinator call site supplies authority; the binder alone does not authenticate arbitrary Python callers. No alternate first-binding path at close is valid. Conditional unwrap operation schemas remain unchanged.

Additional coverage in `test_native_transport.py`: optional absence and invalid callback; exact notification order/count/return and exception identity; missing notification; unbound/premature close; late first bind/rebind; foreign copied context; every retained component/binding replacement; cross-connection binding; initial-only registration; real canonical strict/replacement transition. The previous 27 groups remain intact; five added groups yield 32.

True notification RED: `E/c6b-fix1-red-notification` exited 1 with `RuntimeError: missing post-open binding notification` after descriptor schema acceptance and before invocation implementation. The original foreign-context behavioral RED remains at `E/c6b-fix1-red-foreign` (exit 1). Exact notification RED command uses the terminal variables below with label `c6b-fix1-red-notification` and target `"$N/test_native_transport.py" --notification-check`.

Pending source authority is explicit, separate from the unchanged historical 119-entry restorer. `control/c6b-fix1-pending.sha256` lists exactly three absolute source paths/hashes. Every final controlled shell restores first, verifies those hashes, snapshots code, then executes the identity-checking wrapper. The wrapper verifies the imported coordinator's exact resolved path/hash before target behavior. The initial query preflight rejected relative manifest paths before target execution; `c6b-fix1-query-authority-valid` corrected them. No pins were rewritten.

Final source SHA256 values supersede the initial C6b values:

```text
6585ad2323ce38a75948c7c365ceb7b9589c06e1c6010ae01ba35de0f11e6b32  integration-owned/combined-cases/coordinator.py
e09b73926fbd87ff4bb278f0952acb61fcdd93d2da1af9c3ec3ebdd97774a02e  combined-native/native_transport.py
e90ab753b524e8d6ef906ad856938b2f0630c43f7e6e6d36696b008276e73cdb  combined-native/test_native_transport.py
```

Exact changed code/control hashes are in `E/c6b-fix1-terminal.sha256`. Coordinator baseline provenance is `E/c6b-final2-normal/source/cases/coordinator.py`; preserved baseline bytes and 46-source hashes are `E/c6b-fix1-canonical-baseline/` and `control/c6b-fix1-canonical-baseline.sha256`.

Define `N`, `P` as above and:

```sh
C=$N/evidence/native-transport/control
R1=$C/c6b-fix1-run.sh
X=$C/c6b-fix1-execute.py
```

Exact terminal commands:

```sh
env -i PATH=/usr/bin:/bin bash "$R1" c6b-fix1-final-normal "$P" -B -S "$X" "$N/test_native_transport.py" --check
env -i PATH=/usr/bin:/bin bash "$R1" c6b-fix1-final-optimized "$P" -B -S -O "$X" "$N/test_native_transport.py" --check
env -i PATH=/usr/bin:/bin bash "$R1" c6b-fix1-inert-normal "$P" -B -S "$X" "$N/test_native_imports.py" --check
env -i PATH=/usr/bin:/bin bash "$R1" c6b-fix1-inert-optimized "$P" -B -S -O "$X" "$N/test_native_imports.py" --check
env -i PATH=/usr/bin:/bin bash "$R1" c6b-fix1-all40-explicit "$P" -B -S "$X" "$C/c6b-fix1-all40.py" --explicit
env -i PATH=/usr/bin:/bin bash "$R1" c6b-fix1-all40-omitted "$P" -B -S "$X" "$C/c6b-fix1-all40.py" --omitted
env -i PATH=/usr/bin:/bin bash "$R1" c6b-fix1-preservation "$P" -B -S "$X" "$C/c6b-fix1-preserve.py" --after
env -i PATH=/usr/bin:/bin bash "$R1" c6b-fix1-preserve-canonical "$P" -B -S "$X" "$C/c6b-fix1-freeze.py" --after
env -i PATH=/usr/bin:/bin bash "$R1" c6b-fix1-all40-summary "$P" -B -S "$X" "$C/c6b-fix1-summarize.py"
```

All nine statuses are `0`; each identically named `E` directory retains full stdout/stderr/status, exact argv/safe settings, restoration receipt, pending-source check and code/control snapshots. Focused normal and `-O` raw summary:

```text
pending_source_identity: PASS
{"groups": 32, "source_only": true, "native_executed": false, "c6b_c6c_complete": false}
Exit status: 0
```

Both inert runs pass with shared canonical identity and source nesting 3. Source all40 runs call unchanged `test_all40.check_composition` with canonical `catalogue.CASES`, explicit versus `omitted=True`; that accepted harness genuinely invokes `coordinator.run` without any selection argument for the latter. Neither writes old evidence. Both retained:

```text
all40_source_recomposition: PASS
Exit status: 0
```

Their actual JSON observations each contain 2 children, 40 dispatches, 41 receipts/connections, 802 heads, 789 small, request_flow 200091899, settings 46, informationals 2, incoming_resets 13, final_collections 2, receive_bytes 51312051 and receive_calls 31433. Invocation records are `positional=1` versus `positional=0`, both `selection_keyword=false`. Full original JSON remains in each run's stdout; compact extraction is `c6b-fix1-all40-summary/stdout`.

Preservation raw outputs:

```text
{"public_paths": 6482, "private_paths_never_read": 25, "exact_additive_inventory": true}
{"native_sources": 7, "retained_safe_proof_paths": 9299, "private_originals_read": 0, "unchanged_other_canonical_sources": 45}
```

All privacy, pinned interpreter, six-part PYTHONPATH and same-shell restoration constraints persist. No native operations or unrelated suites ran. Root owns scoped re-review, additive reviewed coordinator authority/publication and final AST-only Graphify update. C6c, provider/native acceptance and full project gates remain required.
