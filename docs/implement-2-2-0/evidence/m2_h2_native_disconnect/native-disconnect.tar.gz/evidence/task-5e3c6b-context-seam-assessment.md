The existing disconnect hooks do **not** expose an authentic context before `disconnect_close`.

`coordinator.run_child` calls `adapter.open_case` internally. The returned context remains local until the disconnect handler invokes the close hook. `connect` runs earlier; send/receive callbacks receive no context. Shutdown `preconditions` is unavailable for disconnect. Consequently, matching protocol/send/clock plus self-consistent `raw`/`stage` dictionaries cannot establish identity with that earlier canonical context.

Two bounded alternatives:

1. **Provider directly owns context creation.** If an authorized provider adaptation itself calls canonical `adapter.open_case`, it can immediately call a new `bind_context(state, context)` with that actual return. The binding retains context, stage, raw, request, credit and records identities after validating the existing canonical binding. This works only where the provider genuinely owns that creation call; adding the function alone does not solve integration through unchanged `coordinator.run`.

2. **Minimal coordinator notification—recommended for the current execution path.** Introduce an explicit child-descriptor `bind_context(context)` callback for disconnect selections. Validate its presence and invoke it immediately after `adapter.open_case` returns, before entering the receive loop or handler. The provider binds it to the transport state. This requires a small, separately authorized coordinator contract change; it preserves the seven-key connection, conditional unwrap operations, S46 protocol machinery and C4. It avoids monkeypatching factories, stack inspection or a duplicate coordinator.

`disconnect_close` must subsequently require the exact retained context **and** component identities, then validate their current canonical `pre_unwrap` state. Retaining only the context dictionary is insufficient because its fields could be replaced. Binding must be one-shot, tied to the current connection and rejected when first attempted at close.

Acceptance criteria:

- Real coordinator execution establishes the binding before disconnect handling.
- Unbound close performs no unwrap/receive/close operations.
- A copied context with self-consistent foreign raw/stage fails despite identical protocol/send/clock.
- Replacing components within the retained context also fails.
- The genuine bound context rejects premature close and permits the canonical transition.
- Binding cannot migrate between connections or be repeated.

If coordinator changes remain forbidden, the honest result is a missing integration seam—not an authentication claim based on the first close argument.
