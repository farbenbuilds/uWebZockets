# C6b: strict disconnect and safe replacement

Read task-5e3c6b-plan-report.md FIRST for exact interface/operation/fact contracts.
Read the existing C6 architect report/addendum and C6a report for current state,
deadline, ownership and callback invariants. BASE9e2b536e002aac168fefe28771e975cf9e073f6e
on feat/implement-2-2-0 is clean/pushed with exact six reviewed C6a files.

Own only combined-native/native_transport.py, test_native_transport.py and the
minimal source-evidence controls/new proof needed for this slice. New proof
under evidence/native-transport/ with fresh c6b-* labels; do not overwrite old
runs. Prefix .uwz-work/evidence/h2-streaming/. No new native modules/inventory
entry unless a concrete invariant requires one. You are sole implementer, not
alone: preserve all other work. No subagents/Git/publication. Root integrates.

Deliver the planned disconnect_close and conditional named unwrap operation,
retaining exact existing operation schemas for selections without disconnect.
Use the canonical descriptor, context, pre_unwrap phase and strict five facts.
Preserve original min(case,whole) deadline and monotonic integer ns clock; no
15-second ordinary-close cap or new budget. Public unwrap once, accept only
raw EOF, close the returned handle, preserve primary/cleanup exception identity
and sticky failure. No success/replacement after any failed acceptance step.
Canonical handlers remain sole lifecycle begin/finish owners.

Handle ownership transitions explicitly. A valid returned raw handle becomes
the cleanup target before post-unwrap time/health checks. An invalid absent
return must not lose the still-identifiable TLS cleanup target. Do not require
raw and TLS opaque tokens to be different objects; prove correct returned-
handle use with distinct tokens and permit a valid same-token transfer. Do not
retry a successfully closed resource. Failure cleanup never creates release
proof. Replacement connection2 is permitted only after strict first-connection
release; ordinary cleanup alone must not authorize it.

TDD: real canonical disconnect/replacement hook (or a precisely qualified
transition test ending at an expected sentinel), exact facts/deadlines; wrong
identity/context/phase/no effects; TLS unwrap failure and malformed return;
raw trailing/malformed bytes, EOF, timeout/TLS EOF; ownership/capture/timeout
errors; time expiry/regression at every stage; returned-handle cleanup and
close-error identity; duplicate/reentrant calls; replacement acceptance and
rejection. Keep ordinary EOF rejection and accepted C4 binding intact. Run
focused normal/-O and inert checks; no old C4/C5/S46/all40 suites absent a new
concrete coverage gap. No actual compiler/server/socket/SSLContext/real-clock/
process-under-test/network/install operations. Scripted opaque handles only.

Resolve the carried collector minor in new evidence: restore first, snapshot
the authenticated executed source bytes, then run target in SAME controlled
shell. Preserve old controller before modifying it. No replay of old tests to
repair history; current old restore logs were0 and remain qualified. Do not
copy another Graphify closure; use retained hash references and Root final
AST-only update if needed. Snapshots are source/code only, no old evidence.

Freeze the C6a approved seven native sources and prior public evidence bytes
before edits, with native_transport/test_native_transport as the only intended
code changes. C6a archive is docs/implement-2-2-0/evidence/m2_h2_native_connection/
native-connection.tar.gz, SHAc0bdf2032aedfeea034e08edc4b2ab170f122931df10e419bc9f12a57f9f96f9.
The public parent C5 view has6482paths and25 private local original environments;
use only its reviewed safe projections for comparison. NEVER read/copy/hash/
print those originals or dump ambient environment. Do not traverse/copy whole
evidence trees into snapshots. New controllers use env-i/explicit safe controls.
Retain every exercised code/control version before runs, safe argv/settings,
fresh restore receipts and full stdout/stderr/status. All canonical/S46/C4/C5/
candidate/dependency/product/pin and committed files remain unchanged.

Follow AGENTS/conventions/verification+transport/TLS and narrow API/TDD skills.
No classes/assert/custom errors/global mutable state/hidden OOP, no silent
errors, functions <=3 control nesting. No placeholder C6c hooks. Real signal,
active receive cleanup, termination/live receipts and provider/runtime/build/
native all40/full gates/adoption remain REQUIRED later, never fake them.

Python/tooling EXACTLY as C6a brief: pinned /home/codespace/.python/current/bin/
python3 -B -S SHA4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601,
PYTHONDONTWRITEBYTECODE=1, fresh task-5e3b8a-restore-inputs.py --restore
NEW_ABSOLUTE_RECEIPT immediately before EACH dependent Python shell operation,
same shell, exact six-part PYTHONPATH from C6a/fullC6 brief. Graphify before NEW
questions/searches; supplied paths located; final AST-only/no ignored topology
claim. No skill edits or weaker gates.

Write task-5e3c6b-report.md here <=1200words preferred, exact files/interfaces/
hashes/commands/results/raw paths/concerns and remaining scope. Return concise
DONE|DONE_WITH_CONCERNS|NEEDS_CONTEXT|BLOCKED. Raise actual conflicts early.
