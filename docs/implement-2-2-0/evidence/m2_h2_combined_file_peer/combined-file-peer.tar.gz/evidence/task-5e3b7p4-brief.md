# File and early-final peer construction

Released after reviewed/pushed P3 atde4ce702c491b9516ec75e1b7c874cae56cb7d50.
BASE is this commit. Exact38-module accepted source authority is
docs/implement-2-2-0/evidence/m2_h2_combined_producer_peer/manifest.json, bound
by task-5e3b7p3-root-commit-audit.json. Preserve this baseline.
Read task-5e3b-peer-extraction-addendum.md P4 and
task-5e3b-coordinator-composition-plan-report.md. Prepare actual
shared family constructors for later coordinator composition; do not substitute
driverchecks/defaultmodels for coordinator execution. All37ordinary/default/
all40/native/adoption/fullmilestones remain required.

Own only combined-cases/test_file_early.py, new evidence/file-peer and
task-5e3b7p4-report.md. A demonstrated small producer-module adjustment requires
specificRootrelease beforeedit; no automatic shared-file expansion. No other
module/immutable core/model/fixture/helper/codec/product/pin/limit/deadline edit.
You are notalone; preserveothers/allraw/source/history. Root owns independent
review/publication/commits/refs/pushes. No agents/externalCLI/public/Git/native.

Promote new_peer(case,*,app,prior,now,clock,final=False,fault=None), exact
{connection,state}; sevenconnectionfields protocol,send,receive,now,owned,tls,
alpn. Pinnedinitiatedprotocol and queued initialSETTINGS+ACK, suppliedsynthetic
owned/TLSv1.3/h2 facts. No constructionclock/clientdispatch/adapterobserve/
finalization/apptransition. Keep single familyserializationimplementation used
by unchanged-interface standalone check() and futurecoordinator factory.

Persistentapp exactlyrecords,heads,outputs,binding fromreviewedcore/producer
contracts; initialunselecteddefaults and absentobservedbindingNone. prior must
validateactualearnedfacts, never seedundispatchedwork. Preserve retainedproducer
diagnostics/Bbinding while file/early actions earn onlytheir ownfacts. Resolve
modeldefaultbinding conversion only atvalidator-required unselectedpostdefault,
not as an observedbinding. Do not clear or manufacture retainedprioroutputs.

Move peer/clientcontext coupling into standalone-driver wrappers invoking
originalcalls once/preservingresults/errors. Generate ownfile/early diagnostics
when concretefactsserialize; retain bounded independentcopies inpeerapp. Compare
client-parsedobservations with separatecopies; never copyclientobservations into
app to establish truth. Peer decisions use serializedrequests/credit/resets/
finite progress only. No generic protocolframework/callbackregistry/**kwargs/
forwardingwrapper withoutinvariant; no duplicated movedpeerimplementation.

Preserve actualproducer->file->early-finalchain, standalonefinals, exactfile
range/content-length/sourcehash/sentinels/closeownership and END_STREAM-before-
reset controls. Derive every exactmetadata/payload/hash/range value fromcurrent
immutablecontracts/handlers/acceptedtests ratherthan guessing. Incrementalhash/
count/generation and boundedchunks/packets; no wholefile/output/history retained.
Keep original request/responsecredit/parser/stage/cumulativecaps/deadlines and
retainedfacts. Validate all storagecapacity beforegrowth and strict scalar types.
final permits prescribedfinal68 onlyafterfinitecase; never markscompletion.

Add meaningful constructor/no-clock/no-dispatch/no-seed/independence/priorproof
and independentpeertruth checks inowneddriver; preserve everyexistingpositive
andnegative, not just newfactories. Capture actualbaseline, truthfulinterfaceRED
scope and anynewbehaviorRED beforefix; do not fabricatewireRED for missingAPI.
Before/frozen/current/source/input identities and priorhashmaps preserved; reuse
preexistingfrozenfiles only afterexactcontentidentity/provenancecheck, no recopy
or overwriteoldraw. All errors/intermediateoutcomes remain separatelyqualified.

Afterfinalsourceedit run test_file_early.py/test_imports.py normal/-O pinned
Python -B -S; producercoveringnormalO only ifactuallychanged or concreteunanswered
dependency. No broadprecedingmatrixrepeat. Current38 AST/oneguard/actualinert
empty+foreignargv imports, everyauthoredrecordertoo. No classes/assert/custom
exceptions/modulemutableglobals/deadcode/camelCase/ignored errors/nesting>3.

Pinned /home/codespace/.python/current/bin/python3 SHA
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
Existing model /tmp/uwz-task5e1-contract-v3,core26
/tmp/uwz-task5e3a-snapshot-v9/source,codecs /tmp/uwz-h2-client-tooling/packages,
integration-client helper/combined-cases exactPYTHONPATH. Immutable119entries:
118physical113resolved +ordered42codecaggregate SHA
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Keep originalroworder/encoding. No installs/network/native/build/server/socket/
SSLContext/TLS-close/realclock/processownership/transfer/kernel/fault/cancel/
schedule/interleaving/race/resource/panic/crash/leak/oldruntimeentrypoint execution.
Onlypinned in-memorycodecs and suppliedsynthetic app/transport/processfacts.

Graphifyquery before newcodebasequestion/search/source read, exactreleaseprefix:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650
Providedpaths located. Readproject/role/narrowskills, no unrelatedtools/interview.
Reportactualcontracts/oracleownership/bounds/files, baseline/RED/failure/current
commands/rawpaths/source/input/frozen/historyidentity/selfreview/remaininggaps.
Returnstatus/reportpath/checksummary/concerns under15lines; no commit.
