"""Package reviewed file and early-final peer source with qualified history."""
import hashlib
import json
import runpy
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    provenance = Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_peer/combined-core-peer.tar.gz')
    if sha(provenance.read_bytes()) != 'dbcd7a01a56a3c80600aa39fa7b61dec00060976c14a82e2bd4a712a2520d25d':
        raise ValueError('Writer provenance differs')
    builder = plan / 'task-5e3b7p1-build-publication.py'
    with tarfile.open(provenance, 'r:gz') as previous:
        if previous.extractfile('evidence/' + builder.name).read() != builder.read_bytes():
            raise ValueError('Published writer source differs')
    writer = runpy.run_path(str(builder))['load_writer'](plan)
    baseline = Path('docs/implement-2-2-0/evidence/m2_h2_combined_producer_peer/combined-producer-peer.tar.gz')
    if sha(baseline.read_bytes()) != '592fb804e9cff48fe154358b87fadba2a5bb0a8b7b94a854e9b41416a17cc5a0':
        raise ValueError('Baseline archive differs')
    members, latest_raw = {}, {}
    with tarfile.open(baseline, 'r:gz') as previous:
        inventory = json.loads(previous.extractfile('INVENTORY.json').read())
        for member in previous:
            if not member.isfile():
                raise ValueError('Nonregular baseline member')
            if member.name == 'INVENTORY.json':
                continue
            data = previous.extractfile(member).read()
            if inventory[member.name] != dict(size=len(data), sha256=sha(data)):
                raise ValueError('Baseline inventory differs')
            if member.name.startswith('reference/') or member.name.startswith('history/') and member.name.endswith('map.json'):
                writer['add'](members, member.name, data)
            if member.name.startswith('source/current/'):
                writer['add'](members, member.name.replace('source/current/', 'history/producer-peer-source/', 1), data)
            if member.name.startswith('raw/producer-peer/'):
                latest_raw[member.name] = inventory[member.name]
    writer['add'](members, 'history/producer-peer-published-raw-map.json', (json.dumps(latest_raw, indent=2) + '\n').encode())
    audit = json.loads((plan / 'task-5e3b7p4-root-final-audit.json').read_text())
    current = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if current != audit['current_source_sha256']:
        raise ValueError('Approved source differs')
    for path in sorted(source.glob('*.py')):
        writer['add'](members, 'source/current/' + path.name, path.read_bytes())
    raw = source / 'evidence/file-peer'
    for path in sorted(raw.rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink in evidence')
        if path.is_file():
            writer['add'](members, 'raw/file-peer/' + path.relative_to(raw).as_posix(), path.read_bytes())
    names = ('task-5e3b7p4-brief.md', 'task-5e3b7p4-report.md', 'task-5e3b7p4-review-brief.md',
             'task-5e3b7p4-review-report.md', 'task-5e3b7p4-review-source.diff',
             'task-5e3b7p4-root-final-audit.json', 'task-5e3b7p4-build-publication.py',
             'task-5e3b-peer-extraction-addendum.md', 'task-5e3b-coordinator-composition-plan-report.md')
    for name in names:
        writer['add'](members, 'evidence/' + name, (plan / name).read_bytes())
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_combined_file_peer')
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'combined-file-peer.tar.gz'
    inventory = writer['write_archive'](archive, members)
    manifest = dict(scope='Pure file/early-final peer construction with independent diagnostics',
                    base_commit='de4ce702c491b9516ec75e1b7c874cae56cb7d50', baseline_archive_sha256=sha(baseline.read_bytes()),
                    archive=archive.name, archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
                    safe_regular_text_members=len(members), inventory_entries=len(inventory), current_source_files=current,
                    changed_files=['test_file_early.py'], added_files=[], unchanged_producer_peer_modules=37,
                    current_normal_optimized_commands=4, current_ast_inert_import_files=38,
                    earlier_recorded_evidence_hashes_checked=4412,
                    latest_published_raw_files_checked={'lifecycle-peer': 308, 'core-peer-capacity': 83, 'producer-peer': 226},
                    exhaustive_fresh_later_history_map_captured=False, pre_fix_boundary_behavioral_red_captured=False,
                    initial_red_scope='Missing constructor API only', retained_identity_entries=119,
                    physical_identity_rows=118, unique_file_paths=113, ordered_codec_files=42,
                    observed_case_J_C_R={'stream_file': [7,6,33], 'early_final_order': [7,6,32]},
                    output_bytes={'stream_file': 24593, 'early_final_order': 17},
                    parser_buffer_limit=8201, frame_payload_limit=8192, pending_deferred_packet_limit=12,
                    independent_file_diagnostics_earned_at_serialization=True, retained_producer_binding_and_outputs=True,
                    receive_wrapper_once_result_error_identity=True,
                    source_review='Spec and quality approved; historical RED/history gaps explicitly retained',
                    supplied_transport_lifecycle_facts=True, coordinator_supported_nonempty_selections=[['ready_buffered']],
                    explicit_empty_supported=True, default_supported=False, combined_all40_executed=False,
                    native_executed=False, milestone_complete=False,
                    remaining=['All37 ordinary coordinator composition', 'Disconnect/shutdown children',
                               'Actual default/all40 aggregate and broad combined-client review',
                               'Runtime/native/full gates and production adoption'])
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
                  regular_members=len(members), inventory_entries=len(inventory), source_modules=len(current),
                  all_reopened_member_bytes_exact=True, native_executed=False)
    (plan / 'task-5e3b7p4-root-archive-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
