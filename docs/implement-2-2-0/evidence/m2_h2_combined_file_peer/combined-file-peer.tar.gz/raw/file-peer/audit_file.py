"""Verify accepted inventory, immutable identities and retained earlier receipts."""
import importlib.util
import json
from pathlib import Path


def main():
    evidence = Path(__file__).resolve().parent
    root = evidence.parents[1]
    spec = importlib.util.spec_from_file_location('audit', root / 'evidence/core-peer/audit.py')
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    audit.immutable(root, evidence)
    manifest = Path('docs/implement-2-2-0/evidence/m2_h2_combined_producer_peer/manifest.json')
    accepted = json.loads(manifest.read_text())['current_source_files']
    current = {path.name: audit.sha(path) for path in sorted(root.glob('*.py'))}
    if len(current) != 38 or set(current) != set(accepted):
        raise RuntimeError('source inventory differs')
    if {name for name in current if current[name] != accepted[name]} != {'test_file_early.py'}:
        raise RuntimeError('source scope differs')
    if audit.sha(evidence / 'before-source.py') != accepted['test_file_early.py']:
        raise RuntimeError('before source differs from accepted baseline')
    history = json.loads((root / 'evidence/lifecycle-peer/prior-evidence-map.json').read_text())
    for name, digest in history.items():
        if audit.sha(root / name) != digest:
            raise RuntimeError('prior evidence differs: ' + name)
    audit.structure(root, evidence)
    audit.inert_helpers(evidence)
    audit.snapshot(root, evidence, 'current-source')
    print('accepted=38 changed=test_file_early.py prior_history=%d current=%s' %
          (len(history), current['test_file_early.py']))


if __name__ == '__main__':
    main()
