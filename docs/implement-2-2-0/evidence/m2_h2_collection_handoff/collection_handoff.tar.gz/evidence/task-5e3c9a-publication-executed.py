"""Publish the handoff revision with a lossless content-indexed evidence packet."""
import base64
import hashlib
import json
import runpy
import stat
import sys
import tarfile
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def api(plan, name):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_native_builds/native_builds.tar.gz')
    require(sha(archive.read_bytes()) == 'e3b8fe1c3c0a5f99a8144752eddab62f5568dcf6c9f7a51719bd669f3b6874a0', 'C8 archive differs')
    helper = plan / 'task-5e3c8-artifact-api.py'
    with tarfile.open(archive, 'r:gz') as source:
        require(source.extractfile('evidence/' + helper.name).read() == helper.read_bytes(), 'Published archive API differs')
    return runpy.run_path(str(helper))['published'](plan, name)


def packet_objects(packet):
    members = {}
    index = {}
    for path in sorted(packet.rglob('*')):
        require(not path.is_symlink(), 'Packet symlink')
        if path.is_dir():
            continue
        require(path.is_file() and path.suffix.lower() not in ('.pem', '.key'), 'Invalid or private packet member')
        add_object(members, index, path, packet)
    members['PACKET_INDEX.json'] = (json.dumps(index, indent=2) + '\n').encode()
    return members, index


def add_object(members, index, path, packet):
    data = path.read_bytes()
    digest = sha(data)
    try:
        data.decode('utf-8')
        encoded, encoding = data, 'utf8'
    except UnicodeDecodeError:
        encoded, encoding = base64.b64encode(data) + b'\n', 'base64'
    name = 'objects/' + digest + '.' + encoding
    if name in members:
        require(members[name] == encoded, 'Content object collision')
    else:
        members[name] = encoded
    index[path.relative_to(packet).as_posix()] = dict(object=name, encoding=encoding,
        bytes=len(data), sha256=digest, mode=stat.S_IMODE(path.stat().st_mode))


def root_records(plan):
    names = [
        'task-5e3c9a-brief.md', 'task-5e3c9-handoff-plan-report.md', 'task-5e3c9a-report.md',
        'task-5e3c9a-before-fix1-report.md', 'task-5e3c9a-review-report.md', 'task-5e3c9a-fix1-review-report.md',
        'task-5e3c9a-unit-triage-report.md',
        'task-5e3c9a-review-package.diff', 'task-5e3c9a-fix1-review-package.diff',
        'task-5e3c9a-root-audit.py', 'task-5e3c9a-root-audit-executed.py', 'task-5e3c9a-root-audit-code.sha256',
        'task-5e3c9a-root-audit.json', 'task-5e3c9a-root-audit-inputs.json',
        'task-5e3c9a-root-final-graph-command.sh', 'task-5e3c9a-root-final-graph-inputs.json',
        'task-5e3c9-snapshot-dedup.py', 'task-5e3c9-snapshot-dedup-executed.py',
        'task-5e3c9-snapshot-dedup-code.sha256', 'task-5e3c9-snapshot-dedup-before.json',
        'task-5e3c9-snapshot-dedup-after.json', 'task-5e3c9-snapshot-dedup.json',
        'task-5e3c9-snapshot-dedup-inputs.json', 'task-5e3c9a-publication.py',
        'task-5e3c9a-publication-executed.py', 'task-5e3c9a-publication-code.sha256']
    stems = ('root-audit', 'root-format', 'root-conventions', 'root-version', 'root-dependencies', 'root-unit', 'root-unit-seed-repro', 'root-final-graph')
    names.extend('task-5e3c9a-' + stem + '.' + suffix for stem in stems for suffix in ('stdout', 'stderr', 'exit'))
    names.extend('task-5e3c9-snapshot-dedup.' + suffix for suffix in ('stdout', 'stderr', 'exit'))
    members = {'evidence/' + name: (plan / name).read_bytes() for name in names}
    for path in sorted((plan / 'task-5e3c9a-fix1-base').iterdir()):
        require(path.is_file() and not path.is_symlink(), 'Invalid fix baseline')
        members['evidence/fix1-base/' + path.name] = path.read_bytes()
    return members


def collect(plan, packet):
    members, index = packet_objects(packet)
    members.update(root_records(plan))
    revision = (packet / 'handoff/revision.json').read_bytes()
    require(sha(revision) == '8fc6c797a5d481c36b25636df0e909635000e66b7baa25ef52d5ce67b7a8f9ae', 'Reviewed revision differs')
    members['SOURCE_REVISION.json'] = revision
    for name in ('coordinator.py', 'shutdown_cases.py'):
        members['source/canonical/' + name] = (packet / 'handoff/new' / name).read_bytes()
        members['baseline/canonical/' + name] = (packet / 'handoff/old' / name).read_bytes()
    return members, index


def build(plan, packet, folder):
    members, index = collect(plan, packet)
    writer = api(plan, 'task-5e3c1-build-publication.py')
    safe = {}
    for name, data in members.items():
        writer['add'](safe, name, data, {})
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'collection_handoff.tar.gz'
    inventory = writer['write_archive'](archive, safe)
    manifest = dict(scope='Reviewed C9a source handoff; native full40 remains unaccepted',
        base_commit='67a8be8b4a6a4aa35e94fae68d53d0f7d2dd3c7b', archive=archive.name,
        archive_sha256=sha(archive.read_bytes()), archive_bytes=archive.stat().st_size,
        safe_regular_utf8_members=len(safe) + 1, inventory_entries=len(inventory),
        logical_packet_files=len(index), unique_packet_objects=len({row['object'] for row in index.values()}),
        packet_index='PACKET_INDEX.json', encoding='Lossless UTF-8/base64 content objects with per-path size/hash/mode',
        revision_sha256=sha(members['SOURCE_REVISION.json']), canonical_runtime_files_revised=2,
        unchanged_canonical_modules=44, unchanged_legacy_tests=3, native7_unchanged=True,
        opaque_context_internals='Identity only; not a general deep freeze',
        completed_snapshot_dedup='Bytes/modes/ownership/paths preserved; shared inode timestamps qualified',
        repository_unit_initial='851/852; C ephemeral TLS lifecycle test terminated by SIGTERM',
        repository_unit_same_seed_replay='852/852 and22/22; seed0x240412be, no source/test/assertion changes',
        repository_unit_sigterm_attribution='Unproven; triage and failed output retained, capture sender if it recurs',
        prior_incomplete_native_attempts_preserved=True, new_revision_native_executed=False,
        native_full40_accepted=False, production_pin_changed=False, milestone_complete=False)
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({key: manifest[key] for key in ('archive_sha256', 'archive_bytes', 'safe_regular_utf8_members', 'logical_packet_files', 'unique_packet_objects')}))


def audit_publication(plan, packet, folder):
    expected, index = collect(plan, packet)
    reader = api(plan, 'task-5e3c1-publication-audit.py')
    manifest = json.loads((folder / 'manifest.json').read_text())
    archive = folder / manifest['archive']
    require(archive.stat().st_size == manifest['archive_bytes'] and sha(archive.read_bytes()) == manifest['archive_sha256'], 'Archive identity differs')
    actual = reader['read_archive'](archive)
    require(actual == expected and len(actual) == manifest['inventory_entries'], 'Complete archive member bytes differ')
    for name, row in index.items():
        data = actual[row['object']]
        decoded = base64.b64decode(data.strip(), validate=True) if row['encoding'] == 'base64' else data
        require(decoded == (packet / name).read_bytes() and sha(decoded) == row['sha256'] and len(decoded) == row['bytes'], 'Logical packet bytes differ')
        require(stat.S_IMODE((packet / name).stat().st_mode) == row['mode'], 'Logical packet mode differs')
    check = api(plan, 'task-5e3c1-prepare-review.py')['root_check']
    helpers = {name: check((plan / name).resolve()) for name in ('task-5e3c9a-root-audit.py', 'task-5e3c9a-publication.py', 'task-5e3c9-snapshot-dedup.py')}
    docs = Path('docs/implement-2-2-0')
    files = [docs / 'README.md', docs / 'm2_request_streaming.md', docs / 'm2_h2_collection_handoff.md',
             folder / 'README.md', folder / 'manifest.json', archive]
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=archive.stat().st_size,
        inventory_entries=len(actual), logical_packet_files=len(index), helpers=helpers,
        local_links_checked=reader['verify_links'](files),
        delivery_files={str(path): dict(size=path.stat().st_size, sha256=sha(path.read_bytes())) for path in files},
        new_revision_native_executed=False, native_full40_accepted=False, milestone_complete=False)
    (plan / 'task-5e3c9a-root-publication-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('helpers', 'delivery_files')}))


def main(arguments):
    if arguments not in (['--build'], ['--audit']):
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    packet = Path('.uwz-work/evidence/h2-streaming/native_provider')
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_collection_handoff')
    if arguments == ['--build']:
        build(plan, packet, folder)
        return
    audit_publication(plan, packet, folder)


if __name__ == '__main__':
    main(sys.argv[1:])
