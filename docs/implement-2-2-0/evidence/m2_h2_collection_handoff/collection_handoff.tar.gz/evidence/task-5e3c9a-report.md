C9a is DONE for source review. C9 actual native full40 remains incomplete and paused until Root independently reviews, publishes, commits/pushes, and releases the two-file source override. No target defect or native full40 success is claimed.

The optional named `BindCollection(context, actual_capture) -> None` callback now passes from the coordinator descriptor into shutdown hooks. Ordinary completion hands off its stored original collection immediately after collection; idle and active paths hand off the exact returned collection before close/signal. The helper preserves absence behavior, rejects noncallables/non-None returns, and protects the original records/metrics mappings and scalar facts against callback mutation. Collector calls, parsers, request sequence, barriers, deadlines, termination, publication and result schemas remain unchanged. No production module-global replacement was introduced.

The provider validates the current bound context, terminal case and one-shot ownership, validates the actual records/metrics with the existing model, obtains output/binding facts through `shutdown_cases.outputs`, and freezes detached facts with `coordinator.copy_facts`. Signal now requires this retained baseline; it never reads a missing late `final_observations` field. Wrong context, duplicate binding, missing baseline and mutation isolation are covered.

Only these canonical files changed:

| File | Old bytes / SHA256 | New bytes / SHA256 |
|---|---|---|
| `coordinator.py` | 23073 / `6585ad2323ce38a75948c7c365ceb7b9589c06e1c6010ae01ba35de0f11e6b32` | 23518 / `4c00e7ae957d2ca488dd14b9814c91f3068a5aa61758ab9a43fb81483a200bb0` |
| `shutdown_cases.py` | 7689 / `2856e200fa463b26c79e4e0b74cc9ead4863f9a1dd6372c0e8249fb9b163e15c` | 8996 / `a757f12ec8fcdbf33d0d2fca06c723306dbc641569f4c8347992ff3e0ba2103e` |

Both are under `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/`. Old bytes were checked against C8 preflight SHA `e78cbbc2f1665e6999a5502f2817be531909a80d72e1dbd0fd22055dc93bb53c` before editing and preserved under `P/handoff/old/`. Exact new snapshots are under `P/handoff/new/`. `P/handoff/revision.json` SHA is `aed73728f5feb482abf94941b2f22704fae10d03f509a2023c4bd7f68e745e05`; full scoped diff SHA is `15ee9d7a3c36b762483fb8685d0f6e5d23b82973240797afcb63636581f1c4eb`.

Own packet changes are `native_provider.py`, `run_native.py`, new `test_collection.py`, extended `test_provider.py`, source controls, snapshots, and handoff evidence. The three original test files remain byte-identical, verified by `P/handoff/unchanged-tests.sha256` and the C8 import manifest. Adapter, native7, fixtures, binaries, SDK, dependency/product/pin state and C8 authorities were not modified. C8 archival equality remains strict.

Here `P=.uwz-work/evidence/h2-streaming/native_provider`. Every proof used this exact form from Root cwd:

```sh
env -i PATH=/usr/bin:/bin /bin/sh "$P/run_control.sh" NAME [-O] "$P/run_native.py" --source MODE
```

The wrapper authenticates bootstrap/tool/data/source controls and runs unchanged pinned119 restoration into a fresh receipt in the same shell before Python `/home/codespace/.python/current/bin/python3 -B -S` (optimized proofs add `-O`). Sources and controls are snapshotted before each execution. Full argv/stdout/stderr/status are `P/raw/NAME.{argv,stdout,stderr,exit}`.

| NAME | MODE | Raw result |
|---|---|---|
| `32_collection_red` | descriptor | 1: existing validator rejected the optional callable, `child descriptor fields differ`; behavioral RED, no absent-interface error |
| `33_collection_green` | descriptor | 0 |
| `48_collection_final`, `39_collection_optimized` (-O) | focused | 0 each; exact identities/order, legacy result/request equality, malformed/mutating hooks, original exceptions, and ten provider groups passed |
| `40_legacy`, `44_legacy_optimized` (-O) | legacy | 0 each; original `test_coordinator`, `test_coordinator_shutdown`, `test_shutdown` ran unchanged |
| `41_source_full40_explicit`, `45_source_full40_explicit_optimized` (-O) | full40_explicit | 0 each |
| `42_source_full40_omitted`, `46_source_full40_omitted_optimized` (-O) | full40_omitted | 0 each |
| `43_source_inert`, `47_source_inert_optimized` (-O) | inert | 0 each; canonical AST/import and provider import/rejected direct CLI guards passed from foreign cwd |

The unchanged, C8-authenticated `test_all40.py` source driver observed 40 dispatches, two fresh fake children, 41 connections, 802 heads, 789 small responses, request flow 200091899, 46 settings, two informationals, 13 incoming resets and two final collections. Explicit invocation recorded one positional argument; omitted selection recorded zero positional arguments and no selection keyword. These are pure source/fake-peer results, not native observations or performance measurements.

Failures34/35 preserve pre-load graph rejection of `_heapq` and `_interpreters`. Source-only unittest dependencies were subsequently declared explicitly and admitted only against already-pinned C8 identities and independently approved dependencies. Native runtime approval remains separately limited; unrelated identity-bound `_csv` still rejects without an approved graph. Failure36 corrected an invalid test expectation: ordinary teardown already publishes a detached copy, whereas identity is required at handoff. Failure37 corrected a test that mistakenly required the final collection before an earlier ordinary connection close. Neither correction weakened canonical behavior.

Control49 invoked the ordinary native entry with `--run debug explicit r9`; it rejected with status1 at C8's unchanged source-identity gate before native execution or creation of that run directory. Source-only approval cannot authorize native effects. The source inventory SHA is `4e3d6a80bb89f80507690526669d93887edea0434ad6c6e26b73f4d540ab9876`; two-file source control SHA is `6b36a30ca27997ac9f347ba446ffbe3c1054d9c20b32b1d74d3efd375ef65c1b`.

Self-review found no new parser, case exclusion, weaker threshold, production global mutation, class/assert/custom error, private-original environment access or private certificate/key publication. Source compatibility does not authenticate real process/TLS/closing/post behavior. Root owns review/publication/release of the revision; C9 still requires all four actual native runs against that reviewed override. H3, adoption, platform/release gates and full M2 remain later.

FIX1: DONE for scoped re-review; the initial boundary was rejected for P1/P2 and is superseded here. Previous report, revision, diff, controls and canonical bytes remain under `P/handoff/before_fix1/`; Root also retained its independent fix1 base.

P1 now snapshots caller-owned builtin context data, retaining original container identities and typed frozen leaves. Matching checks original structure before descending; cycles are tracked. Count, case/whole deadline and time mutation reject before terminal effects. P2 uses the same typed matching for capture facts, so bool/int equality cannot bypass mutation detection. Opaque protocol/hash/callback objects retain identity and are never deep-copied; their internal behavior remains outside this data guard. Callback exceptions still propagate as the exact original object. Absent hooks remain immediate no-ops.

Covering file is `P/test_collection.py`. Behavioral RED50 (`--source regression_context`, status1) printed `OLD_BOUNDARY_TERMINAL_EFFECT heads ['close']`; RED51 (`--source regression_capture`, status1) printed `typed_capture_rejected int bool False`. These exercised existing boundaries, not absent interfaces. Green52/53 returned0; all four int/bool transitions printed True. Consolidated regressions also prove typed rejection before idle close/active signal, unchanged provider callback operation and exact exception identity after context mutation.

Using the same pinned/bootstrap/fresh119 command form above, final controls all returned0:

- `63_fix1_final_focused`, `64_fix1_final_focused_optimized` (-O): `--source focused`; mutation regressions, provider positive paths and ten provider groups passed.
- `66_fix1_final_legacy`, `71_fix1_final_legacy_optimized` (-O): `--source legacy`; all three unchanged suites passed.
- `67_fix1_final_hook_explicit`, `68_fix1_final_hook_omitted`, optimized69/70: `--source full40_hook_explicit` / `full40_hook_omitted`; each executed the unchanged driver baseline and a separate provider-hook composition. Full canonical results and ordered wire receipts were exactly equal. Both omitted calls genuinely omitted selection. These remain source/fake-peer results.
- `72_fix1_final_inert`, `65_fix1_final_inert_optimized` (-O): `--source inert`; foreign-cwd imports/CLI guards passed.

No further canonical file changed: coordinator remains23518B/SHA`4c00e7ae957d2ca488dd14b9814c91f3068a5aa61758ab9a43fb81483a200bb0`. Shutdown cases is now10562B/SHA`c03bc49a65760d3fa99cf45078b893ecebbc4dd3602de6ced4017207b1f08eb7`. Refreshed revision SHA is `8fc6c797a5d481c36b25636df0e909635000e66b7baa25ef52d5ce67b7a8f9ae`; full diff `adc18b69d09b106664b01e808cedb6addd4dc111e59c6744a2b106e5f084b5d0`; fix1-only diff `1859f84a96f54a483ef9613d9896465137d726e48752d3f4b661a68f2e3a8678`. Current source inventory is `32785ae3b8707b12c79474db30c05b3644de6c81753df21d0e5fbfd35c1e33b2`; two-file control `f03116283571f467aa343b813df500a6b04b944555315ca6ccc2dafcd7b3ed6a`. Original three test hashes rechecked unchanged. No native effects, publication, Git, C8/native7/target/product/pin changes occurred. Root re-review/publication/release and all four actual native runs remain required.
