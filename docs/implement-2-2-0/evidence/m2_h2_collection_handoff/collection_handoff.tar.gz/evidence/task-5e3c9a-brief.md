# C9a: explicit final-collection handoff, before further native execution

Read `task-5e3c9-handoff-plan-report.md` FIRST. Root approves its optional
`bind_collection(context, actual_capture) -> None` seam, including ordinary,
idle and active completion paths, and rejects the module-global monkeypatch.
The actual r3 provider failure shows the pre-fact timing gap; no target defect
has been established. BASE remains67a8be8b4a6a4aa35e94fae68d53d0f7d2dd3c7b.

SAME C9 implementer is sole owner. Additional edit ownership is ONLY:
`.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/coordinator.py`
and sibling `shutdown_cases.py`, plus own native_provider packet/callback/tests.
No other canonical, native7, product, pin, fixture, binary, C8 code or historical
evidence edits. You are not alone; shared-file edits stay serialized. No
subagents/Git/publication writes. No new target/socket/SSLContext/cert/clock/
signal operations until Root reviews and publishes this source revision.

Old identities are independently fixed by C8 preflight-fix1
e78cbbc2f1665e6999a5502f2817be531909a80d72e1dbd0fd22055dc93bb53c:
coordinator23073B SHA6585ad2323ce38a75948c7c365ceb7b9589c06e1c6010ae01ba35de0f11e6b32;
shutdown_cases7689B SHA2856e200fa463b26c79e4e0b74cc9ead4863f9a1dd6372c0e8249fb9b163e15c.
Before editing preserve exact old bytes and after source-only verification emit
an explicit old/new path/size/hash revision manifest and full scoped diff.
Do not overwrite C8 acceptance or weaken its strict archived-source equality.
C9 will consume a separate reviewed two-file override after publication.

Keep all collector calls/return objects/requests, outputs/barriers/deadlines,
begin/finish termination, post publication and final result schemas unchanged.
The named optional callable is validated before use. Its return must be None;
callback failure propagates unchanged before close/signal. No hook retains
current behavior. The provider stores detached actual records/metrics outside
the canonical context, with exact context and one-shot ownership validation;
the callback cannot replace canonical facts. The signal path requires the
retained baseline and does not infer it from missing late fields.

Ruling on tests: keep the three existing S tests BYTE-IDENTICAL. Put new hook
coverage in a named own-packet test file, reuse their fixtures where useful,
and run original test_coordinator/test_coordinator_shutdown/test_shutdown
unchanged for compatibility. This confines the canonical revision to TWO
files. C8 authenticates those three test files too, so changing them would
expand source authority unnecessarily. Same acceptance cases as architect:
legacy absence, noncallable/non-None, exactctx/capture once before idleclose/
activeSignal, ordinary collection shape, no added/reordered requests/results,
original exception, wrongctx/duplicate/missingbaseline, detached facts survive
later mutation. Retain genuine behavioral RED separately from interface errors.

Run focused normal/-O and inert/foreign-cwd checks for changed new controls.
Recompose original explicit and genuinely omitted SOURCE full40 with unchanged
selection/requests/result, using existing accepted source driver after verifying
its code identity. No native runs or duplicated parser/model. Pure test clocks
and fake hosts only. Source compatibility is not actual native proof.

Every dependent Python uses pinnedB-S/fresh119 SAME Rootcwd shell and approved
bootstrap/source/import controls as C9brief; guard the specific revised source
bytes from a pre-run snapshot for SOURCE tests. No current-hash discovery
authorization, C8 file mutation, private25original reads or environment dumps.
Snapshot all source/control versions before execution and preserve failures.
Read AGENTS/conventions/narrowAPI/TDD skills; no classes/assert/custom errors/
mutablemoduleglobals, newnesting<=3. Root owns final graph/gates/review/publication.

Write <=1200word `task-5e3c9a-report.md` with changed paths, exact old/new hashes,
covering commands/results and raw paths, own-provider wiring/test changes,
remaining source-authority/native integration limits. Return DONE or precise
concerns/report path. C9 overall remains incomplete; no new native effects
until Root separately releases the published two-file authority.
