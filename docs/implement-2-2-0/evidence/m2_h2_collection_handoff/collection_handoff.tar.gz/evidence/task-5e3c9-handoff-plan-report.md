Recommend the explicit optional `bind_collection(context, actual_capture) -> None` handoff. Reject the temporary module-global replacement of `adapter.final_collection`: identity checks and `finally` restoration do not remove its hidden process-wide mutation, reentrancy hazards or conflict with AGENTS.

The observed failure is a harness/provider interface gap. In `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py:378–396`, shutdown collection returns `{records, metrics}` without setting `context['final_observations']`. `shutdown_cases.py:68` sets that field only after process/post validation. Therefore `native_provider.py:98–109` cannot obtain it before signaling. My earlier plan was incorrect on this point.

Use this minimal extension:

1. **`coordinator.py`**: extend `validate_descriptor` at line 23 with optional callable `bind_collection`, following the existing `bind_context` precedent. Declare a named `BindCollection` callable type. In `teardown_hooks`, pass the optional callback through to shutdown hooks. For ordinary child completion, invoke the same handoff immediately after `adapter.final_collection` in `run_child`, passing its actual `context['final_observations']`; ordinary collection currently returns `None`.

2. **`shutdown_cases.py`**: let `validate_hooks` accept exactly this additional optional callable. Add one small handoff function that calls it when present and rejects a non-`None` return. Invoke that function immediately after the original collector calls in `active` (line 82) and `idle` (line 113), passing the exact returned object. This occurs before close/signal. Preserve existing barrier checks, output attachment, grace calculation, termination and final publication.

3. **`native_provider.py`**: supply the optional descriptor callback, bound explicitly to caller-owned child state. Replace `freeze_before`’s lookup with its `actual_capture` argument. Verify exact context identity against the currently bound native transport row, terminal-case identity and one-shot capture ownership. Reuse `shutdown_cases.outputs`, existing model validation and `coordinator.copy_facts` to freeze the four-part baseline into `child['before']`. Do not mutate the capture or context. `signal_child` requires that baseline; it does not reconstruct it.

This preserves `adapter.py`, collector requests/counts, parser behavior, result schemas, binaries, target and native7. The callback’s return cannot replace canonical facts. Descriptors and shutdown hooks without it retain their current behavior.

Add focused checks in `test_coordinator.py`, `test_coordinator_shutdown.py` and `test_shutdown.py`, plus provider tests:

- absent-hook compatibility and rejection of noncallable/non-`None` hooks;
- one invocation with the exact context/capture, before idle close or active signal;
- unchanged collection counts, request ordering and final result;
- callback failure prevents close/signal and preserves the primary exception;
- wrong context, duplicate binding and missing baseline reject;
- frozen provider facts survive subsequent capture mutation.

Update source authority before execution. `native_runtime_builds/replay_builds.py:56–73` currently requires all canonical files to equal archived bytes; both proposed canonical edits will correctly fail that check. Root must authorize and publish an explicit two-file revision with immutable old/new identities, then extend the C9 preflight authority for those reviewed revisions. Preserve C8’s archived acceptance and unchanged native7/binary identities; do not simply approve newly discovered hashes or weaken equality checks.

Root can authorize this bounded canonical extension while retaining C9’s sole implementation ownership. No target defect or native success is established by this correction.
