"""Verify the exact two-file canonical revision against the immutable C8 base."""
import hashlib
import json
import runpy
import sys
import tarfile
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def authority(plan):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_native_builds/native_builds.tar.gz')
    require(sha(archive.read_bytes()) == 'e3b8fe1c3c0a5f99a8144752eddab62f5568dcf6c9f7a51719bd669f3b6874a0', 'C8 archive differs')
    helper = plan / 'task-5e3c8-root-audit.py'
    with tarfile.open(archive, 'r:gz') as source:
        require(source.extractfile('evidence/' + helper.name).read() == helper.read_bytes(), 'C8 audit helper differs')
        raw = source.extractfile('packet/preflight-fix1.json').read()
    require(sha(raw) == 'e78cbbc2f1665e6999a5502f2817be531909a80d72e1dbd0fd22055dc93bb53c', 'C8 preflight differs')
    return runpy.run_path(str(helper)), json.loads(raw)


def revision_files(packet, revision, base, check):
    result = {}
    expected_names = {'coordinator.py', 'shutdown_cases.py'}
    require(len(revision['files']) == 2, 'Revision scope differs')
    for row in revision['files']:
        path = Path(row['path'])
        require(path.name in expected_names and path.parent == Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'), 'Unexpected revised path')
        old = base['files'][str(path)]
        require(row['old'] == {name: old[name] for name in ('bytes', 'sha256')}, 'Old source authority differs')
        require(sha((packet / row['old_snapshot']).read_bytes()) == old['sha256'], 'Preserved old source differs')
        new = row['new']
        require(len(path.read_bytes()) == new['bytes'] and sha(path.read_bytes()) == new['sha256'], 'Live revised source differs')
        require((packet / row['new_snapshot']).read_bytes() == path.read_bytes(), 'Revised snapshot differs')
        result[str(path)] = dict(old=old, new=new)
    require({Path(path).name for path in result} == expected_names, 'Duplicate revised source')
    for name, row in base['files'].items():
        if name not in result:
            check(row)
    return result


def check_source_inventory(packet, expected):
    matches = [path for path in packet.glob('*.sha256') if sha(path.read_bytes()) == expected]
    require(len(matches) == 1, 'Exact source inventory not found')
    rows = matches[0].read_text().splitlines()
    for line in rows:
        expected_sha, name = line.split('  ', 1)
        path = Path(name)
        require(path.is_file() and not path.is_symlink(), 'Source inventory path invalid')
        require(sha(path.read_bytes()) == expected_sha, 'Exercised source inventory differs')
    return dict(path=str(matches[0]), rows=len(rows), sha256=expected)


def audit(plan):
    packet = Path('.uwz-work/evidence/h2-streaming/native_provider')
    data = (packet / 'handoff/revision.json').read_bytes()
    expected = '8fc6c797a5d481c36b25636df0e909635000e66b7baa25ef52d5ce67b7a8f9ae'
    require(sha(data) == expected, 'Reviewed source revision differs')
    revision = json.loads(data)
    api, base = authority(plan)
    changed = revision_files(packet, revision, base, api['check_file'])
    inventory = check_source_inventory(packet, revision['packet_source_inventory_sha256'])
    canonical_root = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    canonical = {path for path in base['files'] if Path(path).parent == canonical_root}
    require(len(canonical) == 46 and {str(path) for path in canonical_root.glob('*.py')} == canonical,
            'Canonical module inventory differs')
    builds = {mode: api['check_build'](Path('/tmp/uwz-h2-native-c8-fix1'), mode,
              'e78cbbc2f1665e6999a5502f2817be531909a80d72e1dbd0fd22055dc93bb53c', digest)
              for mode, digest in (
                  ('debug', '4c89d63f760f467315e83d8c40021f49335b432490e9a06f8cf3f604e69bb476'),
                  ('release', '94510b8b95880b084f5a2250fd825db181cc9f1320d36f59130f3bdcf64d2f10'))}
    for name in ('test_coordinator.py', 'test_coordinator_shutdown.py', 'test_shutdown.py'):
        api['check_file'](base['files'][str(canonical_root / name)])
    result = dict(revision_sha256=expected, revised=changed, unchanged_c8_paths=len(base['files']) - 2,
                  canonical_modules=46, unchanged_canonical_modules=44, unchanged_legacy_tests=3,
                  source_inventory=inventory, builds=builds, source_only=True,
                  opaque_context_internals='Identity only; not a deep freeze', target_executed_by_auditor=False,
                  native_all40_accepted=False, milestone_complete=False)
    (plan / 'task-5e3c9a-root-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('revised', 'builds')}))


if __name__ == '__main__' and sys.argv[1:] == ['--audit']:
    audit(Path('.superpowers/sdd/h2_streaming_plan'))
