/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
import ast, hashlib, importlib.util, json
from pathlib import Path
root = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases').resolve()
evidence = root / 'evidence/core-peer-capacity'
spec = importlib.util.spec_from_file_location('audit', root / 'evidence/core-peer/audit.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
audit.immutable(root, evidence)
manifest = json.loads(Path('docs/implement-2-2-0/evidence/m2_h2_combined_lifecycle_peer/manifest.json').read_text())['current_source_files']
current = {p.name: audit.sha(p) for p in sorted(root.glob('*.py'))}
frozen = {p.name: audit.sha(p) for p in sorted((root / 'evidence/lifecycle-peer/fix1-source').glob('*.py'))}
if len(current) != 38 or frozen != manifest or set(current) != set(manifest) or {n for n in current if current[n] != manifest[n]} != {'test_core_peer.py', 'test_shared.py'}:
    raise RuntimeError('current or frozen source differs')
for name, saved in [('test_core_peer.py', 'before-core.py'), ('test_shared.py', 'before-shared.py')]:
    if audit.sha(evidence / saved) != manifest[name]:
        raise RuntimeError('before source differs: ' + name)
history = json.loads((root / 'evidence/lifecycle-peer/prior-evidence-map.json').read_text())
for name, digest in history.items():
    if audit.sha(root / name) != digest:
        raise RuntimeError('history differs: ' + name)
audit.structure(root, evidence)
(evidence / 'current-source.json').write_text(json.dumps(current, indent=2) + '\n')
print('current=38 frozen=38 baseline changed=test_core_peer.py,test_shared.py prior_history=%d' % len(history))
print('core=' + current['test_core_peer.py'] + ' shared=' + current['test_shared.py'])
PY
