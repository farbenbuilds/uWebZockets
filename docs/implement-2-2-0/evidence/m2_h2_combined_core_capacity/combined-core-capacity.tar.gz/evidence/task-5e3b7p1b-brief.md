# Shared core peer capacity followup

Released after reviewed/pushed P2 at8b7f8d3aaecea179b3d95893d0801e3252bd5ade.
BASE is this commit. Exact38-module source authority is
docs/implement-2-2-0/evidence/m2_h2_combined_lifecycle_peer/manifest.json,
bound by task-5e3b7p2-root-commit-audit.json. Preserve this baseline. Read
task-5e3b7p1-buffer-addendum.md: concrete independently source-confirmed finding
against accepted P1. Fix separately from P2loop, before P3 peer preparation.
All original parent/default/all40/native/adoption requirements unchanged.

Own only combined-cases/test_core_peer.py and test_shared.py, new evidence/
core-peer-capacity and task-5e3b7p1b-report.md. You are not alone; preserve other
edits/history. No othermodule/immutableinput/product/capacity/deadline change.
Root owns review/publication/commits/refs/pushes. No agents/externalmodelCLI,
public/Git/native/runtime operations. Specific APIgap to Root before sharededit.

Current send extends buffer before check_storage validates8201cap; an actual
partialframe with8200bytes followed by allowed8192input retains16392onrejection
and updates oversizedhighwater. Add a direct remainingcapacity check BEFORE
mutation; keep existing error/cap/flags/parser/schedule/storage semantics.
No thresholds weakened or generic bufferingframework/cleanup introduced.

Add one focused pure regression in shared driver beforefix: build actual
incomplete serializedframe using individuallyallowed sendspans; submit8192
continuation; rejection must preserve exactbufferbytes and highwater; repeat
to prove rejectedcalls cannotgrow retainedstorage. Record genuine pre-fix RED
and source/raw, then green actualsamecheck. No claim validstream completion or
native memory/allocator proof. Constructor/default/finalfacts unchanged.

Afterfinalsourceedit run shared/coordinator/import consumers normal/-O with
pinned Python -B -S. Original ready73/73/R257/74reads29903bytes and both actual
100000000declared/undeclared transfers/12208frames/hash/splitrefund and every
existing negative remain. No broadprecedingmatrix. All38 AST/oneguard/actual
inert empty+foreignargv imports; every newhelper likewise guarded/inert.

Baseline map/currentfrozen/priorhistory andimmutable119entries (118physicalrows/
113resolved files +ordered42codecaggregate) stay exact; interpreterSHA
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601 andcodecSHA
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Use existing pinned model/core/helper/codecs/PYTHONPATH, no installs/network.

Graphify query before new source/codebase search using release exactprefix;
provided sourcepaths located. Project/role/narrowskills and all source-only
restrictions apply: no native/build/socket/server/SSLContext/TLS-close/realclock/
processownership/transfer/kernel/fault/cancel/schedule/race/panic/leak probes or
oldruntimeentrypoint. Pure pinned in-memory codecs and suppliedfacts only.

Report concise actualdiff/regression/commands/rawpaths/current/frozen/input/
historyidentities/selfreview/remaininggaps; return status/reportpath/checks and
concerns under15lines. No implementation owner until Root release.
