# Shared core capacity fix review

Review task-5e3b7p1b-brief.md and sourceconfirmed
task-5e3b7p1-buffer-addendum.md. Claims task-5e3b7p1b-report.md;
Root task-5e3b7p1b-root-final-audit.json binds fullscopeddiff
task-5e3b7p1b-review-source.diff and current/frozen/source/raw identities.
BASE8b7f8d3aaecea179b3d95893d0801e3252bd5ade; no taskcommit.

Binding narrowrequirements: ownonlytest_core_peer.py/test_shared.py/newraw/report;
checkremaining8201capacity BEFOREextend; existing error/cap/flags/parser/schedule
unchanged; actualpartial8200frame/8192continuation rejection leaves bufferbytes
andhighwater unchanged, repeatedrejectionscannotgrow; realpre-fixRED preserved.
No sharedframework/newabstraction/gateweakening, no othermodule/immutableedit.
Affectedshared/coordinator/import normalO checks retainoriginal actualuploads/
counts/splitrefund/negatives; all38 guard/inertimports. Scopepurecodecfixture,
notnativeallocator/performance/composition/default/all40/adoption acceptance.

Read diffonce withcontext10/testsfirst; no duplicatechanged-file reads unless
neededhunkcutoff. Outside-diff reads onlyconcretenamedrisk/onefocusedcheck. Risk
focus: guardbeforeallmutation inclhighwater, preservingacceptedframeboundaries/
existingerror, trueRED/no-growthproof ratherthanposthoclimitcheck; no unintended
serialization/debt/clock/childstore change. No broad P1/P2 re-review/passedsuite
reruns. Treat report/Rootaudit as claims to assess independently.

ApplyAGENTS/CODING/code-review-and-quality; Rootexplicitlyrequests focused
structurallens torejectunneededframework/indirection. Existingmanualthermo skill
may be used for thatlens underprojectoverrides; notbroadarchitectureaudit.
Read-only/noagents/externalCLI/Git/file/servicewrites/native/build/socket/server/
SSLContext/TLS-close/realclock/processownership/transfer/kernel/fault/cancel/
schedule/race/panic/leak execution. Graphifyquerybefore new codebasequestion/
search, exactprefixinbrief; providedpaths located. Onlyfocusedpurecheckforan
unansweredconcrete doubt. ReturnfullSPEC/QUALITY/actionablefilelinefindings and
cannot-verifyboundaries; Root savesit.
