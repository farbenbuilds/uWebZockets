"""Package the shared peer pre-mutation capacity correction."""
import hashlib
import json
import runpy
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    published = Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_peer/combined-core-peer.tar.gz')
    if sha(published.read_bytes()) != 'dbcd7a01a56a3c80600aa39fa7b61dec00060976c14a82e2bd4a712a2520d25d':
        raise ValueError('Writer provenance archive differs')
    builder = plan / 'task-5e3b7p1-build-publication.py'
    with tarfile.open(published, 'r:gz') as previous:
        if previous.extractfile('evidence/' + builder.name).read() != builder.read_bytes():
            raise ValueError('Published writer source differs')
    writer = runpy.run_path(str(builder))['load_writer'](plan)
    baseline = Path('docs/implement-2-2-0/evidence/m2_h2_combined_lifecycle_peer/combined-lifecycle-peer.tar.gz')
    if sha(baseline.read_bytes()) != 'e57d3b6a74355e466b030a34685f67d37517a79f7345073db949c63107415b91':
        raise ValueError('Baseline archive differs')
    members, latest_raw = {}, {}
    with tarfile.open(baseline, 'r:gz') as previous:
        inventory = json.loads(previous.extractfile('INVENTORY.json').read())
        for member in previous:
            if not member.isfile():
                raise ValueError('Nonregular baseline member')
            if member.name == 'INVENTORY.json':
                continue
            data = previous.extractfile(member).read()
            if inventory[member.name] != dict(size=len(data), sha256=sha(data)):
                raise ValueError('Baseline inventory differs')
            if member.name.startswith('reference/'):
                writer['add'](members, member.name, data)
            if member.name.startswith('source/current/'):
                writer['add'](members, member.name.replace('source/current/', 'history/lifecycle-peer-source/', 1), data)
            if member.name.startswith('raw/lifecycle-peer/'):
                latest_raw[member.name] = inventory[member.name]
    writer['add'](members, 'history/lifecycle-published-raw-map.json', (json.dumps(latest_raw, indent=2) + '\n').encode())
    writer['add'](members, 'history/earlier-recorded-evidence-map.json',
                  (source / 'evidence/lifecycle-peer/prior-evidence-map.json').read_bytes())
    audit = json.loads((plan / 'task-5e3b7p1b-root-final-audit.json').read_text())
    current = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if current != audit['current_source_sha256']:
        raise ValueError('Reviewed source changed')
    for path in sorted(source.glob('*.py')):
        writer['add'](members, 'source/current/' + path.name, path.read_bytes())
    raw = source / 'evidence/core-peer-capacity'
    for path in sorted(raw.rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink in evidence')
        if path.is_file():
            writer['add'](members, 'raw/core-peer-capacity/' + path.relative_to(raw).as_posix(), path.read_bytes())
    names = ('task-5e3b7p1b-brief.md', 'task-5e3b7p1b-report.md', 'task-5e3b7p1b-review-brief.md',
             'task-5e3b7p1b-review-report.md', 'task-5e3b7p1b-review-source.diff',
             'task-5e3b7p1b-root-final-audit.json', 'task-5e3b7p1b-build-publication.py',
             'task-5e3b7p1-buffer-addendum.md', 'task-5e3b-peer-extraction-addendum.md')
    for name in names:
        writer['add'](members, 'evidence/' + name, (plan / name).read_bytes())
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_capacity')
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'combined-core-capacity.tar.gz'
    inventory = writer['write_archive'](archive, members)
    manifest = dict(scope='Shared pure-codec peer pre-mutation parser capacity fix',
                    base_commit=audit['base_commit'], baseline_archive_sha256=sha(baseline.read_bytes()),
                    archive=archive.name, archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
                    safe_regular_text_members=len(members), inventory_entries=len(inventory), current_source_files=current,
                    changed_files=audit['changed'], added_files=[], unchanged_lifecycle_peer_modules=36,
                    current_normal_optimized_commands=6, current_ast_inert_import_files=38,
                    earlier_recorded_evidence_hashes_checked=4412, latest_published_lifecycle_raw_files_checked=308,
                    retained_identity_entries=119, physical_identity_rows=118, unique_file_paths=113, ordered_codec_files=42,
                    parser_buffer_limit=8201, partial_frame_bytes=8200, rejected_send_bytes=8192,
                    pre_fix_retained_buffer_and_highwater=16392, post_fix_rejections_preserve_exact_bytes_and_highwater=2,
                    genuine_partial_frame_red_exit=1, regression_green_exit=0, existing_error_preserved=True,
                    shared_peer_pre_mutation_capacity_fixed=True, positive_peer_maxima_unchanged=True,
                    source_review='Spec and quality approved, no actionable findings',
                    supplied_transport_lifecycle_facts=True, coordinator_supported_nonempty_selections=[['ready_buffered']],
                    explicit_empty_supported=True, default_supported=False, combined_all40_executed=False,
                    native_executed=False, milestone_complete=False,
                    remaining=['Producer/file peer construction', 'All37 ordinary coordinator composition',
                               'Disconnect/shutdown children and actual default/all40 aggregate',
                               'Broad review, runtime/native/full gates and production adoption'])
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
                  regular_members=len(members), inventory_entries=len(inventory), source_modules=len(current),
                  all_reopened_member_bytes_exact=True, native_executed=False)
    (plan / 'task-5e3b7p1b-root-archive-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
