Early read-only discovery preceded durable raw logging. The conversation tool
transcript retains those exact commands and returned tool results; some large
results were console-truncated. They are not represented as complete raw files
in this packet. No missing raw output or exit status has been fabricated.

Known discovery diagnostics:

- `ls .uwz-work/evidence/h2-streaming/combined-interface-audit` reported that the
  newly assigned directory did not yet exist. It was then created within scope.
- Piping the existing restoration JSON through `head -45` emitted
  `cat: write error: Broken pipe` after the requested prefix.
- A discovery `jq` expression used `.source_before[0]` on the fixture receipt;
  it emitted `Cannot index object with number`. The mapping was subsequently
  read with `to_entries[0]`. No authoritative bytes were changed.
- Reading the bundle header with `tar -xOf ... | head -c 240` emitted a broken
  pipe after the prefix. The later durable dependency audit reads the entire
  authenticated bundle and retains exact `git bundle verify` output and exit.
- Some initial `cat`/`jq` results were much larger than intended and the tool
  truncated the displayed results. Final conclusions use the complete,
  authenticated machine-readable index and recorded audit passes instead.

From `raw/01-catalog.sh` onward, owned-helper attempts have exact shell commands,
stdout, stderr, exit files and fresh restoration receipts. Failed/intermediate
helper versions and matrix versions are retained in `snapshots/`. The deliberate
red test and all three subsequent implementation/reference failures remain in
raw attempts 02, 03, 06 and 09. This early discovery retention limitation must
remain visible to Root's independent review; later successful checks do not
retroactively manufacture original discovery evidence.
