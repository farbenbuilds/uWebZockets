"""Bind the review matrix and audit only owned metadata; no target imports."""
import ast
import contextlib
import io
import json
import runpy
import sys
from pathlib import Path
import metadata


def matrix_shape(rows):
    metadata.require(type(rows) is list and len(rows) == 7, 'Seven joins required')
    metadata.require([row['join'] for row in rows] == list(range(1, 8)), 'Join identity differs')
    required = {'join', 'producer', 'consumer', 'invariant', 'refs', 'existing_evidence',
                'remaining_native_evidence', 'gap', 'owners'}
    for row in rows:
        metadata.require(set(row) == required and row['refs'] and row['owners'], 'Incomplete matrix row')
        metadata.require(all(type(row[key]) is str and row[key] for key in required - {'join', 'refs', 'owners'}), 'Empty matrix text')


def bound_ref(ref, archives):
    metadata.require(type(ref) is list and len(ref) == 4, 'Malformed source reference')
    archive, member, first, last = ref
    metadata.require(archive in archives and member in archives[archive][1], 'Missing source member')
    source = archives[archive][1][member]
    lines = source.decode().splitlines()
    metadata.require(type(first) is int and type(last) is int and 1 <= first <= last <= len(lines), 'Invalid source span: ' + member + ' length=' + str(len(lines)))
    return dict(metadata.authority_ref(archive, member, archives[archive][1]), first_line=first,
                last_line=last, excerpt='\n'.join(lines[first - 1:last]))


def depth(node, level=0):
    controls = (ast.If, ast.For, ast.While, ast.With, ast.Try, ast.Match)
    current = level + int(isinstance(node, controls))
    return max([current] + [depth(child, current) for child in ast.iter_child_nodes(node)])


def helper_structure(path):
    tree = ast.parse(path.read_text())
    forbidden = (ast.ClassDef, ast.Assert, ast.Global, ast.Nonlocal)
    metadata.require(not any(isinstance(node, forbidden) for node in ast.walk(tree)), 'Forbidden helper structure')
    nesting = depth(tree)
    metadata.require(nesting <= 3, 'Helper nesting exceeded')
    for node in tree.body:
        metadata.require(isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef, ast.Expr, ast.If)), 'Global helper state')
        if isinstance(node, ast.Expr):
            metadata.require(isinstance(node.value, ast.Constant) and type(node.value.value) is str, 'Import-time effect')
    return dict(source=metadata.file_identity(path), maximum_nesting=nesting)


def inert(path):
    results = []
    old = sys.argv
    try:
        for name, args in (('foreign_module', ['--check']), ('__main__', []), ('__main__', ['--foreign'])):
            sys.argv = [str(path)] + args
            output = io.StringIO()
            with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
                runpy.run_path(str(path), run_name=name)
            metadata.require(output.getvalue() == '', 'Inert invocation emitted output')
            results.append(dict(name=name, argv=args, output_bytes=0))
    finally:
        sys.argv = old
    return results


def artifacts(output, archives):
    receipts = json.loads((output / 'recipes.json').read_bytes())
    records = {}
    for mode, item in receipts.items():
        receipt = item['receipt']
        path = next(arg.split('=', 1)[1] for arg in receipt['argv'] if arg.startswith('-femit-bin='))
        metadata.add_input(records, path, receipt['binary_sha256'], 'historical binary ' + mode, item['authority'])
    close = archives['m2_h2_lifecycle_close_live'][1]
    return dict(historical_binaries=list(records.values()),
                strict_close_manifest=metadata.authority_ref('m2_h2_lifecycle_close_live', 'evidence/manifest-v4.json', close),
                required_fresh_binaries=['Debug', 'ReleaseSafe'],
                fresh_runtime_closure='required; historical v4/v5 hashes are references only')


def check(output):
    root = Path('/workspaces/uWebZockets')
    archives = metadata.load_all(root)
    rows = json.loads((output / 'matrix.json').read_bytes())
    matrix_shape(rows)
    bound = [dict(row, refs=[bound_ref(ref, archives) for ref in row['refs']]) for row in rows]
    before = json.loads((output / 'before.json').read_bytes())
    after = metadata.freeze(root)
    metadata.require(before == after, 'Current45, preceding evidence or 119-input closure changed')
    helpers = {}
    for name in ('metadata.py', 'test_metadata.py', 'packet.py'):
        helpers[name] = dict(helper_structure(output / name), inert=inert(output / name))
    suffix = '-optimized' if sys.flags.optimize else ''
    metadata.write_json(output / ('bound-matrix' + suffix + '.json'), bound)
    metadata.write_json(output / ('artifact-audit' + suffix + '.json'), artifacts(output, archives))
    metadata.write_json(output / ('packet-check' + suffix + '.json'), dict(helpers=helpers, joins=7,
             references=sum(len(row['refs']) for row in rows), current45_unchanged=True,
             preceding_combined_files_unchanged=len(before['combined_files']), closure_unchanged=True,
             optimization='-O' if sys.flags.optimize else 'normal', native_executed=False))
    print('Packet checked: seven joins; immutable source spans bound; 19808 preceding files and 119/118/113/42 unchanged; three helpers strict/inert')


def seal(output):
    report = Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3c1-report.md')
    exclusions = {'packet-manifest.json', 'raw/12.stdout', 'raw/12.stderr', 'raw/12.exit', 'raw/12-restore.json'}
    paths = sorted(path for path in output.rglob('*') if path.is_file() and str(path.relative_to(output)) not in exclusions)
    rows = [metadata.file_identity(path) for path in paths]
    metadata.write_json(output / 'packet-manifest.json', dict(files=rows, report=metadata.file_identity(report),
             exclusions=sorted(exclusions), scope='Packet and all completed prior attempts; final sealing command receipts excluded explicitly'))
    print('Packet bound:', len(rows), 'files plus report; final sealing log/receipt excluded explicitly')


if __name__ == '__main__' and len(sys.argv) == 3 and sys.argv[1] == '--check':
    check(Path(sys.argv[2]))
if __name__ == '__main__' and len(sys.argv) == 3 and sys.argv[1] == '--seal':
    seal(Path(sys.argv[2]))
