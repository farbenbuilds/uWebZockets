"""Read authenticated evidence; never import or execute its source members."""
import hashlib
import json
import sys
import tarfile
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load_archive(folder):
    manifest_path = folder / 'manifest.json'
    manifest_data = manifest_path.read_bytes()
    manifest = json.loads(manifest_data)
    path = folder / manifest['archive']
    require(path.parent == folder, 'Archive escaped authority directory')
    data = path.read_bytes()
    require(digest(data) == manifest['archive_sha256'], 'Archive hash mismatch: ' + str(path))
    members = {}
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive:
            if member.isfile():
                require(member.name not in members, 'Duplicate archive member')
                members[member.name] = archive.extractfile(member).read()
    authority = dict(archive=str(path), archive_sha256=digest(data),
                     manifest=str(manifest_path), manifest_sha256=digest(manifest_data))
    return manifest, members, authority


def write_json(path, value):
    require(not path.exists(), 'Refusing to replace existing evidence: ' + str(path))
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def file_identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def freeze(root):
    combined = root / '.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'
    paths = sorted(path for path in combined.rglob('*') if path.is_file())
    rows = [file_identity(path) for path in paths]
    authority_path = combined / 'evidence/coordinator-a/immutable-inputs.json'
    identity = json.loads(authority_path.read_bytes())
    inputs = [file_identity(Path(row['path']).resolve()) for row in identity['identities']]
    codecs = [file_identity(Path('/tmp/uwz-h2-client-tooling/packages') / row[0]) for row in identity['codec_files']]
    return dict(combined_files=rows, authority=file_identity(authority_path),
                closure_rows=inputs, codec_rows=codecs,
                identity_entries=119, physical_rows=len(inputs),
                resolved_files=len({row['path'] for row in inputs}), ordered_codecs=len(codecs))


def catalog(root, output):
    folders = ('m2_h2_combined_all40', 'm2_h2_combined_fixture', 'm2_h2_metadata_live',
               'm2_h2_output_driver', 'm2_h2_lifecycle_close_live', 'm2_h2_native_tcp',
               'm3_libxev_registration_rollback', 'm2_h2_combined_coordinator_shutdown')
    result = {}
    for name in folders:
        manifest, members, authority = load_archive(root / 'docs/implement-2-2-0/evidence' / name)
        rows = [dict(member=name, bytes=len(data), sha256=digest(data)) for name, data in members.items()]
        result[name] = dict(authority=authority, manifest=manifest, members=rows)
    write_json(output / 'archive-catalog.json', result)
    write_json(output / 'before.json', freeze(root))
    print('Authenticated archives:', len(result), '; combined freeze and 119/118/113/42 closure retained')


if __name__ == '__main__' and len(sys.argv) == 4 and sys.argv[1] == '--catalog':
    catalog(Path(sys.argv[2]), Path(sys.argv[3]))
