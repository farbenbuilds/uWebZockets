"""Deterministic metadata integrity checks; no source/runtime suite execution."""
import sys
import json
import metadata


def rejects(function, *args):
    try:
        function(*args)
    except ValueError as error:
        metadata.require(str(error) != '', 'Empty rejection reason')
        return
    raise ValueError('Malformed metadata accepted')


def main():
    good = metadata.digest(b'unchanged')
    metadata.require(metadata.classify(good, good) == 'available-matching', 'Match lost')
    metadata.require(metadata.classify(good, None) == 'missing', 'Missing accepted')
    metadata.require(metadata.classify(good, metadata.digest(b'changed')) == 'changed', 'Changed accepted')
    rejects(metadata.classify, 'bad', good)
    rejects(metadata.classify, good, 'bad')
    rejects(metadata.validate_inventory, {'../escape': good}, 1)
    rejects(metadata.validate_inventory, {'/absolute': good}, 1)
    rejects(metadata.validate_inventory, {'source.py': 'bad'}, 1)
    rejects(metadata.validate_inventory, {'source.py': good}, 2)
    metadata.validate_inventory({'source.py': good}, 1)
    rejects(metadata.validate_inventory, {'a/../source.py': good}, 1)
    row = dict(bytes=9, sha256=good)
    mapping = {'source.py': row}
    inventory = dict(mapping, **{})
    members = {'source.py': b'unchanged', 'inventory.json': json.dumps(inventory).encode()}
    metadata.require(metadata.archive_inventory(members)['entries'] == 1, 'Map inventory rejected')
    members['inventory.json'] = json.dumps({'files': [dict(row, path='source.py')]}).encode()
    metadata.require(metadata.archive_inventory(members)['entries'] == 1, 'Row inventory rejected')
    rejects(metadata.archive_inventory, dict(members, **{'source.py': b'changed'}))
    rejects(metadata.archive_inventory, {'inventory.json': members['inventory.json']})
    print('Metadata checks: matching, changed, missing, malformed hashes, count and path rejection passed')


if __name__ == '__main__' and sys.argv[1:] == ['--check']:
    main()
