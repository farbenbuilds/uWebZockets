"""Read authenticated evidence; never import or execute its source members."""
import hashlib
import json
import re
import subprocess
import sys
import tarfile
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def classify(expected, observed):
    require(type(expected) is str and re.fullmatch('[0-9a-f]{64}', expected), 'Malformed expected hash')
    if observed is None:
        return 'missing'
    require(type(observed) is str and re.fullmatch('[0-9a-f]{64}', observed), 'Malformed observed hash')
    return 'available-matching' if expected == observed else 'changed'


def validate_inventory(mapping, count):
    require(type(mapping) is dict and len(mapping) == count, 'Inventory count mismatch')
    for name, value in mapping.items():
        require(type(name) is str and not Path(name).is_absolute(), 'Absolute inventory path')
        require(name and '..' not in Path(name).parts, 'Escaping inventory path')
        classify(value, None)


def load_archive(folder):
    manifest_path = folder / 'manifest.json'
    manifest_data = manifest_path.read_bytes()
    manifest = json.loads(manifest_data)
    path = folder / manifest['archive']
    require(path.parent == folder, 'Archive escaped authority directory')
    data = path.read_bytes()
    require(digest(data) == manifest['archive_sha256'], 'Archive hash mismatch: ' + str(path))
    members = {}
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive:
            if member.isfile():
                require(member.name not in members, 'Duplicate archive member')
                members[member.name] = archive.extractfile(member).read()
    authority = dict(archive=str(path), archive_sha256=digest(data),
                     manifest=str(manifest_path), manifest_sha256=digest(manifest_data))
    return manifest, members, authority


def write_json(path, value):
    require(not path.exists(), 'Refusing to replace existing evidence: ' + str(path))
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def file_identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def freeze(root):
    combined = root / '.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'
    paths = sorted(path for path in combined.rglob('*') if path.is_file())
    rows = [file_identity(path) for path in paths]
    authority_path = combined / 'evidence/coordinator-a/immutable-inputs.json'
    identity = json.loads(authority_path.read_bytes())
    inputs = [file_identity(Path(row['path']).resolve()) for row in identity['identities']]
    codecs = [file_identity(Path('/tmp/uwz-h2-client-tooling/packages') / row[0]) for row in identity['codec_files']]
    return dict(combined_files=rows, authority=file_identity(authority_path),
                closure_rows=inputs, codec_rows=codecs,
                identity_entries=119, physical_rows=len(inputs),
                resolved_files=len({row['path'] for row in inputs}), ordered_codecs=len(codecs))


def catalog(root, output):
    folders = ('m2_h2_combined_all40', 'm2_h2_combined_fixture', 'm2_h2_metadata_live',
               'm2_h2_output_driver', 'm2_h2_lifecycle_close_live', 'm2_h2_native_tcp',
               'm3_libxev_registration_rollback', 'm2_h2_combined_coordinator_shutdown')
    result = {}
    for name in folders:
        manifest, members, authority = load_archive(root / 'docs/implement-2-2-0/evidence' / name)
        rows = [dict(member=name, bytes=len(data), sha256=digest(data)) for name, data in members.items()]
        result[name] = dict(authority=authority, manifest=manifest, members=rows)
    write_json(output / 'archive-catalog.json', result)
    write_json(output / 'before.json', freeze(root))
    print('Authenticated archives:', len(result), '; combined freeze and 119/118/113/42 closure retained')


def authority_ref(archive, member, members):
    return dict(archive=archive, member=member, member_sha256=digest(members[member]))


def add_input(records, path, expected, role, reference):
    actual_path = Path(path).resolve()
    key = str(actual_path)
    if key not in records:
        observed = file_identity(actual_path) if actual_path.is_file() else None
        records[key] = dict(path=key, observed=observed, aliases=[])
    observed = records[key]['observed']
    status = classify(expected, observed['sha256'] if observed else None)
    records[key]['aliases'].append(dict(path=str(path), expected_sha256=expected,
                                       role=role, authority=reference, status=status))


def add_tree(records, base, mapping, role, reference):
    validate_inventory(mapping, len(mapping))
    for name, value in mapping.items():
        add_input(records, Path(base) / name, value, role, dict(reference, schema_key=name))


def checked_sources(records, archive, content, base, prefix, role):
    manifest, members, authority = content
    mapping = manifest['current_source_files']
    for name, value in mapping.items():
        member = prefix + name
        require(digest(members[member]) == value, 'Published current source differs')
        add_input(records, Path(base) / name, value, role, authority_ref(archive, member, members))


def git_read(root, output, name, args, stdin=None):
    argv = ['git', '--no-optional-locks', '-C', str(root)] + args
    result = subprocess.run(argv, input=stdin, capture_output=True, check=False)
    write_json(output / 'raw' / (name + '-command.json'), dict(argv=argv, stdin_sha256=digest(stdin) if stdin else None))
    (output / 'raw' / (name + '.stdout')).write_bytes(result.stdout)
    (output / 'raw' / (name + '.stderr')).write_bytes(result.stderr)
    (output / 'raw' / (name + '.exit')).write_text(str(result.returncode) + '\n')
    return result


def base_objects(root, output, base, paths):
    queries = [(base + ':' + name).encode() for name in paths]
    result = git_read(root, output, 'base-objects', ['cat-file', '--batch'], b'\n'.join(queries) + b'\n')
    require(result.returncode == 0, 'Read-only Git batch failed')
    rows = {}
    offset = 0
    for name in paths:
        end = result.stdout.index(b'\n', offset)
        header = result.stdout[offset:end].decode()
        offset = end + 1
        offset, row = parse_object(result.stdout, offset, header)
        rows[name] = row
    require(offset == len(result.stdout), 'Unaccounted Git batch bytes')
    return rows


def parse_object(data, offset, header):
    if header.endswith(' missing'):
        return offset, dict(status='missing', query=header[:-8])
    oid, kind, length = header.split()
    require(kind == 'blob', 'Expected exact blob')
    size = int(length)
    body = data[offset:offset + size]
    require(len(body) == size and data[offset + size:offset + size + 1] == b'\n', 'Malformed Git batch')
    return offset + size + 1, dict(object=oid, bytes=size, sha256=digest(body), status='available')


def candidate_audit(root, output, records, archives, receipt):
    manifest, members, authority = archives['m2_h2_metadata_live']
    delta = json.loads(members['candidate/delta.json'])
    inventory = receipt['source_before']
    validate_inventory(inventory, 1031)
    require(receipt['source_after'] == inventory, 'Historical candidate changed during build')
    aggregate = digest(json.dumps(list(inventory.items())).encode())
    expected = 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de'
    require(aggregate == expected == delta['candidate_source_digest'], 'Candidate aggregate differs')
    require(len(delta['files']) == 40, 'Metadata delta count differs')
    objects = base_objects(root, output, delta['base_commit'], list(inventory))
    changes = {row['path']: row for row in delta['files']}
    rows = []
    for name, expected_hash in inventory.items():
        row = dict(path=name, expected_sha256=expected_hash, base_object=objects[name])
        candidate_origin(row, name, expected_hash, changes, members)
        rows.append(row)
    write_json(output / 'candidate-reconstruction-audit.json', dict(base=delta['base_commit'],
               expected_count=1031, aggregate_sha256=aggregate, delta_files=40, files=rows))
    return rows


def candidate_origin(row, name, expected, changes, members):
    if name in changes:
        change = changes[name]
        member = 'candidate/source/' + name
        require(digest(members[member]) == expected == change['candidate_sha256'], 'Delta member differs')
        base_hash = row['base_object'].get('sha256')
        require(base_hash == change['base_sha256'], 'Delta base differs')
        row['reconstruction'] = dict(status='available-matching', source=authority_ref('m2_h2_metadata_live', member, members))
        return
    status = classify(expected, row['base_object'].get('sha256'))
    row['reconstruction'] = dict(status=status, source='exact base Git blob')


def summary(records):
    result = {}
    for row in records.values():
        for alias in row['aliases']:
            counts = result.setdefault(alias['role'], {})
            status = alias['status']
            counts[status] = counts.get(status, 0) + 1
    return result


def load_all(root):
    names = ('m2_h2_combined_all40', 'm2_h2_combined_fixture', 'm2_h2_metadata_live',
             'm2_h2_output_driver', 'm2_h2_lifecycle_close_live', 'm2_h2_native_tcp',
             'm3_libxev_registration_rollback', 'm2_h2_combined_coordinator_shutdown',
             'm2_h2_combined_client_core', 'm2_h2_combined_contract')
    return {name: load_archive(root / 'docs/implement-2-2-0/evidence' / name) for name in names}


def archive_inventory(members):
    name = 'inventory.json' if 'inventory.json' in members else 'INVENTORY.json'
    if name not in members:
        return dict(status='no top-level inventory; whole archive authenticated')
    inventory = json.loads(members[name])
    rows = inventory.get('files')
    if rows is None:
        rows = [dict(row, path=name) for name, row in inventory.items()]
    for row in rows:
        require(row['path'] in members, 'Archive inventory member missing')
        require(digest(members[row['path']]) == row['sha256'], 'Archive inventory hash differs')
        require(len(members[row['path']]) == row['bytes'], 'Archive inventory size differs')
    return dict(status='verified', entries=len(rows))


def closure_inputs(records, archives):
    archive = 'm2_h2_combined_coordinator_shutdown'
    members = archives[archive][1]
    member = 'raw/coordinator-shutdown/fix1-final-audit/immutable-inputs.json'
    identity = json.loads(members[member])
    reference = authority_ref(archive, member, members)
    for number, row in enumerate(identity['identities']):
        add_input(records, row['path'], row['sha256'], '119-input authority', dict(reference, row=number))
    codec_map = dict(identity['codec_files'])
    require(digest(json.dumps(identity['codec_files']).encode()) == identity['codec_digest'], 'Codec order differs')
    add_tree(records, '/tmp/uwz-h2-client-tooling/packages', codec_map, 'ordered codecs42', reference)
    return dict(identity_entries=identity['identity_entries_checked'], physical_rows=len(identity['identities']),
                resolved_files=len({str(Path(row['path']).resolve()) for row in identity['identities']}),
                ordered_codecs=len(codec_map), codec_digest=identity['codec_digest'])


def recipe_inputs(records, archives):
    archive = 'm2_h2_combined_fixture'
    members = archives[archive][1]
    receipts = {}
    for mode in ('debug', 'release'):
        member = 'builds/uwz-task5e2-Fix1Final2/' + mode + '-receipt.json'
        receipt = json.loads(members[member])
        reference = authority_ref(archive, member, members)
        require(receipt['inputs_before'] == receipt['inputs_after'], 'Recipe changed inputs')
        for path, value in receipt['inputs_before'].items():
            add_input(records, path, value, 'recipe ' + mode, reference)
        receipts[mode] = dict(receipt=receipt, authority=reference)
    release = receipts['release']['receipt']
    add_tree(records, release['cwd'], release['source_before'], 'candidate1031', receipts['release']['authority'])
    add_tree(records, '/tmp/uwz-reviewed-libxev-c223-loop-callbacks', release['override_before'],
             'libxev93', receipts['release']['authority'])
    return receipts


def runtime_inputs(records, archives):
    archive = 'm2_h2_output_driver'
    members = archives[archive][1]
    member = 'provenance/manifest-v5.json'
    require(digest(members[member]) == 'aab3dda65e16b0475ccb59de28028a2d324ee81c7c05dc6c48daf909f6ae9890', 'v5 manifest differs')
    manifest = json.loads(members[member])
    reference = authority_ref(archive, member, members)
    for base, mapping in manifest['trees'].items():
        if base.startswith('/nix/store/') or '/zig-pkg/zslay-' in base:
            add_tree(records, base, mapping, 'SDK tree' if base.startswith('/nix/') else 'zslay14', reference)
    add_tree(records, '/tmp/uwz-task5d3-runtime-v5', manifest['trees']['/tmp/uwz-task5d3-runtime-v5'], 'runtime v5', reference)
    return reference


def dependency_audit(root, output, archives, receipt):
    members = archives['m2_h2_metadata_live'][1]
    identity = json.loads(members['inputs/immutable-libxev-input.json'])
    validate_inventory(identity['files_sha256'], 93)
    require(identity['files_sha256'] == receipt['override_before'] == receipt['override_after'], 'Libxev inventory differs')
    bundle = archives['m3_libxev_registration_rollback'][1]['epoll-registration-rollback.bundle']
    header = bundle.split(b'\n\n', 1)[0].decode('ascii')
    require(header == '# v2 git bundle\n' + identity['commit'] + ' HEAD', 'Unexpected bundle heads/prerequisites')
    bundle_path = output / 'epoll-registration-rollback.bundle'
    bundle_path.write_bytes(bundle)
    local = git_read(root, output, 'libxev-object', ['cat-file', '-t', identity['commit']])
    verified = git_read(root, output, 'libxev-bundle', ['bundle', 'verify', str(bundle_path)])
    return dict(identity=identity, bundle_sha256=digest(bundle), header=header,
                local_commit_available=local.returncode == 0, bundle_verify_exit=verified.returncode,
                qualification='Bundle retained and header checked; 93 packed blob identities require later isolated export verification')


def audit(root, output):
    archives = load_all(root)
    records = {}
    authorities = {}
    for name, content in archives.items():
        authorities[name] = dict(content[2], inventory=archive_inventory(content[1]))
    combined = root / '.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'
    checked_sources(records, 'm2_h2_combined_all40', archives['m2_h2_combined_all40'], combined, 'source/current/', 'current45')
    checked_sources(records, 'm2_h2_combined_fixture', archives['m2_h2_combined_fixture'], '/tmp/uwz-task5e2-Fix1Final2/fixture', 'source/fixture/', 'fixture25')
    closure = closure_inputs(records, archives)
    require(list(closure.values())[:4] == [119, 118, 113, 42], 'Identity cardinalities differ')
    recipes = recipe_inputs(records, archives)
    release = recipes['release']['receipt']
    candidates = candidate_audit(root, output, records, archives, release)
    runtime = runtime_inputs(records, archives)
    dependency = dependency_audit(root, output, archives, release)
    write_json(output / 'recipes.json', recipes)
    write_json(output / 'dependency-audit.json', dependency)
    write_json(output / 'input-index.json', dict(authorities=authorities, closure=closure,
               runtime_manifest=runtime, paths=list(records.values()), summary=summary(records)))
    write_json(output / 'after-input-audit.json', freeze(root))
    print(json.dumps(dict(closure=closure, availability=summary(records),
          candidate_reconstructable=sum(row['reconstruction']['status'] == 'available-matching' for row in candidates),
          bundle_verify_exit=dependency['bundle_verify_exit']), indent=2))


def supplement(root, output):
    archives = load_all(root)
    index = json.loads((output / 'input-index.json').read_bytes())
    reconstruction = json.loads((output / 'candidate-reconstruction-audit.json').read_bytes())
    provenance = json.loads(archives['m2_h2_metadata_live'][1]['inputs/restoration-provenance.json'])
    records = {row['path']: row for row in index['paths']}
    for row in reconstruction['files']:
        if row['reconstruction']['status'] != 'available-matching':
            supplementary_origin(root, records, row, provenance, archives)
    for name, content in archives.items():
        index['authorities'][name]['inventory'] = archive_inventory(content[1])
    add_member_provenance(records, archives)
    index['paths'] = list(records.values())
    index['summary'] = summary(records)
    index['published_manifests_git_anchor'] = manifest_git_anchor(root, output, index['authorities'])
    index['native_ready'] = False
    index['fresh_loader_ssl_closure'] = 'still required; no interpreter/SSL/library loader execution performed'
    write_json(output / 'final-input-index.json', index)
    write_json(output / 'final-candidate-reconstruction.json', reconstruction)
    write_json(output / 'scoped-file-sets.json', scoped_sets(index))
    print(json.dumps(dict(availability=index['summary'], reconstruction_available=sum(
          row['reconstruction']['status'] == 'available-matching' or row.get('supplement', {}).get('status') == 'available-matching'
          for row in reconstruction['files'])), indent=2))


def supplementary_origin(root, records, row, provenance, archives):
    origin = provenance['provenance'].get(row['path'])
    require(origin is not None and origin.startswith('preserved-snapshot:'), 'No named supplemental source')
    path = root / origin.split(':', 1)[1]
    expected = row['expected_sha256']
    reference = authority_ref('m2_h2_metadata_live', 'inputs/restoration-provenance.json', archives['m2_h2_metadata_live'][1])
    add_input(records, path, expected, 'candidate supplemental origin', dict(reference, schema_key=row['path']))
    observed = records[str(path.resolve())]['observed']
    row['supplement'] = dict(path=str(path), expected_sha256=expected, observed=observed,
                             status=classify(expected, observed['sha256'] if observed else None), authority=reference)


def add_member_provenance(records, archives):
    hashes = {}
    for name, content in archives.items():
        for member, data in content[1].items():
            hashes.setdefault(digest(data), []).append(authority_ref(name, member, content[1]))
    for row in records.values():
        for alias in row['aliases']:
            if alias['role'] in ('119-input authority', 'ordered codecs42', 'runtime v5'):
                alias['authenticated_source_members'] = hashes.get(alias['expected_sha256'], [])


def manifest_git_anchor(root, output, authorities):
    base = '58bc6d6a525e01380ccc7bf3802e695c07877e89'
    paths = [str(Path(row['manifest']).relative_to(root)) for row in authorities.values()]
    queries = '\n'.join(base + ':' + path for path in paths) + '\n'
    result = git_read(root, output, 'published-manifests', ['cat-file', '--batch'], queries.encode())
    require(result.returncode == 0, 'Published manifest Git query failed')
    offset = 0
    rows = []
    for authority in authorities.values():
        end = result.stdout.index(b'\n', offset)
        offset, row = parse_object(result.stdout, end + 1, result.stdout[offset:end].decode())
        require(row.get('sha256') == authority['manifest_sha256'], 'Published manifest changed from base')
        rows.append(dict(manifest=authority['manifest'], **row))
    return dict(commit=base, manifests=rows)


def scoped_sets(index):
    roots = ('/tmp/uwz-task4d-fix1-frozen', '/tmp/uwz-reviewed-libxev-c223-loop-callbacks',
             '/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/lib',
             '/workspaces/uWebZockets/zig-pkg/zslay-0.2.1-OB-IfBl0AQCHCIVUH0AbAjErcCG_LNkaLp8Gz1BUXnoy')
    result = {}
    for root in roots:
        actual = sorted(str(path.relative_to(root)) for path in Path(root).rglob('*') if path.is_file())
        expected = {alias['path'][len(root) + 1:] for row in index['paths'] for alias in row['aliases'] if alias['path'].startswith(root + '/')}
        result[root] = dict(observed_count=len(actual), expected_count=len(expected),
                            extras=sorted(set(actual) - expected), missing=sorted(expected - set(actual)))
    return result


if __name__ == '__main__' and len(sys.argv) == 4 and sys.argv[1] == '--catalog':
    catalog(Path(sys.argv[2]), Path(sys.argv[3]))
if __name__ == '__main__' and len(sys.argv) == 4 and sys.argv[1] == '--audit':
    audit(Path(sys.argv[2]), Path(sys.argv[3]))
if __name__ == '__main__' and len(sys.argv) == 4 and sys.argv[1] == '--supplement':
    supplement(Path(sys.argv[2]), Path(sys.argv[3]))
