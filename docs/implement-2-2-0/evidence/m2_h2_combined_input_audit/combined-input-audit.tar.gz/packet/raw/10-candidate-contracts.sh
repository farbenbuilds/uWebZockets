set -e
printf 'App slab and upload owner initialization\n'
tar -xOf docs/implement-2-2-0/evidence/m2_h2_metadata_live/metadata-live.tar.gz candidate/source/src/router/app.zig | nl -ba | sed -n '345,375p;559,605p;768,785p'
printf 'Router admission\n'
tar -xOf docs/implement-2-2-0/evidence/m2_h2_metadata_live/metadata-live.tar.gz candidate/source/src/router/body_admission.zig | nl -ba | sed -n '1,130p'
printf 'Fixture ownership\n'
tar -xOf docs/implement-2-2-0/evidence/m2_h2_combined_fixture/combined-fixture.tar.gz source/fixture/file_observer.zig | nl -ba | sed -n '1,150p'
