set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-interface-audit/raw/01-restore.json
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-interface-audit/metadata.py --catalog /workspaces/uWebZockets /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-interface-audit
