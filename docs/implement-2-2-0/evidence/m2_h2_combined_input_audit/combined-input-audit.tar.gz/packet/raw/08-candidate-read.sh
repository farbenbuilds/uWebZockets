set -e
for source in src/router/app.zig src/router/builder.zig src/router/body_admission.zig src/core/tcp_http2_upload.zig src/http2/body_receive.zig; do
printf '\nSOURCE %s\n' "$source"
tar -xOf docs/implement-2-2-0/evidence/m2_h2_metadata_live/metadata-live.tar.gz "candidate/source/$source" | nl -ba | sed -n '/BodyBinding\|BodyControl\|body_upload\|body_sink\|stream_request\|upload_context\|finish\|cancel\|deinit\|resume\|pub fn\|fn dispatch\|on_body/p'
done
