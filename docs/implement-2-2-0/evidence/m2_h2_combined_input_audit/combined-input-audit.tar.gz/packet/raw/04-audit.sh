set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-interface-audit/raw/04-restore.json
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-interface-audit/test_metadata.py --check
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-interface-audit/metadata.py --audit /workspaces/uWebZockets /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-interface-audit
