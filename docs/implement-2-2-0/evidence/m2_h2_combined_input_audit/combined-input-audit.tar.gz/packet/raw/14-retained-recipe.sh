set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-interface-audit/raw/14-restore.json
jq -e '.debug.receipt.retained_sources_before == .debug.receipt.retained_sources_after and .debug.receipt.retained_sources_before == .release.receipt.retained_sources_before and .release.receipt.retained_sources_before == .release.receipt.retained_sources_after and .debug.receipt.source_before == .release.receipt.source_before and .debug.receipt.override_before == .release.receipt.override_before and .debug.receipt.fixture_before == .release.receipt.fixture_before' .uwz-work/evidence/h2-streaming/combined-interface-audit/recipes.json
jq -r '.debug.receipt.retained_sources_before|to_entries[]|"\(.value)  \(.key)"' .uwz-work/evidence/h2-streaming/combined-interface-audit/recipes.json > .uwz-work/evidence/h2-streaming/combined-interface-audit/raw/14-retained.sha256
sha256sum -c .uwz-work/evidence/h2-streaming/combined-interface-audit/raw/14-retained.sha256
