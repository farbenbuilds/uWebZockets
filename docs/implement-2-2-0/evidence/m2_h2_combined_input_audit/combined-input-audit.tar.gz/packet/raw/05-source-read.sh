set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-interface-audit/raw/05-restore.json
for source in /tmp/uwz-task5e2-Fix1Final2/fixture/{profile,tags,shared,log_bounds,schema_proof,output_body}.zig /tmp/uwz-task5e1-contract-v3/{catalogue,model}.py /tmp/uwz-task5e3a-snapshot-v9/source/{output_stage,wire,request_credit,response_credit}.py /tmp/uwz-task5d3-runtime-v5/{connection,owned_io,process_shutdown,post,capture,process_setup,process_cleanup,identity}.py /tmp/uwz-task5c3-runtime-v2/strict_close.py; do
printf '\nSOURCE %s\n' "$source"
nl -ba "$source"
done
