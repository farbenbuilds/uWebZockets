"""Restore exact archived source inputs immediately before pure client checks."""
import hashlib
import json
import sys
import tarfile
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def archive_matches(path, expected, needed):
    if digest(path.read_bytes()) != expected:
        raise ValueError('Published restoration archive differs: ' + str(path))
    matches = {}
    with tarfile.open(path, 'r:gz') as bundle:
        for member in bundle:
            if not member.isfile():
                continue
            data = bundle.extractfile(member).read()
            value = digest(data)
            if value in needed:
                matches.setdefault(value, dict(archive=str(path), archive_sha256=expected, member=member.name, data=data))
    return matches


def pinned_authority(archive, expected, authority):
    if digest(archive.read_bytes()) != expected:
        raise ValueError('Authority archive differs')
    with tarfile.open(archive, 'r:gz') as bundle:
        data = bundle.extractfile('raw/coordinator-shutdown/fix1-final-audit/immutable-inputs.json').read()
    if data != authority.read_bytes():
        raise ValueError('Current identity authority differs from committed bytes')
    return json.loads(data)


def restore(expected, matches):
    restored = {}
    for path, size, value in expected:
        if path.exists():
            if digest(path.read_bytes()) != value:
                raise ValueError('Existing pinned source differs: ' + str(path))
            continue
        if not str(path).startswith('/tmp/uwz-') or value not in matches:
            raise ValueError('Missing or unexpected source restoration: ' + str(path))
        origin = matches[value]
        data = origin['data']
        data.decode('utf-8')
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        restored[str(path)] = dict(archive=origin['archive'], archive_sha256=origin['archive_sha256'],
                                   member=origin['member'], bytes=len(data), sha256=value)
    return restored


def verify(expected):
    for path, size, value in expected:
        data = path.read_bytes()
        if digest(data) != value or size is not None and len(data) != size:
            raise ValueError('Restored source identity differs: ' + str(path))


def main(receipt):
    if receipt.exists():
        raise ValueError('Restoration receipt already exists')
    plan = Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan')
    evidence = Path('/workspaces/uWebZockets/docs/implement-2-2-0/evidence')
    latest = evidence / 'm2_h2_combined_coordinator_shutdown/combined-coordinator-shutdown.tar.gz'
    latest_pin = '240fdc2ac208101249ff777b25a67a158e0b9f7d99b685200f4d37f9913a8218'
    authority = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/coordinator-a/immutable-inputs.json')
    identity = pinned_authority(latest, latest_pin, authority)
    expected = [(Path(row['path']).resolve(), row['bytes'], row['sha256']) for row in identity['identities']]
    expected.extend((Path('/tmp/uwz-h2-client-tooling/packages') / name, None, value) for name, value in identity['codec_files'])
    needed = {value for path, size, value in expected if not path.exists()}
    matches = archive_matches(latest, latest_pin, needed) if needed else {}
    older = json.loads((plan / 'task-5e3b1-root-source-restoration.json').read_text())['source_archives']
    for folder, value in older.items():
        remaining = needed - set(matches)
        if not remaining:
            break
        archives = list((evidence / folder).glob('*.tar.gz'))
        if len(archives) != 1:
            raise ValueError('Ambiguous historical source archive')
        matches.update(archive_matches(archives[0], value, remaining))
    if needed - set(matches):
        raise ValueError('Pinned archive closure incomplete')
    restored = restore(expected, matches)
    verify(expected)
    codec_digest = digest(json.dumps(identity['codec_files']).encode())
    interpreter_digest = digest(Path(sys.executable).read_bytes())
    if codec_digest != identity['codec_digest'] or interpreter_digest != '4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601':
        raise ValueError('Ordered codecs or interpreter differs')
    resolved = {str(Path(row['path']).resolve()) for row in identity['identities']}
    if identity['identity_entries_checked'] != 119 or len(identity['identities']) != 118 or len(resolved) != 113 or len(identity['codec_files']) != 42:
        raise ValueError('Pinned identity contract differs')
    result = dict(restored_sources=restored, restored_source_count=len(restored), authority_entries=119,
                  physical_rows_checked=118, unique_resolved_files=113, ordered_codec_files_checked=42,
                  ordered_codec_digest=codec_digest, interpreter_sha256=interpreter_digest,
                  all_inputs_verified_in_this_command=True, full_native_candidate_restored=False,
                  binaries_restored=False, native_executed=False,
                  qualification='Exact source bytes only; execute dependent proofs in this same shell command')
    receipt.parent.mkdir(parents=True, exist_ok=True)
    receipt.write_text(json.dumps(result, indent=2) + '\n')
    print('Pinned source restoration verified: 118 rows, 113 files, 42 ordered codecs; restored', len(restored))


if __name__ == '__main__' and len(sys.argv) == 3 and sys.argv[1] == '--restore':
    main(Path(sys.argv[2]))
