The next release should be **one bounded combined-contract review and native-input closure audit**. Native provider implementation and execution should follow that verdict. The accepted source all40 checkpoint remains intact; no source tests, builds, native operations or restoration were performed here.

Paths below use:

- `P`: `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/`
- `E`: `docs/implement-2-2-0/evidence/`
- `F`: `/tmp/uwz-task5e2-Fix1Final2/fixture/`
- `R`: `/tmp/uwz-task5d3-runtime-v5/`

### 1. Smallest broad combined review

Produce one immutable input index and a cross-component matrix. Reference existing verdicts instead of repeating individual peer reviews or the source all40 runs.

The closure should contain:

| Input | Authority |
|---|---|
| Current 45 combined Python files | `E/m2_h2_combined_all40/combined-all40.tar.gz`, its manifest and inventory |
| Canonical model, client core, pinned codecs | The existing 119-input authority and restoration provenance, including the underlying combined-contract/client-core archives |
| Current 25-file combined fixture | `E/m2_h2_combined_fixture/combined-fixture.tar.gz`, `source/fixture/` |
| Candidate interfaces used by that fixture | Exact 1031-file inventory from the final fixture receipts; targeted review of changed App/router/body/H2/TCP ownership interfaces |
| Reusable native primitives | `E/m2_h2_output_driver/output-driver.tar.gz`, `source/runtime/` v5 |
| Strict disconnect and active-shutdown precedent | `E/m2_h2_lifecycle_close_live/lifecycle-close-live.tar.gz`, `source/runtime-v2/strict_close.py` and its v4 manifest |

Each matrix row should identify producer, consumer, invariant, immutable source references, existing evidence and remaining native evidence. Review these joins:

1. Fixture routes, tags, JSON schemas and capacity markers versus model and schedules.
2. Client registration/retirement versus independent wire classification, including refused responses, output roles and final collection.
3. Shared application records, actual producer binding and file ownership across cases and disconnect replacement.
4. Startup SETTINGS versus ACKs/subsequent SETTINGS; credit scopes, late refunds and intentionally abandoned uploads.
5. Caller clock units, deadline clipping and setup/teardown time.
6. Final pre-signal snapshots versus post-deinit cancellation and output facts.
7. Real process/TLS ownership, capture bounds, cleanup and terminal EOF observation.

This is a combined-interface review, not a repository-wide review. Whole-branch/M1–M7 review remains later. Verification owns the matrix; HTTP protocol, transport/TLS and build/vendor specialists own findings in their interfaces.

### 2. Native source closure is currently incomplete

The candidate directory currently contains only:

```text
src/http2/server.zig
src/http/request_body.zig
src/core/http2_upload.zig
src/core/tcp.zig
```

`/tmp/uwz-reviewed-libxev-c223-loop-callbacks` is absent. Therefore the 119-input restorer cannot authorize a native build. Its own result explicitly records `full_native_candidate_restored=False`:

`.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py`

Authoritative restoration inputs are:

- **Candidate:** `E/m2_h2_metadata_live/metadata-live.tar.gz`, `candidate/delta.json` and `candidate/source/`: 40 changed `src` paths against base `30f27ab80f0471437c34adcdf7b2d42f58227b74`. Restore the remaining paths against the exact retained 1031-file inventory, not current Root files merely sharing names. Required aggregate source digest is `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`.
- **Candidate reconstruction precedent:** `E/m2_h2_native_tcp/reviewed-native-tcp.tar.gz` and its reconstruction records. The metadata delta alone is not the complete tree.
- **Dependency:** `E/m3_libxev_registration_rollback/epoll-registration-rollback.tar.gz`, containing `epoll-registration-rollback.bundle`. Exact historical test input is commit `c223bd886c6a51d2cd60def39dd9a68d701fea73`, tree `86c6944f53dc009d7503a9ab0bc873aef3cd7b79`; authenticate all 93 files against `inputs/immutable-libxev-input.json` in the metadata/lifecycle archives.
- **Fixture/compiler recipe:** combined-fixture archive members `builds/uwz-task5e2-Fix1Final2/{debug,release}-receipt.json`. These bind the fixture, candidate, override, compiler, translated C module, zslay and six static archives.
- **Historical runtime closure:** output-driver `provenance/` v5 manifest, SHA256 `aab3dda65e16b0475ccb59de28028a2d324ee81c7c05dc6c48daf909f6ae9890`. This is a reference for constructing a fresh combined closure, not a manifest for the new runner.

The recorded Zig executable, translated C module and six libraries presently exist. Their identities and complete dependency source availability were **not** authenticated in this planning pass. Required paths include:

```text
/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig
.uwz-work/evidence/h1-transport/r2/c-native.zig
zig-pkg/zslay-0.2.1-OB-IfBl0AQCHCIVUH0AbAjErcCG_LNkaLp8Gz1BUXnoy/
zig-out/lib/{libuWebZockets,libssl,libcrypto,liblsquic,libdeflate,libz}.a
```

Build/vendor must report missing or changed inputs explicitly. Historical restoration scripts use Git and broad recovery searches; they are provenance, not an automatically authorized current command. Restore under a separately released preparation task, with per-file provenance and exact inventory equality. Preserve maintained pins; the historical c223 test export is not production dependency adoption.

### 3. Reusable native seams and superseded helpers

Keep `coordinator.run` as sole dispatcher. Its existing `child_factory(...)`, `connect(case, number, case_deadline, whole_deadline)` and lifecycle hooks already supply the required seam (`P/coordinator.py:296–412`).

Reuse or adapt narrowly:

| Existing function | Disposition |
|---|---|
| `R/identity.py:4,13,27`: `start_id`, `match_listeners`, `require_owned` | Reuse pure PID/start/listener checks |
| `R/process_io.py:14–79`: process identity, collector, spawn/wait operations | Reuse authenticated primitives with explicit clock conversion |
| `R/capture.py:5–75` | Reuse bounded capture/readiness logic; preserve overflow and collector errors |
| `R/connection.py:10–35` | Reuse TLS1.3, h2, hostname/certificate verification policy |
| `R/process_setup.py:9` | Adapt setup sequencing to coordinator-provided ready/whole deadlines and combined nonce bound |
| `R/process_cleanup.py:4` | Retain failure cleanup and every cleanup error; forced cleanup never becomes successful acceptance |

Do **not** install the old runtime wholesale:

- `connection.factory` returns an old five-output connection shape, not the coordinator’s seven-key shape.
- `owned_io.read` rejects EOF (`R/owned_io.py:18–22`).
- `process_shutdown.graceful` combines signal/wait/post and computes its own seconds-based grace (`R/process_shutdown.py:5–24`).
- `post.validate` requires 32 records and unchanged before/after totals (`R/post.py:42–48`).
- Archived `strict_close.observe_shutdown` begins and finishes canonical termination itself. The combined driver already does both at `P/shutdown_cases.py:93–103`; invoking it unchanged would duplicate ownership.

The strict **disconnect** helper remains the correct model:

```text
unwrap_eof(tls, deadline, clock) -> close-facts
```

It requires successful public TLS unwrap, ordinary TCP EOF, zero trailing bytes and closure of the returned socket. Active shutdown is different: the retained successful native precedent permits either ordinary EOF or `ssl.SSLEOFError` after the owned signal. It does not promise a reciprocal TLS close alert.

### 4. Independent native evidence needs one narrow terminal extension

There is a demonstrated incompatibility, not hypothetical traffic:

- `P/test_wire_oracle.py:141–154` poisons every underlying exception.
- Lifecycle runtime-v2 `strict_close.observe_shutdown` accepts `ssl.SSLEOFError`.
- `P/shutdown_cases.py:96–103` accepts `eof` or `tls_eof`.
- `P/coordinator.py:220–238` freezes canonical counters **before teardown**.

Consequently, a poisoned source receipt cannot certify the native closing window, and full native receive totals cannot blindly equal the coordinator’s pre-teardown totals.

Release a separate, narrowly reviewed test-observer extension before native binding:

```text
begin_shutdown_observation(state) -> None
shutdown_observation(state) -> immutable closing-window receipt
```

Required contract:

- Available only for the existing `shutdown_active` transport-abandon descriptor, after actual final collection and successful owned signal.
- Record an immutable pre-teardown counter/debt checkpoint and separate closing receive calls/bytes.
- Continue observing every successfully returned closing byte through the existing decoder.
- Permit only the specified terminal EOF outcomes in this phase. Preserve the exact returned value or raised `SSLEOFError`; do not translate arbitrary errors into EOF, clear poison or fabricate bytes.
- Preserve ordinary exception poisoning everywhere else.
- Require an observed terminal outcome and no partial frame/header tail before native acceptance; retain abandoned upload debt.
- Native binding compares canonical counters with the pre-teardown checkpoint and accounts for closing traffic separately under applicable limits.

No second parser/client is needed. Focused doubles should prove valid EOF, permitted TLS EOF, wrong-phase EOF, other SSL errors, timeout, partial tail, closing bytes, duplicate activation and operations after terminal completion. Exact tuple fields can be fixed in that small implementation brief; they must expose the checkpoint, closing counters and observed outcome.

### 5. Concrete owned-provider slices

Use a new private `combined-native/` directory. Preserve archived runtime and source45 bytes.

1. **`native_post.py` + focused checks — verification**
   - `parse_post(data, nonce, capacity) -> facts`
   - Parse exactly 67 unique body records, four outputs, one binding and one deinit metrics record.
   - Enforce the fixture’s nonce limit of 32 and capture limits (`F/log_bounds.zig:9–18`).
   - Compare actual pre/post records with the canonical model, preserving the active-shutdown delta.
   - Compare actual binding and diagnostics; never substitute synthetic binding index/generation or timing-dependent producer counters.

2. **`native_transport.py` + focused checks — verification with transport/TLS**
   - Construct the coordinator’s real seven-key connection and strict disconnect hook.
   - Implement active termination using the existing canonical termination ownership and extended independent observation.
   - Use one integer monotonic clock, preferably nanoseconds with `units_per_second=1_000_000_000`; convert remaining ticks to seconds only at OS waits. Old helpers’ `+15` and float timeout conventions require explicit adaptation.

3. **`native_provider.py`, `run_native.py`, `test_native_provider.py` — verification**
   - `new_provider(config, *, clock, ops) -> (ChildFactory, NativeState)`.
   - Each child owns its process/start identity, nonce, listener, certificate, capture and current socket.
   - The idle child must complete post-validation/reaping before main starts.
   - Derive hook facts from operations and retained logs, never synthetic `owned=True` declarations.
   - Reuse `connection_descriptor` at `P/test_all40_descriptors.py:152`; do not reuse its synthetic application snapshots, peer construction or `finish_binding`.
   - Validate empty/rejected selections before certificate/process/socket effects. Provide an actual omitted-selection coordinator call.

The deep-module seam is the existing child provider: it contains process/socket ownership behind unchanged coordinator hooks. Its deletion would otherwise spread identity, cleanup and teardown logic across the runner and case handlers.

### 6. Ordered acceptance

1. Finish the combined review/matrix and exact source-availability audit.
2. Restore/authenticate complete native inputs; review the terminal observer extension and native helper slices with source-only doubles, normal and optimized.
3. Freeze a fresh combined runtime manifest. Bind source, codecs, interpreter/loader/SSL/OpenSSL inputs, Zig SDK, candidate/dependencies, fixture, exact argv/environment and fresh binary hashes.
4. Rebuild Debug and ReleaseSafe using the retained Zig `build-exe` recipe, changing only declared output/cache destinations. Put caches and binaries under a fresh `/tmp/uwz-…` directory; do not delete existing evidence or libraries.
5. After Root’s native release, execute explicit and genuinely omitted-default all40 as separate recorded invocations. Each runs fresh idle then main children, with 41 connections and all original semantic counts, hashes, credit/debt rules, deadlines and ceilings. Native RX/read/refund observations need not equal synthetic scheduling totals.
6. Retain actual pre-signal 67 records/metrics, post-deinit logs, output/binding facts, strict disconnect outcome, active termination, PID/start/listener/certificate identities, exit/reaping, file/key removal and all cleanup results. Audit each attempt independently; retain failures without silent retry.
7. Complete candidate/current quality, sanitizer, fuzz, package, protocol and platform gates, then reviewed production adoption and maintained-dependency publication. Include the prescribed formatting, conventions, version and `zig build test` gates; foreign compilation is not native platform execution.

Exact-current returned-error ownership evidence, physical lifetime coverage, H3/multipart/genuine early-data work and all remaining M1–M7 requirements remain open. Neither the historical native checkpoints nor source all40 closes them.
