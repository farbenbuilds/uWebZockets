"""Independently bind the combined review packet and recorded input availability."""
import ast
import hashlib
import json
import subprocess
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_text())


def check_file(row):
    path = Path(row['path'])
    data = path.read_bytes()
    if len(data) != row['bytes'] or sha(data) != row['sha256']:
        raise ValueError('Recorded bytes differ: ' + str(path))


def verify_packet(root, plan):
    seal = load(root / 'packet-manifest.json')
    recorded = set()
    for row in seal['files']:
        path = Path(row['path'])
        if not path.resolve().is_relative_to(root.resolve()) or path.is_symlink():
            raise ValueError('Unsafe packet path')
        check_file(row)
        recorded.add(path.resolve())
    excluded = {root.resolve() / name for name in seal['exclusions']}
    actual = {path.resolve() for path in root.rglob('*') if path.is_file()}
    if len(recorded) != 116 or actual != recorded | excluded:
        raise ValueError('Sealed packet coverage differs')
    if Path(seal['report']['path']).resolve() != (plan / 'task-5e3c1-report.md').resolve():
        raise ValueError('Sealed report identity differs')
    check_file(seal['report'])
    if (root / 'raw/12.exit').read_text() != '0\n' or (root / 'raw/12.stderr').read_bytes():
        raise ValueError('Final packet sealing failed')
    return dict(sealed_files=len(recorded), current_files=len(actual), report_sha256=seal['report']['sha256'])


def verify_preservation(root):
    before = load(root / 'before.json')
    if (before['identity_entries'], before['physical_rows'], before['resolved_files'], before['ordered_codecs']) != (119, 118, 113, 42):
        raise ValueError('Input closure counts differ')
    if len(before['closure_rows']) != 118 or len({Path(row['path']).resolve() for row in before['closure_rows']}) != 113 or len(before['codec_rows']) != 42:
        raise ValueError('Actual input closure inventory differs')
    for row in before['combined_files'] + before['closure_rows'] + before['codec_rows'] + [before['authority']]:
        check_file(row)
    if len(before['combined_files']) != 19808:
        raise ValueError('Preceding combined inventory differs')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    manifest = load(Path('docs/implement-2-2-0/evidence/m2_h2_combined_all40/manifest.json'))
    current = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if current != manifest['current_source_files'] or len(current) != 45:
        raise ValueError('Current45 changed during metadata audit')
    return dict(current_source_sha256=current, preceding_files=19808, closure_rows=118, resolved_files=113)


def verify_archives(index):
    anchor = index['published_manifests_git_anchor']
    if anchor['commit'] != '58bc6d6a525e01380ccc7bf3802e695c07877e89' or len(anchor['manifests']) != 10:
        raise ValueError('Published Git anchor differs')
    for row in anchor['manifests']:
        relative = Path(row['manifest']).resolve().relative_to(Path.cwd()).as_posix()
        blob = subprocess.run(['git', 'rev-parse', anchor['commit'] + ':' + relative], check=True, capture_output=True).stdout.decode().strip()
        if blob != row['object']:
            raise ValueError('Manifest Git tree binding differs')
        data = subprocess.run(['git', 'cat-file', 'blob', row['object']], check=True, capture_output=True).stdout
        if sha(data) != row['sha256'] or len(data) != row['bytes']:
            raise ValueError('Published Git blob differs')
        if Path(row['manifest']).read_bytes() != data:
            raise ValueError('Published live manifest differs')
    for authority in index['authorities'].values():
        if sha(Path(authority['archive']).read_bytes()) != authority['archive_sha256']:
            raise ValueError('Authority archive differs')
    return sum(row['inventory']['entries'] for row in index['authorities'].values())


def verify_paths(index):
    physical, summary = set(), {}
    for row in index['paths']:
        if row['path'] in physical:
            raise ValueError('Index physical path is duplicated')
        physical.add(row['path'])
        if row['observed'] is not None:
            check_file(row['observed'])
        record_aliases(row, summary)
    if summary != index['summary'] or len(physical) != 20893 or index['native_ready']:
        raise ValueError('Availability totals or native readiness differ')
    return dict(deduplicated_paths=len(physical), availability=summary, native_ready=False)


def record_aliases(row, summary):
    for alias in row['aliases']:
        counts = summary.setdefault(alias['role'], {})
        counts[alias['status']] = counts.get(alias['status'], 0) + 1
        if alias['status'] == 'available-matching' and (row['observed'] is None or row['observed']['sha256'] != alias['expected_sha256']):
            raise ValueError('Matching alias lacks matching observed bytes')
        if alias['status'] == 'missing' and (row['observed'] is not None or Path(alias['path']).exists()):
            raise ValueError('Missing alias contradicts observed availability')


def verify_matrix(root, index):
    rows = load(root / 'bound-matrix.json')
    if [row['join'] for row in rows] != list(range(1, 8)):
        raise ValueError('Seven joins differ')
    wanted = {}
    for row in rows:
        for ref in row['refs']:
            wanted.setdefault(ref['archive'], set()).add(ref['member'])
    contents = read_members(index, wanted)
    count = 0
    for row in rows:
        for ref in row['refs']:
            verify_span(contents[ref['archive']][ref['member']], ref)
            count += 1
    if count != 50:
        raise ValueError('Bound source span inventory differs')
    return dict(joins=7, references=count, exact_source_spans=True)


def read_members(index, wanted):
    result = {}
    for key, names in wanted.items():
        selected = read_selected(index['authorities'][key]['archive'], names)
        if selected.keys() != names:
            raise ValueError('Matrix archive source member missing')
        result[key] = selected
    return result


def read_selected(path, names):
    selected = {}
    with tarfile.open(path, 'r:gz') as stream:
        for member in stream:
            if member.isfile() and member.name in names:
                selected[member.name] = stream.extractfile(member).read()
    return selected


def verify_span(data, ref):
    lines = data.decode('utf-8').splitlines()
    first, last = ref['first_line'], ref['last_line']
    if sha(data) != ref['member_sha256'] or not 1 <= first <= last <= len(lines):
        raise ValueError('Source member or line bound differs')
    if '\n'.join(lines[first - 1:last]) != ref['excerpt']:
        raise ValueError('Source excerpt differs')


def nesting(node, depth=0):
    kinds = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.With, ast.AsyncWith, ast.Try, ast.TryStar, ast.Match)
    level = depth + int(isinstance(node, kinds))
    return max([level] + [nesting(child, level) for child in ast.iter_child_nodes(node)])


def verify_helpers(root):
    normal, optimized = load(root / 'packet-check.json'), load(root / 'packet-check-optimized.json')
    if normal['optimization'] != 'normal' or optimized['optimization'] != 'optimized':
        raise ValueError('Owned metadata check modes differ')
    comparable = {key: value for key, value in normal.items() if key != 'optimization'}
    if comparable != {key: value for key, value in optimized.items() if key != 'optimization'}:
        raise ValueError('Normal/optimized metadata results differ')
    for row in normal['helpers'].values():
        check_file(row['source'])
        tree = ast.parse(Path(row['source']['path']).read_text())
        if nesting(tree) > 3 or any(isinstance(node, (ast.ClassDef, ast.Assert)) for node in ast.walk(tree)):
            raise ValueError('Current metadata helper structure differs')
        if any(item['output_bytes'] != 0 for item in row['inert']):
            raise ValueError('Current metadata helper is not inert')
    return dict(current_helpers=len(normal['helpers']), max_nesting=3, normal_optimized_checks_bound=True)


def main(argv):
    if argv != ['--audit']:
        return
    root = Path('.uwz-work/evidence/h2-streaming/combined-interface-audit')
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    index = load(root / 'final-input-index.json')
    result = dict(packet=verify_packet(root, plan), preservation=verify_preservation(root),
                  inventory_entries=verify_archives(index), inputs=verify_paths(index),
                  matrix=verify_matrix(root, index), helpers=verify_helpers(root),
                  native_executed=False, full_tree_restored=False, milestone_complete=False)
    if result['inventory_entries'] != 10290:
        raise ValueError('Authenticated archive inventory count differs')
    (plan / 'task-5e3c1-root-final-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(packet=result['packet'], input_paths=20893, inventory_entries=10290,
                          matrix=result['matrix'], native_ready=False), indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
