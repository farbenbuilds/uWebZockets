# c1 combined-interface packet and native-input availability audit

**DONE_WITH_CONCERNS.** The bounded packet is complete. Current45 and its prior
source all40 checkpoint remain unchanged. Native inputs are **not ready**:
the candidate export has four matching files and 1,027 missing files; the c223
test export has zero of 93 files; both historical combined fixture executables
are missing. All 1,031 candidate reconstruction origins are nevertheless
available and hash-matching. No reconstruction or native execution occurred.

Authority is pushed commit `58bc6d6a525e01380ccc7bf3802e695c07877e89`. The brief
and architect proposal were read before work. The architect's terminal-extension
proposal is not an accepted EOF relaxation or an implementation authorization.
Root retains fresh independent combined review, publication, commit and push.

## Packet location and exact outputs

Let `A` be
`/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-interface-audit/`.
All new files except this report are beneath `A`.

| File | Purpose |
|---|---|
| `final-input-index.json` | Authoritative final index: 20,893 deduplicated physical paths, preserving per-authority aliases, expected/observed hashes, roles and availability; ten published manifest Git anchors and whole-archive identities |
| `matrix.json`, `bound-matrix.json` | Seven joins; producer, consumer, invariants, prior evidence, remaining native evidence, gaps and owners; 50 exact archive/member/line references with member hashes and actual source excerpts |
| `final-candidate-reconstruction.json` | Every one of the 1,031 expected candidate paths, exact base Git blob facts, 40 archived delta identities and nine named snapshot supplements |
| `dependency-audit.json` | Exact 93-file c223 inventory, commit/tree, authenticated bundle and current export/object availability |
| `scoped-file-sets.json` | Exact expected/observed path-set differences for candidate, libxev, SDK library tree and zslay; no extras in any of these four scopes |
| `recipes.json`, `artifact-audit.json` | Complete final Debug/ReleaseSafe argv/environment/receipt authorities; historical binary absence, strict-close manifest-v4 identity and fresh build requirements |
| `before.json`, `after-input-audit.json` | Frozen prior combined evidence plus 119/118/113/42 closure; final normal/optimized checks re-read this closure and require exact equality |
| `packet-check.json`, `packet-check-optimized.json` | Metadata helper structural/inert checks, source-span binding and preservation results |
| `packet-manifest.json` | Final packet/report byte inventory, explicitly excluding its own circular entry and the active final sealing receipt/logs |
| `metadata.py`, `test_metadata.py`, `packet.py` | Only three current helpers; pure metadata checks with explicit CLI effect boundaries |
| `raw/`, `snapshots/` | Exact recorded audit commands/results/restoration receipts, prior helper/matrix versions, read-only Git output and source-read excerpts |
| `discovery-retention-notes.md` | Explicit limitation for initial read-only discovery that preceded durable logging |
| `archive-catalog.json`, `input-index.json`, `candidate-reconstruction-audit.json` | Preserved intermediate inventories; superseded by the final files above, not deleted or presented as final |
| `epoll-registration-rollback.bundle` | Authenticated historical bundle copied only into the audit evidence directory; not imported into a Git object database or exported as a source tree |

The optimized bound matrix and artifact audit are identical in substance to
their normal counterparts and remain separate evidence. `packet-manifest.json`
enumerates every retained file rather than this report pretending that failed
or intermediate files never existed.

## Authentication and observed availability

The helper first hashes each complete archive against its published manifest,
then reads members and verifies each publication inventory entry. Final
manifest bytes are independently compared with exact Git blobs at
`58bc6d6a525e01380ccc7bf3802e695c07877e89`. Ten archives and **10,290** internal
inventory entries passed. No matching filename was treated as matching bytes.

The ten authorities are `m2_h2_combined_all40`,
`m2_h2_combined_coordinator_shutdown`, `m2_h2_combined_client_core`,
`m2_h2_combined_contract`, `m2_h2_combined_fixture`, `m2_h2_metadata_live`,
`m2_h2_native_tcp`, `m2_h2_output_driver`, `m2_h2_lifecycle_close_live` and
`m3_libxev_registration_rollback` under `docs/implement-2-2-0/evidence/`.
Their absolute archive/manifest paths, SHA256 values, Git object IDs and member
identities are in the final index. Runtime-v5 retains SHA256
`aab3dda65e16b0475ccb59de28028a2d324ee81c7c05dc6c48daf909f6ae9890` for
`provenance/manifest-v5.json`; strict-close v4 is
`fc64a55cb7de3f1473a1883d12911366fe26aea745ec424cba4f0ff863258da9` for
`evidence/manifest-v4.json`. Neither historical manifest closes a fresh runtime.

| Input | Available matching | Missing | Changed/unresolved qualification |
|---|---:|---:|---|
| Current combined Python source | 45 | 0 | All45 match published current source members |
| Canonical identity authority | 118 physical rows / 113 resolved files | 0 | Preserve declared119; do not relabel it as118 |
| Ordered codecs | 42 | 0 | Ordered digest `0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473` |
| Combined fixture | 25 | 0 | Matches source/fixture and final recipe inventory |
| Runtime-v5 source | 19 | 0 | Read/hash only; not imported or executed |
| Candidate export | 4 | 1,027 | Exact source-tree reconstruction remains a separate task |
| c223 isolated libxev export | 0 | 93 | Bundle present; packed commit/tree/blob equality is not freshly established by an export |
| Zig executable | 1 | 0 | Read/hash only; no compiler execution |
| Zig SDK `lib` tree | 19,542 | 0 | Exact path set, zero extras, all expected hashes match |
| Translated C module | 1 | 0 | Exact historical input bytes match |
| zslay source | 14 | 0 | Exact path set, zero extras, all expected hashes match |
| Six static archives | 6 | 0 | Hash matching is not a rebuild or loader proof |
| Recipe retained fixture/profile inputs | 11 | 0 | Both modes' before/after inventories equal and each file hashes correctly |
| Historical combined fixture binaries | 0 | 2 | Fresh Debug and ReleaseSafe builds remain required |
| Fresh interpreter/loader/SSL/OpenSSL closure | — | — | Unresolved; pinned Python executable alone does not prove dynamic closure |

Both final build receipts have 12 direct inputs: nine match and three are
missing (`src/root.zig`, `src/core/xev.zig` in the candidate export, and
libxev `src/main.zig`). The three missing direct inputs are already included
in the source inventories above; they are not additional distinct missing files.

Recorded compiler:
`/nix/store/9zyky24fffkbhnkmjcnrjcl3dmvx6w9x-zig-0.16.0/bin/zig`, SHA256
`2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c`.
Translated module:
`.uwz-work/evidence/h1-transport/r2/c-native.zig`, SHA256
`d9ada6e22902d9aae00bec473ce6942376a8f569f481b7b544b4395beb53d536`.
All six archive hashes and all14 zslay hashes are retained per path in the index.
The pinned Python executable SHA256 remains
`4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`.

## Candidate and dependency reconstruction facts

The exact candidate inventory comes from
`m2_h2_combined_fixture/combined-fixture.tar.gz` members
`builds/uwz-task5e2-Fix1Final2/{debug,release}-receipt.json`, `source_before`.
The ordered aggregate is exactly
`fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`.

Read-only `git cat-file --batch` queried the exact 1,031 paths at base
`30f27ab80f0471437c34adcdf7b2d42f58227b74`. Results retain object IDs, byte counts,
SHA256s and raw batch output. Of those paths, 982 already match the final
inventory. Forty `src` paths match authenticated `candidate/source/` members
and their base SHA256s match `candidate/delta.json` in metadata-live.

Nine remaining paths differ from that base. They are **not** authorized by the
40-file `src` delta. Each was checked at the exact named preserved snapshot in
metadata-live `inputs/restoration-provenance.json` and matches the final
candidate inventory:

- `README.md`, `docs/adr/0008-request-body-streaming.md`, `docs/deployment.md`
  from `.uwz-work/evidence/upload-platform/implementation/final/`.
- `docs/implement-2-2-0/README.md`,
  `docs/implement-2-2-0/evidence/m2_h1_retirement_v6/README.md`,
  `docs/implement-2-2-0/m2_loop_callback_adapter.md`, and
  `docs/implement-2-2-0/m2_request_streaming.md` from
  `.uwz-work/drafts/m2-h1-baseline/`.
- `docs/implement-2-2-0/m1_streaming_static_tls.md` from
  `.uwz-work/drafts/m2-h1-transport-legacy/`.
- `tests/package_consumer/main.zig` from
  `.uwz-work/evidence/configured-https/implementation/snapshot/`.

Thus **982 + 40 + 9 = 1,031** available reconstruction origins. This does not
mean the target candidate directory is complete: it still contains only
`src/core/http2_upload.zig`, `src/core/tcp.zig`, `src/http/request_body.zig`,
and `src/http2/server.zig`, all matching, with no extra files. No full tree was
materialized. Raw Git batch evidence contains blobs in one audit stream; it is
not a populated build tree or permission to use current Root filenames instead.

The 93-file libxev inventory from metadata-live `inputs/immutable-libxev-input.json`
equals both fixture receipt override inventories. Its expected commit is
`c223bd886c6a51d2cd60def39dd9a68d701fea73`, expected tree
`86c6944f53dc009d7503a9ab0bc873aef3cd7b79`. The current exact export path
`/tmp/uwz-reviewed-libxev-c223-loop-callbacks` is absent. Exact object lookup in
the Root repository exits128 with `fatal: git cat-file: could not get object info`.

The archived bundle has the sole HEAD c223, no prerequisite header, and passes
read-only `git bundle verify` with exit0:

```text
The bundle contains this ref:
c223bd886c6a51d2cd60def39dd9a68d701fea73 HEAD
The bundle records a complete history.
The bundle uses this hash algorithm: sha1
.../combined-interface-audit/epoll-registration-rollback.bundle is okay
```

The last displayed path is abbreviated here; raw stdout/stderr preserve it
exactly. This verifies the authenticated bundle's advertised completeness and
prerequisites, **not** a fresh 93-file export or packed-tree equality. Later
preparation must import into an authorized isolated destination, resolve the
exact commit/tree and verify every exported byte. Historical c223 is an
isolated test dependency, not adoption of a production pin.

## Seven-join findings

The complete machine-readable matrix includes all claims and 50 immutable
source spans. Compact review map:

| Join | Verified source contract | Remaining native mismatch/evidence |
|---|---|---|
| 1. Fixture/model | 67 tags, nine families, routes, canonical JSON, exact capacity marker; nonce<=32 | Old post parser expects32 and permits64-character/hyphen nonce; capture actual67/four outputs/one binding/one deinit |
| 2. Registration/wire | Canonical special-output role maps to passive output role; refusals/reset ordering; final67+metrics; one-shot poison-preserving seal | Old five-key factory differs from seven-key seam; native provider and receipt binding needed |
| 3. Shared records/output/file | One child application's67 records and two slots; replacement preserves outputs; actual admitted generation; transferred file closes once | No synthetic generation18 or hardcoded producer counters; actual file/binding/producer observations required |
| 4. SETTINGS/credit | Initial SETTINGS vs ACK/later settings, scoped debts, late closed-stream refund semantics, open windows and abandonment debt | Passive observer is not full flow validation; preserve canonical checks and original ceilings while using actual native scheduling |
| 5. Time | Integer ticks; explicit units; ready15, whole900, case30/180, grace clipped by case/whole | Old seconds/+15 helpers cannot be copied; setup/connect/close/process waits must consume caller budgets |
| 6. Pre/post | Pre-signal final collection; active shutdown adds one cancel and clears active/paused; outputs/binding unchanged | Old32-record equality rejects legitimate67-record active delta; native closing bytes differ from sealed pre-teardown counters |
| 7. Real ownership/EOF | PID/start/listener/certificate, TLS1.3/h2, bounded capture, strict unwrap+TCP EOF, canonical single terminal owner | Fresh runtime closure; old EOF-rejecting read and duplicate observe_shutdown owner incompatible; active SSLEOF remains unresolved |

Targeted candidate source reads also verified App's H2 owner/metadata-slice
binding (`candidate/source/src/router/app.zig:345–375`), shutdown-before-release
ordering (`559–605`), borrowed route/sink contexts (`770–780`) and the router's
reservation rollback (`body_admission.zig:65–82`). These are scoped interface
reads, not a repeat production correctness or lifetime acceptance review.

Current source all40's exact semantic observations remain references: 41
connections, 802 heads, 789 small completions, request-flow200091899, 46
SETTINGS, two informationals, 13 incoming resets, two final collections, and
two100000000-byte payload hashes. The retained source RX51312051/read31433 and
binding generation18 are **source execution observations**, not requirements
for native scheduling. Native runs must keep semantic contracts, applicable
limits, debt/deadlines and actual observed bytes without copying those timings.

## Native EOF question: unresolved, no policy relaxation

`test_wire_oracle.py:141–184` poisons every underlying exception because a
failed operation can have an unknown consumed prefix. Successful returned
closing bytes are knowable and must still pass the existing decoder.
An `SSLEOFError` does not reveal bytes consumed internally and cannot prove
complete wire truth. Do not clear poison, invent bytes or turn arbitrary SSL
errors/timeouts into accepted EOF.

The historical strict helper accepts active `SSLEOFError`, while the combined
handler owns canonical begin/finish termination and accepts `eof`/`tls_eof` hook
facts. The coordinator seals its counters before teardown and restores them
after hooks. Reusing the old helper would both duplicate terminal ownership and
leave passive/native final accounting unresolved.

Root, verification, transport_io and crypto_tls must first settle the exact
phase/tuple and limits: after successful final collection and owned signal;
immutable pre-signal checkpoint; all successfully returned closing bytes;
separate receive counters; explicit observed terminal outcome; no partial
frame/header tail; retained abandoned-upload debt; unknown-prefix qualification;
ordinary poison unchanged. A future narrow implementation needs wrong-phase,
ordinary error, timeout, partial-tail, closing-byte, duplicate-activation and
post-terminal checks in addition to valid EOF cases. This report does not
decide that an exception may be accepted as complete independent proof.

## Commands, raw results and preservation

Every dependent Python metadata/check shell uses `set -e`,
`PYTHONDONTWRITEBYTECODE=1`, then this exact command with its own new absolute
receipt, immediately followed by the dependent operation in the same shell:

```sh
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT
```

Every recorded receipt reports restored0, 118 rows,113 files,42 codecs,
`full_native_candidate_restored=false`, no binaries restored and no native
execution. Python helper edits used patching, not another interpreter.
The exact commands, flags, argv/stdin hashes and full raw results are retained:

| Attempt / exact shell under A | Result |
|---|---|
| `bash raw/01-catalog.sh` | exit0; authenticated initial8 archives and froze preceding evidence/closure |
| `bash raw/02-red.sh` | exit1; deliberate red: `AttributeError: module 'metadata' has no attribute 'classify'` |
| `bash raw/03-audit.sh` | exit1; `KeyError: 'files'` exposed map-vs-row historical inventory schema |
| `bash raw/04-audit.sh` | exit0; complete initial availability, candidate delta and read-only Git audit |
| `bash raw/05-source-read.sh` | exit0; restored source reads with numbered lines, no imports/execution |
| `bash raw/06-supplement.sh` | exit1; `KeyError: 'bytes'` exposed uppercase inventory `size` schema |
| `bash raw/07-supplement.sh` | exit0; ten manifest anchors/inventories, nine supplements and exact scoped path sets |
| `bash raw/08-candidate-read.sh` | exit0; authenticated archived candidate interface locations |
| `bash raw/09-check.sh` | exit1; `ValueError: Invalid source span`; corrected file_observer end99->86 and model end452->448 |
| `bash raw/10-candidate-contracts.sh` | exit0; exact App/admission/file source excerpts |
| `bash raw/11-check.sh` | exit0; normal metadata/packet checks |
| `bash raw/13-check-optimized.sh` | exit0; same owned checks with Python `-O`, separate outputs |
| `bash raw/14-retained-recipe.sh` | exit0; Debug/ReleaseSafe inventory equalities and all11 retained recipe inputs `OK` |
| `bash raw/12-seal.sh` | Final packet sealing; raw12 preserves actual result |

The normal and optimized successful raw output is:

```text
Pinned source restoration verified: 118 rows, 113 files, 42 ordered codecs; restored 0
Metadata checks: matching, changed, missing, malformed hashes, count and path rejection passed
Packet checked: seven joins; immutable source spans bound; 19808 preceding files and 119/118/113/42 unchanged; three helpers strict/inert
```

Those checks include wrong hash, absent file/member, malformed hash/count/path,
both inventory shapes and size-key forms, absent matrix join, missing source
reference and out-of-range span. Ordinary-exception poison was not changed or
re-tested. Current helpers have maximum nesting3/1/3, no classes/asserts/custom
exceptions/global mutable containers, and no silenced unexpected errors.
Foreign import, empty CLI and foreign CLI produce no output/effectful branch.

**Retention limitation:** early read-only discovery commands were captured in
the tool transcript before durable per-command logs; some large console results
were truncated and two short-prefix pipelines emitted broken-pipe diagnostics.
`discovery-retention-notes.md` names these facts. Original missing raw outputs
and statuses are not invented. All substantive helper failures, source/helper
snapshots, authentication results and subsequent audit commands are retained.
Root should consider this explicit limitation when reviewing evidence hygiene.

## Self-review and next released slices

Correctness: materialized availability, reconstructable origins and unresolved
runtime closure are separate. Published manifest anchors, archive hashes,
inventory members and per-path comparisons establish the index. Missing files
remain missing. Existing source/all40 verdicts were referenced, not repeated.

Ownership: only `A` and this report were authored. The pinned restorer was used
only for its already authorized closure and restored0 each time. No current45,
canonical model/core/codec/fixture/candidate/product/dependency/pin bytes were
edited. No agent was spawned; no Git writes, publication, compiler/library
execution, target process, socket, SSLContext, clock, network, install or old
runtime import/execution occurred. Read-only Git object and bundle queries are
recorded. No source/cache/evidence was deleted. No acceptance bar was weakened.

Verification limits: this is verified metadata and an interface packet, not
native/compliance/milestone verification. Full Zig formatting/build/test,
sanitizer/fuzz/package/protocol/platform gates were not run because this slice
forbids target compilation/execution and changes no such source. The later
fixed ASan/UBSan and MSan commands remain required; MSan covers the C boundary,
does not instrument Zig, and cannot combine with ASan. No performance claim is
made. The ignored evidence helper changes do not change the source knowledge
graph; Root owns any publication graph refresh.

Immediate next scopes:

1. **Root/reviewer:** fresh broad combined review using this packet and prior
   verdicts. Review the source contracts and the explicit EOF question, without
   treating this self-review as independent approval.
2. **build_vendor, with verification:** separately authorize exact candidate
   reconstruction from982 base blobs+40 delta members+9 named snapshots into a
   fresh isolated destination; verify1,031 paths, zero extras, every hash and
   ordered aggregate. Import/export the authenticated bundle into a separately
   authorized destination; resolve c223/tree86c6944f and verify all93 paths and
   hashes. Preserve current pins and historical evidence.
3. **verification + transport_io + crypto_tls:** settle and review the narrow
   terminal observation contract first, then implement source-only doubles for
   it and native_post/native_transport/provider helpers. Keep coordinator.run
   as sole dispatcher and canonical termination as a single owner. Use actual
   producer/binding/file/close facts, integer ticks and original limits.
4. **build_vendor + verification:** freeze a fresh runtime closure including
   exact source/codecs, interpreter/loader/SSL/OpenSSL, SDK/dependencies, argv,
   environment and later binary hashes. Rebuild Debug/ReleaseSafe with retained
   build-exe recipes, changing only declared output/cache destinations under
   fresh `/tmp` paths. Existing matching static libraries are inputs, not fresh
   compilation evidence.
5. **Only after Root's native release:** explicit and genuinely omitted-default
   all40 invocations with fresh idle then main children and41 connections;
   preserve pre/post67 rows, outputs/binding, all traffic, strict disconnect,
   active terminal facts, identity/reaping/removal and every cleanup failure.
   Record failed attempts; never silently retry or promote forced cleanup.

Exact-current returned-error ownership, physical lifetime coverage, H3,
multipart, genuine early data, full native/platform gates, production adoption
and all remaining M1–M7 acceptance remain open.
