import ast
import difflib
import hashlib
import json
import subprocess
import sys
from pathlib import Path


def nesting(node, depth=0):
    controls = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.With, ast.AsyncWith, ast.Try, ast.TryStar, ast.Match)
    level = depth + int(isinstance(node, controls))
    return max([level] + [nesting(child, level) for child in ast.iter_child_nodes(node)])


def root_check(path):
    source = path.read_bytes()
    tree = ast.parse(source)
    if nesting(tree) > 3 or any(isinstance(node, (ast.Assert, ast.ClassDef)) for node in ast.walk(tree)):
        raise ValueError('Root auditor structural violation')
    probes = ([sys.executable, '-B', '-S', str(path)],
              [sys.executable, '-B', '-S', str(path), '--foreign'],
              [sys.executable, '-B', '-S', '-c', 'import runpy; runpy.run_path(' + repr(str(path)) + ', run_name="metadata_import_probe")'])
    receipts = []
    for argv in probes:
        result = subprocess.run(argv, capture_output=True, check=True)
        if result.stdout or result.stderr:
            raise ValueError('Root auditor inert probe emitted output')
        receipts.append(dict(argv=argv, exit=result.returncode, stdout_bytes=0, stderr_bytes=0))
    return dict(path=str(path), sha256=hashlib.sha256(source).hexdigest(), bytes=len(source), max_nesting=nesting(tree), inert=receipts)


def main(argv):
    if argv != ['--prepare']:
        return
    plan = Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan')
    root = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-interface-audit')
    checks = root_check(plan / 'task-5e3c1-root-audit.py')
    (plan / 'task-5e3c1-root-helper-check.json').write_text(json.dumps(checks, indent=2) + '\n')
    paths = [root / name for name in ('test_metadata.py', 'metadata.py', 'packet.py')]
    paths.append(plan / 'task-5e3c1-root-audit.py')
    parts = ['# c1 review package\n\nBase and head: 58bc6d6a525e01380ccc7bf3802e695c07877e89.\nNew ignored metadata helpers below; no tracked source changes.\n']
    for path in paths:
        parts.extend(difflib.unified_diff([], path.read_text().splitlines(True), fromfile='/dev/null', tofile=str(path), n=10))
    for name in ('task-5e3c1-root-final-audit.json', 'task-5e3c1-root-helper-check.json'):
        parts.extend(['\n# ' + name + '\n', (plan / name).read_text()])
    for name in ('artifact-audit.json', 'dependency-audit.json', 'bound-matrix.json'):
        parts.extend(['\n# ' + name + '\n', (root / name).read_text()])
    output = plan / 'task-5e3c1-review-package.diff'
    output.write_text(''.join(parts))
    data = output.read_bytes()
    print(json.dumps(dict(path=str(output), bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), root_max_nesting=checks['max_nesting'])))


if __name__ == '__main__':
    main(sys.argv[1:])
