# Combined interface packet and native-input availability audit

Read this first: one bounded preparation/audit task, no native implementation.
BASE58bc6d6a525e01380ccc7bf3802e695c07877e89, feat/implement-2-2-0,
reviewed/pushed/sourceall40 complete. Root commit audit task-5e3b9c-root-commit-audit.json.
Read the full architect task-5e3c-native-transition-report.md for exact authority
paths, native incompatibilities and ordered next steps. That is a proposal;
only this first packet/availability task is released. Native terminal-extension
mechanism/tuple contract and real runner are NOT implementation-authorized yet.

Own NEW directory
/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-interface-audit/
and full report
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3c1-report.md.
Write packet/matrix, immutable index, availability facts, bounded metadata helpers
and raw audit evidence there. No current45/canonicalcore/model/client/fixture/
candidate/dependency/runtime/product/pin edits or restoration of full trees here.
You are not alone: preserve all other work/historical bytes. No agents/Gitwrites/
publication/nativebuild/server/socket/SSLContext/TLSclose/realclock/processownership/
kernel/network/install/oldruntime execution. Root owns independent review and
publication/commit+immediatepush. Read-only Git object queries for the exact
retained base/trees are permitted if needed; no fetch/clone/worktree/index writes.

Acceptance output1: immutable input index plus combined-interface matrix.
Index authenticated current45 combinedsources, the119-input model/core/codec
authority, combinedfixture25, exact expected1031candidate inventory, expected93
libxev testexport, reusable runtime-v5 and strictclose precedent, compilerrecipe
and known required build artifacts. For each source/input record authorityarchive/
manifest/hash/member or exactGitobject, expected and observed identities/status,
role, availability and provenance. Deduplicate actual paths without losing
authority aliases. Verify whole archive hashes against published manifests before
using members; preserve exact archive/member references for reproducible review.
Do not equate matching filenames with matching source, or a historical manifest
with a fresh native runtime closure. Preserve the existing119/118/113/42 identity.

Matrix rows: producer/consumer/invariant/exactimmutable source refs+line/schema/
existing evidence/remaining native evidence/identified gap or mismatch.
Cover the architect's seven joins: fixture tags/routes/JSON/capacities; client
registration/retirement vsindependent wire roles/finalcollection; sharedrecords/
outputbinding/fileownership; SETTINGS/ACK/credit/lategrants/openwindows; clockunits/
deadlines/setupteardown; presignal vs postdeinitfacts; realprocess/TLS/capture/
cleanup/EOFownership. Verify contracts using scoped source reads, not just copied
claims. Existing individual verdicts/sourceall40 evidence are references, not
tests or reviews to repeat. Whole-repo and allmilestone review remain later.

Acceptance output2: exact current native-input availability/authentication audit.
The architect observed onlyfourcandidate Zig files and absentc223export. Check
actual state; classify available-matching, missing, changed, unresolved rather
than marking native-ready. Locate exact1031 inventory and aggregate
fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de,
40path metadata delta against30f27ab80f0471437c34adcdf7b2d42f58227b74,
and93libxev inventory for c223bd886c6a51d2cd60def39dd9a68d701fea73/
tree86c6944f53dc009d7503a9ab0bc873aef3cd7b79. Validate authority and available
bytes, identify whether exact localGitbase/bundle allow a later reconstruction.
Do not reconstruct/materialize missing candidate/dependency sources in this task.

Authenticate readable existing Zig executable, translatedCmodule, zslaysources,
six staticarchives and recipe inputs against recorded authority. Inspect only
documented paths/archives and named dependencies; no broad recovery scan.
No compiler/library execution or promotion of old runtime helpers. Hash/read
metadata only; no ldd/import oldmodules to manufacture currentloader closure.
Mark fresh interpreter/loader/SSL runtime closure as stillneeded where unproved.
Do not update maintainedpins or claim c223testexport is productionadoption.

Acceptance output3: immediately actionable next scoped work and risk rulings.
Name exact reconstruction/native-preparation ownership, prerequisites and checks.
Oldruntime five-output connection, EOF-rejecting read, seconds/+15 graceful
shutdown,32record postvalidator and duplicate termination owner cannot be copied
wholesale. Current45 sourceproof has ordinary-exception poison; active native
SSLEOF/window accounting needs a separately resolved contract. Distinguish
observed returned closing bytes from unknown consumed prefixes; do not infer
complete wire truth from an allowed exception or erase poison. Record this
as a native contract question/gap for Root, not an accepted relaxed policy.
Native binding must not hardcode synthetic bindinggeneration18/producer counters
or require nativeRX/read/refund timing to equal source scheduling; preserve
semantic counts, actual observations and original ceilings/debt/deadlines.

An incomplete source tree is an expected audit finding, not an excuse to stop
without the available index/matrix. Return all meaningful available facts and
exact missing prerequisites; no native acceptance claim. Do not silently fix
current source contracts discovered while auditing; report them for owners.

Read actual AGENTS.md/CODING_CONVENTION.md and narrow verification/review/build
instructions/skills for this phase. Graphify query before NEW codebase questions/
search/read; architect-supplied/already located paths can be read. No skill file
changes. Known genericDoD documentation reference drift is already resolved
under explicitproject gates, not a missing transitive SKILL.md to reopen.

Use simplest bounded metadata helpers; all CURRENT helper source max3/no classes/
asserts/customexceptions/globalmutablecontainers/silencederrors. Explicit CLI
flags/arity, inert import/empty/foreign arguments and clear effect boundaries.
Meaningful metadata integrity checks should detect changed/missing/malformed
inputs; do not write ceremonial tests for prose. Preserve helper originals and
all failed/intermediate command/stdout/stderr/exit/source/input snapshots.
New helper selfchecks/metadata audits are allowed; no reexecution of source45,
fixture, model/runtime suites, old recovery scripts or target native programs.

Every dependent Python metadata/check shell uses set-e and exact pinned restorer
with a NEW absolute receipt then metadata operation in SAMEshell. It restores
only its existing source closure, not fullnativeinput authorization:
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT
All direct Python including edits pinned -B-S, optional-O for ownedmetadata
checks. InterpreterSHA4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
PYTHONDONTWRITEBYTECODE=1, and exact PYTHONPATH when needed:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
Graphify:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650
Source-only restored reads in samecommand ifTMP disappears; no fetching/installing.
Build outputs/caches remain plannedfor/tmp(36GiBfree), workspace4.2GiBfree.
No evidence/worktree/cache/library deletion, gitclean/reset/rebase/forcepush.

Freeze current45 hashes and newunit preceding evidence integrity before work;
prove current45 unchanged after audit,119closure unchanged, allownedhelpers
strict/inert and newpacket/index bytes bound. Fullreport lists exact files,
commands/raw/results/authorities, matrix findings, observedvsrequired source
availability, selfreview, unresolved facts and recommended nextslice. Return
<=15lines DONE|DONE_WITH_CONCERNS|NEEDS_CONTEXT|BLOCKED, no commits, summary and
report path. Sourceavailability gaps alone do not mean this audit cannotfinish.
Root dispatches the fresh broadcombined review against your packet afterward.
All native/fullproject/platform/adoption/M1-M7 acceptance remains open.
