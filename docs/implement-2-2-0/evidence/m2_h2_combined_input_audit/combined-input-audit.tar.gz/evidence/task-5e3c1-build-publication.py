"""Archive the input audit with a lossless reference to existing Git blob data."""
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tarfile
from pathlib import Path, PurePosixPath


def sha(data):
    return hashlib.sha256(data).hexdigest()


def add(members, name, data, binary):
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or name in members:
        raise ValueError('Unsafe or duplicate member: ' + name)
    if name in binary:
        if sha(data) != binary[name]:
            raise ValueError('Binary identity differs: ' + name)
    else:
        data.decode('utf-8')
    members[name] = data


def collect(root, plan, binary):
    members = {}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError('Packet symlink: ' + str(path))
        if path.is_file():
            name = 'packet/' + path.relative_to(root).as_posix()
            if name != 'packet/raw/base-objects.stdout':
                add(members, name, path.read_bytes(), binary)
    names = ('task-5e3c1-brief.md', 'task-5e3c1-report.md', 'task-5e3c1-review-report.md',
             'task-5e3c1-review-package.diff', 'task-5e3c1-reviewer-restoration.json', 'task-5e3c1-root-audit.py',
             'task-5e3c1-root-audit-original.py', 'task-5e3c1-root-resume-audit.stdout',
             'task-5e3c1-root-resume-audit.stderr', 'task-5e3c1-root-resume-audit-inputs.json',
             'task-5e3c1-root-corrected-audit.stdout', 'task-5e3c1-root-corrected-audit.stderr',
             'task-5e3c1-root-corrected-audit.exit', 'task-5e3c1-root-corrected-audit-inputs.json',
             'task-5e3c1-root-final-audit.json', 'task-5e3c1-root-helper-check.json',
             'task-5e3c1-prepare-review.py', 'task-5e3c1-root-review-inputs.json',
             'task-5e3c1-build-publication.py', 'task-5e3c1-publication-audit.py',
             'task-5e3c1-git-batch-reference.json',
             'task-5e3c-native-transition-report.md', 'task-5e3b8a-restore-inputs.py')
    for name in names:
        add(members, 'evidence/' + name, (plan / name).read_bytes(), binary)
    return members


def git_reference(root, plan):
    candidate = json.loads((root / 'final-candidate-reconstruction.json').read_text())
    command = json.loads((root / 'raw/base-objects-command.json').read_text())
    queries = ''.join(candidate['base'] + ':' + row['path'] + '\n' for row in candidate['files']).encode()
    if len(candidate['files']) != 1031 or sha(queries) != command['stdin_sha256']:
        raise ValueError('Exact Git batch query order differs')
    ancestry = subprocess.run(['git', 'merge-base', '--is-ancestor', candidate['base'], '58bc6d6a525e01380ccc7bf3802e695c07877e89'], capture_output=True, check=True)
    if ancestry.stdout or ancestry.stderr:
        raise ValueError('Unexpected Git ancestry output')
    result = subprocess.run(command['argv'], input=queries, capture_output=True, check=True)
    expected = dict(size=102708085, sha256='86a11dc6c4f13c49b0675ff2547160680b76e1d48ff82a43f89286fb92d34044')
    if result.stderr or len(result.stdout) != expected['size'] or sha(result.stdout) != expected['sha256']:
        raise ValueError('Lossless Git batch reconstruction differs')
    reference = dict(packet_member='packet/raw/base-objects.stdout', expected=expected,
                     storage='Retained original raw locally; losslessly reproducible from immutable repository Git blobs',
                     base_commit=candidate['base'], reachable_from='58bc6d6a525e01380ccc7bf3802e695c07877e89',
                     ancestry_argv=['git', 'merge-base', '--is-ancestor', candidate['base'], '58bc6d6a525e01380ccc7bf3802e695c07877e89'], ancestry_exit=ancestry.returncode,
                     ordered_queries='packet/final-candidate-reconstruction.json files order; base_commit:path plus newline',
                     argv=command['argv'], stdin_sha256=sha(queries), exit=result.returncode, stderr='',
                     reproduced_stdout_bytes=len(result.stdout), reproduced_stdout_sha256=sha(result.stdout))
    (plan / 'task-5e3c1-git-batch-reference.json').write_text(json.dumps(reference, indent=2) + '\n')
    return reference


def write_archive(path, members):
    inventory = {name: dict(size=len(data), sha256=sha(data)) for name, data in sorted(members.items())}
    members = dict(members, **{'INVENTORY.json': (json.dumps(inventory, indent=2) + '\n').encode()})
    with gzip.GzipFile(filename=str(path), mode='wb', mtime=0) as compressed:
        write_tar(compressed, members)
    return inventory


def write_tar(compressed, members):
    with tarfile.open(fileobj=compressed, mode='w') as stream:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o444, 0
            stream.addfile(info, io.BytesIO(data))


def main(argv):
    if argv != ['--build']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    root = Path('.uwz-work/evidence/h2-streaming/combined-interface-audit')
    audit = json.loads((plan / 'task-5e3c1-root-final-audit.json').read_text())
    if audit['packet']['report_sha256'] != sha((plan / 'task-5e3c1-report.md').read_bytes()):
        raise ValueError('Reviewed report differs')
    reference = git_reference(root, plan)
    binary = {'packet/epoll-registration-rollback.bundle': '6f9f27199b2cc4bf47e7f04fd3d1862362899be283d84ec1e97c614b69a03580'}
    members = collect(root, plan, binary)
    if len([name for name in members if name.startswith('packet/')]) != 120:
        raise ValueError('Reviewed packet coverage differs')
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_combined_input_audit')
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'combined-input-audit.tar.gz'
    inventory = write_archive(archive, members)
    manifest = dict(scope='Combined interface and native-input availability audit; no native preparation or execution',
                    base_commit='58bc6d6a525e01380ccc7bf3802e695c07877e89',
                    archive=archive.name, archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
                    safe_regular_members=len(members) + 1, inventory_entries=len(inventory),
                    utf8_members=len(members) - len(binary) + 1, binary_members={name: inventory[name] for name in binary},
                    packet_files=121, packet_files_embedded=120, packet_files_referenced=1,
                    external_packet_members={reference['packet_member']: reference},
                    root_evidence_files=len(members) - 120, current_helpers=3, max_helper_nesting=3,
                    physical_paths=20893, authority_archives=10, authority_inventory_entries=10290,
                    interface_joins=7, exact_source_spans=50, candidate_expected=1031, candidate_matching=4,
                    candidate_missing=1027, candidate_reconstruction_origins=1031, libxev_expected=93, libxev_matching=0,
                    historical_fixture_binaries_matching=0, historical_fixture_binaries_required=2,
                    current_source_modules=45, preceding_files_unchanged=19808, retained_identity_entries=119,
                    physical_identity_rows=118, unique_resolved_files=113, ordered_codec_files=42,
                    source_review='Spec and quality approved; see verbatim evidence/task-5e3c1-review-report.md',
                    discovery_logging='Initial readonly discovery has explicitly qualified incomplete raw retention',
                    root_audit_correction='Preserved failed expectation optimized; actual receipt label is -O',
                    full_tree_restored=False, native_ready=False, native_executed=False, milestone_complete=False,
                    remaining=['Exact candidate and isolated dependency reconstruction', 'Native EOF contract resolution',
                               'Native provider and fresh runtime closure', 'Fresh builds and native all40',
                               'Full project/platform gates and production adoption', 'All remaining original milestones'])
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = {key: manifest[key] for key in ('archive_sha256', 'archive_bytes', 'safe_regular_members', 'inventory_entries', 'utf8_members', 'binary_members')}
    (plan / 'task-5e3c1-root-archive-build.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
