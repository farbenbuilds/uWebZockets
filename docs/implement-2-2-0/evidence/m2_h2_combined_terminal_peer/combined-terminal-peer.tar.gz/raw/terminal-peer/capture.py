"""Explicit opt-in source-only proof recorder; every invocation needs restoration."""
import ast
import hashlib
import json
import pathlib
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_map(root):
    return {path.name: digest(path) for path in sorted(root.glob('*.py'))}


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def freeze(directory):
    root = directory.parent.parent
    target = directory / 'baseline'
    target.mkdir()
    manifest = pathlib.Path('/workspaces/uWebZockets/docs/implement-2-2-0/evidence/m2_h2_combined_metadata_peer/manifest.json')
    expected = json.loads(manifest.read_text())['current_source_files']
    actual = source_map(root)
    if actual != expected or len(actual) != 40:
        raise ValueError('accepted source inventory differs')
    write_json(target / 'source.json', actual)
    for name in actual:
        (target / (name + '.txt')).write_bytes((root / name).read_bytes())
    history = {str(path.relative_to(root)): digest(path) for path in sorted((root / 'evidence').rglob('*'))
               if path.is_file() and not path.is_relative_to(directory)}
    write_json(target / 'prior_history.json', history)
    authority = root / 'evidence/coordinator-a/immutable-inputs.json'
    (target / 'immutable-inputs.json').write_bytes(authority.read_bytes())
    print('Frozen 40 sources and %d prior evidence files' % len(history))


def run(directory, name, module, optimized, arguments):
    root = directory.parent.parent
    target = directory / name
    target.mkdir()
    argv = [sys.executable, '-B', '-S'] + (['-O'] if optimized else []) + [str(module)] + arguments
    env = {'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': '/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'}
    write_json(target / 'command.json', dict(argv=argv, env=env, cwd=str(root), restoration=str(directory / ('restore-' + name + '.json'))))
    write_json(target / 'source-before.json', source_map(root))
    for path in sorted(root.glob('*.py')):
        (target / (path.name + '.txt')).write_bytes(path.read_bytes())
    (target / 'check-source.txt').write_bytes(module.read_bytes())
    (target / 'capture-source.txt').write_bytes(pathlib.Path(__file__).read_bytes())
    tree = ast.parse(module.read_text())
    (target / 'structure.txt').write_text(ast.dump(tree, indent=2))
    with (target / 'stdout.txt').open('wb') as out, (target / 'stderr.txt').open('wb') as err:
        result = subprocess.run(argv, cwd=root, env=env, stdout=out, stderr=err, check=False)
    write_json(target / 'exit.json', dict(exit_code=result.returncode))
    write_json(target / 'source-after.json', source_map(root))
    print(name + ': exit ' + str(result.returncode))


def main():
    if sys.argv[1:] == ['--freeze']:
        freeze(pathlib.Path(__file__).resolve().parent)
        return
    if len(sys.argv) < 5 or sys.argv[1] != '--run' or sys.argv[4] not in ('normal', 'optimized'):
        return
    directory = pathlib.Path(__file__).resolve().parent
    run(directory, sys.argv[2], pathlib.Path(sys.argv[3]).resolve(), sys.argv[4] == 'optimized', sys.argv[5:])


if __name__ == '__main__':
    main()
