# Shared independent terminal peer

Released after reviewed/pushed8f. BASE:
50a385fdcd42b7794a1a95e4f1f6c208d8fa65aa.
Accepted baseline40 manifest:
docs/implement-2-2-0/evidence/m2_h2_combined_metadata_peer/manifest.json.
Root audit: task-5e3b8f-root-commit-audit.json in this directory.
Implement accepted remaining-peer plan unit7/shared contract and aggregate notes.
This is source-only synthetic preparation, not actualall40/native/adoption/M2.

Own exactly these source paths beneath
/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases:
NEW test_terminal_peer.py; existing test_control_reset.py;
test_application_error.py; test_imports.py ONLY its necessary source inventory
addition. NEW evidence/terminal-peer and
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8g-report.md.
Baseline40 -> current41: three existing sources changed, one added,37 unchanged.
No other module/model/core/adapter/handler/fixture/codec/pin/product/limit edit.
Report exact extra API/ownership gap before edit. You are not alone: preserve all
others/historical source/raw. No agents/Git/publication/native/network/CLI.

One shared new_peer(case, *, app, prior, now, clock, final=False, fault=None)
in test_terminal_peer.py covers cancel_ready,cancel_paused,peer_reset,sink_error,
invalid_progress,end_error. Both existing check drivers import it DIRECTLY,
delete both old nested byte peers and selected terminal recipes. No forwarding
new_peer in each driver, no duplicate shared machinery. Exact {connection,state}
and connection7 protocol/send/receive/now/owned/tls/alpn; initialized pinned
protocol/queuednormalSETTINGS+ACK; supplied ownedTrue/TLSv1.3/h2. Validate inputs/
app/prior before effects. Constructor no clock/client dispatch/observe/final/app
mutation/selected completion. Canonical app4 via test_core_peer.new_app; preserve
app object/output/binding references and earned prior facts, no seeding.
Both check(case, *, app=None, prior=(), final=False, fault=None) signatures and
same-app returns/local synthetic clock behavior/prints remain. Default app
upgrades old2keys to canonical4keys, no speculative adapter. Shared helper's
imports flow one way; no driver/helper cycle. Source guard/import requirements
also cover the new module.

Normal peer facts derive only from decoded validated bytes and delivered
terminal/refund/control events. HEADERS earns metadata/admission/begin facts,
never accepted7 or future terminal facts. Fix old cancellation HEADERS seed:
only actual DATA earns accepted prefix. sink/progress DATA validation must
precede frame/count/digest mutation (old data increments before validation).
Use explicit bounded case distinctions, not selected model completion recipes
or client-context/capture as truth.

Cancellation cases: primary stream5 (sibling3), length7nonEND cancel_ready or
32nonEND cancel_paused/peer_reset. Preserve actual accepted7 ready/paused versus
peer_reset accepted0, one preterminal status and actual terminal action.
Public cancel produces incoming CANCEL8; peer_reset decodes outgoing CANCEL8
and MUST NOT count it as incoming. Application cases sink/progress send7nonEND,
deliver accepted-prefix status, then8nonEND (wire15, accepted7); end_error sends
32END, no preterminal status, and earns end failure. Incoming reset is
INTERNAL_ERROR2. Preserve failure/cancel/END/bytes/hash/chunk/metadata diagnostic
differences, not a generic terminal row.

All cases retain exact stale-control -> connection refund -> sibling -> recovery
-> stale-control order. Four stale controls earn independent counters and
BodyControlExpired, never future stale counts at terminate. Refund exactly the
primary transmitted bytes only after second stale control, and count it only
when actually delivered. Then sibling1byteEND/echo, recovery32END and remaining
stale controls/healthy request. No stream grant after closed primary and no
incoming reset for outgoing peer_reset. Split reset success must retain parser
partial state and deliver one reset, not two.

Move peer client-context assertions to DRIVER wrappers preserving their exact
original boundary: paired primary absent from records/raw/stage.active/credit
and outgoing retired+reset+response_end before FIRST actual stale control;
sibling connection debt exactly1 immediately after original adapter.send_data.
Peer independently proves its own delivered refund/stale/sibling state. Driver
wrapper invokes original once, preserves exact result/exception identity and
original error priority, restores instrumentation on failure. Do not replace
with final-only checks or add arbitrary observer callback to factory.

Preserve original budgets J/C/R:
cancel_ready12/11/40,cancel_paused12/11/65,peer_reset11/10/65;
sink_error11/10/48,invalid_progress11/10/48,end_error10/9/65.
Keep exact wire hashes: sink/progress bytes are span(32,0,7)+span(32,0,8), not
a contiguous15byte prefix. Recovery hash32 and siblingbyte s independent.
Both old mains' actual three-case shared chains/final68, split-reset positives,
all existing negative invocations and exact messages remain mandatory. Add an
ACTUAL mixed six-case shared-app chain through the factory with final68,
without family check substitutes or seeded prior success.

Fault names/messages from old mains are authority; preserve every one:
preterminal_bytes/pause/chunks/cancel; terminal_reason/metadata/cancel/ends/
bytes/hash/chunks; chunk/progress/end diagnostics; stale_reply/counter;
missing/excess_refund; sibling_echo; recovery_record; other_record;
early_final/primary_final; reset_code/duplicate_reset/missing_reset/split_reset.
Case-specific messages include upload completed before resume, unexpected final
versus invalid terminal, failure callback follows accepted prefix, missing finite
synthetic response, invalid connection refund, control result differs, and all
record mismatch diagnostics. Freeze/execute exact accepted Python baseline if
uncertain, preserve result; no guessed messages or weakened gate. Finite faults
alter named observations, normal persistent facts remain independent.

Bound parser8201/frame/send8192/HPACK and finite pending/read/bytes/upload/
stale/case cursors before growth/repeat. Preserve parent ceilings and old200read
cap unless a strictly bounded concrete tighter limit applies. No payload/request/
frame/read histories. Queued/delivered reset/refund and incoming/outgoing reset
receipts remain separate. Final permission alone inert; require actual ordinary
terminal/recovery completion and final68 on same protocol/parser/ledgers/debt/
receivecaps/deadlines. Metrics sum actual app records/heads.

Before editing: read actual AGENTS.md, CODING_CONVENTION.md, developer role and
narrow incremental/TDD/API/codebase-design workflows plus accepted context.
Use Graphify before a NEW codebase question/search/read; supplied paths are
located. Freeze the exact accepted baseline 40 sources and 119-input identity,
and a fresh exhaustive prior-evidence hash map excluding only this new unit.
Freeze before actual acceptance RED; constructor absence is a pre-effect RED,
not a behavioral defect. Each discovered defect needs the real source/RED
before its fix; preserve every failed/intermediate command/source/raw artifact.

After last source edit retain SIX focused checks: test_control_reset.py, test_application_error.py and
test_imports.py, each normal and -O. Other suites only for an identified
dependency or unanswered concern. Add meaningful direct constructor/prior/
metadata-vs-DATA/refusal-order/final/bounds/retention proofs as needed. Actual
shared prior cases must be earned from traffic; supplied fixtures remain
explicitly synthetic. Every check has exact argv/env/cwd, 41-source before and
after maps, separate stdout/stderr/exit and same-shell restoration receipt.
Capture the inventory actually present: baseline REDs have 40 modules and
post-addition checks have 41; do not fabricate a 41-module pre-addition map.
All 41 source AST/import guards, all CURRENT unit helper nesting <=3 and inert
import/empty/foreign argv, 119 authority/118 physical/113 resolved/42 ordered
codecs, frozen source and prior-history preservation must be audited. No live
helper is exempt as historical; preserve old bytes before correcting it. No
classes/assert/custom exceptions/global mutable containers/dead code/camelCase/
silenced errors/forwarding wrappers or weakened bounds, tests or lint.

Temporary inputs reset across continuations. EACH dependent Python proof,
audit or check exec_command shell must start with set -e and run the Root
restorer below, with a NEW absolute receipt, then its operation IN THAT SAME
SHELL. Never infer persistence from a prior Root command.

/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT

Pinned interpreter SHA256:
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
All direct Python, including source edits, uses this interpreter with -B -S;
optional -O for optimized. Exact PYTHONPATH:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases

Graphify invocation:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650

No native/build/server/socket/SSLContext/TLS-close/real-clock/process ownership/
kernel/fault scheduling/race/panic/crash/leak/old-runtime/install/network runs.
Only pinned in-memory codecs and supplied synthetic app/transport/process
facts. No additional named-skill drift is established by the known missing
generic DoD reference: explicit project gates/exact scope remain authoritative,
full native/project/platform gates mandatory later, not waived.

Write the full report at the owned report path: exact files/commands/raw/exits,
RED/GREEN chronology, all current source/check/input/history/helper audits,
self-review and actual gaps. Return concise DONE or specific concerns/context/
blocker under 15 lines. Remaining work alone is not missing context. Root owns
fresh source review, publication accuracy, commit and immediate push before
releasing the next serial peer unit. Full goal remains active.

