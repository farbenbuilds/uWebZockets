# Shared terminal peer implementation

DONE for the assigned source-only slice; independent Root review/publication remains pending.
BASE: `50a385fdcd42b7794a1a95e4f1f6c208d8fa65aa`.
Accepted baseline manifest: `docs/implement-2-2-0/evidence/m2_h2_combined_metadata_peer/manifest.json`.

## Exact ownership and result

Under `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/`:

- Added `test_terminal_peer.py`: one independent `new_peer(case, *, app, prior, now, clock, final=False, fault=None)` for all six terminal cases.
- Changed `test_control_reset.py`: removed nested peer and selected terminal recipe; direct shared factory import, canonical `new_app`, exact original driver interface and budgets, driver-side paired-retirement/sibling-debt instrumentation.
- Changed `test_application_error.py`: removed nested peer and selected terminal recipe; direct shared factory import, canonical `new_app`, existing original interface/budgets/mains; reuses the driver instrumentation from the cancellation driver.
- Changed `test_imports.py`: only added `test_terminal_peer` to the exact source inventory.
- Added `evidence/terminal-peer/`: frozen baseline, capture/proof/audit helpers, every intermediate/check source and raw receipt.
- Added this report. No other authored module, model, adapter, handler, codec, fixture, pin, product, or limit changed.

The final source audit proves baseline40 -> current41: three existing sources changed, one added, 37 unchanged. Both drivers import the same constructor directly. The peer imports neither driver nor adapter and reads no client context. The wrapper is driver-owned; no forwarding constructor or duplicate terminal machinery remains.

## Independent facts and invariants

The constructor validates case, arguments, canonical four-field app, earned prior records/heads, output facts and binding before creating effects. It returns exactly connection/state, with the existing seven connection keys and supplied owned/TLSv1.3/h2 facts. It queues normal SETTINGS/ACK and invokes no clock, dispatcher, observer or final collection. No application record or output/binding reference is replaced at construction.

Decoded HEADERS earns only admission/metadata/begin facts. Validated DATA earns accepted bytes/hash/chunks: cancellation ready and paused accept seven; peer reset accepts zero despite transmitting32; sink/progress transmit7+8 while accepting7; end failure receives32END. The sink/progress wire hash is the concatenation of two spans starting at offset zero, not a contiguous15-byte span. Malformed DATA is rejected before frame/count/digest/application mutation.

Terminal reason, callback diagnostics, cancel/END and metadata-end facts follow the concrete terminal action. No selected model completion recipe is used. Public cancellation queues incoming CANCEL8; application failure queues incoming INTERNAL_ERROR2; peer-reset parses outgoing CANCEL8 without increasing incoming queued/delivered reset counters. Faults change finite observations; persistent ordinary facts remain independent. Original negative names/messages and original three-case/final chains are preserved.

Four decoded stale requests earn counters individually. Separate delivery receipts track status/stale responses, queued versus delivered reset (including an11-byte partial reset), actual connection-only refund, sibling echo, recovery and final health. Refund equals primary transmitted bytes and is delivered after the second stale response, before sibling DATA. No stream grant follows the closed primary. Sibling and recovery retain independent digests.

The driver snapshots all four primary-retention maps and outgoing retired/reset/response_end at the serialized send inside the first stale `adapter.start`. The original operation runs once and its error wins; instrumentation restores in finally. Sibling debt is asserted immediately after the original `adapter.send_data` returns. Four map and three flag corruption controls in each driver family prove the snapshot boundary, with temporary corruption removed before receive. Direct wrapper controls prove exact result/exception identity, original-once invocation, priority and restoration, including original send errors while debt is wrong.

Storage bounds: parser8201, frame/send8192, HPACK4096, pending at most4 packets/16384 bytes, three rolling upload summaries, two response-delivery labels, finite heads/final68, statuses/stales/resets, reads200 and sent/received bytes200*8192. No request/payload/frame/read histories. Parser high-water accounting now includes consumed frames. Final permission is inert until ordinary completion; actual final collection preserves parser/protocol/ledger identity, request debt, cumulative read/byte accounting and deadlines.

## Freeze and RED/GREEN chronology

`evidence/terminal-peer/baseline/` was created before implementation. It contains the exact accepted40 source texts and hash map, the119-entry authority, and a fresh exhaustive map of11,284 prior evidence files excluding only this new unit. Final audits prove every prior file remains present and byte-identical, and the authority remains119 entries /118 physical rows /113 resolved files /42 ordered codecs.

1. `red-constructor`: exit1,40 modules before/after. Missing constructor is an explicit pre-effect absence RED, not a behavioral defect.
2. `red-headers`: exit1,40 modules before/after. Captured actual old closure shows HEADERS prematurely earns accepted7.
3. `red-data`: exit1,40 modules before/after. Captured actual old closure shows malformed DATA mutates upload count before rejection.
4. `green-control-first`, `green-application-first`: exit0,41 modules. Both full old mains pass through the shared peer, including every negative and original shared/final chains.
5. `green-direct-first`: exit1. Actual mixed six-case factory chain already passes. The retirement sensitivity proof exposed that the first draft instrumented `adapter.get`, while stale controls actually use `adapter.start`; its bad snapshot gate was never reached. Source, failed proof, stdout/stderr and result remain captured.
6. `green-direct-boundary`: exit0 after moving the wrapper to `adapter.start` and adapting corruption injection to the actual serialized send. All14 boundary corruptions reject.
7. Initial six `cover-*` checks, `final-direct-*` checks and `strict-audit-*`: all exit0. Further direct-v2 proofs add cumulative final receive-accounting and original send-error identity/priority; both normal/optimized and strict-audit-v2 passed.
8. `red-buffer-receipt`: exit1,41 modules. Self-review added a direct assertion showing a consumed SETTINGS ACK was absent from the parser high-water receipt. The fix records storage after bounded append and before consumption; source and RED are retained.
9. FINAL `cover-v3-*`, `final-direct-v3-*`, `strict-audit-v3-*`: every check exit0, stderr empty. No source edits follow these checks.

The initial constructor and buffer RED recorder guessed a restoration filename from the check label. Both checks had the required fresh successful same-shell restoration under another name. `command-initial.json` preserves the original metadata; `command.json` now points to the actual `restore-red-setup.json` and `restore-buffer-proof-edit.json`, respectively. No restoration result or source inventory was fabricated. The pre-edit RED helper is retained as `red-original.txt`; its exact executed source is also in each RED check-source artifact. It is historical text, not an unguarded current Python helper.

## Exact executed check commands and receipts

Root directory `R` below is the absolute path:
`/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases`.
Unit `U` is `R/evidence/terminal-peer`.
Interpreter `P` is `/home/codespace/.python/current/bin/python3`, SHA256
`4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`.

Every dependent Python shell started with `set -e` and the exact Root restorer in that same shell:

```sh
P -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore U/restore-NAME.json
```

Each child check used exactly this complete environment (not inherited shell variables):

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
```

The captured command form was `P -B -S U/capture.py --run NAME MODULE MODE [ARGS...]` under that environment. `capture.py` executes `P -B -S [-O] MODULE [ARGS...]` with cwd exactly `R`. Every check directory retains exact expanded `command.json` argv/env/cwd/restoration, before/after inventory, all current source texts, check/capture source, AST, separate stdout/stderr, and exit.json. The command.json is the exact authoritative invocation, including actual audit CLI flags.

Final executed matrix (each row ran both normal and optimized, with the corresponding suffix):

| NAME prefix | MODULE | Extra arguments | Outcomes |
|---|---|---|---|
| cover-v3-control | R/test_control_reset.py | none | 0 /0 |
| cover-v3-application | R/test_application_error.py | none | 0 /0 |
| cover-v3-imports | R/test_imports.py | none | 0 /0 |
| final-direct-v3 | U/proofs.py | --run | 0 /0 |
| strict-audit-v3 | U/audit.py | --audit U/audit-v3-normal or U/audit-v3-optimized | 0 /0 |

All six final covering checks match the final41-source map. Direct proofs execute all six canonical handlers through the actual factory with a single shared app, earned prior traffic and final68:67 ordinary heads +68 =135. No family check substitute or seeded prior success is used for that chain. Constructor/invalid-prior tests, causal metadata/DATA, malformed DATA rejection, final gate, bounded-growth tests, split-reset/refund/stale receipts, retention sensitivity and wrapper contracts pass under both interpreters.

Both final strict audits ran their actual `--audit` CLI through capture. They verify119/118/113/42 immutable identities, interpreter, all41 source AST guards/conventions, exact ownership, frozen source preservation, all11,284 prior-evidence hashes, current helper guard/import/main-empty/main-foreign behavior, and both nesting counters. The three current helpers (`capture.py`, `proofs.py`, `audit.py`) have max depth2 under both counters. All41 source modules pass inert-import checks; source maximum accepted nesting is3.

Graphify query was used for new codebase navigation. `graphify update .` ran with the prescribed local tool environment and reported no relevant graph changes, exit0. Its stdout/stderr/exit and same-shell restoration receipt are retained. No Git, publication, external service, network, build, native server, socket/TLS context, old runtime, installation, or agent delegation was performed.

## Self-review and remaining boundaries

Self-review covered all changed source and current helpers, one-way imports, exact original negative invocations/messages, budgets, hash distinctions, causal transition timing, reset direction, finite receipts, final gate/accounting, instrumentation restoration and error priority. The two implementation defects found during this pass (wrong adapter seam and undercounted parser high-water receipt) have retained REDs and verified fixes. No unresolved API or ownership gap is known.

These are pinned in-memory codec executions with supplied synthetic application and transport facts. No native behavior or fixture correctness is established. Root still owns independent review, publication accuracy, commit and immediate push. Independent aggregate receipts, actual default/all40 coordination, broad combined review, runtime/native/full project/platform gates, adoption and every original milestone remain required. Formatting/conventions/version/Zig/full gates were not run in this source-only slice because the explicit brief prohibits native/build operations; they are deferred, not waived.
