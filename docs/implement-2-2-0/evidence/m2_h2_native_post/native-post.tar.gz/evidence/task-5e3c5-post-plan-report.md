Implement only `.uwz-work/evidence/h2-streaming/combined-native/native_post.py` and `test_native_post.py` after separate release. Preserve pure `S46`, its import inventory, C4 files and immutable archives.

References: `F/` = `combined-fixture.tar.gz::source/fixture/`; `M/` = `combined-all40.tar.gz::reference/model/`; `R/` = `output-driver.tar.gz::source/runtime/`, under their existing `docs/implement-2-2-0/evidence/m2_h2_*` directories.

**Assumptions and prerequisites.** Input is the complete caller-owned fixture capture, with explicit collector facts and an independently established expected capacity line. Parsing cannot establish process identity, actual deinitialization, successful exit/reap or cleanup. Those remain provider-owned prerequisites. No runtime imports or native execution enter this slice.

1. **Implement bounded pure parsing — verification owns; transport_io guides capture semantics.**

   Proposed interfaces:

   - `parse_capture(capture: CaptureFacts, nonce: str, expected_capacity: str) -> PostFacts`
   - `validate_post(selection: CaseSelection, before: PreFacts, after: PostFacts) -> None`

   Named dictionary contracts:

   - `CaptureFacts`: exactly `bytes`, `overflow`, `error`, `finished`; require bytes<=65536, `overflow is False`, `error is None`, `finished is True`.
   - `PostFacts`: exactly `records`, `metrics`, `outputs`, `binding`, matching the existing post hook.
   - `PreFacts`: those same semantic fields, with nullable pre-binding.

   `R/capture.py:5` retains at most65536 bytes, accepts collector reads<=8192 and preserves overflow/error separately. Truncated bytes must never become acceptable merely because their retained length fits.

   Decode strict UTF-8; require complete LF-terminated lines. Recognize full anchored fixture lines with the emitted `info: ` prefix, never substring matches. The fixture emits this ordered75-line subsequence (`F/profile.zig:266`):

   - `info: H2_CAPACITY config=<JSON> request_stride=<decimal> h2_bytes=<decimal> h2_stride=<decimal> slab=<decimal> router=<decimal>`
   - `info: H2_READY <nonce>`
   - `info: H2_BINDING <nonce> tag=producer_reuse_next index=<decimal> generation=<decimal>`
   - 67 `info: H2_RECORD <nonce> <JSON>` lines in `M/model.py:23` BODY_SPECS order.
   - Four `info: H2_OUTPUT <nonce> <JSON>` lines: `producer_reuse`, `output_pressure_window`, `output_pressure_ready`, `stream_file`.
   - One `info: H2_DEINIT <nonce> <JSON>`.

   Require nonce `[A-Za-z0-9_]{1,32}` (`F/log_bounds.zig:9`). Reject duplicate, missing, reordered, extra, unknown, wrong-nonce or malformed fixture markers, including markers embedded in another line. Bounded unrelated diagnostics may remain outside the fixture subsequence; they never satisfy evidence requirements.

   Compare the complete capacity payload exactly against caller-supplied authenticated expectation; do not infer expected strides from observed output. Preserve all six fields, including the complete config. `F/profile.zig:19` defines the fixture configuration; `:266` computes actual sizes.

   Enforce body JSON<=768 bytes, output/deinit JSON<=1024, nonce-line overhead<=64, combined capacity/ready/binding/deinit allowance<=2048, and fixture-line total<=62144 (`F/log_bounds.zig:20`, `:61`, `:100`, `:129`). The full capture retains its65536 ceiling.

   JSON decoding must reject duplicate object keys, non-object roots, trailing documents, floats, nonfinite constants and out-of-range integers; booleans remain distinct from integers. Build dictionaries only after duplicate-tag checks. Do not normalize legacy schemas.

2. **Reuse canonical comparisons — verification with http_protocol.**

   Exact field contracts already exist:

   - Records: `COMMON_RECORD + FAMILY_EVIDENCE[family]`, `M/model.py:15`.
   - Producers: `PRODUCER_NUMBERS`, `armed`, `done`, `tag`, `sha256`, `:49`.
   - File: `FILE_NUMBERS`, `transferred`, `caller_owned`, `tag`, `:50`.
   - Binding: `tag`, `binding_index`, `binding_generation`, `:433`. Convert only textual `index`/`generation` names.
   - Metrics: `COMMON_COUNTERS`, `bytes`, `active`, `paused`, `buffered_middleware`, `slot0_active`, `slot1_active`; emitted at `F/formatting.zig:62`.

   Call existing pure validators:

   - `model.validate_pre_post(selection, before['records'], after['records'])` (`:343`).
   - `model.validate_metrics(selection, 'before', before['metrics'])` and corresponding `'after'` (`:389`).
   - `model.validate_output_pre_post(selection, before['outputs'], after['outputs'], binding_before=before['binding'], binding_after=after['binding'])` (`:382`).

   These validate all67 records, all four outputs and exact fields/types. Only selected `shutdown_active` changes: cancels becomes1, active/paused becomeFalse, reason becomes`shutdown`; every other record field remains identical. Metrics consequently gain one cancellation and lose one active/paused body; outputs and binding remain unchanged.

   Preserve observed producer counters. Canonical algebra permits scheduling-dependent attempts/blocks while requiring2049 writes, one terminal, completed hash/offset and metadata checks (`:265`). Binding uses actual slot0-or1 and relative generation+1 (`:285`, `:440`), never synthetic generation18. Actual fixture generation increments at `F/output_body.zig:82`; producer capture retains it at `F/output.zig:50`.

3. **Focused source-only proof — verification, then independent reviewer.**

   Test valid ordinary/idle/active captures, valid differing producer counters/generations, unselected defaults, and exact shutdown delta. Mutate each marker/count/order/nonce, JSON key/type, capacity field, capture flag, payload limit, producer equation, binding relation and post-deinit field. Include invalid UTF-8, truncated final line, duplicate tags/keys, overflow and bool-as-int regressions. Confirm rejected input cannot mutate `before`; add native-specific inert-import coverage.

The deep seam is complete-capture parsing plus canonical comparison: deleting it would spread framing, multiplicity and schema checks across provider hooks. `R/post.py:29` is historical context only: its32-record count,64-character nonce, substring matching and unchanged-body assumption are incompatible.

No edits or tests were performed. Existing project gates remain required; this source plan grants neither implementation release nor native acceptance.
