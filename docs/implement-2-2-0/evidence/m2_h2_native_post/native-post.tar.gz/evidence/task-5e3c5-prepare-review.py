import difflib
import hashlib
import json
import sys
import tarfile
from pathlib import Path


def main(arguments):
    if arguments != ['--prepare']:
        return
    plan = Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan')
    source = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native')
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_native_closing/native-closing.tar.gz')
    if hashlib.sha256(archive.read_bytes()).hexdigest() != '83d71ed27c0680121216d1e0df00020a2556505dc1a4817d8d1b686317356c7a':
        raise ValueError('Review baseline differs')
    with tarfile.open(archive, 'r:gz') as stream:
        baseline = stream.extractfile('native/test_native_imports.py').read()
    paths = [source / name for name in ('test_native_post.py', 'test_native_imports.py', 'native_post.py')]
    controls = source / 'evidence/native-post/control'
    paths.extend(sorted(controls.glob('*.py')))
    paths.extend(sorted(controls.glob('*.sh')))
    paths.extend((plan / 'task-5e3c5-root-audit.py', Path(__file__)))
    parts = ['# C5 pure fixture-capture and post-facts source review\n',
             'Base/current HEAD ed1647336f8136630a910cf0ef4baf98d7a1b6de; ignored source additions.\n']
    inventory = []
    for path in paths:
        data = path.read_bytes()
        old = baseline if path == source / 'test_native_imports.py' else b''
        inventory.append(dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest()))
        parts.extend(difflib.unified_diff(old.decode().splitlines(True), data.decode().splitlines(True),
                     fromfile='C4/test_native_imports.py' if old else '/dev/null', tofile=str(path), n=10))
    parts.extend(['\n# Root independent preservation and structure result\n',
                  (plan / 'task-5e3c5-root-final-audit.json').read_text()])
    package = plan / 'task-5e3c5-review-package.diff'
    package.write_text(''.join(parts))
    (plan / 'task-5e3c5-review-inputs.json').write_text(json.dumps(inventory, indent=2) + '\n')
    print(json.dumps(dict(path=str(package), size=package.stat().st_size,
                         sha256=hashlib.sha256(package.read_bytes()).hexdigest(), files=len(paths))))


if __name__ == '__main__':
    main(sys.argv[1:])
