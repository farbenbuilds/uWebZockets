"""Check public environment substitutions without exporting private values."""
import hashlib
import json
import sys
from pathlib import Path, PurePosixPath


def fields(data):
    if not data.endswith(b'\0'):
        raise ValueError('Invalid environment record')
    parts = [item.split(b'=', 1) for item in data[:-1].split(b'\0')]
    if any(len(item) != 2 or not item[0] for item in parts):
        raise ValueError('Invalid environment record')
    result = dict(parts)
    if len(parts) != len(result):
        raise ValueError('Ambiguous environment record')
    return result


def contained(root, relative):
    name = PurePosixPath(relative)
    if name.is_absolute() or '..' in name.parts:
        raise ValueError('Unsafe projection path')
    path = root / relative
    if path.is_symlink() or not path.resolve(strict=True).is_relative_to(root.resolve()):
        raise ValueError('Unsafe projection destination')
    return path


def substitutions(source):
    public = source / 'evidence/native-post/privacy-publication-inputs'
    manifest = json.loads((public / 'manifest.json').read_text())
    keys = (b'PYTHONDONTWRITEBYTECODE', b'PYTHONHASHSEED', b'PYTHONPATH')
    originals, missing, secrets = set(), 0, set()
    for row in manifest['substitutions']:
        member = row['original_member']
        if not member.startswith('native/'):
            raise ValueError('Unexpected original member')
        path = contained(source, member.removeprefix('native/'))
        if path in originals:
            raise ValueError('Duplicate original member')
        originals.add(path)
        original = fields(path.read_bytes())
        replacement = contained(public, row['replacement']).read_bytes()
        expected = b''.join(key + b'=' + original[key] + b'\0' for key in keys if key in original)
        if replacement != expected or set(fields(replacement)) - set(keys):
            raise ValueError('Public projection differs from recorded controls')
        absent = [key.decode() for key in keys if key not in original]
        retained = [key.decode() for key in keys if key in original]
        if row['absent_controls'] != absent or row['retained_controls'] != retained:
            raise ValueError('Projection disclosure differs')
        if absent not in ([], ['PYTHONHASHSEED']) or row['original_private_unpublished'] is not True:
            raise ValueError('Historical qualification differs')
        missing += bool(absent)
        secrets.update(original[key] for key in (b'GITHUB_TOKEN', b'GITHUB_CODESPACE_TOKEN') if original.get(key))
    if len(originals) != 25 or missing != 9 or manifest['projections_with_three_controls'] != 16:
        raise ValueError('Historical projection coverage differs')
    base = source / 'evidence/native-post'
    actual = {path for path in base.glob('*/environment.nul') if not path.parent.name.startswith('privacy-')}
    if originals != actual:
        raise ValueError('Original path coverage differs')
    return originals, secrets, dict(original_private_files=25, retained_three_controls=16,
                                    explicit_historical_seed_absence=9, public_controls_exact=True)


def public_safety(source, originals, secrets):
    checked = 0
    for path in source.rglob('*'):
        if path.is_symlink():
            raise ValueError('Unexpected native packet symlink')
        if path.is_file() and path not in originals:
            data = path.read_bytes()
            if any(value in data for value in secrets):
                raise ValueError('Private credential value outside retained originals')
            checked += 1
    return dict(nonoriginal_files_checked=checked, current_captured_credential_matches=0,
                scope='Known currently captured auth values only; not a comprehensive historical secret audit')


def frozen_native(plan, source):
    manifest = Path('docs/implement-2-2-0/evidence/m2_h2_native_closing/manifest.json')
    expected = json.loads(manifest.read_text())['current_native_sources']
    expected.update(json.loads((plan / 'task-5e3c5-root-fix1-audit.json').read_text())['touched_sources'])
    actual = {path.name: path for path in source.glob('*.py')}
    if len(actual) != 5 or set(expected) != set(actual):
        raise ValueError('Native source inventory differs')
    for name, path in actual.items():
        data = path.read_bytes()
        if len(data) != expected[name]['size'] or hashlib.sha256(data).hexdigest() != expected[name]['sha256']:
            raise ValueError('Approved native source changed')
    return len(actual)


def main(arguments):
    if arguments != ['--audit']:
        return
    source = Path('.uwz-work/evidence/h2-streaming/combined-native')
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    originals, secrets, projection = substitutions(source)
    result = dict(projection=projection, safety=public_safety(source, originals, secrets),
                  frozen_native_sources=frozen_native(plan, source),
                  private_values_or_hashes_printed=False, native_executed=False, milestone_complete=False)
    (plan / 'task-5e3c5-root-privacy-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
