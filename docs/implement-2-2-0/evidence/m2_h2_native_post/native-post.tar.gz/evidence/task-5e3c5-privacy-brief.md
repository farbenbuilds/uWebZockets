# Prepare safe public environment evidence before C5 publication

Root architecture/ruling: publication is halted until this bounded privacy
slice is independently reviewed. C5 parser/spec and diagnostic fix are already
approved. Do not change native_post.py, test_native_post.py, native_closing.py,
their tests, the native import inventory, canonical sources or committed files.
No C6 implementation release. BASE remains ed1647336f8136630a910cf0ef4baf98d7a1b6de.

Observed boundary and threat: control/run.sh records env -0, so 25 local
environment.nul files contain ambient authentication credentials. Root checked
KEY NAMES ONLY without printing values. No C5 archive or commit was created.
Root also checked the pushed C4 archive for the two currently captured values
and found no matches; that is not a comprehensive historical secret audit.
Private ambient process environment must never cross into public Git evidence.
Exact runtime-control evidence must remain truthful; no fabricated fields.

Own only combined-native/evidence/native-post/control/run.sh and new minimal
public_environment.py plus its focused tests under that same control directory.
New raw proof under evidence/native-post/privacy-*. You are sole implementer,
not alone; preserve others. No subagents/Git/publication. Root owns archive
assembly and will apply your reviewed transformation to environment members.

Implement a named, pure bytes-to-bytes projection for environment.nul evidence:
- Retain exactly PYTHONDONTWRITEBYTECODE, PYTHONHASHSEED and PYTHONPATH in a
  deterministic documented order with their actual recorded values.
- PYTHONDONTWRITEBYTECODE and PYTHONPATH must be present exactly once. A fresh
  key-only Root audit found nine historical captures genuinely lack
  PYTHONHASHSEED. Preserve that absence: omit the missing seed from projected
  bytes and record it as absent in the manifest, never synthesize zero. When
  present, seed must occur once and equal zero. Validate the source-controlled
  values (1, optional 0, and the exact six-part PYTHONPATH in the C5 brief).
  New wrapper captures must contain all three controls. Historical absence is
  a qualified fact, not an accepted missing field in new runs.
- Preserve valid NUL-delimited key=value grammar and return only the three
  allowlisted records. All other keys AND values are omitted, independent of
  their spelling. Handle '=' inside values without lossy splitting. Reject
  malformed/ambiguous required-control records with generic errors that do not
  echo source bytes or values. No classes/global mutable state/custom errors.
- Make the module inert on import and empty/foreign CLI. No new native helper
  import inventory entry is needed for a metadata-only control module.

Change future run.sh capture to record only these three already-exported
controls, preferably shell printf so no dependent Python operation precedes
fresh restoration. Do not rerun parser/C4/S46/all40 suites for this metadata fix.
Prove the wrapper captures an allowlist using fake ambient credential sentinels
and a harmless command, with the same restoration/source snapshot policy.

Keep every existing original environment.nul UNCHANGED locally. Generate safe
public projections separately under a clearly named privacy publication input
directory, with a manifest identifying each original member path and its safe
replacement. No private values, credential hashes or full raw environments in
logs, reports, manifests, new snapshots or responses. Describe original raw
sources as private/unpublished. Root will deliberately substitute public
projection bytes at those archive paths and disclose this transformation in
the public manifest; never claim public environment bytes equal full originals.
Other evidence/source bytes remain exact. Do not copy originals into new raw
snapshots; before manifests may bind paths/counts without exposing values.

TDD using synthetic credentials only: retain a real behavioral RED proving
naive whole-environment inclusion unsafe, then GREEN that only three controls
remain, fake credentials and unknown-key values do not appear, '=' handling is
correct, malformed/duplicate/missing controls reject, projection is idempotent,
  and inputs are not mutated. Missing either always-required control rejects;
  historical seed absence is retained and disclosed. Normal/-O tests and inert guards;
check all 25 actual historical projections silently, reporting counts only.
Preserve all exercised new helper/control versions before their runs. Snapshot
the old run.sh before modification. Do not attempt to reconstruct missing past
Graphify history or repeat navigation queries. No secret values printed.

Every dependent Python shell uses fresh pinned task-5e3b8a-restore-inputs.py
receipt in the SAME shell before operation, PYTHONDONTWRITEBYTECODE=1 and
/home/codespace/.python/current/bin/python3 -B -S, exact PYTHONPATH in C5 brief.
No compiler/server/socket/TLSContext/realclock/network/install operations.
Follow AGENTS/conventions/narrow security-and-hardening and TDD skills. Existing
project gates are not waived; this is source/evidence preparation only.

Report <=1000 words preferred at task-5e3c5-privacy-report.md in this plan
directory, with files/hashes/commands/counts/raw references and qualifications.
Return concise DONE|DONE_WITH_CONCERNS|NEEDS_CONTEXT|BLOCKED. No credentials,
values or secret-containing excerpts. Independent review precedes publication.
