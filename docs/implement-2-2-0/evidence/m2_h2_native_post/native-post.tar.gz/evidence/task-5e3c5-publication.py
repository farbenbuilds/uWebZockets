"""Publish reviewed post-facts sources with explicit safe environment substitutions."""
import hashlib
import json
import runpy
import sys
import tarfile
from pathlib import Path, PurePosixPath


def sha(data):
    return hashlib.sha256(data).hexdigest()


def prior(plan):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_native_closing/native-closing.tar.gz')
    if sha(archive.read_bytes()) != '83d71ed27c0680121216d1e0df00020a2556505dc1a4817d8d1b686317356c7a':
        raise ValueError('Published parent authority differs')
    path = plan / 'task-5e3c4-publication.py'
    with tarfile.open(archive, 'r:gz') as stream:
        if stream.extractfile('evidence/' + path.name).read() != path.read_bytes():
            raise ValueError('Published metadata helper differs')
    return runpy.run_path(str(path))


def safe_path(root, name):
    relative = PurePosixPath(name)
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('Unsafe publication input path')
    path = root / name
    if path.is_symlink() or not path.resolve(strict=True).is_relative_to(root.resolve()):
        raise ValueError('Publication input escapes its root')
    return path


def environment_substitutions(source):
    control = source / 'evidence/native-post/control/public_environment.py'
    if sha(control.read_bytes()) != 'c0a0e4941eec367cf7a096268ff2bee06716dcdc8b149b05fc22d19e211c2a65':
        raise ValueError('Reviewed privacy projection differs')
    project = runpy.run_path(str(control))['project_environment']
    root = source / 'evidence/native-post/privacy-publication-inputs'
    manifest = json.loads((root / 'manifest.json').read_text())
    replacements, secrets = {}, set()
    for row in manifest['substitutions']:
        name = row['original_member']
        if not name.startswith('native/') or name in replacements:
            raise ValueError('Unexpected private member identity')
        original = safe_path(source, name.removeprefix('native/')).read_bytes()
        public = safe_path(root, row['replacement']).read_bytes()
        if public != project(original) or row['original_private_unpublished'] is not True:
            raise ValueError('Reviewed public projection differs')
        fields = dict(item.split(b'=', 1) for item in original.split(b'\0') if item)
        secrets.update(fields[key] for key in (b'GITHUB_TOKEN', b'GITHUB_CODESPACE_TOKEN') if fields.get(key))
        replacements[name] = public
    if len(replacements) != 25 or manifest['projections_with_three_controls'] != 16 or manifest['projections_with_two_controls'] != 9:
        raise ValueError('Private environment projection coverage differs')
    return replacements, secrets, manifest


def source_inventory(source, plan):
    path = Path('docs/implement-2-2-0/evidence/m2_h2_native_closing/manifest.json')
    expected = json.loads(path.read_text())['current_native_sources']
    expected.update(json.loads((plan / 'task-5e3c5-root-fix1-audit.json').read_text())['touched_sources'])
    actual = {p.name: dict(size=p.stat().st_size, sha256=sha(p.read_bytes())) for p in source.glob('*.py')}
    wanted = {name: dict(size=row['size'], sha256=row['sha256']) for name, row in expected.items()}
    if actual != wanted or len(actual) != 5:
        raise ValueError('Reviewed five-source native inventory differs')
    return actual


def collect(source, plan, replacements, references):
    members = dict(references)
    for path in sorted(source.rglob('*')):
        if path.is_symlink():
            raise ValueError('Native packet symlink')
        if not path.is_file():
            continue
        name = 'native/' + path.relative_to(source).as_posix()
        members[name] = replacements[name] if name in replacements else path.read_bytes()
    names = ('task-5e3c5-brief.md', 'task-5e3c5-post-plan-report.md', 'task-5e3c5-report.md',
             'task-5e3c5-review-report.md', 'task-5e3c5-fix1-review-report.md',
             'task-5e3c5-review-package.diff', 'task-5e3c5-fix1-review-package.diff',
             'task-5e3c5-review-inputs.json', 'task-5e3c5-root-audit.py',
             'task-5e3c5-root-audit-initial.py', 'task-5e3c5-prepare-review.py',
             'task-5e3c5-root-before-fix1-audit.json', 'task-5e3c5-root-before-fix1-audit.stdout',
             'task-5e3c5-root-before-fix1-audit.stderr', 'task-5e3c5-root-before-fix1-audit.exit',
             'task-5e3c5-root-fix1-audit.json', 'task-5e3c5-root-fix1-audit.stdout',
             'task-5e3c5-root-fix1-audit.stderr', 'task-5e3c5-root-fix1-audit.exit',
             'task-5e3c5-root-final-inputs.json', 'task-5e3c5-root-fix1-inputs.json',
             'task-5e3c5-privacy-brief.md', 'task-5e3c5-privacy-report.md',
             'task-5e3c5-privacy-review-report.md', 'task-5e3c5-privacy-review-package.diff',
             'task-5e3c5-privacy-audit.py', 'task-5e3c5-privacy-audit-initial.py',
             'task-5e3c5-root-privacy-audit.json', 'task-5e3c5-root-privacy-audit.stdout',
             'task-5e3c5-root-privacy-audit.stderr', 'task-5e3c5-root-privacy-audit.exit',
             'task-5e3c5-root-privacy-inputs.json', 'task-5e3c5-root-environment-controls.json',
             'task-5e3c5-root-c4-secret-audit.json', 'task-5e3c5-publication.py',
             'task-5e3b8a-restore-inputs.py')
    for name in names:
        members['evidence/' + name] = (plan / name).read_bytes()
    return members


def publication_inputs(source, plan):
    parent = prior(plan)
    replacements, secrets, disclosure = environment_substitutions(source)
    members = collect(source, plan, replacements, parent['references']())
    for name, data in members.items():
        data.decode('utf-8')
        if any(value in data or value in name.encode('utf-8') for value in secrets):
            raise ValueError('Private credential value in publication input')
    return parent, members, replacements, disclosure


def build(plan, source, folder):
    current = source_inventory(source, plan)
    parent, members, replacements, disclosure = publication_inputs(source, plan)
    api = parent['published_api'](plan, 'task-5e3c1-build-publication.py')
    safe = {}
    for name, data in members.items():
        api['add'](safe, name, data, {})
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'native-post.tar.gz'
    inventory = api['write_archive'](archive, safe)
    manifest = dict(scope='Pure native fixture capture and canonical post facts; source-only',
                    base_commit='ed1647336f8136630a910cf0ef4baf98d7a1b6de',
                    archive=archive.name, archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
                    safe_regular_utf8_members=len(safe) + 1, inventory_entries=len(inventory),
                    native_packet_files=sum(name.startswith('native/') for name in safe),
                    reference_files=sum(name.startswith('reference/') for name in safe),
                    root_evidence_files=sum(name.startswith('evidence/') for name in safe),
                    current_native_sources=current, public_environment_substitutions=len(replacements),
                    public_environment_disclosure=disclosure, private_originals_embedded=False,
                    fixture_markers=75, body_records=67, output_records=4,
                    focused_groups=9, semantic_field_mutations=1485, diagnostic_placement_cases=380,
                    capture_bytes_limit=65536, fixture_bytes_bound=62144,
                    component_boundary_vector_bytes=61150, capacity_numbers_are_native_measurements=False,
                    source_review='Original P2 and approved fix retained verbatim',
                    privacy_review='Preparation approved; archive application verified separately',
                    credential_scan_scope='Known currently captured authentication values only; not comprehensive historical audit',
                    historical_limits=['Nine earliest environment records omit the unrecorded seed',
                                       'First exploratory Graphify query lacks transitive tool snapshot'],
                    native_compiled=False, native_executed=False, milestone_complete=False)
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({key: manifest[key] for key in ('archive_sha256', 'archive_bytes',
                     'safe_regular_utf8_members', 'native_packet_files', 'reference_files', 'root_evidence_files')}))


def audit(plan, source, folder):
    parent, expected, replacements, disclosure = publication_inputs(source, plan)
    api = parent['published_api'](plan, 'task-5e3c1-publication-audit.py')
    manifest = json.loads((folder / 'manifest.json').read_text())
    archive = folder / manifest['archive']
    if archive.stat().st_size != manifest['archive_bytes'] or sha(archive.read_bytes()) != manifest['archive_sha256']:
        raise ValueError('Public archive identity differs')
    contents = api['read_archive'](archive)
    if contents != expected or len(contents) != manifest['inventory_entries']:
        raise ValueError('Whole public archive differs')
    if source_inventory(source, plan) != manifest['current_native_sources'] or disclosure != manifest['public_environment_disclosure']:
        raise ValueError('Reviewed sources or privacy disclosure differ')
    if len(contents) + 1 != manifest['safe_regular_utf8_members'] or len(replacements) != manifest['public_environment_substitutions']:
        raise ValueError('Public coverage counts differ')
    check = runpy.run_path(str(plan / 'task-5e3c1-prepare-review.py'))['root_check']
    helpers = {name: check((plan / name).resolve()) for name in (
        'task-5e3c5-root-audit.py', 'task-5e3c5-prepare-review.py',
        'task-5e3c5-privacy-audit.py', 'task-5e3c5-publication.py')}
    docs = Path('docs/implement-2-2-0')
    files = [docs / 'README.md', docs / 'm2_request_streaming.md', docs / 'm2_h2_native_post.md',
             folder / 'README.md', folder / 'manifest.json', archive]
    result = dict(archive_sha256=sha(archive.read_bytes()), archive_bytes=archive.stat().st_size,
                  safe_regular_utf8_members=len(contents) + 1, inventory_entries=len(contents),
                  explicit_private_substitutions=len(replacements), private_originals_embedded=False,
                  known_captured_auth_values_absent=True, credential_scan_comprehensive=False,
                  helpers=helpers, local_links_checked=api['verify_links'](files),
                  delivery_files={str(path): dict(size=path.stat().st_size, sha256=sha(path.read_bytes())) for path in files},
                  native_executed=False, milestone_complete=False)
    (plan / 'task-5e3c5-root-publication-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('helpers', 'delivery_files')}))


def main(arguments):
    if arguments not in (['--build'], ['--audit']):
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/combined-native')
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_native_post')
    if arguments == ['--build']:
        build(plan, source, folder)
        return
    audit(plan, source, folder)


if __name__ == '__main__':
    main(sys.argv[1:])
