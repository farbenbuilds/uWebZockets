# Parse native fixture capture and compare canonical post-shutdown facts

Released after C4 source review, publication review and pushed checkpoint.
BASE ed1647336f8136630a910cf0ef4baf98d7a1b6de on feat/implement-2-2-0;
Root post-commit audit confirms clean/pushed exact six reviewed files.

Read task-5e3c5-post-plan-report.md first for the architect's exact interfaces,
source references, schemas, limits and validation calls. Implement that plan
without expanding to real process/runtime/native work. The original full
2.2.0 milestone scope remains open; this slice supplies the missing pure seam.

Own only .uwz-work/evidence/h2-streaming/combined-native/native_post.py,
test_native_post.py and the necessary additive inventory entry in
test_native_imports.py. Put all new controls/raw/source snapshots under
combined-native/evidence/native-post/. You are not alone; preserve all other
work, especially C4 implementation/tests and all existing raw evidence. No
subagents, Git writes or publication. Root reviews, commits and pushes.

Binding requirements (exact details in architect report):
- Pure parse_capture(CaptureFacts, nonce, expected_capacity) -> PostFacts;
  validate_post(selection, before, after) -> None. Named explicit contracts,
  caller-owned inputs, detached outputs, no input mutation or I/O.
- Complete capture <=65536 bytes, overflow is False, error is None, finished
  is True. Strict UTF-8 and LF-complete lines; nonce [A-Za-z0-9_]{1,32}.
- Exact anchored info-prefixed ordered75 fixture markers: capacity, ready,
  binding, 67 body records in canonical order, four named outputs, deinit.
  Reject embedded/unknown/wrong nonce/extra/duplicate/missing/reordered markers.
  Unrelated bounded diagnostics are not evidence.
- Independently supplied authenticated exact capacity payload, all six fields
  including config. Never infer expected values from observed output.
  expected_capacity excludes the literal info: H2_CAPACITY prefix and final LF;
  it begins config= and includes request_stride, h2_bytes, h2_stride, slab and
  router in emitted order/grammar. Preserve exact payload bytes; no normalization.
- Body JSON <=768, output/deinit JSON <=1024, nonce overhead <=64;
  capacity/ready/binding/deinit allowance <=2048, fixture total <=62144.
- Reject duplicate JSON keys, non-object roots, trailing documents, floats,
  nonfinite constants, out-of-range integers and bool-as-integer confusion.
- Reuse canonical model.validate_pre_post, validate_metrics both phases, and
  validate_output_pre_post including actual before/after binding. All67 records
  and four outputs exact. Active shutdown changes only canonical shutdown
  fields/metrics; producer counters scheduling-dependent but canonical algebra
  holds; binding actual slot0/1 and relative generation+1, never fixed18.
- Parsing proves semantic facts from supplied capture, not real PID/listener,
  deinit occurrence/exit/reap/cleanup authenticity. These are provider gates.

No canonical source/model/fixture/candidate/dependency/product/pin/old S46
changes. No old runtime imports, compiler/server/socket/SSLContext/real clock/
process-under-test/network/install operations. Do not reconstruct a second
parser/model or normalize legacy schemas. Preserve original failing source
versions, raw commands/stdout/stderr/status, and distinguish API-absence RED
from real behavioral RED. Tests should exercise actual serialized fixture
schemas and pure canonical validators, not mirror implementation branches.
Cover all architect-specified positive and mutation cases, normal/-O focused
runs and additive native import-inert checks. Do not repeat old C4/S46/all40
suites without a concrete changed gap.

Follow AGENTS.md and CODING_CONVENTION.md, relevant verification specialist
instructions and narrow TDD/API/quality skills. No classes/assertions/custom
exceptions/module mutable globals; functions <=3 control-flow nesting. No gate
weakening or hidden error handling. Freeze all prior C4 packet paths/bytes
before implementation and compare after (directory history only from an actual
captured boundary); preserve all immutable committed archives. The sole allowed
prior-packet change is the additive test_native_imports.py inventory entry;
retain its exact pushed baseline and review that diff explicitly. All other
prior paths/bytes remain unchanged.

Every dependent Python shell: set -e; export PYTHONDONTWRITEBYTECODE=1; pinned
/home/codespace/.python/current/bin/python3 -B -S
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py
--restore NEW_ABSOLUTE_RECEIPT immediately before operation in same shell.
Pinned interpreter SHA256:
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
Exact PYTHONPATH:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native

Graphify before NEW codebase questions/searches; already supplied paths and
archive spans are located. Run AST-only update after changes; ignored helper
topology is not inferred from it. No skill edits. Known generic definition-of-
done reference drift is documented and does not waive explicit project gates.

Write full report <=1200 words preferred to task-5e3c5-report.md in this plan
directory, exact source hashes/commands/results/raw evidence references/limits
and DONE|DONE_WITH_CONCERNS|NEEDS_CONTEXT|BLOCKED status. Return concise status,
path, one-line verification and concerns. Do not claim unrun/native gates.
