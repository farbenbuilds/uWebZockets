# C5 native fixture capture and canonical post facts

Status: **DONE_WITH_CONCERNS**. Focused source implementation is complete; native acceptance and the larger milestone remain open.

## Scope and contracts

Changed only `combined-native/native_post.py`, `test_native_post.py`, and the additive `NAMES` inventory in `test_native_imports.py`. New controls and evidence are under `combined-native/evidence/native-post/` (relative to `.uwz-work/evidence/h2-streaming/`). No Git writes, publication, compiler, server, socket operation, TLS context, real clock, process under test, network, or installation occurred.

`parse_capture(CaptureFacts, nonce, expected_capacity) -> PostFacts` checks the exact collector dictionary, immutable bytes, 65536-byte ceiling, strict UTF-8, LF completion, collector flags, anchored ordered 75 markers, all 67 canonical record identities and four output identities, nonce grammar, byte allowances, duplicate keys/tags, exact primitive schemas, and unsigned integer/boolean separation. Standard JSON decoding rejects floats/nonfinite numbers, trailing documents and non-object roots. Returned dictionaries are detached.

Root clarified that `expected_capacity` is the complete payload starting `config=... request_stride=... h2_bytes=... h2_stride=... slab=... router=...`, excluding `info: H2_CAPACITY ` and LF. All six fields must have their emitted order/grammar and match the independently authenticated expectation exactly; no observed value becomes its own expectation. Test capacities are explicit synthetic inputs using the emitted serialization schema; their size values are not native measurements.

`validate_post(selection, before, after)` reuses canonical `validate_pre_post`, `validate_metrics` for both phases, and `validate_output_pre_post` with actual before/after binding. It preserves scheduling-dependent producer counters, relative generation+1, slots 0/1, unselected defaults and the exact active-shutdown transition. There is no second model, legacy normalization or runtime integration.

## Tests-first evidence

All run directories retain `argv.nul`, `environment.nul`, fresh `restore.json`, restoration stdout/stderr, pre-execution source snapshots and SHA256 manifests, target stdout/stderr and numeric status. `control/run.sh` records the exact pinned interpreter, `-B -S`, exact six-entry `PYTHONPATH`, and restoration immediately before dependent execution in the same shell. It additionally fixes `PYTHONHASHSEED=0` for final runs.

Distinct REDs:

- `red-api`: exit 1, `ModuleNotFoundError: No module named 'native_post'` (API absence only).
- `red-capture`: exit 1, `RuntimeError: invalid input accepted: overflowTrue` (working parser accepted collector overflow).
- `red-allowance`: exit 1, `RuntimeError: invalid input accepted: combined overhead allowance` (individually bounded JSON exceeded the shared 2048 allowance).

Both behavioral defects were fixed after their retained REDs. The first `red-capacity` and `red-nesting` attempts passed; neither is claimed as a RED or fixed defect. The former oversized vector already hit a component bound; a revised independently bounded vector exposed the actual shared-allowance defect. The nested-input probe did not reproduce a decoder exception.

Reproduction, from the repository root:

```sh
c=.uwz-work/evidence/h2-streaming/combined-native/evidence/native-post/control/run.sh
n=.uwz-work/evidence/h2-streaming/combined-native
p=/home/codespace/.python/current/bin/python3
"$c" final-normal "$p" -B -S "$n/test_native_post.py" --check
"$c" final-optimized "$p" -B -S -O "$n/test_native_post.py" --check
"$c" final-imports-normal "$p" -B -S "$n/test_native_imports.py" --check
"$c" final-imports-optimized "$p" -B -S -O "$n/test_native_imports.py" --check
"$c" final-audit-proof "$p" -B -S "$n/evidence/native-post/control/audit.py" --check
```

Run labels are immutable; use fresh labels when reproducing. All five final runs exited 0. Both normal and optimized focused stdout ends:

```text
Rejected semantic-field mutations: 1485
fields: PASS
Maximal legal serialized fixture bytes: 61150; conservative bound: 62144
bounds: PASS
Native post pure checks passed: 8
```

The other passing groups are valid, capture, markers, json, capacity and comparisons. Cases cover every marker removal/duplication/embedded position, every adjacent reordering and nonce-bearing wrong nonce; per-body/output/deinit limits; 2048/2049 shared allowance; 65536/65537 complete capture; invalid UTF-8/truncation/JSON/flags/types; all semantic post fields; both metrics phases; actual binding; producer algebra; and rejected-input preservation of `before`.

Import checks report `import_empty_foreign_inert=true`, `shared_canonical_identity=true`, source nesting `native_post=2`, `test_native_post=3`, and the five-entry native inventory. No old C4, S46 or all40 suite was rerun.

## Identity and preservation

Final SHA256:

- `native_post.py`: `220c007b7c15efc6bde74ade4edbc7283b95ec725ca8125ed67ac8f11ffbe99b`
- `test_native_post.py`: `8b7cefb268381082ffa29644a3141b35192d952798768e5a88253eab5683f9a5`
- `test_native_imports.py`: `db84e11d46985e7fb93b17f09a5d416f1da510e4541847041b34c426ad6b8158`
- Canonical `model.py`: `ebb6164c01617045b6120a00977aeae88609053318f89b1891d9ede5c89b8175`

`final-audit/canonical-source.sha256` and `fixture-source.sha256` retain further source identities. The interpreter is the brief's `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`.

The actual initial boundary contained 465 prior native files. Final audit proves 464 immutable files unchanged, the exact permitted inventory addition, no other prior path/directory drift, and all 649 committed evidence files unchanged. Baseline inventory bytes and explicit diff are retained. The C4 archive remains `83d71ed27c0680121216d1e0df00020a2556505dc1a4817d8d1b686317356c7a`.

## Qualifications

The first Graphify query retained its runner source but lacked a pre-execution snapshot of Graphify's existing package closure. Root ruled it exploratory navigation only; the hash-only tool inventory is retained, no repair query was rerun, and no helper acceptance depends on it. `graph-update` ran the pinned interpreter with `graphify_runner.py update .`, exited 0, used AST-only extraction with sequential fallback after a sandbox parallelism warning, and reported no topology changes. It cannot establish ignored helper topology.

No Zig/full native/compliance/sanitizer gates ran: this release expressly prohibited compiler/runtime execution. Parsing supplies semantic facts only; PID/listener identity, authentic deinitialization, exit/reap and cleanup remain provider gates. Independent review and root integration remain outstanding.

## Fix round 1/5 — unrelated diagnostics

Status: **DONE_WITH_CONCERNS**, carrying forward the original source-only and exploratory-Graphify qualifications. Addressed the review's P2 finding with one classifier condition/comment in `native_post.py` and a regression group in `test_native_post.py`; the inventory file is unchanged.

The lexical contract reserves every literal `info: H2_` prefix, including embedded prefixes and malformed lowercase suffixes. Outside that prefix, `H2_` followed by an ASCII uppercase letter, digit or underscore, or bare `H2_` followed by whitespace/end, denotes a marker candidate. Candidates must still be complete anchored fixture lines and satisfy all existing ordering/schema checks. Lowercase diagnostic identifiers such as `H2_stream` do not supply fixture evidence. Unknown uppercase markers and malformed/embedded fixture prefixes remain rejected.

`fix1-red-diagnostics` retained the original parser and new regression before execution: exit 1, `ValueError: embedded fixture marker` for the valid capture with `warning: retrying H2_stream`. The first edit caused a regex syntax error; `fix1-green-diagnostics` retained that intermediate source and raw failure (`re.PatternError: missing ), unterminated subpattern`). The corrected implementation passed `fix1-green-diagnostics-corrected`.

Using the same `c`, `n`, `p` definitions and pinned restoration wrapper above, final commands were:

```sh
"$c" fix1-final-normal "$p" -B -S "$n/test_native_post.py" --check
"$c" fix1-final-optimized "$p" -B -S -O "$n/test_native_post.py" --check
"$c" fix1-imports-normal "$p" -B -S "$n/test_native_imports.py" --check
"$c" fix1-imports-optimized "$p" -B -S -O "$n/test_native_imports.py" --check
"$c" fix1-audit-proof "$p" -B -S "$n/evidence/native-post/control/audit.py" --check
"$c" fix1-graph-update "$p" -B -S "$n/evidence/native-post/control/graphify_runner.py" update .
```

All six exited 0. Both focused runs include raw `diagnostics: PASS` and `Native post pure checks passed: 9`, retaining all original groups, 1485 semantic mutations and the 61150-byte component-maxima capture. The regression accepts five diagnostic forms at all 76 insertion positions (380 captures), and rejects nine reserved/malformed/embedded forms, including `warning: example info: H2_bad payload`. Both inert checks retain true import/empty/foreign-argument inertness and shared canonical identity. AST update reported no relevant changes; no ignored-helper topology is inferred.

New final SHA256 values:

- `native_post.py`: `0ba8cd7bee70cf666f303756de2389e4d79608bbad46a6bb6e6ad85479db076c`
- `test_native_post.py`: `3186c2360b676ee9a62a06787cafc40bae6be9ca6662001d7b7027c0b77303d9`

`test_native_imports.py` remains `db84e11d46985e7fb93b17f09a5d416f1da510e4541847041b34c426ad6b8158`. Exact before sources, final hashes/diffs, and all new immutable run receipts are under `evidence/native-post/fix1-before`, `fix1-final-audit`, and the named run directories. The audit again confirms 464 immutable prior files, the exact prior inventory addition, unchanged prior paths/directories and all 649 committed evidence files unchanged. No native/compiler or old C4/S46/all40 suites ran. Ready for scoped re-review; no new unresolved implementation concern.
