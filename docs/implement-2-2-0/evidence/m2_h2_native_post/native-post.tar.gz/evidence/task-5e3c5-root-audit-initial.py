"""Check preserved authorities and the scoped native-post additions."""
import ast
import hashlib
import json
import runpy
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def authority(plan):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_native_closing/native-closing.tar.gz')
    if sha(archive.read_bytes()) != '83d71ed27c0680121216d1e0df00020a2556505dc1a4817d8d1b686317356c7a':
        raise ValueError('Pushed C4 authority differs')
    helper = plan / 'task-5e3c4-root-audit.py'
    with tarfile.open(archive, 'r:gz') as stream:
        inventory = json.loads(stream.extractfile('INVENTORY.json').read())
        if stream.extractfile('evidence/' + helper.name).read() != helper.read_bytes():
            raise ValueError('Preservation-helper authority differs')
    return inventory, runpy.run_path(str(helper))


def native_tree(source, inventory):
    before = {name.removeprefix('native/'): row for name, row in inventory.items() if name.startswith('native/')}
    if len(before) != 465:
        raise ValueError('C4 packet count differs')
    mutable = 'test_native_imports.py'
    for name, row in before.items():
        data = (source / name).read_bytes()
        if name != mutable and (len(data) != row['size'] or sha(data) != row['sha256']):
            raise ValueError('Protected C4 packet differs: ' + name)
    paths = list(source.rglob('*'))
    if any(path.is_symlink() for path in paths):
        raise ValueError('Native packet symlink')
    actual = {path.relative_to(source).as_posix() for path in paths if path.is_file()}
    added = actual - before.keys()
    modules = {'native_post.py', 'test_native_post.py'}
    if not modules <= added or any(name not in modules and not name.startswith('evidence/native-post/') for name in added):
        raise ValueError('Native addition scope differs')
    return dict(protected_files=464, authorized_inventory_edit=mutable,
                baseline_inventory=before[mutable], added_files=len(added),
                directory_history='File authority only; actual directory-boundary proof remains separately scoped')


def touched_sources(source, check):
    result = {}
    for name in ('test_native_post.py', 'native_post.py', 'test_native_imports.py'):
        data = (source / name).read_bytes()
        tree = ast.parse(data)
        forbidden = (ast.ClassDef, ast.Assert, ast.Global, ast.Nonlocal)
        if check['nesting'](tree) > 3 or any(isinstance(node, forbidden) for node in ast.walk(tree)):
            raise ValueError('Touched source structure differs: ' + name)
        result[name] = dict(size=len(data), sha256=sha(data), maximum_nesting=check['nesting'](tree))
    return result


def publication(plan):
    rows = json.loads((plan / 'task-5e3c4-root-commit-audit.json').read_text())['reviewed_files']
    if len(rows) != 6:
        raise ValueError('C4 publication scope differs')
    for name, row in rows.items():
        data = Path(name).read_bytes()
        if len(data) != row['size'] or sha(data) != row['sha256']:
            raise ValueError('Protected C4 publication differs: ' + name)
    return len(rows)


def main(arguments):
    if arguments != ['--audit']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/combined-native')
    inventory, check = authority(plan)
    result = dict(native_tree=native_tree(source, inventory),
                  pure_source=check['preserve_s46'](), c2=check['preserve_c2'](),
                  closure=check['preserve_closure'](), preserved_publication_files=publication(plan),
                  touched_sources=touched_sources(source, check),
                  native_executed=False, milestone_complete=False)
    (plan / 'task-5e3c5-root-final-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
