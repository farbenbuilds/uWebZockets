**Spec: Issues found. Task quality: Needs fixes.**

- **P2 — Unrelated diagnostics can invalidate a complete capture.** [native_post.py:104](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native/native_post.py:104) treats every line containing `H2_` as a fixture marker. A bounded diagnostic such as `warning: retrying H2_stream` therefore raises an error even when all 75 fixture markers are present and valid. Distinguish fixture marker tokens from ordinary diagnostic text while continuing to reject embedded and unknown markers, and add a regression test.

The review package and three source hashes match the supplied identities. Retained normal and optimized focused runs and import checks report success; the two behavioral REDs report failure as described. The exploratory capacity and nesting attempts passed and are correctly not claimed as REDs.

Verification gaps: I did not rerun suites or execute a focused reproduction. Native execution, provider authenticity, and the project’s compiler and compliance gates remain unverified in this slice. The first Graphify query lacked a pre-run tool-package snapshot and is usable only as disclosed exploratory navigation.
