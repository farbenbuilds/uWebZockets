# C5 public environment evidence preparation

Status: **DONE_WITH_CONCERNS**. Prepared for independent privacy review; publication remains halted. No archive, Git write, publication or native execution occurred.

Changed only `combined-native/evidence/native-post/control/run.sh` and added `public_environment.py` / `test_public_environment.py` beside it. New proof, before sources and public projection inputs use `evidence/native-post/privacy-*`. The five approved native Python source hashes remain unchanged.

The threat boundary is private ambient process metadata entering public evidence. `project_environment(source: bytes) -> bytes` is pure, input-owned and deterministic. It validates NUL-delimited nonempty key/value records, partitions only the first equals sign, and emits only source-controlled Python controls in this order: `PYTHONDONTWRITEBYTECODE`, `PYTHONHASHSEED` when recorded, `PYTHONPATH`. All unknown names and values are omitted. Always-required controls must occur exactly once with their approved values; seed, when present, must occur once with its approved value. Invalid input produces the single generic error `invalid environment evidence`, without including source bytes.

Root's updated brief identified nine historical seed omissions. The projection preserves those omissions rather than fabricating a setting. New wrapper captures still contain all three controls: the sole runner edit replaces `env -0` with a shell `printf` of the three already-exported settings before fresh pinned restoration. Empty/foreign CLI and import are inert.

TDD evidence is under `privacy-red`: the naive whole-environment projection failed with exit 1 and `RuntimeError: whole-environment inclusion is unsafe`. This used an empty inherited environment plus synthetic sentinels; no real credentials entered the new proof. That source version and the old runner were preserved before their runs. `privacy-green` then passed. Final normal and optimized metadata tests cover unknown names/values, equals signs inside values, missing/duplicate/wrong controls, malformed grammar, historical seed absence, idempotence, input preservation and inert guards.

Exact final commands from repository root, with fresh immutable labels:

```sh
c=.uwz-work/evidence/h2-streaming/combined-native/evidence/native-post/control/run.sh
t=.uwz-work/evidence/h2-streaming/combined-native/evidence/native-post/control/test_public_environment.py
p=/home/codespace/.python/current/bin/python3
/usr/bin/env -i PATH=/usr/bin:/bin /bin/bash "$c" privacy-final-normal "$p" -B -S "$t" --check
/usr/bin/env -i PATH=/usr/bin:/bin /bin/bash "$c" privacy-final-optimized "$p" -B -S -O "$t" --check
/usr/bin/env -i PATH=/usr/bin:/bin /bin/bash "$c" privacy-check-wrapper "$p" -B -S "$t" --check-wrapper
/usr/bin/env -i PATH=/usr/bin:/bin /bin/bash "$c" privacy-prepare-public-inputs "$p" -B -S "$t" --prepare-public-inputs
```

All four exited 0. Raw normal/optimized stdout:

```text
Public environment metadata checks passed: projection, grammar, required controls, idempotence, inert guards
```

`privacy-runner-green` executed `/bin/true` under `env -i`, with explicit safe PATH and synthetic ambient credential/unknown fields. `privacy-check-wrapper` reported:

```text
Harmless runner proof passed: exactly three controls; synthetic ambient fields omitted
```

All dependent runs retain exact target argv, safe environment receipts, fresh pinned restoration receipts, pre-execution control/source snapshots, raw stdout/stderr and status. No original private environment was copied into a new source snapshot or logged. The synthetic RED's full environment is synthetic only; its unknown fields are intentional leakage-test evidence.

Public inputs: `.uwz-work/evidence/h2-streaming/combined-native/evidence/native-post/privacy-publication-inputs/manifest.json`. It maps each original `native/evidence/native-post/<run>/environment.nul` member to a separate safe replacement and discloses the projection, original private/unpublished status, and absent controls. All 25 actual historical projections were checked silently: 16 have three controls, nine have two controls with seed explicitly absent. Original environments were only read and remain privately retained; no original environment or credential hashes were created or printed. Public environment bytes are deliberately not described as equal to their full originals. Other evidence bytes are unchanged.

Final source SHA256:

- `run.sh`: `f5ce27c9fdd86427aa31771bd7500a4763aa3705c399186d732b631fa65d8655`
- `public_environment.py`: `c0a0e4941eec367cf7a096268ff2bee06716dcdc8b149b05fc22d19e211c2a65`
- `test_public_environment.py`: `c25089e3a98269922074c934e1d2bcfe9360dabe7d652cedf8e996cfee54fc9e`

The before runner, exact one-line diff, historical path-only inventory and frozen native source verification are retained under `privacy-before`. `privacy-graph-update` completed AST-only maintenance with exit 0 and no relevant changes; no navigation query or ignored-helper topology claim was added.

No parser, C4, S46, all40, compiler, native or compliance suite was repeated. Existing project gates remain outstanding. Root owns reviewed archive substitution and publication; the retained private originals must not be archived directly. The original exploratory Graphify qualification and provider/native acceptance limits still apply.
