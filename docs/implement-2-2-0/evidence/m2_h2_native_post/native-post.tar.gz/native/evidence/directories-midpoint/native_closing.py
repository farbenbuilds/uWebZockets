"""Bounded local transport receipt; no complete-wire or authenticated-close proof.

The provider installs the original callbacks before wrapping once, binds once,
then freezes at signal entry. The handler owns canonical begin and finish.
A receipt is usable only with local_receipt(state); later forbidden I/O revokes
that live verdict. Application postconditions and real cleanup remain external.
"""
import ssl
from functools import partial
from typing import Callable
import catalogue
import shutdown_cases
import test_wire_oracle as oracle
import wire

Prepare = Callable[[int], None]
Recv = Callable[[int], bytes]
Clock = Callable[[], int]
Send = Callable[[bytes], None]
Receive = Callable[[], tuple[bytes, int]]
ReceiveBinding = tuple[Prepare, Recv, Clock]
Connection = dict
Observer = dict
Context = dict
ReceiveState = dict
# ready start/end, case start/end, whole start/end, in caller integer ticks.
Deadlines = tuple[int, int, int, int, int, int]
# original connection reference, identity, oracle operation, attempt, phase,
# bounded diagnostic returned bytes, actual primitive exception (live only).
ReceiveProvenance = tuple[Connection, oracle.ConnectionIdentity, int, int, str, bytes | None, BaseException | None]
# wrapped attempts, primitive attempts/returns, boundary returns, nonempty, bytes.
ReceiveCounts = tuple[int, int, int, int, int, int]
ClosingCounts = tuple[ReceiveCounts, ReceiveCounts, ReceiveCounts, int]
ClosingTiming = tuple[int, int, int, int]
ClosingTerminal = tuple[int, int, str]
ClosingTails = tuple[int, int, bool, int]
# canonical and passive connection/stream debt before and after.
ClosingDebt = tuple[tuple[int, int, int, int], tuple[int, int, int, int]]
TerminationFacts = dict
ClosingReceipt = tuple[oracle.CheckpointReceipt, ClosingTiming, ClosingCounts, ClosingTerminal,
                       oracle.FailureReceipt | None, ClosingTails, ClosingDebt, str, bool, str, str]
COUNT_KEYS = ('wrapped_attempts', 'attempts', 'returns', 'boundary_returns', 'nonempty', 'bytes')
U64 = (1 << 64) - 1


def require(condition: bool, code: str) -> None:
    if not condition:
        raise ValueError(code)


def uint(value: int) -> bool:
    return type(value) is int and 0 <= value <= U64


def invalidate(state: ReceiveState, code: str) -> None:
    if state['failure'] is None:
        state['failure'] = code
    state['phase'] = 'failed'


def checked(state: ReceiveState, condition: bool, code: str) -> None:
    if not condition:
        invalidate(state, code)
        raise ValueError(code)


def increment(state: ReceiveState, key: str, amount: int = 1) -> None:
    value = state['counts'][key]
    checked(state, uint(value) and uint(amount) and value <= U64 - amount, 'receive_count_overflow')
    state['counts'][key] += amount


def new_receive_state(identity: oracle.ConnectionIdentity, now: int, units: int, deadlines: Deadlines) -> ReceiveState:
    require(type(identity) is tuple and len(identity) == 3 and uint(identity[0]) and
            identity[1:] == ('shutdown_active', 1), 'receive_identity')
    require(uint(units) and units > 0 and type(deadlines) is tuple and len(deadlines) == 6 and
            all(uint(value) for value in deadlines) and uint(now), 'receive_deadlines')
    ready_start, ready, case_start, case, whole_start, whole = deadlines
    require(whole_start <= ready_start <= case_start <= now < min(ready, case, whole), 'receive_deadlines')
    require(ready <= min(catalogue.add_u64(ready_start, catalogue.mul_u64(15, units)), whole) and
            case <= min(catalogue.add_u64(case_start, catalogue.mul_u64(30, units)), whole) and
            whole <= catalogue.add_u64(whole_start, catalogue.mul_u64(900, units)), 'receive_deadlines')
    return dict(identity=identity, now=now, units=units, deadlines=deadlines, deadline=min(case, whole),
                phase='ordinary', observer=None, connection=None, wrapped=None, binding=None, checkpoint=None,
                authorization=None, provenance=None, counts=dict.fromkeys(COUNT_KEYS, 0), baseline=None,
                failure=None, busy=False, pending_error=False, draining=False, receipt=None, context=None)


def bind_observer(state: ReceiveState, connection: Connection, wrapped: Connection, observer: Observer) -> None:
    checked(state, state['observer'] is None and state['phase'] == 'ordinary', 'observer_already_bound')
    checked(state, observer['operation'] == 0 and not observer['busy'] and not observer['sealed'] and
            observer['failure'] is None and observer['descriptor'][0] == state['identity'], 'observer_binding')
    original, receive = connection['receive'], wrapped['receive']
    checked(state, isinstance(original, partial) and original.func is receive_once and len(original.args) == 2 and
            original.args[0] is state and not original.keywords, 'original_receive_binding')
    binding = original.args[1]
    checked(state, type(binding) is tuple and len(binding) == 3 and all(callable(item) for item in binding), 'receive_callbacks')
    checked(state, isinstance(receive, partial) and receive.func is oracle.invoke and
            receive.args == (observer, 'receive', original) and not receive.keywords, 'wrapped_receive_binding')
    send, wrapped_send = connection['send'], wrapped['send']
    checked(state, isinstance(send, partial) and send.func is send_once and len(send.args) == 2 and
            send.args[0] is state and callable(send.args[1]) and not send.keywords, 'original_send_binding')
    checked(state, isinstance(wrapped_send, partial) and wrapped_send.func is oracle.invoke and
            wrapped_send.args == (observer, 'send', send) and not wrapped_send.keywords, 'wrapped_send_binding')
    checked(state, set(connection) == set(wrapped) == {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'} and
            all(connection[key] is wrapped[key] for key in ('protocol', 'now', 'owned', 'tls', 'alpn')), 'connection_binding')
    state.update(observer=observer, connection=connection, wrapped=wrapped, binding=binding,
                 original_receive=original, wrapped_receive=receive, wrapped_send=wrapped['send'])


def provider_io(state: ReceiveState, direction: str) -> None:
    checked(state, state['phase'] in ('ordinary', 'closing') and not state['pending_error'] and
            state['failure'] is None, 'provider_io_closed')
    checked(state, state['observer'] is not None and not state['busy'], 'provider_io_unbound_or_reentrant')
    checked(state, state['phase'] != 'closing' or direction == 'receive' and state['draining'], 'closing_io_owner')
    observer = state['observer']
    checked(state, observer['busy'] and observer['failure'] is None and not observer['sealed'] and
            observer['descriptor'][0] == state['identity'], 'provider_observer_state')
    checked(state, state['connection']['receive'] is state['original_receive'] and
            state['wrapped']['receive'] is state['wrapped_receive'] and state['wrapped']['send'] is state['wrapped_send'],
            'provider_callback_changed')


def sample(state: ReceiveState, clock: Clock) -> int:
    tick = clock()
    checked(state, uint(tick) and state['now'] <= tick < state['deadline'], 'receive_time')
    state['now'] = tick
    return tick


def send_once(state: ReceiveState, send: Send, data: bytes) -> None:
    provider_io(state, 'send')
    state['busy'] = True
    success = False
    try:
        sample(state, state['binding'][2])
        result = send(data)
        sample(state, state['binding'][2])
        success = True
        return result
    finally:
        state['busy'] = False
        if not success:
            invalidate(state, 'send_failed')


def receive_once(state: ReceiveState, binding: ReceiveBinding) -> tuple[bytes, int]:
    provider_io(state, 'receive')
    checked(state, binding is state['binding'], 'receive_binding_changed')
    state['busy'] = True
    state['provenance'] = None
    increment(state, 'wrapped_attempts')
    success = False
    try:
        result = receive_primitive(state, binding)
        success = True
        return result
    finally:
        state['busy'] = False
        state['pending_error'] = not success
        if not success and state['phase'] == 'ordinary':
            invalidate(state, 'ordinary_receive_failed')


def receive_primitive(state: ReceiveState, binding: ReceiveBinding) -> tuple[bytes, int]:
    prepare, recv, clock = binding
    sample(state, clock)
    prepare(state['deadline'])
    checked(state, state['failure'] is None, 'prepare_callback_failed')
    sample(state, clock)
    observer = state['observer']
    prefix = state['connection'], state['identity'], observer['operation'], state['counts']['attempts'] + 1
    state['provenance'] = prefix + ('prepared', None, None)
    increment(state, 'attempts')
    state['provenance'] = prefix + ('recv_entered', None, None)
    try:
        data = recv(8192)
    except BaseException as error:
        state['provenance'] = prefix + ('recv_raised', None, error)
        raise
    state['provenance'] = prefix + ('recv_returned', data[:8192] if type(data) is bytes else None, None)
    increment(state, 'returns')
    checked(state, type(data) is bytes, 'primitive_return_shape')
    increment(state, 'bytes', len(data))
    if data:
        increment(state, 'nonempty')
    checked(state, len(data) <= 8192, 'primitive_read_bound')
    tick = sample(state, clock)
    checked(state, bool(data) or state['phase'] == 'closing', 'ordinary_premature_eof')
    checked(state, state['failure'] is None, 'receive_callback_failed')
    increment(state, 'boundary_returns')
    return data, tick


def counts(state: ReceiveState) -> ReceiveCounts:
    result = tuple(state['counts'][key] for key in COUNT_KEYS)
    checked(state, all(uint(value) for value in result), 'receive_count_overflow')
    return result


def debt(context: Context, observer: Observer) -> tuple[int, int, int, int]:
    return (context['request']['connection_debt'], context['request']['stream_debt_total'],
            observer['request_connection_debt'], observer['request_stream_debt_total'])


def tails(context: Context, observer: Observer) -> ClosingTails:
    raw = context['raw']
    return len(observer['receive']['buffer']), len(raw['header']), raw['frame'] is not None, raw['remaining']


def stage_boundary(context: Context) -> tuple[int, ...]:
    stage = context['stage']
    return (stage['case_state']['reads'], stage['case_state']['bytes'], stage['reads'], stage['bytes'],
            stage['final_bytes'], stage['final_budget'], stage['budget'], stage['limits']['receive_calls'])


def context_binding(context: Context, state: ReceiveState) -> None:
    checked(state, state['context'] is None or context is state['context'], 'closing_context')
    checked(state, context['protocol'] is state['connection']['protocol'] and context['send'] is state['wrapped_send'], 'closing_connection')
    wire.require_binding(context['stage'], context['protocol'], context['raw'], context['request'], context['credit'])
    stage = context['stage']
    checked(state, stage['binding']['records'] is context['records'] and stage['case'] == 'shutdown_active' and
            stage['connection_index'] == 1 and stage['held'] == 3 and stage['final_complete'] is True and
            stage['final'] is True and context.get('shutdown_boundary') is True and not stage['failed'] and
            not context['request']['transport_closed'] and not context['raw']['closed'], 'closing_phase')
    checked(state, (stage['case_deadline'], stage['whole_deadline']) == (state['deadlines'][3], state['deadlines'][5]), 'closing_deadlines')


def idle_observer(state: ReceiveState, connection: Connection, observer: Observer) -> None:
    checked(state, connection is state['wrapped'] and observer is state['observer'], 'closing_identity')
    checked(state, not observer['busy'] and not observer['sealed'] and observer['failure'] is None and
            observer['descriptor'][0] == state['identity'] and not state['busy'], 'closing_observer')


def freeze_checkpoint(context: Context, connection: Connection, observer: Observer, state: ReceiveState, deadline: int) -> oracle.CheckpointReceipt:
    checked(state, state['phase'] == 'ordinary' and state['checkpoint'] is None, 'checkpoint_lifecycle')
    success = False
    try:
        idle_observer(state, connection, observer)
        context_binding(context, state)
        checked(state, context['raw']['closing'] is None and not context['stage']['signaled'] and
                tails(context, observer) == (0, 0, False, 0), 'checkpoint_boundary')
        checked(state, uint(context['now']) and context['now'] >= state['now'], 'checkpoint_time')
        state['now'] = context['now']
        start = sample(state, state['binding'][2])
        checked(state, uint(deadline) and start < deadline <= min(catalogue.add_u64(start, catalogue.mul_u64(15, state['units'])),
                state['deadlines'][3], state['deadlines'][5]), 'closing_deadline')
        prefix = oracle.checkpoint(observer)
        checked(state, prefix[0][3][0] == context['stage']['reads'] == state['counts']['boundary_returns'] and
                prefix[0][3][1] == context['stage']['bytes'] == state['counts']['bytes'] and
                debt(context, observer)[:2] == prefix[0][11:13], 'checkpoint_counts_or_debt')
        state.update(checkpoint=prefix, baseline=counts(state), pre_stage=stage_boundary(context),
                     pre_debt=debt(context, observer), start=start, deadline=deadline, context=context, phase='checkpoint')
        success = True
        return prefix
    finally:
        if not success:
            invalidate(state, 'checkpoint_failed')


def activate(context: Context, connection: Connection, observer: Observer, state: ReceiveState, signal: dict, deadline: int) -> None:
    checked(state, state['phase'] == 'checkpoint' and state['authorization'] is None, 'activation_lifecycle')
    success = False
    try:
        idle_observer(state, connection, observer)
        context_binding(context, state)
        shutdown_cases.validate_signal(signal, True)
        checked(state, observer['operation'] == state['checkpoint'][1] and counts(state) == state['baseline'] and
                stage_boundary(context) == state['pre_stage'] and debt(context, observer) == state['pre_debt'], 'activation_prefix_changed')
        checked(state, deadline == state['deadline'] and uint(deadline), 'activation_deadline')
        raw, stage = context['raw'], context['stage']
        expected = dict(stream=3, policy='owned_shutdown', phase='post_signal', bytes=0, frames=0, connection_credit=0, stream_credit=0)
        checked(state, stage['signaled'] is True and raw['closing'] == expected and
                set(raw['streams']) == set(context['records']) == set(stage['active']) == {3} and
                tails(context, observer) == (0, 0, False, 0), 'activation_canonical_begin')
        sample(state, state['binding'][2])
        cap = stage['limits']['receive_calls']
        if stage['final'] and stage['limits']['legacy_receive_cap'] is None and not stage['limits']['final_included']:
            cap = catalogue.add_u64(cap, stage['final_budget'])
        used = stage['case_state']['reads']
        checked(state, uint(used) and used <= cap, 'closing_read_budget')
        state.update(authorization=tuple(sorted(signal.items())), allowance=cap - used, phase='closing')
        success = True
    finally:
        if not success:
            invalidate(state, 'activation_failed')


def is_tls_terminal(state: ReceiveState, error: BaseException, operation: int, attempt: int) -> bool:
    provenance, observer = state['provenance'], state['observer']
    first = observer['failure']
    return (isinstance(error, ssl.SSLEOFError) and state['phase'] == 'closing' and state['failure'] is None and
            state['draining'] and state['pending_error'] and provenance is not None and
            provenance[0] is state['connection'] and provenance[1] == state['identity'] and
            provenance[2:5] == (operation, attempt, 'recv_raised') and provenance[5] is None and
            provenance[6] is error and observer['operation'] == operation and
            state['counts']['attempts'] == attempt and first is not None and
            first[:3] == ('receive_exception', 'receive', operation) and not observer['busy'] and not observer['sealed'])


def closing_receive(state: ReceiveState, receive: Receive) -> tuple[bytes, int, str | None]:
    observer = state['observer']
    operation, attempt = observer['operation'] + 1, state['counts']['attempts'] + 1
    checked(state, uint(operation) and uint(attempt), 'closing_operation_overflow')
    try:
        data, tick = receive()
    except ssl.SSLEOFError as error:
        if not is_tls_terminal(state, error, operation, attempt):
            raise
        return b'', sample(state, state['binding'][2]), 'tls_eof'
    checked(state, observer['failure'] is None and observer['operation'] == operation and
            state['provenance'] is not None and state['provenance'][2:5] == (operation, attempt, 'recv_returned'), 'closing_observation_failed')
    return data, tick, None if data else 'eof'


def accept_closing(context: Context, state: ReceiveState, data: bytes) -> None:
    baseline = state['baseline']
    checked(state, state['counts']['nonempty'] - baseline[4] <= state['allowance'], 'closing_nonempty_budget')
    checked(state, state['counts']['bytes'] - baseline[5] <= 65536, 'closing_byte_budget')
    sample(state, state['binding'][2])
    wire.accept(context['protocol'], data, context['records'], context['raw'], context['trace'],
                credit=context['credit'], request=context['request'], stage=context['stage'])
    sample(state, state['binding'][2])


def freeze_receipt(context: Context, state: ReceiveState, outcome: str) -> tuple[TerminationFacts, ClosingReceipt]:
    observer = state['observer']
    checked(state, tails(context, observer) == (0, 0, False, 0), 'closing_partial_tail')
    checked(state, state['failure'] is None and not context['stage']['failed'], 'closing_failed')
    after = counts(state)
    delta = tuple(value - old for value, old in zip(after, state['baseline']))
    receipt = (state['checkpoint'], (state['start'], state['now'], state['deadline'], state['units']),
               (state['baseline'], after, delta, context['raw']['closing']['frames']),
               (observer['operation'], state['counts']['attempts'], outcome), observer['failure'], tails(context, observer),
               (state['pre_debt'], debt(context, observer)), 'local_transport_only', False, 'not_established', 'unknown')
    state.update(receipt=receipt, phase='terminal')
    return dict(phase='post_signal', outcome=outcome, primary_response=False, frames_valid=True, trailing_bytes=0), receipt


def drain_closing(context: Context, wrapped_receive: Receive, observer: Observer, state: ReceiveState, deadline: int) -> tuple[TerminationFacts, ClosingReceipt]:
    checked(state, state['phase'] == 'closing' and not state['draining'] and state['failure'] is None, 'drain_lifecycle')
    checked(state, context is state['context'] and wrapped_receive is state['wrapped_receive'] and
            observer is state['observer'] and deadline == state['deadline'] and uint(deadline), 'drain_binding')
    state['draining'] = True
    success = False
    try:
        result = drain_loop(context, state, wrapped_receive)
        success = True
        return result
    finally:
        state['draining'] = False
        if not success:
            invalidate(state, 'closing_failed')


def drain_loop(context: Context, state: ReceiveState, receive: Receive) -> tuple[TerminationFacts, ClosingReceipt]:
    while True:
        checked(state, state['counts']['attempts'] - state['baseline'][1] <= state['allowance'], 'closing_attempt_budget')
        sample(state, state['binding'][2])
        data, tick, outcome = closing_receive(state, receive)
        checked(state, uint(tick) and context['now'] <= tick < state['deadline'], 'closing_time')
        context['now'] = tick
        sample(state, state['binding'][2])
        if outcome is not None:
            return freeze_receipt(context, state, outcome)
        accept_closing(context, state, data)


def local_receipt(state: ReceiveState) -> ClosingReceipt:
    require(state['phase'] == 'terminal' and state['failure'] is None and state['receipt'] is not None,
            'local_receipt_invalid')
    return state['receipt']


if __name__ == '__main__':
    pass
