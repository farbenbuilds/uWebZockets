#!/bin/sh
set -e
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native
root=/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native
name=$1
shift
mkdir "$root/evidence/$name"
cp "$root"/*.py "$root/evidence/$name/" 2>/dev/null || test ! -e "$root/native_closing.py"
cp "$root/evidence/run.sh" "$root/evidence/$name/runner.sh"
printf '%s\n' '/home/codespace/.python/current/bin/python3 -B -S' "$@" > "$root/evidence/$name/command.txt"
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore "$root/evidence/$name/restoration.json" > "$root/evidence/$name/restore.stdout" 2> "$root/evidence/$name/restore.stderr"
status=0
/home/codespace/.python/current/bin/python3 -B -S "$@" > "$root/evidence/$name/stdout" 2> "$root/evidence/$name/stderr" || status=$?
printf '%s\n' "$status" > "$root/evidence/$name/status"
cat "$root/evidence/$name/stdout" "$root/evidence/$name/stderr"
exit "$status"
