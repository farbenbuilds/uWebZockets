use strict;
use warnings;
local $/;
my $path = '.uwz-work/evidence/h2-streaming/combined-native/test_native_post.py';
open my $in, '<', $path or die $!;
my $source = <$in>;
close $in;
my $addition = <<'PY';

def changed_scalar(value):
    if type(value) is bool:
        return not value
    if type(value) is int:
        return value + 1
    return 'changed'


def check_fields():
    selection = catalogue.CASES
    before, after = facts(selection, 'before'), facts(selection)
    original = copy.deepcopy(before)
    count = 0
    for area in ('records', 'outputs'):
        for tag, item in after[area].items():
            for key, value in item.items():
                changed = copy.deepcopy(after)
                changed[area][tag][key] = changed_scalar(value)
                rejects(lambda: native.validate_post(selection, before, changed), area + ':' + tag + ':' + key)
                count += 1
    require(before == original, 'field rejection mutated before')
    for phase in ('before', 'after'):
        base = before if phase == 'before' else after
        for key, value in base['metrics'].items():
            changed = copy.deepcopy(base)
            changed['metrics'][key] = changed_scalar(value)
            rejects(lambda: native.validate_post(selection, changed if phase == 'before' else before,
                                                 changed if phase == 'after' else after), 'metric field ' + key)
            count += 1
    changed_fields = {key for key, value in before['records']['shutdown_active'].items()
                      if value != after['records']['shutdown_active'][key]}
    require(changed_fields == {'cancels', 'active', 'paused', 'reason'}, 'exact shutdown delta')
    print('Rejected semantic-field mutations: ' + str(count))


def check_bounds():
    after = facts()
    ordinary = lines(after)
    allowance = sum(len(ordinary[index].encode()) + 1 for index in (0, 1, 2, 74))
    prefix = 'config={"padding":"'
    suffix = '",' + CAPACITY[len('config={'):]
    padded = prefix + 'p' * (2048 - allowance - len(prefix + suffix) + len(CAPACITY)) + suffix
    entries = lines(after, capacity=padded)
    require(sum(len(entries[index].encode()) + 1 for index in (0, 1, 2, 74)) == 2048, 'test allowance boundary')
    require(parse(entries, capacity=padded) == after, '2048 inclusive allowance')
    larger = padded.replace('"padding":"', '"padding":"p')
    rejects(lambda: parse(lines(after, capacity=larger), capacity=larger), '2049 allowance')
    deep_config = 'config={"x":' + '[' * 1000 + '0' + ']' * 1000 + '}' + CAPACITY[CAPACITY.index(' request_stride='):]
    rejects(lambda: parse(lines(after, capacity=deep_config), capacity=deep_config), 'bounded decoder nesting')

PY
$source =~ s/\ndef main\(group\):/$addition\ndef main(group):/ or die 'main not found';
$source =~ s/capacity=check_capacity, comparisons=check_comparisons\)/capacity=check_capacity, comparisons=check_comparisons, fields=check_fields, bounds=check_bounds)/ or die 'checks not found';
open my $out, '>', $path or die $!;
print {$out} $source;
close $out;
