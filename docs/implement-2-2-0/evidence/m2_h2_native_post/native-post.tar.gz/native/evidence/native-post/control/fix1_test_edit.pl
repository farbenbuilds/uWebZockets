use strict;
use warnings;
local $/;
my $path = '.uwz-work/evidence/h2-streaming/combined-native/test_native_post.py';
open my $input, '<', $path or die $!;
my $source = <$input>;
close $input;
my $addition = <<'PY';

def check_diagnostics():
    after = facts()
    original = lines(after)
    for diagnostic in ('warning: retrying H2_stream', 'warning: H2_connection',
                       'info: retrying H2_stream', 'warning: preH2_streamSuffix',
                       'H2_stream H2_diagnostics'):
        for index in range(76):
            entries = original[:index] + [diagnostic] + original[index:]
            require(parse(entries) == after, 'unrelated diagnostic at ' + str(index) + ': ' + diagnostic)
    for marker in ('warning: retrying H2_STREAM', 'warning: H2_123', 'warning: H2_',
                   'warning: H2_READYfoo', 'warning: H2_UNKNOWN', 'info: H2_stream',
                   'warning: embeddedH2_RECORD ' + NONCE, 'warning: H2__bad'):
        rejects(lambda: parse(original + [marker]), 'reserved fixture marker: ' + marker)

PY
$source =~ s/\ndef check_capture\(\):/$addition\ndef check_capture():/ or die 'check_capture not found';
$source =~ s/checks = dict\(valid=check_valid, capture=/checks = dict(valid=check_valid, diagnostics=check_diagnostics, capture=/ or die 'checks not found';
open my $output, '>', $path or die $!;
print {$output} $source;
close $output;
