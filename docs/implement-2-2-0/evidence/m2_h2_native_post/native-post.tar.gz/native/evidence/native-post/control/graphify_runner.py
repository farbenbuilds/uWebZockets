"""Invoke existing AST graph tooling with the task's pinned interpreter."""
import sys


def main():
    sys.path.insert(0, '/workspaces/uWebZockets/.uwz-work/tools/graphify')
    from graphify.__main__ import main as graphify_main
    return graphify_main()


if __name__ == '__main__' and len(sys.argv) >= 2 and sys.argv[1] in ('query', 'update'):
    raise SystemExit(main())
