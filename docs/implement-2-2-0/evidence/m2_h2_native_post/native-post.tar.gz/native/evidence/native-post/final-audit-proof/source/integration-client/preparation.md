# Independent HTTP/2 client preparation

This is prepared verification tooling, not uWebZockets upload/runtime evidence.
No socket, TLS handshake, server, native cancellation or endpoint contact ran.
Live use must wait for independently reviewed native activation and Root's scope.

The helpers use the documented hyper-h2 APIs for encoded HTTP/2 and independent
flow accounting. h2 4.4.1, hpack 4.2.0 and hyperframe 6.1.0 are pinned with official
PyPI wheel hashes, exact source URLs/retrieval times, original wheels/licenses and
the complete 42-file extracted source inventory. No package scripts run and no
production build dependency is added. All installed source lives under /tmp.

Sources:

- https://python-hyper.org/projects/hyper-h2/en/stable/api.html
- https://pypi.org/pypi/h2/4.4.1/json
- https://pypi.org/pypi/hpack/4.2.0/json
- https://pypi.org/pypi/hyperframe/6.1.0/json

send_data obeys both current stream/connection credit and peer frame size, with
an 8192-byte application chunk bound. Response capture is bounded while full bytes
are counted/hashed; received credit includes padding via flow_controlled_length.
Raw DATA and trailers use the library codec, not an invented native completion.

The pure self-check exchanges frames between actual hyper-h2 client/server
objects only. It covers three-byte input fragmentation, informational/final
headers, padded DATA, trailers, independent response hash and bounded generation
of 100000000 logical bytes matching the reviewed 190f6457... payload SHA256.
client-selfcheck-corrected-green.json/log exits 0 with unchanged helper/package
identities. This does not test uWebZockets, socket helpers, uploads or TLS.

Two earlier records (client-selfcheck-red and client-selfcheck-green) exit1 and
remain preserved with their source snapshots. Their expected 32-byte literal
incorrectly contained 33 bytes; they are not behavioral-red proof. The diagnosis
records the 22-byte marker and correct 10-byte prefix. Separately, variable-window
payload generation now slices the marker within each offered span and checks its
length; the corrected self-check verifies every 32-byte split and the full hash.
Socket cleanup/capture/terminal guards were reviewed but not exercised against a
socket. Independent review identified unbounded informational-header retention;
round1 now enforces16 responses and aggregate16384 bytes, including32 per field
plus UTF8 content. Actual behavior-red, corrected boundary/unchanged-state tests
and existing selfcheck pass. The scoped re-review approves preparation only.
See client-fix-1-report.md and review-round1.md for exact identities and limits.

restore_tools.py re-extracts the pinned pure wheels into a new destination and
checks every expected file hash without network or package scripts. Original
verification/download records and exact helper-run argv/environment are retained.
The fixture/process-owning live runner and complete live case matrix are separate
work; this preparation cannot close any M2 transport acceptance requirement.
