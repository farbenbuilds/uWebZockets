use strict;
use warnings;
local $/;
my $path = '.uwz-work/evidence/h2-streaming/combined-native/test_native_post.py';
open my $in, '<', $path or die $!;
my $source = <$in>;
close $in;
my $addition = <<'PY';
    for tail in ('index=2 generation=0', 'index=true generation=0', 'index=-1 generation=0',
                 'index=0 generation=-1', 'index=0 generation=01',
                 'index=0 generation=18446744073709551616', 'generation=0 index=0'):
        changed = list(original)
        changed[2] = 'info: H2_BINDING ' + NONCE + ' tag=producer_reuse_next ' + tail
        if tail == 'index=2 generation=0':
            rejects(lambda: native.validate_post((), facts((), 'before'), parse(changed)), 'binding slot')
            continue
        rejects(lambda: parse(changed), 'binding grammar')

PY
$source =~ s/\ndef replace_json\(entries/$addition\ndef replace_json(entries/ or die 'marker insertion';
my $boundary = <<'PY';
    maximal = lines(after, nonce='n' * 32)
    for index in range(3, 75):
        limit = 768 if index < 70 else 1024
        payload = maximal[index].split(' ', 3)[3]
        maximal[index] += ' ' * (limit - len(payload.encode()))
    overhead = sum(len(maximal[index].encode()) + 1 for index in (0, 1, 2, 74))
    maximal_capacity = CAPACITY + ' ' * (2048 - overhead)
    maximal[0] = 'info: H2_CAPACITY ' + maximal_capacity
    # Capacity's authenticated grammar excludes trailing whitespace.
    capacity_room = 2048 - overhead
    maximal_capacity = prefix + 'p' * (capacity_room - len(prefix + suffix) + len(CAPACITY)) + suffix
    maximal[0] = 'info: H2_CAPACITY ' + maximal_capacity
    require(parse(maximal, 'n' * 32, maximal_capacity) == after, 'all serialized component maxima')
    total = sum(len(line.encode()) + 1 for line in maximal)
    require(total <= 62144, 'conservative fixture bound')
    print('Maximal legal serialized fixture bytes: ' + str(total) + '; conservative bound: 62144')
PY
$source =~ s/    deep_config =/$boundary    deep_config =/ or die 'bounds insertion';
open my $out, '>', $path or die $!;
print {$out} $source;
close $out;
