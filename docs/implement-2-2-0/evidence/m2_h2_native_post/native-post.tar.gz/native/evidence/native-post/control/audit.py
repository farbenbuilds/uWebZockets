"""Verify the captured prior boundary and the single permitted inventory edit."""
import hashlib
import json
from pathlib import Path
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(entries):
    return {line.split('  ', 1)[1]: line.split('  ', 1)[0] for line in entries.splitlines()}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    native = Path('.uwz-work/evidence/h2-streaming/combined-native')
    evidence = native / 'evidence/native-post'
    baseline = evidence / 'baseline'
    prior = inventory((baseline / 'prior-files.sha256').read_text())
    allowed = str(native / 'test_native_imports.py')
    for name, expected in prior.items():
        if name != allowed:
            require(digest(Path(name)) == expected, 'prior byte drift: ' + name)
    current = {str(path) for path in native.rglob('*') if path.is_file() and not path.is_relative_to(evidence)}
    added = {str(native / 'native_post.py'), str(native / 'test_native_post.py')}
    require(current == set(prior) | added, 'prior path set drift')
    directories = sorted(str(path) for path in native.rglob('*') if path.is_dir() and not path.is_relative_to(evidence))
    require([str(native)] + directories == (baseline / 'prior-directories.txt').read_text().splitlines(), 'prior directory drift')
    original = (baseline / 'test_native_imports.py').read_bytes()
    old = b"NAMES = ('native_closing', 'test_native_closing', 'test_native_imports')"
    new = old[:-1] + b", 'native_post', 'test_native_post')"
    require(original.count(old) == 1 and Path(allowed).read_bytes() == original.replace(old, new), 'inventory edit exceeds allowed addition')
    archives = inventory((baseline / 'committed-evidence.sha256').read_text())
    for name, expected in archives.items():
        require(digest(Path(name)) == expected, 'committed evidence drift: ' + name)
    print(json.dumps(dict(prior_paths=len(prior), immutable_prior_files=len(prior) - 1,
                          prior_directories_unchanged=True, inventory_exact_addition=True,
                          committed_evidence_files_unchanged=len(archives), added=sorted(added),
                          final_source_hashes={str(path): digest(path) for path in sorted(native.glob('*.py'))}), sort_keys=True))


if __name__ == '__main__':
    if sys.argv[1:] == ['--check']:
        main()
