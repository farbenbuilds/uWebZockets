"""Pure public projection; caller supplies private NUL-delimited records."""
import sys

EXPECTED_CONTROLS = (
    (b'PYTHONDONTWRITEBYTECODE', b'1'),
    (b'PYTHONHASHSEED', b'0'),
    (b'PYTHONPATH', b'/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native'),
)


def require(condition: bool) -> None:
    if not condition:
        raise ValueError('invalid environment evidence')


def project_environment(source: bytes) -> bytes:
    """Emit controls in declared order, preserving historical seed absence."""
    require(type(source) is bytes and source.endswith(b'\0'))
    names = tuple(key for key, value in EXPECTED_CONTROLS)
    observed = {}
    for record in source[:-1].split(b'\0'):
        key, separator, value = record.partition(b'=')
        require(bool(key) and separator == b'=')
        if key not in names:
            continue
        require(key not in observed)
        observed[key] = value
    require(b'PYTHONDONTWRITEBYTECODE' in observed and b'PYTHONPATH' in observed)
    for key, expected in EXPECTED_CONTROLS:
        require(key not in observed or observed[key] == expected)
    return b'\0'.join(key + b'=' + observed[key] for key, expected in EXPECTED_CONTROLS if key in observed) + b'\0'


if __name__ == '__main__':
    if sys.argv[1:] == ['--contract']:
        print('Only validated recorded Python controls; historical seed absence remains absent.')
