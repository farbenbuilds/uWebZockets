"""Synthetic metadata privacy regressions; no ambient environment access."""
import builtins
import copy
import io
import json
from pathlib import Path
import sys
from contextlib import redirect_stderr, redirect_stdout
from unittest import mock
import public_environment as public

CONTROLS = (
    b'PYTHONDONTWRITEBYTECODE=1',
    b'PYTHONHASHSEED=0',
    b'PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native',
)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def serialized(records):
    return b'\0'.join(records) + b'\0'


def reject(source):
    try:
        public.project_environment(source)
    except ValueError as error:
        require(str(error) == 'invalid environment evidence', 'error discloses input')
        return
    raise RuntimeError('invalid environment evidence accepted')


def check_projection():
    expected = serialized(CONTROLS)
    source = serialized((b'EXAMPLE_AUTH=fake-private-sentinel', CONTROLS[2], b'UNRELATED=a=b=c',
                         CONTROLS[0], b'OTHER_CREDENTIAL=fake-other-sentinel', CONTROLS[1],
                         b'UNRELATED=d=e', b'EMPTY=', b'\xff=opaque'))
    original = copy.deepcopy(source)
    projected = public.project_environment(source)
    require(projected == expected, 'whole-environment inclusion is unsafe')
    require(b'fake-private-sentinel' not in projected and b'fake-other-sentinel' not in projected,
            'synthetic credential included')
    require(b'UNRELATED' not in projected and b'a=b=c' not in projected, 'unknown key or value included')
    require(public.project_environment(projected) == expected, 'projection is not idempotent')
    require(source == original, 'projection mutated supplied bytes')


def check_malformed():
    good = serialized(CONTROLS)
    require(public.project_environment(serialized((CONTROLS[2], CONTROLS[0]))) == serialized((CONTROLS[0], CONTROLS[2])),
            'historical seed absence was fabricated')
    for index in range(3):
        if index != 1:
            reject(serialized(CONTROLS[:index] + CONTROLS[index + 1:]))
        reject(serialized(CONTROLS + (CONTROLS[index],)))
        reject(serialized(CONTROLS[:index] + (CONTROLS[index] + b'=fake-private-sentinel',) + CONTROLS[index + 1:]))
        reject(serialized(CONTROLS[:index] + (CONTROLS[index].split(b'=', 1)[0] + b'=wrong',) + CONTROLS[index + 1:]))
    for source in (b'', good[:-1], good + b'\0', b'\0' + good, b'BROKEN\0' + good,
                   b'=empty-key\0' + good, bytearray(good), good.decode()):
        reject(source)


def reject_effect(*args, **kwargs):
    raise RuntimeError('metadata import attempted an effect')


def check_inert():
    paths = (Path(public.__file__), Path(__file__))
    sources = tuple((compile(path.read_text(), str(path), 'exec'), path) for path in paths)
    out, err = io.StringIO(), io.StringIO()
    with mock.patch.object(builtins, 'open', reject_effect), mock.patch.object(Path, 'open', reject_effect):
        with redirect_stdout(out), redirect_stderr(err):
            execute_inert(sources)
    require(not out.getvalue() and not err.getvalue(), 'metadata script emitted output')


def execute_inert(sources):
    for source, path in sources:
        for mode, argv in (('private_import', []), ('__main__', []), ('__main__', ['--foreign'])):
            with mock.patch.object(sys, 'argv', [str(path)] + argv):
                exec(source, dict(__name__=mode, __file__=str(path)))


def check_wrapper():
    directory = Path(__file__).parent.parent
    captured = (directory / 'privacy-runner-green/environment.nul').read_bytes()
    require(captured == serialized(CONTROLS), 'runner captured ambient records or omitted controls')
    require(b'fake-runner-sentinel' not in captured and b'fake-other-sentinel' not in captured,
            'runner captured synthetic credentials')
    print('Harmless runner proof passed: exactly three controls; synthetic ambient fields omitted')


def prepare_public_inputs():
    directory = Path(__file__).parent.parent
    paths = (directory / 'privacy-before/private-original-paths.txt').read_text().splitlines()
    require(len(paths) == 25 and len(set(paths)) == 25, 'historical path inventory changed')
    destination = directory / 'privacy-publication-inputs'
    destination.mkdir()
    rows = []
    seed_absent = 0
    for relative in paths:
        original = directory / relative
        private = original.read_bytes()
        projected = public.project_environment(private)
        require(original.read_bytes() == private, 'private original changed during projection')
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(projected)
        require(public.project_environment(target.read_bytes()) == projected, 'projection not stable')
        controls = [entry.partition(b'=')[0].decode('ascii') for entry in projected[:-1].split(b'\0')]
        absent = [] if 'PYTHONHASHSEED' in controls else ['PYTHONHASHSEED']
        seed_absent += bool(absent)
        rows.append(dict(original_member='native/evidence/native-post/' + relative,
                         replacement=relative, retained_controls=controls, absent_controls=absent,
                         original_private_unpublished=True))
    require(seed_absent == 9, 'historical absence inventory changed')
    manifest = dict(transformation='Replace full private environment records with validated allowlisted records; preserve historical seed absence.',
                    public_bytes_equal_full_originals=False, original_records_retained_privately=True,
                    original_count=25, projections_with_three_controls=25 - seed_absent,
                    projections_with_two_controls=seed_absent, substitutions=rows)
    (destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print('Historical public projections prepared: 25 total; 16 with three controls; 9 with historical seed absence')


def main():
    check_projection()
    check_malformed()
    check_inert()
    print('Public environment metadata checks passed: projection, grammar, required controls, idempotence, inert guards')


if __name__ == '__main__':
    if sys.argv[1:] == ['--check']:
        main()
    elif sys.argv[1:] == ['''--check-wrapper''']:
        check_wrapper()
    elif sys.argv[1:] == ['''--prepare-public-inputs''']:
        prepare_public_inputs()
