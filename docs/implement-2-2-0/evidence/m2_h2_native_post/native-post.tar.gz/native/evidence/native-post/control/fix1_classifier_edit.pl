use strict;
use warnings;
local $/;
my $path = '.uwz-work/evidence/h2-streaming/combined-native/native_post.py';
open my $input, '<', $path or die $!;
my $source = <$input>;
close $input;
my $line = <<'PY';
        if 'info: H2_' in line or re.search(r'H2_(?:[A-Z0-9_]|(?=\s|$))', line):
PY
$source =~ s/^        if line\.startswith\('info: H2_'\).*\n/$line/m or die 'classifier line not found';
$source =~ s/Reserve uppercase marker names and malformed namespace prefixes\./Reserve literal fixture prefixes and uppercase marker names./ or die 'comment not found';
open my $output, '>', $path or die $!;
print {$output} $source;
close $output;
