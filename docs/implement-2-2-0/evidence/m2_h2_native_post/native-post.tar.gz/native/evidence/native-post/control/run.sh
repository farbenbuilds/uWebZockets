#!/bin/bash
set -e
export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native
base=/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native
run_dir="$base/evidence/native-post/$1"
shift
mkdir "$run_dir"
printf '%s\0' "$@" > "$run_dir/argv.nul"
printf '%s\0' "PYTHONDONTWRITEBYTECODE=$PYTHONDONTWRITEBYTECODE" "PYTHONHASHSEED=$PYTHONHASHSEED" "PYTHONPATH=$PYTHONPATH" > "$run_dir/environment.nul"
cp "$base/evidence/native-post/control/run.sh" "$run_dir/run.sh"
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore "$run_dir/restore.json" > "$run_dir/restore.stdout" 2> "$run_dir/restore.stderr"
mkdir "$run_dir/source"
cp "$base"/*.py "$run_dir/source/"
cp -a /tmp/uwz-task5e1-contract-v3 "$run_dir/source/contract"
cp -a /tmp/uwz-task5e3a-snapshot-v9/source "$run_dir/source/canonical"
cp -a /tmp/uwz-h2-client-tooling/packages "$run_dir/source/codecs"
cp -a /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client "$run_dir/source/integration-client"
mkdir "$run_dir/source/combined-cases"
cp /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/*.py "$run_dir/source/combined-cases/"
cp /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py "$run_dir/source/restore_inputs.py"
cp "$base/evidence/native-post/control/"* "$run_dir/source/"
find "$run_dir/source" -type f -print0 | sort -z | xargs -0 sha256sum > "$run_dir/source.sha256"
set +e
"$@" > "$run_dir/stdout" 2> "$run_dir/stderr"
status=$?
set -e
printf '%s\n' "$status" > "$run_dir/status"
cat "$run_dir/stdout" "$run_dir/stderr"
printf 'Exit status: %s\n' "$status"
exit "$status"
