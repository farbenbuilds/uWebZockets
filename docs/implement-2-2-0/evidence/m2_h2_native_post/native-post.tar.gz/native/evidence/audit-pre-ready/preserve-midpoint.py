"""Freeze and compare the previously accepted file authorities."""
import hashlib
import json
import sys
from pathlib import Path


def row(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def inventory():
    base = Path('/workspaces/uWebZockets')
    source = base / '.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'
    c2 = base / '.uwz-work/evidence/h2-streaming/native-input-preparation'
    prior = json.loads((base / '.uwz-work/evidence/h2-streaming/combined-interface-audit/before.json').read_text())
    audit = json.loads((base / '.superpowers/sdd/h2_streaming_plan/task-5e3c3-root-commit-audit.json').read_text())
    groups = dict(s46=[row(path) for path in sorted(source.glob('*.py'))],
                  combined=[row(path) for path in sorted(source.rglob('*')) if path.is_file()],
                  c2=[row(path) for path in sorted(c2.rglob('*')) if path.is_file()],
                  c3=[row(base / name) for name in audit['reviewed_files']],
                  closure=[row(Path(item['path'])) for item in prior['closure_rows']],
                  codecs=[row(Path(item['path'])) for item in prior['codec_rows']])
    counts = {name: len(rows) for name, rows in groups.items()}
    expected = dict(s46=46, combined=19926, c2=809, c3=6, closure=118, codecs=42)
    if counts != expected or prior['identity_entries'] != 119 or len({item['path'] for item in groups['closure']}) != 113:
        raise ValueError('preservation shape differs: ' + repr(counts))
    return groups


def main(argv):
    if argv in (['--directories-midpoint'], ['--directories-after']):
        directories(argv[0][2:])
        return
    if argv not in (['--before'], ['--after']):
        return
    root = Path(__file__).parent
    current = inventory()
    if argv == ['--after'] and current != json.loads((root / 'preservation-before.json').read_text()):
        raise ValueError('preserved authority changed')
    (root / ('preservation-' + argv[0][2:] + '.json')).write_text(json.dumps(current, indent=2) + '\n')
    print(json.dumps({name: len(rows) for name, rows in current.items()}, sort_keys=True))


def directories(phase):
    base = Path('/workspaces/uWebZockets')
    roots = ('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases',
             '.uwz-work/evidence/h2-streaming/native-input-preparation',
             'docs/implement-2-2-0/evidence/m2_h2_wire_checkpoint')
    rows = {name: sorted(str(path.relative_to(base)) for path in (base / name).rglob('*') if path.is_dir()) for name in roots}
    root = Path(__file__).parent
    if phase == 'directories-after' and rows != json.loads((root / 'directories-midpoint.json').read_text()):
        raise ValueError('directory inventory changed after midpoint freeze')
    (root / (phase + '.json')).write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps(dict(boundary=phase, counts={name: len(items) for name, items in rows.items()})))


if __name__ == '__main__':
    main(sys.argv[1:])
