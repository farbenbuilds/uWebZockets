"""Separate inert native-helper inventory; accepted pure inventory is untouched."""
import ast
import builtins
import importlib
import io
import json
import os
from pathlib import Path
import socket
import ssl
import subprocess
import sys
import time
from contextlib import ExitStack, redirect_stderr, redirect_stdout
from unittest import mock

NAMES = ('native_closing', 'test_native_closing', 'test_native_imports')


def reject(*args, **kwargs):
    raise RuntimeError('native import attempted an effect')


def depth(node, level=0):
    controls = (ast.If, ast.For, ast.While, ast.With, ast.Try, ast.Match)
    current = level + int(isinstance(node, controls))
    return max([current] + [depth(child, current) for child in ast.iter_child_nodes(node)])


def source_check(path):
    tree = ast.parse(path.read_text(), filename=str(path))
    forbidden = (ast.ClassDef, ast.Assert, ast.Global, ast.Nonlocal)
    if depth(tree) > 3 or any(isinstance(node, forbidden) for node in ast.walk(tree)):
        raise ValueError('source structure differs: ' + str(path))
    assignments = [node for node in tree.body if isinstance(node, (ast.Assign, ast.AnnAssign))]
    mutable = (ast.List, ast.Dict, ast.Set, ast.ListComp, ast.DictComp, ast.SetComp)
    if any(isinstance(node.value, mutable) for node in assignments):
        raise ValueError('module mutable state: ' + str(path))
    guards = [node for node in tree.body if isinstance(node, ast.If) and
              ast.unparse(node.test) == "__name__ == '__main__'"]
    if len(guards) != 1:
        raise ValueError('standalone main guard missing: ' + str(path))
    return depth(tree)


def inert_import(name, source, mode):
    previous = sys.modules.pop(name, None)
    try:
        if mode == 'import':
            importlib.import_module(name)
        else:
            exec(source, dict(__name__='__main__', __file__=str(Path(__file__).parent / (name + '.py'))))
    finally:
        sys.modules.pop(name, None)
        if previous is not None:
            sys.modules[name] = previous


def effect_checks(sources):
    replacements = ((builtins, 'open'), (Path, 'open'), (socket, 'socket'), (socket, 'socketpair'),
                    (socket, 'create_connection'), (socket, 'create_server'), (ssl, 'SSLContext'),
                    (subprocess, 'Popen'), (subprocess, 'run'), (subprocess, 'call'), (os, 'system'),
                    (os, 'popen'), (os, 'open'), (os, 'write'), (time, 'time'), (time, 'monotonic'),
                    (time, 'perf_counter'), (time, 'sleep'))
    out, err = io.StringIO(), io.StringIO()
    before = set(sys.modules)
    with ExitStack() as stack:
        for module, attribute in replacements:
            stack.enter_context(mock.patch.object(module, attribute, reject))
        stack.enter_context(redirect_stdout(out))
        stack.enter_context(redirect_stderr(err))
        importlib.import_module('native_closing')
        helper_closure = tuple(sorted(name for name in set(sys.modules) - before if getattr(sys.modules[name], '__file__', None)))
        for name in NAMES:
            importlib.import_module(name)
        execute_modes(sources)
    if out.getvalue() or err.getvalue():
        raise ValueError('native import emitted output')
    return helper_closure


def execute_modes(sources):
    for argv in (['native'], ['native', '--foreign', '--run']):
        with mock.patch.object(sys, 'argv', argv):
            for name, source in sources.items():
                inert_import(name, source, 'import')
                inert_import(name, source, 'main')


def check():
    directory = Path(__file__).parent
    if {path.stem for path in directory.glob('*.py')} != set(NAMES):
        raise ValueError('native source inventory differs')
    depths = {name: source_check(directory / (name + '.py')) for name in NAMES}
    sources = {name: compile((directory / (name + '.py')).read_text(), name + '.py', 'exec') for name in NAMES}
    helper_closure = effect_checks(sources)
    module = sys.modules['native_closing']
    import wire
    import test_wire_oracle
    if module.wire is not wire or module.oracle is not test_wire_oracle:
        raise ValueError('alternate canonical module identity')
    forbidden = ('runtime', 'owned_io', 'strict_close', 'native_provider')
    if any(name == part or name.startswith(part + '.') for name in sys.modules for part in forbidden):
        raise ValueError('archived runtime loaded')
    print(json.dumps(dict(native_inventory=NAMES, nesting=depths, helper_dependency_closure=helper_closure,
                          import_empty_foreign_inert=True, shared_canonical_identity=True), sort_keys=True))


if __name__ == '__main__':
    if sys.argv[1:] == ['--check']:
        check()
