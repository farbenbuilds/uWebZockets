"""Deterministic serialized native closing seam checks; no native transport."""
import copy
import json
import ssl
import sys
from functools import partial
from unittest import mock
import adapter
import coordinator
import model
import shutdown_cases
import test_all40_descriptors as descriptors
import test_core_peer
import test_shutdown
import test_wire_oracle as oracle
import test_wire_oracle_checks as packets
import native_closing as native
import wire


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def raises(callback, expected, message=None):
    try:
        callback()
    except expected as error:
        require(message is None or message in str(error), 'wrong rejection: ' + str(error))
        return error
    raise RuntimeError('missing rejection')


def fixture(chunks=(), *, origin=None, original=None, control=None, drain=True):
    script = dict(tick=2, chunks=list(chunks) + [b''], calls=0, prepared=0, close=False,
                  received=False, clock_failed=False, result=None, original=original, origin=origin, signal=None)

    def clock():
        if script['close'] and script['received'] and origin == 'clock' and not script['clock_failed']:
            script['clock_failed'] = True
            raise original
        return script['tick']

    app = test_core_peer.new_app()
    peer = test_shutdown.new_peer('shutdown_active', app=app, prior=(), now=2, clock=clock)
    peer_receive, peer_send = peer['connection']['receive'], peer['connection']['send']
    state = native.new_receive_state((7, 'shutdown_active', 1), 2, 1000, (1, 15001, 2, 30002, 1, 900001))

    def prepare(deadline):
        script['prepared'] += 1
        require(deadline == state['deadline'], 'prepare lost caller ticks')
        if script.get('prepare_action') is not None:
            script['prepare_action']()
        if script['close'] and origin == 'prepare':
            raise original

    def recv(size):
        require(size == 8192, 'primitive read bound changed')
        script['calls'] += 1
        if not script['close']:
            return peer_receive()[0]
        script['received'] = True
        if origin == 'recv':
            raise original
        value = script['chunks'].pop(0)
        if isinstance(value, BaseException):
            raise value
        return value

    binding = (prepare, recv, clock)
    original_connection = dict(peer['connection'], receive=partial(native.receive_once, state, binding),
                               send=partial(native.send_once, state, peer_send))
    connection, observer = oracle.wrap_connection(original_connection, descriptors.connection_descriptor(7, 'shutdown_active', 1, final=True))
    native.bind_observer(state, original_connection, connection, observer)
    script.update(state=state, observer=observer, connection=connection, original_connection=original_connection,
                  binding=binding, app=app, peer=peer)
    if control is not None:
        control(script, 'bound')
    context = adapter.open_case('shutdown_active', connection['protocol'], connection['send'], 2, 30002, 900001, clock=clock)
    script['context'] = context
    data, tick = connection['receive']()
    adapter.observe(context, data, tick)

    def signal(current, deadline):
        if control is not None:
            control(script, 'signal_entry')
        native.freeze_checkpoint(current, connection, observer, state, deadline)
        script['before'] = (coordinator.snapshot_counts(current), tuple(state['counts'].values()))
        peer['state']['signal'] = True
        app['records']['shutdown_active'].update(cancels=1, active=False, paused=False, reason='shutdown')
        script['signal'] = dict(signal='SIGTERM', owned_identity=True, watcher_installed=True, client_open=True)
        return script['signal']

    def terminate(current, deadline):
        script.update(close=True, deadline=deadline)
        if control is not None:
            control(script, 'before_activate')
        native.activate(current, connection, observer, state, script['signal'], deadline)
        if control is not None:
            control(script, 'activated')
        if not drain:
            raise StopIteration('captured canonical begin')
        result, receipt = native.drain_closing(current, connection['receive'], observer, state, deadline)
        script['result'], script['receipt'] = result, receipt
        return result

    def post(current, deadline):
        return dict(records=copy.deepcopy(app['records']), metrics=test_core_peer.metrics(app),
                    outputs=copy.deepcopy(app['outputs']), binding=model.default_binding())

    hooks = dict(preconditions=lambda current: dict(client_open=True, prior_complete=True), signal=signal,
                 termination=terminate, process=lambda current, deadline: dict(exit_code=0, reaped=True, forced=False,
                 run_ok=True, deinit_ok=True, key_removed=True), post=post, units_per_second=1000)
    script['hooks'] = hooks
    return script


def run(script):
    context = script['context']
    adapter.run_case(context, script['connection']['receive'], shutdown=script['hooks'])
    return script


def active(chunks=(), **kwargs):
    script = fixture(chunks, drain=False, **kwargs)
    error = raises(lambda: run(script), StopIteration)
    require(str(error) == 'captured canonical begin', 'fixture stopped at wrong boundary')
    return script


def drain(script):
    return native.drain_closing(script['context'], script['connection']['receive'], script['observer'],
                                script['state'], script['deadline'])


def fail_same(error, *args, **kwargs):
    raise error


def check_origins():
    original = ssl.SSLEOFError(8, 'same object at every origin')
    verdicts = []
    for origin in ('recv', 'prepare', 'clock', 'parser', 'passive'):
        script = active((packets.credit_packet(1),), origin=origin, original=original)
        module, name = (wire, 'accept') if origin == 'parser' else (oracle, 'feed')
        callback = partial(fail_same, original) if origin in ('parser', 'passive') else getattr(module, name)
        try:
            with mock.patch.object(module, name, callback):
                facts, receipt = drain(script)
        except BaseException as error:
            verdicts.append((origin, False))
            require(origin != 'recv', 'actual primitive EOF rejected: ' + repr(error))
            require(error is original or origin == 'passive' and isinstance(error, ValueError), 'wrong-origin identity lost')
            require(script['state']['failure'] is not None, 'failure did not invalidate local verdict')
            continue
        verdicts.append((origin, True))
        if origin != 'recv':
            continue
        require(facts['outcome'] == 'tls_eof' and receipt[-4:] == ('local_transport_only', False, 'not_established', 'unknown'), 'TLS receipt scope lost')
        require(oracle.failure(script['observer'])[0] == 'receive_exception', 'original poison cleared')
        raises(lambda: oracle.seal(script['observer']), ValueError, 'oracle_unsealed')
        require(script['state']['provenance'][-1] is original, 'actual exception identity lost')
    print('origin verdicts:', verdicts)
    require(verdicts == [(name, name == 'recv') for name in ('recv', 'prepare', 'clock', 'parser', 'passive')], 'type-only accepted wrong-origin SSLEOFError')
    print('same-object actual recv / prepare / clock-after-bytes / canonical parser / passive postprocessing origin matrix passed')


def check_success():
    packet = packets.credit_packet(7) + packets.credit_packet(11, 3)
    script = run(fixture((packet[:1], packet[1:10], packet[10:])))
    state, context, observer = script['state'], script['context'], script['observer']
    receipt = native.local_receipt(state)
    require(receipt is script['receipt'] and receipt[0][0][11:14] == (32, 32, (3,)), 'frozen prefix lost')
    require(context['request']['connection_debt'] == 25 and context['request']['stream_debt_total'] == 21, 'abandoned debt changed')
    require(context['raw']['closed'] and context['request']['transport_closed'] and not context['records'], 'handler did not finish canonical transport')
    require(context['raw']['closing']['frames'] == 2 and context['raw']['closing']['bytes'] == 26, 'canonical charge duplicated')
    require(state['counts']['attempts'] == state['counts']['returns'] == state['counts']['boundary_returns'], 'successful lifetime counts differ')
    require(state['counts']['nonempty'] + 1 == state['counts']['returns'], 'empty boundary not counted separately')
    require(state['baseline'][0] > 1 and observer['checkpointed'] and not observer['sealed'], 'ordinary traffic or checkpoint missing')
    require(state['phase'] == 'terminal' and state['failure'] is None, 'healthy local lifecycle differs')
    before = script['calls']
    raises(script['connection']['receive'], ValueError, 'provider_io_closed')
    require(script['calls'] == before, 'terminal performed primitive retry')
    raises(lambda: native.local_receipt(state), ValueError, 'local_receipt_invalid')
    print('serialized ordinary startup/final collection, single canonical begin/finish, fragmented refunds, exact counters, retained debt and stale receipt invalidation passed')


def immutable(value):
    if type(value) is tuple:
        for member in value:
            immutable(member)
        return
    require(type(value) in (int, bool, str, bytes, type(None)), 'mutable or exception receipt member')


def check_composition():
    for outcome in ('eof', 'tls_eof'):
        original = ssl.SSLEOFError(8, 'closing') if outcome == 'tls_eof' else None
        calls = dict(wrap=0, begin=0, finish=0)
        wrap, begin, finish = oracle.wrap_connection, wire.begin_termination, wire.finish_termination

        def wrapping(*args, **kwargs):
            calls['wrap'] += 1
            return wrap(*args, **kwargs)

        def beginning(*args, **kwargs):
            calls['begin'] += 1
            return begin(*args, **kwargs)

        def finishing(*args, **kwargs):
            calls['finish'] += 1
            return finish(*args, **kwargs)

        with mock.patch.object(oracle, 'wrap_connection', wrapping), mock.patch.object(wire, 'begin_termination', beginning), mock.patch.object(wire, 'finish_termination', finishing):
            script = run(fixture(origin='recv' if original is not None else None, original=original))
        require(calls == dict(wrap=1, begin=1, finish=1), 'canonical lifecycle ownership differs')
        receipt = native.local_receipt(script['state'])
        immutable(receipt)
        require(receipt[3][2] == outcome and receipt[6] == ((32, 32, 32, 32), (32, 32, 32, 32)), 'empty/SSL terminal lost actual abandoned debt')
        require(script['context']['raw']['closed'] and script['context']['request']['transport_closed'], 'canonical finish missing')
        print(json.dumps(dict(outcome=outcome, lifecycle=calls, checkpoint_operation=receipt[0][1],
                              prefix_received=receipt[0][0][3][:3], lifetime_baseline=receipt[2][0],
                              closing_delta=receipt[2][2], terminal=receipt[3], original_failure=receipt[4],
                              debt=receipt[6], scope=receipt[-4:]), sort_keys=True))


def check_ordinary():
    for item in (b'', ssl.SSLEOFError(8, 'ordinary EOF'), OSError('ordinary failure')):
        script = fixture((item,))
        script['close'] = True
        state, observer = script['state'], script['observer']
        before = native.counts(state)
        error = raises(script['connection']['receive'], (ValueError, OSError))
        if isinstance(item, BaseException):
            require(error is item, 'ordinary exception identity changed')
        after = native.counts(state)
        require(after[0:2] == (before[0] + 1, before[1] + 1), 'ordinary primitive attempt not counted')
        require(after[2] == before[2] + int(item == b'') and after[3] == before[3], 'ordinary EOF return classification differs')
        require(state['checkpoint'] is None and oracle.failure(observer)[0] == 'receive_exception', 'ordinary EOF rehabilitated')
        first, calls = oracle.failure(observer), script['calls']
        raises(script['connection']['receive'], ValueError, 'provider_io_closed')
        require(oracle.failure(observer) is first and script['calls'] == calls, 'ordinary failure retried or poison replaced')
    script = fixture()
    original = script['connection']['receive']
    raises(lambda: native.bind_observer(script['state'], script['original_connection'], script['connection'], script['observer']), ValueError, 'observer_already_bound')
    require(script['connection']['receive'] is original, 'duplicate binding swapped callback')
    print('ordinary empty/SSL/other EOF fail before checkpoint with exact primitive/boundary counts, original identity and absorbing poison; duplicate bind rejected')


def check_binding_identity():
    state = native.new_receive_state((7, 'shutdown_active', 1), 2, 1000, (1, 15001, 2, 30002, 1, 900001))
    callbacks = (lambda deadline: None, lambda size: b'', lambda: 2)
    original = dict(protocol=object(), send=partial(native.send_once, state, lambda data: None),
                    receive=partial(native.receive_once, state, callbacks), now=2, owned=True, tls='TLSv1.3', alpn='h2')
    connection, observer = oracle.wrap_connection(original, descriptors.connection_descriptor(7, 'shutdown_active', 1, final=True))
    substitute = dict(observer)
    require(substitute == observer and substitute is not observer, 'equal observer substitute not distinct')
    raises(lambda: native.bind_observer(state, original, connection, substitute), ValueError, 'wrapped_receive_binding')
    require(observer['operation'] == 0 and state['counts']['attempts'] == 0, 'invalid binding performed receive')
    print('equal-valued observer from another ownership object cannot bind the captured wrapper')


def check_no_retry_and_shapes():
    errors = (TimeoutError('timeout'), ssl.SSLWantReadError(2, 'want read'), ssl.SSLWantWriteError(3, 'want write'),
              OSError('other error'), RuntimeError('other runtime'), KeyboardInterrupt('interrupt'))
    for original in errors:
        script = active((original,))
        before = script['calls']
        error = raises(lambda: drain(script), BaseException)
        require(error is original and script['calls'] == before + 1, 'error identity changed or retry occurred')
        raises(script['connection']['receive'], ValueError, 'provider_io_closed')
        require(script['calls'] == before + 1, 'failed receive retried')
    for value in (None, bytearray(b'x'), b'x' * 8193):
        script = active((value,))
        before = native.counts(script['state'])
        raises(lambda: drain(script), ValueError)
        after = native.counts(script['state'])
        require(after[1:3] == (before[1] + 1, before[2] + 1) and after[3] == before[3], 'malformed primitive return counts lost')
        diagnostic = script['state']['provenance'][5]
        require(diagnostic is None or len(diagnostic) == 8192, 'diagnostic retained oversized chunk')
    print('timeout/WANT/other/BaseException identity and no-retry; malformed/8193-byte returns recorded before checks with bounded diagnostic passed')


def check_tails_and_frames():
    packet = packets.credit_packet(1)
    for cut in range(1, len(packet)):
        script = active((packet[:cut],))
        raises(lambda: drain(script), ValueError, 'closing_partial_tail')
        require(script['state']['receipt'] is None, 'partial tail exported a receipt')
        healthy = run(fixture((packet[:cut], packet[cut:])))
        require(healthy['receipt'][2][-1] == 1, 'fragmented refund count differs')
    wrong = (packets.data_packet(b'x', 3), packets.credit_packet(1, 5), packets.credit_packet(33),
             packets.credit_packet(33, 3), packet[:4] + b'\x01' + packet[5:],
             packet[:5] + b'\x80' + packet[6:], packet[:9] + b'\x80\x00\x00\x01',
             packet[:9] + b'\0\0\0\0', packet[:2] + b'\x03' + packet[3:])
    for data in wrong:
        script = active((data,))
        raises(lambda: drain(script), (ValueError, RuntimeError))
        require(script['state']['receipt'] is None, 'forbidden frame or overrefund accepted')
    script = active((packets.credit_packet(33),))
    raises(lambda: drain(script), ValueError, 'invalid connection refund')
    require(oracle.failure(script['observer']) is None and script['context']['stage']['failed'], 'canonical credit authority not exercised')
    print('all12 partial tails rejected/all12 fragmented refunds accepted; forbidden type/stream/flags/reserved/size/zero/overrefund rejected by existing consumers')


def check_lifecycle():
    script = fixture()
    raises(lambda: native.activate(script['context'], script['connection'], script['observer'], script['state'], {}, 15002), ValueError, 'activation_lifecycle')
    for mode in ('connection', 'operation', 'signal', 'begin', 'tail', 'sealed', 'busy', 'io', 'counts'):
        def control(current, phase):
            if phase != 'before_activate':
                return
            context, state, observer = current['context'], current['state'], current['observer']
            match mode:
                case 'connection':
                    native.activate(context, dict(current['connection']), observer, state, current['signal'], current['deadline'])
                case 'operation':
                    oracle.invoke(observer, 'receive', lambda: (b'', 2))
                case 'signal':
                    current['signal']['owned_identity'] = 1
                case 'begin':
                    context['raw']['closing']['phase'] = 'pre_unwrap'
                case 'tail':
                    context['raw']['header'].extend(b'x')
                case 'sealed':
                    oracle.seal(observer)
                case 'busy':
                    oracle.invoke(observer, 'receive', lambda: native.activate(context, current['connection'], observer, state, current['signal'], current['deadline']))
                case 'io':
                    current['connection']['send'](b'')
                case 'counts':
                    context['stage']['case_state']['reads'] += 1
        current = fixture(control=control)
        raises(lambda: run(current), ValueError)
        require(current['state']['failure'] is not None and current['state']['receipt'] is None, 'invalid lifecycle accepted: ' + mode)
    for mode in ('duplicate', 'reentrant', 'send'):
        script = active()
        state = script['state']
        match mode:
            case 'duplicate':
                raises(lambda: native.activate(script['context'], script['connection'], script['observer'], state, script['signal'], script['deadline']), ValueError)
            case 'reentrant':
                script['prepare_action'] = script['connection']['receive']
                raises(lambda: drain(script), ValueError, 'reentrant')
            case 'send':
                drain(script)
                raises(lambda: script['connection']['send'](b''), ValueError, 'provider_io_closed')
        raises(lambda: native.local_receipt(state), ValueError, 'local_receipt_invalid')
    print('activation before binding/checkpoint, wrong connection/op/signal/begin/tail/sealed/busy/IO/counts, duplicate/reentrant/postterminal-send reject')


def check_provenance():
    original = ssl.SSLEOFError(8, 'primitive')
    script = active((original,))
    captured = []
    classify = native.is_tls_terminal

    def inspect(state, error, operation, attempt):
        captured.append((dict(state), error, operation, attempt))
        return classify(state, error, operation, attempt)

    with mock.patch.object(native, 'is_tls_terminal', inspect):
        drain(script)
    snapshot, error, operation, attempt = captured[0]
    snapshot['draining'] = True
    require(classify(snapshot, error, operation, attempt), 'actual provenance not captured')
    provenance = snapshot['provenance']
    replacements = ((0, {}), (1, (8, 'shutdown_active', 1)), (2, operation - 1), (3, attempt - 1),
                    (4, 'recv_returned'), (5, b''), (6, ssl.SSLEOFError(8, 'primitive')))
    for index, value in replacements:
        changed = list(provenance)
        changed[index] = value
        invalid = dict(snapshot, provenance=tuple(changed))
        require(not classify(invalid, error, operation, attempt), 'forged provenance accepted')
    for field, value in (('failure', ('internal', 'receive', operation, 0, None)), ('sealed', True), ('busy', True)):
        invalid = dict(snapshot, observer=dict(snapshot['observer'], **{field: value}))
        require(not classify(invalid, error, operation, attempt), 'wrong oracle provenance accepted')
    require(not classify(snapshot, error, operation + 1, attempt) and not classify(snapshot, error, operation, attempt + 1), 'wrong expected operation accepted')
    print('actual recv proof captured; stale/wrong connection/identity/phase/operation/attempt/error and prior oracle failure rejected without mutating actual observer')


def check_time_and_overflow():
    for value in (True, -1, 1, 15002, 15003, native.U64 + 1, 2.0):
        script = active()
        script['tick'] = value
        before = script['calls']
        raises(lambda: drain(script), ValueError, 'receive_time')
        require(script['calls'] == before, 'expired or invalid time called primitive')
    for key in native.COUNT_KEYS:
        script = active((packets.credit_packet(1),))
        script['state']['counts'][key] = native.U64
        raises(lambda: drain(script), ValueError)
        require(script['state']['receipt'] is None, 'counter overflow yielded receipt')
        require(not script['state']['busy'], 'counter overflow left receive busy')
    for units, deadlines in ((True, (1, 15001, 2, 30002, 1, 900001)),
                             (1000, (1, 15002, 2, 30002, 1, 900001)),
                             (1000, (1, 15001, 2, 30003, 1, 900001)),
                             (1000, (1, 15001, 2, 30002, 1, 900002)),
                             (native.U64, (1, 3, 2, 4, 1, 5))):
        raises(lambda: native.new_receive_state((7, 'shutdown_active', 1), 2, units, deadlines), (ValueError, OverflowError))
    print('integer clock regression/equality/late/type/uint64, lifetime counter overflow, ready15/case30/whole900 deadline and units bounds rejected')


def check_ready_and_live_binding():
    def expire(script, phase):
        if phase == 'bound':
            script['tick'] = 15001

    raises(lambda: fixture(control=expire), ValueError, 'ready_deadline')
    for mode in ('phase', 'context', 'frames', 'callback'):
        script = active()
        context, state = script['context'], script['state']
        match mode:
            case 'phase':
                context['raw']['closing']['phase'] = 'pre_unwrap'
            case 'context':
                context['raw'] = copy.deepcopy(context['raw'])
            case 'frames':
                context['raw']['closing']['frames'] = 4097
            case 'callback':
                script['original_connection']['receive'] = lambda: (b'', 2)
        raises(lambda: drain(script), ValueError)
        require(state['receipt'] is None, 'changed live phase/binding yielded receipt')
    print('actual first-IO readiness expiry and postactivation phase/context/frame/callback changes reject')


def check_budget_boundaries():
    packet = packets.credit_packet(1)
    for allowance, chunks, success in ((0, (), True), (0, (packet,), False), (1, (packet,), True),
                                        (1, (packet, packet), False)):
        script = active(chunks)
        script['state']['allowance'] = allowance
        before = script['calls']
        if success:
            facts, receipt = drain(script)
            require(receipt[2][2][1] == allowance + 1 and facts['outcome'] == 'eof', 'terminal probe count differs')
        else:
            raises(lambda: drain(script), ValueError, 'closing_nonempty_budget')
        require(script['calls'] - before == allowance + 1, 'terminal-only probe became extra data allowance')
    for kind in ('final', 'case', 'reads', 'frames', 'closing_bytes'):
        script = active((packet,))
        stage = script['context']['stage']
        match kind:
            case 'final':
                stage['final_bytes'] = stage['final_budget']
            case 'case':
                stage['case_state']['bytes'] = stage['budget']
            case 'reads':
                stage['case_state']['reads'] = stage['limits']['receive_calls']
            case 'frames':
                script['context']['raw']['closing']['frames'] = 4096
            case 'closing_bytes':
                script['state']['counts']['bytes'] = script['state']['baseline'][5] + 65536
        raises(lambda: drain(script), ValueError)
        require(script['state']['receipt'] is None, 'exhausted bound yielded a receipt')
    print('explicit residual-bound fault injections: zero/one read allowance plus terminal-only probe, final/case/read/4096-frame/65536-byte exhaustion reject extra data')


def check_exact_budget_controls():
    packet = packets.credit_packet(1)
    for mode in ('final', 'case', 'reads', 'frames', 'closing_bytes'):
        script = active((packet,))
        stage, state = script['context']['stage'], script['state']
        match mode:
            case 'final':
                stage['final_bytes'] = stage['final_budget'] - len(packet)
            case 'case':
                stage['case_state']['bytes'] = stage['budget'] - len(packet)
            case 'reads':
                stage['case_state']['reads'] = stage['limits']['receive_calls'] - 1
            case 'frames':
                script['context']['raw']['closing']['frames'] = 4095
            case 'closing_bytes':
                state['counts']['bytes'] = state['baseline'][5] + 65536 - len(packet)
        facts, receipt = drain(script)
        require(facts['outcome'] == 'eof' and receipt[6][1][:2] == (31, 32), 'exact numeric bound rejected valid serialized refund')
    packet = b''.join(packets.credit_packet(1, stream) for stream in (0, 3) for number in range(32))
    script = run(fixture((packet,)))
    require(script['receipt'][2][-1] == 64 and script['receipt'][6][1] == (0, 0, 0, 0), 'maximum earned 64 refunds lost')
    script = active((packet, packets.credit_packet(1)))
    raises(lambda: drain(script), ValueError, 'invalid connection refund')
    print('isolated exact numeric final/case/read/frame4096/byte65536 controls passed; independently earned64 refunds/832bytes exhaust actual64 debt, next refund rejects')


def main(argv):
    if argv == ['--check-api']:
        require(callable(native.receive_once), 'missing native receive API')
    elif argv == ['--check-origins']:
        check_origins()
    elif argv == ['--check']:
        check_origins()
        check_success()
        check_composition()
        check_ordinary()
        check_binding_identity()
        check_no_retry_and_shapes()
        check_tails_and_frames()
        check_lifecycle()
        check_provenance()
        check_time_and_overflow()
        check_ready_and_live_binding()
        check_budget_boundaries()
        check_exact_budget_controls()


if __name__ == '__main__':
    main(sys.argv[1:])
