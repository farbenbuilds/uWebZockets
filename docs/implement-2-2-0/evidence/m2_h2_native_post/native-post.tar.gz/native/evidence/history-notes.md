The API-absence RED, actual naive type-only origin REDs, and implementation
regressions have separate run directories containing the source versions,
runner, restoration receipt, exact arguments, stdout, stderr and status.

The first readiness implementation and its first-I/O expiry expectation were
overstrict. The canonical coordinator checks readiness once per child, before
its case loop. Root's accepted source ruling is
.superpowers/sdd/h2_streaming_plan/task-5e3c4-ready-scope-report.md.
The earlier files/results remain unchanged historical evidence; they do not
establish a per-connection first-byte deadline. red-child-ready-scope reproduces
the actual later-case rejection. The corrected contract retains explicitly
supplied observed ready_start/ready_at and the original clipped ready deadline;
it never reconstructs ready_start or restarts case/whole/grace deadlines.

All original native implementation/test versions exercised by retained runs
were snapshotted before those runs. The initial preservation metadata helper
was written in the recorded task tool call, but was not separately copied to
a pre-run filesystem snapshot before its successful first freeze. This gap is
not represented as a pre-run snapshot. Later versions are retained as
preserve-midpoint.py and in subsequent run directories.

File preservation-before.json was captured before native code creation.
The directory-only inventory was captured later, at directories-midpoint.json;
its comparison proves only that later boundary. No earlier directory history
is inferred. The two directory inventories include membership, including empty
directories within the protected roots, for the stated directory boundary.

Final normal/-O and inert results preceding the readiness correction remain
historical. final-ready-* run directories bind the final corrected source.
High numeric budget boundary controls deliberately inject counters and do not
claim earned4096-frame/65536-byte closing traffic. The separate serialized
64-refund/832-byte test earns the maximum actual64 units of held request debt.
