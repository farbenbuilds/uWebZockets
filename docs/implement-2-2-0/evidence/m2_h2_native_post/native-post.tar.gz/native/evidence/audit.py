"""Retain exact new-source identities, commands, results and closure metadata."""
import hashlib
import json
import sys
from pathlib import Path


def file_row(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def run_row(folder):
    return dict(name=folder.name, command=(folder / 'command.txt').read_text().splitlines(),
                status=int((folder / 'status').read_text()),
                files=[file_row(path) for path in sorted(folder.iterdir()) if path.is_file()])


def main(argv):
    if argv != ['--audit']:
        return
    import native_closing
    import test_native_imports
    root = Path(__file__).resolve().parent.parent
    executable = file_row(Path('/home/codespace/.python/current/bin/python3'))
    if executable['sha256'] != '4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601':
        raise ValueError('pinned Python changed')
    source = [file_row(path) for path in sorted(root.glob('*.py'))]
    required = ('final-ready-normal', 'final-ready-optimized', 'final-ready-inert', 'final-ready-inert-optimized',
                'final-ready-preservation', 'final-ready-directories')
    for name in required:
        folder = root / 'evidence' / name
        if int((folder / 'status').read_text()) != 0:
            raise ValueError('required final check failed: ' + name)
        for row in source:
            if file_row(folder / Path(row['path']).name)['sha256'] != row['sha256']:
                raise ValueError('final check exercised different source: ' + name)
    depths = {path.name: test_native_imports.source_check(path) for path in root.glob('*.py')}
    helpers = tuple(root / 'evidence' / name for name in ('preserve.py', 'audit.py'))
    depths.update({path.name: test_native_imports.source_check(path) for path in helpers})
    canonical = ('catalogue', 'model', 'wire', 'raw_observer', 'output_stage', 'request_credit',
                 'response_credit', 'adapter', 'shutdown_cases', 'test_wire_oracle')
    rows = {name: file_row(Path(sys.modules[name].__file__)) for name in canonical}
    if native_closing.wire is not sys.modules['wire'] or native_closing.oracle is not sys.modules['test_wire_oracle']:
        raise ValueError('canonical object identities differ')
    runs = [run_row(path) for path in sorted((root / 'evidence').iterdir()) if path.is_dir() and (path / 'status').is_file()]
    result = dict(source=source, helpers=[file_row(path) for path in helpers], nesting=depths,
                  required_successful_source_matched_runs=required,
                  python=executable, optimization=sys.flags.optimize, canonical=rows, runs=runs,
                  prior_file_snapshot='preservation-before.json', prior_file_after='preservation-after.json',
                  directories_later_boundary='directories-midpoint.json', directories_after='directories-after.json',
                  actual_serialized_closing_max=dict(frames=64, returned_bytes=832, refund_debt=64),
                  high_bound_controls='Explicit injected numeric boundary controls, not earned4096-frame/65536-byte traffic',
                  native_transport_executed=False, provider_runtime_build_fullgates_adoption_open=True)
    (root / 'evidence/audit.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(dict(source=source, nesting=depths, recorded_runs=len(runs), native_transport_executed=False), sort_keys=True))


if __name__ == '__main__':
    main(sys.argv[1:])
