The next slice should add one source-only closing module with explicit receive provenance. Keep the seven-key connection dictionary, `(bytes, tick)` return, passive oracle, and canonical shutdown ownership unchanged.

References below use `S/` for `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/`, `C/` for `combined-all40.tar.gz::reference/core/`, and `R/` for `output-driver.tar.gz::source/runtime/`.

Assumptions and scope:

- The accepted c3 checkpoint and local-only terminal contract remain binding; implementation release follows Root’s publication.
- Proposed files: `S/native_closing.py` and `S/test_native_closing.py`. No runtime imports, sockets, SSLContext, target execution, production Zig changes, or archive changes.
- Native provider binding, actual owned-signal evidence, runtime closure and final run acceptance remain later prerequisites.

1. **Define the receive provenance seam — transport_io with crypto_tls.**

   `S/coordinator.py:40` and `S/test_wire_oracle.py:112` require exactly seven connection keys. Preserve those keys; retain provenance separately in caller-owned state.

   Proposed named contracts:

   - `ReceiveBinding = (prepare, recv, clock)`, with named callback aliases. `prepare(deadline)` performs identity/capture/timeout preparation; `recv(8192)` is the actual receive primitive; `clock()` returns integer caller ticks.
   - `ReceiveProvenance = (connection_identity, operation, attempt, phase, returned_data, exception)`.
   - `phase` is exactly `prepared`, `recv_entered`, `recv_returned`, or `recv_raised`; `returned_data` and `exception` are mutually exclusive optional values.
   - `ClosingState` is explicit mutable caller-owned data, containing the immutable checkpoint, bound connection identity/references, authorization, counters, current provenance and sticky local failure.
   - `receive_once(state, binding) -> (bytes, tick)` supplies the original no-argument receive callback through binding.
   - `drain_closing(context, wrapped_receive, observer, state, deadline) -> (TerminationFacts, ClosingReceipt)` supplies the later termination hook.

   Before each wrapped call, assign the expected observer operation and clear previous provenance. Perform preparation outside the primitive catch. Increment actual receive attempts immediately before `recv(8192)`. Catch only that call, record the exact exception object, then **bare re-raise**. Record returned bytes immediately after success, before clock or shape/postprocessing checks.

   `R/owned_io.py:18` currently combines timeout setup, receive and nonempty validation; it rejects empty bytes. Do not catch that whole helper as proof of receive origin or change its ordinary contract.

   At the closing consumer, accept `tls_eof` only when the caught object **is** provenance’s exception, phase is `recv_raised`, connection/operation/attempt match, and the first oracle failure is the matching `receive_exception`. Exception type alone is insufficient. Preserve `S/test_wire_oracle.py:143` unchanged.

2. **Bind activation and immutable evidence — transport_io, guided by http_protocol.**

   The signal-hook entry freezes the existing `CheckpointReceipt = (ConnectionReceipt, operation)` after semantic final collection and before signal effects (`S/test_wire_oracle.py:521`; `S/coordinator.py:220`). Validate checkpoint counts/debts against that same pre-teardown boundary.

   Activation requires successful owned signal evidence, unchanged connection/operation, no intervening application I/O, unsealed/unbusy/unpoisoned observer, completed final collection, held stream3, and matching canonical `raw['closing']` state. The handler establishes signal/begin ordering at `S/shutdown_cases.py:87`.

   `coordinator.run` remains dispatcher; `shutdown_cases.active` alone calls `wire.begin_termination` and `wire.finish_termination` (`:93`, `:102`). The helper neither begins nor finishes canonical termination.

   Freeze `ClosingReceipt` as a named immutable tuple containing checkpoint, phase, timing tuple, counts tuple, terminal tuple, original `FailureReceipt`, parser-tail tuple, credit/debt deltas and scope qualifiers. Suggested component tuples:

   - `ClosingTiming = (start, end, deadline, units_per_second)`
   - `ClosingCounts = (wrapped_attempts, recv_attempts, recv_returns, boundary_returns, nonempty_returns, returned_bytes, frames)`
   - `ClosingTerminal = (operation, recv_attempt, outcome)`
   - `ClosingTails = (passive_bytes, canonical_header_bytes, canonical_frame_active, canonical_remaining)`

   Exception objects stay in live provenance, not immutable exported receipts.

3. **Drain through existing consumers and bounds — http_protocol with transport_io.**

   For each successful nonempty boundary return: validate integer monotonic time and grace, check oracle poison, then call exactly once:

   `wire.accept(protocol, data, records, raw, trace, credit=credit, request=request, stage=stage)`.

   `C/wire.py:146` invokes `raw_observer.observe`; that invokes `output_stage.read` (`C/raw_observer.py:135`). Do not separately charge `read`, call `adapter.observe`—which rejects shutdown at `S/adapter.py:89`—or flush/send.

   Preserve conjunctively:

   - Read8192, closing65536 bytes and4096 frames.
   - Residual case bytes, final bytes and read allowance from `C/output_stage.py:163`. Read cap uses `limits['receive_calls']`, adding `final_budget` only under its existing condition; subtract current `case_state['reads']`.
   - At most remaining nonempty-read allowance plus one actual receive attempt. Once data allowance is exhausted, permit one terminal-only probe; positive bytes reject without granting allowance. Retain at most one8192-byte diagnostic chunk.
   - Only length4, flags0, unreserved WINDOW_UPDATE on stream0 or3 (`C/raw_observer.py:122`, `:158`).
   - Canonical refund limits (`C/request_credit.py:140`), since passive observation clamps excessive refunds.
   - Integer readiness15/whole900/case30-or180 limits and supplied grace<=15, clipped to case/whole. Check before/after operations and acceptance; equality, regression, overflow or invalid ticks reject. Convert only remaining ticks to OS timeout seconds.

   Never reset counters during draining. Coordinator restoration at `S/coordinator.py:235` publishes pre-teardown accounting; it grants no additional budget.

   Empty boundary return requires no poison. Actual receive `SSLEOFError` remains poisoned, contributes one attempt and no receive return, and permits only a separate local receipt. Preserve known-tail rejection, unknown internal prefix, `complete_wire_proof=False`, and `authenticated_close_notify='not_established'`; discarded plaintext is unknown. Retain unpaid debt through `C/request_credit.py:126`.

4. **Prove the seam — verification, then independent reviewer.**

   Use caller-owned doubles and existing serialized codecs/checkpoint fixtures. Required behavioral RED/GREEN cases:

   - Identical `SSLEOFError` raised by actual recv versus preparation, clock-after-bytes, canonical parser and passive postprocessing. Only actual recv qualifies; preserve existing propagation/swallow-and-poison semantics.
   - Stale provenance, wrong identity/operation, prior poison, duplicate activation, reentrancy and postterminal I/O reject.
   - Fragmented valid refunds, all partial-tail splits, forbidden frames/excess refunds, empty EOF and real receive EOF preserve exact counters and immutable prefix.
   - Exhausted byte/read/frame limits allow no extra data; timeout/WANT/other exceptions never retry.
   - Canonical composition finishes once and retains unrepaid debt.

The deep-module seam is provenance-checked bounded draining. Its deletion would scatter origin classification, accounting and authorization across provider hooks; no parser duplication is justified.

Skill conflicts are explicit: the requested read-only scope overrides plan-file writes and interview-driven execution. The referenced `.agents/references/definition-of-done.md` was absent. Project gates remain unchanged; none were run here, and this plan grants no implementation or native acceptance.
