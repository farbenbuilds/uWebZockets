Install the receive seam once, before ordinary traffic. The closing helper must never replace the captured callback or wrap the connection again.

1. **Initialization and lifecycle**

   Create caller-owned `ReceiveState` before constructing the seven-key connection dictionary:

   `phase='ordinary'`, `observer=None`, `checkpoint=None`, `authorization=None`, `provenance=None`, all counters zero.

   Install the no-argument callback bound to `receive_once(state, binding)` as the original `connection['receive']`. Call `oracle.wrap_connection(connection, descriptor)` exactly once, then bind its returned observer to `state['observer']` before any send/receive. Reject duplicate binding or activation before binding. The observer reference permits provenance to record the operation already incremented by `oracle.invoke`; it does not grant permission to modify observer state.

   Every ordinary call uses the same preparation, actual-recv provenance recording and postprocessing sequence. Maintain lifetime counters independently of checkpoint availability. Record a successful raw return before subsequent checks, including an empty return or bytes followed by a clock failure.

   Ordinary empty receive retains the existing failure policy: raise the ordinary premature-EOF error; do not return `(b'', tick)`. Ordinary `SSLEOFError` propagates unchanged and poisons normally. Only the successfully authorized closing phase permits an empty return as a terminal candidate. Neither EOF form can activate closing.

   At checkpoint creation, freeze independent lifetime-counter baselines alongside the immutable `CheckpointReceipt`; do not reset counters. Require no wrapped I/O between checkpoint and activation. Closing deltas subtract these baselines; primitive attempts, primitive returns and boundary returns remain distinct. The existing checkpoint has no primitive-attempt counters, so do not infer them from its successful-call totals.

   Activation changes only explicit local lifecycle state after the previously specified signal/canonical-begin checks. At terminal or failure, further provider I/O is refused and marks the local verdict failed. Ordinary oracle poison behavior remains unchanged.

2. **Namespace and dependency seam**

   Use the new files:

   - `.uwz-work/evidence/h2-streaming/combined-native/native_closing.py`
   - `.uwz-work/evidence/h2-streaming/combined-native/test_native_closing.py`

   This supersedes the first plan’s proposed `S/` placement. Preserve accepted pure `S46` and `test_imports` inventory exactly.

   `native_closing` owns explicit I/O provenance, lifecycle authorization, bounded draining and local receipts. It consumes the accepted passive oracle/checkpoint and canonical `wire`/stage contracts through the existing pinned source-loading mechanism. Reuse the same loaded module identities and context objects; do not copy canonical modules or load alternate parser instances.

   The future provider supplies preparation, recv and integer-clock callbacks; this slice imports no archived runtime/provider and constructs no transport. Tests supply scripted callbacks and reuse accepted serialized fixtures without changing them.

   Add a separate native-helper inert-import inventory check covering the new helper’s actual dependency closure and absence of import-time I/O, process creation or runtime loading. It supplements the unchanged pure inventory.

These are source-plan clarifications only. No tests, native operations, source edits or Git writes were performed.
