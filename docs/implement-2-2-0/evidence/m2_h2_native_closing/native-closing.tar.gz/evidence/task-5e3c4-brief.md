# Native receive provenance and bounded local closing receipt

Read this first: exact source-only implementation scope. BASE
6bd6d0494ead541636c8ff23d465c7f78e897b38, feat/implement-2-2-0, clean/pushed
fork; task-5e3c3-root-commit-audit.json binds exact6 reviewed committed files.
Read task-5e3c4-plan-report.md AND task-5e3c4-plan-addendum.md for exact source
seams, signatures, bounds and lifecycle order. The addendum supersedes first
plan's S/ placement and clarifies installation BEFORE ordinary traffic.
Existing accepted local-transport-only policy remains binding from
task-5e3c-terminal-contract-report.md and its independent doubt verdict.

Own NEW .uwz-work/evidence/h2-streaming/combined-native/ directory with
native_closing.py, test_native_closing.py and a separate native-helper inert
inventory check; use evidence/ for bounded metadata/raw controls. Full report
.superpowers/sdd/h2_streaming_plan/task-5e3c4-report.md. Additional source files
need a concrete complexity/invariant reason; report it before expanding.
You are sole implementation owner, not alone in workspace: preserve others.
No subagents/Gitwrites/publication. Root independently reviews/commits/pushes.

Pure S46 (integration-owned/combined-cases) and its test_imports inventory must
remain byte-identical. No canonical model/client/wire/stage/oracle/fixture/
candidate/dependency/product/pin changes. Do not import/execute oldruntime or
native candidates. No compiler/library target/server/socket/SSLContext/real-clock/
process-under-test/network/install operations; source-only scripted callbacks
and bounded metadata are allowed. Actual TLS/PID/listener/signal/cleanup proof,
provider/runtime closure, builds/nativeall40/fullgates/adoption remain later.

Implement the plan's single receive/provenance/lifecycle seam, with explicit
named callback and immutable tuple contracts and caller-owned mutable state.
No classes/assert/customexceptions/globalmutablecontainers/any-typed public
contracts/silencederrors. No second parser/client/alternate canonical module
instances, global monkeypatch or forwarding abstraction. Reuse exact loaded
source identities through pinned PYTHONPATH; scoped test fault injection is
permitted only where it proves a named boundary without altering production
code or leaving global state changed. Keep helpers/functions max3 nesting.

Connection and provenance:
- Initialize ReceiveState before seven-key connection creation. Install one
  receive_once(state,binding) callback as original receive, wrap once with
  accepted oracle, bind returned observer once before IO; no callback swap or
  second observer at shutdown. Connection keys/return(bytes,tick) unchanged.
- prepare(deadline), actual recv(8192), integer clock are named callbacks.
  Record exact connection/observeroperation/primitiveattempt and phase. Catch
  ONLY actual recv call, retain exact exception object locally, bare-rethrow.
  Preparation/clock/parser/passive-postprocessing SSL EOF cannot qualify.
  Record primitive returns before later shape/time checks; do not retain more
  than one8192-byte diagnostic chunk on failure. Export no exception objects.
- Ordinary EOF fails immediately under original ordinary-failure policy;
  ordinary SSL EOF preserves identity/poison. Authorized closing alone admits
  empty boundary return. Count primitive attempts/returns/boundary returns/
  nonemptyreturns separately for lifetime and closing deltas, never reset.
- State must support ordinary traffic before checkpoint exists. Bind explicit
  caller deadlines/units safely; validate integer monotonic ticks and uint64
  counters. Never infer primitive counts from observer successful-call totals.

Checkpoint/activation/termination:
- At signal-hook entry after canonical semantic final collection, freeze the
  c3 checkpoint plus separate lifetime-count baselines. Bind actual observer/
  connection and pre-teardown counts/debts; no appIO between checkpoint and
  activation. Actual application records/metrics/output/binding validation is
  an external provider prerequisite, not new parser work here.
- Activate once only after validated supplied signal evidence AND existing
  canonical signaled/post_signal/begin state for shutdown_active heldstream3.
  Supplied source doubles prove schema/order, not real process identity.
  Wrong connection/operation/phase/priorpoison/tail/busy/sealed/duplicate fails.
- Handler alone begins/finishes canonical termination. Each successful
  nonempty boundary return goes exactly once through the plan's wire.accept
  path, which already charges raw_observer/output_stage; no adapter.observe,
  separate read charge, flush/send, counter reset or fabricated terminal.
- Closing receipt is explicit immutable prefix/timing/count/terminal/failure/
  tail/debt data with scope local_transport_only, complete_wire_proof=False,
  authenticated_close_notify=not_established. Actualrecv SSLEOF qualifies only
  with exact exception identity + matching phase/op/attempt/connection and first
  oracle receive_exception. Ordinary poison remains absorbing and ordinaryseal
  stillfails. Unknown internal prefix/discarded plaintext stays unknown.
- Empty EOF requires no poison. Reject known partial tails/forbidden frames/
  excessive credit; preserve all actual abandoned debt. Terminal/failure
  forbids further provider IO and invalidates local run verdict if attempted;
  no stale frozen receipt may hide subsequent failure. Whole native acceptance
  still requires real postdeinit/exit/reap/normalcleanup outside this slice.

Bounds remain conjunctive: read8192, closing65536returnedbytes/4096frames;
residual case/final bytes/reads and original deadlines. Only length4/flags0/
unreserved WINDOW_UPDATE stream0 or3 during closing. Canonical request-credit
validation remains authoritative because passive observer clamps refunds.
Permit at most remaining nonempty-read allowance+one terminal-only probe;
positive data on exhausted allowance rejects, no new budget. Integer ticks,
ready15/whole900/case30or180 and originalgrace<=15 clippedcase/whole; equality,
regression/invalid/overflow/afterdeadline reject. No retry after any EOF/error.
OS-time conversion belongs later real preparation callback, not a new realclock.

TDD: retain APIabsence versus real behavioralRED separately. Specifically
disprove naive type-only SSLEOF acceptance with SAME exception at actualrecv,
prepare, clockafterbytes, canonical parser and passivepostprocessing. Only
actualrecv may qualify with sticky original poison. Cover actual ordinary
traffic before checkpoint/wraponce/bindonce/ordinaryEOF failure; stale/wrong
provenance/operation/identity; priorpoison/duplicate/reentrant/postterminal IO;
fragmented refunds/partialtails/forbiddenframes/overrefund; exact/exhausted
read/byte/frame budgets/terminalprobe; timeout/WANT/otherexceptions/no retry;
canonical active composition singlebegin/finish and retained debt. Earn positive
facts through serialized accepted fixtures/codecs, not manual oracle mutation.
Normal/-O focused tests and new native-closure inert inventory check required.
No repeat existing S46/all40 suites absent concrete changed gap.

Before code: freeze S46/current19926source+evidencefiles, c2all809packetfiles,
c3currentpublishedsixfiles and119/118/113/42 closure. Afterward prove unchanged.
Future nativehelper source is separate from preserved pureS46. Preserve every
original/failure/intermediate source and exact command/stdout/stderr/status
before runs; no fabricated missinghistory. Evidence scripts are guarded/inert
on import/empty/foreignCLI; test mains use explicit check flag and a standalone
__name__ guard compatible with source AST rules. Report <=1200wordspreferred
with machine/raw references, exactfiles/hashes/commands/results/limits, no
unrunclaims. Return concise DONE|DONE_WITH_CONCERNS|NEEDS_CONTEXT|BLOCKED/path.

Every dependent Python shell: set-e, PYTHONDONTWRITEBYTECODE=1, pinned
/home/codespace/.python/current/bin/python3 -B -S
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py
--restore NEW_ABSOLUTE_RECEIPT immediately before operation SAMEshell.
All directPython includingedits pinned-B-S, SHA
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
Exact PYTHONPATH:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native
Read actual AGENTS/CODING_CONVENTION and relevant specialist/narrow skills.
Graphify before NEW codebasequestions; supplied exact source/archiveref paths
already located. Graphify with PYTHONPATH=.uwz-work/tools/graphify and
PYTHONDONTWRITEBYTECODE=1 .uwz-work/tools/graphify/bin/graphify query QUESTION
--budget 650. Known genericDoD reference drift is documented, not a skill
dependency blocker; no gate waiver. Do not edit skills or frozen instructions.
