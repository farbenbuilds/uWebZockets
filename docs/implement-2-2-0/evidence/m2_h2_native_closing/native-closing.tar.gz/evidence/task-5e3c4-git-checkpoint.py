import hashlib
import json
import subprocess
import sys
from pathlib import Path


def git(arguments):
    result = subprocess.run(['git'] + arguments, capture_output=True, check=True)
    if result.stderr:
        raise ValueError('Unexpected Git audit diagnostics')
    return result.stdout


def verify_blobs(files, prefix):
    for name, row in files.items():
        data = git(['show', prefix + ':' + name])
        if len(data) != row['size'] or hashlib.sha256(data).hexdigest() != row['sha256']:
            raise ValueError('Reviewed Git blob differs: ' + name)


def main(arguments):
    if arguments not in (['--stage-audit'], ['--post-audit']):
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    files = json.loads((plan / 'task-5e3c4-root-publication-audit.json').read_text())['delivery_files']
    if len(files) != 6 or git(['branch', '--show-current']).decode().strip() != 'feat/implement-2-2-0':
        raise ValueError('Branch or six-file scope differs')
    for name, row in files.items():
        data = Path(name).read_bytes()
        if len(data) != row['size'] or hashlib.sha256(data).hexdigest() != row['sha256']:
            raise ValueError('Reviewed working file differs')
    base = '8a6e568524c16e441f753ad08f7ec29886c737c5'
    head = git(['rev-parse', 'HEAD']).decode().strip()
    if arguments == ['--stage-audit']:
        if head != base or set(git(['diff', '--cached', '--name-only']).decode().splitlines()) != set(files):
            raise ValueError('Base or index scope differs')
        verify_blobs(files, '')
        mode = 'stage'
    else:
        if git(['status', '--porcelain']) or head != git(['rev-parse', 'fork/feat/implement-2-2-0']).decode().strip():
            raise ValueError('Commit is not clean and pushed')
        if git(['rev-parse', 'HEAD^']).decode().strip() != base:
            raise ValueError('Unexpected commit parent')
        verify_blobs(files, 'HEAD')
        mode = 'commit'
    result = dict(head=head, branch='feat/implement-2-2-0', reviewed_files=files,
                  exact_reviewed_bytes=True, mode=mode, native_executed=False, milestone_complete=False)
    (plan / ('task-5e3c4-root-' + mode + '-audit.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'head': head, 'mode': mode, 'exact_reviewed_files': len(files)}))


if __name__ == '__main__':
    main(sys.argv[1:])
