**DONE_WITH_CONCERNS — source-only implementation complete; independent Root review remains.** No commits, publication, target execution, compiler, server, socket, SSLContext, real clock, installation or network operations were performed. No old S46/all40 suites were rerun.

`N` below denotes `.uwz-work/evidence/h2-streaming/combined-native/`. The only implementation files added are `native_closing.py`, `test_native_closing.py`, and the separate `test_native_imports.py`. `N/evidence/` contains bounded preservation/audit helpers, run controls, snapshots and raw results. Pure S46 and its import inventory remain unchanged.

The original receive callback is installed before ordinary traffic, wrapped once, and bound to the exact observer object once. Caller-owned state keeps separate lifetime primitive attempts, primitive returns, boundary returns, nonempty returns and bytes. Only the actual `recv(8192)` call is caught for provenance; its exact exception object is retained locally and bare-rethrown through the unchanged oracle. Preparation, clock-after-bytes, canonical parser and passive postprocessing exceptions cannot qualify. The guarded original send callback also prevents postterminal provider I/O from preserving a stale local verdict.

The signal-entry checkpoint freezes prefix facts and independent counter baselines. Activation requires matching context/connection/observer, unchanged prefix/counts/debts, validated supplied signal evidence, and the already established canonical post-signal begin state. The helper never begins or finishes termination. Nonempty accepted reads pass once through existing `wire.accept`, preserving canonical accounting, frame and refund checks. Terminal receipts explicitly carry phase, supplied child-readiness ticks, timing, counts, first oracle failure, tails and actual remaining debt: `local_transport_only`, `complete_wire_proof=False`, `authenticated_close_notify=not_established`, discarded/internal plaintext `unknown`.

Root's accepted [readiness scope ruling](task-5e3c4-ready-scope-report.md) corrected an overstrict initial expectation: readiness is child-scoped, with no separate first-connection-I/O15 timer. Explicit observed `ready_start`/`ready_at` and the original ready deadline are retained. Later cases may start after that deadline. No timestamps are reconstructed and case/whole/grace deadlines are not restarted. The initial stricter implementation/tests remain qualified historical evidence.

Final source SHA256:

| File under N | SHA256 |
| --- | --- |
| `native_closing.py` | `7c42cd04d5aba362b6b381b2d31e3feb07654de690159764dd0b7bae600d1007` |
| `test_native_closing.py` | `dd942f50e0b2c03c9ccf8fef5de11599849350fe388c75221d266005dc8e12c1` |
| `test_native_imports.py` | `6dcdc45b4b55ea1a3015c1ca7cb23d86ce3c3a598f7258377f6390ed9c32af06` |

Every Python run used pinned `/home/codespace/.python/current/bin/python3 -B -S`, SHA256 `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`, the exact six-part PYTHONPATH, `PYTHONDONTWRITEBYTECODE=1`, and a fresh restorer receipt immediately before execution in the same shell. `N/evidence/run.sh` and each retained `runner.sh` record those complete settings. Final executions, all exit0:

```sh
N=.uwz-work/evidence/h2-streaming/combined-native
sh "$N/evidence/run.sh" --run final-ready-normal "$N/test_native_closing.py" --check
sh "$N/evidence/run.sh" --run final-ready-optimized -O "$N/test_native_closing.py" --check
sh "$N/evidence/run.sh" --run final-ready-inert "$N/test_native_imports.py" --check
sh "$N/evidence/run.sh" --run final-ready-inert-optimized -O "$N/test_native_imports.py" --check
sh "$N/evidence/run.sh" --run final-ready-preservation "$N/evidence/preserve.py" --after
sh "$N/evidence/run.sh" --run final-ready-directories "$N/evidence/preserve.py" --directories-after
sh "$N/evidence/run.sh" --run final-audit "$N/evidence/audit.py" --audit
```

Normal Python optimization0 and `-O` optimization1 produced the same focused results. Each run directory contains exact arguments, stdout, stderr, status, restoration receipt and source snapshots. `N/evidence/audit.json` binds final hashes, canonical module paths/hashes, structural depths, successful source-matched final runs and historical raw records. AST maximum nesting is2 for the helper and3 for both tests; no classes, asserts or module mutable containers were added. Inert checks cover guarded first dependency import, empty/foreign main execution and shared canonical module identity. AST-only graphify update exited0: `No relevant changes; graphify-out left untouched.`

Selected recorded facts (verbatim output is in `N/evidence/final-ready-normal/stdout` and `final-ready-optimized/stdout`):

```text
origin verdicts: [('recv', True), ('prepare', False), ('clock', False), ('parser', False), ('passive', False)]
checkpoint_operation:145; prefix_received:[71,29502,142]
eof closing_delta:[1,1,1,1,0,0]; tls_eof closing_delta:[1,1,0,0,0,0]
tls_eof original_failure:["receive_exception","receive",146,29502,null]
wrap:1, begin:1, finish:1; retained connection/stream debt:32/32
```

Additional checks cover ordinary EOF, same-object exception identity, stale/wrong provenance and observer substitution, prior poison, duplicate/reentrant/postterminal I/O, all12 partial splits, malformed/forbidden frames, canonical overrefund rejection, timeout/WANT/other exceptions without retry, overflow, deadline equality/regression, residual budgets and terminal-only probes. `terminal-tail-controls/` separately rejects all12 actual-recv TLS EOF partial tails. High4096-frame/65536-byte tests explicitly inject numeric boundary counters; they do not claim that traffic was earned. Independently serialized64 refunds/832 bytes exhaust actual held debt64, and refund65 fails.

API-absence RED is separate from real type-only wrong-origin RED. Busy-counter cleanup, equal-valued observer substitution, and later-case readiness rejection have retained behavioral RED/GREEN evidence. Earlier harness failures preserve their source/logs; the exact canonical error expectation and excessive `elif` AST nesting were corrected without weakening checks.

Preservation raw result is `{"c2":809,"c3":6,"closure":118,"codecs":42,"combined":19926,"s46":46}`: initial protected file bytes remain identical, including119 identity entries/113 resolved closure files. Directory membership, including empty directories, matches the explicitly later midpoint boundary:698 combined directories,4 c2 directories and0 descendants in the c3 publication directory.

**Concerns and limits:** the initial successful preservation helper was written in the tool transcript but lacked a separately copied pre-run filesystem snapshot. This is explicitly recorded in `N/evidence/history-notes.md`; no reconstructed snapshot/history is claimed. The directory freeze was later than the initial file freeze. All exercised native implementation/test versions and failure sources are retained. Supplied signal/readiness doubles prove schema/order only. Actual provider/runtime closure, native all40, real process/listener/TLS/cleanup evidence, builds/full project gates, adoption and the full goal remain open.
