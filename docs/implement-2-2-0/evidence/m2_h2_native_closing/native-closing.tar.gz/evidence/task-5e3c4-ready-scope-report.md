**Recommendation: accept the distinction. The inspected combined execution path has child readiness15, but no separate per-connection first-byte15 deadline.** Retain case/whole deadlines for every ordinary I/O operation.

Exact evidence:

- Current `combined-cases/coordinator.py:323`, `run_child(..., whole, ready_duration)`: samples `ready_start`, sets `ready=min(whole, ready_start+ready_duration)`, passes it to `child_factory`, then requires factory return before `ready` (`:324–329`). `ready_duration` is15 seconds in caller units (`:305`).
- The same child then runs multiple cases. Each samples a new `case_start`, calls `cases.deadlines`, then `connect(case, 1, case_deadline, whole)` (`:335–340`). Child readiness is not passed to connections.
- `combined-cases/cases.py:14`, `deadlines(case, now, whole_deadline, units_per_second)`, returns `min(now+case_duration, whole_deadline)`. Canonical `reference/model/catalogue.py:122` gives180 seconds for the two large cases,30 otherwise.
- Canonical `reference/core/output_stage.py:24`, `new_stage(...)`, stores `case_deadline` and `whole_deadline`; there is no readiness/first-byte deadline field. `remaining(stage, now)` at`:158` checks both strictly; `read(stage, data)` at`:163` charges byte/read budgets without a first-read timing branch.
- Initial SETTINGS/ACK collection uses ordinary `adapter.tick`, receive and `adapter.observe` (`coordinator.py:345–348`). `adapter.py:71` and`:89` enforce the stage deadlines and monotonic time.
- `reference/core/wire.py:146` and `raw_observer.py:135` consume bytes and enforce protocol/accounting bounds, without clock or readiness inputs.
- Archived `reference/helper/h2_client.py:137` simply receives; `connect_tls(port, certificate)` at`:179` uses connection timeout30 and socket timeout120. It supplies no first-byte15 contract and must not override the combined deadlines.

All archive references above are members of `combined-all40.tar.gz`.

Minimum state recommendation:

- Retain immutable child-scoped readiness identity, supplied `ready_deadline`, and actual `ready_at` evidence.
- Require readiness succeeded before its deadline; permit subsequent connection initialization/current time after that deadline.
- Keep connection-local monotonic `now`, case/whole deadlines, and later authorized grace deadline. Never restart those deadlines at first receive.
- If storing `ready_start`, use an actually observed timestamp. `child_factory` does **not** receive coordinator’s `ready_start`; do not reconstruct it as `ready_deadline−15`, because whole-deadline clipping breaks that inference.

Source-only regression: timely child readiness followed by a later case must work; readiness at deadline, regressing clocks, and connection I/O at case/whole deadline must fail. No additional first-byte15 field is justified by these clauses. No tests or edits were performed.
