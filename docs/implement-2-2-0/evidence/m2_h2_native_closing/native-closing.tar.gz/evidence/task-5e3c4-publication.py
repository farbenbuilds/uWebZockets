"""Preserve the reviewed source-only closing helper and verify its publication."""
import hashlib
import json
import runpy
import sys
import tarfile
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def published_api(plan, filename):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_combined_input_audit/combined-input-audit.tar.gz')
    if digest(archive.read_bytes()) != '4c4d93bdec76e4b302a38e5811062b48100df0b617f479fe17eac1bdaa6105c8':
        raise ValueError('Published metadata authority differs')
    path = plan / filename
    with tarfile.open(archive, 'r:gz') as stream:
        if stream.extractfile('evidence/' + filename).read() != path.read_bytes():
            raise ValueError('Metadata helper provenance differs')
    return runpy.run_path(str(path))


def references():
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_wire_checkpoint/wire-checkpoint.tar.gz')
    if digest(archive.read_bytes()) != 'cc63b28f8690cbb35fac3ca506ad1e7f12f02909fe5be38e637e16d43a94f5eb':
        raise ValueError('Canonical source authority differs')
    members = {}
    with tarfile.open(archive, 'r:gz') as stream:
        for member in stream:
            if member.name.startswith(('source/current/', 'reference/')) and member.isfile():
                name = member.name.replace('source/current/', 'reference/combined/', 1)
                members[name] = stream.extractfile(member).read()
    return members


def local_members(plan, source):
    members = {}
    for path in sorted(source.rglob('*')):
        if path.is_symlink():
            raise ValueError('Native packet symlink')
        if path.is_file():
            members['native/' + path.relative_to(source).as_posix()] = path.read_bytes()
    names = ('task-5e3c4-brief.md', 'task-5e3c4-report.md', 'task-5e3c4-plan-report.md',
             'task-5e3c4-plan-addendum.md', 'task-5e3c4-ready-scope-report.md',
             'task-5e3c4-review-report.md', 'task-5e3c4-review-package.diff',
             'task-5e3c4-root-audit.py', 'task-5e3c4-prepare-review.py',
             'task-5e3c4-publication.py', 'task-5e3c4-git-checkpoint.py', 'task-5e3c4-review-inputs.json',
             'task-5e3c4-root-final-audit.json', 'task-5e3c4-root-final-audit.stdout',
             'task-5e3c4-root-final-audit.stderr', 'task-5e3c4-root-final-audit.exit',
             'task-5e3c4-root-final-audit-inputs.json', 'task-5e3c4-review-resume-inputs.json',
             'task-5e3c-terminal-contract-report.md', 'task-5e3c-terminal-doubt-artifact.md',
             'task-5e3c-terminal-doubt-report.md', 'task-5e3b8a-restore-inputs.py')
    for name in names:
        members['evidence/' + name] = (plan / name).read_bytes()
    for label in ('fmt', 'conventions', 'version', 'docs', 'dependencies', 'dependencies-network', 'graph'):
        for suffix in ('stdout', 'stderr', 'exit'):
            name = 'task-5e3c4-root-' + label + '.' + suffix
            members['evidence/' + name] = (plan / name).read_bytes()
    return members


def source_inventory(source, plan):
    reviewed = json.loads((plan / 'task-5e3c4-review-inputs.json').read_text())
    expected = {Path(row['path']).name: row for row in reviewed if Path(row['path']).parent == source.resolve()}
    actual = {}
    for path in sorted(source.glob('*.py')):
        data = path.read_bytes()
        row = expected[path.name]
        if len(data) != row['size'] or digest(data) != row['sha256']:
            raise ValueError('Reviewed native bytes changed')
        actual[path.name] = {'size': len(data), 'sha256': digest(data)}
    if len(actual) != 3 or set(expected) != set(actual):
        raise ValueError('Native source coverage differs')
    return actual


def build(plan, source, folder):
    api = published_api(plan, 'task-5e3c1-build-publication.py')
    members = {}
    for name, data in dict(references(), **local_members(plan, source)).items():
        api['add'](members, name, data, {})
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'native-closing.tar.gz'
    inventory = api['write_archive'](archive, members)
    preservation = json.loads((plan / 'task-5e3c4-root-final-audit.json').read_text())
    manifest = dict(scope='Private receive provenance and bounded local closing receipt; source-only',
                    base_commit='8a6e568524c16e441f753ad08f7ec29886c737c5',
                    archive=archive.name, archive_bytes=archive.stat().st_size,
                    archive_sha256=digest(archive.read_bytes()),
                    safe_regular_utf8_members=len(members) + 1, inventory_entries=len(inventory),
                    current_native_sources=source_inventory(source, plan),
                    native_packet_files=sum(name.startswith('native/') for name in members),
                    reference_files=sum(name.startswith('reference/') for name in members),
                    root_evidence_files=sum(name.startswith('evidence/') for name in members),
                    scope_of_terminal='local_transport_only', complete_wire_proof=False,
                    authenticated_close_notify='not_established', internal_or_discarded_plaintext='unknown',
                    readiness_scope='Observed child readiness once; no per-connection first-byte ready deadline',
                    closing_bounds=dict(read_bytes=8192, returned_bytes=65536, frames=4096),
                    actual_serialized_refund_limit=dict(frames=64, bytes=832, next_refund_rejected=True),
                    injected_policy_boundary_tests='4096 frames and 65536 bytes are counter-injection controls',
                    historical_limits=['Initial successful preservation helper lacks a separate pre-run snapshot',
                                       'Directory preservation starts at a later midpoint than file preservation',
                                       'Initial context-only console retention is incomplete'],
                    preservation=preservation, source_review='Verbatim evidence/task-5e3c4-review-report.md',
                    native_compiled=False, native_executed=False, milestone_complete=False)
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({key: manifest[key] for key in ('archive_sha256', 'archive_bytes',
                     'safe_regular_utf8_members', 'native_packet_files', 'reference_files', 'root_evidence_files')}))


def audit(plan, source, folder):
    api = published_api(plan, 'task-5e3c1-publication-audit.py')
    manifest = json.loads((folder / 'manifest.json').read_text())
    archive = folder / manifest['archive']
    if archive.stat().st_size != manifest['archive_bytes'] or digest(archive.read_bytes()) != manifest['archive_sha256']:
        raise ValueError('Archive identity differs')
    contents = api['read_archive'](archive)
    expected = dict(references(), **local_members(plan, source))
    if contents != expected or len(contents) != manifest['inventory_entries']:
        raise ValueError('Whole archive coverage differs')
    for data in contents.values():
        data.decode('utf-8')
    if len(contents) + 1 != manifest['safe_regular_utf8_members']:
        raise ValueError('Archive member count differs')
    if source_inventory(source, plan) != manifest['current_native_sources']:
        raise ValueError('Reviewed source inventory differs')
    check = runpy.run_path(str(plan / 'task-5e3c1-prepare-review.py'))['root_check']
    helpers = {name: check((plan / name).resolve()) for name in (
        'task-5e3c4-root-audit.py', 'task-5e3c4-prepare-review.py',
        'task-5e3c4-publication.py', 'task-5e3c4-git-checkpoint.py')}
    docs = Path('docs/implement-2-2-0')
    files = [docs / 'README.md', docs / 'm2_request_streaming.md', docs / 'm2_h2_native_closing.md',
             folder / 'README.md', folder / 'manifest.json', archive]
    result = dict(archive_sha256=digest(archive.read_bytes()), archive_bytes=archive.stat().st_size,
                  inventory_entries=len(contents), safe_regular_utf8_members=len(contents) + 1,
                  helpers=helpers, local_links_checked=api['verify_links'](files),
                  delivery_files={str(path): {'size': path.stat().st_size, 'sha256': digest(path.read_bytes())} for path in files},
                  native_executed=False, milestone_complete=False)
    (plan / 'task-5e3c4-root-publication-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('helpers', 'delivery_files')}))


def main(arguments):
    if arguments not in (['--build'], ['--audit']):
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/combined-native')
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_native_closing')
    if arguments == ['--build']:
        build(plan, source, folder)
        return
    audit(plan, source, folder)


if __name__ == '__main__':
    main(sys.argv[1:])
