import difflib
import hashlib
import json
import sys
from pathlib import Path


def main(arguments):
    if arguments != ['--prepare']:
        return
    root = Path('/workspaces/uWebZockets')
    plan = root / '.superpowers/sdd/h2_streaming_plan'
    source = root / '.uwz-work/evidence/h2-streaming/combined-native'
    names = ('test_native_closing.py', 'test_native_imports.py', 'native_closing.py')
    paths = [source / name for name in names]
    paths.extend(sorted((source / 'evidence').glob('*.py')))
    paths.extend(sorted((source / 'evidence').glob('*.sh')))
    paths.extend((plan / 'task-5e3c4-root-audit.py', Path(__file__)))
    parts = ['# C4 source-only review; additions against 6bd6d04\n',
             'Current HEAD 8a6e568 adds HANDOFF.md only. No native execution claimed.\n']
    inventory = []
    for path in paths:
        data = path.read_bytes()
        inventory.append({'path': str(path), 'size': len(data),
                          'sha256': hashlib.sha256(data).hexdigest()})
        parts.extend(difflib.unified_diff([], data.decode('utf-8').splitlines(True),
                     fromfile='/dev/null', tofile=str(path), n=10))
    parts.extend(['\n# Root preservation result\n',
                  (plan / 'task-5e3c4-root-final-audit.json').read_text()])
    package = plan / 'task-5e3c4-review-package.diff'
    package.write_text(''.join(parts))
    (plan / 'task-5e3c4-review-inputs.json').write_text(json.dumps(inventory, indent=2) + '\n')
    print(json.dumps({'package': str(package), 'bytes': package.stat().st_size,
                      'sha256': hashlib.sha256(package.read_bytes()).hexdigest(),
                      'source_files': len(inventory)}))


if __name__ == '__main__':
    main(sys.argv[1:])
