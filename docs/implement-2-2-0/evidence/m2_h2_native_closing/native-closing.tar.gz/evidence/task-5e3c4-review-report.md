# C4 independent source-only review

**Spec compliant. Task quality: Approved.**

No actionable findings in the reviewed slice. This verdict approves the source-only receive/provenance/closing helper and its focused evidence; it does not approve native execution, whole-run acceptance, publication contents, or milestone completion.

## Scope and method

Reviewed `task-5e3c4-review-package.diff` once, tests first, against the brief, plan, addendum, terminal contract, and superseding child-readiness ruling. Read project conventions, reviewer and relevant transport/TLS/HTTP/verification instructions, and applied `code-review-and-quality` plus the requested `thermo-nuclear-code-quality-review` lens with the AGENTS.md override. Focused canonical reads checked observer exception handling and canonical closing-frame/read-budget enforcement. Graphify was queried before that additional codebase question.

The reviewed implementation remains confined to the three new native source files and evidence/review helpers. `git diff --stat 6bd6d04 HEAD` showed only the separately identified HANDOFF.md addition. The untracked publication document being prepared by Root was outside this review. No source, index, HEAD, or existing evidence was changed by this reviewer. No suites, compiler, target, socket, TLSContext, network, installation, or real-clock operations were run.

## Correctness and ownership assessment

The installed receive callback is bound before traffic, wrapped once, and checked against the exact observer and callback identities. Primitive attempts, primitive returns, successful boundary returns, nonempty returns, and returned bytes have distinct lifetime counters and frozen baselines. Only the actual receive call records exception-origin provenance; preparation, clock, canonical parser, and passive-postprocessing failures cannot qualify as terminal TLS EOF.

Checkpoint and activation enforce connection/context identity, unchanged operation/count/debt boundaries, canonical final state, supplied signal schema, and single activation. The corrected implementation retains child readiness evidence while allowing later cases and ordinary I/O after the child readiness deadline. Case, whole, and grace deadlines remain bounded and monotonic.

Closing data passes through the original observer and one canonical `wire.accept` call. Canonical begin/finish remain handler-owned. Existing raw and request-credit validation enforce frame restrictions, residual budgets, and overrefund rejection. The terminal-only probe grants no extra positive-data allowance. Known tails reject; unpaid debt remains recorded. TLS EOF preserves original observer poison and cannot produce an ordinary sealed proof. Receipts state the local scope and unknown plaintext limitation, and guarded postterminal I/O invalidates subsequent `local_receipt` access.

The structural pass found no actionable duplication, unnecessary forwarding layer, shared-code growth, or file-size regression. The helper is 394 lines; its lifecycle/provenance guards enforce distinct contract boundaries. No project gate, pin, product behavior, or accepted pure source was modified by this implementation diff.

## Evidence checked

Independently computed current SHA256 values match the report:

- `native_closing.py`: `7c42cd04d5aba362b6b381b2d31e3feb07654de690159764dd0b7bae600d1007`
- `test_native_closing.py`: `dd942f50e0b2c03c9ccf8fef5de11599849350fe388c75221d266005dc8e12c1`
- `test_native_imports.py`: `6dcdc45b4b55ea1a3015c1ca7cb23d86ce3c3a598f7258377f6390ed9c32af06`

Byte comparisons confirmed all three current files match snapshots in final-ready normal, optimized, inert, and optimized-inert runs. Their recorded statuses are zero and stderr files empty. Normal and optimized stdout match. Reviewed raw results establish the five-origin distinction, exact lifecycle counts, retained debt, strict bounds, and child-readiness behavior. Retained origin RED output demonstrates erroneous preparation-origin acceptance; readiness RED demonstrates actual rejection of a later case. Separate actual-receive TLS EOF controls cover all twelve partial-tail splits.

Reviewed preservation/audit code and Root's final audit result. Before/after file manifests and midpoint/after directory manifests compare equal. The Root audit reconstructs protected source/packet expectations from prior authorities and checks their current bytes; its recorded counts are 46 modules, 19,926 combined files, 809 packet files, six prior publication files, 119 identity entries, 118 closure rows, 113 resolved files, and 42 codec rows. This reviewer did not rerun that large audit.

## Verification gaps and limits

- The initial successful preservation helper lacks a separate pre-run filesystem source snapshot. The directory inventory establishes only the later midpoint boundary. Current comparisons and the independently structured Root audit cannot reconstruct missing earlier history; the implementation report and history notes disclose this accurately.
- Saved execution evidence was inspected and source-matched, not independently rerun. Existing suites were deliberately not repeated under this assignment.
- The 4,096-frame and 65,536-byte boundary checks use explicit injected counters. The independently earned serialized maximum is 64 refunds and 832 bytes, matching the actual held debt; this is not a measured high-volume closing run.
- Signal/readiness evidence is supplied by scripted doubles. Real provider/runtime closure, process ownership, TLS behavior, listener/signal/capture/exit/reap/cleanup proof, native all40, builds, full project gates, and adoption remain unverified and outside this slice. No gate waiver or complete-wire/authenticated-close claim follows from this approval.
