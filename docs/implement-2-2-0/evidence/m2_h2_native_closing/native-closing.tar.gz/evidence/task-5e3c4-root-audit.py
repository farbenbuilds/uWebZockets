"""Independently preserve all accepted pure sources and prior packet bytes."""
import ast
import hashlib
import json
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_authority(folder, expected):
    manifest = json.loads((folder / 'manifest.json').read_text())
    archive = folder / manifest['archive']
    if manifest['archive_sha256'] != expected or sha(archive.read_bytes()) != expected:
        raise ValueError('Pushed authority archive differs')
    with tarfile.open(archive, 'r:gz') as stream:
        inventory = json.loads(stream.extractfile('INVENTORY.json').read())
    return manifest, archive, inventory


def preserve_s46():
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_wire_checkpoint')
    manifest, archive, inventory = read_authority(folder, 'cc63b28f8690cbb35fac3ca506ad1e7f12f02909fe5be38e637e16d43a94f5eb')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    before = json.loads(Path('.uwz-work/evidence/h2-streaming/combined-interface-audit/before.json').read_text())
    expected = {Path(row['path']).relative_to(source.resolve()).as_posix(): dict(size=row['bytes'], sha256=row['sha256']) for row in before['combined_files']}
    for name in manifest['current_source_files']:
        expected[name] = inventory['source/current/' + name]
    add_raw(expected, inventory)
    actual = {path.relative_to(source).as_posix() for path in source.rglob('*') if path.is_file()}
    if len(expected) != 19926 or actual != expected.keys():
        raise ValueError('Accepted pure source/evidence path set differs')
    verify_tree(source, expected)
    return dict(modules=46, source_and_evidence_files=19926, all_accepted_bytes_unchanged=True)


def add_raw(expected, inventory):
    for name, row in inventory.items():
        if name.startswith('raw/wire-checkpoint/'):
            expected['evidence/wire-checkpoint/' + name.removeprefix('raw/wire-checkpoint/')] = row


def verify_tree(root, expected):
    for name, row in expected.items():
        data = (root / name).read_bytes()
        if len(data) != row['size'] or sha(data) != row['sha256']:
            raise ValueError('Protected bytes differ: ' + str(root / name))


def preserve_c2():
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_native_source_preparation')
    manifest, archive, inventory = read_authority(folder, '3c6d55ddc6a9d58445d1635a79186135f230c476eaba97257685649f7481e7de')
    expected = {name.removeprefix('packet/'): row for name, row in inventory.items() if name.startswith('packet/')}
    expected.update({name.removeprefix('packet/'): row for name, row in manifest['external_packet_members'].items()})
    root = Path('.uwz-work/evidence/h2-streaming/native-input-preparation')
    actual = {path.relative_to(root).as_posix() for path in root.rglob('*') if path.is_file()}
    if len(expected) != 809 or actual != expected.keys():
        raise ValueError('C2 packet path set changed')
    verify_tree(root, expected)
    return dict(packet_files=809, all_bytes_unchanged=True)


def preserve_closure():
    before = json.loads(Path('.uwz-work/evidence/h2-streaming/combined-interface-audit/before.json').read_text())
    rows = before['closure_rows']
    resolved = {Path(row['path']).resolve(strict=True) for row in rows}
    if before['identity_entries'] != 119 or len(rows) != 118 or len(resolved) != 113 or len(before['codec_rows']) != 42:
        raise ValueError('Input closure counts differ')
    for row in rows + before['codec_rows'] + [before['authority']]:
        data = Path(row['path']).read_bytes()
        if len(data) != row['bytes'] or sha(data) != row['sha256']:
            raise ValueError('Canonical input bytes changed')
    return dict(identity_entries=119, physical_rows=118, resolved_files=113, ordered_codecs=42)


def preserve_delivery():
    audit = json.loads(Path('.superpowers/sdd/h2_streaming_plan/task-5e3c3-root-commit-audit.json').read_text())
    if audit['head'] != '6bd6d0494ead541636c8ff23d465c7f78e897b38' or len(audit['reviewed_files']) != 6:
        raise ValueError('C3 delivery authority differs')
    for name, row in audit['reviewed_files'].items():
        if Path(name).stat().st_size != row['size'] or sha(Path(name).read_bytes()) != row['sha256']:
            raise ValueError('Accepted C3 publication changed')
    return 6


def nesting(node, depth=0):
    controls = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.With, ast.AsyncWith, ast.Try, ast.TryStar, ast.Match)
    level = depth + int(isinstance(node, controls))
    return max([level] + [nesting(child, level) for child in ast.iter_child_nodes(node)])


def native_sources():
    root = Path('.uwz-work/evidence/h2-streaming/combined-native')
    result = {}
    for path in root.glob('*.py'):
        data = path.read_bytes()
        tree = ast.parse(data)
        if nesting(tree) > 3 or any(isinstance(node, (ast.ClassDef, ast.Assert, ast.Global, ast.Nonlocal)) for node in ast.walk(tree)):
            raise ValueError('New native helper structure differs: ' + path.name)
        result[path.name] = dict(size=len(data), sha256=sha(data), maximum_nesting=nesting(tree))
    if 'native_closing.py' not in result or 'test_native_closing.py' not in result or len(result) < 3:
        raise ValueError('Native helper inventory incomplete')
    return result


def main(argv):
    if argv != ['--audit']:
        return
    result = dict(pure_source=preserve_s46(), c2=preserve_c2(), closure=preserve_closure(),
                  preserved_publication_files=preserve_delivery(), native_sources=native_sources(),
                  native_executed=False, milestone_complete=False)
    Path('.superpowers/sdd/h2_streaming_plan/task-5e3c4-root-final-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'native_sources'}, indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
