"""Deterministic serialized native closing seam checks; no native transport."""
import copy
import ssl
import sys
from functools import partial
from unittest import mock
import adapter
import catalogue
import coordinator
import model
import shutdown_cases
import test_all40_descriptors as descriptors
import test_core_peer
import test_shutdown
import test_wire_oracle as oracle
import test_wire_oracle_checks as packets
import native_closing as native
import wire


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def raises(callback, expected, message=None):
    try:
        callback()
    except expected as error:
        require(message is None or message in str(error), 'wrong rejection: ' + str(error))
        return error
    raise RuntimeError('missing rejection')


def fixture(chunks=(), *, origin=None, original=None, control=None, drain=True):
    script = dict(tick=2, chunks=list(chunks) + [b''], calls=0, prepared=0, close=False,
                  received=False, result=None, original=original, origin=origin, signal=None)

    def clock():
        if script['close'] and script['received'] and origin == 'clock':
            raise original
        return script['tick']

    app = test_core_peer.new_app()
    peer = test_shutdown.new_peer('shutdown_active', app=app, prior=(), now=2, clock=clock)
    peer_receive, peer_send = peer['connection']['receive'], peer['connection']['send']
    state = native.new_receive_state((7, 'shutdown_active', 1), 2, 1000, (1, 15001, 2, 30002, 1, 900001))

    def prepare(deadline):
        script['prepared'] += 1
        require(deadline == state['deadline'], 'prepare lost caller ticks')
        if script['close'] and origin == 'prepare':
            raise original

    def recv(size):
        require(size == 8192, 'primitive read bound changed')
        script['calls'] += 1
        if not script['close']:
            return peer_receive()[0]
        script['received'] = True
        if origin == 'recv':
            raise original
        value = script['chunks'].pop(0)
        if isinstance(value, BaseException):
            raise value
        return value

    binding = (prepare, recv, clock)
    original_connection = dict(peer['connection'], receive=partial(native.receive_once, state, binding),
                               send=partial(native.send_once, state, peer_send))
    connection, observer = oracle.wrap_connection(original_connection, descriptors.connection_descriptor(7, 'shutdown_active', 1, final=True))
    native.bind_observer(state, original_connection, connection, observer)
    script.update(state=state, observer=observer, connection=connection, original_connection=original_connection,
                  binding=binding, app=app, peer=peer)
    context = adapter.open_case('shutdown_active', connection['protocol'], connection['send'], 2, 30002, 900001, clock=clock)
    script['context'] = context
    data, tick = connection['receive']()
    adapter.observe(context, data, tick)

    def signal(current, deadline):
        native.freeze_checkpoint(current, connection, observer, state, deadline)
        script['before'] = (coordinator.snapshot_counts(current), tuple(state['counts'].values()))
        peer['state']['signal'] = True
        app['records']['shutdown_active'].update(cancels=1, active=False, paused=False, reason='shutdown')
        script['signal'] = dict(signal='SIGTERM', owned_identity=True, watcher_installed=True, client_open=True)
        return script['signal']

    def terminate(current, deadline):
        script.update(close=True, deadline=deadline)
        if control is not None:
            control(script, 'before_activate')
        native.activate(current, connection, observer, state, script['signal'], deadline)
        if control is not None:
            control(script, 'activated')
        if not drain:
            raise StopIteration('captured canonical begin')
        result, receipt = native.drain_closing(current, connection['receive'], observer, state, deadline)
        script['result'], script['receipt'] = result, receipt
        return result

    def post(current, deadline):
        return dict(records=copy.deepcopy(app['records']), metrics=test_core_peer.metrics(app),
                    outputs=copy.deepcopy(app['outputs']), binding=model.default_binding())

    hooks = dict(preconditions=lambda current: dict(client_open=True, prior_complete=True), signal=signal,
                 termination=terminate, process=lambda current, deadline: dict(exit_code=0, reaped=True, forced=False,
                 run_ok=True, deinit_ok=True, key_removed=True), post=post, units_per_second=1000)
    script['hooks'] = hooks
    return script


def run(script):
    context = script['context']
    adapter.run_case(context, script['connection']['receive'], shutdown=script['hooks'])
    return script


def active(chunks=(), **kwargs):
    script = fixture(chunks, drain=False, **kwargs)
    error = raises(lambda: run(script), StopIteration)
    require(str(error) == 'captured canonical begin', 'fixture stopped at wrong boundary')
    return script


def drain(script):
    return native.drain_closing(script['context'], script['connection']['receive'], script['observer'],
                                script['state'], script['deadline'])


def fail_same(error, *args, **kwargs):
    raise error


def check_origins():
    original = ssl.SSLEOFError(8, 'same object at every origin')
    verdicts = []
    for origin in ('recv', 'prepare', 'clock', 'parser', 'passive'):
        script = active((packets.credit_packet(1),), origin=origin, original=original)
        module, name = (wire, 'accept') if origin == 'parser' else (oracle, 'feed')
        callback = partial(fail_same, original) if origin in ('parser', 'passive') else getattr(module, name)
        try:
            with mock.patch.object(module, name, callback):
                facts, receipt = drain(script)
        except BaseException as error:
            verdicts.append((origin, False))
            require(origin != 'recv', 'actual primitive EOF rejected: ' + repr(error))
            require(error is original or origin == 'passive' and isinstance(error, ValueError), 'wrong-origin identity lost')
            require(script['state']['failure'] is not None, 'failure did not invalidate local verdict')
            continue
        verdicts.append((origin, True))
        if origin != 'recv':
            continue
        require(facts['outcome'] == 'tls_eof' and receipt[-4:] == ('local_transport_only', False, 'not_established', 'unknown'), 'TLS receipt scope lost')
        require(oracle.failure(script['observer'])[0] == 'receive_exception', 'original poison cleared')
        raises(lambda: oracle.seal(script['observer']), ValueError, 'oracle_unsealed')
        require(script['state']['provenance'][-1] is original, 'actual exception identity lost')
    print('origin verdicts:', verdicts)
    require(verdicts == [(name, name == 'recv') for name in ('recv', 'prepare', 'clock', 'parser', 'passive')], 'type-only accepted wrong-origin SSLEOFError')
    print('same-object actual recv / prepare / clock-after-bytes / canonical parser / passive postprocessing origin matrix passed')


def check_success():
    packet = packets.credit_packet(7) + packets.credit_packet(11, 3)
    script = run(fixture((packet[:1], packet[1:10], packet[10:])))
    state, context, observer = script['state'], script['context'], script['observer']
    receipt = native.local_receipt(state)
    require(receipt is script['receipt'] and receipt[0][0][11:14] == (32, 32, (3,)), 'frozen prefix lost')
    require(context['request']['connection_debt'] == 25 and context['request']['stream_debt_total'] == 21, 'abandoned debt changed')
    require(context['raw']['closed'] and context['request']['transport_closed'] and not context['records'], 'handler did not finish canonical transport')
    require(context['raw']['closing']['frames'] == 2 and context['raw']['closing']['bytes'] == 26, 'canonical charge duplicated')
    require(state['counts']['attempts'] == state['counts']['returns'] == state['counts']['boundary_returns'], 'successful lifetime counts differ')
    require(state['counts']['nonempty'] + 1 == state['counts']['returns'], 'empty boundary not counted separately')
    require(state['baseline'][0] > 1 and observer['checkpointed'] and not observer['sealed'], 'ordinary traffic or checkpoint missing')
    require(state['phase'] == 'terminal' and state['failure'] is None, 'healthy local lifecycle differs')
    before = script['calls']
    raises(script['connection']['receive'], ValueError, 'provider_io_closed')
    require(script['calls'] == before, 'terminal performed primitive retry')
    raises(lambda: native.local_receipt(state), ValueError, 'local_receipt_invalid')
    print('serialized ordinary startup/final collection, single canonical begin/finish, fragmented refunds, exact counters, retained debt and stale receipt invalidation passed')


def main(argv):
    if argv == ['--check-api']:
        require(callable(native.receive_once), 'missing native receive API')
    elif argv == ['--check-origins']:
        check_origins()
    elif argv == ['--check']:
        check_origins()
        check_success()


if __name__ == '__main__':
    main(sys.argv[1:])
