"""Explicit independent metadata/concurrency serialized proofs."""
import copy
import json
import catalogue
import hpack
import wire
import credit_cases
import concurrent_cases
import pause_cases
from pathlib import Path
import sys
import adapter
import model
import test_metadata_concurrency as peer
from test_core_peer import frame, new_app, require


def constructor():
    app = new_app()
    before = copy.deepcopy(app)

    def no_clock():
        raise RuntimeError('constructor called clock')

    result = peer.new_peer('metadata_helpers', app=app, prior=(), now=1, clock=no_clock, final=True)
    require(set(result) == {'connection', 'state'}, 'peer shape differs')
    require(set(result['connection']) == {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'}, 'connection shape differs')
    require(app == before, 'constructor changed app')
    print('constructor inert; canonical app; startup queued')


def startup_bound(driver):
    original = adapter.open_case

    def open_case(case, protocol, send, *args, **kwargs):
        try:
            send(b'x' * 8193)
        except ValueError as exc:
            require(str(exc) == 'send span differs', 'wrong startup refusal')
            return original(case, protocol, send, *args, **kwargs)
        raise ValueError('oversized startup accepted')

    adapter.open_case = open_case
    try:
        driver('metadata_helpers')
    finally:
        adapter.open_case = original
    print('oversized startup refused before actual schedule')


def baseline_bounds():
    path = Path(__file__).resolve().parent / 'baseline/test_metadata_concurrency.py.txt'
    namespace = dict(__name__='frozen_baseline')
    exec(compile(path.read_text(), str(path), 'exec'), namespace)
    startup_bound(namespace['check'])


def bounds():
    app, result, _context = open_peer('metadata_helpers')
    state, send = result['state'], result['connection']['send']
    for _ in range(2):
        rejects(lambda: send(b'x' * 8193), 'send span differs')
        rejects(lambda: send((8193).to_bytes(3, 'big') + bytes(6)), 'frame payload bound differs')
        require(not state['buffer'], 'oversize grew parser')
    packet = frame(0, 0, 3, b'x' * 8192)
    send(packet[:8192])
    send(packet[8192:8200])
    before = bytes(state['buffer'])
    for _ in range(2):
        rejects(lambda: send(b'xx'), 'parser storage bound differs')
        require(bytes(state['buffer']) == before and state['max_buffer'] == 8200, 'parser overflow mutated')
    _app, result, _context = open_peer('metadata_helpers')
    state = result['state']
    state['pending'][:] = [b'a' * 8192, b'b' * 8192]
    for _ in range(2):
        rejects(lambda: peer.queue(state, (b'c',)), 'pending storage bound differs')
        require(sum(map(len, state['pending'])) == 16384, 'pending byte overflow')
    state['pending'][:] = [b'a'] * 4
    rejects(lambda: peer.queue(state, (b'c',)), 'pending storage bound differs')
    state['pending'][:] = [b'a' * 8193]
    rejects(result['connection']['receive'], 'pending packet bound differs')
    state['pending'][:] = [b'a']
    state['received'] = state['head_limit'] + 4
    rejects(result['connection']['receive'], 'receive bound differs')
    state['received'] = 0
    state['received_bytes'] = (state['head_limit'] + 4) * 8192
    rejects(result['connection']['receive'], 'receive byte bound differs')
    require(state['pending'] == [b'a'], 'receive cap consumed bytes')
    print('finite parser8201/send8192/frame8192/pending4/16384/receive caps reject before growth')


def final_boundary(peer, context):
    state, stage = peer['state'], context['stage']
    identities = {name: context[name] for name in ('protocol', 'raw', 'request', 'credit', 'records', 'stage')}
    deadlines = stage['case_deadline'], stage['whole_deadline']
    reads, size = stage['reads'], stage['bytes']
    debt = context['request']['connection_debt'], context['request']['stream_debt_total']
    seen = [0, 0]

    def receive():
        result = peer['connection']['receive']()
        require(all(context[name] is value for name, value in identities.items()), 'final changed connection identities')
        require((stage['case_deadline'], stage['whole_deadline']) == deadlines, 'final refreshed deadlines')
        require(stage['reads'] == reads + seen[0] and stage['bytes'] == size + seen[1], 'final reset cumulative receive cap')
        seen[0] += 1
        seen[1] += len(result[0])
        return result

    require(adapter.final_collection(context, receive) is None, 'ordinary final return changed')
    require(state['final_requests'] == stage['final_registered'] == 68 and stage['final_complete'], 'final count differs')
    require((context['request']['connection_debt'], context['request']['stream_debt_total']) == debt, 'final erased debt')
    require(stage['reads'] == reads + seen[0] and stage['bytes'] == size + seen[1], 'final receive accounting')
    require('final_observations' in context, 'missing retained actual final capture')


def retained_supplied_fixture():
    # Explicit historical supplied facts; this does not execute producer_reuse.
    app = new_app()
    app['records'] = model.records(('producer_reuse',), 'before')
    for tag in ('producer_reuse', 'producer_reuse_next'):
        app['records'][tag].update(chunks=1, max_span=32)
    producer = app['outputs']['producer_reuse']
    producer.update(offset=16777313, invocations=2051, attempts=4099, writes=2049, blocked=2050,
                    pending=2050, terminal_attempts=1, terminals=1, checks=2051, after_reuse=1,
                    binding_index=0, binding_generation=7, armed=True, done=True, sha256=model.PRODUCER_HASH)
    app['binding'] = dict(tag='producer_reuse_next', binding_index=0, binding_generation=8)
    app['heads'] = catalogue.case_budget('producer_reuse')['heads']
    copied = copy.deepcopy(app)
    outputs, binding = copied['outputs'], copied['binding']
    supplied, peer, context = open_peer('metadata_helpers', app=copied, prior=('producer_reuse',), final=True, health=False)
    adapter.run_case(context, peer['connection']['receive'])
    final_boundary(peer, context)
    require(supplied is copied and copied['outputs'] is outputs and copied['binding'] is binding, 'retained references replaced')
    require(outputs == app['outputs'] and binding == app['binding'], 'supplied retained output or binding mutated')
    require(app['records']['metadata_helpers']['middleware'] == 0, 'copied application mutated original')
    print('explicit supplied historical producer fixture: copied retained outputs/binding preserved; no prior producer traffic claim')



def hpack_limits():
    for payload in (header_block(((':path', 'a' * 4097),)), b'\x3f\xe2\x1f'):
        app, result, _context = open_peer('metadata_helpers', health=False)
        before = copy.deepcopy(app)
        for _ in range(2):
            try:
                result['connection']['send'](frame(1, 5, 1, payload))
            except hpack.HPACKError:
                require(app == before and result['state']['cursor'] == 0, 'HPACK earned facts')
                continue
            raise ValueError('HPACK overflow accepted')
    print('HPACK table/header-list bounds reject before facts twice')



def receive_error_identity():
    error = RuntimeError('clock failed')
    app = new_app()
    calls = [0]

    def clock():
        calls[0] += 1
        raise error

    result = peer.new_peer('metadata_helpers', app=app, prior=(), now=1, clock=clock)
    connection, state = result['connection'], result['state']
    adapter.open_case('metadata_helpers', connection['protocol'], connection['send'], 1, 30001, 900001, clock=lambda: 2)
    pending = tuple(state['pending'])
    for _ in range(2):
        try:
            connection['receive']()
        except RuntimeError as exc:
            require(exc is error, 'clock error identity lost')
        else:
            raise ValueError('clock error swallowed')
        require(tuple(state['pending']) == pending and state['received'] == state['received_bytes'] == 0,
                'clock failure consumed pending input')
    require(calls == [2], 'clock called more than once per receive')
    print('clock failure preserves exception identity and queued bytes/receipts; constructor never samples clock')

def rejects(action, message=None):
    try:
        action()
    except (ValueError, RuntimeError) as exc:
        require(message is None or str(exc) == message, 'unexpected rejection: ' + str(exc))
        return
    raise ValueError('invalid action accepted')


def open_peer(case, final=False, *, app=None, prior=(), health=True):
    app = new_app() if app is None else app
    result = peer.new_peer(case, app=app, prior=prior, now=1, clock=lambda: 2, final=final)
    connection = result['connection']
    context = adapter.open_case(case, connection['protocol'], connection['send'], 1, 30001, 900001,
                                selected_before=prior, clock=lambda: 2)
    adapter.observe(context, *connection['receive']())
    if health:
        adapter.health(context, connection['receive'])
    return app, result, context


def header_block(entries):
    # Independent malformed probes must not desynchronize the real client's table.
    return hpack.Encoder().encode(tuple((name, value, True) for name, value in entries))


def summary(state):
    counts = tuple(state[key] for key in ('cursor', 'heads', 'statuses', 'statuses_delivered', 'resumed', 'trailers', 'resets', 'final_requests'))
    uploads = tuple((stream, item['tag'], item['count'], item['frames'], item['accepted'], item['ends'], item['terminal'],
                     item['digest'].hexdigest()) for stream, item in state['streams'].items())
    return counts, uploads


def unchanged_refusal(app, result, packet, message):
    before, counts = copy.deepcopy(app), summary(result['state'])
    for _ in range(2):
        rejects(lambda: result['connection']['send'](packet), message)
        require(app == before and summary(result['state']) == counts, 'invalid input earned application/wire facts')


def constructor_rejections():
    changes = ({'case': 'ready_buffered'}, {'case': []}, {'prior': ('metadata_helpers',)}, {'prior': ('unknown',)},
               {'prior': ('concurrent_routes', 'concurrent_routes')}, {'prior': ('concurrent_routes',)}, {'final': 1},
               {'fault': 'unknown'}, {'fault': []}, {'fault': 'reset_first'}, {'now': True}, {'now': -1}, {'clock': None})
    for changed in changes:
        app = new_app()
        before = copy.deepcopy(app)
        args = dict(case='metadata_helpers', app=app, prior=(), now=1, clock=lambda: 2)
        args.update(changed)
        rejects(lambda: peer.new_peer(**args))
        require(app == before, 'invalid constructor changed app')
    for field in ('records', 'heads', 'outputs', 'binding'):
        app = new_app()
        del app[field]
        before = copy.deepcopy(app)
        rejects(lambda: peer.new_peer('concurrent_routes', app=app, prior=(), now=1, clock=lambda: 2), 'app fields differ')
        require(app == before, 'shape refusal mutated application')
    app = new_app()
    app['heads'] = 3
    rejects(lambda: peer.new_peer('metadata_helpers', app=app, prior=(), now=1, clock=lambda: 2), 'prior heads not earned')
    print('constructor rejects malformed case/prior/fault/time/clock/app before effects')


def header_refusals():
    app, result, context = open_peer('metadata_helpers', final=True)
    entries = [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'), (':path', peer.target('metadata_helpers'))]
    entries += peer.expected_headers('metadata_helpers')
    variants = (entries[::-1], entries + [('host', 'localhost')], entries[:-1],
                entries + [('x-trailer-only', 'discarded')], entries[:3] + [(':path', '/wrong')] + entries[4:])
    for changed in variants:
        unchanged_refusal(app, result, frame(1, 4, 3, header_block(changed)), 'upload header multiplicity or target differs')
    unchanged_refusal(app, result, frame(1, 5, 3, header_block(entries)), 'upload header multiplicity or target differs')
    unchanged_refusal(app, result, frame(1, 4, 5, header_block(entries)), 'stream request-order binding differs')
    final = [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', '/status/' + model.BODY_SPECS[0][0])]
    unchanged_refusal(app, result, frame(1, 5, 3, header_block(final)), 'upload header multiplicity or target differs')
    stream = adapter.start(context, 'POST', peer.target('metadata_helpers'), peer.expected_headers('metadata_helpers'), False, True, 4095, held=True)
    require(stream == 3 and app['records']['metadata_helpers']['metadata_begin'] == 1, 'valid metadata not earned')
    print('serialized metadata order/multiplicity/host/target/trailer-only/END/stream and early final rejected twice')


def metadata_transitions():
    case = 'metadata_helpers'
    app, result, context = open_peer(case)
    state, receive = result['state'], result['connection']['receive']
    stream = adapter.start(context, 'POST', peer.target(case), peer.expected_headers(case), False, True, 4095, held=True)
    item = app['records'][case]
    require(item['bytes'] == item['chunks'] == item['ends'] == item['metadata_end'] == item['helpers_end'] == 0 and
            item['sha256'] == model.EMPTY_HASH and item['paused'] and
            item['middleware'] == item['metadata_middleware'] == item['metadata_begin'] == item['helpers_begin'] == 1,
            'metadata HEADERS manufactured terminal facts')
    before = dict(item)
    trailers = frame(1, 5, stream, header_block((('x-h62', 'changed'), ('x-trailer-only', 'discarded'))))
    unchanged_refusal(app, result, trailers, 'trailer ordinal differs')
    first = model.payload_span(32, 0, 16)
    unchanged_refusal(app, result, frame(0, 1, stream, first), 'DATA length END or ordinal differs')
    unchanged_refusal(app, result, frame(0, 0, 5, first), 'DATA stream differs')
    unchanged_refusal(app, result, frame(0, 0, stream, b'x' + first[1:]), 'DATA payload differs')
    adapter.send_data(context, stream, first, False)
    require(item == before and state['streams'][3]['count'] == 16, 'paused DATA changed accepted record')
    unchanged_refusal(app, result, frame(0, 0, stream, model.payload_span(32, 16, 16)), 'DATA delivery barrier differs')
    credit_cases.barrier(context, receive, stream, case)
    adapter.send_data(context, stream, model.payload_span(32, 16, 16), False)
    wrong = frame(1, 5, stream, header_block((('x-h62', 'v62'), ('x-trailer-only', 'discarded'))))
    unchanged_refusal(app, result, wrong, 'trailer fields differ')
    for chunk in wire.send_trailers(context['stage'], stream, [('x-h62', 'changed'), ('x-trailer-only', 'discarded')]):
        context['send'](chunk)
    require(item == before and state['trailers'] == state['streams'][3]['ends'] == 1, 'trailers changed initial metadata or accepted record')
    unchanged_refusal(app, result, trailers, 'trailer ordinal differs')
    credit_cases.barrier(context, receive, stream, case)
    credit_cases.resume(context, receive, stream, case)
    require(item['bytes'] == 32 and item['chunks'] == 2 and item['max_span'] == 16 and item['sha256'] == model.H32 and
            item['ends'] == item['metadata_end'] == item['helpers_end'] == 1 and not item['active'], 'resume completion differs')
    model.validate_item(json.loads(adapter.finish(context, stream, receive)['body']), model.record(case, True, 'after'))
    adapter.health(context, receive)
    unchanged_refusal(app, result, frame(1, 5, 13, header_block(((':path', '/metrics'),))), 'request beyond finite schedule')
    print('metadata HEADERS/DATA16/status/DATA16/exact trailers/status/resume: initial facts retained, actual END/helpers completion earned; final permission bounded')


def concurrent_transitions():
    app, result, context = open_peer('concurrent_routes', final=True)
    state, receive = result['state'], result['connection']['receive']
    held = concurrent_cases.start(context, 'concurrent_hold')
    adapter.send_data(context, held, model.payload_span(32, 0, 16), False)
    credit_cases.barrier(context, receive, held, 'concurrent_hold')
    holder = dict(app['records']['concurrent_hold'])
    refused = concurrent_cases.start(context, 'concurrent_refused')
    require(refused == 7 and state['resets'] == 1 and state['resets_delivered'] == 0 and len(state['pending']) == 2,
            'refusal queue/delivery conflated')
    record = app['records']['concurrent_refused']
    require(record['middleware'] == 1 and record['attempts'] == record['begins'] == record['bytes'] == record['ends'] == 0,
            'refusal accepted body/begin')
    packet, stamp = receive()
    require(packet[3:5] == bytes((1, 5)) and int.from_bytes(packet[5:9], 'big') == 7 and state['resets_delivered'] == 0,
            'refusal final not first')
    adapter.observe(context, packet, stamp)
    upload_entries = [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'), (':path', peer.target('concurrent_upload'))]
    upload_entries += peer.expected_headers('concurrent_upload')
    unchanged_refusal(app, result, frame(1, 4, 9, header_block(upload_entries)), 'request before refused reset delivery')
    packet, stamp = receive()
    require(packet == frame(3, 0, 7, bytes(4)) and state['resets_delivered'] == 1, 'refusal reset differs')
    adapter.observe(context, packet, stamp)
    adapter.finish(context, refused, receive, keep=True)
    upload = concurrent_cases.start(context, 'concurrent_upload')
    concurrent_cases.active(context, receive)
    require(app['records']['concurrent_hold'] == holder and state['streams'][3]['accepted'] == 0, 'active barrier changed holder')
    adapter.send_data(context, upload, model.payload_span(32, 0, 32), True)
    concurrent_cases.finish(context, receive, upload, 'concurrent_upload')
    peer.retained_health(adapter.health, context, receive, state)
    require(app['records']['concurrent_hold'] == holder, 'sibling completion changed holder')
    credit_cases.barrier(context, receive, held, 'concurrent_hold')
    credit_cases.resume(context, receive, held, 'concurrent_hold')
    item = app['records']['concurrent_hold']
    require(item['bytes'] == 16 and item['sha256'] == model.digest(32, 0, 16) and item['chunks'] == 1 and item['ends'] == 0 and
            not item['paused'] and item['metadata_end'] == 0, 'actual resume prefix differs')
    unchanged_refusal(app, result, frame(0, 1, held, model.payload_span(32, 16, 16)), 'DATA delivery barrier differs')
    pause_cases.status(context, receive, 'concurrent_hold')
    adapter.send_data(context, held, model.payload_span(32, 16, 16), True)
    concurrent_cases.finish(context, receive, held, 'concurrent_hold')
    recovery = concurrent_cases.start(context, 'concurrent_recovery')
    adapter.send_data(context, recovery, model.payload_span(32, 0, 32), True)
    concurrent_cases.finish(context, receive, recovery, 'concurrent_recovery')
    peer.retained_health(adapter.health, context, receive, state)
    adapter.retire(context, refused)
    peer.retained_health(adapter.health, context, receive, state)
    model.validate_records(('concurrent_routes',), 'before', app['records'])
    adapter.check_counts(context)
    print('concurrent refusal final/reset delivery distinct; active2/paused1/slots; held prefix/ready/END; isolated recovery; health7/12/13 retention')


def retention_integrity():
    result, sent = object(), object()
    for head, keep in ((6, True), (11, True), (12, False)):
        mapping = {7: None} if keep else {}
        context = dict(records=dict(mapping), stage=dict(active=dict(mapping)), raw=dict(streams=dict(mapping)))
        state, calls = dict(heads=head), [0, 0]

        def send(_data):
            calls[1] += 1
            state['heads'] += 1
            return sent

        def health(current, _receive):
            calls[0] += 1
            require(current['send'](b'health') is sent, 'send result identity changed')
            current['records'].clear()
            current['stage']['active'].clear()
            current['raw']['streams'].clear()
            return result

        context['send'] = send
        require(peer.retained_health(health, context, None, state) is result, 'health result identity changed')
        require(context['send'] is send and calls == [1, 1], 'retention wrapper not once/restored')
    retention_failures()
    print('retention wrapper captures original send boundary, preserves original-once/result/error priority, restores both instruments')


def retention_failures():
    error, calls = RuntimeError('original health error'), [0]
    context = dict(records={}, stage=dict(active={}), raw=dict(streams={}), send=lambda _data: None)
    send = context['send']

    def failing(current, _receive):
        calls[0] += 1
        current['send'](b'health')
        raise error

    try:
        peer.retained_health(failing, context, None, dict(heads=6))
    except RuntimeError as exc:
        require(exc is error, 'original health error identity/priority lost')
    else:
        raise ValueError('original error swallowed')
    require(context['send'] is send and calls == [1], 'failure wrapper not once/restored')
    rejects(lambda: peer.retained_health(lambda current, _receive: current['send'](b'health'),
                                        context, None, dict(heads=6)), 'refused retention or retirement order differs')
    require(context['send'] is send, 'failed assertion instrumentation leaked')
    original_run, original_health = adapter.run_case, adapter.health

    def run(current, receive):
        return adapter.health(current, receive)

    try:
        adapter.run_case, adapter.health = run, failing
        try:
            peer.run_with_retention(context, None, dict(case='concurrent_routes', heads=6))
        except RuntimeError as exc:
            require(exc is error, 'driver error identity lost')
        else:
            raise ValueError('driver error swallowed')
        require(adapter.health is failing and context['send'] is send, 'driver instrumentation leaked')
    finally:
        adapter.run_case, adapter.health = original_run, original_health


def actual_chain():
    app, result, context = open_peer('metadata_helpers', health=False)
    peer.run_with_retention(context, result['connection']['receive'], result['state'])
    model.validate_records(('metadata_helpers',), 'before', app['records'])
    original = app
    app, result, context = open_peer('concurrent_routes', final=True, app=app, prior=('metadata_helpers',), health=False)
    peer.run_with_retention(context, result['connection']['receive'], result['state'])
    final_boundary(result, context)
    require(app is original and app['heads'] == 87, 'actual shared chain differs')
    model.validate_records(('metadata_helpers', 'concurrent_routes'), 'before', app['records'])
    print('actual two-case prior/final68: same application/protocol/parser/ledgers/debt/caps/deadlines, heads87')


def actual_retention_fault(head, field):
    original, calls = adapter.health, [0]

    def health(context, receive):
        next_head = context['stage']['case_state']['heads'] + 1
        if next_head != head:
            return original(context, receive)
        calls[0] += 1
        mappings = dict(records=context['records'], active=context['stage']['active'], raw=context['raw']['streams'])
        mapping = mappings[field]
        original_send = context['send']

        def send(data):
            old, existed = mapping.get(7), 7 in mapping
            if existed:
                del mapping[7]
            else:
                mapping[7] = None
            try:
                result = original_send(data)
            finally:
                if existed:
                    mapping[7] = old
                else:
                    del mapping[7]
            return result

        context['send'] = send
        try:
            result = original(context, receive)
        finally:
            context['send'] = original_send
        return result

    adapter.health = health
    try:
        rejects(lambda: peer.check('concurrent_routes'), 'refused retention or retirement order differs')
        require(calls == [1] and adapter.health is health, 'actual retention fault boundary differs')
    finally:
        adapter.health = original


def actual_retention_controls():
    for head in (7, 12, 13):
        for field in ('records', 'active', 'raw'):
            actual_retention_fault(head, field)
    print('nine actual health7/12/13 map corruptions rejected at original transport snapshot despite restoration before health return')


def startup_wrapper_integrity():
    original, calls = adapter.open_case, [0]
    marker, error = object(), RuntimeError('open original failure')

    def returning(*_args, **_kwargs):
        calls[0] += 1
        return marker

    def failing(*_args, **_kwargs):
        calls[0] += 1
        raise error

    def send(_data):
        raise ValueError('send span differs')

    def driver(_case):
        require(adapter.open_case(None, None, send) is marker, 'open result identity differs')

    try:
        adapter.open_case = returning
        startup_bound(driver)
        require(adapter.open_case is returning and calls == [1], 'open success instrumentation leaked')
        adapter.open_case = failing
        try:
            startup_bound(driver)
        except RuntimeError as exc:
            require(exc is error, 'open exception identity/priority differs')
        else:
            raise ValueError('open exception swallowed')
        require(adapter.open_case is failing and calls == [2], 'open failure instrumentation leaked')
    finally:
        adapter.open_case = original
    print('startup proof wrapper original-once/result/error/restoration verified')


def all_proofs():
    constructor()
    constructor_rejections()
    startup_bound(peer.check)
    header_refusals()
    metadata_transitions()
    concurrent_transitions()
    retention_integrity()
    actual_retention_controls()
    startup_wrapper_integrity()
    receive_error_identity()
    bounds()
    hpack_limits()
    actual_chain()
    retained_supplied_fixture()


def main():
    modes = {'--constructor': constructor, '--baseline-bounds': baseline_bounds, '--all': all_proofs}
    if len(sys.argv) == 2 and sys.argv[1] in modes:
        modes[sys.argv[1]]()


if __name__ == '__main__':
    main()
