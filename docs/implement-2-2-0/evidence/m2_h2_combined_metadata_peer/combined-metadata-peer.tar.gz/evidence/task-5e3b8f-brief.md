# Shared independent metadata/concurrency peer

Released after reviewed/pushed8e. BASE:
1bafb088de275cea54982c37a4f73f101aefc918.
Accepted current40 manifest:
docs/implement-2-2-0/evidence/m2_h2_combined_credit_peer/manifest.json.
Root audit: task-5e3b8e-root-commit-audit.json in this directory.
Implement accepted remaining-peer plan unit6/shared contract and aggregate
acceptance notes. This is standalone synthetic preparation, not actualall40/
native/adoption/M2 completion.

Own ONLY
/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py,
NEW evidence/metadata-peer beneath that directory and
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8f-report.md.
One source changed39unchanged/current40. No other source/handler/model/core/
fixture/codec/pin/product/limit changes. Report concrete additional API/ownership
gap before editing. You are not alone; preserve others and all historical
source/raw. Root review/publication/commit+immediatepush; no agents/Git/native/
network/external CLI.

Promote new_peer(case, *, app, prior, now, clock, final=False, fault=None) for
metadata_helpers and concurrent_routes, exact {connection,state} and exact
connection7 protocol/send/receive/now/owned/tls/alpn. Pinned initialized protocol,
supplied owned=True/TLSv1.3/h2, normal queued startupSETTINGS/ACK. Validate all
inputs before effects; no constructor clock/client dispatch/observe/final/app
mutation/selected completion. Exact app4 records/heads/outputs/binding from
test_core_peer.new_app; prior validates earned facts only, no seed or competing
app constructor. Preserve outputs/binding references. Keep check(case, *,
app=None, prior=(), final=False, fault=None), same app return, local synthetic
caller-clock behavior and existing prints/main/negatives. No legacy2key shim
without actual caller need.

Preserve expected_headers/target/validate_upload/contract_and_oracle_checks
contracts. Initial metadata_helpers has66 regular headers including regular
host, target/query and17 captures, split16+16 DATA, initial metadata and discarded
trailers. Preserve helper errors/borrowed slice and overflow contracts, zero
allocator observation and untouched issue/pointer/length facts. Seven direct
header controls remain explicitly oracle sensitivity checks, not seven extra
serialized schedules.

Delete old nested peer, selected terminal recipe, histories and client-context
oracle in peer. Derive normal metadata/admission/begin/paused/helper facts from
validated exact metadata; earn body/hash/chunks/END/trailer/resume/terminal facts
at actual transitions, no future completion atHEADERS. Preserve metadata_end/
helpers_end boundaries, initial-only metadata and discarded trailer-only/changed
x-h62. Metadata begin-pauses, receives16 then status, next16 plus exact trailers,
second status then actual resume before completion.

Concurrent case independently owns held/refused/upload/recovery streams:
held16nonEND remains paused with accepted0; refusal503 finalHEADERS then
NO_ERROR reset without100/body; concurrent upload completes32END while holder
remains isolated. Active metric barrier is active2/paused1/bothslots. Actual
resume earns held16 prefix/hash/chunk, next status is ready before held16END;
recovery and healthy siblings preserve isolation, terminal facts and hashes.

Concrete old peer retention() reads client context records/stage.active/raw
streams at actual health heads7,12,13: refused row retained at7 and12, retired
at13. Move this EXACT assertion to a driver-side transport/adapter wrapper at
corresponding serialized health boundaries; peer truth must never read context.
A wrapper must call original exactly once, preserve its exact result/exception
identity and error priority, restore instrumentation on failure, and assert
the original boundary snapshot. Do not replace with a later/final-only check.
No arbitrary observer callback in new_peer. Preserve primary stream3, exact
online request order/counts, slot/refusal/reset/settings counts, split spans/
trailers/hash checks and actual two-case sharedapp/final68.

Preserve ALL diagnostics: helpers_begin/helpers_end/metadata_middleware/
metadata_begin/metadata_end -> record mismatch: FIELD; paused_bytes -> record
mismatch: bytes; not_paused -> record mismatch: paused; early_final -> invalid
terminal; other_record -> record mismatch: middleware atfinal; refusal_status ->
wrong final status; refusal_continue -> invalid HEADERS; reset_first -> reset
order; reset_code -> wrong reset code; active_count/paused_count/slot_count ->
concurrent active barrier differs; resume_prefix -> record mismatch: sha256;
route_contamination -> record mismatch: metadata_begin. Keep finite faults
limited to named observations and preserve unselected-record contamination
controls. Freeze and execute accepted Python baseline if a diagnostic is
uncertain; no guessed message or weakened canonical check.

Bound parser8201, frame/send8192, HPACK table/list, finite pending packet/bytes/
read caps, upload summaries/control cursors before growth and repeated invalid
input; preserve all parentceilings. No whole payloads, request/frame/read
histories, or future seeded model records. Queued and delivered responses/
resets/grants remain distinct. Final permission is inert until actual ordinary/
recovery order completes, thenfinal68 uses same protocol/parser/ledgers/debt/
receivecaps/deadlines. Metrics derive actual app/slot/head facts. Any direct
proof wrapper also preserves original-once/result/error-priority/restoration.

Before editing: read actual AGENTS.md, CODING_CONVENTION.md, developer role and
narrow incremental/TDD/API/codebase-design workflows plus accepted context.
Use Graphify before a NEW codebase question/search/read; supplied paths are
located. Freeze the exact accepted current 40 sources and 119-input identity,
and a fresh exhaustive prior-evidence hash map excluding only this new unit.
Freeze before actual acceptance RED; constructor absence is a pre-effect RED,
not a behavioral defect. Each discovered defect needs the real source/RED
before its fix; preserve every failed/intermediate command/source/raw artifact.

After last source edit retain FOUR focused checks: test_metadata_concurrency.py and
test_imports.py, each normal and -O. Other suites only for an identified
dependency or unanswered concern. Add meaningful direct constructor/prior/
metadata-vs-DATA/refusal-order/final/bounds/retention proofs as needed. Actual
shared prior cases must be earned from traffic; supplied fixtures remain
explicitly synthetic. Every check has exact argv/env/cwd, 40-source before and
after maps, separate stdout/stderr/exit and same-shell restoration receipt.
All 40 source AST/import guards, all CURRENT unit helper nesting <=3 and inert
import/empty/foreign argv, 119 authority/118 physical/113 resolved/42 ordered
codecs, frozen source and prior-history preservation must be audited. No live
helper is exempt as historical; preserve old bytes before correcting it. No
classes/assert/custom exceptions/global mutable containers/dead code/camelCase/
silenced errors/forwarding wrappers or weakened bounds, tests or lint.

Temporary inputs reset across continuations. EACH dependent Python proof,
audit or check exec_command shell must start with set -e and run the Root
restorer below, with a NEW absolute receipt, then its operation IN THAT SAME
SHELL. Never infer persistence from a prior Root command.

/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT

Pinned interpreter SHA256:
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
All direct Python, including source edits, uses this interpreter with -B -S;
optional -O for optimized. Exact PYTHONPATH:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases

Graphify invocation:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650

No native/build/server/socket/SSLContext/TLS-close/real-clock/process ownership/
kernel/fault scheduling/race/panic/crash/leak/old-runtime/install/network runs.
Only pinned in-memory codecs and supplied synthetic app/transport/process
facts. No additional named-skill drift is established by the known missing
generic DoD reference: explicit project gates/exact scope remain authoritative,
full native/project/platform gates mandatory later, not waived.

Write the full report at the owned report path: exact files/commands/raw/exits,
RED/GREEN chronology, all current source/check/input/history/helper audits,
self-review and actual gaps. Return concise DONE or specific concerns/context/
blocker under 15 lines. Remaining work alone is not missing context. Root owns
fresh source review, publication accuracy, commit and immediate push before
releasing the next serial peer unit. Full goal remains active.

