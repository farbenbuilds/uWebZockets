# Independent metadata/concurrency peer

DONE for the assigned standalone synthetic preparation, pending Root independent
review. No ownership/API gap or unresolved implementation defect is known.
This does not claim actual all40, native, adoption, or milestone acceptance.

## Scope and identities

Accepted BASE: `1bafb088de275cea54982c37a4f73f101aefc918`.
Accepted current40 authority:
`docs/implement-2-2-0/evidence/m2_h2_combined_credit_peer/manifest.json`.
Implemented the shared contract and unit6 in
`.superpowers/sdd/h2_streaming_plan/task-5e3b-all40-peer-plan-report.md`, as
released by `task-5e3b8f-brief.md`.

Changed exactly one source:
`.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py`.
Final SHA256:
`f6d95f44b9377fc886891d748a878b57d4f68ddea7d633d94b691c18225dbb20`.
The other 39 current source modules match the accepted manifest byte for byte.

Added only the new evidence tree
`.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/metadata-peer/`
and this report. Its current executable helpers are exactly `capture.py`,
`proofs.py`, and `audit.py`. The `.txt` sources are retained baseline,
intermediate, assembly, and execution snapshots; they are not additional live
helpers. The baseline source is explicitly executed only by the opt-in
baseline reproduction proof. No handler, model, codec, catalogue, adapter,
other peer, fixture, product source, pin, or threshold was changed.

Read the actual AGENTS.md, CODING_CONVENTION.md, developer role instructions,
accepted shared contract/unit6, prior credit evidence/report/source patterns,
and narrow using-agent-skills, incremental implementation, TDD, interface
design, and codebase-design workflows. Recovered truncated applicable reads
with narrower reads. Applied debugging-and-error-recovery to the retained
intermediate failures. No additional skill drift was established beyond the
brief's already-qualified generic DoD reference.

## Implemented contract and behavior

`new_peer(case, *, app, prior, now, clock, final=False, fault=None)` supports
`metadata_helpers` and `concurrent_routes`, returning exactly `connection,state`.
Connection fields remain exactly `protocol,send,receive,now,owned,tls,alpn`.
It validates case, finite applicable faults, exact app4, prior records/outputs/
binding/earned heads, time, clock, and final permission before creating state.
It uses canonical `test_core_peer.new_app()` for standalone calls. Constructor
creation never samples the clock, dispatches a client schedule, observes input,
mutates application facts, or completes selected records. Startup SETTINGS/ACK
are queued for ordinary receive on the initialized pinned protocol. Ownership,
TLSv1.3 and h2 remain explicitly supplied synthetic facts.

The old nested peer and terminal-record recipe are removed. No peer function
reads client context; `retained_health` and `run_with_retention` are driver-only
instrumentation. `check(case, *, app=None, prior=(), final=False, fault=None)`
retains its signature, same-app return, incrementing local synthetic clock,
prints, primary stream3, canonical schedules, negatives and shared main/final68.
Outputs and binding references are preserved; prior state is validated rather
than manufactured. No two-key app shim or competing constructor was added.

The unchanged `expected_headers`, `target`, `validate_upload`, and
`contract_and_oracle_checks` preserve 66 regular headers including regular
`host`, exact target/query, 17 captures, overflow storage, borrowed/empty body
helper facts, BodyNotBuffered errors, zero allocator observation and untouched
issue/pointer/length facts. The seven direct header controls remain explicitly
oracle sensitivity controls, not additional serialized schedules.

Metadata HEADERS earn only validated middleware, attempt/begin, initial metadata,
helper-begin and paused facts. DATA16, first status, DATA16, exact trailing
HEADERS, second status and actual resume remain ordered. Both paused snapshots
retain accepted bytes0/hash-empty/chunks0/END0. Initial metadata remains unchanged
by trailer-only and changed x-h62 fields. Actual resume accepts the accumulated
32 bytes, incremental hash, two chunks/max16 and actual END, then earns
metadata_end/helpers_end and terminal response.

Concurrency independently tracks four bounded upload summaries. The held stream
receives16 without END and accepts0 while paused. Refusal earns only middleware
at exact request HEADERS, queues final503 HEADERS before NO_ERROR reset and no
100/body in the normal mode. Queued versus delivered response/reset counts are
separate, and the next upload requires delivered refusal reset. The active
barrier remains active2/paused1/both slots. The independent upload completes32END
without changing the holder. Actual resume accepts the held16 prefix/hash/chunk;
the ready status must be delivered before the final held16END. Recovery and
health siblings retain isolation, terminal order, split spans and hashes.

Metrics sum actual persistent records and derive slots from actual active rows
and buffered middleware from actual heads. Final permission is inert until the
ordinary schedule, recovery and terminal requirements complete. Final68 retains
the same protocol, parser, ledgers, debt, cumulative receive caps and deadlines.
Actual two-case traffic earns prior state and 87 total heads including final68.
The retained producer output/binding fixture is explicitly supplied historical
synthetic data, not a claim that producer traffic executed in this slice.

Bounds remain parser8201, send/frame payload8192, HPACK list/table4096, pending
at most4 packets/16384 bytes, packet at most8192, receive count at most heads+4
and matching byte cap, and at most four upload summaries with count<=32 and
frames<=2. Online cursors replace histories. There are no retained full payloads
or request/frame/read histories. Invalid metadata/DATA/trailer/order inputs are
rejected before earned application/body facts; direct repeated invalid-input
proofs and storage/receive growth refusals are retained.

All original diagnostics pass unchanged: five helper/metadata field mismatches;
paused bytes and paused flag; early-final invalid terminal; final-only unselected
middleware contamination; refusal status/Continue; reset order/code; all three
active metric faults; resumed sha256; and cross-route metadata_begin contamination.
The deliberate early-final mode permits only its one queued erroneous response
at the original first-status boundary so the canonical invalid-terminal error
keeps priority. Normal delivery ordering remains strict.

## Retention and instrumentation

At health heads7,12,13 the driver wraps the original health operation and its
transport send. It captures presence of refused stream7 in client records,
stage.active and raw.streams at the actual send boundary. Expected presence is
true/true/true at7 and12 and false/false/false at13. It evaluates that original
snapshot after the original health returns, so an original failure retains
priority. The original operation and send execute once, their result and
exception identities propagate, and both instrumentation levels restore on
success and failure. There is no arbitrary peer observer callback.

Direct proof covers successful original result identity, exception identity/
priority, original-once counts, restoration after original errors and assertion
failure, and snapshots unaffected by later map changes. Nine additional actual
serialized controls corrupt each of the three maps separately at each of heads
7,12,13, restoring it immediately after transport send. All nine are rejected
from the original snapshot, before a later/final-only check could substitute.
The startup proof wrapper separately checks original-once/result/error identity
and restoration. Final receive wrappers call the original receive once, return
its result unchanged, and propagate its exception before assertions.

## Freeze, commands and raw evidence

Before source editing or either acceptance RED, `capture.py --freeze` compared
all40 sources against the accepted manifest and retained every source in
`baseline/*.py.txt`, with hashes in `baseline/source.json`. It copied the119-entry
input authority to `baseline/immutable-inputs.json` and froze a fresh exhaustive
map of 11,037 prior evidence files in `baseline/prior_history.json`, excluding
only this new unit. `restore-freeze.json` records same-shell pinned input
restoration. The freeze printed `Frozen 40 sources and 11037 prior evidence files`
and exited0. Evidence helper creation preceded the freeze; no test-source edit
or acceptance check did.

Let ROOT be the absolute combined-cases directory above and UNIT be
ROOT/evidence/metadata-peer. These are report notation only; captured argv/cwd
contain exact absolute paths. Every dependent Python check/audit/edit used the
pinned interpreter with `-B -S`, optional child `-O`, and a fresh same-shell
Root-restoration receipt. Each command sequence used:

```sh
set -e
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore UNIT/restore-NAME.json
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S UNIT/capture.py --run NAME MODULE MODE ARGS
```

Source/proof edits occurred after restoration, before their corresponding checks
in those same shells. Final proof/docstring/audit edits have the separate fresh
`restore-edit-final-proofs.json`. Each restoration verifies119 authority entries,
118 physical rows,113 resolved files,42 ordered codecs, and interpreter SHA256
`4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`.
Ordered codec digest:
`0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`.

Every row below has exact child argv/env/cwd/restoration binding in command.json,
40-source before/after hashes, target source snapshot, exact executed check and
capture helper sources, check AST, separate raw stdout/stderr and exit.json.
The child environment is exactly the two variables displayed above. The
recorder exits0 after preserving a child failure; the table reports CHILD exits.

| NAME | MODULE relative to ROOT | MODE / ARGS | Child exit/result |
| --- | --- | --- | --- |
| red-constructor | evidence/metadata-peer/proofs.py | normal --constructor | 1: new_peer absent; pre-effect API RED, not behavioral defect |
| red-baseline-bounds | evidence/metadata-peer/proofs.py | normal --baseline-bounds | 1: frozen real baseline accepts oversized startup |
| green-schedules | test_metadata_concurrency.py | normal | 1: new delivery guard preempted early_final diagnostic |
| green-fault-priority | test_metadata_concurrency.py | normal | 0: original two-case chain/final and all diagnostics |
| green-direct-primary | evidence/metadata-peer/proofs.py | normal --all | 1: manual transition proof attempted final without canonical driver completion |
| green-direct-manual-boundary | evidence/metadata-peer/proofs.py | normal --all | 0: manual transition checks and separate actual-driver final proof |
| green-direct-retention | evidence/metadata-peer/proofs.py | normal --all | 1: proof's retired-row sentinel persisted into client receive validation |
| green-retention-transport | evidence/metadata-peer/proofs.py | normal --all | 0: corruptions confined to exact send snapshot and restored before receive |
| cover-metadata-normal | test_metadata_concurrency.py | normal | 0 |
| cover-metadata-optimized | test_metadata_concurrency.py | optimized | 0 |
| cover-imports-normal | test_imports.py | normal | 0 |
| cover-imports-optimized | test_imports.py | optimized | 0 |
| final-direct-normal | evidence/metadata-peer/proofs.py | normal --all | 0 |
| final-direct-optimized | evidence/metadata-peer/proofs.py | optimized --all | 0 |
| strict-audit-normal | evidence/metadata-peer/audit.py | normal --audit UNIT/audit-normal | 0 |
| strict-audit-optimized | evidence/metadata-peer/audit.py | optimized --audit UNIT/audit-optimized | 0 |

All intermediate failed source/check/raw artifacts remain unmodified. The two
proof setup failures did not establish product or peer defects: manually calling
a handler's operations does not earn adapter.run_case's completed flag, and an
invalid row sentinel left through receive is rejected by the client before the
retention assertion. The fixes preserved canonical completion and receive
validation; actual final proof uses adapter.run_case, and retention corruption
now exists only at the required send boundary.

The two audit executions have the same complete captures as proofs, specifically
`strict-audit-normal/command.json` and `strict-audit-optimized/command.json` and
all their sibling source/raw/exit artifacts. Their argv names audit.py, not
proofs.py. Generated outputs are in audit-normal/ and audit-optimized/.

Graphify queries ran before new related codebase exploration, using the supplied
executable/environment and budget650, exit0. Results were broad/truncated; named
supplied and located paths were read for precise context. One read-only `ls`
reported no remaining-named plan file, and a later `rg` reported a nonexistent
candidate temporary model path (exit2); the accepted plan and actual model paths
were located and read. No execution depended on either missing path.

After modifications, same-shell `restore-graphify.json` preceded the supplied
Graphify executable with `env PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify` and `update .`, exit0.
Raw output is graphify.stdout.txt/graphify.stderr.txt. It reported no relevant
changes and left graphify-out untouched; this does not establish indexing of
ignored preparation sources. No external model CLI or semantic extraction ran.

## Final verification and self-review

Four focused covering checks were run after the last source edit: metadata and
imports, each normal and optimized. Both direct proof modes and both strict
audits also exit0 with empty stderr. No current executable helper was changed
after its final audit. Both strict audits establish:

- All40 AST/main guards, no classes/assert/global containers/custom exceptions,
  accepted maximum source control nesting3; matching inert import checks.
- All3 current unit helpers, none exempt: import and main empty/foreign argv
  inertness, guards, accepted and strict depth limits. capture depth1, audit
  depth2, proofs depth3 under both counters.
- Exactly one changed source and39 unchanged; all frozen baseline source bytes
  and input authority preserved.
- Exhaustive prior-evidence map and every hash unchanged:11,037 files.
- 119 authority/118 physical/113 resolved/42 ordered codecs plus interpreter pin.
- Four covering and two direct receipts bound to the final40 source map, exact
  optimization flags, exit0, empty stderr and same-shell restored identities.

Self-reviewed the entire final diff and direct proof output. Checked constructor
validation before effects, exact metadata and retained helper contracts, no
model-selected completion recipe, actual DATA/hash/END and resume timing,
independent streams, refusal delivery order, initial-only metadata, finite
fault applicability, original diagnostic priorities, explicit bounded state,
and driver-only context inspection. Confirmed actual prior/final traffic and
qualified synthetic fixture use, reference preservation, instrumentation cleanup,
and unchanged public check/main behavior. No canonical test, assertion, lint,
threshold, bound, handler or gate was weakened.

Root owns fresh independent source/spec/quality review, publication, commit and
immediate push before another serial peer release. Actual default/all40
execution, remaining peer extraction, broader combined review, runtime closure,
strict close/owned-process work, sequential native acceptance, adoption and full
milestone acceptance remain required. Project formatting/conventions/release
version/Zig tests, sanitizer, compile, fuzz, package-consumer and applicable
protocol/platform/compliance gates were NOT run in this source-only slice and
remain mandatory later. No native/build/server/network/socket/SSLContext/TLS
close/real-clock/process-ownership/old-runtime/install/Git/publication/agent or
external model CLI execution occurred.
