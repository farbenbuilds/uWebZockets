"""Independently bind the Metadata/concurrency candidate, preserved history and four receipts."""
import ast
import hashlib
import json
import sys
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def verify_source(source, unit):
    current = {path.name: sha(path.read_bytes()) for path in sorted(source.glob('*.py'))}
    baseline = read_json(unit / 'baseline/source.json')
    published = read_json(Path('docs/implement-2-2-0/evidence/m2_h2_combined_credit_peer/manifest.json'))
    if baseline != published['current_source_files'] or len(current) != 40:
        raise ValueError('Baseline or current module inventory differs')
    changed = [name for name in current if current[name] != baseline[name]]
    if changed != ['test_metadata_concurrency.py'] or current.keys() != baseline.keys():
        raise ValueError('Ownership differs')
    for name, digest in baseline.items():
        if sha((unit / 'baseline' / (name + '.txt')).read_bytes()) != digest:
            raise ValueError('Frozen baseline differs: ' + name)
    return current


def verify_history(source, unit):
    prior = read_json(unit / 'baseline/prior_history.json')
    for name, digest in prior.items():
        path = source / name
        if path.is_symlink() or sha(path.read_bytes()) != digest:
            raise ValueError('Prior evidence differs: ' + name)
    return len(prior)


def verify_receipt(unit, name, current):
    folder = unit / name
    if folder.resolve().parent != unit.resolve():
        raise ValueError('Receipt must be a direct unit child')
    command = read_json(folder / 'command.json')
    argv = command['argv']
    if argv[0] != '/home/codespace/.python/current/bin/python3' or argv[1:3] != ['-B', '-S']:
        raise ValueError('Interpreter flags differ')
    expected = ['-O'] if '-O' in argv else []
    if argv[3:-1] != expected or Path(argv[-1]).name not in ('test_metadata_concurrency.py', 'test_imports.py'):
        raise ValueError('Focused check differs')
    for side in ('before', 'after'):
        if read_json(folder / ('source-' + side + '.json')) != current:
            raise ValueError('Receipt source differs')
    if read_json(folder / 'exit.json') != dict(exit_code=0):
        raise ValueError('Focused check failed')
    if (folder / 'stderr.txt').read_bytes():
        raise ValueError('Focused stderr is not empty')
    restoration = Path(command['restoration'])
    facts = read_json(restoration)
    if not facts['all_inputs_verified_in_this_command'] or facts['authority_entries'] != 119:
        raise ValueError('Command-local restoration is not verified')
    if (facts['physical_rows_checked'], facts['unique_resolved_files'], facts['ordered_codec_files_checked']) != (118, 113, 42):
        raise ValueError('Restored input inventory differs')
    return dict(module=Path(argv[-1]).name, optimized=bool(expected), command=command,
                stdout_sha256=sha((folder / 'stdout.txt').read_bytes()),
                restoration_sha256=sha(restoration.read_bytes()), exit_code=0, stderr_empty=True)


def nesting(node, depth=0):
    control = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.With, ast.AsyncWith,
               ast.Try, ast.TryStar, ast.Match)
    level = depth + int(isinstance(node, control))
    return max([level] + [nesting(child, level) for child in ast.iter_child_nodes(node)])


def verify_helpers(unit, plan):
    paths = sorted(unit.glob('*.py')) + [plan / 'task-5e3b8f-build-publication.py',
                                       plan / 'task-5e3b8f-root-audit.py']
    result = {}
    for path in paths:
        tree = ast.parse(path.read_text(), filename=str(path))
        level = nesting(tree)
        if level > 3 or any(isinstance(node, (ast.ClassDef, ast.Assert)) for node in ast.walk(tree)):
            raise ValueError('Helper structure differs: ' + str(path))
        namespace = {'__name__': 'metadata_audit', '__file__': str(path)}
        exec(compile(tree, str(path), 'exec'), namespace)
        if 'main' not in namespace:
            raise ValueError('Missing helper main guard: ' + str(path))
        result[str(path)] = dict(sha256=sha(path.read_bytes()), max_nesting=level, metadata_import_inert=True)
    return result


def main(argv):
    if len(argv) != 5 or argv[0] != '--audit':
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    unit = source / 'evidence/metadata-peer'
    current = verify_source(source, unit)
    history = verify_history(source, unit)
    receipts = {name: verify_receipt(unit, name, current) for name in argv[1:]}
    coverage = {(row['module'], row['optimized']) for row in receipts.values()}
    if coverage != {('test_metadata_concurrency.py', False), ('test_metadata_concurrency.py', True), ('test_imports.py', False), ('test_imports.py', True)}:
        raise ValueError('Final four-check coverage differs')
    helpers = verify_helpers(unit, plan)
    result = dict(base_commit='1bafb088de275cea54982c37a4f73f101aefc918',
                  current_source_sha256=current, changed_modules=['test_metadata_concurrency.py'], unchanged_modules=39,
                  prior_evidence_hashes_verified=history, focused_receipts=receipts, current_helpers=helpers,
                  current_source_files=40, native_executed=False, milestone_complete=False)
    output = plan / 'task-5e3b8f-root-final-audit.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(source_modules=40, unchanged_modules=39, prior_evidence_hashes_verified=history,
                          focused_receipts=4, current_helpers=len(helpers), result=str(output)), indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])




