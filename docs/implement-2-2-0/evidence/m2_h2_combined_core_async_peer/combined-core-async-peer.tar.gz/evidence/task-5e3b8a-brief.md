# Core delayed peer and shared standalone driver

Released after reviewed/pushed phase2C BASE
6061f0bc11190eae5733914bbdf83d490722f8ef. Accepted40 source map:
docs/implement-2-2-0/evidence/m2_h2_combined_coordinator_shutdown/manifest.json,
bound by task-5e3b7p8-root-commit-audit.json. Read accepted
task-5e3b-all40-peer-plan-report.md unit1 and
task-5e3b-all40-core-async-addendum.md. Parent requirements remain
task-5e3b-aggregate-acceptance-notes.md. This prepares another actualall40 peer;
it does not establish coordinator/default/all40/native or milestone completion.

## Ownership

Own ONLY combined-cases/test_core_peer.py and test_ready.py, new
evidence/core-async-peer and task-5e3b8a-report.md. Directory absolute:
/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases.
No test_async/test_large/test_time/test_final/test_shared/test_imports/coordinator/
otherpeers/handlers/core/model/fixture/helper/codecs/pins/product/limits edits.
Inventory stays40, twochanged38unchanged. Exact extraownership/API gap toRoot
BEFORE edit. You are notalone; preserveothers/allraw/source/history. No agents/
externalmodelCLI/Git/public/native operations. Root owns review/commit+push.

## Shared constructor and driver

Extend existing test_core_peer.new_peer(case,*,app,prior,now,clock,final=False)
for async_delayed inadditiontoits3existingcases. No unnecessaryfaultargument,
newmodule/registry/simulator/publicforwardingwrapper. Existingreturnexact
{connection,state}/sevenconnectionfacts/protocolinit/queueSETTINGS+ACK/
no constructorclock/clientdispatch/observe/apptransition contract preserved.
Keep app exactrecords,heads,outputs,binding; noextra persistentfield needed.

Delayed actualschedule /health -> /delayed -> /health, ordinary3heads with
primaryordinal1, GET/emptyrequestbody/HEADERS END frommodel.core_request.
Preservecontent-type:text/plain/exactten-bytebody/optionalmissingretained
x-middleware policy fromcanonicalvalidate_core_response. Do notguessbodybytes
ornewdiagnostictypes: readimmutablecontracts. Delayed creates NOselectedbody
record; neveraccess app.records.async_delayed. Earn3headincrements onlyafter
validateddecodedmetadata. DATA/DATA-END counters remain0; completion/final68
requiresactualdelayed+finalhealth sequence, neverfabricateduploadEND.

metrics(app) already derives buffered_middleware=app.heads-sum(record.middleware).
Actual3delayedrequests contribute3; async-onlyfinal68 yields71 withbodymiddleware0.
Finalmetricsrequest itselfearnsitsheadbeforegeneration. Shareappacrossfresh
constructors/preserveoutputs+binding andvalidatepriorwithoutseeding. Headcount
alone neverestablishes selected-beforeidentity/completion; coordinator later
commitsonlyactualsuccessfuldispatch/release.

Convert test_ready.check(case='ready_buffered',final=False,*,clock=lambda:2,
after_case=None) into standaloneclientdriver using this SAMEsharedcorepeer for
allitscases. Preserveexactsignature/return/clock/after_case/final behavior,
existingheader/body/hash/count/assertion controls and printeddiagnostics.
Delete movedduplicatepeer/unusedimports in samechange. Existinglarge drivers,
ready/default, time andfinalboundary checks mustkeepmeaningunchanged.

Delete duplicate test_ready.frame implementation anddirectlyreexport
from test_core_peer import frame. Existingtest_ready.frame callers mustrefer
toSAMEfunctionobject; no forwardingfunction. Dependencyonewaytest_ready->core,
coreimports onlyitscodec/modeldeps, nevertest_ready/otherdriver. test_async.py
stayssixlineproxy. Preserve all3 oldcorepeer cases, independentappfacts,
pre-growthparser8201/frame8192/HPACK/pending limits, late-refund split/cursor,
large100000000incrementalhash190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2,
positivecloseddebt andboundedstate; no accumulatedbody/request/read histories.

Driverboundarychecks mayinspectclientcontext butmustnotfeedpeertruth. Any
inspectionwrapper invokesoriginaloperationexactlyonce, returnssamevalue and
preservesoriginalexceptionpriority, thenchecks capturedpre-observation. Keep
clock/after_case failures andpointofinvocation; no defaultsuccesscallback or
handlerinjection/modelcompletion. after_case remains beforeexistingfinalboundary.

## Proof and evidence

Beforeedits verify/freeze40acceptedbaseline andcaptureFRESH exhaustive prior
evidencefileSHAmap excludingonlynewunitdir. ActualacceptanceRED beforechanges;
qualify unsupported/missingAPI/pre-effects vswire faithfully. Anydiscoveredbug
actualfailing source/run BEFOREfix. Distincteveryattempt source/structure/
command/rawexit/currentmaps; no overwrites/historyfabrication.

Proveactualdelayed3head/zeroDATA/tenbyte/metadata/final68, optionalmiddleware
and metrics71, no bodyrecordselected atconstruct orcompletion, constructor
noeffects/priorvalidation/appshape/outputbindingretention. Premature/fabricated
finalpermission andunexpectedDATA cannotearnbody/completion; preserveeveryold
parser/pending/late-refund/large/typed/time/final control. Framealiasidentity
andonewayimports proven. Newnegativecontrols meaningfulwire/stateboundaries,
not tests mirroring branchsyntax. Priorfixturepreparation, ifany, explicitly
suppliedfacts not actualpriorwire. Standalonedriverproof notcoordinatorproof.

Afterfinaledit run these SEVENmodules normal and-O (14focusedcommands):
test_ready.py,test_async.py,test_large.py,test_time.py,test_final.py,
test_shared.py,test_imports.py. Concretecallers: async.py6,large.py6-7,
time.py81(clock+after_case),final.py124(finalTrue); shared directlyexercises
constructorlatecredit/large/storage invariants. Do notbroadlyrepeatcoordinator/
otherpassed suites unlessa specificchangedreturn/statecontractaffectsit; report
thedependencybeforeaddingchecks. Exactoldthresholds/errors remain.

Audit40AST/maxnest3/no classes/assert/customexceptions/globalmutablecontainers,
oneguard/actualinertimports empty+foreignargv andallCURRENTauthoredrecorders
guarded/inert (historicalfrozen artifacts separate). No deadcode/camelCase/
silencederrors/extraabstractions. Immutable119authority/118physical113resolved/
42orderedcodecs unchanged. Freshpriorhashes andbeforecurrentfrozenmap checked.

Pinned /home/codespace/.python/current/bin/python3 ->
/usr/local/python/3.14.2/bin/python3.14 SHA256
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601;
everydirectPython-B-S, optional-O foroptimized. ExactPYTHONPATH:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
Identityauthority evidence/coordinator-a/immutable-inputs.json; ordered42codec
defaultJSONdigest0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Existingcore-peer/audit.py immutable routine authority. GenericmissingDoD link
alreadyrecorded: explicitAGENTS/CODING/CONTRIBUTE/CIgates+exactscope govern,
notmissingnamedskill/noinventedfile/install/repeatedsearch. Readapplicable
project/role/narrow skills. No native/build/server/socket/SSLContext/TLSclose/
realclock/processownership/transfer/kernel/fault/race/cancel/scheduling/panic/
crash/leak/oldruntime/network execution. Onlypinnedin-memorycodec/suppliedfacts.
GraphifybeforeNEWcodebasequestion/search/read:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650
Providedpaths located. Rootsourcepublicationformat/Git/ASToperationsseparate;
native/fullprojectgates remainmandatorylater, no weakerbar.

Fullreport exactfiles/commands/rawoutputs/exits/RED/GREEN/frozenmaps/inputs/
historybounds/selfreview/gaps to task-5e3b8a-report.md; returnconcise DONE or
DONE_WITH_CONCERNS/NEEDS_CONTEXT/BLOCKED/reportpath/checksummary/concerns.
No commit. Root freshreview/qualifiedpublication/commit+immediatepush; then
remainingpeerunits/actualall40/broadreview/runtime/native/twochild/adoption/
everyoriginalmilestone stillrequired. No taskscope reduction or completionclaim.
