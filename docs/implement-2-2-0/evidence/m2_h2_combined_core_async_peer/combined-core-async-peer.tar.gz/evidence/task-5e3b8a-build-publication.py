"""Package reviewed delayed peer reuse and complete current check receipts."""
import hashlib
import json
import runpy
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    plan=Path('.superpowers/sdd/h2_streaming_plan')
    source=Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    provenance=Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_peer/combined-core-peer.tar.gz')
    if sha(provenance.read_bytes())!='dbcd7a01a56a3c80600aa39fa7b61dec00060976c14a82e2bd4a712a2520d25d':
        raise ValueError('Writer provenance differs')
    builder=plan/'task-5e3b7p1-build-publication.py'
    with tarfile.open(provenance,'r:gz') as previous:
        if previous.extractfile('evidence/'+builder.name).read()!=builder.read_bytes():
            raise ValueError('Published writer differs')
    writer=runpy.run_path(str(builder))['load_writer'](plan)
    baseline=Path('docs/implement-2-2-0/evidence/m2_h2_combined_coordinator_shutdown/combined-coordinator-shutdown.tar.gz')
    if sha(baseline.read_bytes())!='240fdc2ac208101249ff777b25a67a158e0b9f7d99b685200f4d37f9913a8218':
        raise ValueError('Baseline archive differs')
    members={}
    with tarfile.open(baseline,'r:gz') as previous:
        inventory=json.loads(previous.extractfile('INVENTORY.json').read())
        for member in previous:
            if not member.isfile():
                raise ValueError('Nonregular baseline member')
            if member.name=='INVENTORY.json':
                continue
            data=previous.extractfile(member).read()
            if inventory[member.name]!=dict(size=len(data),sha256=sha(data)):
                raise ValueError('Baseline inventory differs')
            if member.name.startswith('reference/'):
                writer['add'](members,member.name,data)
            if member.name.startswith('source/current/'):
                writer['add'](members,member.name.replace('source/current/','history/shutdown-coordinator-source/',1),data)
    audit=json.loads((plan/'task-5e3b8a-root-final-audit.json').read_text())
    current={path.name:sha(path.read_bytes()) for path in source.glob('*.py')}
    if current!=audit['current_source_sha256']:
        raise ValueError('Approved current source differs')
    for path in sorted(source.glob('*.py')):
        writer['add'](members,'source/current/'+path.name,path.read_bytes())
    raw=source/'evidence/core-async-peer'
    for path in sorted(raw.rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink in evidence')
        if path.is_file():
            writer['add'](members,'raw/core-async-peer/'+path.relative_to(raw).as_posix(),path.read_bytes())
    names=('task-5e3b8a-brief.md','task-5e3b8a-report.md','task-5e3b8a-initial-candidate-report.md',
           'task-5e3b8a-proof-completion-brief.md','task-5e3b8a-proof-resume-brief.md',
           'task-5e3b8a-proof-atomic-resume-brief.md','task-5e3b8a-finalize-brief.md',
           'task-5e3b8a-current-quality-brief.md','task-5e3b8a-review-brief.md',
           'task-5e3b8a-review-report.md','task-5e3b8a-review-source.diff',
           'task-5e3b8a-root-resume-audit.json','task-5e3b8a-root-final-audit.json',
           'task-5e3b8a-restore-inputs.py','task-5e3b8a-root-input-restoration-partial.json',
           'task-5e3b8a-root-input-restoration-extra.json','task-5e3b8a-root-input-restoration.json',
           'task-5e3b8a-root-final-audit-inputs.json','task-5e3b8a-build-publication.py',
           'task-5e3b1-root-source-restoration.json','task-5e3b-all40-peer-plan-report.md',
           'task-5e3b-all40-core-async-addendum.md','task-5e3b-aggregate-acceptance-notes.md')
    for name in names:
        writer['add'](members,'evidence/'+name,(plan/name).read_bytes())
    folder=Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_async_peer')
    folder.mkdir(parents=True,exist_ok=True)
    archive=folder/'combined-core-async-peer.tar.gz'
    inventory=writer['write_archive'](archive,members)
    manifest=dict(scope='Shared core delayed peer and standalone driver with synthetic peer facts',
                  base_commit=audit['base_commit'],baseline_archive_sha256=sha(baseline.read_bytes()),
                  archive=archive.name,archive_bytes=archive.stat().st_size,archive_sha256=sha(archive.read_bytes()),
                  safe_regular_text_members=len(members),inventory_entries=len(inventory),current_source_files=current,
                  changed_files=['test_core_peer.py','test_ready.py'],added_files=[],unchanged_modules=38,
                  core_peer_cases=['ready_buffered','async_delayed','large_declared','large_undeclared'],
                  direct_frame_reexport=True,shared_standalone_driver=True,driver_lines_before=127,driver_lines_after=37,
                  delayed_observed=dict(heads_before_final=3,request_data=0,data_end_count=0,final_observations=68,buffered_middleware_final=71),
                  delayed_selected_body_record=False,actual_producer_delayed_retention_proof=True,
                  actual_partial_health_delayed_final_status_rejection=True,current_normal_optimized_commands=14,
                  preceding_reported_stdout_only_checks=14,old_check_exit_stderr_metadata_missing=True,
                  source_ast_inert_import_modules=40,current_guarded_inert_helpers=13,current_helper_max_nesting=3,
                  current_recorder_nesting_corrected_from=4,prior_evidence_hashes_checked=9277,
                  preserved_unit_maps=[167,191,273],retained_identity_entries=119,physical_identity_rows=118,
                  unique_resolved_files=113,ordered_codec_files=42,atomic_source_restoration_before_checks=True,
                  initial_red_scope='Frame identity and unsupported delayed constructor before effects',
                  missing_pre_edit_identity_capture=True,initial_snapshot_after_first_green=True,
                  original_system_python_source_edit=True,required_context_read_after_initial_edit=True,
                  source_review='Spec and quality approved with historical qualifications',
                  coordinator_composition_accepted=False,actual_all40_executed=False,native_executed=False,milestone_complete=False,
                  remaining=['Pause/admission/Continue/credit/metadata/terminal peer extractions',
                             'Actual default/all40 aggregate and broad combined review',
                             'Runtime/native/full gates and production adoption'])
    (folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    result=dict(archive_sha256=manifest['archive_sha256'],archive_bytes=manifest['archive_bytes'],regular_members=len(members),
                inventory_entries=len(inventory),source_modules=40,all_reopened_member_bytes_exact=True,native_executed=False)
    (plan/'task-5e3b8a-root-archive-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
