# Finalize existing core async evidence, no implementation restart

Read /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-brief.md
forcompleteoriginalrequirements, then
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-proof-atomic-resume-brief.md
forcurrentrestore+executionconstraints. Base6061f0b/source40/currentmodulebytes
unchanged since14passedchecks. Sameownership2modules/newevidence/appendreport.
No otherimplementeractive; youarenotalone/preserveallhistory.

Two pendingruntimeproofs ALREADY PASS normal/O underatomicrestoration:
- retained completion/proof.py: actualproducer->delayed final68/output/Bbinding,
  prematurefinalafterfirsthealth. Oldandnewreceipts undercompletion/atomic_finish.
- inline-c health->delayed->prematurefinal/status: adapterfinal rejects case not
  complete; serializedstatusstream5 rejects requestcontract; heads2/DATA0/END0/
  recordsunchanged/contextincomplete. Both modes pass, sourcebeforeafterequal.

LastTerra ownerreturnedNEEDS_CONTEXT listingunfinishedadministrative/auditwork,
butgaveNO actualmissinginput/API/question. Rootescalatescapability forjudgment/
closure, notnewscope. Do notreruninitialimplementation/baseline/oldRED/14checks.
Finish exactremainingdeliverables below; ifgenuineinformationmissing, askRoot
aspecificquestionwhileindependentworkcontinues. Remainingtodo aloneisnotblocker.

1. Read actualrequiredcontext FULLY, boundedchunks asneeded:
   /workspaces/uWebZockets/AGENTS.md (205lines), CODING_CONVENTION.md(151),
   CONTRIBUTЕ.md is a ROOT TYPO withCyrillicE: actualASCIIpath is
   /workspaces/uWebZockets/CONTRIBUTE.md (relevantLocalchecks),
   CI_CD_PIPELINE.md(346), CODEBASE.md(486),
   benchmarks/http_throughput_guarantee.md(63),
   .codex/agents/verification.toml(124) andyourdeveloperrole. Narrow applicable
   .agents/skills using-agent-skills/test-driven-development/code-review-and-quality/
   debugging-and-error-recovery/incremental-implementation workflows. No
   unrelatedZigskills/install/newCONSTRAINTS interview. GenericmissingDoD
   referencealreadyruled: explicitprojectgates/exactscope govern, no inventedfile.
   Recordreadnow/afterinitialedits honestly; selfreviewallcurrenttouchedlines
   againstactualrules. Historicalbeforeeditcontextgap cannotbeerased.
2. Preserveallcurrentevidence/report/sourcebeforefinishing. Retain a GUARDED
   reproducibleafter-delayed proofscript matchingactualinlineproof. Recordfull
   exactcommands includingRootrestorer/flags/PYTHONPATH, andcurrentstdout/stderr/
   exit/sourcebeforeafter. Priorinlinepasses/normalproducerconsole-onlycapture
   remainqualifiedhistoricalresults, notfakecontemporaneousraw. ExecuteNEW
   guardedproofversionnormal/O withredirectedraw forreproduciblecoverage. For
   retainedproducerproof, reuseproperlyretainedoptimizedraw; ifnormalrawmissing
   ondisk, runonlymissingnormal capturewithnewlabel. No broadpassed-suitererun.
3. Finalcurrent40AST/import/inertcurrentrecorders/119identity/9277history audit,
   preserveinitial167files/6586Bprefix andeverylaterresumefile/reportappend.
   Bindcurrent40 toexistingfinal-source and14passingraws. Ifmoduleeditsneeded
   foractualrules/bug, realREDbeforefix+14rerunafterlastedit/newlabels; else
   no14repeat. Guardedevidence-onlyscripts preferred/no test_ready-producercycle.
4. AppendFULLreport currentcontextread/selfreview/proofs/commands/results/
   restoration+sourcebindings/currentaudits/historicalgaps. Supersedeblocked
   resumestatus explicitlywhilepreservingtext. ReturnDONEorDONE_WITH_CONCERNS
   forexactremainingrealgaps; Rootfreshindependentreviewstillmandatory.

CRITICAL EACHdependentexec_command shellstarts Root
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py
--restore NEWUNIQUE_JSONRECEIPT thenproof/audit IN SAME shell (set-e). TMP
resets acrosscontinuations. Itrestoresonlyexactsourcefrompinnedarchives and
verifies119/118/113/42/interpreter; noinventedpins/no binaries/no network/native.
Exactexample/PYTHONPATH/pinned-B-S/-O inatomicresumebrief. Empty/foreignargs
restorerinertimport/main verified. Uniqueallnewpaths/no overwrittenreceipts.

No native/build/server/socket/SSLContext/TLSclose/realclock/processownership/
oldruntime/network/Git/subagents/externalmodelCLI. Onlypurepinnedcodecs/supplied
facts. Rootowns allreview/publication/commits+immediatepush. Actualall40/native/
adoption/fullmilestones remainopen. Thisisfinalizationofoneunit, notglobaldone.
