# Core asynchronous peer, unit 1: implementation evidence

Status: DONE_WITH_CONCERNS. Two source files changed: `combined-cases/test_core_peer.py` and `combined-cases/test_ready.py`. Evidence is under `combined-cases/evidence/core-async-peer/`. This establishes standalone pure-codec behavior, not coordinator, all40, native, adoption, or milestone completion. Root owns review and publication.

Before edits, `baseline.py` compared the 40 current source hashes with `docs/implement-2-2-0/evidence/m2_h2_combined_coordinator_shutdown/manifest.json` and copied all source files to `before-source/`; it stored the complete 9,277-file pre-existing evidence map as `prior-evidence-map.json`. Raw output, exit 0: `accepted source=40 prior evidence files=9277`. The initial acceptance RED (`red.raw`, exit 1) stopped at `RuntimeError: frame alias differs` before wire activity. A separate constructor RED (`red-constructor.raw`, exit 1) stopped with `ValueError: unsupported core peer` before wire activity. Neither is a wire failure.

The shared peer now handles the exact health/delayed/health sequence; it validates metadata before incrementing heads, generates the delayed text response with the existing ten bytes, never indexes a delayed body record, and permits final collection only after the ordinary schedule. It rejects delayed DATA. The standalone driver calls the shared peer, re-exports `frame` directly, preserves clock and after-case invocation, and retains the old checks through the peer's online validation and bounded counters. Normal and optimized focused results below prove concrete calls only.

Pinned environment for all checks below (normal uses `-B -S`, optimized adds `-O`):

```sh
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH='/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'
P=/home/codespace/.python/current/bin/python3
D=.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
$P -B -S "$D/evidence/core-async-peer/baseline.py"
$P -B -S "$D/evidence/core-async-peer/acceptance.py"
$P -B -S -c "import test_core_peer as p; p.new_peer('async_delayed', app=p.new_app(), prior=(), now=1, clock=lambda: 2, final=True)"
$P -B -S "$D/evidence/core-async-peer/boundaries.py"
$P -B -S "$D/evidence/core-async-peer/current_audit.py"
$P -B -S "$D/evidence/core-async-peer/recorder_audit.py"
for opt in '' -O; do
  for name in test_ready test_async test_large test_time test_final test_shared test_imports; do
    $P -B -S $opt "$D/$name.py"
  done
done
```

The first acceptance command was run before and after edits. GREEN `attempt1.raw`, exit 0: `delayed heads=3 DATA=0 END=0 final=68 buffered_middleware=71`. This uses actual adapter dispatch, parsed response validation, and final observations; the delayed response lacks the optional middleware header. `boundaries.raw`, exit 0: `constructor/prior/premature-final/unexpected-DATA boundaries passed`. The negative packet checks invoke the actual peer packet parser but prepare ACK/pending state directly; they are state-boundary controls, not a complete serialized wire schedule. No `async_delayed` record exists or was selected in the actual run.

All 14 focused commands exited 0. Exact stdout/stderr are retained in the corresponding `attempt1-normal-*.raw` and `attempt1-optimized-*.raw` files. Both modes: ready and async print their respective `codec schedule passed`; large prints that line for each declared and undeclared case; time prints `fresh time checks passed`; final prints `ordinary capture passed: heads=73 final=68 chunks=2 max_span=19 return=None extra_requests=0`; imports prints `AST and inert import checks passed`. Shared logs contain the full late-credit, large upload, storage and order receipts, including parser=8201, 12208 upload frames and the split refund boundary.

`current_audit.raw`, exit 0:

```text
immutable rows=118 file_rows=118 unique_paths=113 ordered_codecs=42 digest=0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473 interpreter=4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601
AST modules=40 maximum control nesting=3; no class/assert/custom exception/module mutable containers
evidence helpers inert under empty and foreign argv: 0
source=40 changed=2 unchanged=38 history=9277
```

The zero helper count is the pinned routine's `audit*.py` glob and does not establish recorder coverage. Separate `recorder_audit.raw`, exit 0, reports `current recorders guarded/inert under empty and foreign argv: 5`. The 40-module `test_imports` normal and optimized runs cover module imports/guards. `before-source.json` and `final-source.json` bind baseline and current maps; `attempt1-source/` preserves the tested source. The pinned identity audit was run after edits; a fresh pre-edit immutable identity audit was not captured, although the prior evidence hash map and accepted source baseline were captured before edits.

Graph update command: `env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .`. Exit 0, raw relevant output: `No relevant changes; graphify-out left untouched. Code graph updated.`

Self-review and limitations: The supplied clock is used for adapter timing while the shared standalone peer receive timestamp remains the old constant 2, preserving the previous driver contract. The nonempty application output/binding retention is preserved by construction and covered for existing core cases by `test_shared`, but this unit does not independently demonstrate a nonempty output/binding preceding delayed. The negative test sets ACK/pending state directly and does not independently demonstrate fabricated final permission after a partial actual wire schedule. The source snapshot was taken after the first successful acceptance run, although it reflects the same source; no separate snapshot was made immediately before that run. A single source-edit operation used the system `python3` rather than the specified pinned interpreter; it was not a test or evidence execution. The project and skills were concatenated to a local temporary context file, but their entire contents were not surfaced for review in this session. Independent review must assess these gaps and the source diff before acceptance. No native or project-wide Zig checks were executed; all original gates remain open.
