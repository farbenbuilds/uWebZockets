# Core asynchronous peer, unit 1: implementation evidence

Status: DONE_WITH_CONCERNS. Two source files changed: `combined-cases/test_core_peer.py` and `combined-cases/test_ready.py`. Evidence is under `combined-cases/evidence/core-async-peer/`. This establishes standalone pure-codec behavior, not coordinator, all40, native, adoption, or milestone completion. Root owns review and publication.

Before edits, `baseline.py` compared the 40 current source hashes with `docs/implement-2-2-0/evidence/m2_h2_combined_coordinator_shutdown/manifest.json` and copied all source files to `before-source/`; it stored the complete 9,277-file pre-existing evidence map as `prior-evidence-map.json`. Raw output, exit 0: `accepted source=40 prior evidence files=9277`. The initial acceptance RED (`red.raw`, exit 1) stopped at `RuntimeError: frame alias differs` before wire activity. A separate constructor RED (`red-constructor.raw`, exit 1) stopped with `ValueError: unsupported core peer` before wire activity. Neither is a wire failure.

The shared peer now handles the exact health/delayed/health sequence; it validates metadata before incrementing heads, generates the delayed text response with the existing ten bytes, never indexes a delayed body record, and permits final collection only after the ordinary schedule. It rejects delayed DATA. The standalone driver calls the shared peer, re-exports `frame` directly, preserves clock and after-case invocation, and retains the old checks through the peer's online validation and bounded counters. Normal and optimized focused results below prove concrete calls only.

Pinned environment for all checks below (normal uses `-B -S`, optimized adds `-O`):

```sh
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH='/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'
P=/home/codespace/.python/current/bin/python3
D=.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
$P -B -S "$D/evidence/core-async-peer/baseline.py"
$P -B -S "$D/evidence/core-async-peer/acceptance.py"
$P -B -S -c "import test_core_peer as p; p.new_peer('async_delayed', app=p.new_app(), prior=(), now=1, clock=lambda: 2, final=True)"
$P -B -S "$D/evidence/core-async-peer/boundaries.py"
$P -B -S "$D/evidence/core-async-peer/current_audit.py"
$P -B -S "$D/evidence/core-async-peer/recorder_audit.py"
for opt in '' -O; do
  for name in test_ready test_async test_large test_time test_final test_shared test_imports; do
    $P -B -S $opt "$D/$name.py"
  done
done
```

The first acceptance command was run before and after edits. GREEN `attempt1.raw`, exit 0: `delayed heads=3 DATA=0 END=0 final=68 buffered_middleware=71`. This uses actual adapter dispatch, parsed response validation, and final observations; the delayed response lacks the optional middleware header. `boundaries.raw`, exit 0: `constructor/prior/premature-final/unexpected-DATA boundaries passed`. The negative packet checks invoke the actual peer packet parser but prepare ACK/pending state directly; they are state-boundary controls, not a complete serialized wire schedule. No `async_delayed` record exists or was selected in the actual run.

All 14 focused commands exited 0. Exact stdout/stderr are retained in the corresponding `attempt1-normal-*.raw` and `attempt1-optimized-*.raw` files. Both modes: ready and async print their respective `codec schedule passed`; large prints that line for each declared and undeclared case; time prints `fresh time checks passed`; final prints `ordinary capture passed: heads=73 final=68 chunks=2 max_span=19 return=None extra_requests=0`; imports prints `AST and inert import checks passed`. Shared logs contain the full late-credit, large upload, storage and order receipts, including parser=8201, 12208 upload frames and the split refund boundary.

`current_audit.raw`, exit 0:

```text
immutable rows=118 file_rows=118 unique_paths=113 ordered_codecs=42 digest=0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473 interpreter=4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601
AST modules=40 maximum control nesting=3; no class/assert/custom exception/module mutable containers
evidence helpers inert under empty and foreign argv: 0
source=40 changed=2 unchanged=38 history=9277
```

The zero helper count is the pinned routine's `audit*.py` glob and does not establish recorder coverage. Separate `recorder_audit.raw`, exit 0, reports `current recorders guarded/inert under empty and foreign argv: 5`. The 40-module `test_imports` normal and optimized runs cover module imports/guards. `before-source.json` and `final-source.json` bind baseline and current maps; `attempt1-source/` preserves the tested source. The pinned identity audit was run after edits; a fresh pre-edit immutable identity audit was not captured, although the prior evidence hash map and accepted source baseline were captured before edits.

Graph update command: `env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .`. Exit 0, raw relevant output: `No relevant changes; graphify-out left untouched. Code graph updated.`

Self-review and limitations: The supplied clock is used for adapter timing while the shared standalone peer receive timestamp remains the old constant 2, preserving the previous driver contract. The nonempty application output/binding retention is preserved by construction and covered for existing core cases by `test_shared`, but this unit does not independently demonstrate a nonempty output/binding preceding delayed. The negative test sets ACK/pending state directly and does not independently demonstrate fabricated final permission after a partial actual wire schedule. The source snapshot was taken after the first successful acceptance run, although it reflects the same source; no separate snapshot was made immediately before that run. A single source-edit operation used the system `python3` rather than the specified pinned interpreter; it was not a test or evidence execution. The project and skills were concatenated to a local temporary context file, but their entire contents were not surfaced for review in this session. Independent review must assess these gaps and the source diff before acceptance. No native or project-wide Zig checks were executed; all original gates remain open.

## Resume audit: blocked by missing pinned temporary inputs

The 6,586-byte initial report prefix was preserved. The resume audit verified all 40 current source hashes and all 167 pre-existing unit evidence hashes against `task-5e3b8a-root-resume-audit.json`; the initial report SHA-256 was `0950276a9279ccbd0724510ffa0a707e79b2cf98570aa39df24c0151f56b4954`. The pinned Python `-B -S` command exited 0 and printed `resume source=40 unit=167 report=6586 sha=0950276a9279ccbd0724510ffa0a707e79b2cf98570aa39df24c0151f56b4954`.

The resume audit's 167 files already include `completion/proof.py` and its normal and optimized raw results. Those retained results report a serialized partial-health rejection and an actual producer-to-delayed chain, but the partial test attempts premature final after health, before the delayed response; the requested partial health/delayed boundary remains open. They are historical artifacts and were not rerun in this resume.

Current identity audit command, with the same `PYTHONPATH` and interpreter as above:

```sh
$P -B -S "$D/evidence/core-async-peer/resume_proofs/audit.py" before
```

Exit 1, ending in `FileNotFoundError: [Errno 2] No such file or directory: '/tmp/uwz-task5c3-runtime-v2/expectations.py'`. A second invocation with argument `retry` likewise exited 1; its full raw traceback is `evidence/core-async-peer/resume_proofs/identity-failure.raw`. Both attempts wrote their source maps before failing, and those maps matched the original final source map. `/tmp/uwz-task5e1-contract-v3`, `/tmp/uwz-task5e3a-snapshot-v9/source`, and `/tmp/uwz-h2-client-tooling/packages` were also absent. Current identity and runnable proof completion therefore remain blocked pending exact restoration of pinned inputs. No source modules were changed or old results repeated.

A separate pinned Python `-B -S` static structure and prior-history check, calling the retained `core-peer/audit.py` structure routine and comparing each SHA in `prior-evidence-map.json`, exited 0 with raw output:

```text
AST modules=40 maximum control nesting=3; no class/assert/custom exception/module mutable containers
prior evidence=9277 mismatches=0
first mismatch=[]
```

The resulting current structure map is `evidence/core-async-peer/resume_proofs/structure.json`. This static result does not substitute for the missing identity, inert import, or runtime proof. Required complete context review and line-by-line self-review also remain open; the attempted concatenated context read was truncated. The previously documented missing pre-edit identity, post-first-GREEN freeze, and system-Python source-edit gaps remain unchanged. No native, project-wide, or all40 gate was run.

## Finalization: current proof and audit work complete

Status: DONE_WITH_CONCERNS for this standalone pure-codec unit only. This section supersedes the earlier BLOCKED/resume status for current input restoration, context review, proofs, and audits; all earlier report text and artifacts remain intact. There is no missing input or API blocking this slice. Root's fresh independent source/spec/quality review remains mandatory before acceptance or publication.

No source module changed during this finalization. The complete current40 equals both the original `final-source.json` and the 40 files in `attempt1-source/` used by the 14 passing focused commands. Relative to accepted BASE `6061f0bc11190eae5733914bbdf83d490722f8ef`, only `test_core_peer.py` and `test_ready.py` differ; the other38 remain unchanged. Current SHA-256:

- `test_core_peer.py`: `861f60664ec808ddc80781ba1d9ced03f2665f16700471a4864a335103b1308f`.
- `test_ready.py`: `86747df89e9c7f6905aef432c468b56b44dd49dbc3642bce8a89660fb4f1fdd3`.

### Context read now and self-review

During finalization, the following actual files were surfaced and read completely: `AGENTS.md`, `CODING_CONVENTION.md`, ASCII `CONTRIBUTE.md` (including Local checks), `CI_CD_PIPELINE.md`, `CODEBASE.md`, `benchmarks/http_throughput_guarantee.md`, `.codex/agents/developer.toml`, and `.codex/agents/verification.toml`. Applicable local workflows read completely: `using-agent-skills`, `test-driven-development`, `code-review-and-quality`, `debugging-and-error-recovery`, and `incremental-implementation`. Oversized combined tool output was reread in bounded individual calls. These reads occurred AFTER the original implementation; they do not repair the historical before-edit context gap.

The original task brief, completion brief, atomic-resume brief, finalization brief, accepted peer plan's shared contract and unit1, full async addendum, and full aggregate acceptance notes were read. The Graphify fast-path/query instructions were consulted and the query below ran before new code exploration. The generic absent Definition-of-Done reference remains governed by Root's existing ruling: explicit project gates and this scoped task apply; no file was invented or skill installed.

Every touched module diff line was reviewed against those rules using retained `finalize_v1/test_core_peer.py.diff` and `test_ready.py.diff`, plus both complete current modules. The delayed request uses the canonical GET/empty-body contract, primary ordinal1, exact metadata validation before head increments, and exact existing ten-byte response. The ordinary health/delayed/health cursor gates status requests; no delayed body record is read or selected and no fabricated DATA-END establishes completion. Metrics still derive from earned app heads and body records. The shared app retains outputs/binding; constructor validation remains independent of client context. The old upload/echo, parser pre-growth, pending, HPACK, refund split and incremental hash logic is unchanged.

The driver now directly imports the frame alias and uses the shared peer. Removed request/head histories are replaced by the peer's online exact order/header/terminal checks. The echo's one accepted DATA is enforced by `echo_data`'s terminal guard (the separate `frames` field counts large-upload frames); large count/hash checks remain explicit. The supplied adapter clock and after-case position remain intact; the standalone peer receive timestamp stays the previous constant2. No context-inspection wrapper was introduced. Source dependencies remain one-way core -> codec/model and driver -> core. No source correctness issue requiring a module edit was found in this self-review.

### Evidence preservation and exact commands

All new evidence is under:

`/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1`

The first restoration and freeze command is retained verbatim in `freeze_command.sh`. It checked source40 equality and retained `before_source.json`, a fresh `before_unit.json` map of all191 then-existing unit files, and the full9,284-byte `before_report.md` (SHA-256 `f1acef1f4a5bdc133dac8e7d75cd6130e43855610db0e51955a311c36e380554`). Its console-only output reported exit0; no retrospectively manufactured redirected raw is claimed. The original167-file Root map and original6,586-byte prefix remain separately checked. Existing resume/failed identity artifacts were preserved.

Each dependent proof/audit shell starts with the exact Root restorer using a new unique receipt, followed by the dependent operation in the SAME shell. The proof shells retained verbatim are `partial_normal.sh` and `partial_optimized.sh`; each includes the complete interpreter flags, exact PYTHONPATH, source snapshots before/after, stdout/stderr redirection, and exit capture. They contain these exact proof invocations after restoration:

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S  /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1/partial_proof.py --prove
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S -O /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1/partial_proof.py --prove
```

Corresponding unique Root-restorer invocations are:

```sh
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1/partial_normal_inputs.json
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1/partial_optimized_inputs.json
```

Use the retained complete shell bodies for command order and all redirects; commands cannot reuse an existing restoration receipt filename. All new direct Python execution used the pinned `/home/codespace/.python/current/bin/python3 -B -S`; the optimized proof adds `-O`. Restorer receipts verify the exact source archive closure and interpreter; no binary installation or native execution occurred.

### Actual proof results

New guarded `partial_proof.py` SHA-256 is `f572744ee42af300b559e0484da736c678eb4b51547a41010911f3de5982fded`. It is inert on import and when executed with empty or foreign arguments; explicit `--prove` enables execution. It uses actual startup/SETTINGS/ACK, adapter health and primary delayed operations, canonical response validation, then both adapter final collection and an encoded stream5 status request through the actual peer send/parser path. It does not prepare ACK/pending state directly. Both normal and optimized runs exited0 with empty stderr and this exact stdout:

```text
serialized health -> delayed -> premature final/status rejected; heads=2 DATA=0 END=0 records unchanged context incomplete
```

The adapter rejects with `case not complete`; the serialized premature status rejects with `request contract differs`. The delayed response is ten bytes and terminal. Heads/cursor/app heads remain2, DATA/END remain0, records remain unchanged with no delayed record, context remains incomplete, final registrations remain0 and no final observation is published. This proves no unearned application or completion facts, not complete parser/HPACK rollback after a malformed request.

Raw files: `partial_normal.stdout/.stderr/.exit`, `partial_optimized.stdout/.stderr/.exit`; associated `*_restore.stdout/.stderr/.exit` and `*_inputs.json`; and `*_before_source.json` / `*_after_source.json` bind the same40 source and exact evidence scripts around each proof. Both restoration exits were0. No source module was edited, so the14 passing focused suites were not rerun.

The actual producer-to-delayed/final68 and partial-after-first-health coverage already has retained normal `completion/proof-attempt1.raw` and optimized `completion/proof-optimized.raw`. Both are preserved and bound by the original167 map and current final bindings. They report producer heads9, delayed heads3, final68, app heads80, unchanged nonempty actual output/B binding and records, with independently copied client observations. Their script calls the unchanged producer constructor and actual adapter dispatch; it does not seed prior success or call a family check. Existing `completion/normal.raw` and `optimized.raw` are identity-audit output, not producer stdout. Thus no missing normal producer capture remained on disk and neither producer proof was unnecessarily repeated.

The atomic-resume handoff also describes later successful inline and console-only runs. No `completion/atomic_finish/` directory is present in the frozen191-file inventory. Those later inline/console results remain qualified historical statements; this finalization does not invent missing contemporaneous raw files. The newly retained script/raws provide reproducible after-delayed coverage, while the original producer raws provide retained producer evidence.

### Final audits and preserved failed attempt

`final_audit.sh` ran the first audit and exited1 after identity, source40 AST, and source40 inert import checks passed. Its additional recorder nesting assertion found depth4 in the untouched pre-existing `recorder_audit.py` (nested mock contexts). This extra assertion extended the task's source40 max-depth requirement to historical recorder code. Exact failing source, command, stdout/stderr and exit are retained both at their original new paths and under `frozen_audit_attempt1/`.

The separately versioned `audit_final.py` keeps source40 max nesting3 enforcement, enforces it on newly authored scripts, and tests ALL current recorders for a single main guard and inert imports under empty/foreign argv. It does not change the historical recorder. The depth4 historical auditor is an explicit review concern, not a source40 failure hidden by lowering a source gate.

The exact final audit command/restoration/redirects are retained in `final_audit_attempt2.sh`. Its restorer and audit both exited0, stderr was empty, and `final_audit_attempt2.stdout` contains:

```text
immutable rows=118 file_rows=118 unique_paths=113 ordered_codecs=42 digest=0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473 interpreter=4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601
AST modules=40 maximum control nesting=3; no class/assert/custom exception/module mutable containers
AST and inert import checks passed
current recorders guarded/inert under empty and foreign argv: 11
source=40 changed=2 unchanged=38; original unit=167 resumed unit=191 history=9277 preserved
14 historical focused raws and actual producer normal/optimized raws bound; frame alias and one-way imports passed
```

`audit_attempt2/immutable-inputs.json` and `structure.json` retain the current authority and40-module structure. `recorders.json` lists all11 audited current helpers (frozen historical source directories are explicitly separate). New helpers also pass inert main execution with empty/foreign arguments. The module inert check uses the existing forbidden-hook import checker; it creates no socket, SSLContext, process, real-clock, or native operation. `final_bindings.json` binds all40 sources, all14 original focused raw hashes, both producer raw hashes, original167 and current191 historical evidence maps, full report prefix, and prior9,277-file map. The119 authority-entry/118 physical-row/113 resolved-file/42 ordered-codec distinction is preserved.

Graphify query (exit0):

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "core async peer completion proof evidence test_core_peer test_ready" --budget 650
```

After evidence-script changes, the required AST-only update exited0, with redirected `graph_update.stdout/.stderr/.exit`:

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .
```

It reported no relevant changes and left graph output untouched. Two initial read-only adapter-path probes used incorrect guessed locations and exited2; the actual local `combined-cases/adapter.py` was then read. These were source-location errors, not failed runtime proofs, and caused no edits.

### Remaining qualifications

The missing fresh pre-edit119-identity capture, post-first-GREEN source-freeze timing, original system-Python source-edit operation, and before-edit context-review gap remain historical limitations. The untouched historical recorder auditor's depth4 is disclosed above. The new current audit and source bindings cannot retroactively repair any of those facts.

Only the new `evidence/core-async-peer/finalize_v1/` artifacts and this report append were written by this finalizer. Source modules, all other peers/coordinator/handlers/models/codecs, pins and previous evidence were preserved. No Git, subagents, native/build/server/network/SSLContext/TLS-close/real-clock/process-ownership execution or external model CLI was used.

Root still owns fresh independent review, source acceptance, publication and commits/push. The full project formatting/conventions/release-version/Zig tests, native and broader compliance/platform gates were not run in this explicitly pure-codec slice and remain mandatory at their released phase. Actual all40/default coordinator acceptance, remaining peer units, runtime closure, sequential two-child native acceptance, product adoption and every original milestone remain open.


## Current quality closure after Root review of the finalization report

Status: DONE for the two current quality corrections released in `task-5e3b8a-current-quality-brief.md`. This section supersedes the previous classification of the live recorder's nesting violation as an unresolved historical concern and the claim that stdout hashes alone suffice to verify the14 focused check receipts. The original historical provenance qualifications remain unchanged. No source module or runtime proof was restarted or changed.

### Live helper correction with preserved original bytes

Root correctly ruled that `evidence/core-async-peer/recorder_audit.py` was authored in this still-unaccepted8a unit, so its depth4 violated the current project max3 requirement. The earlier decision to exclude that live helper from depth enforcement was insufficient. The failed strict audit and the later scoped audit remain preserved, without rewriting their results.

Before editing, a fresh command-local Root restoration and freeze preserved all273 then-existing unit artifacts in `quality_v1/before_unit.json`, the full23,795-byte report in `quality_v1/before_report.md`, source40 in `before_source.json`, and the original helper bytes at:

`/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/quality_v1/frozen_before/recorder_audit.py`

The freeze command is retained verbatim in `quality_v1/freeze_command.sh`; its tool-console result was exit0. Original helper SHA-256: `66b8c5d3a95caece58612bd4ef2394a384c9c3b482fc4c20fac71362fb6d8859`. The snapshot is read-only.

The live helper's two nested mock context blocks were combined into one parenthesized `with` statement. All six patches, their entry order, stdout/stderr write rejection, single-main-guard check, and both empty/foreign argv cases remain intact. The unchanged nested loops plus one context block now have maximum depth3. New live helper SHA-256: `7cf8552d499718c977f98476d57f927666f65dc2a247b5f362a9fa472cece533`.

This is the only modification to an existing artifact in this quality closure. The previous167-,191-, and273-file maps now resolve the `recorder_audit.py` entry to that exact frozen original; every other entry is checked at its unchanged original path. They are NOT claims that all old paths still have the old live bytes. `quality_v1/final_bindings.json` records the explicit old snapshot/new live mapping, both hashes/depths, and all map counts. The9,277-file prior-unit history remains entirely unchanged. Older audit commands retain their historical meaning and may reject the intentionally updated live helper if replayed without this explicit mapping.

### Fresh focused check receipts

The old14 `attempt1-normal/optimized-test_*.raw` files contain stdout. The Root resume audit and finalization bindings contain their hashes, not separately captured process exits or stderr. No complete stored per-check exit/stderr/command receipts were found in the unit evidence or the referenced Root receipt. The old report's exit0 statements remain historical reported results; they were not promoted to independently verified empty stderr/exits.

Root explicitly authorized a fresh run of exactly the seven original modules in normal and optimized mode to close this new material evidence gap. No broader suite or previous runtime proof was rerun. The14 fresh commands completed successfully under the same pinned interpreter and immutable source inputs. Each has:

- `quality_v1/<mode>_<module>.sh`: exact executed shell, complete Python argv/PYTHONPATH, same-shell restoration and all redirections.
- `<mode>_<module>_before.json` and `_after.json`: exact argv, cwd, explicit environment, interpreter hash and all40 source hashes; before equals after.
- Separate `.stdout`, `.stderr`, and `.exit`: full stdout, empty stderr and exit0 for every command.
- Unique `_inputs.json` and separate `_restore.stdout/.stderr/.exit`: command-local restoration evidence.

Modes are `normal` and `optimized`; modules are `test_ready`, `test_async`, `test_large`, `test_time`, `test_final`, `test_shared`, and `test_imports`. All14 module source maps equal the prior final40 and original attempt1 source snapshot. The executed serial batch is retained in `quality_v1/focused_batch.sh`; its tool process exited0. Per-check records are independently complete, so an interruption would require only unfinished checks to resume.

The exact command form (expanded concrete commands are in each retained shell and JSON record) is:

```sh
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/quality_v1/<mode>_<module>_inputs.json
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S [-O] /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/<module>.py
```

The bracketed `[-O]` denotes the optimized mode only, not a literal argument. Actual argv arrays have no placeholders. Every check followed its restoration in the same shell; no prior continuation's temporary files were assumed to persist.

Stdout includes ready/async success, both large schedules, `fresh time checks passed`, the final-boundary receipt `heads=73 final=68 chunks=2 max_span=19 return=None extra_requests=0`, shared late-credit/large/storage/order receipts, and `AST and inert import checks passed`. All exact logs remain on disk. `quality_v1/focused_receipts.json` hashes all14 command, stdout, stderr, exit, metadata and restoration record sets. No old receipt was overwritten and no claim is made that the old stdout-only logs had failed.

### Strict final audit

`quality_v1/strict_audit.sh` retains the exact restoration and commands. The live recorder auditor ran with pinned `-B -S` and exited0 with empty stderr, reporting its existing top-level5-helper import scope. The new strict auditor `quality_v1/audit.py --audit` then exited0 with empty stderr and verified the complete recursive current-helper inventory, including the corrected helper. Its stdout:

```text
immutable rows=118 file_rows=118 unique_paths=113 ordered_codecs=42 digest=0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473 interpreter=4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601
AST modules=40 maximum control nesting=3; no class/assert/custom exception/module mutable containers
AST and inert import checks passed
ALL current helpers guarded/inert empty+foreign argv; count=13 max_nesting=3
14 fresh focused checks verified: exit0, empty stderr, exact metadata/source before=after
source40 unchanged; history9277 and maps167/191/273 preserved with explicit recorder snapshot mapping
live recorder_audit.py depth4->3; original bytes retained; report prefix=23795 bytes
```

Artifacts: `strict_audit.stdout/.stderr/.exit`, separate recorder and restoration logs/exits, `immutable-inputs.json`, `structure.json`, `helper_depths.json`, `focused_receipts.json`, and `final_bindings.json`. Historical source snapshots and explicit frozen audit/helper versions are excluded from the CURRENT helper set; no live helper is exempt from max3. All13 current helpers have one main guard and inert imports with empty/foreign argv. The119 authority/118 physical/113 resolved/42 ordered codec distinctions remain intact.

Self-review checked the helper delta against the old snapshot: only control nesting changed, no interception or guard was removed. New capture and audit scripts pass the same strict max3/guard/inert checks. The original two module hashes remain exactly those listed in the preceding finalization section. No accepted threshold or source gate was weakened.

The AST-only Graphify update was run after the helper/scripts changed:

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .
```

Exit0, retained `quality_v1/graph_update.stdout/.stderr/.exit`; no relevant graph changes.

Changed existing file: `evidence/core-async-peer/recorder_audit.py`. New files: the bounded quality capture/audit evidence under `evidence/core-async-peer/quality_v1/`. This report was appended. No source40 module, model, coordinator, peer outside the assigned unit, dependency, runtime proof or old receipt was edited.

Both current quality gaps are closed. Historical pre-edit identity, initial freeze timing, original interpreter used for one source edit, and before-edit context-review qualifications remain accurately recorded. Root's fresh independent source/spec/quality review is still required before publication. Native/project-wide checks, actualall40, adoption and all original milestones remain open; no native/build/server/network/Git/subagent/process-ownership work occurred.

