# Finish pending async proofs with command-local input restoration

Originalrequirements:
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-brief.md
andcurrentproofgaps:
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-proof-completion-brief.md.
Readthosefirst, then thiscurrenthandoff. Currentreport:
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-report.md.
BASE6061f0bc11190eae5733914bbdf83d490722f8ef/source40/onlycore+readychanged.
Previousproofowners stoppedorhandlesdisappeared aftergoalcontinuations;
doNOTredoexistingimplementation, baseline, oldREDs or14passingchecks.

Rootcorrection: existing evidence/core-async-peer/completion/proof.py andits
normal/Oraws ALREADY existedwithin167Rootpinnedartifacts, despiteearliertop-level
onlylistingmissingthem. Assessandpreserveexistingactualproducer->delayed and
after-healthpartial-final coverage. No reportappendwasmadeatthattime. Subsequent
resume ownerverified40/167/initial6586Bprefix and9277history/AST butidentity
failedbecauseTMPwasabsent; its honestBLOCKEDappend andresume_proofs failures
remain. Currentnewwork iscompletecontextreview/currentproofvalidation and
theafter-delayed-before-final-health boundary ifnotalreadycovered.

## Critical execution boundary

TMPsourceinputs disappearedagainbetweencontinuations AFTERrestoration. Root
fixedthiswithoutchangingpins/PYTHONPATH: execute exactRootrestorer immediately
beforeeachdependentproof/audit IN THE SAME exec_command SHELL. Do notassume
previouscall's/tmporreceiptpersists. ExactRoothelper:
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py
Itrequires --restore NEW_RECEIPT_PATH, copiesonlymissingexactUTF8sourcebytes
frompinnedcommittedarchives, rejectswrongexistingbytes, thenverifies119authority/
118physical113resolved/42orderedcodecs/interpreter before returning0. Itrestores
no binaries/fullnativecandidate, performsno install/network/nativeexecution.
Import/mainemptyforeignargv verifiedinert. Rootsuccessreceipt
task-5e3b8a-root-input-restoration.json records129restored inthatcommand only.

ExampleoneSHELLcommand (useNEWlabels/paths, notliteralrepeat):

```sh
set -e
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/atomic_resume/normal-inputs.json
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S PATH_TO_GUARDED_PURE_PROOF
```

For-Oproofadd-OtoPROOF interpreter;restoreritselfnormalpinnedisfine. Eachnew
receiptfilenameunique; helperrefusesoverwrite. Preservecommandmetadata/full
stdout/stderr/exit/sourcebeforeafter forbothrestore+proof. Ifcheckpointtakes
severaltoolcalls, restorationbelongsintheSAMEshellasimport/audit/proof, notan
earliertoolcall. Restorehelperdoesnotrunproofs/servers/processownershiptools.

## Scope and remaining deliverables

Sameoriginalownershiponlytest_core_peer.py/test_ready.py/newevidenceinside
core-async-peer/appendsamereport; youarenotalone/preserveothers. Freezeallcurrent
source40/currentunit/report before newwork. Existinginitialreport6586B SHA
0950276a9279ccbd0724510ffa0a707e79b2cf98570aa39df24c0151f56b4954 andRootinitial
167filemap in task-5e3b8a-root-resume-audit.json remainauthoritativehistory.
Preserveanylaterresume files/appendedreporttoo; no oldreceiptsoverwritten.

Readpreviouslyunreadrequiredcontext FULLY inboundedchunks, thenselfreviewevery
touchedline againstactualrules. Recordreadnow/afterinitialedits honestly.
Actualpartial-final proof afterhealth isrealcoverage; supplementafterdelayed
beforefinalhealth toprove finalpermissiondoesnotbypasslastordinaryhead. No
ACK/pendingstatepreparation innewserializedproof. Independentactualproducer
chain mayalreadymeetrequirement; assessoldscript, preservehistoricalruns and
freshvalidatebothmodesaftercommand-localrestoration ifneeded. Nofamilycheck,
modelseed/defaultselectedfacts/extraoutputGET; compareactualparsedoutput/B
bindingtoindependentlyearnedapp acrossfreshdelayedcontext/final68.

Preferguardedevidence-onlyscripts; no newtest_ready/producerimportcycle or
publicparameters/appshape. Actualbug getsrealRED/freezeBEFOREfix. Ifmodules
unchanged, bindcurrent40tooldfinalmap/14passingreceipts andDO NOTrepeatsuites.
Ifmodulechanges, rerun14afterlastedit withcommand-localrestoration/newlabels.
Finishcurrent40AST/inertimports/currentrecorders/pinned119/history9277 audit.
AllPythonexactpinned-B-S; historicalsystemPythonEDIT/missingpreeditidentity/
postGREENfreeze remainqualified, neverfabricatedhistory. GenericmissingDoD
alreadyruledviaexplicitprojectgates, nofileinvention/repeatedsearch/approval.

No native/build/server/socket/SSLContext/TLSclose/realclock/processownership/
oldruntime/network/Git/agents/externalmodelCLI. Onlypinnedin-memorysourceproofs.
No sourceacceptance/pub/nextunitrelease untilRootfreshindependentreview.
Appendfullreport contextread/currentactualproofs/commands/raw/restore+source
bindings/audits/scope/gaps, concise status. Rootowns everyGit/publicoperation.
