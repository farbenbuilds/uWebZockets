The existing application shape suffices. `async_delayed` needs no additional persistent field or body record.

- `test_core_peer.py:19` new_app initializes records, heads, outputs, binding.
- `test_core_peer.py:153` packet_received validates decoded headers before incrementing persistent app.heads. Delayed earns three increments from /health, /delayed, /health.
- `test_core_peer.py:59` metrics derives buffered_middleware = app.heads - sum(record.middleware). Delayed changes no body record, so its actual requests contribute three. This matches test_ready.py:69 and immutable /tmp/uwz-task5e1-contract-v3/model.py:365.
- Later fresh connections share the same app and retain those increments. Async-only final68 earns another68, producing71 buffered middleware observations when body middleware is zero. Metrics request increments heads before response generation.

Missing retained x-middleware response header does not subtract its request from the metric. Preserve content-type:text/plain, exact ten-byte body and terminal validation under model.validate_core_response at model.py:410.

Unit1 distinguishes delayed from uploads at existing seams:

1. primary_contract uses model.core_request('async_delayed'): GET, empty body, HEADERS END.
2. request_path/validation uses three ordinary heads and primary ordinal1.
3. Upload record mutation at test_core_peer.py:159 applies only to large uploads; no records.async_delayed exists.
4. Completion uses actual delayed response/final health sequence. DATA and DATA-END stay0; final68 never fabricates upload END.

Persistent heads retains metric contribution; canonical dispatch completion/coordinator selection retains actual case completion. Head count alone never establishes selected-before identity.

Replace duplicate test_ready.frame definition with direct re-export `from test_core_peer import frame`. Existing callers then use the same function object, no forwarding wrapper. Dependency stays one-way: test_ready imports core; core imports only codec/model dependencies, never driver. test_core_peer.py:2 currently follows that direction.

No app-shape/immutable-model gap found. Source-based architect clarification only; no checks executed or P8 source inspected.
