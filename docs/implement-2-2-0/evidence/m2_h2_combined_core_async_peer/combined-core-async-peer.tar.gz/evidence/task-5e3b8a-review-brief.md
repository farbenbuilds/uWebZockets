# Core async shared peer source review

Review ONE unit8a, spec thenquality. Requirements task-5e3b8a-brief.md,
accepted task-5e3b-all40-peer-plan-report.md unit1 and
task-5e3b-all40-core-async-addendum.md. Claims task-5e3b8a-report.md now33039B
SHA25647560139579154d14e15e0414fe721894134b2b5b3c854758923b2f41619b0a7.
Fullreviewdiff task-5e3b8a-review-source.diff25245B SHA256
b0e00ba4ed751a9a0f0aeef051fb8449939309906b824f2a9a4cd7f1f66d1acf.
BASE/HEAD6061f0bc11190eae5733914bbdf83d490722f8ef/no taskcommit.
Source40 onlytest_core_peer/test_ready changed38unchanged. Diffincludesfull
newactualproducer/partialproofs pluslivehelperold->newnestingdelta.

Rootfinalaudit task-5e3b8a-root-final-audit.json independentlybinds current40/
accepted40/frozeninitial40,14FRESH focusednormalO per-checkargv/cwd/env/source
before=after/stdout/stderr/exit/restore receipts, all0emptyerr. Old14.raw were
stdoutonly/reportclaimedpasses, notcurrentverifiedstderr/exits. Fresh14 exactly
sevenoriginalmodules ready/async/large/time/final/shared/imports x2, no broaden.
9277priorhashes/167/191/273unitmaps verified withexplicitoldhelperfrozenmapping;
oldreportprefix23,795B unchanged.119authority118physical113resolved+42ordered
codecfiles checked. All13currenthelpers max3/guards/inertimports; source40same.

Bindingrequirements:
- Existingnew_peer signature(nofaultarg) exactconnection/state/7facts andapp
  records,heads,outputs,binding unchanged. Asyncaddshealth/delayed/health,
  GET/emptybody/HEADERSEND/primaryordinal1/exact10byteresponse+content-type,
  optionalmissingretainedmiddleware. No delayedbodyrecord orfakeDATAEND.
- Decodedvalidatedheaders earnappheads; delayed3+final68->71 middleware
  observations viaheads-sumrecordmiddleware, notselectedmodelrecipe. Prior
  validatednotseeded/headcountnotcompletionauthority. Constructornoeffects
  onclock/app/clientdispatch. Finalpermissionnotcompletion; actualordinary
  schedule beforefinal68. RepeatedunexpectedDATA can'tearnbodyfacts.
- test_ready.check exactsignature/return/clock/after_case/final semantics,
  usesSAMEcorepeer; duplicatepeer/deadimports removed. frame directreexport
  samefunctionobject/no wrapper/dependencycycle. Preserveeveryoldheader/body/
  hash/count/time/final/large/latecredit/pending/parser/HPACKnegative contract.
- Buffer8201/payload8192/pre-growthguard/cursor/splitrefund/incremental100m
  hash unchanged. No payload/request/read histories; zeroDATAcasecompletion
  cannot weakenupload/ready guards. Peertruthindependentofclientcontext.

Namedrisks: sharedpeer vsold standalone driver contract(lossoldchecks ornew
clock/aftercase/errorbehavior); asyncprimaryrole/path/END andfinalgate; metrics
onpersistentapp/retainedactualoutputbinding; framealias/circularimports; old
ready/large guards retained whileaddingnoDATAcase. Outside-diff onlyonefocused
checkperconcreterisk (canonicalmodel/actualcallers if needed), notbroadcrawl.

Actualguardedpartial normal/O stdout: health->delayed->prematurefinal/status
rejected; heads2/DATA0/END0/recordsunchanged/contextincomplete. Usesactual
startupACK/adapteroperations/encodedstatus send, NOACK/pendingstateprep. Full
healthyasyncsourceacceptance3heads/final68/metrics71. Retainedproducerproof
actualconstructor+adapterdispatch (nofamilycheck/modelseed/extraGET), appheads80,
parsedproduceroutput/Bbindingretainedacrossfreshdelayed andfinal68. Bothproof
sources includedindiff; olddirectstatecontrols remainseparatequalifications.

Historicalgapsremain explicit: missingpre-edit119audit/postfirstGREENsnapshot/
systemPythonSOURCEEDIT/beforeeditcontextnotfullyread. Currentcontextfullyread/
selfreviewlater/currentpinsandfresh14strong. Earlierafterhealth/producerproofs
existedwithinRoot167map; some lateratomicinline/consoleclaimshavenoretainedraw,
notinvented here. Newguardedpartialnormal/O completecapture. Livehelperdepth4
initiallyexcludedas"historical"; Rootcorrectedcurrentunacceptedunit scope,
preservedoriginalSHA66b8c.../refactoredsamepatches tonew7cf855...depth3. Every
oldfailure/audit retained; no weakenedCURRENTgate. Reviewthathelperdelta.

TMPresetacrosscontinuations: Root source-onlytask-5e3b8a-restore-inputs.py
--restore NEWreceipt prefaces EACHdependentcheck SAMEshell. Itbindscommitted
archive240fdc...authority, restoresonlyexactsourcebytes/no binaries/installs/
network, thenverifies119/118/113/42/interpreter. No assumptionTMPpersists.
If a focusedpure sensitivityisneeded, invokeRoothelperfirst IN SAMEshell with
newreceipt under/tmp orRootreview-specificscratch; reviewisotherwiseREADONLY
checkout. Do notrerunpassed14suites. Source-onlyartifactrestoration isRoot
owned; askRootifyourfocusedcheckneedstmpdependencies, caninspectwithouttests.

Apply AGENTS/CODING/.codex/agents/reviewer.toml/code-review-and-quality and
explicitRoot-requestedthermo-nuclearstructurallens/projectoverrides. Diffonce,
testsfirst/context10; changedsource rereadonlyhunkcutoff andsaywhy. No source/
Git/service/ref mutations/agents/externalmodelCLI/native/build/server/socket/
SSLContext/TLSclose/realclock/processownership/oldruntime/network/probes.
Purepinnedcodecs/suppliedfacts only; focusedtestonlyforunanswerednamedrisk.
ExactPython-B-S/PYTHONPATH/graphifyprefix inoriginalbrief, providedpaths located;
graphifybeforeNEWcodebasequestion/search. ReturnFULLSPEC/QUALITY/strengths/
actionable severity/fileline/scenariofindings/cannotverifyboundaries. Root
savesverdict/routesfixes tofinalize_h2_core_async_evidence owner, no codefix.
No coordinator/default/all40/native/adoption/milestone closure claimed.
