# Core async current proof completion before initial review

Root read full report and non-DONE handling. Same soleowner/originalownership;
no independentreview/sourceacceptance yet. Preserve completecandidate source40,
14current receipts/initialREDs/firstGREEN/sourceandreport BEFORE newwork.

Historicalruling: missingpre-edit119identityaudit andpost-firstGREEN snapshot
remainexplicitgaps; do notfabricate orreplaythem asoldcaptures. Currentpinned
authorityaudit establishescurrentinputs. Single systempython SOURCE EDIT is
admitted, nottest/evidenceexecution; do notrerunedit tohideit. ALLnewdirectPython
mustuseexactpinned-B-S/-O. Capturefreshcurrent40map/pinnedidentity nowbefore
newproofs; qualifytimingcorrectly. No needuserapproval forreversible scopedwork.

Close these CURRENT originalbrief requirements:

1. Read the actual required project/role/task/narrow skill text you had only
   concatenated intoa tempcontextfile. Readrelevantfiles completely inbounded
   chunks if needed; identifyexactpreviouslyunreadpaths. Include AGENTS/CODING,
   originaltask/acceptedplan+asyncaddendum, applicableverificationroleproject
   docs/narrow workflows. Do notloadirrelevantZigskills justbecausecatalogued.
   Then self-revieweverytoucheddiffline againstcurrentrules andcorrectanyactual
   issuewithinownership. Readnow isafterinitialedit; reportthishonestly, not
   claimbeforereadingcompliance. GenericmissingDoD alreadyruled, nonewinvention.
2. Add actualserialized premature-final proof: constructfinal=True without
   selectingrecords/clockeffects, deliverstartup/ACK viarealprotocol/adapter,
   processpartialactualhealth/delayed schedule, attemptfinal/statusobservation
   tooearly throughactualsend/parserpath. No directACK/pending statepreparation
   for thisnewproof. Verifyrejection/no unearnedselectedrecords/completion,
   withfullhealthyasync/final control. Existingdirectstatecontrols mayremain
   asqualifiedadditionaloracles; do notmisrepresentwholeparserrollback.
3. Add independentactualnonemptyoutput+binding->delayed proof. Drive reviewed
   producer_reuse.new_peer withactualadapterdispatch (neverfamilycheck), earn
   itsrealappdiagnostic/Bbinding, thennewdelayedpeer usingthatsameapp andactual
   prior. Carrycopiedactualclientparsedobservations intofreshcontext asexisting
   driverdoes; assertunchangedretainedoutput+binding andindependentapptruth after
   actualdelayed+final68, noextraoutputGET/modelseed/defaultrecipe. Useexisting
   unchangedproducerfactory; no newpublicdriverparameter/appshape/sourceownership.
   Preferguarded evidence-onlyproofscript toavoidnewtest_ready<->producer import
   cycle. This isactualstandalonechain, notcoordinatorproof.

Runnewproofsnormal/-O, retainexactcommands/raw/exits andsource40binding BEFORE
andaftereach. Anygenuinebug getsactualRED/frozenaffectedsource BEFOREfix. If
thetwoMODULEsourceschange, rerun14coveringcommands AFTERlastedit withdistinct
names/newsource freeze. Ifonlyevidenceproofs added andmodulesunchanged, verify
current40 byte-equalexistingfinalmap andreuse14existingpassingreceipts; do not
repeatpassedsuites needlessly. Final40 AST/inertimports/currentrecorders/input/
9277history audit+distinctstructure/currentmaps required, preservealloldpaths.
AnyextraAPI/ownershipgap reportbeforeedit. No native/Git/agents/othermodules.

Appendfullcompletion report contextpathsread/corrections/newactualproof/results/
sourcebinding/commands/remaininghistoricalqualifications. Returnconcise status.
Rootaudits thenfreshsource/spec/qualityreview; actualall40/native/adoption/full
milestones remainmandatory. Originalpinnedpaths/graphify/sourceconstraints apply.
