import copy
import hpack
import model
import test_core_peer as peer


def require(value, message):
    if not value:
        raise RuntimeError(message)


def rejects(call, message):
    try:
        call()
    except ValueError:
        return
    raise RuntimeError(message)


def main():
    app = peer.new_app()
    before = copy.deepcopy(app)
    calls = []
    item = peer.new_peer('async_delayed', app=app, prior=(), now=1, clock=lambda: calls.append(1), final=True)
    require(app == before and not calls and set(item) == {'connection', 'state'}, 'constructor effects')
    require(set(item['connection']) == {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'}, 'connection shape')
    bad = peer.new_app()
    bad['heads'] = 1
    rejects(lambda: peer.new_peer('async_delayed', app=bad, prior=(), now=1, clock=lambda: 2), 'invalid prior accepted')
    state = item['state']
    state['pending'].clear()
    state['acks'] = 1
    encoder = hpack.Encoder()
    headers = ((':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', '/status/' + model.BODY_SPECS[0][0]))
    packet = peer.frame(1, 5, 1, encoder.encode(headers))
    rejects(lambda: peer.packet_received(state, app, packet), 'premature final accepted')
    rejects(lambda: peer.packet_received(state, app, peer.frame(0, 1, 1, b'x')), 'unexpected DATA accepted')
    require((state['heads'], state['data'], state['ends'], app['heads']) == (0, 0, 0, 0), 'rejection earned facts')
    require(app['records'] == before['records'], 'rejection selected record')
    print('constructor/prior/premature-final/unexpected-DATA boundaries passed')


if __name__ == '__main__':
    main()
