set -e
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/quality_v1/delivery_inputs.json > /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/quality_v1/delivery_restore.stdout 2> /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/quality_v1/delivery_restore.stderr
printf '0\n' > /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/quality_v1/delivery_restore.exit
/home/codespace/.python/current/bin/python3 -B -S - <<'PY' > /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/quality_v1/delivery.stdout 2> /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/quality_v1/delivery.stderr
from pathlib import Path
import hashlib, json
out=Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/quality_v1')
unit=out.parent
root=unit.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-report.md')
if not report.read_bytes().startswith((out/'before_report.md').read_bytes()):
    raise RuntimeError('report prefix changed')
for name,expected in json.loads((out/'before_unit.json').read_text()).items():
    path=out/'frozen_before/recorder_audit.py' if name=='recorder_audit.py' else unit/name
    if sha(path)!=expected:
        raise RuntimeError('historical bytes changed: '+name)
source={p.name:sha(p) for p in sorted(root.glob('*.py'))}
if source!=json.loads((unit/'final-source.json').read_text()):
    raise RuntimeError('source40 changed')
files={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file()
       and p.name not in ('delivery.stdout','delivery.stderr')}
result=dict(report_bytes=report.stat().st_size,report_sha256=sha(report),evidence=files,
            current_source=source,live_recorder_sha256=sha(unit/'recorder_audit.py'),
            frozen_recorder_sha256=sha(out/'frozen_before/recorder_audit.py'),
            qualification='Manifest excludes itself and in-progress delivery stdout/stderr/exit.')
with (out/'delivery_manifest.json').open('x') as handle:
    handle.write(json.dumps(result,indent=2)+'\n')
print('report prefix23795 preserved; history273 preserved with explicit helper snapshot; source40 unchanged')
print('quality evidence and full appended report bound in delivery_manifest.json')
PY
printf '0\n' > /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/quality_v1/delivery.exit

