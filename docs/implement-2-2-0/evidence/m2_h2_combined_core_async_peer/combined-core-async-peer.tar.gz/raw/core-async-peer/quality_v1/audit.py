"""Strict current-helper, source and historical receipt audit."""
import ast
import builtins
from contextlib import ExitStack
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from unittest import mock


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def load_pinned(root):
    path = root / 'evidence/core-peer/audit.py'
    spec = importlib.util.spec_from_file_location('pinned_core_audit', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_history(unit, mapping, frozen):
    for name, expected in mapping.items():
        path = frozen if name == 'recorder_audit.py' else unit / name
        require(sha(path) == expected, 'history differs: ' + name)


def reject(*_args, **_kwargs):
    raise RuntimeError('helper import effect')


def inert(path, code, argv):
    with ExitStack() as stack:
        stack.enter_context(mock.patch.object(sys, 'argv', argv))
        for target, name in ((builtins, 'open'), (Path, 'open'), (Path, 'read_bytes'),
                             (Path, 'read_text'), (Path, 'write_bytes'), (Path, 'write_text'),
                             (Path, 'mkdir'), (sys.stdout, 'write'), (sys.stderr, 'write')):
            stack.enter_context(mock.patch.object(target, name, reject))
        exec(code, dict(__name__='inert_recorder', __file__=str(path)))


def helpers(unit, output, pinned):
    frozen = {'before-source', 'attempt1-source', 'final-source',
              'frozen_audit_attempt1', 'frozen_before'}
    paths = [path for path in sorted(unit.rglob('*.py'))
             if not frozen.intersection(path.relative_to(unit).parts)]
    depths = {}
    for path in paths:
        tree = ast.parse(path.read_text(), filename=str(path))
        guards = [node for node in tree.body if isinstance(node, ast.If) and
                  "__name__ == '__main__'" in ast.unparse(node.test)]
        require(len(guards) == 1, 'helper guard differs: ' + str(path))
        depth = pinned.nesting(tree)
        require(depth <= 3, 'current helper nesting exceeds3: ' + str(path))
        require(not any(isinstance(node, (ast.ClassDef, ast.Assert, ast.Global)) for node in ast.walk(tree)),
                'helper class/assert/global: ' + str(path))
        code = compile(tree, str(path), 'exec')
        for argv in ([], ['foreign', '--run', 'unexpected']):
            inert(path, code, argv)
        depths[str(path.relative_to(unit))] = depth
    write_json(output / 'helper_depths.json', depths)
    print('ALL current helpers guarded/inert empty+foreign argv; count=%d max_nesting=%d' %
          (len(depths), max(depths.values())))


def check_receipts(output, source):
    receipts = {}
    for mode in ('normal', 'optimized'):
        for name in ('test_ready', 'test_async', 'test_large', 'test_time',
                     'test_final', 'test_shared', 'test_imports'):
            label = mode + '_' + name
            before = json.loads((output / (label + '_before.json')).read_text())
            after = json.loads((output / (label + '_after.json')).read_text())
            require(before == after and before['source'] == source, 'check binding differs: ' + label)
            require((output / (label + '.exit')).read_text() == '0\n' and
                    (output / (label + '.stderr')).read_bytes() == b'', 'check result differs: ' + label)
            receipts[label] = {suffix: sha(output / (label + suffix)) for suffix in
                               ('.sh', '.stdout', '.stderr', '.exit', '_before.json', '_after.json',
                                '_inputs.json', '_restore.stdout', '_restore.stderr', '_restore.exit')}
    write_json(output / 'focused_receipts.json', receipts)
    print('14 fresh focused checks verified: exit0, empty stderr, exact metadata/source before=after')


def main():
    output = Path(__file__).resolve().parent
    unit, root = output.parent, output.parents[2]
    plan = Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan')
    frozen = output / 'frozen_before/recorder_audit.py'
    source = {path.name: sha(path) for path in sorted(root.glob('*.py'))}
    require(len(source) == 40 and source == json.loads((unit / 'final-source.json').read_text()),
            'final source40 differs')
    require(source == {path.name: sha(path) for path in sorted((unit / 'attempt1-source').glob('*.py'))},
            'original tested source differs')
    prior_maps = (json.loads((plan / 'task-5e3b8a-root-resume-audit.json').read_text())['initial_unit_files'],
                  json.loads((unit / 'finalize_v1/before_unit.json').read_text()),
                  json.loads((output / 'before_unit.json').read_text()))
    for mapping in prior_maps:
        verify_history(unit, mapping, frozen)
    history = json.loads((unit / 'prior-evidence-map.json').read_text())
    for name, expected in history.items():
        require(sha(root / name) == expected, 'prior9277 differs: ' + name)
    prefix = (output / 'before_report.md').read_bytes()
    require((plan / 'task-5e3b8a-report.md').read_bytes().startswith(prefix), 'report prefix differs')
    require(hashlib.sha256(prefix[:6586]).hexdigest() ==
            '0950276a9279ccbd0724510ffa0a707e79b2cf98570aa39df24c0151f56b4954',
            'initial report prefix differs')
    pinned = load_pinned(root)
    pinned.immutable(root, output)
    pinned.structure(root, output)
    import test_imports
    test_imports.check()
    helpers(unit, output, pinned)
    check_receipts(output, source)
    old_depth = pinned.nesting(ast.parse(frozen.read_text()))
    new_depth = pinned.nesting(ast.parse((unit / 'recorder_audit.py').read_text()))
    require(old_depth == 4 and new_depth == 3, 'expected helper depth transition differs')
    write_json(output / 'final_bindings.json',
               dict(source=source, prior_history=len(history), preserved_maps=list(map(len, prior_maps)),
                    report_prefix_bytes=len(prefix), report_prefix_sha256=hashlib.sha256(prefix).hexdigest(),
                    live_helper=dict(path=str(unit / 'recorder_audit.py'), sha256=sha(unit / 'recorder_audit.py'), depth=new_depth),
                    frozen_helper=dict(path=str(frozen), sha256=sha(frozen), depth=old_depth)))
    print('source40 unchanged; history9277 and maps167/191/273 preserved with explicit recorder snapshot mapping')
    print('live recorder_audit.py depth4->3; original bytes retained; report prefix=%d bytes' % len(prefix))


if __name__ == '__main__' and sys.argv[1:] == ['--audit']:
    main()

