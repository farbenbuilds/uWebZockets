set -e
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/quality_v1/freeze_inputs.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import hashlib, json
unit=Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer')
out=unit/'quality_v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
history={str(p.relative_to(unit)):sha(p) for p in sorted(unit.rglob('*')) if p.is_file() and out not in p.parents}
(out/'before_unit.json').write_text(json.dumps(history,indent=2)+'\n')
report=Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-report.md').read_bytes()
(out/'before_report.md').write_bytes(report)
frozen=out/'frozen_before'
frozen.mkdir()
(frozen/'recorder_audit.py').write_bytes((unit/'recorder_audit.py').read_bytes())
(frozen/'recorder_audit.py').chmod(0o444)
source={p.name:sha(p) for p in sorted(unit.parents[1].glob('*.py'))}
if source != json.loads((unit/'final-source.json').read_text()):
    raise RuntimeError('source40 differs')
(out/'before_source.json').write_text(json.dumps(source,indent=2)+'\n')
print('frozen prior unit files',len(history),'report bytes',len(report),'source',len(source),'old recorder',sha(frozen/'recorder_audit.py'))
for name in sorted(history):
    if '/' not in name and name not in ('prior-evidence-map.json',):
        print(name)
PY
