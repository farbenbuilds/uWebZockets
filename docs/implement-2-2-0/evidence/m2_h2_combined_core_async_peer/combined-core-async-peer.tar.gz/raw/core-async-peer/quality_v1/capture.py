"""Capture per-check command metadata and exact source identities."""
import hashlib
import json
import os
from pathlib import Path
import sys


def source_map(root):
    return {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(root.glob('*.py'))}


def main():
    stage, mode, name = sys.argv[1:]
    if stage not in ('--before', '--after') or mode not in ('normal', 'optimized'):
        raise ValueError('capture arguments differ')
    if name not in ('test_ready', 'test_async', 'test_large', 'test_time',
                    'test_final', 'test_shared', 'test_imports'):
        raise ValueError('focused module differs')
    output = Path(__file__).resolve().parent
    root = output.parents[2]
    source = source_map(root)
    if source != json.loads((output.parent / 'final-source.json').read_text()):
        raise RuntimeError('source differs from original final40')
    label = mode + '_' + name
    flags = ['-B', '-S'] + (['-O'] if mode == 'optimized' else [])
    record = dict(source=source, argv=['/home/codespace/.python/current/bin/python3'] + flags +
                  [str(root / (name + '.py'))], cwd=os.getcwd(),
                  environment=dict(PYTHONDONTWRITEBYTECODE=os.environ['PYTHONDONTWRITEBYTECODE'],
                                   PYTHONPATH=os.environ['PYTHONPATH']),
                  interpreter_sha256=hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest())
    suffix = 'before' if stage == '--before' else 'after'
    if stage == '--after':
        before = json.loads((output / (label + '_before.json')).read_text())
        if record != before:
            raise RuntimeError('per-check source or execution metadata changed')
    with (output / (label + '_' + suffix + '.json')).open('x') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')


if __name__ == '__main__' and len(sys.argv) == 4:
    main()

