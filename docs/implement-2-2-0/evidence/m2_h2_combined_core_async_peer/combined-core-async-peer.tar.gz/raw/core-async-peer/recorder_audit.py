import ast
import builtins
from pathlib import Path
import sys
from unittest import mock


def reject(*_args, **_kwargs):
    raise RuntimeError('recorder import effect')


def main():
    evidence = Path(__file__).resolve().parent
    paths = sorted(evidence.glob('*.py'))
    for path in paths:
        tree = ast.parse(path.read_text())
        guards = [node for node in tree.body if isinstance(node, ast.If) and ast.unparse(node.test) == "__name__ == '__main__'"]
        if len(guards) != 1:
            raise RuntimeError('guard count differs: ' + path.name)
        code = compile(tree, str(path), 'exec')
        for argv in ([], ['foreign', '--run', 'unexpected']):
            out, err = mock.Mock(), mock.Mock()
            out.write.side_effect = reject
            err.write.side_effect = reject
            with (mock.patch.object(sys, 'argv', argv), mock.patch.object(sys, 'stdout', out),
                  mock.patch.object(sys, 'stderr', err), mock.patch.object(builtins, 'open', reject),
                  mock.patch.object(Path, 'read_bytes', reject), mock.patch.object(Path, 'write_text', reject)):
                exec(code, {'__name__': 'inert_recorder', '__file__': str(path)})
    print('current recorders guarded/inert under empty and foreign argv: %d' % len(paths))


if __name__ == '__main__':
    main()
