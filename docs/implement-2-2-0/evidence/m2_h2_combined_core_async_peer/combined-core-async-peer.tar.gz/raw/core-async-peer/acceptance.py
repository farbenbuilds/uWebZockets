import adapter
import model
import test_core_peer
import test_ready


def require(value, message):
    if not value:
        raise RuntimeError(message)


def main():
    require(test_ready.frame is test_core_peer.frame, 'frame alias differs')
    app = test_core_peer.new_app()
    peer = test_core_peer.new_peer('async_delayed', app=app, prior=(), now=1, clock=lambda: 2, final=True)
    require(app['heads'] == 0 and app['records'] == model.records((), 'before'), 'constructor changed app')
    connection, state = peer['connection'], peer['state']
    context = adapter.open_case('async_delayed', connection['protocol'], connection['send'], 1, 30001, 900001, clock=lambda: 2)
    adapter.observe(context, *connection['receive']())
    adapter.run_case(context, connection['receive'])
    require((state['heads'], state['data'], state['ends']) == (3, 0, 0), 'delayed actions differ')
    require(app['records'] == model.records((), 'before'), 'delayed selected a body record')
    adapter.final_collection(context, connection['receive'])
    require((state['heads'], state['data'], state['ends'], app['heads']) == (71, 0, 0, 71), 'final actions differ')
    require(context['final_observations']['metrics']['buffered_middleware'] == 71, 'final metric differs')
    print('delayed heads=3 DATA=0 END=0 final=68 buffered_middleware=71')


if __name__ == '__main__':
    main()
