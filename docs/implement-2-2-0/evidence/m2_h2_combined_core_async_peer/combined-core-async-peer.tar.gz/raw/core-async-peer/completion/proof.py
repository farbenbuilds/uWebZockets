import copy
import adapter
import model
import test_core_peer
import test_producer_pressure


def require(value, message):
    if not value:
        raise RuntimeError(message)


def open_peer(case, app, prior=(), final=False):
    now = [1]
    def clock():
        now[0] += 1
        return now[0]
    factory = test_producer_pressure.new_peer if case == 'producer_reuse' else test_core_peer.new_peer
    peer = factory(case, app=app, prior=prior, now=1, clock=clock, final=final)
    connection = peer['connection']
    context = adapter.open_case(case, connection['protocol'], connection['send'], 1, 30001, 900001,
                                selected_before=prior, clock=clock)
    adapter.observe(context, *connection['receive']())
    return peer, context


def partial():
    app = test_core_peer.new_app()
    before = copy.deepcopy(app)
    def forbidden():
        raise RuntimeError('constructor called clock')
    peer = test_core_peer.new_peer('async_delayed', app=app, prior=(), now=1, clock=forbidden, final=True)
    require(app == before and peer['state']['heads'] == 0, 'constructor effects')
    peer, context = open_peer('async_delayed', app, final=True)
    connection, state = peer['connection'], peer['state']
    adapter.health(context, connection['receive'])
    require((state['acks'], state['heads'], app['heads']) == (1, 1, 1), 'health not earned')
    try:
        adapter.final_collection(context, connection['receive'])
    except ValueError as exc:
        require(str(exc) == 'case not complete', 'wrong premature final failure')
    else:
        raise RuntimeError('premature final collection accepted')
    protocol = connection['protocol']
    protocol.send_headers(3, [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'),
                              (':path', '/status/' + model.BODY_SPECS[0][0])], end_stream=True)
    try:
        connection['send'](protocol.data_to_send())
    except ValueError as exc:
        require(str(exc) == 'request contract differs', 'wrong serialized rejection')
    else:
        raise RuntimeError('premature status accepted')
    require((state['heads'], state['data'], state['ends'], app['heads']) == (1, 0, 0, 1), 'premature request earned facts')
    require(app['records'] == before['records'] and not context['completed'], 'premature completion or selection')
    print('serialized partial health -> premature final and status rejected; heads=1 data=0 ends=0')


def chain():
    app = test_core_peer.new_app()
    producer, context = open_peer('producer_reuse', app)
    adapter.run_case(context, producer['connection']['receive'])
    require(context['completed'] and producer['state']['heads'] == 9 and producer['state']['output_ended'], 'producer incomplete')
    observed = copy.deepcopy(context['output_observations'])
    binding = copy.deepcopy(context['output_binding'])
    require(observed['producer_reuse'] == app['outputs']['producer_reuse'] and binding == app['binding'], 'producer observations differ')
    require(observed['producer_reuse'] is not app['outputs']['producer_reuse'] and binding is not app['binding'], 'observations alias app')
    app_before = copy.deepcopy(app)
    delayed, context = open_peer('async_delayed', app, prior=('producer_reuse',), final=True)
    context['output_observations'] = copy.deepcopy(observed)
    context['output_binding'] = copy.deepcopy(binding)
    adapter.run_case(context, delayed['connection']['receive'])
    require((delayed['state']['heads'], delayed['state']['data'], delayed['state']['ends']) == (3, 0, 0), 'delayed sequence differs')
    adapter.final_collection(context, delayed['connection']['receive'])
    require(delayed['state']['heads'] == 71 and context['stage']['final_registered'] == 68, 'final collection differs')
    require(context['output_observations'] == observed and context['output_binding'] == binding, 'client observations changed')
    require(app['outputs'] == app_before['outputs'] and app['binding'] == app_before['binding'], 'peer facts changed')
    require(app['records'] == app_before['records'] and app['heads'] == 80, 'app record or head count differs')
    require(context['final_observations']['records'] == app['records'], 'parsed records differ from app facts')
    print('actual producer -> delayed -> final68: producer heads=9 delayed heads=3 output and binding retained app heads=80')


def main():
    partial()
    chain()


if __name__ == '__main__':
    main()
