import hashlib
import importlib.util
import json
from pathlib import Path
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    evidence = Path(__file__).resolve().parent
    parent = evidence.parent
    root = parent.parents[1]
    source = {path.name: digest(path) for path in sorted(root.glob('*.py'))}
    if source != json.loads((parent / 'final-source.json').read_text()):
        raise RuntimeError('current source differs from original final map')
    (evidence / (sys.argv[1] + '-source.json')).write_text(json.dumps(source, indent=2) + '\n')
    spec = importlib.util.spec_from_file_location('pinned_audit', root / 'evidence/core-peer/audit.py')
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    audit.immutable(root, evidence)
    history = json.loads((parent / 'prior-evidence-map.json').read_text())
    for name, expected in history.items():
        if digest(root / name) != expected:
            raise RuntimeError('history changed: ' + name)
    print('source=40 matches original final map; prior evidence=%d preserved' % len(history))
    if sys.argv[1] == 'final':
        audit.structure(root, evidence)


if __name__ == '__main__':
    main()
