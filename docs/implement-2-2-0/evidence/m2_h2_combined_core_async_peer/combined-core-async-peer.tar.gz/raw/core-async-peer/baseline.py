import hashlib
import json
from pathlib import Path
import shutil


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    evidence = Path(__file__).resolve().parent
    root = evidence.parents[1]
    manifest = Path('docs/implement-2-2-0/evidence/m2_h2_combined_coordinator_shutdown/manifest.json')
    accepted = json.loads(manifest.read_text())['current_source_files']
    paths = sorted(root.glob('*.py'))
    current = {path.name: sha(path) for path in paths}
    if len(current) != 40 or current != accepted:
        raise RuntimeError('accepted 40 source mismatch')
    target = evidence / 'before-source'
    target.mkdir()
    for path in paths:
        shutil.copyfile(path, target / path.name)
    (evidence / 'before-source.json').write_text(json.dumps(current, indent=2) + '\n')
    history = {str(path.relative_to(root)): sha(path) for path in sorted((root / 'evidence').rglob('*'))
               if path.is_file() and evidence not in path.parents}
    (evidence / 'prior-evidence-map.json').write_text(json.dumps(history, indent=2) + '\n')
    print('accepted source=%d prior evidence files=%d' % (len(current), len(history)))


if __name__ == '__main__':
    main()
