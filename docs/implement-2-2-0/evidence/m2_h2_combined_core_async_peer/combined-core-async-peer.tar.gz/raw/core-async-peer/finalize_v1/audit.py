"""Current source, identity, import and append-only evidence verification."""
import ast
import builtins
from contextlib import ExitStack
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from unittest import mock


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def source_map(root):
    return {path.name: sha(path) for path in sorted(root.glob('*.py'))}


def snapshot(label):
    output = Path(__file__).resolve().parent
    unit, root = output.parent, output.parents[2]
    current = source_map(root)
    require(len(current) == 40 and current == json.loads((unit / 'final-source.json').read_text()),
            'current source differs from tested40')
    scripts = {path.name: sha(path) for path in sorted(output.glob('*.py'))}
    write_json(output / (label + '_source.json'), dict(source=current, scripts=scripts))
    print(label + ': source40 equals original final map; evidence scripts bound')


def verify_map(root, mapping):
    for name, expected in mapping.items():
        require(sha(root / name) == expected, 'historical bytes differ: ' + name)


def load_audit(root):
    path = root / 'evidence/core-peer/audit.py'
    spec = importlib.util.spec_from_file_location('pinned_core_audit', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def reject(*_args, **_kwargs):
    raise RuntimeError('current recorder import effect')


def inert_import(path, code, argv, main=False):
    namespace = dict(__name__='__main__' if main else 'inert_recorder', __file__=str(path))
    with ExitStack() as stack:
        stack.enter_context(mock.patch.object(sys, 'argv', argv))
        for target, name in ((builtins, 'open'), (Path, 'open'), (Path, 'read_bytes'),
                             (Path, 'read_text'), (Path, 'write_bytes'), (Path, 'write_text'),
                             (Path, 'mkdir'), (sys.stdout, 'write'), (sys.stderr, 'write')):
            stack.enter_context(mock.patch.object(target, name, reject))
        exec(code, namespace)


def recorder_checks(unit, output, audit):
    frozen = {'before-source', 'attempt1-source', 'final-source'}
    paths = [path for path in sorted(unit.rglob('*.py'))
             if not frozen.intersection(path.relative_to(unit).parts)]
    names = []
    for path in paths:
        tree = ast.parse(path.read_text(), filename=str(path))
        guards = [node for node in tree.body if isinstance(node, ast.If) and
                  "__name__ == '__main__'" in ast.unparse(node.test)]
        require(len(guards) == 1, 'recorder guard differs: ' + str(path))
        require(audit.nesting(tree) <= 3, 'recorder nesting differs: ' + str(path))
        require(not any(isinstance(node, (ast.ClassDef, ast.Assert, ast.Global)) for node in ast.walk(tree)),
                'recorder class/assert/global: ' + str(path))
        code = compile(tree, str(path), 'exec')
        for argv in ([], ['foreign', '--run', 'unexpected']):
            inert_import(path, code, argv)
            if path.parent == output:
                inert_import(path, code, argv, main=True)
        names.append(str(path.relative_to(unit)))
    write_json(output / 'recorders.json', names)
    print('current recorders guarded/inert under empty and foreign argv:', len(names))


def final_audit():
    output = Path(__file__).resolve().parent
    unit, root = output.parent, output.parents[2]
    plan = Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan')
    current = source_map(root)
    require(current == json.loads((unit / 'final-source.json').read_text()), 'final source differs')
    require(current == source_map(unit / 'attempt1-source'), '14-check snapshot differs')
    before = json.loads((unit / 'before-source.json').read_text())
    require(len(current) == 40 and {name for name in before if before[name] != current[name]} ==
            {'test_core_peer.py', 'test_ready.py'}, 'source ownership differs')
    pinned = json.loads((plan / 'task-5e3b8a-root-resume-audit.json').read_text())
    verify_map(unit, pinned['initial_unit_files'])
    initial_report = (output / 'before_report.md').read_bytes()
    require(hashlib.sha256(initial_report[:6586]).hexdigest() ==
            '0950276a9279ccbd0724510ffa0a707e79b2cf98570aa39df24c0151f56b4954',
            'initial report prefix differs')
    require((plan / 'task-5e3b8a-report.md').read_bytes().startswith(initial_report),
            'later report prefix differs')
    existing = json.loads((output / 'before_unit.json').read_text())
    verify_map(unit, existing)
    history = json.loads((unit / 'prior-evidence-map.json').read_text())
    verify_map(root, history)
    audit = load_audit(root)
    audit.immutable(root, output)
    audit.structure(root, output)
    import test_imports
    test_imports.check()
    recorder_checks(unit, output, audit)
    import test_core_peer
    import test_ready
    require(test_ready.frame is test_core_peer.frame, 'frame alias differs')
    tree = ast.parse((root / 'test_core_peer.py').read_text())
    imports = [node.names[0].name for node in tree.body if isinstance(node, ast.Import)]
    require(set(imports) == {'hashlib', 'json', 'catalogue', 'h2_client', 'hpack', 'model'} and
            not any(isinstance(node, ast.ImportFrom) for node in tree.body), 'core import direction differs')
    raws = {path.name: sha(path) for path in sorted(unit.glob('attempt1-*-test_*.raw'))}
    require(len(raws) == 14, 'focused raw inventory differs')
    write_json(output / 'final_bindings.json',
               dict(source=current, focused_raws=raws, original_unit_files=len(pinned['initial_unit_files']),
                    preserved_resume_files=len(existing), prior_history=len(history),
                    report_prefix_bytes=len(initial_report), report_prefix_sha256=hashlib.sha256(initial_report).hexdigest(),
                    producer_normal_raw=sha(unit / 'completion/proof-attempt1.raw'),
                    producer_optimized_raw=sha(unit / 'completion/proof-optimized.raw')))
    print('source=40 changed=2 unchanged=38; original unit=167 resumed unit=%d history=9277 preserved' % len(existing))
    print('14 historical focused raws and actual producer normal/optimized raws bound; frame alias and one-way imports passed')


if __name__ == '__main__' and len(sys.argv) == 3 and sys.argv[1] == '--snapshot':
    snapshot(sys.argv[2])
elif __name__ == '__main__' and sys.argv[1:] == ['--audit']:
    final_audit()

