set -e
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1/freeze_inputs.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import hashlib, json, difflib
root = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
unit = root / 'evidence/core-async-peer'
out = unit / 'finalize_v1'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = {p.name: sha(p) for p in sorted(root.glob('*.py'))}
if source != json.loads((unit / 'final-source.json').read_text()):
    raise RuntimeError('source differs')
history = {str(p.relative_to(unit)): sha(p) for p in sorted(unit.rglob('*')) if p.is_file() and out not in p.parents}
(out / 'before_unit.json').write_text(json.dumps(history, indent=2) + '\n')
(out / 'before_source.json').write_text(json.dumps(source, indent=2) + '\n')
report = Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-report.md').read_bytes()
(out / 'before_report.md').write_bytes(report)
for name in ('test_core_peer.py', 'test_ready.py'):
    delta = ''.join(difflib.unified_diff((unit/'before-source'/name).read_text().splitlines(True), (root/name).read_text().splitlines(True), fromfile='before/'+name, tofile='current/'+name))
    (out / (name + '.diff')).write_text(delta)
print('frozen source', len(source), 'prior unit files', len(history), 'report bytes', len(report), 'report SHA', hashlib.sha256(report).hexdigest())
print('root audit keys', list(json.loads(Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-root-resume-audit.json').read_text())))
print('proof raws', [(str(p.relative_to(unit)), p.read_text()[:600]) for p in sorted((unit/'completion').glob('*.raw'))])
PY
