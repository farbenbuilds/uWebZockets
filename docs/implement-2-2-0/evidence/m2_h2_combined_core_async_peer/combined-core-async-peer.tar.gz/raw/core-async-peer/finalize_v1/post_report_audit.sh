set -e
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1/post_report_inputs.json > /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1/post_report_restore.stdout 2> /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1/post_report_restore.stderr
printf '0\n' > /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1/post_report_restore.exit
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1/audit.py --snapshot post_report > /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1/post_report_snapshot.stdout 2> /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1/post_report_snapshot.stderr
/home/codespace/.python/current/bin/python3 -B -S - <<'PY' > /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1/post_report.stdout 2> /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1/post_report.stderr
from pathlib import Path
import hashlib, json
out = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1')
report = Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-report.md')
sha = lambda data: hashlib.sha256(data).hexdigest()
if not report.read_bytes().startswith((out/'before_report.md').read_bytes()):
    raise RuntimeError('report history changed')
for name, expected in json.loads((out/'before_unit.json').read_text()).items():
    if sha((out.parent/name).read_bytes()) != expected:
        raise RuntimeError('prior unit changed: ' + name)
for mode in ('partial_normal', 'partial_optimized'):
    before = json.loads((out/(mode+'_before_source.json')).read_text())
    after = json.loads((out/(mode+'_after_source.json')).read_text())
    if before != after or before['scripts']['partial_proof.py'] != sha((out/'partial_proof.py').read_bytes()):
        raise RuntimeError('proof source binding differs')
    if (out/(mode+'.exit')).read_text() != '0\n' or (out/(mode+'.stderr')).read_bytes():
        raise RuntimeError('proof result differs')
artifacts = {str(p.relative_to(out)): sha(p.read_bytes()) for p in sorted(out.rglob('*'))
             if p.is_file() and p.name not in ('post_report.stdout', 'post_report.stderr')}
result = dict(report_sha256=sha(report.read_bytes()), report_bytes=report.stat().st_size,
              preserved_report_prefix_bytes=(out/'before_report.md').stat().st_size,
              evidence_files=artifacts, qualification='Manifest excludes itself and in-progress post_report stdout/stderr/exit.')
with (out/'delivery_manifest.json').open('x') as handle:
    handle.write(json.dumps(result, indent=2)+'\n')
print('post-report source40/prefix9284/unit191/proof source bindings verified; delivery manifest retained')
PY
printf '0\n' > /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/core-async-peer/finalize_v1/post_report.exit

