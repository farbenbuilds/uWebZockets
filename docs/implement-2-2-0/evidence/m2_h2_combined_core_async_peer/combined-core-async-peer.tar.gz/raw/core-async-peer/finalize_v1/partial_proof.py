"""Reject final permission after delayed response but before final health."""
import copy
import sys
import adapter
import model
import test_core_peer


def require(value, message):
    if not value:
        raise RuntimeError(message)


def main():
    app = test_core_peer.new_app()
    records = copy.deepcopy(app['records'])
    peer = test_core_peer.new_peer('async_delayed', app=app, prior=(), now=1,
                                   clock=lambda: 2, final=True)
    connection, state = peer['connection'], peer['state']
    context = adapter.open_case('async_delayed', connection['protocol'], connection['send'],
                                1, 30001, 900001, clock=lambda: 2)
    adapter.observe(context, *connection['receive']())
    adapter.health(context, connection['receive'])
    result = adapter.get(context, '/delayed', connection['receive'], primary=True,
                         limit=10, middleware='optional')
    model.validate_core_response('async_delayed', result)
    require(result['bytes'] == 10 and result['ended'], 'delayed response incomplete')
    require((state['acks'], state['heads'], state['data'], state['ends'], app['heads']) ==
            (1, 2, 0, 0, 2), 'partial schedule facts differ')
    try:
        adapter.final_collection(context, connection['receive'])
    except ValueError as exc:
        require(str(exc) == 'case not complete', 'wrong premature final failure')
    else:
        raise RuntimeError('premature final collection accepted')
    protocol = connection['protocol']
    protocol.send_headers(5, [(':method', 'GET'), (':scheme', 'https'),
                             (':authority', 'localhost'),
                             (':path', '/status/' + model.BODY_SPECS[0][0])], end_stream=True)
    try:
        connection['send'](protocol.data_to_send())
    except ValueError as exc:
        require(str(exc) == 'request contract differs', 'wrong serialized rejection')
    else:
        raise RuntimeError('premature status accepted')
    require((state['heads'], state['cursor'], state['data'], state['ends'], app['heads']) ==
            (2, 2, 0, 0, 2), 'premature request earned facts')
    require(app['records'] == records and 'async_delayed' not in app['records'],
            'premature record selection')
    require(not context['completed'] and context['stage']['final_registered'] == 0 and
            'final_observations' not in context, 'premature completion or final observation')
    print('serialized health -> delayed -> premature final/status rejected; heads=2 DATA=0 END=0 records unchanged context incomplete')


if __name__ == '__main__' and sys.argv[1:] == ['--prove']:
    main()

