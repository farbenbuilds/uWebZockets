import hashlib
import importlib.util
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    evidence = Path(__file__).resolve().parent
    root = evidence.parents[1]
    spec = importlib.util.spec_from_file_location('pinned_audit', root / 'evidence/core-peer/audit.py')
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    audit.immutable(root, evidence)
    audit.structure(root, evidence)
    audit.inert_helpers(evidence)
    history = json.loads((evidence / 'prior-evidence-map.json').read_text())
    for name, digest in history.items():
        if sha(root / name) != digest:
            raise RuntimeError('history changed: ' + name)
    before = json.loads((evidence / 'before-source.json').read_text())
    current = audit.snapshot(root, evidence, 'final-source')
    changed = {name for name in before if current.get(name) != before[name]}
    if len(current) != 40 or changed != {'test_core_peer.py', 'test_ready.py'}:
        raise RuntimeError('source scope differs')
    print('source=40 changed=2 unchanged=38 history=%d' % len(history))


if __name__ == '__main__':
    main()
