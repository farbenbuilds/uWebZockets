**P1: ADDRESSED. Spec: Compliant. Quality: Approved for this scoped fix.**

No actionable findings in the fix diff.

[validate_close](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native/native_transport.py:289) now accepts the original case/whole deadline for intermediate connections. The additional 15-second cap applies only to the final selected case. A shorter supplied deadline remains unchanged throughout closure and post-operation checks.

The new regression exercises the real coordinator’s intermediate-close hook. Saved RED evidence fails there with `close_deadline`; saved normal and optimized GREEN runs pass all 15 groups, verify TLS-handle closure and canonical close facts, and reach the exact expected second-connect sentinel. This proves the repaired transition, not completion of both cases or native execution.

Package, current-source, and preserved pre-fix hashes match the supplied identities. Saved inert and preservation checks report status `0`. Passing suites were not rerun, and no files were edited.

Remaining qualifications are unchanged: C6b/C6c, active-receive/provider cleanup, native acceptance, publication provenance, collector snapshot ordering, and project gates remain open. Root’s separate AST update was not evaluated in this scoped pass.
