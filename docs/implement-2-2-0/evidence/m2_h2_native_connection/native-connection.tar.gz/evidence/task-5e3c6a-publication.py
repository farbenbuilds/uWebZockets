"""Publish the connection delta; retain large AST-tool snapshots as hash references."""
import hashlib
import json
import runpy
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def parent(plan):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_native_post/native-post.tar.gz')
    if sha(archive.read_bytes()) != 'd19281da19d04c3afbc3bb97ef614b21efa3746f0dc405dfb982d7cc959fbe92':
        raise ValueError('Published parent differs')
    path = plan / 'task-5e3c5-publication.py'
    with tarfile.open(archive, 'r:gz') as stream:
        if stream.extractfile('evidence/' + path.name).read() != path.read_bytes():
            raise ValueError('Published metadata helper differs')
    return archive, runpy.run_path(str(path))['prior'](plan)


def fixed_sources(source, plan):
    old = json.loads(Path('docs/implement-2-2-0/evidence/m2_h2_native_post/manifest.json').read_text())['current_native_sources']
    changed = json.loads((plan / 'task-5e3c6a-root-fix1-audit.json').read_text())['sources']
    old.update(changed)
    wanted = {name: dict(size=row['size'], sha256=row['sha256']) for name, row in old.items()}
    actual = {path.name: dict(size=path.stat().st_size, sha256=sha(path.read_bytes())) for path in source.glob('*.py')}
    if len(actual) != 7 or actual != wanted:
        raise ValueError('Reviewed native source differs')
    return actual


def add_parent(members, archive):
    with tarfile.open(archive, 'r:gz') as stream:
        for member in stream:
            if member.isfile() and member.name.startswith('reference/'):
                members[member.name] = stream.extractfile(member).read()
            if member.isfile() and member.name.startswith('native/') and member.name.count('/') == 1 and member.name.endswith('.py'):
                members['baseline/' + member.name.removeprefix('native/')] = stream.extractfile(member).read()


def tool_reference(path, raw, cache):
    relative = path.relative_to(raw)
    parts = relative.parts
    index = parts.index('graphify-tool')
    if index < 2 or parts[index - 1] != 'source':
        raise ValueError('Unexpected tool snapshot boundary')
    receipt = raw.joinpath(*parts[:index - 1]) / 'source.sha256'
    if receipt not in cache:
        cache[receipt] = dict((line.split(maxsplit=1)[1], line.split(maxsplit=1)[0]) for line in receipt.read_text().splitlines())
    data = path.read_bytes()
    digest = sha(data)
    if cache[receipt].get(str(path.resolve())) != digest:
        raise ValueError('Recorded tool snapshot hash differs')
    return dict(size=len(data), sha256=digest, local_snapshot=str(path),
                recorded_manifest='raw/native-transport/' + receipt.relative_to(raw).as_posix())


def collect(source, plan, archive):
    members, references, cache = {}, {}, {}
    add_parent(members, archive)
    for path in sorted(source.glob('*.py')):
        members['source/current/' + path.name] = path.read_bytes()
    raw = source / 'evidence/native-transport'
    for path in sorted(raw.rglob('*')):
        if path.is_symlink():
            raise ValueError('New evidence symlink')
        if not path.is_file():
            continue
        name = 'raw/native-transport/' + path.relative_to(raw).as_posix()
        if 'graphify-tool' in path.relative_to(raw).parts:
            references[name] = tool_reference(path, raw, cache)
            continue
        members[name] = path.read_bytes()
    names = ('task-5e3c6-report.md', 'task-5e3c6a-brief.md', 'task-5e3c6a-report.md',
             'task-5e3c6-plan-report.md', 'task-5e3c6-plan-addendum.md',
             'task-5e3c6a-review-report.md', 'task-5e3c6a-fix1-review-report.md',
             'task-5e3c6a-review-package.diff', 'task-5e3c6a-fix1-review-package.diff',
             'task-5e3c6a-review-inputs.json', 'task-5e3c6a-root-audit.py',
             'task-5e3c6a-root-audit-initial.py', 'task-5e3c6a-prepare-review.py',
             'task-5e3c6a-root-before-fix1-audit.json', 'task-5e3c6a-root-before-fix1-audit.stdout',
             'task-5e3c6a-root-before-fix1-audit.stderr', 'task-5e3c6a-root-before-fix1-audit.exit',
             'task-5e3c6a-root-fix1-audit.json', 'task-5e3c6a-root-fix1-audit.stdout',
             'task-5e3c6a-root-fix1-audit.stderr', 'task-5e3c6a-root-fix1-audit.exit',
             'task-5e3c6a-root-final-inputs.json', 'task-5e3c6a-root-fix1-inputs.json',
             'task-5e3c6a-root-graph.stdout', 'task-5e3c6a-root-graph.stderr', 'task-5e3c6a-root-graph.exit',
             'task-5e3c6a-root-graph-inputs.json', 'task-5e3c6a-publication.py', 'task-5e3b8a-restore-inputs.py')
    for name in names:
        members['evidence/' + name] = (plan / name).read_bytes()
    disclosure = dict(scope='AST maintenance tooling only; not native/runtime authority',
                      snapshots_retained_locally=True, portable_reconstruction_claimed=False,
                      omitted_members=references)
    members['TOOL_SNAPSHOT_REFERENCES.json'] = (json.dumps(disclosure, indent=2) + '\n').encode()
    return members, references


def build(plan, source, folder):
    current = fixed_sources(source, plan)
    archive, bridge = parent(plan)
    members, references = collect(source, plan, archive)
    api = bridge['published_api'](plan, 'task-5e3c1-build-publication.py')
    safe = {}
    for name, data in members.items():
        api['add'](safe, name, data, {})
    folder.mkdir(parents=True, exist_ok=True)
    output = folder / 'native-connection.tar.gz'
    inventory = api['write_archive'](output, safe)
    manifest = dict(scope='C6a connection construction, ordinary I/O and ordinary close; source-only delta',
                    base_commit='ad43ddba05de35705c11384e6af858082a744550',
                    archive=output.name, archive_bytes=output.stat().st_size, archive_sha256=sha(output.read_bytes()),
                    safe_regular_utf8_members=len(safe) + 1, inventory_entries=len(inventory),
                    current_native_sources=current, parent_public_native_paths=6482,
                    parent_archive_sha256='d19281da19d04c3afbc3bb97ef614b21efa3746f0dc405dfb982d7cc959fbe92',
                    raw_files_embedded=sum(name.startswith('raw/') for name in safe),
                    tool_snapshot_files_referenced=len(references),
                    tool_snapshot_bytes_referenced=sum(row['size'] for row in references.values()),
                    focused_groups=15, canonical_transition_proven='Intermediate close succeeds and reaches expected second-connect sentinel',
                    whole_two_case_run_completed=False, private_original_environments_included=False,
                    deferred_collector_issue='Snapshot dependencies after restoration before future runs that change restored bytes',
                    active_receive_cleanup_owner='Required downstream C6c/provider work; C4 does not own socket closure',
                    native_compiled=False, native_executed=False, complete_transport=False, milestone_complete=False)
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({key: manifest[key] for key in ('archive_sha256', 'archive_bytes', 'safe_regular_utf8_members',
                     'raw_files_embedded', 'tool_snapshot_files_referenced', 'tool_snapshot_bytes_referenced')}))


def audit(plan, source, folder):
    archive, bridge = parent(plan)
    expected, references = collect(source, plan, archive)
    api = bridge['published_api'](plan, 'task-5e3c1-publication-audit.py')
    manifest = json.loads((folder / 'manifest.json').read_text())
    output = folder / manifest['archive']
    if output.stat().st_size != manifest['archive_bytes'] or sha(output.read_bytes()) != manifest['archive_sha256']:
        raise ValueError('Public archive identity differs')
    contents = api['read_archive'](output)
    if contents != expected or len(contents) != manifest['inventory_entries']:
        raise ValueError('Complete connection delta differs')
    for data in contents.values():
        data.decode('utf-8')
    if fixed_sources(source, plan) != manifest['current_native_sources'] or len(references) != manifest['tool_snapshot_files_referenced']:
        raise ValueError('Reviewed sources or local tool references differ')
    if len(contents) + 1 != manifest['safe_regular_utf8_members']:
        raise ValueError('Public inventory count differs')
    check = runpy.run_path(str(plan / 'task-5e3c1-prepare-review.py'))['root_check']
    helpers = {name: check((plan / name).resolve()) for name in (
        'task-5e3c6a-root-audit.py', 'task-5e3c6a-prepare-review.py', 'task-5e3c6a-publication.py')}
    docs = Path('docs/implement-2-2-0')
    files = [docs / 'README.md', docs / 'm2_request_streaming.md', docs / 'm2_h2_native_connection.md',
             folder / 'README.md', folder / 'manifest.json', output]
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=output.stat().st_size,
                  safe_regular_utf8_members=len(contents) + 1, inventory_entries=len(contents),
                  tool_snapshot_files_referenced=len(references),
                  helpers=helpers, local_links_checked=api['verify_links'](files),
                  delivery_files={str(path): dict(size=path.stat().st_size, sha256=sha(path.read_bytes())) for path in files},
                  native_executed=False, complete_transport=False, milestone_complete=False)
    (plan / 'task-5e3c6a-root-publication-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('helpers', 'delivery_files')}))


def main(arguments):
    if arguments not in (['--build'], ['--audit']):
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/combined-native')
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_native_connection')
    if arguments == ['--build']:
        build(plan, source, folder)
        return
    audit(plan, source, folder)


if __name__ == '__main__':
    main(sys.argv[1:])
