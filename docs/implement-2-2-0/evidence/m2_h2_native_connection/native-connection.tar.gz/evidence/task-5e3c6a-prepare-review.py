import difflib
import hashlib
import json
import sys
import tarfile
from pathlib import Path


def main(arguments):
    if arguments != ['--prepare']:
        return
    plan = Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan')
    source = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native')
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_native_post/native-post.tar.gz')
    if hashlib.sha256(archive.read_bytes()).hexdigest() != 'd19281da19d04c3afbc3bb97ef614b21efa3746f0dc405dfb982d7cc959fbe92':
        raise ValueError('Published review baseline differs')
    with tarfile.open(archive, 'r:gz') as stream:
        baseline = stream.extractfile('native/test_native_imports.py').read()
    paths = [source / name for name in ('test_native_transport.py', 'test_native_imports.py', 'native_transport.py')]
    control = source / 'evidence/native-transport/control'
    paths.extend(sorted(control.glob('*.py')))
    paths.extend(sorted(control.glob('*.sh')))
    paths.extend((plan / 'task-5e3c6a-root-audit.py', Path(__file__)))
    parts = ['# C6a source-only connection setup/ordinary I/O/close review\n',
             'BASE/current HEAD ad43ddba05de35705c11384e6af858082a744550.\n',
             'Strict disconnect C6b and active hooks C6c remain required, outside this slice.\n']
    rows = []
    for path in paths:
        data = path.read_bytes()
        old = baseline if path == source / 'test_native_imports.py' else b''
        rows.append(dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest()))
        parts.extend(difflib.unified_diff(old.decode().splitlines(True), data.decode().splitlines(True),
                     fromfile='C5/test_native_imports.py' if old else '/dev/null', tofile=str(path), n=10))
    parts.extend(['\n# Root independent public-view preservation/structure\n',
                  (plan / 'task-5e3c6a-root-final-audit.json').read_text()])
    package = plan / 'task-5e3c6a-review-package.diff'
    package.write_text(''.join(parts))
    (plan / 'task-5e3c6a-review-inputs.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps(dict(path=str(package), bytes=package.stat().st_size,
                         sha256=hashlib.sha256(package.read_bytes()).hexdigest(), files=len(rows))))


if __name__ == '__main__':
    main(sys.argv[1:])
