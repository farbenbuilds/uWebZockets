Recommend one bounded `native_transport.py` module behind the existing coordinator hooks. It should own connection I/O, socket lifetime and transport receipts, while consuming accepted C4 unchanged. Provider reconstruction and native execution remain separate releases.

**Assumptions, scope and conflicts.** C4 at `ed1647336f8136630a910cf0ef4baf98d7a1b6de` is accepted authority. C5 remains the sole owner of `native_post.py`; this plan uses only its supplied contract. Preserve canonical S46, codecs, fixture, candidate, dependencies and archives.

No unresolved contract conflict was found. The brief’s read-only, no-interview instructions govern over generic skill instructions to save plans or conduct an interview. I applied codebase-design, API/interface-design and planning guidance, and used grill-me/grilling to stress-test the settled decision tree. This is neither a deepening scan nor a vocabulary/ADR change.

The implementation scope is:

- `.uwz-work/evidence/h2-streaming/combined-native/native_transport.py`
- Sibling `test_native_transport.py`
- A later, serialized additive import-inventory update, after C5 releases its ownership of `test_native_imports.py`

No product/build change is justified. Preserve Zig 0.16.0, bounded storage and zero-allocation production paths; Python remains private verification tooling, not a new build requirement.

**Inspected authorities and reusable spans.** Here `P` is `integration-owned/combined-cases/` beneath `.uwz-work/evidence/h2-streaming/`; `N` is sibling `combined-native/`. Archive paths are under `docs/implement-2-2-0/evidence/`.

| Source | Binding contract |
|---|---|
| `P/coordinator.py:40–47,111–150,197–265,296–412` | Seven-key connections; disconnect replacement; pre-teardown counts; deadlines and hooks |
| `P/shutdown_cases.py:18–39,72–105` | Grace and exact facts; sole active begin/finish owner |
| `P/test_wire_oracle.py:112–165,521–580` | Wrap once, original exception propagation, checkpoint and ordinary seal |
| `N/native_closing.py:75–114,137–198,241–390` | Exact callback identity, primitive provenance, checkpoint/activation/drain/live receipt |
| `combined-all40.tar.gz::reference/core/wire.py:29–45,146–174,499–542` | Shared context identity, canonical acceptance and termination |
| Same archive, `output_stage.py:24–44,121–182` | Connection/deadline identity and residual budgets |
| `output-driver.tar.gz::source/runtime/connection.py:10–44` | TLS1.3/h2, certificate/hostname verification, ragged-EOF suppression disabled, cleanup ordering |
| `lifecycle-close-live.tar.gz::source/runtime-v2/strict_close.py:8–30` | Public unwrap, returned raw socket EOF and close |
| Output-driver `identity.py:4–29`, `process_io.py:14–31` | Pure identity checks and future provider-owned host observations |

Adapt these algorithms narrowly after authenticating their archived inputs. Do not install `connection.factory`’s obsolete five-key return, seconds-based `owned_io.remaining`, EOF-rejecting `owned_io.read`, or `strict_close.observe_shutdown`. The latter duplicates canonical termination ownership. `process_cleanup.py:4–44` supplies error-retention precedent, but its fresh `clock()+15` is incompatible with acceptance deadlines.

**Named contracts.** Use explicit dictionary/tuple contracts and named callback aliases, no classes or hidden module state:

- `ChildBinding`: run/child identity, selection, observed readiness start/return, supplied ready deadline, whole-run start/deadline, expected process/start/listener identity, address and certificate digest.
- `TransportState`: that binding, clock/operations, bounded connection history, current handle/connection/observer, optional C4 state, signal evidence, first failure and cleanup errors.
- `Connection`: exactly `protocol`, `send`, `receive`, `now`, `owned`, `tls`, `alpn`.
- `Send(bytes)->None`; `Receive()->tuple[bytes,int]`; `Clock()->int`.
- `TransportOps`: named callbacks for dial, TLS wrap/inspection, timeout setting, full send, primitive receive, public unwrap, close, canonical protocol construction, ownership observation and capture-health checking.
- `OwnershipFacts`: observed process status, start identity and listener identities, compared against `ChildBinding`; never an input `owned=True`.
- `OwnedSignal(child_identity, deadline_ns)->SignalFacts`: provider operation that verifies ownership/watcher/open-client prerequisites, actually issues SIGTERM and retains supporting evidence.

Proposed entry points:

```text
new_transport(child, *, clock, ops) -> TransportState
connect(state, case, number, case_deadline, whole_deadline) -> Connection
close(state, context, deadline) -> CloseFacts
disconnect_close(state, context) -> StrictCloseFacts
signal(state, owned_signal, context, deadline) -> SignalFacts
termination(state, context, deadline) -> TerminationFacts
transport_receipt(state, connection_identity) -> TransportReceipt
```

Bind explicit state with `partial` to satisfy existing hook signatures. `TransportReceipt` distinguishes ordinary sealed receipts from C4’s checkpoint plus local closing receipt; it does not create a replacement protocol receipt.

**Ordered implementation slices and acceptance criteria.**

1. **Bind one real connection — transport_io owns; crypto_tls and verification guide.**

   Validate child identity, completed readiness, case/index, deadlines and descriptor before effects. Reuse `P/test_all40_descriptors.py:152–162` for `connection_descriptor`; do not use its synthetic application/provider functions.

   Dial and wrap with residual deadlines. Require TLS1.3, h2, verified localhost identity and expected certificate digest; preserve `suppress_ragged_eofs=False`. Recheck actual ownership and capture health. Create the canonical protocol without sending startup bytes.

   For active shutdown, C4 accepts only `(child, 'shutdown_active', 1)`. Create its state before traffic. Install precisely:

   ```text
   receive = partial(native_closing.receive_once, state, binding)
   send = partial(native_closing.send_once, state, bounded_send)
   binding = (prepare, primitive_recv, clock)
   ```

   `primitive_recv` must invoke only the actual receive operation: ownership, timeout and capture checks belong in `prepare`, not inside a wrapper that could falsely attribute their exception to TLS receive.

   Call `oracle.wrap_connection` once, then `native_closing.bind_observer` once, retaining exact original/wrapped/observer identities. Return the wrapped seven-key connection only after binding. Ordinary cases use bounded callbacks with premature EOF rejection; do not generalize C4 beyond its accepted descriptor.

   Prove no startup traffic precedes binding, no callback replacement/double wrap, exact send return and receive shape, and cleanup at every failed construction stage.

2. **Preserve time and strict close — transport_io with crypto_tls.**

   Use one monotonic integer-nanosecond clock and `units_per_second=1000000000`. Reject booleans, regression, overflow, equality and expiration. Keep absolute child-ready, case, whole and supplied grace deadlines unchanged. Convert only positive residual nanoseconds to seconds at OS waits; check time again after operations.

   Readiness belongs to the child once. Later connections may start after that ready deadline. Supply C4 actual observed factory/connect-entry timestamps, explicitly distinguished from coordinator-internal start samples. Never reconstruct starts by subtracting durations or introduce a first-byte15 budget.

   Ordinary `close` returns its exact three-field facts only after successful socket closure. Strict disconnect uses the original case/whole minimum: successful public `unwrap`, inspect the returned raw socket, require `recv(8192)==b''`, close that returned socket, then return the exact five-field strict-close facts. No canonical begin/finish belongs here.

   Preserve the original exception object and attach cleanup failures without replacing it. A raw close failure prevents success. TLS EOF, timeout, trailing bytes or malformed return never become strict-close success.

3. **Compose active termination — transport_io owns; http_protocol, crypto_tls and verification guide.**

   At active `signal` entry, the coordinator has frozen its counts. Call C4 `freeze_checkpoint(context, wrapped, observer, state, deadline)` before signal effects. Invoke the external owned-signal operation, retain its evidence and exact result, and return only after success within the unchanged deadline. Failure leaves no authorized closing path.

   Let the canonical handler validate signal, mark the stage and call `wire.begin_termination`. The transport’s `termination` hook then calls C4 `activate` with the retained signal, followed by `drain_closing` through the exact wrapped receive callback. Return its narrow termination facts; retain the qualified receipt alongside them. The handler alone calls `wire.finish_termination`.

   Keep all residual case/final budgets, 8192-byte reads, 65536 closing bytes, 4096 frames and at most one terminal probe beyond remaining nonempty-read allowance. Preserve primitive attempts, primitive returns and boundary returns separately. Compare canonical published totals against the checkpoint; retain closing deltas and before/after debts separately. Never add closing deltas back into frozen coordinator counts or manufacture refunds.

   Consume active evidence through `local_receipt(state)` again at final aggregation. Reject stale saved tuples after forbidden I/O. Preserve poison and ordinary seal failure after actual receive-origin `SSLEOFError`; retain `local_transport_only`, unknown internal prefix and no authenticated-close claim.

4. **Prove the binding and review it — verification owns; independent reviewer follows.**

   Use source-only scripted operations/clocks and existing serialized fixtures through the real coordinator and canonical handler. Cover:

   - Timely child readiness followed by later cases; all deadline equality/regression/overflow failures.
   - Wrong identity/certificate/ALPN, failed full send, premature EOF and every construction/close cleanup failure.
   - Strict unwrap failure, raw trailing bytes, raw EOF and returned-socket closure.
   - Active EOF and receive-origin TLS EOF; preparation/clock/parser-origin TLS EOF must fail.
   - Failed signal, intervening I/O, duplicate activation, partial tails, illegal refunds, exhausted budgets and postterminal operations.
   - Exactly one canonical begin/finish, immutable pre-counts, separate closing counters/debts and live receipt revocation.

   Run focused normal/optimized tests and additive inert-import checks only after implementation release. Preserve RED versions and raw command/output/status evidence. Do not rerun unchanged suites without a concrete coverage reason.

**External prerequisites and later native acceptance.** Provider ownership remains explicit: real signal authorization, watcher installation, capture completion, successful exit/reap, listener disappearance, socket cleanup and file/key removal. Forced cleanup permanently fails the attempt. C5’s `parse_capture(CaptureFacts, nonce, expected_capacity)` and `validate_post(selection, before, after)` establish semantics only; transport must neither import unfinished C5 nor duplicate its parser.

Later native release requires authenticated complete candidate/dependency/runtime closure, Debug/ReleaseSafe rebuilds, and separate explicit and genuinely omitted-default all40 invocations with fresh idle/main children and 41 connections. Preserve every project gate in AGENTS, CONTRIBUTE and CI_CD_PIPELINE, including formatting, conventions, version, unit, sanitizer, fuzz, package, protocol and platform checks.

The deep-module seam is coordinator connection/lifecycle hooks over explicit transport operations. Its deletion would spread deadline conversion, socket ownership, callback provenance and closing accounting across provider and case handlers. No additional wrapper module earns its place.

This pass performed metadata/source reads and the prescribed bounded Graphify query. Graph output was truncated and does not establish ignored-helper topology. No files, tests, native operations, compiler, sockets, TLSContext, real clock, network or Git writes were used. The full 2.2.0 goal and native all40 acceptance remain open.
