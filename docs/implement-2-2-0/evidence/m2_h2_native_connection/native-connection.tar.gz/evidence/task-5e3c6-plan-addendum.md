The ownership checks must change phase after successful owned SIGTERM. Requiring the child to remain alive and listening during closing would reject legitimate shutdown.

**Before signal.** Connection construction and ordinary I/O preparation require current ownership observations: process still running, observed start identity matching the retained child, and the expected listener belonging to that child. Preserve capture-health checks and strict case/whole deadlines. At active signal entry:

1. Freeze C4’s checkpoint after canonical final collection and the coordinator’s pre-teardown snapshot.
2. Revalidate the live PID/start/listener and the exact open client connection immediately before signaling. Confirm the previously installed watcher.
3. Issue the owned SIGTERM and retain its successful operation evidence.
4. Check capture health and time before returning signal facts.

Do not require continued process/listener existence after the successful signal operation. Its result must come from the operation and retained prerequisites, not fabricated booleans. Signal failure never authorizes closing.

**After signal.** The canonical handler validates signal facts, marks the stage and begins termination. C4 `activate` then establishes the authorized closing phase. Each closing preparation checks:

- The same retained child identity, connection handle, observer and callback bindings; no replacement socket or reassignment to another process.
- Successful retained signal authorization and the existing C4 lifecycle predicates.
- Capture health: bounded collection without overflow or collector error. Collector completion is permitted; it does not itself prove successful shutdown.
- The unchanged grace deadline, clipped to case/whole, using monotonic integer nanoseconds. Set the OS timeout from positive residual time only.

Closing preparation must **not** require a live process, an existing `/proc` entry, or a still-listening socket. It must not invoke the ordinary live-ownership checker. PID/start/listener observations gathered before signaling remain evidence of signal authorization; closing I/O acts only on the already bound client socket. No further signal is authorized by that evidence.

C4 already samples time before preparation, after preparation and after receive. Its primitive receive callback must still perform only the bound receive operation, preserving exact exception provenance. Do not move capture, ownership or time checks into that callback. Terminal observation remains local transport evidence; real exit/reap, capture completion, listener disappearance, post-validation and cleanup remain later provider prerequisites.

**Correct construction order.** `receive_state` below is C4’s `ReceiveState`, not the enclosing `TransportState`:

```python
receive_state = native_closing.new_receive_state(
    identity, now, units, deadlines, ready_at=ready_at)
binding = (prepare, primitive_recv, clock)
connection['receive'] = partial(native_closing.receive_once, receive_state, binding)
connection['send'] = partial(native_closing.send_once, receive_state, bounded_send)
wrapped, observer = oracle.wrap_connection(connection, descriptor)
native_closing.bind_observer(receive_state, connection, wrapped, observer)
```

Create `connection` with its other five required fields before installing these callbacks. `prepare` selects the ordinary or authorized-closing checks from explicit local lifecycle state. No traffic occurs before the final bind.

**Source-only regression criteria.**

- Missing/replaced PID, changed start identity or wrong listener before signal rejects without signaling or activating.
- Successful signal followed immediately by listener disappearance and process exit still permits legal closing bytes and EOF/TLS EOF.
- The preceding case must prove the live-ownership callback is never invoked during closing.
- Signal failure followed by identical apparent EOF cannot produce an accepted closing receipt.
- Capture overflow/error, changed connection identity, deadline equality/regression and forbidden postterminal I/O still fail.
- Missing successful exit/reap, completed capture, post-validation or normal cleanup prevents overall native acceptance despite a valid local closing receipt.

No new source edits, tests or native operations were performed. C5 ownership and scope remain unchanged.
