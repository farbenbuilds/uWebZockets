"""Verify the preserved public packet without reading private environments."""
import ast
import hashlib
import json
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def nesting(node, depth=0):
    controls = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.With, ast.AsyncWith, ast.Try, ast.TryStar, ast.Match)
    level = depth + int(isinstance(node, controls))
    return max([level] + [nesting(child, level) for child in ast.iter_child_nodes(node)])


def authority():
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_native_post/native-post.tar.gz')
    if sha(archive.read_bytes()) != 'd19281da19d04c3afbc3bb97ef614b21efa3746f0dc405dfb982d7cc959fbe92':
        raise ValueError('Pushed C5 authority differs')
    with tarfile.open(archive, 'r:gz') as stream:
        inventory = json.loads(stream.extractfile('INVENTORY.json').read())
    return {name.removeprefix('native/'): row for name, row in inventory.items() if name.startswith('native/')}


def preserve(source, expected):
    paths = list(source.rglob('*'))
    if any(path.is_symlink() for path in paths):
        raise ValueError('Native packet symlink')
    public = source / 'evidence/native-post/privacy-publication-inputs'
    raw = (public / 'manifest.json').read_bytes()
    row = expected['evidence/native-post/privacy-publication-inputs/manifest.json']
    if len(raw) != row['size'] or sha(raw) != row['sha256']:
        raise ValueError('Published privacy projection map differs')
    manifest = json.loads(raw)
    replacements = {row['original_member'].removeprefix('native/'): public / row['replacement'] for row in manifest['substitutions']}
    if len(expected) != 6482 or len(replacements) != 25:
        raise ValueError('Public-view authority count differs')
    for name, row in expected.items():
        if name == 'test_native_imports.py':
            continue
        path = replacements.get(name, source / name)
        data = path.read_bytes()
        if len(data) != row['size'] or sha(data) != row['sha256']:
            raise ValueError('Protected public-view bytes differ: ' + name)
    actual = {path.relative_to(source).as_posix() for path in paths if path.is_file()}
    added = actual - expected.keys()
    modules = {'native_transport.py', 'test_native_transport.py'}
    if not expected.keys() <= actual or not modules <= added:
        raise ValueError('Native preservation path set differs')
    if any(name not in modules and not name.startswith('evidence/native-transport/') for name in added):
        raise ValueError('Native addition scope differs')
    return dict(public_view_paths=6482, protected_unchanged=6481, private_paths_not_read=25,
                private_projection_bytes_verified=25, authorized_import_edit=expected['test_native_imports.py'],
                new_files=len(added), directory_history='File-only published authority; no inferred directory history')


def sources(source):
    result = {}
    for name in ('test_native_transport.py', 'native_transport.py', 'test_native_imports.py'):
        data = (source / name).read_bytes()
        tree = ast.parse(data)
        if nesting(tree) > 3 or any(isinstance(node, (ast.ClassDef, ast.Assert, ast.Global, ast.Nonlocal)) for node in ast.walk(tree)):
            raise ValueError('Touched source structure differs')
        result[name] = dict(size=len(data), sha256=sha(data), maximum_nesting=nesting(tree))
    return result


def main(arguments):
    if arguments != ['--audit']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/combined-native')
    result = dict(preservation=preserve(source, authority()), sources=sources(source),
                  native_executed=False, complete_transport=False, milestone_complete=False)
    (plan / 'task-5e3c6a-root-final-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
