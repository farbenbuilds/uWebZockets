**Spec: Issuesfound. Quality: Needsfixes.**

1. **[P1] Ordinary close rejects the canonical intermediate-case deadline.**  
   [native_transport.py:289](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native/native_transport.py:289) requires every close deadline to be within 15 seconds of `context['now']`. However, [coordinator.py:393](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/coordinator.py:393) passes `min(case_deadline, whole)` when closing an intermediate connection. A successful 30-second case finishing with more than 15 seconds remaining therefore raises `ValueError('close_deadline')`, leaves its socket open, and prevents the next case.

   The injected reproduction used `('ready_buffered', 'async_delayed')`, context tick `3`, and the original deadline `30000000003`; it produced `close_deadline` with zero close operations. [test_native_transport.py:143](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native/test_native_transport.py:143) misses this because it substitutes a 10-second deadline.

   Accept the coordinator’s unchanged case/whole deadline for intermediate closes while preserving the supplied final grace deadline. Add regression coverage using the canonical intermediate-close hook behavior.

Verification and remaining gaps:

- Review package SHA256 and all three current source hashes match the supplied report. Saved normal and optimized focused tests, inert checks, preservation, and Graphify update report status `0`; passing suites were not rerun.
- The narrow reproduction used injected operations only, after fresh pinned restoration: `/tmp/task-5e3c6a-review-close-restore-1.json`, reporting `restored 0`.
- The runner snapshots dependencies before restoring them. Every inspected restoration log reports `restored 0`, so no current snapshot mismatch was demonstrated. A future restoration that changes files would require snapshots of the restored bytes.
- Graphify’s bounded query was truncated and does not establish ignored-helper topology. Retained Graphify `.so`/Python snapshots support tooling provenance only; publication still needs explicit hash references rather than native-runtime authority claims.
- Active receive failure cleanup remains downstream provider ownership work. C6b, C6c, real ownership observations, native acceptance, and project verification gates remain open.
- The structural lens found no additional actionable maintainability defect: the focused transport seam earns its boundary, and neither changed source file approaches the project’s file-size review flag.

No files were edited; this full verdict is returned for Root to record.
