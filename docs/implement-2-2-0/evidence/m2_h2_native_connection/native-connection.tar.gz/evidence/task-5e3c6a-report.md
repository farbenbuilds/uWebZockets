# C6a source transport connection slice

DONE_WITH_CONCERNS: the narrowed constructor/ordinary-I/O/ordinary-close slice is implemented and source-tested. C6b strict disconnect, C6c signal/termination/live receipts and real provider/native acceptance remain required. No placeholder hooks were added.

## Files and interfaces

Under `.uwz-work/evidence/h2-streaming/combined-native/`:

- New `native_transport.py`: `new_transport(child, *, clock, ops)`, `connect(state, case, number, case_deadline, whole_deadline)`, `close(state, context, deadline)`.
- New `test_native_transport.py`: 14 deterministic focused groups.
- `test_native_imports.py`: only the exact two-name inventory addition.
- New controls, code-only snapshots, safe metadata and raw proof under `evidence/native-transport/` (`E` below).

`ChildBinding` has exact fields: `identity=(run,child)`, canonical tuple `selection`, observed `ready_start/ready_at`, original `ready_deadline/whole_start/whole_deadline`, `pid/start_identity/listener/address/certificate_sha256`. `new_transport` validates and copies those facts without calling operations. Readiness is child-scoped; the `entry` retained by `connect` is its observed callback-entry tick, not a reconstructed coordinator start.

`TransportOps` has exact callable keys: `dial(address, seconds)`, `wrap(raw, 'localhost', False, seconds)`, `inspect(handle)`, `set_timeout(handle, seconds)`, `send(handle, bytes)`, `recv(handle, 8192)`, `close(handle)`, `ownership()`, `capture()`, `new_protocol()`. The last must be the existing `h2_client.new_protocol` identity. Named callback aliases and exact observation schemas are documented in source. Successful wrap transfers raw ownership; failed wrap leaves raw owned by the caller. Successful close returns `None`. No input `owned=True` substitutes for observed PID/start/listener facts.

Returned connections have exactly `protocol/send/receive/now/owned/tls/alpn`. Canonical descriptor and protocol identities are reused. Outer state retains `history` (maximum 41), `current`, `failure` (exact first exception), and `cleanup_errors` (bounded exact exception objects). Each connection record retains `identity`, original deadlines, entry, handle, closed/release facts, original/wrapped connections, observer and separate C4 `receive_state`.

Active construction creates C4 state and binding before the exact receive/send partials, wraps once and binds once before HTTP traffic. Its primitive is only the bound receive operation; ownership/capture/timeout/time checks remain outside primitive provenance. Active ordinary EOF still fails. Ordinary close rejects active and first-disconnect connections, leaves canonical lifecycle ownership untouched, and returns the exact three-field close facts only after supplied closure and post-operation checks succeed.

The clock is integer nanoseconds (`1000000000` units/second), bounded to uint64, nondecreasing, and strictly before the unchanged deadline. Repeated ticks are valid; equality with a deadline fails. Only positive residuals become seconds. A canonical context may lag the transport after a successful send; close retains the maximum observed tick without extending grace/case/whole deadlines.

SHA256:

```text
f9931ec5914c0c40d914b51fb86c4bc162df1f9bc0ba5ce3d4c40df37d62c5fd  native_transport.py
b6efeec1bbe0e8b5b42f5eae395f7aad625f07a2442e0210ed9800c25370459b  test_native_transport.py
1d9baac7ff2aa10eea930ee6a24522109c97a7e8fc5852660f0dd541187378b3  test_native_imports.py
```

## Commands and results

Commands ran from `/workspaces/uWebZockets`. Exact argv is retained as each run's `argv.nul`; exact wrapper, safe controls, source hashes, restoration stdout/stderr/receipt, test stdout/stderr/status and interpreter hash are retained beside it. For compact reproducibility, define:

```sh
N=.uwz-work/evidence/h2-streaming/combined-native
R=$N/evidence/native-transport/control/run.sh
P=/home/codespace/.python/current/bin/python3
```

Final commands (all status `0`):

```sh
env -i PATH=/usr/bin:/bin bash "$R" final2-normal "$P" -B -S "$N/test_native_transport.py" --check
env -i PATH=/usr/bin:/bin bash "$R" final2-optimized "$P" -B -S -O "$N/test_native_transport.py" --check
env -i PATH=/usr/bin:/bin bash "$R" final2-inert-normal "$P" -B -S "$N/test_native_imports.py" --check
env -i PATH=/usr/bin:/bin bash "$R" final2-inert-optimized "$P" -B -S -O "$N/test_native_imports.py" --check
env -i PATH=/usr/bin:/bin bash "$R" final2-graph-update "$P" -B -S "$N/evidence/native-transport/control/graphify_runner.py" update .
env -i PATH=/usr/bin:/bin bash "$R" final2-preservation "$P" -B -S "$N/evidence/native-transport/control/preserve.py" --after
```

Each Python operation has a fresh `task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT` immediately before it in the same shell, exact six-part `PYTHONPATH`, `PYTHONDONTWRITEBYTECODE=1`, seed 0 and the pinned interpreter SHA `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`. Optimization modes were Python normal and `-O`; no Zig optimization mode was exercised.

Raw focused final summary and exit status from `E/final2-{normal,optimized}/{stdout,status}`:

```text
{"groups": 14, "source_only": true, "native_executed": false, "c6b_c6c_complete": false}
Exit status: 0
```

Groups cover static no-effects rejection, ordinary/canonical startup and receive, child-scoped late readiness, exact C4 binding, clocks/overflow/equality/regression, ownership/TLS/certificate/ALPN/capture rejection, every setup stage's cleanup, invalid I/O shapes/EOF and exception identity, active primitive provenance, ordinary close failure paths, poisoned-observer I/O rejection, residual/post-operation time, cleanup success/history bounds and context/transport clock advancement. Inert checks cover imports plus empty/foreign main invocation; nesting is transport 1, test 3.

Behavioral REDs are retained separately from API absence: `red-bounds-corrected-fixture` accepted an excessive case deadline; `red-failures` allowed I/O through a poisoned observer; `red-close-clock` rejected a valid close after send advanced time. All exited 1 before their fixes. `red-api` is only missing API evidence. The initial `red-bounds` fixture incorrectly used zero-length initial SETTINGS; the canonical contract requires 30 bytes. Its correction preserved the protocol expectation.

## Preservation and limits

`E/{before,after}.json` and `final2-preservation` prove the 6482-path C5 public view, the exact permitted inventory edit and allowed new path set. The archive SHA matches `d19281da19d04c3afbc3bb97ef614b21efa3746f0dc405dfb982d7cc959fbe92`. All 25 private original environment paths were substituted with reviewed public projections before reading/hashing; originals were never read, copied, hashed or printed. Snapshots contain source/code dependencies only, never old evidence trees or ambient environment dumps.

AST-only Graphify update exited 0, reporting no relevant changes; ignored helper topology is not established. The initial bounded Graphify query preceded source exploration but lacks a transitive tool snapshot; the retained final update includes one.

No compiler, server, socket, SSLContext, real transport clock, process-under-test, network, install or Git/publication operation ran. No unchanged C4/C5/S46/all40 suites were repeated. Actual OS ownership, strict disconnect, signal authorization/watcher, authorized closing, live receipts, capture completion/post checks, normal cleanup, successful exit/reap/listener disappearance and native all40 acceptance remain unproved and required downstream.

## Fix round 1: canonical intermediate close deadline

The review's P1 is fixed. `validate_close` now uses the original case/whole minimum for intermediate connections; only the final selected case has the additional 15-second grace cap. The supplied deadline is passed unchanged to every sample and close check. No clock, case, whole or shorter final-grace deadline is extended.

Only `native_transport.py` and `test_native_transport.py` changed in this round. The new `canonical_intermediate_close` regression runs the real `coordinator.run` for `ready_buffered,async_delayed`, using the accepted serialized core peer with injected transport operations. It proves the coordinator supplies `30000000003`, closes exactly the TLS handle, retains canonical close facts and reaches the second connection. The test stops there with an exact expected sentinel exception; it does not claim a completed two-case native run. `late_readiness` also now uses the original case/whole close deadline. Existing final-close tests retain shorter deadlines and reject expiration or excessive grace.

True RED: `E/fix1-red-intermediate` exited 1 at the real coordinator intermediate-close hook with `ValueError: close_deadline`. The original source is retained by Root in `task-5e3c6a-fix1-before-source` and by the RED snapshot. With `N`, `R`, `P` as defined above, exact focused final commands were:

```sh
env -i PATH=/usr/bin:/bin bash "$R" fix1-normal "$P" -B -S "$N/test_native_transport.py" --check
env -i PATH=/usr/bin:/bin bash "$R" fix1-optimized "$P" -B -S -O "$N/test_native_transport.py" --check
env -i PATH=/usr/bin:/bin bash "$R" fix1-inert-normal "$P" -B -S "$N/test_native_imports.py" --check
env -i PATH=/usr/bin:/bin bash "$R" fix1-inert-optimized "$P" -B -S -O "$N/test_native_imports.py" --check
env -i PATH=/usr/bin:/bin bash "$R" fix1-preservation "$P" -B -S "$N/evidence/native-transport/control/preserve.py" --after
```

All five statuses are `0`, with exact argv, safe controls, source snapshots, fresh same-shell restore receipts and raw stdout/stderr/status in each corresponding `E/fix1-*` directory. Raw normal and `-O` focused summaries:

```text
canonical_intermediate_close: PASS
{"groups": 15, "source_only": true, "native_executed": false, "c6b_c6c_complete": false}
```

Both inert runs retain `import_empty_foreign_inert=true`, `shared_canonical_identity=true`, transport nesting 1/test nesting 3. Preservation outputs:

```text
{"public_paths": 6482, "private_paths_never_read": 25, "exact_additive_inventory": true}
```

Current SHA256 values supersede the initial report values:

```text
88b97b4437612f273356741b0f91e2412d453412163a574d2e31d596ba332ecc  native_transport.py
4f1bfcb66fc122c16a29b39c665a58006c8c5ffc6938758a441afcb249671789  test_native_transport.py
1d9baac7ff2aa10eea930ee6a24522109c97a7e8fc5852660f0dd541187378b3  test_native_imports.py
```

No old suites, native operations, Graphify closure copy, Git or publication ran in this fix. Root owns the final AST-only update. Collector snapshot ordering remains the separately deferred minor issue; it was not changed. Active receive cleanup remains C6c/provider work, with no C4 socket-cleanup claim. Status: DONE_WITH_CONCERNS pending scoped re-review and the previously stated downstream work.
