# C6a: construct one bounded coordinator transport connection

This is the first implementation slice of C6, not a substitute for C6. The
initial C6 owner returned an incomplete report without code or a concrete
external blocker. Root splits the existing architect plan into C6a connection
setup/ordinary I/O/ordinary close, C6b strict disconnect, C6c active signal/
termination/live receipts. ALL slices and the original native/full goal remain
required. Preserve task-5e3c6-report.md as the truthful initial status.

Read task-5e3c6-plan-report.md and task-5e3c6-plan-addendum.md, plus the privacy/
preservation/tooling constraints in task-5e3c6-brief.md. Implement ONLY the first
slice here. BASE ad43ddba05de35705c11384e6af858082a744550 is clean/pushed.

Own new combined-native/native_transport.py, test_native_transport.py and the
necessary additive test_native_imports.py inventory entry. New safe metadata
and proof under evidence/native-transport/. Prefix is
.uwz-work/evidence/h2-streaming/. You are sole implementation owner, not alone;
preserve all other work. No subagents/Git/publication. Root reviews/commits/pushes.

Deliver implemented new_transport, connect and ordinary close plus required
private helpers. Define explicit named data/callback contracts from the plan.
Do not add unimplemented hooks/stubs/placeholders for C6b/c or claim complete
transport/provider acceptance. Report your actual interfaces for later slices.

Required behavior:
- Validate child/readiness/selection/case/index/identity/deadlines before
  effects, retain caller-owned bounded state/history. Readiness is observed
  once per child; later connections may start after the ready deadline.
- One monotonic integer ns clock, units_per_second=1000000000, original case/
  whole deadlines. Reject boolean ticks, overflow/regression/equality/expiry.
  Only residual positive time converts to OS timeout units; recheck after ops.
- Named injected operations perform dial, TLS wrap/inspection, timeout, full
  send, primitive receive, close and live ownership/capture observations.
  Match expected PID/start/listener facts, TLS1.3/h2, hostname/certificate and
  digest policy; do not accept an input owned=True as ownership evidence.
- Build exactly protocol/send/receive/now/owned/tls/alpn with the canonical
  protocol and descriptor. No startup HTTP traffic before observer wrapping.
- Ordinary bounded I/O rejects premature EOF and invalid send/receive shapes.
  Preserve exact primary exceptions and cleanup errors at every construction
  and ordinary-close failure. Close facts must match canonical three-field
  schema and follow actual supplied close success, never forced cleanup.
- Active-descriptor construction must already use accepted C4 correctly:
  separate ReceiveState, binding created before exact partial callbacks,
  wrap once and bind once before traffic. Primitive callback contains only
  recv; ownership/capture/time preparation stays outside its origin boundary.
  This slice proves ordinary pre-signal active I/O, NOT checkpoint/signal/
  activate/drain/termination acceptance; those belong to C6c.
- Keep canonical state/module identities and all accepted C4/C5 code unchanged.
  No second parser/model/client, no obsolete old runtime factory wholesale.

TDD in the narrow boundary: no-effects invalid inputs; valid ordinary and
active connection shapes; no startup I/O before bind; one wrap/bind; late
legitimate case; deadline/type/regression/overflow failures; wrong ownership/
TLS/cert/ALPN; send/receive failure identity and premature EOF; cleanup at each
construction stage and ordinary close. Use existing serialized codecs where
bytes are needed. Focused normal/-O and additive inert tests. No old C4/C5/
S46/all40 suite repeats without a concrete new gap. No real compiler/server/
socket/SSLContext/clock/process-under-test/network/install operations.

Preserve C5's public Native6482 view from archive SHA
d19281da19d04c3afbc3bb97ef614b21efa3746f0dc405dfb982d7cc959fbe92.
At25 private local environment paths use the reviewed C5 public projection
before comparison; NEVER copy/hash/print originals. Source snapshots copy code
only, not whole evidence trees. New runners use env-i/explicit safe controls,
never ambient env dumps. Keep every exercised new helper/source version and
safe argv/settings/restore/stdout/stderr/status before runs. Preserve all other
prior paths/bytes; sole authorized prior edit is additive native import list.

Follow AGENTS/conventions/narrow TDD/API skills and relevant transport/TLS/
verification constraints. No classes/assert/custom errors/global mutable state,
no hidden OOP or silenced errors; functions <=3 control nesting. Python/tooling
requirements are EXACTLY those in task-5e3c6-brief.md: pinned -B -S interpreter,
fresh task-5e3b8a restore receipt immediately before each dependent operation in
SAME shell, exact six-part PYTHONPATH, PYTHONDONTWRITEBYTECODE=1. Graphify before
NEW codebase questions, supplied paths alreadylocated; final AST-only update,
no ignored-helper topology claim. No skill edits or gate weakening.

Write task-5e3c6a-report.md here, <=1200words preferred: changed files/interfaces/
hashes/exact commands/results/raw evidence/concerns and remaining C6b/c/provider
scope. Return concise DONE|DONE_WITH_CONCERNS|NEEDS_CONTEXT|BLOCKED. If blocked,
name the precise missing input or failed invariant immediately; remaining
implementation work alone is not an external blocker.
