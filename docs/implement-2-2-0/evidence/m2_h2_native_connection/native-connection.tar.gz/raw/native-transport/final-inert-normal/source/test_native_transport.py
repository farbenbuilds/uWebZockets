"""Focused source-only C6a checks over injected operations and canonical codecs."""
import json
import sys
from functools import partial
from unittest import mock
import adapter
import coordinator
import h2_client
import native_closing
import native_transport as transport
import test_core_peer
import test_wire_oracle as oracle


def require(value, message):
    if not value:
        raise RuntimeError(message)


def raises(callback, kind=ValueError, exact=None):
    try:
        callback()
    except kind as error:
        require(exact is None or error is exact, 'primary exception replaced')
        return error
    raise RuntimeError('missing rejection')


def initial_settings():
    payload = b"".join(key.to_bytes(2, "big") + value.to_bytes(4, "big") for key, value in
                       ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    return test_core_peer.frame(4, 0, 0, payload) + test_core_peer.frame(4, 1, 0, b"")


def fixture(selection=('ready_buffered',), tick=3):
    script = dict(tick=tick, events=[], failures={}, responses=[initial_settings()],
                  raw=object(), tls=object(), sent=[], timeout=[], state=None, results={}, tick_after={})
    child = dict(identity=('transport_test', 0), selection=selection, ready_start=1, ready_at=2,
                 ready_deadline=15000000001, whole_start=0, whole_deadline=900000000000,
                 pid=123, start_identity='start-1', listener=('127.0.0.1', 4433),
                 address=('127.0.0.1', 4433), certificate_sha256='a' * 64)

    def clock():
        error = script['failures'].get('clock')
        if error is not None:
            raise error
        return script['tick']

    def operation(name, *args):
        script['events'].append((name, args))
        error = script['failures'].get(name)
        if error is not None:
            raise error
        result = script['results'][name] if name in script['results'] else perform(script, child, name, args)
        if name in script['tick_after']:
            script['tick'] = script['tick_after'][name]
        return result

    ops = {name: partial(operation, name) for name in
           ('dial', 'wrap', 'inspect', 'set_timeout', 'send', 'recv', 'close', 'ownership', 'capture')}
    ops['new_protocol'] = h2_client.new_protocol
    return script, child, clock, ops


def perform(script, child, name, args):
    if name == 'dial':
        return script['raw']
    if name == 'wrap':
        require(args[0] is script['raw'] and args[1:3] == ('localhost', False), 'TLS policy arguments')
        return script['tls']
    if name == 'inspect':
        return dict(tls='TLSv1.3', alpn='h2', hostname='localhost', check_hostname=True,
                    certificate_verified=True, certificate_sha256=child['certificate_sha256'], suppress_ragged_eofs=False)
    if name == 'ownership':
        return dict(pid=child['pid'], running=True, start_identity=child['start_identity'], listeners=(child['listener'],))
    if name == 'capture':
        return dict(overflow=False, error=None, complete=False)
    if name == 'set_timeout':
        script['timeout'].append(args[1])
    if name == 'send':
        state = script['state']
        require(state is not None and state['current']['observer']['operation'] > 0, 'unwrapped startup send')
        script['sent'].append(args[1])
    if name == 'recv':
        require(args[1] == 8192, 'receive size')
        return script['responses'].pop(0)
    return None


def opened(selection=('ready_buffered',), tick=3):
    script, child, clock, ops = fixture(selection, tick)
    state = transport.new_transport(child, clock=clock, ops=ops)
    script['state'] = state
    case = selection[0]
    connection = transport.connect(state, case, 1, tick + 30000000000, child['whole_deadline'])
    return script, state, connection


def context(state, connection):
    row = state['current']
    return adapter.open_case(row['identity'][1], connection['protocol'], connection['send'], connection['now'],
                             row['case_deadline'], state['child']['whole_deadline'], clock=state['clock'])


def shape_and_startup():
    script, state, connection = opened()
    coordinator.validate_connection(connection, 3, 30000000003)
    require(not script['sent'] and all(name != 'recv' for name, args in script['events']), 'startup traffic before bind')
    current = context(state, connection)
    require(script['sent'] and state['current']['observer']['operation'] > 0, 'startup not observed')
    data, tick = connection['receive']()
    adapter.observe(current, data, tick)
    require(current['stage']['initial_settings'] == 1, 'canonical receive state absent')
    facts = transport.close(state, current, 10000000000)
    require(facts == dict(method='close', client_closed=True, close='normal'), 'close schema')
    require([args[0] for name, args in script['events'] if name == 'close'] == [script['tls']], 'wrong socket closure')
    raises(lambda: transport.close(state, current, 10000000000))


def invalid_inputs():
    mutations = (('identity', ('bad space', 0)), ('identity', ('run', True)), ('selection', ('missing',)),
                 ('selection', ('shutdown_active', 'shutdown_idle')), ('ready_at', True), ('ready_at', 15000000001),
                 ('ready_deadline', 15000000002), ('whole_deadline', 1 << 64), ('pid', True),
                 ('certificate_sha256', 'z' * 64), ('address', ('elsewhere', 4433)))
    for key, value in mutations:
        script, child, clock, ops = fixture()
        child[key] = value
        raises(lambda: transport.new_transport(child, clock=clock, ops=ops))
        require(not script['events'], 'invalid child caused effects')
    for args in (('missing', 1, 100, 900000000000), ('ready_buffered', True, 100, 900000000000),
                 ('ready_buffered', 2, 100, 900000000000), ('ready_buffered', 1, True, 900000000000),
                 ('ready_buffered', 1, 3, 900000000000), ('ready_buffered', 1, 30000000004, 900000000000),
                 ('ready_buffered', 1, 100, 900000000001)):
        script, child, clock, ops = fixture()
        state = transport.new_transport(child, clock=clock, ops=ops)
        raises(lambda: transport.connect(state, *args))
        require(not script['events'], 'invalid connection caused effects')


def late_readiness():
    script, state, connection = opened(('ready_buffered', 'async_delayed'))
    current = context(state, connection)
    transport.close(state, current, 10000000000)
    script['tick'] = 20000000000
    later = transport.connect(state, 'async_delayed', 1, 50000000000, 900000000000)
    require(later['now'] == 20000000000 and len(state['history']) == 2, 'per-connection ready budget')
    require(state['child']['ready_deadline'] == 15000000001, 'readiness changed')


def active_binding():
    with mock.patch.object(oracle, 'wrap_connection', wraps=oracle.wrap_connection) as wrap:
        with mock.patch.object(native_closing, 'bind_observer', wraps=native_closing.bind_observer) as bind:
            script, state, connection = opened(('shutdown_active',), tick=20000000000)
            require(wrap.call_count == bind.call_count == 1, 'not exactly one wrap/bind')
    row, receive_state = state['current'], state['current']['receive_state']
    require(receive_state is not state and receive_state['wrapped'] is connection, 'C4 state identity')
    original = row['original']
    require(original['receive'].func is native_closing.receive_once and original['receive'].args ==
            (receive_state, receive_state['binding']), 'C4 receive partial')
    require(original['send'].func is native_closing.send_once and original['send'].args[0] is receive_state, 'C4 send partial')
    current = context(state, connection)
    data, tick = connection['receive']()
    adapter.observe(current, data, tick)
    require(receive_state['counts']['attempts'] == receive_state['counts']['boundary_returns'] == 1, 'C4 accounting')
    require(receive_state['ready'] == (0, 1, 2, 15000000001), 'C4 ready observation')
    require(receive_state['deadlines'][2] == 20000000000, 'C4 observed entry time')
    require(current['stage']['initial_settings'] == 1, 'active canonical I/O')


def clock_boundaries():
    for tick in (True, -1, 1, 100, 1 << 64):
        script, child, clock, ops = fixture()
        state = transport.new_transport(child, clock=clock, ops=ops)
        script['tick'] = tick
        raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline']))
        require(not script['events'], 'invalid entry clock caused effects')
    for operation in ('ownership', 'capture', 'dial', 'wrap', 'inspect'):
        script, child, clock, ops = fixture()
        original = ops[operation]
        def expire(*args):
            result = original(*args)
            script['tick'] = 100
            return result
        ops[operation] = expire
        state = transport.new_transport(child, clock=clock, ops=ops)
        raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline']))
        require(state['failure'] is not None and state['current']['release'] is None, 'late construction accepted')
    script, child, clock, ops = fixture()
    child.update(whole_start=transport.U64 - 10, ready_start=transport.U64 - 9, ready_at=transport.U64 - 8,
                 ready_deadline=transport.U64 - 7, whole_deadline=transport.U64)
    raises(lambda: transport.new_transport(child, clock=clock, ops=ops))
    require(not script['events'], 'overflow caused effects')


def observation_failures():
    fields = (('ownership', 'pid', 456), ('ownership', 'pid', True), ('ownership', 'running', False),
              ('ownership', 'start_identity', 'replaced'), ('ownership', 'listeners', (('127.0.0.1', 4434),)),
              ('inspect', 'tls', 'TLSv1.2'), ('inspect', 'alpn', 'http/1.1'), ('inspect', 'hostname', 'other'),
              ('inspect', 'check_hostname', False), ('inspect', 'certificate_verified', False),
              ('inspect', 'certificate_sha256', 'b' * 64), ('inspect', 'suppress_ragged_eofs', True),
              ('capture', 'overflow', True), ('capture', 'error', RuntimeError('capture')), ('capture', 'complete', 1))
    for name, key, value in fields:
        script, child, clock, ops = fixture()
        facts = perform(script, child, name, ())
        facts[key] = value
        script['results'][name] = facts
        state = transport.new_transport(child, clock=clock, ops=ops)
        raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline']))
        require(state['current']['release'] is None, 'bad observations earned success')
    script, child, clock, ops = fixture()
    script['results']['ownership'] = dict(owned=True)
    state = transport.new_transport(child, clock=clock, ops=ops)
    raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline']))


def construction_failures():
    for stage in ('ownership', 'capture', 'dial', 'wrap', 'inspect'):
        script, child, clock, ops = fixture()
        primary, secondary = RuntimeError(stage), RuntimeError('cleanup')
        script['failures'].update({stage: primary, 'close': secondary})
        state = transport.new_transport(child, clock=clock, ops=ops)
        raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline']), RuntimeError, primary)
        require(state['failure'] is primary, 'construction failure lost')
        expected = [secondary] if stage in ('wrap', 'inspect') else []
        require(state['cleanup_errors'] == expected, 'construction cleanup failure lost')
        handles = [args[0] for name, args in script['events'] if name == 'close']
        require(handles == ([script['raw']] if stage == 'wrap' else [script['tls']] if stage == 'inspect' else []), 'construction cleanup handle')
    for module, name in ((h2_client, 'new_protocol'), (oracle, 'wrap_connection'), (native_closing, 'bind_observer')):
        script, child, clock, ops = fixture(('shutdown_active',))
        primary, secondary = RuntimeError(name), RuntimeError('cleanup')
        script['failures']['close'] = secondary
        with mock.patch.object(module, name, side_effect=primary) as callback:
            ops['new_protocol'] = h2_client.new_protocol
            state = transport.new_transport(child, clock=clock, ops=ops)
            raises(lambda: transport.connect(state, 'shutdown_active', 1, 100, child['whole_deadline']), RuntimeError, primary)
        require(callback.call_count == 1 and state['failure'] is primary and state['cleanup_errors'] == [secondary], 'binding stage cleanup')
        require([args[0] for name, args in script['events'] if name == 'close'] == [script['tls']], 'bound handle cleanup')


def io_shapes_and_failures():
    for selection in (('ready_buffered',), ('shutdown_active',)):
        for value in (None, bytearray(b'x'), (b'x', 3), b'', b'x' * 8193):
            script, state, connection = opened(selection)
            script['results']['recv'] = value
            raises(connection['receive'])
            require(state['current']['observer']['failure'] is not None, 'bad receive not poisoned')
        for value in (b'', bytearray(b'x'), 'x', b'x' * 65537):
            script, state, connection = opened(selection)
            raises(lambda: connection['send'](value))
            require(not script['sent'], 'invalid send entered primitive')
        for name in ('send', 'recv', 'set_timeout', 'ownership', 'capture'):
            script, state, connection = opened(selection)
            primary, secondary = RuntimeError(name), RuntimeError('cleanup')
            script['failures'].update({name: primary, 'close': secondary})
            action = partial(connection['send'], b'x') if name == 'send' else connection['receive']
            raises(action, RuntimeError, primary)
            require(state['current']['observer']['failure'] is not None, 'I/O failure not poisoned')
            if selection == ('ready_buffered',) or name == 'send':
                require(state['failure'] is primary and state['cleanup_errors'] == [secondary], 'I/O cleanup failure identity')
    script, state, connection = opened()
    script['results']['send'] = 1
    raises(lambda: connection['send'](b'x'))
    require(state['failure'] is not None, 'short/full send shape accepted')


def active_origin_boundary():
    for name in ('recv', 'ownership', 'capture', 'set_timeout'):
        script, state, connection = opened(('shutdown_active',))
        primary = RuntimeError(name)
        script['failures'][name] = primary
        raises(connection['receive'], RuntimeError, primary)
        receive_state = state['current']['receive_state']
        require(receive_state['phase'] == 'failed', 'active ordinary failure not sticky')
        if name == 'recv':
            require(receive_state['provenance'][4] == 'recv_raised' and receive_state['provenance'][6] is primary, 'primitive origin lost')
        else:
            require(receive_state['provenance'] is None and receive_state['counts']['attempts'] == 0, 'preparation attributed to recv')
    script, state, connection = opened(('shutdown_active',))
    before = len(script['events'])
    script['tick'] = True
    raises(connection['receive'])
    require(len(script['events']) == before and state['current']['receive_state']['provenance'] is None, 'clock attributed to recv')


def close_failures():
    for stage in ('ownership', 'capture', 'close'):
        script, state, connection = opened()
        current = context(state, connection)
        primary, secondary = RuntimeError(stage), RuntimeError('close cleanup')
        script['failures'][stage] = primary
        if stage != 'close':
            script['failures']['close'] = secondary
        raises(lambda: transport.close(state, current, 100), RuntimeError, primary)
        require(state['failure'] is primary and state['current']['release'] is None, 'failed close success')
        require(state['cleanup_errors'] == [primary if stage == 'close' else secondary], 'close cleanup errors lost')
    script, state, connection = opened()
    current = context(state, connection)
    original = state['ops']['close']
    def late_close(handle):
        original(handle)
        script['tick'] = 100
    state['ops']['close'] = late_close
    raises(lambda: transport.close(state, current, 100))
    require(state['current']['closed'] and state['current']['release'] is None, 'late close receipt')
    require(sum(name == 'close' for name, args in script['events']) == 1, 'already closed handle closed twice')
    for deadline in (True, 3, 15000000004):
        script, state, connection = opened()
        current = context(state, connection)
        before = len(script['events'])
        raises(lambda: transport.close(state, current, deadline))
        require(len(script['events']) == before, 'invalid close had effects')


def poisoned_observer_blocks_io():
    script, state, connection = opened()
    state['current']['observer']['failure'] = ('external_poison', 'receive', 0, 0, None)
    before = len(script['events'])
    raises(connection['receive'])
    require(all(name == 'close' for name, args in script['events'][before:]), 'poisoned observer entered I/O')



def residual_and_postoperation_time():
    script, state, connection = opened()
    context(state, connection)
    require(all(value == 30.0 for value in script['timeout']), 'timeout conversion changed units')
    for selection in (('ready_buffered',), ('shutdown_active',)):
        for name in ('send', 'recv', 'set_timeout'):
            script, state, connection = opened(selection)
            script['tick_after'][name] = state['current']['case_deadline']
            action = partial(connection['send'], b'x') if name == 'send' else connection['receive']
            raises(action)
            require(state['current']['observer']['failure'] is not None, 'expired operation accepted')
    script, child, clock, ops = fixture(tick=99)
    state = transport.new_transport(child, clock=clock, ops=ops)
    script['state'] = state
    connection = transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline'])
    connection['receive']()
    require(script['timeout'] == [1e-9], 'one-ns residual lost')


def successful_cleanup_and_bounds():
    for stage in ('wrap', 'inspect'):
        script, child, clock, ops = fixture()
        primary = RuntimeError(stage)
        script['failures'][stage] = primary
        state = transport.new_transport(child, clock=clock, ops=ops)
        raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline']), RuntimeError, primary)
        require(state['current']['closed'] and not state['cleanup_errors'] and state['current']['release'] is None, 'cleanup fabricated close facts')
    script, child, clock, ops = fixture()
    state = transport.new_transport(child, clock=clock, ops=ops)
    state['history'].extend([None] * 41)
    raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, child['whole_deadline']))
    require(not script['events'], 'history bound allowed effects')
    script, state, connection = opened()
    before = len(script['events'])
    raises(lambda: transport.connect(state, 'ready_buffered', 1, 100, 900000000000))
    require(len(script['events']) == before, 'duplicate connect caused effects')
    for name in ('close', 'set_timeout', 'send'):
        script, state, connection = opened()
        script['results'][name] = True
        action = partial(transport.close, state, context(state, connection), 100) if name == 'close' else partial(connection['send'], b'x')
        raises(action)
        require(state['current']['release'] is None, 'invalid operation result earned receipt')



def run():
    groups = (shape_and_startup, invalid_inputs, late_readiness, active_binding, clock_boundaries,
              observation_failures, construction_failures, io_shapes_and_failures, active_origin_boundary,
              close_failures, poisoned_observer_blocks_io, residual_and_postoperation_time,
              successful_cleanup_and_bounds)
    for check in groups:
        check()
        print(check.__name__ + ': PASS')
    print(json.dumps(dict(groups=len(groups), source_only=True, native_executed=False, c6b_c6c_complete=False)))


if __name__ == '__main__':
    if sys.argv[1:] == ['--check']:
        run()
