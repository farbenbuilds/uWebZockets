#!/bin/bash
set -eu
export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native
base=/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/combined-native
run_dir="$base/evidence/native-transport/$1"
shift
mkdir "$run_dir"
printf '%s\0' "$@" > "$run_dir/argv.nul"
printf '%s\0' "PYTHONDONTWRITEBYTECODE=$PYTHONDONTWRITEBYTECODE" "PYTHONHASHSEED=$PYTHONHASHSEED" "PYTHONPATH=$PYTHONPATH" > "$run_dir/environment.nul"
cp "$base/evidence/native-transport/control/"* "$run_dir/"
mkdir "$run_dir/source"
cp "$base/"*.py "$run_dir/source/"
for item in contract:/tmp/uwz-task5e1-contract-v3 canonical:/tmp/uwz-task5e3a-snapshot-v9/source codecs:/tmp/uwz-h2-client-tooling/packages client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client cases:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases; do
  label=${item%%:*}
  source_dir=${item#*:}
  mkdir "$run_dir/source/$label"
  (cd "$source_dir" && find . -type f -name '*.py' -not -path '*/evidence/*' -exec cp --parents '{}' "$run_dir/source/$label/" \;)
done
if [[ "$*" == *graphify_runner.py* ]]; then
  mkdir "$run_dir/source/graphify-tool"
  (cd /workspaces/uWebZockets/.uwz-work/tools/graphify && find . -type f \( -name "*.py" -o -name "*.so" -o -name METADATA \) -exec cp --parents "{}" "$run_dir/source/graphify-tool/" \;)
fi
cp /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py "$run_dir/source/restore_inputs.py"
find "$run_dir/source" -type f -print0 | sort -z | xargs -0 sha256sum > "$run_dir/source.sha256"
sha256sum /home/codespace/.python/current/bin/python3 > "$run_dir/interpreter.sha256"
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore "$run_dir/restore.json" > "$run_dir/restore.stdout" 2> "$run_dir/restore.stderr"
set +e
"$@" > "$run_dir/stdout" 2> "$run_dir/stderr"
status=$?
set -e
printf '%s\n' "$status" > "$run_dir/status"
cat "$run_dir/stdout" "$run_dir/stderr"
printf 'Exit status: %s\n' "$status"
exit "$status"
