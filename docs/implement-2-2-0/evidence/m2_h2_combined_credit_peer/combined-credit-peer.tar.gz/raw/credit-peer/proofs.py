"""Opt-in independent serialized credit/trailer proofs."""
import copy
import catalogue
import hashlib
import hpack
import credit_cases
import wire
from pathlib import Path
import sys
import adapter
import model
import test_credit as peer
from test_core_peer import frame, new_app, require


def constructor():
    app = new_app()
    before = copy.deepcopy(app)

    def no_clock():
        raise RuntimeError('constructor called clock')

    result = peer.new_peer('queued_trailers_padding', app=app, prior=(), now=1, clock=no_clock, final=True)
    require(set(result) == {'connection', 'state'}, 'peer shape differs')
    require(set(result['connection']) == {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'}, 'connection shape differs')
    require(app == before, 'constructor changed app')
    print('constructor inert; canonical app; startup queued')


def metadata_only(driver):
    original = adapter.start
    app = new_app()
    seen = [0]

    def start(context, method, path, *args, **kwargs):
        result = original(context, method, path, *args, **kwargs)
        if method == 'POST':
            seen[0] += 1
            item = app['records']['queued_trailers_padding']
            require(item['bytes'] == item['chunks'] == item['ends'] == 0 and item['sha256'] == model.EMPTY_HASH,
                    'HEADERS manufactured accepted DATA facts')
        return result

    adapter.start = start
    try:
        driver('queued_trailers_padding', app)
    finally:
        adapter.start = original
    require(seen == [1], 'missing metadata probe')
    print('metadata earns no accepted DATA facts')


def baseline_timing():
    path = Path(__file__).resolve().parent / 'baseline/test_credit.py.txt'
    namespace = dict(__name__='frozen_baseline')
    exec(compile(path.read_text(), str(path), 'exec'), namespace)
    metadata_only(namespace['check'])



def rejects(action, message=None):
    try:
        action()
    except ValueError as exc:
        require(message is None or str(exc) == message, 'unexpected rejection: ' + str(exc))
        return
    raise ValueError('invalid action accepted')


def open_peer(case, final=False, *, app=None, prior=(), health=True):
    app = new_app() if app is None else app
    result = peer.new_peer(case, app=app, prior=prior, now=1, clock=lambda: 2, final=final)
    connection = result['connection']
    context = adapter.open_case(case, connection['protocol'], connection['send'], 1, 30001, 900001,
                                selected_before=prior, clock=lambda: 2)
    adapter.observe(context, *connection['receive']())
    if health:
        adapter.health(context, connection['receive'])
    return app, result, context



def header_block(entries):
    # Malformed independent requests must not desynchronize the real client's table.
    return hpack.Encoder().encode(tuple((name, value, True) for name, value in entries))

def send_wire(result, packet):
    for offset in range(0, len(packet), 8192):
        result['connection']['send'](packet[offset:offset + 8192])


def summary(state):
    fields = ('frames', 'logical', 'flow', 'padding', 'accepted', 'ends', 'trailers', 'cursor', 'heads', 'resumed', 'terminal')
    return tuple(state[field] for field in fields) + (state['hash'].hexdigest(), state['accepted_hash'].hexdigest())


def unchanged_refusal(app, result, packet, message):
    before, counts = copy.deepcopy(app), summary(result['state'])
    for _ in range(2):
        rejects(lambda: send_wire(result, packet), message)
        require(app == before and summary(result['state']) == counts, 'invalid frame earned application/wire facts')


def constructor_rejections():
    changes = ({'case': 'ready_buffered'}, {'case': []}, {'prior': ('receive_credit',)}, {'prior': ('unknown',)},
               {'prior': ('receive_credit', 'receive_credit')}, {'final': 1}, {'fault': 'unknown'}, {'fault': []},
               {'fault': 'missing_stream_credit'}, {'now': True}, {'now': -1}, {'clock': None})
    for changed in changes:
        app = new_app()
        before = copy.deepcopy(app)
        args = dict(case='queued_trailers_padding', app=app, prior=(), now=1, clock=lambda: 2)
        args.update(changed)
        rejects(lambda: peer.new_peer(**args))
        require(app == before, 'invalid constructor changed app')
    for field in ('records', 'heads', 'outputs', 'binding'):
        app = new_app()
        del app[field]
        before = copy.deepcopy(app)
        rejects(lambda: peer.new_peer('receive_credit', app=app, prior=(), now=1, clock=lambda: 2), 'app fields differ')
        require(app == before, 'shape refusal mutated application')
    app = new_app()
    app['heads'] = 3
    rejects(lambda: peer.new_peer('receive_credit', app=app, prior=(), now=1, clock=lambda: 2), 'prior heads not earned')
    print('constructor rejects malformed prior/case/fault/clock/app before effects')


def header_refusals():
    app, result, context = open_peer('queued_trailers_padding', final=True)
    path = model.request_contract('queued_trailers_padding')['target']
    _upload, entries = peer.header_contract(result['state'], path)
    variants = (entries[::-1], entries + [('content-length', '12289')],
                entries[:-2] + [('x-metadata', 'trailer-qtp'), ('x-initial-only', 'initial-only')],
                entries + [('x-trailer-only', 'discarded')], entries[:-1])
    for changed in variants:
        unchanged_refusal(app, result, frame(1, 4, 3, header_block(changed)), 'request contract differs')
    unchanged_refusal(app, result, frame(1, 5, 3, header_block(entries)), 'request contract differs')
    unchanged_refusal(app, result, frame(1, 4, 5, header_block(entries)), 'request contract differs')
    final = [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', '/status/' + model.BODY_SPECS[0][0])]
    unchanged_refusal(app, result, frame(1, 5, 3, header_block(final)), 'request contract differs')
    stream = credit_cases.start(context, 'queued_trailers_padding')
    require(stream == 3 and app['records']['queued_trailers_padding']['metadata_begin'] == 1, 'valid initial metadata not earned')
    print('pseudo order/multiplicity/initial metadata/trailer-only/stream/flags and premature final rejected before facts')


def queued_transitions():
    case = 'queued_trailers_padding'
    app, result, context = open_peer(case)
    state, receive = result['state'], result['connection']['receive']
    stream = credit_cases.start(context, case)
    item = app['records'][case]
    require(item['bytes'] == item['chunks'] == item['ends'] == 0 and not item['paused'], 'initial metadata accepts bytes')
    trailer = frame(1, 5, stream, header_block((('x-metadata', 'trailer-qtp'), ('x-trailer-only', 'discarded'))))
    unchanged_refusal(app, result, trailer, 'trailer ordinal differs')
    first = model.payload_span(12289, 0, 8192)
    unchanged_refusal(app, result, frame(0, 1, stream, first), 'DATA ordinal differs')
    unchanged_refusal(app, result, frame(0, 0, 5, first), 'DATA stream differs')
    unchanged_refusal(app, result, frame(0, 0, stream, b'x' + first[1:]), 'request body differs')
    adapter.send_data(context, stream, first, False)
    require(item['bytes'] == 7 and item['sha256'] == hashlib.sha256(first[:7]).hexdigest() and
            item['chunks'] == 1 and item['max_span'] == 7 and item['paused'], 'first DATA prefix differs')
    checkpoint = dict(item)
    second = model.payload_span(12289, 8192, 4097)
    padded = bytes((7,)) + second + bytes(7)
    unchanged_refusal(app, result, frame(0, 8, stream, padded), 'DATA delivery barrier differs')
    credit_cases.barrier(context, receive, stream, case)
    for bad in (bytes((6,)) + padded[1:], padded[:-1] + b'x'):
        unchanged_refusal(app, result, frame(0, 8, stream, bad), 'padding differs')
    adapter.send_data(context, stream, second, False, padding=7)
    require(item == checkpoint and (state['logical'], state['flow'], state['padding']) == (12289, 12297, 8), 'buffered DATA changed accepted checkpoint')
    bad = frame(1, 5, stream, header_block((('x-trailer-only', 'discarded'), ('x-metadata', 'trailer-qtp'))))
    unchanged_refusal(app, result, bad, 'trailer metadata differs')
    for packet in wire.send_trailers(context['stage'], stream, [('x-metadata', 'trailer-qtp'), ('x-trailer-only', 'discarded')]):
        result['connection']['send'](packet)
    require(item == checkpoint and state['ends'] == state['trailers'] == 1 and app['heads'] == 3, 'trailers changed metadata/app heads')
    unchanged_refusal(app, result, trailer, 'trailer ordinal differs')
    credit_cases.barrier(context, receive, stream, case)
    require(item == checkpoint, 'second paused status changed checkpoint')
    credit_cases.resume(context, receive, stream, case)
    adapter.finish(context, stream, receive)
    adapter.health(context, receive)
    require(item['bytes'] == 12289 and item['ends'] == item['metadata_end'] == 1 and not item['active'] and
            item['sha256'] == state['hash'].hexdigest() and state['accepted'] == 12289, 'actual resume completion differs')
    print('queued trailer: metadata0 -> DATA7 -> paused7 through 12289logical/12297flow -> resume complete; trailers discarded')


def credit_transitions():
    case = 'receive_credit'
    app, result, context = open_peer(case)
    state, receive = result['state'], result['connection']['receive']
    stream = credit_cases.start(context, case)
    item = app['records'][case]
    for offset in range(0, 65535, 8192):
        adapter.send_data(context, stream, model.payload_span(65536, offset, min(8192, 65535 - offset)), False)
    require(item['bytes'] == item['chunks'] == item['ends'] == 0 and item['sha256'] == model.EMPTY_HASH and item['paused'], 'paused receive credit accepted body')
    require(state['logical'] == state['flow'] == 65535 and state['frames'] == 8, 'wire exhaustion differs')
    adapter.health(context, receive)
    credit_cases.barrier(context, receive, stream, case)
    credit_cases.resume(context, receive, stream, case)
    require(item['bytes'] == 65535 and item['chunks'] == 8 and item['ends'] == 0 and not item['paused'], 'resume prefix differs')
    require(state['connection_queued'] == state['stream_queued'] == 65535 and
            state['connection_delivered'] == state['stream_delivered'] == 0, 'queued grant treated delivered')
    status = adapter.start(context, 'GET', '/status/' + case, (), True, False, 4095)
    last = frame(0, 1, stream, model.payload_span(65536, 65535, 1))
    unchanged_refusal(app, result, last, 'DATA before delivered connection and stream credit')
    packet, stamp = receive()
    require(packet == frame(8, 0, 0, (65535).to_bytes(4, 'big')) and state['connection_delivered'] == 65535 and
            state['stream_delivered'] == 0, 'connection grant delivery differs')
    adapter.observe(context, packet, stamp)
    unchanged_refusal(app, result, last, 'DATA before delivered connection and stream credit')
    packet, stamp = receive()
    require(packet == frame(8, 0, stream, (65535).to_bytes(4, 'big')), 'stream grant not separately delivered')
    adapter.observe(context, packet, stamp)
    unchanged_refusal(app, result, last, 'DATA before delivered connection and stream credit')
    adapter.finish(context, status, receive)
    adapter.send_data(context, stream, last[9:], True)
    adapter.finish(context, stream, receive)
    adapter.health(context, receive)
    require(state['logical'] == state['flow'] == state['accepted'] == item['bytes'] == 65536 and
            state['frames'] == item['chunks'] == 9 and item['ends'] == 1 and
            item['sha256'] == model.accepted_hash(65536), 'last byte END completion differs')
    print('receive credit: zero accepted paused; actual resume accepts65535; separate delivered connection+stream grants and status precede final1END')


def bounds():
    app, result, _context = open_peer('receive_credit')
    state, send = result['state'], result['connection']['send']
    for _ in range(2):
        rejects(lambda: send(b'x' * 8193), 'send span differs')
        rejects(lambda: send((8193).to_bytes(3, 'big') + bytes(6)), 'frame payload bound differs')
        require(not state['buffer'], 'oversize grew parser')
    packet = frame(0, 0, 3, b'x' * 8192)
    send(packet[:8192])
    send(packet[8192:8200])
    before = bytes(state['buffer'])
    for _ in range(2):
        rejects(lambda: send(b'xx'), 'parser storage bound differs')
        require(bytes(state['buffer']) == before and state['max_buffer'] == 8200, 'parser overflow mutated')
    _app, result, _context = open_peer('receive_credit')
    state = result['state']
    state['pending'][:] = [b'a' * 8192, b'b' * 8192]
    for _ in range(2):
        rejects(lambda: peer.queue(state, (b'c',)), 'pending storage bound differs')
        require(sum(map(len, state['pending'])) == 16384, 'pending byte overflow')
    state['pending'][:] = [b'a'] * 4
    rejects(lambda: peer.queue(state, (b'c',)), 'pending storage bound differs')
    state['pending'][:] = [b'a' * 8193]
    rejects(result['connection']['receive'], 'pending packet bound differs')
    state['pending'][:] = [b'a']
    state['received'] = state['head_limit'] + 3
    rejects(result['connection']['receive'], 'receive bound differs')
    state['received'] = 0
    state['received_bytes'] = (state['head_limit'] + 3) * 8192
    rejects(result['connection']['receive'], 'receive byte bound differs')
    require(state['pending'] == [b'a'], 'receive cap consumed bytes')
    print('finite parser8201/send8192/frame8192/pending4/16384/receive caps reject before growth')


def wrapper_integrity():
    original, calls, sentinel = adapter.start, [0], object()
    error = RuntimeError('original error wins')

    def returning(*_args, **_kwargs):
        calls[0] += 1
        return sentinel

    def failing(*_args, **_kwargs):
        calls[0] += 1
        raise error

    def driver(_case, _app):
        require(adapter.start(None, 'POST', 'upload') is sentinel, 'original result identity lost')

    try:
        adapter.start = returning
        metadata_only(driver)
        require(adapter.start is returning and calls == [1], 'success wrapper restore/calls differ')
        adapter.start = failing
        try:
            metadata_only(driver)
        except RuntimeError as exc:
            require(exc is error, 'original error identity/priority lost')
        else:
            raise ValueError('original error swallowed')
        require(adapter.start is failing and calls == [2], 'failure wrapper restore/calls differ')
    finally:
        adapter.start = original
    print('proof wrapper original once; result/error identity and priority; restored success/failure')


def final_boundary(peer, context):
    state, stage = peer['state'], context['stage']
    identities = {name: context[name] for name in ('protocol', 'raw', 'request', 'credit', 'records', 'stage')}
    deadlines = stage['case_deadline'], stage['whole_deadline']
    reads, size = stage['reads'], stage['bytes']
    debt = context['request']['connection_debt'], context['request']['stream_debt_total']
    seen = [0, 0]

    def receive():
        result = peer['connection']['receive']()
        require(all(context[name] is value for name, value in identities.items()), 'final changed connection identities')
        require((stage['case_deadline'], stage['whole_deadline']) == deadlines, 'final refreshed deadlines')
        require(stage['reads'] == reads + seen[0] and stage['bytes'] == size + seen[1], 'final reset cumulative receive cap')
        seen[0] += 1
        seen[1] += len(result[0])
        return result

    require(adapter.final_collection(context, receive) is None, 'ordinary final return changed')
    require(state['final_requests'] == stage['final_registered'] == 68 and stage['final_complete'], 'final count differs')
    require((context['request']['connection_debt'], context['request']['stream_debt_total']) == debt, 'final erased debt')
    require(stage['reads'] == reads + seen[0] and stage['bytes'] == size + seen[1], 'final receive accounting')
    require('final_observations' in context, 'missing retained actual final capture')


def retained_supplied_fixture():
    # Explicit historical supplied facts; this does not execute producer_reuse.
    app = new_app()
    app['records'] = model.records(('producer_reuse',), 'before')
    for tag in ('producer_reuse', 'producer_reuse_next'):
        app['records'][tag].update(chunks=1, max_span=32)
    producer = app['outputs']['producer_reuse']
    producer.update(offset=16777313, invocations=2051, attempts=4099, writes=2049, blocked=2050,
                    pending=2050, terminal_attempts=1, terminals=1, checks=2051, after_reuse=1,
                    binding_index=0, binding_generation=7, armed=True, done=True, sha256=model.PRODUCER_HASH)
    app['binding'] = dict(tag='producer_reuse_next', binding_index=0, binding_generation=8)
    app['heads'] = catalogue.case_budget('producer_reuse')['heads']
    copied = copy.deepcopy(app)
    outputs, binding = copied['outputs'], copied['binding']
    supplied, peer, context = open_peer('queued_trailers_padding', app=copied, prior=('producer_reuse',), final=True, health=False)
    adapter.run_case(context, peer['connection']['receive'])
    final_boundary(peer, context)
    require(supplied is copied and copied['outputs'] is outputs and copied['binding'] is binding, 'retained references replaced')
    require(outputs == app['outputs'] and binding == app['binding'], 'supplied retained output or binding mutated')
    require(app['records']['queued_trailers_padding']['middleware'] == 0, 'copied application mutated original')
    print('explicit supplied historical producer fixture: copied retained outputs/binding preserved; no prior producer traffic claim')



def hpack_limits():
    for payload in (header_block(((':path', 'a' * 4097),)), b'\x3f\xe2\x1f'):
        app, result, _context = open_peer('queued_trailers_padding', health=False)
        before = copy.deepcopy(app)
        for _ in range(2):
            try:
                result['connection']['send'](frame(1, 5, 1, payload))
            except hpack.HPACKError:
                require(app == before and result['state']['cursor'] == 0, 'HPACK earned facts')
                continue
            raise ValueError('HPACK overflow accepted')
    print('HPACK table/header-list bounds reject before facts twice')



def actual_chain():
    app, result, context = open_peer('queued_trailers_padding', health=False)
    adapter.run_case(context, result['connection']['receive'])
    model.validate_records(('queued_trailers_padding',), 'before', app['records'])
    original = app
    app, result, context = open_peer('receive_credit', final=True, app=app, prior=('queued_trailers_padding',), health=False)
    adapter.run_case(context, result['connection']['receive'])
    final_boundary(result, context)
    require(app is original and app['heads'] == 81, 'actual shared chain differs')
    model.validate_records(('queued_trailers_padding', 'receive_credit'), 'before', app['records'])
    print('actual serialized two-case prior and final68: same app/connection/parser/ledgers/debt/caps/deadlines; heads81')



def connection_only_refusal():
    case, app = 'receive_credit', new_app()
    result = peer.new_peer(case, app=app, prior=(), now=1, clock=lambda: 2, fault='missing_stream_credit')
    connection, state = result['connection'], result['state']
    context = adapter.open_case(case, connection['protocol'], connection['send'], 1, 30001, 900001, clock=lambda: 2)
    adapter.observe(context, *connection['receive']())
    adapter.health(context, connection['receive'])
    stream = credit_cases.start(context, case)
    for offset in range(0, 65535, 8192):
        adapter.send_data(context, stream, model.payload_span(65536, offset, min(8192, 65535 - offset)), False)
    adapter.health(context, connection['receive'])
    credit_cases.barrier(context, connection['receive'], stream, case)
    credit_cases.resume(context, connection['receive'], stream, case)
    adapter.get(context, '/status/' + case, connection['receive'])
    require(state['statuses_delivered'] == 2 and state['connection_delivered'] == 65535 and
            state['stream_delivered'] == 0 and not state['pending'], 'connection-only setup differs')
    unchanged_refusal(app, result, frame(0, 1, stream, model.payload_span(65536, 65535, 1)),
                      'DATA before delivered connection and stream credit')
    print('connection-only credit with delivered postresume status rejects final byte; missing stream is independently necessary')


def receive_error_identity():
    error = RuntimeError('clock failed')
    app = new_app()
    calls = [0]

    def clock():
        calls[0] += 1
        raise error

    result = peer.new_peer('receive_credit', app=app, prior=(), now=1, clock=clock)
    connection, state = result['connection'], result['state']
    adapter.open_case('receive_credit', connection['protocol'], connection['send'], 1, 30001, 900001, clock=lambda: 2)
    pending = tuple(state['pending'])
    for _ in range(2):
        try:
            connection['receive']()
        except RuntimeError as exc:
            require(exc is error, 'clock error identity lost')
        else:
            raise ValueError('clock error swallowed')
        require(tuple(state['pending']) == pending and state['received'] == state['received_bytes'] == 0,
                'clock failure consumed pending input')
    require(calls == [2], 'clock called more than once per receive')
    print('clock failure preserves exception identity and queued bytes/receipts; constructor never samples clock')

def all_proofs():
    constructor()
    constructor_rejections()
    metadata_only(peer.check)
    wrapper_integrity()
    header_refusals()
    queued_transitions()
    credit_transitions()
    connection_only_refusal()
    receive_error_identity()
    bounds()
    hpack_limits()
    actual_chain()
    retained_supplied_fixture()


def main():
    modes = {'--constructor': constructor, '--baseline-timing': baseline_timing,
             '--timing': lambda: metadata_only(peer.check), '--all': all_proofs}
    if len(sys.argv) == 2 and sys.argv[1] in modes:
        modes[sys.argv[1]]()


if __name__ == '__main__':
    main()
