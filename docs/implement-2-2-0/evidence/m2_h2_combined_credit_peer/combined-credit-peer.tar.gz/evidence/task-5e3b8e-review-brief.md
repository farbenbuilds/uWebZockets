# Independent credit/trailer peer review

Read the requirements first: task-5e3b8e-brief.md in this directory. The BASE
is 63f23af69fdfc39ef21f62539691c97b4ae45def. The implementation is an ignored
working source candidate; Root will publish only after this review. Read the
full task-5e3b8e-report.md and task-5e3b8e-review-source.diff. The latter is the
complete single-file source diff plus current evidence helpers/proofs. Do not
run Git to regenerate it. Read tests first, then implementation, using context
in the diff. Reopen a changed source only if an essential hunk is cut off, and
name that reason. Name a concrete risk before inspecting an unchanged source;
one focused check per named risk. Do not crawl unrelated source.

Read AGENTS.md, CODING_CONVENTION.md, the reviewer role, and
.agents/skills/code-review-and-quality/SKILL.md. Root explicitly requests the
structural lens in .agents/skills/thermo-nuclear-code-quality-review/SKILL.md
with AGENTS overrides: 1000 lines is a review signal, not a mechanical split;
no emojis. Assess correctness/security, compatibility/evidence, bounds,
causally earned facts, ownership, and maintainability. Do not turn preferences
into defects. Read-only review: do not edit source/index/Git or spawn agents.

The exact constructor/application/connection/driver contract, DATA ordinals,
final barrier, fault diagnostics, current helper nesting and evidence capture
requirements are in the implementation brief. Treat the report as claims and
verify against the diff and retained receipts. Fresh Root audit is retained in
task-5e3b8e-root-final-audit.json. Current four focused checks have complete
receipts; do not rerun passing suites on unchanged source. A new focused test
requires a specific doubt unanswered by those runs. Every dependent command
must restore the pinned source inputs first in the same shell as the operation,
using the exact Root restorer/Python/PYTHONPATH and a NEW receipt specified in
the task brief. No native/build/network/server/clock/process/old-runtime runs.

Before a NEW codebase question/search/read, use the Graphify command in the
task brief. Provided paths are already located. The graph does not establish
coverage of ignored working-source topology. Historical and supplied synthetic
facts remain qualified; actual all40/native/adoption/full milestone gates
remain mandatory later. This is a scoped standalone peer review.

Return the full review as your terminal message: Spec Compliance verdict;
specific strengths; severity-ordered actionable issues with exact file/line
and failure scenario; cannot-verify items and named outside checks; Task Quality
Approved or Needs fixes. Root saves it as task-5e3b8e-review-report.md. No
independent source edits, broad retests, publication, or acceptance claims.



