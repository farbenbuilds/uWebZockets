# Shared independent credit/trailer peer

Released after reviewed/pushed8d. BASE:
63f23af69fdfc39ef21f62539691c97b4ae45def.
Accepted source40 manifest:
docs/implement-2-2-0/evidence/m2_h2_combined_continue_peer/manifest.json.
Root audit: task-5e3b8d-root-commit-audit.json in this directory.
Implement accepted remaining-peer plan unit5 and shared
contract in task-5e3b-all40-peer-plan-report.md, with aggregate acceptance notes.
Standalone synthetic preparation only; actual all40/native/adoption/M2 later.

Own ONLY
/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_credit.py,
NEW evidence/credit-peer beneath that directory, and
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8e-report.md.
Current inventory40, one changed39unchanged. No other modules/model/core/handler/
fixture/codec/pin/product/limit edit. Report concrete additional ownership/API
gap BEFORE edit. You are not alone; preserve others and all historical bytes.
Root owns independent review/publication/commit+immediate push; no agents/Git/
native/network/external CLI.

Promote new_peer(case, *, app, prior, now, clock, final=False, fault=None) for
queued_trailers_padding and receive_credit. Exact {connection,state}, connection
seven keys protocol/send/receive/now/owned/tls/alpn, initialized pinned protocol,
supplied owned=True/TLSv1.3/h2 facts. Queue startup SETTINGS/ACK normally, no
constructor clock/client dispatch/observe/final/app mutation/selectedcompletion.
Validate case/prior/app/time/clock/final/fault before effects. Exact canonical
app4 records/heads/outputs/binding and test_core_peer.new_app; no competing app
constructor or speculative legacy adapter. Prior validates earned facts only.
Keep check(case, app=None, prior=(), final=False, fault=None), including positional
optional arguments, same app return, prints/hash/frame/trailer assertions and
existing main's actual two-case shared sequence/final68.

Delete the old nested peer, model-selected completion recipes, early checkpoint
seeding and histories. The concrete old HEADERS branch installs a paused record
including accepted7bytes before DATA: replace it with metadata/begin facts only.
DATA alone earns wire logical/flow/hash/frame and actual accepted-prefix/chunk
facts. queued_trailers_padding accepts first7bytes after first8192nonEND DATA,
retains that checkpoint through second DATA and trailers, completes only after
actual resume. Initial metadata and discarded trailers remain distinct; no
trailer-only/overridden initial metadata enters application helpers.

queued_trailers_padding wire ordinals:8192payload flag0, then4105 flow bytes
flag8 consisting of pad length7,4097logical bytes,7zero padding bytes. Logical
total12289, flow12297; validate pad octet/trailingzeros and payload before facts.
Trailing HEADERS on the upload stream has flag5 and exactly x-metadata:
trailer-qtp then x-trailer-only:discarded, after both DATA and before resume.
It is not a new request/head/middleware observation. Preserve both paused
status barriers and exact online health/upload/status/status/resume/health.

receive_credit emits eight nonEND DATA frames totaling65535 logical/flow bytes,
then waits. No accepted bytes until actual resume by canonical policy. Resume
earns accepted65535prefix/chunks8/end0, emits separate connection+stream
WINDOW_UPDATE65535; final1byteEND must wait for actual delivered grants in both
scopes. Connection credit alone never authorizes last byte. Preserve healthy
sibling, paused/status/resume/postresume/health barriers and zero accepted
paused record. Final completion earns65536/chunks9/hash/END. Track logical,
padding/flow, accepted and refunded bytes separately, with no catalogue-derived
observed totals or client-context peer oracle.

Preserve paused_record -> record mismatch: bytes and missing_stream_credit ->
missing synthetic response. Keep missing-stream-credit as its exact serialized
negative, not a constructor refusal or generic new message. Check frozen
baseline Python if diagnostic uncertainty arises. Faults are finite and change
only named observation. Hash payload incrementally; no full-body/request/frame/
read history. Preserve copied persistent output/binding state.

Bound parser8201, frame/send8192, HPACK, finite pending packets/bytes/reads/stream
summaries/cursors before growth, repeated rejection stable. Preserve all parent
ceilings. Validate metadata/pseudo order/multiplicity/stream/flags, DATA ordinal,
delivery barriers, padding/trailers before application/count/hash mutation.
Queued grants/responses differ delivered events. Final permission is inert;
require actual ordinary schedule first and collect final68 on same protocol/
parser/ledgers/debt/receivecaps/deadlines. Metrics derive actual app facts.
Any necessary driver proof wrapper invokes original exactly once, preserves
original result/exception identity and error priority, restores on failure.

Before editing: read actual AGENTS.md, CODING_CONVENTION.md, developer role and
narrow incremental/TDD/API/codebase-design workflows plus accepted context.
Use Graphify before a NEW codebase question/search/read; supplied paths are
located. Freeze the exact accepted current 40 sources and 119-input identity,
and a fresh exhaustive prior-evidence hash map excluding only this new unit.
Freeze before actual acceptance RED; constructor absence is a pre-effect RED,
not a behavioral defect. Each discovered defect needs the real source/RED
before its fix; preserve every failed/intermediate command/source/raw artifact.

After last source edit retain FOUR focused checks: test_credit.py and
test_imports.py, each normal and -O. Other suites only for an identified
dependency or unanswered concern. Add meaningful direct constructor/prior/
metadata-vs-DATA/refusal-order/final/bounds/retention proofs as needed. Actual
shared prior cases must be earned from traffic; supplied fixtures remain
explicitly synthetic. Every check has exact argv/env/cwd, 40-source before and
after maps, separate stdout/stderr/exit and same-shell restoration receipt.
All 40 source AST/import guards, all CURRENT unit helper nesting <=3 and inert
import/empty/foreign argv, 119 authority/118 physical/113 resolved/42 ordered
codecs, frozen source and prior-history preservation must be audited. No live
helper is exempt as historical; preserve old bytes before correcting it. No
classes/assert/custom exceptions/global mutable containers/dead code/camelCase/
silenced errors/forwarding wrappers or weakened bounds, tests or lint.

Temporary inputs reset across continuations. EACH dependent Python proof,
audit or check exec_command shell must start with set -e and run the Root
restorer below, with a NEW absolute receipt, then its operation IN THAT SAME
SHELL. Never infer persistence from a prior Root command.

/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT

Pinned interpreter SHA256:
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
All direct Python, including source edits, uses this interpreter with -B -S;
optional -O for optimized. Exact PYTHONPATH:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases

Graphify invocation:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650

No native/build/server/socket/SSLContext/TLS-close/real-clock/process ownership/
kernel/fault scheduling/race/panic/crash/leak/old-runtime/install/network runs.
Only pinned in-memory codecs and supplied synthetic app/transport/process
facts. No additional named-skill drift is established by the known missing
generic DoD reference: explicit project gates/exact scope remain authoritative,
full native/project/platform gates mandatory later, not waived.

Write the full report at the owned report path: exact files/commands/raw/exits,
RED/GREEN chronology, all current source/check/input/history/helper audits,
self-review and actual gaps. Return concise DONE or specific concerns/context/
blocker under 15 lines. Remaining work alone is not missing context. Root owns
fresh source review, publication accuracy, commit and immediate push before
releasing the next serial peer unit. Full goal remains active.

