# Shared independent credit/trailer peer implementation

DONE for assigned standalone synthetic preparation; ready for Root independent review.
No API or ownership gap remains. No actual all40, native, adoption, or milestone
acceptance is claimed.

## Scope and source identity

Accepted BASE: `63f23af69fdfc39ef21f62539691c97b4ae45def`.
Accepted source40 authority:
`docs/implement-2-2-0/evidence/m2_h2_combined_continue_peer/manifest.json`.
Implemented the shared contract and unit5 in
`task-5e3b-all40-peer-plan-report.md`, as released by `task-5e3b8e-brief.md`.

Changed exactly one source:
`.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_credit.py`.
Its current SHA256 is
`f3667deb7760f613f744a0f0afcf0402d7ba41cae24b6c399d0e7510d3a99f4b`.
The other 39 current modules are byte-identical to the accepted manifest.

Added only the new evidence directory
`.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/credit-peer/`
and this report. Its CURRENT executable helpers are exactly `capture.py`,
`proofs.py`, and `audit.py`; text files preserve source/edit/check snapshots,
including intermediate work, rather than additional executable helpers.
No model, canonical handler, adapter, codec, fixture, product, pin, threshold,
or other peer module was edited. Root retains review, publication, Git,
commit, and immediate-push ownership.

Read actual AGENTS.md, CODING_CONVENTION.md, developer specialist instructions,
accepted plan/brief, and narrow using-agent-skills, incremental implementation,
TDD, interface-design and codebase-design workflows. Recovered truncated
conventions, TDD, API, incremental, and accepted-plan content through narrower
reads. Applied the debugging workflow to the retained proof-setup failure.
The known generic DoD reference qualification remains unchanged; no new skill
or scope drift was established.

## Implemented behavior

`new_peer(case, *, app, prior, now, clock, final=False, fault=None)` supports
both credit cases and returns exactly `connection,state`, with the seven
accepted connection fields. Canonical `test_core_peer.new_app()` supplies the
application; constructor validation covers case/prior/app4/time/clock/final
and finite faults before creating protocol state. Ownership/TLSv1.3/h2 are
supplied synthetic facts. Startup SETTINGS/ACK are queued for ordinary receive;
construction never samples the clock, executes a client schedule, observes
input, mutates application facts, or selects final results.

The old nested peer, accumulated path history, early checkpoint seeding,
and model-selected completion recipes are removed. `check` retains all five
positional-or-keyword parameters, its same-application return, original print
lines, hash/flow/frame/trailer assertions, and original two-case shared main
sequence/final68. The two original negative diagnostics remain exact:
`paused_record` -> `record mismatch: bytes`; `missing_stream_credit` ->
`missing synthetic response`.

Upload HEADERS now earn only validated middleware/attempt/begin/initial-metadata
facts. Queued-trailer DATA ordinal1 earns the seven-byte accepted prefix and
its incremental hash. The second padded DATA earns 4,097 additional wire
logical bytes, 4,105 flow bytes, and eight padding-overhead bytes, without
changing the accepted paused checkpoint. Its pad-length octet is seven and
all seven trailing padding bytes must be zero. Totals are 12,289 logical and
12,297 flow bytes. Exact trailing HEADERS flag5 fields are validated after both
DATA frames and before resume. They do not increment request/middleware heads
or enter initial metadata. The same seven-byte record persists through both
status barriers and the trailers; actual resume earns completion.

Receive-credit DATA earns eight frames and 65,535 logical/flow bytes while the
application accepts zero. Actual resume accepts that prefix/chunks8/end0,
then queues separate connection and stream WINDOW_UPDATE packets of 65,535.
Their delivered-byte receipts remain separate from queued-byte receipts. The
final one-byte END requires both delivered grants and delivered postresume
status. A separate direct negative delivers the postresume status and connection
grant while withholding the stream grant, then proves the final byte still
cannot earn facts. Final completion derives bytes65536/chunks9/hash/END from
actual validated traffic.

The peer uses bounded cursors, one upload summary, incremental wire/accepted
hashes, and no full request/body/frame/read history. Bounds: parser8,201,
send/frame payload8,192, pending at most4 packets and16,384 bytes, each packet
at most8,192, HPACK4,096, and reads at most schedule heads+3 with corresponding
byte cap. Online validation covers path, stream, pseudo/regular header order,
multiplicity, flags, DATA ordinal/payload/padding, trailers, status delivery,
resume, and final permission before application/count/hash mutation.

Final metrics sum actual persistent application records. Actual two-case
traffic earns the prior state and 81 total heads including final68. Final
collection keeps the same protocol/parser/record and credit ledgers, cumulative
receive caps, debt, and deadlines; retained actual final observations are checked.
Copied output/binding preservation is separately tested with an explicitly
supplied historical producer fixture. That fixture is not a claimed producer
execution or actual prior-case chain.

## Fresh freeze and retained provenance

Before any source change or acceptance RED:

- Ran the exact Root restorer in the same shell as the freeze, with new receipt
  `restore-freeze.json`.
- `capture.py --freeze` compared all40 current sources to the accepted manifest,
  copied every source to `baseline/*.py.txt`, and wrote `baseline/source.json`.
- Copied the 119-entry input authority to `baseline/immutable-inputs.json`.
- Wrote fresh exhaustive `baseline/prior_history.json`: 10,800 files under
  prior evidence, excluding only this new unit directory.

Every dependent Python edit/check/audit used the pinned interpreter with
`-B -S` and a fresh same-shell Root-restoration receipt. The interpreter SHA256
is `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`.
All final audit executions verify authority119/physical118/resolved113/ordered
codecs42, with ordered codec digest
`0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`.

## Commands and RED/GREEN chronology

Let `UNIT` denote the absolute new evidence directory above and `ROOT` its
parent's parent (the combined-cases directory). These are notation only; all
retained `command.json` files use exact absolute argv and cwd.
Every captured check shell began with `set -e`, then:

```sh
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore UNIT/restore-NAME.json
```

Each recorder invocation then used:

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S UNIT/capture.py --run NAME MODULE MODE ARGS
```

The recorder's child environment contains exactly those two variables, cwd is
`ROOT`, and argv is pinned interpreter, `-B`, `-S`, optional `-O`, absolute
module path, then listed arguments. Every row below has source40 before/after
maps, current test_credit source, exact check/recorder source snapshots,
AST snapshot, separate stdout/stderr, exit receipt, and restoration binding.
`receipt-index.json` indexes all15 checks and hashes their artifacts.

| NAME | MODULE relative to ROOT | MODE / ARGS | Exit and result |
| --- | --- | --- | --- |
| red-constructor | evidence/credit-peer/proofs.py | normal --constructor | 1: missing new_peer; pre-effect API RED, not behavioral defect |
| red-baseline-timing | evidence/credit-peer/proofs.py | normal --baseline-timing | 1: real frozen baseline HEADERS manufactured accepted DATA facts |
| green-constructor | evidence/credit-peer/proofs.py | normal --constructor | 0: constructor shape/app/clock boundary |
| green-schedules | test_credit.py | normal | 0: original chain/final and both exact negatives |
| green-direct-primary | evidence/credit-peer/proofs.py | normal --all | 1: direct malformed HEADERS perturbed HPACK dynamic table; proof setup error |
| green-direct-hpack | evidence/credit-peer/proofs.py | normal --all | 0: malformed probes now never-indexed; valid traffic still checked |
| green-direct-extra | evidence/credit-peer/proofs.py | normal --all | 0: added independent connection-only grant and clock-error proofs |
| cover-credit-normal | test_credit.py | normal | 0 |
| cover-credit-optimized | test_credit.py | optimized | 0 |
| cover-imports-normal | test_imports.py | normal | 0 |
| cover-imports-optimized | test_imports.py | optimized | 0 |
| final-direct-normal | evidence/credit-peer/proofs.py | normal --all | 0 |
| final-direct-optimized | evidence/credit-peer/proofs.py | optimized --all | 0 |
| strict-direct-normal | evidence/credit-peer/audit.py | normal --audit UNIT/audit-normal | 0 |
| strict-direct-optimized | evidence/credit-peer/audit.py | optimized --audit UNIT/audit-optimized | 0 |

The constructor edit/check shared the actual `restore-edit-constructor.json`
receipt. Initially the recorder inferred `restore-green-constructor.json`.
This bookkeeping path was corrected transparently: `green-constructor/command.json`
now names the actual receipt; the original JSON bytes remain in
`command-as-recorded.json`, and `restoration-correction.txt` explains it.
No original raw/check/source bytes were overwritten. All final check/audit
restoration filenames already matched their actual same-shell executions.

Source/proof edits additionally used fresh receipts named
`restore-green-schedules.json`, `restore-green-direct-primary.json`,
`restore-green-direct-hpack.json`, and `restore-green-direct-extra.json` before
those checks in the same shells. Evidence-index bookkeeping used
`restore-evidence-index.json`. No current helper edits followed the final
normal/optimized direct checks and strict audits.

The HPACK setup failure was localized to injected test headers encoded using an
independent indexing encoder. That altered the peer decoder table while the
real client retained its own table. The proof now marks injected headers
never-indexed, preserving the malformed metadata checks and continued actual
client traffic. The failed source/check/raw snapshot remains intact.

Graphify query ran before new related exploration, exit0, with the supplied
environment and query `test_credit test_continue_quota credit peer evidence
recorder audit`, budget650. It returned a truncated, broad graph; named supplied
and query-located paths were read directly for exact details. A read-only `rg`
lookup also reported one nonexistent candidate temporary model path (exit2);
the actual model path from the other match was then read. No execution depended
on that missing path.

After source modification, ran the supplied graphify executable with
`env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify`
and arguments `update .`, exit0. Raw stdout/stderr are retained in this unit.
Graphify reported no relevant changes and left graphify-out untouched; it does
not establish coverage of ignored preparation sources.

## Direct proof and strict-audit evidence

`final-direct-{normal,optimized}/stdout.txt` records:

- Constructor shape, unchanged application, and no constructor clock read;
  malformed case/prior/fault/clock/app/head-count refusal before application effects.
- Baseline timing regression now green; middleware/begin versus actual DATA prefix.
- Exact header/pseudo order/multiplicity, initial-vs-trailer metadata, stream/flags,
  premature final, early/wrong trailers, ordinal/stream/payload/padding refusals.
  Invalid frames are repeated and app/wire/hash receipts remain unchanged.
- Both paused trailer barriers, seven accepted bytes preserved, exact logical/flow
  accounting, discarded trailer fields, and completion only after actual resume.
- Eight paused receive-credit frames with zero accepted bytes; actual accepted
  prefix at resume; separately delivered grants; connection-only refusal after
  delivered postresume status; final byte END/hash completion.
- Repeated bounded parser/send/frame/queue growth refusals and finite receive caps;
  HPACK list/table overflows rejected twice before app facts.
- Clock failure preserves original exception identity and pending input/receipts.
- Driver proof instrumentation calls original exactly once and preserves original
  result/exception identity and error priority, restoring on success and failure.
- Actual shared prior/final68 chain and separately qualified copied retained fixture.

Both `strict-direct-*` directories retain full command capture in addition to
`audit-normal/` and `audit-optimized/` generated audit maps. Each audit proves:

- All40 source AST/main guards; no classes/asserts/global mutable containers and
  accepted maximum control nesting3; matching normal/optimized inert-import checks.
- All3 CURRENT unit helpers scanned, each guarded and inert under import and main
  with empty/foreign argv. Both accepted and strict depth counters are retained;
  maximum3 under each. No live helper is excluded as historical.
- Exact one-changed/39-unchanged source inventory; fresh current diff and maps.
- Every one of 10,800 prior-history hashes and the exhaustive file map unchanged.
- All119 authority entries,118 physical rows,113 resolved files,42 ordered codecs,
  and the pinned interpreter match the retained authority.
- Four final covering checks plus two final direct checks bind to the current40
  source map, exit0, empty stderr, exact optimization flags and restored identities.

## Self-review and remaining gates

Reviewed the entire generated current diff after final verification. The public
constructor is the shared serialized seam; standalone check retains compatibility.
Validation precedes earned metadata/DATA/control facts. Wire logical, flow and
padding totals remain distinct from accepted application bytes and delivered
connection/stream refunds. Exact online cursors replace histories. Final permission
is inert until ordinary traffic has completed. No peer reads client context as an
oracle; proof wrappers alone inspect client ledgers/deadlines/caps after original
operations. No selected model completion recipe or legacy app adapter remains.
Bounded packet parsing, supplied-clock error handling, persistent output/binding
references, finite faults, exact original diagnostic strings, and final provenance
were checked. No gate, test, lint, or assertion was weakened.

No unresolved implementation defect or scope/API blocker is known. This remains
an in-memory peer/application preparation with supplied ownership/TLS facts.
Independent Root source/spec/quality review is required before publication.
Actual default/all40 execution, remaining peer extraction, broader combined
review, runtime closure, strict close/owned-process work, sequential native
acceptance, production adoption, and all parent milestones remain mandatory.
The project formatting/convention/release-version/Zig-test, sanitizer, compile,
fuzz, library/package-consumer, protocol/platform/compliance gates were NOT run
in this source-only slice and are NOT waived. No native/build/server/socket/TLS
context/real-clock/old-runtime/network/install/Git/publication/agent/external
model CLI execution occurred.

Exact audit-execution receipt paths (the `strict-direct` names are historical
labels for actual `audit.py` invocations, not `proofs.py`):

- `/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/credit-peer/strict-direct-normal/command.json`
- `/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/credit-peer/strict-direct-optimized/command.json`

Their argv respectively invoke pinned `-B -S audit.py --audit .../audit-normal`
and `-B -S -O audit.py --audit .../audit-optimized`. Sibling `check-source.txt`
contains the executed audit source; `capture-source.txt`, source-before/after
maps, raw stdout/stderr, `exit.json`, and the command's exact restoration path
complete each audit execution receipt.
