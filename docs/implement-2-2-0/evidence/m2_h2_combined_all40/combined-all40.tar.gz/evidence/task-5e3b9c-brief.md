# Complete source binding and actual default/all40 proof

Read this first: requirements for the next serial source-only binding slice.
BASE9e6a300341ef72056f7689a0fee108a1786c2095, feat/implement-2-2-0.
Prior9b source/publication approved and immediately pushed; exact post-push
audit task-5e3b9b-root-commit-audit.json. Published baseline45 authority:
docs/implement-2-2-0/evidence/m2_h2_combined_binding/manifest.json.
Read task-5e3b9b-binding-plan-report.md and task-5e3b-oracle-interface-report.md
for exact existing seams/all-family ordinals. Completed mechanism, peer and
first-binding reviews are not work to restart.

Own exactly existing test_all40_descriptors.py and test_all40.py under
/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases,
NEW evidence/all40-binding-b, and full report
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b9c-report.md.
Current45 remains45: two changed,43 unchanged, no import-inventory addition.
No accepted peer/oracle/coordinator/adapter/model/client/core/fixture/handler/
product/pin/capacity edits. If actual traffic exposes an accepted-component
contract defect, freeze a real focused RED and report exact evidence to Root;
do not silently alter descriptors/observations to hide it or expand ownership.
Other independent descriptor work may continue while Root resolves a gap.
You are not alone; preserve others and historical bytes. No agents/Git/
publication/native/network/external CLI. Root owns independent review, publication,
commit and immediate push before any next source unit.

Extend the existing private descriptor/provider binding from12 to all40 canonical
IDs, adding pause, admission, Continue/quota, credit/trailers, metadata/concurrency,
terminal failures/cancellation/reset and lifecycle reuse. Existing core/producer/
file/disconnect/shutdown paths and negatives remain. Reuse stable pure peer
schedule/paths/order and model payload expectations, not mutable handlers with
pretend state or model-selected totals as observations. No family check/driver
calls or new dispatcher; canonical coordinator.run plus existing adapter handlers
remain the sole execution path, all existing factory peers wrapped once.

The accepted observer schema is fixed. Distinguish transmitted versus accepted
bytes, logical versus padded flow, request END mode, initialheaders/trailers,
small versusoutput even17bytes, info100, refusalEND+reset0, incomingreset8/2
versus outgoingpeer_reset8, and authorized open transport windows. In particular
sink/progress sends7prefix plus restarted8prefix, not contiguous15 oraccepted7;
queued-trailer upload12289logical/12297flow; Continue earns actual100 beforeDATA;
refusal/header-only cases cannot invent unsent body bytes. Final tags are exact
67BODY_SPECS order plusmetrics on actuallastconnection; disconnect1 neverfinal.

Maintain existing provider interface and bounded explicit state. No classes,
customexceptions/asserts/filemutablecontainers, generic framework, forwarding
wrappers or extraGETs. No retained client contexts or payload/frame/read histories.
At most2 children/41 observer states, active8/retained802 per observer contract;
retain debt and latecredit rather than inventing closure/zero. Preserve canonical
protocol/parser/ledger identities, clocks, deadlines, read caps, credit and final
handoff. The one-shot finish boundary still consumes failed comparisons.
Expectations/canonical counts remain comparison operands only; sealed actual
wire receipts supply observed counters/hashes/connection identities.

Actual retained client output/binding/final observations must survive every
case transition and disconnect replacement into final pre-signal capture. Use
existing canonical captures and detached app facts earned from traffic, never
regenerated model.records(selection,...) or wire-equivalent substituted values.
Connection receipts once; cumulative lifecycle case evidence once. Signal and
post snapshots have their existing timing, successful-return contract and
synthetic-fact qualification. Native ownership is not inferred.

Mandatory ACTUAL positive execution:

1. Explicit all40 selection through canonical coordinator, idle fresh child
   first and39 main cases in caller order, including actual100000000-byte
   declared/undeclared uploads and all three producer/pressure output cases.
2. Actual omitted-selection/default invocation of coordinator.run, without a
   supplied selection argument. Passing None or an explicit all40 tuple is not
   the omitted-argument proof. Existing explicit wrapper may remain explicit;
   use the smallest direct default call/binding path. Instrument only to prove
   actual call semantics/order, preserving original once/results/errors.
3. Representative remaining-family compositions (not family check substitutes),
   including Continue/quota, padded/credit, metadata/terminal/reuse transitions.
   Choose a few meaningful cross-family chains rather than every permutation.
4. Subsets/reordering/no-active-shutdown/final-large-debt: actual chains ending
   large_declared and large_undeclared, preserving late/split grants and both
   exact large hashes. Existing empty/badselection/identity/retainedcorruption/
   hookfailure/partialtails/reseal negatives remain and apply to expanded scope.

For both all40/default the independent observed result must be:
2children/41distinctconnections/802heads/789small/requestflow200091899/
46nonACKclientSETTINGS/2actualinfo/13incomingresets/2finalcollections.
Main733heads/720small, idle69/69; idle is a separate fresh app/child first.
Outgoing peer_reset stays separate from13 incoming. StartupSETTINGS and later
SETTINGS/ACK are separate facts. Actuallarge request hashes both equal
190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2;
producer/file/sentinel/range output contracts stay exact. Do not sum catalogue
budgets or select recipe success to populate these observed fields.

Final active-shutdown collection is67records+metrics BEFORE signal and no later
collection. Post-main totals: middleware67,attempts62,begins61,ends52,cancels9,
failures1,end_errors1,chunk_errors1,invalid_progress1,errors0,bytes200091500,
active0,paused0,buffered_middleware666; pre-signal cancels8. Report actual captures
and comparisons, not manufactured postmodel records. Preserve actual output/
binding/private fields from client retention without extra diagnostics.

Preserve ready15/whole900/grace<=15 clipped/ordinary30/large180 limits and original
caller-clock freshness. Default final-main debt<=64; final allowance3064352 plus
13*ACTUALremainingdebt (default<=3065184, endinglarge<=4768262 atdebt131070).
No erasing parser tails/debt or resetting caps/deadlines to pass. WholeRX
5288609050 and refundframes400183798 are upper ceilings, never observed traffic
to invent. Assert actual counts within ceilings; retain actual amount/frame
credits and lateclosed-grant facts. No allocation of wholelarge bodies.

Before edits read actual AGENTS.md/CODING_CONVENTION.md and narrow incremental/
TDD/interface workflows plus relevant specialist instructions. Graphify query
before NEW codebase questions/search/read; supplied/already located paths may
be read. Freeze exact published45 bytes/hashes,119-input identity and fresh
exhaustive prior-evidence hash map excluding only newunit. Preserve all actual
failed/intermediate commands/source/raws; genuine defects need pre-fix REDs.
Do not overwrite failed receipts or label APIabsence as behavioral evidence.

After final source edit FOUR covering commands: test_all40.py and test_imports.py,
normal and-O. No old family suites absent actual dependency/gap. Covering output
must identify explicit versus genuinely omitted-default invocation and actual
dispatched/observed IDs/connections/counts/hashes/retained facts for positives.
Record actual45 before/after source and current-helper texts/hashes, exactargv/
cwd/PYTHONPATH/PYTHONDONTWRITEBYTECODE/interpreter, stdout/stderr/exit, SAME-shell
fresh pinned restoration. Audit source ownership, all45 established AST/import
guards, strict max3/newsource+ALLcurrentunithelpers, inert metadata helper import/
empty+foreign CLI (explicitflags/arity including shell), input/history integrity.
Preserve oldhelper bytes before corrections, no livehistorical exemptions or new
policy forced onto unchanged source. Do not lower tests/lints/thresholds/bounds.

Every dependent Python proof/audit/check SHELL begins set-e and exact pinned
restorer with NEW absolute receipt, followed by operation in THAT SAME SHELL:
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT
TMP resets across continuations. Never rely on persistence or install/fetch tools.
All direct Python, edits included, pinned interpreter -B-S, optional-O.
InterpreterSHA4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
PYTHONDONTWRITEBYTECODE=1 and exact PYTHONPATH:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
Graphify:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650
Root owns finalASTupdate. Known genericDoD documentation reference drift already
resolved under explicitgates, no vendoredskill edit or contextstall needed.

Only pinned in-memory codecs/supplied synthetic app/transport/process facts.
No native/build/server/socket/SSLContext/TLSclose/realclock/processownership/
kernel/race/fault-scheduling/network/install/oldruntime runs. Even successful
sourceall40 leaves broad combinedreview, runtime/native/fullproject/platform,
productionadoption and alloriginalmilestones mandatory; no M2/fullgoal completion.

Write full report: exactinterfaces/files/commands/raw/results/RED-GREEN chronology;
actual defaultcall proof, both fullaggregate and subset facts, all40 successful
IDs vs partial/negative starts, actual retained values, caps/debt/credit/hash facts;
source/input/history/helper audits and selfreview/limits. Return<=15lines status
DONE|DONE_WITH_CONCERNS|NEEDS_CONTEXT|BLOCKED, no commits, testsummary/concerns/report.
Root dispatches fresh reviewer, publicationaccuracy and commit+immediatepush.
No worker subagents or self-appointed reviewer. Finish authorized report/audits
before reporting DONE; a concrete component defect is a reportable dependency.
