"""Independently bind the coordinator binding candidate to its exact covering receipts."""
import ast
import hashlib
import json
import sys
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def nesting(node, depth=0):
    control = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.With, ast.AsyncWith,
               ast.Try, ast.TryStar, ast.Match)
    level = depth + int(isinstance(node, control))
    return max([level] + [nesting(child, level) for child in ast.iter_child_nodes(node)])


def verify_source(source, unit):
    baseline = read_json(unit / 'baseline.json')
    manifest = Path('docs/implement-2-2-0/evidence/m2_h2_combined_binding/manifest.json')
    published = read_json(manifest)
    if baseline['source'] != published['current_source_files'] or sha(manifest.read_bytes()) != baseline['authority_sha256'] or Path(baseline['authority']).resolve() != manifest.resolve():
        raise ValueError('Frozen published baseline differs')
    if (unit / 'baseline-inputs.json').read_bytes() != (source / 'evidence/coordinator-a/immutable-inputs.json').read_bytes():
        raise ValueError('Frozen input authority differs')
    current = {path.name: sha(path.read_bytes()) for path in sorted(source.glob('*.py'))}
    added = sorted(current.keys() - baseline['source'].keys())
    changed = sorted(name for name, digest in baseline['source'].items() if current.get(name) != digest)
    if len(current) != 45 or added != [] or changed != ['test_all40.py', 'test_all40_descriptors.py']:
        raise ValueError('Source ownership differs')
    for name, digest in baseline['source'].items():
        if sha((unit / 'baseline-source' / name).read_bytes()) != digest:
            raise ValueError('Frozen source bytes differ')
    for name, digest in baseline['history'].items():
        path = source / 'evidence' / name
        if path.is_symlink() or sha(path.read_bytes()) != digest:
            raise ValueError('Prior evidence differs: ' + name)
    return current, len(baseline['history'])


def verify_inventory(folder, current, source):
    data = read_json(folder / 'inventory.json')
    expected_path = '/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'
    expected_interpreter = '4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601'
    if data['source'] != current or data['pythonpath'] != expected_path or data['dontwritebytecode'] != '1':
        raise ValueError('Covering source/environment differs')
    if data['interpreter_sha256'] != expected_interpreter or sha(Path(data['interpreter']).read_bytes()) != expected_interpreter:
        raise ValueError('Covering interpreter differs')
    if Path(data['cwd']).resolve() != source.resolve():
        raise ValueError('Covering cwd differs')
    for name, digest in current.items():
        if sha((folder / name).read_bytes()) != digest:
            raise ValueError('Captured source text differs')
    for name, digest in data['helpers'].items():
        if sha((folder / 'helpers' / (name + '.txt')).read_bytes()) != digest:
            raise ValueError('Captured helper text differs')
    helpers = source / 'evidence/all40-binding-b/helpers'
    if data['helpers'] != {path.name: sha(path.read_bytes()) for path in helpers.iterdir() if path.is_file()}:
        raise ValueError('Final captured helpers differ from current live helpers')
    return data


def verify_receipt(unit, name, current):
    folder = unit / name
    if Path(name).is_absolute() or '..' in Path(name).parts or not folder.resolve().is_relative_to(unit.resolve()):
        raise ValueError('Receipt must remain within the owned unit')
    argv = (folder / 'argv.txt').read_text().splitlines()
    if argv[:3] != ['/home/codespace/.python/current/bin/python3', '-B', '-S']:
        raise ValueError('Covering argv prefix differs')
    optimized = len(argv) > 3 and argv[3] == '-O'
    tail = argv[4:] if optimized else argv[3:]
    if tail not in (['test_all40.py'], ['test_imports.py']):
        raise ValueError('Covering target differs')
    before = verify_inventory(folder / 'before', current, unit.parents[1])
    after = verify_inventory(folder / 'after', current, unit.parents[1])
    if before != after:
        raise ValueError('Covering identities changed during check')
    if (folder / 'exit.txt').read_text() != '0\n' or (folder / 'stderr.txt').read_bytes():
        raise ValueError('Covering command failed or emitted stderr')
    restored = read_json(folder / 'restoration.json')
    if not restored['all_inputs_verified_in_this_command'] or restored['authority_entries'] != 119:
        raise ValueError('Same-shell input restoration differs')
    if (restored['physical_rows_checked'], restored['unique_resolved_files'], restored['ordered_codec_files_checked']) != (118, 113, 42):
        raise ValueError('Restored input inventory differs')
    return dict(module=tail[0], optimized=optimized, argv=argv, cwd=before['cwd'],
                source_before_after_exact=True, exit_code=0, stderr_empty=True,
                stdout_sha256=sha((folder / 'stdout.txt').read_bytes()),
                restoration_sha256=sha((folder / 'restoration.json').read_bytes()))


def verify_helpers(unit, plan, source):
    paths = sorted((unit / 'helpers').glob('*.py'))
    paths += [plan / ('task-5e3b9c-' + name + '.py') for name in
              ('root-audit', 'build-publication', 'publication-audit') if (plan / ('task-5e3b9c-' + name + '.py')).exists()]
    paths += [source / name for name in ('test_all40_descriptors.py', 'test_all40.py')]
    result = {}
    for path in paths:
        tree = ast.parse(path.read_text(), filename=str(path))
        depth = nesting(tree)
        if depth > 3 or any(isinstance(node, (ast.ClassDef, ast.Assert)) for node in ast.walk(tree)):
            raise ValueError('Current helper/source structure differs: ' + str(path))
        scope = {'__name__': 'root_metadata', '__file__': str(path)}
        previous_path = sys.path[:]
        try:
            sys.path.insert(0, str(path.parent.resolve()))
            exec(compile(tree, str(path), 'exec'), scope)
        finally:
            sys.path[:] = previous_path
        result[str(path)] = dict(sha256=sha(path.read_bytes()), max_nesting=depth, metadata_import_inert=True)
    return result


def receipt_totals(receipts):
    streams = [stream for receipt in receipts for stream in receipt['streams']]
    return dict(connections=len(receipts), heads=sum(item['sent'][3] for item in receipts),
                small=sum(int(item[2] == 'small' and item[14]) for item in streams),
                request_flow=sum(item['sent'][7] for item in receipts),
                settings=sum(item['sent'][9] for item in receipts),
                informationals=sum(item['informationals'] for item in receipts),
                incoming_resets=sum(count for item in receipts for _code, count in item['received'][11]),
                final_collections=sum(item['final_collections'] for item in receipts),
                receive_bytes=sum(item['received'][1] for item in receipts),
                receive_calls=sum(item['received'][0] for item in receipts))


def verify_final_caps(row):
    for final in row['finals']:
        allowance = 3064352 + 13 * final['debt']
        if final['allowance'] != allowance or final['bytes'] > allowance or final['debt'] > 131070:
            raise ValueError('Actual final debt/allowance differs')
    if row['observed']['receive_bytes'] > 5288609050:
        raise ValueError('Whole RX ceiling exceeded')
    refunds = sum(item['received'][12][0] + item['received'][13][0] for item in row['receipts'])
    if refunds > 400183798:
        raise ValueError('Refund frame ceiling exceeded')
    return refunds


def verify_children(row):
    for index, child in enumerate(row['children']):
        receipts = [item for item in row['receipts'] if item['identity'][0] == index]
        if receipt_totals(receipts) != child['counts']:
            raise ValueError('Actual child receipt counts differ')


def verify_row(row):
    receipts = row['receipts']
    identities = [tuple(item['identity']) for item in receipts]
    if len(set(identities)) != len(identities) or row['actual_dispatch'] != row['selection']:
        raise ValueError('Actual identity or dispatch differs')
    if receipt_totals(receipts) != row['observed']:
        raise ValueError('Full direction/stream receipt arithmetic differs')
    if sum(item['flow'] for item in receipts) != sum(stream[4] for item in receipts for stream in item['streams']):
        raise ValueError('Stream and direction request flow differs')
    verify_children(row)
    refunds = verify_final_caps(row)
    return dict(invocation=row['invocation'], invocation_calls=row['invocation_calls'],
                selection=row['selection'], children=len(row['children']), observed=row['observed'],
                refund_frames=refunds, finals=row['finals'], receipt_arithmetic_exact=True)


def verify_large_hashes(row):
    expected = '190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2'
    result = {}
    for receipt in row['receipts']:
        if receipt['identity'][1] not in ('large_declared', 'large_undeclared'):
            continue
        streams = [item for item in receipt['streams'] if item[3] == 100000000]
        if len(streams) != 1 or streams[0][4] != 100000000 or streams[0][5] != expected or not streams[0][14]:
            raise ValueError('Actual large payload/hash/terminal differs')
        result[receipt['identity'][1]] = dict(logical=streams[0][3], flow=streams[0][4], sha256=streams[0][5])
    if set(result) != {'large_declared', 'large_undeclared'}:
        raise ValueError('Both large uploads were not observed')
    return result


def verify_post_capture(row):
    child = row['children'][1]
    before, after = child['final_observations'], child['teardown']['post']
    expected = dict(middleware=67, attempts=62, begins=61, ends=52, cancels=9,
                    failures=1, end_errors=1, chunk_errors=1, invalid_progress=1,
                    errors=0, bytes=200091500, active=0, paused=0, buffered_middleware=666)
    if len(before['records']) != 67 or len(after['records']) != 67 or before['metrics']['cancels'] != 8:
        raise ValueError('Actual before/post capture differs')
    if any(after['metrics'][key] != value for key, value in expected.items()):
        raise ValueError('Actual post metrics differ')
    summed = {key: sum(record[key] for record in after['records'].values()) for key in expected if key != 'buffered_middleware'}
    if any(summed[key] != value for key, value in expected.items() if key != 'buffered_middleware'):
        raise ValueError('Actual post record totals differ')
    if child['counts']['heads'] - summed['middleware'] != expected['buffered_middleware']:
        raise ValueError('Actual buffered middleware differs')
    return dict(pre_metrics=before['metrics'], post_metrics=after['metrics'], record_count=67,
                binding=before['binding'], retained_snapshots=[len(item) for item in row['retained']])


def verify_all40(row):
    expected = dict(connections=41, heads=802, small=789, request_flow=200091899,
                    settings=46, informationals=2, incoming_resets=13, final_collections=2,
                    receive_bytes=51312051, receive_calls=31433)
    if row['observed'] != expected or len(row['children']) != 2 or len(set(row['selection'])) != 40:
        raise ValueError('Actual all40 aggregate differs')
    children = row['children']
    if children[0]['selection'] != ['shutdown_idle'] or (children[0]['counts']['heads'], children[0]['counts']['small']) != (69, 69):
        raise ValueError('Fresh idle child differs')
    if (children[1]['counts']['heads'], children[1]['counts']['small']) != (733, 720):
        raise ValueError('Main child totals differ')
    outgoing = sum(count for item in row['receipts'] for code, count in item['sent'][11] if code == 8)
    if outgoing != 1 or row['finals'][1]['debt'] > 64:
        raise ValueError('Outgoing reset or default final debt differs')
    return dict(invocation=row['invocation'], observed=expected, large_hashes=verify_large_hashes(row),
                captures=verify_post_capture(row), outgoing_peer_reset=outgoing)


def verify_compositions(unit):
    normal = (unit / 'final-01-focused/stdout.txt').read_bytes()
    if normal != (unit / 'final-02-focused-optimized/stdout.txt').read_bytes():
        raise ValueError('Normal and optimized observed facts differ')
    rows = [json.loads(line) for line in normal.decode().splitlines() if line.startswith('{')]
    if len(rows) != 11 or [row['invocation'] for row in rows] != ['explicit'] * 10 + ['omitted_default']:
        raise ValueError('Actual invocation modes differ')
    if rows[-2]['selection'] != rows[-1]['selection']:
        raise ValueError('Explicit/default selected IDs differ')
    if any(row['invocation_calls'] != [dict(positional=1, selection_keyword=False)] for row in rows[:-1]):
        raise ValueError('Explicit invocation proof differs')
    if rows[-1]['invocation_calls'] != [dict(positional=0, selection_keyword=False)]:
        raise ValueError('Default selection argument was not omitted')
    return dict(compositions=[verify_row(row) for row in rows],
                full_all40=[verify_all40(row) for row in rows[-2:]], stdout_bytes=len(normal),
                stdout_sha256=sha(normal), native_executed=False)


def main(argv):
    if len(argv) != 5 or argv[0] != '--audit':
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    unit = source / 'evidence/all40-binding-b'
    current, history_count = verify_source(source, unit)
    receipts = {name: verify_receipt(unit, name, current) for name in argv[1:]}
    expected = {(module, optimized) for module in ('test_all40.py', 'test_imports.py') for optimized in (False, True)}
    if {(row['module'], row['optimized']) for row in receipts.values()} != expected:
        raise ValueError('Four-check coverage differs')
    result = dict(base_commit='9e6a300341ef72056f7689a0fee108a1786c2095',
                  current_source_sha256=current, changed_modules=['test_all40.py', 'test_all40_descriptors.py'],
                  added_modules=[], unchanged_modules=43,
                  prior_evidence_hashes_verified=history_count,
                  focused_receipts=receipts, observed_compositions=verify_compositions(unit),
                  current_helpers=verify_helpers(unit, plan, source),
                  native_executed=False, actual_all40_source_executed=True, milestone_complete=False)
    output = plan / 'task-5e3b9c-root-final-audit.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(source_modules=len(current), prior_evidence_hashes_verified=history_count,
                          focused_receipts=len(receipts), result=str(output)), indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
