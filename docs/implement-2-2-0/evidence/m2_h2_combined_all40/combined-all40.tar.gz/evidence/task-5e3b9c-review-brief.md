# Fresh source review: complete binding and source all40

Read task-5e3b9c-brief.md, task-5e3b9c-report.md and complete
task-5e3b9c-review-source.diff once. BASE9e6a300341ef72056f7689a0fee108a1786c2095;
uncommitted candidate45 is tied to task-5e3b9c-root-final-audit.json.
Exact architect/observer contracts linked by the task brief remain binding.

Independent task-scoped spec and quality review, with Root explicitly requested
thermo-nuclear structural lens under project overrides. Read project/reviewer/
convention/relevant skills and specialist instructions. Report actionable
Critical/Important/Minor with file:line/scenario, both verdicts and explicit
cannot-verify limits. No edits/Git/network/native/build/agents or suite reruns.

Global constraints verbatim from the brief:

For both all40/default the independent observed result must be:
2children/41distinctconnections/802heads/789small/requestflow200091899/
46nonACKclientSETTINGS/2actualinfo/13incomingresets/2finalcollections.
Main733heads/720small, idle69/69; idle is a separate fresh app/child first.
Outgoing peer_reset stays separate from13 incoming. StartupSETTINGS and later
SETTINGS/ACK are separate facts. Actuallarge request hashes both equal
190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2;
producer/file/sentinel/range output contracts stay exact. Do not sum catalogue
budgets or select recipe success to populate these observed fields.

Final active-shutdown collection is67records+metrics BEFORE signal and no later
collection. Post-main totals: middleware67,attempts62,begins61,ends52,cancels9,
failures1,end_errors1,chunk_errors1,invalid_progress1,errors0,bytes200091500,
active0,paused0,buffered_middleware666; pre-signal cancels8. Report actual captures
and comparisons, not manufactured postmodel records. Preserve actual output/
binding/private fields from client retention without extra diagnostics.

Preserve ready15/whole900/grace<=15 clipped/ordinary30/large180 limits and original
caller-clock freshness. Default final-main debt<=64; final allowance3064352 plus
13*ACTUALremainingdebt (default<=3065184, endinglarge<=4768262 atdebt131070).
No erasing parser tails/debt or resetting caps/deadlines to pass. WholeRX
5288609050 and refundframes400183798 are upper ceilings, never observed traffic
to invent. Assert actual counts within ceilings; retain actual amount/frame
credits and lateclosed-grant facts. No allocation of wholelarge bodies.

Review actual omitted default call (zero positional selection and no keyword),
actual full traffic/retained comparisons, all-family descriptor payload/END/reset
authority, caller order/subsets and expanded negative coverage. Existing peer/
oracle/coordinator/adapter/model untouched: two changed/43unchanged. No native/
M2/fullgoal completion follows from this source-only all40 proof.

Four covering normal/O binding/import checks and final audit already passed on
this exact source. Read actual argv, metadata, raw results and current identities.
Root independently rehashes45source/17766history/11911811342 inputclosure, current
helpers, four complete receipts, normal/O equality; recomputes direction+stream
and child arithmetic, both all40 aggregates/largehashes/defaultcall, finalcaps/
refundceilings and pre/post record metrics from recorded actual stdout.
Those metadata checks do not replace your source provenance/logic review.

One new late-credit assertion was incorrect and is explicitly qualified: a
connection has no closed stream identity; actual final stream latecredit1781,
not256. Failed intermediate source/results retained, accepted components/bounds
unchanged. Check that corrected expectation matches actual semantics and does
not conceal a defect. Old019/020 receipts renamed intact before final clock
identity cleanup remain intermediate; currentfourfresh commands are separate.

Diff includes full context for both changed modules plus all newunit helpers and
Root auditor. Do not reread changed files unless required context is missing.
Scoped unchanged reads only for a concrete named risk. Graphify before new
questions/search/read, supplied/diff-located paths allowed. No source tests to
recreate missing evidence; report specific unanswered doubts to Root. Exact
pinned restorer may supply missing source reads in same shell/newreceipt only.
Future publication helpers/accuracy and broadcombined/native/adoption gates are
outside this source review. Return full report; Root preserves it verbatim.
