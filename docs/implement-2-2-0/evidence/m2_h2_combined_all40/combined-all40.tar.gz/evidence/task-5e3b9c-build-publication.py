"""Archive the reviewed complete binding and its actual source execution evidence."""
import hashlib
import json
import runpy
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load_writer(plan):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_peer/combined-core-peer.tar.gz')
    if sha(archive.read_bytes()) != 'dbcd7a01a56a3c80600aa39fa7b61dec00060976c14a82e2bd4a712a2520d25d':
        raise ValueError('Writer provenance differs')
    builder = plan / 'task-5e3b7p1-build-publication.py'
    with tarfile.open(archive, 'r:gz') as previous:
        if previous.extractfile('evidence/' + builder.name).read() != builder.read_bytes():
            raise ValueError('Published writer differs')
    return runpy.run_path(str(builder))['load_writer'](plan)


def add_baseline(writer, members, baseline):
    if sha(baseline.read_bytes()) != 'fe13eb22510ec853caeae7b345bd13d33d5678decf8375766d8789a3816a0b4c':
        raise ValueError('Baseline archive differs')
    with tarfile.open(baseline, 'r:gz') as previous:
        for member in previous:
            if not member.isfile():
                raise ValueError('Nonregular baseline member')
            if not member.name.startswith(('reference/', 'source/current/')):
                continue
            name = member.name.replace('source/current/', 'history/first-binding-source/', 1)
            writer['add'](members, name, previous.extractfile(member).read())


def add_files(writer, members, source, plan):
    for path in sorted(source.glob('*.py')):
        writer['add'](members, 'source/current/' + path.name, path.read_bytes())
    raw = source / 'evidence/all40-binding-b'
    for path in sorted(raw.rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink in evidence')
        if path.is_file():
            writer['add'](members, 'raw/all40-binding-b/' + path.relative_to(raw).as_posix(), path.read_bytes())
    names = ('task-5e3b9c-brief.md', 'task-5e3b9c-report.md',
             'task-5e3b9c-review-brief.md', 'task-5e3b9c-review-report.md',
             'task-5e3b9c-review-source.diff', 'task-5e3b9c-root-final-audit.json',
             'task-5e3b9c-root-final-audit-inputs.json', 'task-5e3b9c-root-final-audit-inputs-2.json',
             'task-5e3b9c-root-audit.py', 'task-5e3b9c-build-publication.py',
             'task-5e3b9c-publication-audit.py', 'task-5e3b8a-restore-inputs.py',
             'task-5e3b1-root-source-restoration.json', 'task-5e3b9b-binding-plan-report.md',
             'task-5e3b-oracle-interface-report.md')
    for name in names:
        writer['add'](members, 'evidence/' + name, (plan / name).read_bytes())


def main(argv):
    if argv != ['--build']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    audit = json.loads((plan / 'task-5e3b9c-root-final-audit.json').read_text())
    current = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if current != audit['current_source_sha256']:
        raise ValueError('Approved current source differs')
    writer, members = load_writer(plan), {}
    baseline = Path('docs/implement-2-2-0/evidence/m2_h2_combined_binding/combined-binding.tar.gz')
    add_baseline(writer, members, baseline)
    add_files(writer, members, source, plan)
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_combined_all40')
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'combined-all40.tar.gz'
    inventory = writer['write_archive'](archive, members)
    completed = sorted({case for row in audit['observed_compositions']['compositions'] for case in row['selection']})
    manifest = dict(scope='Complete source canonical coordinator binding with passive wire receipts',
                    base_commit=audit['base_commit'], baseline_archive_sha256=sha(baseline.read_bytes()),
                    archive=archive.name, archive_bytes=archive.stat().st_size,
                    archive_sha256=sha(archive.read_bytes()), safe_regular_text_members=len(members),
                    inventory_entries=len(inventory), current_source_files=current,
                    changed_files=['test_all40_descriptors.py', 'test_all40.py'], added_files=[],
                    unchanged_modules=43, supported_case_count=40, actual_completed_case_ids=completed,
                    actual_completed_case_count=len(completed), actual_compositions=audit['observed_compositions']['compositions'],
                    full_all40=audit['observed_compositions']['full_all40'],
                    focused_checks=audit['focused_receipts'],
                    prior_evidence_hashes_checked=audit['prior_evidence_hashes_verified'],
                    source_ast_inert_import_modules=45, current_guarded_inert_unit_helpers=3,
                    current_helper_max_nesting=3, retained_identity_entries=119,
                    physical_identity_rows=118, unique_resolved_files=113, ordered_codec_files=42,
                    source_review='Spec and quality approved', complete_source_binding_accepted=True,
                    canonical_coordinator_sole_dispatcher=True, retained_client_observations_compared=True,
                    rejected_finish_cannot_reseal=True, independent_codec_implementation=False,
                    actual_all40_source_executed=True, native_executed=False, milestone_complete=False,
                    remaining=['Broad combined review', 'Runtime/native/full gates', 'Production adoption'])
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
                  regular_members=len(members), inventory_entries=len(inventory), source_modules=len(current),
                  actual_completed_case_ids=completed, native_executed=False, actual_all40_source_executed=True)
    (plan / 'task-5e3b9c-root-archive-build.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
