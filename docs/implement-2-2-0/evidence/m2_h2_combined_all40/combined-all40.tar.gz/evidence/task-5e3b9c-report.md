# Remaining-family binding and actual explicit/default all40 proof

Status: DONE for the assigned source-only slice. All four covering
commands and the final audit passed. This report concerns the assigned source-only
slice; independent review, publication, graph update, commit and immediate push
remain Root-owned. No native, network, Git, publication, dependency, product,
capacity, or other source work was performed.

Supplied base: 9e6a300341ef72056f7689a0fee108a1786c2095.
Scope and acceptance came from task-5e3b9c-brief.md, the prior binding plan,
accepted observer interface report, actual AGENTS.md/CODING_CONVENTION.md,
HTTP protocol/verification specialist instructions, and incremental, TDD,
interface/design and review workflows. Project overrides and this source-only
assignment govern; Zig/native/full-project gates remain mandatory later.

## Files, interface and scope

P = `/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases`.
U = `P/evidence/all40-binding-b`.

Changed existing source only:

- `P/test_all40_descriptors.py`: all40 immutable request expectations, existing
  peer factory selection and separate bounded disconnect/reuse case evidence.
- `P/test_all40.py`: canonical compositions, true omitted-selection invocation,
  detached full wire receipts/client captures, aggregate/cap/debt/hash checks.

New evidence only under U, plus this report at
`/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b9c-report.md`.
Current45 remains45;43 source modules remain byte-identical to the published
binding manifest. No import-inventory addition or accepted peer/oracle/
coordinator/adapter/model/client/core/fixture/handler edit was made.

The provider interface remains:

```
connection_descriptor(child, case, connection_index, *, final) -> ConnectionDescriptor
new_provider(*, clock) -> (ChildFactory, BindingState)
finish_binding(state, successful_result) -> tuple[ConnectionReceipt, ...]
run_selection(selection, *, clock) -> (result, BindingState)
```

Only canonical `coordinator.run` dispatches through the existing `adapter.run_case`
handlers. The binding selects stable existing peer factories, wraps each returned
connection once, and seals after the successful canonical return and completed
hooks. No family check/driver, alternative dispatcher, extra GET or retained
client context was added. The one-shot finish boundary still consumes failed
post-seal comparisons. Named observer aliases and the seven-key connection
contract remain unchanged; `protocol`, `now`, ownership, TLS and ALPN retain their
original identities. The same caller clock is passed to provider and coordinator.

Each child has one fresh app, one current peer, bounded ordered observer states,
completed prefix, detached retained facts and lifecycle evidence for at most two
case IDs. Disconnect1 and its replacement share exactly one disconnect evidence
object. Reuse has a separate object; each case's cumulative evidence is compared
once against only that case's sealed connection receipts. No per-connection
repeat summation of cumulative lifecycle totals is used.

## Immutable descriptor authority

Pure schedule/order/path sources remain the existing peer contracts:
`test_pause.schedule`, `test_admission.schedule/header_contract`,
`test_continue_quota.schedule`, `test_credit.schedule`,
`test_metadata_concurrency.paths`, `test_terminal_peer.paths`, and
`test_lifecycle.order`. Core/producer/file/shutdown construction from9b remains.
No mutable peer handler is called with pretend state.

New payload expectations distinguish actual transmitted bytes from application
acceptance. Sink/progress sends the seven-byte prefix followed by a restarted
eight-byte prefix; it is neither a contiguous15-byte body nor accepted7.
Cancel-ready sends7, cancel-paused/peer-reset/end-error send32; incoming reset8,
incoming reset2 and outgoing peer-reset8 are separate terminals. End-error has
request DATA END; other primary reset cases have open requests. Recovery bodies
remain32 and sibling echo is exactly `b's'`.

Observed-limit refusal sends32 valid bytes plus offending `b'x'`; zero-observed
sends only `b'x'`; declared refusals, quota refusal, begin failure and concurrent
refusal transmit no DATA. Header-only empty cases use HEADERS END, empty-DATA
uses DATA END, and queued-trailer/metadata cases use trailer END. Continue
expects one actual100 before the existing peer admits DATA. Refusals require
response END plus reset0. Queued trailers expect12289 logical/12297 flow bytes,
including eight padding bytes. Other new complete payload expectations use the
model's pure payload/hash contract only where transmitted equals accepted.

All roles remain explicit: file/producer/pressure and17-byte early-final are
output, never small by size. Final tags are the exact ordered67 BODY_SPECS tags
plus metrics on the actual last connection; disconnect1 is never final.
Expectation lengths/hashes and catalogue constants are comparison operands,
never observed totals. Actual totals come exclusively from sealed wire receipts.

## Actual execution and omitted default

The covering `test_all40.py` executes nine explicit subset/composition chains,
then explicit catalogue.CASES, then this direct call with no selection argument:

```
factory, state = binding.new_provider(clock=clock)
result = coordinator.run(run_identity='omitted_default', now=1,
                         units_per_second=1000, clock=clock, child_factory=factory)
```

The test interposes on the actual coordinator invocation only to record the
positional argument count and presence of a `selection` keyword. It calls the
original once and returns its original result/errors. Explicit has one positional
argument; omitted-default has zero and no selection keyword. None and explicit
all40 are not used as substitutes. Actual adapter dispatch is captured and
compared with canonical order, and each observer/wrapper identity and underlying
send/receive call count is compared with the resulting sealed receipt.

Both all40 runs independently produce:

| Fact | Actual |
| --- | ---: |
| Fresh children | 2 |
| Distinct connection identities | 41 |
| Initial request heads | 802 |
| Small completions | 789 |
| Request flow bytes | 200091899 |
| Non-ACK client SETTINGS | 46 |
| Actual informational responses | 2 |
| Incoming resets | 13 |
| Separate outgoing peer resets | 1 |
| Final collections | 2 |
| Received wire bytes | 51312051 |
| Receive calls | 31433 |

Idle executes first on a separate fresh child/app with69heads/69small; main
executes the39 cases in caller order with733heads/720small. All40 IDs successfully
complete and seal in both invocations. Large declared and undeclared each
actually transmit100000000 bytes and each hash equals
`190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2`.
The full large bodies are never allocated; peers/model helpers remain bounded
chunk/hash processing.

All three producer cases actually emit16777313 bytes with SHA256
`e5b7e8c5bbad59c7bc86f18236a37661571e972f65c707d7dc1902386ec5e91d`.
File emits24593 bytes with SHA256
`8cacc49e5f9553369e25a67f4e0e9a799b38c07245a6da92a54ffb58c3ebc2ac`.
Early final emits17 output bytes with SHA256
`d826bcf95ee8850cecb39accdeb84b32336a0415411938da42da7edcac891da7`.
Existing peers/handlers enforce exact file range, producer sentinel, and output
pressure contracts; their observations and private fields are retained unchanged.

The nine explicit compositions are:

1. shutdown_idle, producer_reuse, stream_file, disconnect, shutdown_active.
2. producer_reuse, stream_file, disconnect.
3. shutdown_idle, async_delayed, ready_buffered.
4. early_final_order.
5. continue_ready, quota_refuse, begin_failure_rollback, limit_observed_reject.
6. partial_pause, queued_trailers_padding, receive_credit, continue_paused,
   control_rules.
7. metadata_helpers, cancel_ready, peer_reset, sink_error, invalid_progress,
   end_error, concurrent_routes, reuse, disconnect.
8. producer_reuse, stream_file, disconnect, large_declared.
9. output_pressure_ready, metadata_helpers, receive_credit, large_undeclared.

These exercise caller reordering, no active shutdown, both large-ending variants,
retained output through other families and disconnect replacement, Continue/quota,
padded credit/trailers, metadata, reset/error and reuse transitions. Full per-child
counts and per-stream facts are retained in stdout, not inferred from budgets.

## Actual captures, debt and timing

Each successful composition emits full direction receipts (settings/ACKs, DATA,
padding, resets, amount/frame credits and late credit) and every detached stream
receipt including logical/flow/hash, END/reset, debt and completion. No payload,
frame or read history is retained. JSON encodes receipt digest bytes as hex only;
other receipt fields retain their original values. These are sealed observations,
not regenerated model records.

Each result includes actual canonical child `final_observations` and teardown
`post`, compared by the provider to detached snapshots of the traffic-updated app.
Ordinary close, disconnect close and signal also validate/copy retained client
output/binding through the existing shutdown seam. All retained snapshots and
full final/post records, metrics, output diagnostics and binding/private fields
are printed without extra diagnostics. This preserves provider/client comparison
independence and catches existing retained corruption negatives.

Final active collection is67records+metrics BEFORE signal; no later collection
occurs. Pre-signal main cancels8. Post-main is middleware67, attempts62,
begins61, ends52, cancels9, failures1, end_errors1, chunk_errors1,
invalid_progress1, errors0, bytes200091500, active0, paused0,
buffered_middleware666. Signal then synthetic termination/process/post hooks
retain their accepted timing and successful-return contracts. They are supplied
synthetic facts, not proof of native process/transport ownership.

Both authorized open transport windows retain stream3, transmitted32/H32,
request_end=False, response_end=False, no reset, terminal_complete=False and
32/32 connection/stream debt. No closure or zero debt is invented.

With supplied clock2 and start1, ready=15002, whole=900001,
ordinary case=30002, large case=180002 and grace=15002; grace remains clipped by
case/whole. Existing read caps/deadlines/ledger/parser identities are unmodified.
The final collection instrumentation records actual entry debt and resulting
allowance and bytes; it requires3064352+13*ACTUAL remaining debt.
Default active main debt64 gives3065184. Large-ending cases enter with3562 debt
(1781 in each scope), allowance3110658, below the maximum4768262 at debt131070.
The last1781 stream grant is split across receives and observed after closure;
connection credit has no closed stream identity. Large-ending sealed debt is
zero only after the actual grants are parsed, not by reset or tail erasure.
Each large run observes12208 connection grants and12208 stream grants totaling
100000000 bytes in each scope. Nonfinal large has no late-closed stream grant;
final large has one late-closed stream grant of1781 bytes.

Whole RX5288609050 and refundframes400183798 remain upper ceilings, and the
actual receipt totals are asserted below them. They are never emitted as observed
traffic. Observer state retains active8/retained802 limits; binding retains at
most2 children/41 observers. Repeated successful/rejected finish cannot consume
receipts again.

## RED/GREEN and negatives

`red-004-expanded` is a pre-effect support-set RED: the new all40 expectation
failed while only12 descriptors were supported. This proves the old scope gap,
not a traffic defect or missing API behavioral proof. `intermediate-006-descriptors`
then validated all40 contracts and actually completed the first remaining-family
chain. `intermediate-007-remaining` completed the padded/credit and terminal/reuse
chains. `intermediate-008-explicit-all40` actually completed/sealed all40.

`intermediate-013-large` completed actual large traffic and sealing but failed my
new late-credit assertion, which wrongly required connection and stream scopes
to both have one late256-byte grant. `diagnostic-014-credit` recorded the actual
scope-specific receipts and debt: connection(12208,100000000,0,0),
stream(12208,100000000,1,1781), debt3562. Inspection of the accepted peer/observer
confirmed connection credit has no closed stream, and window splitting determines
the final1781 span. The new assertion was corrected to these exact contracts;
no accepted implementation/gate/bound changed. Original failing source, stderr,
exit and snapshots are preserved. `intermediate-016-full` then passed all expanded
compositions, both all40 forms and all negatives. No accepted-component defect
was found and ownership did not expand.

Existing negatives remain: empty and invalid selections pre-effect; duplicate
and ordering rejection; missing/duplicate/wrong receipt identities; actual
receive failure poison; one-shot failed comparison; retained context and returned
output/binding/record corruption; termination/post exceptions; and partial required
reset/refund tails. Reuse/pause are now valid, so their former unsupported-only
negative entries become actual positive execution. None remains an invalid
explicit selection. Partial-refund negative starts a large upload but does not
count as a completed case; all40/large positives supply separate completion proof.

## Evidence, commands and audit

U/baseline.json freezes exact45 published source hashes, the published manifest
identity and an exhaustive17766-file preceding evidence map, excluding only U.
U/baseline-source contains exact45 bytes; U/baseline-inputs.json preserves the
119-entry input authority from evidence/coordinator-a/immutable-inputs.json.
Current helpers are capture.py, freeze.py, audit.py and run.sh. The preceding
live audit bytes were preserved as U/audit-before-current-scope.py.txt before
adapting its ownership check to45existing/2changed/43unchanged. Old helpers/evidence
were never edited, and no live helper is exempted as historical.

The explicit runner is:

```
sh P/evidence/all40-binding-b/helpers/run.sh --run NAME PYTHON_ARGUMENTS
```

Each runner shell starts `set -e`, exports PYTHONDONTWRITEBYTECODE=1 and the exact
PYTHONPATH below, creates a fresh run directory, invokes the exact pinned restorer
with its new absolute restoration.json, then executes capture/target/capture in
THAT SAME SHELL. Targets run from P with
`/home/codespace/.python/current/bin/python3 -B -S`, optionally `-O`.
Interpreter SHA256:
`4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`.

```
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
```

Restorer exact command:

```
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT
```

Every recorded run has before/after actual45 source bytes/hashes, current helper
texts/hashes, exact argv/cwd/env/interpreter, separate stdout/stderr/exit, and
fresh restoration stdout/stderr/receipt. All direct Python edits also used the
pinned -B -S interpreter after same-shell restoration. Read/edit receipts are
restore-002,003,005,009,010,011,012,015,018,021 with purpose suffixes in U.
The one wrong-path read after restore-009 exited2; its original tool-output
transcript is retained as read-009-failure-transcript.txt. It is explicitly a
transcribed tool result, not an invented redirected raw or behavioral RED.

Recorded command chronology (exact argv and source bytes in each named folder):

| Run folder | Target after -B -S | Exit/result |
| --- | --- | --- |
| freeze-001 | helpers/freeze.py --freeze absolute U/baseline.json | 0;45 sources/17766 histories |
| red-004-expanded | test_all40.py | 1; prior12 support-set failure |
| intermediate-006-descriptors | -c check_descriptors + Continue/quota chain | 0 |
| intermediate-007-remaining | -c padded/credit + terminal/reuse chains | 0 |
| intermediate-008-explicit-all40 | -c check_composition(catalogue.CASES) | 0 |
| intermediate-013-large | -c producer/file/disconnect/large_declared | 1; new late-credit assertion |
| diagnostic-014-credit | -c execute large_declared and print exact credit/final/deadlines | 0 |
| intermediate-016-full | test_all40.py | 0 |
| intermediate-017-audit | -c source/history, strict AST, inert helper/runner audit | 0 |
| intermediate-019-focused | test_all40.py | 0; preserved before final caller-clock identity cleanup |
| intermediate-020-focused-optimized | -O test_all40.py | 0; likewise preserved |

The019/020 runs were first named final-01/final-02, then renamed intact to
intermediate folders before the last source edit. That edit made omitted-default
pass the same caller clock object to both provider and coordinator. No old raw,
source snapshot or helper byte was overwritten; new final folders have fresh
restoration receipts.

Final command outcomes and audit details follow below.

All FOUR covering commands ran after the final source/helper edits, with fresh
same-shell restoration and byte-identical before/after source/helper inventories:

| Run | Exact target after pinned -B -S | Exit | stderr |
| --- | --- | ---: | --- |
| final-01-focused | test_all40.py | 0 | empty |
| final-02-focused-optimized | -O test_all40.py | 0 | empty |
| final-03-imports | test_imports.py | 0 | empty |
| final-04-imports-optimized | -O test_imports.py | 0 | empty |
| final-audit | evidence/all40-binding-b/helpers/audit.py --audit absolute U/final-audit.json | 0 | empty |
| summary-022 | -c extraction of actual final stdout into U/actual-summary.json | 0 | empty |
| summary-023-retention | -c actual retained values, stdout equality and final audit receipts | 0 | empty |

Both focused stdout files are byte-identical, SHA256
`d95d0d9c5f8505dd7b12d4f87585a075385cf56ef1cb1cfa72f002b64998bb61`.
Both import-check stdout files have SHA256
`f43a3cdd9c945d3f7a96ac2897e949b991f45a431f1694de613b36651d0b00d6`.
Every final restorer verified119authority entries/118physical rows/113unique
files/42ordered codec files and the pinned interpreter; none needed restoration.
Fresh files have identical content SHA256
`9b7d82ff13d9cdcccd73c8fd3b9dcd7703e0d00cbd35b53ffa77c4269ad85812`.

Final source identities:

| File | Lines | SHA256 |
| --- | ---: | --- |
| test_all40_descriptors.py | 401 | f9e60b6b124e99b248579148a1005f9f2664c62ac9ae9361df42e2a4ce0a000d |
| test_all40.py | 397 | e2d0cf09e90d8d15bc351c5c52aaa2d266986d98d2482f9151677ce1e6eb3703 |

Current helper identities:

| Helper | SHA256 |
| --- | --- |
| audit.py | ea09c2ccbb69f16a5666b273b236d8df5352f8f33f84d66cf8788e3585383fdd |
| capture.py | e556b4e79645ff119f556c04dd351532d1cf134e8b1aa232df2c1a652ce29a5b |
| freeze.py | a9a0962b2c2f6883f7867394b39881d6e6e06fd5e8157cc50cf5781fbd0d27cb |
| run.sh | 17ab80242637a243ebbd6ab46fd07314b4d22b6c1cb3b41a7686e3fd17ab3efe |

Actual subset totals, using composition numbers listed above:

| Chain | Connections | Heads | Small | Request flow | SETTINGS | Info | Incoming resets | RX bytes | Refund frames |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 6 | 181 | 177 | 193 | 8 | 0 | 0 | 16890888 | 0 |
| 2 | 4 | 109 | 106 | 161 | 6 | 0 | 0 | 16861299 | 0 |
| 3 | 3 | 145 | 145 | 257 | 3 | 0 | 0 | 59080 | 0 |
| 4 | 1 | 75 | 74 | 32 | 2 | 0 | 1 | 31042 | 0 |
| 5 | 4 | 91 | 91 | 257 | 4 | 1 | 3 | 33659 | 0 |
| 6 | 5 | 113 | 113 | 90218 | 5 | 1 | 0 | 39366 | 2 |
| 7 | 10 | 556 | 550 | 746 | 10 | 0 | 5 | 200386 | 5 |
| 8 | 5 | 114 | 111 | 100000161 | 7 | 0 | 0 | 17179808 | 24416 |
| 9 | 4 | 92 | 91 | 100065601 | 5 | 0 | 0 | 17147222 | 24418 |
| Explicit all40 | 41 | 802 | 789 | 200091899 | 46 | 2 | 13 | 51312051 | 48840 |
| Omitted default | 41 | 802 | 789 | 200091899 | 46 | 2 | 13 | 51312051 | 48840 |

Both all40 runs retain2 idle and40 main output/binding snapshots. Actual main
binding remains tag producer_reuse_next, index1, generation18. Producer reuse
and window-pressure observations retain offset16777313, attempts2051,
writes2049, blocked2, pending2, invocations3, checks3 and terminals1;
after_reuse is1 for producer reuse and0 for window-pressure. Ready-pressure
retains attempts/writes2049, blocked/pending0, invocations/checks1 and terminals1.
These private pending values are deliberately preserved, not normalized to zero.
File retains reads4, requested/returned24593, min_offset37/max_end24630,
close_calls/closed_files/arms1, transferred=True, caller_owned=False and zero
read/arm/span errors. Exact output hashes are listed above and in actual captures.

Idle final received bytes28943. Main all40 final received bytes29159 against
allowance3065184. Chain8 large-declared final bytes29010; chain9 large-undeclared
final bytes29003, each against allowance3110658. Full direction receipts retain
ACK and non-ACK settings separately, and all48840 actual incoming refund frames
remain below the400183798 ceiling.

## Final audits, self-review and limits

Final audit output:

```
45 current AST; 43 unchanged + 2 changed; prior history: 17766
Strict max-three nesting, inert empty/foreign argv and live helper identities: 3
```

All45 established source AST/main-guard/inert-import gates passed normally and
optimized. Strict lexical/local max3 applies to both changed source files and
ALL three current Python metadata helpers; source maxima3/3, helper maxima2/1/2.
No authored classes, asserts, global/nonlocal mutation, mutable file-scope
containers or extra dispatch framework was added. Current helpers enforce exact
CLI flags/arity and passed inert import/empty/foreign argv effect guards; shell
runner passed all five empty/foreign/incomplete argv cases with zero output,
exit0 and unchanged file inventory. Current helper text hashes are bound to
all four final checks. Published source/input authorities and every frozen
historical evidence hash remain intact; unchanged source is not subjected to a
new policy or exemption.

Self-review inspected the final two-file diff against frozen bytes, all-family
request identity/END roles, transmitted versus accepted payloads, special hashes,
reset direction/code separation, trailer padding, final tag placement, observer
sealing and hook ordering, independent actual counter aggregation, separate
lifecycle evidence, exact once dispatch/wrapping, retained client/provider captures,
clock/deadline identity, credit/debt/tails and snapshot/source/helper integrity.
No unresolved component defect, ownership conflict or weakened gate was found.
Independent review remains Root-owned; this self-review does not replace it.

This is source-only execution using the pinned in-memory codecs and supplied
synthetic app/transport/process facts. Shared codec dependencies mean it is not
an independent codec implementation. No native server/socket/SSLContext/TLS-close,
real clock/process/kernel ownership, race/fault scheduling, platform, install,
network, or historical runtime suite was exercised. No Git/commit/push or
publication was performed. Broad combined review, runtime/native/full-project
and platform gates, production adoption and all original milestones remain
mandatory. Actual all40 source proof does not complete M2 or the full goal.
