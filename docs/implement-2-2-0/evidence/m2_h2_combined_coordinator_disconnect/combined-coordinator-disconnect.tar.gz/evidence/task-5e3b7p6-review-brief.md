# Disconnect coordinator source review

Review task-5e3b7p6-brief.md and exact
task-5e3b-coordinator-composition-plan-report.md phase2B. Claims
task-5e3b7p6-report.md; Rootfinalaudit task-5e3b7p6-root-final-audit.json binds
29489B full task-5e3b7p6-review-source.diff SHA256
86ba2ac28a0343e2d67052d5162b7b50204e6f81a2327a6aabfb2c9c1c596585.
BASEd357c2e005150e859934f36e9da923bff1d6b1f7/no taskcommit.39live/frozen/before
exact;3ownedchanged36unchanged;6actualnormalO0-emptyerr/fresh5576priorhashes and
119inputs/42orderedcodecs verified. Rootinitialmetadataaudit doubledrepo-relative
historyprefix; correctedpathnormalization only, no source/testchange.

Bindingfocus:
- ALL38validorderedselections incldiscoanyposition;2shutdown/defaultstillreject
  beforeeffects. Empty/staticvalidation/oldordinary/typed/privacy/error proofs
  preserved. Exactdescriptorbase+disconnect_close IFFselected; copiedcallbacks.
- Canonicalactualhandler/stricttermination BEFOREconnect2, sameoriginalcase/
  whole/clock/budget, no re-ready/deadline/debt reset or modelcompletion.
  Canonicalstrictschema/sevenreplacementfacts/exacttyping reused, notneworacle.
- Originalcallerclock/newesttime/localdeadline remainprivate throughstrictclose
  ANDconnect2 callbacks; do notinheritcallback-mutated contextnow/clock/deadlines
  intoauthoritativereplacement state. Actualexpiry/rollback beforewire/nextcase.
- Independent old/newprotocol/raw/request/responseledgers; existingcaseobjects
  shared/countonce. Returnedreplacementcontext ANDitsreceive used. Oldlatecredit
  rejected/isolated, no effectonfreshdebt.
- Oldlocalstats/debt captureatcanonicalterminationbeforeconnect2 and protected
  from exposedhooks/latermutation. AddonlyoldlocalSETTINGS/info tofinalcase;
  no doublecountsharedheads/small/flow/bytes/reads. Local summariesnotcumulative.
  Checkedtotals/ordinal vsindex1,1,2/strictoldrelease+normalnewrelease sealed.
- Retainedactualproduceroutput/Bbinding restoredafterreplacebeforecapture/final,
  no defaultrecipe/extraGET. Privatebefore/post/facts/resultgraphs protected;
  onefinalcollection/nonemptychild, no earnedidlecase or genericcleanupframework.

Namedrisks: actualtwo-transportdispatch/receiver, strictfactcopies surviving
laterconnectcallback mutation, localoldcounterprivacy acrossclose/replacement,
privatetime restoration acrossboth callbackboundaries, sharedcaseaccountonce,
retainedfacts/privatefinalcapture. Currentactualalone/middle/reuse/producerfinal
proof vsstatic38factorysupport/futureall38/default/native scope distinct.
Observedproducer->disco102heads/100small/R128/3conn/4SETTINGS derivesactualrun.
HistoricalinitialREDpre-effects, transientdeadline-expectationfailureunfrozen and
initialfailedauditreceiptmissing explicit; no fabricatedproduction/wireREDclaim.

Read diffonce/testsfirst/context10; changedfile rereadonlyneededcutoff/identifyit.
Outside-diff onlyconcretenamedrisk/onefocusedcheck. ApplyAGENTS/CODING/code-review-
and-quality andexplicitRoot-requestedthermo-nuclearstructurallens/projectoverrides.
No broadcrawl/passedsuite/Gitrepeats. Read-only/noagents/externalCLI/file/ref/
service/Git/native/build/server/socket/SSLContext/TLS-close/realclock/process
ownership/transfer/kernel/fault/cancel/schedule/race/panic/leak execution.
Exactgraphifyprefixinbrief before newquestion/search; providedpaths located.
Onlyfocusedpurepinnedsensitivity for unansweredconcreterisk. ReturnfullSPEC/
QUALITY/actionableseverity/fileline/scenariofindings, strengths/cannotverify;
Root savesfullverdict, no sourcefix yourself.
