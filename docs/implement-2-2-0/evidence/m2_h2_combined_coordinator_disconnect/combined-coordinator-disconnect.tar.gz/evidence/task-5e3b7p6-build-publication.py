"""Package reviewed disconnect composition and its bounded source evidence."""
import hashlib
import json
import runpy
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    provenance = Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_peer/combined-core-peer.tar.gz')
    if sha(provenance.read_bytes()) != 'dbcd7a01a56a3c80600aa39fa7b61dec00060976c14a82e2bd4a712a2520d25d':
        raise ValueError('Writer provenance differs')
    builder = plan / 'task-5e3b7p1-build-publication.py'
    with tarfile.open(provenance, 'r:gz') as previous:
        if previous.extractfile('evidence/' + builder.name).read() != builder.read_bytes():
            raise ValueError('Published writer source differs')
    writer = runpy.run_path(str(builder))['load_writer'](plan)
    baseline = Path('docs/implement-2-2-0/evidence/m2_h2_combined_coordinator_ordinary/combined-coordinator-ordinary.tar.gz')
    if sha(baseline.read_bytes()) != '8d53aae7605a054a10a78c5866ed4404f952d1000c603c648488dc0830fca675':
        raise ValueError('Baseline archive differs')
    members = {}
    with tarfile.open(baseline, 'r:gz') as previous:
        inventory = json.loads(previous.extractfile('INVENTORY.json').read())
        for member in previous:
            if not member.isfile():
                raise ValueError('Nonregular baseline member')
            if member.name == 'INVENTORY.json':
                continue
            data = previous.extractfile(member).read()
            if inventory[member.name] != dict(size=len(data), sha256=sha(data)):
                raise ValueError('Baseline inventory differs')
            if member.name.startswith('reference/'):
                writer['add'](members, member.name, data)
            if member.name.startswith('source/current/'):
                writer['add'](members, member.name.replace('source/current/', 'history/ordinary-coordinator-source/', 1), data)
    audit = json.loads((plan / 'task-5e3b7p6-root-final-audit.json').read_text())
    current = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if current != audit['current_source_sha256']:
        raise ValueError('Approved source differs')
    for path in sorted(source.glob('*.py')):
        writer['add'](members, 'source/current/' + path.name, path.read_bytes())
    raw = source / 'evidence/coordinator-disconnect'
    for path in sorted(raw.rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink in evidence')
        if path.is_file():
            writer['add'](members, 'raw/coordinator-disconnect/' + path.relative_to(raw).as_posix(), path.read_bytes())
    names = ('task-5e3b7p6-brief.md', 'task-5e3b7p6-report.md', 'task-5e3b7p6-review-brief.md',
             'task-5e3b7p6-review-report.md', 'task-5e3b7p6-review-source.diff',
             'task-5e3b7p6-root-final-audit.json', 'task-5e3b7p6-build-publication.py',
             'task-5e3b-peer-extraction-addendum.md', 'task-5e3b-coordinator-composition-plan-report.md',
             'task-5e3b-aggregate-acceptance-notes.md')
    for name in names:
        writer['add'](members, 'evidence/' + name, (plan / name).read_bytes())
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_combined_coordinator_disconnect')
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'combined-coordinator-disconnect.tar.gz'
    inventory = writer['write_archive'](archive, members)
    examples = [['disconnect'], ['ready_buffered', 'disconnect', 'large_declared'],
                ['disconnect', 'reuse'], ['producer_reuse', 'disconnect'], ['disconnect', 'ready_buffered']]
    summary_keys = ['case', 'case_connection', 'ordinal', 'case_deadline', 'settings', 'informationals',
                    'receive_bytes', 'receive_calls', 'connection_debt', 'stream_debt_total', 'release']
    manifest = dict(scope='Actual disconnect replacement coordinator composition using bounded synthetic peers',
                    base_commit=audit['base_commit'], baseline_archive_sha256=sha(baseline.read_bytes()),
                    archive=archive.name, archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
                    safe_regular_text_members=len(members), inventory_entries=len(inventory), current_source_files=current,
                    changed_files=audit['changed'], added_files=[], unchanged_ordinary_coordinator_modules=36,
                    current_normal_optimized_commands=6, current_ast_inert_import_files=39,
                    fresh_pre_edit_evidence_hashes_checked=5576, retained_identity_entries=119,
                    physical_identity_rows=118, unique_file_paths=113, ordered_codec_files=42,
                    supported_case_count=38, unsupported_cases=['shutdown_idle', 'shutdown_active'],
                    explicit_empty_supported=True, default_supported=False, actual_all38_execution_verified=False,
                    actual_representative_selections=examples, connection_summary_keys=summary_keys,
                    observed_producer_disconnect=dict(heads=102, small=100, request_flow=128, connections=3, settings=4),
                    one_final_collection_per_nonempty_child=True, strict_close_before_replacement=True,
                    independent_transport_shared_case_accounting=True, original_private_time_across_both_hooks=True,
                    old_local_accounting_and_release_facts_copied=True, retained_actual_output_binding=True,
                    initial_red_exit=1, initial_red_scope='Unsupported selection before factory/wire',
                    transient_harness_failure_frozen=False, initial_failed_audit_receipt_retained=False,
                    source_review='Spec and quality approved with no actionable findings',
                    supplied_transport_lifecycle_facts=True, combined_all40_executed=False,
                    native_executed=False, milestone_complete=False,
                    remaining=['Idle/active shutdown child composition',
                               'Actual default/all40 aggregate and broad combined-client review',
                               'Runtime/native/full gates and production adoption'])
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
                  regular_members=len(members), inventory_entries=len(inventory), source_modules=len(current),
                  all_reopened_member_bytes_exact=True, native_executed=False)
    (plan / 'task-5e3b7p6-root-archive-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
