# Disconnect replacement coordinator composition

Released after reviewed/pushed P5 at
d357c2e005150e859934f36e9da923bff1d6b1f7 (BASE). Exact39-module source map is
docs/implement-2-2-0/evidence/m2_h2_combined_coordinator_ordinary/manifest.json,
bound by task-5e3b7p5-root-commit-audit.json. Read
task-5e3b-coordinator-composition-plan-report.md phase2B first, then
task-5e3b-peer-extraction-addendum.md. This adds actual disconnect composition to
ordinary support; it does not replace later shutdown/default/all40/native work.

## Ownership and public contract

Own combined-cases/coordinator.py, test_coordinator_composition.py and necessary
test_coordinator.py support/schema checks; new evidence/coordinator-disconnect
and task-5e3b7p6-report.md. Reuse the existing composition harness/peer factories,
not duplicated child or byte peers. No other module/core/model/fixture/helper/
codec/product/pin/limit/deadline edits. A specific additional module/API gap goes
to Root before edit. Current inventory stays39 unless Root releases otherwise.
You are not alone; preserve others/all raw/source/history. No agents/external
model CLI/public/Git/native operations. Root owns review/publication/commit+push.

Support every valid ordered subset of the37 ordinary cases PLUS disconnect,
including disconnect first/middle/last. Only shutdown_idle/shutdown_active remain
unsupported, so default all40 still rejects before effects. Explicit empty and
malformed/unknown/duplicate/order/identity/type/overflow checks remain. Update
obsolete unsupported-disconnect assertions intentionally; preserve old ordinary
proofs,67ready typed controls/private facts/clock/error semantics.

Descriptor exact base fields remain identity,ready,fresh_application,connect,
close,signal,process,post; add disconnect_close IFF the actual child selection
contains disconnect. Reject missing/extra/noncallable fields before connect and
copy validated descriptor. No separate replacement or release callback/registry.
Use connect(case,case_connection_index,case_deadline,whole_deadline) for both
transports: index1 normally, index1 then2 for disconnect. Seven connection facts
and strict supplied owned/TLSv1.3/h2/now typing unchanged.

disconnect_close(context) returns the existing canonical strict-close fact graph
(ssl_unwrap/success/tcp_eofTrue/integer0trailing/normal). Read exact field names
from unchanged lifecycle validators/tests, reuse them rather than guessing a
new schema. Facts remain synthetic, not native TLS/EOF/OS ownership evidence.

## Actual replacement and protected state

Invoke actual adapter.run_case with its canonical disconnect hook contract only
for that case. Original strict termination must succeed before replacement
connect. Wrap existing hooks to validate/seal actual facts, retain private
accounting and original time bounds; no handler injection/model completion or
family check() running a separate client.

Replacement remains in the same original case/whole deadline, parser policy,
cumulative case budget and selected-before set. No new ready/case/whole/final
deadline or erased debt. Keep original caller clock/newest checked timestamps
privately across strict close and connect2; callback-mutated context deadline/
now/clock must not weaken validation or be inherited as authoritative by the
replacement. Apply P5's private-time invariant throughout, using existing core
APIs. If restoring canonical time fields is necessary for existing helper
handoff, use only validated private facts; do not add a context-freezing framework
or change immutable core. Propagate original callback exceptions unchanged.

Each transport owns independent protocol/raw/request/response-credit state;
only existing cumulative case objects are shared. None return keeps original
context/receiver; reuse keeps its receiver; disconnect must use the returned
replacement context AND that context's receive callback. Old late transport
credit must remain rejected/isolated, never affect replacement debt.

Child-owned completed IDs/output/binding survive replacement. Existing replace
helpers drop arbitrary parent fields: restore retained actual output/binding
copies before capture/finalization. Never manufacture selected facts from model
recipes, defaults or extra output GETs. Preserve private final observations,
copied callback facts, normal intermediate release and one final collection.

## Accounting and returned summaries

Child connection ordinals count actual connections1..N; factory case index stays
local. ready->disconnect gives connect indices1,1,2 and ordinals1,2,3. No global
Python-ID/FD/address uniqueness set. Existing live-original/replacement identity
check remains canonical.

Capture old connection-local stats/debt at canonical termination and before
replacement creation, protected from later exposed hooks. Sum only old LOCAL
SETTINGS/informationals into the final case snapshot; do not add old shared
heads/small/request-flow/bytes/reads twice. Cumulative case snapshot counts
disconnect once, with two connections. Checked-add case->child->run; final
registrations once. Per-connection bytes/reads are genuinely local using actual
existing counters/deltas; do not add instrumentation to immutable core or infer
wire observations by catalogue sums. Positive old/new debt is permitted.

Keep exact11 connection-summary keys and owned scalar/fact copies. Old release
is the validated copied strict-close result; replacement release is normal-close
facts. Summary count equals actual connection count; no context/codec/callback/
per-stream/frame/read histories. Other child/top-level/count/deadline meanings
stay. Only last actual connection collects final68 and supplied child teardown.

## Real proof and evidence

Use reviewed test_lifecycle.new_case_evidence/new_peer for actual two-transport
wire schedules, with shared independently earned app and case evidence. Extend
the existing real coordinator harness, not standalone lifecycle check(). Actual
proofs include:
- Ordinary->disconnect->ordinary using distinct valid IDs (no duplicate ready).
- disconnect->reuse; disconnect alone/final.
- producer_reuse->disconnect final, preserving output/B binding through replacement.
- Correct replacement receiver, independent ledgers/protocols, old-credit isolation,
  old/new local summaries, both client SETTINGS, case counts once, one final68.
- Bad strict-close facts stop before connect2; bad replacement facts/time do not
  start its wire; private original deadline/clock mutation, rollback/equality expiry,
  descriptor/callback-map mutation, retained fact loss/privacy and failure-before-
  later-case controls. Preserve all P5 ordinary/ready/empty proofs.

Contract example producer_reuse+disconnect:102heads/100small/R128,3connections,
4clientSETTINGS. Derive expectations from immutable contracts/tests; actual
serialized traffic and parsed observations must establish them. Do not mistake
static acceptance of all38 selections for actual all38/default/all40 execution.

Before edits preserve exact39baseline and capture a FRESH exhaustive prior
evidence-file hash map excluding only this new unit directory. Preserve existing
files before reuse/content-check; distinct names for every snapshot/structure/
command/run. Write actual acceptance RED first, qualify pre-effect unsupported
rejection honestly; any discovered bug gets actual RED/source before fix. No
fabricated missing history or model-seeded completion.

After final source/test edit run composition/coordinator/import checks pinned
Python -B -S normal/-O (six commands), plus unchanged suite only for a concrete
dependency. All39 AST/oneguard/actual inert empty+foreignargv imports and authored
recorders; no classes/assert/custom exceptions/hidden mutable globals/dead code/
camelCase/ignored errors/nesting>3. Keep original thresholds and callback errors.

Pinned /home/codespace/.python/current/bin/python3 SHA
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601; existing
model/core26/helper/42codecs PYTHONPATH/immutable119 entries remain. Orderedcodec
aggregate0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Graphify query before new codebase question/search/source read using exactprefix:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650
Provided paths located. Read project/role/narrow skills. No native/build/server/
socket/SSLContext/TLS-close/realclock/processownership/transfer/kernel/fault/
cancel/scheduling/interleaving/race/resource/panic/crash/leak/oldruntime execution,
installs/network. Only pinned in-memory codecs and supplied synthetic facts.
Full shutdown/default/all40/broadreview/runtime/native/twochild/adoption/milestone
gates remain later. Report exact changes/commands/raw/RED/GREEN/current-frozen/
input/history bounds/selfreview/gaps; return concise status/reportpath/checks/
concerns. Root independently reviews and owns every public/Git operation.
