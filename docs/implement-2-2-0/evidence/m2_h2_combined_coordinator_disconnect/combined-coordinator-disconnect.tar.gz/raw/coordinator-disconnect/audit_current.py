"""Audit immutable inputs, source scope and retained evidence."""
import builtins
import importlib.util
import json
from pathlib import Path
import sys
from unittest import mock


def main():
    evidence = Path(__file__).resolve().parent
    root = evidence.parents[1]
    spec = importlib.util.spec_from_file_location('prior_audit', root / 'evidence/core-peer/audit.py')
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    audit.immutable(root, evidence)
    baseline = json.loads((evidence / 'baseline-source-hashes.json').read_text())
    current = {p.name: audit.sha(p) for p in sorted(root.glob('*.py'))}
    audit.require(len(current) == 39 and set(current) == set(baseline), 'source inventory differs')
    changed = {name for name in current if current[name] != baseline[name]}
    audit.require(changed <= {'coordinator.py', 'test_coordinator.py', 'test_coordinator_composition.py'}, 'source scope differs')
    for name, digest in baseline.items():
        audit.require(audit.sha(evidence / 'before-source' / name) == digest, 'baseline differs: ' + name)
    history = json.loads((evidence / 'prior-evidence-hashes.json').read_text())
    for name, digest in history.items():
        audit.require(audit.sha(Path(name)) == digest, 'prior evidence differs: ' + name)
    audit.structure(root, evidence)
    for path in (evidence / 'audit_current.py', evidence / 'run_checks.py'):
        code = compile(path.read_text(), str(path), 'exec')
        for argv in ([], ['foreign', '--run', 'unexpected']):
            out, err = mock.Mock(), mock.Mock()
            out.write.side_effect = audit.reject
            err.write.side_effect = audit.reject
            with mock.patch.object(sys, 'argv', argv), mock.patch.object(sys, 'stdout', out), mock.patch.object(sys, 'stderr', err):
                with mock.patch.object(builtins, 'open', audit.reject), mock.patch.object(Path, 'read_bytes', audit.reject), mock.patch.object(Path, 'write_text', audit.reject):
                    exec(code, {'__name__': 'inert_helper', '__file__': str(path)})
    audit.snapshot(root, evidence, 'final-source')
    print('source=39 changed=%s prior_evidence=%d preserved; two recorders inert' % (sorted(changed), len(history)))


if __name__ == '__main__':
    main()
