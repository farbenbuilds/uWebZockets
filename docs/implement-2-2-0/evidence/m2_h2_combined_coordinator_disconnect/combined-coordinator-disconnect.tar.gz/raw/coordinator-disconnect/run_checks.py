"""Record six pinned coordinator verification commands."""
import os
import pathlib
import subprocess


def main():
    out = pathlib.Path('evidence/coordinator-disconnect')
    env = dict(os.environ)
    env['PYTHONPATH'] = '/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'
    python = '/home/codespace/.python/current/bin/python3'
    for name in ('test_coordinator_composition.py', 'test_coordinator.py', 'test_imports.py'):
        for mode in ('normal', 'optimized'):
            command = [python, '-B', '-S'] + (['-O'] if mode == 'optimized' else []) + [name]
            stem = out / ('final-' + name + '-' + mode)
            stem.with_suffix(stem.suffix + '.command').write_text('env PYTHONPATH=' + env['PYTHONPATH'] + ' ' + ' '.join(command) + '\n')
            result = subprocess.run(command, env=env, capture_output=True, text=True, check=False)
            stem.with_suffix(stem.suffix + '.stdout').write_text(result.stdout)
            stem.with_suffix(stem.suffix + '.stderr').write_text(result.stderr)
            stem.with_suffix(stem.suffix + '.exit').write_text(str(result.returncode) + '\n')
            print(name, mode, result.returncode, flush=True)


if __name__ == '__main__':
    main()
