"""Pure bounded source-provenance validation; importing performs no work."""

import hashlib
import json
import re


def require(condition, message):
    if not condition:
        raise ValueError(message)


def safe_path(path):
    require(isinstance(path, str) and bool(path), "Empty or non-string path")
    require(not path.startswith("/") and "\\" not in path, "Absolute or backslash path")
    require(not any(ord(char) < 32 or ord(char) == 127 for char in path), "Control in path")
    parts = path.split("/")
    require(all(part not in ("", ".", "..") for part in parts), "Traversal or empty component")
    require(all(":" not in part and part.lower() != ".git" for part in parts), "Unsafe component")
    return path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def hex_hash(value, length):
    require(isinstance(value, str), "Non-string hash")
    require(re.fullmatch("[0-9a-f]{" + str(length) + "}", value) is not None, "Malformed hash")
    return value


def check_bytes(data, expected, size=None):
    hex_hash(expected, 64)
    require(isinstance(data, bytes), "Non-byte source")
    require(digest(data) == expected, "Changed source bytes")
    require(size is None or type(size) is int and size >= 0 and len(data) == size, "Wrong byte count")
    return data


def inventory(rows, count):
    require(type(count) is int and 0 <= count <= 30000, "Invalid inventory count")
    require(isinstance(rows, list) and len(rows) == count, "Inventory count mismatch")
    result = {}
    for row in rows:
        require(isinstance(row, dict), "Malformed inventory row")
        path = safe_path(row["path"])
        require(path not in result, "Duplicate path")
        result[path] = hex_hash(row["sha256"], 64)
    require(all(parent not in result for path in result for parent in parents(path)), "File parent collision")
    return result


def parents(path):
    parts = path.split("/")
    return ("/".join(parts[:index]) for index in range(1, len(parts)))


def aggregate(mapping):
    payload = "".join(path + " " + mapping[path] + "\n" for path in sorted(mapping))
    return digest(payload.encode())


def exact_set(actual, expected):
    require(set(actual) == set(expected), "Missing or extra paths")


def regular_tree(raw):
    require(isinstance(raw, bytes) and raw.endswith(b"\0"), "Malformed tree listing")
    result = {}
    for record in raw[:-1].split(b"\0"):
        header, path = record.split(b"\t", 1)
        mode, kind, object_id = header.decode("ascii").split(" ")
        require(mode in ("100644", "100755") and kind == "blob", "Nonregular tree member")
        name = safe_path(path.decode("utf-8"))
        require(name not in result, "Duplicate tree path")
        result[name] = {"mode": mode, "object": hex_hash(object_id, 40)}
    return result


def git_object(kind, data):
    return hashlib.sha1(kind.encode() + b" " + str(len(data)).encode() + b"\0" + data).hexdigest()


def batch_blobs(raw, expected):
    result = {}
    offset = 0
    for object_id in expected:
        end = raw.find(b"\n", offset)
        require(end >= offset, "Missing batch header")
        header = raw[offset:end].decode("ascii").split(" ")
        require(len(header) == 3 and header[:2] == [object_id, "blob"], "Unexpected batch object")
        size = int(header[2])
        require(size >= 0, "Negative blob size")
        data = raw[end + 1:end + 1 + size]
        require(len(data) == size and raw[end + 1 + size:end + 2 + size] == b"\n", "Truncated batch")
        require(git_object("blob", data) == object_id, "Git blob identity mismatch")
        result[object_id] = data
        offset = end + 2 + size
    require(offset == len(raw), "Extra batch bytes")
    return result


def identity(actual_commit, actual_tree, expected_commit, expected_tree):
    hex_hash(actual_commit, 40)
    hex_hash(actual_tree, 40)
    require(actual_commit == expected_commit, "Wrong commit")
    require(actual_tree == expected_tree, "Wrong tree")


def tar_members(members):
    names = []
    for member in members:
        name = safe_path(member.name)
        require(member.isfile() and not member.issparse(), "Nonregular archive member")
        names.append(name)
    require(len(names) == len(set(names)), "Duplicate archive member")
    require(all(parent not in names for name in names for parent in parents(name)), "Archive parent collision")
    return names


def parse_json(data):
    return json.loads(data, object_pairs_hook=unique_pairs)


def unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key")
        result[key] = value
    return result
