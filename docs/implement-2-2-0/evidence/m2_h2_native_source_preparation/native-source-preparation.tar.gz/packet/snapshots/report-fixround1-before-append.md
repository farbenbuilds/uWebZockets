# Exact combined native source preparation

Status: **Fix round1 implementation complete; ready for scoped re-review.**
The original source exports passed their checks, but the original run did not
record protected empty directories. Its historical directory-preservation
claim is withdrawn. A fresh preparation with an actual before/after directory
baseline is recorded in the appended fix round1 section. No commit or
publication was made. Base is `cbdadc8bad2a6f1adb2dddb0b416da45caf96125` on
`feat/implement-2-2-0`. Native readiness, native execution and M2 completion
remain false.

The final fresh isolated source roots are:

- `/tmp/uwz-h2-combined-c2-fix1/candidate/`: **1,031** exact regular files,
  **103,051,479** source bytes.
- `/tmp/uwz-h2-combined-c2-fix1/libxev/`: **93** exact regular files,
  **1,347,665** source bytes.
- `/tmp/uwz-h2-combined-c2-fix1/objects.git/`: newly initialized local bare object
  database, imported only from the authenticated absolute local bundle.

The original `/tmp/uwz-h2-combined-c2/` source roots and database are retained
unchanged. The initial evidence described below remains historical evidence;
the appended section identifies final fix1 artifacts and helper hashes.

Both fresh source exports have files **0444**, directories **0555**, exact inferred
directory sets, zero additional files or directories, and every expected
SHA256. Frozen instructions/skills in candidate are data. They were neither
activated nor formatted. Original Git file modes are recorded separately in
the provenance ledger; export modes deliberately remove execution permission.

The only additional temporary children are `control-normal`,
`control-optimized`, `control-normal2`, and `control-optimized2`: bounded
miniature metadata fixtures, including deliberately changed files, symlinks
and one FIFO per full test invocation. They are retained control data, not
production/export inputs. No frozen production source was mutated for a test.

## Owned evidence and original sealed helpers

Evidence root, abbreviated **P** below:
`/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/`.
This report and P are the only workspace implementation outputs. No product,
maintained dependency pin, current45, closure119, c1 packet or old canonical
export was edited.

| Original sealed helper, retained under snapshots/fixround1-original | SHA256 | Maximum statement nesting |
|---|---|---:|
| `metadata.py` | `e02b74fc103ae5ac30318a98f83241ab1b4e469b30301ccbe5c93c1f29067430` | 1 |
| `prepare.py` | `5a812370381411285df97cc80e40d95f8f2aa62a90bfc83b995369529381c112` | 2 |
| `test_metadata.py` | `0ff8e3239f7383104651dd4e7f3c05e1353e02df4e3c91227dfab3d05cdadfda` | 1 |

These were the three original sealed helpers. There are no classes, asserts,
custom exceptions, module mutable containers or silenced unexpected errors.
Validation takes explicit inputs; effects live in preparation/audit/test CLI
boundaries. Imports and empty/foreign CLI calls are inert in normal and `-O`
modes. Prior helper versions remain under `snapshots/`; they are superseded
evidence, not alternate active implementations.

| Original sealed artifact under P | Purpose |
|---|---|
| `normal2-audit.json`, `optimized2-audit.json` | Actual per-file bytes/hash/mode inventories, ordered aggregates, packed dependency identity, remapping and preservation results |
| `normal2-origin-ledger.json`, `optimized2-origin-ledger.json` | Complete per-file origin ledger for all 1,031+93 inputs, including source object/member/snapshot facts |
| `origin-authorities.json` | Whole-archive/manifest/Git/bundle authorities for those origins and lossless large-batch reproduction facts |
| `checks-normal2.json`, `checks-optimized2.json` | Final 49 bounded negative cases, helper hashes and strict AST checks |
| `inert-final-normal.json`, `inert-final-optimized.json` | Foreign imports and empty/foreign CLI inertness, unchanged exports and protected inputs |
| `preservation-before.json` | Original before snapshot of1,704 physical file identities and regular-file path sets; no empty-directory inventory |
| `final-summary2.json` | Final bounded source/helper/storage summary; supersedes `final-summary.json` |
| `packet-manifest.json` | Retained local evidence/report inventory with explicit self/active-seal exclusions |
| `raw/`, `snapshots/` | Commands saved before execution, complete stdout/stderr/status, Git stdin/query receipts, restoration receipts and all intermediate helpers/failures |

The final normal and optimized audit JSON files are byte-identical, as are
their origin ledgers. They also retain the same export facts as the earlier
normal audit. The final checks add an exact directory-set invariant and an
extra-empty-directory negative without changing source bytes.

## Authenticated source reconstruction

The published c1 manifest was read as the exact Git blob at base
`cbdadc8bad2a6f1adb2dddb0b416da45caf96125` and compared byte-for-byte with its
published file. The complete c1 archive was hashed before any members were
used. Its `INVENTORY.json` and every regular member were checked. Local c1
candidate/dependency/input indexes equal their embedded authenticated bytes.
The metadata-live and fixture manifests were separately compared with exact
Git blobs at `58bc6d6a525e01380ccc7bf3802e695c07877e89`; complete archives were
hashed before members, and their inventories/member hashes were checked.

| Input | Bytes | SHA256 |
|---|---:|---|
| Published `combined-input-audit.tar.gz` | 5,794,648 | `4c4d93bdec76e4b302a38e5811062b48100df0b617f479fe17eac1bdaa6105c8` |
| `metadata-live.tar.gz` | 8,415,267 | `a08dbf448de76b3642816b0eed9388b59d83356b0d3d1fc8a7025b3718ec7d59` |
| `combined-fixture.tar.gz` | 1,601,430 | `c731e84571477286905ed9116fe8f3e6d820d492e6696fb3382947def8cb38c9` |
| `epoll-registration-rollback.bundle` | 1,471,282 | `6f9f27199b2cc4bf47e7f04fd3d1862362899be283d84ec1e97c614b69a03580` |

Candidate ordered aggregate:
`fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`.
The algorithm is SHA256 of
`json.dumps(list(inventory.items())).encode()` in the exact fixture inventory
order. Both final Debug/ReleaseSafe fixture receipts agree on the complete
before/after1,031 inventories and order. The candidate is reconstructed from:

1. **982 exact base Git blobs** at
   `30f27ab80f0471437c34adcdf7b2d42f58227b74`. Exact selected `ls-tree -r -z`
   output proves each selected path is a regular blob and binds mode/object
   ID. `cat-file --batch` proves each blob's framing, byte count, SHA1 object
   identity, SHA256 and final expected bytes. The blob object ID equals c1's
   per-path base-object ID; no current Root filename substitutes for a blob.
2. **40 delta source members** from authenticated metadata-live
   `candidate/source/`, with `candidate/delta.json`'s exact base commit,
   candidate digest, paths and base/candidate hashes. Added paths retain their
   absent-base identity. Source members match their individual hashes before
   export.
3. **Nine named preserved snapshots**, each bound by authenticated
   `inputs/restoration-provenance.json`, its literal `preserved-snapshot:`
   origin, c1's absolute path, source byte count and final SHA256:
   `README.md`, `docs/adr/0008-request-body-streaming.md` and
   `docs/deployment.md` from upload-platform/implementation/final;
   `docs/implement-2-2-0/README.md`, its
   `evidence/m2_h1_retirement_v6/README.md`, `m2_loop_callback_adapter.md` and
   `m2_request_streaming.md` from drafts/m2-h1-baseline;
   `m1_streaming_static_tls.md` from drafts/m2-h1-transport-legacy; and
   `tests/package_consumer/main.zig` from configured-https/implementation/snapshot.
   The ledger records every exact absolute source path. No recovery search or
   matching-name substitution was used.

All origins are validated before candidate filesystem effects. Export uses
exclusive new files; existing destinations and mismatches are rejected.

## Packed historical libxev

The93-file metadata-live identity equals c1's dependency identity and both
fixture override-before/after inventories. The bundle was authenticated before
the isolated Git initialization/import. Every Git command disables hooks,
fsmonitor, optional locks and system/global Git configuration; no remote or URL
was configured. Initialization used an empty template, so no hook directory was
installed. The database contains one pack, **3,192 packed objects**, zero loose
objects and zero garbage.

Actual resolved and raw-object-verified identities:

- Commit `c223bd886c6a51d2cd60def39dd9a68d701fea73`.
- Tree `86c6944f53dc009d7503a9ab0bc873aef3cd7b79`.

Raw commit and tree bytes reproduce their Git SHA1 IDs. `git fsck --full
--strict --no-reflogs` passed against that exact commit. Recursive packed tree
enumeration contains exactly the93 expected regular blobs, with no symlink or
gitlink. All93 packed blob SHA1 IDs and source SHA256s match before export;
all93 actual exported bytes and modes match afterward. The libxev ordered
aggregate, using the retained metadata identity order, is
`4ce6e5ad1a0ae954352ea1e8890cc82c2a57509102c4eaa3cd434735613df6f9`.

Historical c223 is an isolated test dependency. This does not adopt it into
production or change any maintained fork/pin policy.

## Preserved inputs and exact command evidence

The new temporary root was absent at the initial recorded check; neither
failed preparation attempt created it. Before substantive export work,
`preservation-before.json` froze current45, closure119, ordered42 codecs,
the complete existing c1 packet/published c1 files, retained scoped inputs,
original candidate regular-file path set and tracked product/build/pin files.
All1,704 physical file identities and the recorded regular-file sets are
unchanged afterward. The original snapshot did not inventory empty directories;
its `directories` values are file lists. Unchanged directory sets cannot be
claimed for the original preparation, and later captures cannot repair that
historical evidence gap.
Declared119 remains119, with118 physical authority rows,113 resolved files,
42 ordered codecs and digest
`0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`.
The original `/tmp/uwz-task4d-fix1-frozen` still has its four original files;
none of its1,027 missing files was filled. The original
`/tmp/uwz-reviewed-libxev-c223-loop-callbacks` remains absent, including no
dangling symlink. Current45/c1 source helpers were read/hashed, not executed.
Root's independent audit of the broader preceding19,808 identities remains a
separate review input; this helper did not repeat the SDK/source-all40 audit.

All direct Python uses
`/home/codespace/.python/current/bin/python3 -B -S`, SHA256
`4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`.
Every dependent Python shell starts with `set -e`, exports
`PYTHONDONTWRITEBYTECODE=1`, then invokes the exact pinned
`task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT` before dependent
operations in that same shell. Every retained receipt reports restored0 and
118 rows/113 files/42 ordered codecs. No alternate interpreter, runtime source
import, network or installation was used.

Each command below is retained under P/raw as its exact `.sh`, `.stdout`,
`.stderr` and `.exit`; each Git subprocess additionally retains argv,
stdin bytes/hash, complete stdout/stderr and original exit status before its
result is interpreted.

| Recorded attempt | Actual outcome |
|---|---|
| `01-context.sh` | exit2: context/skills/report read succeeded; deliberate initial `ls` confirmed newTMP absent |
| `02-context.sh` | exit0: actual role TOML, required build/vendor context capture and pinned Python hash |
| `03-inspect.sh` through `09-aggregate.sh` | exit0: bounded supplied-index/archive schema/order reads; no reconstruction |
| `10-freeze-unit.sh` | exit0: preservation freeze and37 pure bounded negative checks |
| `11-prepare.sh` | exit1: c1 inventory is uppercase `INVENTORY.json`; exact `KeyError`/helper original retained; no export/database created |
| `12-c1-inventory-name.sh` | exit0: authenticated whole archive then bounded actual inventory-name/schema read |
| `13-prepare.sh` | exit1: snapshot provenance uses literal `preserved-snapshot:` relative-path format; exact error/helper original retained; no export/database created |
| `14-provenance-prefix.sh` | exit0: authenticated whole metadata archive then exact nine provenance strings |
| `15-prepare.sh` | exit0: exact source export, bundle-only isolated import, packed verification, full export/preservation audit |
| `16-normal.sh`, `17-optimized.sh` | exit0: initial48 bounded negative cases and complete actual export audit per mode |
| `18-inert.sh` | exit0: initial normal/optimized foreign imports and empty/foreign CLI inertness |
| `19-summary.sh`, `20-authorities.sh` | exit0: bounded packed storage/authority/source/helper summaries |
| `21-final-checks.sh` | exit0: final49 negative cases and complete source/file+directory/packed audit in normal and `-O` modes |
| `22-inert-final.sh` | exit0: final helper import/CLI inertness, byte-identical normal2/optimized2 inventories/ledgers, unchanged exports/protected inputs |
| `23-seal.sh` | Final evidence/report inventory and preservation seal; exact result retained beside the script |

The two failed preparations were not silently retried: both original commands,
statuses, errors, outputs and pre-correction helper versions remain. The
source root was created only by the successful third attempt. The aggregate
format was corrected before first execution after a bounded read of the
already-located c1 implementation; its unexecuted prior helper remains under
snapshots. Self-review later strengthened the directory-path invariant and
absent-old-root check; preceding successful48-case helpers/results also remain.

Initial context-only reads occurred before durable per-command logging. One
attempt used nonexistent `.codex/agents/build_vendor.md`; the actual file is
`build_vendor.toml`. The combined context console output was truncated and its
original complete stdout was not saved. `raw/00-bootstrap-notes.txt` records
this limitation; missing original statuses/output are not invented. All
substantive schema/origin queries, helper runs, failures, preparation and final
audits have durable original logs. Edits used the patch tool; pre-correction
and pre-execution helper bytes are retained independently.

The six retained982-blob batch streams are each101,829,106 bytes with SHA256
`af7d265c4d2aaf9b1e782749096fa496e9e2fa2ef1192f5ef63b600109661a66`.
They remain intact locally. Each command receipt and exact ordered stdin binds
lossless reproduction from immutable base Git blobs. No candidate tree or
large raw stream was duplicated into a publication by this task; Root owns
any later immutable-reference publication.

## Regression evidence, self-review and limits

Final normal and `-O` runs each pass **49** bounded negative checks. They reject
changed origin/export bytes, malformed hashes/sizes/counts/rows, missing or
extra files, an extra empty directory, duplicate and parent-colliding paths,
duplicate JSON keys, absolute/traversal/backslash/control paths, changed
commit/tree identities, symlink/gitlink/nonregular packed entries, malformed
packed blobs, duplicate/traversing/symlink/hardlink/directory/FIFO/device archive
members, source symlinks/symlink ancestors/nonregular files, existing export
destinations and changed export modes. Positive miniature inventories and
packed blobs also pass. Negative fixtures are bounded and retained under the
explicit new temporary control paths; production bytes remain untouched.

Normal and optimized foreign-import tests execute only the three owned
metadata helpers, under foreign module names. They invoke empty and foreign
CLI inputs, capture zero stdout/stderr, verify no owned paths changed, and
re-audit the exact exports and preservation snapshot. Native sources and
their frozen skills were never imported or executed.

Self-review separates authenticity, reconstructed source availability and
runtime readiness. Whole-archive hashes precede member reads; immutable Git
objects precede base export; source-origin validation precedes writes;
exclusive writes prevent repair-by-overwrite; exact file and inferred
directory sets, byte hashes and immutable modes are audited afterward. The
bundle import never uses a Root Git write or remote. Read-only Git metadata
queries and the expressly authorized isolated metadata operations are the
only Git work. No agent was spawned, no commit/tag/push was made, no existing
evidence/library/cache/worktree/source was removed and no gate was weakened.

No compiler, library, candidate/toolchain code, native target process, server,
socket, SSLContext, clock/TLS-close path, old runtime suite or source-all40
suite ran. The full project formatting/build/test/sanitizer/fuzz/package/
protocol/platform gates remain required later. This source-only slice does
not run or waive those native gates, and makes no performance claim. The
ignored evidence helpers do not alter the product knowledge graph; Root owns
any graph refresh accompanying later publication.

If this exact newTMP disappears, an approved later preparation can rerun the
owned `prepare.py --prepare` with a fresh unused evidence label after the
same-shell pinned119 restoration protocol. The CLI accepts only this exact
newTMP root and refuses an existing destination. It never silently repairs
changed or partially present source trees. Any alternate source-root mapping
or build recipe needs explicit declaration and exact byte bindings.

Next released work remains separate: independent Root review/publication and
immediate checkpoint push; native EOF contract/provider work; fresh
interpreter/loader/SSL/OpenSSL runtime closure; explicitly remapped fresh
Debug/ReleaseSafe builds; native all40 under its authorization; full project
and platform gates; production adoption; and every remaining original
milestone. Exact returned-error ownership, physical lifetime coverage, H3,
multipart and genuine early data are not closed by copied source files.
