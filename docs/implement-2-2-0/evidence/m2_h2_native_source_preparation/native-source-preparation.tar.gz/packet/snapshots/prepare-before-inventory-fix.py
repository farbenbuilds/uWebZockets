"""Explicit source-only freeze, preparation and audit CLI; foreign use is inert."""

import os
from pathlib import Path
import stat
import subprocess
import sys
import tarfile

import metadata as m


def write_json(path, value):
    import json
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + "\n")


def regular_file(path):
    for parent in (path, *path.parents):
        m.require(not parent.is_symlink(), "Symlink source or ancestor: " + str(parent))
    m.require(stat.S_ISREG(path.lstat().st_mode), "Nonregular source: " + str(path))
    return path.read_bytes()


def run_git(root, output, label, arguments, git_dir=None, stdin=b""):
    prefix = ["git", "--no-optional-locks", "-c", "core.hooksPath=/dev/null", "-c", "core.fsmonitor=false"]
    location = ["-C", str(root)] if git_dir is None else ["--git-dir=" + str(git_dir)]
    argv = prefix + location + arguments
    environment = {key: value for key, value in os.environ.items() if not key.startswith("GIT_")}
    environment.update(GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL="/dev/null", GIT_CONFIG_SYSTEM="/dev/null",
                       GIT_TERMINAL_PROMPT="0", GIT_OPTIONAL_LOCKS="0", LC_ALL="C")
    target = output / "raw" / label
    write_json(target.with_suffix(".command.json"), dict(argv=argv, stdin_sha256=m.digest(stdin),
               stdin_bytes=len(stdin), environment_policy="Inherited non-Git variables; disabled Git system/global config, hooks, fsmonitor and optional locks"))
    with target.with_suffix(".stdin").open("xb") as stream:
        stream.write(stdin)
    result = subprocess.run(argv, input=stdin, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            env=environment, check=False)
    target.with_suffix(".stdout").write_bytes(result.stdout)
    target.with_suffix(".stderr").write_bytes(result.stderr)
    target.with_suffix(".exit").write_text(str(result.returncode) + "\n")
    m.require(result.returncode == 0, "Git failed; retained " + str(target))
    return result.stdout


def observed(path):
    if not path.exists() and not path.is_symlink():
        return dict(path=str(path), status="absent")
    data = regular_file(path)
    return dict(path=str(path), status="regular", bytes=len(data), sha256=m.digest(data),
                mode=oct(stat.S_IMODE(path.lstat().st_mode)))


def walk_regular(root):
    m.require(root.is_dir() and not root.is_symlink(), "Nonregular source directory")
    result = []
    for directory, directories, files in os.walk(root, followlinks=False):
        m.require(not any((Path(directory) / name).is_symlink() for name in directories), "Symlink directory")
        for name in files:
            path = Path(directory) / name
            regular_file(path)
            result.append(path)
    return sorted(result)


def freeze(root, output):
    audit = root / ".uwz-work/evidence/h2-streaming/combined-interface-audit"
    index = m.parse_json(regular_file(audit / "final-input-index.json"))
    protected = [Path(row["path"]) for row in index["paths"]
                 if any(alias["role"] != "SDK tree" for alias in row["aliases"])]
    protected.extend(walk_regular(audit))
    packet = root / "docs/implement-2-2-0/evidence/m2_h2_combined_input_audit"
    protected.extend(walk_regular(packet))
    protected.append(root / ".superpowers/sdd/h2_streaming_plan/task-5e3c1-report.md")
    scopes = ["src", "builds", "include", "examples", "tests", "fuzz", "build.zig", "build.zig.zon",
              "build.zig.zon.json", "build.zig.zon.nix", "build.zig.zon.txt", ".gitmodules", "flake.nix"]
    raw = run_git(root, output, "freeze-tracked", ["ls-files", "-z", "--", *scopes])
    protected.extend(root / name.decode() for name in raw.split(b"\0") if name)
    head = run_git(root, output, "freeze-head", ["rev-parse", "HEAD"]).decode().strip()
    m.require(head == "cbdadc8bad2a6f1adb2dddb0b416da45caf96125", "Wrong Root checkpoint")
    directories = (audit, packet, Path("/tmp/uwz-task4d-fix1-frozen"))
    roots = {str(path): [str(item) for item in walk_regular(path)] for path in directories}
    m.require(not Path("/tmp/uwz-reviewed-libxev-c223-loop-callbacks").exists(), "Old libxev path appeared")
    write_json(output / "preservation-before.json", dict(head=head, files=[observed(p) for p in sorted(set(protected))],
               directories=roots, old_libxev_absent=True, closure=index["closure"]))
    print("Frozen protected source identities, current45/119 closure, c1 packet and original source paths")


def inventory_rows(data):
    if isinstance(data, dict) and "files" in data:
        return data["files"]
    m.require(isinstance(data, dict), "Malformed archive inventory")
    return [dict(path=path, **value) for path, value in data.items()]


def archive_members(path, expected_hash, expected_bytes=None):
    m.check_bytes(regular_file(path), expected_hash, expected_bytes)
    with tarfile.open(path, "r:gz") as archive:
        names = m.tar_members(archive.getmembers())
        members = {name: archive.extractfile(name).read() for name in names}
    rows = inventory_rows(m.parse_json(members["inventory.json"]))
    hashes = m.inventory(rows, len(rows))
    m.exact_set(members, [*hashes, "inventory.json"])
    for row in rows:
        m.check_bytes(members[row["path"]], row["sha256"], row.get("bytes", row.get("size")))
    return members


def published_inputs(root, output, label):
    relative = "docs/implement-2-2-0/evidence/m2_h2_combined_input_audit/manifest.json"
    anchor = "cbdadc8bad2a6f1adb2dddb0b416da45caf96125"
    raw = run_git(root, output, label + "-c1-manifest", ["cat-file", "blob", anchor + ":" + relative])
    m.require(raw == regular_file(root / relative), "Published c1 manifest drift")
    manifest = m.parse_json(raw)
    archive = (root / relative).parent / manifest["archive"]
    members = archive_members(archive, manifest["archive_sha256"], manifest["archive_bytes"])
    names = ("final-candidate-reconstruction.json", "dependency-audit.json", "final-input-index.json")
    audit = root / ".uwz-work/evidence/h2-streaming/combined-interface-audit"
    for name in names:
        m.require(members["packet/" + name] == regular_file(audit / name), "Local c1 index drift")
    return tuple(m.parse_json(members["packet/" + name]) for name in names)


def historical_archives(root, output, index, label):
    result = {}
    for name in ("m2_h2_metadata_live", "m2_h2_combined_fixture"):
        authority = index["authorities"][name]
        manifest_path = Path(authority["manifest"])
        relative = str(manifest_path.relative_to(root))
        commit = index["published_manifests_git_anchor"]["commit"]
        raw = run_git(root, output, label + "-" + name, ["cat-file", "blob", commit + ":" + relative])
        m.check_bytes(raw, authority["manifest_sha256"])
        m.require(raw == regular_file(manifest_path), "Historical manifest drift")
        manifest = m.parse_json(raw)
        m.require(manifest["archive_sha256"] == authority["archive_sha256"], "Archive authority differs")
        result[name] = archive_members(Path(authority["archive"]), authority["archive_sha256"], manifest["archive_bytes"])
    return result


def source_inventories(candidate, dependency, archives):
    rows = candidate["files"]
    expected = m.inventory([dict(path=r["path"], sha256=r["expected_sha256"]) for r in rows], 1031)
    m.require(candidate["expected_count"] == 1031 and candidate["delta_files"] == 40, "Wrong candidate counts")
    m.require(candidate["base"] == "30f27ab80f0471437c34adcdf7b2d42f58227b74", "Wrong candidate base")
    m.require(m.aggregate(expected) == candidate["aggregate_sha256"] ==
              "fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de", "Wrong ordered candidate aggregate")
    members = archives["m2_h2_metadata_live"]
    identity = m.parse_json(members["inputs/immutable-libxev-input.json"])
    m.require(identity == dependency["identity"], "Historical dependency identity differs")
    libxev = m.inventory([dict(path=p, sha256=h) for p, h in identity["files_sha256"].items()], 93)
    for mode in ("debug", "release"):
        name = "builds/uwz-task5e2-Fix1Final2/" + mode + "-receipt.json"
        receipt = m.parse_json(archives["m2_h2_combined_fixture"][name])
        m.require(receipt["source_before"] == receipt["source_after"] == expected, "Fixture candidate differs")
        m.require(list(receipt["source_before"].items()) == list(expected.items()), "Candidate order differs")
        m.require(receipt["override_before"] == receipt["override_after"] == libxev, "Fixture dependency differs")
    return expected, libxev, identity


def base_sources(root, output, candidate, label):
    rows = [row for row in candidate["files"] if row["reconstruction"]["status"] == "available-matching"
            and row["reconstruction"]["source"] == "exact base Git blob" and "supplement" not in row]
    m.require(len(rows) == 982, "Wrong base-origin count")
    raw = run_git(root, output, label + "-base-tree", ["ls-tree", "-r", "-z", candidate["base"], "--", *[r["path"] for r in rows]])
    tree = m.regular_tree(raw)
    m.exact_set(tree, [r["path"] for r in rows])
    object_ids = [tree[row["path"]]["object"] for row in rows]
    raw = run_git(root, output, label + "-base-blobs", ["cat-file", "--batch"], stdin=("\n".join(object_ids) + "\n").encode())
    blobs = m.batch_blobs(raw, object_ids)
    sources = {}
    for row in rows:
        source = tree[row["path"]]
        m.require(source["object"] == row["base_object"]["object"], "Base tree/object mismatch")
        data = m.check_bytes(blobs[source["object"]], row["expected_sha256"], row["base_object"]["bytes"])
        sources[row["path"]] = (data, dict(kind="base Git blob", commit=candidate["base"], **source))
    return sources


def supplemental_sources(candidate, members, sources):
    delta = m.parse_json(members["candidate/delta.json"])
    m.require(delta["base_commit"] == candidate["base"] and delta["candidate_source_digest"] == candidate["aggregate_sha256"], "Delta identity differs")
    changes = {row["path"]: row for row in delta["files"]}
    m.require(len(changes) == len(delta["files"]) == 40, "Wrong delta count")
    provenance = m.parse_json(members["inputs/restoration-provenance.json"])["provenance"]
    for row in candidate["files"]:
        add_origin(row, members, sources, changes, provenance)
    m.require(sum(item[1]["kind"] == "metadata delta member" for item in sources.values()) == 40, "Missing delta origins")
    m.require(sum(item[1]["kind"] == "named snapshot" for item in sources.values()) == 9, "Missing snapshot origins")
    return sources


def add_origin(row, members, sources, changes, provenance):
    path = row["path"]
    if path in sources:
        return
    if path in changes:
        change = changes[path]
        m.require(change["candidate_sha256"] == row["expected_sha256"], "Delta target differs")
        m.require(change["base_sha256"] == row["base_object"].get("sha256"), "Delta base differs")
        origin = row["reconstruction"]["source"]
        m.require(origin["archive"] == "m2_h2_metadata_live" and origin["member"] == "candidate/source/" + path, "Wrong delta member")
        data = m.check_bytes(members[origin["member"]], row["expected_sha256"])
        sources[path] = (data, dict(kind="metadata delta member", **origin, base=change))
        return
    supplement = row["supplement"]
    authority = supplement["authority"]
    m.require(authority["archive"] == "m2_h2_metadata_live" and authority["member"] == "inputs/restoration-provenance.json", "Wrong snapshot authority")
    m.check_bytes(members[authority["member"]], authority["member_sha256"])
    m.require(provenance[path] == supplement["path"], "Wrong named snapshot origin")
    data = m.check_bytes(regular_file(Path(supplement["path"])), row["expected_sha256"], supplement["observed"]["bytes"])
    sources[path] = (data, dict(kind="named snapshot", path=supplement["path"], authority=authority))


def dependency_sources(root, output, temporary, dependency, expected, label, initialize):
    bundle = root / ".uwz-work/evidence/h2-streaming/combined-interface-audit/epoll-registration-rollback.bundle"
    m.check_bytes(regular_file(bundle), "6f9f27199b2cc4bf47e7f04fd3d1862362899be283d84ec1e97c614b69a03580", 1471282)
    database = temporary / "objects.git"
    if initialize:
        m.require(not database.exists(), "Object database already exists")
        run_git(root, output, label + "-git-init", ["init", "--bare", "--template=", "--initial-branch=source-evidence", str(database)])
        run_git(root, output, label + "-bundle-import", ["bundle", "unbundle", str(bundle)], database)
    identity = dependency["identity"]
    commit = identity["commit"]
    actual = run_git(root, output, label + "-commit", ["rev-parse", "--verify", commit + "^{commit}"], database).decode().strip()
    tree = run_git(root, output, label + "-tree", ["rev-parse", "--verify", commit + "^{tree}"], database).decode().strip()
    m.identity(actual, tree, "c223bd886c6a51d2cd60def39dd9a68d701fea73", "86c6944f53dc009d7503a9ab0bc873aef3cd7b79")
    raw_commit = run_git(root, output, label + "-raw-commit", ["cat-file", "commit", commit], database)
    m.require(m.git_object("commit", raw_commit) == commit and raw_commit.startswith(("tree " + tree + "\n").encode()), "Packed commit mismatch")
    raw_tree = run_git(root, output, label + "-raw-tree", ["cat-file", "tree", tree], database)
    m.require(m.git_object("tree", raw_tree) == tree, "Packed tree mismatch")
    run_git(root, output, label + "-fsck", ["fsck", "--full", "--strict", "--no-reflogs", commit], database)
    raw = run_git(root, output, label + "-libxev-tree", ["ls-tree", "-r", "-z", commit], database)
    listing = m.regular_tree(raw)
    m.exact_set(listing, expected)
    object_ids = [value["object"] for value in listing.values()]
    raw = run_git(root, output, label + "-libxev-blobs", ["cat-file", "--batch"], database, ("\n".join(object_ids) + "\n").encode())
    blobs = m.batch_blobs(raw, object_ids)
    sources = {path: (m.check_bytes(blobs[value["object"]], expected[path]), dict(kind="packed Git blob", commit=commit, tree=tree, **value))
               for path, value in listing.items()}
    return sources, dict(commit=commit, tree=tree, fsck="full strict passed", packed_root_tree_sha1=tree)


def validate_sources(sources, expected):
    m.exact_set(sources, expected)
    for path, (data, origin) in sources.items():
        m.safe_path(path)
        m.require(isinstance(origin, dict) and bool(origin), "Missing origin")
        m.check_bytes(data, expected[path])


def export_sources(destination, sources, expected):
    validate_sources(sources, expected)
    m.require(not destination.exists() and not destination.is_symlink(), "Refusing existing export")
    destination.mkdir(mode=0o700)
    for path, (data, _) in sources.items():
        target = destination / path
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(data)
        target.chmod(0o444)
    for directory, _, _ in os.walk(destination, topdown=False):
        Path(directory).chmod(0o555)


def audit_export(destination, expected):
    paths = walk_regular(destination)
    actual = {str(path.relative_to(destination)): observed(path) for path in paths}
    m.exact_set(actual, expected)
    for path, row in actual.items():
        m.require(row["sha256"] == expected[path] and row["mode"] == "0o444", "Changed export bytes or file mode")
    for directory, _, _ in os.walk(destination):
        m.require(stat.S_IMODE(Path(directory).lstat().st_mode) == 0o555, "Changed export directory mode")
    ordered = {path: actual[path]["sha256"] for path in expected}
    return dict(count=len(actual), extras=[], missing=[], ordered_aggregate_sha256=m.aggregate(ordered),
                files=[dict(path=path, bytes=actual[path]["bytes"], sha256=expected[path], mode="0444") for path in expected], directories_mode="0555")


def preservation(output):
    before = m.parse_json(regular_file(output / "preservation-before.json"))
    after = [observed(Path(row["path"])) for row in before["files"]]
    m.require(after == before["files"], "Protected input changed")
    for root, expected in before["directories"].items():
        m.require([str(path) for path in walk_regular(Path(root))] == expected, "Protected path set changed")
    m.require(not Path("/tmp/uwz-reviewed-libxev-c223-loop-callbacks").exists(), "Old libxev path appeared")
    return dict(unchanged=True, physical_identities=len(after), closure=before["closure"],
                original_candidate_files=4, old_libxev_absent=True, protected_directories=before["directories"])


def execute(root, output, temporary, label, initialize):
    m.require(temporary == Path("/tmp/uwz-h2-combined-c2"), "Unauthorized temporary destination")
    if initialize:
        m.require(not temporary.exists() and not temporary.is_symlink(), "Temporary preparation root already exists")
    candidate, dependency, index = published_inputs(root, output, label)
    archives = historical_archives(root, output, index, label)
    expected_candidate, expected_dependency, _ = source_inventories(candidate, dependency, archives)
    candidate_sources = base_sources(root, output, candidate, label)
    supplemental_sources(candidate, archives["m2_h2_metadata_live"], candidate_sources)
    validate_sources(candidate_sources, expected_candidate)
    preservation(output)
    if initialize:
        temporary.mkdir(mode=0o700)
    dependency_data, packed = dependency_sources(root, output, temporary, dependency, expected_dependency, label, initialize)
    validate_sources(dependency_data, expected_dependency)
    if initialize:
        export_sources(temporary / "candidate", candidate_sources, expected_candidate)
        export_sources(temporary / "libxev", dependency_data, expected_dependency)
    actual_candidate = audit_export(temporary / "candidate", expected_candidate)
    actual_dependency = audit_export(temporary / "libxev", expected_dependency)
    m.require(actual_candidate["ordered_aggregate_sha256"] == candidate["aggregate_sha256"], "Export aggregate mismatch")
    ledger = {"candidate": origin_ledger(candidate_sources, expected_candidate),
              "libxev": origin_ledger(dependency_data, expected_dependency)}
    write_json(output / (label + "-origin-ledger.json"), ledger)
    write_json(output / (label + "-audit.json"), dict(candidate=actual_candidate, libxev=actual_dependency,
               packed_dependency=packed, preservation=preservation(output), native_executed=False, native_ready=False,
               source_roots=dict(candidate=str(temporary / "candidate"), libxev=str(temporary / "libxev")),
               remapping="Later approved builds must declare exact source-root remapping and new recipes"))
    print("Verified exact candidate1031 (982 Git +40 delta +9 snapshots), isolated packed c223 libxev93, zero extras, immutable modes and preservation")


def origin_ledger(sources, expected):
    return [dict(path=path, bytes=len(sources[path][0]), sha256=expected[path], origin=sources[path][1]) for path in expected]


def main(arguments):
    if len(arguments) != 6 or arguments[1] not in ("--freeze", "--prepare", "--audit"):
        return
    root, output, temporary = (Path(value) for value in arguments[2:5])
    label = arguments[5]
    m.require(root == Path("/workspaces/uWebZockets") and output == root / ".uwz-work/evidence/h2-streaming/native-input-preparation", "Unauthorized workspace/evidence destination")
    m.require(label.isascii() and label.replace("-", "").isalnum(), "Invalid evidence label")
    if arguments[1] == "--freeze":
        freeze(root, output)
        return
    execute(root, output, temporary, label, arguments[1] == "--prepare")


if __name__ == "__main__":
    main(sys.argv)
