"""Bounded metadata regressions for owned helpers; never imports frozen sources."""

import ast
from pathlib import Path
import sys
import tarfile

import metadata as m
import prepare as p


def reject(name, operation):
    try:
        operation()
    except (ValueError, KeyError, TypeError):
        return name
    raise ValueError("Negative check accepted: " + name)


def pure_checks():
    data = b"bounded metadata fixture\n"
    good = m.digest(data)
    rows = [dict(path="src/a.zig", sha256=good)]
    m.require(m.inventory(rows, 1) == {"src/a.zig": good}, "Valid inventory rejected")
    m.check_bytes(data, good, len(data))
    checks = [reject("changed origin bytes", lambda: m.check_bytes(data + b"x", good)),
              reject("malformed hash", lambda: m.check_bytes(data, "0")),
              reject("wrong size", lambda: m.check_bytes(data, good, 1)),
              reject("missing inventory row", lambda: m.inventory(rows, 2)),
              reject("extra inventory row", lambda: m.inventory(rows, 0)),
              reject("duplicate path", lambda: m.inventory(rows + rows, 2)),
              reject("malformed row", lambda: m.inventory([{}], 1)),
              reject("malformed count", lambda: m.inventory(rows, True)),
              reject("file parent collision", lambda: m.inventory(rows + [dict(path="src/a.zig/b", sha256=good)], 2)),
              reject("missing or extra path", lambda: m.exact_set({"a": good}, {"b": good})),
              reject("duplicate JSON key", lambda: m.parse_json(b'{"x":1,"x":2}'))]
    for path in ("/absolute", "../escape", "a/../b", "a//b", "./a", "a\\b", "C:/a", ".git/config", "a\x00b", "a/", "a\nb"):
        checks.append(reject("unsafe path " + repr(path), lambda value=path: m.safe_path(value)))
    commit, tree = "1" * 40, "2" * 40
    checks.append(reject("wrong commit", lambda: m.identity(tree, tree, commit, tree)))
    checks.append(reject("wrong tree", lambda: m.identity(commit, commit, commit, tree)))
    for mode, kind in (("120000", "blob"), ("160000", "commit"), ("040000", "tree")):
        raw = (mode + " " + kind + " " + commit + "\ta\0").encode()
        checks.append(reject("nonregular packed tree " + mode, lambda value=raw: m.regular_tree(value)))
    blob = m.git_object("blob", data)
    raw = (blob + " blob " + str(len(data)) + "\n").encode() + data + b"\n"
    m.require(m.batch_blobs(raw, [blob])[blob] == data, "Valid packed blob rejected")
    checks.append(reject("changed packed blob", lambda: m.batch_blobs(raw.replace(data, b"x" * len(data)), [blob])))
    checks.append(reject("truncated packed blob", lambda: m.batch_blobs(raw[:-1], [blob])))
    checks.append(reject("extra packed bytes", lambda: m.batch_blobs(raw + b"x", [blob])))
    checks.extend(archive_checks())
    return checks


def archive_checks():
    regular = tarfile.TarInfo("src/a.zig")
    m.tar_members([regular])
    checks = [reject("duplicate archive member", lambda: m.tar_members([regular, regular]))]
    for kind in (tarfile.SYMTYPE, tarfile.LNKTYPE, tarfile.DIRTYPE, tarfile.FIFOTYPE, tarfile.CHRTYPE):
        member = tarfile.TarInfo("src/b")
        member.type = kind
        checks.append(reject("nonregular archive " + repr(kind), lambda value=member: m.tar_members([value])))
    traversal = tarfile.TarInfo("../outside")
    checks.append(reject("archive traversal", lambda: m.tar_members([traversal])))
    return checks


def file_checks(control):
    m.require(not control.exists(), "Refusing existing miniature test control directory")
    control.mkdir(mode=0o700)
    target = control / "original"
    target.write_bytes(b"original\n")
    link = control / "symlink"
    link.symlink_to(target)
    checks = [reject("symlink source", lambda: p.regular_file(link)),
              reject("directory as source", lambda: p.regular_file(control))]
    link_directory = control / "symlink_directory"
    link_directory.symlink_to(control, target_is_directory=True)
    checks.append(reject("symlink ancestor", lambda: p.regular_file(link_directory / "original")))
    expected = {"src/a.zig": m.digest(b"a"), "src/b.zig": m.digest(b"b")}
    sources = {path: (path[-5].encode(), {"kind": "miniature"}) for path in expected}
    sources = {"src/a.zig": (b"a", {"kind": "miniature"}), "src/b.zig": (b"b", {"kind": "miniature"})}
    valid = control / "valid"
    p.export_sources(valid, sources, expected)
    m.require(p.audit_export(valid, expected)["count"] == 2, "Valid miniature export rejected")
    checks.append(reject("existing export refused", lambda: p.export_sources(valid, sources, expected)))
    checks.append(reject("changed origin before export", lambda: p.validate_sources({"src/a.zig": (b"x", {"kind": "miniature"}), "src/b.zig": sources["src/b.zig"]}, expected)))
    checks.extend(changed_exports(control, sources, expected))
    return checks


def changed_exports(control, sources, expected):
    checks = []
    for name in ("changed", "missing", "extra", "symlink", "nonregular", "mode"):
        destination = control / ("export_" + name)
        p.export_sources(destination, sources, expected)
        miniature_change(destination, name)
        checks.append(reject("export " + name, lambda value=destination: p.audit_export(value, expected)))
    return checks


def miniature_change(destination, name):
    source = destination / "src/a.zig"
    source.parent.chmod(0o755)
    source.chmod(0o644)
    if name == "changed":
        source.write_bytes(b"changed")
        source.chmod(0o444)
        return
    if name == "extra":
        (source.parent / "extra").write_bytes(b"extra")
        return
    if name == "mode":
        return
    source.unlink()
    if name == "symlink":
        source.symlink_to("b.zig")
        return
    if name == "nonregular":
        import os
        os.mkfifo(source)


def node_depth(node, depth=0):
    blocks = (ast.If, ast.For, ast.While, ast.With, ast.Try, ast.AsyncFor, ast.AsyncWith)
    current = depth + int(isinstance(node, blocks))
    return max([current, *(node_depth(child, current) for child in ast.iter_child_nodes(node))])


def helper_checks(directory):
    results = []
    for name in ("metadata.py", "prepare.py", "test_metadata.py"):
        tree = ast.parse(p.regular_file(directory / name))
        m.require(not any(isinstance(node, (ast.ClassDef, ast.Assert)) for node in ast.walk(tree)), "Class or assert in helper")
        m.require(not any(isinstance(node, (ast.Assign, ast.AnnAssign, ast.AugAssign)) for node in tree.body), "Module mutable state")
        nesting = max(node_depth(node) for node in tree.body if isinstance(node, ast.FunctionDef))
        m.require(nesting <= 3, "Helper nesting exceeds three")
        results.append(dict(path=name, sha256=m.digest(p.regular_file(directory / name)), max_nesting=nesting))
    return results


def main(arguments):
    if len(arguments) != 4 or arguments[1] not in ("--unit", "--full"):
        return
    directory = Path(arguments[2])
    label = arguments[3]
    m.require(label in ("normal", "optimized", "unit"), "Unknown check label")
    checks = pure_checks()
    helpers = helper_checks(directory)
    if arguments[1] == "--full":
        control = Path("/tmp/uwz-h2-combined-c2") / ("control-" + label)
        checks.extend(file_checks(control))
    p.write_json(directory / ("checks-" + label + ".json"), dict(negative_checks=checks, helpers=helpers, passed=True))
    print("Metadata checks passed:", len(checks), "bounded negatives; strict helpers and inert import boundaries")


if __name__ == "__main__":
    main(sys.argv)
