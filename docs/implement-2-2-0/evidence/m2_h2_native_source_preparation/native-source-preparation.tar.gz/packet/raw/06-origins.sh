set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/06-restore.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
import json,tarfile,hashlib
from pathlib import Path
b=Path('.uwz-work/evidence/h2-streaming/combined-interface-audit')
c=json.loads((b/'final-candidate-reconstruction.json').read_text())
for row in c['files']:
    if isinstance(row['reconstruction']['source'],str) and row['reconstruction']['source']!='exact base Git blob':
        print(json.dumps(row))
i=json.loads((b/'final-input-index.json').read_text())
for name in ('m2_h2_metadata_live','m2_h2_combined_fixture'):
    a=i['authorities'][name]
    if hashlib.sha256(Path(a['archive']).read_bytes()).hexdigest()!=a['archive_sha256']:
        raise ValueError('archive hash')
    with tarfile.open(a['archive']) as t:
        print('inventory',name,t.extractfile('inventory.json').read()[:700])
        if name=='m2_h2_combined_fixture':
            d=json.loads(t.extractfile('builds/uwz-task5e2-Fix1Final2/debug-receipt.json').read())
            print('receipt keys',list(d))
            print('source_before type/head',type(d['source_before']).__name__,str(d['source_before'])[:650])
PY
