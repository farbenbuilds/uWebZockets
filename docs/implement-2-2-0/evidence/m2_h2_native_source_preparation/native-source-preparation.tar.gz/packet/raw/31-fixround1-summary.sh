set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/31-restore.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import sys
root=Path('/workspaces/uWebZockets')
b=root/'.uwz-work/evidence/h2-streaming/native-input-preparation'
sys.path.insert(0,str(b))
import metadata as m,prepare as p,test_metadata as t
a=m.parse_json(p.regular_file(b/'fix1normal-audit.json'))
m.require(p.regular_file(b/'fix1normal-audit.json')==p.regular_file(b/'fix1optimized-audit.json'),'Final normal/optimized audit differs')
m.require(p.regular_file(b/'fix1normal-origin-ledger.json')==p.regular_file(b/'fix1optimized-origin-ledger.json'),'Final normal/optimized origins differ')
for mode in ('fix1normal','fix1optimized'):
    check=m.parse_json(p.regular_file(b/('checks-'+mode+'.json')))
    m.require(check['passed'] and len(check['negative_checks'])==2,'Missing focused preservation proof')
    m.require(check['helpers']==t.helper_checks(b),'Unchecked helper change')
baseline=m.parse_json(p.regular_file(b/'preservation-fixround1-baseline.json'))
preservation=p.preservation(b)
original=m.parse_json(p.regular_file(b/'snapshots/fixround1-original/packet-manifest.json'))
for row in original['files']:
    path=Path(row['path'])
    if path.parent==b and path.name in ('metadata.py','prepare.py','test_metadata.py'):
        path=b/'snapshots/fixround1-original'/path.name
    m.check_bytes(p.regular_file(path),row['sha256'],row['bytes'])
old_report=original['report']
m.check_bytes(p.regular_file(b/'snapshots/fixround1-original/report.md'),old_report['sha256'],old_report['bytes'])
for name in ('candidate','libxev'):
    expected={row['path']:row['sha256'] for row in a[name]['files']}
    old=p.audit_export(Path('/tmp/uwz-h2-combined-c2')/name,expected)
    m.require(old==a[name],'Original and fresh source export facts differ')
summary=dict(status='Implementation ready for scoped re-review',source_roots=a['source_roots'],candidate=dict(count=a['candidate']['count'],aggregate=a['candidate']['ordered_aggregate_sha256']),libxev=dict(count=a['libxev']['count'],aggregate=a['libxev']['ordered_aggregate_sha256']),packed=a['packed_dependency'],helpers=t.helper_checks(b),focused_negative_cases_per_mode=2,normal_optimized_audits_and_ledgers_identical=True,original_exports_unchanged=True,original_509_sealed_files_retained=True,historical_original_directory_proof=False,directory_baseline_scope=baseline['scope'],protected_files=len(baseline['files']),protected_directory_counts={key:len(value) for key,value in baseline['directory_paths'].items()},preservation=preservation,native_executed=False,native_ready=False,milestone_complete=False)
p.write_json(b/'fixround1-summary.json',summary)
print(dict(helpers=summary['helpers'],protected_files=summary['protected_files'],protected_directory_counts=summary['protected_directory_counts'],source_roots=summary['source_roots']))
print('Fixround1 proof passed: fresh1031+93 exports, two focused negatives each normal/-O, actual protected before/after file+directory equality, original exports/database/evidence retained; historical original directory proof remains false')
PY
