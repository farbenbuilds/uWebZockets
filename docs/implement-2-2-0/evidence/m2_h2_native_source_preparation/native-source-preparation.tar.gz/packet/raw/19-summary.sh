set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/19-restore.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import sys
b=Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation')
sys.path.insert(0,str(b))
import metadata as m,prepare as p
root=Path('/workspaces/uWebZockets')
tmp=Path('/tmp/uwz-h2-combined-c2')
packed=p.run_git(root,b,'final-packed-storage',['count-objects','-v'],tmp/'objects.git').decode()
config=p.regular_file(tmp/'objects.git/config').decode()
m.require('[remote ' not in config,'Unexpected remote configuration')
m.require(not (tmp/'objects.git/hooks').exists(),'Unexpected initialized hooks')
a=m.parse_json(p.regular_file(b/'normal-audit.json'))
ledger=m.parse_json(p.regular_file(b/'normal-origin-ledger.json'))
helpers=[p.observed(b/name) for name in ('metadata.py','prepare.py','test_metadata.py')]
large=[p.observed(path) for path in sorted((b/'raw').glob('*-base-blobs.stdout'))]
summary=dict(helpers=helpers,candidate=dict(count=a['candidate']['count'],aggregate=a['candidate']['ordered_aggregate_sha256'],bytes=sum(r['bytes'] for r in a['candidate']['files'])),libxev=dict(count=a['libxev']['count'],aggregate=a['libxev']['ordered_aggregate_sha256'],bytes=sum(r['bytes'] for r in a['libxev']['files'])),packed=a['packed_dependency'],packed_storage=packed,no_remotes=True,no_initialized_hooks=True,preservation=a['preservation']['physical_identities'],closure=a['preservation']['closure'],large_retained_raw_streams=large,temporary_entries=sorted(path.name for path in tmp.iterdir()),normal_optimized_identical=True)
p.write_json(b/'final-summary.json',summary)
print(m.parse_json(p.regular_file(b/'checks-normal.json'))['helpers'])
print(summary)
PY
