set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/32-restore.json
cp .superpowers/sdd/h2_streaming_plan/task-5e3c2-report.md .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/report-fixround1-before-seal.md
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import sys
root=Path('/workspaces/uWebZockets')
b=root/'.uwz-work/evidence/h2-streaming/native-input-preparation'
sys.path.insert(0,str(b))
import metadata as m,prepare as p,test_metadata as t
summary=m.parse_json(p.regular_file(b/'fixround1-summary.json'))
m.require(summary['helpers']==t.helper_checks(b),'Helper changed after focused final proof')
m.require(summary['historical_original_directory_proof'] is False,'Historical qualification missing')
m.require(summary['normal_optimized_audits_and_ledgers_identical'] and summary['original_exports_unchanged'],'Fresh/retained source evidence missing')
m.require(m.digest(p.regular_file(b/'snapshots/fixround1-original/packet-manifest.json'))=='745ab3bdf39bad8f61e176e9cfd819c08009515970eaa7e84f2304901806c70f','Original seal changed')
m.require(p.regular_file(b/'preservation-before.json')==p.regular_file(b/'snapshots/fixround1-original/preservation-before.json'),'Original before snapshot changed')
excluded=('packet-manifest.json','packet-manifest-fixround1.json','raw/32-restore.json','raw/32-fixround1-seal.stdout','raw/32-fixround1-seal.stderr','raw/32-fixround1-seal.exit')
files=[p.observed(path) for path in p.walk_regular(b) if str(path.relative_to(b)) not in excluded]
report=root/'.superpowers/sdd/h2_streaming_plan/task-5e3c2-report.md'
p.write_json(b/'packet-manifest-fixround1.json',dict(scope='Fixround1 complete retained source-preparation evidence/report; original seal/helper/report versions retained; original directory-history qualification explicit',files=files,report=p.observed(report),exclusions=list(excluded),current_helpers=3,original_seal='snapshots/fixround1-original/packet-manifest.json',final_source_roots=summary['source_roots'],original_directory_history_proven=False,fresh_preparation_before_after_directory_proof=True,source_exports_embedded=False,native_executed=False,native_ready=False,milestone_complete=False))
replacement=p.regular_file(b/'packet-manifest-fixround1.json')
(b/'packet-manifest.json').write_bytes(replacement)
m.require(p.regular_file(b/'packet-manifest.json')==replacement,'Current seal copy differs')
print('Fixround1 seal passed:',len(files),'retained evidence files; fresh1031+93 exact exports; focused normal/-O directory addition/removal proof; original history explicitly qualified; original seal retained; ready for scoped re-review')
PY
