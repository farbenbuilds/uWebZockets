set -e
mkdir .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/fixround1-original
cp .uwz-work/evidence/h2-streaming/native-input-preparation/metadata.py .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/fixround1-original/metadata.py
cp .uwz-work/evidence/h2-streaming/native-input-preparation/prepare.py .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/fixround1-original/prepare.py
cp .uwz-work/evidence/h2-streaming/native-input-preparation/test_metadata.py .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/fixround1-original/test_metadata.py
cp .superpowers/sdd/h2_streaming_plan/task-5e3c2-report.md .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/fixround1-original/report.md
cp .uwz-work/evidence/h2-streaming/native-input-preparation/packet-manifest.json .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/fixround1-original/packet-manifest.json
cp .uwz-work/evidence/h2-streaming/native-input-preparation/preservation-before.json .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/fixround1-original/preservation-before.json
cat .agents/skills/code-review-and-quality/SKILL.md /home/codespace/.codex/plugins/cache/openai-curated-remote/superpowers/7.0.1/skills/receiving-code-review/SKILL.md > .uwz-work/evidence/h2-streaming/native-input-preparation/raw/24-fixround1-skills.txt
sha256sum .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/fixround1-original/*
