set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/35-restore.json
cp .uwz-work/evidence/h2-streaming/native-input-preparation/prepare.py .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/prepare-before-fixround2-checks.py
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/test_metadata.py --history /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation fix2normal
/home/codespace/.python/current/bin/python3 -B -S -O /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/test_metadata.py --history /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation fix2optimized
