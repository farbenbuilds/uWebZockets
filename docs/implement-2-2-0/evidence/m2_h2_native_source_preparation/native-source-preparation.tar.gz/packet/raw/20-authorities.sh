set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/20-restore.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import sys
root=Path('/workspaces/uWebZockets')
b=root/'.uwz-work/evidence/h2-streaming/native-input-preparation'
sys.path.insert(0,str(b))
import metadata as m,prepare as p
idx=m.parse_json(p.regular_file(root/'.uwz-work/evidence/h2-streaming/combined-interface-audit/final-input-index.json'))
c1=root/'docs/implement-2-2-0/evidence/m2_h2_combined_input_audit/manifest.json'
manifest=m.parse_json(p.regular_file(c1))
authorities={name:idx['authorities'][name] for name in ('m2_h2_metadata_live','m2_h2_combined_fixture')}
base=dict(commit='30f27ab80f0471437c34adcdf7b2d42f58227b74',ledger='normal-origin-ledger.json candidate rows;982 base Git blob origins',ordered_queries='raw/normal-base-blobs.stdin',query_receipt='raw/normal-base-blobs.command.json',raw_sha256='af7d265c4d2aaf9b1e782749096fa496e9e2fa2ef1192f5ef63b600109661a66',raw_bytes=101829106)
p.write_json(b/'origin-authorities.json',dict(base=base,archives=authorities,published_c1=dict(manifest=str(c1),manifest_sha256=m.digest(p.regular_file(c1)),manifest_git_commit='cbdadc8bad2a6f1adb2dddb0b416da45caf96125',archive=str(c1.parent/manifest['archive']),archive_sha256=manifest['archive_sha256'],archive_bytes=manifest['archive_bytes']),historical_manifest_git_anchor=idx['published_manifests_git_anchor'],bundle=dict(path=str(root/'.uwz-work/evidence/h2-streaming/combined-interface-audit/epoll-registration-rollback.bundle'),bytes=1471282,sha256='6f9f27199b2cc4bf47e7f04fd3d1862362899be283d84ec1e97c614b69a03580',commit='c223bd886c6a51d2cd60def39dd9a68d701fea73',tree='86c6944f53dc009d7503a9ab0bc873aef3cd7b79'),perfile_ledger='normal-origin-ledger.json',actual_exports='normal-audit.json',optimized_equivalent=True))
print('Origin authorities bound: exact published c1/Git manifests, metadata/fixture archives,982 Git blobs and authenticated c223 bundle')
PY
