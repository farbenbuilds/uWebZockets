set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/17-restore.json
/home/codespace/.python/current/bin/python3 -B -S -O /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/test_metadata.py --full /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation optimized
/home/codespace/.python/current/bin/python3 -B -S -O /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/prepare.py --audit /workspaces/uWebZockets /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation /tmp/uwz-h2-combined-c2 optimized
