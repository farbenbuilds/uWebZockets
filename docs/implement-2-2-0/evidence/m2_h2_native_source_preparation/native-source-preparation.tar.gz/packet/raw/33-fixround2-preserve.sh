set -e
mkdir .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/fixround2-original
cp .uwz-work/evidence/h2-streaming/native-input-preparation/metadata.py .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/fixround2-original/metadata.py
cp .uwz-work/evidence/h2-streaming/native-input-preparation/prepare.py .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/fixround2-original/prepare.py
cp .uwz-work/evidence/h2-streaming/native-input-preparation/test_metadata.py .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/fixround2-original/test_metadata.py
cp .superpowers/sdd/h2_streaming_plan/task-5e3c2-report.md .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/fixround2-original/report.md
cp .uwz-work/evidence/h2-streaming/native-input-preparation/packet-manifest.json .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/fixround2-original/packet-manifest.json
sha256sum .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/fixround2-original/*
