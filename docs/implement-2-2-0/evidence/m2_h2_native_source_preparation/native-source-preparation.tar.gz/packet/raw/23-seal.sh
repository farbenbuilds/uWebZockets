set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/23-restore.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import sys
root=Path('/workspaces/uWebZockets')
b=root/'.uwz-work/evidence/h2-streaming/native-input-preparation'
sys.path.insert(0,str(b))
import metadata as m,prepare as p,test_metadata as t
summary=m.parse_json(p.regular_file(b/'final-summary.json'))
summary['helpers']=[p.observed(b/name) for name in ('metadata.py','prepare.py','test_metadata.py')]
summary['canonical_audit']='normal2-audit.json'
summary['canonical_ledger']='normal2-origin-ledger.json'
summary['negative_cases_each_mode']=49
summary['exact_file_and_directory_sets']=True
summary['temporary_entries']=sorted(path.name for path in Path('/tmp/uwz-h2-combined-c2').iterdir())
large=[p.observed(path) for path in sorted((b/'raw').glob('*-base-blobs.stdout'))]
m.require(len(large)==6,'Wrong retained raw batch stream count')
m.require(all(row['bytes']==101829106 and row['sha256']=='af7d265c4d2aaf9b1e782749096fa496e9e2fa2ef1192f5ef63b600109661a66' for row in large),'Large batch identity differs')
summary['large_retained_raw_streams']=large
m.require(p.regular_file(b/'normal2-audit.json')==p.regular_file(b/'optimized2-audit.json')==p.regular_file(b/'normal-audit.json'),'Audit facts differ')
m.require(p.regular_file(b/'normal2-origin-ledger.json')==p.regular_file(b/'optimized2-origin-ledger.json')==p.regular_file(b/'normal-origin-ledger.json'),'Origin facts differ')
for mode in ('normal2','optimized2'):
    check=m.parse_json(p.regular_file(b/('checks-'+mode+'.json')))
    m.require(len(check['negative_checks'])==49 and check['passed'],'Missing final check proof')
    m.require(check['helpers']==t.helper_checks(b),'Helper differs from checked bytes')
summary['final_preservation']=p.preservation(b)
p.write_json(b/'final-summary2.json',summary)
report=root/'.superpowers/sdd/h2_streaming_plan/task-5e3c2-report.md'
excluded=('packet-manifest.json','raw/23-restore.json','raw/23-seal.stdout','raw/23-seal.stderr','raw/23-seal.exit')
files=[p.observed(path) for path in p.walk_regular(b) if str(path.relative_to(b)) not in excluded]
p.write_json(b/'packet-manifest.json',dict(scope='All local retained source-preparation evidence and report; excludes only circular manifest and active seal outputs/receipt',files=files,report=p.observed(report),exclusions=list(excluded),current_helpers=3,source_exports_embedded=False,native_executed=False,native_ready=False,milestone_complete=False))
print('Final seal passed:1031+93 exact immutable source exports;49 negatives each normal/-O; helper bytes/inert proofs/preservation bound;',len(files),'retained evidence files')
PY
