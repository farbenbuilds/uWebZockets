set -e
rg -n -A 5 -B 2 'def aggregate|source_before_sha256|json.dumps|aggregate_sha256' .uwz-work/evidence/h2-streaming/combined-interface-audit/metadata.py
