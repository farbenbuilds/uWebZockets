set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/07-restore.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
import json
from pathlib import Path
c=json.loads(Path('.uwz-work/evidence/h2-streaming/combined-interface-audit/final-candidate-reconstruction.json').read_text())
for r in c['files']:
    if r['path'] in ('README.md','tests/package_consumer/main.zig'):
        print(json.dumps(r,indent=2))
PY
