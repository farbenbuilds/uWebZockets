set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/08-restore.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
import hashlib,json,tarfile
from pathlib import Path
b=Path('.uwz-work/evidence/h2-streaming/combined-interface-audit')
c=json.loads((b/'final-candidate-reconstruction.json').read_text())
m={r['path']:r['expected_sha256'] for r in c['files']}
for sep in (' ', '\0','  ',':'):
    for suffix in ('\n','\0',''):
        v=hashlib.sha256(''.join(p+sep+m[p]+suffix for p in sorted(m)).encode()).hexdigest()
        if v==c['aggregate_sha256']:
            print('aggregate exact',repr(sep),repr(suffix))
i=json.loads((b/'final-input-index.json').read_text())
a=i['authorities']['m2_h2_metadata_live']
if hashlib.sha256(Path(a['archive']).read_bytes()).hexdigest()!=a['archive_sha256']:
    raise ValueError('archive hash')
with tarfile.open(a['archive']) as t:
    d=json.loads(t.extractfile('inputs/restoration-provenance.json').read())
    print('provenance keys',d.keys(),str(d)[:3500])
a=i['authorities']['m2_h2_combined_fixture']
if hashlib.sha256(Path(a['archive']).read_bytes()).hexdigest()!=a['archive_sha256']:
    raise ValueError('archive hash')
with tarfile.open(a['archive']) as t:
    d=json.loads(t.extractfile('builds/uwz-task5e2-Fix1Final2/debug-receipt.json').read())
    print('override',str(d['override_before'])[:800])
PY
