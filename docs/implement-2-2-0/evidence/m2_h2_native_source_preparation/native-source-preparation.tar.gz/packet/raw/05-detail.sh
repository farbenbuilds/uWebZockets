set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/05-restore.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
import hashlib,json,tarfile
from pathlib import Path
b=Path('.uwz-work/evidence/h2-streaming/combined-interface-audit')
c=json.loads((b/'final-candidate-reconstruction.json').read_text())
print('supplement rows',json.dumps([r for r in c['files'] if isinstance(r['reconstruction']['source'],dict) and 'archive' not in r['reconstruction']['source']],indent=2))
i=json.loads((b/'final-input-index.json').read_text())
for name in ('m2_h2_metadata_live','m2_h2_combined_fixture'):
    a=i['authorities'][name]
    if hashlib.sha256(Path(a['archive']).read_bytes()).hexdigest()!=a['archive_sha256']:
        raise ValueError('archive hash')
    with tarfile.open(a['archive']) as t:
        print(name,'inventory names',[m.name for m in t.getmembers() if 'inventory' in m.name][:10])
        targets=('candidate/delta.json','inputs/immutable-libxev-input.json','builds/uwz-task5e2-Fix1Final2/debug-receipt.json')
        for target in targets:
            if target not in t.getnames():
                continue
            d=json.loads(t.extractfile(target).read())
            print(target,str(d)[:2200])
PY
