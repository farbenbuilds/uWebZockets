set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/26-restore.json
cp .uwz-work/evidence/h2-streaming/native-input-preparation/prepare.py .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/prepare-before-fixround1-baseline.py
cp .uwz-work/evidence/h2-streaming/native-input-preparation/test_metadata.py .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/test-metadata-before-fixround1-baseline.py
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/prepare.py --capture-directories /workspaces/uWebZockets /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation /tmp/uwz-h2-combined-c2-fix1 fix1baseline
