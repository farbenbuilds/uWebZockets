set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/22-restore.json
run_inert() {
/home/codespace/.python/current/bin/python3 -B -S "$@" - <<'PY'
import contextlib,importlib.util,io,json,os,sys
from pathlib import Path
base=Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation')
sys.path.insert(0,str(base))
before=sorted(str(Path(d)/f) for d,_,files in os.walk(base) for f in files)
stdout,stderr=io.StringIO(),io.StringIO()
with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
    for name in ('metadata','prepare','test_metadata'):
        spec=importlib.util.spec_from_file_location('foreign_'+name,base/(name+'.py'))
        module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if hasattr(module,'main'):
            module.main(['empty'])
            module.main(['foreign','--foreign'])
            module.main(['foreign','--foreign','/invalid','/invalid','/invalid','foreign'])
after=sorted(str(Path(d)/f) for d,_,files in os.walk(base) for f in files)
if stdout.getvalue() or stderr.getvalue() or before!=after:
    raise ValueError('Effectful foreign import or empty/foreign CLI')
import metadata,prepare
normal=json.loads((base/'normal2-audit.json').read_text())
for name in ('candidate','libxev'):
    expected={row['path']:row['sha256'] for row in normal[name]['files']}
    if prepare.audit_export(Path('/tmp/uwz-h2-combined-c2')/name,expected)!=normal[name]:
        raise ValueError('Export changed during inert proof')
prepare.preservation(base)
if (base/'normal2-audit.json').read_bytes()!=(base/'optimized2-audit.json').read_bytes():
    raise ValueError('Normal and optimized full audit differ')
if (base/'normal2-origin-ledger.json').read_bytes()!=(base/'optimized2-origin-ledger.json').read_bytes():
    raise ValueError('Normal and optimized origin ledgers differ')
mode='optimized' if sys.flags.optimize else 'normal'
prepare.write_json(base/('inert-final-'+mode+'.json'),dict(mode=mode,foreign_import=True,empty_cli=True,foreign_cli=True,
    stdout='',stderr='',owned_paths_unchanged=True,full_exports_unchanged=True,normal_optimized_audit_identical=True))
print('Inert proof passed:',mode,'three foreign imports, empty/foreign CLI; exports and protected sources unchanged')
PY
}
run_inert
run_inert -O
