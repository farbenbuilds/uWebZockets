set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/12-restore.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import hashlib,json,tarfile
p=Path('docs/implement-2-2-0/evidence/m2_h2_combined_input_audit')
m=json.loads((p/'manifest.json').read_text())
a=p/m['archive']
if hashlib.sha256(a.read_bytes()).hexdigest()!=m['archive_sha256']:
    raise ValueError('Archive drift')
with tarfile.open(a) as t:
    print([x.name for x in t.getmembers() if 'inventory' in x.name.lower()])
    for x in t.getmembers():
        if 'inventory' in x.name.lower():
            print(t.extractfile(x).read()[:750])
PY
