set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/14-restore.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import hashlib,json,tarfile
p=Path('docs/implement-2-2-0/evidence/m2_h2_metadata_live/metadata-live.tar.gz')
if hashlib.sha256(p.read_bytes()).hexdigest()!='a08dbf448de76b3642816b0eed9388b59d83356b0d3d1fc8a7025b3718ec7d59':
    raise ValueError('Archive drift')
with tarfile.open(p) as t:
    d=json.loads(t.extractfile('inputs/restoration-provenance.json').read())
c=json.loads(Path('.uwz-work/evidence/h2-streaming/combined-interface-audit/final-candidate-reconstruction.json').read_text())
for row in c['files']:
    if 'supplement' in row:
        print(row['path'],repr(d['provenance'][row['path']]),repr(row['supplement']['path']))
PY
