set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/03-restore.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
import json
from pathlib import Path
base=Path('.uwz-work/evidence/h2-streaming/combined-interface-audit')
for name in ('final-candidate-reconstruction.json','dependency-audit.json','scoped-file-sets.json','final-input-index.json','packet-manifest.json'):
    data=json.loads((base/name).read_text())
    print(name, type(data).__name__)
    if isinstance(data,dict):
        for key,value in data.items():
            print(key, type(value).__name__, str(value)[:1500])
PY
