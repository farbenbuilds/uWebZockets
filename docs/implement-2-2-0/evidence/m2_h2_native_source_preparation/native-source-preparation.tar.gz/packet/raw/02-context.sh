set -e
cat .codex/agents/build_vendor.toml
cat CONTRIBUTE.md CODEBASE.md CI_CD_PIPELINE.md build.zig.zon docs/dependency_forks.md docs/adr/0005-libxev-fork.md docs/adr/0006-dependency-forks.md docs/adr/0001-http3-datagram-and-webtransport.md > .uwz-work/evidence/h2-streaming/native-input-preparation/raw/02-required-context.txt
sha256sum /home/codespace/.python/current/bin/python3
cat .uwz-work/evidence/h2-streaming/native-input-preparation/raw/01-context.stderr
cat .uwz-work/evidence/h2-streaming/native-input-preparation/raw/01-context.exit
