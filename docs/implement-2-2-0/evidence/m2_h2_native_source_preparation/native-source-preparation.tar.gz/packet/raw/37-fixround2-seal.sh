set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/37-restore.json
cp .superpowers/sdd/h2_streaming_plan/task-5e3c2-report.md .uwz-work/evidence/h2-streaming/native-input-preparation/snapshots/report-fixround2-before-seal.md
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import sys
root=Path('/workspaces/uWebZockets')
b=root/'.uwz-work/evidence/h2-streaming/native-input-preparation'
sys.path.insert(0,str(b))
import metadata as m,prepare as p,test_metadata as t
helpers=t.helper_checks(b)
for mode in ('fix2normal','fix2optimized'):
    result=m.parse_json(p.regular_file(b/('checks-'+mode+'.json')))
    m.require(result['passed'] and result['helpers']==helpers and len(result['negative_checks'])==2,'Missing focused fix2 proof')
    m.require(all(result[key] for key in ('unchanged_frozen_positive','restored_frozen_positive','legacy_absence_false','frozen_regular_files_unchanged')),'Incomplete frozen snapshot coverage')
for mode in ('normal','optimized'):
    result=m.parse_json(p.regular_file(b/('inert-fix2-'+mode+'.json')))
    m.require(all(result[key] for key in ('foreign_import','empty_cli','foreign_cli','owned_paths_unchanged','full_exports_unchanged','normal_optimized_audit_identical')),'Missing final inert/export proof')
m.require(m.digest(p.regular_file(b/'snapshots/fixround2-original/packet-manifest.json'))=='1b540f2f42040813922f6b6df717630247a659eab81374aaede93d8485d9da8d','Reviewed fix1 seal changed')
m.require(p.regular_file(b/'preservation-before.json')==p.regular_file(b/'snapshots/fixround1-original/preservation-before.json'),'Original before snapshot changed')
before=m.parse_json(p.regular_file(b/'preservation-before.json'))
m.require('directory_paths' not in before,'Historical absence qualification changed')
report=root/'.superpowers/sdd/h2_streaming_plan/task-5e3c2-report.md'
report_identity=p.observed(report)
source=m.parse_json(p.regular_file(b/'fixround1-summary.json'))['source_roots']
p.write_json(b/'fixround2-summary.json',dict(status='Ready for scoped re-review',helpers=helpers,report=report_identity,actual_source_roots=source,focused_negative_cases_per_mode=2,unchanged_frozen_positive=True,restored_frozen_positive=True,legacy_directory_absence_remains_false=True,actual_fresh_exports_and_protected_inputs_unchanged=True,no_source_reconstruction=True,no_git_batch_rerun=True,retained_red='raw/34-fixround2-red.stderr',reviewed_fix1_seal='snapshots/fixround2-original/packet-manifest.json',native_executed=False,native_ready=False,milestone_complete=False))
excluded=('packet-manifest.json','packet-manifest-fixround2.json','raw/37-restore.json','raw/37-fixround2-seal.stdout','raw/37-fixround2-seal.stderr','raw/37-fixround2-seal.exit')
files=[p.observed(path) for path in p.walk_regular(b) if str(path.relative_to(b)) not in excluded]
p.write_json(b/'packet-manifest-fixround2.json',dict(scope='Fixround2 retained focused history-check evidence/report with original/fix1 versions and explicit historical qualification',files=files,report=report_identity,exclusions=list(excluded),current_helpers=3,original_seal='snapshots/fixround1-original/packet-manifest.json',fix1_seal='snapshots/fixround2-original/packet-manifest.json',final_source_roots=source,original_directory_history_proven=False,fresh_preparation_before_after_directory_proof=True,source_exports_embedded=False,native_executed=False,native_ready=False,milestone_complete=False))
replacement=p.regular_file(b/'packet-manifest-fixround2.json')
(b/'packet-manifest.json').write_bytes(replacement)
m.require(p.regular_file(b/'packet-manifest.json')==replacement,'Current seal copy differs')
print('Fixround2 seal passed:',len(files),'retained evidence files; post-freeze directory changes rejected before baseline capture normal/-O; unchanged/legacy proofs qualified; actual exports unchanged; ready for scoped re-review')
print('Final report SHA256:',report_identity['sha256'],'bytes:',report_identity['bytes'])
PY
