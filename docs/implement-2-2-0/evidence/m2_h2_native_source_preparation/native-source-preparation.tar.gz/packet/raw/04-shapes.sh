set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/04-restore.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
import json
from pathlib import Path
base=Path('.uwz-work/evidence/h2-streaming/combined-interface-audit')
c=json.loads((base/'final-candidate-reconstruction.json').read_text())
print('nonbase rows', json.dumps([r for r in c['files'] if r['reconstruction']['source']!='exact base Git blob'],indent=2)[:10500])
i=json.loads((base/'final-input-index.json').read_text())
print('roles',sorted({a['role'] for r in i['paths'] for a in r['aliases']}))
for name in ('m2_h2_metadata_live','m2_h2_combined_fixture'):
    print('authority',name,i['authorities'][name])
    m=json.loads(Path(i['authorities'][name]['manifest']).read_text())
    print('manifest keys',m.keys(),str(m)[:1500])
print('identity keys', json.loads((base/'dependency-audit.json').read_text())['identity'].keys())
p=Path('docs/implement-2-2-0/evidence/m2_h2_combined_input_audit/manifest.json')
print('publishedc1',p.read_text()[:3500])
print('c1 anchor',Path('.superpowers/sdd/h2_streaming_plan/task-5e3c1-root-commit-audit.json').read_text()[:1800])
PY
