set -e
ls .codex/agents
cat .agents/skills/using-agent-skills/SKILL.md .agents/skills/git-workflow-and-versioning/SKILL.md .agents/skills/documentation-and-adrs/SKILL.md .agents/skills/code-review-and-quality/SKILL.md
cat .superpowers/sdd/h2_streaming_plan/task-5e3c1-report.md
ls -ld /tmp/uwz-h2-combined-c2
