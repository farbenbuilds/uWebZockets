set -e
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/raw/25-restore.json
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import sys
b=Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation')
sys.path.insert(0,str(b))
import metadata as m,prepare as p
before=m.parse_json(p.regular_file(b/'preservation-before.json'))
original=m.parse_json(p.regular_file(b/'snapshots/fixround1-original/packet-manifest.json'))
for row in original['files']:
    if row['path'].endswith('/packet-manifest.json'):
        continue
    actual=p.observed(Path(row['path']))
    m.require(actual==row,'Original sealed evidence changed')
m.require(len(original['files'])==509,'Wrong original sealed filecount')
root=Path('/tmp/uwz-h2-combined-c2-fix1')
m.require(not root.exists() and not root.is_symlink(),'Fresh fix1 TMP already exists')
facts=dict(original_snapshot_keys=sorted(before),original_snapshot_directory_values='regular file path lists only; no captured empty-directory inventory',roots={root:dict(regular_files=len(files),inferred_ancestor_directories=sorted({str(Path(root)),*(str(parent) for file in files for parent in Path(file).parents if str(parent)==root or root in str(parent)+"/")})) for root,files in before['directories'].items()},raw_freeze_tree='raw/freeze-tracked.stdout is a NUL-separated tracked-file list; it cannot prove absence of empty directories',original_ls='raw/01-context.stdout lists role filenames and raw/01-context.stderr records only missing newTMP; no protected recursive directory listing',historical_full_directory_proof=False,fresh_fix1_root_absent=True,original_509_sealed_files_unchanged=True)
p.write_json(b/'fixround1-retained-directory-facts.json',facts)
print('Original509 sealed files match; original baseline records regular files only. Ancestor directory existence is inferable; empty-directory history is not recoverable. Fresh fix1 root absent.')
PY
