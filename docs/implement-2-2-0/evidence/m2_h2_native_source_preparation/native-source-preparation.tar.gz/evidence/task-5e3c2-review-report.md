### Spec compliance

**Issues found:** The preservation check does not prove that protected directory sets remained unchanged.

- **Important:** [prepare.py](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/prepare.py:69) records only the regular files returned by `walk_regular`; [preservation](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/prepare.py:251) compares the same file-only lists. Creating or removing an empty directory under the protected c1 packet or original candidate tree would therefore pass, despite the report’s claim that exact protected directory sets were preserved. Record and compare directory paths separately, including empty directories. The independent root audit also does not close this gap.

### Strengths

The preparation code validates source bytes and path inventories before export, checks the packed dependency identity, and audits exported file and directory modes. The report retains the failed preparation attempts and clearly limits the result to source preparation.

### Assessment

**Task quality: Needs fixes.** The source-export checks are well scoped, but the required preservation evidence is incomplete.

Verification gaps: I reviewed the supplied diff and report without rerunning the reported suites or independently inspecting all retained raw evidence. The report also identifies an original context-only bootstrap logging gap; native and full project gates remain outside this task.
