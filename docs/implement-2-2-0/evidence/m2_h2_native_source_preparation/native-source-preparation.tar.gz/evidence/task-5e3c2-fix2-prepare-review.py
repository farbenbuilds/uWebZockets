import difflib
import hashlib
import json
import runpy
import sys
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def old_bytes(root, current, expected):
    paths = [current] + sorted((root / 'snapshots').rglob('*'))
    for path in paths:
        if path.is_file() and sha(path.read_bytes()) == expected:
            return path.read_bytes()
    raise ValueError('Reviewed original snapshot missing: ' + str(current))


def main(argv):
    if argv != ['--prepare']:
        return
    plan = Path('/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan')
    root = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation')
    originals = {'metadata.py': 'e02b74fc103ae5ac30318a98f83241ab1b4e469b30301ccbe5c93c1f29067430',
                 'prepare.py': '032fbf4718af26ffc7739326fe1ded7ec0d369ea1b487d65a4fa9404b40e32a6',
                 'test_metadata.py': '356dbc0e613c6f5d03a1a0b96473c8013c21f09147616967ee160b15cbeed8bd'}
    parts = ['# c2 fix round2 scoped review\nBase=head cbdadc8bad2a6f1adb2dddb0b416da45caf96125; compare exact fix1 reviewed bytes with currentfix.\n']
    for name, expected in originals.items():
        current = root / name
        before = old_bytes(root, current, expected).decode().splitlines(True)
        parts.extend(difflib.unified_diff(before, current.read_text().splitlines(True), fromfile='reviewed/' + name, tofile=str(current), n=10))
    before_report = old_bytes(root, plan / 'task-5e3c2-report.md', '489c621f73dacbe22aebc19caec8564e48373bf2eb5232723526f143887484c2').decode().splitlines(True)
    parts.extend(difflib.unified_diff(before_report, (plan / 'task-5e3c2-report.md').read_text().splitlines(True), fromfile='reviewed/report.md', tofile='fixed/report.md', n=10))
    check = runpy.run_path(str(plan / 'task-5e3c1-prepare-review.py'))['root_check']
    checks = {name: check(plan / name) for name in ('task-5e3c2-root-audit.py', 'task-5e3c2-fix2-prepare-review.py')}
    (plan / 'task-5e3c2-root-fix2-helper-check.json').write_text(json.dumps(checks, indent=2) + '\n')
    for name in ('task-5e3c2-root-final-audit.json', 'task-5e3c2-root-fix2-helper-check.json'):
        parts.extend(['\n# ' + name + '\n', (plan / name).read_text()])
    output = plan / 'task-5e3c2-fix2-review.diff'
    output.write_text(''.join(parts))
    data = output.read_bytes()
    print(json.dumps(dict(path=str(output), bytes=len(data), sha256=sha(data))))


if __name__ == '__main__':
    main(sys.argv[1:])
