"""Independently verify publication coverage, binary identities and delivery files."""
import hashlib
import json
import runpy
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def auditor(plan):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_combined_input_audit/combined-input-audit.tar.gz')
    if sha(archive.read_bytes()) != '4c4d93bdec76e4b302a38e5811062b48100df0b617f479fe17eac1bdaa6105c8':
        raise ValueError('Independent auditor provenance differs')
    path = plan / 'task-5e3c1-publication-audit.py'
    with tarfile.open(archive, 'r:gz') as stream:
        if stream.extractfile('evidence/' + path.name).read() != path.read_bytes():
            raise ValueError('Published auditor source differs')
    return runpy.run_path(str(path))


def verify_binary(contents, manifest):
    allowed = {'fe8112ed995b5c922e2ddc00b74554824cd1e2286c759f1780c6437a97003a64': 1352485,
               'e060a78f1024ce7dce9aa3359b25a1d1bbe3700e1b8d3428ddd4b533006ecac6': 562}
    binary = manifest['binary_members']
    if len(binary) != 16:
        raise ValueError('Explicit Git binary inventory differs')
    for name, data in contents.items():
        if name not in binary:
            data.decode('utf-8')
            continue
        row = binary[name]
        if sha(data) not in allowed or len(data) != allowed[sha(data)] or row['size'] != len(data) or row['sha256'] != sha(data):
            raise ValueError('Git binary identity differs')
        command = json.loads(contents[row['command_member']])
        if not name.startswith('packet/raw/') or command['argv'] != row['argv'] or command['argv'][0] != 'git':
            raise ValueError('Binary record lacks bound Git provenance')


def verify_packet(contents, root, plan, manifest):
    references = manifest['external_packet_members']
    if len(references) != 9:
        raise ValueError('Lossless reference count differs')
    names = set()
    for path in root.rglob('*'):
        if path.is_symlink():
            raise ValueError('Live packet symlink')
        if not path.is_file():
            continue
        name = 'packet/' + path.relative_to(root).as_posix()
        data = path.read_bytes()
        names.add(name)
        if name in references:
            verify_reference(data, references[name])
            continue
        if contents.get(name) != data:
            raise ValueError('Archived packet differs: ' + name)
    archived = {name for name in contents if name.startswith('packet/')}
    if len(names) != 809 or archived != names - references.keys() or len(archived) != 800:
        raise ValueError('Packet coverage differs')
    for name, data in contents.items():
        if name.startswith('evidence/') and data != (plan / name.removeprefix('evidence/')).read_bytes():
            raise ValueError('Root evidence differs')
    return dict(embedded=800, lossless_references=9, total=809)


def verify_reference(data, row):
    expected = dict(size=101829106, sha256='af7d265c4d2aaf9b1e782749096fa496e9e2fa2ef1192f5ef63b600109661a66')
    if row != expected or len(data) != expected['size'] or sha(data) != expected['sha256']:
        raise ValueError('Locally retained referenced Git batch differs')


def verify_reproduction(contents, manifest):
    row = manifest['lossless_git_reference']
    queries = contents[row['stdin_member']]
    if len(queries) != 40262 or sha(queries) != row['stdin_sha256'] or row['exit'] != 0 or row['stderr'] or row['ancestry_exit'] != 0:
        raise ValueError('Lossless reconstruction receipt differs')
    if row['stdout_bytes'] != 101829106 or row['stdout_sha256'] != 'af7d265c4d2aaf9b1e782749096fa496e9e2fa2ef1192f5ef63b600109661a66':
        raise ValueError('Reproduced stdout identity differs')
    command = json.loads(contents['packet/raw/normal-base-blobs.command.json'])
    if command['argv'] != row['argv'] or command['stdin_sha256'] != row['stdin_sha256']:
        raise ValueError('Original batch command binding differs')


def verify_supplements(contents, manifest):
    source = Path('/tmp/uwz-h2-combined-c2-fix1/candidate')
    rows = manifest['supplemental_source_files']
    if len(rows) != 9:
        raise ValueError('Nine durable source supplements required')
    for name, row in rows.items():
        data = contents[name]
        original = source / name.removeprefix('reconstruction/supplements/')
        if original.read_bytes() != data or row != dict(size=len(data), sha256=sha(data)):
            raise ValueError('Supplemental source differs')
    return len(rows)


def main(argv):
    if argv != ['--audit']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    docs = Path('docs/implement-2-2-0')
    folder = docs / 'evidence/m2_h2_native_source_preparation'
    manifest = json.loads((folder / 'manifest.json').read_text())
    archive = folder / manifest['archive']
    if sha(archive.read_bytes()) != manifest['archive_sha256'] or archive.stat().st_size != manifest['archive_bytes']:
        raise ValueError('Archive identity differs')
    api = auditor(plan)
    contents = api['read_archive'](archive)
    verify_binary(contents, manifest)
    packet = verify_packet(contents, Path('.uwz-work/evidence/h2-streaming/native-input-preparation'), plan, manifest)
    verify_reproduction(contents, manifest)
    supplements = verify_supplements(contents, manifest)
    if len(contents) != manifest['inventory_entries'] or len(contents) + 1 != manifest['safe_regular_members'] or len(contents) + 1 - 16 != manifest['utf8_members']:
        raise ValueError('Archive counts differ')
    names = ('task-5e3c2-root-audit.py', 'task-5e3c2-fix2-prepare-review.py', 'task-5e3c2-publication-inputs.py',
             'task-5e3c2-build-publication.py', 'task-5e3c2-publication-audit.py')
    check = runpy.run_path(str(plan / 'task-5e3c1-prepare-review.py'))['root_check']
    helpers = {name: check((plan / name).resolve()) for name in names}
    files = [docs / 'README.md', docs / 'm2_request_streaming.md', docs / 'm2_h2_native_source_preparation.md',
             folder / 'README.md', folder / 'manifest.json', archive]
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
                  regular_members=len(contents) + 1, inventory_entries=len(contents), binary_records=16,
                  packet=packet, supplements=supplements, local_links=api['verify_links'](files), root_helpers=helpers,
                  delivery_files={str(path): dict(size=path.stat().st_size, sha256=sha(path.read_bytes())) for path in files},
                  native_compiled=False, native_executed=False, milestone_complete=False)
    (plan / 'task-5e3c2-root-publication-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('root_helpers', 'delivery_files')}, indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
