"""Audit exact source exports independently against the pushed c1 authorities."""
import hashlib
import json
import stat
import subprocess
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def authority():
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_combined_input_audit')
    manifest = json.loads((folder / 'manifest.json').read_text())
    if manifest['archive_sha256'] != '4c4d93bdec76e4b302a38e5811062b48100df0b617f479fe17eac1bdaa6105c8':
        raise ValueError('Published c1 identity differs')
    archive = folder / manifest['archive']
    if sha(archive.read_bytes()) != manifest['archive_sha256']:
        raise ValueError('Published c1 archive differs')
    names = ('packet/final-candidate-reconstruction.json', 'packet/dependency-audit.json',
             'packet/packet-manifest.json', 'packet/before.json', 'evidence/task-5e3c1-git-batch-reference.json')
    with tarfile.open(archive, 'r:gz') as stream:
        inventory = json.loads(stream.extractfile('INVENTORY.json').read())
        members = {name: stream.extractfile(name).read() for name in names}
    for name, data in members.items():
        if inventory[name] != dict(size=len(data), sha256=sha(data)):
            raise ValueError('Authority member differs')
    result = {name: json.loads(data) for name, data in members.items()}
    result['packet_file_identities'] = {name.removeprefix('packet/'): row for name, row in inventory.items() if name.startswith('packet/')}
    result['packet_file_identities']['raw/base-objects.stdout'] = result['evidence/task-5e3c1-git-batch-reference.json']['expected']
    return result


def check_identity(path, size, digest):
    data = path.read_bytes()
    if len(data) != size or sha(data) != digest:
        raise ValueError('Recorded bytes differ: ' + str(path))


def check_tree(root, expected):
    paths = list(root.rglob('*'))
    if any(path.is_symlink() for path in paths):
        raise ValueError('Symlink in source export')
    actual = {path.relative_to(root).as_posix(): sha(path.read_bytes()) for path in paths if path.is_file()}
    if actual != expected:
        raise ValueError('Source export path/hash set differs: ' + str(root))
    if any(not (path.is_file() or path.is_dir()) for path in paths):
        raise ValueError('Nonregular source export')
    if any(stat.S_IMODE(path.stat().st_mode) != (0o555 if path.is_dir() else 0o444) for path in [root] + paths):
        raise ValueError('Immutable source export mode differs')
    return dict(path=str(root), files=len(actual), exact_paths_and_hashes=True, files_mode='0444', directories_mode='0555')


def git(directory, args, data=None):
    result = subprocess.run(['git', '--no-replace-objects', '-c', 'core.hooksPath=/dev/null', '--git-dir=' + str(directory)] + args,
                            input=data, capture_output=True, check=True)
    if result.stderr:
        raise ValueError('Unexpected isolated Git diagnostics')
    return result.stdout


def check_dependency(database, expected):
    commit = 'c223bd886c6a51d2cd60def39dd9a68d701fea73'
    tree = git(database, ['rev-parse', commit + '^{tree}']).decode().strip()
    if tree != '86c6944f53dc009d7503a9ab0bc873aef3cd7b79':
        raise ValueError('Packed dependency tree differs')
    entries = {}
    for row in git(database, ['ls-tree', '-r', '-z', commit]).split(b'\0'):
        if not row:
            continue
        header, name = row.split(b'\t', 1)
        mode, kind, oid = header.decode().split()
        if mode not in ('100644', '100755') or kind != 'blob':
            raise ValueError('Nonregular packed dependency member')
        entries[name.decode()] = oid
    if entries.keys() != expected.keys():
        raise ValueError('Packed dependency path set differs')
    data = git(database, ['cat-file', '--batch'], ''.join(oid + '\n' for oid in entries.values()).encode())
    check_batch(data, entries, expected)
    return dict(commit=commit, tree=tree, packed_blobs_verified=len(entries))


def check_batch(data, entries, expected):
    offset = 0
    for name, oid in entries.items():
        end = data.index(b'\n', offset)
        observed, kind, size = data[offset:end].decode().split()
        start, size = end + 1, int(size)
        body = data[start:start + size]
        if observed != oid or kind != 'blob' or len(body) != size or sha(body) != expected[name] or data[start + size:start + size + 1] != b'\n':
            raise ValueError('Packed dependency blob differs: ' + name)
        offset = start + size + 1
    if offset != len(data):
        raise ValueError('Unaccounted packed dependency bytes')


def preservation(members):
    before = members['packet/before.json']
    seal = members['packet/packet-manifest.json']
    resolved = {Path(row['path']).resolve(strict=True) for row in before['closure_rows']}
    if len(before['closure_rows']) != 118 or len(resolved) != 113 or len(before['codec_rows']) != 42 or before['identity_entries'] != 119:
        raise ValueError('Physical input closure differs')
    packet = Path('.uwz-work/evidence/h2-streaming/combined-interface-audit')
    paths = {path.relative_to(packet).as_posix() for path in packet.rglob('*') if path.is_file()}
    identities = members['packet_file_identities']
    if len(identities) != 121 or paths != identities.keys():
        raise ValueError('C1 packet coverage changed')
    for name, row in identities.items():
        check_identity(packet / name, row['size'], row['sha256'])
    for row in [seal['report']] + before['combined_files'] + before['closure_rows'] + before['codec_rows'] + [before['authority']]:
        check_identity(Path(row['path']), row['bytes'], row['sha256'])
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    expected = json.loads(Path('docs/implement-2-2-0/evidence/m2_h2_combined_all40/manifest.json').read_text())['current_source_files']
    actual = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if actual != expected or len(actual) != 45:
        raise ValueError('Source45 changed')
    old = Path('/tmp/uwz-task4d-fix1-frozen')
    candidate = {row['path']: row['expected_sha256'] for row in members['packet/final-candidate-reconstruction.json']['files']}
    four = ('src/core/http2_upload.zig', 'src/core/tcp.zig', 'src/http/request_body.zig', 'src/http2/server.zig')
    old_files = {path.relative_to(old).as_posix(): sha(path.read_bytes()) for path in old.rglob('*') if path.is_file()}
    if old_files != {name: candidate[name] for name in four} or Path('/tmp/uwz-reviewed-libxev-c223-loop-callbacks').exists():
        raise ValueError('Original native source paths changed')
    return dict(current_source_modules=45, c1_packet_files=121, preceding_files=19808, identity_entries=119,
                physical_rows=len(before['closure_rows']), resolved_files=len(resolved), ordered_codecs=len(before['codec_rows']), original_native_paths_unchanged=True)


def main(argv):
    if argv != ['--audit']:
        return
    members = authority()
    candidate = members['packet/final-candidate-reconstruction.json']
    expected = {row['path']: row['expected_sha256'] for row in candidate['files']}
    aggregate = sha(json.dumps(list(expected.items())).encode())
    if len(expected) != 1031 or aggregate != 'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de':
        raise ValueError('Candidate authority aggregate differs')
    dependency = members['packet/dependency-audit.json']['identity']['files_sha256']
    if len(dependency) != 93:
        raise ValueError('Dependency authority count differs')
    root = Path('/tmp/uwz-h2-combined-c2')
    result = dict(candidate=check_tree(root / 'candidate', expected), candidate_aggregate=aggregate,
                  dependency=check_tree(root / 'libxev', dependency), packed_dependency=check_dependency(root / 'objects.git', dependency),
                  preservation=preservation(members), native_compiled=False, native_executed=False, milestone_complete=False)
    output = Path('.superpowers/sdd/h2_streaming_plan/task-5e3c2-root-final-audit.json')
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
