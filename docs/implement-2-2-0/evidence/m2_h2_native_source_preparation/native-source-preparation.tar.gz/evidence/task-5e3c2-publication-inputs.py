"""Bind the complete retained packet and classify explicit Git provenance records."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return dict(size=len(data), sha256=sha(data))


def verify_seal(root, plan):
    seal = json.loads((root / 'packet-manifest.json').read_text())
    for row in seal['files'] + [seal['report']]:
        if identity(Path(row['path'])) != dict(size=row['bytes'], sha256=row['sha256']):
            raise ValueError('Final seal bytes differ')
    if seal['report']['sha256'] != '282f3c496f10e864fbb581c3126508e4a018fb29398996abc90963b422f5f592':
        raise ValueError('Reviewed final report differs')
    expected = {Path(row['path']).relative_to(root.resolve()).as_posix() for row in seal['files']}
    expected.update(seal['exclusions'])
    actual = {path.relative_to(root).as_posix() for path in root.rglob('*') if path.is_file()}
    if len(seal['files']) != 803 or len(actual) != 809 or actual != expected:
        raise ValueError('Final packet coverage differs')
    return seal


def classify(root):
    large, binary = {}, {}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError('Packet symlink')
        if not path.is_file():
            continue
        record = identity(path)
        name = 'packet/' + path.relative_to(root).as_posix()
        if record == dict(size=101829106, sha256='af7d265c4d2aaf9b1e782749096fa496e9e2fa2ef1192f5ef63b600109661a66'):
            large[name] = record
            continue
        classify_small(path, name, record, binary)
    if len(large) != 9:
        raise ValueError('Nine retained identical Git batches required')
    return large, binary


def classify_small(path, name, record, binary):
    try:
        path.read_bytes().decode('utf-8')
    except UnicodeDecodeError:
        command_path = path.with_suffix('.command.json')
        if not name.startswith('packet/raw/') or path.suffix != '.stdout' or not command_path.is_file():
            raise ValueError('Unexpected binary evidence')
        command = json.loads(command_path.read_text())
        if command['argv'][0] != 'git':
            raise ValueError('Binary record lacks Git provenance')
        binary[name] = dict(record, command_member='packet/raw/' + command_path.name, argv=command['argv'])


def reproduce(root):
    command = json.loads((root / 'raw/normal-base-blobs.command.json').read_text())
    queries = (root / 'raw/normal-base-blobs.stdin').read_bytes()
    if len(queries) != 40262 or sha(queries) != command['stdin_sha256']:
        raise ValueError('Exact ordered Git batch stdin differs')
    result = subprocess.run(command['argv'], input=queries, capture_output=True, check=True)
    if result.stderr or len(result.stdout) != 101829106 or sha(result.stdout) != 'af7d265c4d2aaf9b1e782749096fa496e9e2fa2ef1192f5ef63b600109661a66':
        raise ValueError('Lossless reproduction differs')
    ancestry = subprocess.run(['git', 'merge-base', '--is-ancestor', '30f27ab80f0471437c34adcdf7b2d42f58227b74', 'cbdadc8bad2a6f1adb2dddb0b416da45caf96125'], capture_output=True, check=True)
    if ancestry.stdout or ancestry.stderr:
        raise ValueError('Unexpected ancestry diagnostics')
    return dict(argv=command['argv'], stdin_member='packet/raw/normal-base-blobs.stdin',
                stdin_bytes=len(queries), stdin_sha256=sha(queries), exit=result.returncode, stderr='',
                stdout_bytes=len(result.stdout), stdout_sha256=sha(result.stdout),
                base_commit='30f27ab80f0471437c34adcdf7b2d42f58227b74',
                reachable_from='cbdadc8bad2a6f1adb2dddb0b416da45caf96125', ancestry_exit=ancestry.returncode)


def main(argv):
    if argv != ['--inspect']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    root = Path('.uwz-work/evidence/h2-streaming/native-input-preparation')
    seal = verify_seal(root, plan)
    large, binary = classify(root)
    result = dict(packet_files=809, sealed_files=len(seal['files']), external_packet_members=large,
                  binary_members=binary, lossless_git_reference=reproduce(root),
                  final_report_sha256=seal['report']['sha256'], native_executed=False)
    (plan / 'task-5e3c2-publication-inputs.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(packet_files=809, referenced_git_batches=len(large), embedded_binary_records=len(binary))))


if __name__ == '__main__':
    main(sys.argv[1:])
