### Finding verdict

**Protected empty-directory changes were not detected — ADDRESSED for the fresh preparation.** [prepare.py](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/prepare.py:67) now captures directory paths separately and compares them against the pre-fix1 baseline. [test_metadata.py](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/test_metadata.py:148) covers both addition and removal of empty directories. The report correctly retains the original run’s historical evidence gap.

### New breakage in the fix diff

**Important:** [prepare.py](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native-input-preparation/prepare.py:301) reports `historical_full_directory_proof` as true whenever a prior snapshot contains `directory_paths`, but does not compare those paths with the current tree. A future `--freeze` can record a directory, have that directory added or removed before `--capture-directories`, and still report a historical proof. Validate the stored paths when present, and test changes between freeze and baseline capture.

### Out-of-scope observations

None.

### Verdict

**Fix round: Findings remain open** because the fix introduces a false historical-preservation proof for future snapshots. The reported focused checks and audits were not rerun.
