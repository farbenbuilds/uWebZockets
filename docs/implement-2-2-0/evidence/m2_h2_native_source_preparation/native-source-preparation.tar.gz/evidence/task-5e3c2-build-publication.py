"""Publish the reviewed exact-source preparation without duplicating Git history."""
import hashlib
import json
import runpy
import sys
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def writer(plan):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_combined_input_audit/combined-input-audit.tar.gz')
    if sha(archive.read_bytes()) != '4c4d93bdec76e4b302a38e5811062b48100df0b617f479fe17eac1bdaa6105c8':
        raise ValueError('Published writer provenance differs')
    path = plan / 'task-5e3c1-build-publication.py'
    with tarfile.open(archive, 'r:gz') as stream:
        if stream.extractfile('evidence/' + path.name).read() != path.read_bytes():
            raise ValueError('Published writer bytes differ')
    return runpy.run_path(str(path))


def collect_packet(api, members, root, inputs):
    binary = {name: row['sha256'] for name, row in inputs['binary_members'].items()}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError('Packet symlink')
        if not path.is_file():
            continue
        name = 'packet/' + path.relative_to(root).as_posix()
        if name in inputs['external_packet_members']:
            continue
        api['add'](members, name, path.read_bytes(), binary)
    return binary


def collect_root(api, members, plan):
    names = ('task-5e3c2-brief.md', 'task-5e3c2-report.md', 'task-5e3c2-review-report.md',
             'task-5e3c2-fix1-review-report.md', 'task-5e3c2-fix2-review-report.md',
             'task-5e3c2-review-package-initial.diff', 'task-5e3c2-fix1-review.diff', 'task-5e3c2-fix2-review.diff',
             'task-5e3c2-root-audit.py', 'task-5e3c2-root-audit-before-directory-check.py',
             'task-5e3c2-root-audit-before-preservation-fix.py', 'task-5e3c2-root-final-audit.json',
             'task-5e3c2-root-initial-audit.json', 'task-5e3c2-root-final-audit.stdout',
             'task-5e3c2-root-final-audit.stderr', 'task-5e3c2-root-final-audit.exit',
             'task-5e3c2-root-fix1-final.stdout', 'task-5e3c2-root-fix1-final.stderr', 'task-5e3c2-root-fix1-final.exit',
             'task-5e3c2-root-fix1-directory-before.json', 'task-5e3c2-root-fix1-directory-inputs.json',
             'task-5e3c2-root-final-audit-inputs.json', 'task-5e3c2-root-fix1-final-inputs.json',
             'task-5e3c2-root-fix2-helper-check.json', 'task-5e3c2-root-fix2-review-inputs.json',
             'task-5e3c2-fix2-prepare-review.py', 'task-5e3c2-publication-inputs.py',
             'task-5e3c2-publication-inputs.json', 'task-5e3c2-root-publication-inputs-restoration.json',
             'task-5e3c2-build-publication.py', 'task-5e3c2-publication-audit.py',
             'task-5e3b8a-restore-inputs.py')
    for name in names:
        api['add'](members, 'evidence/' + name, (plan / name).read_bytes(), {})


def collect_supplements(api, members):
    authority = Path('.uwz-work/evidence/h2-streaming/combined-interface-audit/final-candidate-reconstruction.json')
    rows = json.loads(authority.read_text())['files']
    names = ('README.md', 'docs/adr/0008-request-body-streaming.md', 'docs/deployment.md',
             'docs/implement-2-2-0/README.md', 'docs/implement-2-2-0/evidence/m2_h1_retirement_v6/README.md',
             'docs/implement-2-2-0/m2_loop_callback_adapter.md', 'docs/implement-2-2-0/m2_request_streaming.md',
             'docs/implement-2-2-0/m1_streaming_static_tls.md', 'tests/package_consumer/main.zig')
    expected = {row['path']: row['expected_sha256'] for row in rows}
    source = Path('/tmp/uwz-h2-combined-c2-fix1/candidate')
    result = {}
    for name in names:
        data = (source / name).read_bytes()
        if sha(data) != expected[name]:
            raise ValueError('Reviewed supplemental source differs')
        key = 'reconstruction/supplements/' + name
        api['add'](members, key, data, {})
        result[key] = dict(size=len(data), sha256=sha(data))
    return result


def main(argv):
    if argv != ['--build']:
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    root = Path('.uwz-work/evidence/h2-streaming/native-input-preparation')
    inputs = json.loads((plan / 'task-5e3c2-publication-inputs.json').read_text())
    if sha((plan / 'task-5e3c2-report.md').read_bytes()) != inputs['final_report_sha256']:
        raise ValueError('Reviewed final report changed')
    api, members = writer(plan), {}
    binary = collect_packet(api, members, root, inputs)
    collect_root(api, members, plan)
    supplements = collect_supplements(api, members)
    if sum(name.startswith('packet/') for name in members) != 800:
        raise ValueError('Embedded packet coverage differs')
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_native_source_preparation')
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'native-source-preparation.tar.gz'
    inventory = api['write_archive'](archive, members)
    manifest = dict(scope='Exact combined HTTP/2 native source preparation, no target compilation/execution',
                    base_commit='cbdadc8bad2a6f1adb2dddb0b416da45caf96125',
                    archive=archive.name, archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
                    safe_regular_members=len(members) + 1, inventory_entries=len(inventory),
                    utf8_members=len(members) + 1 - len(binary), binary_members=inputs['binary_members'],
                    packet_files=809, packet_files_embedded=800, packet_files_referenced=9,
                    external_packet_members=inputs['external_packet_members'], lossless_git_reference=inputs['lossless_git_reference'],
                    root_evidence_files=sum(name.startswith('evidence/') for name in members), supplemental_source_files=supplements,
                    candidate_files=1031, candidate_bytes=103051479,
                    candidate_aggregate='fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de',
                    origins=dict(base_git=982, archived_delta=40, archived_supplements=9),
                    libxev_files=93, libxev_commit='c223bd886c6a51d2cd60def39dd9a68d701fea73',
                    libxev_tree='86c6944f53dc009d7503a9ab0bc873aef3cd7b79', source_modes=dict(files='0444', directories='0555'),
                    final_source_root='/tmp/uwz-h2-combined-c2-fix1', original_source_root='/tmp/uwz-h2-combined-c2',
                    initial_negative_cases_each_mode=49, fix_rounds=2, all_review_findings_addressed=True,
                    current_helpers=3, helper_max_nesting=2, current_combined_source=45,
                    retained_identity_entries=119, physical_rows=118, resolved_files=113, ordered_codecs=42,
                    original_empty_directory_history='unproved; initial snapshot recorded regular files only',
                    qualifying_fresh_run='actual files and directories captured before fresh preparation; unchanged afterward',
                    root_independent_directory_roots=8, initial_context_logging='original context console retention incomplete',
                    native_ready=False, native_compiled=False, native_executed=False, production_adopted=False, milestone_complete=False,
                    remaining=['Native observer checkpoint and closing receipt', 'Native provider and fresh runtime/loader/SSL closure',
                               'Fresh builds and native all40', 'Full project/platform gates and production adoption', 'All remaining original milestones'])
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = {key: manifest[key] for key in ('archive_sha256', 'archive_bytes', 'safe_regular_members', 'inventory_entries', 'utf8_members', 'root_evidence_files')}
    (plan / 'task-5e3c2-root-archive-build.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main(sys.argv[1:])
