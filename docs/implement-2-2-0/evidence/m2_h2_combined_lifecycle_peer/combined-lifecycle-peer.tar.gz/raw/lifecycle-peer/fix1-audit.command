/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
import ast, hashlib, importlib.util, json
from pathlib import Path
root = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases').resolve()
evidence = root / 'evidence/lifecycle-peer'
spec = importlib.util.spec_from_file_location('audit', root / 'evidence/core-peer/audit.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
audit.immutable(root, evidence)
before = json.loads((evidence / 'before-source.json').read_text())
reviewed = json.loads((evidence / 'final3-source.json').read_text())
current = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob('*.py'))}
frozen = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((evidence / 'final3-source').glob('*.py'))}
if frozen != reviewed or set(current) != set(before) or [name for name in current if current[name] != before[name]] != ['test_lifecycle.py'] or [name for name in current if current[name] != reviewed[name]] != ['test_lifecycle.py']:
    raise RuntimeError('source or reviewed snapshot differs')
history = json.loads((evidence / 'prior-evidence-map.json').read_text())
for name, digest in history.items():
    if hashlib.sha256((root / name).read_bytes()).hexdigest() != digest:
        raise RuntimeError('prior evidence differs: ' + name)
depths = {p.name: audit.nesting(ast.parse(p.read_text())) for p in root.glob('*.py')}
if len(depths) != 38 or max(depths.values()) > 3:
    raise RuntimeError('AST nesting differs')
target = evidence / 'fix1-source'
target.mkdir()
for path in sorted(root.glob('*.py')):
    (target / path.name).write_bytes(path.read_bytes())
(evidence / 'fix1-source.json').write_text(json.dumps(current, indent=2) + '\n')
print('source=38 reviewed snapshot=38 changed=test_lifecycle.py prior evidence preserved=%d maximum nesting=%d' % (len(history), max(depths.values())))
print('lifecycle sha256=' + current['test_lifecycle.py'])
PY
