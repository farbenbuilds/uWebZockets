/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
import hashlib, importlib.util, json
from pathlib import Path
root = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases').resolve()
evidence = root / 'evidence/lifecycle-peer'
spec = importlib.util.spec_from_file_location('audit', root / 'evidence/core-peer/audit.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
audit.immutable(root, evidence)
audit.structure(root, evidence)
before = json.loads((evidence / 'before-source.json').read_text())
current = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob('*.py'))}
if set(current) != set(before) or [name for name in current if current[name] != before[name]] != ['test_lifecycle.py']:
    raise RuntimeError('source scope differs')
history = json.loads((evidence / 'prior-evidence-map.json').read_text())
for name, digest in history.items():
    if hashlib.sha256((root / name).read_bytes()).hexdigest() != digest:
        raise RuntimeError('prior evidence differs: ' + name)
target = evidence / 'final-source'
target.mkdir()
for path in sorted(root.glob('*.py')):
    (target / path.name).write_bytes(path.read_bytes())
(evidence / 'final-source.json').write_text(json.dumps(current, indent=2) + '\n')
print('source=38 changed=test_lifecycle.py prior evidence preserved=%d' % len(history))
PY
