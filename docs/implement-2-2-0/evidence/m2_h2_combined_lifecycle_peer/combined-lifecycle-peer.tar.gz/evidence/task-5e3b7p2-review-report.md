SPEC FAIL
QUALITY NEEDS FIXES

Independent /root/review_h2_lifecycle_peer, Astra/high, read-only.

1. P2 — Replacement validation accepts incorrectly typed records.
   test_lifecycle.py:124 compares dictionaries using == then substitutes the
   unselected record before strict validation. Python0==False means intermediate
   disconnect active=0 passes construction. Focused pinned check reproduced.
   Use existing model.validate_item against intermediate terminal record with
   zero stale counters; add type-confusion rejection. Remove weaker bespoke
   validation beside canonical validator.

2. P2 — Parser exceeds storage bound before checking it.
   test_lifecycle.py:258 extends before capacity check at261. Fragmented frame
   with8200bufferedbytes followed by allowed8192send rejects but retains16392.
   Further rejected calls grow buffer. Check available capacity before mutation;
   regression must prove rejection without growth. Claimed8201cap does not hold.

One shared serialization implementation/independent connection state/shared
case evidence and driver-owned replacement orchestration otherwise preserved.
Two-response queue preserves intentional early-response negative. Structural
lens found no other file-size/spaghetti blocker (462lines, oldnestedcode removed).

Reviewed supplieddiff/relevantvalidators/report/Rootaudit/normalstdout. Only two
focused pure sensitivities ran, no passed suites repeated. Root suppliedsource/
38imports/O/input/history identities. Coordinator/native/runtime/fullgates/
adoption outside scoped preparation. No writes performed.
