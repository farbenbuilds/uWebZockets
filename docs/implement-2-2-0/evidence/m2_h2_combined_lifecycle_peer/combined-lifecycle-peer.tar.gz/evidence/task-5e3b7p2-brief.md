# Task5e3b7p2: lifecycle peer construction

Released after reviewed/pushed P1 at05175b4f41e0e54c36d2fbbb63fb206a992e8600.
BASE is that commit; current38-module source map is published in
docs/implement-2-2-0/evidence/m2_h2_combined_core_peer/manifest.json and bound
by task-5e3b7p1-root-commit-audit.json. Preserve this exact accepted baseline.
Requirements: task-5e3b-peer-extraction-addendum.md P2 and the binding phase2
composition contract. This prepares reusable disconnect/reuse peers for actual
coordinator dispatch; it does not earn coordinator multi-case/default/native
acceptance. All37ordinary/phase2B/2C/actualdefault/aggregate/fullmilestones remain.

Own only combined-cases/test_lifecycle.py, new evidence/lifecycle-peer and
task-5e3b7p2-report.md. No other current modules, immutable core/model/fixture/
helper/codec, product, dependencies, deadlines or capacities. Report exact API
gaps before shared edits. You are not alone; preserve others' edits and every
prior raw/source receipt. Root owns review/publication/commits/refs/pushes.
No agents, external model CLI, public edits, Git writes or native/runtime tests.

Promote existing nested connection machinery once, shared by existing check()
and future coordinator factory. Add documented new_case_evidence() and
new_peer(case, connection_index, *, app, prior, now, clock, case_evidence,
final=False, fault=None). Return exact {connection,state}, seven connection
fields protocol,send,receive,now,owned,tls,alpn. Protocol is initiated pinned
helper-shaped; initial server SETTINGS+ACK are queued for ordinary receive,
not observed by constructor. TLSv1.3/h2/owned are supplied synthetic facts.
case_evidence owns bounded existing rolling digest/totals across replacement.
No parallel copied reuse/disconnect serialization implementation.

Persistent child app schema records,heads,outputs,binding from reviewed core
peer; all defaults at empty start, absent observed bindingNone. Validate prior
earned state; never seed an undispatched selection. Factories do not run client,
call adapter.observe/run_case/final_collection, select replacement ordering or
consume app actions. Concrete frame/HPACK parsing observes outbound bytes,
updates app only at actual finite actions and queues bounded independent facts.
Keep exact current family evidence fields/counters/hashes/cursors/grants; no
client context/protocol completion aliases or accumulated request histories.

check() remains an actual standalone driver returning app. Preserve its exact
caller interface, default semantics and every existing main() sequence/control:
disconnect->reuse, standalone final collections, stale controls/hash, grants,
strict-close/replacement negatives. Shared productioncase objects count once;
each connection has independent parser/protocol/credit/debt. Construction is
not replacement orchestration. Actual replacement receive must be used, and
late old transport credit must not retire fresh-state debt. final permits
prescribed final68 only after finite schedule; never supplies completion.

Add meaningful factory/control proof in owned module: construction has no
dispatch/app transition; fresh independent connections; prior validation does
not seed results; returned seven-field shape; shared rolling digest actual
serialization across replacement; unchanged real driver checks remain. Keep
old peer implementation removed after extraction. No generic registry, **kwargs,
forwarding wrapper without invariant, classes/assert/custom exceptions, hidden
mutable globals, dead code or nesting>3. Every authored helper has main guard
and inert empty/foreignargv import proof; preserve source-only bounds.

Before edits preserve current reviewed source map/prior evidence SHA map and
all immutable input identities; baseline actual relevant proof, new interface
RED scope truthful. Missing API is not a serialized behavioral RED. Retain all
failures/intermediate snapshots separately. After last source edit run focused
test_lifecycle.py and test_imports.py normal/-O pinned Python -B -S, plus an
unchanged suite only for a concrete demonstrated dependency. Do not rerun all
preceding matrices. Current38-module guards/AST/actual inert imports include
reviewed core peer. Record exact commands/stdout/stderr/exits/current snapshots.

Pinned /home/codespace/.python/current/bin/python3 SHA
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
Use existing PYTHONPATH model /tmp/uwz-task5e1-contract-v3,core26
/tmp/uwz-task5e3a-snapshot-v9/source,codecs /tmp/uwz-h2-client-tooling/packages,
integration-client helper,combined-cases.119retained identity entries consist
118physical rows/113resolved files plus ordered42codec aggregate SHA
0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Authority latest reviewed core-peer immutable-inputs; original coordinator-a
retains same immutable rows. Preserve ordered encodings, do not normalize SHA.

Before new codebase question/search/source reads use graphify query first:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650
Read project/role/narrow skills; provided paths located. No native/build/server/
socket/SSLContext/TLS-close/realclock/process ownership or transfer/kernel/fault/
cancel/schedule/interleaving/race/resource/panic/crash/leak execution, oldruntime
entrypoints, installs or network. Only pinned in-memory codecs and supplied
caller/process facts. Native/wholeproject gates remain required later.

Full report actual constructor/driver contracts/storage/deadline and debt
boundaries, changed files, baseline/RED/failures/current raw commands, source/
input/frozen hashes, self-review/concerns and parent limitations. Return only
under15lines status/reportpath/one-line checks/concerns, no commit.
