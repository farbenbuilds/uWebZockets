# P2 fix round1

Read full task-5e3b7p2-review-report.md; both findings binding. Retain original
requirements/onefileownership. Root reviewed findings and read fix-loop before
release. Same implementation owner; no public/Git/native/agent operations.

Use canonical exact-type model.validate_item for replacement's actual terminal
disconnect record with stale counters zero, preserving no-appmutation/no-seeding
and all remaining prior validation. Add actual before-fix constructor behavioral
regression demonstrating incorrectly typed active=0 accepted; exact typed
record remains positive. Preserve original error/result semantics.

Reject input exceeding remaining8201buffer capacity before extend. Preserve
existing frame/parser/request bounds and positive serialization. Actual before-
fix pure regression:8200retainedpartialframe +8192input leaves16392onrejection;
afterfix no growth, repeated rejectedinput cannotgrowbuffer. Do not adjustbound
or omit existing early-response controls/tworesponsequeue.

Retain current reviewed6258B report/source/final3 raw and snapshot distinct.
Append fix report, full REDs/commands/current actualnormalO test_lifecycle and
test_imports results, exactcurrent38 frozen/source/input/history identities.
Do not re-run broad old matrices. No other currentmodule edit before Root
release. Specific newly found sharedgap to Root; don't silently fix it. Root
will send scopedfix to same reviewer; all parent scopes remain unchanged.
