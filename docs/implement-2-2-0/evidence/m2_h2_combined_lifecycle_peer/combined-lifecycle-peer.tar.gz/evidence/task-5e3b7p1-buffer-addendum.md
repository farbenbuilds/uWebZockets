# Shared peer capacity finding

Separate read-only source check /root/review_h2_lifecycle_peer confirms same
P2-severity buffer defect in acceptedP1 test_core_peer.py:175: extend occurs
before check_storage's8201cap.8200partial+8192input retains16392onrejection;
oversized high-water mark also recorded. No execution/edits performed for this
addendum. Not a new-breakage item in P2fixloop.

Smallest followup: preextendcombinedlength guard preserving error/cap; pure
partialframe/rejectedcontinuation check bufferbytes+highwater unchanged, repeated
rejections cannotgrow. Rerun affected shared/coordinator/import consumers normalO,
no broadmatrix. Root will release separate tiny followup afterP2review/push,
beforeP3. No parallel implementationowner; retain originalP1approvedsource and
newfinding provenance, no history rewrite or forcepush.
