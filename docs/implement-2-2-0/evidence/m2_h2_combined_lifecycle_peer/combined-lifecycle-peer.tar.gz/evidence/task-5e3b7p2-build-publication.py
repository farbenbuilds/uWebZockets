"""Package lifecycle peer source and exact retained text evidence."""
import hashlib
import json
import runpy
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    baseline = Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_peer/combined-core-peer.tar.gz')
    if sha(baseline.read_bytes()) != 'dbcd7a01a56a3c80600aa39fa7b61dec00060976c14a82e2bd4a712a2520d25d':
        raise ValueError('Published baseline differs')
    builder = plan / 'task-5e3b7p1-build-publication.py'
    with tarfile.open(baseline, 'r:gz') as previous:
        if previous.extractfile('evidence/' + builder.name).read() != builder.read_bytes():
            raise ValueError('Published writer source differs')
    parent = runpy.run_path(str(builder))
    writer = parent['load_writer'](plan)
    members = {}
    with tarfile.open(baseline, 'r:gz') as previous:
        inventory = json.loads(previous.extractfile('INVENTORY.json').read())
        for member in previous:
            if not member.isfile():
                raise ValueError('Nonregular baseline member')
            if member.name == 'INVENTORY.json':
                continue
            data = previous.extractfile(member).read()
            if inventory[member.name] != dict(size=len(data), sha256=sha(data)):
                raise ValueError('Baseline inventory differs')
            if member.name.startswith('reference/'):
                writer['add'](members, member.name, data)
            if member.name.startswith('source/current/'):
                writer['add'](members, member.name.replace('source/current/', 'history/core-peer-source/', 1), data)
    audit = json.loads((plan / 'task-5e3b7p2-root-fix-1-audit.json').read_text())
    current = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if current != audit['current_source_sha256']:
        raise ValueError('Approved source differs')
    for path in sorted(source.glob('*.py')):
        writer['add'](members, 'source/current/' + path.name, path.read_bytes())
    raw = source / 'evidence/lifecycle-peer'
    for path in sorted(raw.rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink in evidence')
        if path.is_file():
            writer['add'](members, 'raw/lifecycle-peer/' + path.relative_to(raw).as_posix(), path.read_bytes())
    names = ('task-5e3b7p2-brief.md', 'task-5e3b7p2-report.md', 'task-5e3b7p2-review-brief.md',
             'task-5e3b7p2-review-report.md', 'task-5e3b7p2-review-source.diff',
             'task-5e3b7p2-root-final-audit.json', 'task-5e3b7p2-fix-1-brief.md',
             'task-5e3b7p2-fix-1-review-brief.md', 'task-5e3b7p2-fix-1-review-report.md',
             'task-5e3b7p2-fix-1-review.diff', 'task-5e3b7p2-root-fix-1-audit.json',
             'task-5e3b7p2-build-publication.py', 'task-5e3b-peer-extraction-addendum.md',
             'task-5e3b7p1-buffer-addendum.md', 'task-5e3b-coordinator-composition-plan-report.md')
    for name in names:
        writer['add'](members, 'evidence/' + name, (plan / name).read_bytes())
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_combined_lifecycle_peer')
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'combined-lifecycle-peer.tar.gz'
    inventory = writer['write_archive'](archive, members)
    manifest = dict(scope='Pure lifecycle peer preparation; coordinator support unchanged',
                    base_commit='05175b4f41e0e54c36d2fbbb63fb206a992e8600', archive=archive.name,
                    archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
                    safe_regular_text_members=len(members), inventory_entries=len(inventory),
                    current_source_files=current, changed_files=['test_lifecycle.py'], added_files=[],
                    unchanged_core_peer_modules=37, current_normal_optimized_commands=4,
                    preceding_reviewed_normal_optimized_commands=4, current_ast_inert_import_files=38,
                    prior_evidence_hashes_preserved=4412, retained_identity_entries=119,
                    physical_identity_rows=118, unique_file_paths=113, ordered_codec_files=42,
                    observed_case_J_C_R=dict(disconnect=[25,24,64], reuse=[389,389,288]),
                    parser_buffer_limit=8201, frame_payload_limit=8192, pending_response_limit=2,
                    source_review='Spec and quality approved after two review findings fixed',
                    constructor_typed_record_red_exit=1, repeated_parser_growth_red_exit=1,
                    initial_red_scope='Missing constructor API, not serialized behavior',
                    original_copy_failure_raw_captured=False, repeated_copy_failure_retained=True,
                    re_copied_authority_bytes_exact=True, supplied_transport_lifecycle_facts=True,
                    coordinator_supported_nonempty_selections=[['ready_buffered']], explicit_empty_supported=True,
                    default_supported=False, combined_all40_executed=False, native_executed=False, milestone_complete=False,
                    remaining=['Separate shared core peer pre-mutation buffer fix', 'Producer/file peer extraction',
                               'All37 ordinary coordinator composition and disconnect/shutdown children',
                               'Actual default/all40 aggregate, broad review, runtime/native gates and production adoption'])
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
                  regular_members=len(members), inventory_entries=len(inventory), source_modules=len(current),
                  all_reopened_member_bytes_exact=True, native_executed=False)
    (plan / 'task-5e3b7p2-root-archive-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
