# Lifecycle peer construction source review

Review P2 against task-5e3b7p2-brief.md and peer-extraction-addendum P2.
Claims task-5e3b7p2-report.md; Root audit task-5e3b7p2-root-final-audit.json.
Full diff task-5e3b7p2-review-source.diff (identity in Root audit). BASE pushed
05175b4f41e0e54c36d2fbbb63fb206a992e8600; no task commit. Source is ignored
preparation, published in an evidence archive after review; adoption remains.

Read diff once, tests first/context10. No separate changed-file reread unless a
needed function is cut mid-hunk; identify it. Outside-diff reads only for a
concrete named risk, one focused check per risk. No broad crawl/Git repetition
or passed-suite rerun. Evaluate report and audit as claims, not authority.

Binding excerpts:
- "Own only combined-cases/test_lifecycle.py, new evidence/lifecycle-peer and
  task-5e3b7p2-report.md. No other current modules ... edits."
- "Promote existing nested connection machinery once, shared by existing
  check() and future coordinator factory."
- "Add documented new_case_evidence() and new_peer(case, connection_index, *,
  app, prior, now, clock, case_evidence, final=False, fault=None). Return exact
  {connection,state}, seven connection fields ..."
- "prior ... never seed an undispatched selection. Factories do not run
  client, call adapter.observe/run_case/final_collection, select replacement
  ordering or consume app actions."
- "check() remains an actual standalone driver returning app. Preserve its
  exact caller interface, default semantics and every existing main() sequence/
  control ..."
- "Shared productioncase objects count once; each connection has independent
  parser/protocol/credit/debt. Construction is not replacement orchestration."
- "final permits prescribed final68 only after finite schedule; never supplies
  completion."

Named risks: genuine once-only serialization extraction without copied reuse;
factory app/prior independence and exact schema; fresh connection objects and
shared rolling case digest/counters; replacement receive selection; late old
credit/stale-control isolation; strict-close/replacement ordering retained in
actual driver/handler; bounded queues/hashes/cursors; unchanged negative controls
and truthful source-only results. All38 imports/guards remain bound by proof.

Apply AGENTS/CODING/code-review-and-quality and explicitly Root-requested
thermo-nuclear structural lens under project overrides. Read-only/noagents/
externalmodelCLI/Git/service/file writes. Only focused pure sensitivity for a
concrete unanswered doubt; no native/build/socket/server/SSLContext/TLS-close/
realclock/process ownership/transfer/kernel/fault/cancel/schedule/race/panic/leak
execution. Graphify before new codebase question/search using exact prefix in
brief; provided paths located. Return SPEC PASS/FAIL, QUALITY APPROVED/NEEDS FIXES,
strengths/actionable severity/file:line/failure findings and cannot-verify scope.
Root saves full verdict. This does not close parent composition/default/native.
