"""Serialized producer schedules; diagnostics are supplied synthetic model inputs."""
import hashlib
import json
import adapter
import h2_client
from h2.exceptions import FlowControlError
import hpack
import model
import test_ready

TOTAL = 16777313


def paths(case):
    if case == 'producer_reuse':
        return ['/health', '/limit/producer_reuse?case=producer_reuse', '/status/producer_reuse',
                '/output/producer_reuse', '/limit/producer_reuse_next?case=producer_reuse_next',
                '/output/producer_reuse', '/output/producer_reuse_next', '/output/producer_reuse', '/health']
    result = ['/health', '/echo', '/limit/' + case + '?case=' + case]
    if case == 'output_pressure_window':
        return result + ['/status/' + case, '/output/' + case, '/output/' + case, '/output/' + case, '/health']
    return result + ['/status/' + case, '/output/' + case, '/health']


def diagnostic(case, offset, slot, generation):
    done = offset == TOTAL
    writes = 2049 if done else int(offset != 0)
    pending = 0 if case == 'output_pressure_ready' else 2 if done or offset else 1
    return dict(tag=case, armed=True, done=done, offset=offset,
                sha256=model.PRODUCER_HASH if done else model.digest(TOTAL, 0, offset),
                invocations=pending + int(done), attempts=writes + pending, writes=writes,
                blocked=pending, pending=pending, terminal_attempts=int(done), terminals=int(done),
                checks=pending + int(done), after_reuse=int(done and case == 'producer_reuse'),
                errors=0, binding_index=slot, binding_generation=generation)


def check(case, *, app=None, prior=(), final=False, fault=None, slot=1, generation=17, echo_order='middle'):
    if app is None:
        app = {'records': {tag: model.record(tag, False, 'before') for tag in model.SPECS}, 'heads': 0, 'outputs': model.default_outputs(), 'binding': None}
    model.validate_records(prior, 'before', app['records'])
    decoder, encoder = hpack.Decoder(), hpack.Encoder()
    state = dict(startup=True, buffer=bytearray(), pending=[], deferred={}, heads=0, streams={},
                 payloads={}, settings=0, acks=0, bootstrap=0, auxiliary=0, auxiliary_streams=set(), special=0, grant_total=0,
                 allowance=TOTAL if case == 'output_pressure_ready' else 0, offset=0,
                 echo_packet=None, output_headers=False, output_ended=False, output_reads=0, output_digest=hashlib.sha256(), reads=0, statuses=0,
                 diagnostics=0, sibling=False, next_done=False, final=False, prefix_seen=False)
    order, caller_time = paths(case), [1]
    primary = 3 if case == 'producer_reuse' else 5

    def clock():
        if fault == 'deadline' and state['offset'] > 8192:
            return 30001
        if fault == 'backwards_time' and state['offset'] > 8192:
            return caller_time[0] - 1
        caller_time[0] += 1
        return caller_time[0]

    def response(stream, body):
        block = encoder.encode(((':status', '200'), ('x-middleware', 'retained')))
        packet = test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body)
        if case == 'output_pressure_ready' and stream == 3:
            state['echo_packet'] = packet
        elif case != 'output_pressure_ready' and stream not in state['auxiliary_streams']:
            state['deferred'][stream] = packet
        else:
            state['pending'].append(packet)

    def producer_headers():
        block = encoder.encode(((':status', '500' if fault == 'output_status' else '200'), ('x-middleware', 'retained')))
        state['pending'].append(test_ready.frame(1, 4, primary, block))
        state['output_headers'] = True

    def observe_request(path, stream):
        if path == '/health':
            if state['heads'] == len(paths(case)) and not state['output_ended']:
                raise RuntimeError('end health before output completion')
            response(stream, b'ok')
            return
        if path.startswith('/status/'):
            tag = path[8:]
            if not state['final']:
                expected_offset = TOTAL if case == 'output_pressure_ready' else 0
                if state['offset'] != expected_offset or tag != case or state['statuses']:
                    raise RuntimeError('body status ordering differs')
                state['statuses'] += 1
            item = dict(app['records'][tag])
            if fault == 'body_hash' and tag == case:
                item['sha256'] = model.EMPTY_HASH
            response(stream, json.dumps(item).encode())
            return
        if path.startswith('/output/'):
            tag = path[8:]
            state['diagnostics'] += 1
            if tag == 'producer_reuse_next':
                if not state['next_done'] or state['offset'] or state['diagnostics'] != 3:
                    raise RuntimeError('B binding observation ordering differs')
                item = dict(tag=tag, binding_index=slot, binding_generation=generation + 1)
                if fault == 'binding_generation':
                    item['binding_generation'] += 1
                if fault == 'binding_slot':
                    item['binding_index'] = 1 - slot
            else:
                item = diagnostic(case, state['offset'], slot, generation)
                if fault == 'identity' and state['diagnostics'] == 2:
                    item['binding_generation'] += 1
                if fault == 'counter' and state['diagnostics'] == 2:
                    item.update(invocations=0, checks=0, attempts=0, writes=0, blocked=0, pending=0)
                if fault == 'monotonic' and state['diagnostics'] == 1:
                    item.update(invocations=4, checks=4, attempts=4, blocked=4, pending=4)
                if fault == 'after_reuse' and state['offset'] == TOTAL:
                    item['after_reuse'] = 0
                if fault == 'diagnostic_hash':
                    item['sha256'] = model.LARGE_HASH
            response(stream, json.dumps(item).encode())
            return
        if path != '/metrics' or not state['final']:
            raise RuntimeError('unexpected observation')
        values = model.metrics(prior + (case,), 'before')
        values.update(buffered_middleware=app['heads'] - values['middleware'], slot0_active=False, slot1_active=False)
        response(stream, json.dumps(values).encode())

    def headers(packet, stream, flags):
        entries = list(decoder.decode(packet[9:]))
        path = dict(entries)[':path']
        index = state['heads']
        if index >= len(order) or stream != 2 * index + 1 or path != order[index]:
            raise RuntimeError('request order or stream binding differs')
        state['heads'] += 1
        app['heads'] += 1
        tag = 'sibling' if path == '/echo' else path.split('/')[-1].split('?')[0]
        upload = path == '/echo' or path.startswith('/limit/')
        expected = [(':method', 'POST' if upload else 'GET'), (':scheme', 'https'),
                    (':authority', 'localhost'), (':path', path)]
        if upload:
            expected += [('content-length', '1' if tag == 'sibling' else '32')]
            if tag != 'sibling':
                expected.append(('x-case', tag))
        if entries != expected or flags != (4 if upload else 5):
            raise RuntimeError('request headers or END differ')
        if not upload:
            observe_request(path, stream)
            return
        state['streams'][stream] = tag
        state['payloads'][stream] = dict(count=0, frames=0, digest=hashlib.sha256())
        if tag == 'producer_reuse_next' and (stream != 9 or state['diagnostics'] != 1 or state['offset']):
            raise RuntimeError('B upload before held A observation')

    def data(packet, stream, flags):
        tag, payload = state['streams'][stream], packet[9:]
        item = state['payloads'][stream]
        item['frames'] += 1
        item['count'] += len(payload)
        item['digest'].update(payload)
        expected = b's' if tag == 'sibling' else model.payload_span(32, 0, 32)
        if payload != expected or flags != 1 or item['frames'] != 1:
            raise RuntimeError('upload DATA bytes END or ordinal differs')
        if tag == 'sibling':
            if case == 'output_pressure_window' and (state['diagnostics'], state['special']) != (1, 0):
                raise RuntimeError('sibling before held observation or after special grant')
            state['sibling'] = True
            if fault == 'missing_sibling':
                return
            response(stream, b'x' if fault == 'sibling' else b's')
            return
        item_record = model.record(tag, True, 'after')
        item_record.update(chunks=1, max_span=32)
        app['records'][tag] = item_record
        if fault == 'other_record':
            app['records']['empty_headers']['middleware'] = 1
        if tag == 'producer_reuse_next':
            state['next_done'] = True
            response(stream, json.dumps(item_record).encode())
            return
        if stream != primary:
            raise RuntimeError('actual producer stream differs')
        producer_headers()
        if fault == 'early_data':
            state['pending'].append(test_ready.frame(0, 0, primary, b'x'))
        if fault == 'early_end':
            state['pending'].append(test_ready.frame(0, 1, primary, b''))

    def grant(stream, amount):
        if stream == 0:
            state['bootstrap'] += 1
            if amount != 33554432 - 65535 or state['bootstrap'] != 1 or state['heads']:
                raise RuntimeError('bootstrap amount once-only or order differs')
            return
        if stream != primary:
            state['auxiliary'] += 1
            if case == 'output_pressure_ready' or amount != 65535 or stream in state['auxiliary_streams']:
                raise RuntimeError('auxiliary grant differs')
            state['auxiliary_streams'].add(stream)
            if stream in state['deferred']:
                state['pending'].append(state['deferred'].pop(stream))
            return
        sequence = (TOTAL,) if case == 'producer_reuse' else (8192, TOTAL - 8192)
        index = state['special']
        if case == 'output_pressure_ready' or index >= len(sequence) or amount != sequence[index]:
            raise RuntimeError('special grant amount differs')
        if case == 'producer_reuse' and (state['diagnostics'], state['next_done']) != (3, True):
            raise RuntimeError('special grant before reuse binding')
        if case == 'output_pressure_window' and (not state['sibling'] or state['diagnostics'] != index + 1):
            raise RuntimeError('special grant before sibling or prefix observation')
        if index and (state['offset'] != 8192 or not state['prefix_seen']):
            raise RuntimeError('remaining grant before exact prefix')
        state['special'] += 1
        state['grant_total'] += amount
        state['allowance'] += amount

    def packet_received(packet):
        kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
        if kind == 1:
            headers(packet, stream, flags)
            return
        if kind == 0:
            data(packet, stream, flags)
            return
        if kind == 8 and flags == 0 and len(packet) == 13:
            grant(stream, int.from_bytes(packet[9:], 'big'))
            return
        if kind != 4 or stream:
            raise RuntimeError('unexpected outgoing frame')
        if flags == 1 and len(packet) == 9:
            state['acks'] += 1
            return
        window = 33554432 if case == 'output_pressure_ready' else 0
        if flags or packet[9:] != b'\x00\x04' + window.to_bytes(4, 'big') or state['settings']:
            raise RuntimeError('output SETTINGS differs')
        state['settings'] += 1
        if fault != 'missing_ack':
            state['pending'].append(test_ready.frame(4, 1, 0, b''))

    def send(data_bytes):
        if type(data_bytes) is not bytes or len(data_bytes) > 8192:
            raise RuntimeError('send bound differs')
        if state['startup']:
            state['startup'] = False
            if data_bytes[:24] != b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n' or len(data_bytes) != 75:
                raise RuntimeError('already-initiated startup differs')
            return
        state['buffer'].extend(data_bytes)
        while len(state['buffer']) >= 9:
            size = int.from_bytes(state['buffer'][:3], 'big')
            if len(state['buffer']) < size + 9:
                return
            packet = bytes(state['buffer'][:size + 9])
            del state['buffer'][:size + 9]
            packet_received(packet)

    def output_packet():
        length = min(8192, state['allowance'] - state['offset'])
        offset = state['offset']
        body = model.payload_span(TOTAL, offset, length)
        if fault == 'output_hash' and offset == 0:
            body = b'x' + body[1:]
        state['output_digest'].update(body)
        state['offset'] += length
        end = state['offset'] == TOTAL
        state['output_ended'] = end
        state['output_reads'] += 1
        if state['offset'] == 8192 and case == 'output_pressure_window':
            state['prefix_seen'] = True
        if state['echo_packet'] is not None and (echo_order == 'middle' or end):
            state['pending'].append(state['echo_packet'])
            state['echo_packet'] = None
        terminal = end and fault != 'missing_end' or fault == 'prefix_end' and state['offset'] == 8192
        return test_ready.frame(0, int(terminal), primary, body)

    def receive():
        state['reads'] += 1
        if state['reads'] > 2400:
            raise RuntimeError('finite synthetic read limit exceeded')
        if primary in context['records'] and context['records'][primary]['body']:
            raise RuntimeError('hash-only producer retained response body')
        result = bytearray()
        while len(result) < 8192:
            if state['pending']:
                packet = state['pending'].pop(0)
            elif state['output_headers'] and state['offset'] < state['allowance']:
                packet = output_packet()
            else:
                break
            size = min(8192 - len(result), len(packet))
            result.extend(packet[:size])
            if size < len(packet):
                state['pending'].insert(0, packet[size:])
        if not result:
            raise RuntimeError('missing finite synthetic response')
        return bytes(result), clock()

    context = adapter.open_case(case, h2_client.new_protocol(), send, 1, 30001, 900001, selected_before=prior, clock=clock)
    pairs = ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1))
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in pairs)
    adapter.observe(context, test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b''), clock())
    adapter.run_case(context, receive)
    expected = {'producer_reuse': (9, 8, 64), 'output_pressure_window': (8, 7, 33), 'output_pressure_ready': (6, 5, 33)}[case]
    actual = (state['heads'], context['stage']['case_state']['small'], context['request']['case']['sent'])
    if actual != expected or context['stage']['primary'] != primary or state['heads'] != len(order):
        raise RuntimeError('exact J C R or primary binding differs')
    special = 0 if case == 'output_pressure_ready' else 1 if case == 'producer_reuse' else 2
    auxiliary = 0 if case == 'output_pressure_ready' else expected[1]
    if (state['settings'], state['acks'], context['stage']['acks'], state['bootstrap'], state['special'], state['auxiliary']) != (1, 1, 2, 1, special, auxiliary):
        raise RuntimeError('settings ACK or grant counts differ')
    if state['grant_total'] != (0 if case == 'output_pressure_ready' else TOTAL) or state['offset'] != TOTAL or not state['output_ended']:
        raise RuntimeError('producer total grant output or END differs')
    for stream, item in state['payloads'].items():
        expected_body = b's' if state['streams'][stream] == 'sibling' else model.payload_span(32, 0, 32)
        if item['count'] != len(expected_body) or item['frames'] != 1 or item['digest'].hexdigest() != hashlib.sha256(expected_body).hexdigest():
            raise RuntimeError('final upload count or digest differs')
    if context['records'] or context['stage']['active'] or context['raw']['streams']:
        raise RuntimeError('paired retirement differs')
    if (context['request']['connection_debt'], context['request']['stream_debt_total']) != (expected[2], expected[2]):
        raise RuntimeError('request final carried debt differs')
    if state['output_digest'].hexdigest() != model.PRODUCER_HASH:
        raise RuntimeError('serialized producer count or digest differs')
    if state['output_reads'] != 2049 or state['pending'] or state['deferred'] or state['buffer'] or state['echo_packet'] is not None:
        raise RuntimeError('pending synthetic input or output remains')
    retained = context['output_observations'][case]
    model.validate_producer(retained, TOTAL, after_reuse=case == 'producer_reuse')
    app['outputs'][case] = retained
    if case == 'producer_reuse':
        app['binding'] = context['output_binding']
        model.validate_reuse_binding(retained, app['binding'])
    retained_outputs = {tag: dict(item) for tag, item in app['outputs'].items()}
    retained_binding = None if app['binding'] is None else dict(app['binding'])
    if final:
        state['final'] = True
        order.extend('/status/' + tag for tag in model.SPECS)
        order.append('/metrics')
        adapter.final_collection(context, receive)
        if state['heads'] != expected[0] + 68 or not context['stage']['final_complete']:
            raise RuntimeError('final67 plus metrics differs')
    model.validate_output_pre_post(prior + (case,), retained_outputs, app['outputs'],
                                   binding_before=retained_binding, binding_after=app['binding'] if app['binding'] is not None else model.default_binding())
    model.validate_records(prior + (case,), 'before', app['records'])
    print(case + ' passed: J=%d C=%d R=%d output=%d' % (*actual, state['offset']))
    return app


def rejected(case, fault, message, *, final=False):
    try:
        check(case, fault=fault, final=final)
    except (ValueError, RuntimeError, FlowControlError) as exc:
        if str(exc) != message:
            raise RuntimeError('wrong negative-control rejection: ' + fault + ': ' + str(exc)) from exc
        print(fault + ' rejected: ' + str(exc))
        return
    raise RuntimeError('negative control accepted: ' + fault)


def main():
    app, prior = None, ()
    for case in ('producer_reuse', 'output_pressure_window', 'output_pressure_ready'):
        app = check(case, app=app, prior=prior, final=case == 'output_pressure_ready')
        prior += (case,)
    check('producer_reuse', slot=0, generation=41, final=True)
    check('output_pressure_ready', echo_order='last', final=True)
    for case in ('producer_reuse', 'output_pressure_window', 'output_pressure_ready'):
        rejected(case, 'body_hash', 'record mismatch: sha256')
        rejected(case, 'diagnostic_hash', 'producer identity')
        rejected(case, 'output_hash', 'producer checkpoint differs' if case == 'output_pressure_window' else 'body length or digest differs')
        rejected(case, 'output_status', 'wrong final status')
        rejected(case, 'missing_end', 'missing finite synthetic response')
        rejected(case, 'deadline', 'deadline expired or invalid')
        rejected(case, 'backwards_time', 'monotonic time moved backwards')
        rejected(case, 'missing_ack', 'missing finite synthetic response')
        rejected(case, 'other_record', 'record mismatch: middleware', final=True)
    for case in ('producer_reuse', 'output_pressure_window'):
        rejected(case, 'early_data', 'Flow control window shrunk below 0')
        rejected(case, 'early_end', 'invalid terminal')
        rejected(case, 'identity', 'producer identity changed')
        rejected(case, 'counter', 'producer held state')
        rejected(case, 'monotonic', 'producer counter decreased')
    rejected('output_pressure_window', 'prefix_end', 'invalid terminal')
    rejected('output_pressure_ready', 'missing_sibling', 'missing finite synthetic response')
    rejected('producer_reuse', 'binding_generation', 'relative reuse binding')
    rejected('producer_reuse', 'binding_slot', 'relative reuse binding')
    rejected('producer_reuse', 'after_reuse', 'reuse callback missing')
    for case in ('output_pressure_window', 'output_pressure_ready'):
        rejected(case, 'sibling', 'sibling echo differs')


if __name__ == '__main__':
    main()
