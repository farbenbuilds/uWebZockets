"""Synthetic in-memory public-codec proof of the buffered schedule."""
import json
import hashlib
import h2_client
import hpack
import adapter
import model


def frame(kind, flags, stream, payload):
    return len(payload).to_bytes(3, 'big') + bytes((kind, flags)) + stream.to_bytes(4, 'big') + payload


def check(case='ready_buffered', final=False, *, clock=lambda: 2, after_case=None):
    decoder, encoder = hpack.Decoder(), hpack.Encoder()
    state = {'bytes': bytearray(), 'pending': [], 'paths': [], 'stream': None, 'body': bytearray(), 'startup': True, 'upload_bytes': 0, 'hash': hashlib.sha256(), 'heads': [], 'header_flags': [], 'data_count': 0, 'end_count': 0}

    def send(data):
        if state['startup']:
            state['startup'] = False
            return
        state['bytes'].extend(data)
        while len(state['bytes']) >= 9:
            size = int.from_bytes(state['bytes'][:3], 'big')
            if len(state['bytes']) < 9 + size:
                return
            packet = bytes(state['bytes'][:9 + size])
            del state['bytes'][:9 + size]
            kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
            if kind == 1:
                headers = decoder.decode(packet[9:])
                path = dict(headers)[':path']
                state['paths'].append(path)
                state['heads'].append(headers)
                state['header_flags'].append(flags)
                state['stream'] = stream
                if flags & 1:
                    respond(path, stream)
            elif kind == 0:
                state['data_count'] += 1
                state['end_count'] += int(bool(flags & 1))
                if state['paths'][-1].startswith('/upload/'):
                    payload = packet[9:]
                    state['upload_bytes'] += len(payload)
                    state['hash'].update(payload)
                    update = len(payload).to_bytes(4, 'big')
                    state['pending'].append(frame(8, 0, 0, update) + frame(8, 0, stream, update))
                else:
                    state['body'].extend(packet[9:])
                if flags & 1:
                    respond(state['paths'][-1], stream)

    def respond(path, stream):
        if path == '/health':
            body = b'ok'
        elif path == '/echo':
            body = bytes(state['body'])
        elif path == '/delayed':
            body = b'delayed-ok'
        elif path.startswith('/upload/'):
            record = model.record(case, True, 'after')
            record.update(chunks=12208, max_span=8192)
            body = json.dumps(record).encode()
        elif path.startswith('/status/'):
            record = model.record(path[8:], path[8:] == case and case.startswith('large_'), 'before')
            if record['bytes']:
                record.update(chunks=12208, max_span=8192)
            body = json.dumps(record).encode()
        elif path == '/metrics':
            selection = (case,) if state['upload_bytes'] == 100000000 or len(state['paths']) > 5 else ()
            metrics = model.metrics(selection, 'before')
            metrics.update(buffered_middleware=len(state['paths']) - metrics['middleware'], slot0_active=False, slot1_active=False)
            body = json.dumps(metrics).encode()
        else:
            raise RuntimeError('unexpected request')
        headers = ((':status', '200'), ('content-type', 'text/plain')) if path == '/delayed' else ((':status', '200'), ('x-middleware', 'retained'))
        block = encoder.encode(headers)
        state['pending'].append(frame(1, 4, stream, block) + frame(0, 1, stream, body))

    def receive():
        if not state['pending']:
            raise RuntimeError('unexpected receive')
        return state['pending'].pop(0), 2

    context = adapter.open_case(case, h2_client.new_protocol(), send, 1, 30001, 900001, clock=clock)
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    adapter.observe(context, frame(4, 0, 0, settings) + frame(4, 1, 0, b''), 2)
    adapter.run_case(context, receive)
    if after_case is not None:
        after_case(context, receive)
    expected = ['/health', '/delayed', '/health'] if case == 'async_delayed' else ['/health', '/metrics', '/echo' if case == 'ready_buffered' else '/upload/' + case, '/metrics', '/health']
    if final:
        adapter.final_collection(context, receive)
        expected += ['/status/' + row[0] for row in model.BODY_SPECS] + ['/metrics']
    if state['paths'] != expected:
        raise RuntimeError('request order differs')
    if context['request']['case']['sent'] != (257 if case == 'ready_buffered' else 0 if case == 'async_delayed' else 100000000) or context['stage']['case_state']['heads'] != len(expected):
        raise RuntimeError('case totals differ')
    for index, path in enumerate(expected):
        head = dict(state['heads'][index])
        primary = path in ('/echo', '/delayed') or path.startswith('/upload/')
        expected_head = {':method': 'POST' if primary and case != 'async_delayed' else 'GET',
                         ':scheme': 'https', ':authority': 'localhost', ':path': path}
        if primary and case in ('ready_buffered', 'large_declared'):
            expected_head['content-length'] = '257' if case == 'ready_buffered' else '100000000'
        if head != expected_head or len(state['heads'][index]) != len(expected_head):
            raise RuntimeError('request contract differs')
        if bool(state['header_flags'][index] & 1) != (not primary or case == 'async_delayed'):
            raise RuntimeError('request header terminal differs')
    if case == 'ready_buffered' and (bytes(state['body']) != model.core_request(case)['body'] or state['data_count'] != 1 or state['end_count'] != 1):
        raise RuntimeError('echo request body differs')
    if case == 'async_delayed' and state['data_count'] != 0:
        raise RuntimeError('delayed request DATA differs')
    if case.startswith('large_'):
        if state['data_count'] != 12208 or state['end_count'] != 1:
            raise RuntimeError('upload DATA actions differ')
        if state['hash'].hexdigest() != model.LARGE_HASH or state['upload_bytes'] != 100000000:
            raise RuntimeError('large payload differs')
        headers = dict(state['heads'][2])
        if headers.get('content-length') != ('100000000' if case == 'large_declared' else None):
            raise RuntimeError('declaration differs')
    print(case + ' codec schedule passed')


if __name__ == '__main__':
    check()
