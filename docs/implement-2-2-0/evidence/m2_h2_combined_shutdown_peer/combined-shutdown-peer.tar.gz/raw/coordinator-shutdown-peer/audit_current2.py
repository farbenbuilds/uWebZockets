"""Audit retained source, immutable inputs, and independent evidence."""
import importlib.util
import json
from pathlib import Path


def main():
    evidence = Path(__file__).resolve().parent
    root = evidence.parents[1]
    spec = importlib.util.spec_from_file_location('prior_audit', root / 'evidence/core-peer/audit.py')
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    audit.immutable(root, evidence)
    baseline = json.loads((evidence / 'baseline-source-hashes.json').read_text())
    current = {path.name: audit.sha(path) for path in sorted(root.glob('*.py'))}
    audit.require(len(current) == 39 and set(current) == set(baseline), 'inventory differs')
    changed = {name for name in current if current[name] != baseline[name]}
    audit.require(changed == {'test_shutdown.py'}, 'source scope differs')
    for name, digest in baseline.items():
        audit.require(audit.sha(evidence / 'before-source' / name) == digest, 'baseline differs: ' + name)
    history = json.loads((evidence / 'prior-evidence-hashes.json').read_text())
    for name, digest in history.items():
        audit.require(audit.sha(root / 'evidence' / name) == digest, 'prior evidence differs: ' + name)
    output = evidence / 'audit2-output'
    output.mkdir(exist_ok=False)
    audit.structure(root, output)
    audit.inert_helpers(evidence)
    audit.snapshot(root, evidence, 'final2-source')
    print('source=39 changed=%s prior_evidence=%d preserved' % (sorted(changed), len(history)))


if __name__ == '__main__':
    main()
