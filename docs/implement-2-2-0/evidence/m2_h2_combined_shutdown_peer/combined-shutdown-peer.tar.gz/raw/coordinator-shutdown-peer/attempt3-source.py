"""Serialized shutdown schedules with supplied teardown and app facts only."""
import copy
import hashlib
import json
import adapter
import catalogue
import h2_client
import hpack
import model
import output_stage
import test_lifecycle
import test_ready
import test_core_peer
import test_producer_pressure
import test_file_early


def require(value, message):
    if not value:
        raise RuntimeError(message)


def corrupt(result, fault, group):
    recipes = (('signal_name', 'signal', 'signal', 'SIGINT'), ('signal_open', 'signal', 'client_open', None),
               ('signal_watcher', 'signal', 'watcher_installed', False), ('signal_extra', 'signal', 'extra', True),
               ('process_reaped', 'process', 'reaped', 1), ('process_forced', 'process', 'forced', True),
               ('process_run', 'process', 'run_ok', False), ('process_deinit', 'process', 'deinit_ok', False),
               ('process_key', 'process', 'key_removed', False), ('process_extra', 'process', 'extra', True),
               ('termination_phase', 'termination', 'phase', 'pre_unwrap'), ('termination_extra', 'termination', 'extra', True),
               ('close_method', 'close', 'method', 'ssl_unwrap'), ('close_kind', 'close', 'close', 'forced'),
               ('close_extra', 'close', 'extra', True))
    for name, kind, key, value in recipes:
        if fault == name and group == kind:
            result[key] = value
    return result


def private_capture(context):
    require('final_observations' not in context and 'shutdown_observations' not in context,
            'shutdown comparison baseline exposed to hook')


def alias_post(context, result, fault):
    if fault == 'alias_record':
        result['records']['shutdown_active']['max_span'] = 7
        if 'final_observations' in context:
            context['final_observations']['records']['shutdown_active']['max_span'] = 7
        return
    if fault == 'alias_output':
        fields = ('pending', 'invocations', 'checks', 'blocked', 'attempts')
        for key in fields:
            result['outputs']['producer_reuse'][key] += 1
            context['output_observations']['producer_reuse'][key] += 1
        if 'final_observations' in context:
            context['final_observations']['outputs']['producer_reuse'].update(result['outputs']['producer_reuse'])
        return
    result['binding']['binding_generation'] += 1
    result['outputs']['producer_reuse']['binding_generation'] += 1
    context['output_binding']['binding_generation'] += 1
    context['output_observations']['producer_reuse']['binding_generation'] += 1
    if 'final_observations' in context:
        context['final_observations']['binding'].update(result['binding'])
        context['final_observations']['outputs']['producer_reuse'].update(result['outputs']['producer_reuse'])


def new_peer(case, *, app, prior, now, clock, fault=None):
    if type(case) is not str or case not in ('shutdown_idle', 'shutdown_active'):
        raise ValueError('unsupported shutdown peer')
    if type(app) is not dict or set(app) != {'records', 'heads', 'outputs', 'binding'}:
        raise ValueError('app fields differ')
    catalogue.schedule(prior)
    prior = tuple(prior)
    if case == 'shutdown_idle' and prior:
        raise ValueError('idle child must be first')
    if any(item in prior for item in ('shutdown_idle', 'shutdown_active')):
        raise ValueError('shutdown prior differs')
    if type(now) is not int or not 0 <= now < catalogue.U64 or not callable(clock) or fault is not None and type(fault) is not str:
        raise ValueError('peer arguments differ')
    model.validate_records(prior, 'before', app['records'])
    model.validate_outputs(prior, app['outputs'])
    model.validate_binding_pre_post(prior, app['binding'], model.default_binding() if app['binding'] is None else app['binding'],
                                    app['outputs']['producer_reuse'] if 'producer_reuse' in prior else None)
    if type(app['heads']) is not int or app['heads'] != sum(catalogue.case_budget(item)['heads'] for item in prior):
        raise ValueError('prior heads not earned')
    state = dict(startup=True, buffer=bytearray(), pending=[], heads=0, status=0, metrics=0,
                 data=0, ends=0, settings=0, signal=False, closed=False, reads=0, max_buffer=0,
                 decoder=hpack.Decoder(max_header_list_size=8192), encoder=hpack.Encoder(), digest=hashlib.sha256())

    def expected_path():
        index = state['heads']
        if index == 0:
            return '/health'
        if case == 'shutdown_active':
            if index == 1:
                return '/limit/shutdown_active?case=shutdown_active'
            if index == 2:
                return '/status/shutdown_active'
            index -= 2
        if index <= len(model.SPECS):
            return '/status/' + tuple(model.SPECS)[index - 1]
        if index == len(model.SPECS) + 1:
            return '/metrics'
        return None

    def response(stream, body):
        block = state['encoder'].encode(((':status', '200'), ('x-middleware', 'retained')))
        packet = test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body)
        require(len(packet) <= 8192 and len(state['pending']) < 2, 'pending packet capacity differs')
        state['pending'].append(packet)

    def packet_received(packet):
        kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
        if kind == 4:
            require(packet == test_ready.frame(4, 1, 0, b''), 'unexpected settings')
            state['settings'] += 1
            return
        if kind == 0:
            require(case == 'shutdown_active' and stream == 3 and flags == 0 and state['data'] == 0, 'request DATA or END differs')
            require(packet[9:] == model.payload_span(32, 0, 32), 'request payload differs')
            state['data'] += len(packet[9:])
            app['records'][case].update(bytes=7, chunks=1, max_span=32, paused=True,
                                        sha256=hashlib.sha256(packet[9:16]).hexdigest())
            state['ends'] += flags & 1
            require(hashlib.sha256(packet[9:]).hexdigest() == model.H32, 'request hash differs')
            return
        require(kind == 1, 'unexpected outgoing frame')
        entries = list(state['decoder'].decode(packet[9:]))
        path = dict(entries)[':path']
        require(path == expected_path() and stream == 2 * state['heads'] + 1, 'request ordering differs')
        upload = path.startswith('/limit/')
        expected = [(':method', 'POST' if upload else 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)]
        if upload:
            expected += [('content-length', '32'), ('x-case', 'shutdown_active')]
        require(entries == expected and flags == (4 if upload else 5), 'request metadata or END differs')
        state['digest'].update(json.dumps((stream, entries, flags)).encode())
        state['heads'] += 1
        app['heads'] += 1
        if upload:
            app['records'][case].update(middleware=1, attempts=1, begins=1, metadata_middleware=1, metadata_begin=1, active=True)
            if fault == 'early_response':
                response(stream, b'')
            return
        if path == '/health':
            response(stream, b'ok')
            return
        if path.startswith('/status/'):
            state['status'] += 1
            tag = path[8:]
            item = dict(app['records'][tag])
            if fault == 'active_hash' and tag == 'shutdown_active':
                item['sha256'] = model.H32
            if fault == 'barrier_changed' and tag == 'shutdown_active' and state['status'] > 1:
                item['max_span'] = 7
            if fault == 'other_record' and tag == 'empty_headers':
                item['middleware'] += 1
            response(stream, json.dumps(item).encode())
            return
        require(path == '/metrics', 'unexpected observation')
        state['metrics'] += 1
        value = test_core_peer.metrics(app)
        value.update(slot0_active=case == 'shutdown_active', slot1_active=False)
        if fault == 'metrics':
            value['buffered_middleware'] += 1
        response(stream, json.dumps(value).encode())

    def send(data):
        require(not state['signal'] and not state['closed'], 'send after shutdown')
        require(type(data) is bytes and len(data) <= 8192, 'send bound differs')
        if state['startup']:
            state['startup'] = False
            require(data[:24] == b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n' and len(data) == 75, 'startup differs')
            return
        require(len(data) <= 8201 - len(state['buffer']), 'parser capacity differs')
        candidate = bytes(state['buffer']) + data
        offset = 0
        while len(candidate) - offset >= 9:
            size = int.from_bytes(candidate[offset:offset + 3], 'big')
            require(size <= 8192, 'frame payload bound differs')
            if len(candidate) - offset < size + 9:
                break
            offset += size + 9
        state['buffer'].extend(data)
        state['max_buffer'] = max(state['max_buffer'], len(state['buffer']))
        while len(state['buffer']) >= 9:
            size = int.from_bytes(state['buffer'][:3], 'big')
            require(size <= 8192, 'frame payload bound differs')
            if len(state['buffer']) < size + 9:
                return
            packet = bytes(state['buffer'][:size + 9])
            del state['buffer'][:size + 9]
            packet_received(packet)

    def receive():
        require(not state['signal'] and not state['closed'], 'receive after shutdown')
        state['reads'] += 1
        require(state['pending'] and state['reads'] <= 150, 'finite response missing')
        packet = state['pending'].pop(0)
        if fault == 'parser_residue' and state['metrics']:
            packet += b'\x00'
        return packet, clock()

    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    state['pending'].append(test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b''))
    connection = dict(protocol=h2_client.new_protocol(), send=send, receive=receive, now=now,
                      owned=True, tls='TLSv1.3', alpn='h2')
    return dict(connection=connection, state=state)


def check(case, *, prior=(), fault=None, units=1000, outcome='eof'):
    app = test_core_peer.new_app()
    app['records'] = model.records(prior, 'before')
    for item in app['records'].values():
        if item.get('chunks', 0) is None:
            item['chunks'] = (item['bytes'] + 8191) // 8192
        if item.get('max_span', 0) is None:
            item['max_span'] = min(item['bytes'], 8192)
    app['heads'] = sum(catalogue.case_budget(item)['heads'] for item in prior)
    for tag in model.PRODUCERS:
        if tag in prior:
            app['outputs'][tag] = test_producer_pressure.diagnostic(tag, 16777313, 1, 17)
    if 'stream_file' in prior:
        app['outputs']['stream_file'] = test_file_early.file_diagnostic(True)
    if 'producer_reuse' in prior:
        app['binding'] = dict(tag='producer_reuse_next', binding_index=1, binding_generation=18)
    retained = {tag: copy.deepcopy(app['outputs'][tag]) for tag in model.PRODUCERS + ('stream_file',) if tag in prior}
    binding = None if app['binding'] is None else dict(app['binding'])
    caller_time = [1]
    peer_state = [None]

    def clock():
        caller_time[0] += 1
        if fault == 'deadline' and peer_state[0]['status'] == 3:
            return 30001
        return caller_time[0]

    peer = new_peer(case, app=app, prior=prior, now=1, clock=clock, fault=fault)
    connection, state = peer['connection'], peer['state']
    peer_state[0] = state
    receive = connection['receive']
    context = adapter.open_case(case, connection['protocol'], connection['send'], connection['now'], 30001, 900001, selected_before=prior, clock=clock)
    startup, timestamp = receive()
    adapter.observe(context, startup, timestamp)
    context['output_observations'] = copy.deepcopy(retained)
    if binding is not None:
        context['output_binding'] = dict(binding)
    if fault == 'retained_missing':
        context['output_observations'] = {}
    identities = {name: context[name] for name in ('stage', 'raw', 'request', 'credit', 'records')}

    def preconditions(current):
        private_capture(current)
        require(current is context and state['heads'] == 0, 'preconditions after effects')
        result = dict(client_open=True, prior_complete=True) if case == 'shutdown_active' else dict(client_open=True, fresh_application=True)
        if fault == 'precondition':
            result['client_open'] = 1
        return result

    def signal(current, deadline):
        private_capture(current)
        require(current['stage']['final_complete'] and state['metrics'] == 1 and state['status'] == (68 if case == 'shutdown_active' else 67), 'signal before final collection')
        require(not state['pending'] and not state['buffer'] and state['heads'] == (71 if case == 'shutdown_active' else 69), 'signal before finite boundary')
        require(deadline == (state['grace'] if case == 'shutdown_idle' else min(current['now'] + 15 * units, 30001, 900001)), 'grace deadline differs')
        require(all(current[key] is value for key, value in identities.items()), 'final objects replaced')
        require((current['stage']['case_deadline'], current['stage']['whole_deadline']) == (30001, 900001), 'deadline widened')
        if case == 'shutdown_active':
            require(not state['closed'] and set(current['records']) == {3} and not current['stage']['primary_complete'], 'held primary fabricated complete')
            require(current['request']['connection_debt'] == 32 and current['request']['stream_debt_total'] == 32, 'final debt lost')
            require(current['stage']['final_budget'] == catalogue.final_budget(64), 'final debt bound differs')
        else:
            require(state['closed'] and not current['records'] and not current['stage']['active'] and not current['credit']['streams'], 'idle residue or client still open')
        state['signal'] = True
        state['before_records'] = copy.deepcopy(app['records'])
        if case == 'shutdown_active':
            app['records'][case].update(cancels=1, active=False, paused=False, reason='shutdown')
        result = dict(signal='SIGTERM', owned_identity=True, watcher_installed=True, client_open=case == 'shutdown_active')
        if fault == 'signal':
            result['owned_identity'] = 1
        if fault == 'late_observation':
            adapter.get(current, '/health', receive)
        return corrupt(result, fault, 'signal')

    def termination(current, deadline):
        private_capture(current)
        require(current['stage']['signaled'] and current['raw']['closing']['phase'] == 'post_signal', 'canonical post-signal phase missing')
        result = dict(phase='post_signal', outcome=outcome, primary_response=False, frames_valid=True, trailing_bytes=0)
        field = {'termination': 'outcome', 'trailing': 'trailing_bytes', 'trailing_bool': 'trailing_bytes', 'primary_response': 'primary_response', 'frames': 'frames_valid'}.get(fault)
        if field is not None:
            result[field] = 'reset' if field == 'outcome' else False if fault == 'trailing_bool' else 1 if field == 'trailing_bytes' else True if field == 'primary_response' else 1
        return corrupt(result, fault, 'termination')

    def close(current, deadline):
        private_capture(current)
        require(current['stage']['final_complete'] and not state['signal'], 'idle close out of order')
        require(deadline == min(current['now'] + 15 * units, 30001, 900001), 'idle grace deadline differs')
        state['grace'] = deadline
        state['closed'] = True
        return corrupt(dict(method='close', client_closed=1 if fault == 'close' else True, close='normal'), fault, 'close')

    def process(current, deadline):
        private_capture(current)
        require(state['signal'], 'process before signal')
        result = dict(exit_code=0, reaped=True, forced=False, run_ok=True, deinit_ok=True, key_removed=True)
        if fault == 'process':
            result['exit_code'] = False
        if fault == 'late_process':
            caller_time[0] = deadline
        return corrupt(result, fault, 'process')

    def post(current, deadline):
        private_capture(current)
        records = copy.deepcopy(app['records'])
        if fault == 'post_chunks':
            records['shutdown_active']['max_span'] = 7
        if fault == 'post_record':
            records['empty_headers']['middleware'] += 1
        metrics = test_core_peer.metrics(app)
        metrics.update(slot0_active=False, slot1_active=False)
        if fault == 'post_metrics':
            metrics['buffered_middleware'] += 1
        output = copy.deepcopy(app['outputs'])
        result = dict(records=records, metrics=metrics, outputs=output, binding=model.default_binding() if binding is None else dict(binding))
        if fault == 'post_output':
            result['outputs']['stream_file']['close_calls'] = 1
        if fault == 'post_binding':
            result['binding']['binding_generation'] = 1
        if fault == 'selected_output':
            result['outputs']['producer_reuse']['binding_generation'] += 1
        if fault == 'selected_binding':
            result['binding']['binding_generation'] += 1
        if fault in ('alias_record', 'alias_output', 'alias_binding'):
            alias_post(current, result, fault)
        return result

    hooks = dict(preconditions=preconditions, signal=signal, process=process, post=post, units_per_second=units)
    hooks['termination' if case == 'shutdown_active' else 'close'] = termination if case == 'shutdown_active' else close
    if fault == 'hooks':
        hooks['extra'] = close
    if fault == 'hook_missing':
        del hooks['post']
    if fault == 'hook_callable':
        hooks['signal'] = None
    if fault == 'units_bool':
        hooks['units_per_second'] = True
    if fault == 'units_zero':
        hooks['units_per_second'] = 0
    require(adapter.run_case(context, receive, shutdown=hooks) is context, 'shutdown context return changed')
    if fault in ('alias_record', 'alias_output', 'alias_binding'):
        raise RuntimeError('shutdown schedule accepted aliased post evidence')
    require(context['final_observations'] is context['shutdown_observations']['before'], 'shutdown final capture duplicated or lost')
    require(context['final_observations']['records'] == state['before_records'], 'shutdown retained parsed facts differ')
    require(context['completed'] and context['stage']['final_complete'], 'shutdown incomplete')
    expected = (71, 70, 32) if case == 'shutdown_active' else (69, 69, 0)
    require((state['heads'], context['stage']['case_state']['small'] + context['stage']['final_registered'], state['data']) == expected, 'exact J C R differs')
    require(state['ends'] == 0 and state['settings'] == 1 and state['metrics'] == 1, 'END settings collection counts differ')
    require(not state['pending'] and not state['buffer'] and not context['records'] and not context['stage']['active'], 'shutdown response residue')
    if case == 'shutdown_idle':
        test_lifecycle.reject_call(output_stage.signal, 'invalid shutdown signal', context['stage'])
    test_lifecycle.reject_call(adapter.observe, 'observation after shutdown', context, b'x', clock())
    print(case + ' passed: J=%d C=%d R=%d request_sha256=%s' % (*expected, state['digest'].hexdigest()))
    return context


def construction_checks():
    def forbidden_clock():
        raise RuntimeError('constructor invoked clock')

    for case in ('shutdown_idle', 'shutdown_active'):
        app = test_core_peer.new_app()
        before = copy.deepcopy(app)
        peer = new_peer(case, app=app, prior=(), now=9, clock=forbidden_clock)
        state, connection = peer['state'], peer['connection']
        require(set(peer) == {'connection', 'state'} and set(connection) == {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'}, 'constructor schema differs')
        require(app == before and state['startup'] and state['heads'] == 0 and state['data'] == 0, 'constructor earned facts')
        require(connection['now'] == 9 and connection['owned'] is True and connection['tls'] == 'TLSv1.3' and connection['alpn'] == 'h2', 'synthetic facts differ')
        require(len(state['pending']) == 1 and state['decoder'].max_allowed_table_size == 4096 and state['encoder'].header_table_size == 4096, 'startup or HPACK bounds differ')
        connection['send'](connection['protocol'].data_to_send())
        partial = b'\x00\x20\x01\x00\x00\x00\x00\x00'
        connection['send'](partial)
        saved = (bytes(state['buffer']), state['max_buffer'])
        for unused in range(2):
            try:
                connection['send'](b'\x01')
            except RuntimeError as exc:
                require(str(exc) == 'frame payload bound differs', 'wrong frame limit rejection')
            else:
                raise RuntimeError('oversized frame accepted')
            require((bytes(state['buffer']), state['max_buffer']) == saved, 'rejected frame grew parser')
        require(app == before, 'malformed fragment earned facts')
    for case, prior in (('unsupported', ()), ('shutdown_idle', ('empty_headers',)), ('shutdown_active', ('empty_headers',))):
        app = test_core_peer.new_app()
        before = copy.deepcopy(app)
        try:
            new_peer(case, app=app, prior=prior, now=1, clock=forbidden_clock)
        except ValueError:
            require(app == before, 'invalid constructor mutated app')
        else:
            raise RuntimeError('invalid constructor accepted')
    print('shutdown constructors preserve app and clock; repeated oversized fragments preserve parser')


def serialized_active_check():
    app = test_core_peer.new_app()
    peer = new_peer('shutdown_active', app=app, prior=(), now=1, clock=lambda: 2)
    connection, state = peer['connection'], peer['state']
    send = connection['send']
    send(connection['protocol'].data_to_send())
    connection['receive']()
    send(test_ready.frame(4, 1, 0, b''))
    encoder = hpack.Encoder()
    common = [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', '/health')]
    send(test_ready.frame(1, 5, 1, encoder.encode(common)))
    connection['receive']()
    entries = [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'),
               (':path', '/limit/shutdown_active?case=shutdown_active'), ('content-length', '32'), ('x-case', 'shutdown_active')]
    send(test_ready.frame(1, 4, 3, encoder.encode(entries)))
    item = app['records']['shutdown_active']
    require((item['middleware'], item['begins'], item['active'], item['bytes'], item['paused']) == (1, 1, True, 0, False), 'active metadata facts differ')
    payload = model.payload_span(32, 0, 32)
    send(test_ready.frame(0, 0, 3, payload))
    require((item['bytes'], item['chunks'], item['max_span'], item['sha256'], item['paused']) == (7, 1, 32, hashlib.sha256(payload[:7]).hexdigest(), True), 'active DATA facts differ')
    values = test_core_peer.metrics(app)
    require((values['middleware'], values['bytes'], values['active'], values['paused'], values['buffered_middleware']) == (1, 7, 1, 1, 1), 'independent metrics differ')
    require(not state['pending'] and state['ends'] == 0 and app['outputs'] == model.default_outputs() and app['binding'] is None, 'selected completion fabricated')
    print('serialized active metadata and DATA earn record and metrics')


def rejected(case, fault, message, *, prior=()):
    try:
        check(case, fault=fault, prior=prior)
    except (ValueError, RuntimeError) as error:
        require(str(error) == message, 'wrong rejection for ' + fault + ': ' + str(error))
        print(fault + ' rejected: ' + str(error))
        return
    raise RuntimeError('corruption accepted: ' + fault)


def main():
    construction_checks()
    serialized_active_check()
    check('shutdown_idle')
    check('shutdown_active')
    check('shutdown_active', prior=('empty_headers', 'reuse'))
    check('shutdown_active', outcome='tls_eof', units=2000)
    output_prior = ('empty_headers', 'reuse', 'producer_reuse', 'output_pressure_window', 'output_pressure_ready', 'stream_file', 'early_final_order')
    check('shutdown_active', prior=output_prior)
    shared = (('hooks', 'shutdown hooks required'), ('precondition', 'shutdown preconditions differ'),
              ('other_record', 'record mismatch: middleware'), ('metrics', 'metrics differ'),
              ('signal', 'owned signal evidence differs'), ('process', 'shutdown process evidence differs'),
              ('post_record', 'record mismatch: middleware'), ('post_metrics', 'metrics differ'),
              ('post_output', 'unselected output differs'), ('post_binding', 'unselected binding differs'),
              ('deadline', 'deadline expired or invalid'), ('late_process', 'shutdown grace deadline expired'),
              ('parser_residue', 'finite response missing'), ('late_observation', 'observation after shutdown'))
    for case in ('shutdown_active', 'shutdown_idle'):
        for fault, message in shared:
            rejected(case, fault, message)
    for fault, message in (('active_hash', 'record mismatch: sha256'), ('barrier_changed', 'shutdown barrier changed before signal'),
                           ('post_chunks', 'shutdown changed nonterminal evidence'), ('early_response', 'unexpected closing target payload'),
                           ('termination', 'post-signal termination differs'), ('trailing', 'post-signal termination differs'),
                           ('trailing_bool', 'post-signal termination differs'), ('primary_response', 'post-signal termination differs'),
                           ('frames', 'post-signal termination differs')):
        rejected('shutdown_active', fault, message)
    rejected('shutdown_idle', 'close', 'idle close evidence differs')
    for case in ('shutdown_active', 'shutdown_idle'):
        for fault in ('signal_name', 'signal_open', 'signal_watcher', 'signal_extra'):
            rejected(case, fault, 'owned signal evidence differs')
        for fault in ('process_reaped', 'process_forced', 'process_run', 'process_deinit', 'process_key', 'process_extra'):
            rejected(case, fault, 'shutdown process evidence differs')
        for fault in ('hook_missing', 'hook_callable', 'units_bool', 'units_zero'):
            rejected(case, fault, 'shutdown hooks required')
    for fault in ('termination_phase', 'termination_extra'):
        rejected('shutdown_active', fault, 'post-signal termination differs')
    for fault in ('close_method', 'close_kind', 'close_extra'):
        rejected('shutdown_idle', fault, 'idle close evidence differs')
    rejected('shutdown_active', 'retained_missing', 'retained output observations differ', prior=output_prior)
    rejected('shutdown_active', 'selected_output', 'post-deinit output changed', prior=output_prior)
    rejected('shutdown_active', 'selected_binding', 'post-deinit binding changed', prior=output_prior)
    rejected('shutdown_idle', 'prior_idle', 'idle child must be first', prior=('empty_headers',))
    rejected('shutdown_active', 'alias_record', 'shutdown changed nonterminal evidence')
    rejected('shutdown_active', 'alias_output', 'post-deinit output changed', prior=('producer_reuse',))
    rejected('shutdown_active', 'alias_binding', 'post-deinit output changed', prior=('producer_reuse',))


if __name__ == '__main__':
    main()
