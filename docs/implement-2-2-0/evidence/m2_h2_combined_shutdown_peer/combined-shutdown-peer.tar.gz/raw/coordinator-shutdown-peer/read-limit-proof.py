"""Check that rejected reads cannot grow the bounded counter."""
import importlib.util
import sys
import test_core_peer


def main():
    spec = importlib.util.spec_from_file_location('tested_shutdown', sys.argv[1])
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    peer = module.new_peer('shutdown_idle', app=test_core_peer.new_app(), prior=(), now=1, clock=lambda: 2)
    connection, state = peer['connection'], peer['state']
    connection['send'](connection['protocol'].data_to_send())
    state['reads'] = 150
    before = list(state['pending'])
    for unused in range(2):
        try:
            connection['receive']()
        except RuntimeError as exc:
            if str(exc) != 'finite response missing':
                raise
        else:
            raise RuntimeError('read bound accepted')
        if state['reads'] != 150 or state['pending'] != before:
            raise RuntimeError('rejected read changed bounded state')
    print('repeated rejected reads preserve counter and queue')


if __name__ == '__main__':
    main()
