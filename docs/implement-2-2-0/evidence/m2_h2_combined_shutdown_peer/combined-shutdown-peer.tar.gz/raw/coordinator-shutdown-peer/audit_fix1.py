"""Audit retained source, immutable inputs, and independent evidence."""
import ast
import importlib.util
import json
from pathlib import Path


def main():
    evidence = Path(__file__).resolve().parent
    root = evidence.parents[1]
    spec = importlib.util.spec_from_file_location('prior_audit', root / 'evidence/core-peer/audit.py')
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    audit.immutable(root, evidence)
    baseline = json.loads((evidence / 'baseline-source-hashes.json').read_text())
    current = {path.name: audit.sha(path) for path in sorted(root.glob('*.py'))}
    audit.require(len(current) == 39 and set(current) == set(baseline), 'inventory differs')
    changed = {name for name in current if current[name] != baseline[name]}
    audit.require(changed == {'test_shutdown.py'}, 'source scope differs')
    for name, digest in baseline.items():
        audit.require(audit.sha(evidence / 'before-source' / name) == digest, 'baseline differs: ' + name)
    history = json.loads((evidence / 'prior-evidence-hashes.json').read_text())
    for name, digest in history.items():
        audit.require(audit.sha(root / 'evidence' / name) == digest, 'prior evidence differs: ' + name)
    output = evidence / 'fix1-audit-output'
    output.mkdir(exist_ok=False)
    frozen3 = json.loads((evidence / 'final3-source.json').read_text())
    audit.require({path.name: audit.sha(path) for path in sorted((evidence / 'final3-source').glob('*.py'))} == frozen3, 'final3 frozen source differs')
    history = json.loads((evidence / 'fix1-before-evidence-map.json').read_text())
    for name, digest in history.items():
        audit.require(audit.sha(evidence / name) == digest, 'pre-fix evidence differs: ' + name)
    reviewed = json.loads((evidence / 'fix1-reviewed-map.json').read_text())
    for name, digest in reviewed.items():
        audit.require(audit.sha(evidence / 'fix1-before' / name) == digest, 'reviewed freeze differs: ' + name)
        audit.require(audit.sha(evidence / 'final4-source' / name) == digest, 'final4 freeze differs: ' + name)
    red = ast.parse((evidence / 'fix1-red-source.py').read_text())
    red.body = [node for node in red.body if not isinstance(node, ast.FunctionDef) or node.name != 'premature_data_check']
    main_function = next(node for node in red.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
    main_function.body = [node for node in main_function.body if not (isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == 'premature_data_check')]
    audit.require(ast.dump(red) == ast.dump(ast.parse((evidence / 'fix1-before/test_shutdown.py').read_text())), 'RED differs beyond new test')
    print('reviewed39 and RED production structure matched; pre-fix evidence=%d preserved' % len(history))
    audit.structure(root, output)
    audit.inert_helpers(evidence)
    audit.snapshot(root, evidence, 'fix1-final-source')
    print('source=39 changed=%s prior_evidence=%d preserved' % (sorted(changed), len(history)))


if __name__ == '__main__':
    main()
