import copy
import test_core_peer
import test_shutdown

app = test_core_peer.new_app()
before = copy.deepcopy(app)
def clock():
    raise RuntimeError('constructor invoked clock')
peer = test_shutdown.new_peer('shutdown_idle', app=app, prior=(), now=1, clock=clock)
if set(peer) != {'connection', 'state'} or set(peer['connection']) != {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'}:
    raise RuntimeError('constructor schema differs')
if app != before:
    raise RuntimeError('constructor mutated application')
