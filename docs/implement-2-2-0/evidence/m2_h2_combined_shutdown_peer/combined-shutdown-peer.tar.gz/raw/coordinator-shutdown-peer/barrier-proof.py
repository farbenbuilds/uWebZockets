"""Prove the serialized barrier requires actual DATA."""
import importlib.util
import sys
import hpack
import test_core_peer
import test_ready


def main():
    spec = importlib.util.spec_from_file_location('tested_shutdown', sys.argv[1])
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    app = test_core_peer.new_app()
    peer = module.new_peer('shutdown_active', app=app, prior=(), now=1, clock=lambda: 2)
    connection = peer['connection']
    send = connection['send']
    send(connection['protocol'].data_to_send())
    connection['receive']()
    send(test_ready.frame(4, 1, 0, b''))
    encoder = hpack.Encoder()
    def request(stream, method, path, extra=()):
        entries = [(':method', method), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)]
        entries.extend(extra)
        send(test_ready.frame(1, 4 if method == 'POST' else 5, stream, encoder.encode(entries)))
    request(1, 'GET', '/health')
    connection['receive']()
    request(3, 'POST', '/limit/shutdown_active?case=shutdown_active', (('content-length', '32'), ('x-case', 'shutdown_active')))
    try:
        request(5, 'GET', '/status/shutdown_active')
    except RuntimeError as exc:
        if str(exc) != 'barrier before request DATA':
            raise
        print('barrier rejected before DATA')
        return
    raise RuntimeError('barrier accepted before DATA')


if __name__ == '__main__':
    main()
