# Coordinator phase2 composition contract

Read-only architect refinement. No code/tests/imports/runtime operations.
Three serial slices collectively preserve ALL phase2 requirements: ordinary
composition, disconnect, then idle/active children. Actual default/all40 and
independent aggregate acceptance remain mandatory following phases.

## Reuse and exact descriptors

Reuse read_time,validate_connection,copy_facts,ordinary finish_child,COUNT_FIELDS,
and single-connection snapshot_counts. Generalize run/descriptor validation.
Disconnect needs old connection-local statistics added explicitly, never old
cumulative case counters twice.

Factory signature/run-ID grammar/logical child identity/connection facts stay.
For actual child_selection exact keys are:

    common={identity,ready,fresh_application,connect,signal,process,post}
    +close if any selected case is not shutdown_active
    +disconnect_close if disconnect selected
    +preconditions if idle or active shutdown selected
    +termination if active selected

Reject extra/missing keys; validate callbacks before connect; copy validated
descriptor so later factory-map mutation cannot replace callbacks. Ordinary
keeps eight fields; idle adds preconditions; active-only has no unusedclose;
main endingactive needsclose for preceding ordinary releases. Disconnect only
adds disconnect_close, replacement reusesconnect. No releasecallback/registry/
handler injection/unusedcleanup interface.

connect(case,case_connection_index,case_deadline,whole_deadline): existing7field
result; index1 normally,1then2 fordisconnect. close(context,deadline): existing
normal-close facts for intermediate ordinary and final ordinary/idle.
disconnect_close(context): strict ssl_unwrap/success/tcp_eofTrue/integer0
trailing/normal dictionary, canonical lifecycle validates. preconditions(ctx):
active client_openTrue/prior_completeTrue; idle client_openTrue/freshTrue.
termination(ctx,deadline): post_signal/eof|tls_eof/primary_responseFalse/
frames_validTrue/integer0 trailing. Signal/process/post signatures/schemas
unchanged; active signal client_openTrue, ordinary/idleFalse. Construct existing
run_case hook dictionaries including units only for selected lifecycle case.

## Ordinals and accounting

Child index zero-based from child_plan; case position in caller order; evidence
connection identity=(child_identity,child_connection_ordinal), ordinal starts1
and advances for every actual connection, including replacement. Do not change
connect's case-local index: ready->disconnect uses1,1,2 while evidence uses1,2,3.
No global Pythonid/FD/address uniqueness assumption. Fresh canonical state and
the existing still-live original/replacement identity check remain valid.

For each completedcase snapshot cumulative case once: heads,prefinalsmall,
requestflow,connections,incomingresets,bytes,reads; add final registrations once.
Sum connection-local settings/info separately. On disconnect capture oldlocal
stats after canonical termination and before replacement creation; add only
local stats to finalcase snapshot, never oldcumulativeheads/flow/bytes/reads.
Checked additions case->child->run. Freeze counters before exposed-context
teardown callbacks can mutate them.

## Intermediate release/final

For nonterminalordinary: actual run_case -> completion/count/quiescence checks
-> copy earned outputs/binding/counts -> close -> validate/copyclose/recheck
originaldeadline -> commit selected-before -> nextconnect/dispatch.

Quiescent: no partialrawframe/active response or stage records/pending SETTINGS;
requeststreams retired/closed perterminalpolicy. Positive late debt permitted.
Close receives min(case_deadline,whole_deadline), never newgrace; no health/
status/output/final requests, no signal/deinit. Set observationboundary before
close. Preserve debts/counters, no fake refund/final. Failure stops before next
connection/dispatch, retains already-earned bounded evidence, no successful
result. No cleanup framework or conversion of failure to pass.

Only lastordinary appends final68/finish_child. Active/idle do their own; do not
collect/finish again. For disconnect wrap strictclose and coordinator replacement
factory. Replacement runs after successful canonical stricttermination, captures
oldlocalstats/debt, calls connect(disconnect,2,samecase,whole), validates facts
and time handoff. None keeps originalctx/receiver; reuse returns samectx without
receiver change; disconnect uses returnedctx['receive']; shutdown returns finalctx.
Only cumulative case objects shared across two independent transports.

## State/privacy/deadlines

Child-owned completed IDs and copied latest output/binding. selected_before is
only successful actual main dispatches; no idle or undispatched seed. Commit
after intermediate release. Attach retained copies to freshctx beforedispatch;
copy latestvalidatedvalues back aftersuccess. Restore child-retained values to
replacementctx beforefinalization because replace_connection drops arbitrary
parentfields. Never reconstruct selectedoutputs frommodelrecipes.

Keep finish_child privatebefore/callbackcopy behavior. For active/idle hook
adapters validate/copy precondition/close/signal/process/termination facts before
anotherhook; validate boundedpostschema/model then copy postgraph. Existing
handlerprivatebaseline enforces equality; never expose it/manufacturefacts/GET.
Copy publishedfinalfacts/teardown intoresult.

Onewholedeadline acrosschildren; eachchild readyinterval clippedtowhole; each
case catalogue timeout beforeconnect. Actualctx/callback timestamps feed next
operation's monotonic handoff. Replacement/finalinheritcase. Oneclippedgrace at
childfinalshutdown. Neverresetcumulativefinalreads or eraseclosed/large debt.

## Results

Keep top-level/count/scope/child meanings. child.deadlines.case means finalcase;
ready/whole/finalgrace unchanged. Add child.connections tuple uniformly, including
ready-only. Each boundedsummary exactkeys:

    case,case_connection,ordinal,case_deadline,settings,informationals,
    receive_bytes,receive_calls,connection_debt,stream_debt_total,release

Bytes/reads connection-local; debt actualatrelease/termination; release copied
normalclose/strictclose/active-termination fact. Length equals actual childconn
count bounded by immutable selectionplan. No transportobjects/callbacks/stream/
read/frame histories. Update exact-schema tests explicitly.

Ordinary/idle teardown keys close,signal,process,post. Active keys
signal,termination,transport,process,post from validated shutdown observations;
transport is canonical result, no inventedclose foractive-only.

## Ordered slices

2A supports all37 ordinary handlers: any valid orderedsubset excluding
disconnect/shutdown_idle/shutdown_active, includingreuse/outputs. Coordinator
developer/http_protocol; verification peers/proof. Realbuffered+streaming both
orders, reuse acrossfreshctx, selectedproducer/file->ordinaryfinal, intermediate
normalrelease, onefinal68. This is not default/native/wholeaggregate acceptance.

2B depends2A: disconnect anywhere inordinaryselection, includinglast.
transport_io/protocol guideclose/independentledgers. Realordinary->disconnect->
ordinary, disconnect->reuse, producer->disconnect-final; returnedreceiver,
olddebt, sharedcaseonce andbothsettings counted.

2C dependsretention/accounting2A/2B: idle-only/idle+main,active-only/mainending
active, fullcatalogueselectionsemantics. Realidle-only,idle+ordinary,active-only,
ordinary+active,output+active,idle+mainwithdisconnect/output. Freshidlefully
finishes beforemainfactory; independentapp/onerun/no duplicatefinal/postsignal
reads. After2C remove artificialdefaultselectionrejection; actualdefaultproof
still separatemandatoryphase.

Expectedsubset examples (derivefromimmutablecontracts intest,notprodconstants):

| Selection | Heads/small | Connections | Flow/other |
| --- | --- | --- | --- |
| ready,large_declared orreverse |78/78|2|100000257flow|
| reuse,ready |462/462|2|545flow|
| producer_reuse,ready |82/81|2| |
| producer_reuse,disconnect |102/100|3|4SETTINGS,128flow|
| idle,ready |142/142|2|2children,2collections|
| ready,active |76/75|2|1child,1collection|

Every slice covers failure-before-nextdispatch, failedrelease,baddescriptor,
expiry/rollback,callbackmutation,missingretainedfacts,validreordering,invalid
shutdownorder,debt. Existingready/empty mustpass.

## Peers/ownership

Small serial dependency/peer extractions: test_coordinator ready/facts;
test_shared persistentrecords/latecredit; test_lifecycle reuse/disconnect/stale;
test_producer_pressure/test_file_early outputmetadata/order/grants/hashes;
test_shutdown sequencing/privacy. Standalone and composition tests should use
same extractedfactory; onlycoordinator invokesclientdispatch. Neverfamilycheck()
that createsindependentcontexts. Boundedframe/HPACK/cursors/hashes/counts/one
pending response; one empty-startchildrecordstore acrossconnections. Apply
synthetic transitions onlyaftercorrespondingserializedactions; releaseoldpeer
buffers afterscalar summaries, no accumulatedpayloads/requesthistories.

Likelyprod ownership coordinator.py plus oneinternal lifecyclehelper onlyif
needed for clarity. Verification owns compositiontests/usedpeers/minimalimports.
Existinghandlers/core/model/fixture/helper/pins unchanged unless exactproven gap.
No immutablecoregapfound. Currentgaps composition/oldconnstats/shutdownfactcopy/
peerconstruction. Scope stayspure_client_synthetic_peer. Default/all40proof,
broadreview/runtime/native/twochild/adoption/fullmilestones remainopen.
