# P7 scoped fix1 re-review

One finding verbatim in task-5e3b7p7-review-report.md: ImportantP2 DATA before
accepted health/upload metadata earns selectedfacts on unopenedstream3.
Review ONLY that finding and newbreakage in task-5e3b7p7-fix-1-review.diff,
5416B SHA2564ad0bdf5c970be5d264c3b53a68ab178abe95c30b0522ab52183b3cb2c16b130.
Fixbase is your frozen final4 source/Rootfinalaudit, current fix1-final-source;
HEAD remains f87ac67139994313402aa14a781104f030ccc971/no taskcommit.

Fix1 appended report task-5e3b7p7-report.md now15070B SHA256
63c9e12932979f39481a8ca5062b427412ff1e0845a427f02e93bd9327c2d8c3;
original10733Bprefix exact. Root task-5e3b7p7-root-fix-1-audit.json verifies
39live/frozen/map/onlyshutdownchanged38unchanged; reviewed39/fourfinal4results
preserved; original5695+fresh333pre-fixunitfiles unchanged;118physical113resolved/
42codecs checked. Fourcurrent covering shutdown/import normalO0-emptyerr;
actualpre-fixREDexit1 prematureDATAaccepted, REDAST equalsreviewed after removing
onlynewtestfunction/call (notposthoc test of changed production code).

Currentguard exactACK1/health+validatedupload cursor beforeDATA/factmutation.
Regression beforehealth andafterhealthpremetadata twice each preserves app,
HEAD/DATA/END/SETTINGS counters/digest/pending/parserempty; firstinvalidframe may
raisehighwater, repeat doesnotgrow. Healthyserializedcase/alloldcontrols run.
Originalhistoricalgaps anddirecthelper/fault-injectedpendingproof unchanged.

Use SDD re-review-prompt.md. Verdict finding ADDRESSED/NOTADDRESSED withline
evidence; inspectfixdiffonly fornewbreakage; untouched observations separately
nonblocking. No broadreview/source/suite repeats; supportingpathonlyspecific
claimdoubt. Same read-only/noagents/Git/services/native/network/graphify/pinned
purecodecs constraints. Return full verdict, notedit. Root savesbeforepub.
