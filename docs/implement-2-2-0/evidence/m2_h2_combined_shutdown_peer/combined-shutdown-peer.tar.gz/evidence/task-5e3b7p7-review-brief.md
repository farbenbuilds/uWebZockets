# Shared shutdown peer source review

Review one P7 source-preparation task. Requirements task-5e3b7p7-brief.md and
task-5e3b7p7-proof-completion-brief.md; claims task-5e3b7p7-report.md (10733B,
SHA1ddb671d95358a05a9d7782d6d55f4023b8a09fdd57e4495698901b83376a243).
Full diff task-5e3b7p7-review-source.diff 29035B SHA256
2dddd6f023d3deaf58a2f84004ea4150cc08534626168ff4b04fae66c01c386a.
BASEf87ac67139994313402aa14a781104f030ccc971/no taskcommit. Root final audit
task-5e3b7p7-root-final-audit.json verifies39live/final4frozen/map/beforeP6exact,
onlytest_shutdownchanged38unchanged; fourcurrentnormalO0-emptyerr, fresh5695
priorhashes/all118physical113resolved+42orderedcodecs+119identityauthority.
Final3previoussource39 preserved; final4 is current.

Binding focus:
- Shared new_peer exactsignature/return7facts+state, no dispatch/observe/clock/
  apptransitions in constructor; cases/app/prior checked before mutation.
  Selected facts onlyearned at actual serialized metadata/DATA; active32sent
  consumes7prefix by immutablecontract, pause/hash/begin notmodelseed.
- Independent app records/metrics/retainedoutputs/binding truth; no client
  capture/coordinator imports/model-generated selectedcompletion. Existing
  seededpriorfixtures are explicit standalone driver fixtures, notpriorwire.
- check uses extracted peer once, moved code deleted/no separate bytepeer;
  preserve ALL old positive/negs/alias/private/units/eof/JCR/hash controls.
- Online exact frame/HPACK/stream/flag/requestorder checks. Parser8201/frame8192
  guard BEFORE growth; pending2/packet8192/read150/HPACKbounds finite; rejection
  does not exceedstore or grow on repeat. No request/frame/read histories or
  unearnedstreamset. No receivewrapper introduced (ifdiff showsone, strictonce/
  identity/error contract applies).
- Active noEND/noresponse/heldbarrier final67+metrics once, suppliedpostsignal
  transition onlyat hook boundary, idlefreshhealth/final67+metrics. Teardown
  schemas/ordering and privatecomparison facts unchanged.

Named risk checks beyond diff only if needed: constructorprior aliasing; encoded
response size before pendingstore; HPACK/header framing/storage guard order;
read-limit state on repeated rejection; driver-earns selected prefix/body vs
modelseed; retained prior validation/outputbinding isolation; oldcontrols
stillinvoked. Tests-first/diffonce/context10; changedsource rereadonlycutoffand
saywhy; outside-diff onlyconcretenamedrisk/onefocusedcheck. No broadcrawl or
passed-suite repeats. Focused purepinned sensitivity only for unanswered doubt.

Evidence qualification: initialRED missingAPI/pre-effect; barrier-old is POSTHOC
diagnostic againstfrozenattempt3, notpre-fixRED; actualread-limitRED beforefix
frozenattempt4. Initialbaselinecommand/intermediateattemptcommands notsaved;
sources/rawexitresults retained. Pending current actualserialized overflow uses
early_response fault (nothealthy); repeated count/8193rejection and8192acceptance
targetsharedqueue_pending helper; its seam-onlyRED notexistingguarddefect.
No fictionalfullrequestrollback: onlyqueuebytes/count unchanged. Original
reportappend preserves qualifiers; publication later must distinguish current4
frompriorfinal3/final2/final results. Identify actualcurrent gaps asfindings.

Apply AGENTS/CODING/code-review-and-quality and explicitRoot-requested
thermo-nuclear structural lens underprojectoverrides. Read-only/noagents/files/
Git/services/native/server/socket/SSLContext/TLSclose/realclock/process/build/
fault/race/cancel/schedule/panic/leak/oldruntime/network execution. Only pinned
in-memorycodec/suppliedfacts; exactPython-B-S/PYTHONPATH/graphifyprefix inbrief.
Provided paths located; graphify beforeNEWcodebasequestion/search. Returnfull
SPEC/QUALITY, strengths/actionable severity/fileline/scenariofindings and
cannotverify boundaries; Root savesverdict/fixes viaowner, no sourcefix yourself.
P8shutdowncomposition/defaultall40/native/adoption/fullmilestones remainfuture.
