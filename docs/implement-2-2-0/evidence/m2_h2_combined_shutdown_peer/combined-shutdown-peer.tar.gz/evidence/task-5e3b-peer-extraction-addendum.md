# Peer construction addendum

Read-only architect /root/architect_h2_all40_coordinator, Nov 2. This refines
task-5e3b-coordinator-composition-plan-report.md; all parent scope remains.

Only test_coordinator.peer(control=None) is currently an externally callable
factory, fixed to ready-only. test_shared.check() constructs and executes
ready->large. test_lifecycle.check(case,app,prior,final,fault) executes clients;
its nested connection(index) returns state,send,receive. Producer/file check()
functions likewise combine construction/dispatch, inspect client context during
receive and copy client observations into peer app state. Calling these check()
functions from a coordinator test cannot prove coordinator composition.

Extract one genuinely shared ready/large implementation in test_core_peer.py;
promote family constructors inside existing lifecycle/producer/file modules.
Persistent child store exact keys: records,heads,outputs,binding. All67 records
start unselected; heads counts decoded actual heads; outputs starts unselected;
binding is None until actually supplied. Convert absent binding to model default
only where validators require unselected post defaults, never as an observation.

Core interfaces:

    new_app()
    new_peer(case, *, app, prior, now, clock, final=False)

Lifecycle new_case_evidence() and
new_peer(case,connection_index,*,app,prior,now,clock,case_evidence,final=False,
fault=None) retain existing shared rolling digest/counters across replacement.
Producer new_peer(case,*,app,prior,now,clock,final=False,fault=None,slot=1,
generation=17,echo_order='middle'). File has same core signature plus fault.
Every peer returns exact {connection,state}; connection exact seven keys
protocol,send,receive,now,owned,tls,alpn. Already-initiated pinned protocol,
bounded callbacks, supplied timestamp, explicitly synthetic owned/TLS facts.
Initial SETTINGS/ACK queued for normal receive; never call adapter.observe in
constructor. Document bounded family-specific state fields, no generic registry.
final permits final68 after finite concrete schedule, never marks completion.
prior validates supplied persistent state; never seeds undispatched results.

Move serialization/synthetic transitions into peers, keep actual client calls
in drivers/coordinator. Driver-side wrappers may check real adapter boundaries
but must invoke original exactly once, preserve result/errors and not leak
client context into peer. Move shared parser/debt/deadline checks into driver
final boundary wrapper. Peer chooses split late refunds from serialized cursor.
Producer/file truth is recorded when peer facts serialize, separately copied
and compared with client observations; never set peer truth from client capture.
Remove original moved implementations, retain every existing negative control.
Replace accumulated shared heads/paths with online exact order/metadata checks,
counts/digests; bounded bodies/packets only, large payloads incremental.

Serial preparation, one implementation owner:

P1 new test_core_peer.py + test_shared.py + test_coordinator.py + minimal
test_imports.py inventory. Preserve shared ready->large declared/independent
ledgers/fragmented late refund and all ready coordinator success/preflight/time/
privacy/fact checks. test_coordinator.peer keeps lifecycle/fault invariants and
existing return contract while using core byte peer; it adds real invariants.

P2 test_lifecycle.py promotes nested connection construction, no separate reuse
copy. Preserve disconnect->reuse/finals/stale/hash/grant/strict-close negatives.

P3 test_producer_pressure.py promotes peer; preserve three-producer sequence,
alternate binding/order and every output/hash/credit/identity/time negative.

P4 test_file_early.py and demonstrated producer adjustment only. Preserve
producer->file->early chain, standalone finals/range/length/close/reset controls.

P5 coordinator.py + focused composition test + import inventory. Actual
coordinator dispatch using reviewed constructors. All37 ordinary handlers remain
the target in arbitrary valid caller order, not only extracted peer families.
Representative proofs: ready/large both orders, undeclared, reuse before/after
ordinary, producer/file->ordinary final, persistent records/fresh contexts,
onefinal68/intermediate failure/privacy/inherited debt and time bounds.

P1-P4 are preparation, not coordinator composition or native completion. Later
phase2B disconnect and phase2C shutdown children, actual default/all40 aggregate,
broad review, runtime/native/adoption and full milestones remain mandatory.
Pinned codecs/synthetic supplied facts only; no native/runtime release here.
