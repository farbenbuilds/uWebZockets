**Important P2 — DATA accepted before upload metadata: ADDRESSED.** [test_shutdown.py:122](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py:122) now requires exactly one SETTINGS ACK and the validated health/upload HEADERS cursor before changing DATA counters or application facts.

**Regression coverage:** [test_shutdown.py:425](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py:425) tests premature DATA before health and after health, twice each. It checks unchanged application facts, counters, digest, pending packets, and empty parser storage. Its repeated high-water check correctly permits the first invalid frame to increase high-water.

**Evidence checked:** The appended report identifies an actual pre-fix RED (`premature DATA accepted`) and four covering shutdown/import runs in normal and optimized modes, all exit 0 with empty stderr. Root’s audit confirms the RED production AST matches the reviewed implementation and records preservation of previous sources and evidence. Existing healthy serialized execution remains covered. No suites rerun.

**New breakage in the fix diff:** None.

**Out-of-scope observations:** None newly identified. Historical evidence qualifications and the synthetic-only scope remain unchanged; coordinator/default/all40/native/adoption and full project gates remain open.

**Fix round:** All findings addressed, no new Critical/Important breakage. Scoped SPEC and QUALITY review approved.
