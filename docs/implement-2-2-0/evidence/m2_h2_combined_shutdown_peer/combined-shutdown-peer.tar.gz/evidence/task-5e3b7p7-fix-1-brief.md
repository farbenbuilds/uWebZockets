# P7 fix round1: DATA requires accepted upload metadata

Same P7 owner/source ownership/BASE; read full task-5e3b7p7-review-report.md.
One Important P2 finding: current DATA branch accepts stream3 payload immediately
after startup+ACK without health/upload HEADERS, earning bytes7/chunks1/pausedTrue
while middleware0/begins0/activeFalse, heads0/data32.

Before implementation capture exact reviewed39 live source/full map and current
final4 snapshots/stdout/hashes; add a real failing regression and retain command/
stdout/stderr/exit and reviewed source. Require the exact upload cursor/state
before changing DATA, digest, peer counters or application facts. Test DATA
before health, after health but before upload metadata, and correct healthy
metadata->DATA flow. Premature rejection earns no selected record/counters;
repeat it without growth. Parser consuming an invalid frame is not a promise
of transactional whole-request rollback; state precisely what is preserved.

Fix only test_shutdown.py (same original ownership), no core/handlers/peerfamily/
model/coordinator edits. Preserve existing barrier/pending/read/parser/HPACK
guards and all controls. No native/Git/subagents/network or passed-suite repeats.
After final edit run four covering shutdown/import normal-O commands with
distinct fix1 names; fresh39current/frozen/map/structure119input/prior5695/inert
audit. Preserve all final4/final3/history and report original prefix. Append
fix report (finding/fix/actualRED/source/commands/currentGREEN/delta/gaps), concise
terminal status then Root audit and SAME reviewer scoped re-review. No broad
review or fixing unrelated code. Full source-only constraints/exact pinned
interpreter/paths/PYTHONPATH/graphify in original brief remain binding.
