# P7 current pending-capacity boundary completion

Root read the full candidate report and non-DONE handling reference. Historical
chronology/command gaps stay explicitly qualified. One current proof required
by the original brief remains missing: forced pending-capacity rejection.
Complete this before initial independent review; no other scope expansion.

Same sole owner and source ownership. Preserve candidate final3-source/map,
four final3 commands/outputs and all report bytes before append. Add a focused
current boundary test that reaches the existing pending cap with real valid
serialized requests if feasible, then attempts enqueue beyond the allowed two
packets and proves the queue/count/packet bytes do not grow. Also exercise an
oversized pending packet against the packet cap if not already covered. Prefer
the peer's actual send/receive path; do not seed case completion or weaken
ordering/state checks to reach the boundary. If only a specific isolated queue
helper is reachable, test the bound directly and qualify that scope. Rejected
capacity must be reproducible without growth on repeat. Any actual defect needs
genuine failing source/run BEFORE fix; no invented historical RED.

Run four shutdown/import normal-O commands after the final edit with NEW names,
freeze current39/source map and separate structure/input/history/inert receipt.
No old receipts overwritten. No other passed suites without dependency. Append
completion proof/commands/results/source/delta/gaps to the same report, then
return concise status. If the capacity boundary is unreachable under every
valid finite schedule, provide concrete derivation and exact code locations
instead of silently omitting it; Root will rule on that evidence.

All original pinned Python/immutable/synthetic-only/no native/Git/subagents and
history constraints apply. No coordinator/handler/model/other source edits.
