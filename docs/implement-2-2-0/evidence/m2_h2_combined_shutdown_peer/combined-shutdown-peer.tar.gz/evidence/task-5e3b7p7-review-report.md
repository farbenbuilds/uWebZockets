SPEC: Issues found. QUALITY: Needs fixes.

Strengths:

- [test_shutdown.py:71](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py:71) extracts one shared constructor, validates supplied application state, and preserves independent peer records and counters.
- [test_shutdown.py:66](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py:66), [178](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py:178), and [200](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py:200) enforce pending, parser, and read bounds before growing their respective stores.
- The structural extraction removes the duplicate driver implementation. The queue helper adds a concrete invariant. No separate actionable maintainability regression found.

Important — P2: Require upload metadata before accepting DATA.

[test_shutdown.py:122](/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shutdown.py:122) validates the DATA stream, flags, payload, and prior DATA count, but never requires the upload HEADERS to have been accepted. Consequently, startup followed by SETTINGS ACK and stream 3 DATA immediately earns selected application facts before health or upload metadata.

One focused check using the brief’s exact pinned interpreter and PYTHONPATH reproduced:

```text
{'middleware': 0, 'begins': 0, 'active': False,
 'bytes': 7, 'chunks': 1, 'paused': True}
heads 0 data 32
```

This violates the required metadata-before-DATA ordering and allows the shared peer to certify body consumption on an unopened request. Require the exact upload cursor/state before changing DATA or application facts; add a regression that rejects DATA before metadata without earning facts.

Verification and boundaries:

- Read the complete supplied diff once, reviewed added tests and retained final4 shutdown/import/audit output. No changed-source rereads, source edits, or passed-suite reruns.
- Ran only the focused in-memory ordering check above; it exited 0, demonstrating unintended acceptance.
- Final4 output retains idle `69/69/0`, active `71/70/32`, and existing negative controls. Root’s audit reports only `test_shutdown.py` changed, with 38 modules and prior evidence preserved; I did not independently recompute that inventory.
- Historical missing command receipts and posthoc barrier evidence remain qualified limitations, not current correctness findings. Pending proof remains one fault-injected serialized rejection plus repeated direct-helper boundaries.
- Shutdown coordinator composition, default/all40, native/runtime behavior, adoption, and full project gates remain unverified by this task.
