"""Package the reviewed independent shutdown peer and scoped evidence."""
import hashlib
import json
import runpy
import tarfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    provenance = Path('docs/implement-2-2-0/evidence/m2_h2_combined_core_peer/combined-core-peer.tar.gz')
    if sha(provenance.read_bytes()) != 'dbcd7a01a56a3c80600aa39fa7b61dec00060976c14a82e2bd4a712a2520d25d':
        raise ValueError('Writer provenance differs')
    builder = plan / 'task-5e3b7p1-build-publication.py'
    with tarfile.open(provenance, 'r:gz') as previous:
        if previous.extractfile('evidence/' + builder.name).read() != builder.read_bytes():
            raise ValueError('Published writer source differs')
    writer = runpy.run_path(str(builder))['load_writer'](plan)
    baseline = Path('docs/implement-2-2-0/evidence/m2_h2_combined_coordinator_disconnect/combined-coordinator-disconnect.tar.gz')
    if sha(baseline.read_bytes()) != 'e259f495fa02113ad24c617bbe60af11e102d7c261fcc76362d91ace1dae268d':
        raise ValueError('Baseline archive differs')
    members = {}
    with tarfile.open(baseline, 'r:gz') as previous:
        inventory = json.loads(previous.extractfile('INVENTORY.json').read())
        for member in previous:
            if not member.isfile():
                raise ValueError('Nonregular baseline member')
            if member.name == 'INVENTORY.json':
                continue
            data = previous.extractfile(member).read()
            if inventory[member.name] != dict(size=len(data), sha256=sha(data)):
                raise ValueError('Baseline inventory differs')
            if member.name.startswith('reference/'):
                writer['add'](members, member.name, data)
            if member.name.startswith('source/current/'):
                writer['add'](members, member.name.replace('source/current/', 'history/disconnect-coordinator-source/', 1), data)
    audit = json.loads((plan / 'task-5e3b7p7-root-fix-1-audit.json').read_text())
    current = {path.name: sha(path.read_bytes()) for path in source.glob('*.py')}
    if current != audit['current_source_sha256']:
        raise ValueError('Approved source differs')
    for path in sorted(source.glob('*.py')):
        writer['add'](members, 'source/current/' + path.name, path.read_bytes())
    raw = source / 'evidence/coordinator-shutdown-peer'
    for path in sorted(raw.rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink in evidence')
        if path.is_file():
            writer['add'](members, 'raw/coordinator-shutdown-peer/' + path.relative_to(raw).as_posix(), path.read_bytes())
    names = ('task-5e3b7p7-brief.md', 'task-5e3b7p7-report.md', 'task-5e3b7p7-review-brief.md',
             'task-5e3b7p7-review-report.md', 'task-5e3b7p7-review-source.diff',
             'task-5e3b7p7-proof-completion-brief.md', 'task-5e3b7p7-root-final-audit.json',
             'task-5e3b7p7-fix-1-brief.md', 'task-5e3b7p7-fix-1-review-brief.md',
             'task-5e3b7p7-fix-1-review-report.md', 'task-5e3b7p7-fix-1-review.diff',
             'task-5e3b7p7-root-fix-1-audit.json',
             'task-5e3b7p7-build-publication.py', 'task-5e3b-peer-extraction-addendum.md',
             'task-5e3b-coordinator-composition-plan-report.md', 'task-5e3b-aggregate-acceptance-notes.md')
    for name in names:
        writer['add'](members, 'evidence/' + name, (plan / name).read_bytes())
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_combined_shutdown_peer')
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / 'combined-shutdown-peer.tar.gz'
    inventory = writer['write_archive'](archive, members)
    manifest = dict(scope='Independent bounded shutdown peer preparation using supplied synthetic facts',
                    base_commit=audit['base_commit'], baseline_archive_sha256=sha(baseline.read_bytes()),
                    archive=archive.name, archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
                    safe_regular_text_members=len(members), inventory_entries=len(inventory), current_source_files=current,
                    changed_files=['test_shutdown.py'], added_files=[], unchanged_disconnect_coordinator_modules=38,
                    peer_constructor='new_peer(case, *, app, prior, now, clock, fault=None)',
                    standalone_driver_shared_peer=True, no_constructor_app_clock_or_client_dispatch_effects=True,
                    selected_facts_earned_from_serialized_metadata_and_data=True,
                    active_request_bytes=32, active_consumed_prefix_bytes=7,
                    standalone_observed={'shutdown_idle': dict(heads=69, small=69, request_flow=0),
                                         'shutdown_active': dict(heads=71, small=70, request_flow=32)},
                    bounds=dict(parser_bytes=8201, frame_payload_bytes=8192, pending_packets=2,
                                pending_packet_bytes=8192, receive_calls=150),
                    supplied_prior_fixtures_not_actual_prior_execution=True, selected_model_completion_seeded=False,
                    current_normal_optimized_commands=4, preceding_final4_commands=4, preceding_final3_commands=4,
                    preceding_final2_commands=4, preceding_final_commands=4,
                    current_ast_inert_import_files=39, fresh_pre_edit_evidence_hashes_checked=5695,
                    fresh_pre_fix_unit_evidence_hashes_checked=333,
                    retained_identity_entries=119, physical_identity_rows=118, unique_file_paths=113,
                    ordered_codec_files=42, initial_red_scope='Missing constructor API before effects',
                    actual_read_limit_regression_red=True, barrier_diagnostic_posthoc=True,
                    actual_premature_data_regression_red=True, premature_data_red_production_ast_matches_reviewed=True,
                    intermediate_commands_independently_recorded=False,
                    pending_proof_scope='One fault-injected serialized overflow and repeated direct shared-helper bounds',
                    pending_red_scope='Unavailable helper test seam, not preexisting guard defect',
                    source_review='Spec and quality approved after DATA-before-metadata fix', coordinator_shutdown_composition_accepted=False,
                    coordinator_supported_case_count=38, default_supported=False, combined_all40_executed=False,
                    native_executed=False, milestone_complete=False,
                    remaining=['Idle/active shutdown child composition',
                               'Actual default/all40 aggregate and broad combined-client review',
                               'Runtime/native/full gates and production adoption'])
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
                  regular_members=len(members), inventory_entries=len(inventory), source_modules=len(current),
                  all_reopened_member_bytes_exact=True, native_executed=False)
    (plan / 'task-5e3b7p7-root-archive-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
