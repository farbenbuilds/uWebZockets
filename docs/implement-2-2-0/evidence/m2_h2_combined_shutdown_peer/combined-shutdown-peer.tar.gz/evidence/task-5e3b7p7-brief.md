# Independent shutdown peer preparation

Released after P6 reviewed/pushed at
f87ac67139994313402aa14a781104f030ccc971 (BASE). Current39 source identities:
docs/implement-2-2-0/evidence/m2_h2_combined_coordinator_disconnect/manifest.json.
Read task-5e3b-coordinator-composition-plan-report.md phase2C and
task-5e3b-peer-extraction-addendum.md. This is the necessary shutdown peer
extraction for phase2C, following the same independent-peer preparation used
for core/lifecycle/producer/file. It is not shutdown coordinator acceptance.

## Ownership and constructor

Own only combined-cases/test_shutdown.py, new evidence/coordinator-shutdown-peer,
and task-5e3b7p7-report.md under this plan workspace. No coordinator/handler/core/
model/fixture/helper/codec/import-inventory/product/pin/limit/deadline changes;
39-module inventory stays unchanged. Any specific ownership/API gap goes to
Root before editing. You are not alone; preserve others and all source/history.
No subagents/external model CLI/Git/public/native operations. Root owns review,
publication, commits and immediate pushes.

Existing test_shutdown.check mixes construction and dispatch and seeds supplied
prior fixtures. Expose one genuinely shared bounded constructor:

    new_peer(case, *, app, prior, now, clock, fault=None)

Support shutdown_idle/shutdown_active only. Return exact {connection,state};
connection exact7 protocol,send,receive,now,owned,tls,alpn, with initiated pinned
protocol, supplied timestamp, ownedTrue/TLSv1.3/h2 synthetic facts. Reuse the
existing application shape records,heads,outputs,binding from
test_core_peer.new_app. Prior is validated supplied persistent state; no prior
or selected completion seeding in the constructor. Idle requires no prior and
a fresh app. Active accepts valid successful main prior; never idle/active in
prior. Validate before app mutation. Constructor queues startup SETTINGS/ACK
for normal receive, but does not invoke client dispatch/observe/clock or mutate
app/state transitions. The peer never imports coordinator or reads client
contexts/observations to establish its own truth.

Move actual serialized parsing, response construction and synthetic app
transitions from check into that single peer. check remains the standalone
driver using new_peer; delete moved duplicate code. Preserve its public call
signature/return context and ALL existing success/negative controls, including
alternate units/tls_eof, prior fixture cases, private capture, output/binding
alias rejection and exact J/C/R/hash assertions. Existing prior fixtures may
be prepared explicitly in the driver to preserve historical checks; report
them as supplied fixtures, not actual prior wire execution. The new constructor
must validate supplied prior and never manufacture it. Do not add a second
standalone implementation or call family check() from future composition.

## Independent bounded peer facts

Start selected shutdown state unselected. Active metadata and positive32-byte
DATA earn its middleware/begin/chunk/byte/active/paused facts at the actual
serialized boundaries. Preserve no-END and no-primary-response behavior;
derive the exact record fields from canonical immutable contracts. Parsed
status/metrics responses use the app store and independently derived counters,
not model-generated selected completion. Outputs/binding come from separately
copied validated retained app facts, never client capture/default recipes for
selected values. Allowed unselected defaults remain explicit.

Idle emits health plus final67status+metrics, no selected body record. Active
emits health/upload/barrier plus final67status+metrics, no extra output GET.
Actual post-signal cancellation transition belongs at the supplied signal
boundary in the driver/hooks, preserving nonterminal data facts; do not
pre-mark cancellation/completion in new_peer. Synthetic driver hook changes
must follow the corresponding actual serialized/validated boundary. Keep
shutdown close/signal/termination/process/post supplied schemas and ordering;
do not execute sockets/processes/real clocks/TLS closes.

Use bounded online exact frame/HPACK/stream/flag/metadata order checks and
scalar cursors/counts/digests, not accumulated actual request/frame histories.
Enforce parser/frame/HPACK/pending/packet/read bounds BEFORE storage growth;
reuse existing finite peer policies where applicable, derive any family bound
from its finite schedule. Rejected oversized fragments must preserve parser
bytes/highwater on repeat. No growing unearned-stream sets. Driver inspection
wrappers, if needed, must invoke original receive exactly once and preserve
result identity/exception priority, then check the captured pre-observation.

## Proof/evidence

Preserve all old shutdown controls with actual standalone driver invocation.
Add constructor no-clock/no-client/no-app-effects tests, exact returned schema,
bad case/prior/app rejection before mutation, independently serialized active
record/metrics and retained output/binding checks, no selected model seeding,
pending/parser/HPACK/read limits, repeated rejected growth, and original
receive callback result/error behavior if a wrapper is introduced. Do not
claim coordinator/default/all40 proof. Expected standalone active71heads/70small/
R32, idle69/69/R0 and oneSETTINGS/onecollection remain unchanged.

Before edits verify/freeze39baseline and capture FRESH exhaustive pre-edit
evidence-file hash map excluding only this new unit directory. Write actual
constructor acceptance RED first; qualify missing-API/pre-effect rejection.
Any discovered behavioral defect gets real failing source/run before its fix.
Distinct immutable paths for every source/structure/command/run; no overwritten
receipts, fabricated RED chronology or retroactive missing history.

After last source edit run pinned test_shutdown.py and test_imports.py normal
and -O (four commands), plus an unchanged suite only for a concrete dependency.
Audit all39 AST/one-main-guard/actual inert empty+foreignargv imports and all
authored recorders. No classes/assert/customexceptions/hiddenmutableglobals/
deadcode/camelCase/ignored errors/control nesting>3. Preserve thresholds and
original callback errors. Read project/role and narrow applicable skills.

Pinned /home/codespace/.python/current/bin/python3 SHA
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601; execute
every direct Python -B -S, -O only for optimized runs. PYTHONPATH unchanged:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
Immutable119 identity authority remains evidence/coordinator-a/immutable-inputs.json
(118physical rows/113resolved files +42orderedcodec aggregate). Ordered codec
digest0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473.
Graphify before new codebase question/search/source read:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650
Provided paths located. No native/build/server/socket/SSLContext/TLS-close/
realclock/processownership/transfer/kernel/fault/cancel/scheduling/interleaving/
race/resource/panic/crash/leak/oldruntime execution, installs/network. Only
pinned in-memory codecs and supplied synthetic facts; formatter/Git/AST Root
operations remain separate. Native/full gates later remain mandatory.

Full report exact changes/commands/raw/RED/GREEN/sourcefrozen/input/history
bounds/selfreview/gaps to task-5e3b7p7-report.md. Return concise DONE or
DONE_WITH_CONCERNS/NEEDS_CONTEXT/BLOCKED, reportpath/testsummary/concerns; no
commit. Root independent review then publication+commit+push, then phase2C
coordinator using this peer. Actual default/all40/broadreview/runtime/native/
twochild/adoption/fullmilestones remain mandatory and unchanged.
