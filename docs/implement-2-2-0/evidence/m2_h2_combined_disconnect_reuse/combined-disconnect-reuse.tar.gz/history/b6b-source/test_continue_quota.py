"""In-memory serialized Continue, quota and failed-begin schedules."""
import hashlib
import json
import adapter
import cases
import catalogue
import h2_client
import hpack
import model
import test_ready


NAMES = ('continue_ready', 'continue_paused', 'quota_refuse', 'begin_failure_rollback')


def completed(tag):
    item = model.record(tag, True, 'after')
    if item['bytes']:
        item.update(chunks=1, max_span=32)
    return item


def check(case, *, app=None, prior=(), final=False, fault=None):
    decoder, encoder = hpack.Decoder(), hpack.Encoder()
    if app is None:
        app = {'records': {tag: model.record(tag, False, 'before') for tag in model.SPECS}, 'heads': 0}
    state = {'startup': True, 'buffer': bytearray(), 'pending': [], 'paths': [], 'streams': {},
             'payloads': {}, 'active': set(), 'resume': False, 'paused_data': False, 'info': set(), 'metrics': []}

    def response(stream, body, status='200', reset=False):
        block = encoder.encode(((':status', status), ('x-middleware', 'retained')))
        final_frame = (test_ready.frame(1, 5, stream, block) if reset else
                       test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body))
        reset_frame = test_ready.frame(3, 0, stream, (0).to_bytes(4, 'big'))
        if reset and fault == 'refusal_data':
            state['pending'].append(test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, b'x') + reset_frame)
        elif reset and fault == 'refusal_continue':
            info = encoder.encode(((':status', '100'),))
            state['pending'].append(test_ready.frame(1, 4, stream, info) + final_frame + reset_frame)
        elif reset and fault == 'reset_first':
            state['pending'].append(reset_frame + final_frame)
        elif reset:
            state['pending'].extend((final_frame, reset_frame))
        else:
            state['pending'].append(final_frame)

    def done(stream, tag):
        if tag in state['active']:
            state['active'].remove(tag)
        app['records'][tag] = completed(tag)
        response(stream, json.dumps(app['records'][tag]).encode())

    def request(path, stream):
        if path == '/health':
            response(stream, b'ok')
        elif path == '/metrics':
            state['metrics'].append(len(state['active']))
            metrics = {key: sum(item[key] for item in app['records'].values()) for key in model.COMMON_COUNTERS + ('bytes',)}
            metrics.update(active=len(state['active']), paused=0, buffered_middleware=app['heads'] - metrics['middleware'],
                           slot0_active=len(state['active']) > 0, slot1_active=len(state['active']) > 1)
            if fault == 'active_count' and len(state['metrics']) == 1:
                metrics['active'] = 1
            response(stream, json.dumps(metrics).encode())
        elif path.startswith('/status/'):
            tag = path[8:]
            item = dict(app['records'][tag])
            if tag == 'continue_paused' and case == tag and state['paused_data'] and not state['resume']:
                item = model.checkpoint(tag, 'paused')
                if fault == 'paused_bytes':
                    item['bytes'] = 1
            response(stream, json.dumps(item).encode())
        elif path == '/resume/continue_paused':
            if not state['paused_data'] or state['resume']:
                raise RuntimeError('invalid resume order')
            state['resume'] = True
            response(stream, b'ok')
            target = next(s for s, tag in state['streams'].items() if tag == 'continue_paused')
            done(target, 'continue_paused')
        else:
            raise RuntimeError('unexpected request')

    def headers(packet, stream, flags):
        entries = list(decoder.decode(packet[9:]))
        path = dict(entries)[':path']
        state['paths'].append(path)
        app['heads'] += 1
        expected = [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)]
        if path.startswith(('/health', '/status/', '/metrics', '/resume/')):
            if entries != expected or flags != 5:
                raise RuntimeError('auxiliary headers differ')
            request(path, stream)
            return
        tag = path.split('/')[-1]
        contract = model.request_contract(tag)
        expected[0] = (':method', contract['method'])
        expected.append(('content-length', str(contract['declared'])))
        expect = tag in ('continue_ready', 'continue_paused', 'quota_refuse', 'begin_failure')
        if expect:
            expected.append(('expect', '100-continue'))
        if entries != expected or path != contract['target'] or flags != 4:
            raise RuntimeError('upload headers differ')
        state['streams'][stream] = tag
        state['payloads'][stream] = {'count': 0, 'hash': hashlib.sha256(), 'frames': 0}
        if tag in ('quota_refuse', 'begin_failure'):
            if tag == 'quota_refuse' and len(state['active']) != 2:
                raise RuntimeError('quota refusal before active barrier')
            app['records'][tag] = completed(tag)
            if fault == 'wrong_failure' and tag == 'begin_failure':
                app['records'][tag]['failures'] = 0
            if fault == 'other_record' and tag == 'begin_failure':
                app['records']['empty_headers']['middleware'] = 1
            response(stream, b'', status='503', reset=True)
            return
        state['active'].add(tag)
        app['records'][tag] = model.record(tag, True, 'after')
        app['records'][tag].update(bytes=0, sha256=model.EMPTY_HASH, chunks=0, max_span=0, ends=0, active=True)
        if expect and fault == 'missing_continue':
            response(stream, b'')
        elif expect:
            block = encoder.encode(((':status', '100'),))
            state['pending'].append(test_ready.frame(1, 4, stream, block))
            state['info'].add(stream)

    def data(packet, stream, flags):
        tag = state['streams'][stream]
        item = state['payloads'][stream]
        payload = packet[9:]
        if item['frames'] or len(payload) != 32 or flags != 1 or tag in ('quota_refuse', 'begin_failure'):
            raise RuntimeError('DATA ordinal differs')
        if tag.startswith('continue_') and stream not in state['info']:
            raise RuntimeError('DATA before Continue')
        item['frames'] += 1
        item['count'] += len(payload)
        item['hash'].update(payload)
        if tag == 'continue_paused':
            state['paused_data'] = True
            if fault == 'early_final':
                done(stream, tag)
        else:
            done(stream, tag)

    def send(data_bytes):
        if state['startup']:
            state['startup'] = False
            return
        state['buffer'].extend(data_bytes)
        while len(state['buffer']) >= 9:
            size = int.from_bytes(state['buffer'][:3], 'big')
            if len(state['buffer']) < size + 9:
                return
            packet = bytes(state['buffer'][:size + 9])
            del state['buffer'][:size + 9]
            kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
            if kind == 1:
                headers(packet, stream, flags)
            elif kind == 0:
                data(packet, stream, flags)

    def receive():
        if not state['pending']:
            raise RuntimeError('missing synthetic response')
        return state['pending'].pop(0), 2

    context = adapter.open_case(case, h2_client.new_protocol(), send, 1, 30001, 900001, selected_before=prior, clock=lambda: 2)
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    adapter.observe(context, test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b''), 2)
    adapter.run_case(context, receive)
    expected_tags = {'continue_ready': ('continue_ready',), 'continue_paused': ('continue_paused',),
                     'quota_refuse': ('quota_holder_one', 'quota_holder_two', 'quota_refuse', 'quota_recovery_one', 'quota_recovery_two'),
                     'begin_failure_rollback': ('begin_failure', 'begin_recovery')}[case]
    expected = ['/health']
    for tag in expected_tags:
        if tag == 'quota_refuse':
            expected.append('/metrics')
        expected.append(model.request_contract(tag)['target'])
        if tag == 'continue_paused':
            expected += ['/status/continue_paused', '/resume/continue_paused']
        if tag == 'quota_refuse':
            expected.append('/metrics')
        if tag == 'quota_recovery_two':
            expected.extend(('/metrics', '/metrics'))
    expected.append('/health')
    if case == 'quota_refuse' and state['metrics'] != [2, 0, 2, 0]:
        raise RuntimeError('quota metrics order differs')
    if final:
        adapter.final_collection(context, receive)
        expected += ['/status/' + tag for tag, _, _, _ in model.BODY_SPECS] + ['/metrics']
    if state['paths'] != expected:
        raise RuntimeError('request order differs')
    for stream, item in state['payloads'].items():
        tag = state['streams'][stream]
        body = b'' if tag in ('quota_refuse', 'begin_failure') else model.payload_span(32, 0, 32)
        if item['frames'] != int(bool(body)) or item['count'] != len(body) or item['hash'].digest() != hashlib.sha256(body).digest():
            raise RuntimeError('request body differs')
    print(case + ' passed: heads=%d flow=%d' % (context['stage']['limits']['heads'], context['request']['case']['sent']))
    return app


def before_continue():
    context = adapter.open_case('continue_ready', h2_client.new_protocol(), lambda _data: None,
                                1, 30001, 900001, clock=lambda: 2)
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in
                        ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    adapter.observe(context, test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b''), 2)
    adapter.start(context, 'GET', '/health', (), True, False, 2)
    stream = adapter.start(context, 'POST', '/limit/continue_ready',
                           (('content-length', '32'), ('expect', '100-continue')), False, True, 4095, info=1)
    try:
        adapter.send_data(context, stream, model.payload_span(32, 0, 32), True)
    except ValueError as exc:
        if str(exc) != 'DATA before Continue or after terminal':
            raise
        print('pre-Continue DATA rejected: ' + str(exc))
    else:
        raise RuntimeError('pre-Continue DATA accepted')


def main():
    before_continue()
    if len([case for case in catalogue.CASES if case not in cases.IMPLEMENTED]) != 4:
        raise RuntimeError('unsupported inventory differs')
    for case in NAMES:
        check(case)
    app, prior = None, ()
    for case in NAMES:
        app = check(case, app=app, prior=prior, final=case == NAMES[-1])
        prior += (case,)
    for fault, message in (('wrong_failure', 'record mismatch: failures'),
                           ('other_record', 'record mismatch: middleware')):
        try:
            check('begin_failure_rollback', final=True, fault=fault)
        except ValueError as exc:
            if str(exc) != message:
                raise RuntimeError('final fault rejected for wrong reason: ' + fault) from exc
            print(fault + ' rejected: ' + str(exc))
        else:
            raise RuntimeError('final fault accepted: ' + fault)
    for fault, case, message in (('missing_continue', 'continue_ready', 'invalid DATA'),
                                 ('refusal_continue', 'begin_failure_rollback', 'invalid HEADERS'),
                                 ('refusal_data', 'quota_refuse', 'response body bound'),
                                 ('reset_first', 'begin_failure_rollback', 'reset order'),
                                 ('active_count', 'quota_refuse', 'quota active barrier differs'),
                                 ('paused_bytes', 'continue_paused', 'record mismatch: bytes'),
                                 ('early_final', 'continue_paused', 'invalid terminal')):
        try:
            check(case, fault=fault)
        except ValueError as exc:
            if str(exc) != message:
                raise RuntimeError('fault rejected for wrong reason: ' + fault) from exc
            print(fault + ' rejected: ' + str(exc))
        else:
            raise RuntimeError('fault accepted: ' + fault)


if __name__ == '__main__':
    main()
