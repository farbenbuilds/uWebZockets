export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S - <<'PY'
from pathlib import Path
import ast
import difflib
import hashlib
import json
import cases
import catalogue
import model

def depth(nodes, level=0):
    maximum = level
    for node in nodes:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            maximum = max(maximum, depth(node.body))
        elif isinstance(node, (ast.If, ast.For, ast.While, ast.With, ast.Try)):
            maximum = max(maximum, depth(node.body, level + 1))
            otherwise = getattr(node, 'orelse', [])
            branch_level = level if isinstance(node, ast.If) and len(otherwise) == 1 and isinstance(otherwise[0], ast.If) else level + 1
            maximum = max(maximum, depth(otherwise, branch_level), depth(getattr(node, 'finalbody', []), level + 1))
            for handler in getattr(node, 'handlers', []):
                maximum = max(maximum, depth(handler.body, level + 1))
    return maximum

if __name__ == '__main__':
    root=Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    evidence=root/'evidence/b6c'
    (evidence/'final-source').mkdir(exist_ok=True)
    immutable=json.loads((root/'evidence/b6b/immutable-inputs.json').read_text())
    for item in immutable['identities']:
        data=Path(item['path']).read_bytes()
        if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
            raise RuntimeError('immutable identity differs: '+item['path'])
    rows=immutable['codec_files']
    packages=Path('/tmp/uwz-h2-client-tooling/packages')
    for name,digest in rows:
        if hashlib.sha256((packages/name).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('codec identity differs: '+name)
    present={str(p.relative_to(packages)) for p in packages.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
    if present!={r[0] for r in rows} or len(rows)!=42 or hashlib.sha256(json.dumps(rows).encode()).hexdigest()!=immutable['codec_digest']:
        raise RuntimeError('ordered42 codec identity set or aggregate differs')
    files=immutable['identities']
    unique={str(Path(item['path']).resolve()) for item in files}
    if len(files)!=118 or len(unique)!=113:
        raise RuntimeError('retained identity row count differs')
    (evidence/'immutable-inputs.json').write_text(json.dumps(immutable,indent=2)+'\n')
    before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((evidence/'before-source').glob('*.py'))}
    published=json.loads(Path('docs/implement-2-2-0/evidence/m2_h2_combined_file_early/manifest.json').read_text())['current_source_files']
    if before!=published:
        raise RuntimeError('captured before bytes differ from released B6b')
    (evidence/'before-map.json').write_text(json.dumps(before,indent=2)+'\n')
    final={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob('*.py'))}
    if len(before)!=31 or len(final)!=33:
        raise RuntimeError('source module inventory differs')
    added=sorted(final.keys()-before.keys())
    removed=sorted(before.keys()-final.keys())
    changed=sorted(name for name in before.keys() & final.keys() if before[name]!=final[name])
    unchanged=sorted(name for name in before.keys() & final.keys() if before[name]==final[name])
    differences=[]
    depths={}
    for name in final:
        source=(root/name).read_bytes()
        tree=ast.parse(source,filename=name)
        if any(isinstance(n,(ast.ClassDef,ast.Assert)) for n in ast.walk(tree)):
            raise RuntimeError('class or assertion: '+name)
        depths[name]=depth(tree.body)
        if depths[name]>3:
            raise RuntimeError('control depth exceeds3: '+name)
        (evidence/'final-source'/name).write_bytes(source)
        old=(evidence/'before-source'/name).read_text() if name in before else ''
        differences.extend(difflib.unified_diff(old.splitlines(True),source.decode().splitlines(True),fromfile='before/'+name,tofile='after/'+name))
    (evidence/'source.diff').write_text(''.join(differences))
    snapshot=dict(base='738dbe140731cf32b8c7a552e906988622dfffcd',source_files=final,added=added,changed=changed,unchanged=unchanged,removed=removed,control_depth=depths)
    (evidence/'snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
    commands=[]
    for receipt in sorted(evidence.glob('final-test*.exit')):
        if '.pre-last.' in receipt.name:
            continue
        label=receipt.stem
        if receipt.read_text()!='0\n' or (evidence/(label+'.stderr')).read_bytes():
            raise RuntimeError('failed final command: '+label)
        commands.append(dict(command=(evidence/(label+'.command')).read_text(),exit=0,stdout=str(evidence/(label+'.stdout')),stderr=str(evidence/(label+'.stderr'))))
    if len(commands)!=40:
        raise RuntimeError('final command inventory differs')
    (evidence/'final-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    if len(cases.IMPLEMENTED)!=38 or len(model.SPECS)!=67 or len(set(catalogue.CASES)-set(cases.IMPLEMENTED))!=2:
        raise RuntimeError('case or final record inventory differs')
    normal=(evidence/'final-test_lifecycle-normal.stdout').read_bytes()
    if normal!=(evidence/'final-test_lifecycle-optimized.stdout').read_bytes() or len(normal.splitlines())!=45:
        raise RuntimeError('new normal/O proof differs')
    for p in root.glob('*.py'):
        if hashlib.sha256(p.read_bytes()).hexdigest()!=final[p.name]:
            raise RuntimeError('source changed during snapshot')
    contracts={case:dict(catalogue.case_budget(case)) for case in ('disconnect','reuse')}
    contracts.update(new_body_records=['disconnect','disconnect_recovery']+['reuse_'+str(i) for i in range(9)],
                     disconnect_heads_by_connection=[3,22],disconnect_upload_streams=[3,17],
                     disconnect_controls_each=2,reuse_controls_each=36,
                     deadlines=[30001,900001],supplied_close=dict(method='ssl_unwrap',tls_shutdown='success',tcp_eof=True,trailing_bytes=0,close='normal'))
    (evidence/'contracts.json').write_text(json.dumps(contracts,indent=2)+'\n')
    restoration=json.loads(Path('.superpowers/sdd/h2_streaming_plan/task-5e3b6c-root-resume-restoration.json').read_text())
    history={}
    for name,item in restoration['wip_snapshot_files'].items():
        if not name.startswith('evidence/b6c/'):
            continue
        data=(root/name).read_bytes()
        if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
            raise RuntimeError('historical evidence changed: '+name)
        history[name]=item
    (evidence/'preserved-history.json').write_text(json.dumps(history,indent=2)+'\n')
    print('33 modules: %d added, %d changed, %d unchanged, %d removed against released B6b' % (len(added),len(changed),len(unchanged),len(removed)))
    print('119 retained identity rows / 114 unique entries: 118 file rows / 113 unique resolved files plus codec aggregate')
    print('42 ordered codec identities and default-json aggregate match; no extra or missing codec files')
    print('40 final normal/-O commands exit0 with empty stderr; all33-module AST and actual inert empty/foreign argv imports pass')
    print('maximum control depth=%d; new schedule=%d; new test=%d' % (max(depths.values()),depths['lifecycle_cases.py'],depths['test_lifecycle.py']))
    print('38 source schedules; two rejected unsupported selections; final collection67 records plus metrics')
    print('new test: four positive executions and41 exact synthetic negative rejections per mode, plus direct terminal/deadline/credit guards')
    print('preserved historical evidence identities='+str(len(history)))
    print('remaining selections: '+', '.join(case for case in catalogue.CASES if case not in cases.IMPLEMENTED))
PY
