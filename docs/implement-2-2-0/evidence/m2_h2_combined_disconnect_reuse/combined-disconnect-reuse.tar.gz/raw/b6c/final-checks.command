export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_adapter.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_adapter-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_adapter-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_adapter-normal.exit
echo "final-test_adapter-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_adapter.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_adapter-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_adapter-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_adapter-optimized.exit
echo "final-test_adapter-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_admission.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_admission-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_admission-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_admission-normal.exit
echo "final-test_admission-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_admission.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_admission-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_admission-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_admission-optimized.exit
echo "final-test_admission-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_application_error.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_application_error-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_application_error-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_application_error-normal.exit
echo "final-test_application_error-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_application_error.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_application_error-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_application_error-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_application_error-optimized.exit
echo "final-test_application_error-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_async.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_async-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_async-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_async-normal.exit
echo "final-test_async-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_async.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_async-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_async-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_async-optimized.exit
echo "final-test_async-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_continue_quota-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_continue_quota-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_continue_quota-normal.exit
echo "final-test_continue_quota-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_continue_quota-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_continue_quota-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_continue_quota-optimized.exit
echo "final-test_continue_quota-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_control_reset.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_control_reset-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_control_reset-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_control_reset-normal.exit
echo "final-test_control_reset-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_control_reset.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_control_reset-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_control_reset-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_control_reset-optimized.exit
echo "final-test_control_reset-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_credit.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_credit-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_credit-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_credit-normal.exit
echo "final-test_credit-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_credit.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_credit-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_credit-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_credit-optimized.exit
echo "final-test_credit-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_file_early.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_file_early-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_file_early-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_file_early-normal.exit
echo "final-test_file_early-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_file_early.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_file_early-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_file_early-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_file_early-optimized.exit
echo "final-test_file_early-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_final.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_final-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_final-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_final-normal.exit
echo "final-test_final-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_final.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_final-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_final-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_final-optimized.exit
echo "final-test_final-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_imports-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_imports-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_imports-normal.exit
echo "final-test_imports-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_imports-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_imports-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_imports-optimized.exit
echo "final-test_imports-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_large.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_large-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_large-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_large-normal.exit
echo "final-test_large-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_large.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_large-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_large-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_large-optimized.exit
echo "final-test_large-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_lifecycle-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_lifecycle-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_lifecycle-normal.exit
echo "final-test_lifecycle-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_lifecycle-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_lifecycle-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_lifecycle-optimized.exit
echo "final-test_lifecycle-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_metadata_concurrency-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_metadata_concurrency-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_metadata_concurrency-normal.exit
echo "final-test_metadata_concurrency-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_metadata_concurrency-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_metadata_concurrency-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_metadata_concurrency-optimized.exit
echo "final-test_metadata_concurrency-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_negative.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_negative-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_negative-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_negative-normal.exit
echo "final-test_negative-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_negative.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_negative-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_negative-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_negative-optimized.exit
echo "final-test_negative-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_pause.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_pause-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_pause-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_pause-normal.exit
echo "final-test_pause-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_pause.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_pause-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_pause-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_pause-optimized.exit
echo "final-test_pause-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_producer_pressure.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_producer_pressure-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_producer_pressure-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_producer_pressure-normal.exit
echo "final-test_producer_pressure-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_producer_pressure.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_producer_pressure-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_producer_pressure-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_producer_pressure-optimized.exit
echo "final-test_producer_pressure-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_ready.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_ready-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_ready-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_ready-normal.exit
echo "final-test_ready-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_ready.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_ready-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_ready-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_ready-optimized.exit
echo "final-test_ready-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_selection.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_selection-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_selection-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_selection-normal.exit
echo "final-test_selection-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_selection.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_selection-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_selection-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_selection-optimized.exit
echo "final-test_selection-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shared.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_shared-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_shared-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_shared-normal.exit
echo "final-test_shared-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shared.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_shared-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_shared-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_shared-optimized.exit
echo "final-test_shared-optimized exit=$result"
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_time.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_time-normal.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_time-normal.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_time-normal.exit
echo "final-test_time-normal exit=$result"
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_time.py > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_time-optimized.stdout 2> .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_time-optimized.stderr
result=$?
echo "$result" > .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-test_time-optimized.exit
echo "final-test_time-optimized exit=$result"
