"""Finite serialized lifecycle schedules using supplied app and transport facts."""
import hashlib
import json
import adapter
import catalogue
import h2_client
import hpack
import model
import output_stage
import test_ready


def require(value, message):
    if not value:
        raise RuntimeError(message)


def terminal(tag):
    item = model.record(tag, True, 'after')
    item.update(chunks=1 if tag == 'disconnect' else 2, max_span=7 if tag == 'disconnect' else 25)
    return item


def active(tag):
    item = terminal(tag)
    item.update(bytes=7, sha256=model.H7, ends=0, active=True, chunks=1, max_span=7,
                stale_resume=0, stale_cancel=0)
    if tag == 'disconnect':
        item.update(cancels=0, reason=None, paused=True)
    else:
        item['metadata_end'] = 0
    return item


def pair(old, current=None):
    for action in ('resume', 'cancel'):
        yield '/status/' + old
        if current is not None:
            yield '/status/' + current
        yield '/control/' + action + '/' + old
        yield '/status/' + old
        if current is not None:
            yield '/status/' + current


def order(case, index):
    yield '/health'
    if case == 'disconnect':
        if index == 1:
            yield '/limit/disconnect?case=disconnect'
            yield '/status/disconnect'
            return
        yield '/status/disconnect'
        yield from pair('disconnect')
        yield '/limit/disconnect_recovery?case=disconnect_recovery'
        yield '/status/disconnect_recovery'
        yield from pair('disconnect', 'disconnect_recovery')
        yield '/status/disconnect'
    else:
        for i in range(9):
            tag = 'reuse_' + str(i)
            yield '/limit/' + tag + '?case=' + tag
            yield '/status/' + tag
            for j in range(i):
                yield from pair('reuse_' + str(j), tag)
        for i in range(9):
            yield '/status/reuse_' + str(i)
    yield '/health'


def check(case, *, app=None, prior=(), final=False, fault=None):
    if app is None:
        app = dict(records={tag: model.record(tag, False, 'before') for tag in model.SPECS}, heads=0)
    model.validate_records(prior, 'before', app['records'])
    states, contexts, caller_time = [], [], [1]
    totals = dict(heads=0, controls=0, status=0, uploads=0, data=0, frames=0, ends=0)
    evidence = hashlib.sha256()

    def clock():
        caller_time[0] += 1
        if fault == 'deadline' and totals['uploads']:
            return 30001
        return caller_time[0]

    def connection(index):
        state = dict(startup=True, buffer=bytearray(), pending=[], heads=0, settings=0,
                     streams={}, reads=0, closed=False, final=False, uploads=0,
                     order=iter(order(case, index)), decoder=hpack.Decoder(), encoder=hpack.Encoder())
        states.append(state)

        def response(stream, body):
            block = state['encoder'].encode(((':status', '200'), ('x-middleware', 'retained')))
            state['pending'].append(test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body))

        def observation(path, stream):
            if path == '/health':
                response(stream, b'ok')
                return
            if path.startswith('/status/'):
                totals['status'] += 1
                tag = path[8:]
                item = dict(app['records'][tag])
                if fault == 'active_hash' and item['active']:
                    item['sha256'] = model.H32
                if fault == 'post_reason' and tag == 'disconnect' and index == 2:
                    item['reason'] = 'shutdown'
                response(stream, json.dumps(item).encode())
                return
            if path.startswith('/control/'):
                _, _, action, tag = path.split('/')
                totals['controls'] += 1
                item = app['records'][tag]
                require(not item['active'], 'control targets active record')
                if fault != 'stale_counter':
                    item['stale_' + action] += 1
                if fault == 'stale_other':
                    item['metadata_begin'] = 0
                if fault == 'active_isolation':
                    for row in app['records'].values():
                        if row['active']:
                            row['metadata_begin'] = 0
                response(stream, b'ok' if fault == 'control_reply' else b'BodyControlExpired')
                return
            require(path == '/metrics' and state['final'], 'unexpected observation')
            values = model.metrics(prior + (case,), 'before')
            values.update(buffered_middleware=app['heads'] - values['middleware'], slot0_active=False, slot1_active=False)
            response(stream, json.dumps(values).encode())

        def headers(packet, stream, flags):
            entries = list(state['decoder'].decode(packet[9:]))
            path = dict(entries)[':path']
            expected_path = next(state['order'], None)
            require(path == expected_path and stream == 2 * state['heads'] + 1, 'request order or stream ID differs')
            state['heads'] += 1
            totals['heads'] += 1
            app['heads'] += 1
            upload = path.startswith('/limit/')
            expected = [(':method', 'POST' if upload else 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)]
            if upload:
                tag = path.split('/')[-1].split('?')[0]
                expected += [('content-length', '32'), ('x-case', tag)]
            require(entries == expected and flags == (4 if upload else 5), 'metadata multiplicity or initial END differs')
            evidence.update(json.dumps((index, stream, entries, flags)).encode())
            if not upload:
                observation(path, stream)
                return
            require(not any(item['active'] for item in app['records'].values()), 'prior application record still active')
            state['uploads'] += 1
            totals['uploads'] += 1
            state['streams'][stream] = dict(tag=tag, count=0, digest=hashlib.sha256(), frames=0, ends=0)
            app['records'][tag] = active(tag)
            app['records'][tag].update(bytes=0, sha256=model.EMPTY_HASH, chunks=0, max_span=0)

        def data(packet, stream, flags):
            item = state['streams'][stream]
            tag, offset = item['tag'], item['count']
            length = 32 if tag == 'disconnect' else 7 if offset == 0 else 25
            expected = model.payload_span(32, offset, length)
            require(packet[9:] == expected and flags == int(offset > 0), 'DATA payload length hash or END differs')
            item['count'] += length
            item['frames'] += 1
            item['ends'] += flags
            item['digest'].update(packet[9:])
            totals['data'] += length
            totals['frames'] += 1
            totals['ends'] += flags
            if not flags:
                app['records'][tag] = active(tag)
                if fault == 'early_response':
                    response(stream, b'')
                return
            require(item['count'] == 32 and item['digest'].hexdigest() == model.H32, 'completed upload digest differs')
            app['records'][tag] = terminal(tag)
            app['records'][tag].update(stale_resume=0, stale_cancel=0)
            if fault == 'completed_record':
                app['records'][tag]['metadata_end'] = 0
            if fault == 'other_record':
                app['records']['empty_headers']['middleware'] = 1
            response(stream, json.dumps(app['records'][tag]).encode())

        def packet_received(packet):
            kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
            if kind == 1:
                headers(packet, stream, flags)
                return
            if kind == 0:
                data(packet, stream, flags)
                return
            require(packet == test_ready.frame(4, 1, 0, b''), 'unexpected reset grant or settings')
            state['settings'] += 1

        def send(data_bytes):
            require(not state['closed'], 'post-close original send')
            require(type(data_bytes) is bytes and len(data_bytes) <= 8192, 'send bound differs')
            if state['startup']:
                state['startup'] = False
                require(data_bytes[:24] == b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n' and len(data_bytes) == 75, 'startup differs')
                return
            state['buffer'].extend(data_bytes)
            while len(state['buffer']) >= 9:
                size = int.from_bytes(state['buffer'][:3], 'big')
                if len(state['buffer']) < size + 9:
                    return
                packet = bytes(state['buffer'][:size + 9])
                del state['buffer'][:size + 9]
                packet_received(packet)

        def receive():
            require(not state['closed'], 'post-close original receive')
            state['reads'] += 1
            require(bool(state['pending']) and state['reads'] <= 600, 'missing finite synthetic response')
            return state['pending'].pop(0), clock()

        return state, send, receive

    state, send, receive = connection(1)
    context = adapter.open_case(case, h2_client.new_protocol(), send, 1, 30001, 900001, selected_before=prior, clock=clock)
    contexts.append(context)
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    initial = test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b'')
    adapter.observe(context, initial, clock())

    def close_facts(old):
        require(old is context and state['heads'] == 3 and totals['data'] == 32 and totals['ends'] == 0, 'close boundary differs')
        require(set(old['records']) == {3} and not state['pending'] and not state['buffer'], 'auxiliary remains before close')
        require(old['raw']['closing']['phase'] == 'pre_unwrap', 'canonical begin termination missing')
        require(old['request']['connection_debt'] == 32 and old['request']['stream_debt_total'] == 32, 'old debt missing')
        state['closed'] = True
        app['records']['disconnect'] = terminal('disconnect')
        app['records']['disconnect'].update(stale_resume=0, stale_cancel=0)
        result = dict(method='ssl_unwrap', tls_shutdown='success', tcp_eof=True, trailing_bytes=0, close='normal')
        field = {'close_eof': 'tcp_eof', 'close_trailing': 'trailing_bytes', 'close_method': 'method', 'close_tls': 'tls_shutdown', 'close_kind': 'close'}.get(fault)
        if field is not None:
            result[field] = False if field == 'tcp_eof' else 1 if field == 'trailing_bytes' else 'wrong'
        if fault == 'close_bool':
            result['tcp_eof'] = 1
        return result

    def replacement(old):
        require(old is context and state['closed'] and old['raw']['closed'] and not old['records'] and not old['stage']['active'], 'replacement before transport terminal')
        require(old['request']['transport_closed'] and old['stage']['case_state']['transport_finished'], 'transport accounting unfinished')
        require(old['request']['connection_debt'] == 32 and old['request']['stream_debt_total'] == 0, 'old terminal debt differs')
        new_state, new_send, new_receive = connection(2)
        new_state['pending'].append(initial)
        return dict(protocol=old['protocol'] if fault == 'same_codec' else h2_client.new_protocol(), send=new_send,
                    receive=new_receive, now=clock(), owned=fault != 'unowned', tls='TLSv1.2' if fault == 'tls' else 'TLSv1.3',
                    alpn='http/1.1' if fault == 'alpn' else 'h2')

    result = adapter.run_case(context, receive, disconnect=dict(close=close_facts, replacement=replacement)) if case == 'disconnect' else adapter.run_case(context, receive)
    current = result if case == 'disconnect' else context
    contexts.append(current)
    actual = totals['heads'], current['stage']['case_state']['small'], current['request']['case']['sent']
    require(actual == ((25, 24, 64) if case == 'disconnect' else (389, 389, 288)), 'exact J C R differs')
    require(totals['controls'] == (4 if case == 'disconnect' else 72) and totals['uploads'] == (2 if case == 'disconnect' else 9), 'control or upload count differs')
    require(totals['frames'] == (3 if case == 'disconnect' else 18) and totals['ends'] == (1 if case == 'disconnect' else 9), 'DATA or END count differs')
    for peer in states:
        require(next(peer['order'], None) is None and peer['settings'] == 1 and not peer['pending'] and not peer['buffer'], 'finite schedule unfinished')
    if case == 'disconnect':
        require(current is not context and current['stage']['primary'] == 17, 'actual replacement primary differs')
        require(current['stage']['case_state'] is context['stage']['case_state'] and current['request']['case'] is context['request']['case'], 'case object not shared')
        require((current['stage']['case_deadline'], current['stage']['whole_deadline']) == (30001, 900001), 'replacement deadlines differ')
        require(all(current[key] is not context[key] for key in ('protocol', 'raw', 'records', 'request', 'credit')), 'connection object reused')
        require(context['request']['connection_debt'] == 32 and current['request']['connection_debt'] == 32 and current['request']['stream_debt_total'] == 32, 'cross-connection debt changed')
        receive = replacement_receive(current)
    if final:
        peer = states[-1]
        peer['final'] = True
        peer['order'] = iter(['/status/' + tag for tag in model.SPECS] + ['/metrics'])
        adapter.final_collection(current, receive)
        require(next(peer['order'], None) is None and not peer['pending'], 'final collection unfinished')
    model.validate_records(prior + (case,), 'before', app['records'])
    require(len(app['records']) == 67 and len(current['lifecycle_evidence']['sha256']) == 64, 'persistent records or rolling evidence differs')
    print(case + ' passed: J=%d C=%d R=%d controls=%d request_sha256=%s' % (*actual, totals['controls'], evidence.hexdigest()))
    return app


def replacement_receive(context):
    return context['receive']


def rejected(case, fault, message, *, final=False):
    try:
        check(case, fault=fault, final=final)
    except (ValueError, RuntimeError) as error:
        require(str(error) == message, 'wrong rejection for ' + fault + ': ' + str(error))
        print(fault + ' rejected: ' + str(error))
        return
    raise RuntimeError('control accepted: ' + fault)


def main():
    app = check('disconnect')
    check('reuse', app=app, prior=('disconnect',), final=True)
    check('disconnect', final=True)
    check('reuse', final=True)
    for case in ('disconnect', 'reuse'):
        for fault, message in (('active_hash', 'record mismatch: sha256'), ('stale_counter', 'record mismatch: stale_resume'),
                               ('stale_other', 'record mismatch: metadata_begin'), ('active_isolation', 'record mismatch: metadata_begin'),
                               ('control_reply', 'control result differs'), ('completed_record', 'record mismatch: metadata_end'),
                               ('early_response', 'upload completed before resume'), ('deadline', 'deadline expired or invalid')):
            rejected(case, fault, message)
        rejected(case, 'other_record', 'record mismatch: middleware', final=True)
    for fault, message in (('post_reason', 'record mismatch: reason'), ('close_eof', 'strict close evidence differs'),
                           ('close_bool', 'strict close evidence differs'), ('close_trailing', 'strict close evidence differs'),
                           ('close_method', 'strict close evidence differs'), ('close_tls', 'strict close evidence differs'),
                           ('close_kind', 'strict close evidence differs'), ('same_codec', 'replacement facts differ'),
                           ('unowned', 'replacement facts differ'), ('tls', 'replacement facts differ'), ('alpn', 'replacement facts differ')):
        rejected('disconnect', fault, message)


if __name__ == '__main__':
    main()
