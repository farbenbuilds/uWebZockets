"""Concrete disconnect/replacement and nine-tag stale-control schedules."""
import hashlib
import json
import adapter
import catalogue
import model
import pause_cases
import wire


def record_event(evidence, event):
    payload = json.dumps(event, sort_keys=True, separators=(',', ':')).encode()
    if len(payload) >= 4096:
        raise ValueError('lifecycle evidence bound')
    evidence['digest'].update(len(payload).to_bytes(4, 'big'))
    evidence['digest'].update(payload)
    evidence['events'] += 1


def upload(context, tag, primary, transport=False):
    contract = model.request_contract(tag)
    return adapter.start(context, contract['method'], contract['target'],
                         [('content-length', str(contract['declared'])), ('x-case', contract['x-case'])],
                         False, primary, 0 if transport else 4095, role='transport' if transport else 'small',
                         policy='clean_disconnect' if transport else 'healthy')


def active_expected(tag):
    expected = model.record(tag, True, 'after')
    expected.update(bytes=7, sha256=model.H7, ends=0, active=True, stale_resume=0, stale_cancel=0)
    if tag == 'disconnect':
        expected.update(cancels=0, reason=None, paused=True)
    else:
        expected['metadata_end'] = 0
    return expected


def status(context, receive, tag, expected, evidence, stream=None):
    actual = pause_cases.status(context, receive, tag)
    if stream is not None:
        pause_cases.pending(context, stream)
    model.validate_item(actual, expected)
    record_event(evidence, ('status', tag, actual))
    return actual


def stale_pair(context, receive, old_tag, old_expected, evidence, active_tag=None, active=None, stream=None):
    for action in ('resume', 'cancel'):
        before = status(context, receive, old_tag, old_expected, evidence)
        current = None if active_tag is None else status(context, receive, active_tag, active, evidence, stream)
        pause_cases.control(context, receive, action, old_tag, 'BodyControlExpired')
        old_expected['stale_' + action] += 1
        after = status(context, receive, old_tag, old_expected, evidence)
        compared = dict(before)
        compared['stale_' + action] += 1
        if compared != after:
            raise ValueError('expired control changed old record')
        if active_tag is not None and current != status(context, receive, active_tag, active, evidence, stream):
            raise ValueError('expired control changed active record')
        evidence[action] += 1
        record_event(evidence, ('expired', old_tag, active_tag, action))


def complete(context, receive, stream, tag, evidence):
    actual = json.loads(adapter.finish(context, stream, receive)['body'])
    expected = model.record(tag, True, 'after')
    expected.update(stale_resume=0, stale_cancel=0)
    model.validate_item(actual, expected)
    record_event(evidence, ('complete', tag, actual))


def reuse(context, receive, evidence):
    tags = catalogue.TAGS['reuse']
    adapter.health(context, receive)
    for i, tag in enumerate(tags):
        stream = upload(context, tag, i == 0)
        adapter.send_data(context, stream, model.payload_span(32, 0, 7), False)
        active = active_expected(tag)
        status(context, receive, tag, active, evidence, stream)
        for j, old_tag in enumerate(tags[:i]):
            expected = model.record(old_tag, True, 'after')
            expected.update(stale_resume=i-j-1, stale_cancel=i-j-1)
            stale_pair(context, receive, old_tag, expected, evidence, tag, active, stream)
        adapter.send_data(context, stream, model.payload_span(32, 7, 25), True)
        complete(context, receive, stream, tag, evidence)
    for tag in tags:
        status(context, receive, tag, model.record(tag, True, 'after'), evidence)
    adapter.health(context, receive)
    if (evidence['resume'], evidence['cancel']) != (36, 36):
        raise ValueError('reuse stale counts differ')
    return context


def disconnect(context, receive, hooks, evidence):
    if type(hooks) is not dict or set(hooks) != {'close', 'replacement'} or not all(callable(value) for value in hooks.values()):
        raise ValueError('disconnect hooks required')
    adapter.health(context, receive)
    stream = upload(context, 'disconnect', True, True)
    adapter.send_data(context, stream, model.payload_span(32, 0, 32), False)
    status(context, receive, 'disconnect', active_expected('disconnect'), evidence, stream)
    adapter.flush(context)
    adapter.tick(context)
    wire.begin_termination(context['records'], context['raw'], stream, 'clean_disconnect', 'pre_unwrap', stage=context['stage'])
    close = hooks['close'](context)
    adapter.tick(context)
    terminal = wire.finish_termination(context['records'], context['raw'], stream, 'clean_disconnect', 'pre_unwrap', close,
                                       request=context['request'], credit=context['credit'], stage=context['stage'])
    record_event(evidence, ('supplied_close', terminal))
    context['transport_observation'] = terminal
    supplied = hooks['replacement'](context)
    replacement = adapter.replace_connection(context, supplied)
    receive = supplied['receive']
    replacement['receive'] = receive
    while replacement['stage']['initial_settings'] != 1 or replacement['stage']['acks'] != 1:
        adapter.tick(replacement)
        data, now = receive()
        adapter.observe(replacement, data, now)
    adapter.health(replacement, receive)
    old = model.record('disconnect', True, 'after')
    old.update(stale_resume=0, stale_cancel=0)
    status(replacement, receive, 'disconnect', old, evidence)
    stale_pair(replacement, receive, 'disconnect', old, evidence)
    recovery = upload(replacement, 'disconnect_recovery', True)
    adapter.send_data(replacement, recovery, model.payload_span(32, 0, 7), False)
    active = active_expected('disconnect_recovery')
    status(replacement, receive, 'disconnect_recovery', active, evidence, recovery)
    stale_pair(replacement, receive, 'disconnect', old, evidence, 'disconnect_recovery', active, recovery)
    adapter.send_data(replacement, recovery, model.payload_span(32, 7, 25), True)
    complete(replacement, receive, recovery, 'disconnect_recovery', evidence)
    status(replacement, receive, 'disconnect', model.record('disconnect', True, 'after'), evidence)
    adapter.health(replacement, receive)
    if (evidence['resume'], evidence['cancel']) != (2, 2):
        raise ValueError('disconnect stale counts differ')
    context['completed'] = True
    return replacement


def run(context, receive, hooks=None):
    evidence = dict(digest=hashlib.sha256(), events=0, resume=0, cancel=0)
    if context['stage']['case'] == 'disconnect':
        result = disconnect(context, receive, hooks, evidence)
    else:
        result = reuse(context, receive, evidence)
    result['lifecycle_evidence'] = dict(sha256=evidence['digest'].hexdigest(), events=evidence['events'],
                                        stale_resume=evidence['resume'], stale_cancel=evidence['cancel'])
    return result


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned hooks')
