"""Thirty-eight implemented combined case selections and caller-supplied deadlines."""
import catalogue

IMPLEMENTED = ('ready_buffered', 'async_delayed', 'large_declared', 'large_undeclared', 'partial_pause', 'final_pause', 'begin_pause_empty', 'control_rules', 'empty_headers', 'empty_data', 'empty_declared', 'limit_declared', 'limit_undeclared', 'limit_declared_reject', 'limit_observed_reject', 'zero_declared_reject', 'zero_observed_reject', 'continue_ready', 'continue_paused', 'quota_refuse', 'begin_failure_rollback', 'queued_trailers_padding', 'receive_credit', 'metadata_helpers', 'concurrent_routes', 'cancel_ready', 'cancel_paused', 'peer_reset', 'sink_error', 'invalid_progress', 'end_error', 'producer_reuse', 'output_pressure_window', 'output_pressure_ready', 'stream_file', 'early_final_order', 'disconnect', 'reuse')


def select(selection):
    catalogue.schedule(selection)
    if any(case not in IMPLEMENTED for case in selection):
        raise ValueError('case schedule not implemented')
    return tuple(selection)


def deadlines(case, now, whole_deadline, units_per_second):
    select((case,))
    if any(type(value) is not int for value in (now, whole_deadline, units_per_second)):
        raise ValueError('deadline inputs must be integers')
    if now < 0 or whole_deadline <= now or units_per_second <= 0:
        raise ValueError('invalid deadline inputs')
    duration = catalogue.mul_u64(catalogue.case_budget(case)['timeout_seconds'], units_per_second)
    return min(catalogue.add_u64(now, duration), whole_deadline), whole_deadline


if __name__ == '__main__':
    raise SystemExit('Import this module with explicit caller-owned context')
