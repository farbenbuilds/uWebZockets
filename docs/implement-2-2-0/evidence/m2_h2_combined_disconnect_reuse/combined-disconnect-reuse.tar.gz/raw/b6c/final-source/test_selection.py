"""Selection and deadline contracts for the first combined cases."""
import cases


def rejected(call, *args):
    try:
        call(*args)
    except ValueError:
        return
    raise RuntimeError('invalid input accepted')


def check():
    if len(cases.IMPLEMENTED) != 38 or cases.select(('disconnect', 'reuse')) != ('disconnect', 'reuse'):
        raise RuntimeError('lifecycle selection inventory differs')
    names = ('ready_buffered', 'async_delayed', 'large_declared', 'large_undeclared')
    if cases.select(names) != names:
        raise RuntimeError('selection differs')
    for selection in (('ready_buffered', 'ready_buffered'), ('shutdown_idle',), ('unknown',), None):
        rejected(cases.select, selection)
    if cases.deadlines('large_declared', 20, 200000, 1000) != (180020, 200000):
        raise RuntimeError('deadline conversion differs')
    if cases.deadlines('ready_buffered', 20, 25000, 1000) != (25000, 25000):
        raise RuntimeError('whole deadline not retained')
    for values in (('ready_buffered', True, 200, 1), ('ready_buffered', 2, 2, 1),
                   ('ready_buffered', 0, 200, 0)):
        rejected(cases.deadlines, *values)
    print('selection and deadline checks passed')


if __name__ == '__main__':
    check()
