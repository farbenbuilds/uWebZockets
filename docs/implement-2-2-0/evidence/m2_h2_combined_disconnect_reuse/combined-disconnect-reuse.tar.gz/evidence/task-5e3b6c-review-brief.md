# Task5e3b6c independent source review

Review only the completed disconnect/reuse source unit, first spec compliance,
then code quality. Root has not accepted or committed this unit. Broader
whole-branch review and native acceptance remain separate required work.

Requirements: `task-5e3b6c-brief.md`, `task-5e3b6c-resume-brief.md`,
`task-5e3b-release-addendum.md`, and `task-5e3b-cases-pending-brief.md` in this
plan workspace. The explicit release/addenda supersede the older pending
heading only; preserve every original requirement.

Claims: `task-5e3b6c-report.md` (including raw-result appendices).
Diff: `task-5e3b6c-review-source.diff`.
Root's independent file/receipt/identity audit:
`task-5e3b6c-root-final-audit.json`.
Base: `738dbe140731cf32b8c7a552e906988622dfffcd`; head is the exact current
ignored 33-module source snapshot, not a new Git commit. The diff is the full
change from the 31-module accepted B6b archive, tests first, with context 10.
It is 47079 bytes, SHA256
`f52f84926eef762cf676bc2bff06141581ff8d21ad97791e5d9ebfef6aa88732`.

Read the diff once. Do not separately reread changed files unless a hunk
needed for judgment cuts off mid-function; name that gap in your report.
Unchanged inputs may be inspected for a concrete named risk, one focused
check per risk. Do not crawl the repository or rerun Git commands. Treat the
implementation report and Root audit as claims to evaluate, not approvals.

Binding requirements copied from the task/spec:

- "Eleven new records, all untouched records/shared synthetic app/final67+metrics,
  exact caller order and two independent connection ledgers remain mandatory."
- "Share the same output-stage case object and request-credit case object across
  two fresh protocol/connection states. output_stage.new_stage forbids replacement
  before transport_finished and enforces the exact same case/whole deadline pair."
- "Keep independent parser/request/response debt: no cross-connection credit reuse."
- "Use wire.begin_termination/finish_termination with their actual supported phase
  and typed record; no fabricated END/reset or direct state clearing."
- "Hash rolling evidence/counters rather than retaining the control/frame history."
- "No invented public BodyToken generation field; actual fixture controls are tags."
- "Supplied close/TLS/app records are synthetic input, not native
  close/ownership/callback proof."
- "No model/core/fixture/product/dependency/capacity/budget/deadline changes,
  native/build/socket/SSLContext/TLS-close/clock/process ownership/transfer/fault/
  descriptor/kernel/cancel/schedule/race/panic/leak experiments, old entrypoints,
  Git/public changes or other agents. Pure in-memory public codecs and supplied
  transport facts only."

The original brief supplies both exact schedules and all J/C/R counts; review
them literally. Pay attention to the changed common adapter's replacement
boundary, caller-owned contexts/time/deadlines and canonical earned response
credit replenishment, including unchanged callers. The source proof must
retain exact ordering, metadata, stale/current isolation, finite bounds and
the qualification of supplied app/transport facts. Initial selection RED and
intermediate calibration/seam failures must keep their actual scope.

The implementer reports 40 final normal/-O checks, all 33 module guards and
actual empty/foreign-argv inert imports, four positive new-suite executions
and 41 named synthetic rejections per mode, plus focused seam checks. Root
matched all current/frozen/diff module hashes, read every raw exit/stderr,
verified the exact test/mode multiset, retained history, and unchanged inputs.
Do not rerun those same checks. A test is appropriate only for a concrete
unanswered doubt; keep it focused and within the source-only restrictions.

Apply AGENTS.md/CODING_CONVENTION.md, code-review-and-quality, and the explicitly
requested thermo-nuclear-code-quality-review structural lens, with project
overrides. Before new codebase searches/source reads, use the prescribed
graphify prefix in the requirements. The supplied paths are already located.
No emojis, subagents, external model CLI, edits, Git/service writes, or native
operations. You are read-only and are not alone in this workspace.

Return the full review as your final response: SPEC PASS or FAIL, QUALITY
APPROVED or NEEDS FIXES, actionable findings by severity with file:line and
failure scenarios, strengths with evidence, and cannot-verify items with the
specific remaining check. Do not write a report file or provide process prose.
