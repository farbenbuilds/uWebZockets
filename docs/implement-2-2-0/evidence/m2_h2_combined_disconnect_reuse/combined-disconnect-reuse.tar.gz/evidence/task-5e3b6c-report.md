# Task5e3b6c: disconnect replacement and body-slot reuse source schedules

The continued WIP implements the two released concrete schedules over the
unchanged reviewed public-codec seam. The current inventory is38/40 source
schedules and33 modules. This report claims pure in-memory source verification
with supplied app/transport facts. Native TLS close, ownership, callbacks,
post-deinit comparison, runtime adoption, combined all40 acceptance and the
2.2.0 milestones remain unproved. Root owns independent review, publication,
commit and immediate push.

## Scope, continuity and identities

Requirements are `task-5e3b6c-brief.md`, its continuation brief,
`task-5e3b-release-addendum.md` and `task-5e3b-cases-pending-brief.md`.
Released B6b base is `738dbe140731cf32b8c7a552e906988622dfffcd`.
The replacement owner continued the actual33 modules restored by Root;
the31-module baseline was used only for comparison. No source was reset.
`task-5e3b6c-root-resume-restoration.json` authenticates the WIP transfer,
restored inputs and pre-transfer histories. `task-5e3b6c-resume-source/`
retains the transferred bytes. Root subsequently restored the full historical
candidate/libxev source trees; its separate
`task-5e3b6c-root-full-source-restoration.json` records that source-only work.
The four already restored candidate references and required input hashes did
not change. No binary restoration or native execution was released.

Owned source/evidence paths below are relative to
`.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/`.
`evidence/b6c/before-source/` matches all31 published B6b module identities in
`docs/implement-2-2-0/evidence/m2_h2_combined_file_early/manifest.json`.
`evidence/b6c/snapshot.json`, `final-source/`, `before-map.json` and
`source.diff` retain the final33 modules, exact hashes, depth audit and full
comparison. There are2 added,8 changed,23 unchanged and0 removed modules.

The immutable inputs remain the model/catalogue at
`/tmp/uwz-task5e1-contract-v3`,26 core modules at
`/tmp/uwz-task5e3a-snapshot-v9/source`,42 pinned codec files at
`/tmp/uwz-h2-client-tooling/packages`, and the pinned integration-client helper.
The latter retains SHA256
`07a5201f4cb85be3053b572ae6ffccb7173c263db44483f76bd934b5d6f09d00`.
Authenticated lifecycle/strict-close source at
`/tmp/uwz-task5c3-runtime-v2` supplied ordering and typed-fact contracts.
Current model/catalogue/fixture supersede its older record aliases.
No old lifecycle/live/strict-close entrypoint, native constructor or operation
was executed.

`evidence/b6c/immutable-inputs.json` retains119 identity entries:118 file rows
correspond to113 unique resolved file paths; the additional codec aggregate
makes114 unique entries. These are retained row counts, not119 distinct files.
The42 codec rows preserve their exact order and exact current file set.
The canonical aggregate is SHA256 of default `json.dumps(rows).encode()`,
`0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`.
Every retained input row and codec row was rehashed; none was relabeled,
replaced or accommodated after a mismatch.

## Contracts and actual interfaces

The new `lifecycle_cases.py` adds concrete `disconnect`, `reuse` and `run`
schedules. Its helpers validate exact model records, reuse existing
`pause_cases.status/control/pending`, and hash bounded evidence events rather
than storing control/frame histories. Each serialized event must be smaller
than4096 bytes. Public BodyToken generation fields were not invented; controls
target the actual fixture tags.

`adapter.run_case(context, receive, *, disconnect=None)` adds an optional
caller-owned hook dictionary for disconnect, with exactly callable `close`
and `replacement` entries. Existing single-connection call signatures and
results remain usable. New cases return their final context so callers can
collect on the replacement connection. The old context is completed after
disconnect. `adapter.replace_connection(context, supplied)` is the concrete
replacement seam, adding terminal-state/fact/identity invariants; it is not a
forwarding wrapper or a general continuation framework.

The close hook receives the original context and supplies exactly:
`method=ssl_unwrap`, `tls_shutdown=success`, `tcp_eof=True`,
`trailing_bytes=0`, `close=normal`, with strict bool/int types.
`wire.begin_termination` and `wire.finish_termination` use policy
`clean_disconnect` and actual supported phase `pre_unwrap`. Completion uses
the reviewed typed record, parser and both credit ledgers. No fabricated
END/reset or direct state clearing substitutes for termination.

The replacement hook receives that terminal context and supplies exactly
`protocol`, `send`, `receive`, `now`, `owned`, `tls`, `alpn`.
The codec must be distinct and non-null, hooks callable, `now` an integer
at least the original current time, `owned is True`, TLS `TLSv1.3`, ALPN `h2`.
The adapter rejects replacement unless the original raw parser and request
transport are closed, case transport accounting is finished, and response
records, stage-active records and response stream credit are retired.
`output_stage.new_stage` receives the same output case object and exact
deadline pair. `request_credit.new_state` receives the same request case
object, while parser/codec/records/request-state/response-state are fresh and
bound with `wire.bind_connection`. Startup runs once on the supplied initiated
codec. The replacement retains the caller time hook and selection context.

`adapter.observe` rejects all old-context observations after terminal close.
Reuse creates its canonical grant policy through `wire.new_grants`. When
connection response credit reaches32767 or below, `adapter.observe` calls
`wire.grant(..., stream_id=0, amount=flow_bytes-connection_replenished,
purpose=replenish)`. This replenishes only earned response DATA from that
bound connection. There is no direct ledger mutation, bootstrap borrowing,
extra HEADERS, alternate parser or duplicate request refund.

`cases.py` now describes38 implemented cases. `test_imports.py` names all33
modules. Four existing unsupported-count assertions change exactly4 to2;
their rejection loops remain. `test_selection.py` additionally verifies38
and caller-preserved `('disconnect', 'reuse')` ordering. These inventory
corrections represent newly implemented cases, not a lower acceptance bar.

## Concrete schedules and independent decoding

| Case | Heads J | Small C | Request flow R | Connections |
| --- | ---: | ---: | ---: | ---: |
| disconnect |25|24|64|2|
| reuse |389|389|288|1|

Disconnect sends initial health1, primary3 with exact declared32 model
metadata,32 request bytes without END, then one accepted7/paused preclose
status on the original connection.32 is wire flow;7 is the supplied app
accepted-prefix record. The test does not infer native callback acceptance.
All auxiliaries retire before canonical begin/finish transport termination.
Original/replacement head totals are3/22. Replacement health is stream1;
recovery is stream17 after the prescribed status/control requests.

Replacement observes the old peer_closed/cancel1/inactive record, executes
expired resume and cancel with old status before/after each, then starts
recovery and sends7 without END. Both expired controls repeat while recovery
is active, each surrounded by old and current status before/after. Only the
matching old stale counter changes; recovery stays identical. The remaining25
plus END completes recovery, followed by final old status and end health.
There are16 status heads,4 controls,2 uploads and3 health heads. Request DATA
is3 frames with1 END. The case sends32+32=64, independent of the39 app-accepted
bytes across the interrupted primary and complete recovery.

Reuse sends initial health and nine exact tags reuse_0 through reuse_8. Each
declares32, sends7 without END, observes active7, then tests resume/cancel for
every prior tag with both old/current statuses before and after. It sends25
plus END and validates that current completed record before starting the
next. Nine final statuses and end health finish the schedule. Each operation
has36 expired controls; final stale counters are8-i for tag i. The360
control/status heads,9 upload heads,9 active checkpoints,9 final statuses
and2 health heads total389. There are306 status heads,72 controls,18 request
DATA frames and9 END flags; request flow is9*32=288.

`test_lifecycle.py` independently decodes actual outbound bytes with pinned
HPACK and frame-header decoding. A finite order generator checks every
method/scheme/authority/path/query/header pair in sequence, duplicate header
multiplicity, flags and actual odd stream IDs. It verifies each bounded DATA
payload at its independent expected offset, full32-byte wire digest, exact
per-upload/per-case DATA frame and END counts, settings ACKs, connection count
and empty serialization/response queues at the finite boundary. The peer
rejects all old-connection sends/receives after supplied close. Each callback
read is bounded by600 and every send by8192 bytes.

Two case objects are shared by identity across disconnect connections; all
connection objects are distinct. Both original connection/aggregate stream
debts remain32 at termination; replacement connection/aggregate stream debts
are independently32 after recovery. Deadlines remain30001/900001 in supplied
integer units. No real clock is read. Serialized reuse grants must be positive,
connection-only and at most response DATA earned on that connection; their
sum equals canonical replenishment accounting. Rejected unearned/foreign
grants must leave the original credit counters unchanged.

Four positive executions run per mode: disconnect then reuse over one shared
synthetic app with final67+metrics, standalone disconnect with final67+metrics,
and standalone reuse with final67+metrics. Eleven changed records and every
untouched persistent record are validated; all67 remain present. Shared app
and final records/metrics are supplied synthetic observations validated
against the immutable model, not independent native fixture measurements.

## RED and intermediate history

All pre-transfer historical receipts and source/test snapshots are preserved
byte-for-byte. `evidence/b6c/preserved-history.json` rechecks67 historical
entries against Root's transfer map, including the31 before-source files.

Initial RED exited1 because disconnect was not selected/implemented. It stopped
at `cases.select` before serialization. Although the initial test contains
serialized schedules, this RED proves only unsupported selection; it does not
prove earlier serialized behavior was exercised. Initial-red/attempt1/attempt2
have no retained `.command` file. Their raw outputs and snapshots are retained;
this report does not invent a missing historical command receipt.

Attempt1 exited1: transport primary used4095 response bytes instead of the
canonical0 expectation (`invalid close expectation`). Attempt2 exited1: the
test incorrectly expected terminal aggregate stream debt0 instead of32.
Attempt3 exited1 after disconnect passed: reuse exhausted public response
connection credit (`FlowControlError: Flow control window shrunk below 0`).
Attempt4 exited1 after the four positive executions: the early-response
negative expected the reuse error for disconnect, whose canonical raw parser
correctly rejects `unexpected closing target payload`. Attempt5 exited0 with
four positives and29 exact synthetic negatives. Its receipts are historical,
not current proof for later test edits. These histories include actual seam
corrections and test-expectation corrections; no failing implementation was
rolled back to manufacture RED.

The continuation's `resume-confirm` exited0 before edits, reconfirming those
four positives/29 negatives. Five `resume-inventory-red-*` commands exited1:
the actual import inventory still named31 modules, and four suites still
expected4 unsupported cases. Only those inventories/messages were corrected;
rejection loops and their old semantic checks remain.

Attempt6 exited0 after adding focused negatives and terminal/deadline/credit
seam checks. Its retained test snapshot precedes the final exact per-upload
frame/hash assertions. A preceding40-command normal/O pass and snapshot are
retained under `evidence/b6c/pre-review/`. The final matrix reran after the
last review assertions. A metadata-only audit-script generator initially
failed with an unterminated here-document/triple-quoted string; the delimiter
was corrected before the audit ran. This was not a source or test failure.

The41 current named negative executions per mode cover each case's active
hash, missing stale counter, unrelated old-record change, active isolation,
wrong expired-control reply, completed metadata, early final response,
deadline and untouched-record contamination; plus disconnect terminal reason,
all strict-close fields/types/extra field, same/null codec, supplied ownership
type/value, TLS/ALPN, invalid hooks/time/record shape. Direct negative calls
also reject replacement before terminal, changed deadline pairs, post-terminal
old observations, unearned response grants and foreign credit binding.
All are postimplementation synthetic sensitivity checks, not native failure,
race/cancellation or an earlier product-regression claim.

## Verification, self-review and remaining facts

`evidence/b6c/final-checks.command` contains the40 exact current invocations.
`final-commands.json` indexes exact environment/commands and every raw
stdout/stderr/exit file. The appendices below reproduce their current results,
the final audit and all33 current hashes. Both actual import runs exercise all
33 modules under empty and foreign argv using rejecting caller-owned
file/socket/SSLContext/process/clock/console doubles. Every module has exactly
one main guard; AST checks reject classes and assertion-based proof. Maximum
control depth is3, new schedule2 and new test3.

Python optimization modes are normal and `-O`, both with pinned
`/home/codespace/.python/current/bin/python3 -B -S`. They are not Zig modes.
No native/Zig build, socket/TLS/SSLContext/real-close, process ownership,
descriptor/kernel, cancellation/race/fault/panic/leak or performance experiment
ran. Broad project unit/sanitizer/protocol/platform gates remain required in
their later authorized phase. MSan is a C-boundary check, does not instrument
Zig and cannot combine with ASan; neither sanitizer ran here. No performance
or zero-allocation claim is made for the allocating Python preparation code.

Self-review checked correctness, ownership, tests, conventions and gate
integrity. The implementation uses only actual public codec actions and the
canonical staged termination/grant seams; model/core/fixture/product,
dependencies, capacities, budgets and deadlines remain unchanged. No authored
classes, custom exceptions, hidden mutable globals, swallowed errors, dead
helper or generic continuation framework was added. Per-peer/per-upload
counters and hashes are consumed by independent checks. Existing inventories
were corrected solely for the two implemented cases. Final source copies,+current hashes and all prior histories remain reviewable.

No immutable API gap was encountered. Source acceptance remains Root's
independent review decision. Unsupported cases remain `shutdown_idle` and
`shutdown_active`; all40/default/subset/aggregate semantics, all41 connections
over two sequential fresh children, real successful TLS unwrap plus TCP EOF,
native ownership/body-slot reuse/callback evidence, runtime adapter closure,
adoption and every full milestone remain required subsequent work. No public
documentation or Git operation was performed by this owner.

## Recorded final receipts

Every test below used this exact environment:

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
```

All40 exits are0 and all40 raw stderr files are empty. Raw files remain alongside each `.command` and `.exit` file; the following reproduces each exact invocation and stdout.

### final-test_adapter-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_adapter.py
```

Exit: `0`; stderr: empty.

```text
paired startup and rejection checks passed
```

### final-test_adapter-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_adapter.py
```

Exit: `0`; stderr: empty.

```text
paired startup and rejection checks passed
```

### final-test_admission-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_admission.py
```

Exit: `0`; stderr: empty.

```text
empty_headers passed: heads=3 flow=0
empty_data passed: heads=3 flow=0
empty_declared passed: heads=3 flow=0
limit_declared passed: heads=3 flow=32
limit_undeclared passed: heads=3 flow=32
limit_declared_reject passed: heads=4 flow=32
limit_observed_reject passed: heads=5 flow=65
zero_declared_reject passed: heads=4 flow=0
zero_observed_reject passed: heads=4 flow=1
empty_headers passed: heads=3 flow=0
empty_data passed: heads=3 flow=0
empty_declared passed: heads=3 flow=0
limit_declared passed: heads=3 flow=32
limit_undeclared passed: heads=3 flow=32
limit_declared_reject passed: heads=4 flow=32
limit_observed_reject passed: heads=5 flow=65
zero_declared_reject passed: heads=4 flow=0
zero_observed_reject passed: heads=4 flow=1
reset_first rejected: reset order
continue rejected: invalid HEADERS
refusal_data rejected: response body bound
bad_prefix rejected: record mismatch: bytes
```

### final-test_admission-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_admission.py
```

Exit: `0`; stderr: empty.

```text
empty_headers passed: heads=3 flow=0
empty_data passed: heads=3 flow=0
empty_declared passed: heads=3 flow=0
limit_declared passed: heads=3 flow=32
limit_undeclared passed: heads=3 flow=32
limit_declared_reject passed: heads=4 flow=32
limit_observed_reject passed: heads=5 flow=65
zero_declared_reject passed: heads=4 flow=0
zero_observed_reject passed: heads=4 flow=1
empty_headers passed: heads=3 flow=0
empty_data passed: heads=3 flow=0
empty_declared passed: heads=3 flow=0
limit_declared passed: heads=3 flow=32
limit_undeclared passed: heads=3 flow=32
limit_declared_reject passed: heads=4 flow=32
limit_observed_reject passed: heads=5 flow=65
zero_declared_reject passed: heads=4 flow=0
zero_observed_reject passed: heads=4 flow=1
reset_first rejected: reset order
continue rejected: invalid HEADERS
refusal_data rejected: response body bound
bad_prefix rejected: record mismatch: bytes
```

### final-test_application_error-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_application_error.py
```

Exit: `0`; stderr: empty.

```text
sink_error passed: J=11 C=10 R=48
invalid_progress passed: J=11 C=10 R=48
end_error passed: J=10 C=9 R=65
sink_error passed: J=11 C=10 R=48
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
terminal_cancel rejected: record mismatch: cancels
terminal_ends rejected: record mismatch: ends
terminal_bytes rejected: record mismatch: bytes
terminal_hash rejected: record mismatch: sha256
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
primary_final rejected: unexpected final
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
invalid_progress passed: J=11 C=10 R=48
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
terminal_cancel rejected: record mismatch: cancels
terminal_ends rejected: record mismatch: ends
terminal_bytes rejected: record mismatch: bytes
terminal_hash rejected: record mismatch: sha256
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
primary_final rejected: unexpected final
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
end_error passed: J=10 C=9 R=65
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
terminal_cancel rejected: record mismatch: cancels
terminal_ends rejected: record mismatch: ends
terminal_bytes rejected: record mismatch: bytes
terminal_hash rejected: record mismatch: sha256
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
primary_final rejected: unexpected final
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
preterminal_cancel rejected: record mismatch: cancels
terminal_chunks rejected: failure callback follows accepted prefix
early_final rejected: upload completed before resume
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
preterminal_cancel rejected: record mismatch: cancels
terminal_chunks rejected: failure callback follows accepted prefix
early_final rejected: upload completed before resume
chunk_diagnostic rejected: record mismatch: chunk_errors
progress_diagnostic rejected: record mismatch: invalid_progress
end_diagnostic rejected: record mismatch: end_errors
```

### final-test_application_error-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_application_error.py
```

Exit: `0`; stderr: empty.

```text
sink_error passed: J=11 C=10 R=48
invalid_progress passed: J=11 C=10 R=48
end_error passed: J=10 C=9 R=65
sink_error passed: J=11 C=10 R=48
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
terminal_cancel rejected: record mismatch: cancels
terminal_ends rejected: record mismatch: ends
terminal_bytes rejected: record mismatch: bytes
terminal_hash rejected: record mismatch: sha256
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
primary_final rejected: unexpected final
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
invalid_progress passed: J=11 C=10 R=48
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
terminal_cancel rejected: record mismatch: cancels
terminal_ends rejected: record mismatch: ends
terminal_bytes rejected: record mismatch: bytes
terminal_hash rejected: record mismatch: sha256
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
primary_final rejected: unexpected final
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
end_error passed: J=10 C=9 R=65
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
terminal_cancel rejected: record mismatch: cancels
terminal_ends rejected: record mismatch: ends
terminal_bytes rejected: record mismatch: bytes
terminal_hash rejected: record mismatch: sha256
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
primary_final rejected: unexpected final
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
preterminal_cancel rejected: record mismatch: cancels
terminal_chunks rejected: failure callback follows accepted prefix
early_final rejected: upload completed before resume
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
preterminal_cancel rejected: record mismatch: cancels
terminal_chunks rejected: failure callback follows accepted prefix
early_final rejected: upload completed before resume
chunk_diagnostic rejected: record mismatch: chunk_errors
progress_diagnostic rejected: record mismatch: invalid_progress
end_diagnostic rejected: record mismatch: end_errors
```

### final-test_async-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_async.py
```

Exit: `0`; stderr: empty.

```text
async_delayed codec schedule passed
```

### final-test_async-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_async.py
```

Exit: `0`; stderr: empty.

```text
async_delayed codec schedule passed
```

### final-test_continue_quota-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py
```

Exit: `0`; stderr: empty.

```text
pre-Continue DATA rejected: DATA before Continue or after terminal
continue_ready passed: heads=3 flow=32
continue_paused passed: heads=5 flow=32
quota_refuse passed: heads=11 flow=128
begin_failure_rollback passed: heads=4 flow=32
continue_ready passed: heads=3 flow=32
continue_paused passed: heads=5 flow=32
quota_refuse passed: heads=11 flow=128
begin_failure_rollback passed: heads=4 flow=32
wrong_failure rejected: record mismatch: failures
other_record rejected: record mismatch: middleware
missing_continue rejected: invalid DATA
refusal_continue rejected: invalid HEADERS
refusal_data rejected: response body bound
reset_first rejected: reset order
active_count rejected: quota active barrier differs
paused_bytes rejected: record mismatch: bytes
early_final rejected: invalid terminal
```

### final-test_continue_quota-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py
```

Exit: `0`; stderr: empty.

```text
pre-Continue DATA rejected: DATA before Continue or after terminal
continue_ready passed: heads=3 flow=32
continue_paused passed: heads=5 flow=32
quota_refuse passed: heads=11 flow=128
begin_failure_rollback passed: heads=4 flow=32
continue_ready passed: heads=3 flow=32
continue_paused passed: heads=5 flow=32
quota_refuse passed: heads=11 flow=128
begin_failure_rollback passed: heads=4 flow=32
wrong_failure rejected: record mismatch: failures
other_record rejected: record mismatch: middleware
missing_continue rejected: invalid DATA
refusal_continue rejected: invalid HEADERS
refusal_data rejected: response body bound
reset_first rejected: reset order
active_count rejected: quota active barrier differs
paused_bytes rejected: record mismatch: bytes
early_final rejected: invalid terminal
```

### final-test_control_reset-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_control_reset.py
```

Exit: `0`; stderr: empty.

```text
cancel_ready passed: J=12 C=11 R=40
cancel_paused passed: J=12 C=11 R=65
peer_reset passed: J=11 C=10 R=65
cancel_ready passed: J=12 C=11 R=40
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
early_final rejected: upload completed before resume
primary_final rejected: unexpected final
other_record rejected: record mismatch: middleware
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
early_final rejected: upload completed before resume
primary_final rejected: unexpected final
other_record rejected: record mismatch: middleware
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
early_final rejected: upload completed before resume
primary_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
preterminal_chunks rejected: record mismatch: chunks
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
```

### final-test_control_reset-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_control_reset.py
```

Exit: `0`; stderr: empty.

```text
cancel_ready passed: J=12 C=11 R=40
cancel_paused passed: J=12 C=11 R=65
peer_reset passed: J=11 C=10 R=65
cancel_ready passed: J=12 C=11 R=40
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
early_final rejected: upload completed before resume
primary_final rejected: unexpected final
other_record rejected: record mismatch: middleware
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
early_final rejected: upload completed before resume
primary_final rejected: unexpected final
other_record rejected: record mismatch: middleware
preterminal_bytes rejected: record mismatch: bytes
preterminal_pause rejected: record mismatch: paused
terminal_reason rejected: record mismatch: reason
terminal_metadata rejected: record mismatch: metadata_begin
stale_reply rejected: control result differs
missing_refund rejected: missing finite synthetic response
excess_refund rejected: invalid connection refund
sibling_echo rejected: sibling echo differs
recovery_record rejected: record mismatch: metadata_end
stale_counter rejected: record mismatch: stale_resume
early_final rejected: upload completed before resume
primary_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
preterminal_chunks rejected: record mismatch: chunks
reset_code rejected: wrong reset code
duplicate_reset rejected: invalid reset
missing_reset rejected: missing finite synthetic response
```

### final-test_credit-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_credit.py
```

Exit: `0`; stderr: empty.

```text
queued_trailers_padding passed
receive_credit passed
paused_record rejected: record mismatch: bytes
missing_stream_credit rejected: missing synthetic response
```

### final-test_credit-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_credit.py
```

Exit: `0`; stderr: empty.

```text
queued_trailers_padding passed
receive_credit passed
paused_record rejected: record mismatch: bytes
missing_stream_credit rejected: missing synthetic response
```

### final-test_file_early-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_file_early.py
```

Exit: `0`; stderr: empty.

```text
producer_reuse passed: J=9 C=8 R=64 output=16777313
stream_file passed: J=7 C=6 R=33 output=24593
early_final_order passed: J=7 C=6 R=32 output=17
stream_file passed: J=7 C=6 R=33 output=24593
early_final_order passed: J=7 C=6 R=32 output=17
body_hash rejected: record mismatch: sha256
output_hash rejected: body length or digest differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
informationals rejected: invalid HEADERS
other_record rejected: record mismatch: middleware
body_hash rejected: record mismatch: sha256
output_hash rejected: file or early checkpoint differs
output_status rejected: wrong final status
missing_end rejected: reset order
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
informationals rejected: invalid HEADERS
other_record rejected: record mismatch: middleware
held_close rejected: file close once
close_twice rejected: file close once
ownership rejected: file ownership
arm_error rejected: file ownership
read_error rejected: file ownership
invalid_span rejected: file ownership
range rejected: file bounded range
requested rejected: file bounded range
no_reads rejected: file bounded range
range_generator rejected: body length or digest differs
sibling rejected: sibling echo differs
missing_sibling rejected: missing finite synthetic response
content_length rejected: InvalidBodyLengthError: Expected 24592 bytes, received 24593
duplicate_length rejected: file content-length differs
missing_length rejected: file content-length differs
holder_admission rejected: record mismatch: attempts
prefix_body_hash rejected: record mismatch: sha256
output_tail rejected: body length or digest differs
prefix_end rejected: invalid terminal
reset_first rejected: reset order
reset_code rejected: wrong reset code
missing_reset rejected: missing finite synthetic response
```

### final-test_file_early-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_file_early.py
```

Exit: `0`; stderr: empty.

```text
producer_reuse passed: J=9 C=8 R=64 output=16777313
stream_file passed: J=7 C=6 R=33 output=24593
early_final_order passed: J=7 C=6 R=32 output=17
stream_file passed: J=7 C=6 R=33 output=24593
early_final_order passed: J=7 C=6 R=32 output=17
body_hash rejected: record mismatch: sha256
output_hash rejected: body length or digest differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
informationals rejected: invalid HEADERS
other_record rejected: record mismatch: middleware
body_hash rejected: record mismatch: sha256
output_hash rejected: file or early checkpoint differs
output_status rejected: wrong final status
missing_end rejected: reset order
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
informationals rejected: invalid HEADERS
other_record rejected: record mismatch: middleware
held_close rejected: file close once
close_twice rejected: file close once
ownership rejected: file ownership
arm_error rejected: file ownership
read_error rejected: file ownership
invalid_span rejected: file ownership
range rejected: file bounded range
requested rejected: file bounded range
no_reads rejected: file bounded range
range_generator rejected: body length or digest differs
sibling rejected: sibling echo differs
missing_sibling rejected: missing finite synthetic response
content_length rejected: InvalidBodyLengthError: Expected 24592 bytes, received 24593
duplicate_length rejected: file content-length differs
missing_length rejected: file content-length differs
holder_admission rejected: record mismatch: attempts
prefix_body_hash rejected: record mismatch: sha256
output_tail rejected: body length or digest differs
prefix_end rejected: invalid terminal
reset_first rejected: reset order
reset_code rejected: wrong reset code
missing_reset rejected: missing finite synthetic response
```

### final-test_final-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_final.py
```

Exit: `0`; stderr: empty.

```text
ready_buffered codec schedule passed
```

### final-test_final-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_final.py
```

Exit: `0`; stderr: empty.

```text
ready_buffered codec schedule passed
```

### final-test_imports-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `0`; stderr: empty.

```text
AST and inert import checks passed
```

### final-test_imports-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `0`; stderr: empty.

```text
AST and inert import checks passed
```

### final-test_large-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_large.py
```

Exit: `0`; stderr: empty.

```text
large_declared codec schedule passed
large_undeclared codec schedule passed
```

### final-test_large-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_large.py
```

Exit: `0`; stderr: empty.

```text
large_declared codec schedule passed
large_undeclared codec schedule passed
```

### final-test_lifecycle-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py
```

Exit: `0`; stderr: empty.

```text
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=798d2d285194944a252568d0d51805fc0e738708be2e662d670d1901a9e7cf95
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=ed8a52e985e735f2801d8f12214e8911633579df5f6e60ebe8887ab5b4f7e93c
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
active_hash rejected: record mismatch: sha256
stale_counter rejected: record mismatch: stale_resume
stale_other rejected: record mismatch: metadata_begin
active_isolation rejected: record mismatch: metadata_begin
control_reply rejected: control result differs
completed_record rejected: record mismatch: metadata_end
early_response rejected: unexpected closing target payload
deadline rejected: deadline expired or invalid
other_record rejected: record mismatch: middleware
active_hash rejected: record mismatch: sha256
stale_counter rejected: record mismatch: stale_resume
stale_other rejected: record mismatch: metadata_begin
active_isolation rejected: record mismatch: metadata_begin
control_reply rejected: control result differs
completed_record rejected: record mismatch: metadata_end
early_response rejected: upload completed before resume
deadline rejected: deadline expired or invalid
other_record rejected: record mismatch: middleware
post_reason rejected: record mismatch: reason
close_eof rejected: strict close evidence differs
close_bool rejected: strict close evidence differs
close_trailing rejected: strict close evidence differs
close_method rejected: strict close evidence differs
close_tls rejected: strict close evidence differs
close_kind rejected: strict close evidence differs
same_codec rejected: replacement facts differ
unowned rejected: replacement facts differ
tls rejected: replacement facts differ
alpn rejected: replacement facts differ
close_trailing_bool rejected: strict close evidence differs
close_extra rejected: strict close evidence differs
replacement_extra rejected: replacement facts differ
null_codec rejected: replacement facts differ
send_hook rejected: replacement facts differ
receive_hook rejected: replacement facts differ
now_bool rejected: replacement facts differ
now_past rejected: replacement facts differ
owned_int rejected: replacement facts differ
missing_hooks rejected: disconnect hooks required
extra_hook rejected: disconnect hooks required
invalid_hook rejected: disconnect hooks required
```

### final-test_lifecycle-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py
```

Exit: `0`; stderr: empty.

```text
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=798d2d285194944a252568d0d51805fc0e738708be2e662d670d1901a9e7cf95
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=ed8a52e985e735f2801d8f12214e8911633579df5f6e60ebe8887ab5b4f7e93c
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
active_hash rejected: record mismatch: sha256
stale_counter rejected: record mismatch: stale_resume
stale_other rejected: record mismatch: metadata_begin
active_isolation rejected: record mismatch: metadata_begin
control_reply rejected: control result differs
completed_record rejected: record mismatch: metadata_end
early_response rejected: unexpected closing target payload
deadline rejected: deadline expired or invalid
other_record rejected: record mismatch: middleware
active_hash rejected: record mismatch: sha256
stale_counter rejected: record mismatch: stale_resume
stale_other rejected: record mismatch: metadata_begin
active_isolation rejected: record mismatch: metadata_begin
control_reply rejected: control result differs
completed_record rejected: record mismatch: metadata_end
early_response rejected: upload completed before resume
deadline rejected: deadline expired or invalid
other_record rejected: record mismatch: middleware
post_reason rejected: record mismatch: reason
close_eof rejected: strict close evidence differs
close_bool rejected: strict close evidence differs
close_trailing rejected: strict close evidence differs
close_method rejected: strict close evidence differs
close_tls rejected: strict close evidence differs
close_kind rejected: strict close evidence differs
same_codec rejected: replacement facts differ
unowned rejected: replacement facts differ
tls rejected: replacement facts differ
alpn rejected: replacement facts differ
close_trailing_bool rejected: strict close evidence differs
close_extra rejected: strict close evidence differs
replacement_extra rejected: replacement facts differ
null_codec rejected: replacement facts differ
send_hook rejected: replacement facts differ
receive_hook rejected: replacement facts differ
now_bool rejected: replacement facts differ
now_past rejected: replacement facts differ
owned_int rejected: replacement facts differ
missing_hooks rejected: disconnect hooks required
extra_hook rejected: disconnect hooks required
invalid_hook rejected: disconnect hooks required
```

### final-test_metadata_concurrency-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py
```

Exit: `0`; stderr: empty.

```text
metadata helper/overflow contract checked; seven synthetic header oracle controls rejected
metadata_helpers passed: heads=6 small=6 flow=32
concurrent_routes passed: heads=13 small=13 flow=96
helpers_begin rejected: record mismatch: helpers_begin
helpers_end rejected: record mismatch: helpers_end
metadata_middleware rejected: record mismatch: metadata_middleware
metadata_begin rejected: record mismatch: metadata_begin
metadata_end rejected: record mismatch: metadata_end
paused_bytes rejected: record mismatch: bytes
not_paused rejected: record mismatch: paused
early_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
paused_bytes rejected: record mismatch: bytes
not_paused rejected: record mismatch: paused
early_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
refusal_status rejected: wrong final status
refusal_continue rejected: invalid HEADERS
reset_first rejected: reset order
reset_code rejected: wrong reset code
active_count rejected: concurrent active barrier differs
paused_count rejected: concurrent active barrier differs
slot_count rejected: concurrent active barrier differs
resume_prefix rejected: record mismatch: sha256
route_contamination rejected: record mismatch: metadata_begin
2 unsupported cases rejected before actions
```

### final-test_metadata_concurrency-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py
```

Exit: `0`; stderr: empty.

```text
metadata helper/overflow contract checked; seven synthetic header oracle controls rejected
metadata_helpers passed: heads=6 small=6 flow=32
concurrent_routes passed: heads=13 small=13 flow=96
helpers_begin rejected: record mismatch: helpers_begin
helpers_end rejected: record mismatch: helpers_end
metadata_middleware rejected: record mismatch: metadata_middleware
metadata_begin rejected: record mismatch: metadata_begin
metadata_end rejected: record mismatch: metadata_end
paused_bytes rejected: record mismatch: bytes
not_paused rejected: record mismatch: paused
early_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
paused_bytes rejected: record mismatch: bytes
not_paused rejected: record mismatch: paused
early_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
refusal_status rejected: wrong final status
refusal_continue rejected: invalid HEADERS
reset_first rejected: reset order
reset_code rejected: wrong reset code
active_count rejected: concurrent active barrier differs
paused_count rejected: concurrent active barrier differs
slot_count rejected: concurrent active barrier differs
resume_prefix rejected: record mismatch: sha256
route_contamination rejected: record mismatch: metadata_begin
2 unsupported cases rejected before actions
```

### final-test_negative-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_negative.py
```

Exit: `0`; stderr: empty.

```text
credit and terminal rejection checks passed
```

### final-test_negative-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_negative.py
```

Exit: `0`; stderr: empty.

```text
credit and terminal rejection checks passed
```

### final-test_pause-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_pause.py
```

Exit: `0`; stderr: empty.

```text
partial_pause passed: heads=7 flow=12289
final_pause passed: heads=6 flow=32
begin_pause_empty passed: heads=6 flow=0
control_rules passed: heads=20 flow=64
partial_pause passed: heads=7 flow=12289
final_pause passed: heads=6 flow=32
wrong tag rejected before control: record mismatch: tag
premature response rejected: invalid terminal
```

### final-test_pause-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_pause.py
```

Exit: `0`; stderr: empty.

```text
partial_pause passed: heads=7 flow=12289
final_pause passed: heads=6 flow=32
begin_pause_empty passed: heads=6 flow=0
control_rules passed: heads=20 flow=64
partial_pause passed: heads=7 flow=12289
final_pause passed: heads=6 flow=32
wrong tag rejected before control: record mismatch: tag
premature response rejected: invalid terminal
```

### final-test_producer_pressure-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_producer_pressure.py
```

Exit: `0`; stderr: empty.

```text
producer_reuse passed: J=9 C=8 R=64 output=16777313
output_pressure_window passed: J=8 C=7 R=33 output=16777313
output_pressure_ready passed: J=6 C=5 R=33 output=16777313
producer_reuse passed: J=9 C=8 R=64 output=16777313
output_pressure_ready passed: J=6 C=5 R=33 output=16777313
body_hash rejected: record mismatch: sha256
diagnostic_hash rejected: producer identity
output_hash rejected: body length or digest differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
body_hash rejected: record mismatch: sha256
diagnostic_hash rejected: producer identity
output_hash rejected: producer checkpoint differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
body_hash rejected: record mismatch: sha256
diagnostic_hash rejected: producer identity
output_hash rejected: body length or digest differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
identity rejected: producer identity changed
counter rejected: producer held state
monotonic rejected: producer counter decreased
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
identity rejected: producer identity changed
counter rejected: producer held state
monotonic rejected: producer counter decreased
prefix_end rejected: invalid terminal
missing_sibling rejected: missing finite synthetic response
binding_generation rejected: relative reuse binding
binding_slot rejected: relative reuse binding
after_reuse rejected: reuse callback missing
sibling rejected: sibling echo differs
sibling rejected: sibling echo differs
```

### final-test_producer_pressure-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_producer_pressure.py
```

Exit: `0`; stderr: empty.

```text
producer_reuse passed: J=9 C=8 R=64 output=16777313
output_pressure_window passed: J=8 C=7 R=33 output=16777313
output_pressure_ready passed: J=6 C=5 R=33 output=16777313
producer_reuse passed: J=9 C=8 R=64 output=16777313
output_pressure_ready passed: J=6 C=5 R=33 output=16777313
body_hash rejected: record mismatch: sha256
diagnostic_hash rejected: producer identity
output_hash rejected: body length or digest differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
body_hash rejected: record mismatch: sha256
diagnostic_hash rejected: producer identity
output_hash rejected: producer checkpoint differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
body_hash rejected: record mismatch: sha256
diagnostic_hash rejected: producer identity
output_hash rejected: body length or digest differs
output_status rejected: wrong final status
missing_end rejected: missing finite synthetic response
deadline rejected: deadline expired or invalid
backwards_time rejected: monotonic time moved backwards
missing_ack rejected: missing finite synthetic response
other_record rejected: record mismatch: middleware
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
identity rejected: producer identity changed
counter rejected: producer held state
monotonic rejected: producer counter decreased
early_data rejected: Flow control window shrunk below 0
early_end rejected: invalid terminal
identity rejected: producer identity changed
counter rejected: producer held state
monotonic rejected: producer counter decreased
prefix_end rejected: invalid terminal
missing_sibling rejected: missing finite synthetic response
binding_generation rejected: relative reuse binding
binding_slot rejected: relative reuse binding
after_reuse rejected: reuse callback missing
sibling rejected: sibling echo differs
sibling rejected: sibling echo differs
```

### final-test_ready-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_ready.py
```

Exit: `0`; stderr: empty.

```text
ready_buffered codec schedule passed
```

### final-test_ready-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_ready.py
```

Exit: `0`; stderr: empty.

```text
ready_buffered codec schedule passed
```

### final-test_selection-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_selection.py
```

Exit: `0`; stderr: empty.

```text
selection and deadline checks passed
```

### final-test_selection-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_selection.py
```

Exit: `0`; stderr: empty.

```text
selection and deadline checks passed
```

### final-test_shared-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shared.py
```

Exit: `0`; stderr: empty.

```text
entry debt connection=1781 stream=1781 budget=3110658; final bytes=28992 reads=69; upload frames=12208
shared schedules and carried final boundary passed
```

### final-test_shared-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_shared.py
```

Exit: `0`; stderr: empty.

```text
entry debt connection=1781 stream=1781 budget=3110658; final bytes=28992 reads=69; upload frames=12208
shared schedules and carried final boundary passed
```

### final-test_time-normal

```sh
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_time.py
```

Exit: `0`; stderr: empty.

```text
ready_buffered codec schedule passed
fresh time checks passed
```

### final-test_time-optimized

```sh
/home/codespace/.python/current/bin/python3 -B -S -O .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_time.py
```

Exit: `0`; stderr: empty.

```text
ready_buffered codec schedule passed
fresh time checks passed
```

## Recorded final audit

```sh
sh .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/b6c/final-audit.command
```

Exit: `0`; stderr: empty.

```text
33 modules: 2 added, 8 changed, 23 unchanged, 0 removed against released B6b
119 retained identity rows / 114 unique entries: 118 file rows / 113 unique resolved files plus codec aggregate
42 ordered codec identities and default-json aggregate match; no extra or missing codec files
40 final normal/-O commands exit0 with empty stderr; all33-module AST and actual inert empty/foreign argv imports pass
maximum control depth=3; new schedule=2; new test=3
38 source schedules; two rejected unsupported selections; final collection67 records plus metrics
new test: four positive executions and41 exact synthetic negative rejections per mode, plus direct terminal/deadline/credit guards
preserved historical evidence identities=67
remaining selections: shutdown_idle, shutdown_active
```

## Final33-module source map

| Module | SHA256 | B6b comparison |
| --- | --- | --- |
| `adapter.py` | `68d2a0b8f770b75a65682b4a33f8fb69144a0a782767edce16ae3a703b68c850` | changed |
| `admission_cases.py` | `b4cac4031f9be16bca938f7167bb327f4eae4fd5667b42cb70fc23782f8fbbcf` | unchanged |
| `application_error_cases.py` | `9d63d938391f2181205766c3297d9aae5ce6966d9f371251b9fa5aeb152d9e68` | unchanged |
| `cases.py` | `6d3326f907d7ea5e6cfc4bd6966fced0ebb580754b6b4b15ac4452e4fb84fd4f` | changed |
| `concurrent_cases.py` | `a9ab3e7b6f6a362c1c6d33788fa8b7c3ed5961989be1f58d7fd6cc66a998a7c1` | unchanged |
| `continue_quota_cases.py` | `da533ef0fde4179c00427d11b689cba1fdf248e41ba01c98a47f37a08ec99e95` | unchanged |
| `control_reset_cases.py` | `36b8fe72e24eaf8cb7a30b470ea4c23823f324373ac3d4d90a6cc8a1595979d7` | unchanged |
| `credit_cases.py` | `f953e2bacb92c4370904cf2b6e302a215aed9bd28210290406aac965e8d2178d` | unchanged |
| `file_early_cases.py` | `90479c670ee1d75c4974704bb6b51d4543142c80c10a8b01963a1a31e0dc9d8c` | unchanged |
| `lifecycle_cases.py` | `3aeb930ef537ac4690ba3f0b5deaffd3a1770981e247652f9fb2f77ffd98a92c` | added |
| `metadata_cases.py` | `7a48599c53779a2414f4492371174d35030e91d1dd61570408248b7eae12b83c` | unchanged |
| `pause_cases.py` | `c7e28527478f3a3e52de22de019e1698083a8d03b4bca3100dd4788e77a8f250` | unchanged |
| `producer_pressure_cases.py` | `44cb04ab3eee53c50c8cd508244486ef6693646aa276836e244a9fb18caffbda` | unchanged |
| `test_adapter.py` | `ef325e804d454e12a4f8b2d2dfa2e0c778736758cf8618334081c864940aefbf` | unchanged |
| `test_admission.py` | `62a9dfbd680e98ff899ed90362d36e568985a5b6c2b79759f3aeef1189efc2d0` | changed |
| `test_application_error.py` | `221d38b7d31fc419d990df1ce512f9cdc509e7c3a9eb1f9c4ef961a43b82c96c` | unchanged |
| `test_async.py` | `bcf31ec8037b3ba4861d25e7983efaeef269df5c084dc3922cc358d8e94ae314` | unchanged |
| `test_continue_quota.py` | `33292a249affad2f9416ac72fa28f87d7767f6cae839d04d17406c2bbc79593e` | changed |
| `test_control_reset.py` | `7b81f969a0cd5146ac5ac075bd2cc2d25aca890c021db4ab73f828eb04780d67` | unchanged |
| `test_credit.py` | `bd03e99dbe6d1297bc96badf870c4be7486ef2524a14befd323bbebb8a9e0a65` | unchanged |
| `test_file_early.py` | `8feb6e45339160eb28b19a5635a22eba58cc8206f6f127975739201b0d045604` | unchanged |
| `test_final.py` | `bbcd200d37e232ca43fb417b4a757d88fe86bb186319f64bd4bf99e534ded694` | unchanged |
| `test_imports.py` | `f2c14bdcf13596837803404a2e15f761cf97825b60e6b287259787f1fa56c336` | changed |
| `test_large.py` | `5710cb5be11f777f2c0ba4f0b3a647227f75b5955dcf1f8cecd750419b46c7d0` | unchanged |
| `test_lifecycle.py` | `7346386e3482a800bfe20b0dc8da8726dc66d6dd8a516ac038de4222a21f535a` | added |
| `test_metadata_concurrency.py` | `5f6ee2825bc86a1c3ef6f16fea8bf8dfc1bde9c464e3ab3e4f277d84fbabf612` | changed |
| `test_negative.py` | `91ae248806c1402bd4219474c3e08e1ef2fcb5994d3e6f7b5e7f40fac4ec47f0` | unchanged |
| `test_pause.py` | `f6067540f6fc54bdac0d059d90bbc85523b659ee069267c65937a498df67abf5` | changed |
| `test_producer_pressure.py` | `79dc174853ad5285c37e6f36368199d20d403f3afa488e80a32a04faa036ff51` | unchanged |
| `test_ready.py` | `600ec8b0bc072aa4d9a52417425e77c56edc2e02680bdb01d9d288c52001b442` | unchanged |
| `test_selection.py` | `f1069202083649f89ec95bdab588025a78f8d22ba631b21a540c642e86bde702` | changed |
| `test_shared.py` | `cbd3370c4dd56990c126939503a35dd5eabd8a03ce71195865152510a973b91b` | unchanged |
| `test_time.py` | `0e10a1c68bfdd754b67a656bd8f4cc05ca8fcf8c9af63ab66130e2e969edf967` | unchanged |

## Retained earlier receipt details

These receipts precede the final33-module snapshot. Their outcomes do not substitute for the final checks above.

### initial-red

Historical exact command file was not retained. Raw original receipts and corresponding source/test snapshots remain preserved.

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 312, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 292, in main
    app = check('disconnect')
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 217, in check
    context = adapter.open_case(case, h2_client.new_protocol(), send, 1, 30001, 900001, selected_before=prior, clock=clock)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 18, in open_case
    cases.select((case,))
    ~~~~~~~~~~~~^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/cases.py", line 10, in select
    raise ValueError('case schedule not implemented')
ValueError: case schedule not implemented
```

### attempt-1

Historical exact command file was not retained. Raw original receipts and corresponding source/test snapshots remain preserved.

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 312, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 292, in main
    app = check('disconnect')
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 249, in check
    result = adapter.run_case(context, receive, disconnect=dict(close=close_facts, replacement=replacement)) if case == 'disconnect' else adapter.run_case(context, receive)
             ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 256, in run_case
    result = lifecycle_cases.run(context, receive, disconnect)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/lifecycle_cases.py", line 141, in run
    result = disconnect(context, receive, hooks, evidence)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/lifecycle_cases.py", line 98, in disconnect
    stream = upload(context, 'disconnect', True, True)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/lifecycle_cases.py", line 22, in upload
    return adapter.start(context, contract['method'], contract['target'],
           ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                         [('content-length', str(contract['declared'])), ('x-case', contract['x-case'])],
                         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                         False, primary, 4095, role='transport' if transport else 'small',
                         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                         policy='clean_disconnect' if transport else 'healthy')
                         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 106, in start
    stream, chunks = wire.start_request(stage, method, 'localhost', path, headers, end_stream,
                     ~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                        role=role, primary=primary, held=held, body_limit=limit,
                                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                        final_status=status, info_count=info, policy=policy, mode=mode,
                                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                        expected_sha256=expected_sha256, middleware_policy=middleware)
                                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e3a-snapshot-v9/source/wire.py", line 334, in start_request
    register(trial_records, trial_raw, stream_id, body_limit, final_status, info_count, policy,
    ~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
             stage=trial_stage, mode=mode, credit_policy='manual', expected_sha256=expected_sha256,
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
             middleware_policy=middleware_policy)
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e3a-snapshot-v9/source/wire.py", line 128, in register
    require(body_limit == 0 and info_count == 0, 'invalid close expectation')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e3a-snapshot-v9/source/wire.py", line 25, in require
    raise ValueError(message)
ValueError: invalid close expectation
```

### attempt-2

Historical exact command file was not retained. Raw original receipts and corresponding source/test snapshots remain preserved.

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 312, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 292, in main
    app = check('disconnect')
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 249, in check
    result = adapter.run_case(context, receive, disconnect=dict(close=close_facts, replacement=replacement)) if case == 'disconnect' else adapter.run_case(context, receive)
             ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 256, in run_case
    result = lifecycle_cases.run(context, receive, disconnect)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/lifecycle_cases.py", line 141, in run
    result = disconnect(context, receive, hooks, evidence)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/lifecycle_cases.py", line 110, in disconnect
    supplied = hooks['replacement'](context)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 242, in replacement
    require(old['request']['connection_debt'] == 32 and old['request']['stream_debt_total'] == 0, 'old terminal debt differs')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 15, in require
    raise RuntimeError(message)
RuntimeError: old terminal debt differs
```

### attempt-3

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py
```

Exit: `1`.

stdout:

```text
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=798d2d285194944a252568d0d51805fc0e738708be2e662d670d1901a9e7cf95
```

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 312, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 293, in main
    check('reuse', app=app, prior=('disconnect',), final=True)
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 249, in check
    result = adapter.run_case(context, receive, disconnect=dict(close=close_facts, replacement=replacement)) if case == 'disconnect' else adapter.run_case(context, receive)
                                                                                                                                          ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 256, in run_case
    result = lifecycle_cases.run(context, receive, disconnect)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/lifecycle_cases.py", line 143, in run
    result = reuse(context, receive, evidence)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/lifecycle_cases.py", line 83, in reuse
    stale_pair(context, receive, old_tag, expected, evidence, tag, active, stream)
    ~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/lifecycle_cases.py", line 49, in stale_pair
    before = status(context, receive, old_tag, old_expected, evidence)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/lifecycle_cases.py", line 39, in status
    actual = pause_cases.status(context, receive, tag)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/pause_cases.py", line 9, in status
    return json.loads(adapter.get(context, '/status/' + tag, receive)['body'])
                      ~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 161, in get
    return finish(context, start(context, 'GET', path, (), True, primary, limit, middleware), receive)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 139, in finish
    observe(context, data, now)
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 98, in observe
    wire.accept(context['protocol'], data, context['records'], context['raw'], context['trace'],
    ~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                credit=context['credit'], request=context['request'], stage=context['stage'])
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e3a-snapshot-v9/source/wire.py", line 151, in accept
    return _accept(protocol, data, records, raw, trace, credit=credit, request=request, stage=stage)
  File "/tmp/uwz-task5e3a-snapshot-v9/source/wire.py", line 162, in _accept
    events = protocol.receive_data(data)
  File "/tmp/uwz-h2-client-tooling/packages/h2/connection.py", line 1520, in receive_data
    events.extend(self._receive_frame(frame))
                  ~~~~~~~~~~~~~~~~~~~^^^^^^^
  File "/tmp/uwz-h2-client-tooling/packages/h2/connection.py", line 1546, in _receive_frame
    frames, events = self._frame_dispatch_table[frame.__class__](frame)
                     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^^
  File "/tmp/uwz-h2-client-tooling/packages/h2/connection.py", line 1745, in _receive_data_frame
    self._inbound_flow_control_window_manager.window_consumed(
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^
        flow_controlled_length,
        ^^^^^^^^^^^^^^^^^^^^^^^
    )
    ^
  File "/tmp/uwz-h2-client-tooling/packages/h2/windows.py", line 50, in window_consumed
    raise FlowControlError(msg)
h2.exceptions.FlowControlError: Flow control window shrunk below 0
```

### attempt-4

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py
```

Exit: `1`.

stdout:

```text
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=798d2d285194944a252568d0d51805fc0e738708be2e662d670d1901a9e7cf95
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=ed8a52e985e735f2801d8f12214e8911633579df5f6e60ebe8887ab5b4f7e93c
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
active_hash rejected: record mismatch: sha256
stale_counter rejected: record mismatch: stale_resume
stale_other rejected: record mismatch: metadata_begin
active_isolation rejected: record mismatch: metadata_begin
control_reply rejected: control result differs
completed_record rejected: record mismatch: metadata_end
```

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 287, in rejected
    check(case, fault=fault, final=final)
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 257, in check
    result = adapter.run_case(context, receive, disconnect=dict(close=close_facts, replacement=replacement)) if case == 'disconnect' else adapter.run_case(context, receive)
             ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 260, in run_case
    result = lifecycle_cases.run(context, receive, disconnect)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/lifecycle_cases.py", line 142, in run
    result = disconnect(context, receive, hooks, evidence)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/lifecycle_cases.py", line 101, in disconnect
    status(context, receive, 'disconnect', active_expected('disconnect'), evidence, stream)
    ~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/lifecycle_cases.py", line 39, in status
    actual = pause_cases.status(context, receive, tag)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/pause_cases.py", line 9, in status
    return json.loads(adapter.get(context, '/status/' + tag, receive)['body'])
                      ~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 165, in get
    return finish(context, start(context, 'GET', path, (), True, primary, limit, middleware), receive)
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 143, in finish
    observe(context, data, now)
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/adapter.py", line 98, in observe
    wire.accept(context['protocol'], data, context['records'], context['raw'], context['trace'],
    ~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                credit=context['credit'], request=context['request'], stage=context['stage'])
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e3a-snapshot-v9/source/wire.py", line 151, in accept
    return _accept(protocol, data, records, raw, trace, credit=credit, request=request, stage=stage)
  File "/tmp/uwz-task5e3a-snapshot-v9/source/wire.py", line 161, in _accept
    expected_updates = raw_observer.observe(raw, data, request=request, stage=stage)
  File "/tmp/uwz-task5e3a-snapshot-v9/source/raw_observer.py", line 168, in observe
    require(record is None or record['policy'] not in CLOSE_POLICIES, 'unexpected closing target payload')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/uwz-task5e3a-snapshot-v9/source/raw_observer.py", line 14, in require
    raise ValueError(message)
ValueError: unexpected closing target payload

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 316, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 305, in main
    rejected(case, fault, message)
    ~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 289, in rejected
    require(str(error) == message, 'wrong rejection for ' + fault + ': ' + str(error))
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py", line 15, in require
    raise RuntimeError(message)
RuntimeError: wrong rejection for early_response: unexpected closing target payload
```

### attempt-5

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py
```

Exit: `0`.

stdout:

```text
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=798d2d285194944a252568d0d51805fc0e738708be2e662d670d1901a9e7cf95
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=ed8a52e985e735f2801d8f12214e8911633579df5f6e60ebe8887ab5b4f7e93c
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
active_hash rejected: record mismatch: sha256
stale_counter rejected: record mismatch: stale_resume
stale_other rejected: record mismatch: metadata_begin
active_isolation rejected: record mismatch: metadata_begin
control_reply rejected: control result differs
completed_record rejected: record mismatch: metadata_end
early_response rejected: unexpected closing target payload
deadline rejected: deadline expired or invalid
other_record rejected: record mismatch: middleware
active_hash rejected: record mismatch: sha256
stale_counter rejected: record mismatch: stale_resume
stale_other rejected: record mismatch: metadata_begin
active_isolation rejected: record mismatch: metadata_begin
control_reply rejected: control result differs
completed_record rejected: record mismatch: metadata_end
early_response rejected: upload completed before resume
deadline rejected: deadline expired or invalid
other_record rejected: record mismatch: middleware
post_reason rejected: record mismatch: reason
close_eof rejected: strict close evidence differs
close_bool rejected: strict close evidence differs
close_trailing rejected: strict close evidence differs
close_method rejected: strict close evidence differs
close_tls rejected: strict close evidence differs
close_kind rejected: strict close evidence differs
same_codec rejected: replacement facts differ
unowned rejected: replacement facts differ
tls rejected: replacement facts differ
alpn rejected: replacement facts differ
```

stderr: empty.

### resume-confirm

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py
```

Exit: `0`.

stdout:

```text
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=798d2d285194944a252568d0d51805fc0e738708be2e662d670d1901a9e7cf95
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=ed8a52e985e735f2801d8f12214e8911633579df5f6e60ebe8887ab5b4f7e93c
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
active_hash rejected: record mismatch: sha256
stale_counter rejected: record mismatch: stale_resume
stale_other rejected: record mismatch: metadata_begin
active_isolation rejected: record mismatch: metadata_begin
control_reply rejected: control result differs
completed_record rejected: record mismatch: metadata_end
early_response rejected: unexpected closing target payload
deadline rejected: deadline expired or invalid
other_record rejected: record mismatch: middleware
active_hash rejected: record mismatch: sha256
stale_counter rejected: record mismatch: stale_resume
stale_other rejected: record mismatch: metadata_begin
active_isolation rejected: record mismatch: metadata_begin
control_reply rejected: control result differs
completed_record rejected: record mismatch: metadata_end
early_response rejected: upload completed before resume
deadline rejected: deadline expired or invalid
other_record rejected: record mismatch: middleware
post_reason rejected: record mismatch: reason
close_eof rejected: strict close evidence differs
close_bool rejected: strict close evidence differs
close_trailing rejected: strict close evidence differs
close_method rejected: strict close evidence differs
close_tls rejected: strict close evidence differs
close_kind rejected: strict close evidence differs
same_codec rejected: replacement facts differ
unowned rejected: replacement facts differ
tls rejected: replacement facts differ
alpn rejected: replacement facts differ
```

stderr: empty.

### attempt-6

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_lifecycle.py
```

Exit: `0`.

stdout:

```text
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=798d2d285194944a252568d0d51805fc0e738708be2e662d670d1901a9e7cf95
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
disconnect passed: J=25 C=24 R=64 controls=4 request_sha256=ed8a52e985e735f2801d8f12214e8911633579df5f6e60ebe8887ab5b4f7e93c
reuse passed: J=389 C=389 R=288 controls=72 request_sha256=ee9e64efa87e260356b093b427c567a7694541963a37ac1214b74cd7249a0ea5
active_hash rejected: record mismatch: sha256
stale_counter rejected: record mismatch: stale_resume
stale_other rejected: record mismatch: metadata_begin
active_isolation rejected: record mismatch: metadata_begin
control_reply rejected: control result differs
completed_record rejected: record mismatch: metadata_end
early_response rejected: unexpected closing target payload
deadline rejected: deadline expired or invalid
other_record rejected: record mismatch: middleware
active_hash rejected: record mismatch: sha256
stale_counter rejected: record mismatch: stale_resume
stale_other rejected: record mismatch: metadata_begin
active_isolation rejected: record mismatch: metadata_begin
control_reply rejected: control result differs
completed_record rejected: record mismatch: metadata_end
early_response rejected: upload completed before resume
deadline rejected: deadline expired or invalid
other_record rejected: record mismatch: middleware
post_reason rejected: record mismatch: reason
close_eof rejected: strict close evidence differs
close_bool rejected: strict close evidence differs
close_trailing rejected: strict close evidence differs
close_method rejected: strict close evidence differs
close_tls rejected: strict close evidence differs
close_kind rejected: strict close evidence differs
same_codec rejected: replacement facts differ
unowned rejected: replacement facts differ
tls rejected: replacement facts differ
alpn rejected: replacement facts differ
close_trailing_bool rejected: strict close evidence differs
close_extra rejected: strict close evidence differs
replacement_extra rejected: replacement facts differ
null_codec rejected: replacement facts differ
send_hook rejected: replacement facts differ
receive_hook rejected: replacement facts differ
now_bool rejected: replacement facts differ
now_past rejected: replacement facts differ
owned_int rejected: replacement facts differ
missing_hooks rejected: disconnect hooks required
extra_hook rejected: disconnect hooks required
invalid_hook rejected: disconnect hooks required
```

stderr: empty.

### resume-inventory-red-test_imports

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py
```

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py", line 76, in <module>
    check()
    ~~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_imports.py", line 35, in check
    raise RuntimeError('authored source inventory differs')
RuntimeError: authored source inventory differs
```

### resume-inventory-red-test_admission

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_admission.py
```

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_admission.py", line 203, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_admission.py", line 182, in main
    raise RuntimeError('unsupported inventory differs')
RuntimeError: unsupported inventory differs
```

### resume-inventory-red-test_continue_quota

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py
```

Exit: `1`.

stdout:

```text
pre-Continue DATA rejected: DATA before Continue or after terminal
```

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py", line 256, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py", line 221, in main
    raise RuntimeError('unsupported inventory differs')
RuntimeError: unsupported inventory differs
```

### resume-inventory-red-test_pause

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_pause.py
```

Exit: `1`.

stdout: empty.

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_pause.py", line 187, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_pause.py", line 158, in main
    raise RuntimeError('unsupported inventory differs')
RuntimeError: unsupported inventory differs
```

### resume-inventory-red-test_metadata_concurrency

```sh
export PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases
/home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py
```

Exit: `1`.

stdout:

```text
metadata helper/overflow contract checked; seven synthetic header oracle controls rejected
metadata_helpers passed: heads=6 small=6 flow=32
concurrent_routes passed: heads=13 small=13 flow=96
helpers_begin rejected: record mismatch: helpers_begin
helpers_end rejected: record mismatch: helpers_end
metadata_middleware rejected: record mismatch: metadata_middleware
metadata_begin rejected: record mismatch: metadata_begin
metadata_end rejected: record mismatch: metadata_end
paused_bytes rejected: record mismatch: bytes
not_paused rejected: record mismatch: paused
early_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
paused_bytes rejected: record mismatch: bytes
not_paused rejected: record mismatch: paused
early_final rejected: invalid terminal
other_record rejected: record mismatch: middleware
refusal_status rejected: wrong final status
refusal_continue rejected: invalid HEADERS
reset_first rejected: reset order
reset_code rejected: wrong reset code
active_count rejected: concurrent active barrier differs
paused_count rejected: concurrent active barrier differs
slot_count rejected: concurrent active barrier differs
resume_prefix rejected: record mismatch: sha256
route_contamination rejected: record mismatch: metadata_begin
```

stderr:

```text
Traceback (most recent call last):
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py", line 365, in <module>
    main()
    ~~~~^^
  File "/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_metadata_concurrency.py", line 351, in main
    raise RuntimeError('unsupported inventory differs')
RuntimeError: unsupported inventory differs
```

## Graphify receipts

The prescribed prefix was used before the first new codebase search/read:

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "combined-cases lifecycle_cases adapter replacement response credit disconnect reuse test_lifecycle" --budget 650
```

Exit0; the graph returned229 nodes and reported its650-token truncation. Provided concrete paths were already located. After code edits:

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .
```

Exit0; raw final stdout:

```text
Re-extracting code files in . (no LLM needed)...
[graphify watch] 373 file(s) not classified (no supported extension or shebang), skipped: .dockerignore, .git, .gitattributes, .gitignore, .gitmodules, Dockerfile (+367 more)
[graphify watch] No relevant changes; graphify-out left untouched.
Code graph updated. For doc/paper/image changes run /graphify --update in your AI assistant.
Tip: set GEMINI_API_KEY or GOOGLE_API_KEY to use Gemini for semantic extraction.
```

The owned ignored workspace did not produce relevant Graphify changes. No semantic API operation ran.

## Metadata-only generator correction

The failed invocation began `python3 -B -S - <<'PY'`; its generated shell recipe also contained a literal `PY` terminator, ending the outer heredoc too early. Exit1, empty stdout, raw stderr follows. The full failed generator command was not saved on disk; it remains in the tool transcript. No source or prior receipt was changed by this failed generation. The corrected generator used the distinct `MAKE_AUDIT` delimiter and produced the retained `final-audit.command`, whose actual run exited0.

```text
  File "<stdin>", line 14
    command=command[:start]+'''    contracts={case:dict(catalogue.case_budget(case)) for case in ('disconnect','reuse')}
                            ^
SyntaxError: unterminated triple-quoted string literal (detected at line 38)
/bin/bash: -c: line 43: unexpected EOF while looking for matching `''
```
