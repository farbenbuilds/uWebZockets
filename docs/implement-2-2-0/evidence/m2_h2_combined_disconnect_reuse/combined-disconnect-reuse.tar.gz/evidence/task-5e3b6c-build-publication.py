import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path, PurePosixPath


def sha(data):
    return hashlib.sha256(data).hexdigest()


def add(members, name, data):
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or name in members:
        raise ValueError('Unsafe or duplicate member: ' + name)
    data.decode('utf-8')
    members[name] = data


def inherit(members):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_combined_file_early/combined-file-early.tar.gz')
    if sha(archive.read_bytes()) != '083ade9427d90865f9006349c62d9fdfea90613efd82706c477dde6089b7d8cb':
        raise ValueError('Baseline archive differs')
    with tarfile.open(archive, 'r:gz') as tf:
        inventory = json.loads(tf.extractfile('INVENTORY.json').read())
        for member in tf.getmembers():
            inherit_member(members, tf, member, inventory)


def inherit_member(members, tf, member, inventory):
    if member.name == 'INVENTORY.json':
        return
    if not member.isfile():
        raise ValueError('Nonregular baseline member')
    data = tf.extractfile(member).read()
    row = inventory[member.name]
    if len(data) != row['size'] or sha(data) != row['sha256']:
        raise ValueError('Baseline member differs')
    if member.name.startswith('reference/'):
        add(members, member.name, data)
    if member.name.startswith('source/current/'):
        add(members, member.name.replace('source/current/', 'history/b6b-source/', 1), data)


def collect(members, source, root):
    for path in sorted(source.glob('*.py')):
        add(members, 'source/current/' + path.name, path.read_bytes())
    for path in sorted((source / 'evidence/b6c').rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink evidence')
        if path.is_file():
            add(members, 'raw/b6c/' + str(path.relative_to(source / 'evidence/b6c')), path.read_bytes())
    names = ('task-5e3b6c-brief.md', 'task-5e3b6c-resume-brief.md', 'task-5e3b6c-report.md',
             'task-5e3b6c-review-brief.md', 'task-5e3b6c-review-report.md', 'task-5e3b6c-review-source.diff',
             'task-5e3b6c-root-final-audit.json', 'task-5e3b6c-root-resume-restoration.json',
             'task-5e3b6c-root-full-source-restoration.json', 'task-5e3b6c-root-publication-resume.json',
             'task-5e3b6c-build-publication.py', 'task-5e3b6c-builder-history.json',
             'task-5e3b-release-addendum.md', 'task-5e3b-cases-pending-brief.md',
             'task-5e3b-input-audit.json', 'task-5e-combined-architecture.md', 'task-5e-barrier-source-handoff.md')
    for name in names:
        add(members, 'evidence/' + name, (root / name).read_bytes())
    for name in ('expectations.py', 'lifecycle_cases.py', 'strict_close.py'):
        add(members, 'reference/lifecycle-runtime-v2/' + name,
            (Path('/tmp/uwz-task5c3-runtime-v2') / name).read_bytes())


def write_archive(path, members):
    inventory = {name: {'size': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())}
    add(members, 'INVENTORY.json', (json.dumps(inventory, indent=2) + '\n').encode())
    with path.open('wb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as zipped:
            write_tar(zipped, members)
    with tarfile.open(path, 'r:gz') as tf:
        recovered = {member.name: tf.extractfile(member).read() for member in tf if member.isfile()}
    if recovered != members:
        raise ValueError('Reopened archive differs')
    return inventory


def write_tar(zipped, members):
    with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as tf:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = 0
            tf.addfile(info, io.BytesIO(data))


def main():
    root = Path('.superpowers/sdd/h2_streaming_plan')
    source = Path('.uwz-work/evidence/h2-streaming/integration-owned/combined-cases')
    audit = json.loads((root / 'task-5e3b6c-root-final-audit.json').read_text())
    current = {p.name: sha(p.read_bytes()) for p in source.glob('*.py')}
    if current != audit['current_source_sha256']:
        raise ValueError('Approved source differs')
    members = {}
    inherit(members)
    collect(members, source, root)
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_combined_disconnect_reuse')
    archive = folder / 'combined-disconnect-reuse.tar.gz'
    inventory = write_archive(archive, members)
    manifest = {
        'scope': 'Two reviewed combined HTTP/2 disconnect/reuse source schedules; pure-codec only',
        'base_commit': audit['base_commit'], 'archive': archive.name, 'archive_bytes': archive.stat().st_size,
        'archive_sha256': sha(archive.read_bytes()), 'safe_regular_text_members': len(members),
        'inventory_entries': len(inventory), 'current_source_files': current,
        'added_files': audit['added'], 'changed_files': audit['changed'], 'unchanged_b6b_modules': 23,
        'current_normal_optimized_commands': 40, 'all_commands_after_last_source_edit': True,
        'preceding_matrix_commands_retained': 40, 'current_ast_inert_import_checked_files': 33,
        'implemented_source_case_count': 38, 'unsupported_case_count': 2,
        'new_cases_J_C_R': {'disconnect': [25, 24, 64], 'reuse': [389, 389, 288]},
        'new_case_connections': {'disconnect': 2, 'reuse': 1}, 'new_body_records': 11,
        'disconnect_primary_stream': 3, 'replacement_recovery_stream': 17,
        'reuse_uploads': 9, 'reuse_expired_controls_each': 36,
        'positive_executions_per_new_suite_mode': 4, 'postimplementation_synthetic_controls_per_mode': 41,
        'canonical_earned_connection_replenishment': True,
        'initial_red_scope': 'Unsupported selection rejection before serialization only',
        'missing_historical_command_receipts': ['initial-red', 'attempt-1', 'attempt-2'],
        'preserved_pretransfer_history_entries': 67,
        'source_review': 'Spec compliance and task quality approved, no actionable findings',
        'immutable_retained_identity_rows_checked': 119, 'immutable_unique_identity_entries_checked': 114,
        'immutable_unique_file_paths_checked': 113, 'codec_files_checked': 42,
        'synthetic_model_derived_records_and_transport_facts': True, 'native_executed': False,
        'post_deinit_compared': False, 'combined_all40_executed': False, 'parent_all40_complete': False,
        'milestone_complete': False,
        'remaining': ['Active and idle shutdown schedules', 'default/aggregate/strict-close/owned-runner/runtime closure',
                      'sequential two-child native acceptance', 'full project/platform/compliance gates and production source adoption'],
    }
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = {'archive_sha256': manifest['archive_sha256'], 'archive_bytes': manifest['archive_bytes'],
              'regular_members': len(members), 'inventory_entries': len(inventory), 'current_modules': len(current),
              'all_reopened_member_bytes_exact': True, 'native_executed': False}
    (root / 'task-5e3b6c-root-archive-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
