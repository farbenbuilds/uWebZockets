# Task5e3b6c: disconnect replacement and body-slot reuse

Released after B6b source/publication review and immediate push of commit
738dbe140731cf32b8c7a552e906988622dfffcd. Accepted31-module map is
docs/implement-2-2-0/evidence/m2_h2_combined_file_early/manifest.json and
task-5e3b6b-root-final-audit.json; committed bytes/push are verified by
task-5e3b6b-root-commit-audit.json. Accepted36/40 source cases, no native acceptance.
Read task-5e3b-release-addendum.md and original cases brief.
All40/default/aggregate/native/full milestones remain required. Own concrete
lifecycle schedules/tests, minimal actual-used adapter/selection/import changes,
evidence/b6c and task-5e3b6c-report.md. Exact unsupported4->2 assertions with all
rejection loops retained and truthful38-case description are authorized. Root
owns delivery/Git; you are not alone, no reverts/agents/external model CLI.

Source-only authority /tmp/uwz-task5c3-runtime-v2/lifecycle_cases.py and
strict_close.py is authenticated in task-5e3b-input-audit.json. Current model/
catalogue/fixture supersede legacy counter aliases. Never execute old lifecycle/
live/strict-close entrypoints or native constructors/operations.

| Case | Heads J | Small C | Request flow R | Connections |
| --- | ---: | ---: | ---: | ---: |
| disconnect | 25 | 24 | 64 | 2 |
| reuse | 389 | 389 | 288 | 1 |

Eleven new records, all untouched records/shared synthetic app/final67+metrics,
exact caller order and two independent connection ledgers remain mandatory.

Disconnect: initial health, primary declared32 exact model metadata, send32
without END, one accepted7/paused preclose status on original connection. Finish
canonical clean_disconnect transport policy using strictly supplied close facts:
method ssl_unwrap,tls_shutdown success,tcp_eof true,trailing_bytes0,close normal.
No real TLS/socket/close execution is released. Before replacement, require all
prior auxiliary records retired, complete parser and canonical transport terminal.

Use wire.begin_termination/finish_termination with their actual supported phase
and typed record; no fabricated END/reset or direct state clearing. Share the
same output-stage case object and request-credit case object across two fresh
protocol/connection states. output_stage.new_stage forbids replacement before
transport_finished and enforces the exact same case/whole deadline pair. Keep
independent parser/request/response debt: no cross-connection credit reuse.
An explicit caller-owned replacement hook/context seam must add those invariants
and preserve existing single-connection APIs; no generic continuation framework.

Replacement must be distinct with supplied owned/TLS1.3/h2 facts. Initial health,
one peer_closed/cancel1/inactive old-record status, then both expired controls.
Each control has old status before/after and only its stale counter increments.
Start recovery, first7 noEND, active7 status; repeat both expired controls, now
with old and active-recovery status before/after each action, proving recovery
unchanged. Send remaining25+END and validate recovery; final old status and end
health. Existing source lines107..190 show exact ordering. Combined stream IDs
are original health1/primary3; replacement health1 and recovery17 after preceding
status/control requests. Bind from actual order. R32+32=64, not accepted39.

Reuse: initialhealth then nine exact model tags reuse_0..reuse_8. Each declares32,
sends first7 noEND and observes active7. For each previous tag and each resume/
cancel, read old and current status, issue expired old control, read old and
current again; old changes only the one stale counter, current stays identical.
Then send remaining25+END and validate completed current record. After all nine,
read all nine final statuses, then endhealth. Final stale counters per operation
are8-i for tag i,36 operations of each kind. Preserve360 stale-control/status
heads,9 upload heads,9 active checkpoints,9 final statuses and2health=389.
Hash rolling evidence/counters rather than retaining the control/frame history.
No invented public BodyToken generation field; actual fixture controls are tags.

Before implementation retain real serialized initial tests/RED exact scope and
all intermediates. Independently decode request metadata/multiplicity/IDs/DATA/
END/payload/hash, all finite barriers/control ordering, transport/replacement
facts and no post-original-close observation, case-shared counters/deadlines,
independent debt, stale/active isolation and11 persistent records. Supplied close/
TLS/app records are synthetic input, not native close/ownership/callback proof.
Target negatives at these invariants and qualify sensitivity controls.

After final edits run relevant exact pinned Python -B -S normal/O checks with
raw commands/stdout/stderr/exits, changed-seam regressions, all-module guards/
AST and actual silent/inert empty/foreign-argv rejecting imports. Snapshot/hash
every module against released B6b. No authored classes/custom exceptions/assert
proof/hidden mutable globals/dead code/deep nesting. Use prescribed graphify
prefix before first source search/read and exact ordered42codec/default-json
aggregate recipe; distinguish retained from resolved unique identity counts.

No model/core/fixture/product/dependency/capacity/budget/deadline changes,
native/build/socket/SSLContext/TLS-close/clock/process ownership/transfer/fault/
descriptor/kernel/cancel/schedule/race/panic/leak experiments, old entrypoints,
Git/public changes or other agents. Pure in-memory public codecs and supplied
transport facts only. Full report records exact contracts/APIs/files/commands/
raw/history/identities/self-review/remaining facts; Root reviews independently.
