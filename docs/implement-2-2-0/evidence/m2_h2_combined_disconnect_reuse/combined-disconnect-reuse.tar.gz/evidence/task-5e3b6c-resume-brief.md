# Task5e3b6c continuation after the paused session

Read task-5e3b6c-brief.md first: it remains the requirements, including exact
values and scope. This addendum transfers the preserved implementation to a
replacement owner because the paused worker handle is authoritatively missing.
The accepted branch is still 738dbe140731cf32b8c7a552e906988622dfffcd,
with 36 accepted source schedules. No B6c acceptance has occurred.

Continue the current 33 modules in
`.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/`, rather
than copying the accepted baseline over them. The two new modules are
`lifecycle_cases.py` and `test_lifecycle.py`; the previous owner also changed
the actual adapter and selection seams. Root preserved the entire current
module set and B6c history under `task-5e3b6c-resume-source/` before transfer.
Read `task-5e3b6c-root-resume-restoration.json` for the exact current hashes,
changed-module list, restored input identities, and qualifications.

The session reset removed the temporary inputs. Root restored exact source
bytes from authenticated committed archives; no binaries, builds, native runs,
package installation, or network fetch were involved. The complete historical
candidate tree and libxev override are not needed for this task and have not
been restored. The four required candidate reference files, immutable model,
core, fixture, runtime references, and pinned codecs are available and checked.

Preserve `evidence/b6c/initial-red.*`, `initial-test.py`, all five attempted
source/test snapshots and their raw outcomes. The first four attempt exits
are 1; attempt 5 is 0. These are historical results, not proof for later edits.
Do not recreate their initial RED or strengthen its claimed scope. The prior
worker reported both positive serialized schedules passing, including recovery
stream 17 and all 36 expired operations of each kind. Confirm the current
implementation before finishing focused negatives and the final normal/-O
regression/import/AST/guard proof, source snapshot, identities, and report.

Pay particular attention to the adapter's connection-response replenishment
added for reuse's many small replies: it must use the existing canonical
`wire.new_grants`/`wire.grant` replenish seam and only earned per-connection
response DATA credit. No direct ledger mutation, extra heads, cross-connection
credit borrowing, weaker bounds, or core/model changes are authorized.

Own only this B6c implementation/test seam, its B6c evidence, and
`task-5e3b6c-report.md`. You are not alone in the workspace. Do not revert
others' edits. No subagents, external model CLI, public documentation, Git
changes, native/probe execution, or other case implementation. Root owns
independent review, publication, commit, and immediate push. Keep the original
source-only exclusions and full all40/runtime/native/adoption/milestone scope.
Read the relevant project/role instructions and narrow skills; their broad
native matrices do not release execution forbidden by this task.

Return only status, report path, a one-line verification summary, and concerns.
Write full APIs, exact commands and raw results, RED/history qualifications,
source identities, final module hashes, self-review, and remaining facts to
the report. Do not call supplied TLS/EOF/app records native evidence.

Subsequent Root metadata update: the complete historical candidate and libxev
source trees have also been restored without changing the four existing
reference files. See task-5e3b6c-root-full-source-restoration.json; every file
hash matches the authenticated runtime-v5 manifest. The earlier partial
restoration audit remains an accurate receipt for its stage. This adds no
native/binary execution release and changes none of your required inputs.
