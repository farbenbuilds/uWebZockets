"""C8 fixed-root preflight and separately authorized compiler replay only."""
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import build_inputs as b
import native_metadata as n
import runtime_closure as r


def locations():
    root = Path('/workspaces/uWebZockets')
    return root, root / '.uwz-work/evidence/h2-streaming/native_runtime_builds', Path('/tmp/uwz-h2-native-c8-fix1'), Path('/tmp/uwz-h2-native-rehydration-c7')


def authorities(root):
    base = root / 'docs/implement-2-2-0/evidence'
    specs = {
        'fixture':('m2_h2_combined_fixture/combined-fixture.tar.gz', 'c731e84571477286905ed9116fe8f3e6d820d492e6696fb3382947def8cb38c9'),
        'generated':('m2_h2_metadata_live/metadata-live.tar.gz', 'a08dbf448de76b3642816b0eed9388b59d83356b0d3d1fc8a7025b3718ec7d59'),
        'source':('m2_h2_native_rehydration/native-rehydration.tar.gz', '492906b1d077aa494943cdc989f28f2c91a3633a438684176cbcd7d75ea8fa07'),
        'native':('m2_h2_native_active/native-active.tar.gz', '6fda8cfaac4b8c866ff352848c12397a9775a7bd09397f1db7c9740707c50b14'),
    }
    return {key:(base / name, b.archive_index(base / name, pin)) for key,(name,pin) in specs.items()}


def read_member(archives, key, name):
    path, inventory = archives[key]
    return b.member_bytes(path, inventory, name)


def receipts(archives):
    result = {}
    pins = {'debug':'c93072f4cbb2ecff1448f368069be6570530db95f536b17e7a077488253e8075', 'release':'9bf3edbe0c120f0ef0f5c2c82fd6a4caa67d10e19c57d6770a8f178d07842e59'}
    for mode,pin in pins.items():
        data = read_member(archives, 'fixture', 'builds/uwz-task5e2-Fix1Final2/' + mode + '-receipt.json')
        r.require(b.sha(data) == pin, 'Receipt hash differs')
        result[mode] = json.loads(data)
    return result


def source_exports(archives, sources):
    reference = json.loads(read_member(archives, 'source', 'EXPORT_REFERENCES.json'))
    result = {}
    for label,count,total,aggregate in [('candidate',1031,103051479,'fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de'), ('libxev',93,1347665,'4ce6e5ad1a0ae954352ea1e8890cc82c2a57509102c4eaa3cd434735613df6f9')]:
        rows = reference[label]['files']
        mapping = {row['path']:row for row in rows}
        r.require(len(mapping) == count and sum(row['bytes'] for row in rows) == total, 'Export counts differ')
        r.require(b.sha(json.dumps([(row['path'],row['sha256']) for row in rows]).encode()) == aggregate, 'Export aggregate differs')
        result[label] = b.exact_tree(sources / label, mapping, readonly=True)
    return result


def runtime_sources(root, archives, historical):
    files = {}
    native = root / '.uwz-work/evidence/h2-streaming/combined-native'
    combined = root / '.uwz-work/evidence/h2-streaming/integration-owned/combined-cases'
    inventory = archives['native'][1]
    names = [name for name in inventory if name.startswith('source/current/')]
    r.require(len(names) == 7, 'Native source count differs')
    pairs = [(native / Path(name).name,name) for name in names]
    canonical = [name for name in inventory if name.startswith('reference/combined/') and name.endswith('.py') and not name.endswith('/coordinator.py')]
    r.require(len(canonical) == 45, 'Canonical module count differs')
    pairs += [(combined / Path(name).name,name) for name in canonical]
    pairs += [(combined / 'coordinator.py','source/canonical/coordinator.py')]
    for path,name in pairs:
        data = read_member(archives, 'native', name)
        r.require(path.read_bytes() == data, 'Current source differs: ' + str(path))
        files[str(path)] = r.file_identity(path)
    for path,pin in historical['inputs'].items():
        if not path.startswith(('/home/codespace/.python/current/', '/lib/', '/lib64/', '/opt/conda/')):
            continue
        identity = r.file_identity(path)
        r.require(identity['sha256'] == pin, 'Historical runtime changed: ' + path)
        files[path] = identity
        files[identity['resolved']] = r.file_identity(identity['resolved'])
    codecs = historical['trees']['/tmp/uwz-h2-client-tooling/packages']
    for name,pin in codecs.items():
        path = Path('/tmp/uwz-h2-client-tooling/packages') / b.safe_name(name)
        identity = r.file_identity(path)
        r.require(identity['sha256'] == pin, 'Codec identity changed')
        files[str(path)] = identity
    r.require(len(codecs) == 42, 'Codec count differs')
    authority = root / '.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/coordinator-a/immutable-inputs.json'
    current = json.loads(authority.read_bytes())
    for row in current['identities']:
        path = Path(row['path'])
        path = path if path.is_absolute() else root / path
        identity = r.file_identity(path)
        r.require(identity['sha256'] == row['sha256'] and identity['bytes'] == row['bytes'], 'Pinned closure changed')
        files[str(path)] = identity
        files[identity['resolved']] = r.file_identity(identity['resolved'])
    r.require(b.sha(json.dumps(current['codec_files']).encode()) == current['codec_digest'], 'Ordered codecs changed')
    return files, current['codec_files'], pairs


def metadata_phase(packet, files, compiler):
    for path in packet.glob('*.py'):
        files[str(path)] = r.file_identity(path)
    for name in ('bootstrap-data.sha256','metadata-tools.sha256'):
        for line in (packet / name).read_text().splitlines():
            pin,path = line.split('  ',1)
            identity = r.file_identity(path)
            r.require(identity['sha256'] == pin, 'Bootstrap metadata changed')
            files[path] = identity
    tools = ['/usr/bin/readelf', '/usr/bin/sha256sum', '/usr/bin/jq', '/usr/bin/tar', '/usr/bin/dash']
    elfs = [path for path in files if re.search(r'\.so(?:\.[0-9]+)*$', path)]
    elfs += [sys.executable, '/opt/conda/bin/openssl', compiler] + tools
    metadata = n.closure(elfs)
    for path,entry in metadata.items():
        files[path] = entry['identity']
    for path in r.mapped_files(Path('/proc/self/maps').read_text()):
        resolved = str(Path(path).resolve())
        r.require(resolved in files or path in files, 'Unknown bootstrap mapping: ' + path)
        files[path] = r.file_identity(path)
    before = Path('/proc/self/maps').read_text()
    previous,guard = r.install_guard(files, files[sys.executable], metadata)
    try:
        observed_before = r.loaded_origins(files)
        __import__('ssl')
        after = Path('/proc/self/maps').read_text()
        observed_after = r.loaded_origins(files)
        mappings = r.check_mappings(files, after)
    finally:
        sys.meta_path[:] = previous
    config = Path('/opt/conda/ssl/openssl.cnf').read_text()
    r.require(not any(line.strip().startswith('.include') for line in config.splitlines()), 'External OpenSSL config include')
    r.require(os.environ.get('OPENSSL_CONF') == '/opt/conda/ssl/openssl.cnf' and os.environ.get('OPENSSL_MODULES') == '/tmp/uwz-h2-native-c8-fix1/empty-providers', 'OpenSSL startup controls differ')
    return dict(elf=metadata, loaded_before=observed_before, loaded_after=observed_after, mappings=mappings,
                interpreter=files[sys.executable], python_flags=['-B','-S'], effective_flags=str(sys.flags), import_roots=list(sys.path), bytecode_absences=r.eligible_bytecode(files),
                mappings_before=r.check_mappings(files,before), ordered_environment={'OPENSSL_CONF':'/opt/conda/ssl/openssl.cnf', 'OPENSSL_MODULES':'/tmp/uwz-h2-native-c8-fix1/empty-providers'},
                providers='Only built-in default; external provider directory must remain empty; no SSLContext constructed',
                limits=['No protection against concurrent file replacement between check and loader open', 'Kernel, CPU, vDSO and anonymous executable mappings are outside file identity proof', 'Future host/provider/run source modules must be added before their imports', 'Initial metadata discovery precedes reusable guard installation; shell bootstrap authenticates interpreter/std-library/selected libraries first'])


def preflight():
    root,packet,output,sources = locations()
    b.fresh(output / 'inputs')
    archives = authorities(root)
    recipe = receipts(archives)
    exports = source_exports(archives,sources)
    historical = json.loads((packet / 'historical-manifest-v5.json').read_bytes())
    r.require(b.sha((packet / 'historical-manifest-v5.json').read_bytes()) == 'aab3dda65e16b0475ccb59de28028a2d324ee81c7c05dc6c48daf909f6ae9890', 'Runtime authority changed')
    sdk = next(name for name in historical['trees'] if name.startswith('/nix/store/'))
    sdk_empty = ['std/compress/flate/testdata','std/compress/flate/testdata/fuzz','std/compress/lzma/testdata','std/compress/testdata','std/compress/xz/testdata','std/tar/testdata','std/tz']
    sdk_files = b.exact_tree(Path(sdk), historical['trees'][sdk], extra_dirs=sdk_empty)
    zslay = next(name for name in historical['trees'] if '/zig-pkg/zslay-' in name)
    zslay_files = b.exact_tree(Path(zslay),historical['trees'][zslay])
    r.require(len(sdk_files) == 19542 and len(zslay_files) == 14, 'SDK/zslay count differs')
    compiler = recipe['debug']['argv'][0]
    direct = {}
    for path,pin in recipe['debug']['inputs_before'].items():
        if path.startswith('/tmp/') or path.endswith('c-native.zig'):
            continue
        identity = r.file_identity(path)
        r.require(identity['sha256'] == pin, 'Build input changed')
        direct[path] = identity
    r.require(direct[compiler]['sha256'] == '2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c', 'Compiler changed')
    fixture = {Path(name).name:read_member(archives,'fixture',name) for name in archives['fixture'][1] if name.startswith('source/fixture/')}
    r.require(set(fixture) == set(recipe['debug']['fixture_before']) and len(fixture) == 25, 'Fixture inventory differs')
    r.require(all(b.sha(data) == recipe['debug']['fixture_before'][name] for name,data in fixture.items()), 'Fixture receipt differs')
    generated = read_member(archives,'generated','inputs/c-native.zig')
    r.require(len(generated) == 1693033 and b.sha(generated) == 'd9ada6e22902d9aae00bec473ce6942376a8f569f481b7b544b4395beb53d536', 'Generated C changed')
    files,codecs,pairs = runtime_sources(root,archives,historical)
    metadata = metadata_phase(packet, files, compiler)
    authority_files = {str(path):r.file_identity(path) for path,inventory in archives.values()}
    authority_files.update({str(packet / name):r.file_identity(packet / name) for name in ('historical-manifest-v5.json','bootstrap.sha256','metadata-tools.sha256','bootstrap-data.sha256','run_control.sh')})
    b.stage_sources(output / 'inputs',fixture,generated)
    r.require((output / 'empty-providers').is_dir() and not list((output / 'empty-providers').iterdir()), 'Provider directory differs')
    remaps = {mode:b.remap_recipe(row,sources,output / 'inputs',output / mode) for mode,row in recipe.items()}
    result = dict(files=files, ordered_codecs=codecs, runtime=metadata, exports=exports, sdk=sdk_files, sdk_root=sdk, sdk_empty=sdk_empty, zslay=zslay_files, zslay_root=zslay,
                  direct=direct, authorities=authority_files, fixtures={name:r.file_identity(output / 'inputs/fixture' / name) for name in fixture}, generated=r.file_identity(output / 'inputs/c-native.zig'),
                  recipes=recipe, remaps=remaps, cwd=str(sources / 'candidate'), target_executed=False)
    b.write_json(packet / 'preflight-fix1.json',result)
    print('Preflight passed: runtime/bootstrap/import/ELF closure; candidate 1031; libxev 93; SDK 19542; zslay 14; fixture 25; exact Debug/ReleaseSafe argv')


def verify_inputs(manifest):
    _,packet,output,sources = locations()
    for key in ('files','direct','sdk','zslay','fixtures','authorities'):
        for path,identity in manifest[key].items():
            r.verify_file(identity['path'],identity)
    r.verify_file(manifest['generated']['path'],manifest['generated'])
    for label,rows in manifest['exports'].items():
        b.exact_tree(sources / label, rows, readonly=True)
    b.exact_tree(Path(manifest['sdk_root']),manifest['sdk'],extra_dirs=manifest['sdk_empty'])
    b.exact_tree(Path(manifest['zslay_root']),manifest['zslay'])
    r.require(not list((output / 'empty-providers').iterdir()), 'Unknown OpenSSL provider')
    r.require(all(not Path(path).exists() and not Path(path).is_symlink() for path in manifest['runtime']['bytecode_absences']), 'New eligible bytecode appeared')


def build(mode):
    _,packet,output,sources = locations()
    manifest = json.loads((packet / 'preflight-fix1.json').read_bytes())
    verify_inputs(manifest)
    target = output / mode
    b.fresh(target)
    argv,remap = b.remap_recipe(manifest['recipes'][mode],sources,output / 'inputs',target)
    r.require([argv,remap] == manifest['remaps'][mode], 'Remapped recipe changed')
    target.mkdir(mode=0o700)
    environment = {'LC_ALL':'C.UTF-8', 'PATH':'/usr/bin:/bin', 'TMPDIR':str(target)}
    b.write_json(target / 'command.json',dict(argv=argv,cwd=manifest['cwd'],environment=environment,remaps=remap,preflight_sha256=b.sha((packet / 'preflight-fix1.json').read_bytes()), target_executed=False))
    with (target / 'stdout').open('xb') as stdout, (target / 'stderr').open('xb') as stderr:
        result = subprocess.run(argv,cwd=manifest['cwd'],env=environment,stdout=stdout,stderr=stderr,check=False)
    (target / 'exit').write_text(str(result.returncode) + '\n')
    verify_inputs(manifest)
    receipt = dict(status=result.returncode, inputs_preserved=True, stdout=r.file_identity(target / 'stdout'), stderr=r.file_identity(target / 'stderr'), target_executed=False)
    if (target / 'profile').is_file():
        receipt['binary'] = r.file_identity(target / 'profile')
    b.write_json(target / 'receipt.json',receipt)
    b.write_json(packet / (mode + '-fix1-result.json'),receipt)
    r.require(result.returncode == 0, 'Compiler failed; see ' + str(target / 'stderr'))
    print('Fresh',mode,'compiler status',result.returncode,'binary',receipt['binary']['sha256'])


def main(argv):
    if argv == ['--preflight']:
        preflight()
        return 0
    if len(argv) == 2 and argv[0] == '--build' and argv[1] in ('debug','release'):
        build(argv[1])
        return 0
    return 2


if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
