"""Install effect/import guards in a foreign cwd before project imports."""
import builtins
from functools import partial
import importlib.machinery
import importlib.util
import os
from pathlib import Path
import runpy
import sys


def require(condition, message):
    if not condition:
        raise ValueError(message)


def deny_effect(event, args):
    rejected = ('subprocess.Popen','os.system','os.posix_spawn','os.mkdir','os.remove','os.rename','os.chmod','os.link','os.symlink','os.chdir','socket.__new__','socket.bind','socket.connect')
    require(event not in rejected, 'Inert operation attempted: ' + event)
    if event != 'open':
        return
    mode,flags = args[1],args[2]
    require(mode is None or not any(c in mode for c in 'wax+'), 'Inert write attempted')
    require(not flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND), 'Inert descriptor write attempted')


def guarded_import(packet, observed, original, name, globals=None, locals=None, fromlist=(), level=0):
    if name in ('build_inputs','native_metadata','runtime_closure'):
        spec = importlib.machinery.PathFinder.find_spec(name)
        require(spec is not None and spec.origin == str(packet / (name + '.py')), 'Foreign import origin')
        observed.append(name)
    return original(name, globals, locals, fromlist, level)


def main():
    packet = Path('/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native_runtime_builds')
    os.chdir('/tmp/uwz-h2-native-c8-fix1')
    require(Path.cwd() == Path('/tmp/uwz-h2-native-c8-fix1'), 'Foreign cwd proof must run in exclusive tmp root')
    require(not any(name in sys.modules for name in ('build_inputs','native_metadata','runtime_closure')), 'Project imported before guard')
    observed = []
    sys.addaudithook(deny_effect)
    original = builtins.__import__
    builtins.__import__ = partial(guarded_import,packet,observed,original)
    try:
        spec = importlib.util.spec_from_file_location('c8_inspector_inert',packet / 'inspect_outputs.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        require(module.main(['--invalid']) == 2, 'Rejected CLI changed status')
        sys.argv = [str(packet / 'inspect_outputs.py'),'--invalid']
        try:
            runpy.run_path(str(packet / 'inspect_outputs.py'),run_name='__main__')
        except SystemExit as error:
            require(error.code == 2,'Direct CLI changed status')
        else:
            raise ValueError('Direct CLI failed to reject')
    finally:
        builtins.__import__ = original
    require(set(observed) == {'build_inputs','native_metadata','runtime_closure'}, 'Project imports not exercised under guards')
    print('PASS foreign-cwd inert import and rejected CLI; guards installed before all project imports; optimize=' + str(sys.flags.optimize))


if __name__ == '__main__':
    main()
