"""Authenticated archive selections and exact historical recipe remapping."""
import hashlib
import json
from pathlib import Path
import stat
import tarfile
import runtime_closure as r


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe_name(name):
    r.require(isinstance(name, str) and bool(name), 'Empty member')
    r.require(not name.startswith('/') and '\\' not in name, 'Unsafe member')
    r.require(all(c not in ('', '.', '..') and c.lower() != '.git' and ':' not in c for c in name.split('/')), 'Unsafe component')
    r.require(not any(ord(c) < 32 or ord(c) == 127 for c in name), 'Control in member')
    return name


def archive_index(path, expected):
    r.require(sha(path.read_bytes()) == expected, 'Archive digest changed: ' + str(path))
    with tarfile.open(path, 'r:gz') as archive:
        members = archive.getmembers()
        names = [safe_name(m.name) for m in members]
        r.require(len(names) == len(set(names)) and len(names) <= 30000, 'Duplicate/unbounded archive')
        r.require(all(m.isfile() and not m.issparse() and 0 <= m.size <= 200000000 for m in members), 'Unsafe archive type/size')
        name_set = set(names)
        r.require(not any('/'.join(n.split('/')[:i]) in name_set for n in names for i in range(1, len(n.split('/')))), 'Member parent collision')
        label = 'INVENTORY.json' if 'INVENTORY.json' in names else 'inventory.json'
        inventory = json.loads(archive.extractfile(label).read())
        if set(inventory) == {'scope','files'}:
            rows = inventory['files']
            inventory = {row['path']:{'bytes':row['bytes'],'sha256':row['sha256']} for row in rows}
            r.require(len(inventory) == len(rows), 'Duplicate inventory row')
        r.require(set(inventory) == set(names) - {label}, 'Inventory path set differs')
        r.require(all(safe_name(n) and inventory[n]['bytes'] == m.size for n,m in zip(names, members) if n != label), 'Inventory size differs')
    return inventory


def member_bytes(path, inventory, name):
    r.require(name in inventory, 'Uninventoried member')
    with tarfile.open(path, 'r:gz') as archive:
        data = archive.extractfile(name).read()
    r.require(sha(data) == inventory[name]['sha256'] and len(data) == inventory[name]['bytes'], 'Member identity differs')
    return data


def write_json(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


def exact_tree(root, mapping, readonly=False):
    expected_dirs = {'.'}
    for name in mapping:
        safe_name(name)
        expected_dirs.update(str(p) for p in Path(name).parents)
    paths = list(root.rglob('*'))
    files = {str(p.relative_to(root)) for p in paths if p.is_file()}
    dirs = {'.'} | {str(p.relative_to(root)) for p in paths if p.is_dir()}
    r.require(files == set(mapping) and dirs == expected_dirs, 'Tree path set differs: ' + str(root))
    r.require(not any(p.is_symlink() for p in paths), 'Tree contains symlink')
    if readonly:
        r.require(all(stat.S_IMODE(p.stat().st_mode) == 0o555 for p in [root] + [p for p in paths if p.is_dir()]), 'Directory mode differs')
        r.require(all(stat.S_IMODE(p.stat().st_mode) == 0o444 for p in paths if p.is_file()), 'File mode differs')
    rows = {}
    for name, value in mapping.items():
        identity = r.file_identity(root / name)
        expected = value['sha256'] if isinstance(value, dict) else value
        r.require(identity['sha256'] == expected, 'Tree bytes changed: ' + str(root / name))
        r.require(not isinstance(value, dict) or identity['bytes'] == value['bytes'], 'Tree size differs')
        rows[name] = identity
    return rows


def fresh(path):
    r.require(path.is_absolute() and not path.exists() and not path.is_symlink(), 'Destination exists/invalid')
    r.require(all(not p.is_symlink() and p.is_dir() for p in path.parents), 'Unsafe ancestor')


def stage_sources(destination, fixture, c_source):
    fresh(destination)
    r.require(len(fixture) == 25, 'Fixture count differs')
    r.require(all(safe_name(n) == n and '/' not in n for n in fixture), 'Fixture path differs')
    destination.mkdir(mode=0o700)
    (destination / 'fixture').mkdir(mode=0o700)
    for name, data in fixture.items():
        (destination / 'fixture' / name).write_bytes(data)
        (destination / 'fixture' / name).chmod(0o444)
    (destination / 'fixture').chmod(0o555)
    (destination / 'c-native.zig').write_bytes(c_source)
    (destination / 'c-native.zig').chmod(0o444)
    destination.chmod(0o555)


def remap_recipe(receipt, source_root, inputs, mode_root):
    r.require(receipt['optimization'] in ('Debug', 'ReleaseSafe') and receipt['exit_status'] == 0, 'Wrong receipt')
    original = receipt['argv']
    mode = 'debug' if receipt['optimization'] == 'Debug' else 'release'
    old = '/tmp/uwz-task5e2-Fix1Final2'
    mapping = {
        '-Mroot=' + old + '/fixture/profile.zig':'-Mroot=' + str(inputs / 'fixture/profile.zig'),
        '-MuWebZockets=/tmp/uwz-task4d-fix1-frozen/src/root.zig':'-MuWebZockets=' + str(source_root / 'candidate/src/root.zig'),
        '-Mc=/workspaces/uWebZockets/.uwz-work/evidence/h1-transport/r2/c-native.zig':'-Mc=' + str(inputs / 'c-native.zig'),
        '-Mxev=/tmp/uwz-task4d-fix1-frozen/src/core/xev.zig':'-Mxev=' + str(source_root / 'candidate/src/core/xev.zig'),
        '-Mxev_impl=/tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig':'-Mxev_impl=' + str(source_root / 'libxev/src/main.zig'),
        old + '/' + mode + '-cache':str(mode_root / 'cache'),
        old + '/' + mode + '-global':str(mode_root / 'global'),
        '-femit-bin=' + old + '/' + mode + '-profile':'-femit-bin=' + str(mode_root / 'profile'),
    }
    r.require(all(original.count(k) == 1 for k in mapping), 'Recipe remap missing/duplicated')
    r.require(receipt['cwd'] == '/tmp/uwz-task4d-fix1-frozen' and original.count('-j2') == 1, 'Recipe cwd/jobs changed')
    return [mapping.get(arg, arg) for arg in original], mapping
