#!/bin/sh
set -eu
packet=/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native_runtime_builds
root=/tmp/uwz-h2-native-c8
name=$1
shift
mkdir "$packet/snapshots/$name"
cp "$packet"/*.py "$packet/run_control.sh" "$packet/snapshots/$name/"
sha256sum "$packet"/*.py "$packet/run_control.sh" > "$packet/snapshots/$name/code.sha256"
sha256sum -c "$packet/snapshots/$name/code.sha256" > "$packet/raw/${name}_source-check.stdout"
export PYTHONDONTWRITEBYTECODE=1
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore "$root/restore-$name.json" > "$packet/raw/${name}_restore.stdout" 2> "$packet/raw/${name}_restore.stderr"
export PYTHONPATH="$packet"
printf '%s\n' "$@" > "$packet/raw/$name.argv"
set +e
/home/codespace/.python/current/bin/python3 -B -S "$@" > "$packet/raw/$name.stdout" 2> "$packet/raw/$name.stderr"
status=$?
set -e
printf '%s\n' "$status" > "$packet/raw/$name.exit"
exit "$status"
