"""Focused functional checks, including a true changed-source RED."""
import io
import json
from pathlib import Path
import sys
import tarfile
import tempfile
import build_inputs as b
import native_metadata as n
import replay_builds as replay
import runtime_closure as r


def rejects(function, *args):
    try:
        function(*args)
    except (ValueError, FileNotFoundError):
        return
    raise ValueError('Expected rejection: ' + function.__name__)


def test_changed_inputs(root):
    for name in ('module.py', 'module.pyc', 'library.so', 'openssl', 'openssl.cnf'):
        path = root / name
        path.write_bytes(b'approved')
        identity = r.file_identity(path)
        r.verify_file(path, identity)
        path.write_bytes(b'changed')
        rejects(r.verify_file, path, identity)
    rejects(r.file_identity, Path('relative'))
    rejects(r.file_identity, root / 'absent')


def test_import_origin(root):
    source = root / 'lazy.py'
    cached = root / 'lazy.pyc'
    source.write_bytes(b'value = 7\n')
    cached.write_bytes(b'approved bytecode')
    files = {str(p):r.file_identity(p) for p in (source, cached)}
    r.authorize_origin(files, str(source), str(cached))
    cached.write_bytes(b'changed bytecode')
    rejects(r.authorize_origin, files, str(source), str(cached))
    rejects(r.authorize_origin, files, str(root / 'unknown.py'))
    source.write_bytes(b'changed source')
    rejects(r.authorize_origin, files, str(source))


def test_mapping(root):
    path = root / 'loaded.so'
    path.write_bytes(b'library')
    files = {str(path):r.file_identity(path)}
    text = '100-200 r-xp 000 00:00 1 ' + str(path) + '\n'
    r.check_mappings(files, text)
    path.write_bytes(b'altered')
    rejects(r.check_mappings, files, text)
    rejects(r.check_mappings, {}, text)
    rejects(r.mapped_files, text.replace('\n', ' (deleted)\n'))


def test_archive_and_paths(root):
    for name in ('../a', '/a', 'a//b', 'a/.Git/HEAD', 'a\\b', 'a\n'):
        rejects(b.safe_name, name)
    path = root / 'unsafe.tar.gz'
    with tarfile.open(path,'w:gz') as archive:
        info = tarfile.TarInfo('link')
        info.type = tarfile.SYMTYPE
        info.linkname = '/outside'
        archive.addfile(info)
    rejects(b.archive_index,path,b.sha(path.read_bytes()))
    rejects(b.fresh,root)
    source = root / 'fixture-tree'
    source.mkdir()
    (source / 'a').write_bytes(b'source')
    mapping = {'a':b.sha(b'source')}
    b.exact_tree(source,mapping)
    (source / 'empty').mkdir()
    rejects(b.exact_tree,source,mapping)


def test_unknown_lazy_import(root):
    (root / 'uwz_unknown.py').write_text('raise RuntimeError("must not execute")\n')
    rejects(r.guard_spec,{},'uwz_unknown',[str(root)])
    r.require('uwz_unknown' not in sys.modules,'Unknown module executed')


def test_inert_controls(root):
    r.require(replay.main([]) == replay.main(['--build','unknown']) == replay.main(['--run']) == 2,'CLI effects on invalid input')
    rejects(n.resolve_needed,root / 'a','../library',[])


def main():
    with tempfile.TemporaryDirectory(prefix='test_', dir='/tmp/uwz-h2-native-c8') as directory:
        root = Path(directory)
        for check in (test_changed_inputs, test_import_origin, test_mapping, test_archive_and_paths, test_unknown_lazy_import, test_inert_controls):
            check(root)
            print('PASS', check.__name__)
    r.require(r.main([]) == r.main(['--execute']) == 2, 'CLI must be inert')
    print('PASS inert CLI')


if __name__ == '__main__':
    main()
