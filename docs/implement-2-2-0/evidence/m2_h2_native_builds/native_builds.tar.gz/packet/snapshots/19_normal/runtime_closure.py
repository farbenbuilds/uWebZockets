"""Explicit file/import/mapping checks; import is inert."""
import hashlib
import importlib.machinery
import importlib.util
from pathlib import Path
import sys
import types
from functools import partial


def require(condition, message):
    if not condition:
        raise ValueError(message)


def file_identity(path):
    path = Path(path)
    require(path.is_absolute() and '..' not in path.parts, 'Bad absolute path')
    require(path.is_file(), 'Missing regular file: ' + str(path))
    data = path.read_bytes()
    return dict(path=str(path), resolved=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def verify_file(path, expected):
    actual = file_identity(path)
    require(actual == expected, 'Changed file identity: ' + str(path))
    return actual


def authorize_origin(files, origin, cached=None):
    require(origin in files, 'Unknown import origin: ' + str(origin))
    verify_file(origin, files[origin])
    if cached is not None and Path(cached).exists():
        require(cached in files, 'Unknown eligible bytecode: ' + cached)
        verify_file(cached, files[cached])
    return origin


def authorize_native(files, dependencies, origin):
    if not origin.endswith('.so') and '.so.' not in origin:
        return
    pending = [str(Path(origin).resolve())]
    checked = set()
    while pending:
        path = pending.pop()
        if path in checked:
            continue
        require(dependencies is not None and path in dependencies, 'Unknown native dependency: ' + path)
        require(path in files, 'Unbound native dependency: ' + path)
        verify_file(path, files[path])
        checked.add(path)
        pending.extend(dependencies[path]['resolved'] + dependencies[path]['interpreters'])


def guard_spec(files, fullname, path=None, target=None, dependencies=None):
    spec = importlib.machinery.BuiltinImporter.find_spec(fullname, path, target)
    if spec is None:
        spec = importlib.machinery.FrozenImporter.find_spec(fullname, path, target)
    if spec is not None:
        return spec
    spec = importlib.machinery.PathFinder.find_spec(fullname, path, target)
    require(spec is not None and spec.origin is not None, 'Unknown import origin: ' + fullname)
    authorize_origin(files, spec.origin, spec.cached)
    authorize_native(files, dependencies, spec.origin)
    return spec


def install_guard(files, interpreter, dependencies):
    verify_file(sys.executable, interpreter)
    require(sys.flags.no_site == 1 and sys.dont_write_bytecode, 'Unsafe Python flags')
    guard = types.ModuleType('uwz_import_guard')
    guard.find_spec = partial(guard_spec, files, dependencies=dependencies)
    previous = tuple(sys.meta_path)
    sys.meta_path[:] = [guard]
    return previous, guard


def loaded_origins(files):
    result = {}
    for name, module in sorted(sys.modules.items()):
        spec = getattr(module, '__spec__', None)
        origin = getattr(spec, 'origin', None)
        if origin in (None, 'built-in', 'frozen'):
            result[name] = dict(origin=origin, authority='interpreter/bootstrap')
            continue
        authorize_origin(files, origin, getattr(spec, 'cached', None))
        result[name] = dict(origin=origin, cached=getattr(spec, 'cached', None))
    return result


def mapped_files(text):
    paths = set()
    for line in text.splitlines():
        fields = line.split(None, 5)
        if len(fields) < 6 or not fields[5].startswith('/'):
            continue
        require(not fields[5].endswith(' (deleted)'), 'Deleted loaded mapping')
        paths.add(fields[5])
    return sorted(paths)


def check_mappings(files, text):
    result = {}
    for path in mapped_files(text):
        require(path in files, 'Unknown loaded mapping: ' + path)
        result[path] = verify_file(path, files[path])
    return result


def before_after(files, before, after):
    require(mapped_files(before) == mapped_files(after), 'Loaded mappings changed')
    require(check_mappings(files, before) == check_mappings(files, after), 'Mapping identity changed')


def main(argv):
    return 2


if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
