"""Authorized metadata discovery; no claim of prior import authorization."""
import json
from pathlib import Path
import replay_builds
import runtime_closure as r


def main():
    paths = r.mapped_files(Path('/proc/self/maps').read_text())
    print(json.dumps({path:r.file_identity(path) for path in paths},indent=2))


if __name__ == '__main__':
    main()
