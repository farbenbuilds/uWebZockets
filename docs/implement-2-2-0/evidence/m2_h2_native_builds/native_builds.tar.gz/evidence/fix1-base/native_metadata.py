"""Read ELF metadata without invoking the inspected executable."""
from pathlib import Path
import re
import subprocess
import runtime_closure as r


def elf_metadata(path):
    with Path(path).open('rb') as stream:
        if stream.read(4) != b'\x7fELF':
            return None
    argv = ['/usr/bin/readelf', '-W', '-l', '-d', str(path)]
    result = subprocess.run(argv, env={'PATH':'/usr/bin:/bin', 'LC_ALL':'C'}, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    r.require(result.returncode == 0, 'readelf failed: ' + str(path))
    text = result.stdout.decode('utf-8')
    needed = re.findall(r'\(NEEDED\).*?\[(.*?)\]', text)
    search = re.findall(r'\((?:RUNPATH|RPATH)\).*?\[(.*?)\]', text)
    loaders = re.findall(r'Requesting program interpreter: (.*?)\]', text)
    return dict(argv=argv, needed=needed, search=search, interpreters=loaders, stdout=text, stderr=result.stderr.decode(), status=0)


def resolve_needed(path, name, search):
    r.require('/' not in name and name not in ('', '.', '..'), 'Unsafe ELF NEEDED')
    origin = str(Path(path).parent)
    directories = [part.replace('${ORIGIN}', origin).replace('$ORIGIN', origin) for row in search for part in row.split(':')]
    directories += ['/lib/x86_64-linux-gnu', '/usr/lib/x86_64-linux-gnu', '/lib64', '/usr/lib64']
    r.require(all(Path(p).is_absolute() and '$' not in p for p in directories), 'Unknown ELF search path')
    matches = [Path(p) / name for p in directories if (Path(p) / name).is_file()]
    r.require(bool(matches), 'Unresolved ELF dependency: ' + name)
    return str(matches[0].resolve())


def closure(paths):
    pending = list(paths)
    result = {}
    while pending:
        path = str(Path(pending.pop()).resolve())
        if path in result:
            continue
        metadata = elf_metadata(path)
        r.require(metadata is not None, 'Expected ELF: ' + path)
        metadata['identity'] = r.file_identity(path)
        metadata['resolved'] = [resolve_needed(path, name, metadata['search']) for name in metadata['needed']]
        result[path] = metadata
        pending.extend(metadata['resolved'] + metadata['interpreters'])
    return result
