import hashlib
import json
import tarfile
from pathlib import Path


def main():
    base = Path('/workspaces/uWebZockets/docs/implement-2-2-0/evidence')
    requests = [('m2_h2_combined_fixture/combined-fixture.tar.gz', ['builds/uwz-task5e2-Fix1Final2/debug-receipt.json', 'builds/uwz-task5e2-Fix1Final2/release-receipt.json']), ('m2_h2_native_rehydration/native-rehydration.tar.gz', ['EXPORT_REFERENCES.json']), ('m2_h2_output_driver/output-driver.tar.gz', ['provenance/manifest-v5.json'])]
    for filename, members in requests:
        path = base / filename
        print('ARCHIVE', filename, hashlib.sha256(path.read_bytes()).hexdigest())
        with tarfile.open(path) as archive:
            print('MEMBERS', [m.name for m in archive if 'SDK' in m.name.upper() or 'zslay' in m.name.lower()])
            for name in members:
                data = archive.extractfile(name).read()
                value = json.loads(data)
                print('MEMBER', name, hashlib.sha256(data).hexdigest(), 'KEYS', list(value))
                if 'receipt' in name:
                    print(json.dumps({k:v for k,v in value.items() if k not in ('source_before', 'source_after', 'fixture_after', 'inputs_after')}, indent=2))
                elif 'EXPORT' in name:
                    print(json.dumps(value, indent=2)[:12000])
                else:
                    print(json.dumps({k:v for k,v in value.items() if k not in ('stdlib', 'python_stdlib_files', 'files')}, indent=2)[:15000])


if __name__ == '__main__':
    main()
