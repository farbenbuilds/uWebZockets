#!/bin/sh
set -eu
packet=/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native_runtime_builds
root=/tmp/uwz-h2-native-c8
name=$1
shift
mkdir "$packet/snapshots/$name"
cp "$packet"/*.py "$packet"/*.sha256 "$packet/run_control.sh" "$packet/snapshots/$name/"
sha256sum "$packet"/*.py "$packet"/*.sha256 "$packet/run_control.sh" > "$packet/snapshots/$name/code.sha256"
sha256sum -c "$packet/snapshots/$name/code.sha256" > "$packet/raw/${name}_source-check.stdout"
sha256sum -c "$packet/bootstrap.sha256" > "$packet/raw/${name}_bootstrap-check.stdout"
sha256sum -c "$packet/metadata-tools.sha256" > "$packet/raw/${name}_metadata-tools-check.stdout"
sha256sum -c "$packet/bootstrap-data.sha256" > "$packet/raw/${name}_bootstrap-data-check.stdout"
test ! -e /etc/ld.so.preload
test ! -e /home/codespace/.python/current/lib/python314.zip
printf '%s\n' 'aa6d5a881925917f4254f518643e5dbb888ba1d163fafe73d1c857b491c69dea  /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py' | sha256sum -c - > "$packet/raw/${name}_restore-source-check.stdout"
export PYTHONDONTWRITEBYTECODE=1
export OPENSSL_CONF=/opt/conda/ssl/openssl.cnf
export OPENSSL_MODULES=/tmp/uwz-h2-native-c8/empty-providers
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore "$root/restore-$name.json" > "$packet/raw/${name}_restore.stdout" 2> "$packet/raw/${name}_restore.stderr"
export PYTHONPATH="$packet"
printf '%s\n' "$@" > "$packet/raw/$name.argv"
set +e
/home/codespace/.python/current/bin/python3 -B -S "$@" > "$packet/raw/$name.stdout" 2> "$packet/raw/$name.stderr"
status=$?
set -e
printf '%s\n' "$status" > "$packet/raw/$name.exit"
exit "$status"
