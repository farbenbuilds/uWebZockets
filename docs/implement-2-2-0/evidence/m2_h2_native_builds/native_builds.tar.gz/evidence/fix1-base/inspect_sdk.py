import json
from pathlib import Path


def main():
    packet = Path(__file__).parent
    authority = json.loads((packet / 'historical-manifest-v5.json').read_bytes())
    for name,mapping in authority['trees'].items():
        if not name.startswith('/nix/store/') and '/zig-pkg/zslay-' not in name:
            continue
        root = Path(name)
        paths = list(root.rglob('*'))
        files = {str(p.relative_to(root)) for p in paths if p.is_file()}
        dirs = {'.'} | {str(p.relative_to(root)) for p in paths if p.is_dir()}
        expected = {'.'} | {str(p) for name in mapping for p in Path(name).parents}
        print(name, 'files',len(files),'expected',len(mapping), 'missing',sorted(set(mapping)-files)[:30], 'extra',sorted(files-set(mapping))[:30], 'extra-dirs',sorted(dirs-expected)[:40], 'missing-dirs',sorted(expected-dirs)[:30], 'symlinks',[str(p) for p in paths if p.is_symlink()][:15])


if __name__ == '__main__':
    main()
