import json
import tarfile
from pathlib import Path


def main():
    base = Path('/workspaces/uWebZockets/docs/implement-2-2-0/evidence')
    for filename, member in [('m2_h2_native_rehydration/native-rehydration.tar.gz','EXPORT_REFERENCES.json'),('m2_h2_output_driver/output-driver.tar.gz','provenance/manifest-v5.json')]:
        with tarfile.open(base/filename) as archive:
            data = json.loads(archive.extractfile(member).read())
            print(filename, [(k, type(v).__name__, len(v) if hasattr(v,'__len__') else v) for k,v in data.items()])
            if 'EXPORT' in member:
                print({k:({s: (len(t),t[:1]) if isinstance(t,list) else t for s,t in v.items()} if isinstance(v,dict) else v) for k,v in data.items()})
            else:
                print('NONPYTHON INPUTS', {k:v for k,v in data['inputs'].items() if '/lib/python3.14/' not in k})
                print('TREES', data['trees'])
    with tarfile.open(base/'m2_h2_combined_fixture/combined-fixture.tar.gz') as archive:
        print('TOP',sorted(set(m.name.split('/')[0] for m in archive)))
    with tarfile.open(base/'m2_h2_metadata_live/metadata-live.tar.gz') as archive:
        print('METADATA CLOSURE NAMES', [m.name for m in archive if 'inventory' in m.name or 'manifest' in m.name or 'zslay' in m.name])


if __name__ == '__main__':
    main()
