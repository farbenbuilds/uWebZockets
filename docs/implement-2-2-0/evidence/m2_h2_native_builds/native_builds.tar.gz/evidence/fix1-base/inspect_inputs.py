import hashlib
import json
import tarfile
from pathlib import Path


def main():
    base = Path('/workspaces/uWebZockets/docs/implement-2-2-0/evidence')
    for folder, filename, prefix in [('m2_h2_combined_fixture', 'combined-fixture.tar.gz', 'builds/'), ('m2_h2_native_rehydration', 'native-rehydration.tar.gz', ''), ('m2_h2_metadata_live', 'metadata-live.tar.gz', 'inputs/'), ('m2_h2_output_driver', 'output-driver.tar.gz', 'provenance/')]:
        path = base / folder / filename
        if not path.exists():
            print('MISSING', path)
            continue
        print('ARCHIVE', path, hashlib.sha256(path.read_bytes()).hexdigest())
        with tarfile.open(path) as archive:
            for member in archive:
                if not member.name.startswith(prefix):
                    continue
                if 'receipt' in member.name and member.name.endswith('.json') or member.name.endswith('manifest-v5.json'):
                    print(member.name, archive.extractfile(member).read().decode()[:25000])
                elif filename == 'native-rehydration.tar.gz':
                    print(member.name)


if __name__ == '__main__':
    main()
