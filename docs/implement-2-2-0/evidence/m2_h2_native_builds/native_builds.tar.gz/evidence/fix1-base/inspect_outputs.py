"""Post-build ELF metadata only; target executables are never invoked."""
import json
from pathlib import Path
import sys
import build_inputs as b
import native_metadata as n
import runtime_closure as r


def main(argv):
    if argv != ['--inspect']:
        return 2
    packet = Path(__file__).parent
    output = Path('/tmp/uwz-h2-native-c8')
    manifest = json.loads((packet / 'preflight.json').read_bytes())
    result = dict(preflight=r.file_identity(packet / 'preflight.json'), source=r.file_identity(Path(__file__).resolve()), target_executed=False, modes={})
    for mode in ('debug','release'):
        command = json.loads((output / mode / 'command.json').read_bytes())
        r.require(command['preflight_sha256'] == result['preflight']['sha256'], 'Build preflight changed')
        r.require(command['argv'] == manifest['remaps'][mode][0] and command['cwd'] == manifest['cwd'], 'Build recipe differs')
        receipt = json.loads((output / mode / 'receipt.json').read_bytes())
        r.require(receipt['status'] == 0 and receipt['inputs_preserved'], 'Incomplete build receipt')
        binary = receipt['binary']
        r.verify_file(binary['path'],binary)
        graph = n.closure([binary['path']])
        for path,entry in graph.items():
            if path == binary['resolved']:
                continue
            r.require(path in manifest['files'], 'Unknown target native input: ' + path)
            r.verify_file(path,manifest['files'][path])
        aliases = [alias for entry in graph.values() for alias in entry['interpreters']]
        for alias in aliases:
            r.require(alias in manifest['files'], 'Unknown target loader alias')
            r.verify_file(alias,manifest['files'][alias])
        result['modes'][mode] = dict(binary=binary, elf=graph, target_executed=False)
    b.write_json(packet / 'output-native-closure.json',result)
    print('Both fresh outputs match receipts; ELF loaders/shared libraries match preflight; no target execution')
    return 0


if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
