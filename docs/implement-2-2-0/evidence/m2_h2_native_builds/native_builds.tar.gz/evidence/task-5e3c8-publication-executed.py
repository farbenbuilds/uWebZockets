"""Publish the corrected build checkpoint, controls and retained failures."""
import hashlib
import json
import runpy
import sys
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def api(plan, name):
    return runpy.run_path(str(plan / 'task-5e3c8-artifact-api.py'))['published'](plan, name)


def root_records(plan):
    names = [
        'task-5e3c8-brief.md', 'task-5e3c8-native-plan-report.md', 'task-5e3c8-report.md',
        'task-5e3c8-before-fix1-report.md', 'task-5e3c8-review-report.md', 'task-5e3c8-fix1-review-report.md',
        'task-5e3c8-review-package.diff', 'task-5e3c8-fix1-review-package.diff',
        'task-5e3c8-artifact-api.py', 'task-5e3c8-root-audit.py', 'task-5e3c8-root-audit-executed.py',
        'task-5e3c8-root-audit-final-executed.py', 'task-5e3c8-root-audit-code.sha256',
        'task-5e3c8-root-audit-initial-code.sha256', 'task-5e3c8-root-audit-expected.json',
        'task-5e3c8-root-audit.json', 'task-5e3c8-root-audit-command.sh',
        'task-5e3c8-root-audit-initial-command.sh', 'task-5e3c8-root-audit-receipt-reuse-command.sh',
        'task-5e3c8-root-audit-inputs.json', 'task-5e3c8-root-audit-final-inputs.json',
        'task-5e3c8-root-audit-receipt-reuse-restore.stderr',
        'task-5e3c8-root-audit-restore.stdout', 'task-5e3c8-root-audit-restore.stderr',
        'task-5e3c8-root-final-graph-command.sh', 'task-5e3c8-root-final-graph-inputs.json',
        'task-5e3c8-publication.py', 'task-5e3c8-publication-executed.py',
        'task-5e3c8-publication-code.sha256']
    stems = ('root-audit', 'root-audit-initial', 'root-audit-receipt-reuse',
             'root-format', 'root-conventions', 'root-version', 'root-dependencies', 'root-unit', 'root-final-graph')
    names.extend('task-5e3c8-' + stem + '.' + suffix for stem in stems for suffix in ('stdout', 'stderr', 'exit'))
    checks = ('frozen-control', 'frozen', 'restorer-code', 'code', 'bootstrap', 'tools', 'data')
    names.extend('task-5e3c8-root-audit-' + check + '-check.stdout' for check in checks)
    return {'evidence/' + name: (plan / name).read_bytes() for name in names}


def collect(plan, packet):
    result = {}
    for path in sorted(packet.rglob('*')):
        require(not path.is_symlink(), 'Packet symlink')
        if path.is_dir():
            continue
        require(path.is_file(), 'Nonregular packet member')
        result['packet/' + path.relative_to(packet).as_posix()] = path.read_bytes()
    require(len(result) == 1411, 'Frozen packet count differs')
    result.update(root_records(plan))
    for path in sorted((plan / 'task-5e3c8-fix1-base').iterdir()):
        require(path.is_file() and not path.is_symlink(), 'Invalid fix baseline')
        result['evidence/fix1-base/' + path.name] = path.read_bytes()
    audit = json.loads((plan / 'task-5e3c8-root-audit.json').read_text())
    result['BUILD_REFERENCES.json'] = (json.dumps(dict(
        scope='Observed fresh binaries and existing tools are referenced, not embedded',
        accepted_root='/tmp/uwz-h2-native-c8-fix1', original_root='/tmp/uwz-h2-native-c8',
        original_runtime_acceptance='unestablished; retained failure and outputs',
        preflight_sha256=audit['preflight_sha256'], builds=audit['builds'],
        source_authority='m2_h2_native_rehydration/native-rehydration.tar.gz',
        source_authority_sha256='492906b1d077aa494943cdc989f28f2c91a3633a438684176cbcd7d75ea8fa07',
        target_executed=False, clean_machine_reproduction=False), indent=2) + '\n').encode()
    for name, data in result.items():
        try:
            data.decode('utf-8')
        except UnicodeDecodeError as error:
            raise ValueError('Non-UTF-8 publication member: ' + name) from error
    return result, audit


def build(plan, packet, folder):
    members, audit = collect(plan, packet)
    writer = api(plan, 'task-5e3c1-build-publication.py')
    safe = {}
    for name, data in members.items():
        writer['add'](safe, name, data, {})
    folder.mkdir(parents=True, exist_ok=True)
    output = folder / 'native_builds.tar.gz'
    inventory = writer['write_archive'](output, safe)
    manifest = dict(scope='Corrected C8 runtime/input closure and fresh builds; no native execution',
                    base_commit='1b846fcf2cb9bac7d4ef7866c4bb531c0c7dde35', archive=output.name,
                    archive_sha256=sha(output.read_bytes()), archive_bytes=output.stat().st_size,
                    safe_regular_utf8_members=len(safe) + 1, inventory_entries=len(inventory), packet_files=1411,
                    accepted_preflight_sha256=audit['preflight_sha256'], counts=audit['counts'],
                    accepted_builds=audit['builds'], approved_elf_nodes=44,
                    original_runtime_acceptance='unestablished; P1 fixed and fresh builds repeated',
                    private_originals_included=False, toolchain_bytes_embedded=False,
                    repository_gate_scope='Tracked 1b846fc baseline; separate from reconstructed candidate',
                    sdk_historical_directory_state='unproved; seven current extra directories recorded',
                    root_audit_setup_failures='Python real-prefix omission, then reused restoration receipt; retained',
                    root_initial_restore_stdout='superseded; original JSON receipt retained',
                    target_executed=False, native_all40_executed=False, clean_machine_reproduction=False,
                    production_pin_changed=False, milestone_complete=False)
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({key: manifest[key] for key in ('archive_sha256', 'archive_bytes', 'safe_regular_utf8_members', 'packet_files')}))


def audit_publication(plan, packet, folder):
    expected, _ = collect(plan, packet)
    reader = api(plan, 'task-5e3c1-publication-audit.py')
    manifest = json.loads((folder / 'manifest.json').read_text())
    output = folder / manifest['archive']
    require(output.stat().st_size == manifest['archive_bytes'] and sha(output.read_bytes()) == manifest['archive_sha256'], 'Archive identity differs')
    actual = reader['read_archive'](output)
    require(actual == expected and len(actual) == manifest['inventory_entries'], 'Complete archive member bytes differ')
    check = api(plan, 'task-5e3c1-prepare-review.py')['root_check']
    names = ('task-5e3c8-artifact-api.py', 'task-5e3c8-root-audit.py', 'task-5e3c8-publication.py')
    helpers = {name: check((plan / name).resolve()) for name in names}
    docs = Path('docs/implement-2-2-0')
    files = [docs / 'README.md', docs / 'm2_request_streaming.md', docs / 'm2_h2_native_builds.md',
             folder / 'README.md', folder / 'manifest.json', output]
    result = dict(archive_sha256=manifest['archive_sha256'], archive_bytes=output.stat().st_size,
                  safe_regular_utf8_members=len(actual) + 1, inventory_entries=len(actual), packet_files=1411,
                  helpers=helpers, local_links_checked=reader['verify_links'](files),
                  delivery_files={str(path): dict(size=path.stat().st_size, sha256=sha(path.read_bytes())) for path in files},
                  target_executed=False, native_all40_executed=False, milestone_complete=False)
    (plan / 'task-5e3c8-root-publication-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('helpers', 'delivery_files')}))


def main(arguments):
    if arguments not in (['--build'], ['--audit']):
        return
    plan = Path('.superpowers/sdd/h2_streaming_plan')
    packet = Path('.uwz-work/evidence/h2-streaming/native_runtime_builds')
    folder = Path('docs/implement-2-2-0/evidence/m2_h2_native_builds')
    if arguments == ['--build']:
        build(plan, packet, folder)
        return
    audit_publication(plan, packet, folder)


if __name__ == '__main__':
    main(sys.argv[1:])
