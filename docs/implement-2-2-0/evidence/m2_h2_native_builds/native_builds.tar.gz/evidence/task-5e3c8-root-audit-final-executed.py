"""Independently check sealed C8 input rows, recipes and fresh executable bytes."""
import hashlib
import json
import stat
import sys
import tarfile
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            result.update(block)
    return result.hexdigest()


def safe_path(value):
    path = Path(value)
    require(path.is_absolute() and '..' not in path.parts, 'Unsafe input path')
    require('/combined-native/evidence/native-post/' not in value or
            not value.endswith('/environment.nul'), 'Private original is forbidden')
    allowed = ('/workspaces/uWebZockets/', '/tmp/', '/nix/store/', '/home/codespace/.python/',
               '/usr/local/python/3.14.2/', '/usr/lib/', '/usr/bin/', '/lib/', '/lib64/', '/opt/conda/', '/etc/')
    require(value.startswith(allowed), 'Unexpected input scope')
    return path


def check_file(row):
    path = safe_path(row['path'])
    require(path.is_file(), 'Input is not a regular file')
    require(str(path.resolve()) == row['resolved'], 'Resolved input path differs')
    require(path.stat().st_size == row['bytes'] and digest(path) == row['sha256'],
            'Input identity differs: ' + str(path))


def inferred_dirs(names):
    result = {''}
    for name in names:
        result.update('' if str(parent) == '.' else parent.as_posix()
                      for parent in Path(name).parents)
    return result


def check_tree(root, rows, extra_dirs=(), readonly=False):
    require(root.is_dir() and not root.is_symlink(), 'Invalid input tree root')
    files = set()
    directories = {''}
    for path in root.rglob('*'):
        check_tree_path(path, root, files, directories, readonly)
    require(files == set(rows), 'Actual input file set differs')
    require(directories == inferred_dirs(rows) | set(extra_dirs), 'Actual input directory set differs')
    if readonly:
        require(stat.S_IMODE(root.stat().st_mode) == 0o555, 'Tree root is not read-only')
    for name, row in rows.items():
        require(row['path'] == str(root / name), 'Tree row is outside its root')
        check_file(row)
    return dict(files=len(files), directories=len(directories))


def check_tree_path(path, root, files, directories, readonly):
    require(not path.is_symlink(), 'Input tree symlink')
    name = path.relative_to(root).as_posix()
    if path.is_dir():
        directories.add(name)
        if readonly:
            require(stat.S_IMODE(path.stat().st_mode) == 0o555, 'Directory mode differs')
        return
    require(path.is_file(), 'Nonregular input tree member')
    files.add(name)
    if readonly:
        require(stat.S_IMODE(path.stat().st_mode) == 0o444, 'File mode differs')


def old_recipe(mode):
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_combined_fixture/combined-fixture.tar.gz')
    require(digest(archive) == 'c731e84571477286905ed9116fe8f3e6d820d492e6696fb3382947def8cb38c9',
            'Historical fixture authority differs')
    expected = {'debug': 'c93072f4cbb2ecff1448f368069be6570530db95f536b17e7a077488253e8075',
                'release': '9bf3edbe0c120f0ef0f5c2c82fd6a4caa67d10e19c57d6770a8f178d07842e59'}
    name = 'builds/uwz-task5e2-Fix1Final2/' + mode + '-receipt.json'
    with tarfile.open(archive, 'r:gz') as source:
        data = source.extractfile(name).read()
    require(hashlib.sha256(data).hexdigest() == expected[mode], 'Historical recipe differs')
    return json.loads(data)


def replacements(root, mode):
    old = '/tmp/uwz-task5e2-Fix1Final2/'
    candidate = '/tmp/uwz-h2-native-rehydration-c7/candidate/'
    return {
        '-Mroot=' + old + 'fixture/profile.zig': '-Mroot=' + str(root / 'inputs/fixture/profile.zig'),
        '-MuWebZockets=/tmp/uwz-task4d-fix1-frozen/src/root.zig': '-MuWebZockets=' + candidate + 'src/root.zig',
        '-Mc=/workspaces/uWebZockets/.uwz-work/evidence/h1-transport/r2/c-native.zig': '-Mc=' + str(root / 'inputs/c-native.zig'),
        '-Mxev=/tmp/uwz-task4d-fix1-frozen/src/core/xev.zig': '-Mxev=' + candidate + 'src/core/xev.zig',
        '-Mxev_impl=/tmp/uwz-reviewed-libxev-c223-loop-callbacks/src/main.zig': '-Mxev_impl=/tmp/uwz-h2-native-rehydration-c7/libxev/src/main.zig',
        old + mode + '-cache': str(root / mode / 'cache'),
        old + mode + '-global': str(root / mode / 'global'),
        '-femit-bin=' + old + mode + '-profile': '-femit-bin=' + str(root / mode / 'profile')}


def check_build(root, mode, preflight_sha, output_sha):
    folder = root / mode
    command = json.loads((folder / 'command.json').read_text())
    receipt = json.loads((folder / 'receipt.json').read_text())
    substitutions = replacements(root, mode)
    expected = [substitutions.get(token, token) for token in old_recipe(mode)['argv']]
    require(command['argv'] == expected and command['remaps'] == substitutions, 'Build recipe differs')
    require(command['cwd'] == '/tmp/uwz-h2-native-rehydration-c7/candidate', 'Build cwd differs')
    require(command['preflight_sha256'] == preflight_sha, 'Build preflight differs')
    require(command['target_executed'] is False and receipt['target_executed'] is False,
            'Unexpected target-execution claim')
    require(receipt['status'] == 0 and receipt['inputs_preserved'] is True, 'Build receipt failed')
    for name in ('stdout', 'stderr', 'binary'):
        check_file(receipt[name])
    require(receipt['stdout']['bytes'] == 0 and receipt['stderr']['bytes'] == 0, 'Compiler diagnostics differ')
    require(receipt['binary']['path'] == str(folder / 'profile') and
            receipt['binary']['sha256'] == output_sha, 'Fresh output identity differs')
    require(not (folder / 'profile').is_symlink(), 'Output is a symlink')
    return dict(binary=receipt['binary'], status=0, exact_historical_recipe_remap=True)


def audit(plan):
    config = json.loads((plan / 'task-5e3c8-root-audit-expected.json').read_text())
    packet = Path('.uwz-work/evidence/h2-streaming/native_runtime_builds')
    preflight_path = packet / 'preflight-fix1.json'
    require(digest(preflight_path) == config['preflight_sha256'], 'Sealed preflight differs')
    preflight = json.loads(preflight_path.read_text())
    root = Path('/tmp/uwz-h2-native-c8-fix1')
    counts = {}
    for name in ('files', 'direct'):
        for row in preflight[name].values():
            check_file(row)
        counts[name] = len(preflight[name])
    counts['candidate'] = check_tree(Path('/tmp/uwz-h2-native-rehydration-c7/candidate'), preflight['exports']['candidate'], readonly=True)
    counts['libxev'] = check_tree(Path('/tmp/uwz-h2-native-rehydration-c7/libxev'), preflight['exports']['libxev'], readonly=True)
    counts['fixture'] = check_tree(root / 'inputs/fixture', preflight['fixtures'], readonly=True)
    counts['sdk'] = check_tree(Path(preflight['sdk_root']), preflight['sdk'], preflight['sdk_empty'])
    counts['zslay'] = check_tree(Path(preflight['zslay_root']), preflight['zslay'])
    check_file(preflight['generated'])
    require(stat.S_IMODE(Path(preflight['generated']['path']).stat().st_mode) == 0o444,
            'Generated C input mode differs')
    require(stat.S_IMODE((root / 'inputs').stat().st_mode) == 0o555, 'Inputs root mode differs')
    for value in preflight['runtime']['bytecode_absences']:
        path = safe_path(value)
        require(not path.exists() and not path.is_symlink(), 'Eligible bytecode appeared')
    counts['bytecode_absences'] = len(preflight['runtime']['bytecode_absences'])
    builds = {mode: check_build(root, mode, config['preflight_sha256'], config['outputs'][mode])
              for mode in ('debug', 'release')}
    result = dict(counts=counts, builds=builds, preflight_sha256=config['preflight_sha256'],
                  audit_scope='Current referenced input bytes, actual tree sets/modes and output bytes; no execution',
                  target_executed_by_auditor=False, runtime_guard_review_separate=True, milestone_complete=False)
    (plan / 'task-5e3c8-root-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__' and sys.argv[1:] == ['--audit']:
    audit(Path('.superpowers/sdd/h2_streaming_plan'))
