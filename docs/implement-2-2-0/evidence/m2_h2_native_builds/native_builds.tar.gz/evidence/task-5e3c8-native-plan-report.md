Proceed only after C7’s reviewed export is pushed and Root separately releases the next phase. C7 remains sole implementer meanwhile. This plan preserves accepted C4–C6c, canonical coordinator, fixture, production pins, Zig 0.16.0, and zero-allocation product paths.

I applied planning, interface, codebase-design, provenance/security skills and the requested internal grilling lens. No implementation, Python invocation, test, compiler, target process, socket, clock, private-environment read, or write occurred. Graphify navigation was truncated; supplied authorities supplied the relevant detail.

**Authenticated anchors and actual gaps**

Let `E=docs/implement-2-2-0/evidence/` and `N=.uwz-work/evidence/h2-streaming/combined-native/`.

- `E/m2_h2_native_active/native-active.tar.gz`, SHA256 `6fda8cfaac4b8c866ff352848c12397a9775a7bd09397f1db7c9740707c50b14`: all seven `source/current/` files match current native7. `source/canonical/coordinator.py` matches `6585ad2323ce38a75948c7c365ceb7b9589c06e1c6010ae01ba35de0f11e6b32`; transport matches `1ed1d45eab45820ba5e619aaa10525ad5e77e092ac3478c131bc15682e113d1b`.
- Fixture authority: `E/m2_h2_combined_fixture/combined-fixture.tar.gz::source/fixture/` contains 25 files. Complete recipes are `builds/uwz-task5e2-Fix1Final2/debug-receipt.json` SHA `c93072f4cbb2ecff1448f368069be6570530db95f536b17e7a077488253e8075` and `release-receipt.json` SHA `9bf3edbe0c120f0ef0f5c2c82fd6a4caa67d10e19c57d6770a8f178d07842e59`.
- Generated C authority: `E/m2_h2_metadata_live/metadata-live.tar.gz::inputs/c-native.zig`, 1,693,033 bytes, SHA `d9ada6e22902d9aae00bec473ce6942376a8f569f481b7b544b4395beb53d536`. It matches both receipts and current `.uwz-work/evidence/h1-transport/r2/c-native.zig`.
- Compiler and all six current `zig-out/lib/` archives match receipt hashes. Pinned Python, `_ssl`, `_hashlib`, loader, system SSL/crypto libraries, and `/opt/conda` OpenSSL executable/configuration/libraries match historical `output-driver.tar.gz::provenance/manifest-v5.json`, SHA `aab3dda65e16b0475ccb59de28028a2d324ee81c7c05dc6c48daf909f6ae9890`.

No checked authority bytes are missing. Genuine gaps are C7 acceptance, complete fresh executed-runtime/SDK/zslay closure, real provider implementation, rebuilt binaries, and actual combined execution. Matching selected files does not close those gaps.

**Ordered slices**

1. **Runtime closure — verification with build_vendor/crypto_tls.**

   Add bounded `runtime_closure.py` and its focused controls. Produce a fresh manifest referencing existing authenticated bytes, without copying a toolchain or Graphify closure.

   Bind interpreter and flags, native7/canonical sources, ordered codecs, actual standard-library imports, native extensions, and any bytecode eligible for loading. `-B` prevents writes; it does not prove bytecode was not read. Builtin/frozen modules inherit interpreter identity. Guard import preflight against effects, record resolved origins, and require every later lazy import to satisfy the manifest before execution.

   Inspect ELF interpreter/NEEDED/RPATH metadata without running targets; authenticate resolved loader/shared libraries, OpenSSL configuration/providers, and certificate tool. Reconcile actual loaded mappings during authorized runs; reject unknown dependencies and compare identities afterward. Use explicit `env -i` settings, approved import roots, no user-site/startup hooks, no ambient dumps or inherited loader overrides.

   Every dependent Python shell first performs fresh pinned119 restoration with a new receipt. This authorizes metadata preparation only; runtime execution requires Root’s separate release.

2. **Fresh builds — build_vendor.**

   Stage authenticated fixture and C input under a new `/tmp/uwz-h2-native-c8/`. Consume reviewed C7’s 1,031-file candidate and 93-file c223 override, retaining aggregate `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de` and commit `c223bd886c6a51d2cd60def39dd9a68d701fea73`. Production c49 remains unchanged.

   Replay each complete receipt argv, preserving argument order and module scoping:

   ```text
   zig build-exe -O{Debug,ReleaseSafe}
   root=fixture/profile.zig; uWebZockets=candidate/src/root.zig
   c=authenticated c-native.zig; xev=candidate/src/core/xev.zig
   xev_impl=c223/src/main.zig; zslay=authenticated package/src/root.zig
   -lc++ -lc; six receipt-bound static archives; -j2
   ```

   This notation summarizes the receipts; implementation must consume their full argv. Declare only source/input remappings and fresh per-mode cache/global-cache/output destinations; cwd becomes the exact candidate. Verify all 14 zslay files and SDK inventory against existing authorities before/after. Record fresh binary hashes and compiler output.

   The recipe consumes pre-generated C; do not silently replace it with translated output. Separate repository `translate-c` gates retain their command and documented filesystem-escalation handling. Any necessary C/C++ rebuild uses Zig’s native source lists, never system zlib or new build tools.

3. **Real host/provider — transport_io with crypto_tls and verification.**

   Add `native_host.py`, `native_provider.py`, `run_native.py` and focused tests. Keep explicit state/operations; provider returns canonical child descriptors and delegates seven-key connections to accepted transport.

   Map dial/wrap/inspect/timeouts/send/recv/unwrap/close to actual socket/SSL operations; retain canonical `h2_client.new_protocol`. Require TLS1.3, h2, localhost/certificate verification and `suppress_ragged_eofs=False`. Install actual post-open `bind_context`. Strict disconnect requires public unwrap, raw EOF, and closure of the returned handle.

   Bind accepted `signal`, `termination`, `fail_transport`, `transport_receipt`. OwnedSignal evidence comes from fresh PID/start/listener, installed watcher, exact open client, and actual SIGTERM result. Successful signal must not require continuing process/listener existence. Canonical shutdown alone begins/finishes termination.

   Wrap `coordinator.run` with one-shot `fail_transport` followed by bare rethrow; retain first and bounded cleanup errors. Revalidate every receipt during final aggregation.

4. **Child completion and actual runs — verification.**

   Readiness occurs once per child. Preserve ready15/whole900/case30-or180 and clipped grace≤15, using integer nanoseconds without budget resets. Install bounded capture/watcher before signaling; require exit/reap, listener disappearance, completed healthy capture, normal socket/file/key cleanup, then C5 validation.

   Authenticated `profile.zig` emits `info: H2_CAPACITY`, READY, BINDING, 67 RECORDs, four OUTPUTs and DEINIT after server deinit. Use `log_bounds.zig` limits: nonce≤32, fixture≤62144, capture≤65536. Supply independently derived capacity payload and nonce to `parse_capture`, then `validate_post`; never synthesize logs. Publish no certificate/key bytes.

   Run explicit full40 and genuinely omitted selection separately in **both Debug and ReleaseSafe**, each with fresh idle/main children and 41 connections. Observe actual 100MB hashes, output/file facts, generations and scheduling counters. Compare frozen canonical totals with ordinary seals plus active prefix; retain closing deltas/debt and fresh C4 local receipt separately. Missing exit/post/cleanup evidence rejects; forced cleanup rejects; poison and unknown internal-prefix limitations remain.

The deep-module seam is the canonical child provider over explicit host operations. Deleting it would scatter lifetime, deadlines and acceptance across cases. Full repository/platform gates and production adoption remain subsequent requirements; tracked-branch 852/852 is separate evidence.
