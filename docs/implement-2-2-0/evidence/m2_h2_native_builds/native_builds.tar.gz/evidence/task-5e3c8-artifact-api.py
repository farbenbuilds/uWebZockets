"""Authenticate the existing archive tools directly against their published source."""
import hashlib
import runpy
import tarfile
from pathlib import Path


def published(plan, name):
    allowed = ('task-5e3c1-build-publication.py', 'task-5e3c1-publication-audit.py',
               'task-5e3c1-prepare-review.py')
    if name not in allowed:
        raise ValueError('Unknown publication tool')
    archive = Path('docs/implement-2-2-0/evidence/m2_h2_combined_input_audit/combined-input-audit.tar.gz')
    expected = '4c4d93bdec76e4b302a38e5811062b48100df0b617f479fe17eac1bdaa6105c8'
    if hashlib.sha256(archive.read_bytes()).hexdigest() != expected:
        raise ValueError('Published archive tool authority differs')
    helper = plan / name
    if helper.is_symlink() or not helper.is_file():
        raise ValueError('Publication tool is not a regular file')
    with tarfile.open(archive, 'r:gz') as source:
        original = source.extractfile('evidence/' + name).read()
    if helper.read_bytes() != original:
        raise ValueError('Publication tool source differs')
    return runpy.run_path(str(helper))
