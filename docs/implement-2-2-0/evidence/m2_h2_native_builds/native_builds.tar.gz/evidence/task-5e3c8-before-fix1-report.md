# C8 runtime/build closure: DONE

Completed the authorized runtime/input and fresh-build slices against reviewed BASE `1b846fcf2cb9bac7d4ef7866c4bb531c0c7dde35`. Both actual compiler invocations returned **0**, both full input rechecks passed, and subsequent ELF inspection returned **0**. No target executable, SSLContext, certificate operation, socket or provider ran.

New packet `P=.uwz-work/evidence/h2-streaming/native_runtime_builds/`; exclusive work root `T=/tmp/uwz-h2-native-c8/`. No product/build/pin, historical evidence, publication or Root Git changes. C7 exports were consumed directly, never reconstructed again.

## Implementation and controls

`runtime_closure.py` supplies explicit file identity, source/eligible-bytecode authorization, import specification guarding, transitive native-input authorization, loaded-origin checks, mapping reconciliation and a reusable stable-mapping before/after check. Builtin/frozen imports inherit pinned interpreter identity. Unknown or changed origins, caches, libraries and executable/configuration bytes reject before the guarded import specification returns.

`build_inputs.py` authenticates whole archives before selected member reads, validates safe exact inventories/member types/path collisions, checks source/SDK/zslay trees, stages only fixture25 plus pre-generated C, and remaps the complete historical recipes without changing argument order or module scopes. `native_metadata.py` reads ELF INTERP/NEEDED/RPATH/RUNPATH and resolves dependencies without executing inspected files. `replay_builds.py` supplies fixed-root preflight and the two build operations. `inspect_outputs.py` subsequently binds fresh receipts and their preflight hash, validates exact argv/cwd, and checks output ELF dependencies and loader aliases against preflight.

Every acceptance shell uses `env -i PATH=/usr/bin:/bin /bin/sh P/run_control.sh ...`, with explicit packet PYTHONPATH, `PYTHONDONTWRITEBYTECODE=1`, `OPENSSL_CONF=/opt/conda/ssl/openssl.cnf`, and `OPENSSL_MODULES=T/empty-providers`. Each checks interpreter/stdlib/eligible-bytecode/bootstrap-tool/data controls and freshly runs unchanged pinned119 restoration before dependent Python in that same shell. Python is `/home/codespace/.python/current/bin/python3 -B -S`, SHA256 `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`; optimized proofs add `-O`.

Snapshots precede every controlled proof. `raw/` retains argv, stdout/stderr/status and control checks; restoration receipts are under T. Initial navigation/inspection discovery transcripts and source snapshots are retained separately. Those discovery runs do not establish prior import authorization; final preflight uses the subsequently explicit bootstrap controls.

## Acceptance results and retained failures

- `35_normal`, `36_optimized`: nine functional groups plus inert CLI passed in each. Cover changed source/bytecode/library/executable/configuration, unknown imports, library aliases, unsafe paths/archives, nonregular tree entries, extra directories, recipe ordering and inert imports/CLI.
- True behavioral REDs `03_behavioral_red`, `05_path_red`, `34_special_file_red` remain distinct from interface errors; no missing-interface failure is presented as behavioral RED.
- `37_preflight`: **0**; exactly one fixture/C staging, files0444/directories0555.
- `38_debug`, `39_release`: **0**, fresh per-mode local/global caches and outputs; complete before/after input checks passed. Compiler stdout/stderr were empty in both modes. Exact compiler command/environment/receipts/streams/status are copied to `raw/{debug,release}-compiler.*`.
- `42_inspect_inert_normal`, `43_inspect_inert_optimized`: **0**. The test changes to T before installing guards, then imports inspector/project modules and exercises rejected direct CLI. Guards precede all project imports; normal and optimized foreign-cwd proofs passed.
- `44_inspect_outputs`: **0**; fresh binary hashes, original build preflight hash, argv/cwd, ELF libraries and loader aliases match.

Failed preflights08/11/14/18/21/26/29/33 are retained with their exercised sources: inventory schema differences, seven additional SDK directories, the authority's relative client path, bootstrap locale/gconv identities, a non-ELF loader-cache classification, and loader-alias resolution. Fixes normalized authenticated representations or strengthened explicit inputs; no hash/count/path gate was weakened. All failed before fixture staging.

Foreign-cwd attempts40/41 stopped inside pinned119 restoration before inspector execution: that unchanged helper resolves one relative source row against cwd and rejected its physical-path count. Its stdout/stderr and combined tool failure remain; per-operation status files were not produced because restoration terminated the wrapper. Any helper-created duplicate under T remains preserved. Corrected42/43 restore in Root, then change cwd inside the dependent test before project imports. No destination repair, deletion or source extraction retry occurred.

## Exact outputs and ordering

| Mode | Fresh binary bytes | SHA256 |
|---|---:|---|
| Debug | 72174904 | `ced899d02cc5a588a4df55003eabf7d864f3830856b17275cb9543fd0c3b2c32` |
| ReleaseSafe | 31072248 | `df8bd2b30f2e1f6d2a396289a98fc31adf865bc0d679da220dfd176999d68448` |

Binaries remain at `T/{debug,release}/profile`; they were never invoked. Compiler is Zig0.16.0 SHA256 `2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c`, unchanged `-j2`, candidate cwd, original scopes, six static archives and pre-generated C.

`raw/compiler-order.stat` records Debug command07:18:55.423986880, Debug exit07:20:41.132980216, Release command07:20:45.158979962, Release exit07:23:03.046971269 UTC. Actual compiler execution was sequential; wrapper pre/postflight lifetimes overlapped.

## Input identities and preservation

`preflight.json` SHA256 **`c76dc04191b207ffb3461c0ec245803c7d2122c4114909bb64d5014e11432916`** binds all exact paths/lengths/hashes: 5063 runtime path identities,132 ELF objects,474 bytecode absences,53 current/canonical modules, ordered42 codec rows, SDK19542 files, zslay14 files and six archives. Loaded modules108->114 and mapped files25->29 were reconciled during guarded metadata-only ssl import. Seven current directories absent from the file-derived historical SDK directory set are recorded for forward preservation; historical directory state remains unproved.

C7 source authority archive SHA `492906b1d077aa494943cdc989f28f2c91a3633a438684176cbcd7d75ea8fa07` authenticates candidate1031/103051479B aggregate `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`, and libxev93/1347665B aggregate `4ce6e5ad1a0ae954352ea1e8890cc82c2a57509102c4eaa3cd434735613df6f9`. Exact exported paths/directories and0444/0555 modes remained unchanged. Historical c223 override remains evidence, never production c49 adoption.

Fixture archive SHA `c731e84571477286905ed9116fe8f3e6d820d492e6696fb3382947def8cb38c9`; Debug receipt `c93072f4cbb2ecff1448f368069be6570530db95f536b17e7a077488253e8075`; Release receipt `9bf3edbe0c120f0ef0f5c2c82fd6a4caa67d10e19c57d6770a8f178d07842e59`. Generated C1693033B SHA `d9ada6e22902d9aae00bec473ce6942376a8f569f481b7b544b4395beb53d536`; runtime authority manifest SHA `aab3dda65e16b0475ccb59de28028a2d324ee81c7c05dc6c48daf909f6ae9890`. Both fresh build receipts prove these manifests' referenced inputs unchanged. `frozen-current.sha256` records final source/control/manifests; output-native closure records the additional inspector source identity explicitly.

## Self-review and limits

No classes/asserts/custom error types/module mutable state, new toolchain dependency, source patch, private25-original read/hash/copy, or toolchain/Graphify copy. The guard and file hashes do not observe kernel/CPU/vDSO/anonymous memory or eliminate concurrent check/open races. OpenSSL external-provider directory stayed empty; built-in default-provider code inherits its library identity.

Future C9 host/provider/run sources and their imports require explicit new identities and authorization. This proves neither provider ownership nor native all40, repository/release gates, adoption or M2 completion. Root owns review, Graphify maintenance, publication, repository checks, commit and immediate push.
