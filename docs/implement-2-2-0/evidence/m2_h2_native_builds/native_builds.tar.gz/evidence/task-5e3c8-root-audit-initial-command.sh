#!/bin/sh
set -eu
cd /workspaces/uWebZockets
plan=/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan
packet=/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/native_runtime_builds
sha256sum -c "$plan/task-5e3c8-root-audit-code.sha256" > "$plan/task-5e3c8-root-audit-code-check.stdout"
sha256sum -c "$packet/bootstrap.sha256" > "$plan/task-5e3c8-root-audit-bootstrap-check.stdout"
sha256sum -c "$packet/metadata-tools.sha256" > "$plan/task-5e3c8-root-audit-tools-check.stdout"
sha256sum -c "$packet/bootstrap-data.sha256" > "$plan/task-5e3c8-root-audit-data-check.stdout"
test ! -e /etc/ld.so.preload
test ! -L /etc/ld.so.preload
test ! -e /home/codespace/.python/current/lib/python314.zip
test ! -L /home/codespace/.python/current/lib/python314.zip
export PYTHONDONTWRITEBYTECODE=1
export OPENSSL_CONF=/opt/conda/ssl/openssl.cnf
export OPENSSL_MODULES=/tmp/uwz-h2-native-c8-fix1/empty-providers
/home/codespace/.python/current/bin/python3 -B -S "$plan/task-5e3b8a-restore-inputs.py" --restore "$plan/task-5e3c8-root-audit-inputs.json" > "$plan/task-5e3c8-root-audit-restore.stdout" 2> "$plan/task-5e3c8-root-audit-restore.stderr"
/home/codespace/.python/current/bin/python3 -B -S "$plan/task-5e3c8-root-audit.py" --audit
