# C8: fresh runtime/build closure and real Debug/ReleaseSafe binaries

Read `task-5e3c8-native-plan-report.md` first. It is the architecture and exact
authority/recipe anchor for this task. Implement its first two slices only.
This follows C7 review/publication/push; Root will supply the resulting BASE.
This task must produce actual fresh binaries, not another source-only substitute.

Own only NEW `.uwz-work/evidence/h2-streaming/native_runtime_builds/` modules,
focused tests, controls and evidence; stage/build only under the exclusive new
`/tmp/uwz-h2-native-c8/`. You are sole implementer, but not alone: preserve all
other edits. No subagents, Root Git mutations, publication/docs edits, network,
dependency installation, product/build/pin changes, or historical evidence edits.
Root owns review, docs, commit and immediate push. Do not run target binaries,
create certificates, sockets, SSLContext or a provider in this task.

Implement the smallest explicit-function/data modules for runtime closure and
the historical build replay. No classes, asserts, custom error types, mutable
module-level state or speculative abstractions. Keep new control nesting <=3.
Do not copy an interpreter/toolchain/Graphify closure: retain paths, lengths,
hashes and provenance. Read AGENTS/CODING_CONVENTION and relevant build_vendor,
verification/crypto_tls instructions and narrow skills before work. Existing
role advice about local h1spec patches is superseded by AGENTS maintained-fork
policy. Graphify before new codebase questions; supplied paths are located.

Runtime controls must bind pinned interpreter/flags, current seven native
sources, canonical coordinator plus other45 modules, ordered codecs, actual
standard-library/native-extension origins and any eligible bytecode. `-B`
prevents bytecode writes, not reads. Bind startup/import bootstrap explicitly;
do not claim a post-import observation proves prior authorization. Account for
subsequent lazy imports before their execution, using a minimal guard contract
that later provider code can reuse. Builtin/frozen code inherits the binary
identity. Inspect ELF interpreter/NEEDED/RPATH without running targets; bind
resolved loader/libraries, selected OpenSSL configuration/providers and cert
tool for later use. Match loaded mappings for this authorized metadata phase
and retain a reusable before/after check for later authorized native runs.
Unknown or changed dependencies must reject. State unobservable boundaries.

Use focused TDD normal/-O for altered source/bytecode, unknown import origin,
changed shared library or executable/config input, bad paths and inert CLI.
Retain true behavioral RED separately from initial missing-interface failures.
Do not rerun accepted C4-C7 suites or re-materialize C7's source export.

Source authority is the reviewed C7 export:
`/tmp/uwz-h2-native-rehydration-c7/candidate/` (1031 files/103051479 bytes,
aggregate fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de)
and `libxev/` (93 files/1347665 bytes, aggregate
4ce6e5ad1a0ae954352ea1e8890cc82c2a57509102c4eaa3cd434735613df6f9,
commit c223bd886c6a51d2cd60def39dd9a68d701fea73,
tree86c6944f53dc009d7503a9ab0bc873aef3cd7b79). Verify modes0444/0555,
exact path/dir sets and identities before/after, without source writes.
Do not adopt c223 into the production c49 pin.

Authenticate whole source archives and safe inventories before extracting only
the fixture's25 source members and pre-generated C module named in the plan.
No full historical evidence extraction, archive symlinks/traversal, existing
destination repair or reuse. Missing/partial fresh destination must fail closed;
notify Root before choosing a successor root if an actual attempt fails.

Replay COMPLETE Debug and ReleaseSafe receipt argv/order/module scopes. Declare
and record only exact candidate/fixture/C/libxev remaps and fresh per-mode
cache/global-cache/output paths. Use exact candidate cwd, Zig0.16.0 compiler
SHA2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c,
and -j2. Bind actual SDK files and all14 zslay sources from authenticated
authorities, and six static archive input identities. Existing binary hashes
are reference inputs, never fresh-output proof. Pre-generated C is deliberate
in this recipe; no silent translate-c substitution. No system zlib/new build
requirements. Preserve exact recipes, compiler stdout/stderr/status and fresh
binary hashes. Preserve all failures; do not silently fix candidate sources or
weaken validation to compile. Explicitly report any production-source defect.

Root explicitly authorizes the reversible metadata preflight and BOTH compiler
invocations after focused tests and preflight pass. This is separate release
from C7's source-only authorization. Use /tmp for every cache/output, no new
workspace-sized cache. The workspace has1.9GiB free; /tmp has33GiB free.
Do not delete `/tmp/uwz-original-zig-cache`, any evidence, zig-pkg or zig-out/lib.
Filesystem escalation for an unchanged compiler command may be requested with
the concrete cache-write reason; never alter checks because of the sandbox.

Every dependent Python shell uses EXACT
`/home/codespace/.python/current/bin/python3 -B -S` SHA
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601,
PYTHONDONTWRITEBYTECODE=1. First run unchanged
`.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore
NEW_ABSOLUTE_RECEIPT`, then the operation in that SAME shell. Its119 historical
entries are a bootstrap/source authority, not complete current runtime proof.
For actual test/build controls use `env -i` plus only explicitly needed safe
settings/import roots. Snapshot exercised control/source bytes before each run;
retain exact argv, safe settings, complete stdout/stderr/status and receipts.
No ambient environment dumps. Never read/copy/hash the25 private originals in
combined-native/evidence/native-post/*/environment.nul. The authenticated safe
projection map is documented in C7 brief; exclude originals before byte reads.

Acceptance: focused tests and inert checks pass; authentic runtime/build input
manifest; actual fresh Debug and ReleaseSafe compilation terminal0; input
preservation proved; output binary identities recorded. This does not establish
real provider ownership, native all40, release gates, adoption or M2 completion.
Write full report <=1400words to `task-5e3c8-report.md`: status, changed files,
commands/results, exact output/input hashes, self-review, unresolved concerns.
Return only status, one-line results and report path. If a genuine gap remains,
report the precise authority/path/error rather than claiming completion.
