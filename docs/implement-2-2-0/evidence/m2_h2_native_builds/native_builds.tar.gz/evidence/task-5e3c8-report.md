# C8 runtime/build closure: DONE

Completed the authorized runtime/input and fresh-build slices against reviewed BASE `1b846fcf2cb9bac7d4ef7866c4bb531c0c7dde35`. Both actual compiler invocations returned **0**, both full input rechecks passed, and subsequent ELF inspection returned **0**. No target executable, SSLContext, certificate operation, socket or provider ran.

New packet `P=.uwz-work/evidence/h2-streaming/native_runtime_builds/`; exclusive work root `T=/tmp/uwz-h2-native-c8/`. No product/build/pin, historical evidence, publication or Root Git changes. C7 exports were consumed directly, never reconstructed again.

## Implementation and controls

`runtime_closure.py` supplies explicit file identity, source/eligible-bytecode authorization, import specification guarding, transitive native-input authorization, loaded-origin checks, mapping reconciliation and a reusable stable-mapping before/after check. Builtin/frozen imports inherit pinned interpreter identity. Unknown or changed origins, caches, libraries and executable/configuration bytes reject before the guarded import specification returns.

`build_inputs.py` authenticates whole archives before selected member reads, validates safe exact inventories/member types/path collisions, checks source/SDK/zslay trees, stages only fixture25 plus pre-generated C, and remaps the complete historical recipes without changing argument order or module scopes. `native_metadata.py` reads ELF INTERP/NEEDED/RPATH/RUNPATH and resolves dependencies without executing inspected files. `replay_builds.py` supplies fixed-root preflight and the two build operations. `inspect_outputs.py` subsequently binds fresh receipts and their preflight hash, validates exact argv/cwd, and checks output ELF dependencies and loader aliases against preflight.

Every acceptance shell uses `env -i PATH=/usr/bin:/bin /bin/sh P/run_control.sh ...`, with explicit packet PYTHONPATH, `PYTHONDONTWRITEBYTECODE=1`, `OPENSSL_CONF=/opt/conda/ssl/openssl.cnf`, and `OPENSSL_MODULES=T/empty-providers`. Each checks interpreter/stdlib/eligible-bytecode/bootstrap-tool/data controls and freshly runs unchanged pinned119 restoration before dependent Python in that same shell. Python is `/home/codespace/.python/current/bin/python3 -B -S`, SHA256 `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`; optimized proofs add `-O`.

Snapshots precede every controlled proof. `raw/` retains argv, stdout/stderr/status and control checks; restoration receipts are under T. Initial navigation/inspection discovery transcripts and source snapshots are retained separately. Those discovery runs do not establish prior import authorization; final preflight uses the subsequently explicit bootstrap controls.

## Acceptance results and retained failures

- `35_normal`, `36_optimized`: nine functional groups plus inert CLI passed in each. Cover changed source/bytecode/library/executable/configuration, unknown imports, library aliases, unsafe paths/archives, nonregular tree entries, extra directories, recipe ordering and inert imports/CLI.
- True behavioral REDs `03_behavioral_red`, `05_path_red`, `34_special_file_red` remain distinct from interface errors; no missing-interface failure is presented as behavioral RED.
- `37_preflight`: **0**; exactly one fixture/C staging, files0444/directories0555.
- `38_debug`, `39_release`: **0**, fresh per-mode local/global caches and outputs; complete before/after input checks passed. Compiler stdout/stderr were empty in both modes. Exact compiler command/environment/receipts/streams/status are copied to `raw/{debug,release}-compiler.*`.
- `42_inspect_inert_normal`, `43_inspect_inert_optimized`: **0**. The test changes to T before installing guards, then imports inspector/project modules and exercises rejected direct CLI. Guards precede all project imports; normal and optimized foreign-cwd proofs passed.
- `44_inspect_outputs`: **0**; fresh binary hashes, original build preflight hash, argv/cwd, ELF libraries and loader aliases match.

Failed preflights08/11/14/18/21/26/29/33 are retained with their exercised sources: inventory schema differences, seven additional SDK directories, the authority's relative client path, bootstrap locale/gconv identities, a non-ELF loader-cache classification, and loader-alias resolution. Fixes normalized authenticated representations or strengthened explicit inputs; no hash/count/path gate was weakened. All failed before fixture staging.

Foreign-cwd attempts40/41 stopped inside pinned119 restoration before inspector execution: that unchanged helper resolves one relative source row against cwd and rejected its physical-path count. Its stdout/stderr and combined tool failure remain; per-operation status files were not produced because restoration terminated the wrapper. Any helper-created duplicate under T remains preserved. Corrected42/43 restore in Root, then change cwd inside the dependent test before project imports. No destination repair, deletion or source extraction retry occurred.

## Exact outputs and ordering

| Mode | Fresh binary bytes | SHA256 |
|---|---:|---|
| Debug | 72174904 | `ced899d02cc5a588a4df55003eabf7d864f3830856b17275cb9543fd0c3b2c32` |
| ReleaseSafe | 31072248 | `df8bd2b30f2e1f6d2a396289a98fc31adf865bc0d679da220dfd176999d68448` |

Binaries remain at `T/{debug,release}/profile`; they were never invoked. Compiler is Zig0.16.0 SHA256 `2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c`, unchanged `-j2`, candidate cwd, original scopes, six static archives and pre-generated C.

`raw/compiler-order.stat` records Debug command07:18:55.423986880, Debug exit07:20:41.132980216, Release command07:20:45.158979962, Release exit07:23:03.046971269 UTC. Actual compiler execution was sequential; wrapper pre/postflight lifetimes overlapped.

## Input identities and preservation

`preflight.json` SHA256 **`c76dc04191b207ffb3461c0ec245803c7d2122c4114909bb64d5014e11432916`** binds all exact paths/lengths/hashes: 5063 runtime path identities,132 ELF objects,474 bytecode absences,53 current/canonical modules, ordered42 codec rows, SDK19542 files, zslay14 files and six archives. Loaded modules108->114 and mapped files25->29 were reconciled during guarded metadata-only ssl import. Seven current directories absent from the file-derived historical SDK directory set are recorded for forward preservation; historical directory state remains unproved.

C7 source authority archive SHA `492906b1d077aa494943cdc989f28f2c91a3633a438684176cbcd7d75ea8fa07` authenticates candidate1031/103051479B aggregate `fc69e66f18d404aff19a0b018b81dd35c02ec2a46ed8f38670eb926c794f72de`, and libxev93/1347665B aggregate `4ce6e5ad1a0ae954352ea1e8890cc82c2a57509102c4eaa3cd434735613df6f9`. Exact exported paths/directories and0444/0555 modes remained unchanged. Historical c223 override remains evidence, never production c49 adoption.

Fixture archive SHA `c731e84571477286905ed9116fe8f3e6d820d492e6696fb3382947def8cb38c9`; Debug receipt `c93072f4cbb2ecff1448f368069be6570530db95f536b17e7a077488253e8075`; Release receipt `9bf3edbe0c120f0ef0f5c2c82fd6a4caa67d10e19c57d6770a8f178d07842e59`. Generated C1693033B SHA `d9ada6e22902d9aae00bec473ce6942376a8f569f481b7b544b4395beb53d536`; runtime authority manifest SHA `aab3dda65e16b0475ccb59de28028a2d324ee81c7c05dc6c48daf909f6ae9890`. Both fresh build receipts prove these manifests' referenced inputs unchanged. `frozen-current.sha256` records final source/control/manifests; output-native closure records the additional inspector source identity explicitly.

## Self-review and limits

No classes/asserts/custom error types/module mutable state, new toolchain dependency, source patch, private25-original read/hash/copy, or toolchain/Graphify copy. The guard and file hashes do not observe kernel/CPU/vDSO/anonymous memory or eliminate concurrent check/open races. OpenSSL external-provider directory stayed empty; built-in default-provider code inherits its library identity.

Future C9 host/provider/run sources and their imports require explicit new identities and authorization. This proves neither provider ownership nor native all40, repository/release gates, adoption or M2 completion. Root owns review, Graphify maintenance, publication, repository checks, commit and immediate push.

# FIX1: DONE; Root review required

This section supersedes the original runtime-acceptance claim above. Review found P1: ELF discovery automatically authorized its own new/changed transitive identities. Earlier binaries remain actual successful outputs; their original runtime acceptance was unestablished. Original source/control versions, report, receipts and failed proofs remain preserved.

`replay_builds.py` now derives approval independently from authenticated historical manifest `aab3dda65e16b0475ccb59de28028a2d324ee81c7c05dc6c48daf909f6ae9890` and separately source-pinned existing controls: metadata-tools SHA `5b2b713a9654e6fb2071ab7499cbf32993653d36cdd263164a2c2be97fff3be0`, bootstrap-data SHA `e030ea25f5a6f6a6602814a67c531c075557b6fb5e7893b33b8078d5af311b8e`. Their bytes were not regenerated. Known aliases must verify before canonical approval. Discovered ELF identities and every resolved dependency/interpreter must match that independent map before admission; discovery supplies no authorization bytes. Observed mappings likewise verify against existing approval.

The graph covers actual metadata imports plus explicit `_ssl`, `_socket`, `binascii`, certificate/compiler and metadata tools: **44 ELF objects**, reduced from the original132; **5038 path identities**, with mappings25->29. Other historical extension origins remain identity-bound, but imports lacking an explicitly approved native graph reject before native loading. Future C9 work must extend approval explicitly where needed; no unused-library closure is claimed.

`test_runtime_builds.py` exercises the actual `metadata_phase` construction boundary. Behavioral RED `fix1_01_red` and optimized `fix1_02_red_optimized` both show **unknown and changed discovery overwrote authorization** (`authorization_preserved False` for each), then fail. These are behavioral regressions, not missing-interface failures. Fixed08/09 show both True and pass **11 groups plus inert CLI** each. A real import test binds an extension identity but supplies no approved graph: the guard rejects before its native loader or module-cache admission. Foreign-cwd inspector proofs13/14 pass normal/-O with guards preceding project imports.

All commands retain the same `env -i ... P/run_control.sh` form, unchanged pinned Python/restoration and explicit safe controls. Focused tests08/09 run `P/test_runtime_builds.py` (optimized adds `-O`);10 runs `P/replay_builds.py --preflight`;11/12 run `--build debug`/`--build release`;15 runs `P/inspect_outputs.py --inspect`. Snapshots and complete raw results use corresponding `fix1_*` names. Failed preflight07 rejected ssl's lazy binascii import before staging. Adding that explicit phase root still required its authenticated origin and independently approved dependencies; no discovered hash was blessed.

New authorized exclusive root is `/tmp/uwz-h2-native-c8-fix1/`; one fresh fixture/C staging followed preflight10(**0**). Both fresh compiler invocations, complete input afterchecks and ELF-only inspection15 returned **0**, with empty compiler streams. Actual sequential command/exit times were07:41:36.378901081/07:43:14.329894906 and07:43:33.628893689/07:45:43.040885531 UTC. Full recipes/streams/status/receipts are `raw/fix1-{debug,release}-compiler.*`; original root was never deleted, repaired or reused.

| New output | Bytes | SHA256 |
|---|---:|---|
| Debug | 72174904 | `4c89d63f760f467315e83d8c40021f49335b432490e9a06f8cf3f604e69bb476` |
| ReleaseSafe | 31072272 | `94510b8b95880b084f5a2250fd825db181cc9f1320d36f59130f3bdcf64d2f10` |

`preflight-fix1.json` SHA **`e78cbbc2f1665e6999a5502f2817be531909a80d72e1dbd0fd22055dc93bb53c`** records independent native approvals/provenance and all unchanged source, SDK, zslay, archive, fixture and C identities. `output-native-closure-fix1.json` SHA **`334a4c9e27b9837f9aa65bd01ffcc01328e79fdc59e003f5236bcd23921b0cd5`** verifies both fresh outputs against that exact build preflight. `frozen-current-fix1.sha256` records final sources/controls/manifests. Only packet source/control and this report changed. No prior-identity gap remains for the executed metadata scope. Existing unobservable race/kernel boundaries and all subsequent milestone limits remain; no target/provider/certificate/socket, private-original, product/pin, Git or publication operation occurred.
