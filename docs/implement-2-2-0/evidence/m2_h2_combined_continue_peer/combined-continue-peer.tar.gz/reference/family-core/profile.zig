const std = @import("std");
const uz = @import("uWebZockets");
const Hash = std.crypto.hash.sha2.Sha256;
const config: uz.ServerConfig = .{
    .max_connections = 8,
    .stream_request_bodies = true,
    .max_request_line_size = 512,
    .max_header_size = 4096,
    .max_header_count = 80,
    .max_body_size = 256,
    .max_h2_body_size = 4096,
    .max_h2_header_block_size = 8192,
    .max_h2_response_header_size = 4096,
    .max_h2_response_header_count = 32,
    .max_route_params = 24,
    .write_queue_size = 65536,
    .enable_dev_log = false,
};
const Slot = struct {
    owner: *State = undefined,
    active: bool = false,
    hash: Hash = Hash.init(.{}),
    bytes: u64 = 0,
    max_span: usize = 0,
    tag: [32]u8 = undefined,
    tag_len: usize = 0,
    begins: u32 = 0,
    ends: u32 = 0,
    cancels: u32 = 0,
};
const State = struct { slots: [2]Slot = [_]Slot{.{}} ** 2, begins: u32 = 0, ends: u32 = 0, cancels: u32 = 0 };

fn begin(context: *anyopaque, request: *const uz.StreamingRequest, _: uz.BodyControl) !uz.BodyBinding {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.params.get("tag") orelse return error.MissingTag;
    if (tag.len == 0 or tag.len > 32) return error.InvalidTag;
    for (tag) |c| if (!std.ascii.isAlphanumeric(c) and c != '_') return error.InvalidTag;
    for (&state.slots) |*slot| {
        if (slot.active) continue;
        slot.* = .{ .owner = state };
        @memcpy(slot.tag[0..tag.len], tag);
        slot.tag_len = tag.len;
        slot.active = true;
        slot.begins = 1;
        state.begins += 1;
        return .{ .context = slot, .readiness = .ready };
    }
    return error.NoFixtureSlot;
}
fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
    const slot: *Slot = @ptrCast(@alignCast(context));
    slot.max_span = @max(slot.max_span, input.len);
    slot.hash.update(input);
    slot.bytes += input.len;
    return .{ .consumed = input.len, .readiness = .ready };
}
fn end(context: *anyopaque, _: *const uz.StreamingRequest, response: *uz.Response) !void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    defer slot.active = false;
    slot.ends += 1;
    slot.owner.ends += 1;
    var digest: [Hash.digest_length]u8 = undefined;
    slot.hash.final(&digest);
    const hex = std.fmt.bytesToHex(digest, .lower);
    var output: [512]u8 = undefined;
    const body = try std.fmt.bufPrint(&output, "{{\"tag\":\"{s}\",\"accepted\":{d},\"sha256\":\"{s}\",\"begin\":{d},\"end\":{d},\"cancel\":{d},\"max_span\":{d}}}", .{ slot.tag[0..slot.tag_len], slot.bytes, hex, slot.begins, slot.ends, slot.cancels, slot.max_span });
    try response.text(body);
}
fn cancel(context: *anyopaque, _: uz.BodyCancelReason) void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    slot.cancels += 1;
    slot.owner.cancels += 1;
    slot.active = false;
}
fn health(_: *uz.Request, response: *uz.Response) void {
    response.text("ok") catch |err| std.log.err("health: {}", .{err});
}
fn echo_body(_: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    response.text(request.body) catch |err| std.log.err("echo: {}", .{err});
}
fn status(context: *anyopaque, _: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    var output: [256]u8 = undefined;
    const body = std.fmt.bufPrint(&output, "{{\"begin\":{d},\"end\":{d},\"cancel\":{d},\"active\":{d}}}", .{ state.begins, state.ends, state.cancels, @intFromBool(state.slots[0].active) + @as(u32, @intFromBool(state.slots[1].active)) }) catch |err| {
        std.log.err("status formatting: {}", .{err});
        return;
    };
    response.text(body) catch |err| std.log.err("status: {}", .{err});
}
fn delayed(_: *uz.Request, token: uz.AsyncResponse) void {
    token.sleep_complete(10, "200 OK", "Content-Type: text/plain\r\n", "delayed-ok") catch |err| std.log.err("delayed: {}", .{err});
}
pub fn main(init: std.process.Init) !void {
    const certificate = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_CERT") orelse return error.MissingCertificate);
    const key = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_KEY") orelse return error.MissingKey);
    const nonce = init.environ_map.get("H2_PROFILE_NONCE") orelse return error.MissingNonce;
    var state: State = .{};
    var definition: uz.BodyRoute = .{ .sink = .{ .context = &state, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel }, .limits = .{ .max_body_bytes = 100000000, .max_active = 2 }, .middleware_policy = .headers_only };
    {
        var server = try uz.Server.preset(init.io, config).build_https(init.arena.allocator(), certificate, key);
        defer server.deinit();
        _ = try server.route_body(.post, "/upload/:tag", &definition);
        _ = try server.get("/health", health);
        _ = try server.get_context("/status", &state, status);
        _ = try server.route_context(.post, "/echo", &state, echo_body);
        _ = try server.get_async("/delayed", delayed);
        std.log.info("H2_CAPACITY config={f} request_stride={d} h2_bytes={d} h2_stride={d} slab={d} router={d}", .{ std.json.fmt(config, .{}), try config.request_buffer_stride(), try config.h2_session_bytes(), try config.h2_session_stride(), try config.slab_bytes(), try config.router_storage_bytes() });
        try server.listen("127.0.0.1", 28443);
        try server.catch_shutdown_signals();
        std.log.info("H2_READY {s}", .{nonce});
        try server.run();
    }
    std.log.info("H2_DEINIT {s} active={any}", .{ nonce, [_]bool{ state.slots[0].active, state.slots[1].active } });
}
