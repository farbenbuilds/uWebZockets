"""Bounded case plans and independent record expectations; import is inert."""
CASES = ('queued_trailers_padding', 'receive_credit', 'concurrent_routes', 'shutdown_idle')
TAGS = ('queued_trailers_padding', 'receive_credit', 'concurrent_hold', 'concurrent_refused',
        'concurrent_upload', 'concurrent_recovery') + tuple('spare_%02d' % i for i in range(26))
GROUPS = {'queued_trailers_padding': ('queued_trailers_padding',), 'receive_credit': ('receive_credit',),
          'concurrent_routes': ('concurrent_hold', 'concurrent_refused', 'concurrent_upload', 'concurrent_recovery')}
LENGTHS = {'queued_trailers_padding': 12289, 'receive_credit': 65536, 'concurrent_hold': 32,
           'concurrent_upload': 32, 'concurrent_recovery': 32}
HASHES = {'queued_trailers_padding': 'f84149bf46313d9f7da734e3d53f88b2d01a2c01c38bf422063c507b237915f4',
          'concurrent_hold': '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5',
          'concurrent_upload': '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5',
          'concurrent_recovery': '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5'}


def selected_tags(cases):
    return {tag for case in cases if case != 'shutdown_idle' for tag in GROUPS[case]}


def expected(tag, selected, empty_hash, credit_hash):
    touched = tag in selected
    accepted = touched and tag != 'concurrent_refused'
    length = LENGTHS[tag] if accepted else 0
    digest = (credit_hash if tag == 'receive_credit' else HASHES[tag]) if accepted else empty_hash
    return {'tag': tag, 'middleware': int(touched), 'attempts': int(accepted), 'begin': int(accepted),
            'end': int(accepted), 'cancel': 0, 'failure': 0, 'accepted': length, 'sha256': digest,
            'active': False, 'paused': False, 'reason': 'none', 'metadata_begin': int(accepted),
            'metadata_end': int(accepted), 'errors': 0}


def verify_record(actual, expected_record):
    for key, value in expected_record.items():
        if actual.get(key) != value:
            raise ValueError('record ' + expected_record['tag'] + ' field ' + key + ' differs')
    if set(actual) != set(expected_record) | {'chunks', 'max_span'}:
        raise ValueError('record fields differ')
    chunks, span = actual['chunks'], actual['max_span']
    if not isinstance(chunks, int) or not isinstance(span, int) or chunks < 0 or not 0 <= span <= 8192:
        raise ValueError('chunk statistics out of bounds')
    if expected_record['accepted'] == 0 and (chunks or span):
        raise ValueError('unexpected empty record chunk')
    if expected_record['accepted'] and (not chunks or not span):
        raise ValueError('missing accepted chunk')


def barrier(api, tag, stream, accepted, paused, end=0):
    observed = api['status'](tag)
    if (observed['accepted'], observed['paused'], observed['begin'], observed['end'], observed['cancel']) != (accepted, paused, 1, end, 0):
        raise ValueError('body barrier differs: ' + tag)
    api['pending'](stream)
    return observed


def execute(api, case):
    if case not in GROUPS:
        raise ValueError('unsupported case')
    start, send, finish = api['start'], api['send'], api['finish']
    if case == 'queued_trailers_padding':
        tag = case
        stream = start('upload', tag, 12289, '?case=qtp', [('x-metadata', 'initial-qtp'), ('x-initial-only', 'initial-only')])
        send(stream, 12289, 0, 8192, False)
        barrier(api, tag, stream, 7, True)
        send(stream, 12289, 8192, 4097, False, padding=7)
        api['trailers'](stream, [('x-metadata', 'trailer-qtp'), ('x-trailer-only', 'discarded')])
        barrier(api, tag, stream, 7, True)
        api['refund_bound'](stream, 15)
        api['resume'](tag)
        finish(stream)
    elif case == 'receive_credit':
        tag = case
        stream = start('upload', tag, 65536, '', [])
        api['initial_credit'](stream)
        for offset in range(0, 65535, 8192):
            send(stream, 65536, offset, min(8192, 65535 - offset), False)
        api['health']()
        observed = barrier(api, tag, stream, 0, True)
        if observed['chunks'] != 0:
            raise ValueError('paused credit stream invoked chunk')
        api['zero_credit'](stream)
        api['resume'](tag)
        barrier(api, tag, stream, 65535, False)
        api['settled_credit'](stream, 65535)
        send(stream, 65536, 65535, 1, True)
        finish(stream)
    elif case == 'concurrent_routes':
        hold = start('limit', 'concurrent_hold', 32, '?case=hold', [('x-metadata', 'hold-metadata')])
        send(hold, 32, 0, 16, False)
        barrier(api, 'concurrent_hold', hold, 0, True)
        refused = start('limit', 'concurrent_refused', 1, '', [('expect', '100-continue')], status=503, reset=True)
        finish(refused, keep=True)
        upload = start('upload', 'concurrent_upload', 32, '?case=upload', [('x-metadata', 'upload-metadata')])
        api['active'](2)
        send(upload, 32, 0, 32, True)
        finish(upload)
        api['health']()
        barrier(api, 'concurrent_hold', hold, 0, True)
        api['resume']('concurrent_hold')
        barrier(api, 'concurrent_hold', hold, 16, False)
        send(hold, 32, 16, 16, True)
        finish(hold)
        recovery = start('limit', 'concurrent_recovery', 32, '', [])
        send(recovery, 32, 0, 32, True)
        finish(recovery)
        api['health']()
        api['retire'](refused)
    else:
        raise ValueError('unsupported case')
    api['health']()
