const std = @import("std");
const shared = @import("shared.zig");
const catalog = @import("tags.zig");

pub fn format_record(record: *const shared.Record, tag: []const u8, output: []u8) ![]const u8 {
    const index = catalog.index_of(tag) orelse return error.InvalidTag;
    var hash = record.hash;
    var digest: [32]u8 = undefined;
    hash.final(&digest);
    const hex = std.fmt.bytesToHex(digest, .lower);
    const reason = if (record.reason) |value| switch (value) {
        inline else => |reason_value| comptime "\"" ++ @tagName(reason_value) ++ "\"",
    } else "null";
    const common = try std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begins\":{d},\"ends\":{d},\"cancels\":{d},\"failures\":{d},\"end_errors\":{d},\"chunk_errors\":{d},\"invalid_progress\":{d},\"errors\":{d},\"tag\":\"{s}\",\"bytes\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":{s}", .{ record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.end_errors, record.chunk_errors, record.invalid_progress, record.errors, tag, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason });
    const extra = switch (catalog.schema(catalog.family(index) orelse return error.InvalidTag)) {
        .base => try std.fmt.bufPrint(output[common.len..], "}}", .{}),
        .pause => try std.fmt.bufPrint(output[common.len..], ",\"callback_checks\":{d},\"terminal_checks\":{d}}}", .{ record.callback_checks, record.terminal_checks }),
        .credit => try std.fmt.bufPrint(output[common.len..], ",\"metadata_begin\":{d},\"metadata_end\":{d}}}", .{ record.metadata_begin, record.metadata_end }),
        .metadata => try std.fmt.bufPrint(output[common.len..], ",\"metadata_middleware\":{d},\"helpers_begin\":{d},\"helpers_end\":{d},\"metadata_begin\":{d},\"metadata_end\":{d}}}", .{ record.metadata_middleware, record.helpers_begin, record.helpers_end, record.metadata_begin, record.metadata_end }),
        .control => try std.fmt.bufPrint(output[common.len..], ",\"metadata_middleware\":{d},\"metadata_begin\":{d},\"metadata_end\":{d},\"stale_resume\":{d},\"stale_cancel\":{d}}}", .{ record.metadata_middleware, record.metadata_begin, record.metadata_end, record.stale_resume, record.stale_cancel }),
    };
    return output[0 .. common.len + extra.len];
}
pub const Totals = struct {
    middleware: u64 = 0,
    attempts: u64 = 0,
    begins: u64 = 0,
    ends: u64 = 0,
    cancels: u64 = 0,
    failures: u64 = 0,
    end_errors: u64 = 0,
    chunk_errors: u64 = 0,
    invalid_progress: u64 = 0,
    accepted: u64 = 0,
    active: u64 = 0,
    paused: u64 = 0,
    errors: u64 = 0,
    buffered_middleware: u64 = 0,
    slot0_active: bool = false,
    slot1_active: bool = false,
};
pub fn add_record(totals: *Totals, record: *const shared.Record) void {
    totals.middleware += record.middleware;
    totals.attempts += record.attempts;
    totals.begins += record.begins;
    totals.ends += record.ends;
    totals.cancels += record.cancels;
    totals.failures += record.failures;
    totals.end_errors += record.end_errors;
    totals.chunk_errors += record.chunk_errors;
    totals.invalid_progress += record.invalid_progress;
    totals.errors += record.errors;
    totals.accepted += record.bytes;
    totals.active += @intFromBool(record.active);
    totals.paused += @intFromBool(record.paused);
}
pub fn sum_records(records: []const shared.Record, initial: Totals) Totals {
    var totals = initial;
    for (records) |*record| add_record(&totals, record);
    return totals;
}
pub fn format_totals(totals: Totals, output: []u8) ![]const u8 {
    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begins\":{d},\"ends\":{d},\"cancels\":{d},\"failures\":{d},\"end_errors\":{d},\"chunk_errors\":{d},\"invalid_progress\":{d},\"errors\":{d},\"bytes\":{d},\"active\":{d},\"paused\":{d},\"buffered_middleware\":{d},\"slot0_active\":{any},\"slot1_active\":{any}}}", .{ totals.middleware, totals.attempts, totals.begins, totals.ends, totals.cancels, totals.failures, totals.end_errors, totals.chunk_errors, totals.invalid_progress, totals.errors, totals.accepted, totals.active, totals.paused, totals.buffered_middleware, totals.slot0_active, totals.slot1_active });
}
