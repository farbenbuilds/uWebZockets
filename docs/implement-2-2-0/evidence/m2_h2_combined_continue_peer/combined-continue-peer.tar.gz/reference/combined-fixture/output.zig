const std = @import("std");
const uz = @import("uWebZockets");
const Hash = std.crypto.hash.sha2.Sha256;
const total: usize = 16777313;
const sentinel = "final-upload-sentinel!";

const Fields = struct {
    method: []const u8,
    target: []const u8,
    path: []const u8,
    query: []const u8,
    protocol: []const u8,
    tag: []const u8,
    case_header: []const u8,
    content_length: []const u8,
};

pub const Producer = struct {
    scratch: [8192]u8 = undefined,
    storage: [1024]u8 = undefined,
    borrowed: Fields = undefined,
    owned: Fields = undefined,
    hash: Hash = Hash.init(.{}),
    offset: usize = 0,
    invocations: u64 = 0,
    attempts: u64 = 0,
    writes: u64 = 0,
    blocked: u64 = 0,
    pending: u64 = 0,
    terminal_attempts: u64 = 0,
    terminals: u64 = 0,
    checks: u64 = 0,
    after_reuse: u64 = 0,
    errors: u64 = 0,
    binding_index: usize = 0,
    binding_generation: u64 = 0,
    reuse_admitted: *const bool = undefined,
    armed: bool = false,
    done: bool = false,
};

fn copy_field(storage: []u8, used: *usize, value: []const u8) ![]const u8 {
    if (value.len > storage.len - used.*) return error.MetadataOverflow;
    const start = used.*;
    @memcpy(storage[start..][0..value.len], value);
    used.* += value.len;
    return storage[start..used.*];
}

pub fn capture(p: *Producer, request: *const uz.StreamingRequest, binding_index: usize, generation: u64, reuse_admitted: *const bool) !void {
    p.borrowed = .{ .method = request.method, .target = request.target, .path = request.path, .query = request.query, .protocol = request.protocol, .tag = request.params.get("tag") orelse return error.MissingTag, .case_header = request.headers.get("x-case") orelse return error.MissingHeader, .content_length = request.headers.get("content-length") orelse return error.MissingHeader };
    var used: usize = 0;
    p.owned = .{ .method = try copy_field(&p.storage, &used, p.borrowed.method), .target = try copy_field(&p.storage, &used, p.borrowed.target), .path = try copy_field(&p.storage, &used, p.borrowed.path), .query = try copy_field(&p.storage, &used, p.borrowed.query), .protocol = try copy_field(&p.storage, &used, p.borrowed.protocol), .tag = try copy_field(&p.storage, &used, p.borrowed.tag), .case_header = try copy_field(&p.storage, &used, p.borrowed.case_header), .content_length = try copy_field(&p.storage, &used, p.borrowed.content_length) };
    p.binding_index = binding_index;
    p.binding_generation = generation;
    p.reuse_admitted = reuse_admitted;
    p.armed = true;
}
fn same(a: Fields, b: Fields) bool {
    return std.mem.eql(u8, a.method, b.method) and std.mem.eql(u8, a.target, b.target) and
        std.mem.eql(u8, a.path, b.path) and std.mem.eql(u8, a.query, b.query) and
        std.mem.eql(u8, a.protocol, b.protocol) and std.mem.eql(u8, a.tag, b.tag) and
        std.mem.eql(u8, a.case_header, b.case_header) and std.mem.eql(u8, a.content_length, b.content_length);
}
pub fn produce(context: *anyopaque, response: *uz.Response) !uz.StreamStatus {
    const p: *Producer = @ptrCast(@alignCast(context));
    p.invocations += 1;
    p.checks += 1;
    if (p.reuse_admitted.*) p.after_reuse += 1;
    if (!same(p.borrowed, p.owned)) {
        p.errors += 1;
        return error.MetadataChanged;
    }
    while (p.offset < total) {
        const count = @min(p.scratch.len, total - p.offset);
        for (p.scratch[0..count], 0..) |*byte, i| {
            const pos = p.offset + i;
            byte.* = if (pos >= total - sentinel.len) sentinel[pos - (total - sentinel.len)] else @intCast(1 + pos % 251);
        }
        p.attempts += 1;
        response.write_chunk(p.scratch[0..count]) catch |err| {
            if (err == error.WouldBlock) {
                p.blocked += 1;
                p.pending += 1;
                return .pending;
            }
            p.errors += 1;
            return err;
        };
        p.hash.update(p.scratch[0..count]);
        p.offset += count;
        p.writes += 1;
    }
    p.terminal_attempts += 1;
    response.end_chunks() catch |err| {
        if (err == error.WouldBlock) {
            p.blocked += 1;
            p.pending += 1;
            return .pending;
        }
        p.errors += 1;
        return err;
    };
    p.terminals += 1;
    p.done = true;
    return .done;
}
pub fn format(p: *const Producer, tag: []const u8, output: []u8) ![]const u8 {
    var hash = p.hash;
    var digest: [Hash.digest_length]u8 = undefined;
    hash.final(&digest);
    const hex = std.fmt.bytesToHex(digest, .lower);
    return std.fmt.bufPrint(output, "{{\"tag\":\"{s}\",\"armed\":{any},\"done\":{any},\"offset\":{d},\"sha256\":\"{s}\",\"invocations\":{d},\"attempts\":{d},\"writes\":{d},\"blocked\":{d},\"pending\":{d},\"terminal_attempts\":{d},\"terminals\":{d},\"checks\":{d},\"after_reuse\":{d},\"errors\":{d},\"binding_index\":{d},\"binding_generation\":{d}}}", .{ tag, p.armed, p.done, p.offset, hex, p.invocations, p.attempts, p.writes, p.blocked, p.pending, p.terminal_attempts, p.terminals, p.checks, p.after_reuse, p.errors, p.binding_index, p.binding_generation });
}
