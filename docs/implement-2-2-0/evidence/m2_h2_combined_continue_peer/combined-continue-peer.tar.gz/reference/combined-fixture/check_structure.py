"""AST and inert-import proof for new preparation modules only."""
import ast
import contextlib
import importlib.util
import io
from pathlib import Path
import subprocess
import sys


def refuse(*args, **kwargs):
    raise ValueError('import attempted an external command')


def main():
    here = Path(__file__).parent
    paths = tuple(sorted(here.glob('*.py')))
    for path in paths:
        source = ast.parse(path.read_text(),filename=str(path))
        if any(isinstance(node,(ast.Assert,ast.ClassDef)) for node in ast.walk(source)):
            raise ValueError('assert/class in ' + path.name)
        guard = source.body[-1]
        if not isinstance(guard,ast.If) or ast.unparse(guard.test) != "__name__ == '__main__'":
            raise ValueError('missing main guard: ' + path.name)
    original_run = subprocess.run
    original_argv = sys.argv
    subprocess.run = refuse
    try:
        for args in ([], ['foreign','--unexpected']):
            for index,path in enumerate(paths):
                sys.argv = args[:]
                output = io.StringIO()
                error = io.StringIO()
                spec = importlib.util.spec_from_file_location('inert_' + str(index),path)
                module = importlib.util.module_from_spec(spec)
                with contextlib.redirect_stdout(output), contextlib.redirect_stderr(error):
                    spec.loader.exec_module(module)
                if output.getvalue() or error.getvalue():
                    raise ValueError('import emitted output: ' + path.name)
    finally:
        subprocess.run = original_run
        sys.argv = original_argv
    print('PASS AST/no classes/no asserts/main guards; silent inert imports with empty/foreign argv')


if __name__ == '__main__':
    main()
