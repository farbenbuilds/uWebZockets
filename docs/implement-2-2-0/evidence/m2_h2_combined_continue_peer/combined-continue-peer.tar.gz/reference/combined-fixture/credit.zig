const std = @import("std");
const uz = @import("uWebZockets");
const shared = @import("shared.zig");
const Slot = shared.Slot;
const State = shared.State;
const format_record = @import("formatting.zig").format_record;
pub const tags = [_][]const u8{ "queued_trailers_padding", "receive_credit", "concurrent_hold", "concurrent_refused", "concurrent_upload", "concurrent_recovery" };
pub fn tag_index(tag: []const u8) ?usize {
    for (tags, 0..) |candidate, i| if (std.mem.eql(u8, tag, candidate)) return i;
    return null;
}
fn account_body_head(state: *State, request: *const uz.Request) void {
    const tag = request.get_param("tag") orelse {
        state.errors += 1;
        return;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return;
    };
    if (index >= 6) {
        state.errors += 1;
        return;
    }
    state.records[index].middleware += 1;
}
pub fn middleware(context: *anyopaque, request: *uz.Request, response: *uz.Response) uz.MiddlewareResult {
    const state: *State = @ptrCast(@alignCast(context));
    if (std.mem.startsWith(u8, request.path, "/upload/") or std.mem.startsWith(u8, request.path, "/limit/") or std.mem.startsWith(u8, request.path, "/empty/")) {
        account_body_head(state, request);
    } else state.buffered_middleware += 1;
    response.append_header("X-Middleware", "retained") catch {
        state.errors += 1;
        return .stop;
    };
    return .continue_dispatch;
}
const ExpectedMetadata = struct {
    target: []const u8,
    path: []const u8,
    query: []const u8,
    metadata: ?[]const u8,
    initial_only: ?[]const u8 = null,
};
const expected_metadata = [_]ExpectedMetadata{
    .{ .target = "/upload/queued_trailers_padding?case=qtp", .path = "/upload/queued_trailers_padding", .query = "case=qtp", .metadata = "initial-qtp", .initial_only = "initial-only" },
    .{ .target = "/upload/receive_credit", .path = "/upload/receive_credit", .query = "", .metadata = null },
    .{ .target = "/limit/concurrent_hold?case=hold", .path = "/limit/concurrent_hold", .query = "case=hold", .metadata = "hold-metadata" },
    .{ .target = "/limit/concurrent_refused", .path = "/limit/concurrent_refused", .query = "", .metadata = null },
    .{ .target = "/upload/concurrent_upload?case=upload", .path = "/upload/concurrent_upload", .query = "case=upload", .metadata = "upload-metadata" },
    .{ .target = "/limit/concurrent_recovery", .path = "/limit/concurrent_recovery", .query = "", .metadata = null },
};
fn optional_equal(actual: ?[]const u8, expected: ?[]const u8) bool {
    if (actual) |a| {
        const e = expected orelse return false;
        return std.mem.eql(u8, a, e);
    }
    return expected == null;
}
fn metadata_matches(index: usize, request: *const uz.StreamingRequest) bool {
    const expected = expected_metadata[index];
    return std.mem.eql(u8, request.method, "POST") and
        std.mem.eql(u8, request.target, expected.target) and
        std.mem.eql(u8, request.path, expected.path) and
        std.mem.eql(u8, request.query, expected.query) and
        optional_equal(request.params.get("tag"), tags[index]) and
        optional_equal(request.headers.get("x-metadata"), expected.metadata) and
        optional_equal(request.headers.get("x-initial-only"), expected.initial_only) and
        request.headers.get("x-trailer-only") == null;
}
pub fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.params.get("tag") orelse {
        state.errors += 1;
        return error.MissingTag;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return error.InvalidTag;
    };
    if (index >= 6) {
        state.errors += 1;
        return error.SpareTag;
    }
    const record = &state.records[index];
    record.attempts += 1;
    if (!metadata_matches(index, request)) {
        record.errors += 1;
        record.failures += 1;
        return error.MetadataMismatch;
    }
    record.metadata_begin += 1;
    if (record.attempts != 1 or record.middleware != 1) {
        record.errors += 1;
        record.failures += 1;
        return error.DuplicateTag;
    }
    for (state.slots) |*slot| {
        if (slot.record != null) continue;
        slot.generation += 1;
        slot.owner = state;
        slot.record = record;
        slot.index = index;
        record.token = token;
        record.begins += 1;
        record.active = true;
        record.paused = index == 1 or index == 2;
        return .{ .context = slot, .readiness = if (record.paused) .paused else .ready };
    }
    record.failures += 1;
    record.errors += 1;
    return error.NoFixtureSlot;
}
pub fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.max_span = @max(record.max_span, input.len);
    record.chunks += 1;
    var consumed = input.len;
    if (slot.index == 0 and !record.partial_done) {
        consumed = @min(input.len, 7 - @as(usize, @intCast(record.bytes)));
        if (record.bytes + consumed == 7) {
            record.partial_done = true;
            record.paused = true;
        }
    }
    record.hash.update(input[0..consumed]);
    record.bytes += consumed;
    return .{ .consumed = consumed, .readiness = if (record.paused) .paused else .ready };
}
pub fn end(context: *anyopaque, request: *const uz.StreamingRequest, response: *uz.Response) !void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    if (!metadata_matches(slot.index, request)) {
        record.errors += 1;
        return error.MetadataMismatch;
    }
    record.metadata_end += 1;
    record.ends += 1;
    record.active = false;
    record.paused = false;
    record.token = null;
    slot.record = null;
    var output: [1024]u8 = undefined;
    try response.text(try format_record(record, tags[slot.index], &output));
}
pub fn cancel(context: *anyopaque, reason: uz.BodyCancelReason) void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse {
        slot.owner.errors += 1;
        return;
    };
    record.cancels += 1;
    record.reason = reason;
    record.active = false;
    record.paused = false;
    record.token = null;
    slot.record = null;
}
pub fn control(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.get_param("tag") orelse {
        state.errors += 1;
        return;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return;
    };
    const token = state.records[index].token orelse {
        state.errors += 1;
        return;
    };
    if (!state.records[index].paused) {
        state.errors += 1;
        return;
    }
    state.records[index].paused = false;
    token.@"resume"() catch {
        state.errors += 1;
        response.text("error") catch {
            state.errors += 1;
        };
        return;
    };
    response.text("ok") catch {
        state.errors += 1;
    };
}
