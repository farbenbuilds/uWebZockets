const std = @import("std");
const Family = @import("shared.zig").Family;
pub const tags = [_][]const u8{ "large_declared", "large_undeclared", "partial_pause", "final_pause", "begin_pause_empty", "control_one", "control_two", "empty_headers", "empty_data", "empty_declared", "limit_declared", "limit_undeclared", "limit_declared_reject", "limit_declared_recovery", "limit_observed_reject", "limit_observed_recovery", "zero_declared_reject", "zero_declared_recovery", "zero_observed_reject", "zero_observed_recovery", "continue_ready", "continue_paused", "quota_holder_one", "quota_holder_two", "quota_refuse", "quota_recovery_one", "quota_recovery_two", "begin_failure", "begin_recovery", "queued_trailers_padding", "receive_credit", "concurrent_hold", "concurrent_refused", "concurrent_upload", "concurrent_recovery", "metadata_helpers", "cancel_ready", "cancel_ready_recovery", "cancel_paused", "cancel_paused_recovery", "peer_reset", "peer_reset_recovery", "sink_error", "sink_error_recovery", "invalid_progress", "invalid_progress_recovery", "end_error", "end_error_recovery", "disconnect", "disconnect_recovery", "reuse_0", "reuse_1", "reuse_2", "reuse_3", "reuse_4", "reuse_5", "reuse_6", "reuse_7", "reuse_8", "shutdown_active", "producer_reuse", "producer_reuse_next", "output_pressure_window", "output_pressure_ready", "stream_file", "early_final_order", "early_final_recovery" };

pub const Schema = enum { base, pause, credit, metadata, control };
pub fn index_of(tag: []const u8) ?usize {
    for (tags, 0..) |value, index| if (std.mem.eql(u8, tag, value)) return index;
    return null;
}
pub fn family(index: usize) ?Family {
    if (index >= tags.len) return null;
    if (index < 2) return .core;
    if (index < 7) return .pause;
    if (index < 29) return .admission;
    if (index < 35) return .credit;
    if (index < 36) return .metadata;
    if (index < 42) return .cancellation;
    if (index < 48) return .application;
    if (index < 60) return .lifecycle;
    return .output_body;
}
pub fn schema(value: Family) Schema {
    return switch (value) {
        .core, .admission => .base,
        .pause => .pause,
        .credit => .credit,
        .metadata => .metadata,
        .cancellation, .application, .lifecycle, .output_body => .control,
    };
}
