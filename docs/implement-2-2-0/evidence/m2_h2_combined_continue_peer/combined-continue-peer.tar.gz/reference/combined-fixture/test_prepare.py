"""Focused preparation tests; no compiler or fixture is invoked."""
from pathlib import Path
import importlib.util
from types import SimpleNamespace


def require(condition, message):
    if not condition:
        raise ValueError(message)


def raises(function, *args):
    try:
        function(*args)
    except ValueError:
        return
    raise ValueError('missing refusal')


def load_prepare():
    path = Path(__file__).with_name('prepare.py')
    spec = importlib.util.spec_from_file_location('fixture_prepare', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check_commands(module):
    recipe = {'argv': ['zig', 'build-exe', '-ODebug', '-Mroot=/old/profile.zig', '--cache-dir', '/old/cache', '--global-cache-dir', '/old/global', '-femit-bin=/old/bin'], 'cwd': '/source', 'input_sha256': {'/old/profile.zig': 'old', '/native.a': 'native'}}
    command = module.command(recipe, Path('/snapshot'), Path('/attempt'), 'debug')
    require(command == ['zig', 'build-exe', '-ODebug', '-Mroot=/snapshot/profile.zig', '--cache-dir', '/attempt/debug-cache', '--global-cache-dir', '/attempt/debug-global', '-femit-bin=/attempt/debug-profile'], 'actual command construction')
    require(recipe['argv'][3] == '-Mroot=/old/profile.zig', 'recipe mutated')
    raises(module.command, recipe, Path('/snapshot'), Path('/attempt'), 'other')
    require(module.environment() == {'LC_ALL': 'C.UTF-8'}, 'ambient environment leaked')
    one = module.environment()
    one['ambient'] = 'bad'
    require(module.environment() == {'LC_ALL': 'C.UTF-8'}, 'environment aliases caller data')


def check_preparation(module):
    files = {'/owned/profile.zig': b'fixture', '/owned/prepare.py': b'script', '/owned/test_prepare.py': b'tests'}
    copied = []
    removed = []
    def read(path):
        return files[str(path)]
    def copy(source, target):
        copied.append((str(source), str(target)))
        files[str(target)] = read(source)
    def immutable(path):
        removed.append(str(path))
    api = SimpleNamespace(read=read, copy=copy, immutable=immutable)
    actual = module.copy_snapshot(Path('/owned'), Path('/snapshot'), tuple(Path(p).name for p in files), api)
    require(actual == {Path(p).name: module.bytes_digest(value) for p, value in files.items() if p.startswith('/owned/')}, 'copy/hash mismatch')
    require(len(copied) == 3 and len(removed) == 3, 'copy/immutability not applied')
    raises(module.check_expected, {'a': 'wrong'}, {'a': 'expected'})
    module.check_expected({'a': 'same'}, {'a': 'same'})
    raises(module.attempt_path, '../escape')
    raises(module.attempt_path, '')
    require(module.attempt_path('Proof9') == Path('/tmp/uwz-task5e2-Proof9'), 'attempt path')


def main():
    module = load_prepare()
    check_commands(module)
    check_preparation(module)
    print('PASS 2 focused preparation groups: command/environment/copy/hash/refusal')


if __name__ == '__main__':
    main()
