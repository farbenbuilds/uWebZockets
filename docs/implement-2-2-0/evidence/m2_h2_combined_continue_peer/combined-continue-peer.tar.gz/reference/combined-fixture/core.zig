const std = @import("std");
const uz = @import("uWebZockets");
const shared = @import("shared.zig");
const format_record = @import("formatting.zig").format_record;
pub fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
    const state: *shared.State = @ptrCast(@alignCast(context));
    const tag = request.params.get("tag") orelse return error.MissingTag;
    if (tag.len == 0 or tag.len > 32) return error.InvalidTag;
    for (tag) |c| if (!std.ascii.isAlphanumeric(c) and c != '_') return error.InvalidTag;
    const index: usize = if (std.mem.eql(u8, tag, "large_declared")) 0 else if (std.mem.eql(u8, tag, "large_undeclared")) 1 else return error.InvalidTag;
    const record = &state.records[index];
    record.attempts += 1;
    if (record.attempts != 1) return error.DuplicateTag;
    for (state.slots) |*slot| {
        if (slot.record != null) continue;
        slot.generation += 1;
        slot.owner = state;
        slot.index = index;
        slot.record = record;
        record.token = token;
        record.active = true;
        record.begins += 1;
        return .{ .context = slot, .readiness = .ready };
    }
    return error.NoFixtureSlot;
}
pub fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
    const slot: *shared.Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.max_span = @max(record.max_span, input.len);
    record.chunks += 1;
    record.hash.update(input);
    record.bytes += input.len;
    return .{ .consumed = input.len, .readiness = .ready };
}
pub fn end(context: *anyopaque, _: *const uz.StreamingRequest, response: *uz.Response) !void {
    const slot: *shared.Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.ends += 1;
    record.active = false;
    slot.record = null;
    var buffer: [768]u8 = undefined;
    const tag = if (slot.index == 0) "large_declared" else "large_undeclared";
    try response.text(try format_record(record, tag, &buffer));
}
pub fn cancel(context: *anyopaque, reason: uz.BodyCancelReason) void {
    const slot: *shared.Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse {
        slot.owner.errors += 1;
        return;
    };
    record.cancels += 1;
    record.reason = reason;
    record.active = false;
    record.paused = false;
    slot.record = null;
}
