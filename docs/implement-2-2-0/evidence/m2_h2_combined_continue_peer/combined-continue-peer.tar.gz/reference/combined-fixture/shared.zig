const std = @import("std");
const uz = @import("uWebZockets");
const Hash = std.crypto.hash.sha2.Sha256;
const output_state = @import("output.zig");
const file_observer = @import("file_observer.zig");
pub const Record = struct {
    callback_checks: u32 = 0,
    terminal_checks: u32 = 0,
    helpers_begin: u32 = 0,
    helpers_end: u32 = 0,
    partial_done: bool = false,
    binding_index: usize = 0,
    binding_generation: u64 = 0,
    token: ?uz.BodyControl = null,
    hash: Hash = Hash.init(.{}),
    bytes: u64 = 0,
    chunks: u32 = 0,
    max_span: usize = 0,
    middleware: u32 = 0,
    attempts: u32 = 0,
    begins: u32 = 0,
    ends: u32 = 0,
    cancels: u32 = 0,
    failures: u32 = 0,
    end_errors: u32 = 0,
    chunk_errors: u32 = 0,
    invalid_progress: u32 = 0,
    errors: u32 = 0,
    metadata_middleware: u32 = 0,
    metadata_begin: u32 = 0,
    metadata_end: u32 = 0,
    stale_resume: u32 = 0,
    stale_cancel: u32 = 0,
    active: bool = false,
    paused: bool = false,
    reason: ?uz.BodyCancelReason = null,
};

pub const Slot = struct {
    record: ?*Record = null,
    owner: *State = undefined,
    index: usize = 0,
    number: usize = 0,
    generation: u64 = 0,
};
pub const Family = enum { core, pause, admission, credit, metadata, cancellation, application, lifecycle, output_body };
pub const State = struct {
    family: Family,
    slots: *[2]Slot,
    records: []Record,
    producers: *[3]output_state.Producer = undefined,
    file: *file_observer.State = undefined,
    reuse_admitted: *bool = undefined,
    buffered_middleware: u32 = 0,
    errors: u32 = 0,
    attempts: u32 = 0,
    failed: u32 = 0,
};
