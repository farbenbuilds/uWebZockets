"""Verify that importing the supplemental compiler helper has no side effects."""
import contextlib
import importlib.util
import io
from pathlib import Path
import shutil
import subprocess
import sys
from unittest.mock import patch


def verify(path):
    calls = []
    def refuse(*args, **kwargs):
        calls.append((args, kwargs))
        raise ValueError('side effect during import')
    old_argv = sys.argv
    try:
        with patch.object(Path, 'mkdir', refuse), patch.object(Path, 'write_text', refuse), patch.object(Path, 'write_bytes', refuse), patch.object(shutil, 'copytree', refuse), patch.object(subprocess, 'run', refuse):
            for args in ([], ['foreign', '--unexpected']):
                sys.argv = args
                output = io.StringIO()
                error = io.StringIO()
                spec = importlib.util.spec_from_file_location('bounds_helper_check', path)
                module = importlib.util.module_from_spec(spec)
                with contextlib.redirect_stdout(output), contextlib.redirect_stderr(error):
                    spec.loader.exec_module(module)
                if output.getvalue() or error.getvalue() or calls:
                    raise ValueError('import was not silent and inert')
    finally:
        sys.argv = old_argv
    print('PASS bounds helper silent and inert under empty/foreign argv')


def main(args):
    path = Path(args[0]) if args else Path(__file__).with_name('bounds_probe.py')
    verify(path)


if __name__ == '__main__':
    main(sys.argv[1:])
