"""Independent bounded lifecycle case expectations; import is inert."""
CASES = ('sink_error', 'invalid_progress', 'end_error', 'shutdown_idle')
PRIMARIES = CASES[:3]
TAGS = tuple(value for primary in PRIMARIES for value in (primary, primary + '_recovery')) + tuple('spare_%02d' % i for i in range(26))
H32 = '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5'
H7 = '32bbe378a25091502b2baf9f7258c19444e7a43ee4593b08030acd790bd66e6a'
EMPTY = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def selected_tags(selection):
    return {tag for case in selection if case in PRIMARIES for tag in (case, case + '_recovery')}


def expected(tag, selected):
    touched = tag in selected
    recovery = touched and tag.endswith('_recovery')
    primary = touched and not recovery
    end_failure = tag == 'end_error' and primary
    completed = recovery or end_failure
    return {'tag': tag, 'middleware': int(touched), 'attempts': int(touched), 'begin': int(touched),
            'end': int(completed), 'cancel': int(primary and not end_failure), 'failure': 0,
            'end_errors': int(end_failure), 'chunk_errors': int(primary and tag == 'sink_error'),
            'invalid_progress': int(primary and tag == 'invalid_progress'), 'accepted': 32 if completed else 7 if primary else 0,
            'sha256': H32 if completed else H7 if primary else EMPTY,
            'active': False, 'paused': False, 'reason': 'sink_failure' if primary and not end_failure else 'none',
            'metadata_middleware': int(touched), 'metadata_begin': int(touched), 'metadata_end': int(completed),
            'stale_resume': 2 if primary else 0, 'stale_cancel': 2 if primary else 0, 'errors': 0}


def verify_record(actual, expected_record):
    require(set(actual) == set(expected_record) | {'chunks', 'max_span'}, 'record fields differ')
    for key, value in expected_record.items():
        require(actual[key] == value, 'record %s field %s differs' % (expected_record['tag'], key))
    chunks, span = actual['chunks'], actual['max_span']
    require(type(chunks) is int and type(span) is int and chunks >= 0 and 0 <= span <= 8192, 'chunk bounds')
    require((chunks == 0 and span == 0) if not actual['accepted'] else (chunks > 0 and span > 0), 'chunk evidence')


def execute(api, case):
    require(case in PRIMARIES, 'unsupported case')
    sibling = api['sibling']()
    primary = api['start'](case, 'application_failure')
    if case == 'end_error':
        api['send'](primary, 32, True)
        before = None
    else:
        api['send'](primary, 7, False)
        before = api['status'](case)
        require((before['begin'], before['accepted'], before['sha256'], before['end'], before['cancel'], before['paused']) ==
                (1, 7, H7, 0, 0, False), 'preterminal barrier differs')
        api['pending'](primary)
        api['send'](primary, 8, False)
    terminal = api['status'](case)
    end_failure = case == 'end_error'
    require((terminal['begin'], terminal['end'], terminal['cancel'], terminal['end_errors'], terminal['accepted'], terminal['sha256'], terminal['reason'], terminal['active']) ==
            (1, int(end_failure), int(not end_failure), int(end_failure), 32 if end_failure else 7,
             H32 if end_failure else H7, 'none' if end_failure else 'sink_failure', False), 'server terminal barrier differs')
    terminal_wire = api['finish_terminal'](primary)
    stale_before = [api['control'](name, case, 'BodyControlExpired') for name in ('resume', 'cancel')]
    credit = api['reclaim'](32 if end_failure else 15)
    sibling_response = api['finish_sibling'](sibling)
    recovery = api['start'](case + '_recovery', 'healthy')
    api['send'](recovery, 32, True)
    response = api['finish_recovery'](recovery)
    verify_record(response, expected(case + '_recovery', {case + '_recovery'}))
    stale_after = [api['control'](name, case, 'BodyControlExpired') for name in ('resume', 'cancel')]
    return {'before': before, 'terminal': terminal, 'terminal_wire': terminal_wire,
            'stale_before': stale_before, 'sibling': sibling_response, 'credit': credit,
            'recovery': response, 'stale_after': stale_after}
