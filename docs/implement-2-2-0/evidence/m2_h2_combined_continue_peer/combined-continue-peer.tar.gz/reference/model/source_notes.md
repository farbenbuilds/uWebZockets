# Pure combined40 contract boundary

This directory models the future combined fixture/client. It performs no native,
fixture, protocol, descriptor, TLS or scheduler work. All return values are fresh
caller-owned data; constants are immutable tuples, scalars or mapping proxies.
No old checker or live entrypoint was executed. Read the continuation section of
`task-5e1-report.md` for command receipts and the small source snapshot identity.

## Data and schema

`catalogue.ROWS` preserves all 40 caller-ordered IDs and exact 67 tag ownerships.
`child_plan` yields a fresh idle baseline child first when requested, then a main
child. Main disconnect requires its additional replacement connection. Empty
selection has no children or collection. Idle-only has one child and 69 heads.
A nonempty main subset lacking active shutdown appends one 68-response final
collection and ordinary idle teardown; this does not earn the `shutdown_idle` ID.
`shutdown_active` is last if selected. No sorting or replayed checkpoint counts.

`model.BODY_SPECS` independently lists each body's accepted length and terminal
cause. `records(selection, phase)` always yields all 67 keyed rows. `before` means
the final collection before active shutdown's signal, `after` means post-deinit.
`metrics` computes the normalized main-child totals (idle-only yields its own
69 buffered requests). `validate_metrics` requires both explicit bool slot flags
and their sum to equal expected active count; it assumes no initial slot index.
Only `shutdown_active` changes: cancel 0->1, active/paused true->false, reason
None->shutdown. Accepted prefix, SHA, callbacks, stale counters and metadata stay
unchanged. Idle child and all unselected rows have exact zero/default fields.

`COMMON_RECORD` is the named canonical body schema: tag, bytes, SHA-256, chunks,
max_span, middleware, attempts, begins, ends, cancels, failures, end_errors,
chunk_errors, invalid_progress, errors, active, paused and reason. Byte/counter
fields are u64 integers (bool is rejected); active/paused are bool; reason is None
or the exact source cause. SHA is the exact independently expected lowercase
64-character value. Dynamic chunks/max_span and pause callback_checks use None
only in the expected template, never in accepted observations. Chunks are positive
for accepted data and bounded by accepted bytes plus the one diagnosed failed/invalid offer; accepted
bytes must also fit chunks*max_span. Failure offers follow an accepted prefix,
so those records have at least two callbacks;
max_span is 1..8192, additionally <=accepted bytes for admission/output. No packet
count is fixed. Empty records have zero chunks/span. The bounds supplement, and
do not remove, the retained source checks.

Named family schemas in `FAMILY_EVIDENCE` preserve these fields:

| Family | Required additional evidence |
| --- | --- |
| Pause | callback_checks=2*(begins+chunks), terminal_checks=2*ends, errors=0 |
| Credit | metadata_begin and metadata_end for each successful lifecycle |
| Metadata | metadata_middleware, metadata_begin/end, helpers_begin/end |
| Cancellation/application/lifecycle/output | metadata_middleware, metadata_begin/end, stale_resume/cancel |

Common diagnostics distinguish one failed begin from successful begin, one
end_error invocation from cancellation, chunk_error from invalid_progress, and
body_too_large/cancelled/reset/sink_failure/peer_closed/shutdown causes. Stale
reuse vectors are 8,7,6,5,4,3,2,1,0 per operation; no stale call mutates an active
sibling. `validate_stale_control` preserves every other field and sibling;
`validate_unchanged_control` covers BodyNotPaused/BodyControlExpired/
BodyCallbackActive failures. Per-callback fixture self-checks remain represented
by their counters and zero errors, not new invented telemetry.

`LEGACY_SCHEMAS` names each exact retained raw schema. `normalize_legacy` accepts
only its raw keys/types, translates accepted/begin/end/cancel/failure to
bytes/begins/ends/cancels/failures, and string `none` to None. `validate_legacy`
compares that full projection against expected data and refuses extra keys;
missing legacy fields are not fabricated as observations. The canonical combined
schema adds common diagnostics to core/pause/admission and retains every legacy
family field. It is a proposed formatter interface; no combined formatter exists.
The raw output `contracts.py` schema already normalized to canonical names is
compared using `validate_item`/`validate_records`, not passed as legacy raw input.
No JSON parser or serializer is added here.

`request_contract` retains declaration (including absent vs zero/32/33/1), method,
path, query, target, tag and source metadata. Metadata's 66 ordered initial header
entries, 17 captures (64+2 and 16+1 storage), case-insensitive header lookup,
case-sensitive absent P16, absent trailer-only header, begin/end helper checks,
empty text/bytes, five BodyNotBuffered errors, unchanged issue pointer/length/
field/kind, zero-byte allocator and both query helpers are required by the source
self-checks. The exact header/capture vectors and helper contract are retained in
the model. Credit metadata retains x-metadata/x-initial-only and trailer
isolation. The future combined fixture must preserve these predicates.

Producer/file evidence has separate named schemas `PRODUCER_NUMBERS` and
`FILE_NUMBERS`. Producer identity is slot 0/1 and any positive generation; B must
reuse A's slot and generation A+1. No initial generation 1 assumption. Preserve
borrowed fields versus owned copies and no Request pointer retention from
output.zig Fields/Producer/capture/same; checks==invocations, errors=0 and relative
binding tests are the existing observable checks. Preserve writes=2049, one end,
blocked=pending, pending+1=invocations, blocked=attempts-writes+
terminal_attempts-terminals and A's after_reuse>=1. Progress is monotone without
identity change. File reads are positive without an invented exact count;
requested>=returned>0, offsets within [37,24630], arms=1, no error/invalid span,
transferred ownership and close_calls=closed_files=1. Post evidence must equal
pre evidence. Unselected outputs are exact defaults, including caller-owned file
until cleanup. Returned-error ownership remains separate immutable evidence.
`validate_output_response` preserves each separate producer/file/early hash,
file content length 24593, and early final END plus reset. A future client must
also retain the 403/no-100/no-END header barrier, 8+9 grants, END-before-NO_ERROR,
paused/no-final-headers barriers, response sibling and no retained DATA checks.
Those wire/order properties are not proved by this body's pure state model.

## Checked work contracts

Each case derives J/C/R/K, S (SETTINGS), I (100), Z (incoming reset), special wire,
30s ordinary/180s large timeout and finite receive ceilings. Outputs S=2;
disconnect K=S=2; other K=S=1. I=1 only for Continue. Z is exactly the seven
admission/concurrency refusals, two public cancels, three application errors and
early final. Peer reset is client-outgoing, so does not invent an incoming Z.

Checked u64 formula:
`45064*C + special + 39*K + 9*S + 26*R + 4105*I + 13*Z`.
Special wire: producers 16799868, file 250044, early final 4140. No current output
R65/final33/32-record bound is relabeled as combined. Every nonempty read consumes
at least one work byte, so a finite byte ceiling also bounds calls. Existing
4096 receive/snapshot limits are separately retained where the source has them;
no reset of that connection-scoped cap across final collection is allowed.
`receive_calls` is the tighter of byte ceiling and that legacy cap. Large source
reader lacked a 4096 cap. Counters/limits are contracts, not traffic observations.

Connection debt <=min(R,65535); individual stream debt <=min(sentflow,65535).
For the retained case traffic, aggregate stream debt fits the same bound: only
one stream in each case can exceed 65535 sent bytes; other cases' total R is
below 65535. Disconnect's final connection sent only 32. Refund frames <=2R,
each positive refund consumes known debt once in each scope, and debt never
crosses connections. Do not require late debt zero. Final collection is
`3064352+13*actual_remaining_debt`, checked and capped at 131070 debt: full
last connection <=64 debt/final3065184; partial ending large <=131070/final4768262.
`budgets` adds this once only when a main subset lacks active shutdown; active
shutdown's base C70 already includes final68. Preserve parser, ledgers, remaining
case/whole deadline and existing read cap through final collection. No fresh
case deadline is created here. Positive DATA frames <=R, zero DATA frames are
explicitly one for empty_data and begin_pause_empty; DATA<=8192 and header blocks
<=8192 are separate limits. Trailers occur only for queued/metadata cases.

Full arithmetic: main733 heads/720 small, idle69/69, whole802/789/41 connections;
body67/attempts62/begins61/ends52/cancels9/accepted200091500; pre-signal cancels8
and one active paused binding; buffered middleware main666/idle69. Logical output
is 50356549. Whole receive work ceiling is 5288609050 bytes. These schedule
quantities are not measured performance or execution results.

## Finite source ordering adopted by Root

`task-5e-barrier-source-handoff.md` is authoritative. Every preceding action is
fully serialized and flushed with data_to_send(amount=8192), then exactly one
same-connection GET is enqueued; receiving its response establishes synchronous
server parser/driver order. Mismatch fails; no observation retry/poll. Root
adopted the handoff without counts/deadlines/capacity changes. `FINITE_BARRIERS`
and `barrier_policy` record these requirements; they execute no action.

Frozen fc69 locators: tcp511-525 -> server754-802/1095-1130 -> head1390-1402/
1557-1593 -> http2_upload120-162 -> later GET tcp802-840/926-940. Body DATA,
padding, queued EOF and drain are server1596-1680; resume request_body80-85 ->
tcp660-674 -> server1481-1488. Continue must receive one valid 100 before DATA;
server1642-1649 permits pending informational output. Credit receipt alone never
proves SHA/metadata/end/quota; padding/discard/reset have separate credit effects.

Quota has exactly four active metrics: 2,0,2,0 after respective admissions/finals.
Observed-limit keeps the accepted32 ready/no-end status before offending byte.
Pause queues EOF before an unchanged second observation. Receive-credit waits
only for bounded incoming refund frames after the ready65535 observation; those
waits add no heads. Cancellation/error/reuse status follows synchronous action.
Active shutdown collects 67 statuses and one metrics before signal, none after.

Cross-connection disconnect requires original accepted7-paused status, successful
strict_close.unwrap_eof AND plain TCP EOF, then replacement TLS/h2 health and
one peer_closed/cancel1/inactive status. tcp3212-3228 closes H2 inputs before
socket teardown3282-3289; TLS close_notify by itself is insufficient.

Final-source identity: admission/fix1/cases.py and profile.zig match the final
review manifest's task5b2-fix1-frozen entries; pause-control/fix1 profile/run_live
match task5b1-fix1-frozen; credit/fix1 cases/profile/run_live match
review-manifest-v2 task5b3-fix1-frozen-v2. Their SHA inventory is in the report.
The retained legacy polling loops are history; this does not claim they were
already single-GET implementations. `finite_barrier_source_supported=True` and
`combined_action_order_tested=False` deliberately express that distinction.

## Remaining preparation

Actual startup serialization byte count is unproved (`startup_serialization_proved`
is false); formula startup terms are the handoff's proposed ceiling contract.
The later combined client must prove action/observation serialization, one-GET
fail-closed behavior, raw/credit ledgers, reset/transport retirement, bounded
extraction, preserved read/deadline caps and startup grants. Combined formatter
768/1024/prefix64/capture65536 bounds, fixture integration, builds, new immutable
closure and actual fresh two-child combined40 remain unimplemented and unrun.
No native/full gate or original milestone completion is claimed.

## Review fix 1: idle, non-body responses and binding marker

`shutdown_idle` is included in `LEGACY_CAPPED_CASES`: inherited read/snapshot cap
4096, while its byte ceiling remains3109464 and J/C=69/69,R=0. The retained credit
fix1 reader188 appends one snapshot per receive; its idle branch326-333 and final
collection403-405 share that trace. `receive_calls_left(case, consumed)` accepts a
caller-owned cumulative receive count across health and final collection, returns
4096-consumed for idle and rejects consumed4097. No final-boundary reset or fresh
allowance is part of this contract. Counts and deadlines are unchanged.

The two cases with no body tags now have named pure request/response contracts:
`READY_BUFFERED_REQUEST`, `ASYNC_DELAYED_REQUEST`, `CORE_REQUESTS`,
`CORE_RESPONSES`, `CORE_RESPONSE_FIELDS` and `CORE_SINK_COUNTERS`.
`core_request` returns caller-owned request data. Buffered request is POST /echo,
content-length257, HEADERS without END then exactly257 payload bytes with DATA
END. Payload is bytes0..250 followed by0..5, SHA256
`a2c6cad2ffa699b14538231fef914f45d30440389e6f8d79091efba836165a2b`.
Delayed request is GET /delayed with HEADERS END and no DATA, response body
`delayed-ok`, length10, SHA256
`5235430cff06281ef23fabd775a3493bf34fd508219d31ed270ac65ac631ce52`.
These payloads use the original core algorithm, not the streaming sentinel
algorithm. Pure tests also reconstruct the257 bytes with a second algorithm.

`validate_core_response` requires exact body bytes/count/hash, END=true, no reset,
no trailers or informationals, nonempty typed header pairs, exactly one status200,
and for delayed exactly one case-insensitive content-type with value text/plain.
No async middleware header is required; an extra such header is accepted. The
normalized body is bytes before legacy summary rendering; this is not a proposed
JSON byte encoding. `validate_output_response` dispatches these two known core
cases to the same checks. Source: core/run_live.py104-120,141-161 and
core/profile.zig77-91. No wire response or callback has been executed here.

`validate_core_sink` names the core before/after aggregate schema
(begin,end,cancel,active), strictly requires u64 counters and inactive0 on each
side, and requires exact equality. Existing nonzero terminal totals are allowed;
zero is not assumed for a selected subset's history. Apply this pure unchanged
sink predicate to retained observations/projections; it creates no status request
or schedule change. Tests reject mutated counters or active sinks for either
case and corrupt payload, digest, count, status, content type/multiplicity and
terminal evidence.

The separate marker has named schema `BINDING_OBSERVATION`, with exact tag
producer_reuse_next and integer binding_index/binding_generation.
`default_binding()` returns caller-owned (index0,generation0). It remains separate
from the three producer/file outputs, matching the retained formatter's four
H2_OUTPUT rows plus one H2_BINDING marker. `validate_binding_pre_post` validates
selection before comparing evidence. Unselected requires no prior observation
(None), no selected producer context, and the exact zero post marker. Selected
requires a positive generation and actual slot0/1 on armed A; prior B must have
A's slot and generation A+1, and post B must equal prior B with exact types.
`validate_output_pre_post` now requires keyword binding_before/binding_after,
so its existing output comparison also checks the separate binding marker. This
closes a previously uncovered observation rather than silently assigning a
selected A generation1. Source: retained output post.py68-78 and cases.py46-51.
Tests reject stale/nonzero idle bindings, even a zero prior observation when
unselected, generation-zero/invalid-slot A, wrong A+1, missing prior selected
binding, changed post binding and bool-as-index. Marker parsing and actual wire/
formatter action remain in the later client/fixture slice.
