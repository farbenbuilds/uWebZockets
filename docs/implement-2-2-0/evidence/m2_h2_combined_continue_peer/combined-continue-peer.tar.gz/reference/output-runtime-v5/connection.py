"""Construct a fresh, identity-checked TLS 1.3/h2 connection for a case."""
import hashlib
import socket
import ssl
import h2.config
import h2.connection
import owned_io


def tls_context(certificate):
    context = ssl.create_default_context(cafile=certificate)
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    context.maximum_version = ssl.TLSVersion.TLSv1_3
    context.set_alpn_protocols(['h2'])
    return context


def factory(context, certificate_hash, owned, clock, check_capture):
    def connect(case, deadline):
        check_capture()
        owned()
        raw = socket.create_connection(('127.0.0.1', 28443), timeout=owned_io.remaining(deadline, clock))
        try:
            raw.settimeout(owned_io.remaining(deadline, clock))
            sock = context.wrap_socket(raw, server_hostname='localhost', suppress_ragged_eofs=False)
        except BaseException as exc:
            try:
                raw.close()
            except BaseException as cleanup_error:
                exc.add_note('socket cleanup failed: ' + repr(cleanup_error))
            raise
        try:
            if (sock.version() != 'TLSv1.3' or sock.selected_alpn_protocol() != 'h2' or
                    hashlib.sha256(sock.getpeercert(binary_form=True)).hexdigest() != certificate_hash):
                raise ValueError('TLS peer identity differs')
            owned()
            codec = h2.connection.H2Connection(config=h2.config.H2Configuration(
                client_side=True, header_encoding='utf-8', validate_inbound_headers=True, validate_outbound_headers=True))
        except BaseException as exc:
            try:
                sock.close()
            except BaseException as cleanup_error:
                exc.add_note('TLS cleanup failed: ' + repr(cleanup_error))
            raise
        def write(data):
            check_capture()
            owned_io.write(sock, data, deadline, clock)
        def read():
            check_capture()
            return owned_io.read(sock, deadline, clock)
        return {'codec': codec, 'write': write, 'read': read, 'close': sock.close, 'case': case}
    return connect
