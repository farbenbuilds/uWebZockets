"""Pure parsing and checks for the owned Linux child and listener."""


def start_id(stat):
    if type(stat) is not str or ')' not in stat:
        raise ValueError('invalid process stat')
    fields = stat[stat.rfind(')') + 2:].split()
    if len(fields) <= 19 or not fields[19].isdigit():
        raise ValueError('invalid process start identity')
    return fields[19]


def match_listeners(table, links):
    if type(table) is not str or type(links) not in (list, tuple):
        raise ValueError('invalid listener inventory')
    inodes = {link[8:-1] for link in links if type(link) is str and link.startswith('socket:[') and link.endswith(']')}
    result = []
    for line in table.splitlines()[1:]:
        fields = line.split()
        if len(fields) < 10:
            raise ValueError('invalid TCP row')
        if fields[1] == '0100007F:6F1B' and fields[3] == '0A' and fields[9] in inodes:
            result.append(fields[9])
    return result


def require_owned(exit_status, actual_start, expected_start, listeners, listener):
    if exit_status is not None or actual_start != expected_start or listeners != [listener]:
        raise ValueError('owned process or listener changed')
