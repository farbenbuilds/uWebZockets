"""Reap an owned fixture and verify its post-deinit evidence."""
import post


def graceful(state, result, selection, nonce, capacity, overall, clock, ops):
    now = clock()
    deadline = min(overall, now + 15)
    if now >= deadline:
        raise ValueError('shutdown deadline expired')
    child = state['child']
    ops['owned'](child, state['start'], state['listener'])
    ops['signal'](child)
    state['signalled'] = True
    status = ops['wait'](child, deadline)
    state['reaped'] = True
    state['exit_status'] = status
    if type(status) is not int or status != 0:
        raise ValueError('fixture did not exit successfully')
    ops['join'](state['capture'], deadline)
    state['collector_joined'] = True
    output = ops['snapshot'](state['capture'])
    final = result['final']
    observed = post.validate(output, nonce, selection, capacity, final['records'], final['totals'],
                             result['binding'], result['outputs'])
    for name in ('key', 'transfer'):
        ops['unlink'](state[name])
        if ops['absent'](state[name]) is not True:
            raise ValueError('owned temporary file remains: ' + name)
        state[name + '_removed'] = True
    return observed
