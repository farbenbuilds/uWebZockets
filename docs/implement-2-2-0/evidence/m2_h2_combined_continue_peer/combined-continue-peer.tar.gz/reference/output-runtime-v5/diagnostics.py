"""Checks for the reviewed fixture's owned producer and file observations."""
import contracts


PRODUCER_NUMBERS = frozenset(('offset', 'invocations', 'attempts', 'writes', 'blocked',
                              'pending', 'terminal_attempts', 'terminals', 'checks',
                              'after_reuse', 'errors', 'binding_index', 'binding_generation'))
FILE_NUMBERS = frozenset(('reads', 'requested', 'returned', 'read_errors', 'close_calls',
                          'closed_files', 'invalid_spans', 'min_offset', 'max_end',
                          'arms', 'arm_errors'))


def check_fields(item, numbers, booleans, strings):
    if type(item) is not dict or item.keys() != numbers | booleans | strings:
        raise ValueError('diagnostic schema')
    for name in numbers:
        if type(item[name]) is not int or item[name] < 0:
            raise ValueError('diagnostic integer: ' + name)
    for name in booleans:
        if type(item[name]) is not bool:
            raise ValueError('diagnostic boolean: ' + name)
    for name in strings:
        if type(item[name]) is not str:
            raise ValueError('diagnostic string: ' + name)


def producer(item, tag, offset, *, held=False, after_reuse=False):
    check_fields(item, PRODUCER_NUMBERS, frozenset(('armed', 'done')), frozenset(('tag', 'sha256')))
    if type(offset) is not int or offset not in (0, 8192, contracts.TOTAL):
        raise ValueError('invalid producer checkpoint')
    digest = contracts.PRODUCER_HASH if offset == contracts.TOTAL else contracts.digest(contracts.TOTAL, 0, offset)
    if (item['tag'] != tag or not item['armed'] or item['offset'] != offset or item['sha256'] != digest
            or item['errors'] != 0 or item['checks'] != item['invocations']
            or item['blocked'] != item['pending'] or item['attempts'] < item['writes']
            or item['blocked'] != item['attempts'] - item['writes'] + item['terminal_attempts'] - item['terminals']
            or item['binding_index'] not in (0, 1) or item['binding_generation'] < 1):
        raise ValueError('producer diagnostic mismatch')
    if held and (item['done'] or item['blocked'] < 1 or item['pending'] < 1 or item['terminals'] != 0):
        raise ValueError('producer did not block at checkpoint')
    if offset == contracts.TOTAL and (not item['done'] or item['writes'] != 2049
                                      or item['terminals'] != 1 or item['pending'] + 1 != item['invocations']):
        raise ValueError('producer completion mismatch')
    if after_reuse and item['after_reuse'] < 1:
        raise ValueError('producer reuse not observed')


def file_complete(item):
    check_fields(item, FILE_NUMBERS, frozenset(('transferred', 'caller_owned')), frozenset(('tag',)))
    if (item['tag'] != 'stream_file' or item['reads'] < 1 or item['requested'] < item['returned']
            or item['returned'] < 1 or item['read_errors'] != 0 or item['close_calls'] != 1
            or item['closed_files'] != 1 or item['invalid_spans'] != 0
            or item['min_offset'] < 37 or item['max_end'] > 24630
            or item['max_end'] <= item['min_offset'] or item['arms'] != 1 or item['arm_errors'] != 0
            or not item['transferred'] or item['caller_owned']):
        raise ValueError('file diagnostic mismatch')


def progress(before, after):
    if (before['tag'] != after['tag'] or before['binding_index'] != after['binding_index'] or
            before['binding_generation'] != after['binding_generation']):
        raise ValueError('producer identity changed')
    for name in PRODUCER_NUMBERS - {'binding_index', 'binding_generation'}:
        if after[name] < before[name]:
            raise ValueError('producer counter decreased: ' + name)
