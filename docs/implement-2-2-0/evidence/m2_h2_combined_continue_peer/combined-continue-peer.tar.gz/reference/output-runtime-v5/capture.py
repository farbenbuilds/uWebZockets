"""Bounded collector state for an owned fixture's combined output."""
import threading


def new():
    return {'lock': threading.Lock(), 'event': threading.Event(), 'bytes': bytearray(),
            'overflow': False, 'error': None, 'finished': False}


def collect(read, state):
    try:
        while True:
            data = read()
            if type(data) is not bytes or len(data) > 8192:
                raise ValueError('invalid collector read')
            if not data:
                break
            with state['lock']:
                room = 65536 - len(state['bytes'])
                state['bytes'].extend(data[:room])
                if len(data) > room:
                    state['overflow'] = True
                state['event'].set()
    except BaseException as exc:
        with state['lock']:
            state['error'] = repr(exc)
    finally:
        with state['lock']:
            state['finished'] = True
            state['event'].set()


def inspect(state):
    with state['lock']:
        return {'bytes': bytes(state['bytes']), 'overflow': state['overflow'],
                'error': state['error'], 'finished': state['finished']}


def snapshot(state):
    result = inspect(state)
    if result['overflow'] or result['error'] is not None:
        raise ValueError('collector failed: ' + str(result['error']))
    return result['bytes']


def ready_markers(data, nonce, capacity):
    lines = data.decode('utf-8').splitlines()
    capacity_rows = [line.split('H2_CAPACITY ', 1)[1] for line in lines if 'H2_CAPACITY ' in line]
    ready_rows = [line.split('H2_READY ', 1)[1] for line in lines if 'H2_READY ' in line]
    if capacity_rows != [capacity.removeprefix('H2_CAPACITY ')] or ready_rows != [nonce]:
        raise ValueError('readiness markers differ')


def wait_ready(state, nonce, capacity, deadline, clock, poll, listeners):
    while True:
        with state['lock']:
            if state['overflow'] or state['error'] is not None:
                raise ValueError('collector failed: ' + str(state['error']))
            data = bytes(state['bytes'])
            finished = state['finished']
            state['event'].clear()
        if poll() is not None:
            raise ValueError('child exited before readiness')
        complete = data[:data.rfind(b'\n') + 1]
        if ('H2_READY ' + nonce + '\n').encode() in complete:
            ready_markers(complete, nonce, capacity)
            owned = listeners()
            if len(owned) != 1:
                raise ValueError('owned listener differs')
            return owned[0]
        if finished:
            raise ValueError('output ended before readiness')
        remaining = deadline - clock()
        if remaining <= 0 or not state['event'].wait(remaining):
            raise ValueError('readiness deadline expired')
