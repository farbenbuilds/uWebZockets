"""Independent fixed lifecycle record expectations; importing is inert."""

H32 = '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5'
H7 = '32bbe378a25091502b2baf9f7258c19444e7a43ee4593b08030acd790bd66e6a'
EMPTY = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
TAGS = ('disconnect', 'disconnect_recovery') + tuple('reuse_' + str(i) for i in range(9)) + ('shutdown_active',) + tuple('spare_%02d' % i for i in range(20))
CASES = ('disconnect', 'reuse', 'shutdown_active')


def records(selection, phase):
    if phase not in ('before', 'after') or len(set(selection)) != len(selection) or not set(selection) <= set(CASES):
        raise ValueError('invalid selection or phase')
    selected = set(selection)
    result = {}
    for tag in TAGS:
        touched = ((tag in ('disconnect', 'disconnect_recovery') and 'disconnect' in selected) or
                   (tag.startswith('reuse_') and 'reuse' in selected) or
                   (tag == 'shutdown_active' and 'shutdown_active' in selected))
        interrupted = touched and tag in ('disconnect', 'shutdown_active')
        active = touched and tag == 'shutdown_active' and phase == 'before'
        complete = touched and not interrupted
        stale = 8 - int(tag[-1]) if touched and tag.startswith('reuse_') else 2 if touched and tag == 'disconnect' else 0
        result[tag] = {'tag': tag, 'middleware': int(touched), 'attempts': int(touched),
                       'begin': int(touched), 'end': int(complete), 'cancel': int(interrupted and not active),
                       'failure': 0, 'end_errors': 0, 'chunk_errors': 0, 'invalid_progress': 0,
                       'accepted': 32 if complete else 7 if interrupted else 0,
                       'sha256': H32 if complete else H7 if interrupted else EMPTY,
                       'active': active, 'paused': active, 'reason': 'peer_closed' if tag == 'disconnect' and touched else 'shutdown' if interrupted and not active else 'none',
                       'metadata_middleware': int(touched), 'metadata_begin': int(touched), 'metadata_end': int(complete),
                       'stale_resume': stale, 'stale_cancel': stale, 'errors': 0}
    return result


def totals(items):
    return tuple(sum(int(record[field]) for record in items.values()) for field in ('attempts', 'begin', 'end', 'cancel', 'accepted', 'active'))


def verify(actual, expected):
    if actual.keys() != expected.keys():
        raise ValueError('record identities differ')
    for tag, target in expected.items():
        record = actual[tag]
        evidence = set(record) == set(target) | {'chunks', 'max_span'}
        if not evidence and set(record) != set(target):
            raise ValueError('record fields differ: ' + tag)
        if any(type(record[key]) is not type(value) or record[key] != value for key, value in target.items()):
            raise ValueError('record expectations differ: ' + tag)
        if evidence:
            chunks, span = record['chunks'], record['max_span']
            if type(chunks) is not int or type(span) is not int or chunks < 0 or not 0 <= span <= 8192:
                raise ValueError('chunk bounds differ: ' + tag)
            if (chunks == 0 and span == 0) != (record['accepted'] == 0):
                raise ValueError('chunk evidence differs: ' + tag)
