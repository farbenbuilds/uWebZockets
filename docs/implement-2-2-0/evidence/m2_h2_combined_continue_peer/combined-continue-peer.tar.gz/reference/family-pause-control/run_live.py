"""Explicitly gated ordinary owned H2 fixture runner; importing is inert."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import socket
import ssl
import subprocess
import sys
import threading
import time

HERE = Path(__file__).resolve().parent
PORT = 28443
PYTHON = '/home/codespace/.python/current/bin/python3'
PACKAGES = '/tmp/uwz-h2-client-tooling/packages'
HELPER = '/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client'
OPENSSL = '/opt/conda/bin/openssl'
CASES = ('partial_pause', 'final_pause', 'begin_pause_empty', 'control_rules', 'shutdown_idle')
EXPECTED = '190f6457d88258809df90a042b0226dab5537a1984f708cfd5bb90005835cea2'


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    value = hashlib.sha256()
    with open(path, 'rb') as source:
        while block := source.read(8192):
            value.update(block)
    return value.hexdigest()


def check_manifest(path, expected):
    require(digest(path) == expected, 'review manifest identity differs')
    manifest = json.loads(path.read_text())
    for root, expected_files in manifest['trees'].items():
        actual = {str(p.relative_to(root)) for p in Path(root).rglob('*') if p.is_file()}
        require(actual == set(expected_files), 'tree inventory differs: ' + root)
        for name, value in expected_files.items():
            require(digest(Path(root) / name) == value, 'tree input identity differs: ' + name)
    for name, value in manifest['inputs'].items():
        require(digest(name) == value, 'input identity differs: ' + name)
    require(manifest['state'] == 'ready-for-independent-review', 'manifest not review ready')
    checked_path(__file__, manifest['runner'], manifest['inputs'])
    checked_path(manifest['wire'], manifest['wire'], manifest['inputs'])
    checked_path(manifest['helper'], manifest['helper'], manifest['inputs'])
    return manifest


def checked_path(actual, expected, inputs):
    require(Path(actual).absolute() == Path(expected).absolute(), 'executing source path differs')
    require(Path(actual).resolve() == Path(expected).absolute(), 'source path resolves elsewhere')
    require(expected in inputs and digest(actual) == inputs[expected], 'executing source hash differs')


def load_bound(name, path, inputs):
    checked_path(path, path, inputs)
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, 'module loader unavailable')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    checked_path(module.__file__, path, inputs)
    return module


def new_capture():
    return {'lock': threading.Lock(), 'bytes': bytearray(), 'overflow': False, 'error': None}


def capture_fragment(capture, data):
    with capture['lock']:
        room = 65536 - len(capture['bytes'])
        capture['bytes'].extend(data[:room])
        if len(data) > room:
            capture['overflow'] = True


def capture_snapshot(capture):
    with capture['lock']:
        return bytes(capture['bytes']), capture['overflow'], capture['error']


def check_capture(capture):
    _, overflow, error = capture_snapshot(capture)
    require(not overflow, 'server output exceeds 65536 bytes')
    require(error is None, 'server output collector failed: ' + str(error))


def drain_capture(pipe, capture):
    try:
        while data := os.read(pipe.fileno(), 8192):
            capture_fragment(capture, data)
    except BaseException as exc:
        with capture['lock']:
            capture['error'] = repr(exc)
    finally:
        try:
            pipe.close()
        except BaseException as exc:
            with capture['lock']:
                capture['error'] = repr(exc)


def cleanup_actions(actions):
    errors = []
    for name, action in actions:
        try:
            action()
        except BaseException as exc:
            errors.append({'action': name, 'error': repr(exc)})
    return errors


def remaining(deadline):
    seconds = deadline - time.monotonic()
    require(seconds > 0, 'absolute deadline expired')
    return seconds


def child_start(pid):
    # comm can contain spaces or parentheses; the final ')' ends that field.
    text = Path('/proc', str(pid), 'stat').read_text()
    return text[text.rfind(')') + 2:].split()[19]


def owned_listener(pid):
    inodes = set()
    for entry in Path('/proc', str(pid), 'fd').iterdir():
        target = os.readlink(entry)
        if target.startswith('socket:['):
            inodes.add(target[8:-1])
    rows = Path('/proc/net/tcp').read_text().splitlines()[1:]
    return [row.split()[9] for row in rows if row.split()[1] == '0100007F:6F1B'
            and row.split()[3] == '0A' and row.split()[9] in inodes]


def wait_marker(child, capture, nonce, deadline):
    marker = ('H2_READY ' + nonce).encode()
    while True:
        check_capture(capture)
        require(child.poll() is None, 'child exited before readiness')
        data, _, _ = capture_snapshot(capture)
        if marker in data:
            listeners = owned_listener(child.pid)
            require(len(listeners) == 1, 'owned loopback listener not uniquely identified')
            return listeners[0]
        time.sleep(min(0.05, remaining(deadline)))


def flush(sock, protocol, deadline, capture):
    check_capture(capture)
    pending = protocol.data_to_send()
    if pending:
        sock.settimeout(remaining(deadline))
        sock.sendall(pending)


def receive(sock, protocol, records, trace, deadline, wire, capture):
    check_capture(capture)
    sock.settimeout(remaining(deadline))
    data = sock.recv(8192)
    require(data, 'TLS EOF before response completion')
    wire.accept(protocol, data, records, trace)
    flush(sock, protocol, deadline, capture)


def start(protocol, records, method, path, headers, end_stream, limit, wire):
    stream = protocol.get_next_available_stream_id()
    wire.register(records, stream, limit)
    protocol.send_headers(stream, [(':method', method), (':scheme', 'https'),
                                  (':authority', 'localhost'), (':path', path)] + headers,
                          end_stream=end_stream)
    return stream


def complete(sock, protocol, records, trace, stream, deadline, wire, capture):
    flush(sock, protocol, deadline, capture)
    while not records[stream]['ended'] or trace.get('_frames', {}).get('header', []) or trace.get('_frames', {}).get('remaining', 0):
        receive(sock, protocol, records, trace, deadline, wire, capture)
    record = records.pop(stream)
    require(record['reset'] is None and record['headers'] is not None, 'response terminal differs')
    require(record['trailers'] is None and record['informationals'] == 0, 'unexpected response metadata')
    require([v for k, v in record['headers'] if k == ':status'] == ['200'], 'status differs')
    return record


def request(sock, protocol, records, trace, path, deadline, wire, limit, capture):
    stream = start(protocol, records, 'GET', path, [], True, limit, wire)
    return complete(sock, protocol, records, trace, stream, deadline, wire, capture)


def summary(record):
    return {'headers': record['headers'], 'bytes': record['bytes'],
            'sha256': record['hash'].hexdigest(), 'body': bytes(record['body']).decode('utf-8', 'backslashreplace'),
            'ended': record['ended'], 'reset': record['reset']}


def record_bytes(record):
    return bytes(record['body'])


def status(sock, protocol, records, trace, tag, deadline, wire, capture):
    response = request(sock, protocol, records, trace, '/status/' + tag, deadline, wire, 1024, capture)
    return json.loads(record_bytes(response))


def control(sock, protocol, records, trace, action, tag, expected, deadline, wire, capture):
    response = request(sock, protocol, records, trace, '/control/' + action + '/' + tag,
                       deadline, wire, 64, capture)
    require(record_bytes(response) == expected.encode(), 'control result differs')


def payload_digest(helper, size):
    value = hashlib.sha256()
    for offset in range(0, size, 8192):
        value.update(helper.payload_block(size, offset, min(8192, size - offset)))
    return value.hexdigest()


def assert_record(record, tag, accepted, paused, ended, expected_hash=None):
    require(record['tag'] == tag and record['accepted'] == accepted, 'record identity or accepted differs')
    require(record['attempts'] == 1 and record['begin'] == 1 and record['end'] == int(ended) and record['cancel'] == 0,
            'record lifecycle differs')
    require(record['active'] != ended and record['paused'] == paused and record['errors'] == 0,
            'record state or diagnostics differ')
    require(record['callback_checks'] == 2 * (1 + record['chunks']), 'callback diagnostics differ')
    require(record['terminal_checks'] == (2 if ended else 0), 'terminal diagnostics differ')
    require(record['max_span'] <= 8192, 'span exceeds bound')
    if expected_hash is not None:
        require(record['sha256'] == expected_hash, 'record hash differs')


def require_upload_pending(record):
    require(not record['ended'], 'upload final before resume')
    require(record['headers'] is None, 'upload final headers before resume')


def barrier(sock, protocol, records, trace, tag, stream, accepted, deadline, wire, capture):
    while True:
        observed = status(sock, protocol, records, trace, tag, deadline, wire, capture)
        require_upload_pending(records[stream])
        if observed['accepted'] == accepted and observed['paused']:
            assert_record(observed, tag, accepted, True, False)
            return observed
        require(observed['accepted'] <= accepted and observed['end'] == 0 and observed['cancel'] == 0,
                'unexpected state while waiting for pause')
        remaining(deadline)


def finish_upload(sock, protocol, records, trace, stream, tag, size, deadline, wire, helper, capture):
    response = complete(sock, protocol, records, trace, stream, deadline, wire, capture)
    observed = json.loads(record_bytes(response))
    assert_record(observed, tag, size, False, True, payload_digest(helper, size))
    after = status(sock, protocol, records, trace, tag, deadline, wire, capture)
    require(after == observed, 'terminal status differs from upload response')
    return observed


def start_upload(protocol, records, tag, wire):
    return start(protocol, records, 'POST', '/upload/' + tag, [], False, 1024, wire)


def pause_case(sock, protocol, records, trace, deadline, wire, helper, case, capture):
    sizes = {'partial_pause': 12289, 'final_pause': 32, 'begin_pause_empty': 0}
    size = sizes[case]
    stream = start_upload(protocol, records, case, wire)
    first = 8192 if case == 'partial_pause' else size
    protocol.send_data(stream, helper.payload_block(size, 0, first) if first else b'',
                       end_stream=case != 'partial_pause')
    first_barrier = barrier(sock, protocol, records, trace, case, stream,
                            7 if case == 'partial_pause' else size, deadline, wire, capture)
    if case == 'begin_pause_empty':
        require(first_barrier['chunks'] == 0, 'empty upload delivered a chunk')
    if case == 'partial_pause':
        protocol.send_data(stream, helper.payload_block(size, first, size - first), end_stream=True)
        second = barrier(sock, protocol, records, trace, case, stream, 7, deadline, wire, capture)
        require(second == first_barrier, 'paused state changed after queued EOF')
    control(sock, protocol, records, trace, 'resume', case, 'ok', deadline, wire, capture)
    final = finish_upload(sock, protocol, records, trace, stream, case, size, deadline, wire, helper, capture)
    return {'before_resume': first_barrier, 'final': final}


def control_case(sock, protocol, records, trace, deadline, wire, helper, capture):
    first = start_upload(protocol, records, 'control_one', wire)
    before = status(sock, protocol, records, trace, 'control_one', deadline, wire, capture)
    assert_record(before, 'control_one', 0, False, False)
    control(sock, protocol, records, trace, 'resume', 'control_one', 'BodyNotPaused', deadline, wire, capture)
    require(status(sock, protocol, records, trace, 'control_one', deadline, wire, capture) == before,
            'not-paused refusal mutated state')
    protocol.send_data(first, helper.payload_block(32, 0, 32), end_stream=True)
    one = finish_upload(sock, protocol, records, trace, first, 'control_one', 32, deadline, wire, helper, capture)
    second = start_upload(protocol, records, 'control_two', wire)
    before_two = status(sock, protocol, records, trace, 'control_two', deadline, wire, capture)
    assert_record(before_two, 'control_two', 0, False, False)
    for action in ('resume', 'cancel'):
        control(sock, protocol, records, trace, action, 'control_one', 'BodyControlExpired', deadline, wire, capture)
    require(status(sock, protocol, records, trace, 'control_one', deadline, wire, capture) == one and
            status(sock, protocol, records, trace, 'control_two', deadline, wire, capture) == before_two,
            'stale control mutated state')
    protocol.send_data(second, helper.payload_block(32, 0, 32), end_stream=True)
    two = finish_upload(sock, protocol, records, trace, second, 'control_two', 32, deadline, wire, helper, capture)
    for tag in ('control_one', 'control_two'):
        for action in ('resume', 'cancel'):
            control(sock, protocol, records, trace, action, tag, 'BodyControlExpired', deadline, wire, capture)
    require(status(sock, protocol, records, trace, 'control_one', deadline, wire, capture) == one and
            status(sock, protocol, records, trace, 'control_two', deadline, wire, capture) == two,
            'terminal stale control mutated state')
    return {'first': one, 'second': two}


def run(args, manifest):
    helper = load_bound('h2_client', manifest['helper'], manifest['inputs'])
    wire = load_bound('wire', manifest['wire'], manifest['inputs'])
    import h2
    import hpack
    import hyperframe
    for module in (h2, hpack, hyperframe):
        require(Path(module.__file__).resolve().is_relative_to(Path(PACKAGES)), 'client module origin differs')
    require(Path(helper.__file__).resolve() == Path(HELPER) / 'h2_client.py', 'helper origin differs')
    overall = time.monotonic() + 900
    run_dir = Path(args.output).resolve()
    run_dir.mkdir(mode=0o700)
    cert, key, log = run_dir / 'certificate.pem', run_dir / 'private-key.pem', run_dir / 'server.log'
    nonce = os.urandom(16).hex()
    result = {'nonce': nonce, 'cases': {}, 'success': False, 'cleanup': {},
              'python': sys.executable, 'python_path': sys.path, 'openssl': OPENSSL,
              'profile': manifest['binary'], 'manifest_sha256': args.manifest_sha256}
    child = None
    sock = None
    start_id = None
    error = None
    capture = new_capture()
    collector = None
    try:
        command = [OPENSSL, 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '1',
                   '-subj', '/CN=localhost', '-addext', 'subjectAltName=DNS:localhost',
                   '-keyout', str(key), '-out', str(cert)]
        result['certificate_command'] = command
        subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True,
                       timeout=remaining(overall))
        os.chmod(key, 0o600)
        cert_der = ssl.PEM_cert_to_DER_cert(cert.read_text())
        result['certificate_sha256'] = hashlib.sha256(cert_der).hexdigest()
        env = {'H2_PROFILE_CERT': str(cert), 'H2_PROFILE_KEY': str(key), 'H2_PROFILE_NONCE': nonce}
        result['child_argv'] = [manifest['binary']]
        result['child_environment'] = env.copy()
        child = subprocess.Popen([manifest['binary']], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
        collector = threading.Thread(target=drain_capture, args=(child.stdout, capture), daemon=True)
        collector.start()
        start_id = child_start(child.pid)
        result['child'] = {'pid': child.pid, 'start': start_id, 'binary_sha256': digest(manifest['binary'])}
        deadline = min(overall, time.monotonic() + 15)
        result['listener_inode'] = wait_marker(child, capture, nonce, deadline)
        require(child_start(child.pid) == start_id and child.poll() is None, 'owned child changed')
        context = ssl.create_default_context(cafile=str(cert))
        context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_3
        context.set_alpn_protocols(['h2'])
        raw = socket.create_connection(('127.0.0.1', PORT), timeout=remaining(deadline))
        try:
            raw.settimeout(remaining(deadline))
            sock = context.wrap_socket(raw, server_hostname='localhost', suppress_ragged_eofs=False)
        except BaseException:
            raw.close()
            raise
        require(sock.version() == 'TLSv1.3' and sock.selected_alpn_protocol() == 'h2', 'TLS/ALPN differs')
        require(hashlib.sha256(sock.getpeercert(binary_form=True)).hexdigest() == result['certificate_sha256'],
                'peer certificate identity differs')
        require(child.poll() is None and child_start(child.pid) == start_id, 'owned child died')
        result['tls'] = {'version': sock.version(), 'alpn': sock.selected_alpn_protocol()}
        protocol, records, trace = helper.new_protocol(), {}, {}
        flush(sock, protocol, deadline, capture)
        health = request(sock, protocol, records, trace, '/health', deadline, wire, 2, capture)
        require(record_bytes(health) == b'ok', 'initial health differs')
        result['initial_health'] = summary(health)
        for case in args.cases:
            if case == 'shutdown_idle':
                continue
            deadline = min(overall, time.monotonic() + 30)
            if case == 'control_rules':
                value = control_case(sock, protocol, records, trace, deadline, wire, helper, capture)
            else:
                value = pause_case(sock, protocol, records, trace, deadline, wire, helper, case, capture)
            health = request(sock, protocol, records, trace, '/health', deadline, wire, 2, capture)
            require(record_bytes(health) == b'ok', 'post-case health differs')
            result['cases'][case] = value
        require(not records, 'response stream remains active')
        sizes = {'partial_pause': 12289, 'final_pause': 32, 'begin_pause_empty': 0,
                 'control_one': 32, 'control_two': 32}
        selected = set(args.cases) - {'shutdown_idle', 'control_rules'}
        if 'control_rules' in args.cases:
            selected.update(('control_one', 'control_two'))
        final = {tag: status(sock, protocol, records, trace, tag, min(overall, time.monotonic() + 30), wire, capture)
                 for tag in sizes}
        for tag, size in sizes.items():
            if tag in selected:
                assert_record(final[tag], tag, size, False, True, payload_digest(helper, size))
            else:
                require(final[tag] == {'tag': tag, 'accepted': 0, 'sha256': hashlib.sha256(b'').hexdigest(),
                                       'attempts': 0, 'begin': 0, 'end': 0, 'cancel': 0, 'chunks': 0,
                                       'max_span': 0, 'active': False, 'paused': False,
                                       'callback_checks': 0, 'terminal_checks': 0, 'errors': 0},
                        'unused record changed')
        require(sum(item['begin'] for item in final.values()) == len(selected) and
                sum(item['end'] for item in final.values()) == len(selected) and
                sum(item['cancel'] for item in final.values()) == 0 and
                sum(item['attempts'] for item in final.values()) == len(selected) and
                not any(item['active'] for item in final.values()), 'aggregate lifecycle differs')
        result['final_status'] = final
        result['events'] = trace
        sock.close()
        sock = None
        require(child_start(child.pid) == start_id and child.poll() is None, 'child identity changed')
        os.kill(child.pid, signal.SIGTERM)
        exit_code = child.wait(timeout=remaining(min(overall, time.monotonic() + 15)))
        result['cleanup'] = {'signal': 'SIGTERM', 'exit_code': exit_code, 'reaped': True, 'forced': False}
        require(exit_code == 0, 'owned server exit differs')
        collector.join(timeout=remaining(overall))
        require(not collector.is_alive(), 'server output collector did not finish')
        check_capture(capture)
        text = capture_snapshot(capture)[0].decode('utf-8')
        require('H2_DEINIT ' + nonce + ' attempts=' + str(len(selected)) +
                ' failed=0 errors=0 active={ false, false }' in text,
                'post-deinit aggregate differs')
        post = {}
        for line in text.splitlines():
            marker = 'H2_RECORD ' + nonce + ' '
            if marker in line:
                item = json.loads(line.split(marker, 1)[1])
                require(item['tag'] not in post, 'duplicate post-deinit tag')
                post[item['tag']] = item
        require(post == final, 'post-deinit records differ')
        result['cases']['shutdown_idle'] = {'exit_code': exit_code, 'post_deinit': True}
        result['success'] = True
    except BaseException as exc:
        error = repr(exc)
    finally:
        def close_socket():
            if sock is not None:
                sock.close()

        def signal_child():
            if child is None or child.poll() is not None:
                return
            require(start_id is None or child_start(child.pid) == start_id, 'child identity changed during cleanup')
            result['cleanup']['forced'] = True
            child.kill()

        def wait_child():
            if child is None:
                return
            child.wait(timeout=15)
            result['cleanup']['exit_code'] = child.returncode
            result['cleanup']['reaped'] = True

        def delete_key():
            key.unlink(missing_ok=True)

        def save_log():
            if collector is not None:
                collector.join(timeout=15)
            data, overflow, collector_error = capture_snapshot(capture)
            log.write_bytes(data)
            require(collector is None or not collector.is_alive(), 'server output collector did not finish')
            require(not overflow and collector_error is None, 'server output collection failed or overflowed')

        def close_pipe():
            if child is not None and child.stdout is not None:
                child.stdout.close()

        errors = cleanup_actions((('socket', close_socket), ('child_signal', signal_child),
                                  ('child_wait', wait_child), ('key', delete_key), ('log', save_log),
                                  ('pipe', close_pipe)))
        if errors or result['cleanup'].get('forced', False):
            result['success'] = False
        result['cleanup']['errors'] = errors
        result['error'] = error
        (run_dir / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    require(result['success'], 'owned run failed: ' + str(error))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', action='store_true', required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--cases', nargs='+', choices=CASES, required=True)
    args = parser.parse_args()
    require(sys.executable == PYTHON and sys.dont_write_bytecode and sys.flags.no_site and os.environ.get('PYTHONPATH') == PACKAGES + ':' + HELPER,
            'Python interpreter or PYTHONPATH differs')
    require(len(set(args.cases)) == len(args.cases) and args.cases[-1] == 'shutdown_idle', 'invalid case order')
    output = Path(args.output)
    require(output.is_absolute() and output.resolve().is_relative_to(Path('/tmp')) and output.resolve() != Path('/tmp'), 'output must be new /tmp path')
    require(not output.exists(), 'output already exists')
    manifest = check_manifest(args.manifest, args.manifest_sha256)
    run(args, manifest)


if __name__ == '__main__':
    main()
