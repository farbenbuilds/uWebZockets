"""Bounded metadata case; import performs no I/O."""
CASES = ('metadata_helpers', 'shutdown_idle')
TAGS = ('metadata_helpers',) + tuple('spare_%02d' % i for i in range(31))
GROUPS = {'metadata_helpers': ('metadata_helpers',)}


def selected_tags(cases):
    return {'metadata_helpers'} if 'metadata_helpers' in cases else set()


def expected(tag, selected, empty_hash, _credit_hash):
    touched = tag in selected
    return {'tag': tag, 'middleware': int(touched), 'attempts': int(touched), 'begin': int(touched),
            'end': int(touched), 'cancel': 0, 'failure': 0, 'accepted': 32 if touched else 0,
            'sha256': '7f0c5881a9ae2683debba016a4786b6c08dc684c5a334fa0b9876e6e32c390b5' if touched else empty_hash,
            'active': False, 'paused': False, 'reason': 'none', 'metadata_middleware': int(touched),
            'helpers_begin': int(touched), 'helpers_end': int(touched), 'metadata_begin': int(touched),
            'metadata_end': int(touched), 'errors': 0}


def verify_record(actual, expected_record):
    for key, value in expected_record.items():
        if actual.get(key) != value:
            raise ValueError('record ' + expected_record['tag'] + ' field ' + key + ' differs')
    if set(actual) != set(expected_record) | {'chunks', 'max_span'}:
        raise ValueError('record fields differ')
    chunks, span = actual['chunks'], actual['max_span']
    if not isinstance(chunks, int) or not isinstance(span, int) or chunks < 0 or not 0 <= span <= 8192:
        raise ValueError('chunk statistics out of bounds')
    if expected_record['accepted'] == 0 and (chunks or span):
        raise ValueError('unexpected empty record chunk')
    if expected_record['accepted'] and (not chunks or not span):
        raise ValueError('missing accepted chunk')


def execute(api, case):
    if case != 'metadata_helpers':
        raise ValueError('unsupported case')
    tag = case
    target = '/meta/metadata_helpers/' + '/'.join('a%02d' % i for i in range(1, 17)) + '?q=alpha&n=17'
    headers = [('x-mode', 'begin_paused')] + [('x-h%02d' % i, 'v%02d' % i) for i in range(63)]
    stream = api['start']('meta', tag, 32, target, headers)
    for offset in (0, 16):
        api['send'](stream, 32, offset, 16, False)
        if offset == 16:
            api['trailers'](stream, [('x-h62', 'changed'), ('x-trailer-only', 'discarded')])
        observed = api['status'](tag)
        if (observed['begin'], observed['accepted'], observed['chunks'], observed['end'], observed['cancel'], observed['paused']) != (1, 0, 0, 0, 0, True):
            raise ValueError('paused barrier differs')
        api['pending'](stream)
    api['resume'](tag)
    api['finish'](stream)
