const std = @import("std");
const uz = @import("uWebZockets");
const Hash = std.crypto.hash.sha2.Sha256;
const config: uz.ServerConfig = .{
    .max_connections = 8,
    .stream_request_bodies = true,
    .max_request_line_size = 512,
    .max_header_size = 4096,
    .max_header_count = 80,
    .max_body_size = 256,
    .max_h2_body_size = 4096,
    .max_h2_header_block_size = 8192,
    .max_h2_response_header_size = 4096,
    .max_h2_response_header_count = 32,
    .max_route_params = 24,
    .write_queue_size = 65536,
    .enable_dev_log = false,
};
const tags = [_][]const u8{
    "metadata_helpers",
    "spare_00",
    "spare_01",
    "spare_02",
    "spare_03",
    "spare_04",
    "spare_05",
    "spare_06",
    "spare_07",
    "spare_08",
    "spare_09",
    "spare_10",
    "spare_11",
    "spare_12",
    "spare_13",
    "spare_14",
    "spare_15",
    "spare_16",
    "spare_17",
    "spare_18",
    "spare_19",
    "spare_20",
    "spare_21",
    "spare_22",
    "spare_23",
    "spare_24",
    "spare_25",
    "spare_26",
    "spare_27",
    "spare_28",
    "spare_29",
    "spare_30",
};
const Record = struct {
    token: ?uz.BodyControl = null,
    hash: Hash = Hash.init(.{}),
    bytes: u64 = 0,
    chunks: u32 = 0,
    max_span: usize = 0,
    middleware: u32 = 0,
    attempts: u32 = 0,
    begins: u32 = 0,
    ends: u32 = 0,
    cancels: u32 = 0,
    failures: u32 = 0,
    errors: u32 = 0,
    active: bool = false,
    paused: bool = false,
    reason: ?uz.BodyCancelReason = null,
    metadata_middleware: u32 = 0,
    helpers_begin: u32 = 0,
    helpers_end: u32 = 0,
    metadata_begin: u32 = 0,
    metadata_end: u32 = 0,
    partial_done: bool = false,
};
const Slot = struct { record: ?*Record = null, owner: *State = undefined, index: usize = 0 };
const State = struct {
    slots: [2]Slot = [_]Slot{.{}} ** 2,
    records: [32]Record = [_]Record{.{}} ** 32,
    buffered_middleware: u32 = 0,
    errors: u32 = 0,
};
fn tag_index(tag: []const u8) ?usize {
    for (tags, 0..) |candidate, i| if (std.mem.eql(u8, tag, candidate)) return i;
    return null;
}
fn account_body_head(state: *State, request: *const uz.Request) void {
    const tag = request.get_param("tag") orelse {
        state.errors += 1;
        return;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return;
    };
    if (index != 0) {
        state.errors += 1;
        return;
    }
    state.records[index].middleware += 1;
    if (!legacy_metadata_matches(request)) {
        state.records[index].errors += 1;
        return;
    }
    state.records[index].metadata_middleware += 1;
}
fn middleware(context: *anyopaque, request: *uz.Request, response: *uz.Response) uz.MiddlewareResult {
    const state: *State = @ptrCast(@alignCast(context));
    if (std.mem.startsWith(u8, request.path, "/meta/")) {
        account_body_head(state, request);
    } else state.buffered_middleware += 1;
    response.append_header("X-Middleware", "retained") catch {
        state.errors += 1;
        return .stop;
    };
    return .continue_dispatch;
}
const Pair = struct { name: []const u8, value: []const u8 };
const Payload = union { value: []const u8, count: u64 };
const expected_path = "/meta/metadata_helpers/a01/a02/a03/a04/a05/a06/a07/a08/a09/a10/a11/a12/a13/a14/a15/a16";
const expected_target = expected_path ++ "?q=alpha&n=17";
const expected_headers = [_]Pair{
    .{ .name = "content-length", .value = "32" },
    .{ .name = "x-mode", .value = "begin_paused" },
    .{ .name = "x-h00", .value = "v00" },
    .{ .name = "x-h01", .value = "v01" },
    .{ .name = "x-h02", .value = "v02" },
    .{ .name = "x-h03", .value = "v03" },
    .{ .name = "x-h04", .value = "v04" },
    .{ .name = "x-h05", .value = "v05" },
    .{ .name = "x-h06", .value = "v06" },
    .{ .name = "x-h07", .value = "v07" },
    .{ .name = "x-h08", .value = "v08" },
    .{ .name = "x-h09", .value = "v09" },
    .{ .name = "x-h10", .value = "v10" },
    .{ .name = "x-h11", .value = "v11" },
    .{ .name = "x-h12", .value = "v12" },
    .{ .name = "x-h13", .value = "v13" },
    .{ .name = "x-h14", .value = "v14" },
    .{ .name = "x-h15", .value = "v15" },
    .{ .name = "x-h16", .value = "v16" },
    .{ .name = "x-h17", .value = "v17" },
    .{ .name = "x-h18", .value = "v18" },
    .{ .name = "x-h19", .value = "v19" },
    .{ .name = "x-h20", .value = "v20" },
    .{ .name = "x-h21", .value = "v21" },
    .{ .name = "x-h22", .value = "v22" },
    .{ .name = "x-h23", .value = "v23" },
    .{ .name = "x-h24", .value = "v24" },
    .{ .name = "x-h25", .value = "v25" },
    .{ .name = "x-h26", .value = "v26" },
    .{ .name = "x-h27", .value = "v27" },
    .{ .name = "x-h28", .value = "v28" },
    .{ .name = "x-h29", .value = "v29" },
    .{ .name = "x-h30", .value = "v30" },
    .{ .name = "x-h31", .value = "v31" },
    .{ .name = "x-h32", .value = "v32" },
    .{ .name = "x-h33", .value = "v33" },
    .{ .name = "x-h34", .value = "v34" },
    .{ .name = "x-h35", .value = "v35" },
    .{ .name = "x-h36", .value = "v36" },
    .{ .name = "x-h37", .value = "v37" },
    .{ .name = "x-h38", .value = "v38" },
    .{ .name = "x-h39", .value = "v39" },
    .{ .name = "x-h40", .value = "v40" },
    .{ .name = "x-h41", .value = "v41" },
    .{ .name = "x-h42", .value = "v42" },
    .{ .name = "x-h43", .value = "v43" },
    .{ .name = "x-h44", .value = "v44" },
    .{ .name = "x-h45", .value = "v45" },
    .{ .name = "x-h46", .value = "v46" },
    .{ .name = "x-h47", .value = "v47" },
    .{ .name = "x-h48", .value = "v48" },
    .{ .name = "x-h49", .value = "v49" },
    .{ .name = "x-h50", .value = "v50" },
    .{ .name = "x-h51", .value = "v51" },
    .{ .name = "x-h52", .value = "v52" },
    .{ .name = "x-h53", .value = "v53" },
    .{ .name = "x-h54", .value = "v54" },
    .{ .name = "x-h55", .value = "v55" },
    .{ .name = "x-h56", .value = "v56" },
    .{ .name = "x-h57", .value = "v57" },
    .{ .name = "x-h58", .value = "v58" },
    .{ .name = "x-h59", .value = "v59" },
    .{ .name = "x-h60", .value = "v60" },
    .{ .name = "x-h61", .value = "v61" },
    .{ .name = "x-h62", .value = "v62" },
    .{ .name = "host", .value = "localhost" },
};
const expected_params = [_]Pair{
    .{ .name = "tag", .value = "metadata_helpers" },
    .{ .name = "p01", .value = "a01" },
    .{ .name = "p02", .value = "a02" },
    .{ .name = "p03", .value = "a03" },
    .{ .name = "p04", .value = "a04" },
    .{ .name = "p05", .value = "a05" },
    .{ .name = "p06", .value = "a06" },
    .{ .name = "p07", .value = "a07" },
    .{ .name = "p08", .value = "a08" },
    .{ .name = "p09", .value = "a09" },
    .{ .name = "p10", .value = "a10" },
    .{ .name = "p11", .value = "a11" },
    .{ .name = "p12", .value = "a12" },
    .{ .name = "p13", .value = "a13" },
    .{ .name = "p14", .value = "a14" },
    .{ .name = "p15", .value = "a15" },
    .{ .name = "p16", .value = "a16" },
};
fn optional_equal(actual: ?[]const u8, expected: []const u8) bool {
    return if (actual) |a| std.mem.eql(u8, a, expected) else false;
}
fn metadata_matches(request: *const uz.StreamingRequest) bool {
    if (!std.mem.eql(u8, request.method, "POST") or !std.mem.eql(u8, request.target, expected_target) or
        !std.mem.eql(u8, request.path, expected_path) or !std.mem.eql(u8, request.query, "q=alpha&n=17") or request.protocol.len != 0) return false;
    if (request.headers.names.len != 64 or request.headers.extra_names.len != 2 or request.params.names.len != 16 or request.params.extra_names.len != 1) return false;
    var entries = request.headers.entries();
    for (expected_headers) |expected| {
        const entry = entries.next() orelse return false;
        if (!std.ascii.eqlIgnoreCase(entry.name, expected.name) or !std.mem.eql(u8, entry.value, expected.value) or !optional_equal(request.headers.get(expected.name), expected.value)) return false;
    }
    if (entries.next() != null or request.headers.get("x-trailer-only") != null or request.params.get("P16") != null) return false;
    for (expected_params, 0..) |expected, index| {
        const names = if (index < 16) request.params.names else request.params.extra_names;
        const values = if (index < 16) request.params.values else request.params.extra_values;
        const offset = if (index < 16) index else index - 16;
        if (!std.mem.eql(u8, names[offset], expected.name) or !std.mem.eql(u8, values[offset], expected.value) or !optional_equal(request.params.get(expected.name), expected.value)) return false;
    }
    return true;
}
fn legacy_metadata_matches(request: *const uz.Request) bool {
    if (!metadata_matches(&uz.StreamingRequest.from_request(request))) return false;
    var entries = request.header_entries();
    for (expected_headers) |expected| {
        const entry = entries.next() orelse return false;
        if (!std.ascii.eqlIgnoreCase(entry.name, expected.name) or !std.mem.eql(u8, entry.value, expected.value) or !optional_equal(request.get_header(expected.name), expected.value)) return false;
    }
    if (entries.next() != null) return false;
    for (expected_params) |expected| if (!optional_equal(request.get_param(expected.name), expected.value)) return false;
    return request.get_param("P16") == null;
}
fn helpers_match(request: *const uz.StreamingRequest) bool {
    if (request.text().len != 0 or request.bytes().len != 0) return false;
    var storage: [0]u8 = .{};
    var allocator = std.heap.FixedBufferAllocator.init(&storage);
    const memory = allocator.allocator();
    var issue = uz.schema.Issue{ .field = "untouched", .kind = .too_deep };
    const pointer = issue.field.ptr;
    const length = issue.field.len;
    const json: uz.BodyReadError!std.json.Parsed(Payload) = request.json(Payload, memory);
    const validated: uz.BodyReadError!std.json.Parsed(Payload) = request.validate_json(Payload, memory);
    const detailed: uz.BodyReadError!std.json.Parsed(Payload) = request.validate_json_detailed(Payload, memory, &issue);
    const form: uz.BodyReadError!uz.query.QueryParams = request.form();
    const multipart: uz.BodyReadError!uz.multipart.Parser = request.multipart();
    if (json != error.BodyNotBuffered or validated != error.BodyNotBuffered or detailed != error.BodyNotBuffered or form != error.BodyNotBuffered or multipart != error.BodyNotBuffered) return false;
    if (issue.field.ptr != pointer or issue.field.len != length or !std.mem.eql(u8, issue.field, "untouched") or issue.kind != .too_deep or allocator.end_index != 0) return false;
    const query = request.query_params() catch return false;
    const query_two = request.query_params_of(2) catch return false;
    return optional_equal(query.get("q"), "alpha") and optional_equal(query.get("n"), "17") and optional_equal(query_two.get("q"), "alpha") and optional_equal(query_two.get("n"), "17");
}
fn begin(context: *anyopaque, request: *const uz.StreamingRequest, token: uz.BodyControl) !uz.BodyBinding {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.params.get("tag") orelse {
        state.errors += 1;
        return error.MissingTag;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return error.InvalidTag;
    };
    if (index != 0) {
        state.errors += 1;
        return error.SpareTag;
    }
    const record = &state.records[index];
    record.attempts += 1;
    if (!metadata_matches(request)) {
        record.errors += 1;
        record.failures += 1;
        return error.MetadataMismatch;
    }
    record.metadata_begin += 1;
    if (!helpers_match(request)) {
        record.errors += 1;
        record.failures += 1;
        return error.HelpersMismatch;
    }
    record.helpers_begin += 1;
    if (record.attempts != 1 or record.middleware != 1) {
        record.errors += 1;
        record.failures += 1;
        return error.DuplicateTag;
    }
    for (&state.slots) |*slot| {
        if (slot.record != null) continue;
        slot.* = .{ .owner = state, .record = record, .index = index };
        record.token = token;
        record.begins += 1;
        record.active = true;
        record.paused = true;
        return .{ .context = slot, .readiness = if (record.paused) .paused else .ready };
    }
    record.failures += 1;
    record.errors += 1;
    return error.NoFixtureSlot;
}
fn chunk(context: *anyopaque, input: []const u8) !uz.BodyProgress {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    record.max_span = @max(record.max_span, input.len);
    record.chunks += 1;
    const consumed = input.len;
    record.hash.update(input[0..consumed]);
    record.bytes += consumed;
    return .{ .consumed = consumed, .readiness = if (record.paused) .paused else .ready };
}
fn format_record(record: *const Record, tag: []const u8, output: []u8) ![]const u8 {
    var copy = record.hash;
    var digest: [Hash.digest_length]u8 = undefined;
    copy.final(&digest);
    const hex = std.fmt.bytesToHex(digest, .lower);
    const reason = if (record.reason) |value| @tagName(value) else "none";
    return std.fmt.bufPrint(output, "{{\"tag\":\"{s}\",\"middleware\":{d},\"attempts\":{d},\"begin\":{d},\"end\":{d},\"cancel\":{d},\"failure\":{d},\"accepted\":{d},\"sha256\":\"{s}\",\"chunks\":{d},\"max_span\":{d},\"active\":{any},\"paused\":{any},\"reason\":\"{s}\",\"metadata_middleware\":{d},\"helpers_begin\":{d},\"helpers_end\":{d},\"metadata_begin\":{d},\"metadata_end\":{d},\"errors\":{d}}}", .{ tag, record.middleware, record.attempts, record.begins, record.ends, record.cancels, record.failures, record.bytes, hex, record.chunks, record.max_span, record.active, record.paused, reason, record.metadata_middleware, record.helpers_begin, record.helpers_end, record.metadata_begin, record.metadata_end, record.errors });
}
fn end(context: *anyopaque, request: *const uz.StreamingRequest, response: *uz.Response) !void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse return error.MissingRecord;
    if (!metadata_matches(request)) {
        record.errors += 1;
        return error.MetadataMismatch;
    }
    record.metadata_end += 1;
    if (!helpers_match(request)) {
        record.errors += 1;
        return error.HelpersMismatch;
    }
    record.helpers_end += 1;
    record.ends += 1;
    record.active = false;
    record.paused = false;
    record.token = null;
    slot.record = null;
    var output: [1024]u8 = undefined;
    try response.text(try format_record(record, tags[slot.index], &output));
}
fn cancel(context: *anyopaque, reason: uz.BodyCancelReason) void {
    const slot: *Slot = @ptrCast(@alignCast(context));
    const record = slot.record orelse {
        slot.owner.errors += 1;
        return;
    };
    record.cancels += 1;
    record.reason = reason;
    record.active = false;
    record.paused = false;
    record.token = null;
    slot.record = null;
}
fn health(_: *uz.Request, response: *uz.Response) void {
    response.text("ok") catch |err| std.log.err("health: {}", .{err});
}
fn status(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.get_param("tag") orelse {
        state.errors += 1;
        return;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return;
    };
    var output: [1024]u8 = undefined;
    const body = format_record(&state.records[index], tags[index], &output) catch {
        state.errors += 1;
        return;
    };
    response.text(body) catch {
        state.errors += 1;
    };
}
const Totals = struct {
    middleware: u64 = 0,
    attempts: u64 = 0,
    begins: u64 = 0,
    ends: u64 = 0,
    cancels: u64 = 0,
    failures: u64 = 0,
    accepted: u64 = 0,
    active: u32 = 0,
    errors: u64 = 0,
};
fn totals(state: *const State) Totals {
    var result: Totals = .{ .errors = state.errors };
    for (state.records) |record| {
        result.middleware += record.middleware;
        result.attempts += record.attempts;
        result.begins += record.begins;
        result.ends += record.ends;
        result.cancels += record.cancels;
        result.failures += record.failures;
        result.accepted += record.bytes;
        result.errors += record.errors;
        result.active += @intFromBool(record.active);
    }
    return result;
}
fn format_totals(state: *const State, output: []u8) ![]const u8 {
    const t = totals(state);
    return std.fmt.bufPrint(output, "{{\"middleware\":{d},\"attempts\":{d},\"begin\":{d},\"end\":{d},\"cancel\":{d},\"failure\":{d},\"accepted\":{d},\"active\":{d},\"errors\":{d},\"buffered_middleware\":{d},\"slot0_active\":{any},\"slot1_active\":{any}}}", .{ t.middleware, t.attempts, t.begins, t.ends, t.cancels, t.failures, t.accepted, t.active, t.errors, state.buffered_middleware, state.slots[0].record != null, state.slots[1].record != null });
}
fn metrics(context: *anyopaque, _: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    var output: [1024]u8 = undefined;
    const body = format_totals(state, &output) catch {
        state.errors += 1;
        return;
    };
    response.text(body) catch {
        state.errors += 1;
    };
}
fn control(context: *anyopaque, request: *uz.Request, response: *uz.Response) void {
    const state: *State = @ptrCast(@alignCast(context));
    const tag = request.get_param("tag") orelse {
        state.errors += 1;
        return;
    };
    const index = tag_index(tag) orelse {
        state.errors += 1;
        return;
    };
    const token = state.records[index].token orelse {
        state.errors += 1;
        return;
    };
    if (!state.records[index].paused) {
        state.errors += 1;
        return;
    }
    state.records[index].paused = false;
    token.@"resume"() catch {
        state.errors += 1;
        response.text("error") catch {
            state.errors += 1;
        };
        return;
    };
    response.text("ok") catch {
        state.errors += 1;
    };
}
pub fn main(init: std.process.Init) !void {
    const certificate = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_CERT") orelse return error.MissingCertificate);
    const key = try init.arena.allocator().dupeZ(u8, init.environ_map.get("H2_PROFILE_KEY") orelse return error.MissingKey);
    const nonce = init.environ_map.get("H2_PROFILE_NONCE") orelse return error.MissingNonce;
    if (nonce.len == 0 or nonce.len > 64) return error.InvalidNonce;
    var state: State = .{};
    const sink: uz.BodySink = .{ .context = &state, .begin = begin, .chunk = chunk, .end = end, .cancel = cancel };
    var upload: uz.BodyRoute = .{ .sink = sink, .limits = .{ .max_body_bytes = 100000000, .max_active = 2 }, .middleware_policy = .headers_only };
    {
        var server = try uz.Server.preset(init.io, config).build_https(init.arena.allocator(), certificate, key);
        defer server.deinit();
        _ = try server.use(&state, middleware);
        _ = try server.route_body(.post, "/meta/:tag/:p01/:p02/:p03/:p04/:p05/:p06/:p07/:p08/:p09/:p10/:p11/:p12/:p13/:p14/:p15/:p16", &upload);
        _ = try server.get("/health", health);
        _ = try server.get_context("/status/:tag", &state, status);
        _ = try server.get_context("/metrics", &state, metrics);
        _ = try server.get_context("/resume/:tag", &state, control);
        std.log.info("H2_CAPACITY config={f} request_stride={d} h2_bytes={d} h2_stride={d} slab={d} router={d}", .{ std.json.fmt(config, .{}), try config.request_buffer_stride(), try config.h2_session_bytes(), try config.h2_session_stride(), try config.slab_bytes(), try config.router_storage_bytes() });
        try server.listen("127.0.0.1", 28443);
        try server.catch_shutdown_signals();
        std.log.info("H2_READY {s}", .{nonce});
        try server.run();
    }
    for (&state.records, 0..) |*record, i| {
        var output: [1024]u8 = undefined;
        std.log.info("H2_RECORD {s} {s}", .{ nonce, try format_record(record, tags[i], &output) });
    }
    var output: [1024]u8 = undefined;
    std.log.info("H2_DEINIT {s} {s}", .{ nonce, try format_totals(&state, &output) });
}
