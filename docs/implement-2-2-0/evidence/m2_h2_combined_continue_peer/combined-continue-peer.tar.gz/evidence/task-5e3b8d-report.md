# Continue/quota shared peer preparation — task 5e3b8d

DONE for the assigned synthetic source slice; independent Root review and publication remain pending.

The bound base is `c50542f9a80f2c7237592c7adc2ac4e7b34bd860`, supplied by Root. No Git operation was performed. The fresh pre-edit 40-source map matched `docs/implement-2-2-0/evidence/m2_h2_combined_admission_peer/manifest.json` exactly. Constructor extraction implements remaining-peer plan unit4, under the shared contract and aggregate acceptance notes. No ownership or interface gap was found.

## Exact scope and files

The only changed member of the 40-source inventory is:

- `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py`, SHA256 `0a0e06a79ec1dde2c7c9007e08a3e20d6e977e868625726435f0363322ebc4ce`.

All new evidence lives in `.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/continue-peer/` (called `UNIT` below). Its current executable helpers are:

- `capture.py`: exact subprocess command/environment/cwd, source40 maps, source text, AST, stdout/stderr and exit recorder; pre-edit freeze.
- `proofs.py`: opt-in direct causal, rejection, bounded-storage, retained-reference and actual shared-chain proofs.
- `audit.py`: input identity, all-source structure/guards, current-helper strict/accepted depths, inert imports/empty/foreign argv, covering receipt binding, original direct proof preservation, and exhaustive prior-history preservation.

The remaining new files are immutable baseline/source copies, recorded command/source/raw/exit receipts, restoration receipts, audit outputs, intermediate helper/prefix text, and Graphify stdout/stderr/exit. This report is the only other authored path. Historical text files are retained snapshots, not executable current helpers. No handler, model, catalogue, fixture, codec, pin, product source, public limit or other test module was edited.

## Implementation and causal facts

`new_peer(case, *, app, prior, now, clock, final=False, fault=None)` supports exactly the four existing NAMES and returns exactly `{connection,state}`. Connection keys remain `protocol/send/receive/now/owned/tls/alpn`; owned/TLSv1.3/h2 remain explicitly supplied synthetic facts. Validation precedes protocol/state construction; no constructor clock call, dispatch, observation, final collection, selected completion, or application mutation occurs. Startup SETTINGS/ACK are queued for ordinary receive.

`check()` keeps its signature and same-app return, now using canonical `test_core_peer.new_app()` with records/heads/outputs/binding. Prior records, actual head totals, output observations and binding are validated without seeding prior results. Output/binding references survive. The old nested peer, selected `completed()` recipe, path/metric histories and separate payload dictionaries are deleted.

Exact decoded HEADERS earn middleware/admission/begin/active facts only. Each upload keeps bounded scalar count/frame/END/terminal/informational flags and one rolling SHA256. Continue delivery is earned only when receive returns its informational frame; attempting DATA against queued Continue rejects before upload/application facts mutate. Exact32 DATA/END earns wire facts. The paused case keeps accepted bytes/chunks/ends zero until actual delivered paused-status followed by resume; resume releases its slot and completes the accepted32/hash/terminal facts. The admission-family immutable schema has no callback_checks/terminal_checks keys; canonical zero-prefix and terminal behavior is preserved without adding schema fields.

Quota uses two explicit slots. Actual holder HEADERS fill both; the first delivered metric earns active2. Refusal503 has no begin/body/100 and queues final HEADERS before NO_ERROR reset. Holder ENDs release both before active0; two recovery HEADERS and ENDs earn active2 then active0. Bounded metric cursors require the exact2/0/2/0 sequence and delivery barriers. Failed begin acquires a real slot, records attempts1/failures1/begins0, releases that slot, and permits recovery to reuse it. No selected model completion recipe or client capture/context supplies peer truth.

All nine finite faults retain the exact diagnostics. Wrong-failure and other-record corrupt only their final status observation, leaving canonical persistent facts intact. Paused-byte and active-count faults likewise affect only their named observation. Early-final emits a premature terminal observation without falsely completing application state; its narrowly scoped pending status allowance preserves the original `invalid terminal` client diagnostic. Original `before_continue()` is byte-for-byte unchanged and remains a separate direct client-boundary proof.

Bounds: parser8201; send/frame payload8192; pending at most two packets/16384 bytes, each <=8192; HPACK table/list4096; uploads at most1/2/5 according to the finite case; exactly two slot cells; receive count <=head_limit+2 and bytes <=(head_limit+2)*8192. Online finite schedule, exact stream IDs/flags/header order/metadata and DATA ordinals reject before earned facts or retained growth. No path/frame/read/metric history or whole-body retention exists.

Final permission alone is inert. The actual four-case chain earns all prior facts from traffic and completes final68 with total heads91. Final collection uses the existing protocol, raw parser, request/credit ledgers, stage, cumulative read/byte caps, case/whole deadlines and outstanding debt; retained parsed final observations are required. An explicitly labeled supplied producer-history fixture separately proves output/binding reference retention and makes no claim to prior producer traffic.

## Preparation and workflows

Read actual AGENTS.md, CODING_CONVENTION.md, developer role, shared plan/unit4, aggregate acceptance notes, and applicable using-agent-skills, incremental-implementation, test-driven-development, api-and-interface-design, codebase-design, Graphify and code-review-and-quality instructions. Relevant truncated convention/TDD/interface content was recovered in focused reads. Applied project overrides and the existing accepted admission-peer recorder/audit patterns. No subagents, external model CLI, native/build/server/network/old-runtime/Git/publication operations were used.

Before editing source or acceptance RED, `restore-freeze.json` verified the pinned inputs, and `capture.py --freeze` retained all40 exact source bytes/hashes, the immutable119 authority, and the exhaustive prior-evidence hash map excluding only UNIT. That map contains10,486 files. Every subsequent dependent Python command used same-shell Root restoration with a new absolute receipt and the pinned interpreter with -B -S; optimized subprocess checks additionally use -O.

## Exact commands and retained outcomes

Workspace cwd for shell orchestration: `/workspaces/uWebZockets`.
Recorded check subprocess cwd: `/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases` (`ROOT`).
Pinned interpreter (`PY`): `/home/codespace/.python/current/bin/python3`, SHA256 `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`.

For every row NAME below the actual same-shell execution was:

```sh
set -e
/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore /workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/continue-peer/restore-NAME.json
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases /home/codespace/.python/current/bin/python3 -B -S .uwz-work/evidence/h2-streaming/integration-owned/combined-cases/evidence/continue-peer/capture.py --run NAME MODULE MODE ARGS
```

MODULE was the workspace-relative path to the indicated file under ROOT; capture resolves and records its exact absolute pathname. MODE was `normal` or `optimized`. Each `NAME/command.json` contains the exact complete subprocess environment (only the two explicit environment keys), argv, cwd and matching absolute restoration receipt. Each directory also contains `source-before.json`, `source-after.json`, `test_continue_quota.py.txt`, `check-source.txt`, `capture-source.txt`, `structure.txt`, separate `stdout.txt`/`stderr.txt`, and `exit.json`. The recorder itself exits0 after saving a failing child; the table reports actual child exits, never recorder success as proof success.

| NAME | MODULE | MODE | ARGS | child exit |
|---|---|---|---|---:|
| red-constructor | UNIT/proofs.py | normal | --constructor | 1 |
| red-delivery | UNIT/proofs.py | normal | --baseline-delivery | 1 |
| green-constructor | UNIT/proofs.py | normal | --constructor | 0 |
| green-schedules | ROOT/test_continue_quota.py | normal | none | 1 |
| green-delivery | UNIT/proofs.py | normal | --delivery | 0 |
| green-schedules-fixed | ROOT/test_continue_quota.py | normal | none | 0 |
| green-direct | UNIT/proofs.py | normal | --check | 1 |
| green-direct-primary | UNIT/proofs.py | normal | --check | 0 |
| cover-continue-normal | ROOT/test_continue_quota.py | normal | none | 0 |
| cover-continue-optimized | ROOT/test_continue_quota.py | optimized | none | 0 |
| cover-imports-normal | ROOT/test_imports.py | normal | none | 0 |
| cover-imports-optimized | ROOT/test_imports.py | optimized | none | 0 |
| strict-direct-normal | UNIT/proofs.py | normal | --check | 0 |
| strict-direct-optimized | UNIT/proofs.py | optimized | --check | 0 |
| strict-audit-normal | UNIT/audit.py | normal | --audit UNIT/strict-audited-normal | 0 |
| strict-audit-optimized | UNIT/audit.py | optimized | --audit UNIT/strict-audited-optimized | 0 |
| final-direct-normal | UNIT/proofs.py | normal | --check | 0 |
| final-direct-optimized | UNIT/proofs.py | optimized | --check | 0 |
| final-audit-normal | UNIT/audit.py | normal | --audit UNIT/final-audited-normal | 0 |
| final-audit-optimized | UNIT/audit.py | optimized | --audit UNIT/final-audited-optimized | 0 |

All successful child checks above have empty stderr. All failed/intermediate commands/source/raw remain retained. The four `cover-*` module checks ran after the last source edit and bind the final source40 map. The final direct/audit pair was repeated only after deleting an unused proof import and updating the audit's final receipt names; source40 did not change.

RED/GREEN interpretation:

1. `red-constructor`: AttributeError for missing new_peer. This is pre-effect constructor absence, not a behavioral defect.
2. `red-delivery`: executes frozen accepted legacy check and injects exact DATA through its transport after original adapter.start returns, before receive. Fails `queued Continue allowed DATA before delivery`. This is the observed behavioral defect; current `green-delivery` and final proofs reject `DATA before delivered Continue` without earning upload facts.
3. `green-schedules`: all ordinary/shared and earlier faults passed; early_final failed with the new peer barrier `request before preceding response` instead of historical `invalid terminal`. This actual failing source/receipt preceded the narrowly scoped fault-observation correction. `green-schedules-fixed` and both final module checks preserve all exact diagnostics.
4. `green-direct`: proof setup omitted canonical primary selection, causing `invalid primary` before its intended upload. This is a proof defect, not peer behavior. `green-direct-primary` and final direct runs correct the finite primary tag choice and pass.

All source-edit Python executions had separate same-shell restorer receipts: `restore-edit-peer.json`, `restore-edit-early-final.json`, `restore-edit-proofs.json`, `restore-edit-primary.json`, `restore-edit-audit.json`, `restore-edit-unused-import.json`. Historical helper text before meaningful edits is retained; actual check-source snapshots bind every failed/intermediate executable proof version.

Graphify queries preceded new codebase questions using the required supplied binary/environment and --budget650. Queries concerned Continue/admission recorder/audits, canonical Continue/model/core transitions, and adapter transport context. The graph returned truncated scoped results; located authoritative raw files supplied the exact contracts. Final same-shell restored Graphify command:

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify update .
```

`graphify.stdout.txt`, `graphify.stderr.txt`, `graphify.exit.txt`, and `restore-graphify.json` retain the result: exit0, no relevant indexed changes, graph left untouched. It reported388 unclassified skipped files. This was AST-only, with no LLM/API token cost; no semantic update or API call was performed. Final hash verification used `sha256sum` on the changed source and three current helpers.

## Verification and self-review

Both final audits established:

- Immutable authority119, physical rows118, unique resolved files113, ordered codec files42; codec list digest `0f85bd19e3af0e20c135b960d3a16361662c2ae32a256cc8df6e7be283cde473`; pinned interpreter hash as above.
- Inventory40, exactly one source changed and39 unchanged; original direct before_continue function preserved exactly.
- All40 source AST/convention structure and main guards; normal/-O test_imports execution proved inert imports. Maximum accepted source control depth3, with no classes/assert/global/module mutable containers.
- All10,486 historical evidence entries match the fresh pre-edit exhaustive map exactly, with no historical additions/removals/changes outside UNIT.
- All three CURRENT unit helpers pass both accepted and strict depth checks: capture1/1, audit2/2, proofs3/3. All are inert under import and main with empty and foreign argv; no historical live-helper exemption is used.
- Four final module/import checks and two current direct proofs bind exact source40 before/after, exit0, empty stderr, correct normal/-O flags and same-shell restoration identity receipts.

The direct proofs exercise constructor pre-effect semantics; invalid shape/prior/clock/fault/heads; actual delivered informational rather than queue state; zero-prefix pause and actual status/resume; rollback/recovery; exact refusal HEADERS then reset0/no100/body; actual two-slot metrics; malformed headers/streams/flags/DATA repeatedly before facts; parser/pending/read/HPACK bounds repeatedly before growth; actual shared four-case chain; early/unpermitted final rejection; same connection/parser/ledgers/debt/deadlines/cumulative caps and retained final capture; explicit supplied producer output/binding retention. Proof wrappers invoke originals exactly once, preserve their original return/error priority and restore instrumentation in finally. The error-identity/restoration proof intentionally makes the original adapter.start fail and checks object identity and call count.

Self-review used the five correctness/readability/architecture/security/performance axes. The public seam stays the accepted serialized connection; standalone drivers reuse it and peer code never reads client state. Explicit finite schedules and small upload/slot state replace retained histories; no new dependency or production parsing layer is added. Exact header/body/hash/END/slot validation precedes earned facts. Model functions remain contract/expected-value validation only; no touched-record recipe manufactures peer completion. Fault-specific observations remain constrained. One unused copied proof import was removed, then affected direct/helper audits rerun. No remaining implementation finding was identified by this self-review; it does not replace independent Root review.

## Remaining scope and limitations

This proves synthetic in-memory source peer preparation only. It does not execute actual default/all40 coordinator acceptance, native fixture/callback behavior, real process/socket/TLS ownership, strict close, native scheduling/fault/race/leak/panic/crash probes, product adoption, or M2/full2.2.0 acceptance. All are still required later. Project formatting/conventions/release-version/Zig tests and all native/platform/compliance/package/fork gates were not run under this explicit no-native/build slice and remain mandatory at their released phase. No gate was weakened or claimed passed.

Root owns fresh independent source/spec/quality review, publication accuracy, commit plus immediate push and clean postpush audit before releasing the next serial unit. The full goal remains active.
