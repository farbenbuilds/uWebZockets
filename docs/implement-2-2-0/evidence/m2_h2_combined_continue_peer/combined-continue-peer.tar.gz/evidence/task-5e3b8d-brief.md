# Shared independent Continue/quota peer

Released after 8c review/publication/commit/immediate push. BASE:
c50542f9a80f2c7237592c7adc2ac4e7b34bd860.
Accepted current40 manifest:
docs/implement-2-2-0/evidence/m2_h2_combined_admission_peer/manifest.json.
Root commit audit: task-5e3b8c-root-commit-audit.json in this plan directory.

Implement remaining-peer plan unit4 in task-5e3b-all40-peer-plan-report.md.
Read its shared contract/unit4 and task-5e3b-aggregate-acceptance-notes.md.
This is standalone synthetic peer preparation; actual default/all40, native,
adoption and M2 acceptance remain later mandatory gates.

Own ONLY
/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/test_continue_quota.py,
NEW evidence/continue-peer under that same directory and
/workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8d-report.md.
Inventory remains40, one changed39unchanged. No other source/handler/model/core/
fixture/codec/pin/product/limit edits. Report an exact additional ownership/API
gap BEFORE editing. You are not alone: preserve others and all historical bytes.
No Git/publication/native/network/agents; Root owns review/commit+immediate push.

Promote new_peer(case, *, app, prior, now, clock, final=False, fault=None) for
continue_ready, continue_paused, quota_refuse, begin_failure_rollback.
Return exactly {connection,state}, with exact seven-key connection
protocol/send/receive/now/owned/tls/alpn and pinned initialized protocol plus
supplied owned=True/TLSv1.3/h2 facts. Queue startup SETTINGS/ACK for ordinary
receive. No constructor clock/client dispatch/observe/final/app mutation or
selected completion. Validate all arguments before state effects.

Use exact canonical app4 records/heads/outputs/binding and
test_core_peer.new_app(); prior validates earned facts, never seeds them.
Preserve output/binding references. Keep NAMES, check(case, *, app=None,
prior=(), final=False, fault=None) and same app return. Upgrade default app
from old2keys to canonical4keys, no speculative legacy adapter. Delete old
nested peer, model-selected completed recipe and path/metrics/frame/read
histories; use bounded online schedule/metric cursors and upload summaries.

Facts must follow exact decoded validated metadata/DATA/END/control actions.
HEADERS earns metadata/admission/begin/active facts without future body/end/
failure/resume facts. An admitted Continue emits100 before positive DATA;
DATA requires actual delivered informational response, not merely queueing
or an info-set entry at HEADERS. Check before mutation. continue_paused's
32-byte END earns paused facts and completes only after actual status/resume;
preserve zero accepted prefix and callback/terminal contracts.

quota_refuse requires exactly two active slots, refusal503/no body/no100/
finalHEADERS before NO_ERROR reset, recovery and exact active metric sequence
2,0,2,0 from actual slot facts. begin_failure_rollback records attempt/failure
without a begin and actually rolls back its slot before recovery. Derive all
body/hash/counter/slot/END and failure facts independently, never use selected
model completion recipes or client context as peer truth. Preserve exact
headers/expect/content-length, wire bodies32END where applicable, hashes/
ordinals/request counts and unselected-record contamination checks.

Preserve before_continue() as its original separate direct client-boundary
proof, not an extra serialized schedule. Preserve four standalone cases and
actual four-case shared sequence/final68. Preserve ALL exact fault diagnostics:
wrong_failure -> record mismatch: failures (final);
other_record -> record mismatch: middleware (final);
missing_continue -> invalid DATA;
refusal_continue -> invalid HEADERS;
refusal_data -> response body bound;
reset_first -> reset order;
active_count -> quota active barrier differs;
paused_bytes -> record mismatch: bytes;
early_final -> invalid terminal.
Finite faults affect only the named observation. Execute frozen accepted Python
baseline if an observed legacy diagnostic is uncertain; preserve it, no guesses.

Online exact metadata/stream/flag/order/active-slot/Continue/pause barriers before
facts. Parser8201/frame/send8192/HPACK caps and finite pending/packet/read/stream
bounds derived from existing policies/schedules; rejection before growth and on
repeat. Keep generated/queued/delivered facts separate. Final permission alone
does nothing; require ordinary/recovery completion, same protocol/parser/
ledgers/debt/readcaps/deadlines and actual final68. Metrics aggregate actual
records/heads/slots. Peer never observes client capture/context. Any driver proof
wrapper calls original once, preserves original result/error priority, restores
instrumentation on failure. No new forwarding layer or unbounded history.

Before editing: read actual AGENTS.md, CODING_CONVENTION.md, developer role and
narrow incremental/TDD/API/codebase-design workflows plus accepted context.
Use Graphify before a NEW codebase question/search/read; supplied paths are
located. Freeze the exact accepted current 40 sources and 119-input identity,
and a fresh exhaustive prior-evidence hash map excluding only this new unit.
Freeze before actual acceptance RED; constructor absence is a pre-effect RED,
not a behavioral defect. Each discovered defect needs the real source/RED
before its fix; preserve every failed/intermediate command/source/raw artifact.

After last source edit retain FOUR focused checks: test_continue_quota.py and
test_imports.py, each normal and -O. Other suites only for an identified
dependency or unanswered concern. Add meaningful direct constructor/prior/
metadata-vs-DATA/refusal-order/final/bounds/retention proofs as needed. Actual
shared prior cases must be earned from traffic; supplied fixtures remain
explicitly synthetic. Every check has exact argv/env/cwd, 40-source before and
after maps, separate stdout/stderr/exit and same-shell restoration receipt.
All 40 source AST/import guards, all CURRENT unit helper nesting <=3 and inert
import/empty/foreign argv, 119 authority/118 physical/113 resolved/42 ordered
codecs, frozen source and prior-history preservation must be audited. No live
helper is exempt as historical; preserve old bytes before correcting it. No
classes/assert/custom exceptions/global mutable containers/dead code/camelCase/
silenced errors/forwarding wrappers or weakened bounds, tests or lint.

Temporary inputs reset across continuations. EACH dependent Python proof,
audit or check exec_command shell must start with set -e and run the Root
restorer below, with a NEW absolute receipt, then its operation IN THAT SAME
SHELL. Never infer persistence from a prior Root command.

/home/codespace/.python/current/bin/python3 -B -S /workspaces/uWebZockets/.superpowers/sdd/h2_streaming_plan/task-5e3b8a-restore-inputs.py --restore NEW_ABSOLUTE_RECEIPT

Pinned interpreter SHA256:
4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601.
All direct Python, including source edits, uses this interpreter with -B -S;
optional -O for optimized. Exact PYTHONPATH:
/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases

Graphify invocation:
env PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/workspaces/uWebZockets/.uwz-work/tools/graphify /workspaces/uWebZockets/.uwz-work/tools/graphify/bin/graphify query "question" --budget 650

No native/build/server/socket/SSLContext/TLS-close/real-clock/process ownership/
kernel/fault scheduling/race/panic/crash/leak/old-runtime/install/network runs.
Only pinned in-memory codecs and supplied synthetic app/transport/process
facts. No additional named-skill drift is established by the known missing
generic DoD reference: explicit project gates/exact scope remain authoritative,
full native/project/platform gates mandatory later, not waived.

Write the full report at the owned report path: exact files/commands/raw/exits,
RED/GREEN chronology, all current source/check/input/history/helper audits,
self-review and actual gaps. Return concise DONE or specific concerns/context/
blocker under 15 lines. Remaining work alone is not missing context. Root owns
fresh source review, publication accuracy, commit and immediate push before
releasing the next serial peer unit. Full goal remains active.

