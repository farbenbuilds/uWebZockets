Prepare eight serial changes: extend the core peer for `async_delayed`, extract six remaining peer constructors, then add actual all40 coordinator acceptance. No implementation, tests, native operations, or P8 review occurred during this planning pass.

**Assumptions and scope**

- The aggregate acceptance notes, peer-extraction addendum, and `task-5e3b-coordinator-composition-plan-report.md` remain authoritative. The brief’s abbreviated `composition-plan-report.md` does not exist; the addendum supplied the resolved filename.
- The static inventory establishes symbol presence and source identities only. It does not establish constructor semantics or executed coverage.
- P8 remains independently owned. Its changing coordinator/composition/import files were not read. Root must finish that phase’s review before releasing any implementation described here.
- Existing reviewed core, lifecycle, producer, file, and shutdown peers remain the reuse basis. No production handler, model, catalogue, codec, fixture, public Zig API, dependency pin, ADR, or repository vocabulary change is proposed.
- This remains pure-client execution with synthetic supplied peer/application/process facts. It cannot establish native callback or fixture correctness.
- Root resolved the planning-workflow conflict: this is refinement of an accepted reversible pattern, so no manual grilling interview is required. I loaded the relevant instructions and used concrete internal risk questions. No skill-requested plan files or graph artifacts were written.
- All module paths below are relative to `/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases/`.

**Ownership and shared contract**

Verification should implement the test-peer and aggregate-harness changes. `http_protocol` should guide header/terminal ordering, padding, SETTINGS, credit, and reset-direction checks. The independent reviewer owns source/spec/quality review. Root owns serial release, shared-file coordination, evidence retention, and final integration. P8’s owner remains the sole implementer of P8.

Each new peer uses the accepted interface:

```python
new_peer(case, *, app, prior, now, clock, final=False, fault=None)
```

The core peer retains its existing signature without adding an unnecessary `fault` argument.

Every constructor:

- Returns exactly `{'connection', 'state'}`; connection retains exactly `protocol`, `send`, `receive`, `now`, `owned`, `tls`, `alpn`.
- Uses the accepted pinned protocol initialization pattern and supplied clock. Queues initial SETTINGS/ACK for ordinary receive; never calls `adapter.observe`, `open_case`, `run_case`, or final collection itself.
- Accepts the existing application shape: `records`, `heads`, `outputs`, `binding`. Reuse `test_core_peer.new_app()`; do not introduce competing application constructors.
- Validates `prior` against the persistent application without manufacturing prior results. All 67 records begin unselected. Preserve actual output observations and relative binding through every family.
- Earns facts at the applicable decoded metadata, DATA, control, or terminal transition. Creating a peer and advertising `final=True` must not select records or complete a schedule.
- Checks request order online with bounded cursors. Retains bounded parser/pending/HPACK storage, bounded stream summaries and incremental hashes; no request/frame/read histories or whole large payloads.
- Distinguishes a queued response/grant from bytes actually returned by receive.
- Permits final68 only after the concrete schedule, using the same connection, parser, ledgers, receive cap, debt, and deadlines.

The deep-module seam is the existing serialized connection interface returned by `new_peer`. Standalone drivers and coordinator tests must cross that same seam. The deletion test is concrete: moved nested peer code disappears from `check()`; deleting the shared peer would force serialized behavior and invariants back into both standalone and coordinator callers.

**Complete remaining-case mapping**

There are 28 remaining IDs. Existing reviewed constructors cover the other 12.

| Remaining IDs | Existing byte peer / canonical driver | Proposed public constructor |
|---|---|---|
| `async_delayed` | `test_async.py` delegates to `test_ready.check`; `adapter.run_case` has the concrete delayed schedule | Extend `test_core_peer.new_peer` |
| `partial_pause`, `final_pause`, `begin_pause_empty`, `control_rules` | `test_pause.check`; `pause_cases.run` | `test_pause.new_peer` |
| `empty_headers`, `empty_data`, `empty_declared`, `limit_declared`, `limit_undeclared`, `limit_declared_reject`, `limit_observed_reject`, `zero_declared_reject`, `zero_observed_reject` | `test_admission.check`; `admission_cases.run` | `test_admission.new_peer` |
| `continue_ready`, `continue_paused`, `quota_refuse`, `begin_failure_rollback` | `test_continue_quota.check`; `continue_quota_cases.run` | `test_continue_quota.new_peer` |
| `queued_trailers_padding`, `receive_credit` | `test_credit.check`; `credit_cases.run` | `test_credit.new_peer` |
| `metadata_helpers`, `concurrent_routes` | `test_metadata_concurrency.check`; `metadata_cases.run` and `concurrent_cases.run` | `test_metadata_concurrency.new_peer` |
| `cancel_ready`, `cancel_paused`, `peer_reset`, `sink_error`, `invalid_progress`, `end_error` | `test_control_reset.check` and `test_application_error.check`; their existing canonical handlers | New `test_terminal_peer.new_peer`, shared by both drivers |

Retain existing mappings unchanged: core ready/large three; lifecycle disconnect/reuse two; producer/pressure three; file/early two; shutdown two.

**Ordered implementation units**

1. **Add delayed-response reuse and retire the duplicate core peer.**

   Ownership: `test_core_peer.py`, `test_ready.py`; `test_async.py` remains the six-line proxy.

   Extend the core constructor for the exact health -> delayed -> health sequence, optional middleware handling, ten-byte response, zero request DATA, and final68. Preserve a distinct no-DATA completion condition; do not fake a DATA END to satisfy the existing upload guard.

   Convert `test_ready.check()` to drive the shared core constructor for its existing cases. Preserve its signature, `clock`, `after_case` behavior, final option, and all existing header/body/hash/count assertions. Existing imports of `test_ready.frame` must remain compatible without adding a forwarding abstraction.

   Acceptance: standalone ready, delayed, and both large schedules use the shared implementation; delayed adds no selected body record; final observations reflect the persistent application. Preserve ready/large late-refund behavior.

   Focused checks: `test_ready.py`, `test_async.py`, existing large driver and directly affected clock/final hooks, normal and optimized.

2. **Extract pause/control peers.**

   Ownership: `test_pause.py`.

   Preserve all four schedules, accepted-prefix checkpoints, empty END handling, stale controls, and shared application/final behavior. Replace retained path lists with exact online checks; preserve the wrong-tag failure boundary using a bounded cursor or equivalent fixed evidence.

   Keep existing `premature` and `wrong_tag` driver arguments, translating them into explicit peer fault modes. Do not broaden the constructor with arbitrary callbacks.

   Acceptance: partial pause requires both DATA ordinals; final/begin pause cannot complete before resume; wrong-tag rejection precedes control; all existing negative diagnostics remain exact. Final metrics aggregate actual persistent records.

   Focused checks: `test_pause.py`, including its standalone four cases, shared chain/final, wrong-tag, and premature-response controls.

3. **Extract admission peers.**

   Ownership: `test_admission.py`.

   Preserve the nine schedules and recovery requests. Declared refusal is earned from exact HEADERS; observed refusal follows the offending DATA. The 32-byte accepted-prefix status barrier must precede the 33rd byte.

   Acceptance: refusal final HEADERS precede NO_ERROR reset; no informational or body allowance appears; empty-HEADERS and empty-DATA cases remain distinct. Preserve `reset_first`, `continue`, `refusal_data`, and `bad_prefix` negatives and the complete nine-case shared sequence.

   Focused checks: `test_admission.py`.

4. **Extract Continue/quota peers.**

   Ownership: `test_continue_quota.py`.

   Keep explicit case handling for the two Continue schedules, two-slot quota exhaustion/recovery, and failed-begin rollback. Replace path/metrics histories with bounded order counters. Preserve the active-slot barriers and exact metric sequence `2,0,2,0`.

   Acceptance: DATA requires delivered Continue; paused completion requires the actual resume; refusals carry neither 100 nor response DATA; failed begin records attempts/failure without claiming a begin. Preserve `before_continue()` as its separate direct-boundary proof and every current fault case.

   Focused checks: `test_continue_quota.py`.

5. **Extract credit/trailer peers and correct transition timing.**

   Ownership: `test_credit.py`.

   Preserve logical-byte versus flow-byte accounting, trailer fields, seven padding bytes, separate connection/stream grants, and incremental hashes.

   Concrete extraction obligation: lines 85–88 currently install the paused checkpoint at upload HEADERS, including accepted-byte facts for queued trailers. Create only metadata/begin facts there; earn accepted-prefix/hash/chunk facts after the corresponding DATA arrives. Preserve the zero-accepted-byte paused behavior of `receive_credit`.

   Acceptance: queued trailers retain 12,289 logical bytes and 12,297 flow bytes; receive credit sends 65,535 bytes before the grant barrier and one final byte afterward. Missing stream credit still fails despite connection credit. Preserve paused-record corruption, both cases’ shared final, and exact trailer ordering.

   Focused checks: `test_credit.py`.

6. **Extract metadata/concurrency peers and relocate retention assertions.**

   Ownership: `test_metadata_concurrency.py`.

   Preserve the same peer for both cases, exact target/query, 66 initial headers including regular `host`, 17 captures, two DATA spans, trailers, and helper/metadata diagnostics.

   Concrete coupling: lines 164–171 inspect client records/raw/stage maps from inside the peer. Move those assertions into a driver-side wrapper at the corresponding actual health-request boundaries. The wrapper must invoke the original adapter operation exactly once, preserve results/errors, and restore instrumentation on failure. The peer independently enforces serialized order.

   Acceptance: refused stream retention remains proven at the original intermediate and final boundaries; concurrent holder/upload/recovery isolation remains exact. Preserve every helper/metadata, pause, refusal/reset, slot-count, resumed-prefix, contamination, and unselected-record negative.

   Keep the seven direct header controls explicitly qualified as oracle sensitivity checks, not additional serialized schedules.

   Focused checks: `test_metadata_concurrency.py`.

7. **Extract one shared terminal peer for six cases.**

   Ownership: new `test_terminal_peer.py`, `test_control_reset.py`, `test_application_error.py`.

   These peers genuinely share the stale-control -> refund -> sibling -> recovery -> stale-control machinery. One constructor should own it. Both existing drivers import it directly; do not add forwarding constructors in each driver.

   Keep explicit differences:

   - Public cancellation earns incoming CANCEL8.
   - `peer_reset` decodes outgoing CANCEL8 and must not increment incoming-reset totals.
   - Application failure earns incoming INTERNAL_ERROR2.
   - Sink/progress failures distinguish 15 transmitted bytes from seven accepted bytes; end failure handles its 32-byte END.
   - Preterminal status counts, paused/ready states, terminal diagnostics, recovery, and stale counters remain case-specific.

   Concrete coupling: `test_control_reset.py:108–113,194` and `test_application_error.py:107–112,200` inspect client context. Preserve retirement checks in driver wrappers before the first actual stale control; preserve sibling debt `1` immediately after the original `adapter.send_data` call. The peer uses its own decoded bytes and delivered-refund cursor.

   Concrete timing: `test_control_reset.py:156–160` currently installs seven accepted bytes during HEADERS for cancellation cases. Move those facts to validated DATA receipt.

   Acceptance: both old nested peers disappear; all six canonical handlers use this shared peer through standalone drivers and coordinator composition. Preserve every existing negative, split-reset proof, exact diagnostic, final contamination check, and recovery/hash check. Separate direction-specific reset and refund receipts.

   Focused checks: `test_control_reset.py`, `test_application_error.py`, plus inert-import coverage of the new helper.

8. **Add actual default/all40 aggregate acceptance after P8 and all peer reviews.**

   Ownership: new `test_all40.py` and the then-stable `test_imports.py`. No coordinator change is pre-authorized by this plan.

   Use an explicit private case-to-constructor selection in the test harness. Reuse existing lifecycle/shutdown hooks and accepted descriptors. Only the coordinator performs client dispatch. Never call family `check()` functions, replace handlers, seed prior model results, or infer execution from catalogue sums.

   Retain one application per child and one current peer per connection; keep bounded scalar receipts after release. Disconnect retains its required per-case evidence across two independent transport ledgers.

   Acceptance: omitted/default selection actually dispatches all40, and explicit all40 has matching semantics. Require independent peer receipts against canonical result counters, including raw refund directions, padding flow, response informationals, reset directions, and final observations. Catalogue values are expected values only.

   Focused checks: new all40 harness and import checks, normal and optimized; then the broad combined-client review and matrix specified below.

**Independent aggregate oracle**

Use bounded receipts earned where peers decode outgoing requests and construct/deliver incoming frames. Keep connection refunds, stream refunds, incoming resets, outgoing resets, informationals, decoded heads, request flow, payload hashes, and actual delivered bytes distinct.

Compare these independently earned receipts against the canonical coordinator/ledger summaries. Count a serialized frame once despite fragmented delivery, and distinguish queued bytes from delivered bytes. Retain only counts, sums, cursors, hashes, and bounded partial-frame state where the existing peer needs it. Do not introduce another production parser.

The accepted families’ exact available receipt fields were not exhaustively re-inspected. Their sufficiency is a targeted aggregate-preparation dependency. If a necessary scalar is absent, Root should release a narrow change to the owning peer; do not reopen all families or substitute catalogue totals.

**Final acceptance criteria**

The actual default run must establish:

- Idle first in its own fresh application, then 39 main IDs in caller order.
- Two children, 41 connections, 802 heads, 789 small responses, and request flow `200091899`.
- Main `733/720` heads/small; idle `69/69`.
- 46 client SETTINGS, two informationals, 13 incoming resets; outgoing peer-reset traffic is separate.
- Exactly two final collections. Active shutdown collects 67 records plus metrics before signal and performs no later collection.
- Main post-deinit metrics: middleware 67, attempts 62, begins 61, ends 52, cancels 9, failures 1, end_errors 1, chunk_errors 1, invalid_progress 1, errors 0, bytes `200091500`, active 0, paused 0, buffered_middleware 666. Pre-signal cancellation remains eight with the held active row.
- Selected-before state contains only successfully dispatched/released main cases. Constructors reject incompatible persistent state without seeding it.
- Both canonical 100,000,000-byte uploads, producer/file/output hashes, sentinel bytes, and range generation remain independently checked.
- Disconnect cumulative case counters are counted once; its connection-local statistics are counted separately. Final registrations contribute once.
- Ordinary `None` returns retain the original context; lifecycle/shutdown returned contexts and replacement receive hooks remain authoritative. Consume retained actual `final_observations` without additional GETs or regenerated “before” facts.
- Empty selection has no effects. Exercise idle-only, caller-ordered subsets, valid reorderings, malformed/unknown/duplicate/invalid shutdown selections before effects, subsets without active shutdown, and final large-debt cases.
- Preserve ready 15s, whole 900s, grace at most 15s, ordinary 30s/large 180s deadlines and their original handoffs. No refreshed final deadline, erased receive cap, borrowed credit, or unearned zero-debt requirement.
- Last-main carried debt remains bounded by 64. Whole receive bytes `5288609050` and refund frames `400183798` remain upper bounds, not observed traffic claims.

**Verification and unresolved boundaries**

For each released unit, use the supplied pinned interpreter and environment:

```text
env PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=/tmp/uwz-task5e1-contract-v3:/tmp/uwz-task5e3a-snapshot-v9/source:/tmp/uwz-h2-client-tooling/packages:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-client:/workspaces/uWebZockets/.uwz-work/evidence/h2-streaming/integration-owned/combined-cases \
/home/codespace/.python/current/bin/python3 -B -S MODULE
```

Repeat with `-O`; `MODULE` denotes the exact absolute focused module path. Interpreter SHA256 remains `4c275e98e459979b46ff33a08ab0e317db9267fecaffa01d3c70fd0a34711601`. Retain exact commands, source/identity snapshots, stdout/stderr, and every failed/intermediate receipt. Update import inventory only after P8 releases that shared file.

No missing immutable handler/core/model seam was established. Inspected canonical handlers already expose the actual adapter operations needed to relocate client-side assertions. The concrete gaps are constructor extraction, premature peer fact timing, bounded storage/order checks, context-oracle separation, and actual aggregate execution.

Independent source/spec/quality review and a broad final combined-client review remain required. Preserve original fixture qualifications and direct-oracle versus serialized-execution distinctions.

Project gates remain mandatory at their released execution phase: formatting, conventions, release-version synchronization, Zig tests, sanitizer/compile/fuzz/library/package-consumer gates, applicable protocol/platform/compliance gates, and all parent milestones. This Python harness work does not alter Zig 0.16.0, zero-allocation production paths, fixed capacities, native dependency compilation, or fork policy.

Runtime closure, strict-close/owned-process preparation, sequential two-child native acceptance, product adoption, and full milestone acceptance remain subsequent explicit Root releases. This report authorizes none of those operations and claims none passed.
