# Parent all40/default/aggregate acceptance handoff

Preparation notes only, not an implementation release or execution result.
The original cases brief/release addendum/accepted combined architecture and
immutable model/catalogue remain binding. Source coverage40 after B6d will not
by itself satisfy this parent acceptance or native/M2/full2.2.0 requirements.
Root must release the exact stable implementation scope after B6d review/push.

## Requirements rederived from immutable inputs

Root called catalogue.budgets/catalogue.child_plan/model.metrics using pinned
Python -B -S and the unchanged model. These are model-derived requirements,
not measured traffic or evidence that a child/connection was created:

- 40 case IDs,67 persistent main-child body records.
- Idle baseline first as a fresh child/app, then39 main IDs in caller order.
- Main has40 connections including disconnect replacement; idle adds1:41 total.
- 802 heads/789 small responses/R200091899; main733/720 and idle69/69.
- 46 settings,2 informationals,13 incoming resets; peer-reset outgoing direction
  is separate and must not be counted as an incoming reset.
- After main deinit: middleware67,attempts62,begins61,ends52,cancels9,failures1,
  end_errors1,chunk_errors1,invalid_progress1,errors0,bytes200091500,
  active0,paused0,buffered_middleware666. Pre-signal cancels8 and held active row.
- Two final collections. Last main connection carried-debt bound64.
- Whole receive_bytes5288609050/refund_frames400183798 are upper bounds, not
  expected actual traffic, memory allocations, or observed frame counts.
- Ready15s/whole900s/grace<=15s and remaining case/whole deadlines; ordinary30s,
  large180s. No fresh final-collection deadline or reset receive cap.

The immutable contract's combined_action_order_tested/startup_serialization
flags are historical contract fields, not results to overwrite. Record actual
source/pure-codec/native conclusions separately, with exact evidence scopes.

## Acceptance that must be exercised

Default dispatch must actually execute all40 concrete client schedules through
the canonical bound wire/codec/parser/request+response ledgers/stage, not merely
sum catalogue rows, union old checkpoints, seed model results or substitute a
generic successful handler. Actual serialized headers/DATA/flow/hashes/settings/
reset direction and finite observation order must account for global totals.
Model-derived peer body/diagnostic/process records remain supplied synthetic
inputs; an all40 pure-client pass cannot prove native fixture/callback behavior.

Main records and latest parsed output_observations/relative output_binding must
survive all fresh connection contexts; disconnect alone shares its per-case
objects across two independent transport ledgers. Idle state is a separate fresh
app, never a main teardown relabeled as the idle ID. Output pre/post validation
uses retained actual parsed values and later supplied post facts without extra
GETs. Active shutdown collects67+metrics once before signal, none afterward.

Exercise explicit empty selection (no child/connection/action/collection),
idle-only, arbitrary valid caller-ordered subsets, unknown/malformed/duplicate/
shutdown-order rejection before effects, subsets lacking active shutdown (one
extra final68 and ordinary idle teardown without earning shutdown_idle), and
subsets ending with large outstanding debt. Preserve the exact original parser,
ledgers/deadline/read-cap/debt across final boundary. Never require unearned late
debt zero or borrow one connection/scope's credit for another.

Prove selected-before state and the default path with actual dispatch. Seeded
prior model state is a synthetic precondition only, not execution of prior IDs.
No per-DATA/frame/read histories or whole large bodies; bounded summaries and
incremental hashes. Canonical100000000-byte payloads for both upload cases,
separate producer/file/output hashes and exact sentinel/range generation.

Check inert imports/main guards for every new coordinator/helper and exact
normal/O command/source/identity snapshots. Every failed/intermediate attempt
stays retained with accurate RED scope. Independent source/spec/quality review
and a broad final combined client review remain required before runtime release.

## Subsequent boundaries

Runtime/strict-close/owned process preparation is a later explicit Root release,
with stable source/compiler/helper/codecs/capacities/fork overrides and complete
runtime closure. No old live proof or unreviewed binary is executable evidence.
Sequential two-child native acceptance follows that review. Original native
fault/cancel/scheduling/descriptor/kernel/race/panic/leak probes remain stopped.
Product adoption and all project/platform/compliance/fork/release requirements
remain mandatory; no narrower source or synthetic success completes the goal.

## Canonical counter interpretation confirmed during B6d

Immutable output_stage.py keeps pre-final small responses in case_state.small
and final observations in stage.final_registered. HEADERS always increment
case_state.heads. For final_included cases the adapter's per-case comparison
therefore adds final_registered to small, preserving the unchanged catalogue
budgets. This is an interpretation of existing counters, not a new allowance.

Parent actual-traffic aggregation must also count every final observation once.
Default active/idle collections are already included in their case budgets;
ordinary subsets without active shutdown append their required final68 once.
Disconnect's two contexts share a case_state: count that case state once,
while keeping its two parser/connection/request/response ledgers independent.
Do not union per-connection copies of its cumulative case counters.

The accepted run_case returns a final context for lifecycle/shutdown handlers,
including disconnect replacement, and None for the ordinary handlers. Keep the
original ordinary context when the result is None; preserve returned lifecycle/
shutdown contexts. Disconnect replacement carries its own receive hook, which
must also be used for a later final collection on that connection. Retain
validated parsed output observations and binding across later fresh case
connections. A newly generated model record cannot substitute for retained
observed before facts or actual serialized dispatcher execution.

B6d's first report left ordinary final facts local while preserving its None
return; shutdown callers retained before facts in shutdown_observations.before.
Independent review identified ordinary capture retention as required current
shared-seam work. Approved fix rounds1/2 retain ordinary parsed records/metrics
immediately at context.final_observations with its None return unchanged.
Shutdown keeps the capture private through all teardown hooks and validation,
then publishes it at final_observations and shutdown_observations.before.
Parent subsets must consume this actual capture without another collection or
model substitution. Future teardown hooks must not receive mutable access to
their comparison baseline while it is still used for validation.
