"""Opt-in direct causal proofs for the supplied in-memory Continue peer."""
import copy
import catalogue
import hpack
import continue_quota_cases
from pathlib import Path
import sys
import adapter
import model
import test_continue_quota as peer
from test_core_peer import frame, new_app, require


def constructor():
    app = new_app()
    before = copy.deepcopy(app)

    def no_clock():
        raise RuntimeError('constructor called clock')

    result = peer.new_peer('continue_ready', app=app, prior=(), now=1, clock=no_clock, final=True)
    require(set(result) == {'connection', 'state'}, 'peer shape differs')
    require(set(result['connection']) == {'protocol', 'send', 'receive', 'now', 'owned', 'tls', 'alpn'}, 'connection shape differs')
    require(app == before, 'constructor changed app')
    require(result['state']['cursor'] == 0 and result['state']['pending'], 'constructor selected completion')
    print('constructor pre-effect, canonical application, startup queued')


def premature_delivery(driver):
    original = adapter.start
    seen = []

    def start(context, method, path, *args, **kwargs):
        stream = original(context, method, path, *args, **kwargs)
        if path != '/limit/continue_ready':
            return stream
        seen.append(stream)
        try:
            context['send'](frame(0, 1, stream, model.payload_span(32, 0, 32)))
        except ValueError as exc:
            require(str(exc) == 'DATA before delivered Continue', 'wrong delivery rejection')
        else:
            raise ValueError('queued Continue allowed DATA before delivery')
        return stream

    adapter.start = start
    try:
        driver('continue_ready')
    finally:
        adapter.start = original
    require(len(seen) == 1, 'missing delivery probe')
    print('queued Continue rejects DATA before delivery')


def baseline_delivery():
    path = Path(__file__).resolve().parent / 'baseline/test_continue_quota.py.txt'
    namespace = dict(__name__='frozen_baseline')
    exec(compile(path.read_text(), str(path), 'exec'), namespace)
    premature_delivery(namespace['check'])


def final_boundary(peer, context):
    state, stage = peer['state'], context['stage']
    identities = {name: context[name] for name in ('protocol', 'raw', 'request', 'credit', 'records', 'stage')}
    deadlines = stage['case_deadline'], stage['whole_deadline']
    reads, size = stage['reads'], stage['bytes']
    debt = context['request']['connection_debt'], context['request']['stream_debt_total']
    seen = [0, 0]

    def receive():
        result = peer['connection']['receive']()
        require(all(context[name] is value for name, value in identities.items()), 'final changed connection identities')
        require((stage['case_deadline'], stage['whole_deadline']) == deadlines, 'final refreshed deadlines')
        require(stage['reads'] == reads + seen[0] and stage['bytes'] == size + seen[1], 'final reset cumulative receive cap')
        seen[0] += 1
        seen[1] += len(result[0])
        return result

    require(adapter.final_collection(context, receive) is None, 'ordinary final return changed')
    require(state['final_requests'] == stage['final_registered'] == 68 and stage['final_complete'], 'final count differs')
    require((context['request']['connection_debt'], context['request']['stream_debt_total']) == debt, 'final erased debt')
    require(stage['reads'] == reads + seen[0] and stage['bytes'] == size + seen[1], 'final receive accounting')
    require('final_observations' in context, 'missing retained actual final capture')


def retained_supplied_fixture():
    # Explicit historical supplied facts; this does not execute producer_reuse.
    app = new_app()
    app['records'] = model.records(('producer_reuse',), 'before')
    for tag in ('producer_reuse', 'producer_reuse_next'):
        app['records'][tag].update(chunks=1, max_span=32)
    producer = app['outputs']['producer_reuse']
    producer.update(offset=16777313, invocations=2051, attempts=4099, writes=2049, blocked=2050,
                    pending=2050, terminal_attempts=1, terminals=1, checks=2051, after_reuse=1,
                    binding_index=0, binding_generation=7, armed=True, done=True, sha256=model.PRODUCER_HASH)
    app['binding'] = dict(tag='producer_reuse_next', binding_index=0, binding_generation=8)
    app['heads'] = catalogue.case_budget('producer_reuse')['heads']
    copied = copy.deepcopy(app)
    outputs, binding = copied['outputs'], copied['binding']
    supplied, peer, context = open_peer('continue_ready', app=copied, prior=('producer_reuse',), final=True, health=False)
    adapter.run_case(context, peer['connection']['receive'])
    final_boundary(peer, context)
    require(supplied is copied and copied['outputs'] is outputs and copied['binding'] is binding, 'retained references replaced')
    require(outputs == app['outputs'] and binding == app['binding'], 'supplied retained output or binding mutated')
    require(app['records']['continue_ready']['middleware'] == 0, 'copied application mutated original')
    print('explicit supplied historical producer fixture: copied retained outputs/binding preserved; no prior producer traffic claim')


def rejects(action, expected=None):
    try:
        action()
    except ValueError as exc:
        require(expected is None or str(exc) == expected, 'unexpected rejection: ' + str(exc))
        return
    raise ValueError('invalid action accepted')


def summary(state):
    return {tag: (item['count'], item['frames'], item['ends'], item['terminal'], item['digest'].hexdigest())
            for tag, item in state['uploads'].items()}


def send_head(result, entries, flags=5, stream=None):
    state = result['state']
    stream = 2 * state['cursor'] + 1 if stream is None else stream
    result['connection']['send'](frame(1, flags, stream, hpack.Encoder().encode(entries)))


def bounds():
    _app, result, _context = open_peer('continue_ready')
    state, send = result['state'], result['connection']['send']
    for _ in range(2):
        rejects(lambda: send(b'x' * 8193), 'send span differs')
        rejects(lambda: send((8193).to_bytes(3, 'big') + bytes(6)), 'frame payload bound differs')
        require(not state['buffer'], 'oversize grew parser')
    packet = frame(0, 0, 3, b'x' * 8192)
    send(packet[:8192])
    send(packet[8192:8200])
    before = bytes(state['buffer'])
    for _ in range(2):
        rejects(lambda: send(b'xx'), 'parser storage bound differs')
        require(bytes(state['buffer']) == before and state['max_buffer'] == 8200, 'parser overflow changed storage')
    _app, result, _context = open_peer('continue_ready')
    state = result['state']
    state['pending'][:] = [b'a' * 8192, b'b' * 8192]
    for _ in range(2):
        rejects(lambda: peer.respond(state, 1, b'c'), 'response queue or body bound differs')
        require(len(state['pending']) == 2 and sum(map(len, state['pending'])) == 16384, 'pending overflow')
    state['pending'][:] = [b'a' * 8193]
    rejects(result['connection']['receive'], 'pending packet bound differs')
    state['pending'][:] = [b'a']
    state['received'] = state['head_limit'] + 2
    for _ in range(2):
        rejects(result['connection']['receive'], 'receive bound differs')
        require(state['pending'] == [b'a'], 'read cap consumed pending')
    state['received'] = 0
    state['received_bytes'] = (state['head_limit'] + 2) * 8192
    rejects(result['connection']['receive'], 'receive byte bound differs')
    require(state['pending'] == [b'a'], 'byte cap consumed pending')
    print('parser8201, frame/payload8192, pending2/16384 and finite receive caps reject before growth repeatedly')


def hpack_limits():
    for payload in (hpack.Encoder().encode(((':path', 'a' * 4097),)), b'\x3f\xe2\x1f'):
        app, result, _context = open_peer('continue_ready', health=False)
        before = copy.deepcopy(app)
        for _ in range(2):
            try:
                result['connection']['send'](frame(1, 5, 1, payload))
            except hpack.HPACKError:
                require(app == before and result['state']['cursor'] == 0, 'HPACK earned facts')
                continue
            raise ValueError('HPACK overflow accepted')
    print('HPACK table/header-list bounds reject before facts twice')


def open_peer(case, final=False, *, app=None, prior=(), health=True):
    app = new_app() if app is None else app
    result = peer.new_peer(case, app=app, prior=prior, now=1, clock=lambda: 2, final=final)
    connection = result['connection']
    context = adapter.open_case(case, connection['protocol'], connection['send'], 1, 30001, 900001,
                                selected_before=prior, clock=lambda: 2)
    adapter.observe(context, *connection['receive']())
    if health:
        adapter.health(context, connection['receive'])
    return app, result, context


def start_upload(context, tag):
    return continue_quota_cases.start(context, tag, primary=tag in ('continue_ready', 'continue_paused', 'quota_holder_two', 'begin_failure'),
                                     expect=tag in ('continue_ready', 'continue_paused', 'quota_refuse', 'begin_failure'),
                                     refusal=tag in ('quota_refuse', 'begin_failure'), held=tag == 'continue_paused')


def constructor_rejections():
    changes = ({'case': 'ready_buffered'}, {'case': []}, {'prior': ('continue_paused',)}, {'prior': ('unknown',)},
               {'prior': ('continue_ready', 'continue_ready')}, {'final': 1}, {'fault': 'unknown'}, {'fault': []},
               {'fault': 'paused_bytes'}, {'now': True}, {'now': -1}, {'clock': None})
    for changed in changes:
        app = new_app()
        before = copy.deepcopy(app)
        args = dict(case='continue_ready', app=app, prior=(), now=1, clock=lambda: 2)
        args.update(changed)
        rejects(lambda: peer.new_peer(**args))
        require(app == before, 'invalid constructor mutated application')
    for key in ('records', 'heads', 'outputs', 'binding'):
        app = new_app()
        del app[key]
        before = copy.deepcopy(app)
        rejects(lambda: peer.new_peer('continue_ready', app=app, prior=(), now=1, clock=lambda: 2), 'app fields differ')
        require(app == before, 'shape rejection mutated application')
    app = new_app()
    app['heads'] = 3
    rejects(lambda: peer.new_peer('continue_ready', app=app, prior=(), now=1, clock=lambda: 2), 'prior heads not earned')
    print('case/prior/flags/faults/clock/shape/unearned heads reject before application mutation')


def continuation_timing():
    for case in ('continue_ready', 'continue_paused'):
        app, result, context = open_peer(case)
        state, connection = result['state'], result['connection']
        stream = start_upload(context, case)
        item = app['records'][case]
        require((item['middleware'], item['attempts'], item['begins'], item['bytes'], item['ends'], item['paused']) ==
                (1, 1, 1, 0, 0, False) and item['active'], 'metadata claimed body or terminal facts')
        before, counts = copy.deepcopy(app), summary(state)
        for _ in range(2):
            rejects(lambda: connection['send'](frame(0, 1, stream, model.payload_span(32, 0, 32))), 'DATA before delivered Continue')
            require(app == before and summary(state) == counts, 'undelivered Continue mutated facts')
        continue_quota_cases.wait_continue(context, connection['receive'], stream)
        require(state['informationals_queued'] == state['informationals_delivered'] == 1, 'Continue delivery receipts differ')
        adapter.send_data(context, stream, model.payload_span(32, 0, 32), True)
        require(state['frames'] == state['ends'] == 1 and state['data'] == 32, 'DATA count differs')
        if case == 'continue_ready':
            require(item['ends'] == 1 and item['bytes'] == 32 and item['sha256'] == model.H32 and not item['active'], 'ready END differs')
            continue
        require(item['paused'] and item['active'] and item['bytes'] == item['chunks'] == item['ends'] == 0,
                'paused DATA accepted prefix or completed early')
        status = adapter.start(context, 'GET', '/status/continue_paused', (), True, False, 4095)
        before = copy.deepcopy(app)
        entries = [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', '/resume/continue_paused')]
        for _ in range(2):
            rejects(lambda: send_head(result, entries), 'request before preceding response')
            require(app == before and not state['resumed'], 'queued paused status allowed resume')
        observed = adapter.finish(context, status, connection['receive'])
        require(observed['body'] and state['pause_delivered'], 'paused status not delivered')
        continue_quota_cases.resume(context, connection['receive'], stream)
        continue_quota_cases.complete(context, connection['receive'], stream, case)
        require(item['ends'] == 1 and item['bytes'] == 32 and item['sha256'] == model.H32 and not item['paused'], 'resume completion differs')
    print('metadata, delivered100, DATA/END, zero accepted paused prefix, delivered status and actual resume are distinct')


def refusal_rollback():
    app, result, context = open_peer('begin_failure_rollback')
    state, connection = result['state'], result['connection']
    stream = start_upload(context, 'begin_failure')
    item = app['records']['begin_failure']
    require((item['middleware'], item['attempts'], item['failures'], item['begins'], item['ends'], item['bytes']) ==
            (1, 1, 1, 0, 0, 0), 'failed begin facts differ')
    require(state['allocated'] == state['released'] == state['rollbacks'] == 1 and state['slots'] == [None, None], 'slot not rolled back')
    before, counts = copy.deepcopy(app), summary(state)
    for _ in range(2):
        rejects(lambda: connection['send'](frame(0, 1, stream, model.payload_span(32, 0, 32))), 'DATA ordinal differs')
        require(app == before and summary(state) == counts, 'refused DATA changed facts')
    packet, stamp = connection['receive']()
    require(packet[3:5] == bytes((1, 5)) and state['resets_delivered'] == 0, 'refusal HEADERS first differs')
    adapter.observe(context, packet, stamp)
    packet, stamp = connection['receive']()
    require(packet == frame(3, 0, stream, bytes(4)) and state['resets_delivered'] == 1, 'NO_ERROR reset differs')
    adapter.observe(context, packet, stamp)
    require(state['informationals_queued'] == state['informationals_delivered'] == 0, 'refusal allowed Continue')
    recovery = start_upload(context, 'begin_recovery')
    require(state['slots'] == ['begin_recovery', None] and state['allocated'] == 2, 'rollback slot unavailable')
    adapter.send_data(context, recovery, model.payload_span(32, 0, 32), True)
    continue_quota_cases.complete(context, connection['receive'], recovery, 'begin_recovery')
    require(state['released'] == 2, 'recovery slot leaked')
    print('failed attempt has no begin, rolls back actual slot, final503 precedes reset0 without body/100, recovery reuses slot')


def quota_barriers():
    app, result, context = open_peer('quota_refuse')
    state, connection = result['state'], result['connection']
    one = start_upload(context, 'quota_holder_one')
    two = start_upload(context, 'quota_holder_two')
    require(state['slots'] == ['quota_holder_one', 'quota_holder_two'] and state['data'] == 0, 'two independent active slots missing')
    before = copy.deepcopy(app)
    for _ in range(2):
        rejects(lambda: connection['send'](frame(0, 1, one, model.payload_span(32, 0, 32))), 'quota DATA barrier differs')
        require(app == before, 'DATA bypassed first active metric/refusal barrier')
    continue_quota_cases.active(context, connection['receive'], (), ('quota_holder_one', 'quota_holder_two'), ())
    refused = start_upload(context, 'quota_refuse')
    require(app['records']['quota_refuse']['middleware'] == 1 and app['records']['quota_refuse']['attempts'] == 0,
            'full quota attempted begin')
    adapter.finish(context, refused, connection['receive'], keep=True)
    for stream in (one, two):
        adapter.send_data(context, stream, model.payload_span(32, 0, 32), True)
    for stream, tag in ((one, 'quota_holder_one'), (two, 'quota_holder_two')):
        continue_quota_cases.complete(context, connection['receive'], stream, tag)
    require(state['slots'] == [None, None], 'holder slots not released')
    continue_quota_cases.active(context, connection['receive'], ('quota_holder_one', 'quota_holder_two'), (), ('quota_refuse',))
    require(state['metric_cursor'] == state['metric_delivered'] == 2, 'metric2/0 delivery missing')
    print('two actual holders earn active2; refusal never attempts begin; both ENDs earn active0 before recovery')


def malformed():
    fields = [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', '/health')]
    for entries in (fields + [(':path', '/health')], fields[:-1], list(reversed(fields)), fields + [('x-extra', 'v')]):
        app, result, _context = open_peer('continue_ready', health=False)
        before = copy.deepcopy(app)
        for _ in range(2):
            rejects(lambda: send_head(result, entries), 'request contract differs')
            require(app == before and result['state']['cursor'] == 0, 'invalid metadata earned facts')
    for stream, flags in ((3, 5), (1, 4), (1, 13), (0x80000001, 5)):
        app, result, _context = open_peer('continue_ready', health=False)
        rejects(lambda: send_head(result, fields, flags, stream), 'request contract differs')
        require(app['heads'] == 0, 'bad stream or flags earned HEADERS')
    for payload, flags in ((b'x' * 32, 1), (model.payload_span(32, 0, 32), 0), (b'', 1)):
        app, result, context = open_peer('continue_ready')
        stream = start_upload(context, 'continue_ready')
        continue_quota_cases.wait_continue(context, result['connection']['receive'], stream)
        before, counts = copy.deepcopy(app), summary(result['state'])
        for _ in range(2):
            rejects(lambda: result['connection']['send'](frame(0, flags, stream, payload)))
            require(app == before and summary(result['state']) == counts, 'invalid DATA earned facts')
    print('exact header order/multiplicity/flags/stream and DATA ordinal/payload rejection before facts, twice')


def actual_chain():
    app, selection = new_app(), peer.NAMES
    previous = None
    for index, case in enumerate(selection):
        supplied, result, context = open_peer(case, app=app, prior=selection[:index], final=index == 3, health=False)
        require(supplied is app, 'application reference changed')
        if previous is not None:
            require(all(context[name] is not previous[name] for name in ('protocol', 'raw', 'request', 'credit')), 'new connection shared ledger')
        adapter.run_case(context, result['connection']['receive'])
        state = result['state']
        model.validate_records(selection[:index + 1], 'before', app['records'])
        require(state['final_requests'] == 0, 'final permission executed early')
        if index == 3:
            final_boundary(result, context)
        require(state['responses_queued'] == state['responses_delivered'], 'response receipts differ')
        require(state['informationals_queued'] == state['informationals_delivered'] == int(case.startswith('continue_')), 'informational receipts differ')
        require(state['resets_queued'] == state['resets_delivered'] == int(case in ('quota_refuse', 'begin_failure_rollback')), 'reset receipts differ')
        require(state['allocated'] == state['released'] and state['slots'] == [None, None], 'slot retention differs')
        if case == 'quota_refuse':
            require(state['metric_cursor'] == state['metric_delivered'] == 4, 'actual2/0/2/0 metrics incomplete')
        previous = context
    require(app['heads'] == 91, 'four cases plus final68 head total differs')
    _app, result, context = open_peer('continue_ready', health=False)
    adapter.run_case(context, result['connection']['receive'])
    rejects(lambda: adapter.final_collection(context, result['connection']['receive']), 'request beyond finite schedule')
    _app, result, context = open_peer('continue_ready', final=True, health=False)
    rejects(lambda: adapter.final_collection(context, result['connection']['receive']))
    require(result['state']['cursor'] == 0, 'early final earned request')
    print('actual shared four-case chain, independent connections, final68/heads91 preserve parser/ledgers/debt/deadlines/caps')


def probe_error_priority():
    original = adapter.start
    failure, calls = ValueError('original start failure'), []

    def fail(*_args, **_kwargs):
        calls.append(1)
        raise failure

    def driver(_case):
        adapter.start(None, 'POST', '/limit/continue_ready')

    adapter.start = fail
    try:
        try:
            premature_delivery(driver)
        except ValueError as exc:
            require(exc is failure, 'probe replaced original error')
        else:
            raise ValueError('probe swallowed original error')
        require(calls == [1] and adapter.start is fail, 'probe did not restore on failure')
    finally:
        adapter.start = original
    print('driver probe original exactly once; original error identity and failure restoration preserved')


def full_check():
    constructor()
    constructor_rejections()
    premature_delivery(peer.check)
    probe_error_priority()
    continuation_timing()
    refusal_rollback()
    quota_barriers()
    malformed()
    bounds()
    hpack_limits()
    actual_chain()
    retained_supplied_fixture()


def main():
    if sys.argv[1:] == ['--constructor']:
        constructor()
        return
    if sys.argv[1:] == ['--baseline-delivery']:
        baseline_delivery()
        return
    if sys.argv[1:] == ['--delivery']:
        premature_delivery(peer.check)
        return
    if sys.argv[1:] == ['--check']:
        full_check()


if __name__ == '__main__':
    main()
