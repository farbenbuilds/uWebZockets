"""Explicit source, identity, history, receipt and current-helper audit."""
import ast
import builtins
from contextlib import ExitStack
import difflib
import importlib.util
import json
import os
import pathlib
import socket
import ssl
import subprocess
import sys
import time
from unittest import mock
import capture


def require(value, message):
    if not value:
        raise ValueError(message)


def reject(*_args, **_kwargs):
    raise RuntimeError('helper invoked effect')


def inert(path, code, argv, name):
    replacements = ((builtins, 'open'), (pathlib.Path, 'open'), (pathlib.Path, 'read_bytes'),
                    (pathlib.Path, 'read_text'), (pathlib.Path, 'write_bytes'), (pathlib.Path, 'write_text'),
                    (pathlib.Path, 'mkdir'), (pathlib.Path, 'resolve'), (socket, 'socket'), (ssl, 'SSLContext'),
                    (subprocess, 'run'), (subprocess, 'Popen'), (time, 'time'), (time, 'monotonic'),
                    (time, 'perf_counter'), (time, 'sleep'), (sys.stdout, 'write'), (sys.stderr, 'write'))
    with ExitStack() as stack:
        stack.enter_context(mock.patch.object(sys, 'argv', argv))
        for module, field in replacements:
            stack.enter_context(mock.patch.object(module, field, reject))
        exec(code, dict(__name__=name, __file__=str(path)))


def strict_nesting(node, depth=0):
    if isinstance(node, (ast.FunctionDef, ast.Lambda)):
        depth = 0
    if isinstance(node, (ast.If, ast.For, ast.While, ast.Try, ast.With)):
        depth += 1
    return max([depth] + [strict_nesting(child, depth) for child in ast.iter_child_nodes(node)])


def helper_audit(unit, output, pinned):
    depths = {}
    for path in sorted(unit.rglob('*.py')):
        tree = ast.parse(path.read_text(), filename=str(path))
        guards = [node for node in tree.body if isinstance(node, ast.If) and "__name__ == '__main__'" in ast.unparse(node.test)]
        require(len(guards) == 1, 'helper main guard: ' + str(path))
        require(not any(isinstance(node, (ast.ClassDef, ast.Assert, ast.Global)) for node in ast.walk(tree)), 'helper forbidden construct')
        depth = max(pinned.nesting(tree), strict_nesting(tree))
        require(depth <= 3, 'helper nesting: ' + str(path))
        code = compile(tree, str(path), 'exec')
        for argv, name in (([], 'inert_helper'), (['foreign', '--run', 'unexpected'], 'inert_helper'),
                           ([], '__main__'), (['foreign', '--run', 'unexpected'], '__main__')):
            inert(path, code, argv, name)
        depths[str(path.relative_to(unit))] = dict(depth=depth, accepted_depth=pinned.nesting(tree), strict_depth=strict_nesting(tree), sha256=capture.digest(path))
    capture.write_json(output / 'helper-depths.json', depths)
    print('ALL current unit helpers guarded/inert imports+main empty/foreign argv: %d; max nesting %d' %
          (len(depths), max(item['depth'] for item in depths.values())))


def check_receipts(unit, output, sources):
    receipts = {}
    for name in ('cover-continue-normal', 'cover-continue-optimized', 'cover-imports-normal', 'cover-imports-optimized',
                 'final-direct-normal', 'final-direct-optimized'):
        directory = unit / name
        require(json.loads((directory / 'source-before.json').read_text()) == sources ==
                json.loads((directory / 'source-after.json').read_text()), 'receipt source binding: ' + name)
        require(json.loads((directory / 'exit.json').read_text()) == {'exit_code': 0}, 'receipt exit: ' + name)
        require((directory / 'stderr.txt').read_bytes() == b'', 'receipt stderr: ' + name)
        command = json.loads((directory / 'command.json').read_text())
        restoration = json.loads(pathlib.Path(command['restoration']).read_text())
        require(restoration['authority_entries'] == 119 and restoration['physical_rows_checked'] == 118 and
                restoration['unique_resolved_files'] == 113 and restoration['ordered_codec_files_checked'] == 42,
                'receipt restored identity: ' + name)
        require(command['argv'][1:3] == ['-B', '-S'] and ('-O' in command['argv']) == name.endswith('optimized'), 'receipt flags')
        receipts[name] = {path.name: capture.digest(path) for path in sorted(directory.iterdir()) if path.is_file()}
    capture.write_json(output / 'covering-receipts.json', receipts)
    print('Four final covering checks and two direct normal/optimized proofs: exact source bindings, exit0, empty stderr')


def main(output):
    unit = pathlib.Path(__file__).resolve().parent
    root = unit.parent.parent
    output.mkdir()
    spec = importlib.util.spec_from_file_location('pinned_source_audit', root / 'evidence/core-peer/audit.py')
    pinned = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pinned)
    original_cwd = pathlib.Path.cwd()
    try:
        os.chdir('/workspaces/uWebZockets')
        pinned.immutable(root, output)
    finally:
        os.chdir(original_cwd)
    pinned.structure(root, output)
    sources = capture.source_map(root)
    guards = {}
    for path in sorted(root.glob('*.py')):
        tree = ast.parse(path.read_text())
        guards[path.name] = any(isinstance(node, ast.If) and "__name__ == '__main__'" in ast.unparse(node.test) for node in tree.body)
    require(all(guards.values()), 'source main guard missing')
    capture.write_json(output / 'source-guards.json', guards)
    before = json.loads((unit / 'baseline/source.json').read_text())
    require(len(sources) == 40 and set(sources) == set(before), 'source inventory changed')
    require([name for name in sources if sources[name] != before[name]] == ['test_continue_quota.py'], 'source ownership differs')
    capture.write_json(output / 'source.json', sources)
    old = (unit / 'baseline/test_continue_quota.py.txt').read_text().splitlines(True)
    new = (root / 'test_continue_quota.py').read_text().splitlines(True)
    (output / 'test_continue_quota.diff').write_text(''.join(difflib.unified_diff(old, new, fromfile='before/test_continue_quota.py', tofile='current/test_continue_quota.py')))
    old_boundary = old[old.index('def before_continue():\n'):old.index('def main():\n')]
    new_boundary = new[new.index('def before_continue():\n'):new.index('def main():\n')]
    require(old_boundary == new_boundary, 'original direct before_continue changed')
    history = json.loads((unit / 'baseline/prior_history.json').read_text())
    current_history = {str(path.relative_to(root)): capture.digest(path) for path in sorted((root / 'evidence').rglob('*'))
                       if path.is_file() and not path.is_relative_to(unit)}
    require(current_history == history, 'prior history map changed')
    for name, expected in history.items():
        require(capture.digest(root / name) == expected, 'historical evidence changed: ' + name)
    capture.write_json(output / 'history.json', dict(files=len(history), all_preserved=True))
    helper_audit(unit, output, pinned)
    check_receipts(unit, output, sources)
    print('Current40: one changed, 39 unchanged; all %d prior evidence files preserved' % len(history))


if __name__ == '__main__' and len(sys.argv) == 3 and sys.argv[1] == '--audit':
    main(pathlib.Path(sys.argv[2]))
