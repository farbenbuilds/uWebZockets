"""Serialized application failures; supplied peer records are model-derived synthetic input."""
import hashlib
import json
import adapter
import h2_client
import hpack
import model
import test_ready


def terminal(tag):
    item = model.record(tag, True, 'after')
    item.update(chunks=2 if tag in ('sink_error', 'invalid_progress') else 1,
                max_span=8 if tag in ('sink_error', 'invalid_progress') else 32)
    return item


def paths(case):
    result = ['/health', '/echo', '/limit/' + case + '?case=' + case]
    if case != 'end_error':
        result.append('/status/' + case)
    return result + ['/status/' + case, '/control/resume/' + case, '/control/cancel/' + case,
                     '/limit/' + case + '_recovery?case=' + case + '_recovery',
                     '/control/resume/' + case, '/control/cancel/' + case, '/health']


def check(case, *, app=None, prior=(), final=False, fault=None):
    decoder, encoder = hpack.Decoder(), hpack.Encoder()
    if app is None:
        app = {'records': {tag: model.record(tag, False, 'before') for tag in model.SPECS}, 'heads': 0}
    model.validate_records(prior, 'before', app['records'])
    state = dict(startup=True, buffer=bytearray(), pending=[], heads=0, streams={}, payloads={},
                 statuses=0, stale=0, terminated=False, resets=0, settings=0, refunded=False,
                 refund_queued=False, sibling_done=False, recovery_done=False, final=False, reads=0)
    order, caller_time = paths(case), [1]
    primary_length = 32 if case == 'end_error' else 15
    preterminal_count = int(case != 'end_error')

    def clock():
        caller_time[0] += 1
        return caller_time[0]

    def response(stream, body):
        block = encoder.encode(((':status', '200'), ('x-middleware', 'retained')))
        state['pending'].append(test_ready.frame(1, 4, stream, block) + test_ready.frame(0, 1, stream, body))

    def terminate():
        if state['terminated'] or state['statuses'] != preterminal_count:
            raise RuntimeError('terminal callback ordinal differs')
        state['terminated'] = True
        item = terminal(case)
        item.update(stale_resume=0, stale_cancel=0)
        changes = {'terminal_reason': ('reason', 'reset'), 'terminal_metadata': ('metadata_begin', 0),
                   'terminal_cancel': ('cancels', 1 if case == 'end_error' else 2),
                   'terminal_ends': ('ends', 0 if case == 'end_error' else 1),
                   'terminal_bytes': ('bytes', 15), 'terminal_hash': ('sha256', model.EMPTY_HASH),
                   'terminal_chunks': ('chunks', 1), 'chunk_diagnostic': ('chunk_errors', 0),
                   'progress_diagnostic': ('invalid_progress', 0), 'end_diagnostic': ('end_errors', 0)}
        if fault in changes:
            key, value = changes[fault]
            item[key] = value
        app['records'][case] = item
        code = 8 if fault == 'reset_code' else 2
        reset = test_ready.frame(3, 0, 5, code.to_bytes(4, 'big'))
        state['resets'] += 1
        if fault == 'primary_final':
            response(5, b'')
        elif fault == 'split_reset':
            state['pending'].extend((reset[:11], reset[11:]))
        elif fault != 'missing_reset':
            state['pending'].append(reset + (reset if fault == 'duplicate_reset' else b''))

    def queue_refund():
        if state['refund_queued'] or state['stale'] != 2:
            raise RuntimeError('primary refund ordinal differs')
        state['refund_queued'] = True
        if fault != 'missing_refund':
            amount = primary_length + int(fault == 'excess_refund')
            state['pending'].append(test_ready.frame(8, 0, 0, amount.to_bytes(4, 'big')))

    def status(stream, tag):
        item = dict(app['records'][tag])
        if not state['final']:
            if tag != case or state['statuses'] >= preterminal_count + 1 or state['stale']:
                raise RuntimeError('status count tag or stale ordinal differs')
            if state['terminated'] != (state['statuses'] == preterminal_count):
                raise RuntimeError('status terminal ordinal differs')
            length = primary_length if state['terminated'] else 7
            if state['payloads'][5]['count'] != length:
                raise RuntimeError('status DATA barrier differs')
            state['statuses'] += 1
            if not state['terminated'] and fault == 'preterminal_bytes':
                item['bytes'] = 8
            if not state['terminated'] and fault == 'preterminal_pause':
                item['paused'] = True
            if not state['terminated'] and fault == 'preterminal_cancel':
                item['cancels'] = 1
        response(stream, json.dumps(item).encode())

    def control(stream, path):
        _, _, action, tag = path.split('/')
        expected_action = 'resume' if state['stale'] % 2 == 0 else 'cancel'
        if tag != case or not state['terminated'] or action != expected_action or state['stale'] >= 4:
            raise RuntimeError('stale control binding or ordinal differs')
        if state['statuses'] != preterminal_count + 1 or (state['stale'] >= 2) != state['recovery_done']:
            raise RuntimeError('stale recovery barrier differs')
        if state['stale'] == 0:
            retained = (5 in context['records'], 5 in context['raw']['streams'], 5 in context['stage']['active'],
                        5 in context['credit']['streams'])
            outgoing = context['request']['streams'][5]
            if any(retained) or not outgoing['retired'] or not outgoing['reset'] or not outgoing['response_end']:
                raise RuntimeError('paired primary retirement differs')
        state['stale'] += 1
        if fault != 'stale_counter':
            app['records'][case]['stale_' + action] += 1
        response(stream, b'ok' if fault == 'stale_reply' else b'BodyControlExpired')
        if state['stale'] == 2:
            queue_refund()

    def request(path, stream):
        if path.startswith('/status/'):
            status(stream, path[8:])
            return
        if path.startswith('/control/'):
            control(stream, path)
            return
        if path == '/health':
            if state['heads'] == len(paths(case)) and (state['stale'], state['sibling_done'], state['recovery_done']) != (4, True, True):
                raise RuntimeError('final health barrier differs')
            response(stream, b'ok')
            return
        if path != '/metrics' or not state['final']:
            raise RuntimeError('unexpected auxiliary request')
        values = {key: sum(item[key] for item in app['records'].values()) for key in model.COMMON_COUNTERS + ('bytes',)}
        values.update(active=0, paused=0, buffered_middleware=app['heads'] - values['middleware'],
                      slot0_active=False, slot1_active=False)
        response(stream, json.dumps(values).encode())

    def upload_headers(entries, stream, flags, tag):
        target = '/echo' if tag == 'sibling' else '/limit/' + tag + '?case=' + tag
        fields = [('content-length', '1')] if tag == 'sibling' else [('content-length', '32'), ('x-case', tag)]
        expected = [(':method', 'POST'), (':scheme', 'https'), (':authority', 'localhost'), (':path', target)] + fields
        if entries != expected or flags != 4:
            raise RuntimeError('upload headers or initial END differ')
        if tag == 'sibling' and stream != 3 or tag == case and stream != 5:
            raise RuntimeError('primary sibling binding differs')
        state['streams'][stream] = tag
        state['payloads'][stream] = dict(count=0, frames=0, digest=hashlib.sha256())
        if tag == 'sibling' or tag == case:
            return
        if (state['stale'], state['sibling_done'], state['refunded']) != (2, True, True):
            raise RuntimeError('recovery isolation barrier differs')

    def headers(packet, stream, flags):
        entries = list(decoder.decode(packet[9:]))
        path = dict(entries)[':path']
        index = state['heads']
        if stream != 2 * index + 1 or index >= len(order) or path != order[index]:
            raise RuntimeError('request order or stream binding differs')
        state['heads'] += 1
        app['heads'] += 1
        if path == '/echo' or path.startswith('/limit/'):
            tag = 'sibling' if path == '/echo' else path.split('/')[-1].split('?')[0]
            upload_headers(entries, stream, flags, tag)
            return
        if entries != [(':method', 'GET'), (':scheme', 'https'), (':authority', 'localhost'), (':path', path)] or flags != 5:
            raise RuntimeError('auxiliary headers differ')
        request(path, stream)

    def primary_data(stream, payload, flags, item):
        ordinal = item['frames'] - 1
        length = 32 if case == 'end_error' else 7 if ordinal == 0 else 8
        if ordinal > int(case != 'end_error') or payload != model.payload_span(32, 0, length) or flags != int(case == 'end_error'):
            raise RuntimeError('primary DATA bytes END or ordinal differs')
        if ordinal == 1 and state['statuses'] != 1:
            raise RuntimeError('missing accepted-prefix barrier')
        if case == 'end_error' or ordinal == 1:
            terminate()
            return
        before = terminal(case)
        before.update(bytes=7, sha256=model.H7, chunks=1, max_span=7, cancels=0, ends=0,
                      chunk_errors=0, invalid_progress=0, active=True, reason=None, stale_resume=0, stale_cancel=0)
        app['records'][case] = before
        if fault == 'early_final':
            response(stream, b'')

    def data(packet, stream, flags):
        tag, payload = state['streams'][stream], packet[9:]
        item = state['payloads'][stream]
        item['frames'] += 1
        item['count'] += len(payload)
        item['digest'].update(payload)
        if tag == case:
            primary_data(stream, payload, flags, item)
            return
        expected = b's' if tag == 'sibling' else model.payload_span(32, 0, 32)
        if payload != expected or flags != 1 or item['frames'] != 1:
            raise RuntimeError('sibling recovery DATA bytes END or ordinal differs')
        if tag == 'sibling':
            if (state['stale'], state['refunded'], context['request']['connection_debt']) != (2, True, 1):
                raise RuntimeError('sibling DATA before stale and actual refund barrier')
            state['sibling_done'] = True
            response(stream, b'x' if fault == 'sibling_echo' else b's')
            return
        if not state['sibling_done'] or state['stale'] != 2:
            raise RuntimeError('recovery DATA ordinal differs')
        state['recovery_done'] = True
        app['records'][tag] = terminal(tag)
        if fault == 'recovery_record':
            app['records'][tag]['metadata_end'] = 0
        if fault == 'other_record':
            app['records']['empty_headers']['middleware'] = 1
        response(stream, json.dumps(app['records'][tag]).encode())

    def packet_received(packet):
        kind, flags, stream = packet[3], packet[4], int.from_bytes(packet[5:9], 'big')
        if kind == 1:
            headers(packet, stream, flags)
            return
        if kind == 0:
            data(packet, stream, flags)
            return
        if kind != 4 or flags != 1 or len(packet) != 9 or stream:
            raise RuntimeError('unexpected frame or settings ACK')
        state['settings'] += 1

    def send(data_bytes):
        if type(data_bytes) is not bytes or len(data_bytes) > 8192:
            raise RuntimeError('send bound differs')
        if state['startup']:
            state['startup'] = False
            if data_bytes[:24] != b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n' or len(data_bytes) != 75:
                raise RuntimeError('startup differs')
            return
        state['buffer'].extend(data_bytes)
        while len(state['buffer']) >= 9:
            size = int.from_bytes(state['buffer'][:3], 'big')
            if len(state['buffer']) < size + 9:
                return
            packet = bytes(state['buffer'][:size + 9])
            del state['buffer'][:size + 9]
            packet_received(packet)

    def receive():
        state['reads'] += 1
        if not state['pending'] or state['reads'] > 200:
            raise RuntimeError('missing finite synthetic response')
        packet = state['pending'].pop(0)
        if packet[3:4] == b'\x08':
            if state['stale'] != 2 or state['refunded']:
                raise RuntimeError('refund read ordinal differs')
            state['refunded'] = True
        return packet, clock()

    context = adapter.open_case(case, h2_client.new_protocol(), send, 1, 30001, 900001, selected_before=prior, clock=clock)
    if context['stage']['primary'] != 5:
        raise RuntimeError('primary binding differs')
    settings = b''.join(k.to_bytes(2, 'big') + v.to_bytes(4, 'big') for k, v in ((1, 4096), (2, 0), (3, 8), (6, 4096), (8, 1)))
    adapter.observe(context, test_ready.frame(4, 0, 0, settings) + test_ready.frame(4, 1, 0, b''), clock())
    adapter.run_case(context, receive)
    budget = (10, 9, 65) if case == 'end_error' else (11, 10, 48)
    actual = (state['heads'], context['stage']['case_state']['small'], context['request']['case']['sent'])
    if actual != budget or state['heads'] != len(order) or state['settings'] != 1 or state['resets'] != 1 or state['pending'] or state['buffer']:
        raise RuntimeError('exact J C R settings reset or pending count differs')
    for stream, item in state['payloads'].items():
        tag = state['streams'][stream]
        expected = b's' if tag == 'sibling' else model.payload_span(32, 0, 32)
        if tag == case and case != 'end_error':
            expected = model.payload_span(32, 0, 7) + model.payload_span(32, 0, 8)
        if item['frames'] != (2 if tag == case and case != 'end_error' else 1) or item['count'] != len(expected) or item['digest'].hexdigest() != hashlib.sha256(expected).hexdigest():
            raise RuntimeError('final upload count or hash differs')
    selection = prior + (case,)
    if final:
        state['final'] = True
        order.extend('/status/' + tag for tag in model.SPECS)
        order.append('/metrics')
        adapter.final_collection(context, receive)
        if state['heads'] != len(order) or state['pending'] or state['buffer']:
            raise RuntimeError('shared final collection differs')
    model.validate_records(selection, 'before', app['records'])
    print(case + ' passed: J=%d C=%d R=%d' % actual)
    return app


def rejected(case, fault, message, *, final=False):
    try:
        check(case, fault=fault, final=final)
    except (ValueError, RuntimeError) as exc:
        if str(exc) != message:
            raise RuntimeError('control rejected for wrong reason: ' + fault) from exc
        print(fault + ' rejected: ' + str(exc))
        return
    raise RuntimeError('control accepted: ' + fault)


def main():
    app, prior = None, ()
    for case in ('sink_error', 'invalid_progress', 'end_error'):
        app = check(case, app=app, prior=prior, final=case == 'end_error')
        prior += (case,)
    for case in ('sink_error', 'invalid_progress', 'end_error'):
        check(case, fault='split_reset')
        for fault, message in (('terminal_reason', 'record mismatch: reason'), ('terminal_metadata', 'record mismatch: metadata_begin'),
                               ('terminal_cancel', 'record mismatch: cancels'), ('terminal_ends', 'record mismatch: ends'),
                               ('terminal_bytes', 'record mismatch: bytes'), ('terminal_hash', 'record mismatch: sha256'),
                               ('stale_reply', 'control result differs'), ('missing_refund', 'missing finite synthetic response'),
                               ('excess_refund', 'invalid connection refund'), ('sibling_echo', 'sibling echo differs'),
                               ('recovery_record', 'record mismatch: metadata_end'), ('stale_counter', 'record mismatch: stale_resume'),
                               ('primary_final', 'unexpected final'), ('reset_code', 'wrong reset code'),
                               ('duplicate_reset', 'invalid reset'), ('missing_reset', 'missing finite synthetic response')):
            rejected(case, fault, message, final=fault == 'stale_counter')
        rejected(case, 'other_record', 'record mismatch: middleware', final=True)
    for case in ('sink_error', 'invalid_progress'):
        for fault, message in (('preterminal_bytes', 'record mismatch: bytes'), ('preterminal_pause', 'record mismatch: paused'),
                               ('preterminal_cancel', 'record mismatch: cancels'), ('terminal_chunks', 'failure callback follows accepted prefix'),
                               ('early_final', 'upload completed before resume')):
            rejected(case, fault, message)
    rejected('sink_error', 'chunk_diagnostic', 'record mismatch: chunk_errors')
    rejected('invalid_progress', 'progress_diagnostic', 'record mismatch: invalid_progress')
    rejected('end_error', 'end_diagnostic', 'record mismatch: end_errors')


if __name__ == '__main__':
    main()
